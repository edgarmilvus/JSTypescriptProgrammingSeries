/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// UpdateManager.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, Button, Modal, ActivityIndicator, StyleSheet, Alert } from 'react-native';
import * as Updates from 'expo-updates';

type UpdateState = 'idle' | 'checking' | 'downloading' | 'updateAvailable' | 'applied' | 'error';

export const UpdateManager: React.FC = () => {
  const [updateState, setUpdateState] = useState<UpdateState>('idle');
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    checkForUpdates();
  }, []);

  const checkForUpdates = async () => {
    try {
      setUpdateState('checking');
      
      // Check for updates
      const { isAvailable } = await Updates.checkForUpdateAsync();
      
      if (isAvailable) {
        setUpdateState('updateAvailable');
      } else {
        setUpdateState('idle');
      }
    } catch (error) {
      console.error('Error checking for updates:', error);
      setUpdateState('error');
    }
  };

  // Optimistic UI Pattern: Update state immediately, simulate progress, then execute
  const handleDownloadAndApply = async () => {
    // 1. Immediate State Change (Optimistic)
    setUpdateState('downloading');
    setDownloadProgress(0);

    // 2. Simulate Download Progress (Mocking for demonstration)
    // In a real app, expo-updates handles the download, but progress events are limited.
    // We use setTimeout to simulate the UI feeling responsive.
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress >= 100) {
        clearInterval(interval);
        finishDownload();
      } else {
        setDownloadProgress(progress);
      }
    }, 200);
  };

  const finishDownload = async () => {
    try {
      // 3. Actual Download and Fetch Update
      const update = await Updates.fetchUpdateAsync();
      
      if (update.isNew) {
        // 4. Apply Update
        await Updates.reloadAsync();
        setUpdateState('applied');
      } else {
        setUpdateState('idle');
      }
    } catch (error) {
      console.error('Download failed:', error);
      setUpdateState('error');
    }
  };

  const handleRollback = () => {
    // Mock rollback logic: In Expo, you can't strictly "rollback" a JS bundle 
    // without a new OTA containing the old code, or using EAS Update aliases.
    // For this exercise, we reset to idle.
    Alert.alert("Rollback", "Reverting to previous stable state.");
    setUpdateState('idle');
  };

  const renderContent = () => {
    switch (updateState) {
      case 'checking':
        return <ActivityIndicator size="large" color="#0000ff" />;

      case 'updateAvailable':
        return (
          <View>
            <Text>New version available!</Text>
            <Button title="Download Update" onPress={handleDownloadAndApply} />
          </View>
        );

      case 'downloading':
        return (
          <View>
            <Text>Downloading... {downloadProgress}%</Text>
            {/* Visual Progress Bar */}
            <View style={[styles.progressBar, { width: `${downloadProgress}%` }]} />
          </View>
        );

      case 'applied':
        return (
          <View>
            <Text>Update Ready!</Text>
            <Button title="Restart App" onPress={() => Updates.reloadAsync()} />
          </View>
        );

      case 'error':
        return (
          <View>
            <Text style={{ color: 'red' }}>Update Failed.</Text>
            <Button title="Retry" onPress={checkForUpdates} />
            <Button title="Rollback" onPress={handleRollback} />
          </View>
        );

      default:
        return <Text>App is up to date.</Text>;
    }
  };

  return (
    <Modal visible={true} animationType="slide">
      <View style={styles.container}>
        {renderContent()}
        <Button title="Close" onPress={() => setUpdateState('idle')} />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  progressBar: { height: 10, backgroundColor: 'green', marginTop: 10 }
});
