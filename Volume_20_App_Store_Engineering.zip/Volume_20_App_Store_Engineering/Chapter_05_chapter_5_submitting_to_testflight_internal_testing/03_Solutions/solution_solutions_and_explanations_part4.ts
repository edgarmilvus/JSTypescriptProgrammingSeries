/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// uploadSymbols.ts
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Simulates the Crashlytics API client.
 * In a real scenario, this would use the Firebase Admin SDK or REST API.
 */
class CrashlyticsAPI {
  async uploadDsym(filePath: string, version: string, commit: string): Promise<boolean> {
    console.log(`[API] Uploading ${filePath} for version ${version} (${commit})...`);
    // Simulate network failure 30% of the time for testing retry logic
    if (Math.random() < 0.3) {
      throw new Error('Network Error: Timeout');
    }
    return true;
  }

  async verifySymbolsExist(version: string): Promise<boolean> {
    console.log(`[API] Verifying symbols for version ${version}...`);
    // Simulate verification check
    return true; 
  }
}

/**
 * Implements Tool Use Reflection: Execute -> Verify -> Retry if needed.
 */
class SymbolUploader {
  private api = new CrashlyticsAPI();
  private maxRetries = 3;

  /**
   * Finds .dSYM files in the build directory.
   */
  private findDsymFiles(buildDir: string): string[] {
    // Simplified search logic
    const files: string[] = [];
    if (fs.existsSync(buildDir)) {
        files.push(path.join(buildDir, 'App.dSYM')); // Mock path
    }
    return files;
  }

  /**
   * Uploads symbols with exponential backoff and verification.
   */
  async uploadWithReflection(dsymPath: string, version: string, commit: string) {
    let attempt = 0;
    let uploaded = false;

    while (attempt < this.maxRetries && !uploaded) {
      try {
        // 1. ACT: Upload
        await this.api.uploadDsym(dsymPath, version, commit);

        // 2. REFLECT (Verify): Check if the upload was successful
        const verified = await this.api.verifySymbolsExist(version);
        
        if (verified) {
          console.log('✅ Upload verified successfully.');
          uploaded = true;
        } else {
          throw new Error('Verification failed: Symbols not found on server.');
        }
      } catch (error) {
        attempt++;
        console.error(`❌ Attempt ${attempt} failed:`, error.message);
        
        if (attempt < this.maxRetries) {
          // Exponential Backoff: 2^attempt * 1000ms
          const waitTime = Math.pow(2, attempt) * 1000;
          console.log(`⏳ Retrying in ${waitTime / 1000}s...`);
          await new Promise((resolve) => setTimeout(resolve, waitTime));
        }
      }
    }

    if (!uploaded) {
      throw new Error('Failed to upload and verify symbols after max retries.');
    }
  }

  async run(buildDir: string) {
    const version = '1.0.0'; // Should be dynamic from build
    const commit = process.env.GIT_COMMIT_HASH || 'unknown';
    
    const dsyms = this.findDsymFiles(buildDir);
    
    if (dsyms.length === 0) {
      console.warn('No dSYM files found.');
      return;
    }

    for (const dsym of dsyms) {
      await this.uploadWithReflection(dsym, version, commit);
    }
  }
}

// Execution
const uploader = new SymbolUploader();
uploader.run('./build-artifacts').catch((e) => {
  console.error(e);
  process.exit(1);
});
