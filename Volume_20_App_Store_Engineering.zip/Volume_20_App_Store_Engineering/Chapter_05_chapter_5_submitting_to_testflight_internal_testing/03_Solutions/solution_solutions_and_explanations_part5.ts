/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// useTestFlightStore.ts (Zustand Store)
import create from 'zustand';

interface Tester {
  email: string;
  status: 'pending' | 'invited';
}

interface BuildState {
  version: string;
  buildNumber: string;
  processingState: 'PROCESSING' | 'FAILED' | 'COMPLETED';
  testers: Tester[];
}

interface Store {
  build: BuildState | null;
  isLoading: boolean;
  error: string | null;
  fetchBuild: (appId: string) => Promise<void>;
  inviteTester: (email: string) => Promise<void>;
}

// Mock API delay
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const useTestFlightStore = create<Store>((set, get) => ({
  build: null,
  isLoading: false,
  error: null,

  fetchBuild: async (appId: string) => {
    set({ isLoading: true, error: null });
    try {
      // Mock API Fetch
      await delay(500);
      const mockData: BuildState = {
        version: '2.1.0',
        buildNumber: '123',
        processingState: 'COMPLETED',
        testers: [{ email: 'qa@example.com', status: 'invited' }],
      };
      set({ build: mockData });
    } catch (e) {
      set({ error: 'Failed to fetch build status' });
    } finally {
      set({ isLoading: false });
    }
  },

  inviteTester: async (email: string) => {
    const currentBuild = get().build;
    if (!currentBuild) return;

    // 1. OPTIMISTIC UI UPDATE
    // Immediately add to local state
    const optimisticTester: Tester = { email, status: 'pending' };
    set({
      build: {
        ...currentBuild,
        testers: [...currentBuild.testers, optimisticTester],
      },
    });

    try {
      // 2. API Call
      await delay(1000); // Simulate network request
      // If API fails, throw error to trigger catch block
      if (Math.random() < 0.2) throw new Error('API Rate Limit');

      // 3. Update to confirmed state (optional, if status changes from pending)
      set({
        build: {
          ...currentBuild,
          testers: currentBuild.testers.map(t => 
            t.email === email ? { ...t, status: 'invited' } : t
          ),
        },
      });
    } catch (error) {
      // 4. ROLLBACK on failure
      set({
        build: {
          ...currentBuild,
          testers: currentBuild.testers.filter(t => t.email !== email),
        },
        error: 'Failed to invite tester. Changes reverted.',
      });
      // Reset error after toast duration
      setTimeout(() => set({ error: null }), 3000);
    }
  },
}));
