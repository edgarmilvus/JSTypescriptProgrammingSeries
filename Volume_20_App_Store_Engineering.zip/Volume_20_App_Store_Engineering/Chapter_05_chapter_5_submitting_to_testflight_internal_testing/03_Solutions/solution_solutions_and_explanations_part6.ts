/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// TestFlightStatus.tsx
import React, { useEffect } from 'react';
import { View, Text, Button, TextInput, ActivityIndicator, FlatList, StyleSheet } from 'react-native';
import { useTestFlightStore } from './useTestFlightStore';

export const TestFlightStatus: React.FC = () => {
  const { build, isLoading, error, fetchBuild, inviteTester } = useTestFlightStore();
  const [emailInput, setEmailInput] = React.useState('');

  useEffect(() => {
    fetchBuild('com.myapp.bundle'); // Pass App ID
  }, []);

  const handleInvite = () => {
    if (emailInput) {
      inviteTester(emailInput);
      setEmailInput('');
    }
  };

  if (isLoading && !build) {
    return <ActivityIndicator size="large" />;
  }

  return (
    <View style={styles.container}>
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      {build && (
        <>
          <View style={styles.card}>
            <Text style={styles.title}>Build {build.version} ({build.buildNumber})</Text>
            <Text>Status: {build.processingState}</Text>
            <Text>Testers: {build.testers.length}</Text>
          </View>

          <View style={styles.inviteSection}>
            <TextInput
              style={styles.input}
              placeholder="tester@email.com"
              value={emailInput}
              onChangeText={setEmailInput}
            />
            <Button title="Invite Tester" onPress={handleInvite} />
          </View>

          <FlatList
            data={build.testers}
            keyExtractor={(item) => item.email}
            renderItem={({ item }) => (
              <View style={styles.testerItem}>
                <Text>{item.email}</Text>
                <Text style={item.status === 'pending' ? styles.pending : styles.invited}>
                  {item.status}
                </Text>
              </View>
            )}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  card: { padding: 15, backgroundColor: '#f0f0f0', marginBottom: 20, borderRadius: 8 },
  title: { fontSize: 18, fontWeight: 'bold' },
  inviteSection: { flexDirection: 'row', marginBottom: 20 },
  input: { flex: 1, borderColor: '#ccc', borderWidth: 1, marginRight: 10, padding: 8 },
  testerItem: { flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderBottomWidth: 1, borderColor: '#eee' },
  pending: { color: 'orange' },
  invited: { color: 'green' },
  errorText: { color: 'red', marginBottom: 10, textAlign: 'center' },
});
