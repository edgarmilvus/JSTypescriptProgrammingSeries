/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/lib/eas-update-check.ts

import { z } from 'zod';

/**
 * Represents the structure of the EAS Update manifest response.
 * This is a simplified version of the actual EAS API response.
 * @see https://docs.expo.dev/eas-update/api/
 */
const EasManifestSchema = z.object({
  id: z.string(),
  createdAt: z.string().datetime(),
  manifest: z.object({
    assets: z.array(z.object({
      url: z.string().url(),
      key: z.string(),
      hash: z.string(),
    })),
    bundle: z.string().url(),
    metadata: z.object({
      branchName: z.string(),
      releaseChannel: z.string(),
    }),
    version: z.string(), // The runtime version defined in app.json
  }),
});

type EasManifest = z.infer<typeof EasManifestSchema>;

/**
 * Configuration for the update check.
 * In a real app, these would come from environment variables.
 */
const EAS_CONFIG = {
  projectId: 'your-expo-project-id', // e.g., '12345678-1234-1234-1234-123456789012'
  channel: 'production', // The update channel to check against
  baseUrl: 'https://u.expo.dev',
};

/**
 * Checks for an available OTA update for a specific client version.
 * 
 * @param clientVersion - The current runtime version of the app (e.g., "1.0.0")
 * @returns A promise resolving to an object indicating if an update is available and the URL.
 */
export async function checkForEasUpdate(clientVersion: string): Promise<{
  isUpdateAvailable: boolean;
  updateUrl?: string;
  currentVersion: string;
  latestVersion?: string;
}> {
  try {
    // 1. Construct the EAS Update Manifest URL
    // The URL format is: https://u.expo.dev/updates/{projectId}/manifest?channel={channel}&platform={platform}
    // We default to 'ios' for this example, but 'android' is also valid.
    const manifestUrl = new URL(`${EAS_CONFIG.baseUrl}/updates/${EAS_CONFIG.projectId}/manifest`);
    manifestUrl.searchParams.append('channel', EAS_CONFIG.channel);
    manifestUrl.searchParams.append('platform', 'ios');

    // 2. Fetch the latest manifest from EAS
    const response = await fetch(manifestUrl.toString(), {
      headers: {
        // EAS often requires the Expo SDK version or runtime version in headers for compatibility
        'Expo-SDK-Version': '49.0.0', // Example SDK version
        'Accept': 'application/expo+json,application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch manifest: ${response.statusText}`);
    }

    const rawData = await response.json();
    
    // 3. Validate and Parse the Response using Zod
    // This ensures we don't process malformed data.
    const parsedData = EasManifestSchema.safeParse(rawData);

    if (!parsedData.success) {
      console.error('Invalid manifest structure:', parsedData.error);
      return {
        isUpdateAvailable: false,
        currentVersion: clientVersion,
        latestVersion: undefined,
      };
    }

    const manifest = parsedData.data.manifest;
    const latestVersion = manifest.version;

    // 4. Compare Versions
    // In a real scenario, you might use semantic versioning comparison (semver).
    // For this example, we do a strict string equality check.
    const isUpdateAvailable = latestVersion !== clientVersion;

    return {
      isUpdateAvailable,
      updateUrl: isUpdateAvailable ? manifest.bundle : undefined,
      currentVersion: clientVersion,
      latestVersion,
    };

  } catch (error) {
    console.error('Error checking for updates:', error);
    // Fail safe: return no update available if the check fails
    return {
      isUpdateAvailable: false,
      currentVersion: clientVersion,
    };
  }
}
