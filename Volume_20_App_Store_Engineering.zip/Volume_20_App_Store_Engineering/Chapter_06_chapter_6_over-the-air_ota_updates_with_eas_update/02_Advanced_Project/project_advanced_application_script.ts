/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/update-monitor/route.ts
import { NextResponse } from 'next/server';

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & UTILITY TYPES
 * ============================================================================
 * We use TypeScript Utility Types to strictly define the shape of our 
 * telemetry data and the EAS Update configuration state. This ensures 
 * type safety across the monitoring pipeline.
 */

// Represents the raw telemetry data sent by the mobile client (via Expo Application Insights or custom logger).
type ClientTelemetry = {
  channelId: string;      // The EAS Update channel (e.g., 'production', 'beta')
  sessionId: string;      // Unique identifier for the user session
  errorCount: number;     // Number of errors in the last interval
  appVersion: string;     // e.g., '1.0.0'
};

// Represents the state of the EAS Update configuration on the server.
// In a real scenario, this would be an interface to the EAS CLI or a config file like eas.json.
export type EasUpdateConfig = {
  channel: string;
  updateId: string | null;
  isPaused: boolean;      // If true, the EAS Update server refuses to serve updates to this channel
  rolloutPercentage: number; // 0 to 100
  errorThreshold: number; // Max allowed errors per minute before auto-pausing
};

/**
 * ============================================================================
 * 2. SERVER-SIDE STATE MANAGEMENT (SIMULATED EAS BACKEND)
 * ============================================================================
 * We simulate a persistent store for the EAS Update configuration.
 * In production, this would be a database row or a managed configuration file.
 */
const easConfigState: Record<string, EasUpdateConfig> = {
  'production': {
    channel: 'production',
    updateId: '20241120-abc123',
    isPaused: false,
    rolloutPercentage: 100,
    errorThreshold: 5, // Allow 5 errors/min before triggering safety protocol
  }
};

/**
 * ============================================================================
 * 3. THE CORE LOGIC: AI-DRIVEN MONITORING & SAFE ROLLOUT
 * ============================================================================
 * This function acts as the "Brain". It analyzes incoming telemetry
 * and decides whether to keep the update live or pause it.
 */
function analyzeHealthAndAdjustRollout(data: ClientTelemetry): EasUpdateConfig {
  const config = easConfigState[data.channelId];
  
  if (!config) {
    throw new Error(`Unknown channel: ${data.channelId}`);
  }

  // SIMULATED AI LOGIC:
  // A real AI model might correlate errors with specific device models or OS versions.
  // Here, we implement a heuristic safety check.
  
  const isSpikeDetected = data.errorCount > config.errorThreshold;

  if (isSpikeDetected && !config.isPaused) {
    // CRITICAL SAFETY PROTOCOL: Auto-Pause Rollout
    console.warn(`[AI Monitor] Error spike detected on channel ${config.channel}. Pausing rollout.`);
    config.isPaused = true;
    
    // In a real EAS context, this would trigger:
    // `eas update:rollback --channel production --to-id <previous_stable_id>`
  } else if (!isSpikeDetected && config.isPaused) {
    // Recovery logic (optional, usually requires manual intervention)
    console.log(`[AI Monitor] Error rate normalized on channel ${config.channel}.`);
  }

  return config;
}

/**
 * ============================================================================
 * 4. NEXT.JS API ROUTE (SSE IMPLEMENTATION)
 * ============================================================================
 * This route establishes a persistent connection to stream real-time 
 * configuration updates to the dashboard client.
 */
export async function GET(req: Request) {
  // Create a TransformStream to handle SSE formatting
  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const encoder = new TextEncoder();

  // Simulate incoming telemetry stream (e.g., from a WebSocket or Redis Pub/Sub)
  // In production, this would be a subscription to a message queue.
  const telemetryInterval = setInterval(() => {
    // Randomly generate telemetry to simulate a live app environment
    const mockTelemetry: ClientTelemetry = {
      channelId: 'production',
      sessionId: `sess_${Math.floor(Math.random() * 1000)}`,
      // Randomly spike errors to trigger the safety mechanism
      errorCount: Math.random() > 0.7 ? 8 : 1, 
      appVersion: '1.0.0'
    };

    // 1. Process data through the AI logic
    const updatedConfig = analyzeHealthAndAdjustRollout(mockTelemetry);

    // 2. Format as Server-Sent Event (SSE)
    const ssePayload = encoder.encode(
      `data: ${JSON.stringify({ 
        type: 'CONFIG_UPDATE', 
        payload: updatedConfig 
      })}\n\n`
    );

    // 3. Stream to client
    writer.write(ssePayload).catch(err => {
      // Handle client disconnect
      clearInterval(telemetryInterval);
      writer.close();
    });
  }, 2000); // Send data every 2 seconds

  // Clean up on disconnect
  req.signal.addEventListener('abort', () => {
    clearInterval(telemetryInterval);
    writer.close();
  });

  // Return the SSE response
  return new Response(readable, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
