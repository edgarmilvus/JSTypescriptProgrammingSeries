/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import * as Updates from 'expo-updates';
import { View, Text, Button, ActivityIndicator, StyleSheet, Alert } from 'react-native';

export const UpdateNotifier: React.FC = () => {
  const [isUpdateAvailable, setIsUpdateAvailable] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    checkForUpdates();
  }, []);

  const checkForUpdates = async () => {
    try {
      // Check for updates asynchronously
      const { isAvailable } = await Updates.checkForUpdateAsync();
      
      if (isAvailable) {
        setIsUpdateAvailable(true);
      }
    } catch (e) {
      console.error("Failed to check for updates", e);
      setError("Could not check for updates.");
    }
  };

  const handleDownloadAndInstall = async () => {
    setIsDownloading(true);
    setError(null);

    try {
      // Fetch the update bundle
      const { isNew } = await Updates.fetchAsync();
      
      if (isNew) {
        Alert.alert(
          "Update Ready",
          "The app needs to restart to apply the update.",
          [
            { text: "Later", style: "cancel", onPress: () => setIsDownloading(false) },
            { text: "Restart", onPress: () => Updates.reloadAsync() }
          ]
        );
      } else {
        // Edge case: fetch completed but no new bundle (rare)
        setIsUpdateAvailable(false);
        setIsDownloading(false);
      }
    } catch (e) {
      console.error("Failed to download update", e);
      setError("Download failed. Please try again.");
      setIsDownloading(false);
    }
  };

  if (!isUpdateAvailable) {
    return null;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Update Available!</Text>
      
      {isDownloading ? (
        <ActivityIndicator size="small" color="#0000ff" />
      ) : (
        <Button 
          title="Download & Install" 
          onPress={handleDownloadAndInstall} 
          disabled={!!error}
        />
      )}

      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    zIndex: 1000,
  },
  text: {
    fontWeight: 'bold',
    marginBottom: 10,
  },
  errorText: {
    color: 'red',
    marginTop: 5,
    fontSize: 12,
  },
});
