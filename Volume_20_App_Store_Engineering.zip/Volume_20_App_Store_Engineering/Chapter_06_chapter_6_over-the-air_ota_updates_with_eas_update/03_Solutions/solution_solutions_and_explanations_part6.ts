/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# 1. Publish to Internal (Initial Testing)
# Developers push code to the 'internal' channel first.
eas update --channel internal --message "v2.5.0 Internal Test"

# 2. Promote to Beta (External Testers)
# Once validated internally, we point the 'beta' channel to the same update bundle.
# We do not need to rebuild; we simply change the channel pointer.
eas update --channel beta --message "v2.5.0 Beta Release"

# 3. Promote to Production (General Availability)
# After beta validation, we promote to the 'production' channel.
eas update --channel production --message "v2.5.0 Production Release"

# 4. Rollback Plan (If critical issue in Beta)
# If v2.5.0 fails in the beta phase, we rollback the beta channel.
# We assume v2.4.0 is the previous stable update embedded in the beta binary.
eas update --channel beta --rollback-to-embedded --non-interactive
