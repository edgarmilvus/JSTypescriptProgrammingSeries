/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

import * as Updates from 'expo-updates';
import Constants from 'expo-constants';

interface CompatibilityResult {
  isCompatible: boolean;
  updateManifest?: Updates.UpdateManifest;
}

export const checkForCompatibleUpdate = async (): Promise<CompatibilityResult> => {
  try {
    // 1. Check for available updates
    const checkResult = await Updates.checkForUpdateAsync();

    if (!checkResult.isAvailable) {
      return { isCompatible: true }; // No update means no incompatibility risk
    }

    const remoteManifest = checkResult.manifest;
    
    // 2. Extract Runtime Versions
    // Note: Depending on Expo SDK version, runtimeVersion might be in different places.
    // Typically found in manifest.runtimeVersion or manifest.extra.runtimeVersion.
    const remoteRuntimeVersion = (remoteManifest as any).runtimeVersion || (remoteManifest as any)?.extra?.runtimeVersion;
    
    // Local config is usually available via Constants.expoConfig
    const localRuntimeVersion = (Constants.expoConfig as any)?.runtimeVersion;

    console.log(`Local Runtime: ${localRuntimeVersion}, Remote Runtime: ${remoteRuntimeVersion}`);

    // 3. Compare Versions
    if (remoteRuntimeVersion === localRuntimeVersion) {
      return {
        isCompatible: true,
        updateManifest: remoteManifest
      };
    } else {
      console.warn(`Runtime version mismatch! Local: ${localRuntimeVersion}, Remote: ${remoteRuntimeVersion}. Update ignored.`);
      return {
        isCompatible: false
      };
    }

  } catch (error) {
    console.error("Error checking compatibility:", error);
    return { isCompatible: false };
  }
};
