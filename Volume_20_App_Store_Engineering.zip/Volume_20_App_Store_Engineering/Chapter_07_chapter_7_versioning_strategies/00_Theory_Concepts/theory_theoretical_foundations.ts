/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="rounded", fontname="Helvetica"];

    Source [label="Source Code\n& Feature Flags"];
    Config [label="Version Config\n(e.g., app.json)"];
    Trigger [label="CI/CD Trigger\n(e.g., Git Push)"];

    subgraph cluster_pipeline {
        label = "EAS Pipeline";
        style = dashed;
        Calculate [label="Calculate\nMarketing Version & Build Number"];
        Inject [label="Inject Metadata\ninto Native Projects"];
        Build [label="Compile Binary\nwith Native Code"];
    }

    Output [label="Build Artifact\n(.ipa / .apk)"];
    Store [label="App Store\n(App Store Connect / Play Console)"];
    OTA [label="OTA Update Server\n(EAS Update)"];

    Source -> Config;
    Trigger -> Calculate;
    Config -> Calculate;
    Calculate -> Inject;
    Inject -> Build;
    Build -> Output;
    Output -> Store;
    Output -> OTA;

    // Annotations
    { rank = same; Store; OTA }
}
