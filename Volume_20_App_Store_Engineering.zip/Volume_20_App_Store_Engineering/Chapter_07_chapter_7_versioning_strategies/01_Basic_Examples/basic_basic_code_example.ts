/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Basic Versioning Script for CI/CD
 * 
 * This script demonstrates how to programmatically manage app versioning
 * based on Semantic Versioning (Major.Minor.Patch) and platform-specific
 * build numbers.
 * 
 * Context: SaaS Web App / Mobile App Build Pipeline
 * Dependencies: Node.js (fs module)
 */

import * as fs from 'fs';
import * as path from 'path';

// 1. Type Definitions
// Define a strict shape for the app configuration to ensure type safety.
interface AppConfig {
  expo: {
    version: string;
    android: {
      versionCode: number;
    };
    ios: {
      buildNumber: string;
    };
  };
}

// 2. Configuration Constants
// In a real CI pipeline, these would be injected via environment variables.
// We simulate them here for the self-contained example.
const CONFIG_PATH = path.join(__dirname, 'app.json');
const RELEASE_TYPE = process.env.RELEASE_TYPE || 'patch'; // 'major', 'minor', 'patch'
const BUILD_INCREMENT = 1;

/**
 * Helper function to parse the current version string (e.g., "1.2.3").
 * @param versionString - The current semantic version.
 * @returns An object containing numeric major, minor, and patch versions.
 */
function parseSemanticVersion(versionString: string): { major: number; minor: number; patch: number } {
  const parts = versionString.split('.');
  if (parts.length !== 3) {
    throw new Error(`Invalid semantic version format: ${versionString}`);
  }
  return {
    major: parseInt(parts[0], 10),
    minor: parseInt(parts[1], 10),
    patch: parseInt(parts[2], 10),
  };
}

/**
 * Calculates the next semantic version based on the release type.
 * @param currentVersion - The current version string.
 * @param type - The type of release (major, minor, patch).
 * @returns The new version string.
 */
function calculateNextSemanticVersion(currentVersion: string, type: string): string {
  const { major, minor, patch } = parseSemanticVersion(currentVersion);

  switch (type.toLowerCase()) {
    case 'major':
      return `${major + 1}.0.0`;
    case 'minor':
      return `${major}.${minor + 1}.0`;
    case 'patch':
    default:
      return `${major}.${minor}.${patch + 1}`;
  }
}

/**
 * Main execution function.
 * 1. Reads the current app configuration.
 * 2. Calculates new version numbers.
 * 3. Writes the updated configuration back to the file.
 */
async function updateAppVersion(): Promise<void> {
  try {
    // Check if config file exists
    if (!fs.existsSync(CONFIG_PATH)) {
      // Create a dummy config for demonstration if it doesn't exist
      const dummyConfig: AppConfig = {
        expo: {
          version: "1.0.0",
          android: { versionCode: 1 },
          ios: { buildNumber: "1.0.0" }
      };
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(dummyConfig, null, 2));
    }

    // Read current configuration
    const configFile = fs.readFileSync(CONFIG_PATH, 'utf-8');
    const config: AppConfig = JSON.parse(configFile);

    console.log(`Current Version: ${config.expo.version}`);
    console.log(`Current Android Build: ${config.expo.android.versionCode}`);
    console.log(`Current iOS Build: ${config.expo.ios.buildNumber}`);

    // Calculate new Semantic Version
    const newVersion = calculateNextSemanticVersion(config.expo.version, RELEASE_TYPE);
    
    // Calculate new Platform Build Numbers
    // Android uses integers (versionCode), incrementing by 1.
    const newAndroidBuild = config.expo.android.versionCode + BUILD_INCREMENT;
    
    // iOS uses strings (buildNumber), often matching semantic version or incrementing.
    // Here we update it to match the new semantic version for consistency.
    const newIosBuild = newVersion;

    // Update the config object
    config.expo.version = newVersion;
    config.expo.android.versionCode = newAndroidBuild;
    config.expo.ios.buildNumber = newIosBuild;

    // Write the updated configuration back to the file
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));

    console.log(`✅ Version updated successfully to ${newVersion} (Build ${newAndroidBuild})`);
    
    // In a real CI pipeline, you might export these as environment variables
    // for subsequent steps (e.g., build, deploy).
    // console.log(`::set-output name=version::${newVersion}`);

  } catch (error) {
    console.error('❌ Error updating app version:', error);
    process.exit(1); // Fail the CI build if versioning fails
  }
}

// Execute the script
updateAppVersion();
