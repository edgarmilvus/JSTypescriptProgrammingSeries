/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Versioning Orchestrator
 * 
 * Context: Book 20 - App Store Engineering
 * Chapter 7 - Versioning Strategies
 * 
 * This script demonstrates a production-grade utility for managing mobile app 
 * versioning in a CI/CD environment. It handles:
 * 1. Semantic Versioning (Major.Minor.Patch) calculations based on release type.
 * 2. Platform-specific build number management (Android versionCode, iOS buildNumber).
 * 3. Feature Flag integration for parallel development streams.
 * 4. OTA Update Manifest generation for Expo/React Native apps.
 */

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Represents the semantic versioning structure.
 * Major: Breaking changes.
 * Minor: Backward-compatible features.
 * Patch: Backward-compatible bug fixes.
 */
type SemanticVersion = {
  major: number;
  minor: number;
  patch: number;
};

/**
 * Represents the release context for a specific platform (iOS/Android).
 * Build numbers must strictly increase and are distinct from semantic versions.
 */
type PlatformBuildConfig = {
  androidVersionCode: number;
  iosBuildNumber: string; // iOS uses string-based build numbers
};

/**
 * Defines the release strategy input.
 * 'releaseType' drives the semantic version bump.
 * 'featureFlags' determines which code paths are active in the build.
 */
type ReleaseStrategy = {
  releaseType: 'major' | 'minor' | 'patch' | 'rc'; // rc = release candidate
  featureFlags: Record<string, boolean>;
  targetEnvironment: 'production' | 'staging';
};

/**
 * Represents a stored vector in the database for tracking version history.
 * Vector ID is used to update or delete specific version records.
 */
type VersionVector = {
  vectorId: string; // UUID
  semanticVersion: string;
  platformBuildConfig: PlatformBuildConfig;
  featureFlags: Record<string, boolean>;
  createdAt: Date;
};

// ============================================================================
// 2. UTILITY CLASSES & MOCK DATABASE
// ============================================================================

/**
 * Mock Database Service simulating a Vector Store (e.g., PostgreSQL, MongoDB).
 * In a real scenario, this would interact with a persistence layer.
 */
class VersionVectorStore {
  private vectors: VersionVector[] = [];

  /**
   * Saves a new version vector.
   * @param vector - The version data to store.
   */
  async saveVector(vector: Omit<VersionVector, 'vectorId'>): Promise<VersionVector> {
    const newVector: VersionVector = {
      ...vector,
      vectorId: `vec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };
    this.vectors.push(newVector);
    console.log(`[VectorDB] Saved Vector ID: ${newVector.vectorId}`);
    return newVector;
  }

  /**
   * Retrieves the latest version vector for a specific environment.
   * Used to calculate the next incremental version.
   */
  async getLatestVector(env: 'production' | 'staging'): Promise<VersionVector | null> {
    // Filter by environment (simulated by checking semantic version patterns or metadata)
    const envVectors = this.vectors.filter(v => 
        env === 'production' ? !v.semanticVersion.includes('rc') : v.semanticVersion.includes('rc')
    );
    return envVectors.length > 0 ? envVectors[envVectors.length - 1] : null;
  }
}

// ============================================================================
// 3. CORE LOGIC: VERSIONING ORCHESTRATOR
// ============================================================================

class VersioningOrchestrator {
  private store: VersionVectorStore;

  constructor(store: VersionVectorStore) {
    this.store = store;
  }

  /**
   * Calculates the next Semantic Version based on the current state and strategy.
   * 
   * Logic:
   * - Major: Resets Minor and Patch to 0. Increments Major.
   * - Minor: Resets Patch to 0. Increments Minor.
   * - Patch: Increments Patch only.
   * - RC (Release Candidate): Appends '-rc.x' to the current Minor version.
   * 
   * @param currentVersion - The previous semantic version string (e.g., "1.2.3").
   * @param strategy - The release strategy defining the bump type.
   * @returns The new semantic version string.
   */
  private calculateSemanticVersion(currentVersion: string | null, strategy: ReleaseStrategy): string {
    if (!currentVersion) return strategy.releaseType === 'rc' ? '1.0.0-rc.1' : '1.0.0';

    const [maj, min, pat, rc] = currentVersion.split(/[\.\-]/); // Handles "1.2.3" and "1.2.3-rc.1"
    let major = parseInt(maj, 10);
    let minor = parseInt(min, 10);
    let patch = parseInt(pat, 10);

    switch (strategy.releaseType) {
      case 'major':
        major += 1;
        minor = 0;
        patch = 0;
        return `${major}.${minor}.${patch}`;
      
      case 'minor':
        minor += 1;
        patch = 0;
        return `${major}.${minor}.${patch}`;
      
      case 'patch':
        patch += 1;
        return `${major}.${minor}.${patch}`;
      
      case 'rc':
        // If current is already an RC, increment the RC number
        const rcNum = rc ? parseInt(rc, 10) + 1 : 1;
        return `${major}.${minor}.${patch}-rc.${rcNum}`;
      
      default:
        return currentVersion;
    }
  }

  /**
   * Calculates platform-specific build numbers.
   * 
   * Android (versionCode): Must be an integer that increments monotonically. 
   * iOS (CFBundleVersion): String, but typically an integer. We enforce integer logic here.
   * 
   * @param currentConfig - Previous build configuration.
   * @returns New build configuration.
   */
  private calculateBuildNumbers(currentConfig: PlatformBuildConfig | null): PlatformBuildConfig {
    const nextAndroid = currentConfig ? currentConfig.androidVersionCode + 1 : 1;
    const nextIos = currentConfig ? (parseInt(currentConfig.iosBuildNumber, 10) + 1).toString() : '1';
    
    return {
      androidVersionCode: nextAndroid,
      iosBuildNumber: nextIos,
    };
  }

  /**
   * Generates the Expo OTA Update Manifest.
   * This manifest is consumed by the 'expo-updates' library on the client.
   * 
   * The 'assets' field would typically contain the bundle URL (e.g., from S3).
   * 'metadata' stores the Vector ID for database tracking.
   * 
   * @param versionData - The computed version and build data.
   * @param manifestUrl - The public URL where the JS bundle is hosted.
   * @returns A manifest object compatible with Expo Updates.
   */
  private generateOTAManifest(
    versionData: { 
      semanticVersion: string; 
      platformBuildConfig: PlatformBuildConfig; 
      featureFlags: Record<string, boolean>;
      vectorId: string;
    },
    manifestUrl: string
  ) {
    return {
      // Expo manifest version
      manifestVersion: 0,
      // Unique runtime version (usually hashes of the bundle, but here we use semantic version for clarity)
      runtimeVersion: `exposdk:${versionData.semanticVersion}`,
      // The version the app reports to the store
      version: versionData.semanticVersion,
      // Platform specific metadata
      extra: {
        eas: {
          projectId: "your-project-id",
        },
        buildNumber: versionData.platformBuildConfig.iosBuildNumber,
        versionCode: versionData.platformBuildConfig.androidVersionCode,
      },
      // Feature flags embedded in the manifest for client-side evaluation
      metadata: {
        vectorId: versionData.vectorId,
        featureFlags: versionData.featureFlags,
      },
      // Assets (JS bundles, images)
      assets: [
        {
          hash: "sha256-...", // Placeholder for actual bundle hash
          key: "bundle",
          url: manifestUrl, // Pointing to the OTA bundle URL
          contentType: "application/javascript",
        },
      ],
      // Bundle loading logic
      launchAsset: {
        hash: "sha256-...",
        key: "main",
        url: manifestUrl,
        contentType: "application/javascript",
      },
    };
  }

  /**
   * Main Entry Point: Triggers a new release process.
   * 
   * 1. Fetches the latest vector from the store.
   * 2. Computes new Semantic Version and Build Numbers.
   * 3. Stores the new Vector.
   * 4. Generates the OTA Manifest.
   */
  public async triggerRelease(
    strategy: ReleaseStrategy, 
    manifestUrl: string
  ): Promise<any> {
    console.log(`[Orchestrator] Initiating release: ${strategy.releaseType} (${strategy.targetEnvironment})`);

    // 1. Retrieve History
    const latestVector = await this.store.getLatestVector(strategy.targetEnvironment);
    
    // 2. Calculate Versions
    const prevSemantic = latestVector ? latestVector.semanticVersion : null;
    const prevBuildConfig = latestVector ? latestVector.platformBuildConfig : null;

    const newSemanticVersion = this.calculateSemanticVersion(prevSemantic, strategy);
    const newBuildConfig = this.calculateBuildNumbers(prevBuildConfig);

    // 3. Store New Vector (Simulating DB Write)
    const newVector = await this.store.saveVector({
      semanticVersion: newSemanticVersion,
      platformBuildConfig: newBuildConfig,
      featureFlags: strategy.featureFlags,
      createdAt: new Date(),
    });

    // 4. Generate OTA Manifest
    const otaManifest = this.generateOTAManifest(
      {
        semanticVersion: newSemanticVersion,
        platformBuildConfig: newBuildConfig,
        featureFlags: strategy.featureFlags,
        vectorId: newVector.vectorId,
      },
      manifestUrl
    );

    console.log(`[Orchestrator] Release Complete. Version: ${newSemanticVersion}`);
    
    return {
      success: true,
      vectorId: newVector.vectorId,
      version: newSemanticVersion,
      buildConfig: newBuildConfig,
      otaManifest,
    };
  }
}

// ============================================================================
// 4. EXECUTION CONTEXT (NEXT.JS API ROUTE SIMULATION)
// ============================================================================

/**
 * Example usage within a Next.js API Route (app/api/release/route.ts).
 * This simulates the HTTP request handler.
 */
export async function POST(request: Request) {
  const body = await request.json();
  const { releaseType, featureFlags, environment, manifestUrl } = body;

  // Initialize dependencies
  const store = new VersionVectorStore();
  const orchestrator = new VersioningOrchestrator(store);

  // Define Strategy
  const strategy: ReleaseStrategy = {
    releaseType: releaseType, // e.g., 'minor'
    featureFlags: featureFlags || { darkMode: true, betaFeature: false },
    targetEnvironment: environment || 'staging',
  };

  try {
    // Execute Release
    const result = await orchestrator.triggerRelease(strategy, manifestUrl);

    // Return response (simulating Next.js Response object)
    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: 'Release failed' }), {
      status: 500,
    });
  }
}

// ============================================================================
// 5. DEMONSTRATION RUNNER
// ============================================================================

/**
 * Self-contained execution block to demonstrate the logic flow.
 * (In a real app, this would be handled by the API route above).
 */
async function runDemo() {
  console.log("--- Starting Versioning Strategy Demo ---");
  
  const store = new VersionVectorStore();
  const orchestrator = new VersioningOrchestrator(store);

  // Scenario 1: Initial Release (Staging)
  const r1 = await orchestrator.triggerRelease(
    { releaseType: 'patch', featureFlags: { newLogin: false }, targetEnvironment: 'staging' },
    "https://cdn.example.com/bundle-v1.0.1.js"
  );
  console.log("Result 1:", JSON.stringify(r1, null, 2));

  // Scenario 2: Feature Release (Minor Bump) with Feature Flag enabled
  const r2 = await orchestrator.triggerRelease(
    { releaseType: 'minor', featureFlags: { newLogin: true }, targetEnvironment: 'production' },
    "https://cdn.example.com/bundle-v1.1.0.js"
  );
  console.log("Result 2:", JSON.stringify(r2, null, 2));

  // Scenario 3: Breaking Change (Major Bump)
  const r3 = await orchestrator.triggerRelease(
    { releaseType: 'major', featureFlags: { newLogin: true, redesign: true }, targetEnvironment: 'production' },
    "https://cdn.example.com/bundle-v2.0.0.js"
  );
  console.log("Result 3:", JSON.stringify(r3, null, 2));
}

// Uncomment to run locally:
// runDemo();
