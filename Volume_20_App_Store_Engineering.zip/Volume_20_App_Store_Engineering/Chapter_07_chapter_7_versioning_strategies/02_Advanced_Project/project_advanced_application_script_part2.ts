/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

digraph VersioningFlow {
    rankdir=TB;
    node [shape=box, style="rounded", fontname="Helvetica"];
    
    CI [label="CI/CD Trigger\n(e.g., EAS Build)", shape=ellipse, fillcolor="#e1f5fe", style="filled"];
    Orchestrator [label="VersioningOrchestrator", fillcolor="#fff3e0", style="filled"];
    Store [label="VersionVectorStore\n(Vector DB)", shape=cylinder, fillcolor="#f3e5f5", style="filled"];
    OTA [label="OTA Manifest\n(Expo Updates)", shape=note, fillcolor="#e8f5e9", style="filled"];
    Client [label="Mobile Client\n(Expo Go/App)", shape=doubleoctagon];

    CI -> Orchestrator [label="1. Request Release\n(Minor, Prod, Flags)"];
    Orchestrator -> Store [label="2. Fetch Latest Vector"];
    Store -> Orchestrator [label="3. Return History"];
    Orchestrator -> Orchestrator [label="4. Calculate\nSemantic & Build #"];
    Orchestrator -> Store [label="5. Save New Vector\n(Vector ID)"];
    Orchestrator -> OTA [label="6. Generate Manifest\n(Embed Vector ID & Flags)"];
    
    OTA -> Client [label="7. Host Manifest\n(S3/CDN)"];
    Client -> Client [label="8. Poll & Download\n(Update Runtime)"];
}
