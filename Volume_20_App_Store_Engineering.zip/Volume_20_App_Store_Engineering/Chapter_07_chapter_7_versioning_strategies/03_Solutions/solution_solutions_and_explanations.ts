/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type ValidationResult = {
  isValid: boolean;
  reason: string;
};

// validator.ts
export const validateVersionDeployment = (
  version: string,
  currentDate: Date
): ValidationResult => {
  // 1. Validate SemVer format (Major.Minor.Patch)
  // Regex explanation: 
  // ^\d+\.  : Starts with one or more digits followed by a dot (Major)
  // \d+\.   : One or more digits followed by a dot (Minor)
  // \d+$    : One or more digits at the end (Patch)
  const semVerRegex = /^\d+\.\d+\.\d+$/;
  
  if (!semVerRegex.test(version)) {
    return {
      isValid: false,
      reason: "Invalid format. Version must follow Major.Minor.Patch pattern (e.g., 1.2.3)."
    };
  }

  // 2. Parse the version to determine if it is a Patch release
  // Split the string by dots and convert to numbers
  const [major, minor, patch] = version.split('.').map(Number);

  // 3. Check Business Rule: Patch versions cannot be deployed on Fridays
  // getDay() returns 0 for Sunday, 1 for Monday, ..., 5 for Friday, 6 for Saturday
  const dayIndex = currentDate.getDay();
  const isFriday = dayIndex === 5;
  const isPatchRelease = patch !== undefined; // Since format is valid, we just need to confirm we have a patch number

  if (isFriday && isPatchRelease) {
    return {
      isValid: false,
      reason: "Patch releases are not allowed on Fridays."
    };
  }

  // 4. If all checks pass
  return {
    isValid: true,
    reason: "Version is valid and deployment is allowed."
  };
};
