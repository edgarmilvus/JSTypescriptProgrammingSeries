/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// FeatureWrapper.tsx
import React, { useContext } from 'react';

// Define the context for Debug Mode
interface DebugContextType {
  isDebugMode: boolean;
}

const DebugContext = React.createContext<DebugContextType>({ isDebugMode: false });

type FeatureWrapperProps = {
  flagKey: string;
  isEnabled: boolean;
  children: React.ReactNode;
  // Optional prop to override context for specific instances
  forceDebug?: boolean; 
};

export const FeatureWrapper: React.FC<FeatureWrapperProps> = ({
  flagKey,
  isEnabled,
  children,
  forceDebug = false,
}) => {
  // Access the debug context
  const debugContext = useContext(DebugContext);
  
  // Determine if we should show the debug overlay
  // Priority: Explicit prop > Context value
  const showDebug = forceDebug || debugContext.isDebugMode;

  return (
    <div style={{ position: 'relative', border: showDebug ? '2px dashed red' : 'none', padding: '4px' }}>
      {/* Debug Overlay */}
      {showDebug && (
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          right: 0, 
          background: 'red', 
          color: 'white', 
          fontSize: '10px', 
          padding: '2px 6px',
          zIndex: 10 
        }}>
          FLAG: {flagKey} | STATUS: {isEnabled ? 'ENABLED' : 'DISABLED'}
        </div>
      )}

      {/* Conditional Rendering */}
      {isEnabled ? (
        <>{children}</>
      ) : (
        <div className="feature-fallback">
          Feature coming soon
        </div>
      )}
    </div>
  );
};

// Optional: Export the provider for the Debug Context
export const DebugProvider = DebugContext.Provider;
