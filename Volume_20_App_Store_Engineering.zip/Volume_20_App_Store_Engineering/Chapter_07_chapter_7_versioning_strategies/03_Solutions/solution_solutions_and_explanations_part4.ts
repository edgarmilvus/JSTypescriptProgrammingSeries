/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// buildResolver.ts
export const resolveBuildNumber = (
  requestedVersion: string,
  existingBuilds: string[]
): string => {
  // 1. Filter existing builds that match the requested version base
  // We look for strings that start with the requestedVersion followed by a dot (suffix)
  // OR exactly equal to the requestedVersion (implied base version)
  const relatedBuilds = existingBuilds.filter(build => 
    build === requestedVersion || build.startsWith(`${requestedVersion}.`)
  );

  // 2. If no related builds exist, return the requested version as is
  if (relatedBuilds.length === 0) {
    return requestedVersion;
  }

  // 3. Find the highest suffix number
  let maxSuffix = 0;

  relatedBuilds.forEach(build => {
    if (build === requestedVersion) {
      // This represents the base version (e.g., "1.0.0"), which we can consider as suffix 0
      // or simply ignore if we strictly look for dots. 
      // However, to ensure uniqueness, if "1.0.0" exists, the next should be "1.0.0.1".
      // So, if the exact string exists, we treat it as a collision.
      maxSuffix = Math.max(maxSuffix, 0); 
    } else {
      // Extract the suffix after the last dot
      const parts = build.split('.');
      const suffixStr = parts[parts.length - 1];
      const suffixNum = parseInt(suffixStr, 10);

      if (!isNaN(suffixNum)) {
        maxSuffix = Math.max(maxSuffix, suffixNum);
      }
    }
  });

  // 4. Increment the highest suffix and return the new build string
  const nextSuffix = maxSuffix + 1;
  return `${requestedVersion}.${nextSuffix}`;
};
