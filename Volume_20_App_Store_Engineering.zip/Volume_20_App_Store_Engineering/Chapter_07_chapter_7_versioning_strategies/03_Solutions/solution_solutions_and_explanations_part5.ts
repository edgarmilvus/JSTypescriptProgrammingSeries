/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph ServiceWorkerLifecycle {
    rankdir=LR;
    node [shape=box, style=filled, fillcolor="#E3F2FD"];

    subgraph cluster_app {
        label = "Client (Browser/App)";
        style = dashed;
        App [label="Application Request\n(e.g., model_v1.onnx)", fillcolor="#FFF"];
    }

    subgraph cluster_sw {
        label = "Service Worker";
        style = dashed;
        SW [label="Service Worker\nIntercepts Request", fillcolor="#FFECB3"];
        CacheCheck [label="Check Cache API", shape=diamond, fillcolor="#FFCC80"];
        NetworkFetch [label="Fetch from Network", fillcolor="#FFCC80"];
        CachePut [label="Cache.put()", fillcolor="#C8E6C9"];
    }

    App -> SW [label="1. Fetch Event"];
    SW -> CacheCheck;
    
    CacheCheck -> NetworkFetch [label="Cache Miss\n(or Stale)"];
    CacheCheck -> App [label="2. Cache Hit\nReturn Asset", style=bold, color="#2E7D32"];

    NetworkFetch -> App [label="3. Return Asset\nfrom Network", style=bold, color="#1565C0"];
    NetworkFetch -> CachePut [label="4. Store in Cache"];
    CachePut -> App [label="5. Serve Cached\n(Next Time)"];
}
