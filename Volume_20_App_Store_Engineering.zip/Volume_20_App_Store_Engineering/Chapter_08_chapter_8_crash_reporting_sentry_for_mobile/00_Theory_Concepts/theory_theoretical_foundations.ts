/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph SentryFlow {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#f0f0f0", fontname="Helvetica"];

    subgraph cluster_device {
        label="Mobile Device";
        style=dashed;
        App [label="Mobile App\n(Running)", fillcolor="#e1f5fe"];
        SDK [label="Sentry SDK\n(Capture & Serialize)", fillcolor="#b3e5fc"];
        OS [label="OS Signal Handler\n(Crash Detection)", fillcolor="#81d4fa"];
        
        OS -> SDK [label="Interrupt"];
        SDK -> App [label="Context Collection"];
    }

    subgraph cluster_backend {
        label="Sentry Backend (Cloud)";
        style=dashed;
        Ingest [label="Ingestion API\n(Envelope Endpoint)", fillcolor="#fff3e0"];
        Worker [label="Processing Workers\n(Symbolication & Grouping)", fillcolor="#ffcc80"];
        ML [label="AI Engine\n(Fingerprinting & Clustering)", fillcolor="#ffb74d"];
        DB [label="Time-Series Database\n(Events & Metrics)", fillcolor="#ffa726"];
    }

    subgraph cluster_user {
        label="Developer / Product";
        style=dashed;
        Dash [label="Dashboard\n(Issue Stream & Alerts)", fillcolor="#e8f5e9"];
        CI [label="CI/CD Pipeline\n(Deploy & Release)", fillcolor="#c8e6c9"];
    }

    SDK -> Ingest [label="HTTP/JSON Envelope", dir=forward, penwidth=2];
    Ingest -> Worker;
    Worker -> ML [label="Analyze Patterns"];
    ML -> DB [label="Store Aggregated Issues"];
    DB -> Dash [label="Query & Visualize"];
    
    CI -> Dash [label="Release Tracking", dir=back];
}
