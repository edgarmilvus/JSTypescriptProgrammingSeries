/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic Sentry Integration for Mobile Crash Reporting (Adapted for Web SaaS).
 * This code defines a type-safe Sentry client wrapper using Interfaces and Generics.
 * It captures exceptions, user context, and release health metrics.
 * 
 * Dependencies (assumed installed via npm):
 * - @sentry/node (or @sentry/browser for frontend)
 * - @sentry/tracing (for performance monitoring)
 * 
 * Run with: ts-node sentry-basic.ts
 */

import * as Sentry from '@sentry/node';
import { ProfilingIntegration } from '@sentry/profiling-node'; // Optional: For performance profiling

// -----------------------------------------------------------------------------
// 1. INTERFACE DEFINITIONS: Defining the Shape of Sentry Configuration and Context
// -----------------------------------------------------------------------------
// Interfaces are used here to define the contract for Sentry setup and user context.
// Unlike type aliases, interfaces support declaration merging, making them ideal for
// extensible SaaS configurations (e.g., adding environment-specific overrides later).

/**
 * Interface for Sentry initialization options.
 * Defines the required properties for configuring the Sentry client.
 * 
 * @property {string} dsn - Data Source Name: The unique URL for your Sentry project.
 * @property {string} environment - Deployment environment (e.g., 'production', 'staging').
 * @property {string} release - App release version (e.g., '1.0.0'), crucial for release health metrics.
 * @property {Array<any>} integrations - Optional array of Sentry integrations (e.g., Profiling).
 * @property {number} tracesSampleRate - Sampling rate for performance traces (0.0 to 1.0).
 */
interface SentryConfig {
    dsn: string;
    environment: string;
    release: string;
    integrations?: any[];
    tracesSampleRate: number;
}

/**
 * Interface for User Context.
 * Captures user details for error attribution, essential in multi-tenant SaaS apps.
 * 
 * @property {string} id - Unique user identifier.
 * @property {string} email - User's email for contact/debugging.
 * @property {string} ip_address - IP for geo-location (auto-detected if omitted).
 */
interface UserContext {
    id: string;
    email: string;
    ip_address?: string;
}

// -----------------------------------------------------------------------------
// 2. GENERICS: Creating a Reusable Type-Safe Sentry Client Wrapper
// -----------------------------------------------------------------------------
// Generics allow us to create a flexible Sentry client that can work with various
// error types or custom contexts without sacrificing type safety. Here, <T> represents
// a generic error payload type, ensuring that any custom error data passed in is
// properly typed and validated.

/**
 * Generic Sentry Client Wrapper.
 * This class uses generics to handle different error payload types (<T>).
 * It abstracts the Sentry SDK for a SaaS web app, providing methods for error capture
 * and performance tracing. The generic type <T> ensures that custom error data
 * (e.g., API-specific errors) is type-checked at compile time.
 * 
 * Why Generics? In a real SaaS app, errors might vary (e.g., API errors vs. UI errors).
 * Generics prevent runtime type mismatches while keeping the code DRY (Don't Repeat Yourself).
 * 
 * @template T - The type of custom error payload (e.g., an object with error codes).
 */
class SentryClient<T extends Record<string, any>> {
    private config: SentryConfig;

    /**
     * Constructor initializes Sentry with the provided config.
     * Under the hood: Calls Sentry.init() to set up the SDK globally.
     * 
     * @param {SentryConfig} config - Configuration object matching the interface.
     */
    constructor(config: SentryConfig) {
        this.config = config;

        // Initialize Sentry with the config.
        // This sets up error tracking, performance monitoring, and release health.
        Sentry.init({
            dsn: config.dsn,
            environment: config.environment,
            release: config.release,
            integrations: config.integrations || [new ProfilingIntegration()],
            tracesSampleRate: config.tracesSampleRate,
            // AI-Driven Insight Simulation: Sentry's AI features (e.g., issue grouping) are enabled by default.
            // In production, use Sentry's "Suspect Commits" or "AI Issue Summaries" via their dashboard.
        });
    }

    /**
     * Captures an exception (crash) with optional custom payload and user context.
     * 
     * @param {Error} error - The error object to capture.
     * @param {T} [customPayload] - Generic custom data (e.g., { errorCode: 'AUTH_FAIL' }).
     * @param {UserContext} [user] - User context for attribution.
     * @returns {string} - The event ID (for tracking in Sentry dashboard).
     * 
     * Under the Hood: Wraps Sentry.captureException(), adding context via Sentry's scope.
     * This triggers AI-driven grouping in Sentry (e.g., similar errors are merged).
     */
    captureException(error: Error, customPayload?: T, user?: UserContext): string {
        // Set user context if provided (for SaaS multi-tenancy).
        if (user) {
            Sentry.setUser({ id: user.id, email: user.email, ip_address: user.ip_address });
        }

        // Add custom tags/extra data from the generic payload.
        // This allows AI insights to prioritize based on custom metrics (e.g., high-priority error codes).
        if (customPayload) {
            Sentry.setContext('customPayload', customPayload);
            Sentry.setTag('errorType', customPayload.errorCode || 'unknown');
        }

        // Capture the exception.
        const eventId = Sentry.captureException(error);

        console.log(`[Sentry] Exception captured: ${eventId}`);
        return eventId;
    }

    /**
     * Starts a performance transaction for monitoring app stability.
     * Essential for release health metrics (e.g., crash-free sessions).
     * 
     * @param {string} transactionName - Name of the transaction (e.g., 'api/login').
     * @returns {Sentry.Transaction} - The transaction object for finishing.
     * 
     * Under the Hood: Uses Sentry's tracing integration to sample traces.
     * AI-Driven Insight: Sentry analyzes traces to detect anomalies (e.g., slow API calls leading to crashes).
     */
    startPerformanceTransaction(transactionName: string): any {
        // Start a transaction.
        const transaction = Sentry.startTransaction({ op: 'task', name: transactionName });
        
        // Set the transaction on the scope for automatic tracing.
        Sentry.configureScope(scope => scope.setSpan(transaction));
        
        console.log(`[Sentry] Performance transaction started: ${transactionName}`);
        return transaction;
    }

    /**
     * Finishes a performance transaction.
     * 
     * @param {any} transaction - The transaction object from startPerformanceTransaction.
     */
    finishPerformanceTransaction(transaction: any): void {
        if (transaction) {
            transaction.finish();
            console.log('[Sentry] Performance transaction finished.');
        }
    }
}

// -----------------------------------------------------------------------------
// 3. USAGE EXAMPLE: Simulating a SaaS Web App Error Scenario
// -----------------------------------------------------------------------------
// This demonstrates the wrapper in action. In a real SaaS app, this would be
// integrated into an Express.js route or React component.

/**
 * Simulated SaaS App Function: User Login API.
 * This function uses the SentryClient to track errors and performance.
 * 
 * @param {string} userId - The user attempting to log in.
 * @param {string} password - User's password (in real app, hash it!).
 * @returns {Promise<void>} - Resolves on success, throws on failure.
 */
async function simulateUserLogin(userId: string, password: string): Promise<void> {
    // Initialize Sentry Client (in real app, this is done once at app startup).
    const sentryClient = new SentryClient<{ errorCode: string; timestamp: number }>({
        dsn: 'https://your-sentry-dsn@sentry.io/project-id', // Replace with real DSN
        environment: 'production',
        release: '1.0.0',
        tracesSampleRate: 1.0, // Sample 100% of traces for development
    });

    // Start performance monitoring for the login flow.
    const transaction = sentryClient.startPerformanceTransaction('api/login');

    try {
        // Simulate an API call (e.g., to a database).
        console.log(`Attempting login for user: ${userId}`);
        
        // Simulate a crash: Invalid password leads to an error.
        if (password !== 'correctPassword') {
            throw new Error('Authentication failed: Invalid credentials');
        }

        console.log('Login successful!');
    } catch (error: any) {
        // Capture the exception with generic custom payload.
        // The generic type ensures 'errorCode' is a string, enforcing type safety.
        const eventId = sentryClient.captureException(
            error,
            { errorCode: 'AUTH_FAIL', timestamp: Date.now() }, // Custom payload
            { id: userId, email: `${userId}@example.com` } // User context
        );

        // Re-throw or handle as needed (in SaaS, you might return a 401 response).
        throw error;
    } finally {
        // Always finish the transaction for accurate performance metrics.
        sentryClient.finishPerformanceTransaction(transaction);
    }
}

// Main execution (for testing the example).
(async () => {
    try {
        // Simulate a failed login to trigger crash reporting.
        await simulateUserLogin('user123', 'wrongPassword');
    } catch (error) {
        console.log('Login failed as expected. Check Sentry dashboard for the captured event.');
    }

    // Simulate a successful login (no crash).
    try {
        await simulateUserLogin('user123', 'correctPassword');
    } catch (error) {
        console.error('Unexpected error:', error);
    }
})();
