/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Sentry Integration & Release Health API for Next.js
 * 
 * CONTEXT: Book 20 - App Store Engineering
 * CHAPTER: 8 - Crash Reporting (Sentry for Mobile)
 * SUBSECTION: 3/5 - Advanced Application Script
 * 
 * This script demonstrates a SaaS backend service that processes crash reports
 * from mobile clients (React Native) and web clients. It utilizes Non-Blocking I/O
 * to handle high-volume Sentry event ingestion and implements a heuristic for
 * prioritizing fixes based on crash severity and user impact.
 * 
 * TARGET: Next.js 14+ (App Router)
 * DEPENDENCIES: @sentry/nextjs, next (framework)
 */

import { NextRequest, NextResponse } from 'next/server';
import * as Sentry from '@sentry/nextjs';
import { Readable } from 'stream';

// -----------------------------------------------------------------------------
// 1. SENTRY INITIALIZATION & CONFIGURATION
// -----------------------------------------------------------------------------
// We initialize Sentry at the top level to capture errors in the runtime.
// In a real deployment, DSN is injected via environment variables.
// This setup captures both server-side errors and client-side events reported
// via the Sentry SDK running in the mobile/web app.

Sentry.init({
    dsn: process.env.SENTRY_DSN || 'https://examplePublicKey@o0.ingest.sentry.io/0',
    environment: process.env.NODE_ENV || 'development',
    // TracesSampleRate captures performance data for slow transactions.
    tracesSampleRate: 1.0,
    // ProfilesSampleRate enables continuous profiling for mobile performance.
    profilesSampleRate: 1.0,
    // Enable debug mode in development for verbose logging.
    debug: process.env.NODE_ENV === 'development',
});

// -----------------------------------------------------------------------------
// 2. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents the structure of a Sentry Event payload received via webhook.
 * This is a simplified version of the Sentry 'Event' interface.
 */
interface SentryEventPayload {
    event_id: string;
    level: 'fatal' | 'error' | 'warning' | 'info';
    culprit?: string; // The function or file causing the crash
    message?: string;
    tags?: Record<string, string>;
    user?: {
        id: string;
        email?: string;
        ip_address?: string;
    };
    exception?: {
        values: Array<{
            type: string;
            value: string;
            stacktrace?: {
                frames: Array<{ filename: string; function: string; lineno: number }>;
            };
        }>;
    };
    release?: string; // App Store version (e.g., 1.2.0)
}

/**
 * Represents the output of our AI-Driven Triage analysis.
 */
interface TriageResult {
    priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
    estimatedImpact: number; // 0.0 to 1.0
    suggestedAction: string;
    requiresHotfix: boolean;
}

// -----------------------------------------------------------------------------
// 3. NON-BLOCKING I/O UTILITIES
// -----------------------------------------------------------------------------

/**
 * Converts a Next.js Request body into a Node.js Readable Stream.
 * 
 * WHY: Next.js Request.body is a ReadableStream (Web Streams API), but Sentry's
 * Node.js SDK and some utility functions often expect Node.js streams.
 * 
 * HOW: We implement a generator to bridge the Web Stream to a Node.js Stream,
 * ensuring we don't block the event loop by buffering the entire payload in memory.
 * 
 * @param request The incoming Next.js request.
 * @returns A Promise resolving to a Node.js Readable Stream.
 */
async function getRequestBodyStream(request: NextRequest): Promise<Readable> {
    // Access the underlying ReadableStream from the Web API
    const webReadableStream = request.body;

    if (!webReadableStream) {
        return Readable.from([]); // Return empty stream if no body
    }

    // Create a Node.js Readable stream from the Web Stream
    // This is a non-blocking operation; data is pulled as it arrives.
    const nodeReadableStream = Readable.from(webReadableStream);
    
    return nodeReadableStream;
}

// -----------------------------------------------------------------------------
// 4. AI-DRIVEN INSIGHTS & TRIAGE LOGIC
// -----------------------------------------------------------------------------

/**
 * Analyzes a Sentry event payload to prioritize fixes.
 * 
 * CONTEXT: In 'Chapter 8', we discuss using AI to optimize App Store stability.
 * While a full ML model is beyond this script, we implement a rule-based heuristic
 * that mimics AI-driven triage by scoring errors based on severity, user context,
 * and release version.
 * 
 * LOGIC:
 * 1. Critical level errors (Fatal) get top priority.
 * 2. Errors affecting 'pro-tier' users (simulated via tags) are elevated.
 * 3. Crashes in the latest release (release health) are flagged for immediate hotfix.
 * 
 * @param event The parsed Sentry event payload.
 * @returns TriageResult object.
 */
function analyzeCrashWithAI(event: SentryEventPayload): TriageResult {
    let score = 0.0;
    let action = "Review logs and reproduce locally.";
    let isHotfix = false;

    // 1. Analyze Severity
    if (event.level === 'fatal') {
        score += 0.8;
        action = "CRITICAL: App crash detected. Immediate investigation required.";
    } else if (event.level === 'error') {
        score += 0.5;
    }

    // 2. Analyze User Context (Simulating Business Value impact)
    // In a real scenario, we would query a user database.
    if (event.tags && event.tags['plan'] === 'enterprise') {
        score += 0.3; // Enterprise user crash is more urgent
        action += " (Enterprise User Impact)";
    }

    // 3. Analyze Release Health
    // If the crash is from the current release candidate, it blocks App Store deployment.
    if (event.release && event.release.includes('-rc')) {
        score += 0.4;
        isHotfix = true;
        action = "BLOCKING: Release Candidate crash. Do not deploy.";
    }

    // 4. Analyze Stack Trace (Heuristic for complexity)
    const exception = event.exception?.values?.[0];
    if (exception?.stacktrace?.frames) {
        const frames = exception.stacktrace.frames;
        // Check for native bridge errors (common in mobile)
        if (frames.some(f => f.filename.includes('native-modules'))) {
            score += 0.2;
            action += " (Native Bridge Issue)";
        }
    }

    // Determine Priority Label
    let priority: TriageResult['priority'] = 'LOW';
    if (score >= 1.0) priority = 'CRITICAL';
    else if (score >= 0.7) priority = 'HIGH';
    else if (score >= 0.4) priority = 'MEDIUM';

    return {
        priority,
        estimatedImpact: Math.min(score, 1.0),
        suggestedAction: action,
        requiresHotfix: isHotfix,
    };
}

// -----------------------------------------------------------------------------
// 5. NEXT.JS API ROUTE HANDLER
// -----------------------------------------------------------------------------

/**
 * POST /api/sentry/webhook
 * 
 * DESCRIPTION:
 * This endpoint receives crash reports from Sentry (or directly from the client).
 * It performs non-blocking processing to validate, analyze, and store the data.
 * 
 * FLOW:
 * 1. Receive Payload (Non-Blocking Stream).
 * 2. Parse JSON (Async).
 * 3. Run AI Triage Analysis.
 * 4. Log to Sentry (Self-Reporting) or Database.
 * 5. Return Health Status for App Store CI/CD pipeline.
 */
export async function POST(request: NextRequest) {
    // Start a Sentry Transaction for performance monitoring
    const transaction = Sentry.startTransaction({
        op: 'ingest',
        name: 'Sentry Webhook Ingestion',
    });

    try {
        // STEP 1: Non-Blocking I/O - Read stream without buffering full body
        // We use a promise-based approach to handle the stream data.
        const stream = await getRequestBodyStream(request);
        
        // Collect chunks asynchronously
        const chunks: Buffer[] = [];
        for await (const chunk of stream) {
            chunks.push(Buffer.from(chunk));
        }
        
        // Concatenate chunks only when the stream ends
        const buffer = Buffer.concat(chunks);
        
        // STEP 2: Parse the Sentry Event Payload
        // In a real webhook, Sentry sends JSON. We parse it here.
        const payload: SentryEventPayload = JSON.parse(buffer.toString('utf8'));

        // STEP 3: AI-Driven Triage
        // We analyze the crash to determine if it blocks the App Store release.
        const triageResult = analyzeCrashWithAI(payload);

        // STEP 4: Log Insights & Context
        // We use Sentry's context to tag this processing run.
        Sentry.setContext('TriageResult', {
            priority: triageResult.priority,
            impact: triageResult.estimatedImpact,
            isBlocking: triageResult.requiresHotfix,
        });

        Sentry.setTag('crash.origin', payload.culprit || 'unknown');
        Sentry.setTag('app.version', payload.release || 'unknown');

        // If the crash is critical, we capture it as a distinct event in our own Sentry instance
        // to track how often we are receiving critical errors from clients.
        if (triageResult.priority === 'CRITICAL' || triageResult.priority === 'HIGH') {
            Sentry.captureMessage(`Received High Priority Crash: ${payload.message}`, {
                level: 'warning', // Warning in our system, Error in client
                extra: {
                    originalEventId: payload.event_id,
                    user: payload.user?.id,
                    triage: triageResult,
                }
            });
        }

        // STEP 5: Simulate Database Write (Non-Blocking)
        // In a real app, we would await a database call here.
        // We use a simple promise to simulate non-blocking DB I/O.
        await new Promise(resolve => setTimeout(resolve, 50)); // Simulated latency

        // STEP 6: Return Response for CI/CD
        // If this is an automated check from a build pipeline, we return the status.
        const responseStatus = triageResult.requiresHotfix ? 400 : 200;
        
        const responseData = {
            status: responseStatus === 200 ? 'success' : 'blocked',
            message: `Crash processed. Priority: ${triageResult.priority}`,
            action: triageResult.suggestedAction,
            releaseHealth: triageResult.requiresHotfix ? 'unhealthy' : 'healthy',
        };

        return NextResponse.json(responseData, { status: responseStatus });

    } catch (error) {
        // Global Error Handling
        // If the script crashes, capture it to Sentry (Self-Healing loop).
        Sentry.captureException(error);
        
        return NextResponse.json(
            { error: 'Internal Server Error', details: (error as Error).message },
            { status: 500 }
        );
    } finally {
        // Ensure the transaction finishes
        transaction.finish();
    }
}

// -----------------------------------------------------------------------------
// 6. EXPORTS FOR TESTING
// -----------------------------------------------------------------------------

// Export the handler for unit testing
export const dynamic = 'force-dynamic'; // Ensure Next.js doesn't cache this API route
