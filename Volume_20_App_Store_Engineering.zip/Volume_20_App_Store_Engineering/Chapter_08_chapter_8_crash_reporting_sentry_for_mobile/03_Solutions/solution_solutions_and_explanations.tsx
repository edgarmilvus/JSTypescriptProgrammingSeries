/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: SentryErrorBoundary.tsx
import React, { Component, ErrorInfo } from 'react';
import * as Sentry from '@sentry/react-native';

// Define the props interface for the Error Boundary
interface SentryErrorBoundaryProps {
  children: React.ReactNode;
}

// Define the state interface
interface SentryErrorBoundaryState {
  hasError: boolean;
}

export class SentryErrorBoundary extends Component<SentryErrorBoundaryProps, SentryErrorBoundaryState> {
  constructor(props: SentryErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  // 1. Capture the error and report to Sentry
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Update state to display fallback UI
    this.setState({ hasError: true });

    // Capture the exception with additional context
    Sentry.withScope((scope) => {
      scope.setContext('React Error', errorInfo);
      Sentry.captureException(error);
    });
  }

  // 2. Set user context when the component mounts
  componentDidMount() {
    Sentry.setUser({
      id: 'user-123',
      email: 'test@example.com',
    });
  }

  render() {
    if (this.state.hasError) {
      // Fallback UI
      return (
        <div style={{ padding: '20px', color: 'red' }}>
          <h1>Something went wrong.</h1>
          <p>This error has been reported to our team.</p>
          <button onClick={() => this.setState({ hasError: false })}>
            Try Again
          </button>
        </div>
      );
    }

    // Render children if no error
    return this.props.children;
  }
}
