/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: sentryPerformance.ts
import * as Sentry from '@sentry/react-native';

/**
 * Wraps an asynchronous API call with Sentry performance monitoring.
 * @param transactionName - The name of the transaction to track.
 * @param apiCall - The async function to execute and measure.
 * @returns - The result of the API call.
 */
export async function withSentryPerformance<T>(
  transactionName: string,
  apiCall: () => Promise<T>
): Promise<T> {
  // Start the transaction
  const transaction = Sentry.startTransaction({
    name: transactionName,
    op: 'http.client', // Operation type
  });

  // Create a span within the transaction
  const span = transaction.startChild({
    op: 'fetch',
    description: `Fetching data for ${transactionName}`,
  });

  try {
    // Execute the API call
    const result = await apiCall();
    
    // If successful, set status to OK
    span.setStatus('ok');
    return result;
  } catch (error) {
    // If failed, capture the error and set status to internal_error
    Sentry.captureException(error);
    span.setStatus('internal_error');
    
    // Re-throw the error to ensure the calling code handles it
    throw error;
  } finally {
    // Always finish the span and transaction
    span.finish();
    transaction.finish();
  }
}

// Example usage simulation (for context only):
// const fetchProduct = async () => {
//   return new Promise((resolve) => setTimeout(() => resolve({ id: 1, name: 'Product' }), 500));
// };
// await withSentryPerformance('fetchProductDetails', fetchProduct);
