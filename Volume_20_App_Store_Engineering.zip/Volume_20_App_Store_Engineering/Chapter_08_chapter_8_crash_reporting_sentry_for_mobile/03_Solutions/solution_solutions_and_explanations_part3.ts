/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: sentryConfig.ts
import * as Sentry from '@sentry/react-native';

// Define the target release version
const TARGET_RELEASE = 'v2.1.0';

// 1. Define the beforeSend hook function
const beforeSend = (event: Sentry.Event): Sentry.Event | null => {
  // Access tags from the event. 
  // Note: In a real app, tags might be set in the options or globally.
  const environment = event.tags?.environment;
  const release = event.tags?.release;

  // Filter Logic:
  // 1. Ignore crashes from Development environment
  if (environment === 'Development') {
    return null;
  }

  // 2. In Production, only track crashes for the specific release version
  if (environment === 'Production' && release !== TARGET_RELEASE) {
    return null;
  }

  // Return the event to be sent if conditions are met
  return event;
};

// 2. Initialize Sentry with configuration
export const initSentry = () => {
  Sentry.init({
    dsn: 'https://examplePublicKey@o0.ingest.sentry.io/0', // Dummy DSN
    
    // Set environment and release tags globally
    environment: process.env.NODE_ENV || 'development', // e.g., 'production', 'development', 'staging'
    release: TARGET_RELEASE,

    // Attach the filtering hook
    beforeSend: beforeSend,
    
    // Enable debug logging for this exercise
    debug: true,
  });
};
