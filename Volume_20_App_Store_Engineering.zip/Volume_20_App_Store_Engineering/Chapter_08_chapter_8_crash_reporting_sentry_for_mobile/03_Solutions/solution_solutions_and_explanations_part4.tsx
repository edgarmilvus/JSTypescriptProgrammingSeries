/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: CrashDashboard.tsx
import React, { useState } from 'react';

// 1. Define the interface for a Crash Event
interface CrashEvent {
  id: string;
  message: string;
  timestamp: Date;
  user: {
    id: string;
    email: string;
  };
}

// Mock Data
const MOCK_DATA: CrashEvent[] = [
  { id: '1', message: 'Null Reference Exception', timestamp: new Date(), user: { id: 'user-123', email: 'test@example.com' } },
  { id: '2', message: 'Network Timeout', timestamp: new Date(), user: { id: 'user-456', email: 'client@example.com' } },
];

export const CrashDashboard: React.FC = () => {
  // 2. State for crash events and filter input
  const [crashes, setCrashes] = useState<CrashEvent[]>(MOCK_DATA);
  const [filter, setFilter] = useState<string>('');

  // 3. Filter logic
  const filteredCrashes = crashes.filter((crash) => 
    crash.user.id.toLowerCase().includes(filter.toLowerCase())
  );

  // 4. Handler for simulating a crash
  const handleSimulateCrash = () => {
    // Add a new mock event to local state to simulate real-time update
    const newCrash: CrashEvent = {
      id: Date.now().toString(),
      message: 'Simulated UI Crash',
      timestamp: new Date(),
      user: { id: 'user-999', email: 'simulated@example.com' }
    };
    
    // Update state first (so UI updates even if error occurs)
    setCrashes((prev) => [...prev, newCrash]);

    // Throw an error to be caught by a parent Error Boundary
    throw new Error('Simulated Crash triggered by user action');
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Crash Analytics Dashboard</h2>
      
      {/* Filter Input */}
      <div style={{ marginBottom: '15px' }}>
        <label>Filter by User ID: </label>
        <input
          type="text"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Enter user ID..."
          style={{ padding: '5px', marginLeft: '5px' }}
        />
      </div>

      {/* Simulate Crash Button */}
      <button 
        onClick={handleSimulateCrash}
        style={{ backgroundColor: 'red', color: 'white', padding: '10px', border: 'none', cursor: 'pointer', marginBottom: '20px' }}
      >
        Simulate Crash
      </button>

      {/* Crash List Table */}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2' }}>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>ID</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Message</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>User ID</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Email</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Time</th>
          </tr>
        </thead>
        <tbody>
          {filteredCrashes.map((crash) => (
            <tr key={crash.id}>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{crash.id}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{crash.message}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{crash.user.id}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{crash.user.email}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                {crash.timestamp.toLocaleTimeString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {filteredCrashes.length === 0 && <p>No crashes found for this user ID.</p>}
    </div>
  );
};
