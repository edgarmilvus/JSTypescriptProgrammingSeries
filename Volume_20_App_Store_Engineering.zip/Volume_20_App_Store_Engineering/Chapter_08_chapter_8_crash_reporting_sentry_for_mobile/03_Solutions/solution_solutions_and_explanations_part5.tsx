/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// File: ReleaseHealthCard.tsx
import React from 'react';

// 1. Define the interface for the stats
interface ReleaseHealthStats {
  totalUsers: number;
  crashFreeUsers: number;
  crashFreeRate: number; // Expressed as a percentage (e.g., 98.5)
}

// 2. Define props interface
interface ReleaseHealthCardProps {
  stats: ReleaseHealthStats;
}

// 3. Mock Data Fetcher (Simulating Server-Side Fetch)
export const fetchReleaseHealthStats = async (): Promise<ReleaseHealthStats> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Return mock data
  return {
    totalUsers: 10000,
    crashFreeUsers: 9850,
    crashFreeRate: 98.5,
  };
};

// 4. The Component
export const ReleaseHealthCard: React.FC<ReleaseHealthCardProps> = ({ stats }) => {
  // Determine color based on crash-free rate
  let colorClass = 'red';
  if (stats.crashFreeRate > 95) colorClass = 'green';
  else if (stats.crashFreeRate > 90) colorClass = 'orange'; // Yellow/Orange for caution

  const cardStyle: React.CSSProperties = {
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    padding: '20px',
    maxWidth: '300px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    backgroundColor: '#fff',
  };

  const rateStyle: React.CSSProperties = {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: colorClass === 'green' ? '#2ecc71' : colorClass === 'orange' ? '#f39c12' : '#e74c3c',
    margin: '10px 0',
  };

  return (
    <div style={cardStyle}>
      <h3 style={{ margin: 0, color: '#333' }}>Release Health (v2.1.0)</h3>
      <div style={rateStyle}>{stats.crashFreeRate}%</div>
      <p style={{ margin: 0, color: '#666' }}>
        Crash-Free Users: {stats.crashFreeUsers.toLocaleString()} / {stats.totalUsers.toLocaleString()}
      </p>
      <div style={{ marginTop: '10px', height: '8px', backgroundColor: '#eee', borderRadius: '4px', overflow: 'hidden' }}>
        <div 
          style={{ 
            width: `${stats.crashFreeRate}%`, 
            height: '100%', 
            backgroundColor: colorClass === 'green' ? '#2ecc71' : colorClass === 'orange' ? '#f39c12' : '#e74c3c' 
          }} 
        />
      </div>
    </div>
  );
};

// --- Usage Example (for context) ---
// In a parent component or Next.js Server Component:
/*
const ParentComponent = async () => {
  const stats = await fetchReleaseHealthStats();
  return <ReleaseHealthCard stats={stats} />;
};
*/
