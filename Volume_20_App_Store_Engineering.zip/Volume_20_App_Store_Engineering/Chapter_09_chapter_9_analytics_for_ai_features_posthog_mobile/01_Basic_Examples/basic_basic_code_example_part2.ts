/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph AI_Analytics_Flow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e1f5fe"];
    
    Client [label="Client App", fillcolor="#bbdefb"];
    Backend [label="Node.js Backend", fillcolor="#fff9c4"];
    AI_Model [label="External AI Model", fillcolor="#e1bee7"];
    PostHog_API [label="PostHog API", fillcolor="#c8e6c9"];
    Dashboard [label="Analytics Dashboard", fillcolor="#b2dfdb"];

    Client -> Backend [label="1. Request (Prompt)"];
    Backend -> AI_Model [label="2. Async Call (Latency Timer Starts)"];
    AI_Model -> Backend [label="3. Response (Summary)"];
    
    Backend -> PostHog_API [label="4. Capture Event\n(latency, accuracy, version)"];
    PostHog_API -> Dashboard [label="5. Aggregated Data"];

    // Highlight the feedback loop
    Backend -> Backend [label="Error Tracking", style="dashed", color="red"];
}
