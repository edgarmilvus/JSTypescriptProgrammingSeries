/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Analytics Instrumentation for AI Features in Next.js SaaS
 * 
 * This script demonstrates how to instrument AI interactions using PostHog
 * within a modern Next.js architecture (App Router). It separates concerns:
 * 1. Data fetching in Server Components for initial context.
 * 2. Client-side interaction handling and event tracking.
 * 3. Structured payload definitions (Tool Invocation Signature pattern).
 */

import { useEffect, useState } from 'react';
import posthog from 'posthog-js';
import { PostHogProvider } from 'posthog-js/react';

// ==========================================
// 1. TYPE DEFINITIONS & TOOL INVOCATION SIGNATURE
// ==========================================

/**
 * Defines the structure for our AI analytics event.
 * Mimicking a "Tool Invocation Signature" ensures that every event 
 * sent to the analytics platform adheres to a strict schema.
 */
export interface AIAnalyticsPayload {
  event: string;
  distinctId: string; // User ID
  properties: {
    model: string;
    promptLength: number;
    latencyMs: number;
    responseTokenCount: number;
    feedbackScore?: number; // 0 for bad, 1 for good
    context: string; // e.g., 'dashboard_summarizer'
    timestamp: Date;
  };
}

// ==========================================
// 2. SERVER-SIDE DATA FETCHING (Server Component)
// ==========================================

/**
 * Fetches initial conversation context and user profile data directly 
 * within a Server Component. This prevents client-side waterfalls and 
 * ensures the AI model receives necessary context immediately.
 * 
 * In a real app, this would query a database (e.g., Supabase, Prisma).
 * 
 * @returns {Promise<{ context: string, userId: string }>}
 */
async function fetchInitialContext(): Promise<{ context: string; userId: string }> {
  // Simulate database latency
  await new Promise((resolve) => setTimeout(resolve, 100));
  
  return {
    context: "User is viewing the 'Revenue Dashboard'. Current focus: Q3 Metrics.",
    userId: `user_${Math.random().toString(36).substr(2, 9)}` // Mock User ID
  };
}

// ==========================================
// 3. CLIENT-SIDE HOOK: AI INTERACTION & ANALYTICS
// ==========================================

/**
 * Custom hook to handle AI generation requests.
 * 
 * Responsibilities:
 * 1. Manage loading/error states.
 * 2. Measure latency (start vs. end time).
 * 3. Send structured events to PostHog.
 * 4. Handle user feedback submission.
 */
function useAIChatbot(initialUserId: string) {
  const [response, setResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [latency, setLatency] = useState<number>(0);

  /**
   * Core function to invoke the AI API.
   * 
   * @param prompt - The user's input text
   * @param model - The specific AI model identifier (e.g., 'gpt-4-turbo')
   */
  const invokeAI = async (prompt: string, model: string = 'gpt-4-turbo') => {
    setIsLoading(true);
    const startTime = performance.now();

    // 1. Capture Start Event (Optional, good for tracking initiation rates)
    posthog.capture('ai_invocation_started', {
      model,
      promptLength: prompt.length,
      context: 'dashboard_summarizer'
    });

    try {
      // Simulate API Call to Next.js Route Handler
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, model, context: 'dashboard_summarizer' })
      });

      if (!res.ok) throw new Error('API Error');

      const data = await res.json();
      const endTime = performance.now();
      const latencyMs = Math.round(endTime - startTime);

      setResponse(data.text);
      setLatency(latencyMs);

      // 2. Capture Success Event (The "Tool Invocation" result)
      const analyticsPayload: AIAnalyticsPayload = {
        event: 'ai_invocation_completed',
        distinctId: initialUserId,
        properties: {
          model,
          promptLength: prompt.length,
          latencyMs,
          responseTokenCount: data.text.split(' ').length, // Approximate
          context: 'dashboard_summarizer',
          timestamp: new Date()
        }
      };

      // Send to PostHog
      posthog.capture(analyticsPayload.event, analyticsPayload.properties);

    } catch (error) {
      posthog.capture('ai_invocation_error', {
        model,
        error: (error as Error).message
      });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handles user feedback on the AI response.
   * @param isPositive - Boolean indicating thumbs up/down
   */
  const submitFeedback = (isPositive: boolean) => {
    posthog.capture('ai_feedback_submitted', {
      score: isPositive ? 1 : 0,
      model: 'gpt-4-turbo', // Should ideally be dynamic
      context: 'dashboard_summarizer'
    });
    
    // Visual feedback for the user
    alert(`Feedback recorded: ${isPositive ? 'Positive' : 'Negative'}`);
  };

  return { response, isLoading, latency, invokeAI, submitFeedback };
}

// ==========================================
// 4. REACT COMPONENT IMPLEMENTATION
// ==========================================

/**
 * The main UI Component wrapping the AI feature.
 * Note: In Next.js App Router, this would likely be a Server Component 
 * passing props to a Client Component.
 */
export default function AIAnalyticsDashboard({ 
  initialContext 
}: { 
  initialContext: Awaited<ReturnType<typeof fetchInitialContext>> 
}) {
  // Initialize PostHog on the client side only
  useEffect(() => {
    if (typeof window !== 'undefined') {
      posthog.init(process.env.NEXT_PUBLIC_POSTHOG_KEY!, {
        api_host: process.env.NEXT_PUBLIC_POSTHOG_HOST,
        capture_pageview: false, // We handle manual pageviews
      });
    }
  }, []);

  const { response, isLoading, latency, invokeAI, submitFeedback } = useAIChatbot(initialContext.userId);

  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target = e.target as HTMLFormElement;
    const input = target.querySelector('input') as HTMLInputElement;
    invokeAI(input.value);
    input.value = '';
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-gray-50 rounded-lg shadow-sm">
      <h1 className="text-2xl font-bold mb-4">AI Analytics Demo</h1>
      
      <div className="bg-white p-4 rounded border mb-6">
        <h2 className="text-sm font-semibold text-gray-500 uppercase">Server Context</h2>
        <p className="text-sm text-gray-700 mt-1">{initialContext.context}</p>
      </div>

      <form onSubmit={handlePromptSubmit} className="flex gap-2 mb-6">
        <input 
          type="text" 
          placeholder="Ask a question about revenue..." 
          className="flex-1 p-2 border rounded"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          disabled={isLoading}
        >
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
      </form>

      {response && (
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded border border-blue-100">
            <div className="flex justify-between items-center mb-2">
              <span className="font-bold text-blue-800">AI Response</span>
              <span className="text-xs text-gray-500">Latency: {latency}ms</span>
            </div>
            <p>{response}</p>
          </div>

          {/* Feedback Mechanism */}
          <div className="flex gap-2 items-center">
            <span className="text-sm font-medium">Was this helpful?</span>
            <button 
              onClick={() => submitFeedback(true)}
              className="px-3 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 text-sm"
            >
              👍 Yes
            </button>
            <button 
              onClick={() => submitFeedback(false)}
              className="px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm"
            >
              👎 No
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 5. NEXT.JS SERVER COMPONENT WRAPPER (Example Usage)
// ==========================================

/**
 * Example of a Parent Server Component (e.g., app/page.tsx) 
 * that fetches data before rendering the client component.
 */
export async function AIAnalyticsPage() {
  const initialData = await fetchInitialContext();
  
  return (
    <PostHogProvider client={posthog}>
      <AIAnalyticsDashboard initialContext={initialData} />
    </PostHogProvider>
  );
}
