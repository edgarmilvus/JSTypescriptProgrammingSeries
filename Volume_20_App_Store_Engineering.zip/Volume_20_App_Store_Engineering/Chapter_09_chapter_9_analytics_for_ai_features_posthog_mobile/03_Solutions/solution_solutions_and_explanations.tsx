/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: src/components/AISummarizer.tsx
import React, { useState } from 'react';

// Assuming PostHog is globally available or imported via context
declare global {
  interface Window {
    posthog: any;
  }
}

export const AISummarizer: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSummarize = () => {
    // Clear previous errors
    setError(null);

    // 1. Check for empty input and track error
    if (!inputText.trim()) {
      window.posthog.capture('ai_summarizer_error', {
        error_type: 'empty_input',
        timestamp: new Date().toISOString(),
      });
      setError('Please enter some text to summarize.');
      return;
    }

    // 2. Track Request Event
    const inputLength = inputText.length;
    window.posthog.capture('ai_summarizer_request', {
      input_length: inputLength,
    });

    // 3. Start Loading
    setIsLoading(true);

    // 4. Simulate API Call (1-2 seconds)
    const simulatedDelay = 1500; // ms

    setTimeout(() => {
      // 5. Generate Mock Response
      const truncatedText = inputText.substring(0, 50) + (inputText.length > 50 ? '...' : '');
      const mockResponse = `Summary: [AI generated summary for: ${truncatedText}]`;
      
      // 6. Track Success Event
      window.posthog.capture('ai_summarizer_success', {
        response_time_ms: simulatedDelay,
        output_length: mockResponse.length,
      });

      setSummary(mockResponse);
      setIsLoading(false);
    }, simulatedDelay);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: '0 auto' }}>
      <h2>AI Text Summarizer</h2>
      
      <textarea
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        placeholder="Enter text to summarize..."
        rows={5}
        style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
        disabled={isLoading}
      />
      
      <button 
        onClick={handleSummarize} 
        disabled={isLoading}
        style={{ padding: '10px 20px', cursor: 'pointer' }}
      >
        {isLoading ? 'Summarizing...' : 'Summarize'}
      </button>

      {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
      
      {summary && (
        <div style={{ marginTop: '20px', padding: '10px', border: '1px solid #ccc' }}>
          <h3>Result:</h3>
          <p>{summary}</p>
        </div>
      )}
    </div>
  );
};
