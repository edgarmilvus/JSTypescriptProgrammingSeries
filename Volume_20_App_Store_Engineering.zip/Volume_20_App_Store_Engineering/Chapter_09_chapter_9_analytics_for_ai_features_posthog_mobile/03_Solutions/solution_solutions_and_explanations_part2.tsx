/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// File: src/components/AIChatWithFeedback.tsx
import React, { useState } from 'react';

declare global {
  interface Window {
    posthog: any;
  }
}

interface FeedbackState {
  submitted: boolean;
  rating: 'good' | 'bad' | null;
}

export const AIChatWithFeedback: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // State to track feedback for the current interaction
  const [feedback, setFeedback] = useState<FeedbackState>({ submitted: false, rating: null });
  
  // State to store metadata needed for the feedback event
  const [currentMeta, setCurrentMeta] = useState<{ requestId: string; responseTime: number } | null>(null);

  const handleRequest = () => {
    if (!inputText.trim()) return;

    const requestId = crypto.randomUUID(); // Generate unique ID
    const responseTime = 2000; // Simulated latency

    // Reset feedback for new request
    setFeedback({ submitted: false, rating: null });
    setCurrentMeta(null);
    setResponse(null);
    setIsLoading(true);

    // Capture Request
    window.posthog.capture('ai_summarizer_request', {
      input_length: inputText.length,
      request_id: requestId,
    });

    setTimeout(() => {
      const mockResponse = `Summary of "${inputText.substring(0, 20)}..."`;
      setResponse(mockResponse);
      setIsLoading(false);

      // Capture Success
      window.posthog.capture('ai_summarizer_success', {
        response_time_ms: responseTime,
        output_length: mockResponse.length,
        request_id: requestId, // Correlate success with request
      });

      // Store metadata for the feedback step
      setCurrentMeta({ requestId, responseTime });
    }, 2000);
  };

  const handleFeedback = (rating: 'good' | 'bad') => {
    if (!currentMeta || feedback.submitted) return;

    // Capture Feedback
    window.posthog.capture('ai_feedback_submitted', {
      rating: rating,
      model_version: 'summarizer-v1.2', // Hardcoded version
      request_id: currentMeta.requestId,
      response_time_ms: currentMeta.responseTime,
    });

    // Update UI State to prevent double submission
    setFeedback({ submitted: true, rating });
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>AI Chat with Feedback</h2>
      
      <div style={{ marginBottom: '15px' }}>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask a question..."
          style={{ width: '70%', padding: '8px' }}
        />
        <button onClick={handleRequest} disabled={isLoading} style={{ marginLeft: '10px', padding: '8px 16px' }}>
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
      </div>

      {response && (
        <div style={{ padding: '15px', background: '#f0f2f5', borderRadius: '8px' }}>
          <p><strong>AI:</strong> {response}</p>
          
          <div style={{ marginTop: '10px', borderTop: '1px solid #ddd', paddingTop: '10px' }}>
            <span>Was this helpful? </span>
            
            {!feedback.submitted ? (
              <>
                <button 
                  onClick={() => handleFeedback('good')} 
                  style={{ background: '#d4edda', border: 'none', padding: '5px 10px', cursor: 'pointer', marginRight: '5px' }}
                >
                  👍 Good
                </button>
                <button 
                  onClick={() => handleFeedback('bad')} 
                  style={{ background: '#f8d7da', border: 'none', padding: '5px 10px', cursor: 'pointer' }}
                >
                  👎 Bad
                </button>
              </>
            ) : (
              <span style={{ color: 'green', fontWeight: 'bold' }}>
                {feedback.rating === 'good' ? 'Thanks for the positive feedback!' : 'Thanks, we will improve.'}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
