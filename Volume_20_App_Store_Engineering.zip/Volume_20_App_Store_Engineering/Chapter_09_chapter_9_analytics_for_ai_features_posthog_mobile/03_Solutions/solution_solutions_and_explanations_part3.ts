/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: simulate_ai_latency.ts
import { randomInt } from 'node:crypto';

// Interface for the API response
interface AIResponse {
  response: string;
  latency: number;
}

/**
 * Simulates an AI API call with random latency between 100ms and 2000ms.
 * @param prompt - The input text for the AI.
 * @returns Promise resolving to AIResponse
 */
const callAIModel = async (prompt: string): Promise<AIResponse> => {
  // Random delay between 100ms (0.1s) and 2000ms (2s)
  const latency = randomInt(100, 2001);
  
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        response: `Processed: ${prompt.substring(0, 10)}...`,
        latency: latency,
      });
    }, latency);
  });
};

/**
 * Calculates the standard deviation of an array of numbers.
 */
const calculateStdDev = (values: number[], mean: number): number => {
  const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / values.length;
  return Math.sqrt(variance);
};

/**
 * Main function to run the simulation.
 */
const runSimulation = async () => {
  console.log('Starting AI Latency Simulation...');
  const latencies: number[] = [];
  const numCalls = 10;

  for (let i = 0; i < numCalls; i++) {
    const prompt = `Summarize text ${i + 1}`;
    const result = await callAIModel(prompt);
    latencies.push(result.latency);
    console.log(`Call ${i + 1}: Latency ${result.latency}ms`);
  }

  // Calculate Statistics
  const sum = latencies.reduce((acc, val) => acc + val, 0);
  const average = sum / latencies.length;
  const min = Math.min(...latencies);
  const max = Math.max(...latencies);
  const stdDev = calculateStdDev(latencies, average);

  console.log('\n--- Latency Statistics ---');
  console.log(`Average Latency: ${average.toFixed(2)}ms`);
  console.log(`Minimum Latency: ${min}ms`);
  console.log(`Maximum Latency: ${max}ms`);
  console.log(`Standard Deviation: ${stdDev.toFixed(2)}ms`);
  console.log('--------------------------');
};

runSimulation().catch(console.error);
