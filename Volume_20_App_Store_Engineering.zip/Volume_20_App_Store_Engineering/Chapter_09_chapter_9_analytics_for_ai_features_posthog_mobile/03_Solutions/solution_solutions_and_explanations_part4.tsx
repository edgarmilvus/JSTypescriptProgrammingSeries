/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: src/components/AISummarizerWithFeatureFlag.tsx
import React, { useState, useEffect } from 'react';

declare global {
  interface Window {
    posthog: any;
  }
}

export const AISummarizerWithFeatureFlag: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // State for the feature flag (defaulting to false)
  const [isV2Enabled, setIsV2Enabled] = useState(false);

  // Check flag on mount (in a real app, this is handled by PostHog provider)
  useEffect(() => {
    // Simulating a check against PostHog
    const flagEnabled = window.posthog?.isFeatureEnabled('ai-summarizer-v2');
    setIsV2Enabled(!!flagEnabled);
  }, []);

  // Handler for the manual UI toggle
  const toggleFeatureFlag = () => {
    const newState = !isV2Enabled;
    setIsV2Enabled(newState);
    
    // In a real scenario, you might use posthog.setFeatureFlagsForTesting 
    // or reload the page to fetch new flags. 
    // Here we just update local state to simulate the change.
    console.log(`Feature flag 'ai-summarizer-v2' set to: ${newState}`);
  };

  const handleSummarize = () => {
    if (!inputText.trim()) return;

    setIsLoading(true);
    
    // Determine Model Version based on Flag State
    const modelVersion = isV2Enabled ? 'summarizer-v2.0' : 'summarizer-v1.2';
    const simulatedDelay = isV2Enabled ? 800 : 1500; // V2 is faster!

    // Capture Request with Model Version
    window.posthog.capture('ai_summarizer_request', {
      input_length: inputText.length,
      model_version: modelVersion, // Dynamic property
    });

    setTimeout(() => {
      const mockResponse = isV2Enabled 
        ? `V2 Summary: [Optimized summary for ${inputText.substring(0, 20)}...]`
        : `V1 Summary: [Standard summary for ${inputText.substring(0, 20)}...]`;
      
      // Capture Success with Model Version
      window.posthog.capture('ai_summarizer_success', {
        response_time_ms: simulatedDelay,
        output_length: mockResponse.length,
        model_version: modelVersion, // Dynamic property
      });

      setSummary(mockResponse);
      setIsLoading(false);
    }, simulatedDelay);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: '0 auto', border: '1px solid #eee' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h3>AI Summarizer (Model: {isV2Enabled ? 'v2.0' : 'v1.2'})</h3>
        
        {/* Interactive Challenge: UI Toggle */}
        <label style={{ fontSize: '12px', cursor: 'pointer' }}>
          <input 
            type="checkbox" 
            checked={isV2Enabled} 
            onChange={toggleFeatureFlag} 
          />
          Enable V2 (Simulated)
        </label>
      </div>

      <textarea
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        placeholder="Enter text..."
        rows={4}
        style={{ width: '100%', marginBottom: '10px' }}
        disabled={isLoading}
      />
      
      <button onClick={handleSummarize} disabled={isLoading}>
        {isLoading ? 'Processing...' : 'Summarize'}
      </button>

      {summary && (
        <div style={{ marginTop: '15px', padding: '10px', background: '#f9f9f9' }}>
          <strong>Result:</strong> {summary}
        </div>
      )}
    </div>
  );
};
