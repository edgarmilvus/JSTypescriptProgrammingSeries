/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A mock implementation of a WebGPU-accelerated inference engine
 * for a quantized model. This simulates the client-side logic required to run
 * AI tasks in a browser environment, which is critical for offloading server
 * compute in a SaaS architecture.
 */

// Type definitions for our mock WebGPU structures
type GPUBindGroupLayout = { label: string };
type GPUComputePipeline = { label: string };
type GPUBuffer = { size: number; usage: number };
type GPUShaderModule = { code: string };

/**
 * Mock WebGPU API Context
 * In a real browser, this would be obtained via `navigator.gpu.requestAdapter()`
 * and `device.requestAdapter()`.
 */
const mockWebGPUContext = {
  device: {
    createShaderModule: (descriptor: { code: string }): GPUShaderModule => {
      console.log(`[WebGPU] Created shader module with ${descriptor.code.length} bytes.`);
      return { code: descriptor.code };
    },
    createBindGroupLayout: (descriptor: any): GPUBindGroupLayout => {
      console.log(`[WebGPU] Created bind group layout: ${descriptor.label}`);
      return { label: descriptor.label };
    },
    createComputePipeline: (descriptor: any): GPUComputePipeline => {
      console.log(`[WebGPU] Created compute pipeline: ${descriptor.label}`);
      return { label: descriptor.label };
    },
    createBuffer: (descriptor: { size: number; usage: number }): GPUBuffer => {
      console.log(`[WebGPU] Allocated buffer of ${descriptor.size} bytes.`);
      return { size: descriptor.size, usage: descriptor.usage };
    },
    // Simulate writing data to a GPU buffer (e.g., input tensor)
    queue: {
      writeBuffer: (buffer: GPUBuffer, data: Float32Array) => {
        console.log(`[WebGPU] Wrote ${data.length} floats to buffer.`);
      },
      submit: (commandBuffers: any[]) => {
        console.log(`[WebGPU] Submitted ${commandBuffers.length} command buffer(s) for execution.`);
      }
    },
    createCommandEncoder: () => ({
      beginComputePass: () => ({
        setPipeline: (pipeline: GPUComputePipeline) => {
          console.log(`[WebGPU] Compute pass set to pipeline: ${pipeline.label}`);
        },
        setBindGroup: (index: number, layout: GPUBindGroupLayout) => {
          console.log(`[WebGPU] Bind group ${index} set for layout: ${layout.label}`);
        },
        dispatchWorkgroups: (x: number, y: number, z: number) => {
          console.log(`[WebGPU] Dispatching workgroups: (${x}, ${y}, ${z})`);
        },
        end: () => console.log(`[WebGPU] Compute pass ended.`)
      }),
      finish: () => ({ label: 'Command Buffer' })
    })
  }
};

/**
 * Represents a quantized model (e.g., 8-bit integers).
 * In production, this would be loaded from a binary file (e.g., .bin or .onnx).
 */
interface QuantizedModel {
  weights: Int8Array; // Quantized weights (8-bit integers)
  bias: Float32Array;
  inputSize: number;
  outputSize: number;
}

/**
 * Simulates fetching a model from a remote server (e.g., CDN or API).
 * This is a critical step in OTA (Over-the-Air) updates for AI features.
 */
async function fetchQuantizedModel(): Promise<QuantizedModel> {
  console.log("Fetching quantized model from remote storage...");
  // Mock data: A simple linear layer (10 inputs -> 5 outputs)
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        weights: new Int8Array(10 * 5).fill(1), // 50 weights, quantized
        bias: new Float32Array(5).fill(0.5),
        inputSize: 10,
        outputSize: 5
      });
    }, 100); // Simulate network latency
  });
}

/**
 * Initializes the WebGPU compute pipeline.
 * This involves creating shaders and binding layouts.
 */
function initializeWebGPUPipeline(device: any, model: QuantizedModel) {
  console.log("\nInitializing WebGPU Pipeline...");
  
  // 1. Define the Compute Shader (WGSL)
  // This shader runs on the GPU. It dequantizes weights and performs the dot product.
  const shaderCode = `
    @group(0) @binding(0) var<storage, read> input: array<f32>;
    @group(0) @binding(1) var<storage, read> weights: array<i32>;
    @group(0) @binding(2) var<storage, read> bias: array<f32>;
    @group(0) @binding(3) var<storage, write> output: array<f32>;

    @compute @workgroup_size(1)
    fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
      let output_idx = global_id.x;
      if (output_idx >= arrayLength(&output)) { return; }

      var sum = 0.0;
      // Dequantize: (int8 * scale) + bias
      // In a real scenario, the scale factor is a hyperparameter.
      let scale = 0.01; 
      
      for (var i = 0u; i < arrayLength(&input); i = i + 1u) {
        let weight_val = f32(weights[i + output_idx * arrayLength(&input)]);
        sum += input[i] * weight_val * scale;
      }
      
      output[output_idx] = sum + bias[output_idx];
    }
  `;

  // 2. Create Shader Module
  const shaderModule = device.createShaderModule({ code: shaderCode });

  // 3. Create Bind Group Layout (Defines how data is accessed)
  const bindGroupLayout = device.createBindGroupLayout({
    label: "Inference Bind Group Layout",
    entries: [
      { binding: 0, visibility: 4, type: "read-only-storage" }, // Input
      { binding: 1, visibility: 4, type: "read-only-storage" }, // Weights
      { binding: 2, visibility: 4, type: "read-only-storage" }, // Bias
      { binding: 3, visibility: 4, type: "storage" }            // Output
    ]
  });

  // 4. Create Compute Pipeline
  const pipeline = device.createComputePipeline({
    label: "Quantized Inference Pipeline",
    layout: { bindGroupLayouts: [bindGroupLayout] },
    compute: { module: shaderModule, entryPoint: "main" }
  });

  return { pipeline, bindGroupLayout };
}

/**
 * Allocates GPU buffers for inputs and outputs.
 */
function allocateGPUBuffers(device: any, model: QuantizedModel, inputTensor: Float32Array) {
  console.log("\nAllocating GPU Buffers...");
  
  // Input Buffer
  const inputBuffer = device.createBuffer({
    size: inputTensor.byteLength,
    usage: 4 | 8 // COPY_DST | STORAGE
  });

  // Weights Buffer (Int8)
  const weightBuffer = device.createBuffer({
    size: model.weights.byteLength,
    usage: 4 | 8 // COPY_DST | STORAGE
  });

  // Bias Buffer
  const biasBuffer = device.createBuffer({
    size: model.bias.byteLength,
    usage: 4 | 8 // COPY_DST | STORAGE
  });

  // Output Buffer
  const outputBufferSize = model.outputSize * Float32Array.BYTES_PER_ELEMENT;
  const outputBuffer = device.createBuffer({
    size: outputBufferSize,
    usage: 8 | 16 // STORAGE | COPY_SRC
  });

  return { inputBuffer, weightBuffer, biasBuffer, outputBuffer };
}

/**
 * Main execution function.
 * 1. Loads model.
 * 2. Initializes WebGPU.
 * 3. Prepares data.
 * 4. Dispatches compute work.
 */
async function runInference() {
  const device = mockWebGPUContext.device;
  
  // 1. Load Model
  const model = await fetchQuantizedModel();
  
  // 2. Prepare Input (Mock user data)
  const inputTensor = new Float32Array(model.inputSize).fill(1.0);
  console.log(`Input Tensor: [${inputTensor.slice(0, 3)}...] (Length: ${inputTensor.length})`);

  // 3. Initialize Pipeline
  const { pipeline, bindGroupLayout } = initializeWebGPUPipeline(device, model);

  // 4. Allocate Buffers
  const buffers = allocateGPUBuffers(device, model, inputTensor);

  // 5. Write Data to GPU
  console.log("\nUploading data to GPU...");
  device.queue.writeBuffer(buffers.inputBuffer, inputTensor);
  device.queue.writeBuffer(buffers.weightBuffer, model.weights);
  device.queue.writeBuffer(buffers.biasBuffer, model.bias);

  // 6. Create Bind Group (Links buffers to the pipeline layout)
  const bindGroup = {
    label: "Inference Bind Group",
    layout: bindGroupLayout,
    entries: [
      { binding: 0, resource: { buffer: buffers.inputBuffer } },
      { binding: 1, resource: { buffer: buffers.weightBuffer } },
      { binding: 2, resource: { buffer: buffers.biasBuffer } },
      { binding: 3, resource: { buffer: buffers.outputBuffer } }
    ]
  };
  console.log("[WebGPU] Bind group created.");

  // 7. Encode Commands
  const commandEncoder = device.createCommandEncoder();
  const passEncoder = commandEncoder.beginComputePass();
  
  passEncoder.setPipeline(pipeline);
  // In a real implementation, bindGroup would be a GPUBindGroup object
  passEncoder.setBindGroup(0, bindGroup as any); 
  passEncoder.dispatchWorkgroups(model.outputSize, 1, 1); // One thread per output neuron
  passEncoder.end();

  // 8. Submit to GPU Queue
  const commandBuffer = commandEncoder.finish();
  device.queue.submit([commandBuffer]);

  // 9. Read Back Results (Simulated)
  // In a real app, we would use `buffer.mapAsync` and `getMappedRange`.
  console.log("\nInference complete. (Simulated readback)");
  console.log("Performance Monitoring: Frame time, GPU memory usage, and inference latency would be logged here.");
}

// Execute the example
runInference();
