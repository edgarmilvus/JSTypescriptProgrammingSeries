/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/monitor/performance.ts
// Next.js API Route: Performance Monitoring & Anomaly Detection
// -----------------------------------------------------------
// This script demonstrates a production-grade monitoring endpoint that:
// 1. Ingests mobile telemetry data.
// 2. Uses WebAssembly (WASM) for high-performance metric calculation.
// 3. Stores data as vectors using pgvector (via Supabase).
// 4. Detects anomalies using k-Nearest Neighbor (kNN) similarity search.

import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@supabase/supabase-js';
import { Vector } from 'pgvector'; // Hypothetical helper for pgvector serialization

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents the raw telemetry payload sent from the Expo mobile client.
 * Includes both technical metrics (latency) and user-centric metrics (interactions).
 */
interface TelemetryPayload {
  sessionId: string;
  timestamp: number;
  metrics: {
    ttfb: number; // Time to First Byte (Network)
    fcp: number;  // First Contentful Paint (Rendering)
    tti: number;  // Time to Interactive (Main Thread)
    inputDelay: number; // Latency of first user input
  };
  metadata: {
    os: string;
    appVersion: string;
  };
}

/**
 * Represents the calculated vector embedding and score stored in the database.
 * This is the "High-Dimensional Vector" referenced in the chapter context.
 */
interface StoredMetric {
  id?: string;
  session_id: string;
  vector_embedding: number[]; // The pgvector array
  perceived_score: number;    // 0.0 to 1.0 (1.0 is optimal)
  created_at?: string;
}

// Initialize Supabase Client
// In a real app, use environment variables for keys.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

// -----------------------------------------------------------------------------
// 2. WASM INTEGRATION (SIMULATED)
// -----------------------------------------------------------------------------

/**
 * Loads a WebAssembly module designed for heavy mathematical vector operations.
 * In a production environment, this would be a .wasm file compiled from Rust.
 * 
 * Why WASM? For mobile performance monitoring, we often need to process 
 * large arrays of timing data (e.g., calculating standard deviation of 1000 
 * frame times) without blocking the Node.js event loop. WASM provides 
 * near-native execution speed.
 */
async function loadWasmModule() {
  // SIMULATION: We are mocking the WASM load here for code portability.
  // In reality: const wasmBytes = fs.readFileSync('./math_utils.wasm');
  // const module = await WebAssembly.instantiate(wasmBytes);
  
  return {
    // Exports a function to calculate the Geometric Mean of latencies
    // Useful for normalizing disparate time scales (ms vs seconds).
    calculateGeometricMean: (values: Float64Array): number => {
      if (values.length === 0) return 0;
      let product = 1.0;
      for (let i = 0; i < values.length; i++) {
        product *= values[i];
      }
      return Math.pow(product, 1 / values.length);
    }
  };
}

// -----------------------------------------------------------------------------
// 3. PERCEIVED PERFORMANCE CALCULATION
// -----------------------------------------------------------------------------

/**
 * Calculates a "Perceived Performance Score" (0.0 - 1.0).
 * 
 * This uses the concept of "Perceived Performance" from the chapter.
 * We weigh "Time to Interactive" (TTI) and "Input Delay" higher than raw network
 * metrics (TTFB), as these directly impact the user's feeling of responsiveness.
 * 
 * @param metrics - Raw timing data
 * @returns A normalized score where 1.0 is instant.
 */
function calculatePerceivedScore(metrics: TelemetryPayload['metrics']): number {
  // Define ideal targets (in ms)
  const IDEAL_TTI = 2000;
  const IDEAL_INPUT_DELAY = 50;
  const IDEAL_FCP = 1000;

  // Normalize metrics to a 0-1 scale (inverted, so lower latency = higher score)
  const ttiScore = Math.max(0, 1 - (metrics.tti / IDEAL_TTI));
  const inputScore = Math.max(0, 1 - (metrics.inputDelay / IDEAL_INPUT_DELAY));
  const fcpScore = Math.max(0, 1 - (metrics.fcp / IDEAL_FCP));

  // Weighted average: User interaction (TTI + Input) matters more than visual load (FCP)
  return (ttiScore * 0.5 + inputScore * 0.3 + fcpScore * 0.2);
}

// -----------------------------------------------------------------------------
// 4. VECTORIZATION & STORAGE
// -----------------------------------------------------------------------------

/**
 * Converts the raw metrics into a vector embedding for pgvector storage.
 * 
 * The vector represents the "state" of the application performance in a 
 * multi-dimensional space. 
 * 
 * Vector Structure: [TTFB, FCP, TTI, InputDelay, PerceivedScore]
 * 
 * @param payload - The incoming request data
 * @param perceivedScore - The calculated user-centric score
 * @returns A Float32Array representing the vector
 */
function createPerformanceVector(metrics: TelemetryPayload['metrics'], perceivedScore: number): number[] {
  // Normalize raw values to keep vector magnitudes consistent (e.g., divide by 10000 for ms)
  // This prevents large values (like timestamp) from dominating the vector space.
  return [
    metrics.ttfb / 10000,
    metrics.fcp / 10000,
    metrics.tti / 10000,
    metrics.inputDelay / 10000,
    perceivedScore // Score is already normalized 0-1
  ];
}

/**
 * Inserts the processed metric into the Supabase database.
 * 
 * We use the `pgvector` extension to store the array as a vector type.
 */
async function storeMetric(data: StoredMetric) {
  const { error } = await supabase
    .from('performance_metrics')
    .insert({
      session_id: data.session_id,
      vector_embedding: `[${data.vector_embedding.join(',')}]`, // pgvector expects string syntax: "[1,2,3]"
      perceived_score: data.perceived_score
    });

  if (error) {
    console.error('Database Storage Error:', error);
    throw new Error('Failed to store performance vector.');
  }
}

// -----------------------------------------------------------------------------
// 5. ANOMALY DETECTION VIA SIMILARITY SEARCH
// -----------------------------------------------------------------------------

/**
 * Detects anomalies by comparing the current vector against historical data.
 * 
 * Logic:
 * 1. We query the database for the 5 nearest neighbors of the current vector.
 * 2. We calculate the average distance of these neighbors.
 * 3. If the average distance is high, the current state is an outlier (anomaly).
 * 
 * This is an "Unsupervised Anomaly Detection" approach using k-NN (k-Nearest Neighbors).
 * 
 * @param currentVector - The vector generated from the current request
 * @returns An object indicating if an anomaly was detected and the distance score
 */
async function detectAnomaly(currentVector: number[]) {
  // Convert array to pgvector string format for the query
  const vectorString = `[${currentVector.join(',')}]`;

  // Use the cosine distance operator (<->) provided by pgvector
  // We fetch the 5 closest historical records.
  const { data: neighbors, error } = await supabase.rpc('match_performance_metrics', {
    query_embedding: vectorString,
    match_threshold: 0.1, // Cosine distance threshold (0 = identical, 2 = opposite)
    match_count: 5
  });

  if (error) {
    console.error('Anomaly Detection Query Error:', error);
    return { isAnomaly: false, avgDistance: 0 };
  }

  if (!neighbors || neighbors.length === 0) {
    // No history exists, assume healthy for now
    return { isAnomaly: false, avgDistance: 0 };
  }

  // Calculate average distance from neighbors
  const totalDistance = neighbors.reduce((sum, n) => sum + n.distance, 0);
  const avgDistance = totalDistance / neighbors.length;

  // Define a threshold for anomaly (e.g., average distance > 0.3)
  // This threshold should be tuned based on historical data distribution.
  const ANOMALY_THRESHOLD = 0.3;

  return {
    isAnomaly: avgDistance > ANOMALY_THRESHOLD,
    avgDistance: avgDistance,
    neighborsCount: neighbors.length
  };
}

// -----------------------------------------------------------------------------
// 6. API HANDLER
// -----------------------------------------------------------------------------

/**
 * Main Next.js API Handler
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const payload: TelemetryPayload = req.body;

    // Step A: Load WASM Module for heavy lifting
    const wasmUtils = await loadWasmModule();

    // Step B: Calculate Perceived Performance Score
    // We use the WASM module here to calculate a geometric mean of latency 
    // components for a more robust baseline, though we use a weighted formula for the final score.
    const latencies = new Float64Array([
      payload.metrics.ttfb, 
      payload.metrics.fcp, 
      payload.metrics.tti
    ]);
    const baselineLatency = wasmUtils.calculateGeometricMean(latencies);
    
    const perceivedScore = calculatePerceivedScore(payload.metrics);

    // Step C: Create Vector Embedding
    const vector = createPerformanceVector(payload.metrics, perceivedScore);

    // Step D: Store Data (Async fire-and-forget to minimize client latency)
    // In a real high-volume app, this would be sent to a queue (e.g., Kafka) 
    // rather than awaiting the DB write here.
    await storeMetric({
      session_id: payload.sessionId,
      vector_embedding: vector,
      perceived_score: perceivedScore
    });

    // Step E: Detect Anomaly
    // Compare current vector against historical cluster
    const anomalyResult = await detectAnomaly(vector);

    // Step F: Return Response
    // If anomaly is detected, we might trigger an alert (e.g., Slack webhook, PagerDuty)
    // or flag this session for immediate review.
    const status = anomalyResult.isAnomaly ? 'warning' : 'healthy';

    return res.status(200).json({
      status: status,
      metrics: {
        perceivedScore: perceivedScore,
        baselineLatency: baselineLatency
      },
      analysis: {
        isAnomaly: anomalyResult.isAnomaly,
        distanceFromCluster: anomalyResult.avgDistance
      }
    });

  } catch (error) {
    console.error('Internal Server Error:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
