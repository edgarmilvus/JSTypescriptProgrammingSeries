/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Interface defining the structure of the telemetry data.
 */
interface TelemetryData {
  componentName: string;
  ttiDuration: number; // in milliseconds
  timestamp: string;   // ISO 8601
}

/**
 * Measures the time taken for a heavy rendering callback to complete.
 * 
 * @param componentName - The name of the component being measured.
 * @param renderCallback - An async function containing the heavy rendering logic.
 * @returns A promise resolving to TelemetryData.
 */
async function measureTTI(
  componentName: string, 
  renderCallback: () => Promise<void>
): Promise<TelemetryData> {
  // 1. Capture the start time using high-precision API
  const startTime = performance.now();

  // 2. Execute the heavy rendering logic
  // We wrap this in a try-catch to ensure we still capture timing even if the render fails,
  // though strictly speaking, a failed render might not constitute "Interactive".
  try {
    await renderCallback();
  } catch (error) {
    console.error(`Error rendering ${componentName}:`, error);
    // Re-throwing to allow calling code to handle the error if needed
    throw error;
  }

  // 3. Capture the end time
  const endTime = performance.now();

  // 4. Calculate duration
  const ttiDuration = endTime - startTime;

  // 5. Construct and return the telemetry object
  const telemetryData: TelemetryData = {
    componentName: componentName,
    ttiDuration: ttiDuration,
    timestamp: new Date().toISOString(),
  };

  return telemetryData;
}

// --- Demonstration Usage ---

// Hypothetical heavy component logic
const simulateHeavyRender = async (): Promise<void> => {
  // Simulate network fetch or complex computation
  await new Promise(resolve => setTimeout(resolve, 1500)); 
};

// Usage example
const logPerformance = async () => {
  try {
    const data = await measureTTI("HeavyProductList", simulateHeavyRender);
    console.log("Telemetry Data:", data);
    // In a real app, you would send 'data' to your backend service here
  } catch (e) {
    // Handle render errors
  }
};

// Run the demo
// logPerformance(); 
