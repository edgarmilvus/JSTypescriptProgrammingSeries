/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo } from 'react';

interface DataPoint {
  time: string;
  count: number;
}

interface ErrorRateMonitorProps {
  dataPoints: DataPoint[];
}

const ErrorRateMonitor: React.FC<ErrorRateMonitorProps> = ({ dataPoints }) => {
  // We use useMemo to avoid recalculating stats on every render unless data changes
  const { stats, anomalies } = useMemo(() => {
    if (dataPoints.length === 0) return { stats: null, anomalies: new Set<number>() };

    // 1. Calculate Mean
    const sum = dataPoints.reduce((acc, point) => acc + point.count, 0);
    const mean = sum / dataPoints.length;

    // 2. Calculate Standard Deviation
    const variance = dataPoints.reduce(
      (acc, point) => acc + Math.pow(point.count - mean, 2), 
      0
    ) / dataPoints.length;
    const stdDev = Math.sqrt(variance);

    // 3. Identify Anomalies (Mean + 2 * StdDev)
    const threshold = mean + 2 * stdDev;
    const anomalyIndices = new Set<number>();
    
    dataPoints.forEach((point, index) => {
      if (point.count > threshold) {
        anomalyIndices.add(index);
      }
    });

    return { stats: { mean, stdDev, threshold }, anomalies: anomalyIndices };
  }, [dataPoints]);

  // Visualization parameters
  const chartHeight = 100;
  const chartWidth = 400;
  const maxCount = Math.max(...dataPoints.map(d => d.count), 1); // Avoid division by zero

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h3>Error Rate Monitor</h3>
      <svg width={chartWidth} height={chartHeight} style={{ border: '1px solid #ccc', background: '#f9f9f9' }}>
        {dataPoints.map((point, index) => {
          const x = (index / (dataPoints.length - 1 || 1)) * chartWidth;
          const barHeight = (point.count / maxCount) * (chartHeight - 10);
          const isAnomaly = anomalies.has(index);
          
          return (
            <g key={index}>
              {/* Bar */}
              <rect
                x={x - (chartWidth / dataPoints.length) / 2}
                y={chartHeight - barHeight}
                width={Math.max(2, (chartWidth / dataPoints.length) - 2)}
                height={barHeight}
                fill={isAnomaly ? 'red' : '#4a90e2'}
                opacity={isAnomaly ? 1 : 0.8}
              />
              {/* Tooltip text (simplified) */}
              <title>{`${point.time}: ${point.count} errors`}</title>
            </g>
          );
        })}
        
        {/* Threshold Line (Visual Reference) */}
        {stats && (
          <line
            x1={0}
            y1={chartHeight - (stats.threshold / maxCount) * (chartHeight - 10)}
            x2={chartWidth}
            y2={chartHeight - (stats.threshold / maxCount) * (chartHeight - 10)}
            stroke="orange"
            strokeWidth="1"
            strokeDasharray="4"
            opacity="0.7"
          />
        )}
      </svg>
      <div style={{ fontSize: '0.8rem', marginTop: '8px', color: '#666' }}>
        {stats && `Current Threshold (Mean + 2σ): ${stats.threshold.toFixed(2)}`}
      </div>
    </div>
  );
};

export default ErrorRateMonitor;
