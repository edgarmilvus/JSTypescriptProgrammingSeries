/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

interface ModelMetadata {
  layerCount: number;
  parametersPerLayer: number;
  precision: 'FP32' | 'INT8';
}

interface QuantizationResult {
  estimatedSizeMB: number;
  speedupFactor: number;
}

function simulateQuantization(model: ModelMetadata): QuantizationResult {
  // 1. Calculate total number of parameters
  const totalParameters = model.layerCount * model.parametersPerLayer;

  // 2. Determine bits per parameter based on precision
  const bitsPerParameter = model.precision === 'FP32' ? 32 : 8;

  // 3. Calculate total bits
  const totalBits = totalParameters * bitsPerParameter;

  // 4. Convert bits to Bytes (1 byte = 8 bits), then to Megabytes (1 MB = 1024 * 1024 bytes)
  const totalBytes = totalBits / 8;
  const estimatedSizeMB = totalBytes / (1024 * 1024);

  // 5. Calculate speedup factor
  // Assumption: INT8 is 2x faster than FP32 on target hardware.
  // If the model is already FP32, the factor is 1.0 (no change).
  // If converting to INT8, the factor is 2.0.
  const speedupFactor = model.precision === 'INT8' ? 2.0 : 1.0;

  return {
    estimatedSizeMB,
    speedupFactor
  };
}

// --- Example Usage ---
// const fp32Model = { layerCount: 50, parametersPerLayer: 1000000, precision: 'FP32' as const };
// const result = simulateQuantization(fp32Model);
// console.log(result); 
