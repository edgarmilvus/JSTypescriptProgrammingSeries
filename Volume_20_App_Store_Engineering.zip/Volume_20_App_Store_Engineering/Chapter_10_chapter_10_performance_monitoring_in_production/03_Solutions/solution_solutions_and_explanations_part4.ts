/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface EmbeddingStrategy {
  modelName: string;
  dimensions: number;
  latencyPenalty: number;
}

type NetworkType = 'wifi' | 'cellular';

function selectEmbeddingStrategy(networkStatus: NetworkType): EmbeddingStrategy {
  // Logic: Switch based on network capability
  if (networkStatus === 'wifi') {
    // High bandwidth: Prioritize accuracy
    return {
      modelName: 'text-embedding-3-large',
      dimensions: 3072,
      latencyPenalty: 1.5 // Represents 1.5x slower than the small model
    };
  } else {
    // Low bandwidth: Prioritize speed and data transfer size
    return {
      modelName: 'text-embedding-3-small',
      dimensions: 1536,
      latencyPenalty: 1.0 // Baseline speed
    };
  }
}

// --- Scenario Simulation ---

/**
 * Simulates a session where network conditions change.
 * In a real application, this logic would likely be triggered by a 
 * network state listener (e.g., NetInfo from 'react-native-netinfo').
 */
function simulateSession() {
  // 1. Initial State: WiFi
  let currentStrategy = selectEmbeddingStrategy('wifi');
  console.log(`Session Start (WiFi): Using ${currentStrategy.modelName}`);

  // 2. Event: User moves out of WiFi range, switches to Cellular
  console.log("Network changed to Cellular...");
  
  // 3. Re-evaluation
  // We simply call the function again with the new status.
  // In a React context, this would update state, triggering a re-render or effect.
  currentStrategy = selectEmbeddingStrategy('cellular');
  console.log(`Session Update (Cellular): Switched to ${currentStrategy.modelName} to save bandwidth.`);
}

// simulateSession();
