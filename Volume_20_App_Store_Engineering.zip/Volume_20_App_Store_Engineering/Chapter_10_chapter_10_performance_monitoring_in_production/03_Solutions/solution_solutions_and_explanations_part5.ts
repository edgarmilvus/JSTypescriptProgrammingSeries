/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Hypothetical WASM exports interface
interface WasmExports {
  memory: WebAssembly.Memory;
  // Returns a pointer to the new image data in WASM memory
  resize_image(ptr: number, len: number, w: number, h: number): number; 
  // Other exports like free_memory might be needed depending on the WASM implementation
  free_image(ptr: number): void; 
}

/**
 * Wrapper function to process an image using a loaded WASM module.
 * 
 * Note: In a real app, 'wasmInstance' would be the result of WebAssembly.instantiateStreaming.
 * For this example, we assume it is passed or available globally.
 */
async function processImageWithWasm(
  imageData: Uint8Array, 
  dimensions: { width: number; height: number },
  wasmInstance: { exports: WasmExports }
): Promise<Uint8Array> {
  const { memory, resize_image, free_image } = wasmInstance.exports;

  // 1. Memory Management: Write JS data to WASM memory
  // We get a view into the WASM memory buffer
  const wasmMemoryBuffer = new Uint8Array(memory.buffer);
  
  // Allocate space in WASM memory. 
  // In a real scenario, you might need a malloc function exported from WASM.
  // Here we simulate writing directly to an available offset or assuming a pre-allocated buffer.
  // For simplicity, we assume we are writing to the start of memory or a known free region.
  const inputPointer = 0; // Hypothetical pointer to start of input buffer
  wasmMemoryBuffer.set(imageData, inputPointer);

  // 2. Call the WASM function
  // This executes the C/Rust code compiled to WASM
  const outputPointer = resize_image(
    inputPointer, 
    imageData.length, 
    dimensions.width, 
    dimensions.height
  );

  // 3. Retrieve the result
  // We need to know the size of the output image. 
  // Usually, the WASM module would provide a function to query this, 
  // or we calculate it based on target dimensions (e.g., width * height * 4 channels).
  const outputSize = dimensions.width * dimensions.height * 4; // Assuming RGBA
  const resizedImageData = new Uint8Array(memory.buffer, outputPointer, outputSize).slice();

  // 4. Clean up WASM memory to prevent leaks
  // We must free the memory allocated by the WASM function.
  if (free_image) {
    free_image(outputPointer);
  }
  // Note: If we used a specific allocator for the input, we'd free that too.

  return Promise.resolve(resizedImageData);
}
