/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Filename: generate-screenshots.ts
// Purpose: A simple script to compose AI-generated backgrounds with UI mockups
// and overlay localized text for App Store screenshots.

import sharp from 'sharp';

/**
 * Represents the configuration for a single screenshot generation task.
 * @typedef {Object} ScreenshotConfig
 * @property {string} bgPath - File path to the AI-generated background image.
 * @property {string} uiPath - File path to the actual app UI screenshot (with transparent background).
 * @property {string} outputPath - Path where the final screenshot will be saved.
 * @property {string} text - The main text to overlay (e.g., "Welcome").
 * @property {string} locale - The language code for the text (e.g., 'en', 'es').
 */
type ScreenshotConfig = {
    bgPath: string;
    uiPath: string;
    outputPath: string;
    text: string;
    locale: string;
};

/**
 * Core function to generate a single localized screenshot.
 * It composes the UI mockup over the background and overlays the localized text.
 *
 * @param {ScreenshotConfig} config - The configuration for the screenshot.
 * @returns {Promise<void>} A promise that resolves when the image is saved.
 */
async function generateScreenshot(config: ScreenshotConfig): Promise<void> {
    // --- 1. Load and Resize the Background Image ---
    // We use the 'sharp' library to handle image processing.
    // The background is loaded first and resized to a standard mobile screen dimension (e.g., 1242x2688 for iPhone 14 Pro Max).
    const background = sharp(config.bgPath).resize(1242, 2688, {
        fit: 'cover', // Ensure the background covers the entire area without distortion
        position: 'center',
    });

    // --- 2. Load and Resize the UI Mockup ---
    // The UI screenshot (which should ideally have a transparent background) is loaded.
    // We resize it to fit within the background, leaving some padding for a professional look.
    const uiElement = sharp(config.uiPath).resize(1100, 2400, {
        fit: 'contain', // 'contain' ensures the entire UI is visible without being cropped
        background: { r: 0, g: 0, b: 0, alpha: 0 }, // Explicitly set transparent background
    });

    // --- 3. Compose the Layers ---
    // We overlay the UI element onto the background.
    // The 'composite' method takes an array of overlay images.
    const composedImage = await background
        .composite([{ input: await uiElement.toBuffer() }])
        .toBuffer();

    // --- 4. Add Localized Text Overlay ---
    // Now we add the text on top of the composed image.
    // This is a simplified example. In a real-world scenario, you would use a more sophisticated
    // text layout engine, but this demonstrates the core concept.
    const finalImage = sharp(composedImage)
        .composite([
            {
                input: Buffer.from(
                    `<svg width="1242" height="2688">
                        <style>
                            .text { font-family: 'Helvetica Neue', sans-serif; font-size: 80px; fill: white; font-weight: bold; text-anchor: middle; }
                        </style>
                        <text x="621" y="2500" class="text">${config.text}</text>
                    </svg>`
                ),
                gravity: 'north', // Position the text relative to the image
            },
        ]);

    // --- 5. Save the Final Output ---
    // The final image is saved to the specified output path.
    await finalImage.toFile(config.outputPath);
    console.log(`✅ Screenshot generated for locale '${config.locale}': ${config.outputPath}`);
}

/**
 * Main execution function.
 * Defines the tasks for generating screenshots in different languages.
 */
async function main() {
    // In a real application, these paths would point to actual files.
    // For this example, we'll use placeholder paths.
    const BG_PATH = './assets/ai_background.png';
    const UI_PATH = './assets/app_ui_mockup.png';

    // Define the list of screenshots to generate.
    // This demonstrates localization: English and Spanish.
    const tasks: ScreenshotConfig[] = [
        {
            bgPath: BG_PATH,
            uiPath: UI_PATH,
            outputPath: './output/screenshot_en.png',
            text: 'Welcome to My App',
            locale: 'en',
        },
        {
            bgPath: BG_PATH,
            uiPath: UI_PATH,
            outputPath: './output/screenshot_es.png',
            text: 'Bienvenido a Mi App',
            locale: 'es',
        },
    ];

    console.log('🚀 Starting screenshot generation process...');

    // Process all tasks in parallel for efficiency.
    // Using Promise.all allows us to generate multiple screenshots simultaneously,
    // which is crucial for CI/CD pipelines where speed is important.
    await Promise.all(tasks.map(task => generateScreenshot(task)));

    console.log('✨ All screenshots generated successfully!');
}

// Execute the main function and handle any potential errors.
main().catch(error => {
    console.error('❌ Error during screenshot generation:', error);
    process.exit(1);
});
