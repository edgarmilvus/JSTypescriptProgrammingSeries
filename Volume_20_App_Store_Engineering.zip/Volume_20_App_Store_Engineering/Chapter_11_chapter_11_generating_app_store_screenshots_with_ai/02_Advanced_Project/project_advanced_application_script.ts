/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/generate-screenshot.ts
// Next.js API Route for generating App Store screenshots.

import type { NextApiRequest, NextApiResponse } from 'next';
import { generateText } from 'ai'; // Vercel AI SDK
import { openai } from '@ai-sdk/openai'; // Requires @ai-sdk/openai package
import sharp from 'sharp';
import axios from 'axios';

// --- Type Definitions ---

type ScreenshotRequest = {
  appName: string;
  featureDescription: string;
  primaryColor: string; // Hex code (e.g., #FF5733)
  locale: string; // e.g., 'en-US', 'ja-JP'
  deviceFrameUrl: string; // URL to a transparent PNG of the device frame
  appUiBase64: string; // Base64 encoded string of the actual app UI screenshot
};

type ScreenshotResponse = {
  imageUrl: string;
};

/**
 * API Handler: POST /api/generate-screenshot
 * Orchestrates the AI image generation and image composition pipeline.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ScreenshotResponse | { error: string }>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      appName,
      featureDescription,
      primaryColor,
      locale,
      deviceFrameUrl,
      appUiBase64,
    } = req.body as ScreenshotRequest;

    // --- Step 1: Generate Background Description using LLM ---
    // We use 'useCompletion' logic here via the SDK to generate a descriptive prompt
    // for the image generation model. This ensures the background matches the feature.
    const backgroundPrompt = await generateText({
      model: openai('gpt-4-turbo'),
      prompt: `Describe a high-quality, minimalist background image for a mobile app screenshot.
               App Name: ${appName}
               Feature: ${featureDescription}
               Style: Modern, clean, abstract.
               Color Influence: Use accents of ${primaryColor}.
               Output only the visual description.`,
    });

    // --- Step 2: Generate Image using DALL-E 3 ---
    // In a real scenario, you would use an image generation SDK here.
    // For this script, we simulate the response with a placeholder fetch.
    // const imageResponse = await openai.images.generate({ ... });
    const generatedBackgroundUrl = await simulateAiImageGeneration(
      backgroundPrompt.text
    );

    // --- Step 3: Composition using Sharp ---
    // Fetch the generated background and device frame.
    const [backgroundBuffer, frameBuffer] = await Promise.all([
      axios.get(generatedBackgroundUrl, { responseType: 'arraybuffer' }),
      axios.get(deviceFrameUrl, { responseType: 'arraybuffer' }),
    ]);

    // Convert App UI Base64 to Buffer
    const uiBuffer = Buffer.from(appUiBase64, 'base64');

    // Define localized text based on locale (simplified mapping)
    const localizedText = getLocalizedText(locale, appName);

    // Compose the final image
    const finalImageBuffer = await sharp(backgroundBuffer.data)
      .resize(1290, 2796) // iPhone 15 Pro Max dimensions
      .composite([
        {
          input: frameBuffer.data, // Overlay Device Frame
          top: 100,
          left: 100,
          blend: 'over',
        },
        {
          input: uiBuffer, // Overlay Actual App UI
          top: 300, // Adjust based on device frame mask
          left: 120,
          blend: 'over',
        },
        {
          input: Buffer.from(
            `<svg width="1290" height="2796">
               <text x="50%" y="90%" text-anchor="middle" font-family="sans-serif" font-size="80" fill="white" font-weight="bold">
                 ${localizedText}
               </text>
             </svg>`
          ),
          blend: 'over',
        },
      ])
      .png()
      .toBuffer();

    // --- Step 4: Upload to Storage (Simulated) ---
    // In production, upload finalImageBuffer to S3, Cloudinary, or Vercel Blob.
    // Returning base64 for demonstration purposes.
    const base64Image = finalImageBuffer.toString('base64');
    const dataUri = `data:image/png;base64,${base64Image}`;

    res.status(200).json({ imageUrl: dataUri });
  } catch (error) {
    console.error('Screenshot generation failed:', error);
    res.status(500).json({ error: 'Failed to generate screenshot' });
  }
}

// --- Helper Functions ---

/**
 * Simulates an AI Image Generation call.
 * Replace this with actual calls to DALL-E 3 or Stable Diffusion API.
 */
async function simulateAiImageGeneration(prompt: string): Promise<string> {
  // In a real app, this returns a URL from the AI provider.
  // Here we return a placeholder image service for demonstration.
  const encodedPrompt = encodeURIComponent(prompt);
  return `https://placehold.co/1290x2796/1a1a1a/FFF?text=${encodedPrompt}`;
}

/**
 * Returns localized text strings based on the locale code.
 */
function getLocalizedText(locale: string, appName: string): string {
  const texts: Record<string, string> = {
    'en-US': `Discover ${appName} Pro`,
    'ja-JP': `${appName} Pro を発見`,
    'es-ES': `Descubre ${appName} Pro`,
    'de-DE': `Entdecken Sie ${appName} Pro`,
  };
  return texts[locale] || texts['en-US'];
}
