/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Defines the structure for brand guidelines to be used in prompt generation.
 */
export interface BrandGuidelines {
    /** An array of hex color codes representing the brand's palette. */
    colorPalette: string[];
    /** A descriptive term for the overall visual style (e.g., 'minimalist', 'vibrant'). */
    style: string;
    /** Visual motifs or elements that should be recurring in the imagery. */
    keyElements: string[];
    /** Elements that must be explicitly avoided in the generated image. */
    avoid: string[];
}

/**
 * Generates a comprehensive prompt string for an AI image generation service.
 * 
 * @param guidelines - The brand guidelines object containing style, colors, and elements.
 * @param sceneDescription - A textual description of the specific app screen scene.
 * @returns A fully constructed, detailed prompt string.
 */
export function generateBrandPrompt(guidelines: BrandGuidelines, sceneDescription: string): string {
    // Start with a strong, directive opening sentence.
    let prompt = "Create a high-fidelity, photorealistic or 3D render background for a mobile app screenshot. ";

    // Integrate the specific scene description.
    prompt += `The scene depicts: ${sceneDescription}. `;

    // Add brand-specific stylistic instructions.
    prompt += `The image should be rendered in a ${guidelines.style} style. `;
    
    // Incorporate the color palette.
    if (guidelines.colorPalette.length > 0) {
        const colors = guidelines.colorPalette.join(', ');
        prompt += `Use a color palette consisting of ${colors}. `;
    }

    // Add key visual elements.
    if (guidelines.keyElements.length > 0) {
        const elements = guidelines.keyElements.join(', ');
        prompt += `Incorporate visual elements such as ${elements}. `;
    }

    // Add exclusion criteria.
    if (guidelines.avoid.length > 0) {
        const excludedItems = guidelines.avoid.join(', ');
        prompt += `Ensure the image contains no ${excludedItems}. `;
    }

    // Final instruction for composition readiness.
    prompt += "The composition should leave ample negative space for overlaying UI elements.";

    return prompt;
}

// Example Usage:
const myBrand: BrandGuidelines = {
    colorPalette: ['#4A90E2', '#F5F5F5', '#333333'],
    style: 'minimalist',
    keyElements: ['subtle gradients', 'clean lines'],
    avoid: ['text', 'human faces', 'busy patterns']
};

const scene = "A user viewing their profile settings";
const finalPrompt = generateBrandPrompt(myBrand, scene);
console.log(finalPrompt);
