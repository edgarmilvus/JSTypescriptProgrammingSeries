/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// Defines the structure for the overlay positioning configuration.
interface OverlayConfig {
    top: number;  // percentage
    left: number; // percentage
    width: number; // percentage
    height: number; // percentage
}

// Defines the props for the ScreenshotComposer component.
interface ScreenshotComposerProps {
    backgroundImageUrl: string;
    uiMockupUrl: string;
    overlayConfig: OverlayConfig;
    localizationText?: string;
}

/**
 * A React component that composes a final screenshot by layering a UI mockup
 * and optional text over a background image.
 */
export const ScreenshotComposer: React.FC<ScreenshotComposerProps> = ({
    backgroundImageUrl,
    uiMockupUrl,
    overlayConfig,
    localizationText,
}) => {
    // Main container style: relative positioning is essential for layering children.
    const containerStyle: React.CSSProperties = {
        position: 'relative',
        width: '100%',
        maxWidth: '400px', // Typical mobile screen width constraint
        aspectRatio: '9/19.5', // Common mobile aspect ratio
        overflow: 'hidden',
        border: '1px solid #ccc', // For visualization in the dev environment
        backgroundImage: `url(${backgroundImageUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    };

    // UI Mockup style: absolute positioning based on percentage props.
    const mockupStyle: React.CSSProperties = {
        position: 'absolute',
        top: `${overlayConfig.top}%`,
        left: `${overlayConfig.left}%`,
        width: `${overlayConfig.width}%`,
        height: `${overlayConfig.height}%`,
        objectFit: 'contain', // Ensures the mockup is fully visible without distortion
    };

    // Localization text style: absolute positioning with a default top-center placement.
    const textStyle: React.CSSProperties = {
        position: 'absolute',
        top: '5%', // Default position
        left: '50%',
        transform: 'translateX(-50%)',
        color: 'white',
        fontSize: '1.5rem',
        fontWeight: 'bold',
        textShadow: '2px 2px 4px rgba(0,0,0,0.7)',
        zIndex: 10, // Ensure text is above the mockup if needed
        textAlign: 'center',
        padding: '0 10px',
    };

    return (
        <div style={containerStyle}>
            {/* The UI mockup is rendered as an img tag on top of the background */}
            <img 
                src={uiMockupUrl} 
                alt="UI Mockup" 
                style={mockupStyle} 
            />
            
            {/* Conditionally render the localization text if provided */}
            {localizationText && (
                <div style={textStyle}>
                    {localizationText}
                </div>
            )}
        </div>
    );
};
