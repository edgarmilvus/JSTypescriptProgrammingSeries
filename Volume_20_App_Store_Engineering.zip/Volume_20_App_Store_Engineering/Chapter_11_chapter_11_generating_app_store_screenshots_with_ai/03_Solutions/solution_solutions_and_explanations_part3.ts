/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import sharp from 'sharp';
import * as fs from 'fs/promises';
import * as path from 'path';

// Defines the options for text styling.
interface TextOptions {
    fontSize: number;
    fontColor: string; // e.g., '#FFFFFF'
    x: number; // X coordinate in pixels
    y: number; // Y coordinate in pixels
    fontFamily: string; // e.g., 'Arial'
}

/**
 * Overlays text onto an image and saves the result.
 * This function is designed for use in a CI/CD pipeline for localization.
 *
 * @param inputImagePath - Path to the source image.
 * @param outputImagePath - Path where the new image will be saved.
 * @param text - The string to overlay.
 * @param textOptions - Styling and positioning options for the text.
 */
export async function addLocalizedTextToImage(
    inputImagePath: string,
    outputImagePath: string,
    text: string,
    textOptions: TextOptions
): Promise<void> {
    try {
        // Step 1: Check if the input file exists before processing.
        await fs.access(inputImagePath);
        
        // Step 2: Use sharp to load the image, composite the text, and save to the output path.
        await sharp(inputImagePath)
            .composite([
                {
                    input: Buffer.from(
                        `<svg width="500" height="100">
                            <style>
                                .text { 
                                    font-family: ${textOptions.fontFamily}; 
                                    font-size: ${textOptions.fontSize}px; 
                                    fill: ${textOptions.fontColor}; 
                                    font-weight: bold;
                                }
                            </style>
                            <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" class="text">${text}</text>
                        </svg>`
                    ),
                    // Position the SVG overlay. Here we center it based on provided x/y.
                    // For simplicity, this example centers the text block at (x,y).
                    top: textOptions.y,
                    left: textOptions.x,
                },
            ])
            .toFile(outputImagePath);

        console.log(`Successfully created localized screenshot: ${outputImagePath}`);

    } catch (error) {
        if (error.code === 'ENOENT') {
            console.error(`Error: Input file not found at ${inputImagePath}`);
        } else {
            console.error(`An error occurred during image processing:`, error);
        }
        // Re-throw the error to be handled by the calling pipeline function.
        throw error;
    }
}

// Example usage within an async context:
// await addLocalizedTextToImage(
//     './dist/composed-base.png',
//     './dist/screenshots/es/account_balance_es.png',
//     'Saldo de la cuenta',
//     { fontSize: 40, fontColor: '#FFFFFF', x: 50, y: 50, fontFamily: 'Arial' }
// );
