/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs/promises';
import * as path from 'path';

// --- Data Structure Interfaces ---

interface AppFeature {
    name: string;           // e.g., 'account-balance'
    sceneDescription: string; // e.g., 'A user checking their account balance'
}

interface Localization {
    languageCode: string;   // e.g., 'es'
    translatedText: string; // e.g., 'Saldo de la cuenta'
}

// --- Mock Functions (as per requirements) ---

/**
 * Mock function to simulate AI background generation.
 * In a real scenario, this would call an AI API.
 */
async function generateBackground(sceneDescription: string): Promise<string> {
    console.log(`[MOCK] Generating AI background for scene: "${sceneDescription}"...`);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    const mockFilePath = `./temp/background_${sceneDescription.replace(/\s+/g, '_')}.png`;
    console.log(`[MOCK] Background generated and saved to: ${mockFilePath}`);
    return mockFilePath;
}

/**
 * Mock function to simulate UI composition.
 * In a real scenario, this would overlay a UI mockup image.
 */
async function composeScreenshot(backgroundPath: string, featureName: string): Promise<string> {
    console.log(`[MOCK] Composing UI mockup onto background: ${backgroundPath}...`);
    await new Promise(resolve => setTimeout(resolve, 300));
    const composedPath = `./temp/composed_${featureName}.png`;
    console.log(`[MOCK] Composition complete. Base screenshot saved to: ${composedPath}`);
    return composedPath;
}

/**
 * The function from Exercise 3. Included here for completeness.
 * (Assuming it's imported in a real project)
 */
async function addLocalizedTextToImage(
    inputPath: string, outputPath: string, text: string, options: any
): Promise<void> {
    console.log(`[MOCK] Adding localized text "${text}" to ${inputPath}...`);
    await new Promise(resolve => setTimeout(resolve, 200));
    console.log(`[MOCK] Localized screenshot saved to: ${outputPath}`);
}

// --- Main Orchestrator Function ---

/**
 * Orchestrates the entire screenshot generation pipeline for a CI/CD environment.
 *
 * @param features - A list of app features to generate screenshots for.
 * @param localizations - A list of languages to generate screenshots in.
 */
export async function runScreenshotPipeline(
    features: AppFeature[],
    localizations: Localization[]
): Promise<void> {
    console.log('--- Starting Screenshot Generation Pipeline ---');

    // Ensure output directories exist
    const baseOutputDir = './dist/screenshots';
    await fs.mkdir(baseOutputDir, { recursive: true });

    for (const feature of features) {
        console.log(`\nProcessing Feature: ${feature.name}`);

        // Step 1: Generate Background
        const backgroundPath = await generateBackground(feature.sceneDescription);

        // Step 2: Compose Screenshot
        const baseScreenshotPath = await composeScreenshot(backgroundPath, feature.name);

        // Step 3: Localization Loop
        for (const localization of localizations) {
            console.log(`\nLocalizing for language: ${localization.languageCode}`);
            
            // Define the final output path
            const langDir = path.join(baseOutputDir, localization.languageCode);
            await fs.mkdir(langDir, { recursive: true }); // Ensure language directory exists
            const finalScreenshotPath = path.join(langDir, `${feature.name}.png`);

            // Call the localization function (from Exercise 3)
            await addLocalizedTextToImage(
                baseScreenshotPath,
                finalScreenshotPath,
                localization.translatedText,
                { fontSize: 40, fontColor: '#FFFFFF', x: 100, y: 100, fontFamily: 'Arial' }
            );
        }
    }

    console.log('\n--- Pipeline Execution Complete ---');
    console.log(`All assets organized in ${baseOutputDir}`);
}

// --- Example Execution ---
// To run this, you would call the function with your configuration.
/*
const myFeatures: AppFeature[] = [
    { name: 'account-balance', sceneDescription: 'A user checking their account balance' },
    { name: 'transfer-money', sceneDescription: 'A user initiating a money transfer' }
];

const myLocalizations: Localization[] = [
    { languageCode: 'en', translatedText: 'Account Balance' },
    { languageCode: 'es', translatedText: 'Saldo de la Cuenta' },
    { languageCode: 'fr', translatedText: 'Solde du Compte' }
];

runScreenshotPipeline(myFeatures, myLocalizations).catch(console.error);
*/
