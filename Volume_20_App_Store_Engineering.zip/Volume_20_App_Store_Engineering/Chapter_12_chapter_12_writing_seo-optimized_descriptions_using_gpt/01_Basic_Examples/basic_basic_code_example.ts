/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A self-contained TypeScript example demonstrating how to generate
 * SEO-optimized app store descriptions using GPT. This simulates a SaaS backend service.
 * 
 * Dependencies: None (simulated LLM response).
 * Runtime: Node.js (with ts-node or compiled JS).
 */

// --- Type Definitions ---

/**
 * Represents the input data required to generate an app description.
 */
interface AppDescriptionRequest {
  productName: string;
  targetAudience: string;
  keyFeatures: string[];
  seoKeywords: string[]; // High-volume ASO keywords
  brandVoice: 'professional' | 'playful' | 'technical';
}

/**
 * Represents the structure of the simulated LLM response.
 */
interface LLMResponse {
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
  };
}

// --- Configuration ---

/**
 * Simulated database or configuration for brand voice guidelines.
 * In a real app, this might come from a CMS or user settings.
 */
const BRAND_VOICE_TEMPLATES = {
  professional: "Use formal language, focus on efficiency and reliability.",
  playful: "Use energetic language, focus on fun and engagement.",
  technical: "Use precise terminology, focus on specs and performance.",
};

// --- Core Logic ---

/**
 * Simulates the OpenAI ChatCompletion API.
 * In a real scenario, you would use the 'openai' npm package.
 * 
 * @param prompt - The engineered prompt string sent to the LLM.
 * @returns A promise resolving to a simulated LLMResponse.
 */
async function callSimulatedGPT(prompt: string): Promise<LLMResponse> {
  console.log("🚀 [System] Sending prompt to LLM...");
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 500));

  // Simulate a hallucinated response based on the prompt context
  // In a real app, the LLM generates this dynamically.
  const simulatedContent = `
  **App Store Description**

  ${prompt.includes('professional') ? "Maximize your productivity with" : "Unleash your potential with"} ${'Product Name Placeholder'}, the ultimate solution for ${'Target Audience Placeholder'}.

  **Key Features:**
  - Feature 1
  - Feature 2
  - Feature 3

  Download now and experience the difference!
  `;

  return {
    content: simulatedContent,
    usage: {
      promptTokens: 150,
      completionTokens: 80,
    },
  };
}

/**
 * Constructs a detailed prompt for the LLM based on user input and SEO requirements.
 * This is the "Prompt Engineering" step.
 * 
 * @param request - The input data object.
 * @returns A fully formatted string prompt.
 */
function constructPrompt(request: AppDescriptionRequest): string {
  const voiceInstruction = BRAND_VOICE_TEMPLATES[request.brandVoice];
  
  // We inject keywords directly into the system instruction to guide the LLM.
  // We also ask the LLM to naturally integrate these keywords.
  const keywordList = request.seoKeywords.join(', ');

  const systemPrompt = `
  You are an expert ASO (App Store Optimization) copywriter. 
  Your task is to write a high-converting app store description.
  
  **Brand Voice Guidelines:** ${voiceInstruction}
  
  **Mandatory SEO Keywords (Must Include):** ${keywordList}
  
  **Instructions:**
  1. Start with a catchy hook.
  2. Describe the app for the target audience: "${request.targetAudience}".
  3. List the key features: ${request.keyFeatures.join(', ')}.
  4. Ensure the keywords are integrated naturally, not just listed.
  5. End with a strong Call to Action (CTA).
  `;

  return systemPrompt;
}

/**
 * Main function to orchestrate the description generation.
 * 
 * @param request - The data required for the description.
 * @returns The final SEO-optimized description string.
 */
async function generateAppDescription(request: AppDescriptionRequest): Promise<string> {
  // 1. Construct the prompt
  const prompt = constructPrompt(request);
  
  // 2. Call the LLM
  const response = await callSimulatedGPT(prompt);
  
  // 3. Post-process (Optional: In a real app, you might validate length or keyword presence here)
  return response.content.trim();
}

// --- Execution Block (Self-Contained Demo) ---

/**
 * Entry point for the script.
 */
async function main() {
  console.log("--- App Store Description Generator ---");

  const inputData: AppDescriptionRequest = {
    productName: "FocusFlow",
    targetAudience: "remote workers and students",
    keyFeatures: ["Pomodoro Timer", "Distraction Blocker", "Analytics Dashboard"],
    seoKeywords: ["productivity", "focus", "time management", "study timer"],
    brandVoice: "professional",
  };

  try {
    const description = await generateAppDescription(inputData);
    
    console.log("\n✅ [Result] Generated Description:\n");
    console.log(description);
    console.log("\n----------------------------------------");
    
  } catch (error) {
    console.error("❌ [Error] Failed to generate description:", error);
  }
}

// Run the main function
if (require.main === module) {
  main();
}
