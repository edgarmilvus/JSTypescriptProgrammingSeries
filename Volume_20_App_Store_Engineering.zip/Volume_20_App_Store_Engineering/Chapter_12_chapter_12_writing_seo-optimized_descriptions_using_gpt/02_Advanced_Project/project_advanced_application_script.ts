/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: app/api/generate-description/route.ts
 * FRAMEWORK: Next.js 14+ (App Router)
 * PURPOSE: SaaS endpoint for generating SEO-optimized App Store descriptions
 *          using RAG (Retrieval-Augmented Generation) with GPT-4 and Pinecone.
 */

import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import { Pinecone } from '@pinecone-database/pinecone';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

// Environment variable validation (Best Practice for production apps)
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const PINECONE_API_KEY = process.env.PINECONE_API_KEY;
const PINECONE_INDEX_NAME = process.env.PINECONE_INDEX_NAME || 'aso-keywords';

if (!OPENAI_API_KEY || !PINECONE_API_KEY) {
  throw new Error('Missing required API keys in environment variables.');
}

// Define strict typing for the incoming request payload
interface GenerationRequest {
  appName: string;
  appCategory: string;
  targetAudience: string;
  coreFeatures: string[];
  primaryLanguage: string; // e.g., 'en', 'es', 'jp'
}

// Initialize clients
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
const pinecone = new Pinecone({ apiKey: PINECONE_API_KEY });

// -----------------------------------------------------------------------------
// 2. VECTOR INDEX INTEGRATION (RAG)
// -----------------------------------------------------------------------------

/**
 * Queries the Pinecone Vector Index to retrieve high-volume ASO keywords
 * relevant to the app's category.
 * 
 * UNDER THE HOOD:
 * 1. Converts the category string into a vector embedding using OpenAI.
 * 2. Performs a similarity search against the Pinecone index.
 * 3. Returns the top-k most relevant keywords to inject into the context.
 * 
 * @param category - The app category (e.g., "Fitness Tracker")
 * @returns A comma-separated string of high-value keywords
 */
async function retrieveRelevantKeywords(category: string): Promise<string> {
  try {
    // 1. Embed the query (Category) into a vector
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: `High volume keywords for ${category} apps`,
    });
    const queryVector = embeddingResponse.data[0].embedding;

    // 2. Query the Vector Index
    const index = pinecone.Index(PINECONE_INDEX_NAME);
    const queryResult = await index.query({
      vector: queryVector,
      topK: 5, // Retrieve top 5 most relevant keywords
      includeMetadata: true,
    });

    // 3. Format results
    if (!queryResult.matches || queryResult.matches.length === 0) {
      return ''; // Fallback if no keywords found
    }

    // Extract keywords from metadata
    const keywords = queryResult.matches
      .map((match) => match.metadata?.keyword)
      .filter(Boolean)
      .join(', ');

    return keywords;
  } catch (error) {
    console.error('Error retrieving from Vector Index:', error);
    // Fail gracefully; return empty string so generation continues without RAG
    return '';
  }
}

// -----------------------------------------------------------------------------
// 3. PROMPT ENGINEERING & GPT INTEGRATION
// -----------------------------------------------------------------------------

/**
 * Constructs a detailed system prompt and generates the description via GPT-4.
 * 
 * CRITICAL ASPECT: The prompt enforces brand voice and integrates the 
 * retrieved keywords naturally, avoiding "keyword stuffing" which penalizes rankings.
 * 
 * @param request - The user input data
 * @param retrievedKeywords - Keywords from the Vector Index
 * @returns The generated SEO description
 */
async function generateDescription(
  request: GenerationRequest,
  retrievedKeywords: string
): Promise<string> {
  const { appName, appCategory, targetAudience, coreFeatures, primaryLanguage } = request;

  // Construct the System Prompt with dynamic context
  const systemPrompt = `
    You are an expert ASO (App Store Optimization) specialist and copywriter.
    Your task is to write a high-converting, SEO-optimized description for an app.
    
    **Constraints:**
    1. Language: ${primaryLanguage}.
    2. Tone: Professional, engaging, and trustworthy.
    3. Structure: 
       - Start with a catchy hook (max 2 sentences).
       - List core features using bullet points.
       - End with a strong Call to Action (CTA).
    4. SEO Integration: You MUST seamlessly integrate the following high-volume keywords: 
       "${retrievedKeywords}".
       *Do not list them mechanically. Weave them naturally into the narrative.*

    **App Context:**
    - Name: ${appName}
    - Category: ${appCategory}
    - Target Audience: ${targetAudience}
    - Core Features: ${coreFeatures.join(', ')}
  `;

  const userPrompt = `Generate the App Store description for ${appName}.`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.7, // Balance creativity and determinism
      max_tokens: 600,  // Limit for app store description length
    });

    return completion.choices[0].message.content || 'Generation failed.';
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to generate description via GPT.');
  }
}

// -----------------------------------------------------------------------------
// 4. NEXT.JS API ROUTE HANDLER
// -----------------------------------------------------------------------------

/**
 * POST /api/generate-description
 * 
 * Entry point for the SaaS feature.
 * 1. Validates input.
 * 2. Performs Vector Search (RAG).
 * 3. Generates LLM output.
 * 4. Returns JSON response.
 */
export async function POST(req: Request) {
  try {
    // Parse and validate request body
    const body = await req.json() as GenerationRequest;
    
    if (!body.appName || !body.appCategory) {
      return NextResponse.json(
        { error: 'Missing required fields: appName, appCategory' },
        { status: 400 }
      );
    }

    // Step 1: Retrieve context from Vector Index
    // This mimics the "Advanced Application Script" requirement where
    // local/compute-optimized data structures inform the LLM.
    const keywords = await retrieveRelevantKeywords(body.appCategory);

    // Step 2: Generate content using GPT
    const description = await generateDescription(body, keywords);

    // Step 3: Return the result
    return NextResponse.json({
      success: true,
      data: {
        description,
        // For debugging/demo purposes, return the injected keywords
        injectedKeywords: keywords,
      },
    });

  } catch (error) {
    console.error('Route Handler Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
