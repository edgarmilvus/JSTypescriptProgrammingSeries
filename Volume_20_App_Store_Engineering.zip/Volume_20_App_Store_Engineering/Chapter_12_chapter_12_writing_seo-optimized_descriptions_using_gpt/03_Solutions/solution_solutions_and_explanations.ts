/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Defines the structure for a brand persona.
 */
interface BrandPersona {
  targetAudience: string;
  tone: string;
  keyAdjectives: string[];
  wordsToAvoid: string[];
  readingLevel: string;
}

/**
 * A dictionary mapping voice keys to their detailed persona definitions.
 */
const brandPersonas: Record<'playful' | 'professional' | 'zen', BrandPersona> = {
  playful: {
    targetAudience: "Gamers, students, and casual users looking for fun.",
    tone: "Energetic, humorous, informal, and exciting.",
    keyAdjectives: ["fun", "addictive", "awesome", "chill", "epic", "vibrant"],
    wordsToAvoid: ["enterprise", "secure", "robust", "efficient", "utilize", "optimize"],
    readingLevel: "Grade 6 (Casual and easy to read)"
  },
  professional: {
    targetAudience: "Business professionals, productivity seekers, and enterprise clients.",
    tone: "Formal, trustworthy, concise, and results-oriented.",
    keyAdjectives: ["secure", "reliable", "efficient", "powerful", "seamless", "integrated"],
    wordsToAvoid: ["fun", "awesome", "chill", "epic", "vibrant", "hype"],
    readingLevel: "Grade 10 (Clear and professional)"
  },
  zen: {
    targetAudience: "Mindfulness enthusiasts, minimalists, and users seeking calm.",
    tone: "Serene, minimalist, soothing, and focused.",
    keyAdjectives: ["calm", "peaceful", "minimal", "focused", "balance", "clarity"],
    wordsToAvoid: ["loud", "hype", "fast", "powerful", "busy", "complex"],
    readingLevel: "Grade 8 (Simple and flowing)"
  }
};

/**
 * Generates a detailed prompt for an LLM to create an app description
 * based on specific features and a chosen brand voice.
 *
 * @param appFeatures - An array of strings describing the app's core features.
 * @param brandVoice - The target brand voice ('playful', 'professional', or 'zen').
 * @returns A meticulously crafted string prompt.
 */
export function generateBrandPrompt(appFeatures: string[], brandVoice: 'playful' | 'professional' | 'zen'): string {
  const persona = brandPersonas[brandVoice];
  const featuresList = appFeatures.map(f => `- ${f}`).join('\n');

  return `
You are an expert copywriter specializing in App Store Optimization (ASO). Your task is to write a compelling app description that strictly adheres to the following brand persona.

**Brand Persona: ${brandVoice.toUpperCase()}**
- **Target Audience:** ${persona.targetAudience}
- **Tone:** ${persona.tone}
- **Key Adjectives to Use:** ${persona.keyAdjectives.join(', ')}
- **Strictly Forbidden Words:** ${persona.wordsToAvoid.join(', ')}
- **Target Reading Level:** ${persona.readingLevel}

**App Features to Include:**
${featuresList}

**Instructions:**
1. Adopt the persona defined above. Do not deviate from the tone or vocabulary.
2. Integrate the provided app features naturally into the narrative. Do not just list them.
3. Ensure the description is engaging and persuasive for the target audience.
4. **Strictly avoid** using any of the forbidden words. If a feature concept conflicts with the persona, rephrase it to fit (e.g., for "Zen," describe "offline access" as "digital detox mode" or "uninterrupted focus").
5. Structure the output exactly as follows:
   - **Title:** A catchy, persona-appropriate title (max 30 characters).
   - **Paragraph 1:** An engaging hook that introduces the app's main value proposition.
   - **Paragraph 2:** A deeper dive into the key features, weaving in the provided list naturally.

**Output:**
Generate only the description text. Do not include any introductory phrases like "Here is the description" or markdown formatting like ###.
`;
}

// --- Interactive Challenge Script (Conceptual) ---
/*
To test this, you would use a Node.js script with an LLM SDK (e.g., OpenAI).

import OpenAI from 'openai';
const openai = new OpenAI();

async function testPrompt() {
  const appFeatures = ['dark mode', 'offline access', 'collaborative editing'];
  
  // Test 1: Professional Voice
  const professionalPrompt = generateBrandPrompt(appFeatures, 'professional');
  const proCompletion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: professionalPrompt }],
  });
  console.log("--- PROFESSIONAL OUTPUT ---");
  console.log(proCompletion.choices[0].message.content);

  // Test 2: Playful Voice
  const playfulPrompt = generateBrandPrompt(appFeatures, 'playful');
  const playCompletion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: playfulPrompt }],
  });
  console.log("\n--- PLAYFUL OUTPUT ---");
  console.log(playCompletion.choices[0].message.content);
}

// testPrompt();
*/
