/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// AsoDescriptionGenerator.tsx
import { useState } from 'react';
import { useCompletion } from 'ai/react';

export default function AsoDescriptionGenerator() {
  // 1. State Management
  const [rawDescription, setRawDescription] = useState<string>('');
  const [keywords, setKeywords] = useState<string>('');

  // 2. Initialize the useCompletion hook
  // This hook handles the API call to our backend (e.g., /api/generate-aso-description)
  // It manages loading states, errors, and the generated text stream.
  const { completion, input, isLoading, error, complete, setInput } = useCompletion({
    api: '/api/generate-aso-description',
  });

  // 3. Prompt Builder Function
  const buildPrompt = (description: string, keywordString: string): string => {
    const keywordList = keywordString.split(',').map(k => k.trim()).filter(k => k).join(', ');
    
    if (!description || !keywordList) {
      return '';
    }

    return `
You are an ASO (App Store Optimization) expert. Your goal is to rewrite an app description to naturally include a list of target keywords without keyword stuffing.

**Original Description:**
${description}

**Target Keywords:**
${keywordList}

**Instructions:**
1. Analyze the original description and the list of keywords.
2. Rewrite the description to seamlessly integrate the keywords.
3. Maintain a natural, engaging tone. The text should read as if written by a human, not optimized for search engines.
4. Ensure a keyword density of approximately 2-3%. Do not overuse any single keyword.
5. Preserve the core message and features of the original description.
6. Output only the rewritten description text. Do not include any introductory sentences or markdown.
`;
  };

  // Handler for the Generate button
  const handleGenerate = async () => {
    if (!rawDescription || !keywords) {
      alert('Please provide both a description and keywords.');
      return;
    }
    const prompt = buildPrompt(rawDescription, keywords);
    // We set the input for the hook and trigger the completion
    setInput(prompt);
    await complete(prompt);
  };

  // Handler for copying to clipboard
  const handleCopy = () => {
    if (completion) {
      navigator.clipboard.writeText(completion).then(() => {
        alert('Description copied to clipboard!');
      });
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h1>ASO Keyword Integrator</h1>
      
      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Raw App Description</label>
        <textarea
          value={rawDescription}
          onChange={(e) => setRawDescription(e.target.value)}
          rows={6}
          style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          placeholder="Paste the original app description here..."
        />
      </div>

      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Keywords (comma-separated)</label>
        <textarea
          value={keywords}
          onChange={(e) => setKeywords(e.target.value)}
          rows={3}
          style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          placeholder="e.g., task manager, productivity, to-do list, reminders"
        />
      </div>

      <button 
        onClick={handleGenerate} 
        disabled={isLoading}
        style={{ 
          padding: '10px 20px', 
          backgroundColor: isLoading ? '#ccc' : '#0070f3', 
          color: 'white', 
          border: 'none', 
          borderRadius: '4px', 
          cursor: isLoading ? 'not-allowed' : 'pointer' 
        }}
      >
        {isLoading ? 'Generating...' : 'Generate Optimized Description'}
      </button>

      {error && (
        <div style={{ color: 'red', marginTop: '15px' }}>
          Error: {error.message}
        </div>
      )}

      {completion && (
        <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h2 style={{ margin: 0 }}>Generated Output</h2>
            <button 
              onClick={handleCopy}
              style={{ padding: '6px 12px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
            >
              Copy to Clipboard
            </button>
          </div>
          <div style={{ whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>
            {completion}
          </div>
        </div>
      )}
    </div>
  );
}
