/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// localizationGenerator.ts

/**
 * @description A detailed explanation of why JSON Schema output is crucial.
 * 
 * 1. **The Unreliability of LLM Text Output:** LLMs, by nature, are text generation engines. Without strict constraints, their output can be unpredictable. They might add conversational filler ("Sure, here is the JSON you asked for:"), use markdown formatting, or produce slightly malformed JSON (e.g., trailing commas). This makes parsing unreliable and can crash downstream applications.
 * 
 * 2. **Predictable Data Structures for Downstream Processing:** In a production environment, the generated content is not an end product. It's data that needs to be processed. For example, the `title` might be sent to a translation management system, the `shortDescription` might be pushed to a CMS for A/B testing, and the `mainDescription` might be used in a marketing email. Each of these systems expects data in a specific format. A structured output (like JSON) ensures the application can programmatically route and use each piece of data without manual intervention.
 * 
 * 3. **Schema Validation and Error Handling:** This is the most critical aspect. By defining a strict schema (e.g., using TypeScript interfaces or a runtime validation library like Zod), we can validate the LLM's response. If the LLM returns a string instead of an object, or omits a required field, a validation library will immediately throw a clear, descriptive error (e.g., "Validation error: expected 'title' to be a string, but received 'undefined'"). This is far superior to trying to debug a silent failure deep in the application logic. It turns a "garbage in, garbage out" scenario into a "garbage in, explicit error out" scenario, making the system robust and debuggable.
 * 
 * 4. **Function Calling Paradigm:** Modern LLMs support "Function Calling" or "Tool Use." This is the ultimate form of structured output. Instead of asking the model to "write a JSON object," you provide a function definition (a schema) and ask the model to call that function with arguments. The model's output is then a structured function call, not just text. This is more reliable and is the recommended approach for production systems, as the model is explicitly trained to adhere to the function's schema.
 */
/*
 * Your explanation here...
 */

// 1. Define the TypeScript interface for the structured output.
interface Localization {
  languageCode: string;
  title: string;
  shortDescription: string; // Max 30 characters constraint will be in the prompt
  mainDescription: string;
}

interface LocalizationOutput {
  localizations: Localization[];
}

// 2. Create the function to generate the prompt.
export function generateLocalizations(englishDescription: string): string {
  const schemaDescription = JSON.stringify({
    type: "object",
    properties: {
      localizations: {
        type: "array",
        items: {
          type: "object",
          properties: {
            languageCode: { type: "string", description: "The BCP 47 language tag, e.g., ja-JP, de-DE, pt-BR" },
            title: { type: "string", description: "A catchy, culturally relevant title for the app store." },
            shortDescription: { type: "string", description: "A concise subtitle, maximum 30 characters." },
            mainDescription: { type: "string", description: "The full app description, localized for the target market." }
          },
          required: ["languageCode", "title", "shortDescription", "mainDescription"]
        }
      }
    },
    required: ["localizations"]
  }, null, 2);

  return `
You are an expert localization specialist for mobile applications. Your task is to generate culturally adapted app store listings for three specific markets: Japan, Germany, and Brazil.

**Original English Description:**
"""
${englishDescription}
"""

**Task:**
Generate a localized description for the following three languages:
- Japanese (ja-JP)
- German (de-DE)
- Brazilian Portuguese (pt-BR)

**Instructions:**
1. **Cultural Adaptation:** Do not perform a literal translation. Adapt the tone, idioms, and value propositions to be relevant and appealing to each target market. For example, marketing angles in Japan often emphasize quality and precision, while in Brazil, they might focus on community and social features.
2. **Strict JSON Output:** Your entire response MUST be a single, valid JSON object. Do not include any text before or after the JSON.
3. **JSON Schema:** The JSON object must strictly adhere to the following schema:

${schemaDescription}

**Critical Constraints:**
- The \`shortDescription\` for each localization MUST be 30 characters or fewer.
- Ensure all fields are populated for all three languages.
- The JSON must be parseable by a standard JSON parser.
`;
}
