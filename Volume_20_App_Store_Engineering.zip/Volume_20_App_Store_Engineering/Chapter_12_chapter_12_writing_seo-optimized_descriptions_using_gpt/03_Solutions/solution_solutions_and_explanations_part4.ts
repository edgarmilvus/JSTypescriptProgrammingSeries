/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// AOrchestrator.ts

// 1. Define interfaces
interface AppDescription {
  id: string;
  description: string;
}

interface TestResult {
  descriptionId: string;
  impressions: number;
  clicks: number;
  installs: number;
  ctr: number;
  cvr: number;
  weightedScore: number;
}

// 2. Mock data generator
function generateMockMetrics(id: string): TestResult {
  // Base metrics to simulate a realistic scale
  const baseImpressions = 10000;
  const baseClicks = 500;
  const baseInstalls = 150;

  // Introduce randomness to simulate real-world variability (noise)
  // We use Math.random() to create a factor between 0.8 and 1.2
  const noiseFactor = 0.8 + Math.random() * 0.4;

  // Define biases to make the test non-trivial.
  // Description 'B' is the intended winner with a slight performance boost.
  let biasFactor = 1.0;
  if (id === 'B') {
    biasFactor = 1.15; // 15% performance boost
  } else if (id === 'C') {
    biasFactor = 0.90; // 10% performance penalty
  }

  // Calculate final noisy, biased metrics
  const impressions = Math.floor(baseImpressions * noiseFactor);
  // CTR is influenced by the bias
  const clicks = Math.floor(baseClicks * noiseFactor * biasFactor);
  // CVR is also influenced by the bias
  const installs = Math.floor(baseInstalls * noiseFactor * biasFactor);

  return {
    descriptionId: id,
    impressions,
    clicks,
    installs,
    ctr: 0, // Placeholder, will be calculated
    cvr: 0, // Placeholder, will be calculated
    weightedScore: 0 // Placeholder, will be calculated
  };
}

// 3. The main orchestrator function
export async function runAOrchestrator(descriptions: AppDescription[]): Promise<TestResult> {
  // a. Simulate an API call to fetch metrics for each description
  // We use a promise-based timeout to mimic network latency
  const simulatedApiCall = new Promise<TestResult[]>((resolve) => {
    setTimeout(() => {
      const results = descriptions.map(desc => generateMockMetrics(desc.id));
      resolve(results);
    }, 500); // 500ms delay
  });

  const rawResults = await simulatedApiCall;

  // b. & c. Process data: Calculate CTR, CVR, and the weighted score
  const processedResults = rawResults.map(result => {
    // Avoid division by zero
    const ctr = result.impressions > 0 ? result.clicks / result.impressions : 0;
    const cvr = result.clicks > 0 ? result.installs / result.clicks : 0;

    // The required weighted score formula
    const weightedScore = (ctr * 0.6) + (cvr * 0.4);

    return {
      ...result,
      ctr: parseFloat(ctr.toFixed(4)), // Format to 4 decimal places
      cvr: parseFloat(cvr.toFixed(4)),
      weightedScore: parseFloat(weightedScore.toFixed(4))
    };
  });

  // d. Find and return the TestResult with the highest weightedScore
  if (processedResults.length === 0) {
    throw new Error("No descriptions provided for testing.");
  }

  const winner = processedResults.reduce((prev, current) => {
    return (prev.weightedScore > current.weightedScore) ? prev : current;
  });

  // For demonstration, log all results to see the comparison
  console.table(processedResults);
  
  return winner;
}

// --- Example Usage ---
/*
async function runTest() {
  const descriptions: AppDescription[] = [
    { id: 'A', description: 'A standard description focusing on features.' },
    { id: 'B', description: 'An optimized description with strong keywords and a clear CTA.' },
    { id: 'C', description: 'A shorter, less detailed description.' }
  ];

  console.log("Running A/B Test Simulation...");
  const winningResult = await runAOrchestrator(descriptions);
  
  console.log("\n--- TEST COMPLETE ---");
  console.log("Winner:");
  console.log(`Description ID: ${winningResult.descriptionId}`);
  console.log(`Weighted Score: ${winningResult.weightedScore}`);
  console.log(`(CTR: ${winningResult.ctr}, CVR: ${winningResult.cvr})`);
}

// runTest();
*/
