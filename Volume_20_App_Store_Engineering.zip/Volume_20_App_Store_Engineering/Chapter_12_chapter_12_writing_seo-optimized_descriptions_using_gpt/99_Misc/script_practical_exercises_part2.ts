/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// localizationGenerator.ts

/**
 * @description A detailed explanation of why JSON Schema output is crucial.
 * Discuss:
 * 1. The unreliability of LLM text output.
 * 2. The need for predictable data structures for downstream processing (e.g., populating a CMS, sending to a translation API).
 * 3. How schema validation libraries (like Zod) can parse and validate the LLM's output, throwing clear errors if the structure is incorrect.
 * 4. The concept of "Function Calling" where the LLM's output is not just text but a pre-defined function call with structured arguments.
 */
/*
 * Your explanation here...
 */

// 1. Define the TypeScript interface for the structured output.
interface Localization {
  languageCode: string;
  title: string;
  shortDescription: string;
  mainDescription: string;
}

interface LocalizationOutput {
  localizations: Localization[];
}

// 2. Create the function to generate the prompt.
export function generateLocalizations(englishDescription: string): string {
  // Your implementation here
  // Construct the prompt that instructs the LLM to return a JSON object matching the LocalizationOutput interface.
}
