/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview "Hello World" example for automated App Store localization.
 * This script simulates a CI/CD job step that translates metadata using an AI API.
 */

// ==========================================
// 1. TYPE DEFINITIONS & SCHEMA
// ==========================================

/**
 * Represents the standard metadata fields required for an App Store listing.
 * We use TypeScript's `type` alias to define our data shape.
 */
type AppStoreMetadata = {
  title: string;
  subtitle: string;
  description: string;
  keywords: string; // Comma-separated string
};

/**
 * Represents the supported locales in our system.
 */
type LocaleCode = 'es-ES' | 'fr-FR' | 'de-DE' | 'ja-JP';

// ==========================================
// 2. MOCK INFRASTRUCTURE (Vector Store & API)
// ==========================================

/**
 * MOCK: Simulates a Vector Store (e.g., Pinecone or pgvector).
 * In a real scenario, this would query embeddings to find context 
 * about cultural nuances for the target locale.
 * 
 * @returns A string containing context hints for the translator.
 */
async function fetchCulturalContext(targetLocale: LocaleCode): Promise<string> {
    // Simulating a database lookup
    const contexts: Record<LocaleCode, string> = {
        'es-ES': "Tone: Formal but friendly. Use 'tú' conjugation.",
        'fr-FR': "Tone: Professional. Emphasize elegance.",
        'de-DE': "Tone: Direct and functional. Focus on features.",
        'ja-JP': "Tone: Polite. Use honorifics if applicable."
    };
    
    // Simulate network latency
    await new Promise(r => setTimeout(r, 100)); 
    return contexts[targetLocale];
}

/**
 * MOCK: Simulates an AI Translation API (like OpenAI or DeepL).
 * It takes the source text and the cultural context to generate a translation.
 * 
 * @param text - The text to translate.
 * @param context - Cultural instructions for the AI.
 * @returns The translated text.
 */
async function aiTranslate(text: string, context: string): Promise<string> {
    // In a real implementation, this would be an HTTP POST request to an LLM provider.
    // Here, we simulate a deterministic transformation based on the context.
    
    const mockResponse = `[AI-TRANSLATED (${context.split(' ')[1]})] ${text}`;
    await new Promise(r => setTimeout(r, 150)); 
    return mockResponse;
}

// ==========================================
// 3. CORE LOGIC
// ==========================================

/**
 * Orchestrates the localization process for a specific locale.
 * 
 * This function demonstrates **Type Inference**: TypeScript automatically infers 
 * the return type based on the structure of the object we return.
 * 
 * @param source - The original metadata (usually English).
 * @param targetLocale - The locale to translate into.
 * @returns A Promise resolving to the translated metadata object.
 */
async function localizeMetadata(
    source: AppStoreMetadata, 
    targetLocale: LocaleCode
) {
    // Step A: Get cultural context from our Vector Store
    const context = await fetchCulturalContext(targetLocale);

    // Step B: Translate fields in parallel for efficiency
    // We use Promise.all to handle async/await loops efficiently
    const [title, subtitle, description, keywords] = await Promise.all([
        aiTranslate(source.title, context),
        aiTranslate(source.subtitle, context),
        aiTranslate(source.description, context),
        aiTranslate(source.keywords, context)
    ]);

    // Step C: Return structured data
    // TypeScript infers this object matches `AppStoreMetadata`
    return {
        title,
        subtitle,
        description,
        keywords
    };
}

// ==========================================
// 4. EXECUTION (Simulating a CI/CD Runner)
// ==========================================

/**
 * Main entry point.
 */
async function main() {
    console.log("--- Starting Localization Job ---");

    // The source of truth (usually defined in en-US)
    const englishMetadata: AppStoreMetadata = {
        title: "PhotoFlash",
        subtitle: "Fastest Photo Editor",
        description: "Edit your photos instantly with AI magic tools.",
        keywords: "photo, editor, ai, fast, filter"
    };

    // We want to deploy to Spain and Japan
    const targetLocales: LocaleCode[] = ['es-ES', 'ja-JP'];

    for (const locale of targetLocales) {
        console.log(`\nProcessing locale: ${locale}`);
        
        // The `localized` variable is automatically typed by TS based on the function return
        const localized = await localizeMetadata(englishMetadata, locale);
        
        console.log(`✅ Success for ${locale}:`, JSON.stringify(localized, null, 2));
        
        // In a real CI/CD, you would now pipe this JSON to EAS CLI:
        // `eas submit --platform ios --metadata-path ./metadata-${locale}.json`
    }

    console.log("\n--- All localizations complete. Ready for upload. ---");
}

// Execute the script
main().catch(console.error);
