/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import * as path from 'path';

// 1. Define the input data structure
interface AppFeatures {
  productName: string;
  tagline: string;
  keywords: string[];
}

// 2. Define the output metadata structure
interface StoreMetadata {
  whatsNew: string;
  marketingCopy: string;
  keywordString: string;
}

// Helper function to parse input JSON (Type inference used for return type)
function parseFeatures(filePath: string): AppFeatures {
  const rawData = fs.readFileSync(filePath, 'utf-8');
  return JSON.parse(rawData) as AppFeatures;
}

// 3. Function to generate and write metadata
function generateStoreMetadata(features: AppFeatures, targetDir: string): void {
  // Create the metadata object
  const metadata: StoreMetadata = {
    whatsNew: "Bug fixes and performance improvements.",
    marketingCopy: `${features.productName}: ${features.tagline}`,
    keywordString: features.keywords.join(',')
  };

  // Ensure target directory exists
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  // Write the file
  const outputPath = path.join(targetDir, 'metadata.json');
  fs.writeFileSync(outputPath, JSON.stringify(metadata, null, 2));
  console.log(`Metadata generated successfully at ${outputPath}`);
}

// Main execution block
function main() {
  // Example usage
  const inputPath = './features.json'; // Assuming this file exists
  const outputDir = './store';

  // Check if input file exists for demo purposes
  if (fs.existsSync(inputPath)) {
    const features = parseFeatures(inputPath);
    generateStoreMetadata(features, outputDir);
  } else {
    // Fallback for the exercise if file doesn't exist
    const mockFeatures: AppFeatures = {
      productName: "FocusFlow",
      tagline: "Master your time, effortlessly.",
      keywords: ["productivity", "pomodoro", "timer", "focus"]
    };
    generateStoreMetadata(mockFeatures, outputDir);
  }
}

main();
