/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Custom Error for dimension mismatch
class VectorDimensionMismatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "VectorDimensionMismatchError";
  }
}

// 1. Mock embedding function (simulates API call)
async function generateVector(text: string): Promise<number[]> {
  // In a real scenario, this calls an API (e.g., OpenAI, Pinecone)
  // Here we mock a simple vector based on string length for demonstration
  const hash = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return [hash % 100, (hash * 2) % 100, (hash * 3) % 100]; // 3-dimensional vector
}

// 2. Cosine Similarity Calculation
function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new VectorDimensionMismatchError(
      `Vectors must have the same dimension. Got ${vecA.length} and ${vecB.length}.`
    );
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0; // Handle zero vectors

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// 3. Validation Logic
async function validateTranslation(
  sourceText: string,
  generatedTranslation: string,
  threshold: number
): Promise<boolean> {
  try {
    // Generate vectors concurrently
    const [sourceVector, transVector] = await Promise.all([
      generateVector(sourceText),
      generateVector(generatedTranslation)
    ]);

    const similarity = calculateCosineSimilarity(sourceVector, transVector);
    
    console.log(`Similarity Score: ${similarity.toFixed(4)}`);
    return similarity >= threshold;
  } catch (error) {
    if (error instanceof VectorDimensionMismatchError) {
      console.error("Validation Error:", error.message);
      return false; // Treat mismatch as failure
    }
    throw error; // Re-throw other unexpected errors
  }
}

// Example Usage
(async () => {
  const source = "Hello World";
  const translation = "Hola Mundo";
  const isValid = await validateTranslation(source, translation, 0.9);
  console.log(`Is translation valid? ${isValid}`);
})();
