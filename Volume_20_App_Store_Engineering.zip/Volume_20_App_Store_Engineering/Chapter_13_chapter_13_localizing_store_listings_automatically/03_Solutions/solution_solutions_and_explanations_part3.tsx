/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Props Interface
interface LocaleStatus {
  code: string;
  status: 'pending' | 'success' | 'failed';
  confidenceScore?: number; // Optional property
}

interface LocalizationProps {
  locales: LocaleStatus[];
}

// 2. Component Definition
const LocalizationStatusCard: React.FC<LocalizationProps> = ({ locales }) => {
  // 3. State Management
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  // Helper to render status icon
  const renderStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <span style={{ color: 'green' }}>✔</span>;
      case 'pending': return <span style={{ color: 'orange' }}>⏳</span>;
      case 'failed': return <span style={{ color: 'red' }}>⚠</span>;
      default: return null;
    }
  };

  return (
    <div style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '16px', maxWidth: '400px' }}>
      {/* Header - Clickable to toggle */}
      <div 
        style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer', fontWeight: 'bold' }}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <span>Pipeline Status ({locales.length} locales)</span>
        <span>{isExpanded ? '▲' : '▼'}</span>
      </div>

      {/* Detailed List - Conditional Rendering */}
      {isExpanded && (
        <div style={{ marginTop: '10px' }}>
          {locales.map((locale) => (
            <div 
              key={locale.code} 
              style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                padding: '8px 0', 
                borderBottom: '1px solid #eee' 
              }}
            >
              <span style={{ fontWeight: '600' }}>{locale.code}</span>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {renderStatusIcon(locale.status)}
                <span style={{ textTransform: 'uppercase', fontSize: '0.8rem' }}>
                  {locale.status}
                </span>
                
                {/* Conditional rendering for confidence score */}
                {locale.status === 'success' && locale.confidenceScore !== undefined && (
                  <span style={{ fontSize: '0.8rem', color: '#666' }}>
                    ({(locale.confidenceScore * 100).toFixed(1)}%)
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default LocalizationStatusCard;
