/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Input Types
type ValidationStatus = 'passed' | 'failed' | 'manual_review';

interface ValidationResult {
  locale: string;
  status: ValidationStatus;
  confidenceScore?: number; // Only present if passed or failed logic applies
}

interface PipelineResult {
  buildSuccess: boolean;
  metadataGenerated: boolean;
  validations: ValidationResult[];
}

// 2. The Orchestration Function
function orchestrateRelease(result: PipelineResult): string {
  // Step 1: Check Build
  if (!result.buildSuccess) {
    return "Pipeline Halted: Build Failed";
  }

  // Step 2: Check Metadata
  if (!result.metadataGenerated) {
    return "Pipeline Halted: Metadata Missing";
  }

  // Step 3: Analyze Validations
  const successfulLocales: string[] = [];
  const reviewLocales: string[] = [];
  const failedLocales: string[] = [];

  for (const validation of result.validations) {
    if (validation.status === 'passed') {
      // Type narrowing: TypeScript knows confidenceScore is likely available here
      successfulLocales.push(validation.locale);
    } else if (validation.status === 'failed') {
      // If failed, we might still want to flag for review or halt
      failedLocales.push(validation.locale);
      reviewLocales.push(validation.locale); // Logic: Flag failed ones for review
    } else {
      // Manual review status
      reviewLocales.push(validation.locale);
    }
  }

  // Step 4: Decision Logic
  // If ALL validations failed, halt the pipeline completely.
  if (successfulLocales.length === 0 && reviewLocales.length > 0) {
    return "Pipeline Halted: No locales passed validation.";
  }

  // Construct Summary
  let summary = "Pipeline Completed. ";
  
  if (successfulLocales.length > 0) {
    summary += `Submitted: [${successfulLocales.join(', ')}]. `;
  }
  
  if (reviewLocales.length > 0) {
    summary += `Flagged for Manual Review: [${reviewLocales.join(', ')}].`;
  } else {
    summary += "All locales processed successfully.";
  }

  return summary;
}

// --- Test Cases ---

// Case 1: Successful Run
const successCase: PipelineResult = {
  buildSuccess: true,
  metadataGenerated: true,
  validations: [
    { locale: 'en-US', status: 'passed', confidenceScore: 0.99 },
    { locale: 'fr-FR', status: 'passed', confidenceScore: 0.96 }
  ]
};

// Case 2: Partial Failure (Continues)
const partialFailureCase: PipelineResult = {
  buildSuccess: true,
  metadataGenerated: true,
  validations: [
    { locale: 'en-US', status: 'passed', confidenceScore: 0.99 },
    { locale: 'ja-JP', status: 'failed', confidenceScore: 0.50 } // Low score
  ]
};

// Case 3: Total Failure (Halts)
const totalFailureCase: PipelineResult = {
  buildSuccess: true,
  metadataGenerated: true,
  validations: [
    { locale: 'es-ES', status: 'failed' },
    { locale: 'de-DE', status: 'failed' }
  ]
};

console.log("Test 1:", orchestrateRelease(successCase));
console.log("Test 2:", orchestrateRelease(partialFailureCase));
console.log("Test 3:", orchestrateRelease(totalFailureCase));
