/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph PipelineFlow {
    rankdir=TB; // Top to Bottom layout
    node [shape=box, style="rounded,filled", color="#E0E0E0"];
    edge [color="#555555", penwidth=1.5];

    // Define Nodes
    Developer [shape=ellipse, fillcolor="#A7C7E7", fontname="Helvetica"];
    SourceCode [label="Source Code\n(JSON/TS)", fillcolor="#F0F8FF"];
    LocalScript [label="Local Script\n(Automation)", fillcolor="#FFFACD"];
    AI_API [label="AI Translation API", fillcolor="#E6E6FA"];
    VectorStore [label="Vector Store\n(Semantic Memory)", fillcolor="#E0FFFF", shape="cylinder"];
    EAS_CLI [label="EAS CLI", fillcolor="#F0FFF0"];
    AppStore [label="App Store Connect", fillcolor="#FFE4E1", shape="component"];

    // Define Edges (Flow)
    Developer -> SourceCode [label="1. Writes code"];
    Developer -> LocalScript [label="2. Triggers script"];
    
    SourceCode -> LocalScript [label="3. Reads features"];
    
    LocalScript -> AI_API [label="4. Request Translation"];
    AI_API -> VectorStore [label="5. Query for Validation"];
    VectorStore -> AI_API [label="6. Return Semantic Vector"];
    AI_API -> LocalScript [label="7. Return Translation"];

    LocalScript -> EAS_CLI [label="8. Pass Metadata"];
    EAS_CLI -> AppStore [label="9. Upload Metadata"];
}
