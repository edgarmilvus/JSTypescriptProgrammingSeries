/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules from LangChain
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { ChatOllama } from "@langchain/community/chat_models/ollama";

/**
 * @description Represents the structured output of our sentiment analysis.
 * @property sentiment - The classification: 'positive', 'negative', or 'neutral'.
 * @property reason - A brief explanation for the classification.
 */
interface SentimentResult {
  sentiment: 'positive' | 'negative' | 'neutral';
  reason: string;
}

/**
 * @description Analyzes the sentiment of a user review using a local LLM.
 * @param reviewText - The raw text string from the App Store review.
 * @returns A Promise resolving to a SentimentResult object.
 */
async function analyzeReviewSentiment(reviewText: string): Promise<SentimentResult> {
  // 1. Initialize the LLM (Using Ollama for local execution).
  // In production, this might be `new ChatOpenAI({ model: "gpt-4o" })`.
  const model = new ChatOllama({
    model: "llama3.2", // Ensure you have this model pulled in Ollama
    temperature: 0, // Deterministic output for classification tasks
  });

  // 2. Define the System Prompt (The "Persona" and Instructions).
  // We explicitly instruct the model to return JSON to make parsing easier.
  const systemPrompt = `
    You are an AI assistant for a SaaS product management dashboard.
    Analyze the following user review and classify the sentiment.
    Return ONLY a JSON object with the keys "sentiment" and "reason".
    
    Sentiment Options:
    - "positive": The user is happy, praising features, or satisfied.
    - "negative": The user is angry, reporting bugs, or frustrated.
    - "neutral": The user is asking a question or providing objective feedback without strong emotion.
  `;

  // 3. Create the Chat Prompt Template.
  // This combines the system instructions with the dynamic user input.
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", systemPrompt],
    ["user", "{review_text}"],
  ]);

  // 4. Create the Output Parser.
  // This converts the LLM's string response into a structured object.
  const outputParser = new StringOutputParser();

  // 5. Chain the components together.
  // LCEL (LangChain Expression Language) allows us to pipe prompt -> model -> parser.
  const chain = prompt.pipe(model).pipe(outputParser);

  try {
    // 6. Invoke the chain with the review text.
    // The { review_text } object matches the placeholder in the template.
    const response = await chain.invoke({ review_text: reviewText });

    // 7. Parse the JSON string returned by the LLM.
    // Note: LLMs can be unreliable with strict JSON formatting, so we wrap this.
    const parsedResponse: SentimentResult = JSON.parse(response);

    return parsedResponse;
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    // Fallback for production resilience
    return { sentiment: 'neutral', reason: 'Analysis failed due to system error.' };
  }
}

// --- Execution Example ---

// Simulating a user review coming from an API endpoint (e.g., /api/reviews/webhook)
const userReview = "I love the new dark mode feature! However, the app crashes every time I try to export my data to PDF, which is incredibly frustrating.";

// Execute the function
analyzeReviewSentiment(userReview)
  .then((result) => {
    console.log("--- Analysis Result ---");
    console.log(`Sentiment: ${result.sentiment.toUpperCase()}`);
    console.log(`Reason: ${result.reason}`);
    console.log("-----------------------");
    
    // Logic to integrate with CI/CD or Dashboard
    if (result.sentiment === 'negative') {
      console.log("Triggering Jira ticket creation for 'Export to PDF' bug...");
    }
  })
  .catch((err) => console.error(err));
