/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/analyze-reviews.ts
// Next.js API Route for processing user feedback

import { NextApiRequest, NextApiResponse } from 'next';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & SCHEMA
// -----------------------------------------------------------------------------

/**
 * Represents a raw review object from an App Store or Play Store webhook.
 */
interface RawReview {
  id: string;
  userName: string;
  rating: number; // 1-5
  text: string;
  timestamp: string;
  version: string;
}

/**
 * Represents the structured output expected from the LLM.
 * This acts as the "JSON Schema" contract.
 */
interface AnalyzedReview {
  reviewId: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  category: 'bug_report' | 'feature_request' | 'general_feedback';
  summary: string;
  priorityScore: number; // 0-10, calculated by LLM based on severity
  suggestedAction?: 'create_ticket' | 'reply' | 'ignore';
}

/**
 * Interface for the LLM provider (e.g., OpenAI, Anthropic, or a local model).
 * Abstracts the specific API call.
 */
interface LLMProvider {
  generateStructuredOutput(
    prompt: string,
    schema: any
  ): Promise<AnalyzedReview>;
}

// -----------------------------------------------------------------------------
// 2. MOCK LLM PROVIDER (Simulating Tool Calling & JSON Schema)
// -----------------------------------------------------------------------------

/**
 * A mock implementation of an LLM provider.
 * In production, this would wrap `openai.chat.completions.create` with `response_format: { type: "json_object" }`.
 * 
 * This mock demonstrates how we enforce the JSON Schema structure.
 */
class MockLLMProvider implements LLMProvider {
  async generateStructuredOutput(
    prompt: string, 
    schema: any
  ): Promise<AnalyzedReview> {
    // Simulate network latency (Perceived Performance consideration)
    await new Promise(resolve => setTimeout(resolve, 200));

    // Simulate LLM parsing the review text and applying logic
    // In a real scenario, the LLM does this. Here we mimic the output.
    const isBug = prompt.toLowerCase().includes('crash') || prompt.toLowerCase().includes('error');
    const isFeature = prompt.toLowerCase().includes('add') || prompt.toLowerCase().includes('want');
    const isNegative = prompt.toLowerCase().includes('bad') || prompt.toLowerCase().includes('hate');

    return {
      reviewId: "mock-id-123", // Extracted from prompt context
      sentiment: isNegative ? 'negative' : (isFeature ? 'neutral' : 'positive'),
      category: isBug ? 'bug_report' : (isFeature ? 'feature_request' : 'general_feedback'),
      summary: `Summary of review: ${prompt.substring(0, 50)}...`,
      priorityScore: isBug ? 9 : (isFeature ? 5 : 1),
      suggestedAction: isBug ? 'create_ticket' : 'reply'
    };
  }
}

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: REVIEW AGGREGATION & ANALYSIS
// -----------------------------------------------------------------------------

/**
 * Orchestrates the review analysis pipeline.
 * 
 * 1. Fetches raw reviews (simulated).
 * 2. Iterates through reviews.
 * 3. Invokes LLM with a specific prompt and JSON schema constraint.
 * 4. Collects structured insights.
 * 5. (Optional) Triggers Tool Calling for high-priority issues.
 */
async function analyzeReviewPipeline(
  reviews: RawReview[], 
  llm: LLMProvider
): Promise<AnalyzedReview[]> {
  const insights: AnalyzedReview[] = [];

  console.log(`Starting analysis for ${reviews.length} reviews...`);

  for (const review of reviews) {
    // Construct a detailed prompt. This is crucial for guiding the LLM.
    const prompt = `
      Analyze the following App Store review.
      Rating: ${review.rating}/5
      Version: ${review.version}
      Text: "${review.text}"
      
      Determine the sentiment, category, and priority.
    `;

    try {
      // Invoke the LLM with JSON Schema enforcement
      const analysis = await llm.generateStructuredOutput(prompt, {});
      
      // Attach the original ID for traceability
      analysis.reviewId = review.id;
      
      insights.push(analysis);

      // TOOL CALLING SIMULATION:
      // If the LLM determines a high-priority bug, we might trigger an external tool.
      if (analysis.category === 'bug_report' && analysis.priorityScore >= 8) {
        await triggerExternalTool(analysis);
      }

    } catch (error) {
      console.error(`Failed to analyze review ${review.id}:`, error);
    }
  }

  return insights;
}

// -----------------------------------------------------------------------------
// 4. EXTERNAL INTEGRATION (Tool Calling)
// -----------------------------------------------------------------------------

/**
 * Simulates a "Tool Calling" execution.
 * In a real app, the LLM would return a function call request (e.g., "create_jira_ticket").
 * Here, we manually check the result and trigger the action.
 * 
 * This allows the AI to interact with external systems like Jira, Slack, or Linear.
 */
async function triggerExternalTool(analysis: AnalyzedReview) {
  if (analysis.suggestedAction === 'create_ticket') {
    console.log(`[TOOL CALL] Creating Jira Ticket for Review ID: ${analysis.reviewId}`);
    // Actual implementation would be:
    // await jiraApi.createIssue({ summary: analysis.summary, priority: 'High' });
  }
}

// -----------------------------------------------------------------------------
// 5. NEXT.JS API ROUTE HANDLER
// -----------------------------------------------------------------------------

/**
 * Next.js API Route Handler
 * Endpoint: POST /api/analyze-reviews
 * 
 * Accepts a list of raw reviews and returns a dashboard-ready JSON payload.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { reviews } = req.body;

  if (!reviews || !Array.isArray(reviews)) {
    return res.status(400).json({ error: 'Invalid input: "reviews" array required.' });
  }

  try {
    // Initialize the LLM provider (Dependency Injection pattern)
    const llmProvider = new MockLLMProvider();

    // Execute the analysis pipeline
    const analyzedData = await analyzeReviewPipeline(reviews, llmProvider);

    // Calculate aggregate metrics for the dashboard
    const aggregateMetrics = {
      totalReviews: analyzedData.length,
      averagePriority: analyzedData.reduce((acc, curr) => acc + curr.priorityScore, 0) / analyzedData.length,
      bugCount: analyzedData.filter(d => d.category === 'bug_report').length,
      featureRequests: analyzedData.filter(d => d.category === 'feature_request').length,
    };

    // Return structured JSON for the frontend or CI/CD pipeline
    res.status(200).json({
      success: true,
      metrics: aggregateMetrics,
      insights: analyzedData,
    });

  } catch (error) {
    console.error('Pipeline Error:', error);
    res.status(500).json({ error: 'Internal Server Error during analysis.' });
  }
}

// -----------------------------------------------------------------------------
// 6. EXAMPLE USAGE (Mock Data)
// -----------------------------------------------------------------------------

/**
 * Example payload that might be sent to the API.
 * Used for local testing.
 */
const MOCK_REVIEWS: RawReview[] = [
  {
    id: "rev_001",
    userName: "Alice",
    rating: 1,
    text: "The app crashes immediately when I try to upload a photo. Terrible update.",
    timestamp: "2023-10-27T10:00:00Z",
    version: "2.1.0"
  },
  {
    id: "rev_002",
    userName: "Bob",
    rating: 5,
    text: "Love the new dark mode! It would be great if you added a scheduling feature though.",
    timestamp: "2023-10-27T11:00:00Z",
    version: "2.1.0"
  }
];

// To test locally, you can uncomment the following block:
/*
(async () => {
  const llm = new MockLLMProvider();
  const results = await analyzeReviewPipeline(MOCK_REVIEWS, llm);
  console.log(JSON.stringify(results, null, 2));
})();
*/
