/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Represents the raw data structure fetched from an App Store API.
 */
export interface RawReview {
  id: string;
  author: string;
  date: string; // ISO 8601 string or specific format
  rating: number; // 1 to 5
  text: string;
}

/**
 * Represents the processed data structure ready for AI analysis.
 * Extends RawReview and adds a cleanedText property.
 */
export interface ProcessedReview extends RawReview {
  cleanedText: string;
}

/**
 * Sanitizes a string by removing non-ASCII characters and trimming whitespace.
 * @param text - The raw review text.
 * @returns The cleaned string.
 */
const sanitizeText = (text: string): string => {
  // 1. Remove non-ASCII characters (e.g., emojis, special symbols)
  // Regex: [^\x00-\x7F] matches any character outside the standard ASCII range.
  // 2. Trim leading/trailing whitespace.
  return text.replace(/[^\x00-\x7F]+/g, "").trim();
};

/**
 * Aggregates and processes an array of raw reviews.
 * @param reviews - Array of RawReview objects.
 * @returns A Promise resolving to an array of ProcessedReview objects.
 */
export async function aggregateAndProcessReviews(
  reviews: RawReview[]
): Promise<ProcessedReview[]> {
  // Map over the input array to transform each raw review into a processed one.
  const processedReviews: ProcessedReview[] = reviews.map((review) => {
    return {
      ...review, // Spread existing properties (id, author, date, rating, text)
      cleanedText: sanitizeText(review.text), // Add the new cleanedText property
    };
  });

  // In a real-world scenario, this might involve async database operations or API calls.
  // We return a Promise to match the async signature.
  return Promise.resolve(processedReviews);
}
