/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { ProcessedReview } from './exercise-1'; // Assuming previous interface is imported

// 1. Define the Zod schema for the expected AI response.
// This ensures the output strictly matches the structure: { sentiment, reasoning }
const sentimentSchema = z.object({
  sentiment: z.enum(['positive', 'negative', 'neutral']),
  reasoning: z.string(),
});

/**
 * Analyzes a processed review using an LLM to determine sentiment.
 * @param review - The ProcessedReview object containing the cleaned text.
 * @returns A Promise resolving to the structured sentiment analysis.
 */
export async function analyzeReviewSentiment(
  review: ProcessedReview
) {
  // 2. Construct the prompt.
  // We instruct the model to act as a sentiment analyzer and return JSON.
  const prompt = `
    You are a sentiment analysis expert for mobile app reviews.
    Analyze the following review text and classify the sentiment as "positive", "negative", or "neutral".
    Provide a brief reasoning for your classification.
    
    Review Text: "${review.cleanedText}"
    
    Return the result strictly as a JSON object matching this schema: 
    { "sentiment": string, "reasoning": string }
  `;

  // 3. Use generateObject to enforce the schema and infer types automatically.
  const result = await generateObject({
    model: openai('gpt-4-turbo-preview'), // or gpt-3.5-turbo
    schema: sentimentSchema,
    prompt: prompt,
  });

  // 4. Return the structured object.
  // The return type is automatically inferred from the Zod schema by TypeScript.
  return result.object;
}
