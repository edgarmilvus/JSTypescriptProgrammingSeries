/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the shape of the analyzed data expected by the component
export interface AnalyzedReview {
  text: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  reasoning: string;
}

interface ReviewSentimentListProps {
  reviews: AnalyzedReview[];
}

const ReviewSentimentList: React.FC<ReviewSentimentListProps> = ({ reviews }) => {
  // State to track which reviews have their reasoning visible
  const [expandedReviews, setExpandedReviews] = useState<Set<number>>(new Set());

  const toggleReasoning = (index: number) => {
    const newSet = new Set(expandedReviews);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    setExpandedReviews(newSet);
  };

  // Helper to determine CSS class based on sentiment
  const getSentimentStyle = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'border-l-4 border-green-500 bg-green-50';
      case 'negative':
        return 'border-l-4 border-red-500 bg-red-50';
      case 'neutral':
        return 'border-l-4 border-gray-500 bg-gray-50';
      default:
        return 'border-l-4 border-gray-300';
    }
  };

  return (
    <div className="space-y-4 p-4">
      {reviews.map((review, index) => (
        <div
          key={index}
          className={`p-4 rounded shadow-sm transition-all ${getSentimentStyle(review.sentiment)}`}
        >
          <div className="flex justify-between items-start">
            <div>
              <span className="font-bold uppercase text-xs tracking-wider text-gray-600">
                {review.sentiment}
              </span>
              <p className="mt-2 text-gray-800">{review.text}</p>
            </div>
            <button
              onClick={() => toggleReasoning(index)}
              className="text-sm text-blue-600 hover:text-blue-800 underline ml-4"
            >
              {expandedReviews.has(index) ? 'Hide Reasoning' : 'Show Reasoning'}
            </button>
          </div>

          {/* Conditional Rendering for Reasoning */}
          {expandedReviews.has(index) && (
            <div className="mt-3 pt-3 border-t border-gray-200 text-sm text-gray-600 italic">
              <strong>AI Reasoning:</strong> {review.reasoning}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ReviewSentimentList;
