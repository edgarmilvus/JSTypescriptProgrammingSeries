/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useChat } from 'ai/react';

export default function ReviewAnalyzerDashboard() {
  // useChat hook handles state, input, and streaming updates automatically
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/analyze', // Points to our custom backend route
  });

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Real-Time Review Analyzer</h1>
      
      {/* Input Area */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Paste a user review here..."
          className="w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
          rows={4}
        />
        <button 
          type="submit" 
          disabled={isLoading || !input}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isLoading ? 'Analyzing...' : 'Analyze Sentiment'}
        </button>
      </form>

      {/* Output Area */}
      <div className="space-y-4">
        {messages.map((msg, index) => (
          <div key={index} className="p-4 bg-gray-100 rounded-lg">
            <div className="font-semibold text-sm text-gray-500 uppercase">
              {msg.role === 'user' ? 'Your Input' : 'AI Analysis'}
            </div>
            <div className="mt-2 whitespace-pre-wrap">
              {msg.role === 'assistant' ? (
                // Attempt to parse and display the JSON nicely
                <pre className="text-sm font-mono bg-white p-2 rounded border">
                  {msg.content}
                </pre>
              ) : (
                msg.content
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
