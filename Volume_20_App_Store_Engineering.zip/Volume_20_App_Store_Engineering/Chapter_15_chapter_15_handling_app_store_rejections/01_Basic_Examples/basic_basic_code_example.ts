/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/rejection-handler.ts
import { StateGraph, END, START, Annotation } from "@langchain/langgraph";
import { ToolNode } from "@langchain/langgraph/prebuilt";

// --- 1. Define State Schema ---
// We use TypeScript interfaces for type safety across the graph.
interface RejectionState {
  appId: string;
  rejectionReason: string | null;
  analysis: string | null;
  status: "pending" | "analyzed" | "resolved";
}

// --- 2. Define Asynchronous Tool ---
/**
 * Simulates an external API call to fetch detailed rejection info from Apple/Google.
 * In a real app, this would use `fetch` or an SDK like `expo-server-sdk`.
 * 
 * CRITICAL: This function returns a Promise, making it asynchronous.
 * We wrap the network delay in a Promise to simulate real-world latency.
 */
const fetchRejectionDetails = async (appId: string): Promise<{ reason: string; code: number }> => {
  console.log(`[Tool] Fetching details for App ID: ${appId}...`);
  
  // Simulate a network delay (e.g., 1 second)
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock response data
  const mockResponse = {
    reason: "App crashes on launch due to null pointer exception in settings view.",
    code: 42,
  };
  
  return mockResponse;
};

// --- 3. Define Node Functions ---
// Node functions in LangGraph are the building blocks of the workflow.

/**
 * Node A: Initiate the process.
 * Sets the initial state.
 */
const initializeRejection = (state: RejectionState): Partial<RejectionState> => {
  console.log(`[Node] Initializing for App ID: ${state.appId}`);
  return {
    status: "pending",
  };
};

/**
 * Node B: Asynchronous Tool Execution.
 * This is the core example of Asynchronous Tool Handling.
 * It awaits the external tool call and updates the state.
 * 
 * UNDER THE HOOD: LangGraph expects nodes to return a new state object.
 * We use `await` to ensure the graph execution pauses here until the Promise resolves.
 */
const analyzeRejection = async (state: RejectionState): Promise<Partial<RejectionState>> => {
  if (!state.appId) {
    throw new Error("App ID is missing.");
  }

  // 1. Call the async tool
  const details = await fetchRejectionDetails(state.appId);
  
  // 2. Process the result
  const analysis = `Critical Error: ${details.reason}. Error Code: ${details.code}. Recommended Action: Patch settings view logic.`;
  
  return {
    rejectionReason: details.reason,
    analysis: analysis,
    status: "analyzed",
  };
};

/**
 * Node C: Finalize.
 * Determines the next step (e.g., trigger OTA update).
 */
const resolveRejection = (state: RejectionState): Partial<RejectionState> => {
  console.log(`[Node] Resolving. Analysis: ${state.analysis}`);
  return {
    status: "resolved",
  };
};

// --- 4. Construct the Graph ---
// We define the workflow: Start -> Initialize -> Analyze -> Resolve -> End

// Define the graph state using Annotation (standard in LangGraph v0.2+)
const RejectionGraphState = Annotation.Root({
  appId: Annotation<string>({
    reducer: (curr, update) => update ?? curr, // Keep existing if not updated
    default: () => "com.example.app",
  }),
  rejectionReason: Annotation<string | null>({
    reducer: (curr, update) => update ?? curr,
    default: () => null,
  }),
  analysis: Annotation<string | null>({
    reducer: (curr, update) => update ?? curr,
    default: () => null,
  }),
  status: Annotation<"pending" | "analyzed" | "resolved">({
    reducer: (curr, update) => update ?? curr,
    default: () => "pending",
  }),
});

// Initialize the graph
const workflow = new StateGraph(RejectionGraphState);

// Add nodes
workflow.addNode("initialize", initializeRejection);
workflow.addNode("analyze", analyzeRejection);
workflow.addNode("resolve", resolveRejection);

// Define edges (flow logic)
workflow.addEdge(START, "initialize");
workflow.addEdge("initialize", "analyze");
workflow.addEdge("analyze", "resolve");
workflow.addEdge("resolve", END);

// Compile the graph
const app = workflow.compile();

// --- 5. Execution ---
/**
 * Main function to run the graph.
 * This demonstrates how to invoke the graph with an initial state.
 */
async function main() {
  console.log("--- Starting App Store Rejection Handler ---");
  
  const inputs = { 
    appId: "com.mycompany.mobileapp" 
  };

  try {
    // The `invoke` method handles the async execution of the graph
    const finalState = await app.invoke(inputs);
    
    console.log("\n--- Final State ---");
    console.log(JSON.stringify(finalState, null, 2));
  } catch (error) {
    console.error("Error executing graph:", error);
  }
}

// Execute if running directly (e.g., `ts-node src/rejection-handler.ts`)
if (require.main === module) {
  main();
}

export { app, fetchRejectionDetails };
