/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';
import { VectorStore } from './lib/vector-store'; // Hypothetical client-side wrapper for a vector DB

/**
 * @description A client-side component that ingests App Store rejection feedback,
 * queries a Vector Store for historical context, and uses an LLM via useChat
 * to generate actionable remediation steps.
 * @returns {JSX.Element} A React component rendering the analysis interface.
 */
export default function RejectionAnalyzer() {
  // 1. State Management for Contextual Data
  // We need to store the raw rejection reason and the specific platform (iOS/Android)
  // to tailor the AI's response.
  const [rejectionContext, setRejectionContext] = useState<{
    rawText: string;
    platform: 'ios' | 'android' | null;
  }>({
    rawText: '',
    platform: null,
  });

  // 2. Vercel AI SDK Hook Integration
  // The `useChat` hook manages the streaming response from the AI model.
  // We inject a custom `api` endpoint that handles the RAG (Retrieval-Augmented Generation) logic.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/analyze-rejection', // Backend route that handles Vector Store queries
    body: {
      platform: rejectionContext.platform, // Pass platform context to the backend
    }
  });

  // 3. Vector Store Simulation (Client-Side Logic for Demo)
  // In a real app, we might pre-fetch similar historical rejections to show the user
  // before the AI generates a response.
  const [similarCases, setSimilarCases] = useState<any[]>([]);

  useEffect(() => {
    if (rejectionContext.rawText.length > 10 && rejectionContext.platform) {
      // Mocking a Vector Store query to find similar past rejections
      // This helps the user understand the severity of the issue.
      VectorStore.search(rejectionContext.rawText).then(setSimilarCases);
    }
  }, [rejectionContext]);

  /**
   * @description Handles the submission of the rejection form.
   * It constructs a prompt that includes the Vector Store context for the AI.
   */
  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectionContext.platform) return alert('Please select a platform.');

    // Construct a rich prompt for the AI
    const enrichedInput = `
      Platform: ${rejectionContext.platform.toUpperCase()}
      Rejection Reason: ${input}
      
      Instructions:
      1. Identify the specific guideline violation.
      2. Suggest a code fix or metadata change.
      3. If it's a crash, suggest an EAS (Expo Application Services) patch strategy.
    `;

    // Pass this to the useChat hook (which sends it to /api/analyze-rejection)
    // We temporarily override the input state for the submission
    const event = {
      target: { value: enrichedInput },
    } as React.ChangeEvent<HTMLInputElement>;
    
    handleInputChange(event); // Update input state
    handleSubmit(e); // Trigger the API call
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-slate-900 text-slate-100 min-h-screen">
      <header className="mb-8 border-b border-slate-700 pb-4">
        <h1 className="text-3xl font-bold text-blue-400">App Store Rejection AI Assistant</h1>
        <p className="text-slate-400 mt-2">
          Paste rejection feedback to generate remediation scripts and OTA update strategies.
        </p>
      </header>

      {/* Input Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="bg-slate-800 p-4 rounded-lg">
            <label className="block text-sm font-medium mb-2">Platform</label>
            <div className="flex gap-2">
              <button
                onClick={() => setRejectionContext(p => ({...p, platform: 'ios'}))}
                className={`flex-1 py-2 rounded ${rejectionContext.platform === 'ios' ? 'bg-blue-600' : 'bg-slate-700'}`}
              >
                iOS
              </button>
              <button
                onClick={() => setRejectionContext(p => ({...p, platform: 'android'}))}
                className={`flex-1 py-2 rounded ${rejectionContext.platform === 'android' ? 'bg-green-600' : 'bg-slate-700'}`}
              >
                Android
              </button>
            </div>
          </div>

          {/* Historical Vector Search Results */}
          {similarCases.length > 0 && (
            <div className="bg-slate-800 p-4 rounded-lg border border-yellow-600/30">
              <h3 className="text-xs font-bold uppercase text-yellow-500 mb-2">
                Vector Store: Similar Cases
              </h3>
              <ul className="text-xs space-y-2 text-slate-300">
                {similarCases.map((c, i) => (
                  <li key={i} className="border-b border-slate-700 pb-1">
                    <span className="font-mono text-yellow-400">[ID: {c.id}]</span> {c.summary}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Chat & Analysis Interface */}
        <div className="md:col-span-2 flex flex-col h-[600px] bg-slate-800 rounded-lg overflow-hidden border border-slate-700">
          {/* Message History */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 && (
              <div className="text-center text-slate-500 mt-20">
                Enter a rejection reason (e.g., "App crashes on launch when using camera on iPad") to begin.
              </div>
            )}
            
            {messages.map((m, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg max-w-[90%] ${
                  m.role === 'user'
                    ? 'bg-blue-900/40 ml-auto border border-blue-700/50'
                    : 'bg-slate-700 mr-auto border border-slate-600'
                }`}
              >
                <div className="text-xs font-bold mb-1 opacity-70 uppercase">
                  {m.role === 'user' ? 'You' : 'AI Assistant'}
                </div>
                <div className="text-sm leading-relaxed whitespace-pre-wrap">
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="text-blue-400 animate-pulse text-sm italic">AI is analyzing guidelines...</div>
            )}
          </div>

          {/* Input Form */}
          <form onSubmit={handleAnalyze} className="p-3 bg-slate-900/50 border-t border-slate-700 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Paste rejection feedback here..."
              className="flex-1 bg-slate-800 border border-slate-600 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={isLoading || !rejectionContext.platform}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded font-medium text-sm transition-colors"
            >
              {isLoading ? 'Analyzing...' : 'Analyze'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
