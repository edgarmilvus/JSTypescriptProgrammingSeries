/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// ResubmissionStatus.tsx
'use client';

import { useState, useEffect } from 'react';

// Define the shape of the submission status
type SubmissionStatus = 'Waiting for Review' | 'In Review' | 'Rejected' | 'Approved';

export default function ResubmissionStatus() {
    // State management for UI
    const [status, setStatus] = useState<SubmissionStatus | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [otaMessage, setOtaMessage] = useState<string>('');

    // 1. Fetch initial status on mount
    useEffect(() => {
        const fetchStatus = async () => {
            try {
                // Simulate API call to /api/submission-status
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Mock response: simulating a rejection state
                const mockResponse: SubmissionStatus = 'Rejected';
                setStatus(mockResponse);
            } catch (error) {
                console.error("Failed to fetch status", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchStatus();
    }, []); // Empty dependency array ensures this runs only once on mount

    // 2. Handle OTA Trigger
    const handleTriggerOTA = async () => {
        setIsLoading(true);
        setOtaMessage('Sending request to EAS...');

        try {
            // Simulate network request to /api/eas/update (2 seconds)
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Simulate success response
            setOtaMessage('Success: OTA update queued. Users will receive the fix shortly.');
        } catch (error) {
            setOtaMessage('Error: Failed to trigger OTA update.');
        } finally {
            setIsLoading(false);
        }
    };

    // Helper to determine UI color based on status
    const getStatusColor = (s: SubmissionStatus) => {
        switch (s) {
            case 'Rejected': return 'border-red-500 bg-red-50 text-red-800';
            case 'In Review': return 'border-yellow-500 bg-yellow-50 text-yellow-800';
            case 'Approved': return 'border-green-500 bg-green-50 text-green-800';
            default: return 'border-gray-500 bg-gray-50 text-gray-800';
        }
    };

    if (isLoading && !status) {
        return <div className="p-4">Loading submission status...</div>;
    }

    return (
        <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md border">
            <h2 className="text-xl font-bold mb-4">App Submission Status</h2>
            
            {status && (
                <div className={`p-4 mb-4 border-l-4 rounded ${getStatusColor(status)}`}>
                    <p className="font-semibold">Current Status: {status}</p>
                </div>
            )}

            {/* Conditional Rendering: Show button only if Rejected */}
            {status === 'Rejected' && (
                <div className="space-y-4">
                    <button
                        onClick={handleTriggerOTA}
                        disabled={isLoading}
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 disabled:opacity-50 transition"
                    >
                        {isLoading ? 'Processing...' : 'Push OTA Fix'}
                    </button>

                    {otaMessage && (
                        <div className="p-3 bg-gray-100 rounded text-sm text-gray-700">
                            {otaMessage}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
