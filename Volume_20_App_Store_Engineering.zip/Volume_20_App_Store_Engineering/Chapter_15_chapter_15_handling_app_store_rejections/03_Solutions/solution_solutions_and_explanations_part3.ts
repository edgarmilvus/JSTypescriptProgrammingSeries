/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// metadata-versioning.ts

// 1. Define the interface
interface MetadataChunk {
    vectorId: string; // UUID
    text: string;
    type: 'keyword' | 'description' | 'screenshot_caption';
    version: number;
}

interface LogEntry {
    timestamp: Date;
    oldVectorId: string;
    newVectorId: string;
    reason: string;
}

// Simulated Database (In-memory Map)
const mockDatabase = new Map<string, MetadataChunk>();

// Seed initial data
const initialId = 'vec-550e8400-e29b-41d4-a716-446655440000';
mockDatabase.set(initialId, {
    vectorId: initialId,
    text: 'Best app ever',
    type: 'keyword',
    version: 1
});

// Global audit log
const auditLog: LogEntry[] = [];

/**
 * Updates a metadata chunk.
 * Creates a new entry with an incremented version rather than mutating the old one.
 */
async function updateMetadataChunk(
    vectorId: string, 
    newText: string, 
    reason: string
): Promise<MetadataChunk | null> {
    const existing = mockDatabase.get(vectorId);
    
    if (!existing) {
        console.error(`Vector ID ${vectorId} not found.`);
        return null;
    }

    // Simulate DB operation latency
    await new Promise(resolve => setTimeout(resolve, 100));

    // Create new version data
    const newVectorId = `${vectorId}-v${existing.version + 1}`;
    const updatedChunk: MetadataChunk = {
        ...existing,
        vectorId: newVectorId,
        text: newText,
        version: existing.version + 1
    };

    // Save new version
    mockDatabase.set(newVectorId, updatedChunk);
    
    // Log the change
    await logRejectionFix(vectorId, updatedChunk, reason);

    return updatedChunk;
}

/**
 * Logs the transition between vector IDs for audit trails.
 */
async function logRejectionFix(
    oldVectorId: string, 
    newChunk: MetadataChunk, 
    reason: string
): Promise<void> {
    const logEntry: LogEntry = {
        timestamp: new Date(),
        oldVectorId: oldVectorId,
        newVectorId: newChunk.vectorId,
        reason: reason
    };

    auditLog.push(logEntry);
    console.log('Audit Log Updated:', logEntry);
}

// Execution Simulation
(async () => {
    console.log('--- Starting Metadata Update ---');
    console.log('Original:', mockDatabase.get(initialId));

    // Update the "Best app ever" keyword to something compliant
    const result = await updateMetadataChunk(
        initialId, 
        'Efficient productivity tool', 
        'Guideline 2.3.1: Removed spammy keywords'
    );

    console.log('--- Update Complete ---');
    console.log('New Version:', result);
    console.log('Full Audit Log:', JSON.stringify(auditLog, null, 2));
})();
