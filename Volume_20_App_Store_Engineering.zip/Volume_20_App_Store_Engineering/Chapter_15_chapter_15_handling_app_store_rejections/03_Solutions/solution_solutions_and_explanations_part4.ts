/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// RejectionSimulator.tsx
'use client';

import { useState } from 'react';

type SimulationResult = {
    status: 'Pass' | 'Reject';
    guideline?: string;
    explanation?: string;
};

export default function RejectionSimulator() {
    // State for inputs
    const [appDescription, setAppDescription] = useState('');
    const [keywords, setKeywords] = useState('');
    const [hasInAppPurchases, setHasInAppPurchases] = useState(false);
    const [containsUserGeneratedContent, setContainsUserGeneratedContent] = useState(false);

    // State for result
    const [result, setResult] = useState<SimulationResult | null>(null);

    // 3. Logic (Heuristic Rules)
    const runSimulation = () => {
        // Reset result
        let newResult: SimulationResult = { status: 'Pass' };

        // Rule 1: Description length
        if (appDescription.length < 50) {
            newResult = {
                status: 'Reject',
                guideline: 'Guideline 2.3.1 (Metadata)',
                explanation: 'App description is too short. It must be descriptive enough to inform users.'
            };
        }
        // Rule 2: Keyword spamming
        else if (keywords.toLowerCase().includes('free') || keywords.toLowerCase().includes('best')) {
            newResult = {
                status: 'Reject',
                guideline: 'Guideline 2.3.1 (Keyword Spamming)',
                explanation: 'Keywords contain prohibited terms like "free" or "best".'
            };
        }
        // Rule 3: IAP Disclosure
        else if (hasInAppPurchases && !appDescription.toLowerCase().includes('in-app purchases')) {
            newResult = {
                status: 'Reject',
                guideline: 'Guideline 3.1.1 (In-App Purchases)',
                explanation: 'App description must disclose IAP functionality.'
            };
        }
        // Rule 4: User Generated Content
        else if (containsUserGeneratedContent && !appDescription.toLowerCase().includes('user-generated content')) {
            newResult = {
                status: 'Reject',
                guideline: 'Guideline 1.2 (User Data)',
                explanation: 'Apps with UGC must describe this in the description.'
            };
        }

        setResult(newResult);
    };

    // 4. Output & Visualization
    return (
        <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg font-sans">
            <h1 className="text-2xl font-bold mb-4 text-gray-800">App Store Rejection Simulator</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Input Section */}
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">App Description</label>
                        <textarea 
                            className="mt-1 block w-full border border-gray-300 rounded-md p-2 text-sm"
                            rows={4}
                            value={appDescription}
                            onChange={(e) => setAppDescription(e.target.value)}
                            placeholder="Describe your app..."
                        />
                        <p className="text-xs text-gray-500 mt-1">Length: {appDescription.length} chars (Min 50)</p>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">Keywords (comma separated)</label>
                        <input 
                            type="text"
                            className="mt-1 block w-full border border-gray-300 rounded-md p-2 text-sm"
                            value={keywords}
                            onChange={(e) => setKeywords(e.target.value)}
                            placeholder="productivity, tool..."
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                            <input 
                                type="checkbox" 
                                checked={hasInAppPurchases}
                                onChange={(e) => setHasInAppPurchases(e.target.checked)}
                            />
                            <span className="text-sm text-gray-700">Has In-App Purchases</span>
                        </label>

                        <label className="flex items-center space-x-2">
                            <input 
                                type="checkbox" 
                                checked={containsUserGeneratedContent}
                                onChange={(e) => setContainsUserGeneratedContent(e.target.checked)}
                            />
                            <span className="text-sm text-gray-700">Contains User-Generated Content</span>
                        </label>
                    </div>

                    <button 
                        onClick={runSimulation}
                        className="w-full bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700 transition font-semibold"
                    >
                        Simulate Review
                    </button>
                </div>

                {/* Visualization Section */}
                <div className="flex flex-col justify-center items-center">
                    {result ? (
                        <div className={`p-6 rounded-lg border-4 w-full text-center transition-all duration-300 transform hover:scale-105
                            ${result.status === 'Pass' 
                                ? 'bg-green-50 border-green-500 text-green-800' 
                                : 'bg-red-50 border-red-500 text-red-800'}`}
                        >
                            <div className="text-4xl font-bold mb-2">
                                {result.status === 'Pass' ? '✓ PASS' : '✗ REJECT'}
                            </div>
                            
                            {result.status === 'Reject' && (
                                <div className="mt-2 text-left">
                                    <div className="font-bold border-b border-red-200 pb-1 mb-2">
                                        {result.guideline}
                                    </div>
                                    <p className="text-sm">{result.explanation}</p>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="text-gray-400 text-center">
                            <p>Enter details and click Simulate to see the result.</p>
                        </div>
                    )}
                </div>
            </div>

            {/* 5. Visualization: Mermaid Diagram (Represented as Code Block) */}
            <div className="mt-8 p-4 bg-gray-100 rounded border">
                <h3 className="font-bold mb-2">Logic Flow Diagram (Mermaid)</h3>
                <div className="text-xs font-mono bg-white p-2 rounded overflow-x-auto">
                    <pre>{`
graph TD
    A[Start Simulation] --> B{Desc Length < 50?}
    B -- Yes --> C[Reject: Guideline 2.3.1]
    B -- No --> D{Contains 'free'/'best'?}
    D -- Yes --> C
    D -- No --> E{IAP Checked & No Disclosure?}
    E -- Yes --> F[Reject: Guideline 3.1.1]
    E -- No --> G{UGC Checked & No Disclosure?}
    G -- Yes --> H[Reject: Guideline 1.2]
    G -- No --> I[Pass]
                    `}</pre>
                </div>
            </div>
        </div>
    );
}
