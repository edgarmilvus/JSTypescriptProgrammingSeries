/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/services/RevenueCatService.ts

import Purchases, { 
  PurchasesPackage, 
  PurchasesOffering,
  CustomerInfo 
} from '@revenuecat/purchases-react-native';

/**
 * @description Configuration interface for RevenueCat initialization.
 * @property {string} apiKey - The public API key from the RevenueCat dashboard.
 * @property {string} appUserID - Optional unique identifier for the user (defaults to anonymous).
 */
interface RevenueCatConfig {
  apiKey: string;
  appUserID?: string;
}

/**
 * @class RevenueCatService
 * @description A singleton service wrapper for RevenueCat Purchases SDK.
 * Handles initialization, product fetching, and purchase logic.
 */
class RevenueCatService {
  private static instance: RevenueCatService;
  
  // Flag to prevent multiple initializations
  private isInitialized: boolean = false;

  private constructor() {}

  /**
   * @description Get the singleton instance of the service.
   */
  public static getInstance(): RevenueCatService {
    if (!RevenueCatService.instance) {
      RevenueCatService.instance = new RevenueCatService();
    }
    return RevenueCatService.instance;
  }

  /**
   * @description Initializes the RevenueCat SDK.
   * Must be called once early in the app lifecycle (e.g., App.tsx).
   * @param {RevenueCatConfig} config - Configuration object.
   */
  public async initialize(config: RevenueCatConfig): Promise<void> {
    if (this.isInitialized) {
      console.warn('[RevenueCat] SDK is already initialized.');
      return;
    }

    try {
      // Configure the SDK with the API Key
      // Note: In a real app, 'configure' handles platform-specific setup (iOS/Android)
      await Purchases.configure({
        apiKey: config.apiKey,
        appUserID: config.appUserID ?? undefined, // undefined allows RevenueCat to handle anonymous IDs
      });

      // Optional: Set attributes for analytics
      await Purchases.setAttributes({ 
        "$email": "user@example.com" // Example attribute
      });

      this.isInitialized = true;
      console.log('[RevenueCat] SDK Initialized successfully.');
    } catch (error) {
      console.error('[RevenueCat] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * @description Fetches the current offering (paywall products) from RevenueCat.
   * This is where you define which products to display to the user.
   * @returns {PurchasesOffering | null} The current offering containing packages.
   */
  public async fetchOfferings(): Promise<PurchasesOffering | null> {
    if (!this.isInitialized) {
      throw new Error('[RevenueCat] SDK not initialized. Call initialize() first.');
    }

    try {
      const offerings = await Purchases.getOfferings();
      
      // 'current' is the offering configured as "Current" in the RevenueCat dashboard
      if (offerings.current) {
        console.log('[RevenueCat] Offerings fetched:', offerings.current.identifier);
        return offerings.current;
      }
      
      return null;
    } catch (error) {
      console.error('[RevenueCat] Failed to fetch offerings:', error);
      return null;
    }
  }

  /**
   * @description Handles the purchase flow for a specific package.
   * @param {PurchasesPackage} pkg - The package to purchase (e.g., from fetchOfferings).
   * @returns {Promise<CustomerInfo>} Updated customer info upon success.
   */
  public async makePurchase(pkg: PurchasesPackage): Promise<CustomerInfo> {
    if (!this.isInitialized) {
      throw new Error('[RevenueCat] SDK not initialized.');
    }

    try {
      // Initiate the purchase flow. RevenueCat handles the OS native purchase dialog.
      const { customerInfo } = await Purchases.purchasePackage(pkg);

      // Check if the purchase was successful
      if (customerInfo.entitlements.active['pro_access']) { 
        // 'pro_access' is an example entitlement ID configured in RevenueCat
        console.log('[RevenueCat] Purchase successful! Access granted.');
        return customerInfo;
      } else {
        throw new Error('Purchase completed but entitlement not found.');
      }
    } catch (error: any) {
      // Handle user cancellation
      if (!error.userCancelled) {
        console.error('[RevenueCat] Purchase error:', error);
        throw error;
      }
      console.log('[RevenueCat] Purchase cancelled by user.');
      throw error;
    }
  }

  /**
   * @description Checks the current user's subscription status.
   * Useful for gating content on app launch.
   */
  public async checkSubscriptionStatus(): Promise<boolean> {
    try {
      const customerInfo = await Purchases.getCustomerInfo();
      // Check if the 'pro_access' entitlement is active
      return customerInfo.entitlements.active['pro_access']?.isActive ?? false;
    } catch (error) {
      console.error('[RevenueCat] Error checking status:', error);
      return false;
    }
  }
}

export default RevenueCatService;
