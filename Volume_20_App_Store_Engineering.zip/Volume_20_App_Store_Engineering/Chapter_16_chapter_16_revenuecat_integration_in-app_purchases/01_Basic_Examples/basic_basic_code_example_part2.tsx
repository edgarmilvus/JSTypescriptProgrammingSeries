/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: src/components/PaywallButton.tsx
// A simple React component consuming the service.

import React, { useState, useEffect } from 'react';
import { View, Text, Button, ActivityIndicator, Alert } from 'react-native';
import RevenueCatService from '../services/RevenueCatService';
import { PurchasesPackage } from '@revenuecat/purchases-react-native';

const revenueCatService = RevenueCatService.getInstance();

export const PaywallButton: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [proPackage, setProPackage] = useState<PurchasesPackage | null>(null);

  useEffect(() => {
    // Fetch products on component mount
    const loadOfferings = async () => {
      setIsLoading(true);
      try {
        const offering = await revenueCatService.fetchOfferings();
        if (offering) {
          // Find the "monthly" package specifically
          const monthlyPkg = offering.availablePackages.find(
            (pkg) => pkg.identifier === '$rc_monthly'
          );
          setProPackage(monthlyPkg || null);
        }
      } catch (error) {
        console.error("Failed to load offerings", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadOfferings();
  }, []);

  const handlePurchase = async () => {
    if (!proPackage) return;

    setIsLoading(true);
    try {
      await revenueCatService.makePurchase(proPackage);
      Alert.alert("Success", "You are now a Pro member!");
    } catch (error: any) {
      if (!error.userCancelled) {
        Alert.alert("Error", "Could not complete purchase.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) return <ActivityIndicator />;

  return (
    <View style={{ padding: 20 }}>
      {proPackage ? (
        <>
          <Text>Unlock Pro Features</Text>
          <Text>Price: {proPackage.product.priceString}</Text>
          <Button title="Subscribe Now" onPress={handlePurchase} />
        </>
      ) : (
        <Text>No products available.</Text>
      )}
    </View>
  );
};
