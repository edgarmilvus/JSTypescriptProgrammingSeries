/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/purchase-flow.ts
'use server';

import { createAI, getMutableAIState, streamUI } from 'ai-sdk';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { RevenueCat } from '@revenuecat/purchases-node'; // Hypothetical Node SDK wrapper
import { createClient } from '@supabase/supabase-js'; // For user data context

// 1. CONFIGURATION & INITIALIZATION
// We initialize RevenueCat server-side to ensure API keys are secure.
// We also define the Edge Runtime for low-latency AI streaming.
export const runtime = 'edge';

const rc = new RevenueCat({
  apiKey: process.env.REVENUECAT_API_KEY!,
  projectApiKey: process.env.REVENUECAT_PROJECT_API_KEY!,
});

// 2. STATE MANAGEMENT & AI CONTEXT
// We define the 'AI' state to persist the generated paywall text and transaction intent
// across the UI render cycle. This allows the client to display the streamed text.
const AI = createAI({
  actions: { generatePersonalizedOffer },
  initialAIState: {
    offerText: '',
    productId: '',
    discountApplied: false,
  },
  initialUIState: {
    isLoading: false,
    displayText: '',
    ctaLabel: 'Upgrade Now',
  },
});

/**
 * SERVER ACTION: generatePersonalizedOffer
 * 
 * This action performs a "Progressive Enhancement" flow:
 * 1. Fetches user context (e.g., usage stats) from Supabase.
 * 2. Uses the Vercel AI SDK to stream a personalized copy based on that context.
 * 3. Validates the RevenueCat product availability.
 * 4. Returns a checkout URL or error state.
 * 
 * @param {string} userId - The UUID of the current user.
 * @param {string} productId - The RevenueCat product ID (e.g., 'pro_monthly').
 */
async function generatePersonalizedOffer(userId: string, productId: string) {
  'use server';

  // --- Step A: User Context Fetching ---
  // Real-world logic: Fetch usage data to inform the AI.
  const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_KEY!);
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('usage_tier, last_login, feature_flags')
    .eq('id', userId)
    .single();

  // --- Step B: AI Generation (Edge Runtime) ---
  // We use 'streamUI' to generate dynamic text. The prompt injects user data.
  const aiState = getMutableAIState<typeof AI>();
  
  const result = await streamUI({
    model: openai('gpt-4-turbo'),
    prompt: `
      You are a helpful sales assistant. 
      User Usage Tier: ${profile?.usage_tier || 'free'}
      Last Login: ${profile?.last_login || 'unknown'}
      
      Write a short, compelling paragraph (max 2 sentences) convincing this user 
      to upgrade to the ${productId} plan. Highlight a specific benefit related to their usage.
    `,
    text: ({ content }) => {
      // Update the AI state with the generated text
      aiState.update({
        ...aiState.get(),
        offerText: content,
        productId: productId,
      });
      return content;
    },
  });

  // --- Step C: RevenueCat Integration ---
  // Once the text is generated, we prepare the transaction.
  // We check if the user is eligible for a trial or discount via RevenueCat logic.
  try {
    // Fetch customer info to see if they have an active subscription or entitlement
    const customerInfo = await rc.getCustomerInfo(userId);

    // Logic: If they already have 'pro', return early.
    if (customerInfo.entitlements.active['pro']) {
      return {
        status: 'error',
        message: 'You are already subscribed!',
      };
    }

    // Generate an "Off-Platform" URL (iOS/Android/Web) or a direct Stripe link
    // depending on your RevenueCat configuration.
    const makePurchaseURL = await rc.getMakePurchaseURL({
      appUserID: userId,
      productId: productId,
      // Optional: Inject a discount code if the AI decided it was a high-churn risk user
      discountCode: profile?.usage_tier === 'power_user' ? 'WELCOME_BACK_20' : undefined,
    });

    // Update state with the final URL
    aiState.update({
      ...aiState.get(),
      checkoutUrl: makePurchaseURL,
    });

    return {
      status: 'success',
      checkoutUrl: makePurchaseURL,
      generatedText: result.value,
    };

  } catch (error) {
    console.error('RevenueCat Error:', error);
    return {
      status: 'error',
      message: 'Failed to initialize purchase session.',
    };
  }
}

// 3. CLIENT COMPONENT WRAPPER (Conceptual)
// This would be used in your UI to trigger the action and display the stream.
/*
'use client';
import { useAIState, useUIState, useActions } from 'ai/rsc';

export function SmartPaywall() {
  const [uiState, setUiState] = useUIState<typeof AI>();
  const [aiState] = useAIState<typeof AI>();
  const { generatePersonalizedOffer } = useActions();

  const handleUpgrade = async () => {
    setUiState((prev) => ({ ...prev, isLoading: true }));
    
    // Trigger the server action
    const response = await generatePersonalizedOffer('user_123', 'pro_monthly');
    
    if (response.status === 'success') {
      // Progressive Enhancement: If JS is enabled, we can redirect immediately
      // or show a custom modal. If not, the form submits naturally.
      window.location.href = response.checkoutUrl;
    }
    
    setUiState((prev) => ({ ...prev, isLoading: false }));
  };

  return (
    <div className="p-6 border rounded-lg">
      <div className="mb-4 min-h-[60px]">
        {uiState.isLoading ? "Generating offer..." : (aiState.offerText || "Click to see your offer.")}
      </div>
      <button onClick={handleUpgrade} disabled={uiState.isLoading}>
        {uiState.isLoading ? 'Processing...' : uiState.ctaLabel}
      </button>
    </div>
  );
}
*/
