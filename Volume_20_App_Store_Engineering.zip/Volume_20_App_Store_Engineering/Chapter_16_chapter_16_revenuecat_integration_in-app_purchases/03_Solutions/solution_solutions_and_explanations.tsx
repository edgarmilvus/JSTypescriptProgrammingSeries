/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

// 1. Define Interfaces
interface MockPackage {
  identifier: string;
  price: string;
  description: string;
}

interface MockOffering {
  identifier: string;
  packages: MockPackage[];
}

interface PurchaseResult {
  success: boolean;
  error?: string;
}

// 2. Mock Data & Functions (Simulating RevenueCat SDK)
const fetchMockOfferings = async (): Promise<MockOffering> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    identifier: 'default_offer',
    packages: [
      { identifier: 'monthly_sub', price: '$4.99', description: 'Monthly Subscription' },
      { identifier: 'lifetime', price: '$49.99', description: 'Lifetime Access' },
    ],
  };
};

const mockPurchasePackage = async (packageId: string, simulateError: boolean): Promise<PurchaseResult> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (simulateError) {
    return { success: false, error: 'User cancelled purchase' };
  }
  return { success: true };
};

// 3. Component Implementation
interface PaywallProps {
  simulateError?: boolean;
}

export const SubscriptionPaywall: React.FC<PaywallProps> = ({ simulateError = false }) => {
  const [offerings, setOfferings] = useState<MockOffering | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  // useTransition for non-blocking UI updates during purchase
  const [isPending, startTransition] = useTransition();

  // Fetch data on mount
  React.useEffect(() => {
    fetchMockOfferings()
      .then(setOfferings)
      .catch(() => setError('Failed to load products'))
      .finally(() => setLoading(false));
  }, []);

  const handlePurchase = (packageId: string) => {
    setError(null);
    
    startTransition(async () => {
      const result = await mockPurchasePackage(packageId, simulateError);
      
      if (!result.success) {
        setToast(`Error: ${result.error}`);
        // Clear toast after 3 seconds
        setTimeout(() => setToast(null), 3000);
      } else {
        setToast('Purchase Successful!');
        setTimeout(() => setToast(null), 3000);
      }
    });
  };

  if (loading) return <div className="loading-spinner">Loading Products...</div>;
  if (error) return <div className="error-banner">{error}</div>;

  return (
    <div className="paywall-container">
      <h2>Premium Access</h2>
      <div className="products-grid">
        {offerings?.packages.map((pkg) => (
          <div key={pkg.identifier} className="product-card">
            <h3>{pkg.description}</h3>
            <p>{pkg.price}</p>
            <button
              onClick={() => handlePurchase(pkg.identifier)}
              disabled={isPending} // Disable during transition
            >
              {isPending ? 'Processing...' : 'Buy Now'}
            </button>
          </div>
        ))}
      </div>

      {/* Non-blocking Toast Notification */}
      {toast && (
        <div className={`toast ${toast.includes('Error') ? 'error' : 'success'}`}>
          {toast}
        </div>
      )}
    </div>
  );
};
