/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Input Types
interface RawSubscription {
  expiryDate: Date | null;
  isActive: boolean;
}

interface RawCustomerInfo {
  subscriptions: RawSubscription[];
  entitlements: string[];
}

// 2. Define Output Discriminated Union
type CustomerStatus = 
  | { status: 'active'; expiryDate: Date }
  | { status: 'expired'; lastActiveDate: Date }
  | { status: 'non_subscriber' };

// 3. Type Guard Functions
function isActiveSubscription(info: RawCustomerInfo): info is RawCustomerInfo & { status: 'active' } {
  // Logic: Must have active subscriptions with a future expiry date
  return info.subscriptions.some(sub => 
    sub.isActive && sub.expiryDate && sub.expiryDate > new Date()
  );
}

function isExpiredSubscription(info: RawCustomerInfo): info is RawCustomerInfo & { status: 'expired' } {
  // Logic: Has subscriptions, but none are currently active or all are expired
  const hasSubscriptions = info.subscriptions.length > 0;
  const hasNoActive = !info.subscriptions.some(sub => 
    sub.isActive && sub.expiryDate && sub.expiryDate > new Date()
  );
  return hasSubscriptions && hasNoActive;
}

// 4. Processing Function
function processCustomerInfo(info: RawCustomerInfo): CustomerStatus {
  if (isActiveSubscription(info)) {
    // Find the nearest expiry date for the active status
    const expiryDate = info.subscriptions
      .filter(sub => sub.isActive && sub.expiryDate)
      .map(sub => sub.expiryDate as Date)
      .sort((a, b) => a.getTime() - b.getTime())[0];
      
    return { status: 'active', expiryDate };
  }

  if (isExpiredSubscription(info)) {
    // Find the latest expiry date for the expired status
    const lastActiveDate = info.subscriptions
      .filter(sub => sub.expiryDate)
      .map(sub => sub.expiryDate as Date)
      .sort((a, b) => b.getTime() - a.getTime())[0];
      
    return { status: 'expired', lastActiveDate };
  }

  return { status: 'non_subscriber' };
}

// 5. Usage Example (React Component)
const UserDashboard = ({ info }: { info: RawCustomerInfo }) => {
  const status = processCustomerInfo(info);

  switch (status.status) {
    case 'active':
      return <div>Premium Dashboard (Expires: {status.expiryDate.toLocaleDateString()})</div>;
    case 'expired':
      return <div>Your subscription expired on {status.lastActiveDate.toLocaleDateString()}. Please renew.</div>;
    case 'non_subscriber':
      return <div>Upgrade Prompt</div>;
    default:
      return <div>Loading...</div>;
  }
};
