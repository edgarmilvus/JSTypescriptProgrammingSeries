/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface RevenueEvent {
  productId: string;
  price: number;
  currency: string;
  transactionId: string;
}

class AnalyticsService {
  private queue: RevenueEvent[] = [];
  private processedIds: Set<string> = new Set();
  private isProcessing = false;

  // 1. Idempotency Check & Queueing
  async trackRevenue(event: RevenueEvent): Promise<void> {
    if (this.processedIds.has(event.transactionId)) {
      console.log('Duplicate transaction detected, skipping.');
      return;
    }

    this.processedIds.add(event.transactionId);
    this.queue.push(event);
    
    if (!this.isProcessing) {
      this.processQueue();
    }
  }

  // 2. Queue Processing with Exponential Backoff
  private async processQueue(): Promise<void> {
    this.isProcessing = true;

    while (this.queue.length > 0) {
      const event = this.queue[0]; // Peek at the first item
      let success = false;
      let attempts = 0;
      const maxAttempts = 5;
      let delay = 1000; // Initial delay 1s

      while (!success && attempts < maxAttempts) {
        try {
          success = await this.sendToServer(event);
          if (!success) throw new Error('Network failed');
        } catch (error) {
          attempts++;
          if (attempts >= maxAttempts) {
            console.error(`Failed to send event ${event.transactionId} after ${maxAttempts} attempts. Dropping.`);
            this.queue.shift(); // Remove from queue
            this.processedIds.delete(event.transactionId); // Allow retry later if needed
            break;
          }
          
          // Exponential Backoff
          await new Promise(resolve => setTimeout(resolve, delay));
          delay *= 2; // Double the delay
        }
      }

      if (success) {
        this.queue.shift(); // Remove successful event
      }
    }

    this.isProcessing = false;
  }

  // 3. Mock Network Call
  private async sendToServer(event: RevenueEvent): Promise<boolean> {
    // Simulate random network failure (30% chance of failure)
    return new Promise((resolve) => {
      setTimeout(() => {
        const isSuccessful = Math.random() > 0.3;
        console.log(`Sending ${event.transactionId}: ${isSuccessful ? 'Success' : 'Failure'}`);
        resolve(isSuccessful);
      }, 500);
    });
  }
}

// Usage
const analytics = new AnalyticsService();
// Simulate Purchase Event
analytics.trackRevenue({
  productId: 'monthly_sub',
  price: 4.99,
  currency: 'USD',
  transactionId: 'txn_12345'
});
