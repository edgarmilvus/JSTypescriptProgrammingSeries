/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { revalidatePath } from 'next/cache';

// Mock types
type VerificationResult = 
  | { status: 'VALID'; accessLevel: 'premium' }
  | { status: 'INVALID' }
  | { status: 'GRACE_PERIOD'; validUntil: Date };

// Mock in-memory cache (In production, use Redis)
const gracePeriodCache = new Map<string, Date>();

// 1. Server Action
export async function verifyPurchase(receipt: string): Promise<VerificationResult> {
  // Simulate RevenueCat API Call
  const simulateNetworkFailure = Math.random() > 0.7; // 30% chance of failure

  if (!simulateNetworkFailure) {
    // Success: Update cache and return valid
    const validUntil = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h
    gracePeriodCache.set(receipt, validUntil);
    return { status: 'VALID', accessLevel: 'premium' };
  }

  // Failure: Check Grace Period
  const cachedValidUntil = gracePeriodCache.get(receipt);
  
  if (cachedValidUntil && cachedValidUntil > new Date()) {
    return { 
      status: 'GRACE_PERIOD', 
      validUntil: cachedValidUntil 
    };
  }

  return { status: 'INVALID' };
}
