/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// Client Component
'use client';

import { useTransition } from 'react';
import { verifyPurchase } from './actions';

export function PurchaseVerifier() {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<VerificationResult | null>(null);

  const handleVerify = (receipt: string) => {
    startTransition(async () => {
      const res = await verifyPurchase(receipt);
      setResult(res);
      
      // If Grace Period, trigger background retry
      if (res.status === 'GRACE_PERIOD') {
        console.log('Retrying validation in background...');
        // Logic to retry silently could go here
      }
    });
  };

  return (
    <div>
      <button onClick={() => handleVerify('receipt_token_abc')} disabled={isPending}>
        {isPending ? 'Verifying...' : 'Verify Purchase'}
      </button>

      {result && (
        <div className="status-box">
          {result.status === 'VALID' && <p>Premium Access Granted!</p>}
          {result.status === 'GRACE_PERIOD' && (
            <p style={{ color: 'orange' }}>
              Temporary Access (Valid until {result.validUntil.toLocaleTimeString()})
            </p>
          )}
          {result.status === 'INVALID' && <p style={{ color: 'red' }}>Access Denied</p>}
        </div>
      )}
    </div>
  );
}
