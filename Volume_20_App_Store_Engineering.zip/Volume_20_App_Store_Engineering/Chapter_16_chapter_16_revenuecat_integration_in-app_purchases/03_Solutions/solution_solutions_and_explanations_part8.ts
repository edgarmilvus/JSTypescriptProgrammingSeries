/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

digraph PurchaseFlow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#3498db"];
    
    // States
    IDLE [fillcolor="#e1f5fe"];
    LOADING [fillcolor="#fff9c4"];
    PURCHASING [fillcolor="#ffe0b2"];
    SUCCESS [fillcolor="#c8e6c9", shape="doublecircle"];
    ERROR [fillcolor="#ffcdd2"];
    
    // Transitions
    IDLE -> LOADING [label="BUY_CLICKED"];
    LOADING -> PURCHASING [label="Fetch Offerings\nSuccess"];
    
    // Success Path
    PURCHASING -> SUCCESS [label="PURCHASE_SUCCESS"];
    SUCCESS -> IDLE [label="RESET"];
    
    // Error Handling & Retry Logic
    PURCHASING -> ERROR [label="PURCHASE_FAILURE\n(User Cancelled)"];
    PURCHASING -> ERROR [label="PURCHASE_FAILURE\n(Network Error)"];
    
    // User Cancelled returns to Idle immediately
    ERROR -> IDLE [label="User Cancelled\n(Clear Error)"];
    
    // Network Error Retry Loop
    // Note: In a real diagram, we might visualize the delay, 
    // but here we show the state transition.
    ERROR -> LOADING [label="RETRY\n(Network Error Only)"];
}
