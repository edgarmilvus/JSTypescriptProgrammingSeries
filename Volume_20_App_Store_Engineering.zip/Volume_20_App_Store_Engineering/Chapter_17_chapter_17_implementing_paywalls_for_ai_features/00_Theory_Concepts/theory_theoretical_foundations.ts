/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

<dot_diagram>
digraph PaywallArchitecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#E0E0E0"];

    subgraph cluster_client {
        label="Client (Mobile App)";
        style="rounded,bold";
        color="#4A90E2";

        UI [label="Paywall UI / Feature Flag Check", fillcolor="#D1E8FF"];
        StoreKit [label="StoreKit / Google Play", fillcolor="#FFD1D1"];
        JWT [label="Entitlement Token (JWT)", fillcolor="#D1FFD1"];
        AI_Chat [label="AI Feature Interface", fillcolor="#FFF2CC"];
    }

    subgraph cluster_backend {
        label="Backend Services";
        style="rounded,bold";
        color="#50C878";

        API_Gateway [label="API Gateway", fillcolor="#E0E0E0"];
        Verifier [label="Receipt Verifier Service", fillcolor="#FFFACD"];
        DB [label="User Entitlement DB", fillcolor="#E0E0E0"];
        Flag_Service [label="Remote Config / Feature Flags", fillcolor="#E0E0E0"];
        AI_Microservice [label="AI Agent Microservice", fillcolor="#FFF2CC"];
    }

    subgraph cluster_external {
        label="External Services";
        style="rounded,bold";
        color="#FFA500";

        AppStore [label="Apple/Google Servers", fillcolor="#F0F0F0"];
        Pinecone [label="Pinecone Index", fillcolor="#F0F0F0"];
        LLM [label="LLM Provider", fillcolor="#F0F0F0"];
    }

    /* Flow 1: Purchase & Verification */
    StoreKit -> AppStore [label="1. Receipt Generation"];
    UI -> Verifier [label="2. Send Receipt", style=dashed];
    AppStore -> Verifier [label="3. Validate Receipt", style=dashed];
    Verifier -> DB [label="4. Store Entitlement"];
    Verifier -> JWT [label="5. Issue Token"];

    /* Flow 2: Feature Access */
    UI -> Flag_Service [label="6. Fetch Config"];
    Flag_Service -> UI [label="7. Enable/Disable UI"];

    /* Flow 3: AI Execution */
    AI_Chat -> API_Gateway [label="8. Request Inference (with JWT)"];
    API_Gateway -> Verifier [label="9. Verify Token"];
    API_Gateway -> AI_Microservice [label="10. Route Request"];
    AI_Microservice -> Pinecone [label="11. Query Vectors (Namespace: Pro)"];
    AI_Microservice -> LLM [label="12. Generate Response"];
    AI_Microservice -> AI_Chat [label="13. Return Result"];
}
</dot_diagram>
