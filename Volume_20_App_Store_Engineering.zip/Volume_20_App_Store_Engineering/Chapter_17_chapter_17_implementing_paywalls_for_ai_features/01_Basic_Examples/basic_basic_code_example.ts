/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic Paywall Verification Server for AI Features
 * 
 * This script simulates a backend endpoint that validates a purchase receipt
 * before allowing access to an expensive AI inference operation.
 * 
 * Prerequisites:
 * - Node.js (v18+ recommended for native fetch support)
 * - TypeScript installed
 * 
 * To Run:
 * 1. Save as `paywall-server.ts`
 * 2. Compile: `tsc paywall-server.ts --target ES2022 --module ESNext`
 * 3. Run: `node paywall-server.js`
 */

// --- 1. MOCK DATABASE & CONFIGURATION ---

/**
 * Represents a user's subscription status in our internal database.
 * In a real app, this would be a PostgreSQL or MongoDB entry.
 */
interface UserSubscription {
  userId: string;
  isPremium: boolean;
  expiresAt: number; // Unix timestamp
}

// Simulated database storage
const mockDatabase: Map<string, UserSubscription> = new Map();

// Mock Product ID for the "Pro AI Plan" (Apple/Google Store ID)
const PREMIUM_AI_PRODUCT_ID = "com.example.ai.pro.monthly";

/**
 * --- 2. CORE LOGIC: RECEIPT VALIDATION ---
 */

/**
 * Simulates the verification of a receipt token against Apple/Google servers.
 * 
 * In a production environment, you would use:
 * - Apple: `fetch('https://sandbox.itunes.apple.com/verifyReceipt')` (Sandbox) 
 *          or `https://buy.itunes.apple.com/verifyReceipt` (Production)
 * - Google: The Google Play Developer API to query purchase states.
 * 
 * @param receiptToken - The transaction receipt data provided by the client (StoreKit/PlayBilling).
 * @returns A Promise resolving to the validation result.
 */
async function verifyReceiptWithStore(receiptToken: string): Promise<{ isValid: boolean; productId: string; expiresAt: number }> {
  console.log(`[Server] Verifying receipt token: ${receiptToken.substring(0, 10)}...`);

  // SIMULATION: In reality, this is an async network request to Apple/Google.
  // We are mocking a successful validation for the specific product ID.
  return new Promise((resolve) => {
    setTimeout(() => {
      // Logic: Check if the receipt corresponds to our Premium AI product.
      // In reality, we would parse the `latest_receipt_info` from Apple's response.
      const isValid = receiptToken.startsWith("RECEIPT_") && receiptToken.includes("AI_PRO");
      
      if (isValid) {
        // Calculate expiry (e.g., 30 days from now)
        const expiresAt = Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60); 
        resolve({ isValid: true, productId: PREMIUM_AI_PRODUCT_ID, expiresAt });
      } else {
        resolve({ isValid: false, productId: "", expiresAt: 0 });
      }
    }, 500); // Simulate network latency
  });
}

/**
 * --- 3. API ENDPOINT HANDLER ---
 */

/**
 * Handles the request to unlock AI features.
 * 
 * @param userId - The authenticated user ID.
 * @param receiptToken - The raw receipt string from the mobile client.
 * @returns A promise resolving to the server response.
 */
async function handleAiFeatureRequest(userId: string, receiptToken: string) {
  try {
    // Step 1: Check if we already have a valid subscription in our DB (Optimization)
    const existingSubscription = mockDatabase.get(userId);
    
    if (existingSubscription && existingSubscription.expiresAt > Math.floor(Date.now() / 1000)) {
      console.log(`[Server] User ${userId} has active local subscription.`);
      return { 
        status: "success", 
        message: "Access granted (Cached)", 
        accessLevel: "premium" 
      };
    }

    // Step 2: If no valid local record, verify the receipt with the Store
    const validation = await verifyReceiptWithStore(receiptToken);

    if (validation.isValid) {
      // Step 3: Update local database (Entitlement Gating)
      mockDatabase.set(userId, {
        userId,
        isPremium: true,
        expiresAt: validation.expiresAt
      });

      console.log(`[Server] User ${userId} subscription verified and saved.`);
      
      return {
        status: "success",
        message: "Access granted",
        accessLevel: "premium",
        expiresAt: validation.expiresAt
      };
    } else {
      // Receipt invalid or expired
      console.warn(`[Server] Verification failed for user ${userId}.`);
      return {
        status: "error",
        message: "Invalid or expired subscription receipt.",
        accessLevel: "free"
      };
    }
  } catch (error) {
    console.error("[Server] Error during verification:", error);
    return {
      status: "error",
      message: "Internal server error.",
      accessLevel: "free"
    };
  }
}

/**
 * --- 4. SIMULATION EXECUTION ---
 */

/**
 * Main function to simulate the flow.
 */
async function main() {
  console.log("--- Starting Paywall Verification Simulation ---\n");

  // Scenario A: User tries to access AI feature without a valid receipt
  console.log("1. Attempting access with INVALID receipt...");
  const responseA = await handleAiFeatureRequest("user_123", "INVALID_TOKEN");
  console.log("Response:", responseA);
  console.log("\n" + "-".repeat(30) + "\n");

  // Scenario B: User provides a valid receipt (purchased via App Store)
  console.log("2. Attempting access with VALID receipt...");
  const validReceiptToken = "RECEIPT_AI_PRO_987654321";
  const responseB = await handleAiFeatureRequest("user_456", validReceiptToken);
  console.log("Response:", responseB);
  console.log("\n" + "-".repeat(30) + "\n");

  // Scenario C: User tries again (should hit the DB cache)
  console.log("3. Attempting access again (should use local DB cache)...");
  const responseC = await handleAiFeatureRequest("user_456", validReceiptToken);
  console.log("Response:", responseC);
}

// Execute the simulation
main();
