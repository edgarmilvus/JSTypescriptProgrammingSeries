/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/pages/api/ai/verify-entitlement.ts
// Target: Next.js API Route (Server-side)
// Purpose: Secure verification of IAP receipts and dynamic unlocking of AI features.

import { NextApiRequest, NextApiResponse } from 'next';
import jwt from 'jsonwebtoken';
import { verifyAppleReceipt, verifyGooglePurchase } from '@/lib/payment-verifiers'; // Hypothetical external module
import { getUserSubscriptionStatus } from '@/lib/db'; // Hypothetical database adapter

/**
 * @interface EntitlementResponse
 * @description Standardized response structure for feature access checks.
 */
interface EntitlementResponse {
  hasAccess: boolean;
  expiresAt?: number; // Unix timestamp
  token?: string; // Signed JWT for client-side optimistic updates
  reason?: string; // Debugging context (e.g., 'no_active_subscription')
}

/**
 * @description Main API Handler
 * Verifies the payment receipt stored in the user's DB record against the App Store/Play Store.
 * 
 * @param req NextApiRequest - Contains the user ID (extracted from JWT cookie or session)
 * @param res NextApiResponse - Returns the entitlement status
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<EntitlementResponse>
) {
  // 1. HTTP Method Guarding
  if (req.method !== 'POST') {
    return res.status(405).json({ hasAccess: false, reason: 'Method not allowed' });
  }

  // 2. Identity Resolution (Simulated Session Check)
  // In production, decode the NextAuth/JWT token from cookies/headers.
  const userId = req.headers['x-user-id'] as string; 
  if (!userId) {
    return res.status(401).json({ hasAccess: false, reason: 'Unauthorized' });
  }

  try {
    // 3. Database Retrieval
    // Fetch the latest receipt data and subscription state from the local database.
    // This avoids hitting Apple/Google APIs on every single request (rate limiting).
    const userSub = await getUserSubscriptionStatus(userId);

    if (!userSub || !userSub.latestReceipt) {
      return res.status(200).json({ 
        hasAccess: false, 
        reason: 'no_subscription_found' 
      });
    }

    let isValid = false;
    let expiresAt = 0;

    // 4. Platform-Specific Server-Side Verification
    // We validate the receipt against the App Store or Google Play sandbox/production endpoints.
    // This is the "Source of Truth" check.
    if (userSub.platform === 'ios') {
      const verification = await verifyAppleReceipt(userSub.latestReceipt);
      isValid = verification.valid;
      expiresAt = verification.expirationDate;
    } else if (userSub.platform === 'android') {
      const verification = await verifyGooglePurchase(userSub.latestReceipt);
      isValid = verification.valid;
      expiresAt = verification.expirationDate;
    }

    // 5. Feature Flag Gating (Logic Layer)
    // Even if valid, check if the specific AI feature is enabled for this plan tier.
    const isFeatureEnabled = userSub.planTier === 'pro' || userSub.planTier === 'enterprise';

    if (isValid && isFeatureEnabled) {
      // 6. JWT Generation (Optimistic Client Unlocking)
      // We sign a short-lived token so the client can unlock the UI immediately 
      // without re-verifying on every button click (until token expiry).
      const token = jwt.sign(
        { 
          sub: userId, 
          feature: 'ai_advanced', 
          exp: Math.floor(Date.now() / 1000) + (60 * 60) // 1 hour expiry
        },
        process.env.JWT_SECRET!
      );

      return res.status(200).json({
        hasAccess: true,
        expiresAt,
        token
      });
    }

    // 7. Denial Logic
    return res.status(200).json({
      hasAccess: false,
      reason: isValid ? 'feature_not_in_plan' : 'receipt_invalid_expired'
    });

  } catch (error) {
    console.error('Entitlement Verification Error:', error);
    // Fail safe: Deny access on internal errors to prevent unauthorized usage.
    return res.status(500).json({ 
      hasAccess: false, 
      reason: 'internal_server_error' 
    });
  }
}
