/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// server.ts
import { Request, Response } from 'express';

// Mock type definitions for the external library response
interface AppleVerificationResponse {
  status: number;
  environment?: 'Sandbox' | 'Production';
  receipt?: {
    in_app?: Array<{
      product_id: string;
      transaction_id: string;
      expiration_date_ms?: string;
    }>;
  };
}

// Mock declaration for the helper library
declare module 'apple-receipt-verifier' {
  export function verifyReceipt(receiptData: string, isSandbox: boolean): Promise<AppleVerificationResponse>;
}

// Configuration
const TARGET_PRODUCT_ID = 'com.myapp.premium_ai_credits';

/**
 * API Route Handler for Purchase Verification
 */
export async function handlePurchaseVerification(req: Request, res: Response) {
  try {
    const { receiptData, transactionId } = req.body;

    if (!receiptData || !transactionId) {
      return res.status(400).json({ error: 'Missing receiptData or transactionId' });
    }

    // 1. Attempt verification against Production environment first
    let verification = await import('apple-receipt-verifier').then(m => 
      m.verifyReceipt(receiptData, false)
    );

    // 2. Handle Sandbox vs Production Environment Detection
    // Apple returns status 21007 if a sandbox receipt is sent to production endpoint
    if (verification.status === 21007) {
      // Retry against Sandbox environment
      verification = await import('apple-receipt-verifier').then(m => 
        m.verifyReceipt(receiptData, true)
      );
    }

    // 3. Check if receipt is valid (Status 0 indicates success)
    if (verification.status !== 0) {
      return res.status(401).json({ error: 'Invalid receipt', appleStatus: verification.status });
    }

    // 4. Validate specific Product ID and Transaction ID
    const latestReceiptInfo = verification.receipt?.in_app || [];
    // Find the specific transaction or the latest subscription purchase
    const validPurchase = latestReceiptInfo.find(
      (item) => 
        item.product_id === TARGET_PRODUCT_ID && 
        item.transaction_id === transactionId
    );

    if (!validPurchase) {
      return res.status(400).json({ 
        valid: false, 
        error: 'Receipt does not match the required product or transaction ID' 
      });
    }

    // 5. Extract Expiration Date (if subscription)
    const expiresAt = validPurchase.expiration_date_ms 
      ? parseInt(validPurchase.expiration_date_ms, 10) 
      : null;

    // 6. Return structured entitlement object
    return res.status(200).json({
      valid: true,
      expiresAt: expiresAt
    });

  } catch (error) {
    console.error('Verification error:', error);
    return res.status(500).json({ error: 'Internal server error during validation' });
  }
}
