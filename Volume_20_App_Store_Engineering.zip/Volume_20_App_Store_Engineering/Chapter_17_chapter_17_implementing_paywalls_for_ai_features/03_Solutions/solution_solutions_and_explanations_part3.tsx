/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// AIPremiumGate.tsx
import React, { ReactNode } from 'react';
import { useEntitlement } from './EntitlementContext';

// 5. Paywall Modal Component
const PaywallModal = () => {
  // Mock handler signature
  const handlePurchase = () => {
    console.log('Initiating StoreKit purchase flow...');
  };

  const handleRestore = () => {
    console.log('Initiating restore purchases flow...');
  };

  return (
    <div className="paywall-overlay">
      <h2>Upgrade to Premium</h2>
      <p>Unlock unlimited AI Image Generation today.</p>
      <button onClick={handlePurchase}>Subscribe</button>
      <button onClick={handleRestore}>Restore Purchases</button>
    </div>
  );
};

// 6. The Gate Component
interface AIPremiumGateProps {
  children: ReactNode;
}

export const AIPremiumGate: React.FC<AIPremiumGateProps> = ({ children }) => {
  const { isPremium, isLoading } = useEntitlement();

  // Conditional Rendering Logic
  if (isLoading) {
    return <div className="skeleton-loader">Loading entitlement status...</div>;
  }

  if (isPremium) {
    // User is entitled, render the protected feature
    return <>{children}</>;
  }

  // User is not entitled, show the paywall
  return <PaywallModal />;
};
