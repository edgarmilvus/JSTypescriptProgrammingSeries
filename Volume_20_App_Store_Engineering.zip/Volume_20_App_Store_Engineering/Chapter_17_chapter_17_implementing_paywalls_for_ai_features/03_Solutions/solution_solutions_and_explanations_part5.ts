/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// paywallGraph.ts
import { StateGraph, Annotation, NodeInterrupt } from '@langchain/langgraph';

// 1. State Definition
const StateAnnotation = Annotation.Root({
  userId: Annotation<string>,
  userSegment: Annotation<'new' | 'returning'>,
  assignedVariant: Annotation<'A' | 'B' | null>({
    reducer: (curr, update) => update ?? curr,
    default: () => null,
  }),
  paywallContent: Annotation<{ title: string; cta: string } | null>({
    reducer: (curr, update) => update ?? curr,
    default: () => null,
  }),
});

// 2. Node: Assign Variant
const assignVariant = (state: typeof StateAnnotation.State) => {
  const { userSegment } = state;
  let assignedVariant: 'A' | 'B';

  if (userSegment === 'new') {
    // 50/50 split for new users
    assignedVariant = Math.random() < 0.5 ? 'A' : 'B';
  } else {
    // 70/30 split for returning users (70% B)
    assignedVariant = Math.random() < 0.7 ? 'B' : 'A';
  }

  return { assignedVariant };
};

// 3. Node: Load Variant A Content
const loadVariantA = () => {
  return {
    paywallContent: {
      title: "Unlock AI Power",
      cta: "Start Free Trial"
    }
  };
};

// 4. Node: Load Variant B Content
const loadVariantB = () => {
  return {
    paywallContent: {
      title: "Upgrade to Pro",
      cta: "Get 50% Off"
    }
  };
};

// 5. Graph Construction
const workflow = new StateGraph(StateAnnotation)
  .addNode('assignVariant', assignVariant)
  .addNode('loadVariantA', loadVariantA)
  .addNode('loadVariantB', loadVariantB)
  .addEdge('__start__', 'assignVariant') // Entry point
  .addConditionalEdges(
    'assignVariant',
    (state) => {
      // Route to the correct node based on the assigned variant
      return state.assignedVariant === 'A' ? 'loadVariantA' : 'loadVariantB';
    }
  )
  // End the graph after loading content
  .addEdge('loadVariantA', '__end__')
  .addEdge('loadVariantB', '__end__');

export const paywallGraph = workflow.compile();
