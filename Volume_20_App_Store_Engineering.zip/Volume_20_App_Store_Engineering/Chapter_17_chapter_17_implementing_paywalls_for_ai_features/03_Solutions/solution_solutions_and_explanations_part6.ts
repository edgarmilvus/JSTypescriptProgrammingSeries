/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface PaywallConfig {
  header: string;
  subheader: string;
  priceHighlight: boolean;
}

// useRemotePaywallConfig.ts
import { useState, useEffect } from 'react';
import * as Updates from 'expo-updates';

const DEFAULT_CONFIG: PaywallConfig = {
  header: "Unlock Premium AI",
  subheader: "Get unlimited access today",
  priceHighlight: true
};

export const useRemotePaywallConfig = () => {
  const [config, setConfig] = useState<PaywallConfig>(DEFAULT_CONFIG);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const checkForUpdates = async () => {
      try {
        // 1. Check for available updates
        const update = await Updates.checkForUpdateAsync();

        if (update.isAvailable) {
          // 2. Fetch the update
          await Updates.fetchUpdateAsync();
          
          // 3. Reload the app to apply changes immediately
          // In a real app, you might show a toast asking the user to restart
          await Updates.reloadAsync();
        } else {
          // No update available, keep default or existing config
          setConfig(DEFAULT_CONFIG);
        }
      } catch (error) {
        console.error('Error fetching remote config:', error);
        // Fallback to default on error
        setConfig(DEFAULT_CONFIG);
      } finally {
        setIsChecking(false);
      }
    };

    checkForUpdates();
  }, []);

  return { config, isChecking };
};
