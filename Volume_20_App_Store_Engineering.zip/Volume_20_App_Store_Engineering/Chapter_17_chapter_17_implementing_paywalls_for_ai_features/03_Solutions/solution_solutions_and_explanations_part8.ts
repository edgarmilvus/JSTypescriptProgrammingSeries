/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// pricingStrategy.ts

// 1. Type Definitions for Strategy
type Region = 'NA' | 'EU' | 'JP' | 'ROW';

interface Strategy {
  price: string;
  keywords: string[];
}

// 2. Function Implementation
export const getLocalizedPricingStrategy = (locale: string): Strategy => {
  // Determine Region based on Locale
  let region: Region = 'ROW'; // Default

  if (['en-US', 'en-CA'].includes(locale)) {
    region = 'NA';
  } else if (['de-DE', 'fr-FR'].includes(locale)) {
    region = 'EU';
  } else if (['ja-JP'].includes(locale)) {
    region = 'JP';
  }

  // Return Strategy based on Region
  switch (region) {
    case 'NA':
      return {
        price: '$9.99',
        keywords: ['AI', 'Productivity', 'Assistant']
      };
    case 'EU':
      // Specific logic for German vs French within EU
      if (locale === 'de-DE') {
        return {
          price: '€9.99',
          keywords: ['KI', 'Produktivität', 'Assistent']
        };
      }
      return {
        price: '€9.99',
        keywords: ['IA', 'Productivité', 'Assistant']
      };
    case 'JP':
      return {
        price: '¥1200',
        keywords: ['AI', '生産性', 'アシスタント']
      };
    case 'ROW':
    default:
      return {
        price: '$4.99',
        keywords: ['AI', 'Smart']
      };
  }
};
