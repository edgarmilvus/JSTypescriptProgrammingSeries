/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import Zod for schema validation
import { z } from 'zod';

/**
 * Represents the raw Apple App Store receipt data structure (simplified).
 * In production, this would come from Apple's verification endpoint.
 * @typedef {object} RawReceipt
 * @property {string} receiptId - Unique identifier for the receipt.
 * @property {string} productId - The in-app purchase product ID.
 * @property {number} purchaseDate - Timestamp of purchase (milliseconds since epoch).
 * @property {number} [quantity] - Number of items purchased (optional).
 */

/**
 * Zod schema for validating raw receipt data.
 * Defines shape, constraints, and infers TypeScript types.
 * - Ensures receiptId is a non-empty string.
 * - Ensures productId is a non-empty string matching a pattern (e.g., no special chars).
 * - Ensures purchaseDate is a positive integer (timestamp).
 * - Ensures quantity, if present, is a positive integer.
 * This schema bridges runtime validation with compile-time safety.
 */
const RawReceiptSchema = z.object({
  receiptId: z.string().min(1, "Receipt ID is required"),
  productId: z.string().min(1).regex(/^[a-zA-Z0-9_.-]+$/, "Product ID must be alphanumeric"),
  purchaseDate: z.number().int().positive("Purchase date must be a valid timestamp"),
  quantity: z.number().int().positive().optional(),
});

/**
 * Inferred TypeScript type from the Zod schema.
 * This provides compile-time type safety without manual definition.
 */
type RawReceipt = z.infer<typeof RawReceiptSchema>;

/**
 * Immutable state management: Represents the validated receipt state.
 * Once created, this object is never mutated. New copies are made for any changes.
 * This prevents side effects in concurrent environments (e.g., multiple IAP validations).
 */
interface ValidatedReceipt {
  readonly receiptId: string;
  readonly productId: string;
  readonly purchaseDate: Date; // Converted to Date object for easier handling
  readonly quantity: number;
  readonly validatedAt: Date; // Timestamp of validation for audit logging
}

/**
 * Validates and parses a raw Apple receipt.
 * Uses immutable state management: returns a new object without modifying input.
 * 
 * @param {RawReceipt} rawReceipt - The unvalidated receipt data from Apple's API.
 * @returns {ValidatedReceipt} - The immutable, validated receipt object.
 * @throws {Error} - If validation fails (e.g., invalid schema).
 * 
 * Under the hood:
 * 1. Zod validates the raw data at runtime, catching type mismatches or constraint violations.
 * 2. If valid, we create a new immutable object with converted types (e.g., timestamp to Date).
 * 3. No mutation occurs on `rawReceipt`; everything is copied or transformed immutably.
 */
function validateReceipt(rawReceipt: RawReceipt): ValidatedReceipt {
  // Step 1: Runtime validation using Zod schema.
  // This ensures data integrity before any business logic.
  const validatedData = RawReceiptSchema.parse(rawReceipt);

  // Step 2: Immutable transformation. Create a new object without modifying the input.
  // We convert purchaseDate (number) to Date for easier manipulation.
  // Use spread operator for shallow copying; for deep immutability, libraries like Immer could be used.
  const validatedReceipt: ValidatedReceipt = {
    receiptId: validatedData.receiptId,
    productId: validatedData.productId,
    purchaseDate: new Date(validatedData.purchaseDate), // Convert timestamp to Date
    quantity: validatedData.quantity ?? 1, // Default to 1 if not provided
    validatedAt: new Date(), // Current timestamp for audit
  };

  // Step 3: Return the immutable object. No further modifications allowed.
  return Object.freeze(validatedReceipt); // Freeze to enforce immutability at runtime
}

/**
 * Example usage: Simulating a SaaS backend endpoint for IAP validation.
 * In a real app, this would be an Express.js route or AWS Lambda handler.
 * 
 * This demonstrates the full flow:
 * 1. Receive raw data (e.g., from Apple's receipt verification API).
 * 2. Validate and return immutable state.
 * 3. Log for tax compliance (e.g., VAT calculation based on productId).
 */
function simulateIAPValidation() {
  // Mock raw receipt from Apple (hypothetical payload).
  const mockRawReceipt: RawReceipt = {
    receiptId: "abc123",
    productId: "premium_monthly",
    purchaseDate: Date.now(), // Current timestamp
    quantity: 1,
  };

  try {
    // Validate and get immutable receipt.
    const receipt = validateReceipt(mockRawReceipt);

    // Log for compliance (e.g., to a database for tax reporting).
    console.log("Validated Receipt:", receipt);
    console.log("Product:", receipt.productId);
    console.log("Purchase Date:", receipt.purchaseDate.toISOString());
    console.log("Quantity:", receipt.quantity);
    console.log("Validated At:", receipt.validatedAt.toISOString());

    // Attempting to mutate (for demonstration) will fail due to freeze.
    // receipt.quantity = 2; // This would throw in strict mode or be ignored.

  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error("Validation failed:", error.errors); // Detailed Zod errors
    } else {
      console.error("Unexpected error:", error);
    }
  }
}

// Run the example (for Node.js execution).
// In a real app, call this from an HTTP handler.
simulateIAPValidation();
