/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * advanced-tax-compliance-audit.ts
 * 
 * A Next.js API route handler that performs automated tax compliance auditing
 * for mobile/web hybrid SaaS revenue streams.
 * 
 * Context: Book 20, Chapter 18 - Apple/Google Tax Compliance
 * Objective: Automate the calculation of platform fees (tax), VAT/GST handling,
 *            and revenue retention auditing.
 */

import { NextApiRequest, NextApiResponse } from 'next';

// --- DEFINITIONS ---

// 1. Platform Fee Structures (The "Tax")
// Apple/Google take a commission (typically 15-30%).
// Small Business Program (SBP) lowers this for qualifying revenue.
const PLATFORM_FEES = {
  APPLE: {
    STANDARD: 0.30,
    SBP_THRESHOLD: 1_000_000, // $1M USD annual revenue
    SBP_REDUCED: 0.15,
  },
  GOOGLE: {
    STANDARD: 0.15, // Google Play often charges 15% for subscriptions
    FIRST_YEAR: 0.15, // Retention incentives
  },
} as const;

// 2. Tax Jurisdictions (VAT/GST)
// Digital services often require collecting tax based on user location.
const TAX_RATES = {
  US: 0.0, // No federal VAT in US
  EU: 0.21, // Average VAT
  UK: 0.20,
  AU: 0.10, // GST
} as const;

// 3. Types
type Platform = 'APPLE' | 'GOOGLE' | 'WEB';
type Region = keyof typeof TAX_RATES;

interface Transaction {
  id: string;
  amount: number; // Gross amount in USD
  platform: Platform;
  userId: string;
  region: Region;
  isRenewal: boolean;
  timestamp: Date;
}

interface AuditResult {
  transactionId: string;
  netRevenue: number; // Amount after platform fee
  taxLiability: number; // VAT/GST collected (if applicable)
  retainedRevenue: number; // Net after tax and fees
  complianceStatus: 'PASS' | 'FAIL';
  notes: string[];
}

// --- SIMULATED SUPABASE CLIENT ---
// In a real app, import { createClient } from '@supabase/supabase-js'
// Here we simulate the client to focus on the logic structure.

class SupabaseClient {
  private url: string;
  private key: string;

  constructor(url: string, key: string) {
    this.url = url;
    this.key = key;
  }

  /**
   * Simulates a database insert. In production, this writes to a PostgreSQL
   * table (e.g., 'tax_audit_logs') that supports pgvector for analytics.
   */
  async from(table: string) {
    return {
      insert: async (data: any) => {
        console.log(`[Supabase V8 Context] Inserting into ${table}:`, JSON.stringify(data));
        // Simulate network latency (Perceived Performance handling)
        await new Promise(resolve => setTimeout(resolve, 100));
        return { data, error: null };
      },
    };
  }
}

const db = new SupabaseClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'mock-url',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'mock-key'
);

// --- CORE LOGIC ---

/**
 * Calculates the financial breakdown of a transaction based on platform rules.
 * This function is pure and CPU-bound (V8 optimized).
 * 
 * @param transaction - The raw transaction data
 * @param currentAnnualRevenue - Total revenue to date for Small Business Program check
 * @returns AuditResult
 */
function calculateTaxCompliance(
  transaction: Transaction,
  currentAnnualRevenue: number
): AuditResult {
  const notes: string[] = [];
  let platformFeeRate = 0;
  let taxRate = 0;

  // 1. Determine Platform Fee (The "Apple/Google Tax")
  if (transaction.platform === 'APPLE') {
    // Check Small Business Program eligibility
    const projectedRevenue = currentAnnualRevenue + transaction.amount;
    if (projectedRevenue <= PLATFORM_FEES.APPLE.SBP_THRESHOLD) {
      platformFeeRate = PLATFORM_FEES.APPLE.SBP_REDUCED;
      notes.push('Apple Small Business Program applied (15%)');
    } else {
      platformFeeRate = PLATFORM_FEES.APPLE.STANDARD;
      notes.push('Apple Standard Commission applied (30%)');
    }
  } else if (transaction.platform === 'GOOGLE') {
    // Google Play Service Fee
    platformFeeRate = PLATFORM_FEES.GOOGLE.STANDARD;
    notes.push('Google Play Service Fee applied (15%)');
  } else {
    // Web (Stripe/Paddle usually ~2.9% + 30c, but simplified here)
    platformFeeRate = 0.029;
    notes.push('Web Platform Fee applied (Stripe est.)');
  }

  // 2. Determine VAT/GST Liability (Regulatory Obligation)
  // Digital services tax is based on the *User's Location*, not the developer's.
  if (transaction.region in TAX_RATES) {
    taxRate = TAX_RATES[transaction.region];
    if (taxRate > 0) {
      notes.push(`VAT/GST applied for ${transaction.region} at ${taxRate * 100}%`);
    }
  }

  // 3. Calculations
  // Gross Revenue: $100
  // Platform Fee (Tax): $30 (30%)
  // Taxable Base: $70
  // VAT (21%): $14.70
  // Net Retained: $70 - $14.70 = $55.30

  const platformFee = transaction.amount * platformFeeRate;
  const taxableBase = transaction.amount - platformFee;
  const taxLiability = taxableBase * taxRate;
  const retainedRevenue = taxableBase - taxLiability;

  // 4. Compliance Check
  // Ensure we aren't retaining more than allowed (sanity check)
  const complianceStatus = retainedRevenue > 0 ? 'PASS' : 'FAIL';

  return {
    transactionId: transaction.id,
    netRevenue: taxableBase, // Revenue before tax
    taxLiability: taxLiability, // Tax to remit
    retainedRevenue: retainedRevenue, // Actual cash flow
    complianceStatus,
    notes,
  };
}

/**
 * Main API Handler.
 * 
 * This simulates a Next.js API route `/api/audit/transaction`.
 * It demonstrates:
 * 1. Immediate response (Perceived Performance).
 * 2. Asynchronous background processing (V8 Event Loop).
 * 3. Database persistence (Supabase).
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // Input Validation
  const { transaction, currentAnnualRevenue } = req.body as {
    transaction: Transaction;
    currentAnnualRevenue: number;
  };

  if (!transaction || typeof currentAnnualRevenue !== 'number') {
    return res.status(400).json({ error: 'Invalid request payload' });
  }

  try {
    // 1. Immediate Acknowledgement (Perceived Performance)
    // We return a 202 Accepted immediately, signaling the client that the
    // request was received and is being processed in the background.
    res.status(202).json({
      message: 'Audit initiated. Processing in background.',
      transactionId: transaction.id,
    });

    // 2. Background Processing (V8 Engine Execution)
    // We use process.nextTick or a microtask to ensure the response is sent
    // before heavy calculation blocks the event loop.
    setImmediate(async () => {
      try {
        // Perform the complex tax calculation
        const auditResult = calculateTaxCompliance(transaction, currentAnnualRevenue);

        // 3. Persist to Database (Supabase Client)
        // Storing this allows for future analytics and tax reporting.
        const { data, error } = await db.from('tax_audit_logs').insert({
          transaction_id: auditResult.transactionId,
          net_revenue: auditResult.netRevenue,
          tax_liability: auditResult.taxLiability,
          retained_revenue: auditResult.retainedRevenue,
          status: auditResult.complianceStatus,
          notes: auditResult.notes,
          created_at: new Date().toISOString(),
        });

        if (error) {
          console.error('Database Error:', error);
          // In a real app, send to a logging service (e.g., Sentry)
        } else {
          console.log(`[Audit Complete] Transaction ${transaction.id} processed.`);
        }
      } catch (err) {
        console.error('Background Processing Error:', err);
      }
    });

  } catch (error) {
    // Catch-all for synchronous errors
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
