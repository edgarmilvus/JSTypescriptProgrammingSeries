/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface AppleReceipt {
  receipt: {
    in_app: Array<{
      transaction_id: string;
      product_id: string;
      purchase_date_ms: string;
      original_transaction_id: string;
    }>;
  };
  status: number; // 0 is success
}

// Mock response structure for Apple Verification
interface AppleVerificationResponse {
  status: number;
  receipt: {
    in_app: {
      transaction_id: string;
      product_id: string;
      purchase_date_ms: string;
      original_transaction_id: string;
    }[];
  };
}

// middleware.ts
import { Request, Response, NextFunction } from 'express';

export const appleReceiptValidator = async (req: Request, res: Response, next: NextFunction) => {
  // 1. Parse the incoming request body
  const { receiptData } = req.body;

  if (!receiptData) {
    return res.status(400).json({ error: 'Receipt data is required' });
  }

  // 2. Simulate interaction with Apple's Sandbox Verification URL
  // In a real app, we would use fetch/axios here. We mock it for this exercise.
  const mockAppleResponse: AppleVerificationResponse = {
    status: 0, // Success
    receipt: {
      in_app: [
        {
          transaction_id: '1000000123456789',
          product_id: 'com.example.premium_monthly',
          purchase_date_ms: '1640995200000', // Jan 1, 2022
          original_transaction_id: '1000000123456789',
        },
      ],
    },
  };

  // 3. Check if verification was successful (status 0)
  if (mockAppleResponse.status !== 0 || mockAppleResponse.receipt.in_app.length === 0) {
    return res.status(401).json({ error: 'Invalid receipt' });
  }

  // 4. Extract transaction details (taking the latest purchase in the array)
  const transaction = mockAppleResponse.receipt.in_app[0];
  const purchaseDate = new Date(parseInt(transaction.purchase_date_ms, 10));

  // 5. Calculate Platform Fee
  // Assume purchase amount is $10.00
  const grossRevenue = 10.00;
  let platformFeeRate = 0.30; // Standard 30%

  // Small Business Program logic (simplified): 
  // If the transaction is in the first month of the year, assume annual revenue is low enough.
  if (purchaseDate.getMonth() === 0) { 
    platformFeeRate = 0.15; // 15% for Small Business Program
  }

  const platformFee = grossRevenue * platformFeeRate;
  const netRevenue = grossRevenue - platformFee;

  // 6. Determine Compliance Region (Mock logic based on Product ID or Random)
  // In reality, this might come from user profile or IP geolocation.
  const complianceRegion: 'US' | 'EU' | 'Other' = 'US'; 

  // 7. Log the compliance object (Simulating DB write)
  const complianceLog = {
    transactionId: transaction.transaction_id,
    productId: transaction.product_id,
    grossRevenue: grossRevenue,
    platformFee: platformFee,
    netRevenue: netRevenue,
    timestamp: new Date(),
    complianceRegion: complianceRegion,
  };

  console.log('Compliance Log Entry:', JSON.stringify(complianceLog, null, 2));

  // 8. Pass control to the next middleware/route handler
  next();
};
