/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// SubscriptionManager.tsx
import React, { useState, useEffect } from 'react';

interface Subscription {
  id: string;
  name: string;
  status: 'active' | 'expired';
  basePriceUSD: number;
  region: string;
}

// Helper function to calculate display price with tax
const calculateDisplayPrice = (basePrice: number, regionCode: string): number => {
  let taxRate = 0;

  switch (regionCode) {
    case 'DE': // EU VAT
      taxRate = 0.19;
      break;
    case 'JP': // Consumption Tax
      taxRate = 0.10;
      break;
    case 'US': 
    default:
      taxRate = 0;
      break;
  }

  return basePrice * (1 + taxRate);
};

// Mock API function
const fetchSubscriptions = async (): Promise<Subscription[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return [
    { id: '1', name: 'Premium Monthly', status: 'active', basePriceUSD: 9.99, region: 'DE' },
    { id: '2', name: 'Basic Yearly', status: 'expired', basePriceUSD: 99.00, region: 'US' },
    { id: '3', name: 'Game Pass', status: 'active', basePriceUSD: 500, region: 'JP' },
  ];
};

export const SubscriptionManager: React.FC = () => {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  // Fetch data on mount
  useEffect(() => {
    const loadData = async () => {
      const data = await fetchSubscriptions();
      setSubscriptions(data);
      setLoading(false);
    };
    loadData();
  }, []);

  const handleCancel = async (id: string) => {
    setCancellingId(id);
    
    // Simulate API call with 1 second delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Update local state
    setSubscriptions(prev => 
      prev.map(sub => 
        sub.id === id ? { ...sub, status: 'expired' } : sub
      )
    );

    setCancellingId(null);
  };

  if (loading) return <div>Loading subscriptions...</div>;

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Subscription Manager</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {subscriptions.map(sub => {
          const finalPrice = calculateDisplayPrice(sub.basePriceUSD, sub.region);
          
          return (
            <li key={sub.id} style={{ marginBottom: '15px', border: '1px solid #ddd', padding: '10px' }}>
              <div><strong>{sub.name}</strong></div>
              <div>Status: <span style={{ color: sub.status === 'active' ? 'green' : 'red' }}>{sub.status.toUpperCase()}</span></div>
              <div>
                Price: {finalPrice.toFixed(2)} {sub.region === 'DE' ? 'EUR (VAT Inc.)' : sub.region === 'JP' ? 'JPY (Tax Inc.)' : 'USD'}
              </div>
              
              {sub.status === 'active' && (
                <button 
                  onClick={() => handleCancel(sub.id)}
                  disabled={cancellingId === sub.id}
                  style={{ marginTop: '5px', cursor: cancellingId ? 'not-allowed' : 'pointer' }}
                >
                  {cancellingId === sub.id ? 'Cancelling...' : 'Cancel'}
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
};
