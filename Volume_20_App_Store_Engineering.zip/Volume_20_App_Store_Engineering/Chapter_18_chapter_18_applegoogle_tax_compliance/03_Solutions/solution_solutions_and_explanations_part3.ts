/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// revenueCalculator.ts
import * as readline from 'readline';

interface RevenueTier {
  threshold: number;
  commissionRate: number;
}

// Define standard tiers (Apple's structure)
const appleTiers: RevenueTier[] = [
  { threshold: 1000000, commissionRate: 0.15 }, // Small Business Program
  { threshold: Infinity, commissionRate: 0.30 }, // Standard Tier
];

function calculateNetRevenue(grossRevenue: number, tiers: RevenueTier[]): { net: number; commission: number; effectiveRate: number; eligible: boolean } {
  let remainingRevenue = grossRevenue;
  let totalCommission = 0;
  
  // Sort tiers to ensure correct processing order
  const sortedTiers = [...tiers].sort((a, b) => a.threshold - b.threshold);

  let previousThreshold = 0;

  for (const tier of sortedTiers) {
    if (remainingRevenue <= 0) break;

    // Calculate revenue within this tier
    const tierCap = tier.threshold - previousThreshold;
    const taxableInTier = Math.min(remainingRevenue, tierCap);
    
    const commissionForTier = taxableInTier * tier.commissionRate;
    totalCommission += commissionForTier;
    
    remainingRevenue -= taxableInTier;
    previousThreshold = tier.threshold;
  }

  const net = grossRevenue - totalCommission;
  const effectiveRate = grossRevenue > 0 ? (totalCommission / grossRevenue) : 0;
  const eligible = grossRevenue <= 1000000;

  return { net, commission: totalCommission, effectiveRate, eligible };
}

// Interactive CLI Setup
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log("--- Apple Small Business Program Calculator ---");

rl.question("Enter your projected annual gross revenue (USD): ", (input) => {
  const grossRevenue = parseFloat(input);

  if (isNaN(grossRevenue) || grossRevenue < 0) {
    console.error("Invalid input. Please enter a valid number.");
    rl.close();
    return;
  }

  const results = calculateNetRevenue(grossRevenue, appleTiers);

  // Output formatted table
  console.log("\n--- Forecast Report ---");
  console.log(`| Metric                  | Value                  |`);
  console.log(`|-------------------------|------------------------|`);
  console.log(`| Gross Revenue           | $${grossRevenue.toLocaleString()}      |`);
  console.log(`| Total Commission Paid   | $${results.commission.toLocaleString(undefined, {maximumFractionDigits: 2})}      |`);
  console.log(`| Net Revenue             | $${results.net.toLocaleString(undefined, {maximumFractionDigits: 2})}      |`);
  console.log(`| Effective Commission    | ${(results.effectiveRate * 100).toFixed(2)}%              |`);
  console.log(`| Small Business Eligible | ${results.eligible ? 'YES' : 'NO'}              |`);
  console.log(`|-------------------------|------------------------|`);

  rl.close();
});
