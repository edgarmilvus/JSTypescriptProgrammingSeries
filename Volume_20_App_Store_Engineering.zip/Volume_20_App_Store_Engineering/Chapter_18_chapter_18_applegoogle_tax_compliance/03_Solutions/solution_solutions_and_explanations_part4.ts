/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// billingTypes.ts
export interface ProductDetails {
  productId: string;
  title: string;
  description: string;
  oneTimePurchaseOfferDetails?: {
    priceAmountMicros: string;
    currencyCode: string;
  };
}

export interface Purchase {
  purchaseToken: string;
  orderId: string;
  products: { productId: string }[];
}

// billingClient.ts
export class GooglePlayBillingClient {
  
  // Mock database of products
  private mockProducts: Map<string, ProductDetails> = new Map([
    ['consumable_100_coins', {
      productId: 'consumable_100_coins',
      title: '100 Gold Coins',
      description: 'Instant delivery of 100 coins',
      oneTimePurchaseOfferDetails: { priceAmountMicros: '1000000', currencyCode: 'USD' }
    }],
    ['premium_upgrade', {
      productId: 'premium_upgrade',
      title: 'Premium Upgrade',
      description: 'Unlock all features',
      oneTimePurchaseOfferDetails: { priceAmountMicros: '5000000', currencyCode: 'USD' }
    }]
  ]);

  /**
   * Queries product details asynchronously.
   * Simulates network delay.
   */
  async queryProductDetails(productIds: string[]): Promise<ProductDetails[]> {
    console.log(`Querying details for: ${productIds.join(', ')}...`);
    
    // Simulate network delay (500ms)
    await new Promise(resolve => setTimeout(resolve, 500));

    const results: ProductDetails[] = [];
    productIds.forEach(id => {
      const product = this.mockProducts.get(id);
      if (product) results.push(product);
    });

    return results;
  }

  /**
   * Launches the billing flow.
   * Simulates user interaction and potential cancellation.
   */
  async launchBillingFlow(product: ProductDetails): Promise<Purchase> {
    console.log(`Launching billing flow for: ${product.title}...`);
    
    // Simulate user interaction delay (2 seconds)
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Simulate a random cancellation (10% chance)
    const isCancelled = Math.random() < 0.1;

    if (isCancelled) {
      throw new Error(JSON.stringify({ 
        code: 'USER_CANCELED', 
        message: 'The user cancelled the purchase' 
      }));
    }

    // Return a mock Purchase object
    return {
      purchaseToken: 'mock_purchase_token_' + Date.now(),
      orderId: 'GPA.' + Math.random().toString(36).substring(2, 10),
      products: [{ productId: product.productId }]
    };
  }
}

// Usage Example
export async function buyProduct(productId: string) {
  const billingClient = new GooglePlayBillingClient();

  try {
    // 1. Query Product Details
    const detailsList = await billingClient.queryProductDetails([productId]);
    
    if (detailsList.length === 0) {
      console.error('Product not found');
      return;
    }

    const productDetails = detailsList[0];
    console.log(`Found: ${productDetails.title}`);

    // 2. Launch Billing Flow
    const purchase = await billingClient.launchBillingFlow(productDetails);
    console.log('Purchase Successful:', purchase);

  } catch (error) {
    // 3. Handle Errors
    if (error instanceof Error) {
      try {
        const errorObj = JSON.parse(error.message);
        if (errorObj.code === 'USER_CANCELED') {
          console.warn('User cancelled the purchase flow.');
        } else {
          console.error('Billing Error:', errorObj.message);
        }
      } catch (parseError) {
        console.error('Unknown Error:', error.message);
      }
    }
  }
}

// To test: buyProduct('consumable_100_coins');
