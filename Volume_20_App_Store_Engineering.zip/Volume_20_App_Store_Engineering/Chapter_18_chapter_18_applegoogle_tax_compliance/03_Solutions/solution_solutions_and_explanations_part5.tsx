/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// RegionRestrictedPage.tsx (Server Component)
import ComplianceWrapper from './ComplianceWrapper';

// Mock server-side geolocation function
async function getGeolocationData(): Promise<{ country: string; region: string; gdprApplicable: boolean }> {
  // Simulate fetching IP data
  return new Promise(resolve => {
    setTimeout(() => {
      // Simulating a user from Germany
      resolve({
        country: 'DE',
        region: 'EU',
        gdprApplicable: true
      });
    }, 200); // Simulate DB lookup delay
  });
}

// Mock legal text database
const legalTexts = {
  GDPR: "By proceeding, you agree to the processing of your personal data according to the GDPR guidelines...",
  CCPA: "By proceeding, you agree to the CCPA privacy policy...",
  DEFAULT: "Standard terms and conditions apply."
};

async function getLegalText(gdprApplicable: boolean): Promise<string> {
  // Simulate async fetch
  await new Promise(resolve => setTimeout(resolve, 200));
  return gdprApplicable ? legalTexts.GDPR : legalTexts.DEFAULT;
}

export default async function RegionRestrictedPage() {
  // 1. Fetch Geolocation on Server
  const geoData = await getGeolocationData();

  // 2. Fetch Legal Text based on Region
  const legalText = await getLegalText(geoData.gdprApplicable);

  // 3. Pass props to Client Component
  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h1>Checkout</h1>
      <ComplianceWrapper 
        legalText={legalText} 
        region={geoData.region} 
      />
    </div>
  );
}
