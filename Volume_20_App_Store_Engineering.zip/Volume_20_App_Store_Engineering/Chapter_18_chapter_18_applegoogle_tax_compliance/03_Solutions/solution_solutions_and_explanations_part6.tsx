/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// ComplianceWrapper.tsx (Client Component)
'use client';

interface Props {
  legalText: string;
  region: string;
}

export default function ComplianceWrapper({ legalText, region }: Props) {
  // Determine button text based on region prop
  const buttonText = region === 'EU' 
    ? 'Pay with VAT Included' 
    : 'Pay (Sales Tax Calculated at Checkout)';

  return (
    <div>
      {/* Legal Text rendered directly from props */}
      <div style={{ backgroundColor: '#f0f0f0', padding: '15px', marginBottom: '20px', fontSize: '0.9rem' }}>
        {legalText}
      </div>

      {/* Payment Button */}
      <button 
        onClick={() => alert('Initiating payment flow...')}
        style={{ 
          backgroundColor: '#0070f3', 
          color: 'white', 
          padding: '10px 20px', 
          border: 'none', 
          borderRadius: '5px',
          cursor: 'pointer'
        }}
      >
        {buttonText}
      </button>
    </div>
  );
}
