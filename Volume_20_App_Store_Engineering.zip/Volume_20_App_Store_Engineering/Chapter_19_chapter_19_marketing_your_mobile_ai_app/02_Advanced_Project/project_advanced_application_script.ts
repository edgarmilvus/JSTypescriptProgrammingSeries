/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/asoAnalysis.ts
'use server';

import { z } from 'zod';
import { openai } from '@ai-sdk/openai'; // Hypothetical import for AI SDK
import { generateText } from 'ai';
import { db } from '@/lib/db'; // Hypothetical database client

// ============================================================================
// 1. DATA SCHEMAS & TYPES
// ============================================================================

/**
 * Schema for validating user input from the client form.
 * Uses Zod for runtime type checking to ensure data integrity on the server.
 */
const AsoInputSchema = z.object({
  appName: z.string().min(2, "App name must be at least 2 characters"),
  primaryKeyword: z.string().min(1, "Primary keyword is required"),
  targetLocale: z.string().default("en-US"),
  competitorUrls: z.array(z.string().url()).optional(),
});

export type AsoInput = z.infer<typeof AsoInputSchema>;
export type AsoResult = {
  generatedTitle: string;
  generatedDescription: string;
  keywordAnalysis: {
    primary: string;
    density: number;
    suggestions: string[];
  };
  competitorInsights: string[];
};

// ============================================================================
// 2. SERVER ACTION: PROCESS_ASO_ANALYSIS
// ============================================================================

/**
 * Server Action to generate AI-driven ASO metadata and analyze competitors.
 * 
 * This function executes entirely on the server, ensuring API keys (OpenAI, DB)
 * remain secure. It demonstrates the "AI Chatbot Architecture" by orchestrating
 * multiple steps: validation, LLM generation, and database logging.
 * 
 * @param prevState - Previous form state (for Next.js useFormState).
 * @param formData - Form data containing app details.
 * @returns Promise<{ success: boolean; data?: AsoResult; error?: string }>
 */
export async function processAsoAnalysis(
  prevState: any,
  formData: FormData
): Promise<{ success: boolean; data?: AsoResult; error?: string }> {
  
  // Step 1: Validate Input
  // We parse the raw FormData against our Zod schema.
  const parsed = AsoInputSchema.safeParse({
    appName: formData.get('appName'),
    primaryKeyword: formData.get('primaryKeyword'),
    targetLocale: formData.get('targetLocale'),
    competitorUrls: formData.getAll('competitorUrl'), // Handling array inputs
  });

  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0].message };
  }

  const { appName, primaryKeyword, targetLocale, competitorUrls } = parsed.data;

  try {
    // Step 2: Generate Localized Metadata via LLM
    // We use a low temperature (0.2) for deterministic, factual outputs suitable
    // for App Store metadata, adhering to the 'Temperature' definition.
    const prompt = `
      You are an expert App Store Marketer. 
      Generate optimized App Store metadata for "${appName}".
      Primary Keyword: "${primaryKeyword}".
      Target Locale: "${targetLocale}".
      
      Requirements:
      1. Title: Max 30 chars, catchy, includes primary keyword.
      2. Description: Max 100 chars, value-driven, includes keyword naturally.
      3. Keyword List: 5 comma-separated secondary keywords.
      
      Respond in JSON format: 
      { "title": "...", "description": "...", "keywords": "..." }
    `;

    const { text: llmResponse } = await generateText({
      model: openai('gpt-4-turbo-preview'),
      prompt: prompt,
      temperature: 0.2, // Low temperature for consistency
    });

    // Parse LLM JSON response
    const metadata = JSON.parse(llmResponse);

    // Step 3: Analyze Competitors (Mock Analysis)
    // In a real scenario, this would fetch app store data via an API.
    // Here we simulate analysis based on provided URLs.
    const competitorInsights: string[] = [];
    if (competitorUrls && competitorUrls.length > 0) {
      competitorUrls.forEach((url) => {
        // Simulated logic: Extract domain and suggest differentiation
        const domain = new URL(url).hostname;
        competitorInsights.push(
          `Analyzed ${domain}: Focus on differentiating features in your description.`
        );
      });
    }

    // Step 4: Calculate Keyword Density (Simulated Logic)
    // A simple heuristic to ensure keyword presence.
    const description = metadata.description;
    const keywordCount = (description.match(new RegExp(primaryKeyword, 'gi')) || []).length;
    const density = (keywordCount / description.split(' ').length) * 100;

    // Step 5: Construct Result Object
    const result: AsoResult = {
      generatedTitle: metadata.title,
      generatedDescription: metadata.description,
      keywordAnalysis: {
        primary: primaryKeyword,
        density: parseFloat(density.toFixed(2)),
        suggestions: metadata.keywords.split(',').map((k: string) => k.trim()),
      },
      competitorInsights: competitorInsights,
    };

    // Step 6: Log to Database (Server-Side Only)
    // This keeps the marketing data secure and centralized.
    await db.marketingLog.create({
      data: {
        appName,
        analysisType: 'ASO',
        result: JSON.stringify(result),
        createdAt: new Date(),
      },
    });

    return { success: true, data: result };

  } catch (error) {
    console.error("ASO Analysis Error:", error);
    return { success: false, error: "Failed to generate analysis. Please try again." };
  }
}
