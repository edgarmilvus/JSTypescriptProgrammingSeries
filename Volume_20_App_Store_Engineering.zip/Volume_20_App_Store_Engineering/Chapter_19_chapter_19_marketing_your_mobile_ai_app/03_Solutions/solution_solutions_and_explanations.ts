/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/components/ASOMetadataGenerator.tsx
"use client";

import { useFormState, useFormStatus } from "react-dom";
import { useState } from "react";
import { generateASOMetadata, fetchCompetitorKeywords } from "@/app/actions/aso";

// Helper component for the submit button to handle loading state
function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
    >
      {pending ? "Generating..." : "Generate Metadata"}
    </button>
  );
}

export default function ASOMetadataGenerator() {
  // Server Action State (Form State)
  const [state, formAction] = useFormState(generateASOMetadata, null);
  
  // Client State for Competitor Keywords
  const [competitorKeywords, setCompetitorKeywords] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Handler for the Competitor Analysis feature
  const handleCompetitorAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      // Simulate fetching competitor data
      const keywords = await fetchCompetitorKeywords();
      setCompetitorKeywords(keywords);
    } catch (error) {
      console.error("Failed to fetch keywords", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-bold mb-4">ASO Metadata Generator</h2>
        
        <form action={formAction} className="space-y-4">
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              App Description
            </label>
            <textarea
              id="description"
              name="description"
              rows={4}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm border p-2"
              placeholder="Enter your raw app description..."
              required
            />
          </div>

          <div>
            <label htmlFor="locales" className="block text-sm font-medium text-gray-700">
              Target Locales (comma separated)
            </label>
            <input
              id="locales"
              name="locales"
              type="text"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm border p-2"
              placeholder="en-US, es-ES, ja-JP"
              defaultValue="en-US"
              required
            />
          </div>

          <div className="flex gap-4">
            <SubmitButton />
            
            {/* Competitor Analysis Button */}
            <button
              type="button"
              onClick={handleCompetitorAnalysis}
              disabled={isAnalyzing}
              className="bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
            >
              {isAnalyzing ? "Analyzing..." : "Analyze Competitor Keywords"}
            </button>
          </div>
        </form>

        {/* Display Competitor Keywords */}
        {competitorKeywords.length > 0 && (
          <div className="mt-6 p-4 bg-gray-50 rounded">
            <h3 className="font-semibold text-gray-800">Competitor High-Value Keywords</h3>
            <div className="flex flex-wrap gap-2 mt-2">
              {competitorKeywords.map((kw, idx) => (
                <span key={idx} className="bg-white border px-2 py-1 rounded text-sm text-gray-600">
                  {kw}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Display Generated Metadata */}
        {state && (
          <div className="mt-6 space-y-4">
            <h3 className="font-bold text-lg">Generated Results</h3>
            {Object.entries(state).map(([locale, data]) => (
              <div key={locale} className="border rounded-md p-4 bg-gray-50">
                <h4 className="font-semibold text-blue-700 uppercase text-sm mb-2">
                  Locale: {locale}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="block font-medium text-gray-500">Title</span>
                    <span className="text-gray-900">{data.title}</span>
                  </div>
                  <div>
                    <span className="block font-medium text-gray-500">Subtitle</span>
                    <span className="text-gray-900">{data.subtitle}</span>
                  </div>
                  <div>
                    <span className="block font-medium text-gray-500">Keywords</span>
                    <span className="text-gray-900">{data.keywords.join(", ")}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
