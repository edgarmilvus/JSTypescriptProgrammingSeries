/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/components/AdCampaignBuilder.tsx
"use client";

import { useState } from "react";

// Interfaces
interface UserDemographics {
  ageRange: string;
  interests: string[];
  budget: number;
}

interface CampaignMetrics {
  estimatedReach: number;
  suggestedCPC: number;
  projectedROI: number;
}

// Simulation Logic
const simulateAITargeting = (demo: UserDemographics): CampaignMetrics => {
  // Base metrics
  let baseReach = 10000;
  let baseCPC = 1.5;
  
  // Adjust based on budget (higher budget = broader reach cap, but not linear)
  const budgetFactor = Math.log(demo.budget + 1) * 2000;
  
  // Adjust based on specificity of interests (AI logic simulation)
  // "Tech" is broad, "AI Enthusiasts" is specific (higher CPC, better conversion)
  const interestSpecificity = demo.interests.reduce((acc, interest) => {
    if (interest.toLowerCase().includes("ai") || interest.toLowerCase().includes("developer")) return acc + 1.5;
    if (interest.toLowerCase().includes("tech")) return acc + 1.0;
    return acc + 0.8;
  }, 1);

  const estimatedReach = Math.floor(baseReach * (budgetFactor / 1000) * interestSpecificity);
  const suggestedCPC = parseFloat((baseCPC * (interestSpecificity / 1.2)).toFixed(2));
  
  // ROI Calculation: (Conversion Rate * Value) / Cost
  // Higher specificity usually means higher conversion rate
  const conversionRate = 0.02 * interestSpecificity; 
  const conversionValue = 50; // Lifetime value per user
  const totalCost = suggestedCPC * estimatedReach * 0.1; // Simulated spend
  const totalRevenue = (estimatedReach * conversionRate) * conversionValue;
  const projectedROI = ((totalRevenue - totalCost) / totalCost) * 100;

  return {
    estimatedReach,
    suggestedCPC,
    projectedROI: parseFloat(projectedROI.toFixed(2))
  };
};

export default function AdCampaignBuilder() {
  // State for Scenario A
  const [demoA, setDemoA] = useState<UserDemographics>({ ageRange: "25-34", interests: ["Tech"], budget: 5000 });
  const [metricsA, setMetricsA] = useState<CampaignMetrics | null>(null);

  // State for Scenario B (A/B Testing)
  const [isScenarioMode, setIsScenarioMode] = useState(false);
  const [demoB, setDemoB] = useState<UserDemographics>({ ageRange: "25-34", interests: ["AI Enthusiasts"], budget: 5000 });
  const [metricsB, setMetricsB] = useState<CampaignMetrics | null>(null);

  const handleCalculate = () => {
    setMetricsA(simulateAITargeting(demoA));
    if (isScenarioMode) {
      setMetricsB(simulateAITargeting(demoB));
    }
  };

  // Helper to render metric cards
  const renderMetrics = (metrics: CampaignMetrics | null, label: string) => (
    <div className={`mt-4 p-4 border rounded-lg ${label === "Scenario A" ? "bg-blue-50 border-blue-200" : "bg-purple-50 border-purple-200"}`}>
      <h4 className="font-bold text-lg mb-2">{label} Results</h4>
      {metrics ? (
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-sm text-gray-500">Reach</div>
            <div className="text-xl font-bold">{metrics.estimatedReach.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-sm text-gray-500">CPC</div>
            <div className="text-xl font-bold">${metrics.suggestedCPC}</div>
          </div>
          <div>
            <div className="text-sm text-gray-500">ROI</div>
            <div className={`text-xl font-bold ${metrics.projectedROI > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {metrics.projectedROI}%
            </div>
          </div>
        </div>
      ) : (
        <p className="text-gray-500 text-sm">Click calculate to see results.</p>
      )}
    </div>
  );

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI Ad Campaign Builder</h2>
        <label className="flex items-center space-x-2 cursor-pointer">
          <input 
            type="checkbox" 
            checked={isScenarioMode} 
            onChange={(e) => setIsScenarioMode(e.target.checked)}
            className="form-checkbox h-5 w-5 text-purple-600"
          />
          <span className="text-sm font-medium">A/B Test Mode</span>
        </label>
      </div>

      <div className={`grid gap-6 ${isScenarioMode ? 'grid-cols-2' : 'grid-cols-1'}`}>
        {/* Scenario A Inputs */}
        <div className="bg-white p-4 shadow rounded border">
          <h3 className="font-semibold mb-3 text-blue-700">Scenario A</h3>
          <DemographicInputs 
            demographics={demoA} 
            onChange={setDemoA} 
          />
        </div>

        {/* Scenario B Inputs (Conditional) */}
        {isScenarioMode && (
          <div className="bg-white p-4 shadow rounded border">
            <h3 className="font-semibold mb-3 text-purple-700">Scenario B</h3>
            <DemographicInputs 
              demographics={demoB} 
              onChange={setDemoB} 
            />
          </div>
        )}
      </div>

      <div className="flex justify-center">
        <button 
          onClick={handleCalculate}
          className="bg-gray-900 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition"
        >
          Run AI Simulation
        </button>
      </div>

      {/* Results Section */}
      <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
        {renderMetrics(metricsA, "Scenario A")}
        {isScenarioMode && renderMetrics(metricsB, "Scenario B")}
      </div>
    </div>
  );
}

// Sub-component for input fields to keep main component clean
function DemographicInputs({ demographics, onChange }: { demographics: UserDemographics, onChange: (d: UserDemographics) => void }) {
  return (
    <div className="space-y-3">
      <div>
        <label className="block text-xs font-bold text-gray-500 uppercase">Age Range</label>
        <select 
          className="w-full border rounded p-2"
          value={demographics.ageRange}
          onChange={(e) => onChange({ ...demographics, ageRange: e.target.value })}
        >
          <option>18-24</option>
          <option>25-34</option>
          <option>35-44</option>
          <option>45+</option>
        </select>
      </div>
      <div>
        <label className="block text-xs font-bold text-gray-500 uppercase">Interests (comma sep)</label>
        <input 
          type="text"
          className="w-full border rounded p-2"
          value={demographics.interests.join(", ")}
          onChange={(e) => onChange({ ...demographics, interests: e.target.value.split(",").map(s => s.trim()) })}
        />
      </div>
      <div>
        <label className="block text-xs font-bold text-gray-500 uppercase">Budget ($)</label>
        <input 
          type="number"
          className="w-full border rounded p-2"
          value={demographics.budget}
          onChange={(e) => onChange({ ...demographics, budget: Number(e.target.value) })}
        />
      </div>
    </div>
  );
}
