/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/components/FeedbackAnalyzer.tsx
"use client";

import { useState } from "react";

// Types
type SentimentScore = 0 | 0.5 | 1; // 0: Negative, 0.5: Neutral, 1: Positive
type SentimentLabel = "Negative" | "Neutral" | "Positive";

interface AnalysisResult {
  text: string;
  score: SentimentScore;
  label: SentimentLabel;
  inferenceTime: number;
}

// Simulation of WebGPU Inference
const analyzeSentimentWebGPU = (text: string): AnalysisResult => {
  const start = performance.now();
  
  // Simulate heavy computation delay (WebGPU inference latency)
  const delay = Math.random() * 100 + 50; // 50-150ms
  
  // Heuristic logic to mimic a model
  const lowerText = text.toLowerCase();
  const positiveWords = ["great", "love", "amazing", "excellent", "fast", "best"];
  const negativeWords = ["bad", "hate", "slow", "bug", "crash", "worst"];

  let score: SentimentScore = 0.5; // Default neutral

  const hasPositive = positiveWords.some(w => lowerText.includes(w));
  const hasNegative = negativeWords.some(w => lowerText.includes(w));

  if (hasPositive && !hasNegative) score = 1;
  else if (hasNegative && !hasPositive) score = 0;
  else if (hasPositive && hasNegative) score = 0.5; // Mixed

  const end = performance.now();
  
  let label: SentimentLabel = "Neutral";
  if (score === 1) label = "Positive";
  if (score === 0) label = "Negative";

  return {
    text,
    score,
    label,
    inferenceTime: Math.round(end - start + delay) // Add simulated computation time
  };
};

export default function FeedbackAnalyzer() {
  const [inputText, setInputText] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Batch Mode State
  const [batchResults, setBatchResults] = useState<AnalysisResult[]>([]);
  const [batchProgress, setBatchProgress] = useState(0);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    setIsAnalyzing(true);
    
    // Simulate async delay
    await new Promise(r => setTimeout(r, 50)); 
    
    const res = analyzeSentimentWebGPU(inputText);
    setResult(res);
    setIsAnalyzing(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const text = await file.text();
    const reviews = text.split("\n").filter(line => line.trim().length > 0);
    
    setBatchResults([]);
    setBatchProgress(0);

    // Process sequentially to simulate real-time inference
    for (let i = 0; i < reviews.length; i++) {
      const res = analyzeSentimentWebGPU(reviews[i]);
      setBatchResults(prev => [...prev, res]);
      setBatchProgress(Math.round(((i + 1) / reviews.length) * 100));
      // Small delay between batches for visual effect
      await new Promise(r => setTimeout(r, 100));
    }
  };

  const getSummary = () => {
    if (batchResults.length === 0) return null;
    const total = batchResults.length;
    const positive = batchResults.filter(r => r.label === "Positive").length;
    const neutral = batchResults.filter(r => r.label === "Neutral").length;
    const negative = batchResults.filter(r => r.label === "Negative").length;
    
    return {
      positive: ((positive / total) * 100).toFixed(1),
      neutral: ((neutral / total) * 100).toFixed(1),
      negative: ((negative / total) * 100).toFixed(1),
    };
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      {/* Single Analysis Mode */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-bold mb-4">Client-Side Sentiment Analysis</h2>
        <div className="flex gap-2">
          <textarea
            className="flex-1 border rounded p-2"
            rows={3}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste a review here..."
          />
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="bg-indigo-600 text-white px-4 py-2 rounded disabled:opacity-50"
          >
            {isAnalyzing ? "Inferencing..." : "Analyze"}
          </button>
        </div>

        {result && (
          <div className="mt-4 p-4 border rounded bg-gray-50">
            <div className="flex justify-between items-center mb-2">
              <span className={`font-bold text-lg ${
                result.label === 'Positive' ? 'text-green-600' : 
                result.label === 'Negative' ? 'text-red-600' : 'text-gray-600'
              }`}>
                {result.label}
              </span>
              <span className="text-xs text-gray-500">Inference: {result.inferenceTime}ms (Simulated WebGPU)</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
              <div 
                className={`h-2.5 rounded-full ${
                  result.label === 'Positive' ? 'bg-green-500' : 
                  result.label === 'Negative' ? 'bg-red-500' : 'bg-gray-500'
                }`} 
                style={{ width: `${result.score * 100}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-700 italic">"{result.text}"</p>
          </div>
        )}
      </div>

      {/* Batch Mode */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-bold mb-4">Batch Analysis (File Upload)</h2>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <input 
            type="file" 
            accept=".txt" 
            onChange={handleFileUpload}
            className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-violet-50 file:text-violet-700 hover:file:bg-violet-100"
          />
          <p className="text-xs text-gray-500 mt-2">Upload a .txt file with one review per line.</p>
        </div>

        {batchProgress > 0 && (
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Processing...</span>
              <span>{batchProgress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-indigo-600 h-2 rounded-full transition-all duration-300" style={{ width: `${batchProgress}%` }}></div>
            </div>
          </div>
        )}

        {batchResults.length > 0 && (
          <div className="mt-6">
            <h3 className="font-semibold mb-2">Summary Report</h3>
            {(() => {
              const summary = getSummary();
              return summary ? (
                <div className="flex gap-4 mb-4 text-sm">
                  <span className="text-green-600 font-bold">Positive: {summary.positive}%</span>
                  <span className="text-gray-600 font-bold">Neutral: {summary.neutral}%</span>
                  <span className="text-red-600 font-bold">Negative: {summary.negative}%</span>
                </div>
              ) : null;
            })()}
            
            <div className="max-h-60 overflow-y-auto border rounded p-2 space-y-2">
              {batchResults.map((res, idx) => (
                <div key={idx} className="text-xs flex gap-2 items-center border-b pb-1 last:border-0">
                  <span className={`w-2 h-2 rounded-full ${
                    res.label === 'Positive' ? 'bg-green-500' : 
                    res.label === 'Negative' ? 'bg-red-500' : 'bg-gray-500'
                  }`}></span>
                  <span className="flex-1 truncate">{res.text}</span>
                  <span className="text-gray-400">{res.label}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
