/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/components/MarketingDashboard.tsx
"use client";

import { useEffect, useState } from "react";

// Interface
interface MarketingData {
  version: string;
  title: string;
  keywords: string[];
  downloads: number;
  conversionRate: number; // e.g., 0.05 for 5%
}

// Mock Data Generator
const generateMockData = (): MarketingData[] => [
  { version: "1.0", title: "Photo Editor", keywords: ["edit", "filter", "camera"], downloads: 1200, conversionRate: 0.03 },
  { version: "1.1", title: "AI Photo Editor", keywords: ["ai", "edit", "magic", "filter"], downloads: 4500, conversionRate: 0.06 },
  { version: "1.2", title: "Pro AI Editor", keywords: ["ai", "pro", "studio", "enhance"], downloads: 8200, conversionRate: 0.08 },
  { version: "2.0", title: "Smart Lens AI", keywords: ["ai", "camera", "smart", "vision"], downloads: 15000, conversionRate: 0.12 },
  { version: "2.1", title: "Lens Studio", keywords: ["studio", "lens", "ar", "filter"], downloads: 6000, conversionRate: 0.05 },
];

export default function MarketingDashboard() {
  const [data, setData] = useState<MarketingData[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterKeyword, setFilterKeyword] = useState("");
  const [sortConfig, setSortConfig] = useState<{ key: keyof MarketingData | null, direction: 'asc' | 'desc' }>({ key: null, direction: 'asc' });

  // Fetch Data
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setData(generateMockData());
      setLoading(false);
    }, 500);
  }, []);

  // Filtering Logic
  const filteredData = data.filter(item => 
    filterKeyword === "" || 
    item.keywords.some(k => k.toLowerCase().includes(filterKeyword.toLowerCase()))
  );

  // Sorting Logic
  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    const valA = a[sortConfig.key];
    const valB = b[sortConfig.key];
    
    if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
    if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  // Correlation Logic (Simulated)
  const calculateCorrelation = (): string => {
    if (sortedData.length === 0) return "N/A";
    
    // Heuristic: Calculate average conversion rate for items containing the filter keyword
    // vs global average. This simulates a statistical correlation.
    const filteredAvg = sortedData.reduce((acc, curr) => acc + curr.conversionRate, 0) / sortedData.length;
    
    // If no filter, just return a baseline statement
    if (!filterKeyword) return "Analysis requires a keyword filter to correlate density.";
    
    return `Keyword "${filterKeyword}" correlates with ${ (filteredAvg * 100).toFixed(1) }% avg conversion rate.`;
  };

  const handleSort = (key: keyof MarketingData) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  if (loading) return <div className="p-10 text-center">Loading Dashboard...</div>;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Marketing Iteration Dashboard</h2>
        <div className="flex gap-2">
          <input 
            type="text" 
            placeholder="Filter by keyword (e.g., 'ai')" 
            value={filterKeyword}
            onChange={(e) => setFilterKeyword(e.target.value)}
            className="border rounded px-3 py-1 text-sm"
          />
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 p-4 rounded">
        <h3 className="font-bold text-blue-800">Analysis Insight</h3>
        <p className="text-blue-700 text-sm mt-1">{calculateCorrelation()}</p>
      </div>

      <div className="overflow-x-auto bg-white shadow rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {["version", "title", "keywords", "downloads", "conversionRate"].map((col) => (
                <th 
                  key={col} 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort(col as keyof MarketingData)}
                >
                  <div className="flex items-center gap-1">
                    {col}
                    {sortConfig.key === col && (
                      <span>{sortConfig.direction === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedData.map((row, idx) => {
              // Highlight highest conversion rate in current view
              const maxConv = Math.max(...sortedData.map(d => d.conversionRate));
              const isMax = row.conversionRate === maxConv;
              
              return (
                <tr key={idx} className={isMax ? "bg-yellow-50" : ""}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{row.version}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{row.title}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex gap-1 flex-wrap">
                      {row.keywords.map(k => (
                        <span key={k} className="bg-gray-100 px-2 py-0.5 rounded text-xs">{k}</span>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{row.downloads.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <span>{(row.conversionRate * 100).toFixed(1)}%</span>
                      <div className="w-16 bg-gray-200 rounded-full h-1.5">
                        <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: `${row.conversionRate * 100}%` }}></div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
