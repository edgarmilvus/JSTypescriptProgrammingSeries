/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simple OTA Update Checker for a React Native/Expo SaaS App.
 * This module compares the local app version with a remote server's manifest
 * to determine if an update is available.
 */

// --- 1. Type Definitions ---
// Using Utility Types for strict, reusable data structures.

/**
 * Represents the structure of the remote update manifest.
 * We use `Readonly` to ensure these values are immutable once fetched.
 */
export type RemoteManifest = Readonly<{
  /** Semantic version string (e.g., "1.0.1") */
  version: string;
  /** URL to the OTA bundle (JS bundle or assets) */
  bundleUrl: string;
  /** Optional release notes for the user */
  releaseNotes?: string;
  /** Force update flag (critical security patch) */
  isMandatory: boolean;
}>;

/**
 * Represents the local app's state.
 * We use `Pick` to select only the necessary properties from a larger AppContext object.
 */
export type LocalAppInfo = Pick<RemoteManifest, 'version'>;

// --- 2. The Core Logic ---

/**
 * Simulates a network request to a SaaS backend to fetch the latest update manifest.
 * In a real app, this would be a fetch() call to your API.
 * 
 * @returns Promise<RemoteManifest> - The latest available version info.
 */
const fetchRemoteManifest = async (): Promise<RemoteManifest> => {
  // Simulating network latency
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock response from a SaaS backend (e.g., AWS Lambda or Vercel Edge Function)
  return {
    version: "1.0.2", // Newer version available
    bundleUrl: "https://cdn.my-saas.com/bundles/v1.0.2/main.jsbundle",
    releaseNotes: "Bug fixes for login flow.",
    isMandatory: false, // Optional update
  };
};

/**
 * Compares two semantic versions to determine if an update is needed.
 * 
 * Logic:
 * 1. Parse version strings into major.minor.patch numbers.
 * 2. Compare major versions first, then minor, then patch.
 * 
 * @param localVersion - The current version running on the device.
 * @param remoteVersion - The version available on the server.
 * @returns boolean - True if remoteVersion > localVersion.
 */
const isUpdateAvailable = (localVersion: string, remoteVersion: string): boolean => {
  // Helper to split "1.0.1" into [1, 0, 1]
  const parse = (v: string) => v.split('.').map(Number);

  const [localMajor, localMinor, localPatch] = parse(localVersion);
  const [remoteMajor, remoteMinor, remotePatch] = parse(remoteVersion);

  if (remoteMajor > localMajor) return true;
  if (remoteMajor === localMajor && remoteMinor > localMinor) return true;
  if (remoteMajor === localMajor && remoteMinor === localMinor && remotePatch > localPatch) return true;

  return false;
};

/**
 * The main entry point for the update check.
 * This function orchestrates the fetching and comparison logic.
 * 
 * @param localAppInfo - Information about the currently running app.
 * @returns Promise<RemoteManifest | null> - Returns the manifest if update is available, else null.
 */
export const checkForUpdates = async (
  localAppInfo: LocalAppInfo
): Promise<RemoteManifest | null> => {
  try {
    console.log(`[OTA] Checking for updates. Current: ${localAppInfo.version}`);
    
    // 1. Fetch the remote configuration
    const remoteManifest = await fetchRemoteManifest();
    
    // 2. Compare versions
    const updateNeeded = isUpdateAvailable(localAppInfo.version, remoteManifest.version);

    if (updateNeeded) {
      console.log(`[OTA] Update available: ${remoteManifest.version}`);
      return remoteManifest;
    }

    console.log("[OTA] App is up to date.");
    return null;

  } catch (error) {
    console.error("[OTA] Failed to check for updates:", error);
    // Fail silently or retry logic here
    return null;
  }
};

// --- 3. Usage Example (Simulating a React Component Lifecycle) ---

/**
 * Mock React Native Component utilizing the OTA logic.
 * This simulates what happens when a user opens the app.
 */
export const AppEntryPoint = async () => {
  // Mock local app info (usually read from app.json or native modules)
  const currentApp: LocalAppInfo = { version: "1.0.0" };

  const update = await checkForUpdates(currentApp);

  if (update) {
    if (update.isMandatory) {
      // In a real app: Block UI and force download
      console.log("CRITICAL UPDATE REQUIRED. Blocking UI...");
    } else {
      // In a real app: Show a "Update Available" modal
      console.log(`Prompt user to download v${update.version}`);
    }
  }
};

// Execute the mock entry point
AppEntryPoint();
