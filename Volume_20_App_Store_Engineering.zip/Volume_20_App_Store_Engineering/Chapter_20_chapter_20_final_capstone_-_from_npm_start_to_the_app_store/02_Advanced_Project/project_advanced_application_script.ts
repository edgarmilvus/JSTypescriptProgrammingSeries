/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/generate-aso.ts
// Next.js API Route for AI-Driven App Store Optimization

import type { NextApiRequest, NextApiResponse } from 'next';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';
import { Pinecone } from '@pinecone-database/pinecone'; // Assuming Pinecone for production-grade vector DB

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & INTERFACES
// -----------------------------------------------------------------------------

/**
 * Request Payload expected from the client (e.g., an ASO Dashboard).
 * @typedef {Object} AsoRequest
 * @property {string} appName - The name of the mobile application.
 * @property {string} description - The core description of the app's functionality.
 * @property {string[]} keywords - Target keywords for optimization (e.g., "task management", "habit tracker").
 */
interface AsoRequest {
  appName: string;
  description: string;
  keywords: string[];
}

/**
 * Response Payload containing generated metadata.
 * @typedef {Object} AsoResponse
 * @property {string} optimizedTitle - The AI-generated App Store title (max 30 chars).
 * @property {string} optimizedDescription - The AI-generated long description.
 * @property {string[]} semanticMatches - Vector IDs of top 3 competitor apps used for context.
 */
interface AsoResponse {
  optimizedTitle: string;
  optimizedDescription: string;
  semanticMatches: string[];
}

// -----------------------------------------------------------------------------
// 2. VECTOR STORE CLIENT INITIALIZATION
// -----------------------------------------------------------------------------

/**
 * Initializes the Vector Store client.
 * In a real production environment (Chapter 20 context), this connects to 
 * a managed service like Pinecone or a PostgreSQL database with pgvector enabled.
 * 
 * For this script, we mock the client to focus on the logic flow without 
 * requiring external API keys for execution.
 */
const initializeVectorStore = () => {
  // Production: const pc = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
  // const index = pc.Index('app-store-metadata');
  
  // Mock implementation for demonstration
  return {
    query: async (embedding: number[], topK: number) => {
      console.log(`Querying vector store for top ${topK} matches...`);
      // Simulate retrieval of Vector IDs representing successful competitor apps
      return [
        { id: 'vec_001', score: 0.92, metadata: { title: 'TodoMaster Pro', description: 'The ultimate task manager...' } },
        { id: 'vec_002', score: 0.89, metadata: { title: 'HabitForge', description: 'Build habits with ease...' } },
        { id: 'vec_003', score: 0.85, metadata: { title: 'DailyFocus', description: 'Focus on your daily goals...' } },
      ];
    }
  };
};

// -----------------------------------------------------------------------------
// 3. EMBEDDING GENERATION (SIMULATED)
// -----------------------------------------------------------------------------

/**
 * Generates a vector embedding for the input text.
 * In a real app, this uses OpenAI's embedding model (text-embedding-ada-002).
 * This vector is the key to searching the Vector Store.
 */
const generateEmbedding = async (text: string): Promise<number[]> => {
  // Mock: Return a random array of floats to simulate a 1536-dimension vector
  // Production: const response = await openai.embeddings.create({ model: 'text-embedding-ada-002', input: text });
  // return response.data[0].embedding;
  return Array.from({ length: 1536 }, () => Math.random());
};

// -----------------------------------------------------------------------------
// 4. MAIN API HANDLER
// -----------------------------------------------------------------------------

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<AsoResponse | { error: string }>
) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { appName, description, keywords }: AsoRequest = req.body;

  if (!appName || !description) {
    return res.status(400).json({ error: 'Missing required fields: appName or description' });
  }

  try {
    // Step 1: Generate embedding for the new app description
    // This transforms text into a mathematical representation for semantic search.
    const queryEmbedding = await generateEmbedding(description);

    // Step 2: Query the Vector Store
    // We retrieve the top 3 most similar app descriptions from our database.
    // This context is crucial for the LLM to understand "what works" in the store.
    const vectorStore = initializeVectorStore();
    const searchResults = await vectorStore.query(queryEmbedding, 3);
    
    // Extract the text context from the vector metadata
    const contextText = searchResults.map(result => 
      `Title: ${result.metadata.title}\nDescription: ${result.metadata.description}`
    ).join('\n\n---\n\n');

    // Step 3: Construct the LLM Prompt
    // We inject the retrieved context to guide the AI generation.
    const prompt = `
      You are an expert App Store Optimization (ASO) specialist.
      Generate metadata for a new mobile app based on the following details and competitive context.

      **New App Details:**
      Name: ${appName}
      Description: ${description}
      Target Keywords: ${keywords.join(', ')}

      **Competitive Context (Retrieved from Vector Store):**
      ${contextText}

      **Instructions:**
      1. Generate a catchy App Store Title (max 30 characters) incorporating primary keywords.
      2. Generate a compelling long description (max 4000 characters) that highlights unique selling points.
      3. Format the output as JSON.
    `;

    // Step 4: Stream LLM Response
    // Using Vercel AI SDK's OpenAI integration for streaming responses.
    // This is efficient for UX, allowing the user to see results as they are generated.
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY!,
    });

    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [{ role: 'user', content: prompt }],
      stream: true,
      response_format: { type: 'json_object' }, // Force JSON output for structured data
    });

    // Stream the response back to the client
    const stream = OpenAIStream(response);
    
    // Note: In a strictly typed Next.js API route, streaming JSON requires careful parsing on the client.
    // For simplicity in this script, we will buffer the stream and parse it, 
    // though in production, you might stream raw text or use a parser.
    
    // Since we requested JSON, we need to collect the full stream to parse it.
    // In a real streaming UI, you might stream text tokens directly.
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      fullText += decoder.decode(value, { stream: true });
    }

    // Parse the JSON response from the LLM
    const parsedContent = JSON.parse(fullText) as {
      optimizedTitle: string;
      optimizedDescription: string;
    };

    // Step 5: Return Structured Response
    // The client (e.g., a React Dashboard) can now display this data.
    // The developer can review it before pushing to EAS Submit.
    const finalResponse: AsoResponse = {
      optimizedTitle: parsedContent.optimizedTitle,
      optimizedDescription: parsedContent.optimizedDescription,
      semanticMatches: searchResults.map(r => r.id),
    };

    res.status(200).json(finalResponse);

  } catch (error) {
    console.error('ASO Generation Error:', error);
    res.status(500).json({ error: 'Failed to generate ASO metadata' });
  }
}
