/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

digraph ASO_Flow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e0e0e0", fontname="Arial"];

    User [label="User Input\n(App Name, Description)", fillcolor="#a7c7e7"];
    API [label="Next.js API Route\n/generate-aso", fillcolor="#f5f5f5"];
    Embed [label="Embedding Model\n(Vectorization)", fillcolor="#c3e6cb"];
    VectorDB [label="Vector Store\n(Pinecone/Postgres)", fillcolor="#ffeeba"];
    LLM [label="LLM (GPT-4)\nwith RAG Context", fillcolor="#f8c8dc"];
    Output [label="Optimized Metadata\n(Title, Description)", fillcolor="#d4edda"];

    User -> API -> Embed -> VectorDB;
    VectorDB -> LLM [label="Retrieve Top 3\nSimilar Apps"];
    API -> LLM [label="Prompt Construction"];
    LLM -> Output;
}
