/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { View, Text, Button, ActivityIndicator, StyleSheet, Alert } from 'react-native';
import * as Updates from 'expo-updates';

type UpdateStatus = 'idle' | 'checking' | 'downloading' | 'ready' | 'error';

export default function OTAUpdateManager() {
  const [status, setStatus] = useState<UpdateStatus>('idle');
  const [updateInfo, setUpdateInfo] = useState<string>('');

  useEffect(() => {
    // Automatically check for updates on mount
    checkForUpdates();
  }, []);

  const checkForUpdates = async () => {
    try {
      setStatus('checking');
      
      const { isAvailable } = await Updates.checkForUpdateAsync();

      if (isAvailable) {
        setStatus('downloading');
        await Updates.fetchUpdateAsync();
        
        setStatus('ready');
        setUpdateInfo('Update downloaded. Please restart the app.');
      } else {
        setStatus('idle');
        setUpdateInfo('You are on the latest version.');
      }
    } catch (error) {
      setStatus('error');
      Alert.alert('Error', 'Failed to check for updates. Please try again.');
      console.error(error);
    }
  };

  const handleRestart = async () => {
    await Updates.reloadAsync();
  };

  const renderContent = () => {
    switch (status) {
      case 'checking':
        return (
          <View style={styles.statusContainer}>
            <ActivityIndicator size="small" color="#0000ff" />
            <Text style={styles.text}>Checking for updates...</Text>
          </View>
        );
      case 'downloading':
        return (
          <View style={styles.statusContainer}>
            <ActivityIndicator size="small" color="#0000ff" />
            <Text style={styles.text}>Downloading update...</Text>
          </View>
        );
      case 'ready':
        return (
          <View style={styles.statusContainer}>
            <Text style={styles.text}>{updateInfo}</Text>
            <Button title="Restart App" onPress={handleRestart} />
          </View>
        );
      case 'error':
        return (
          <View style={styles.statusContainer}>
            <Text style={styles.text}>Update failed.</Text>
            <Button title="Retry" onPress={checkForUpdates} />
          </View>
        );
      default:
        return null; // Idle state, no UI needed or just a subtle indicator
    }
  };

  return (
    <View style={styles.container}>
      {renderContent()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    margin: 10,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  text: {
    fontSize: 14,
    color: '#333',
  },
});
