/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// generateASO.ts
import fs from 'fs';

// Mock AI Model Interface
interface AIModel {
  warmStart: () => void;
  infer: (prompt: string) => string;
}

// Simulate a warm start model
const mockAIModel: AIModel = {
  warmStart: () => {
    console.log("Model weights loaded into memory. WASM pipelines ready.");
  },
  infer: (prompt: string): string => {
    // Simulate inference latency
    const start = Date.now();
    while (Date.now() - start < 50) {} // Block for 50ms to simulate compute
    
    // Deterministic transformation logic for the exercise
    // 1. Title: Take first 3 words + "Pro"
    const words = prompt.split(' ').slice(0, 3).join(' ');
    const title = `${words} Pro`;
    
    // 2. Subtitle: Add a descriptive suffix
    const subtitle = `${prompt} - The ultimate tool.`;
    
    // 3. Keywords: Split prompt and filter small words
    const keywords = prompt.split(' ').filter(w => w.length > 2).join(', ');
    
    return JSON.stringify({ title, subtitle, keywords });
  }
};

interface ASOMetadata {
  title: string;
  subtitle: string;
  keywords: string;
}

function generateMetadata(description: string, locale: string): ASOMetadata {
  console.log(`\nGenerating metadata for locale: ${locale}...`);
  
  // Simulate Warm Start: Initialize model once
  mockAIModel.warmStart();
  
  // Simulate Inference
  const resultString = mockAIModel.infer(description);
  const parsedResult = JSON.parse(resultString);

  // Enforce Length Constraints (Post-processing)
  return {
    title: parsedResult.title.substring(0, 30),
    subtitle: parsedResult.subtitle.substring(0, 100),
    keywords: parsedResult.keywords
  };
}

// CLI Argument Parsing
const args = process.argv.slice(2);
const descIndex = args.indexOf('--description');
const localeIndex = args.indexOf('--locale');

if (descIndex === -1 || localeIndex === -1) {
  console.error("Usage: ts-node generateASO.ts --description \"Your text\" --locale \"en-US\"");
  process.exit(1);
}

const description = args[descIndex + 1];
const locale = args[localeIndex + 1];

// Execution
const startTime = Date.now();
const metadata = generateMetadata(description, locale);
const endTime = Date.now();

console.log("Generated Metadata:", metadata);

// Write to file
const filename = `aso_metadata_${locale}.json`;
fs.writeFileSync(filename, JSON.stringify(metadata, null, 2));

console.log(`\n✅ Metadata saved to ${filename} (Process took ${endTime - startTime}ms)`);
