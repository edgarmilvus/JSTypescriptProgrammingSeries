/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// reviewAnalyzer.ts

// Mock Data
const csvData = `
reviewId,text
1,"The app crashes on startup after the latest update."
2,"Great UI, but I found a bug in the settings menu."
3,"Performance is amazing, no issues here."
4,"I keep getting a bug when trying to upload photos."
`;

interface VectorStoreEntry {
  vector: number[];
  text: string;
}

const vectorStore: VectorStoreEntry[] = [];

// 1. Data Loading & Chunking
function parseCSV(csv: string): { id: string, text: string }[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',');
  return lines.slice(1).map(line => {
    const [id, text] = line.split(',');
    return { id, text: text.replace(/"/g, '') }; // Remove quotes
  });
}

function chunkText(text: string, chunkSize: number = 50): string[] {
  const words = text.split(' ');
  const chunks: string[] = [];
  for (let i = 0; i < words.length; i += chunkSize) {
    chunks.push(words.slice(i, i + chunkSize).join(' '));
  }
  return chunks;
}

// 2. Embedding Generation (Simulated)
// We simulate embeddings by converting the text into a vector of word lengths.
// In a real scenario, this would be a dense vector from a Transformer model.
function generateEmbeddings(text: string): number[] {
  return text.split(' ').map(word => word.length);
}

// 3. Retrieval (Cosine Similarity)
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  const dotProduct = vecA.reduce((acc, val, i) => acc + val * (vecB[i] || 0), 0);
  const magnitudeA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  return dotProduct / (magnitudeA * magnitudeB);
}

function retrieve(query: string, topK: number = 3): VectorStoreEntry[] {
  const queryVector = generateEmbeddings(query);
  
  // Calculate similarity for all entries
  const scored = vectorStore.map(entry => ({
    ...entry,
    score: cosineSimilarity(queryVector, entry.vector)
  }));

  // Sort by score descending
  scored.sort((a, b) => b.score - a.score);

  return scored.slice(0, topK);
}

// 4. Synthesis
function synthesizeReport(reviews: VectorStoreEntry[]): string {
  if (reviews.length === 0) return "No relevant issues found.";
  
  const issues = reviews.map(r => `- "${r.text}"`).join('\n');
  return `Summary Report:\nThe following reviews mention critical issues (bugs/crashes):\n${issues}`;
}

// 5. Execution Pipeline
function runPipeline() {
  console.log("Starting RAG Pipeline...\n");
  
  // Load
  const reviews = parseCSV(csvData);
  
  // Chunk & Embed & Store
  reviews.forEach(review => {
    const chunks = chunkText(review.text);
    chunks.forEach(chunk => {
      vectorStore.push({
        vector: generateEmbeddings(chunk),
        text: chunk
      });
    });
  });

  // Query
  const query = "bugs in the latest update";
  console.log(`Query: "${query}"`);
  
  const relevantReviews = retrieve(query);
  
  // Synthesize
  const report = synthesizeReport(relevantReviews);
  console.log("\n" + report);
}

// Run
runPipeline();

/*


::: {style="text-align: center"}
![A diagram illustrating the RAG pipeline, where the Query is vectorized to retrieve relevant text chunks from a vector database, which are then synthesized into a final report.](images/b20_c20_s5_diag1.png){width=80% caption="A diagram illustrating the RAG pipeline, where the Query is vectorized to retrieve relevant text chunks from a vector database, which are then synthesized into a final report."}
:::


*/
