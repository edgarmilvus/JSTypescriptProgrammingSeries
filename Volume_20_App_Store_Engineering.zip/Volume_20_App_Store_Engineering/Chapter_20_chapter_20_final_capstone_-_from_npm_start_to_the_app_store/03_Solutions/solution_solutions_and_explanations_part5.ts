/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// deploySimulator.ts
import readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Helper for delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// ANSI Colors for better UX
const colors = {
  reset: "\x1b[0m",
  cyan: "\x1b[36m",
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
};

const log = (msg: string, color: string = colors.reset) => {
  console.log(`${color}${msg}${colors.reset}`);
};

async function simulatePipeline(commitMsg: string, env: 'Staging' | 'Production') {
  log(`\n🚀 Starting Deployment Pipeline for: "${commitMsg}"`, colors.cyan);
  log(`Target Environment: ${env}`, colors.yellow);
  log('--------------------------------------------------');

  // Step 1: Lint & Test
  process.stdout.write('Running Lint & Tests... ');
  await delay(1000);
  log('PASSED', colors.green);

  // Step 2: EAS Build
  log('Triggering EAS Build...');
  if (env === 'Staging') {
    process.stdout.write('Building .aab (Staging)... ');
    await delay(3000); // Simulated 30s shortened to 3s for demo
    log('DONE', colors.green);
  } else {
    process.stdout.write('Building .aab & .ipa (Production)... ');
    await delay(6000); // Simulated 60s shortened to 6s for demo
    log('DONE', colors.green);
  }

  // Step 3: EAS Submit
  process.stdout.write('Uploading to App Store Connect / Google Play... ');
  await delay(2000); // Simulated 20s shortened to 2s
  log('UPLOADED', colors.green);

  // Step 4: OTA Update
  process.stdout.write('Publishing OTA Update... ');
  await delay(1000); // Simulated 5s shortened to 1s
  log('PUBLISHED', colors.green);

  log('--------------------------------------------------');
  log('✅ Deployment Successful!', colors.green);

  // Interactive Challenge: Rollback
  rl.question('\nDo you want to rollback this deployment? (yes/no): ', async (answer) => {
    if (answer.toLowerCase().startsWith('y')) {
      log('\n⚠️  Initiating Rollback Sequence...', colors.red);
      process.stdout.write('Reverting OTA to previous version... ');
      await delay(1000); // Simulated 10s shortened to 1s
      log('REVERTED', colors.green);
      log('❌ Deployment Rolled Back.', colors.red);
    } else {
      log('\nNo rollback requested. Deployment remains active.', colors.cyan);
    }
    
    rl.close();
  });
}

// Main execution
rl.question('Enter Commit Message: ', (commitMsg) => {
  rl.question('Select Environment (Staging/Production): ', (envInput) => {
    const env = envInput.toLowerCase().startsWith('p') ? 'Production' : 'Staging';
    
    // Run the simulation
    simulatePipeline(commitMsg, env as 'Staging' | 'Production');
  });
});
