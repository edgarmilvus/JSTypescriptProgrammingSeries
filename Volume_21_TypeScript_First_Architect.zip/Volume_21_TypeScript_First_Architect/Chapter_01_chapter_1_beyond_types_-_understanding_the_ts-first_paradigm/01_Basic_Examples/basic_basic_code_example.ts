/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * Defines the structure of a raw incoming HTTP request body for user signup.
 * In a TS-First paradigm, we treat external input as `unknown` initially,
 * but here we model the transport layer contract via an Interface.
 */
interface RawSignupRequest {
  // The body is a raw string because HTTP transmits text; parsing is our job.
  body: string; 
}

/**
 * Zod schema representing the expected shape of our user data.
 * This is the "Source of Truth" for both runtime validation and static types.
 */
const UserSchema = z.object({
  email: z.string().email(),
  age: z.number().int().min(18),
  role: z.enum(['user', 'admin']).default('user')
});

/**
 * We infer the TypeScript type directly from the Zod schema.
 * This is a core TS-First principle: types are derived from runtime logic.
 */
type User = z.infer<typeof UserSchema>;

/**
 * Simulates a non-blocking I/O database operation.
 * Returns a Promise, ensuring the Node.js event loop is not blocked.
 * @param user - The strictly typed User object derived from our schema.
 */
async function saveUserToDatabase(user: User): Promise<{ id: string; status: 'saved' }> {
  // Simulating network latency / disk I/O without blocking the main thread
  await new Promise(resolve => setTimeout(resolve, 10));
  return { id: 'usr_123', status: 'saved' };
}

/**
 * The main handler function for our SaaS signup endpoint.
 * @param req - The raw request interface
 */
async function handleSignup(req: RawSignupRequest): Promise<string> {
  // 1. Parse the raw JSON string (CPU bound, but fast)
  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(req.body);
  } catch (e) {
    return 'Error: Invalid JSON format';
  }

  // 2. Type Narrowing via Zod (Runtime validation + Static type inference)
  const validationResult = UserSchema.safeParse(parsedJson);

  if (!validationResult.success) {
    // TypeScript knows validationResult has the 'error' property here
    return `Validation failed: ${validationResult.error.message}`;
  }

  // 3. Type Narrowing succeeded: validationResult.data is now strictly typed as 'User'
  const validatedUser: User = validationResult.data;

  // 4. Non-Blocking I/O: Awaiting the database save
  const dbResult = await saveUserToDatabase(validatedUser);

  return `User ${validatedUser.email} created with ID ${dbResult.id}`;
}

// Self-contained execution for demonstration
(async () => {
  const mockRequest: RawSignupRequest = {
    body: JSON.stringify({ email: 'dev@saas.app', age: 25 })
  };
  
  const response = await handleSignup(mockRequest);
  console.log(response);
})();
