/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { Effect, pipe } from 'effect';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { eq } from 'drizzle-orm';
import { users } from '@/db/schema'; // Assumed Drizzle schema

/**
 * 1. Runtime Validation via Zod:
 * Defines the exact shape of the API payload. External input cannot be trusted,
 * so we enforce structure and types at runtime, not just compile-time.
 */
const AiPromptSchema = z.object({
  userId: z.string().uuid(),
  prompt: z.string().min(10, 'Prompt must be at least 10 characters'),
  config: z.object({
    temperature: z.number().min(0).max(1).default(0.7),
    maxTokens: z.number().int().positive().default(256)
  }).default({})
});

// Type Inference: TS automatically extracts the validated type from the Zod schema.
// No manual interface needed; it stays perfectly in sync with the runtime validator.
type AiPromptInput = z.infer<typeof AiPromptSchema>;

// Initialize Drizzle (Database Layer) for end-to-end type safety
const client = postgres(process.env.DATABASE_URL!);
const db = drizzle(client);

/**
 * 2. Modeling Side Effects with Effect:
 * We wrap the "Cold Start" of a Local AI Model in an Effect. This makes the 
 * asynchronous, potentially failing operation a strongly-typed, composable value.
 */
const initializeLocalAiModel = (): Effect.Effect<string, Error> =>
  Effect.try({
    try: () => {
      // Simulating fetching model weights and compiling WASM/WebGPU shaders
      console.log('Cold Start: Initializing Local AI Model...');
      return 'model-weights-loaded';
    },
    catch: () => new Error('Cold Start Failed: Model initialization error')
  });

/**
 * 3. Database Interaction via Drizzle (Type-Safe):
 * Queries are inferred from the schema, ensuring our app logic matches the DB.
 */
const fetchUserTier = (userId: string): Effect.Effect<string, Error> =>
  Effect.tryPromise({
    try: async () => {
      const userRecord = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!userRecord.length) throw new Error('User not found');
      return userRecord[0].tier; // 'free' | 'pro' | 'enterprise'
    },
    catch: () => new Error('Database query failed')
  });

/**
 * 4. Composable Workflow:
 * We pipe the effects together. First check DB (Drizzle), then handle Cold Start, then infer.
 */
const aiWorkflow = (input: AiPromptInput) =>
  pipe(
    fetchUserTier(input.userId),
    Effect.flatMap((tier) => {
      if (tier === 'free') return Effect.succeed('Free tier limited response');
      return pipe(
        initializeLocalAiModel(),
        Effect.map(() => `AI Response to: ${input.prompt}`)
      );
    }),
    Effect.catchAll((err) => Effect.succeed(`Fallback: ${err.message}`))
  );

/**
 * 5. Next.js Route Handler:
 * The entry point that orchestrates Runtime Validation, DB checks, and AI execution.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();

  // Runtime Validation boundary
  const parsed = AiPromptSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  // 'parsed.data' is now fully typed via Type Inference
  const validatedInput = parsed.data;

  // Execute the Effect workflow
  const responseText = await Effect.runPromise(aiWorkflow(validatedInput));

  return NextResponse.json({
    success: true,
    output: responseText,
    configUsed: validatedInput.config
  });
}
