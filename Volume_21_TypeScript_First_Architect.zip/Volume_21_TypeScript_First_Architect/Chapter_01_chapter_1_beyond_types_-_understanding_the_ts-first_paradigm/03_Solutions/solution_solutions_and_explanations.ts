/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Schema Definition: Accounts for chaotic legacy API (null/undefined values)
// We use .nullable() and .optional() to reflect reality instead of lying with a strict string.
export const MetricsSchema = z.object({
  timestamp: z.number(),
  // The legacy @types incorrectly asserted string, but API sends null/undefined
  value: z.string().nullable().optional(), 
});

// 2. Type Inference: Extract type from schema
// Unlike the legacy `interface` which is just a compiler illusion (erased at runtime),
// `Metrics` is intrinsically linked to `MetricsSchema`. The compiler trusts it because
// Zod enforces it at runtime via actual JS object traversal.
export type Metrics = z.infer<typeof MetricsSchema>;

// 3. The Parser Function: Enforces Strict Type Discipline with `unknown`
export function parseMetrics(rawData: unknown): Metrics {
  // If validation fails, ZodError propagates naturally to the caller
  return MetricsSchema.parse(rawData);
}

// 4. Safe Consumption: Demonstrating compiler-enforced handling
export function consumeMetrics(rawData: unknown) {
  const metrics = parseMetrics(rawData);
  
  // Because `value` is `string | null | undefined`, the compiler FORCES us to check
  if (metrics.value) {
    // Inside this block, TypeScript narrows `metrics.value` to `string`
    console.log(metrics.value.toUpperCase());
  } else {
    console.log(`Value is missing or null at ${metrics.timestamp}`);
  }
}
