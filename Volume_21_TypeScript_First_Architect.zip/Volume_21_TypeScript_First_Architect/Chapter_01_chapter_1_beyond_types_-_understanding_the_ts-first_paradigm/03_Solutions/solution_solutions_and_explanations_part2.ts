/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { pgTable, uuid, text, timestamp, pgEnum } from 'drizzle-orm/pg-core';
import { InferSelectModel } from 'drizzle-orm';

// 1. Drizzle Schema: Defined once, with strict constraints
export const planEnum = pgEnum('plan', ['free', 'pro', 'enterprise']);

export const tenants = pgTable('tenants', {
  id: uuid('id').primaryKey().notNull(),
  name: text('name').notNull(),
  plan: planEnum('plan').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// 2. Type Inference: Derive domain model directly from DB schema
export type Tenant = InferSelectModel<typeof tenants>;

// 3. The Data Access Layer: Signature reflecting potential absence of data
export async function getTenantById(id: string): Promise<Tenant | undefined> {
  // Drizzle query implementation would go here
  // e.g., return (await db.select().from(tenants).where(eq(tenants.id, id)).limit(1))[0];
  return undefined; 
}

/*
4. The `tsconfig.json` Mandate:
{
  "compilerOptions": {
    "strict": true, // Enables all strict type-checking options
    "strictNullChecks": true // Specifically treats null/undefined as distinct types
  }
}
// With `strictNullChecks: true`, if you attempt to access `tenant.name` on a 
// `Promise<Tenant | undefined>` without a null check, the compiler throws TS2532 
// ("Object is possibly 'undefined'"). This forces exhaustive guards like `if (!tenant) return;`.
*/
