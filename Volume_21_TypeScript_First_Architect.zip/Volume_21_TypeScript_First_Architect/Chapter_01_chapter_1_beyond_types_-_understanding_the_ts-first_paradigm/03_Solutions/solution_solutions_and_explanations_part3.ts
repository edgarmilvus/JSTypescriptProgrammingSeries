/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 2. Zod at the Edge: Schema for telemetry payload
const TelemetrySchema = z.object({
  sensorId: z.string(),
  temperature: z.number(),
  status: z.enum(['active', 'idle']),
});

// 1 & 3. The Edge Function Stub & Rejection Logic
export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }

    try {
      const rawData: unknown = await request.json();
      
      // Validate at the Edge using Zod
      const parsedData = TelemetrySchema.parse(rawData);

      // If successful, forward to Origin (pseudo-code representation)
      // return fetch('https://origin.internal/ingest', { 
      //   method: 'POST', body: JSON.stringify(parsedData) 
      // });
      return new Response('Forwarded to Origin', { status: 200 });
      
    } catch (error) {
      // If Zod parsing fails, it throws a ZodError caught here
      // Reject immediately with 400 to save origin bandwidth/compute
      return new Response('Invalid', { status: 400 });
    }
  }
};

/*
4. Topology Explanation:
Zod is uniquely suited for Edge runtimes like Cloudflare Workers because it is written in pure 
TypeScript/JavaScript with zero native Node.js bindings (no .node files). Edge platforms execute 
code in V8 Isolates—lightweight, secure sandboxes that boot in microseconds and lack access to 
Node.js-specific APIs like `fs` or `net`. Heavier validation libraries like `joi` or `yup` often 
rely on Node.js internals or larger dependency trees that bloat the isolate. Zod's minimal footprint 
and seamless tree-shaking allow it to be deployed at the Edge, moving the validation boundary closer 
to the user. This offloads high-volume, low-complexity validation from expensive centralized database 
clusters to a distributed network, effectively implementing an Edge-First Deployment Strategy.
*/
