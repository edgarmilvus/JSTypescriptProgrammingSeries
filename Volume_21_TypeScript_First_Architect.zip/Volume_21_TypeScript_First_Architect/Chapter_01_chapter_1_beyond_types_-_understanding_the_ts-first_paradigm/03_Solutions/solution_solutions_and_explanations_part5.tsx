/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { z } from 'zod';

// 1. The Zod Contract: Defines expected shape from legacy jQuery iframe
export const UserProfileSchema = z.object({
  avatarUrl: z.string().url(),
  name: z.string(),
  lastLogin: z.number(), // unix timestamp
});

// 4. Strict Props: Use z.infer to get trusted type (NO `any` used)
type UserProfile = z.infer<typeof UserProfileSchema>;

// 2 & 3. The TSX Component with Runtime Guard
export const UserProfileCard: React.FC<{ rawData: unknown }> = ({ rawData }) => {
  // Perform Runtime Validation before touching render logic
  const result = UserProfileSchema.safeParse(rawData);

  if (!result.success) {
    // Fallback UI prevents React tree crash
    return <div>Data Unavailable</div>;
  }

  // TypeScript narrows `result.data` to `UserProfile` here
  const parsed: UserProfile = result.data;

  return (
    <div className="user-card">
      <img src={parsed.avatarUrl} alt={parsed.name} />
      <h2>{parsed.name}</h2>
      <p>Last login: {new Date(parsed.lastLogin * 1000).toLocaleDateString()}</p>
    </div>
  );
};

/*
5. Architectural Justification:
React's built-in `PropTypes` are inferior to Zod in a TypeScript-first paradigm because PropTypes 
are purely runtime decorators that exist outside the `tsc` compiler's semantic graph. They provide 
zero compile-time safety; you could pass a `number` where a `string` is expected and the compiler 
won't care (it only warns at runtime in dev mode). Zod, however, generates a TypeScript type via 
`z.infer` that flows seamlessly into the `tsx` build step. The compiler verifies `src={parsed.avatarUrl}` 
is a `string` before the code is ever shipped, unifying runtime safety and compile-time strictness.
*/
