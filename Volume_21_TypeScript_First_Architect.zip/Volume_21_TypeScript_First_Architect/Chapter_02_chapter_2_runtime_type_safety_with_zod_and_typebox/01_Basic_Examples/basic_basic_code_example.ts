/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import the Zod library, which provides the schema-building namespace `z`
import { z } from 'zod';

/**
 * JSDoc: Defines the schema for a SaaS Tenant Configuration.
 * This schema validates data fetched from an external config API during Server Component rendering.
 * It serves as both a runtime validator and a static type definition.
 */
const TenantConfigSchema = z.object({
  // Validates that the tenant ID is a string and matches a specific UUID-like format (simplified)
  tenantId: z.string().uuid("Tenant ID must be a valid UUID"),
  // Validates the subscription tier against a fixed set of allowed literals
  subscriptionTier: z.enum(["free", "startup", "enterprise"]),
  // Validates that the feature flags are an array of strings
  enabledFeatures: z.array(z.string()),
  // Validates the billing cycle, allowing it to be optional with a fallback default
  billingCycle: z.enum(["monthly", "annual"]).default("monthly"),
});

// Infer the static TypeScript type directly from the Zod schema instance.
// This ensures our compile-time types perfectly mirror our runtime validation rules.
type TenantConfig = z.infer<typeof TenantConfigSchema>;

/**
 * JSDoc: Simulates fetching untrusted external data within a Server Component context.
 * In a real app, this would be a fetch() call to a billing service or internal microservice.
 * @param externalApiResponse - The raw, untyped JSON returned by the external system.
 * @returns A promise resolving to validated config or a formatted error object.
 */
async function validateTenantConfig(externalApiResponse: unknown): Promise<TenantConfig | { error: string }> {
  // Use safeParse to attempt validation without throwing exceptions (critical for serverless stability)
  const validationResult = TenantConfigSchema.safeParse(externalApiResponse);

  // Discriminated union check: if success is false, TypeScript narrows to the error branch
  if (!validationResult.success) {
    // Map over the ZodError issues to create a human-readable string for logging or client response
    const errorMessages = validationResult.error.issues
      .map(issue => `Field ${issue.path.join('.') || 'root'}: ${issue.message}`)
      .join(' | ');
    return { error: `Configuration validation failed: ${errorMessages}` };
  }

  // TypeScript now guarantees that validationResult.data conforms exactly to TenantConfig
  const validatedConfig: TenantConfig = validationResult.data;

  // Simulate passing this validated context to the next stage (e.g., Context Augmentation or DB insert)
  console.log(`Validated config for tenant: ${validatedConfig.tenantId}, Tier: ${validatedConfig.subscriptionTier}`);
  
  return validatedConfig;
}

// Example execution simulating an untrusted payload arriving at the server boundary
const mockExternalResponse = {
  tenantId: "123e4567-e89b-12d3-a456-426614174000",
  subscriptionTier: "enterprise",
  enabledFeatures: ["analytics", "sso"],
  // Note: billingCycle is intentionally omitted to demonstrate the .default() behavior
};

// Invoke the validation logic
validateTenantConfig(mockExternalResponse).then(result => {
  if ('error' in result) {
    console.error(result.error);
  } else {
    console.log("Successfully processed tenant:", result.tenantId);
  }
});
