/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';
import { Type, Static } from '@sinclair/typebox';
import { Value } from '@sinclair/typebox/value';
import * as ort from 'onnxruntime-web';
import { type UIState } from '@/ai/types';
import { NextResponse } from 'next/server';

/**
 * Zod schema defining the expected sentiment analysis output.
 * Zod's ergonomic API allows fluent, chainable validation rules.
 */
const ZodSentimentSchema = z.object({
  label: z.enum(['positive', 'negative', 'neutral']), // Restricts to specific string literals
  confidence: z.number().min(0).max(1), // Enforces numeric bounds for probability
  metadata: z.object({ latencyMs: z.number() }).optional() // Allows optional nested object
});
// Inferring the static TypeScript type directly from the runtime schema
type ZodSentiment = z.infer<typeof ZodSentimentSchema>;

/**
 * TypeBox schema mirroring the Zod definition for JSON Schema compliance.
 * TypeBox is ideal when interfacing with OpenAPI or strict standards.
 */
const TypeBoxSentimentSchema = Type.Object({
  label: Type.Union([
    Type.Literal('positive'),
    Type.Literal('negative'),
    Type.Literal('neutral')
  ]),
  confidence: Type.Number({ minimum: 0, maximum: 1 }),
  metadata: Type.Optional(Type.Object({ latencyMs: Type.Number() }))
});
// Static type extraction via TypeBox's compiler-level utility
type TypeBoxSentiment = Static<typeof TypeBoxSentimentSchema>;

/**
 * Generic validation boundary enforcer using TypeScript Generics.
 * The <T> type variable ensures the returned data matches the expected static type.
 * @param data Untrusted external payload (e.g., from ONNX Runtime Web)
 * @param validator Callback encapsulating the specific library validation logic
 */
function enforceBoundary<T>(data: unknown, validator: (input: unknown) => T): T {
  try {
    // Execute the provided validation closure
    return validator(data);
  } catch (error) {
    // Centralize boundary violation handling
    throw new Error(`Boundary violation: ${error instanceof Error ? error.message : 'Unknown'}`);
  }
}

/**
 * Simulates an ONNX Runtime Web inference session.
 * ONNX models execute in WebAssembly/WebGPU and return raw, untrusted JS objects.
 * @param text The user input string to analyze
 */
async function runONNXInference(text: string): Promise<unknown> {
  // Mocking the post-processed tensor output from a WASM memory heap
  const mockTensorOutput = { 
    label: text.length > 5 ? 'positive' : 'neutral', 
    confidence: 0.92,
    metadata: { latencyMs: 14 }
  };
  return mockTensorOutput;
}

/**
 * Advanced Application Script: Bridges ONNX output to Vercel AI SDK UIState.
 * This function validates ML output before it reaches the presentation layer.
 * @param userText The input prompt from the SaaS user
 */
export async function generateSentimentUI(userText: string): Promise<UIState> {
  // 1. Fetch untrusted inference result from ONNX Runtime Web
  const rawResult = await runONNXInference(userText);

  // 2. Validate using Zod via our generic boundary enforcer
  const zodValidated = enforceBoundary<ZodSentiment>(
    rawResult,
    (input) => ZodSentimentSchema.parse(input) // Throws if invalid
  );

  // 3. Cross-validate with TypeBox to demonstrate standards-compliance
  const typeboxValidated = enforceBoundary<TypeBoxSentiment>(
    rawResult,
    (input) => {
      // TypeBox uses a JSON Schema validator under the hood
      if (!Value.Check(TypeBoxSentimentSchema, input)) {
        throw new Error('TypeBox validation failed');
      }
      return input as TypeBoxSentiment;
    }
  );

  // 4. Transform validated data into the Vercel AI SDK UIState
  // UIState manages which React components render based on AIState
  const dynamicUI: UIState = {
    id: crypto.randomUUID(),
    displayComponent: 'SentimentCard',
    props: {
      verdict: zodValidated.label,
      accuracy: typeboxValidated.confidence,
      processingTime: zodValidated.metadata?.latencyMs ?? 0
    }
  };

  return dynamicUI;
}

/**
 * Next.js App Router API Route handling the request lifecycle.
 * @param request The incoming HTTP request containing untrusted body data
 */
export async function POST(request: Request) {
  // Parse the incoming request body (another untrusted boundary)
  const body = await request.json();
  // Validate the request shape using a lightweight inline Zod schema
  const parseResult = z.object({ text: z.string().min(1) }).safeParse(body);
  
  // Guard clause for invalid API payloads
  if (!parseResult.success) {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }

  // Execute the advanced application script with validated input
  const uiState = await generateSentimentUI(parseResult.data.text);
  
  // Return the safely typed UIState to the client for rendering
  return NextResponse.json({ uiState }, { status: 200 });
}
