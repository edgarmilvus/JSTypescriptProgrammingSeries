/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1 & 2. Define the domain entity schema using Zod primitives
const ServerMetricsSchema = z.object({
  cpuLoad: z.number(),
  memoryUsage: z.number(),
  region: z.string(),
});

// 3. Utilize z.infer to derive the static TypeScript type from the schema
type ServerMetrics = z.infer<typeof ServerMetricsSchema>;

// 5. Reflection on "Under the Hood":
// Using `unknown` as the parameter type for boundary functions is superior to using the inferred type directly
// because at the system boundary (e.g., API responses, user input), we cannot trust that the data actually 
// matches our type. If we typed the parameter as `ServerMetrics`, TypeScript would assume it's already valid, 
// bypassing the runtime validation that Zod provides. `unknown` forces us to prove the data's shape via safeParse.

// 4. Implement validateMetrics function
function validateMetrics(input: unknown): ServerMetrics | { error: string[] } {
  const result = ServerMetricsSchema.safeParse(input);
  
  if (result.success) {
    return result.data; // Typed as ServerMetrics
  } else {
    // Return structured error object containing validation messages
    return {
      error: result.error.issues.map(issue => `${issue.path.join('.')}: ${issue.message}`)
    };
  }
}
