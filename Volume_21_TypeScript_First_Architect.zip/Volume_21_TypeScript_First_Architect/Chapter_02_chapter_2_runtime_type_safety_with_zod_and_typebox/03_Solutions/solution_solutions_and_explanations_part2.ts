/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define base UserSchema
const UserSchema = z.object({
  id: z.string(),
  email: z.string(),
  role: z.enum(['admin', 'user']),
  metadata: z.object({
    lastLogin: z.string(), // Using string to represent ISO date for JSON safety
  }),
});

// 2. Create UserUpdateSchema using Zod's chaining .partial()
const UserUpdateSchema = UserSchema.partial();

// 3. Demonstrate TS Utility Type (Omit)
// We derive PublicUser from the inferred type of UserSchema.
// This alias does not need a corresponding Zod schema if used ONLY internally after validation,
// because the data has already been parsed and validated as a full User by UserSchema, so runtime safety is guaranteed.
type PublicUser = Omit<z.infer<typeof UserSchema>, 'email' | 'metadata'>;

// 4. Construct WebhookEventSchema using z.discriminatedUnion
const UserCreatedEvent = z.object({
  type: z.literal('user.created'),
  payload: UserSchema,
});

const UserDeletedEvent = z.object({
  type: z.literal('user.deleted'),
  payload: z.object({
    id: z.string(),
  }),
});

const WebhookEventSchema = z.discriminatedUnion('type', [
  UserCreatedEvent,
  UserDeletedEvent,
]);

// 5. Write processWebhook function
function processWebhook(data: unknown) {
  const result = WebhookEventSchema.safeParse(data);
  
  if (!result.success) {
    console.error('Webhook validation failed', result.error);
    return;
  }

  // Switch on the inferred 'type' property for distinct handling
  switch (result.data.type) {
    case 'user.created':
      console.log(`Handling created user: ${result.data.payload.id}`);
      break;
    case 'user.deleted':
      console.log(`Handling deleted user: ${result.data.payload.id}`);
      break;
  }
}
