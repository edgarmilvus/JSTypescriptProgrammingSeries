/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo } from 'react';
import { z } from 'zod';

// 2. Define FormConfigSchema
const FormConfigSchema = z.object({
  title: z.string(),
  fields: z.array(
    z.object({
      name: z.string(),
      inputType: z.enum(['text', 'email', 'number']),
      required: z.boolean(),
    })
  ),
});

type FormConfig = z.infer<typeof FormConfigSchema>;

// 1. Build DynamicForm component
export function DynamicForm({ config }: { config: unknown }) {
  // 3. Use useMemo to run safeParse against config prop
  const validationResult = useMemo(() => {
    return FormConfigSchema.safeParse(config);
  }, [config]);

  // 4. If safeParse fails, render error and do NOT render form fields
  if (!validationResult.success) {
    return <div>Invalid Configuration Provided</div>;
  }

  // 5. If success, validationResult.data is strictly typed
  const validConfig: FormConfig = validationResult.data;

  return (
    <form>
      <h2>{validConfig.title}</h2>
      {validConfig.fields.map((field) => (
        <div key={field.name}>
          <label htmlFor={field.name}>{field.name}</label>
          <input
            id={field.name}
            name={field.name}
            type={field.inputType} // Strictly typed within .map() callback
            required={field.required}
          />
        </div>
      ))}
    </form>
  );
}
