/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Type, Static } from '@sinclair/typebox';
import { Value } from '@sinclair/typebox/value';

// 1. Define PaymentGatewayResponse using TypeBox
const PaymentGatewayResponse = Type.Object({
  transactionId: Type.String(),
  status: Type.Union([Type.Literal('success'), Type.Literal('failed')]),
  amount: Type.Number(),
});

// 2. Under the Hood Explanation:
// Unlike Zod's `z.infer` which extracts types from proprietary Zod class instances (_def metadata),
// TypeBox's `Static<typeof Schema>` infers types directly from standard JSON Schema keywords.
// Because Type.Object creates a plain JS object `{ type: 'object', properties: {...} }`,
// TypeScript's conditional types map the 'type' keywords ('string' -> string) at compile time.
type PaymentGatewayResponseType = Static<typeof PaymentGatewayResponse>;

// 3. Output raw JSON Schema object
const rawJsonSchema = PaymentGatewayResponse;
console.log(JSON.stringify(rawJsonSchema, null, 2));

// 4. Write validateGatewayResponse function
function validateGatewayResponse(data: unknown): PaymentGatewayResponseType {
  if (!Value.Check(PaymentGatewayResponse, data)) {
    const errors = [...Value.Errors(PaymentGatewayResponse, data)].map(e => e.message);
    console.error('Schema violation:', errors);
    throw new Error('Invalid Payment Gateway Response');
  }
  return data;
}

// 5. Swagger UI Interoperability:
// The generated JSON Schema (rawJsonSchema) can be directly injected into an OpenAPI/Swagger spec 
// under `components.schemas`. Because it adheres to JSON Schema standards, Swagger UI auto-generates 
// API docs (fields, types) without manually writing YAML or duplicating type definitions.
