/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Rewrite the Contract with Zod
const GatewayEventSchema = z.object({
  id: z.string(),
  timestamp: z.number(),
  data: z.record(z.unknown()),
});

type GatewayEvent = z.infer<typeof GatewayEventSchema>;

// 5. Explain the "Why":
// Replacing `as string` with Zod's `z.string()` eliminates "phantom types" because type assertions 
// blindly tell the compiler to trust the developer, bypassing actual runtime checks and allowing 
// malformed data to enter the system as if it were valid. Zod's validation acts as a true gatekeeper 
// at the application boundary, ensuring that only data matching the exact structural contract 
// (e.g., `id` is truly a string) is processed, thus protecting internal domain logic from corruption.

// 2. Eliminate `any`, use `unknown` for parameter
// 3 & 4. Safe Parsing and Error Handling
class ValidationBoundaryError extends Error {
  constructor(public issues: string[]) {
    super('Validation failed at system boundary');
    this.name = 'ValidationBoundaryError';
  }
}

function processLegacyEvent(input: unknown): GatewayEvent {
  let parsedInput: unknown;
  
  if (typeof input === 'string') {
    try {
      parsedInput = JSON.parse(input);
    } catch (e) {
      throw new ValidationBoundaryError(['Input string is not valid JSON']);
    }
  } else {
    parsedInput = input;
  }

  const result = GatewayEventSchema.safeParse(parsedInput);
  if (!result.success) {
    throw new ValidationBoundaryError(result.error.issues.map(i => `${i.path.join('.')}: ${i.message}`));
  }
  
  return result.data;
}
