/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';
import { Effect, Exit } from 'effect';

/**
 * JSDoc: Defines the strict contract for our LLM's Tool Calling mechanism.
 * We use Zod to mirror the JSON Schema Output we expect from the model.
 * This schema acts as our runtime validation gatekeeper.
 */
const CreateTaskToolSchema = z.object({
  toolName: z.literal('create_task').describe('The specific tool identifier invoked by the LLM'),
  parameters: z.object({
    title: z.string().min(3).describe('The human-readable task title, min 3 chars'),
    priority: z.enum(['low', 'medium', 'high']).describe('The urgency level of the task'),
    assigneeEmail: z.string().email().describe('Valid email of the user to assign the task')
  }).describe('The nested parameters object containing task details')
});

// Simulate the LLM's JSON Schema Output (Tool Calling arguments)
// In a real SaaS app, this string arrives from the OpenAI/Anthropic API response.
const mockLLMResponse = JSON.stringify({
  toolName: 'create_task',
  parameters: {
    title: 'Fix login bug',
    priority: 'high',
    assigneeEmail: 'dev@saas-app.com'
  }
});

/**
 * JSDoc: An Effect workflow that encapsulates the parsing and dynamic validation
 * of the LLM response, leveraging Effect's typed error channels.
 * @param rawJson - The raw stringified JSON from the LLM
 */
const validateAndProcessToolCall = (rawJson: string) =>
  Effect.gen(function* (_) {
    // 1. Safely parse the raw string into a JavaScript object
    const parsedJson = yield* Effect.tryCatch(
      () => JSON.parse(rawJson),
      (e) => new Error(`JSON Parsing Failed: ${(e as Error).message}`)
    );

    // 2. Perform dynamic validation using the Zod schema
    const validationResult = CreateTaskToolSchema.safeParse(parsedJson);
    
    // 3. Conditional branching based on validation outcome (our local "Conditional Edge")
    if (!validationResult.success) {
      return yield* Effect.fail(
        new Error(`Validation Failed: ${validationResult.error.issues.map(i => i.message).join(', ')}`)
      );
    }

    // 4. Return the strongly-typed, validated data via the success channel
    return validationResult.data;
  });

// Execute the program and handle the Exit result
const program = validateAndProcessToolCall(mockLLMResponse);

Effect.runPromiseExit(program).then((exit: Exit.Exit<z.infer<typeof CreateTaskToolSchema>, Error>) => {
  if (Exit.isSuccess(exit)) {
    console.log('Tool Call Validated Successfully:', exit.value);
  } else {
    console.error('Tool Call Failed:', exit.cause);
  }
});
