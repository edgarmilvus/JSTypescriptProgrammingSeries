/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file app/api/triage/route.ts
 * @description Next.js Route Handler demonstrating Advanced Schema Composition 
 * and Dynamic Validation using Zod, Effect, and Drizzle-compatible types.
 */

import { z } from 'zod';
import { Effect, pipe, Cause, Exit } from 'effect';
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db'; // Simulated Drizzle instance
import { tickets } from '@/lib/schema'; // Simulated Drizzle schema

/**
 * @const BaseTicketSchema
 * @description Advanced Schema Composition: We define the base shape that mirrors 
 * our Drizzle `tickets` table to ensure zero drift between DB and Validation layers.
 */
const BaseTicketSchema = z.object({
  title: z.string().min(5, 'Title must be descriptive'),
  description: z.string().min(20, 'Description requires detail'),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']),
});

/**
 * @const LlmTriageSchema
 * @description Extends the base schema with LLM-specific inference fields.
 * This is our target structure for the JSON Schema Output.
 */
const LlmTriageSchema = BaseTicketSchema.extend({
  department: z.enum(['BILLING', 'TECHNICAL', 'GENERAL']),
  sentiment: z.number().min(-1).max(1),
  requiresHuman: z.boolean(),
});

// Type inference for our composed schema
type TriageData = z.infer<typeof LlmTriageSchema>;

/**
 * @function mockLlmCall
 * @description Simulates an LLM call that returns a JSON Schema Output string.
 * In production, this enforces `response_format: { type: 'json_schema' }`.
 */
const mockLlmCall = (userPrompt: string): Effect.Effect<string, Error> =>
  Effect.succeed(
    JSON.stringify({
      title: 'Billing Cycle Confusion',
      description: 'User is confused about the annual billing prompt provided.',
      priority: 'MEDIUM',
      department: 'BILLING',
      sentiment: -0.2,
      requiresHuman: true,
    })
  );

/**
 * @function parseAndValidate
 * @description Dynamic Validation: Uses Zod to safely parse the LLM string.
 */
const parseAndValidate = (raw: string): Effect.Effect<TriageData, z.ZodError> =>
  Effect.tryCatch(
    () => LlmTriageSchema.parse(JSON.parse(raw)),
    (e) => e as z.ZodError
  );

/**
 * @function conditionalEdgeRouter
 * @description Implements the Conditional Edge pattern. Inspects the validated 
 * state and returns the next workflow node name.
 */
const conditionalEdgeRouter = (data: TriageData): string => {
  if (data.requiresHuman && data.priority === 'CRITICAL') return 'escalateNode';
  if (data.department === 'BILLING') return 'billingNode';
  return 'generalNode';
};

/**
 * @function persistToDrizzle
 * @description Simulates persisting the validated data via Drizzle ORM.
 */
const persistToDrizzle = (data: TriageData): Effect.Effect<string, Error> =>
  Effect.tryCatchPromise(
    async () => {
      // await db.insert(tickets).values(data);
      return `Persisted ticket: ${data.title}`;
    },
    (e) => new Error(`DB Fail: ${e}`)
  );

/**
 * @function triageWorkflow
 * @description The main Effect workflow orchestrating the pipeline.
 */
const triageWorkflow = (userPrompt: string) =>
  pipe(
    mockLlmCall(userPrompt),
    Effect.flatMap(parseAndValidate),
    Effect.tap((data) => 
      Effect.log(`Routing via Conditional Edge -> ${conditionalEdgeRouter(data)}`)
    ),
    Effect.flatMap(persistToDrizzle)
  );

/**
 * @function POST
 * @description Next.js Route Handler entry point.
 */
export async function POST(req: NextRequest) {
  const { prompt } = await req.json(); // The User Prompt
  
  const program = triageWorkflow(prompt);
  const result = await Effect.runPromiseExit(program);

  if (Exit.isSuccess(result)) {
    return NextResponse.json({ status: 'success', msg: result.value });
  } else {
    return NextResponse.json({ status: 'error', msg: Cause.pretty(result.cause) }, { status: 400 });
  }
}
