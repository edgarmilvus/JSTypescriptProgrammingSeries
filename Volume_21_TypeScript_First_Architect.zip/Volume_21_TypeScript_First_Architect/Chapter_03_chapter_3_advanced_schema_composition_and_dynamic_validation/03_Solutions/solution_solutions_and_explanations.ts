/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { pgTable, uuid, text, timestamp, pgEnum } from "drizzle-orm/pg-core";

// REQUIREMENT 1: Base Zod Schema with Branding
export const UserId = z.string().uuid().brand<"UserId">();
export type UserId = z.infer<typeof UserId>;

export const UserRole = z.enum(["admin", "editor", "viewer"]);
export type UserRole = z.infer<typeof UserRole>;

// Full BaseUserSchema combining all fields for SSOT
export const BaseUserSchema = z.object({
  id: UserId,
  email: z.string().email(),
  role: UserRole,
  createdAt: z.date(),
  passwordHash: z.string(),
});
export type BaseUser = z.infer<typeof BaseUserSchema>;

// REQUIREMENT 2: Drizzle Table Definition
export const roleEnum = pgEnum("role", ["admin", "editor", "viewer"]);

export const usersTable = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  role: roleEnum("role").notNull().default("viewer"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  passwordHash: text("password_hash").notNull(),
});

// REQUIREMENT 3: API Input Schema (omit server-generated, add password validation)
export const ApiUserInputSchema = BaseUserSchema.omit({
  id: true,
  createdAt: true,
  passwordHash: true,
}).extend({
  password: z.string().refine(
    (val) => val.length >= 8 && /[!@#$%^&*]/.test(val),
    { message: "Password must be at least 8 chars and contain a special character" }
  ),
});
export type ApiUserInput = z.infer<typeof ApiUserInputSchema>;

// REQUIREMENT 4: API Response Schema (omit sensitive, transform dates)
export const ApiUserResponseSchema = BaseUserSchema.omit({
  passwordHash: true,
}).extend({
  createdAt: z.date().transform((date) => date.toISOString()),
});
export type ApiUserResponse = z.infer<typeof ApiUserResponseSchema>;

// REQUIREMENT 5: Composition Function
export function mapDrizzleToApi(row: unknown): ApiUserResponse {
  // Parses the Drizzle row (which has a Date object) and transforms it to API shape
  return ApiUserResponseSchema.parse(row);
}
