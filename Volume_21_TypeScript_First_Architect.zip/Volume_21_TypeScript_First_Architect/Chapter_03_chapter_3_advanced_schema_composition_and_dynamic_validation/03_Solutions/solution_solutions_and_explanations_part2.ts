/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect, Context, Data } from "effect";

// REQUIREMENT 1: Domain Errors
export class SchemaValidationError extends Data.TaggedError("SchemaValidationError")<{
  issues: z.ZodIssue[];
}> {}

export class BusinessRuleViolation extends Data.TaggedError("BusinessRuleViolation")<{
  reason: string;
}> {}

// REQUIREMENT 2: Context
export interface TenantConfig {
  readonly maxFileSize: number;
  readonly allowedMimeTypes: string[];
}

export class TenantConfigTag extends Context.Tag("TenantConfig")<TenantConfigTag, TenantConfig>() {}

// REQUIREMENT 3: Dynamic Schema Factory
export const createDocumentSchema = (config: TenantConfig) => {
  return z.object({
    fileName: z.string(),
    mimeType: z.string().refine((type) => config.allowedMimeTypes.includes(type), {
      message: `Mime type not allowed for this tenant`,
    }),
    size: z.number().positive().refine((size) => size <= config.maxFileSize, {
      message: `File size exceeds tenant limit`,
    }),
  });
};

// REQUIREMENT 4 & 5: Validation Workflow
export const validateUpload = (
  input: unknown
): Effect.Effect<z.infer<ReturnType<typeof createDocumentSchema>>, SchemaValidationError, TenantConfigTag> => {
  return Effect.gen(function* () {
    const config = yield* TenantConfigTag;
    const schema = createDocumentSchema(config);
    
    // Parse input and map ZodError to SchemaValidationError via Effect.try
    const parsed = yield* Effect.try({
      try: () => schema.parse(input),
      catch: (e) => {
        if (e instanceof z.ZodError) {
          return new SchemaValidationError({ issues: e.issues });
        }
        return new SchemaValidationError({ issues: [] });
      },
    });
    
    return parsed;
  });
};
