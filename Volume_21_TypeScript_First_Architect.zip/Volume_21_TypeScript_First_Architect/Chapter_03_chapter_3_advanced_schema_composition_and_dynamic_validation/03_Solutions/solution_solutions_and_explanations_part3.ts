/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect, Data } from "effect";

// Advanced Edge Case: Coerce priority string to number via preprocessing
export const TicketSchema = z.object({
  ticketId: z.string().uuid(),
  category: z.enum(["billing", "technical", "general"]),
  priority: z.preprocess(
    (val) => {
      if (typeof val === "string") {
        const lower = val.toLowerCase();
        if (lower === "high") return 2; // Coerce "high" to 2 per requirements
        if (lower === "low") return 1;
      }
      return val;
    },
    z.number().int().min(1).max(3)
  ),
  summary: z.string().min(10)
});

export type Ticket = z.infer<typeof TicketSchema>;

export class LLMParsingError extends Data.TaggedError("LLMParsingError")<{
  message: string;
  rawResponse: string;
}> {}

// Interactive Challenge Implementation
export const parseLLMResponse = (rawLlmOutput: string): Effect.Effect<Ticket, LLMParsingError, never> => {
  return Effect.gen(function* () {
    // 1. Strip markdown wrappers (e.g., 