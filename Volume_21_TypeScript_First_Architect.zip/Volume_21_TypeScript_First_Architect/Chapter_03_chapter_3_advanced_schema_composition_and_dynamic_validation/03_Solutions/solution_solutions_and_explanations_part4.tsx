/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { streamUI } from "ai/rsc";

// REQUIREMENT 1: Schema Definition
export const UserId = z.string().uuid().brand<"UserId">();
export const UserCardPropsSchema = z.object({
  userId: UserId,
  actionType: z.enum(["view", "edit"]),
});
export type UserCardProps = z.infer<typeof UserCardPropsSchema>;

// REQUIREMENT 3: Client Component (strictly typed via z.infer)
export function UserCard(props: UserCardProps) {
  return (
    <div className="user-card">
      <p>User ID: {props.userId.toString()}</p>
      <button>{props.actionType === "view" ? "View Profile" : "Edit Profile"}</button>
    </div>
  );
}

export function ErrorBoundary({ message }: { message: string }) {
  return <div style={{ color: "red" }}>{message}</div>;
}

// REQUIREMENT 2: Server Action with Validation Logic
export async function streamChat(input: string) {
  const result = await streamUI({
    model: "gpt-4o" as any, // Conceptual model reference
    prompt: input,
    text: ({ content }) => <p>{content}</p>,
    tools: {
      renderUserCard: {
        description: "Displays a user card",
        parameters: UserCardPropsSchema,
        generate: async function* (args) {
          // Stream a text token alongside the component
          yield <p>Fetching user details...</p>;

          // Gatekeeper: Validate LLM args against Zod schema
          const parsed = UserCardPropsSchema.safeParse(args);
          if (!parsed.success) {
            // Prevent malformed props from crashing the RSC payload
            yield <ErrorBoundary message="Invalid Tool Call" />;
            return;
          }
          
          // Props are now mathematically guaranteed safe and branded
          yield <UserCard {...parsed.data} />;
        }
      }
    }
  });
  return result.value;
}
