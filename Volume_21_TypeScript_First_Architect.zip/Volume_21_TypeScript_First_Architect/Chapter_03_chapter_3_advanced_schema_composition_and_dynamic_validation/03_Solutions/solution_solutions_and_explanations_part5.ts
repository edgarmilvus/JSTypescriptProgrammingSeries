/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// REQUIREMENT 1 & 2: Schemas
export const GraphStateSchema = z.object({
  messages: z.array(z.string()),
  retryCount: z.number().int().min(0),
  status: z.enum(["pending", "success", "failed"])
});
export type GraphState = z.infer<typeof GraphStateSchema>;

export const NodeNameSchema = z.enum(["process_data", "error_handler"]);
export type NodeName = z.infer<typeof NodeNameSchema>;

// REQUIREMENT 3 & 4: Conditional Edge Predicate
export function route_state(state: unknown): NodeName {
  // 1. Parse state with GraphStateSchema (Runtime Gatekeeper)
  const parsed = GraphStateSchema.safeParse(state);
  
  // 3. If Zod parsing fails (corrupt state), return safe fallback
  if (!parsed.success) {
    return "error_handler";
  }

  const data = parsed.data;

  // 2. Route based on business logic
  if (data.status === "success") {
    return "process_data";
  }
  
  if (data.status === "failed" || data.retryCount > 3) {
    return "error_handler";
  }

  // Default fallback for unhandled pending states
  return "error_handler";
}
