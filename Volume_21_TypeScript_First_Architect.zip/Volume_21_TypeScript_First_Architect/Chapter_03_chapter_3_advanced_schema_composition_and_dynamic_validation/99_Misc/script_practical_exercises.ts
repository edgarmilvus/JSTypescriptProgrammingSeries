/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { z } from "zod";
import { pgTable, uuid, text, timestamp, pgEnum } from "drizzle-orm/pg-core";

// REQUIREMENT 1: Base Zod Schema with Branding
export const UserId = z.string().uuid().brand<"UserId">();
export type UserId = z.infer<typeof UserId>;

export const UserRole = z.enum(["admin", "editor", "viewer"]);
export type UserRole = z.infer<typeof UserRole>;

// TODO: Define the full BaseUserSchema here combining ID, Role, Email, and CreatedAt
// export const BaseUserSchema = ...

// REQUIREMENT 2: Drizzle Table Definition
export const roleEnum = pgEnum("role", ["admin", "editor", "viewer"]);

export const usersTable = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  role: roleEnum("role").notNull().default("viewer"),
  // TODO: Add createdAt timestamp and passwordHash fields
});

// REQUIREMENT 3 & 4: API Schemas
// TODO: Define ApiUserInputSchema (omit id/createdAt, add password validation)
// TODO: Define ApiUserResponseSchema (omit passwordHash, transform dates)

// REQUIREMENT 5: Composition Function Stub
// Implement the logic that takes a Drizzle row and returns a validated API object
export function mapDrizzleToApi(row: unknown) {
  // YOUR IMPLEMENTATION HERE: Use the schemas to parse and transform
  // DO NOT WRITE THE FULL SOLUTION, ONLY THE STUB AND TYPES
  throw new Error("Exercise 1: Implement mapDrizzleToApi");
}
