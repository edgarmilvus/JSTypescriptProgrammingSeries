/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { z } from "zod";
import { Effect, Data } from "effect";

// JSON Schema Output target definition
export const TicketSchema = z.object({
  ticketId: z.string().uuid(),
  category: z.enum(["billing", "technical", "general"]),
  priority: z.number().int().min(1).max(3),
  summary: z.string().min(10)
});

export type Ticket = z.infer<typeof TicketSchema>;

// Custom Error for the workflow
export class LLMParsingError extends Data.TaggedError("LLMParsingError")<{
  message: string;
  rawResponse: string;
}> {}

// INTERACTIVE CHALLENGE: Implement this function
export const parseLLMResponse = (rawLlmOutput: string): Effect.Effect<Ticket, LLMParsingError, never> => {
  // TODO: 
  // 1. Strip markdown wrappers if present
  // 2. JSON.parse with Effect.tryCatch (catch SyntaxError)
  // 3. TicketSchema.safeParse
  // 4. Map errors to LLMParsingError
  // 5. Handle the 'priority' string coercion edge case in the schema or here
  
  // STARTER STUB - DO NOT PROVIDE FULL SOLUTION IN CHAPTER
  return Effect.fail(new LLMParsingError({ message: "Not implemented", rawResponse: rawLlmOutput }));
};

/*
  SIMULATION CONTEXT:
  const badResponse = '