/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// REQUIREMENT 1: Schema
import { z } from "zod";

export const UserId = z.string().uuid().brand<"UserId">();
export const UserCardPropsSchema = z.object({
  userId: UserId,
  actionType: z.enum(["view", "edit"]),
});
export type UserCardProps = z.infer<typeof UserCardPropsSchema>;

// REQUIREMENT 3: Client Component (TSX)
// Note: 'use client' directive would be here in a real app
export function UserCard(props: UserCardProps) {
  // TODO: Render a styled div showing the user ID and action button
  // This component is safe because props are pre-validated by the server
  return <div>User: {props.userId}</div>;
}

export function ErrorBoundary({ message }: { message: string }) {
  return <div style={{ color: "red" }}>{message}</div>;
}

// REQUIREMENT 2: Server Action Stub (Conceptual)
/*
import { streamUI } from "ai/rsc";
import { openai } from "...");
import { zodFunction } from "...";

export async function streamChat(input: string) {
  const result = await streamUI({
    model: openai("gpt-4o"),
    prompt: input,
    tools: {
      renderUserCard: {
        description: "Displays a user card",
        parameters: UserCardPropsSchema, // Used for LLM JSON Schema Output
        generate: async function* (args) {
          // TODO: Validate 'args' using UserCardPropsSchema
          // If valid: yield <UserCard {...validArgs} />
          // If invalid: yield <ErrorBoundary message="Invalid Tool Call" />
          // DO NOT WRITE THE SOLUTION, PROVIDE ONLY THE STRUCTURE
          yield <ErrorBoundary message="Stub: Implement validation here" />;
        }
      }
    }
  });
  return result.value;
}
