/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// File: drizzle.config.ts
// ==========================================
import type { Config } from 'drizzle-kit';

/**
 * Drizzle Kit configuration.
 * This file instructs the migration generator on where to find your schema
 * and how to connect to the database for introspection and SQL generation.
 */
export default {
  schema: './src/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
} satisfies Config;

// ==========================================
// File: src/schema.ts
// ==========================================
import { pgTable, serial, text, timestamp, varchar } from 'drizzle-orm/pg-core';
import { createInsertSchema, createSelectSchema } from 'drizzle-zod';
import { z } from 'zod';

/**
 * Represents the 'users' table in our SaaS application.
 * This schema definition acts as the single source of truth for both the 
 * database structure (via migrations) and the TypeScript type system.
 */
export const users = pgTable('users', {
  /** Auto-incrementing primary key, mapped to Postgres SERIAL and TS number */
  id: serial('id').primaryKey(),
  /** Unique email for login, max 256 chars, cannot be null */
  email: varchar('email', { length: 256 }).notNull().unique(),
  /** Display name of the user */
  name: text('name').notNull(),
  /** Timestamp of account creation, defaults to now() at the DB level */
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

/**
 * Zod schema for validating untrusted input during user creation.
 * Infers shape, optionality, and constraints directly from the Drizzle schema.
 */
export const insertUserSchema = createInsertSchema(users);

/**
 * Zod schema for validating data selected from the database.
 * Ensures the runtime data matches the static types.
 */
export const selectUserSchema = createSelectSchema(users);

// ==========================================
// File: src/db.ts
// ==========================================
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

/**
 * Initializes the database connection pool using postgres.js
 * and wraps it with Drizzle for type-safe query building.
 */
const connectionString = process.env.DATABASE_URL!;
// Limit max connections to 1 for Serverless/Edge compatibility (e.g., Vercel)
const client = postgres(connectionString, { max: 1 });
export const db = drizzle(client, { schema });

// ==========================================
// File: src/actions.ts
// ==========================================
import { eq } from 'drizzle-orm';
import { db, users } from './db';
import { insertUserSchema, selectUserSchema } from './schema';

/**
 * Server Action / Tool Handler to create a new SaaS user.
 * @param rawInput - Untrusted payload from the client or external LLM tool call.
 */
export async function createSaasUser(rawInput: unknown) {
  // 1. Runtime validation (Zod bridges the static/dynamic gap)
  const validatedData = insertUserSchema.parse(rawInput);

  // 2. Type-safe insertion via Drizzle Query Builder
  const [newUser] = await db.insert(users)
    .values(validatedData)
    .returning();

  // 3. Validate DB output before sending to client (Immutable State principle)
  return selectUserSchema.parse(newUser);
}

/**
 * Fetches a user by their email in a completely type-safe manner.
 * @param email - The email address to look up.
 */
export async function findUserByEmail(email: string) {
  const result = await db.select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  if (result.length === 0) return null;
  return selectUserSchema.parse(result[0]);
}
