/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Drizzle ORM Application Script for RAG Audit Logging.
 * Demonstrates type-safe schema definition, Zod bridging, Generics, and Async I/O.
 */
import { NextRequest, NextResponse } from 'next/server';
import { pgTable, serial, text, jsonb, timestamp, integer } from 'drizzle-orm/pg-core';
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';
import { eq, desc } from 'drizzle-orm';

/**
 * 1. Drizzle Schema: Tenants table for SaaS multi-tenancy.
 * Defined entirely in TypeScript; serves as the source of truth for SQL migrations.
 */
const tenants = pgTable('tenants', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

/**
 * 2. Drizzle Schema: RAG Audit table.
 * Stores Context Augmentation data (retrieved text chunks + query) for LLM tracing.
 */
const ragAudits = pgTable('rag_audits', {
  id: serial('id').primaryKey(),
  tenantId: integer('tenant_id').notNull().references(() => tenants.id),
  query: text('query').notNull(),
  // jsonb column strictly typed as string array for retrieved context chunks
  contextChunks: jsonb('context_chunks').notNull().$type<string[]>(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// 3. Initialize PostgreSQL Pool for Asynchronous Tool Handling (non-blocking I/O)
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema: { tenants, ragAudits } });

// 4. Bridge Drizzle static types with Zod for runtime validation at persistence layer
const RagAuditInsertSchema = createInsertSchema(ragAudits);
type AuditPayload = z.infer<typeof RagAuditInsertSchema>;

/**
 * 5. Generic Type-Safe Query Wrapper.
 * Utilizes TypeScript Generics <T> to enforce return type safety across async boundaries.
 * @param operation - Callback receiving the Drizzle db instance
 * @returns Promise resolving to type T
 */
async function executeTypeSafeQuery<T>(
  operation: (client: typeof db) => Promise<T>
): Promise<T> {
  // Asynchronous Tool Handling: awaiting external DB promise to yield event loop
  return await operation(db);
}

/**
 * Utility: Validate tenant existence before audit insertion.
 * Shows relational integrity via application layer (complementing SQL FKs).
 */
async function assertTenantExists(id: number): Promise<boolean> {
  return executeTypeSafeQuery(async (tx) => {
    const result = await tx.select({ id: tenants.id }).from(tenants).where(eq(tenants.id, id));
    return result.length > 0;
  });
}

/**
 * POST /api/rag/audit
 * Handles persisting Context Augmentation logs for RAG pipelines.
 */
export async function POST(req: NextRequest) {
  try {
    // Parse request body from incoming HTTP stream
    const body = await req.json();
    // Runtime validation via Zod-bridged Drizzle schema (catches bad types at runtime)
    const validatedData: AuditPayload = RagAuditInsertSchema.parse(body);

    // Ensure tenant exists to prevent orphaned RAG audits
    if (!(await assertTenantExists(validatedData.tenantId))) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }

    // Execute type-safe insert within generic wrapper
    const insertedAudit = await executeTypeSafeQuery(async (tx) => {
      const [record] = await tx.insert(ragAudits)
        .values(validatedData)
        .returning();
      return record;
    });

    // Return strongly-typed inserted record to the client
    return NextResponse.json({ success: true, data: insertedAudit }, { status: 201 });
  } catch (error) {
    // Graceful error handling for validation vs database faults
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: 'Invalid payload', issues: error.issues }, { status: 400 });
    }
    return NextResponse.json({ error: 'Internal DB error' }, { status: 500 });
  }
}

/**
 * GET /api/rag/audit?tenantId=1
 * Retrieves recent Context Augmentation logs using inferred queries.
 */
export async function GET(req: NextRequest) {
  const tenantId = Number(req.nextUrl.searchParams.get('tenantId'));
  if (isNaN(tenantId)) return NextResponse.json({ error: 'Bad tenantId' }, { status: 400 });

  // Type-safe select with generics and inferred return types (array of ragAudits)
  const audits = await executeTypeSafeQuery(async (tx) => {
    return await tx.select().from(ragAudits)
      .where(eq(ragAudits.tenantId, tenantId))
      .orderBy(desc(ragAudits.createdAt))
      .limit(10);
  });

  return NextResponse.json({ data: audits });
}

/**
 * DELETE /api/rag/audit?id=123
 * Removes a specific audit log by primary key (Admin utility).
 */
export async function DELETE(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get('id'));
  if (isNaN(id)) return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });

  // Asynchronous Tool Handling: awaiting deletion promise
  await executeTypeSafeQuery(async (tx) => {
    await tx.delete(ragAudits).where(eq(ragAudits.id, id));
  });

  return NextResponse.json({ success: true }, { status: 200 });
}
