/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * Self-Contained Illustrative Example: Drizzle ORM + Neon Serverless + React
 * ----------------------------------------------------------------------------
 * This single block aggregates three logical modules that would normally live
 * in separate files within a Next.js App Router project. It is presented as one
 * contiguous TypeScript/TSX artifact to satisfy the "fully self-contained"
 * requirement while preserving pedagogical clarity.
 * ============================================================================
 */

/* ---------------------------------------------------------------------------
 * MODULE 1 — Database Schema & Serverless Client (Server-side runtime)
 * --------------------------------------------------------------------------- */
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { pgTable, serial, text, timestamp, eq } from 'drizzle-orm/pg-core';

/**
 * Represents a SaaS tenant (customer organization).
 * Drizzle infers a complete TypeScript type from this declaration.
 */
export const tenants = pgTable('tenants', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

/** Neon's serverless driver uses WebSockets instead of raw TCP. */
const connectionString = process.env.DATABASE_URL ?? '';
const pool = new Pool({ connectionString });
const db = drizzle(pool, { schema: { tenants } });

/**
 * Fetches a single tenant by name.
 * @param name - The tenant name to look up
 * @returns The tenant row or undefined
 */
export async function getTenantByName(name: string) {
  const rows = await db.select().from(tenants).where(eq(tenants.name, name));
  return rows[0];
}

/* ---------------------------------------------------------------------------
 * MODULE 2 — Server-Side Resolver (would be 'use server' in production)
 * --------------------------------------------------------------------------- */

/**
 * Wraps the low-level DB query so the client never imports server-only code.
 * In a real app this function lives in a file with the 'use server' directive.
 */
export async function fetchTenantAction(tenantName: string) {
  const tenant = await getTenantByName(tenantName);
  return tenant ?? null;
}

/* ---------------------------------------------------------------------------
 * MODULE 3 — Client Component with useTransition (Browser)
 * --------------------------------------------------------------------------- */
'use client';
import React, { useState, useTransition } from 'react';

/**
 * A minimal SaaS admin UI element that looks up a tenant without blocking input.
 */
export function TenantLookup() {
  const [name, setName] = useState('');
  const [tenantId, setTenantId] = useState<number | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleClick() {
    startTransition(async () => {
      const tenant = await fetchTenantAction(name);
      setTenantId(tenant?.id ?? null);
    });
  }

  return (
    <div>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Tenant name"
      />
      <button onClick={handleClick} disabled={isPending}>
        {isPending ? 'Searching…' : 'Lookup'}
      </button>
      {tenantId !== null && <p>Resolved Tenant ID: {tenantId}</p>}
    </div>
  );
}
