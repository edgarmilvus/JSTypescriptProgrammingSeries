/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file app/api/webhooks/sync/route.ts
 * @description Edge-compatible API route for synchronizing tenant subscription
 * data from an external provider into a Neon serverless Postgres database
 * using Drizzle ORM and Zod for end-to-end type safety.
 */

import { NextResponse } from 'next/server';
import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { z } from 'zod';
import { pgTable, text, timestamp, jsonb, uuid, index } from 'drizzle-orm/pg-core';
import { eq, onConflictDoUpdate } from 'drizzle-orm';

// 1. Define the Drizzle Schema mirroring the serverless DB structure
// This acts as the single source of truth for our table shape.
export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').defaultRandom().primaryKey(),
  tenantId: text('tenant_id').notNull().unique(),
  plan: text('plan').notNull(),
  status: text('status').notNull(),
  metadata: jsonb('metadata').notNull().default({}),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  // Indexing the tenantId for rapid multi-tenant lookups at the edge
  tenantIdx: index('tenant_idx').on(table.tenantId),
}));

// 2. Define the Zod Validation Schema for the incoming Webhook Payload
// We enforce runtime safety before any database I/O occurs.
const WebhookPayloadSchema = z.object({
  type: z.literal('subscription.updated'),
  data: z.object({
    tenantId: z.string().min(1),
    plan: z.enum(['free', 'pro', 'enterprise']),
    status: z.enum(['active', 'canceled', 'past_due']),
    rawPayload: z.record(z.unknown()),
  }),
});

// 3. Configure Edge Runtime for global low-latency execution
// This ensures the function runs in V8 isolates, not Node.js containers.
export const runtime = 'edge';

/**
 * Handles POST requests to synchronize subscription state.
 * Utilizes Neon's HTTP driver for connectionless DB interactions.
 */
export async function POST(request: Request) {
  // 4. Parse and Validate the Request Body using Zod
  const rawBody = await request.json();
  const validationResult = WebhookPayloadSchema.safeParse(rawBody);

  if (!validationResult.success) {
    // Return a structured 400 error if the payload fails validation
    return NextResponse.json(
      { error: 'Invalid payload', details: validationResult.error.flatten() },
      { status: 400 }
    );
  }

  const { data } = validationResult.data;

  // 5. Initialize the Neon HTTP Client (Serverless Connection Pooling)
  // The neon() factory creates a fetch-based SQL executor.
  const sql = neon(process.env.DATABASE_URL!);
  const db = drizzle(sql, { schema: { subscriptions } });

  try {
    // 6. Execute Type-Safe Upsert Operation (Update or Insert)
    // Drizzle translates this chain into a Postgres INSERT...ON CONFLICT query.
    const [record] = await db
      .insert(subscriptions)
      .values({
        tenantId: data.tenantId,
        plan: data.plan,
        status: data.status,
        metadata: data.rawPayload,
      })
      .onConflictDoUpdate({
        target: subscriptions.tenantId,
        set: {
          plan: data.plan,
          status: data.status,
          metadata: data.rawPayload,
          updatedAt: new Date(),
        },
      })
      .returning();

    // 7. Return the newly synchronized record with strict typing
    return NextResponse.json(
      { success: true, record },
      { status: 200 }
    );
  } catch (error) {
    // 8. Graceful Error Handling for Serverless Environments
    console.error('Database synchronization failed:', error);
    return NextResponse.json(
      { error: 'Internal Server Error during sync' },
      { status: 500 }
    );
  }
}
