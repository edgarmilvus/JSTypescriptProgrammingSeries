/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import { pgTable, uuid, text, timestamp, jsonb, InferSelectModel } from 'drizzle-orm/pg-core';

// 1. Schema Definition
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').unique().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  metadata: jsonb('metadata'),
});

// InferSelectModel extracts the TS type from the runtime schema
export type User = InferSelectModel<typeof users>;

// db.ts
import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import * as schema from './schema';

// 2. Database Client Initialization at module scope
const sql = neon(process.env.DATABASE_URL!);
export const db = drizzle(sql, { schema });

// data-fetching.ts
import { desc } from 'drizzle-orm';
import { db, users } from './db';
import type { User } from './schema';

// 3. Data Fetching Function
export async function getActiveUsers(limit: number): Promise<User[]> {
  // 4. Type Safety Verification: result is strictly User[]
  const result: User[] = await db
    .select()
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(limit);
  
  // If metadata column changed to text, TS would flag JSON.parse(result[0].metadata) as error
  return result;
}
