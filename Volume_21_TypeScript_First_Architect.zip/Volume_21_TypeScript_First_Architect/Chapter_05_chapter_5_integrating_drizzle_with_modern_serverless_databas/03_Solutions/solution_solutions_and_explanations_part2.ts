/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import { mysqlTable, varchar, text, int, relations } from 'drizzle-orm/mysql-core';
import { InferInsertModel } from 'drizzle-orm';

// 1. Relational Schema Design (No physical FKs)
export const posts = mysqlTable('posts', {
  id: int('id').primaryKey().autoincrement(),
  title: varchar('title', { length: 255 }).notNull(),
  content: text('content').notNull(),
});

export const tags = mysqlTable('tags', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 100 }).notNull().unique(),
});

export const postTags = mysqlTable('post_tags', {
  postId: int('post_id').notNull(),
  tagId: int('tag_id').notNull(),
});

// Logical relations via Drizzle relations API
export const postsRelations = relations(posts, ({ many }) => ({
  postTags: many(postTags),
}));
export const tagsRelations = relations(tags, ({ many }) => ({
  postTags: many(postTags),
}));
export const postTagsRelations = relations(postTags, ({ one }) => ({
  post: one(posts, { fields: [postTags.postId], references: [posts.id] }),
  tag: one(tags, { fields: [postTags.tagId], references: [tags.id] }),
}));

// 2. Drizzle Kit Configuration
// drizzle.config.ts
import type { Config } from 'drizzle-kit';
export default {
  schema: './src/schema.ts',
  out: './drizzle',
  driver: 'mysql2',
  dbCredentials: { uri: process.env.DATABASE_URL! }, // Dev branch
} satisfies Config;

// 3. Zod Interoperability
import { z } from 'zod';
export const createPostSchema = z.object({
  title: z.string().min(1).max(255),
  content: z.string().min(1),
  tagNames: z.array(z.string()).max(10),
});
export type CreatePostInput = z.infer<typeof createPostSchema>;
export type NewPost = InferInsertModel<typeof posts>;
