/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// schema.ts (Drizzle D1)
import { sqliteTable, text, integer, InferSelectModel } from 'drizzle-orm/sqlite-core';

export const comments = sqliteTable('comments', {
  id: text('id').primaryKey(),
  postId: text('post_id').notNull(),
  content: text('content').notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
});
export type Comment = InferSelectModel<typeof comments>;

// server-actions.ts
'use server';
import { z } from 'zod';
import { drizzle } from 'drizzle-orm/d1';
import { comments } from './schema';

// 1. Zod Validation Schema
const CommentSchema = z.object({
  content: z.string().min(1).max(500),
  postId: z.string().uuid(),
});

// 2. Server Action Implementation
export async function submitComment(
  d1: D1Database, 
  formData: FormData
): Promise<{ success: true; comment: Comment } | { success: false; error: string }> {
  const parsed = CommentSchema.safeParse({
    content: formData.get('content'),
    postId: formData.get('postId'),
  });
  if (!parsed.success) return { success: false, error: 'Validation failed' };

  const db = drizzle(d1);
  const newComment: Comment = {
    id: crypto.randomUUID(),
    postId: parsed.data.postId,
    content: parsed.data.content,
    createdAt: new Date(),
  };
  await db.insert(comments).values(newComment);
  return { success: true, comment: newComment };
}

// comments-client.tsx
'use client';
import { useOptimistic, useTransition, useState } from 'react';
import type { Comment } from './schema';
import { submitComment } from './server-actions';

// 3. Client Component & Optimistic UI
export function CommentList({ initialComments, postId, d1Binding }: { initialComments: Comment[]; postId: string; d1Binding: D1Database }) {
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [optimisticComments, addOptimistic] = useOptimistic<Comment[]>(
    comments,
    (state, newComment: Comment) => [...state, newComment]
  );
  const [isPending, startTransition] = useTransition();

  async function handleSubmit(formData: FormData) {
    const tempId = crypto.randomUUID();
    const optimisticComment: Comment = {
      id: tempId, postId,
      content: formData.get('content') as string,
      createdAt: new Date(),
    };
    startTransition(async () => {
      addOptimistic(optimisticComment);
      const res = await submitComment(d1Binding, formData);
      if (res.success) {
        setComments(prev => [...prev.filter(c => c.id !== tempId), res.comment]);
      }
      // On error, React automatically discards optimistic update
    });
  }
  return (
    <form action={handleSubmit}>
      <input name="content" />
      <input type="hidden" name="postId" value={postId} />
      <button disabled={isPending}>Post</button>
      {optimisticComments.map(c => <li key={c.id}>{c.content}</li>)}
    </form>
  );
}
