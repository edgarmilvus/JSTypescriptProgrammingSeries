/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data, Schedule } from 'effect';
import { eq } from 'drizzle-orm';
import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { users } from './schema';

// 1. Error Modeling
export class DatabaseConnectionError extends Data.TaggedError('DatabaseConnectionError')<{
  message: string;
  cause?: unknown;
}> {}

class DrizzleClient extends Data.TaggedClass('DrizzleClient')<{
  db: ReturnType<typeof drizzle>;
}> {}

const makeDbClient = (conn: string) => {
  const sql = neon(conn);
  return new DrizzleClient({ db: drizzle(sql, { schema: { users } }) });
};

// 2. Effect Wrapping
const fetchUserEffect = (id: string) =>
  Effect.gen(function* (_) {
    const client = yield* _(DrizzleClient);
    const result = yield* _(
      Effect.tryPromise({
        try: () => client.db.select().from(users).where(eq(users.id, id)).limit(1),
        catch: (e) => new DatabaseConnectionError({ message: 'Neon timeout', cause: e }),
      })
    );
    return result[0];
  });

// 3. Resilience Policy & 4. Resource Safety
const resilientFetch = (id: string, connString: string) =>
  fetchUserEffect(id).pipe(
    Effect.retry(
      Schedule.exponentialBackoff(10, 2).pipe(Schedule.compose(Schedule.recurs(3)))
    ),
    Effect.provideService(DrizzleClient, makeDbClient(connString))
  );
