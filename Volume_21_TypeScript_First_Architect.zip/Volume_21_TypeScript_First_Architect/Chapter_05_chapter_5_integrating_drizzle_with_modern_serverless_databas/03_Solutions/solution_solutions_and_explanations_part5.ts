/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts (Drizzle for Neon)
import { pgTable, uuid, text, InferSelectModel } from 'drizzle-orm/pg-core';

export const subscriptions = pgTable('subscriptions', {
  userId: uuid('user_id').primaryKey(),
  tier: text('tier').notNull(),
  valid: text('valid').notNull(),
});
export type Subscription = InferSelectModel<typeof subscriptions>;

// tools/lookup-user.ts
import { z } from 'zod';
import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { eq } from 'drizzle-orm';
import { subscriptions } from './schema';

// 2. Refactor the Signature & 4. Type Flow
export const LookupUserSchema = z.object({
  userId: z.string().uuid(),
});
export type LookupUserParams = z.infer<typeof LookupUserSchema>;
export type LookupUserTool = (params: LookupUserParams) => Promise<{ tier: string; valid: boolean }>;

// 3. Edge-Compatible Implementation Plan
export const lookupUserTool: LookupUserTool = async (params) => {
  const parsed = LookupUserSchema.parse(params); // Runtime validation
  const sql = neon(process.env.DATABASE_URL!); // No pg.Pool
  const db = drizzle(sql, { schema: { subscriptions } });
  
  const result = await db.select().from(subscriptions).where(eq(subscriptions.userId, parsed.userId)).limit(1);
  if (result.length === 0) return { tier: 'none', valid: false };
  return { tier: result[0].tier, valid: result[0].valid === 'true' };
};
