/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// ILLUSTRATIVE TYPE STUB (DO NOT WRITE HANDLER LOGIC)
import { z } from 'zod';
import { Effect } from 'effect'; // Optional: if combining with Ex 4

// TODO: Define the Zod schema for LLM params
// export const LookupUserSchema = z.object({ ... });

// TODO: Define the Tool Invocation Signature type
// export type LookupUserTool = (
//   params: z.infer<typeof LookupUserSchema>
// ) => Promise<{ tier: string; valid: boolean }>;

// TODO: Declare the function (no implementation)
// export const lookupUserTool: LookupUserTool = async (params) => {
//    // Must use neon-http + drizzle here, not pg.Pool
// };
