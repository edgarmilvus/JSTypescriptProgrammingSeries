/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Effect, Console, Data } from "effect";

/**
 * Represents a domain-specific error when a user cannot be found in the SaaS tenant.
 * Using `Data.TaggedError` ensures the error is fully typed, immutable, and serializable.
 * This aligns with the principle of Immutable State Management, preventing accidental
 * mutation of error contexts during distributed tracing.
 */
class UserNotFound extends Data.TaggedError("UserNotFound")<{
  readonly userId: string;
}> {}

/**
 * Simulates fetching a user's subscription tier from a remote API or DB.
 * This function returns an `Effect` rather than a Promise, modeling the operation
 * as a declarative value. Runtime Validation would typically occur here via Zod
 * before trusting the external payload.
 * @param userId The unique identifier of the user.
 * @returns An Effect that yields the user's tier or fails with `UserNotFound`.
 */
const fetchUserTier = (userId: string): Effect.Effect<string, UserNotFound> =>
  Effect.gen(function* () {
    // Simulate network latency without blocking the event loop
    yield* Effect.sleep("50 millis");
    
    if (userId === "usr_123") {
      return "Enterprise"; // Success channel returns the tier
    } else {
      // Failure channel returns a typed error, avoiding untyped throws
      return yield* Effect.fail(new UserNotFound({ userId }));
    }
  });

/**
 * The main workflow for greeting a user upon login.
 * @param userId The user identifier.
 * @returns An Effect that produces a greeting string.
 */
const saasLoginGreeting = (userId: string) =>
  Effect.gen(function* () {
    // 1. Fetch the user's tier (composing the previous effect)
    const tier = yield* fetchUserTier(userId);
    
    // 2. Log the login event (a side effect, safely wrapped in the Effect context)
    yield* Console.log(`[Analytics] User ${userId} logged in with ${tier} tier.`);
    
    // 3. Return the computed greeting
    return `Welcome back! You are on the ${tier} plan.`;
  });

// Self-contained execution
const program = saasLoginGreeting("usr_123");

// Effects are lazy; we must run them explicitly at the system boundary.
Effect.runPromise(program)
  .then((greeting) => console.log(greeting))
  .catch((error) => console.error("Failed:", error));
