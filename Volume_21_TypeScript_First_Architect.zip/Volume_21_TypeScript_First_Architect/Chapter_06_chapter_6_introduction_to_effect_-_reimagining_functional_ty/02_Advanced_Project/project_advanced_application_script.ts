/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file SaaS Tenant Configuration Upgrade Workflow
 * @description Advanced Application Script for Chapter 6: Introduction to Effect.
 * Demonstrates ESM, Interfaces, Immutable State Management, and Effect composition.
 */
import { Effect, Context, Data, Layer, pipe } from "effect";
import { NextRequest, NextResponse } from "next/server";

/**
 * @interface TenantConfig
 * @description Defines the immutable structural contract for a SaaS tenant's settings.
 * Using `readonly` enforces Immutable State Management at the type level.
 */
interface TenantConfig {
  readonly tenantId: string;
  readonly features: Readonly<Record<string, boolean>>;
  readonly limits: Readonly<Record<string, number>>;
}

/**
 * @class ConfigNotFoundError
 * @description A typed, tagged error representing a missing tenant configuration.
 * Extends Effect's Data.TaggedError for exhaustive pattern matching.
 */
class ConfigNotFoundError extends Data.TaggedError("ConfigNotFoundError")<{
  readonly tenantId: string;
}> {}

/**
 * @class PersistenceError
 * @description A typed, tagged error for failures during the save operation.
 */
class PersistenceError extends Data.TaggedError("PersistenceError")<{
  readonly message: string;
}> {}

/**
 * @interface ConfigRepository
 * @description Service contract (Interface) for data access, decoupling logic from implementation.
 */
interface ConfigRepository {
  readonly fetch: (tenantId: string) => Effect.Effect<TenantConfig, ConfigNotFoundError>;
  readonly save: (config: TenantConfig) => Effect.Effect<void, PersistenceError>;
}

// Create a Context Tag for dependency injection via Effect's Layer system.
const ConfigRepository = Context.Tag<ConfigRepository>();

// In-memory mock database utilizing ESM export patterns for module-level state.
const mockDb: Record<string, TenantConfig> = {
  "org_123": {
    tenantId: "org_123",
    features: { analytics: true, auditLog: false },
    limits: { apiCalls: 1000, storageMb: 500 }
  }
};

// Implementation of the ConfigRepository Interface using a Mock Layer.
const MockConfigRepository = Layer.succeed(ConfigRepository, {
  fetch: (tenantId) =>
    mockDb[tenantId]
      ? Effect.succeed(mockDb[tenantId])
      : Effect.fail(new ConfigNotFoundError({ tenantId })),
  save: (config) =>
    Effect.sync(() => {
      // Note: Even in mock, we replace the reference to maintain immutability conceptually.
      mockDb[config.tenantId] = config;
    })
});

/**
 * Validates the tenant ID format using a pure Effect function.
 */
const validateTenantId = (id: string): Effect.Effect<string, PersistenceError> =>
  id.startsWith("org_")
    ? Effect.succeed(id)
    : Effect.fail(new PersistenceError({ message: "Invalid tenant ID format" }));

/**
 * Pure function applying Immutable State Management to upgrade a tenant.
 * Returns a brand new object rather than mutating the input.
 */
const upgradeToPremium = (config: TenantConfig): TenantConfig => ({
  ...config,
  features: { ...config.features, auditLog: true, sso: true },
  limits: { ...config.limits, apiCalls: 10000, storageMb: 5000 }
});

/**
 * Next.js Route Handler (ESM export) that executes the Effect workflow.
 */
export async function POST(req: NextRequest) {
  const { tenantId } = await req.json();

  // Compose the workflow using Effect.gen for sequential, typed operations.
  const program = pipe(
    Effect.gen(function* () {
      const validId = yield* validateTenantId(tenantId);
      const repo = yield* ConfigRepository;
      const currentConfig = yield* repo.fetch(validId);
      const upgradedConfig = upgradeToPremium(currentConfig);
      yield* repo.save(upgradedConfig);
      return upgradedConfig;
    }),
    Effect.provide(MockConfigRepository) // Inject the mock dependency
  );

  // Execute and match against the typed error/success channels.
  return pipe(
    program,
    Effect.match({
      onFailure: (error) => NextResponse.json({ error: error.message }, { status: 404 }),
      onSuccess: (config) => NextResponse.json({ success: true, config }, { status: 200 })
    }),
    Effect.runPromise
  );
}
