/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import type { Effect } from 'effect';

// Immutable State Management: Data structures are never modified in place.
// New copies are created via spread or array methods (map/filter) that return new arrays.

// 1. State and Event Interfaces
interface SystemState {
  readonly items: ReadonlyArray<{ readonly id: string; readonly qty: number }>;
}

// Discriminated union for Domain Events
type DomainEvent =
  | { readonly type: 'AddItem'; readonly id: string; readonly qty: number }
  | { readonly type: 'RemoveItem'; readonly id: string };

// 2. Immutable Transformation Function Signature
// Takes state and event, returns a NEW SystemState wrapped in Effect.
declare function applyEvent(state: SystemState, event: DomainEvent): Effect.Effect<SystemState, never, never>;

// 3. Composition (Conceptual)
// We would use Effect.reduce(events, initialState, (acc, event) => applyEvent(acc, event))
// to apply a list of DomainEvents, ensuring each step produces a new immutable snapshot.
