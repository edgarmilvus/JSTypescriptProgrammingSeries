/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file A Hello World level example of managing side effects and synchronous failures
 * using Effect, Zod, and a mocked Supabase client within a Server Action context.
 */

// Import Zod for runtime schema validation at the system boundary
import { z } from "zod";
// Import Effect and its Exit type for modeling side effects and typed errors
import { Effect, Exit } from "effect";

/**
 * @description Mock Supabase Client (JS) to simulate a database side effect.
 * In a production SaaS, this interfaces with PostgreSQL (often hosting the `pgvector` extension).
 * Here, we mock it to keep the example fully self-contained and runnable.
 */
const mockSupabaseClient = {
  // The 'from' method mimics Supabase's table selector for a specific collection
  from: (table: string) => ({
    // The 'insert' method mimics an async database mutation (a side effect)
    insert: async (data: Record<string, unknown>) => {
      // Simulate network latency and an impure side effect (I/O operation)
      await new Promise((resolve) => setTimeout(resolve, 100));
      console.log(`[Supabase Mock] Inserted into ${table}:`, data);
      // Supabase returns an object containing potential errors and the inserted data
      return { error: null, data: { id: "ticket_123", ...data } };
    },
  }),
};

/**
 * @description Zod schema defining the strict shape of a support ticket.
 * This is our first line of defense against synchronous failures when parsing untrusted input.
 */
const SupportTicketSchema = z.object({
  email: z.string().email("Invalid email format"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

/**
 * @description Typed error representing a synchronous validation failure.
 * Using a class with a `_tag` allows Effect to discriminate errors structurally at compile time.
 */
class ValidationError {
  readonly _tag = "ValidationError";
  constructor(readonly message: string) {}
}

/**
 * @description Typed error representing an asynchronous database failure.
 * Separating error types allows the caller to handle DB issues differently from validation issues.
 */
class DatabaseError {
  readonly _tag = "DatabaseError";
  constructor(readonly message: string) {}
}

/**
 * @description The core Effect workflow that models the side effect pipeline.
 * @param input - The untrusted input from the client (e.g., FormData converted to an object).
 */
const submitTicketEffect = (input: unknown) =>
  Effect.gen(function* () {
    // 1. Handle Synchronous Failure: Validate input with Zod inside Effect.tryCatch
    // Zod's .parse() throws synchronously if validation fails. Effect.tryCatch intercepts this.
    const validatedData = yield* Effect.tryCatch(
      () => SupportTicketSchema.parse(input),
      (parseError) =>
        new ValidationError(
          `Validation failed: ${(parseError as Error).message}`
        )
    );

    // 2. Handle Side Effect: Perform async DB insert via the mocked Supabase client
    // Effect.tryPromise wraps the Promise, catching both rejections and mapping them to typed errors.
    const dbResponse = yield* Effect.tryPromise(
      () => mockSupabaseClient.from("tickets").insert(validatedData),
      (dbError) =>
        new DatabaseError(`Insert failed: ${(dbError as Error).message}`)
    );

    // 3. Check for logical DB errors (Supabase often returns errors in the response body)
    if (dbResponse.error) {
      // Effect.fail short-circuits the generator, immediately exiting with our typed DatabaseError
      return yield* Effect.fail(new DatabaseError(dbResponse.error.message));
    }

    // 4. Return Success: Wrap the successful result in Effect.succeed
    return yield* Effect.succeed({ ticketId: dbResponse.data.id });
  });

/**
 * @description Server Action that securely executes on the server.
 * It acts as the system boundary bridging client form submissions to our Effect pipeline.
 */
export async function submitSupportTicketServerAction(
  formData: FormData
): Promise<{ success: boolean; ticketId?: string; error?: string }> {
  // Convert FormData entries into a plain object to pass into the Effect as 'unknown'
  const rawInput = Object.fromEntries(formData.entries());

  // Run the Effect pipeline and capture the Exit (an algebraic data type representing Success or Failure)
  const exit: Exit<{ ticketId: string }, ValidationError | DatabaseError> =
    await Effect.runPromiseExit(submitTicketEffect(rawInput));

  // Pattern match on the Exit type to return a serializable response to the client
  if (exit._tag === "Success") {
    return { success: true, ticketId: exit.value.ticketId };
  } else {
    // In a production app, you would inspect exit.cause to extract the specific typed error message
    return { success: false, error: "An error occurred processing the ticket." };
  }
}
