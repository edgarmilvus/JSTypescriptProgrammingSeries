/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { Effect, pipe, Either } from 'effect';
import { pgTable, uuid, text, boolean, timestamp } from 'drizzle-orm/pg-core';
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';

// 1. Drizzle Schema Definition: Ensures end-to-end type safety with the database.
// The shape of our table is known to TypeScript at compile time.
const chatInteractions = pgTable('chat_interactions', {
  id: uuid('id').defaultRandom().primaryKey(),
  tenantId: uuid('tenant_id').notNull(),
  prompt: text('prompt').notNull(),
  sentiment: text('sentiment').notNull(),
  usedGpu: boolean('used_gpu').notNull(),
  createdAt: timestamp('created_at').notNull(),
});

// Initialize Drizzle with a PostgreSQL connection pool (side effect resource).
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

/**
 * Zod Schema: Defines the strict contract for incoming chatbot requests.
 * This acts as the synchronous boundary validator before any logic executes.
 */
const ChatPayloadSchema = z.object({
  tenantId: z.string().uuid(),
  userPrompt: z.string().min(5).max(2000),
  enableGPU: z.boolean().default(false),
});

type ChatPayload = z.infer<typeof ChatPayloadSchema>;

/**
 * Custom Error Classes: Leveraged by Effect's typed error channels to distinguish
 * failure modes without relying on untyped `throw` statements.
 */
class ValidationFailure {
  readonly _tag = 'ValidationFailure';
  constructor(readonly issues: z.ZodIssue[]) {}
}
class PersistenceFailure {
  readonly _tag = 'PersistenceFailure';
  constructor(readonly cause: unknown) {}
}

/**
 * Simulated Tool 1: Fetches tenant context. Wrapped in Effect.sync to model
 * the impure read of a config or cache as a pure functional description.
 */
const fetchTenantContext = (tenantId: string) =>
  Effect.sync(() => ({ tenantId, tier: 'enterprise', rateLimit: 1000 }));

/**
 * Simulated Tool 2: Analyzes prompt sentiment. A CPU-bound task required
 * by the LLM router to prioritize urgent messages.
 */
const analyzePromptSentiment = (prompt: string) =>
  Effect.sync(() => ({ score: 0.8, label: prompt.includes('urgent') ? 'critical' : 'normal' }));

/**
 * Simulated Tool 3: Verifies WebGPU acceleration availability. In a server
 * context, we check if the environment permits client-side inference offloading.
 */
const verifyGPUAcceleration = (requested: boolean) =>
  Effect.sync(() => ({ gpuAccelerated: requested && process.env.GPU_NODE === 'true' }));

/**
 * Next.js Route Handler: Embodies the AI Chatbot Architecture by keeping
 * all complex routing, validation, and persistence logic server-side.
 */
export async function POST(request: Request) {
  // 2. Boundary Validation: Catch synchronous failures immediately via Zod.
  const rawPayload = await request.json().catch(() => null);
  const validationResult = ChatPayloadSchema.safeParse(rawPayload);
  
  if (!validationResult.success) {
    return NextResponse.json(
      { error: 'Invalid payload', details: validationResult.error.issues },
      { status: 400 }
    );
  }

  const payload: ChatPayload = validationResult.data;

  // 3. Effect Program Construction: Describe the workflow without executing it yet.
  const chatProcessingProgram = pipe(
    // Parallel Tool Execution: Run independent tools concurrently via Effect fibers.
    Effect.all(
      [
        fetchTenantContext(payload.tenantId),
        analyzePromptSentiment(payload.userPrompt),
        verifyGPUAcceleration(payload.enableGPU),
      ],
      { concurrency: 'unbounded' }
    ),
    // 4. Map aggregated tool results to a database persistence side effect.
    Effect.flatMap(([context, sentiment, gpu]) =>
      Effect.tryPromise({
        try: () =>
          db.insert(chatInteractions).values({
            tenantId: context.tenantId,
            prompt: payload.userPrompt,
            sentiment: sentiment.label,
            usedGpu: gpu.gpuAccelerated,
            createdAt: new Date(),
          }).returning({ id: chatInteractions.id }),
        // Capture async DB failures into a typed error channel.
        catch: (e) => new PersistenceFailure(e),
      })
    )
  );

  // 5. Safe Execution: Resolve the Effect to an Either type (Left = Error, Right = Success).
  const outcome = await Effect.either(chatProcessingProgram);

  if (Either.isLeft(outcome)) {
    // Effect forced us to handle the typed error explicitly.
    return NextResponse.json(
      { error: 'Processing failed', reason: outcome.left._tag },
      { status: 500 }
    );
  }

  // 6. Success Path: Return the persisted interaction ID to the client.
  return NextResponse.json({ success: true, interactionId: outcome.right[0].id });
}
