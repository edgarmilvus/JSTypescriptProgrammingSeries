/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect } from "effect";

// 1. Define Zod schema with constraints
export const ServerConfigSchema = z.object({
  port: z.number().int().min(1).max(65535),
  nodeEnv: z.enum(["development", "production"]),
});

// 2. Custom error with discriminative _tag
export class ConfigLoadError {
  readonly _tag = "ConfigLoadError";
  constructor(readonly message: string) {}
}

// 3, 4, 5. Implement the Effect with explicit success and failure types
export const loadServerConfig: Effect.Effect<
  z.infer<typeof ServerConfigSchema>,
  ConfigLoadError
> = Effect.sync(() => {
  // Simulate reading from process.env or a mock object synchronously
  const rawConfig = {
    port: Number(process.env.PORT) || 3000,
    nodeEnv: process.env.NODE_ENV || "development",
  };
  return rawConfig;
}).pipe(
  Effect.flatMap((raw) => {
    // Use Zod's safeParse to validate the raw config
    const parsed = ServerConfigSchema.safeParse(raw);
    if (!parsed.success) {
      // Map parse failure to custom typed error via Effect.fail
      return Effect.fail(new ConfigLoadError(parsed.error.message));
    }
    return Effect.succeed(parsed.data);
  })
);
