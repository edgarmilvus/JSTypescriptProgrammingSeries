/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect } from "effect";

// The numerical vector representation type
export type EmbeddingVector = number[];

// 1. Custom error for API failures with _tag
export class EmbeddingApiError {
  readonly _tag = "EmbeddingApiError";
  constructor(readonly reason: string, readonly statusCode?: number) {}
}

// 2. Interface for the external API client
export interface EmbeddingClient {
  createEmbedding(text: string): Promise<EmbeddingVector>;
}

// 3, 4, 5, 6. Implement the generation function
export const generateTextEmbedding = (
  client: EmbeddingClient,
  text: string
): Effect.Effect<EmbeddingVector, EmbeddingApiError> => {
  return Effect.tryPromise(() => client.createEmbedding(text)).pipe(
    Effect.mapError((unknownError) => {
      // Catch unknown rejection and transform to typed EmbeddingApiError
      const err = unknownError as { status?: number; message?: string };
      return new EmbeddingApiError(
        err.message ?? "Unknown network failure",
        err.status
      );
    })
  );
};
