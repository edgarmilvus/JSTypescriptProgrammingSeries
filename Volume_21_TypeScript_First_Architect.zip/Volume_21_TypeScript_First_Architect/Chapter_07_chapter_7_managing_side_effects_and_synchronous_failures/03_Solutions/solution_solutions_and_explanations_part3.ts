/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect } from "effect";
import { pgTable, text, vector, integer } from "drizzle-orm/pg-core";
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";

export const documents = pgTable("documents", {
  id: integer("id").primaryKey(),
  author: text("author").notNull(),
  content: text("content").notNull(),
  embedding: vector("embedding", { dimensions: 1536 }).notNull(),
});

// 1. Zod schema for search filter input
export const SearchFilterSchema = z.object({
  author: z.string(),
  minLength: z.number().optional(),
});

// 2. Distinct error classes with discriminative _tags
export class DatabaseError {
  readonly _tag = "DatabaseError";
  constructor(readonly message: string = "Query failed") {}
}
export class NotFoundError {
  readonly _tag = "NotFoundError";
  constructor(readonly message: string = "No results") {}
}

// 3, 4, 5, 6, 7. Implement the Effect
export const searchDocumentsByMetadata = (
  db: ReturnType<typeof drizzle>,
  filter: z.infer<typeof SearchFilterSchema>
): Effect.Effect<
  typeof documents.$inferSelect[],
  DatabaseError | NotFoundError
> => {
  return Effect.tryPromise(() => 
    // 4. Perform Metadata Filtering via Drizzle
    db.select().from(documents).where(eq(documents.author, filter.author))
  ).pipe(
    // 5. Map Promise rejection to DatabaseError
    Effect.mapError((e) => new DatabaseError((e as Error).message)),
    // 6. Check empty array and fail with NotFoundError if applicable
    Effect.flatMap((results) => {
      if (results.length === 0) {
        return Effect.fail(new NotFoundError());
      }
      return Effect.succeed(results);
    })
  );
};
