/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from "react";
import { Effect } from "effect";

// 1. Define the error type for inference failures
export class InferenceError {
  readonly _tag = "InferenceError";
  constructor(readonly message: string) {}
}

// 2. Create the React component
export function HeadlessInferencePanel(props: { text: string }) {
  const [state, setState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  // 3. Define an Effect simulating a Web Worker call
  const runInference = (inputText: string): Effect.Effect<number, InferenceError> => {
    return Effect.tryPromise({
      try: () =>
        new Promise<number>((resolve, reject) => {
          setTimeout(() => {
            if (!inputText) reject(new Error("Empty input"));
            else resolve(Math.random() * 2 - 1); // Mock sentiment score between -1 and 1
          }, 500);
        }),
      catch: (e) => new InferenceError((e as Error).message),
    });
  };

  // 5. Execute Effect when text prop changes, mapping to React state
  useEffect(() => {
    if (!props.text) return;
    setState("loading");
    setResult(null);
    setError(null);

    Effect.runPromise(
      Effect.match(runInference(props.text), {
        onFailure: (err) => {
          setError(err.message);
          setState("error");
        },
        onSuccess: (score) => {
          setResult(score);
          setState("success");
        },
      })
    );
  }, [props.text]);

  // 4. Render UI states based on React state
  return (
    <div>
      <h4>Headless Inference</h4>
      {state === "loading" && <p>Loading...</p>}
      {state === "success" && <p>Sentiment Score: {result}</p>}
      {state === "error" && <p>Error: {error}</p>}
      
      {/*
        6. INTERACTIVE CHALLENGE PSEUDO-CODE:
        To unit test, mock the Effect runtime or the `runInference` dependency.
        Provide an Effect that fails with `new InferenceError("Mock failure")`.
        Render <HeadlessInferencePanel text="test" /> and assert that 
        the DOM contains "Error: Mock failure" using a testing library like React Testing Library.
      */}
    </div>
  );
}
