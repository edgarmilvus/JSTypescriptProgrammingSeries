/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect } from "effect";
import { users } from "./schema"; // Assume Drizzle schema exists
import { drizzle } from "drizzle-orm/node-postgres";

const db = drizzle(); // Mock DB instance

// 2. Zod schema for UserInput
export const UserInputSchema = z.object({
  name: z.string(),
  bio: z.string(),
});

// 3. Custom error classes with unique _tags
export class ValidationError {
  readonly _tag = "ValidationError";
  constructor(readonly message: string) {}
}
export class EmbeddingError {
  readonly _tag = "EmbeddingError";
  constructor(readonly message: string) {}
}
export class DbError {
  readonly _tag = "DbError";
  constructor(readonly message: string) {}
}

/*
  9. INTERACTIVE CHALLENGE EXPLANATION:
  The legacy code was vulnerable to an "undefined embedding" bug because it blindly accessed 
  `embeddingJson.data[0].embedding` without validating the external API's response shape. 
  If the API changed, `embedding` would be `undefined` and passed to the DB insert, causing a 
  runtime SQL error. By introducing a Zod schema for the embedding API response (and user input), 
  we enforce runtime validation. Furthermore, Effect's typed error channel (`E`) and strict 
  compile-time checks ensure that if any step fails (returning ValidationError, EmbeddingError, 
  or DbError), the success branch with the database insert cannot execute, eliminating "exception 
  blindness" and ensuring only fully validated data reaches the database.
*/

// 4, 5, 6, 7, 8. Refactored pipeline
export const processUserPipeline = (
  input: string
): Effect.Effect<
  typeof users.$inferSelect,
  ValidationError | EmbeddingError | DbError
> => {
  return Effect.sync(() => JSON.parse(input)).pipe(
    // 5. Map JSON parse failures to ValidationError
    Effect.mapError((e) => new ValidationError("JSON Parse failed: " + (e as Error).message)),
    Effect.flatMap((raw) => {
      // Validate shape with Zod
      const parsed = UserInputSchema.safeParse(raw);
      if (!parsed.success) {
        return Effect.fail(new ValidationError("Schema validation failed"));
      }
      return Effect.succeed(parsed.data);
    }),
    Effect.flatMap((userData) =>
      // 6. Embedding Generation via fetch
      Effect.tryPromise({
        try: () => 
          fetch("https://api.openai.com/v1/embeddings", {
            method: "POST",
            body: JSON.stringify({ input: userData.bio }),
          }).then((res) => res.json()),
        catch: (e) => new EmbeddingError("API failure: " + (e as Error).message),
      }).pipe(
        Effect.flatMap((embeddingJson: any) => {
          // In a production refactor, validate embeddingJson with Zod here!
          const vector = embeddingJson.data[0].embedding;
          return Effect.succeed(vector);
        }),
        Effect.flatMap((vector) =>
          // 7. Drizzle DB Write
          Effect.tryPromise({
            try: () => 
              db.insert(users).values({
                name: userData.name,
                bio: userData.bio,
                embedding: vector,
              }).returning(),
            catch: (e) => new DbError("DB failure: " + (e as Error).message),
          }).pipe(
            Effect.map((rows) => rows[0]) // Return inserted row
          )
        )
      )
    )
  );
};
