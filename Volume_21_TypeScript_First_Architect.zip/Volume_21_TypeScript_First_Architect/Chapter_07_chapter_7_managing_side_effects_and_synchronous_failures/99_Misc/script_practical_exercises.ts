/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// EXERCISE 1 SCAFFOLDING - TYPE DEFINITIONS AND SIGNATURES ONLY
import { z } from "zod";
import { Effect } from "effect";

// TODO: Define a Zod schema for a ServerConfig containing 'port' (number) and 'nodeEnv' (enum of 'development' | 'production')
// export const ServerConfigSchema = z.object({ ... });

// TODO: Define a custom error class for configuration failures
// export class ConfigLoadError {
//   readonly _tag = "ConfigLoadError";
//   constructor(readonly message: string) {}
// }

// TODO: Declare the Effect type signature. 
// Note: Do not write the generator body; just the type annotation and empty stub.
// export const loadServerConfig: Effect.Effect<
//   z.infer<typeof ServerConfigSchema>,
//   ConfigLoadError
// > = Effect.sync(() => {
//   // Implementation left for the student
//   return {} as any; 
// });
