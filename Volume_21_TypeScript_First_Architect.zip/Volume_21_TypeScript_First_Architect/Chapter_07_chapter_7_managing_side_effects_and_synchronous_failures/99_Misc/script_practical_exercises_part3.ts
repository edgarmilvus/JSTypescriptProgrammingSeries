/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// EXERCISE 3 SCAFFOLDING - DRIZZLE SCHEMA AND EFFECT SIGNATURES
import { z } from "zod";
import { Effect } from "effect";
import { pgTable, text, vector, integer } from "drizzle-orm/pg-core";
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";

// Drizzle Schema Definition
export const documents = pgTable("documents", {
  id: integer("id").primaryKey(),
  author: text("author").notNull(),
  content: text("content").notNull(),
  embedding: vector("embedding", { dimensions: 1536 }).notNull(),
});

// TODO: Define a Zod schema for the search filter input
// export const SearchFilterSchema = z.object({ ... });

// TODO: Define DatabaseError and NotFoundError classes
// export class DatabaseError { readonly _tag = "DatabaseError"; }
// export class NotFoundError { readonly _tag = "NotFoundError"; }

// TODO: Declare the Effect for filtered search
// export const searchDocumentsByMetadata = (
//   db: ReturnType<typeof drizzle>,
//   filter: z.infer<typeof SearchFilterSchema>
// ): Effect.Effect<typeof documents.$inferSelect[], DatabaseError | NotFoundError> => {
//   // Implementation left for the student
//   return Effect.fail(new DatabaseError());
// };
