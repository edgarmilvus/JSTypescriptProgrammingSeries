/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// EXERCISE 4 SCAFFOLDING - REACT TSX COMPONENT REQUEST
import React, { useState } from "react";
import { Effect } from "effect";

// TODO: Define the error type for inference failures
// export class InferenceError {
//   readonly _tag = "InferenceError";
//   constructor(readonly message: string) {}
// }

// FEATURE REQUEST:
// Build a component <HeadlessInferencePanel /> that accepts a 'text' prop.
// It should trigger an Effect that simulates sending the text to a Web Worker
// for Headless Inference, and render the resulting sentiment score or an error message.

// export function HeadlessInferencePanel(props: { text: string }) {
//   const [state, setState] = useState<
//     "idle" | "loading" | "success" | "error"
//   >("idle");
//   const [result, setResult] = useState<number | null>(null);
//   const [error, setError] = useState<string | null>(null);

//   // TODO: Implement an Effect that wraps a mock Worker postMessage
//   // TODO: Use useEffect or an event handler to run the Effect
//   // TODO: Update React state based on Effect success/failure

//   return (
//     <div>
//       <h4>Headless Inference</h4>
//       {/* Render loading spinners, results, or typed errors here */}
//     </div>
//   );
// }
