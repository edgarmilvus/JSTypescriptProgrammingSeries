/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// LEGACY CODE - DO NOT USE THIS PATTERN. REFACTOR IT.
// async function legacyProcessUser(userInput: any) {
//   try {
//     const parsed = JSON.parse(userInput);
//     if (!parsed.name || !parsed.bio) throw new Error("Invalid shape");
//     
//     // Embedding Generation (Side Effect)
//     const embeddingRes = await fetch("https://api.openai.com/v1/embeddings", {
//       method: "POST",
//       body: JSON.stringify({ input: parsed.bio })
//     });
//     const embeddingJson = await embeddingRes.json();
//     const vector = embeddingJson.data[0].embedding;
//     
//     // Drizzle DB Write with Metadata
//     const res = await db.insert(users).values({
//       name: parsed.name,
//       bio: parsed.bio,
//       embedding: vector
//     });
//     return res;
//   } catch (e) {
//     console.error(e);
//     throw e; // Untyped error propagation
//   }
// }
