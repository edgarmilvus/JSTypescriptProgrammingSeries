/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file saas_di_hello_world.ts
 * @description A self-contained example of Effect Context and Layers for SaaS DI.
 * This file demonstrates ESM imports, immutable layer construction, and type-safe resolution.
 */

// 1. Import Effect primitives using ESM (ECMAScript Modules)
import { Effect, Context, Layer } from "effect";

/**
 * JSDoc: Defines the abstract contract for our SaaS Billing Service.
 * We define the shape of the service without any concrete implementation.
 * This adheres to interface segregation principles.
 */
interface BillingService {
  readonly calculateProration: (
    userId: string,
    newPlan: string
  ) => Effect.Effect<number, Error>;
}

/**
 * JSDoc: Creates a type-safe Tag for the BillingService.
 * The string "SaaS/BillingService" is a runtime identifier, while the generic
 * <BillingService> links it to the TypeScript interface for compile-time safety.
 */
const BillingService = Context.Tag<BillingService>("SaaS/BillingService");

/**
 * JSDoc: The Live Layer (Production Implementation).
 * Layer.succeed constructs an immutable layer that provides a concrete object
 * satisfying the BillingService interface.
 */
const LiveBillingLayer = Layer.succeed(BillingService, {
  calculateProration: (userId: string, plan: string) =>
    Effect.sync(() => {
      // Simulating immutable state: we compute and return a new value
      // rather than mutating external state.
      const basePrice = plan === "pro" ? 99.99 : 0;
      return basePrice;
    }),
});

/**
 * JSDoc: The Test Layer (Mock Implementation).
 * Allows us to swap the concrete implementation for testing without touching logic.
 */
const TestBillingLayer = Layer.succeed(BillingService, {
  calculateProration: (userId: string, plan: string) =>
    Effect.succeed(0), // Always free in tests to avoid side effects
});

/**
 * JSDoc: Business Logic Effect.
 * This function is completely decoupled from HOW billing is calculated.
 * It only knows it requires a BillingService in its Context.
 */
const upgradeUserPlan = (userId: string, newPlan: string) =>
  Effect.gen(function* () {
    // Yield the BillingService from the Effect's Context
    const billing = yield* BillingService;
    // Execute the service method, yielding the result
    const cost = yield* billing.calculateProration(userId, newPlan);
    // Return a new string (immutable result)
    return `User ${userId} upgraded to ${newPlan} for $${cost}`;
  });

// 2. Compose the program by providing the Live Layer
const liveProgram = upgradeUserPlan("usr_001", "pro").pipe(
  Effect.provide(LiveBillingLayer)
);

// 3. Conceptual execution (would be run in a Node.js ESM environment)
// Effect.runPromise(liveProgram).then(console.log);
