/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Next.js Route Handler demonstrating Effect's Dependency Injection
 * using Context and Layers within a SaaS RAG (Retrieval-Augmented Generation) architecture.
 * Utilizes ECMAScript Modules (ESM) as the standard module system for Node.js/Next.js.
 */
import { Context, Effect, Layer, Console } from "effect";
import { z } from "zod";

/**
 * Zod Schema for validating the incoming user query payload.
 * Ensures type-safety at the network boundaries of our web application.
 */
const QuerySchema = z.object({ prompt: z.string().min(1) });
type UserQuery = z.infer<typeof QuerySchema>;

/**
 * Service Definition: SystemPrompt
 * Represents the foundational LLM instruction (System Prompt).
 * We use Context.Tag to create a type-safe, nominal dependency identifier.
 */
export class SystemPrompt extends Context.Tag("SystemPrompt")<
  SystemPrompt,
  { readonly instruction: string }
>() {}

/**
 * Service Definition: LLMClient
 * Abstracts the concrete LLM API client, allowing easy mocking for tests.
 */
export class LLMClient extends Context.Tag("LLMClient")<
  LLMClient,
  { readonly generate: (prompt: string) => Effect.Effect<string, Error> }
>() {}

/**
 * Service Definition: RAGService
 * Handles the retrieval of relevant text chunks for Context Augmentation.
 */
export class RAGService extends Context.Tag("RAGService")<
  RAGService,
  { readonly retrieve: (query: string) => Effect.Effect<string[], Error> }
>() {}

/**
 * Layer: SystemPromptLive
 * Provides the concrete implementation of the System Prompt for production.
 * The System Prompt sets foundational context and rules for the LLM.
 */
const SystemPromptLive = Layer.succeed(SystemPrompt, {
  instruction: "You are a precise SaaS analytics assistant. Use provided context only."
});

/**
 * Layer: LLMClientLive
 * Mock implementation of the LLM client returning a synthesized string.
 * In a real app, this would wrap fetch/axios calls to an LLM provider.
 */
const LLMClientLive = Layer.succeed(LLMClient, {
  generate: (prompt) => Effect.sync(() => `[LLM Synthesized Output based on]: ${prompt.substring(0, 50)}...`)
});

/**
 * Layer: RAGServiceLive
 * Mock implementation simulating a vector database lookup for context retrieval.
 */
const RAGServiceLive = Layer.succeed(RAGService, {
  retrieve: (query) => Effect.sync(() => [
    `Retrieved chunk 1 regarding ${query}`,
    `Retrieved chunk 2 regarding ${query}`
  ])
});

/**
 * Business Logic: handleUserQuery
 * The core application script that orchestrates dependencies via Effect.gen.
 * It performs the Context Augmentation step before final LLM synthesis.
 */
const handleUserQuery = (query: UserQuery) =>
  Effect.gen(function* () {
    // Dependency Injection: Effects require services, satisfied by the Layer later
    const sysPrompt = yield* SystemPrompt;
    const llm = yield* LLMClient;
    const rag = yield* RAGService;

    // Context Augmentation: Merge retrieved chunks with the original user query
    const chunks = yield* rag.retrieve(query.prompt);
    const augmentedContext = `${sysPrompt.instruction}\nQuery: ${query.prompt}\nContext: ${chunks.join(" | ")}`;
    
    // Final Synthesis via LLM Client
    const response = yield* llm.generate(augmentedContext);
    yield* Console.log("Augmented generation complete.");
    return response;
  });

/**
 * Compose all required layers into a single application layer.
 * Layer.mergeAll combines contexts without nesting.
 */
const AppLayer = Layer.mergeAll(SystemPromptLive, LLMClientLive, RAGServiceLive);

/**
 * Next.js POST Route Handler (ESM export).
 * Executes the Effect program with the provided Layer, bridging Promise/Async worlds.
 */
export async function POST(req: Request) {
  const body = await req.json();
  const parsed = QuerySchema.safeParse(body);
  if (!parsed.success) return new Response("Bad Request", { status: 400 });

  const program = handleUserQuery(parsed.data).pipe(Effect.provide(AppLayer));
  const result = await Effect.runPromise(program);
  return new Response(JSON.stringify({ output: result }), { status: 200 });
}
