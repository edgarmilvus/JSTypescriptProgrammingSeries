/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer } from "effect";

// 1. Define the Service Interface (purely structural)
export interface ConfigService {
  readonly getApiBaseUrl: () => string;
  readonly getLogLevel: () => "DEBUG" | "INFO" | "ERROR";
}

// 2. Create the Context Tag
// The tag acts as a compile-time key. It holds no runtime value itself, but its 
// phantom type allows TypeScript to track the requirement in the Effect's R channel.
export class ConfigServiceTag extends Context.Tag("ConfigService")<
  ConfigService
>() {}

// 3. Construct the Implementation Layer
export const ConfigLive = Layer.succeed(ConfigServiceTag, {
  getApiBaseUrl: () => process.env.API_BASE_URL ?? "https://fallback.api.com",
  getLogLevel: () => (process.env.LOG_LEVEL as "DEBUG" | "INFO" | "ERROR") ?? "INFO"
});

// 4. Consume the Dependency
export const logStartup = Effect.gen(function* (_) {
  // Yielding the tag brings the implementation into scope and infers R = ConfigService
  const config = yield* _(ConfigServiceTag);
  const logLevel = config.getLogLevel();
  const apiUrl = config.getApiBaseUrl();
  return yield* _(Effect.logInfo(`Startup with ${logLevel} and API: ${apiUrl}`));
});

// 5. Provide and Execute
export const main = logStartup.pipe(Effect.provide(ConfigLive));
