/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer } from "effect";
import { ConfigServiceTag, ConfigLive } from "./exercise1";

// 1. Extend the Service Suite
export interface DatabaseService {
  readonly query: <T>(sql: string) => Effect.Effect<T, Error>;
}

// 2. Define the Database Tag
export class DatabaseServiceTag extends Context.Tag("DatabaseService")<
  DatabaseService
>() {}

// 3. Build the Dependent Layer
// This layer REQUIRES ConfigServiceTag to be present in its input context.
export const DatabaseLive = Layer.effect(
  DatabaseServiceTag,
  Effect.gen(function* (_) {
    const config = yield* _(ConfigServiceTag);
    const baseUrl = config.getApiBaseUrl();
    // Simulate client construction using config
    return {
      query: <T>(sql: string) =>
        Effect.tryPromise({
          try: async () => ({ data: sql } as unknown as T),
          catch: () => new Error("DB Query Failed")
        })
    };
  })
);

// 4. Wire the Graph
// DatabaseLive's RIn is ConfigService; providing ConfigLive resolves this, making AppLayer's RIn 'never'.
export const AppLayer = DatabaseLive.pipe(Layer.provide(ConfigLive));

// 5. Validate Compilation
export const businessLogic = Effect.gen(function* (_) {
  const db = yield* _(DatabaseServiceTag);
  const config = yield* _(ConfigServiceTag);
  yield* _(Effect.logInfo(`Connecting to ${config.getApiBaseUrl()}`));
  return yield* _(db.query<{ id: number }>("SELECT 1"));
});

// Providing AppLayer satisfies both DatabaseService and ConfigService requirements at once
export const mainApp = businessLogic.pipe(Effect.provide(AppLayer));
