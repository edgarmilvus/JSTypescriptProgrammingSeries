/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer, Data } from "effect";

// 1. Define the Gateway Interface & Error
export class PaymentError extends Data.TaggedError("PaymentError")<{
  message: string;
}> {}

export interface PaymentService {
  readonly charge: (
    amount: number,
    cardToken: string
  ) => Effect.Effect<{ transactionId: string }, PaymentError>;
}

// 2. Establish the Tag
export class PaymentServiceTag extends Context.Tag("PaymentService")<
  PaymentService
>() {}

// 3. Implement the Live Layer
export const PaymentLive = Layer.effect(
  PaymentServiceTag,
  Effect.gen(function* (_) {
    return {
      charge: (amount, token) =>
        Effect.delay(
          Effect.succeed({ transactionId: Math.random().toString(36).slice(2) }),
          "500 millis" // Simulate network latency
        )
    };
  })
);

// 4. Implement the Test Layer
export const PaymentTest = Layer.succeed(PaymentServiceTag, {
  charge: (amount, token) =>
    Effect.succeed({ transactionId: "test-transaction-123" }) // Static, no delay
});

// 5. Write the Business Logic
export const processCheckout = (amount: number, token: string) =>
  Effect.gen(function* (_) {
    const payment = yield* _(PaymentServiceTag);
    const result = yield* _(payment.charge(amount, token));
    yield* _(Effect.logInfo(`Processed TxID: ${result.transactionId}`));
    return result;
  });

// 6. Demonstrate Swap
export const runLive = processCheckout(100, "tok_123").pipe(Effect.provide(PaymentLive));
export const runTest = processCheckout(100, "tok_123").pipe(Effect.provide(PaymentTest));
