/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer } from "effect";

// 2. Define the Adapters (Tags)
export interface RandomService { readonly next: () => string; }
export class RandomServiceTag extends Context.Tag("RandomService")<RandomService>() {}

export interface ClockService { readonly now: () => number; }
export class ClockServiceTag extends Context.Tag("ClockService")<ClockService>() {}

export interface ApiClientService {
  readonly post: (url: string, body: unknown) => Effect.Effect<unknown, Error>;
}
export class ApiClientServiceTag extends Context.Tag("ApiClientService")<ApiClientService>() {}

// 4. Construct Layers
export const LiveRandomLayer = Layer.succeed(RandomServiceTag, {
  next: () => Math.random().toString(36)
});

export const LiveClockLayer = Layer.succeed(ClockServiceTag, {
  now: () => Date.now()
});

export const LiveApiLayer = Layer.succeed(ApiClientServiceTag, {
  post: (url, body) =>
    Effect.tryPromise({
      try: () => fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      }).then(res => res.json()),
      catch: () => new Error("Network failure")
    })
});

// 3. Rewrite the Logic
export const processOrderRefactored = (orderId: string) =>
  Effect.gen(function* (_) {
    const random = yield* _(RandomServiceTag);
    const clock = yield* _(ClockServiceTag);
    const api = yield* _(ApiClientServiceTag);

    const randomId = random.next();
    const timestamp = clock.now();
    
    // The R channel explicitly lists RandomService, ClockService, and ApiClientService
    return yield* _(api.post(`https://api.example.com/orders/${orderId}`, { randomId, timestamp }));
  });

// 5. Compose and Run
export const AppLayer = Layer.mergeAll(LiveRandomLayer, LiveClockLayer, LiveApiLayer);
export const runRefactored = processOrderRefactored("order-1").pipe(Effect.provide(AppLayer));
