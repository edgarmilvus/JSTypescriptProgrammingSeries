/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer } from "effect";

// 1. Define Domain Services
export interface UserProfileService {
  readonly getProfile: (userId: string) => Effect.Effect<{ name: string; role: string }>;
}
export class UserProfileTag extends Context.Tag("UserProfileService")<UserProfileService>() {}

export interface ConversationRepository {
  readonly getHistory: (userId: string) => Effect.Effect<string[]>;
}
export class ConversationRepoTag extends Context.Tag("ConversationRepository")<ConversationRepository>() {}

export interface TokenCounterService {
  readonly count: (text: string) => number;
}
export class TokenCounterTag extends Context.Tag("TokenCounterService")<TokenCounterService>() {}

// 2. Implement Live Layers
export const UserProfileLive = Layer.succeed(UserProfileTag, {
  getProfile: (userId) => Effect.succeed({ name: "Alice", role: "Admin" })
});

export const ConversationLive = Layer.succeed(ConversationRepoTag, {
  getHistory: (userId) => Effect.succeed(["Hi", "How are you?", "Tell me about Effect TS".repeat(100)])
});

export const TokenCounterLive = Layer.succeed(TokenCounterTag, {
  count: (text) => Math.ceil(text.length / 4) // ~4 chars/token rule
});

// 3. Build the Augmentation Logic
export const augmentContextForUser = (userId: string) =>
  Effect.gen(function* (_) {
    const profileSvc = yield* _(UserProfileTag);
    const convoSvc = yield* _(ConversationRepoTag);
    const tokenSvc = yield* _(TokenCounterTag);

    const profile = yield* _(profileSvc.getProfile(userId));
    let history = yield* _(convoSvc.getHistory(userId));

    let prompt = `User: ${profile.name} (${profile.role})\nHistory: ${history.join("\n")}`;
    
    // Truncate history if token count exceeds 1000
    while (tokenSvc.count(prompt) > 1000 && history.length > 0) {
      history = history.slice(0, -1);
      prompt = `User: ${profile.name} (${profile.role})\nHistory: ${history.join("\n")}`;
    }

    return prompt;
  });

// 4. Create the React Server Component
export const AppLayer = Layer.mergeAll(UserProfileLive, ConversationLive, TokenCounterLive);

export async function AugmentationPage({ userId }: { userId: string }) {
  // Execute Effect on the server during render phase (no useEffect)
  const augmentedPrompt = await Effect.runPromise(
    augmentContextForUser(userId).pipe(Effect.provide(AppLayer))
  );

  return (
    <div>
      <h1>Augmented Context</h1>
      <pre>{augmentedPrompt}</pre>
    </div>
  );
}
