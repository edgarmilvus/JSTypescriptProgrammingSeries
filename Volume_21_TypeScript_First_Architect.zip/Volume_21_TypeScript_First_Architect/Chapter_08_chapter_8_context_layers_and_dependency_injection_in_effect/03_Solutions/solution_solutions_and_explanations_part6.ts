/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Layer } from "effect";

// Conceptual representation of Layer constructors for this reflection.
// 1. Layer.succeed: Immediate value provision; no effects or resource acquisition.
const SimpleLayer = Layer.succeed(Context.Tag("Simple")<{ x: number }>(), { x: 1 });

// 2. Layer.effect: Runs an effect to build the service, but does not manage a Scope for release.
const EffectLayer = Layer.effect(Context.Tag("Eff")<{ y: number }>(), Effect.succeed({ y: 2 }));

// 3. Layer.scoped: Acquires a resource and guarantees its release via Scope (e.g., DB pool).
const ScopedLayer = Layer.scoped(
  Context.Tag("Scoped")<{ close: () => void }>(),
  Effect.acquireRelease(
    Effect.succeed({ close: () => console.log("closed") }),
    (resource) => Effect.sync(() => resource.close())
  )
);
