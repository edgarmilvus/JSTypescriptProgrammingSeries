/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Effect, Console, Duration } from "effect";

/**
 * SaaS Context: A multi-tenant B2B dashboard orchestrating a Hierarchical Agentic Workflow.
 * The Entry Point Node requires fast user context aggregation before an LLM call
 * with a controlled Temperature. We use Effect Fibers to manage this concurrently.
 */

/**
 * Simulates a fast cache lookup (e.g., Redis) for user session data.
 * @param userId - The unique identifier of the tenant user
 * @returns An Effect that resolves to a session string, failing with Error
 */
const fetchUserSessionFromCache = (userId: string): Effect.Effect<string, Error> =>
  Effect.gen(function* (_) {
    // Describe a logging side-effect (does not execute until runtime)
    yield* _(Console.log("Fiber A: Checking Redis cache for session..."));
    // Simulate 50ms network latency; suspends the fiber, freeing the event loop
    yield* _(Effect.sleep(Duration.millis(50)));
    return `SessionData:${userId}`;
  });

/**
 * Simulates a slower secondary API fallback if the cache is cold.
 * @param userId - The unique identifier of the tenant user
 * @returns An Effect that resolves to a session string, failing with Error
 */
const fetchUserSessionFromApi = (userId: string): Effect.Effect<string, Error> =>
  Effect.gen(function* (_) {
    // Describe a logging side-effect for the fallback path
    yield* _(Console.log("Fiber B: Calling Auth API fallback..."));
    // Simulate 500ms network latency to demonstrate racing advantages
    yield* _(Effect.sleep(Duration.millis(500)));
    return `ApiSessionData:${userId}`;
  });

/**
 * Simulates fetching critical billing data from the primary database.
 * @param userId - The unique identifier of the tenant user
 * @returns An Effect that resolves to billing info, failing with Error
 */
const fetchBillingData = (userId: string): Effect.Effect<string, Error> =>
  Effect.gen(function* (_) {
    // Describe logging for the database query fiber
    yield* _(Console.log("Fiber C: Querying Primary DB for billing..."));
    // Simulate 200ms network latency for DB round-trip
    yield* _(Effect.sleep(Duration.millis(200)));
    return `BillingData:${userId}`;
  });

/**
 * The main orchestration logic for the workflow's Entry Point Node.
 * @param userId - The user accessing the dashboard
 */
const loadDashboardContext = (userId: string) =>
  Effect.gen(function* (_) {
    // Step 1: Race the cache against the API to minimize latency for the Agentic Workflow
    const sessionData = yield* _(
      Effect.race(
        fetchUserSessionFromCache(userId),
        fetchUserSessionFromApi(userId)
      )
    );

    // Step 2: Fetch billing data with a strict 1-second timeout to prevent Vercel/Serverless hangs
    const billingData = yield* _(
      fetchBillingData(userId).pipe(
        Effect.timeout(Duration.seconds(1))
      )
    );

    // Step 3: Combine results and log completion
    yield* _(Console.log(`Context ready: ${sessionData} | ${billingData}`));
    return { sessionData, billingData };
  });

// Entry point execution: Bridges the pure Effect world to the Node.js runtime
const program = loadDashboardContext("tenant-user-123");
Effect.runPromise(program).catch((e) => console.error("Workflow Failed:", e));
