/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { Effect, Fiber, Console, Duration, Schedule, Exit } from 'effect';
import { z } from 'zod';

/**
 * Zod schema validating the hierarchical workflow invocation payload.
 * Ensures type-safe boundaries between the client and server action.
 */
const AgenticTaskSchema = z.object({
  basePrompt: z.string().min(5, 'Prompt too short'),
  temperature: z.number().min(0).max(1).default(0.2),
  strategy: z.enum(['fast', 'balanced', 'creative']).default('balanced')
});

type AgenticTask = z.infer<typeof AgenticTaskSchema>;

/**
 * Simulates a low-level Executor Agent performing a discrete sub-task.
 * Utilizes the Temperature hyperparameter to simulate varying LLM latencies/creativity.
 */
const spawnExecutorFiber = (executorId: string, temp: number, prompt: string) =>
  Effect.gen(function* () {
    yield* Console.log(`[Executor ${executorId}] Initiating task with Temp: ${temp}`);
    // Simulate network/LLM latency proportional to temperature (creativity takes time)
    yield* Effect.sleep(Duration.millis(temp * 1500 + 200));
    const output = `Exec-${executorId}: Refined insight on "${prompt}"`;
    yield* Console.log(`[Executor ${executorId}] Task complete`);
    return output;
  });

/**
 * The Supervisor Agent orchestrates concurrent executors using Effect's structured concurrency.
 * It races the executors and applies a global timeout to ensure responsive UX.
 */
const runSupervisorLayer = (task: AgenticTask) =>
  Effect.gen(function* () {
    // 1. Fork executors into lightweight Fibers (green threads managed by Effect runtime)
    const fiberFast = yield* Effect.fork(spawnExecutorFiber('Fast', task.temperature * 0.1, task.basePrompt));
    const fiberBalanced = yield* Effect.fork(spawnExecutorFiber('Balanced', task.temperature * 0.5, task.basePrompt));
    const fiberCreative = yield* Effect.fork(spawnExecutorFiber('Creative', task.temperature, task.basePrompt));

    // 2. Race the fibers: the first to succeed wins the race
    const raceEffect = Effect.raceAll([fiberFast, fiberBalanced, fiberCreative]);

    // 3. Apply a hard timeout to the race to guarantee the Server Action resolves promptly
    const timedRace = raceEffect.pipe(
      Effect.timeout(Duration.seconds(2)),
      Effect.catchTag('TimeoutException', () =>
        Effect.succeed('Supervisor fallback: All executors exceeded 2s limit')
      )
    );

    // 4. Execute the timed race and capture the winning or fallback result
    const finalResult = yield* timedRace;

    // 5. Graceful interruption: Effect automatically interrupts losers, but we explicitly ensure cleanup
    yield* Fiber.interrupt(fiberFast).pipe(Effect.ignore);
    yield* Fiber.interrupt(fiberBalanced).pipe(Effect.ignore);
    yield* Fiber.interrupt(fiberCreative).pipe(Effect.ignore);

    return finalResult;
  });

/**
 * Utility to log fiber states for observability within the Effect runtime.
 */
const logFiberState = (fiber: Fiber.RuntimeFiber<string, never>) =>
  Effect.gen(function* () {
    const state = yield* Fiber.status(fiber);
    yield* Console.log(`Fiber status: ${state._tag}`);
  });

/**
 * Next.js Server Action: Secure entry point for the Hierarchical Agentic Workflow.
 * Validates input, runs the Effect program, and returns a structured response.
 */
export async function executeAgenticWorkflow(payload: unknown) {
  const validation = AgenticTaskSchema.safeParse(payload);
  if (!validation.success) {
    return { status: 'error', message: 'Validation failed', issues: validation.error.issues };
  }

  // Construct the main Effect program with detailed tracing
  const workflowProgram = runSupervisorLayer(validation.data).pipe(
    Effect.tap(() => Console.log('Supervisor layer completed successfully'))
  );

  try {
    // Run the Effect program to a Promise, bridging Effect's runtime with Next.js
    const result = await Effect.runPromise(workflowProgram);
    return { status: 'success', result };
  } catch (e) {
    return { status: 'error', message: 'Workflow execution failed' };
  }
}
