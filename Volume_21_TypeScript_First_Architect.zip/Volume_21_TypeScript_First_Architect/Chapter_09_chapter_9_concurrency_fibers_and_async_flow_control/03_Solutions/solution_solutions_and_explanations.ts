/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data, Duration } from "effect";

// 1. Define custom error using Data.TaggedError
class GatewayTimeoutError extends Data.TaggedError("GatewayTimeoutError")<{}> {}

// 2. Primary API call mock (simulating slow network)
const primaryProvider = Effect.gen(function* () {
  yield* Effect.sleep(Duration.millis(1200)); // Exceeds 800ms limit
  return "PrimarySuccess";
});

// 3. Fallback API call mock
const fallbackProvider = Effect.gen(function* () {
  yield* Effect.sleep(Duration.millis(1000));
  return "FallbackSuccess";
});

// 4. Timeout on primary, mapping TimeoutException to GatewayTimeoutError
const primaryWithTimeout = primaryProvider.pipe(
  Effect.timeout(Duration.millis(800)),
  Effect.catchTag("TimeoutException", () => Effect.fail(new GatewayTimeoutError()))
);

// 5. Race primary (with timeout) against fallback
const racedProviders = Effect.race(primaryWithTimeout, fallbackProvider);

// 6. Global 2s timeout enforcing GatewayTimeoutError if both fail
const paymentGateway = racedProviders.pipe(
  Effect.timeout(Duration.millis(2000)),
  Effect.catchTag("TimeoutException", () => Effect.fail(new GatewayTimeoutError()))
);

// Effect.runPromise(paymentGateway).then(console.log).catch(console.error);
