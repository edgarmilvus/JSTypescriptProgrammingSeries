/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data, Duration, Schedule } from "effect";

// 1. Type aliases
type TextChunk = string;
type EmbeddingVector = number[];

class EmbeddingError extends Data.TaggedError("EmbeddingError")<{ message: string }> {}

// 2. Mock API function with 150ms latency and 5% random failure
const callEmbeddingApi = (chunk: TextChunk): Promise<EmbeddingVector> =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.05) reject(new Error("API Instability"));
      else resolve(Array.from(chunk).map((c) => c.charCodeAt(0)));
    }, 150);
  });

// 3. Wrap Promise in Effect via tryPromise
const embedEffect = (chunk: TextChunk) =>
  Effect.tryPromise({
    try: () => callEmbeddingApi(chunk),
    catch: (e) => new EmbeddingError({ message: String(e) }),
  }).pipe(
    // 6. Retry only the individual failing call with exponential backoff
    Effect.retry(Schedule.exponential(Duration.millis(100)))
  );

// 4. Batched generation with bounded concurrency of 15
const generateEmbeddingsBatched = (
  chunks: TextChunk[]
): Effect.Effect<EmbeddingVector[], EmbeddingError> =>
  Effect.forEach(chunks, embedEffect, { concurrency: 15 });
