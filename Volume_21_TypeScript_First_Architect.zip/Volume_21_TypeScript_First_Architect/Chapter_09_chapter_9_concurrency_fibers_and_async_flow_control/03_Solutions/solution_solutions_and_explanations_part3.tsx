/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// Client Component (TSX)
"use client";
import React, { useState, useEffect } from "react";

// 5. Client Component invocation function type
type InvokeReport = (signal: AbortSignal) => Promise<string>;

export function HeavyReportButton() {
  const [loading, setLoading] = useState(false);
  const abortControllerRef = React.useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      // 1. Abort if component unmounts while pending
      abortControllerRef.current?.abort();
    };
  }, []);

  const handleClick = async () => {
    setLoading(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;
    try {
      const invoke: InvokeReport = generateHeavyReport;
      const result = await invoke(controller.signal);
      console.log(result);
    } finally {
      setLoading(false);
    }
  };

  return <button onClick={handleClick} disabled={loading}>Generate Heavy Report</button>;
}

// Server Action
"use server";
import { Effect, Duration } from "effect";

// 2 & 5. Server Action Signature and Structure
export async function generateHeavyReport(signal: AbortSignal): Promise<string> {
  // Construct Effect simulating three microservice calls
  const workflow = Effect.gen(function* () {
    yield* Effect.sleep(Duration.millis(1000)); // Microservice 1
    yield* Effect.sleep(Duration.millis(1000)); // Microservice 2
    yield* Effect.sleep(Duration.millis(1000)); // Microservice 3
    return "Report Generated";
  });

  // Note: Full Effect.async interruption wiring described in analysis
  return Effect.runPromise(workflow);
}
