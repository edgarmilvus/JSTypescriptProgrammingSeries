/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data, Duration } from "effect";

// 1. Mock resource type
interface FileHandle {
  id: number;
}

// 2 & 3. acquireRelease with 100ms acquire, 5s use, 50ms release
const acquire = Effect.gen(function* () {
  yield* Effect.sleep(Duration.millis(100));
  console.log("Handle Acquired");
  return { id: 1 } as FileHandle;
});

const release = (handle: FileHandle) =>
  Effect.gen(function* () {
    yield* Effect.sleep(Duration.millis(50));
    console.log(`Handle Released for ${handle.id}`);
  });

const use = (handle: FileHandle) =>
  Effect.gen(function* () {
    yield* Effect.sleep(Duration.millis(5000)); // 5-second processing
    console.log("Processing Complete");
    return handle;
  });

const processFile = Effect.acquireRelease(acquire, release).pipe(
  Effect.flatMap(use)
);

// 4. Wrap in 2s timeout to force interruption
const strictSlaWorkflow = processFile.pipe(
  Effect.timeout(Duration.millis(2000))
);

// Effect.runPromiseExit(strictSlaWorkflow).then(console.log);
