/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS AI Knowledge Base - Resilient Microservice Example
 * Using Effect HTTP, Zod, and mocking Pinecone for vector search.
 */
import { Effect, Layer, Schedule, Duration } from "effect";
import { Api, RouterBuilder, Server } from "effect-http";
import { NodeServer } from "effect-http-node";
import { z } from "zod";

// 1. Define the declarative validation contracts using Zod
const QuerySchema = z.object({
  question: z.string().min(3).describe("User question for the SaaS AI"),
});

const ResponseSchema = z.object({
  answer: z.string(),
  contextDocs: z.array(z.string()),
});

// 2. Define the API Specification (Effect HTTP Contract)
const SaaSApi = Api.make({ title: "AI SaaS API", version: "1.0.0" }).pipe(
  Api.addEndpoint(
    Api.post("askQuestion", "/v1/ask", {
      summary: "Query the AI with Pinecone context",
      request: { body: QuerySchema },
      response: ResponseSchema,
    })
  )
);

// 3. Mock Pinecone Client Integration
const pineconeSearch = (q: string): Effect.Effect<string[]> =>
  Effect.succeed(["doc-123", "doc-456"]).pipe(
    Effect.delay(Duration.millis(50))
  );

// 4. Implement the Handler with Resilience Patterns
const askHandler = RouterBuilder.handler(
  SaaSApi,
  "askQuestion",
  (request) =>
    Effect.gen(function* () {
      // Retrieve context from Pinecone (mocked)
      const docs = yield* pineconeSearch(request.body.question);
      // Simulate AI response generation
      const answer = `Resilient answer for: ${request.body.question}`;
      return { answer, contextDocs: docs };
    }).pipe(
      Effect.timeout(Duration.seconds(2)),
      Effect.retry(Schedule.exponential(Duration.millis(100)))
    )
);

// 5. Build the Router
const appRouter = RouterBuilder.make(SaaSApi).pipe(
  RouterBuilder.handle(askHandler)
);

// 6. Provide Server Layer and Run
const ServerLive = NodeServer.layer({ port: 3000 });

const program = Server.serve(appRouter).pipe(
  Effect.provide(ServerLive)
);

// Execute the Effect (Hello World entrypoint)
await Effect.runPromise(program);
