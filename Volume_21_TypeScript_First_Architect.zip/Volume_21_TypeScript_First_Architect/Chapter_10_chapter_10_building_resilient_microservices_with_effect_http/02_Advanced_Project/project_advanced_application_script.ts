/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { HttpServer, HttpRouter, HttpMiddleware, HttpError } from "@effect/platform";
import { NodeHttpServer } from "@effect/platform-node";
import { Effect, Layer, Schedule, Duration, pipe, Data, Log, Cause } from "effect";
import { z } from "zod";
import * as Http from "node:http";

/**
 * Zod schema defining the strict contract for our SaaS semantic search API.
 * Ensures the incoming vector embedding is correctly shaped before hitting the DB.
 */
const SearchQuerySchema = z.object({
  tenantId: z.string().uuid(),
  embedding: z.array(z.number()).length(1536),
  topK: z.number().int().min(1).max(50).default(10)
});

/** Inferred type from Zod, used internally for type-safety */
type SearchQuery = z.infer<typeof SearchQuerySchema>;

/**
 * Utility Type: Creates an immutable configuration object for our pgvector HNSW setup.
 * Using `Readonly` prevents accidental mutation of critical search parameters.
 */
type VectorDbConfig = Readonly<{
  hnswM: number;
  hnswEfSearch: number;
  connectionPool: number;
}>;

/**
 * Structured, tagged error for failures specifically related to the HNSW Index.
 * Tagged errors allow Effect to discriminate errors at the type level.
 */
class VectorIndexError extends Data.TaggedError("VectorIndexError")<{
  readonly cause: unknown;
  readonly tenantId: string;
}> {}

/**
 * Simulates a resilient query against the HNSW Index (pgvector).
 * Implements automatic retries with exponential backoff and a strict timeout.
 */
const queryHnswIndex = (query: SearchQuery, config: VectorDbConfig) =>
  Effect.gen(function* () {
    yield* Log.info(`Executing ANN search on HNSW (m=${config.hnswM}) for tenant ${query.tenantId}`);
    
    // Simulate a transient failure (e.g., index lock) to demonstrate resilience
    const queryEffect = Effect.gen(function* () {
      if (Math.random() < 0.5) {
        yield* Effect.fail(new VectorIndexError({ cause: "HNSW contention", tenantId: query.tenantId }));
      }
      return { matches: [{ id: "doc_1", score: 0.92 }] };
    });

    return yield* queryEffect.pipe(
      Effect.retry(Schedule.exponential(Duration.millis(50), { max: 3 })),
      Effect.timeout(Duration.seconds(1)),
      Effect.tapErrorCause((cause: Cause.Cause<VectorIndexError>) => 
        Log.error(`HNSW Query failed after retries: ${cause}`)
      )
    );
  });

/**
 * Composable middleware for request tracing and logging.
 * This demonstrates how Effect HTTP allows wrapping the application logic.
 */
const tracingMiddleware = HttpMiddleware.make((app) =>
  (request) => Effect.gen(function* () {
    const start = Date.now();
    yield* Log.info(`Ingress: ${request.method} ${request.url}`);
    const response = yield* app(request);
    yield* Log.info(`Egress: ${request.method} completed in ${Date.now() - start}ms`);
    return response;
  })
);

/**
 * The main router defining our declarative API surface.
 */
const router = HttpRouter.empty.pipe(
  // Health check endpoint for k8s liveness probes
  HttpRouter.get("/health", () => 
    Effect.succeed(HttpServer.response.text("OK"))
  ),
  // The primary semantic search endpoint
  HttpRouter.post("/api/v1/semantic-search", (req) =>
    Effect.gen(function* () {
      const body = yield* HttpServer.request.bodyJson(req);
      const parsed = SearchQuerySchema.safeParse(body);
      
      if (!parsed.success) {
        return yield* HttpError.badRequest("Invalid vector payload");
      }
      
      const dbConfig: VectorDbConfig = { hnswM: 16, hnswEfSearch: 64, connectionPool: 10 };
      
      // Execute the resilient query and map domain errors to HTTP errors
      return yield* queryHnswIndex(parsed.data, dbConfig).pipe(
        Effect.map(HttpServer.response.json),
        Effect.catchTag("VectorIndexError", (err) => 
          HttpError.serviceUnavailable(`Search unavailable: ${err.tenantId}`)
        )
      );
    })
  ),
  HttpRouter.use(tracingMiddleware)
);

// Server layer configuration
const ServerLive = NodeHttpServer.layer(() => Http.createServer(), { port: 8080 });

// Application composition
const App = HttpServer.serve(router).pipe(Layer.provide(ServerLive));

// Runtime Entry Point: Bootstraps the Effect graph (similar to an Entry Point Node in workflows)
Effect.runPromise(Layer.launch(App)).catch((e) => console.error("Fatal Boot Error:", e));
