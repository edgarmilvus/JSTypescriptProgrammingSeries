/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { ApiEndpoint, ApiGroup } from "@effect-http/core";
import { Effect } from "effect";

// Requirement 1: Define Domain Schemas
export const UserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  createdAt: z.string().datetime(),
  role: z.enum(["admin", "user"])
});
export type User = z.infer<typeof UserSchema>;

export const CreateUserSchema = UserSchema.omit({ id: true, createdAt: true });
export type CreateUser = z.infer<typeof CreateUserSchema>;

// Custom Error Schemas
export const UserNotFoundSchema = z.object({ error: z.literal("UserNotFound") });
export const ValidationErrorSchema = z.object({ error: z.literal("ValidationError"), details: z.string() });

// Requirement 2 & 3: Declare Endpoints with Success/Error Responses
export const UserApi = ApiGroup.make("users").pipe(
  ApiGroup.add(
    ApiEndpoint.get("getUser", "/users/:id").pipe(
      ApiEndpoint.setPathParams(z.object({ id: z.string() })),
      ApiEndpoint.setSuccessSchema(200, UserSchema),
      ApiEndpoint.setErrorSchema(404, UserNotFoundSchema),
      ApiEndpoint.setErrorSchema(400, ValidationErrorSchema)
    )
  ),
  ApiGroup.add(
    ApiEndpoint.post("createUser", "/users").pipe(
      ApiEndpoint.setBodySchema(CreateUserSchema),
      ApiEndpoint.setSuccessSchema(201, UserSchema),
      ApiEndpoint.setErrorSchema(400, ValidationErrorSchema)
    )
  )
);

// Requirement 4: Conceptual Handler Signature (Typed via Contract)
// The Effect HTTP framework infers these types directly from the ApiEndpoint above.
// type GetUserHandler = (params: { id: string }) => Effect.Effect<User, z.infer<typeof UserNotFoundSchema>>;
// type CreateUserHandler = (body: CreateUser) => Effect.Effect<User, z.infer<typeof ValidationErrorSchema>>;
