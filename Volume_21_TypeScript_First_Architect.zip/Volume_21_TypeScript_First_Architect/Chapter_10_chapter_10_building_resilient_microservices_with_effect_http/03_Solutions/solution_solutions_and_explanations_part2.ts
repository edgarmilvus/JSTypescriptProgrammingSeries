/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { HttpClient } from "@effect-http/client";
import { Effect, Schedule, Duration, Data } from "effect";

// Requirement 1: Define Custom Tagged Error
export class DownstreamUnavailable extends Data.TaggedError("DownstreamUnavailable")<{
  reason: string;
}> {}

// Requirement 3 & 4: Define Retry Policy and Resilience Wrapper
// Exponential backoff starting at 100ms, max 3 recursions
const retryPolicy = Schedule.exponential(Duration.millis(100)).pipe(
  Schedule.compose(Schedule.recurs(3))
);

// Conceptual composition wrapper (no Effect.gen business logic for the HTTP call itself)
export const withResilience = <A, E>(
  downstreamCall: Effect.Effect<A, E, HttpClient.HttpClient>
): Effect.Effect<A, DownstreamUnavailable, HttpClient.HttpClient> =>
  downstreamCall.pipe(
    // Timeout of 2 seconds applies to EACH individual retry attempt
    Effect.timeout(Duration.seconds(2)),
    // Map TimeoutException to our tagged error
    Effect.catchTag("TimeoutException", () => 
      Effect.fail(new DownstreamUnavailable({ reason: "Downstream call timed out" }))
    ),
    // Map any other network/client error to our tagged error
    Effect.catchAll((err) => 
      Effect.fail(new DownstreamUnavailable({ reason: String(err) }))
    ),
    // Apply the retry schedule
    Effect.retry(retryPolicy)
  );

// Requirement 5: HTTP Layer Error Mapping (Conceptual contract addition)
// ApiEndpoint.setErrorSchema(503, z.object({ error: z.literal("ServiceUnavailable"), reason: z.string() }))
// The framework maps `DownstreamUnavailable` to the 503 JSON body above.
