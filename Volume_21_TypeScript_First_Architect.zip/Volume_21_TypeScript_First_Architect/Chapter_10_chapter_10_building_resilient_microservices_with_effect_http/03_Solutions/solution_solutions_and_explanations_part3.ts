/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Context, Effect, Logger, Random } from "effect";
import { HttpMiddleware, HttpApp, HttpError } from "@effect-http/core";
import { z } from "zod";

// Requirement 1: Authentication Context Service
export class UserSession extends Context.Tag("UserSession")<
  UserSession,
  { userId: string; role: string }
>() {}

const AuthHeaderSchema = z.object({ authorization: z.string().startsWith("Bearer ") });

// Requirement 1: Auth Middleware
export const authMiddleware = HttpMiddleware.make((app) =>
  Effect.gen(function* (_) {
    const headers = yield* HttpApp.requestHeaders; // Conceptual access to headers
    const parsed = AuthHeaderSchema.safeParse(headers);
    if (!parsed.success) {
      return yield* Effect.fail(new HttpError({ status: 401, message: "Unauthorized" }));
    }
    const token = parsed.data.authorization.replace("Bearer ", "");
    // Provide UserSession to the app context
    return yield* Effect.provideService(app, UserSession, { userId: token, role: "user" });
  })
);

// Requirement 2: Logging Middleware
export const loggingMiddleware = HttpMiddleware.make((app) =>
  Effect.gen(function* (_) {
    const correlationId = yield* Random.uuid;
    yield* Logger.logInfo(`[${correlationId}] Incoming request`);
    const [duration, result] = yield* Effect.timed(app);
    yield* Logger.logInfo(`[${correlationId}] Completed in ${duration.toString()}`);
    return result;
  })
);

// Requirement 3: Composition (Logging wraps Auth)
export const securedApp = (app: HttpApp.Default) =>
  app.pipe(
    HttpMiddleware.compose(authMiddleware), // Inner layer
    HttpMiddleware.compose(loggingMiddleware) // Outer layer
  );

// Requirement 4: Updated Handler Dependency (Conceptual)
// The handler now requires UserSession from Context, enforced at compile time:
// type SecureGetUser = (params: { id: string }) => Effect.Effect<User, never, UserSession>;
