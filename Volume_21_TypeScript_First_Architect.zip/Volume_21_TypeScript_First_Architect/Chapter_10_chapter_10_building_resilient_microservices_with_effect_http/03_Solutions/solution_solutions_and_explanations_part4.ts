/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect } from "effect";
// Assumes zod-to-json-schema or equivalent is available for LLM prompt constraint
import { zodToJsonSchema } from "zod-to-json-schema"; 

// Requirement 1: Schema Definition
export const SentimentSchema = z.object({
  label: z.enum(["positive", "negative", "neutral"]),
  confidence: z.number().min(0).max(1)
});
export type Sentiment = z.infer<typeof SentimentSchema>;

// Requirement 2: Gap Analysis & Stub Completion
export const analyzeFeedback = (text: string): Effect.Effect<Sentiment, Error> => {
  // GAP 1 FILLED: JSON Schema extraction happens HERE, before the LLM call,
  // to constrain the model's probabilistic token generation.
  const jsonSchema = zodToJsonSchema(SentimentSchema, "Sentiment");
  
  // Simulated LLM call returning a raw string
  const llmCall = Effect.promise(() => Promise.resolve('{"label":"positive","confidence":0.9}'));

  return llmCall.pipe(
    Effect.flatMap((responseStr) =>
      // GAP 2 FILLED: Zod parse happens HERE, on the LLM response,
      // acting as the final gatekeeper before business logic.
      Effect.try({
        try: () => SentimentSchema.parse(JSON.parse(responseStr)),
        catch: (e) => new Error(`Validation failed: ${String(e)}`)
      })
    )
  );
};

// Requirement 3: Error Mapping (Conceptual Route Addition)
// ApiEndpoint.setErrorSchema(422, z.object({ error: z.literal("UnprocessableEntity"), message: z.string() }))
// The `Error` thrown by Zod parse is mapped to the 422 schema in the HTTP layer.
