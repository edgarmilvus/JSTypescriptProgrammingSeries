/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// File: actions.ts
"use server"; // Requirement 3: Server Action directive
import { Effect, Schedule, Duration } from "effect";
import { HttpClient } from "@effect-http/client";
import { z } from "zod";

// Requirement 4: Zod Contract Alignment
export const ModelStatusSchema = z.object({
  modelName: z.string(),
  quantization: z.enum(["int8", "float32", "none"]),
  isReady: z.boolean()
});
export type ModelStatus = z.infer<typeof ModelStatusSchema>;

// Requirement 1 & 5: Server Action with Resilience
export async function getModelStatus(): Promise<ModelStatus> {
  const fetchEffect = HttpClient.get("http://model-microservice/model/status").pipe(
    HttpClient.schemaBodyJson(ModelStatusSchema), // Runtime validation of response
    Effect.timeout(Duration.seconds(3)), // Critical for quantized model latency spikes
    Effect.retry(Schedule.exponential(Duration.millis(200)).pipe(Schedule.compose(Schedule.recurs(3)))),
    Effect.orFail(new Error("Model microservice unreachable"))
  );
  return Effect.runPromise(fetchEffect); // Run Effect to Promise for RSC
}

// File: ModelDashboard.tsx
// Requirement 2 & 3: Server Component (No "use client" needed for this structural display)
import { getModelStatus } from "./actions";

export default async function ModelDashboard() {
  const status = await getModelStatus(); // Awaits the server action
  return (
    <div>
      <h1>Model: {status.modelName}</h1>
      <p>Quantization: {status.quantization}</p>
      {/* Form triggers another server action, keeping chat logic server-side */}
      <form action={async (formData) => {
        "use server";
        // Conceptual: call chat server action using Effect HTTP client
      }}>
        <input name="prompt" placeholder="Test prompt" />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
