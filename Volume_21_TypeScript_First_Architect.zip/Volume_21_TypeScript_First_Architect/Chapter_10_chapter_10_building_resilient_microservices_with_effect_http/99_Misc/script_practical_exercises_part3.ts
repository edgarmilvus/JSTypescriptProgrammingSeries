/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

   // INTERACTIVE STUB - DO NOT SOLVE, ONLY ANALYZE
   import { z } from "zod";
   import { Effect } from "effect";
   
   const SentimentSchema = z.object({
     label: z.enum(["positive", "negative", "neutral"]),
     confidence: z.number().min(0).max(1)
   });
   
   // TODO: Where does the JSON Schema extraction happen for the LLM prompt?
   // TODO: Where does the Zod parse happen on the LLM response?
   const analyzeFeedback = (text: string): Effect.Effect<z.infer<typeof SentimentSchema>, Error> => {
     // Conceptual: Call LLM -> Get String -> ??? -> Return Parsed
     return Effect.fail(new Error("Not implemented"));
   }
   