/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A self-contained "Hello World" example of a basic tRPC procedure.
 * This demonstrates end-to-end type safety, Zod validation, and integration
 * with a mocked Supabase Client (JS) for SaaS-style data fetching.
 */
import { initTRPC, TRPCError, inferRouterInputs, inferRouterOutputs } from '@trpc/server';
import { z } from 'zod';

/**
 * Represents the shape of a workspace record as stored in the PostgreSQL database.
 * In a production SaaS, this table would also host pgvector embeddings for AI features.
 */
interface WorkspaceRecord {
  id: string;
  name: string;
  plan: 'free' | 'pro' | 'enterprise';
}

/**
 * MockSupabaseClient simulates the JavaScript SDK used to interface with a Supabase project.
 * It mimics the fluent builder pattern: .from().select().eq().single()
 */
class MockSupabaseClient {
  private db: WorkspaceRecord[] = [
    { id: 'ws_001', name: 'Acme Corp', plan: 'pro' },
    { id: 'ws_002', name: 'StartupX', plan: 'free' },
  ];

  /**
   * Simulates querying a table in the underlying PostgreSQL database.
   * @param {string} table - The name of the table (e.g., 'workspaces').
   */
  from(table: string) {
    return {
      select: (columns: string) => ({
        eq: (column: string, value: string) => ({
          single: async () => {
            const record = this.db.find((r) => (r as Record<string, string>)[column] === value);
            return record 
              ? { data: record, error: null } 
              : { data: null, error: new Error('Workspace not found') };
          },
        }),
      }),
    };
  }
}

// Instantiate our mocked client (in reality: createClient(URL, KEY))
const supabaseClient = new MockSupabaseClient();

// 1. Initialize tRPC with no additional plugins (basic setup)
const t = initTRPC.create();

/**
 * Creates the context for incoming requests.
 * In a SaaS, this usually parses JWTs to identify the tenant, but here we inject our DB client.
 */
const createContext = async () => {
  return { supabase: supabaseClient };
};
type Context = Awaited<ReturnType<typeof createContext>>;

// 2. Define the Application Router and Procedures
const appRouter = t.router({
  /**
   * Greets a SaaS workspace by ID.
   * Demonstrates Zod input validation and type-safe output inference.
   * @input {object} - Requires a valid workspace UUID.
   * @output {object} - Returns a greeting, workspace name, and plan.
   */
  greetWorkspace: t.procedure
    .input(
      z.object({
        workspaceId: z.string().uuid('Must be a valid UUID for the SaaS workspace'),
      })
    )
    .output(
      z.object({
        greeting: z.string(),
        workspaceName: z.string(),
        plan: z.enum(['free', 'pro', 'enterprise']),
      })
    )
    .query(async ({ input, ctx }) => {
      const { workspaceId } = input;
      const { supabase } = ctx;

      // Query the database via the Supabase Client (JS) SDK
      const { data, error } = await supabase
        .from('workspaces')
        .select('name, plan')
        .eq('id', workspaceId)
        .single();

      if (error || !data) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: `Workspace ${workspaceId} does not exist.`,
        });
      }

      return {
        greeting: `Welcome to ${data.name}! Your plan is ${data.plan}.`,
        workspaceName: data.name,
        plan: data.plan,
      };
    }),
});

// 3. Export type definitions for the client (End-to-End Type Safety)
export type AppRouter = typeof appRouter;
export type AppRouterInputs = inferRouterInputs<AppRouter>;
export type AppRouterOutputs = inferRouterOutputs<AppRouter>;

// 4. Client Side Usage (Simulated via Server-Side Caller)
async function simulateClientCall() {
  // In a real React app, you would use createTRPCClient or @trpc/react-query hooks
  const caller = appRouter.createCaller({ supabase: supabaseClient });
  
  try {
    // TypeScript strictly enforces the input shape here!
    const result = await caller.greetWorkspace({ workspaceId: 'ws_001' });
    // TypeScript knows 'greeting' is a string, 'plan' is the enum
    console.log(result.greeting); 
  } catch (err) {
    console.error('Client caught error:', err);
  }
}

simulateClientCall();
