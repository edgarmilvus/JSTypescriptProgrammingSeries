/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { initTRPC, TRPCError, inferRouterInputs, inferRouterOutputs } from '@trpc/server';
import { z } from 'zod';
import { NextApiRequest, NextApiResponse } from 'next';

/**
 * 1. RUNTIME VALIDATION SCHEMA
 * Zod schema enforcing structural and semantic integrity of external input.
 * This acts as the boundary guard for our SaaS API, catching invalid payloads
 * that TypeScript's compile-time checks cannot verify because they originate externally.
 */
const inviteUserSchema = z.object({
  email: z.string().email("Invalid email format provided by client"),
  role: z.enum(['ADMIN', 'MEMBER', 'VIEWER']),
  workspaceId: z.string().uuid("Workspace ID must be a valid UUID"),
});

/**
 * 2. UTILITY TYPE DERIVATION
 * We simulate a Drizzle ORM model and use Utility Types to derive a safe DTO.
 * The `Omit` utility type creates a new type by excluding specific keys from T.
 */
type DrizzleUserModel = {
  id: string;
  email: string;
  hashedPassword: string; // Sensitive field that must never reach the client
  role: 'ADMIN' | 'MEMBER' | 'VIEWER';
  workspaceId: string;
  createdAt: Date;
};
// Utility Type: Omit removes the sensitive hashedPassword from the client contract
type SafeUserOutput = Omit<DrizzleUserModel, 'hashedPassword'>;

/**
 * 3. GENERICS FOR RESPONSE ENVELOPE
 * A reusable generic interface to standardize API responses across the application.
 * @template T - Captures the specific payload type for strict type-safety.
 */
interface ApiResponseEnvelope<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * 4. GENERIC HELPER FUNCTION
 * Utilizes the Generic Type Variable <T> to ensure the wrapped data matches the envelope's data type.
 * This prevents accidental mismatches between the resolved promise and the API contract.
 */
function createEnvelope<T>(data: T): ApiResponseEnvelope<T> {
  return { success: true, data };
}

// 5. tRPC INITIALIZATION
// We initialize tRPC with a context generic that injects request, response, and authenticated user ID.
const t = initTRPC.context<{ req: NextApiRequest; res: NextApiResponse; userId: string }>().create();
export const router = t.router;
export const publicProcedure = t.procedure;

/**
 * 6. MOCK DATABASE LAYER (Simulating Drizzle)
 * A Generic function simulating persistence. The generic constraint `<T extends ...>`
 * ensures only valid user-shaped objects can be passed to the persistence layer.
 */
async function persistUser<T extends { email: string; role: 'ADMIN' | 'MEMBER' | 'VIEWER'; workspaceId: string }>(
  input: T
): Promise<DrizzleUserModel> {
  return {
    id: crypto.randomUUID(),
    email: input.email,
    hashedPassword: 'bcrypt_simulated_hash',
    role: input.role,
    workspaceId: input.workspaceId,
    createdAt: new Date(),
  };
}

/**
 * 7. tRPC ROUTER DEFINITION
 * Combining Runtime Validation, Generics, and Utility Types into a single procedure.
 */
export const workspaceRouter = router({
  inviteMember: publicProcedure
    .input(inviteUserSchema) // Runtime Validation boundary enforced by Zod
    .mutation(async ({ input, ctx }): Promise<ApiResponseEnvelope<SafeUserOutput>> => {
      // Authorization check using context
      if (!ctx.userId) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Authentication required' });
      }
      
      // Persist using generic simulation
      const dbUser = await persistUser(input);
      
      // Apply Utility Type to construct safe output by manually mapping allowed fields
      const safeUser: SafeUserOutput = {
        id: dbUser.id,
        email: dbUser.email,
        role: dbUser.role,
        workspaceId: dbUser.workspaceId,
        createdAt: dbUser.createdAt,
      };

      // Wrap in Generic Envelope
      return createEnvelope<SafeUserOutput>(safeUser);
    }),
});

// 8. CLIENT-SIDE TYPE INFERENCE (End-to-End Safety)
// tRPC extracts input and output types directly from the router definition.
type RouterInputs = inferRouterInputs<typeof workspaceRouter>;
type RouterOutputs = inferRouterOutputs<typeof workspaceRouter>;

/**
 * 9. GENERIC CLIENT CALLER
 * Demonstrates how the client consumes the contract with full type safety.
 * The parameters and return type are fully inferred from the server router.
 */
async function callInviteMember(
  trpc: any, 
  params: RouterInputs['workspaceRouter']['inviteMember']
): Promise<RouterOutputs['workspaceRouter']['inviteMember']> {
  return trpc.workspaceRouter.inviteMember.mutate(params);
}
