/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { initTRPC, TRPCError } from '@trpc/server';
import { z } from 'zod';

const t = initTRPC.create();
const publicProcedure = t.procedure;

// Mock database
const mockUsers = [
  { id: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', name: 'Alice', createdAt: new Date() },
];

// 2. Zod schema for UUID input
const UserIdSchema = z.string().uuid();

// 5. Zod schema for output enforcement
const UserOutputSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  createdAt: z.date(),
});

export const userRouter = t.router({
  // 1, 3, & 4. getUserById procedure with Zod input and output
  getUserById: publicProcedure
    .input(UserIdSchema)
    .output(UserOutputSchema)
    .query(({ input }) => {
      // 6. Architectural Rationale (z.infer):
      // tRPC's Builder type uses a conditional type (inferProcedureInput) that resolves to 
      // z.infer<typeof UserIdSchema>. The compiler proxies the Zod schema, shifting validation left.
      const user = mockUsers.find((u) => u.id === input);
      if (!user) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      return user; // Validated against UserOutputSchema at runtime
    }),
});
