/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { pgTable, uuid, text, boolean, timestamp } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { initTRPC } from '@trpc/server';
import { db } from './db'; // Assume Drizzle client is initialized

const t = initTRPC.create();
const publicProcedure = t.procedure;

// 1. Drizzle schema for posts table
export const posts = pgTable('posts', {
  id: uuid('id').defaultRandom().primaryKey(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  authorId: uuid('authorId').notNull(),
  isDraft: boolean('isDraft').default(true),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
});

// 2. Zod schema for output (View Model boundary)
export const PostOutputSchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  // Transforms Date to ISO string for clean JSON serialization
  createdAt: z.date().transform((d) => d.toISOString()),
});

export const postRouter = t.router({
  listPosts: publicProcedure
    // 3. Pagination input with Zod defaults
    .input(
      z.object({
        page: z.number().int().positive().default(1),
        pageSize: z.number().int().positive().default(10),
      })
    )
    // 5. Ensure tRPC is aware of output schema
    .output(z.array(PostOutputSchema))
    .query(async ({ input }) => {
      // 4. Drizzle query builder fetching slice
      const dbPosts = await db
        .select()
        .from(posts)
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);

      // Map/validate to conform to PostOutputSchema (excludes content/isDraft, transforms Date)
      return z.array(PostOutputSchema).parse(dbPosts);
    }),
});

/*
 6. Client-side inferRouterOutputs usage:
    type RouterOutputs = inferRouterOutputs<typeof appRouter>;
    type PostsList = RouterOutputs['post']['listPosts']; 
    // This yields an array of { id: string; title: string; createdAt: string }
    // Strictly typed according to the transformed Zod schema, no manual interface needed!
*/
