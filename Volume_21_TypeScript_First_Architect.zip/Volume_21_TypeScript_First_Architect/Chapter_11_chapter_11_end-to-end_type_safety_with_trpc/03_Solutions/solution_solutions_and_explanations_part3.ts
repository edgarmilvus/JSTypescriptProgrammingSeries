/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { initTRPC, TRPCError } from '@trpc/server';
import * as Effect from 'effect/Effect';
import { db } from './db';
import { users } from './schema';

const t = initTRPC.create();
const publicProcedure = t.procedure;

// 1. Custom Effect error type
class EmailSendError {
  readonly _tag = 'EmailSendError';
  constructor(readonly message: string) {}
}

// Simulated email service (fails 20% of the time)
const sendWelcomeEmail = (email: string): Effect.Effect<void, EmailSendError> =>
  Effect.gen(function* () {
    if (Math.random() < 0.2) {
      return yield* Effect.fail(new EmailSendError('SMTP flakiness detected'));
    }
    console.log(`Email sent to ${email}`);
  });

export const authRouter = t.router({
  registerUser: publicProcedure
    // 2. Input validation
    .input(z.object({ email: z.string().email(), password: z.string().min(8) }))
    .mutation(async ({ input }) => {
      // 3. Construct Effect workflow
      const program = Effect.gen(function* () {
        // (a) Insert user via Drizzle
        const [user] = yield* Effect.tryPromise({
          try: () => db.insert(users).values({ email: input.email, password: input.password }).returning(),
          catch: () => new EmailSendError('DB_INSERT_FAILED'),
        });
        // (b) Send email
        yield* sendWelcomeEmail(input.email);
        return user;
      });

      // 4. Map Effect errors to TRPCError
      const mappedProgram = program.pipe(
        Effect.mapError((err): TRPCError => {
          if (err._tag === 'EmailSendError') {
            return new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: err.message });
          }
          return new TRPCError({ code: 'CONFLICT', message: 'Database constraint violated' });
        })
      );

      // 5. Execute the Effect
      // 6. Promise.catch vs Effect's typed error channel:
      // Promise.catch captures `unknown`, requiring manual `instanceof` checks.
      // Effect's channel `E` is explicitly typed; mapError translates `E` to TRPCError 
      // before runtime interpretation, making failures provable at compile-time.
      return Effect.runPromise(mappedProgram);
    }),
});
