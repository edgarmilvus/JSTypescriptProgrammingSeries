/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import * as React from 'react';
import { trpc } from '../utils/trpc'; // Client-side tRPC wrapper
import { z } from 'zod';

// Reusing the exact Zod schema from the server (no manual interface duplication)
import { UpdateUserProfileInput } from '@/server/schemas';

export function UserProfileSettings({ userId }: { userId: string }) {
  const [displayName, setDisplayName] = React.useState('');
  const [bio, setBio] = React.useState('');

  // 2. Utilize @trpc/react-query useMutation
  const mutation = trpc.updateUserProfile.useMutation({
    // 5. onError callback with strongly-typed error code
    onError: (error) => {
      // error.code is a strictly typed union provided by tRPC's inference
      console.error(`Server error code: ${error.code}`);
      alert(`Toast: ${error.message}`); // Simulating toast notification
    },
  });

  // 3. Controlled form with instant validation via shared Zod schema
  const validation = UpdateUserProfileInput.safeParse({ userId, displayName, bio });
  const isValid = validation.success;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;
    // 4. Props passed to mutate are type-checked against server's Zod input
    mutation.mutate({ userId, displayName, bio });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
        placeholder="Display Name"
      />
      {!isValid && displayName === '' && (
        <span style={{ color: 'red' }}>Name required</span>
      )}

      <textarea
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        placeholder="Bio (max 160)"
      />
      {!isValid && bio.length > 160 && (
        <span style={{ color: 'red' }}>Bio too long</span>
      )}

      <button type="submit" disabled={mutation.isLoading}>
        {mutation.isLoading ? 'Saving...' : 'Save'} {/* Loading spinner simulation */}
      </button>
    </form>
  );
}

/*
 6. Vite and TypeScript Resolution Paragraph:
    In a TypeScript-first monorepo, Vite uses path aliases (e.g., @/server) configured in tsconfig.json 
    and vite.config.ts. When the client imports the tRPC wrapper and calls useMutation, TypeScript traverses 
    the imported appRouter type from the server. Because tRPC's client is generic over the router type, the 
    compiler reads the Zod schemas on the server procedures and infers the input/output types directly from the 
    AST (Abstract Syntax Tree). No .d.ts files are copied, and no build step serializes the types; it is pure 
    static analysis across the module graph, achieving the "Holy Grail" of a single source of truth.
*/
