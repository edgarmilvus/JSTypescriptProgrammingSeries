/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { initTRPC } from '@trpc/server';

const t = initTRPC.create();
const publicProcedure = t.procedure;

// 1. Zod schemas for intermediate and final states
const EmbeddingVector = z.array(z.number());
const RetrievedChunk = z.object({
  text: z.string(),
  score: z.number(),
});
const AugmentedPrompt = z.object({
  system: z.string(),
  user: z.string(),
});

// Mock vector store
const mockDocs = [
  { text: 'tRPC uses Zod for validation', score: 0.9 },
  { text: 'Drizzle is a type-safe ORM', score: 0.8 },
  { text: 'Effect handles typed errors', score: 0.85 },
];

export const ragRouter = t.router({
  askDocumentation: publicProcedure
    // 2. Input validation
    .input(z.object({ question: z.string().min(5) }))
    // 5. Output schema strictly defines client-facing contract
    .output(z.object({ answer: z.string(), sources: z.array(RetrievedChunk) }))
    // 3. RAG Pipeline Simulation
    .query(({ input }) => {
      // a. Embedding (Mock)
      const embedding = EmbeddingVector.parse([0.1, 0.2, 0.3]);

      // b. Retrieval (Mock similarity filter)
      const retrieved = mockDocs
        .filter((doc) => doc.score > 0.75)
        .map((doc) => RetrievedChunk.parse(doc))
        .slice(0, 3);

      // c. Context Augmentation
      const augmented = AugmentedPrompt.parse({
        system: 'You are a docs assistant.',
        user: `Question: ${input.question}\nContext: ${retrieved.map((r) => r.text).join(', ')}`,
      });

      // 4. Simulate LLM Call
      const answer = `Based on the docs: ${retrieved.map((r) => r.text).join('; ')}`;

      // 6. Type Safety prevents leaking EmbeddingVector:
      // If we attempted to return `embedding` in the output, TypeScript would fail because 
      // the `.output()` schema only permits `answer` and `sources`. This prevents bandwidth waste 
      // and secures internal ML state.
      return { answer, sources: retrieved };
    }),
});
