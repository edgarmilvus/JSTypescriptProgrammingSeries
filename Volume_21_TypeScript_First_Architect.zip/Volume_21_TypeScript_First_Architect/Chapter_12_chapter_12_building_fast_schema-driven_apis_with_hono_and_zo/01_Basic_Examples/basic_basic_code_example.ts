/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file A minimal SaaS Project Creation API using Hono and Zod.
 * @description This example demonstrates schema-driven validation at the edge,
 * ensuring that only structurally sound payloads reach our business logic.
 */
import { Hono } from 'hono';
import { z } from 'zod';
import { zValidator } from '@hono/zod-validator';

/**
 * @constant ProjectSchema
 * @description Defines the expected shape, types, and constraints of a new project payload.
 * In a SaaS context, this acts as a contractual boundary between the client and the server.
 */
const ProjectSchema = z.object({
  // The project name must be a string between 3 and 50 characters.
  name: z.string().min(3, 'Project name must be at least 3 characters').max(50),
  // The subscription tier is restricted to specific enum values, defaulting to 'free'.
  tier: z.enum(['free', 'pro', 'enterprise']).default('free'),
  // Initial seats must be a positive integer, capped at 100 for initial self-serve setup.
  initialSeats: z.number().int().positive().max(100),
  // The owner's email must conform to Zod's built-in email validation regex.
  ownerEmail: z.string().email('A valid email is required for the owner')
});

// Initialize the Hono application instance. This is our central router and middleware hub.
const app = new Hono();

/**
 * @route POST /api/v1/projects
 * @description Handles the creation of a new SaaS project.
 * The zValidator middleware automatically parses, validates, and types the JSON body.
 */
app.post('/api/v1/projects', zValidator('json', ProjectSchema), async (c) => {
  // Extract the fully validated and strictly typed payload from the request context.
  // TypeScript knows exactly what shape this object has, courtesy of Zod's inference.
  const projectData = c.req.valid('json');

  // Simulate an asynchronous database persistence operation (e.g., writing to Drizzle/Postgres).
  const createdProject = await mockDatabaseInsert(projectData);

  // Return a standardized success response with a 201 Created status code.
  return c.json({
    status: 'success',
    data: createdProject
  }, 201);
});

/**
 * @function mockDatabaseInsert
 * @description Simulates writing to a database and returning the record with a generated ID.
 * @param {z.infer<typeof ProjectSchema>} data - The validated project data
 * @returns {Promise<object>} A promise resolving to the created project record
 */
async function mockDatabaseInsert(data: z.infer<typeof ProjectSchema>) {
  // Simulate network latency or database I/O wait time.
  await new Promise(resolve => setTimeout(resolve, 50));
  // Utilize the globally available crypto module (standard in Edge and modern Node runtimes).
  return { id: crypto.randomUUID(), ...data, createdAt: new Date().toISOString() };
}

// Export the Hono app as the default module for edge/serverless deployment (e.g., Cloudflare Workers).
export default app;
