/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file Advanced SaaS Tool Invocation API
 * @description Demonstrates Hono + Zod for LLM Function Calling and AIState management.
 */
import { Hono, Context } from 'hono';
import { z, ZodError } from 'zod';
import { zValidator } from '@hono/zod-validator';

/**
 * @const CreateSubscriptionSchema
 * @description Zod schema enforcing the Tool Invocation Signature for subscription creation.
 * This acts as the single source of truth for runtime validation.
 */
const CreateSubscriptionSchema = z.object({
  userId: z.string().uuid({ message: "User ID must be a valid UUID" }),
  plan: z.enum(['free', 'pro', 'enterprise'], { required_error: "Plan is required" }),
  billingCycle: z.enum(['monthly', 'yearly']),
  seats: z.number().int().min(1).max(100).optional().default(1)
});

/**
 * @const functionCallingSchema
 * @description The Function Calling Schema (OpenAPI-style) exposed to the LLM.
 * LLMs cannot read Zod directly; they require a serialized JSON description of the tool.
 */
const functionCallingSchema = {
  name: "create_subscription",
  description: "Provision a new SaaS subscription for a specified user",
  parameters: {
    type: "object",
    properties: {
      userId: { type: "string", format: "uuid", description: "Unique user identifier" },
      plan: { type: "string", enum: ["free", "pro", "enterprise"] },
      billingCycle: { type: "string", enum: ["monthly", "yearly"] },
      seats: { type: "integer", description: "Number of seats (default 1)" }
    },
    required: ["userId", "plan", "billingCycle"]
  }
};

// Initialize Hono application instance (edge-ready, zero-dependency router)
const app = new Hono();

// In-memory store representing the conceptual AIState per session.
// In production, this would be backed by Redis or the Vercel AI SDK's state mechanisms.
const aiStateStore = new Map<string, { toolCalls: Array<Record<string, unknown>> }>();

/**
 * Middleware to initialize or retrieve AIState for the session.
 * Binds the session context to the Hono request context for downstream handlers.
 */
app.use('/api/tools/*', async (c: Context, next) => {
  const sessionId = c.req.header('X-Session-Id') || 'anonymous';
  if (!aiStateStore.has(sessionId)) {
    aiStateStore.set(sessionId, { toolCalls: [] });
  }
  c.set('sessionId', sessionId);
  await next();
});

/**
 * GET /api/tools/schema
 * Exposes the Function Calling Schema to the LLM orchestrator (e.g., LangGraph or Vercel AI SDK).
 */
app.get('/api/tools/schema', (c) => {
  return c.json({ available_tools: [functionCallingSchema] });
});

/**
 * POST /api/tools/create_subscription
 * Handles the Tool Invocation Signature from the LLM.
 * The zValidator middleware intercepts the request and validates the JSON body against Zod.
 */
app.post('/api/tools/create_subscription',
  zValidator('json', CreateSubscriptionSchema),
  async (c: Context) => {
    // Extract validated parameters (runtime-safe and fully typed)
    const params = c.req.valid('json');
    
    // Simulate subscription provisioning logic (Drizzle ORM would reside here)
    const subscriptionId = `sub_${crypto.randomUUID().slice(0, 8)}`;
    const provisionedAt = new Date().toISOString();

    // Update the AIState with the tool invocation result to maintain conversation history
    const sessionId = c.get('sessionId');
    const state = aiStateStore.get(sessionId);
    state?.toolCalls.push({
      tool: 'create_subscription',
      input: params,
      output: { subscriptionId, provisionedAt },
      status: 'success'
    });

    // Return response compatible with LangGraph/Vercel AI SDK Tool Invocation Signature
    return c.json({
      tool_call_id: c.req.header('X-Tool-Call-Id'),
      content: {
        success: true,
        subscriptionId,
        provisionedAt,
        message: `Successfully created ${params.plan} plan`
      }
    }, 200);
  }
);

/**
 * Error handling for Zod validation failures (Tool Invocation Signature mismatch).
 * Ensures the LLM receives a structured error it can potentially self-correct from.
 */
app.onError((err, c) => {
  if (err instanceof ZodError) {
    return c.json({ error: "Validation failed", details: err.errors }, 400);
  }
  return c.json({ error: "Internal Server Error" }, 500);
});

export default app;
