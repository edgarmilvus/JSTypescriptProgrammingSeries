/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';

// 1. Schema Definition
const UserCreationSchema = z.object({
  username: z.string().min(3).trim(),
  email: z.string().email(),
  age: z.number().int().positive(),
});

// Initialize Hono app
const app = new Hono();

// 2. Hono Route Registration & 3. Type-Safe Handler
app.post('/api/users', zValidator('json', UserCreationSchema), (c) => {
  // Data is strictly typed and validated before reaching this line
  const validatedData = c.req.valid('json');
  
  // Mock ID generation
  const mockId = crypto.randomUUID();
  
  // Return 201 Created with echoed data + id
  return c.json({ id: mockId, ...validatedData }, 201);
});

// 4. Error Handling (Architectural Note via onError hook)
app.onError((err, c) => {
  // Catch Zod validation failures thrown by zValidator
  if (err instanceof z.ZodError) {
    return c.json({
      error: 'Validation Failed',
      issues: err.errors.map(e => ({ path: e.path.join('.'), message: e.message }))
    }, 400);
  }
  return c.json({ error: 'Internal Server Error' }, 500);
});

export default app;
