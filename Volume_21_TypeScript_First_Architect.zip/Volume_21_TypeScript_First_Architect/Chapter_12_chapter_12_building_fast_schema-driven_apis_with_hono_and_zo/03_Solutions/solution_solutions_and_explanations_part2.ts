/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';

// 1. Coercion Schema & 2. Enumeration Constraint
const ProductQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().default(10),
  category: z.enum(['electronics', 'books', 'apparel']).optional(),
});

// 3. Response Schema for Output Validation
const ProductResponseSchema = z.object({
  data: z.array(z.object({ id: z.string(), name: z.string() })),
  currentPage: z.number(),
  totalPages: z.number(),
  hasMore: z.boolean(),
});

const app = new Hono();

app.get('/api/products', zValidator('query', ProductQuerySchema), (c) => {
  const { page, limit, category } = c.req.valid('query');
  
  // 4. Handler Logic: Simulate DB fetch using validated params
  const mockProducts = Array.from({ length: limit }, (_, i) => ({
    id: `prod_${i + 1}`,
    name: `Product ${i + 1} in ${category || 'all'}`,
  }));
  
  const totalPages = 5; // mocked total
  const responsePayload = {
    data: mockProducts,
    currentPage: page,
    totalPages,
    hasMore: page < totalPages,
  };
  
  // Validate the response itself before sending to client
  const validatedResponse = ProductResponseSchema.parse(responsePayload);
  
  return c.json(validatedResponse, 200);
});

export default app;
