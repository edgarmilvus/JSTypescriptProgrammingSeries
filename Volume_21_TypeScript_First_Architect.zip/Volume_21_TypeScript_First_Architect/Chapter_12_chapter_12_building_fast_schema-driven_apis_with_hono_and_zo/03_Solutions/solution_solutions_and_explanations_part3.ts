/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { createClient } from '@supabase/supabase-js';

// 1. Input Vector Schema (1536 dims for OpenAI text-embedding-3-small)
const SemanticSearchSchema = z.object({
  queryVector: z.array(z.number()).length(1536),
});

// 3. Row Validation Schema for pgvector data
const DocumentSchema = z.object({
  id: z.string(),
  content: z.string(),
  embedding: z.array(z.number()), // Handles array serialization from PostgREST
});

// Final Response Schema
const SearchResponseSchema = z.object({
  results: z.array(z.object({
    id: z.string(),
    content: z.string(),
    similarityScore: z.number(),
  })),
});

type Bindings = {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
};

const app = new Hono<{ Bindings: Bindings }>();

app.post('/api/semantic-search', zValidator('json', SemanticSearchSchema), async (c) => {
  const { queryVector } = c.req.valid('json');
  
  // 2. Environment Binding to instantiate Supabase Client
  const supabase = createClient(c.env.SUPABASE_URL, c.env.SUPABASE_ANON_KEY);
  
  // 4. Distance Calculation via RPC (custom SQL function for cosine distance)
  const { data, error } = await supabase.rpc('match_documents', { 
    query_embedding: queryVector,
    match_threshold: 0.8
  });
  
  if (error) return c.json({ error: 'DB Error' }, 500);
  
  // Validate rows returned from Supabase to prevent runtime drift
  const parsedRows = DocumentSchema.array().safeParse(data);
  if (!parsedRows.success) {
    return c.json({ error: 'Data drift detected from upstream DB' }, 502);
  }
  
  // Map validated rows to final response shape
  const finalResults = parsedRows.data.map(doc => ({
    id: doc.id,
    content: doc.content,
    similarityScore: 0.95, // Normally returned by the RPC match function
  }));
  
  const response = SearchResponseSchema.parse({ results: finalResults });
  return c.json(response, 200);
});

export default app;
