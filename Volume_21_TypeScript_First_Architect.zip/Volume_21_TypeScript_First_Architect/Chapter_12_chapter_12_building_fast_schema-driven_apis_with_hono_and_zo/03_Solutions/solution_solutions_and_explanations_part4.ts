/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';

// 1. Discriminated Union Schema
const ToolCallSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('calculator'),
    expression: z.string(),
  }),
  z.object({
    type: z.literal('text_formatter'),
    text: z.string(),
    case: z.enum(['upper', 'lower']),
  }),
]);

// 2. Array Validation (requires at least one tool)
const AgentToolBatchSchema = z.object({
  tools: z.array(ToolCallSchema).min(1),
});

const app = new Hono();

// 3. Hono Endpoint
app.post('/api/agent/validate-tools', zValidator('json', AgentToolBatchSchema), (c) => {
  const { tools } = c.req.valid('json');
  
  // Mock response indicating batch acceptance for LangGraph
  return c.json({ 
    status: 'Batch Accepted', 
    toolCount: tools.length 
  }, 200);
});

/*
4. Concurrency Note:
Validating the entire array atomically in Hono before LangGraph parallelizes execution is superior 
because it prevents partial state updates. If validation occurs inside parallel workers, a failure 
in one worker might occur after others have already executed side effects (e.g., DB writes). 
Atomic validation at the API boundary ensures all tools are syntactically and semantically correct 
before any concurrent Promise.all execution begins, simplifying error handling to a single 400 response.
*/
