/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';
import { Effect, Cause } from 'effect';

/**
 * SystemPromptSchema
 * Defines the structure for the hidden instruction given to the LLM.
 * Adheres to the architectural definition of a System Prompt:
 * sets foundational context, role, and constraints.
 */
const SystemPromptSchema = z.object({
  // We use z.literal to enforce that the role is strictly 'system' and nothing else.
  role: z.literal('system'),
  // The content must be a string and cannot be empty.
  content: z.string().min(1)
});

/**
 * UserMessageSchema
 * Defines the structure for the end-user's input in our SaaS chat interface.
 */
const UserMessageSchema = z.object({
  // Enforces the role is strictly 'user'.
  role: z.literal('user'),
  // The user's actual text query.
  content: z.string().min(1)
});

/**
 * ChatRequestSchema
 * The authoritative contract for the incoming API payload.
 * It combines the system prompt and user message, adding inference parameters.
 */
const ChatRequestSchema = z.object({
  systemPrompt: SystemPromptSchema,
  userMessage: UserMessageSchema,
  // Temperature controls randomness; bounded between 0 and 1.
  temperature: z.number().min(0).max(1).default(0.7)
});

/**
 * ChatResponseSchema
 * The authoritative contract for the outgoing API payload.
 * In a full streamable-ui implementation, this would be extended to include
 * component descriptors, but for this basic example, we return a resolved reply.
 */
const ChatResponseSchema = z.object({
  reply: z.string(),
  tokensUsed: z.number()
});

/**
 * ChatContract
 * A static, runtime object that holds our route metadata and schema references.
 * This object is the "Contract" that both Server and Client will import.
 */
const chatContract = {
  path: '/api/chat',
  method: 'POST',
  requestSchema: ChatRequestSchema,
  responseSchema: ChatResponseSchema
} as const;

/**
 * handleChatRequest (Server-Side)
 * Uses Effect to safely parse the unknown input and simulate an AI reply.
 * Effect provides a functional approach to async/await with typed errors.
 * 
 * @param rawInput - The untrusted payload coming from the network
 * @returns An Effect that resolves to a validated ChatResponse or fails with an Error
 */
const handleChatRequest = (rawInput: unknown) => {
  return Effect.gen(function* (_) {
    // Step 1: Validate the raw input against our Zod contract.
    // Effect.try catches synchronous throws (like Zod's parse method) and wraps them.
    const parsedInput = yield* _(
      Effect.try({
        try: () => ChatRequestSchema.parse(rawInput),
        catch: (e) => new Error(`Contract Validation Failed: ${JSON.stringify(e)}`)
      })
    );

    // Step 2: Simulate AI processing based on the System Prompt and User Message.
    // In a real SaaS, this would call an LLM. Here we echo to keep it Hello World.
    const simulatedReply = `[${parsedInput.systemPrompt.content}] Response to: ${parsedInput.userMessage.content}`;
    
    // Step 3: Construct and validate the response against the response schema.
    const responsePayload = ChatResponseSchema.parse({
      reply: simulatedMessage,
      tokensUsed: simulatedMessage.length
    });

    // Step 4: Return the validated payload to the Effect runtime.
    return responsePayload;
  });
};

/**
 * createTypeSafeClient
 * A generic factory function that consumes our Contract and returns a 
 * typed client function. This is the "Client Generation" step.
 * 
 * @param contract - The static contract object defining path, method, and schemas
 * @returns A function that accepts request type and returns a Promise of response type
 */
function createTypeSafeClient<C extends {
  path: string;
  method: string;
  requestSchema: z.ZodType<any>;
  responseSchema: z.ZodType<any>;
}>(contract: C) {
  // We extract the TypeScript types directly from the Zod schemas using z.infer.
  // This ensures the client knows exactly what to send and what to expect.
  return async (data: z.infer<C['requestSchema']>): Promise<z.infer<C['responseSchema']>> => {
    // Perform the network request using the contract's metadata.
    const res = await fetch(contract.path, {
      method: contract.method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    // Parse the raw JSON response.
    const json = await res.json();
    
    // Validate the response from the server against our contract.
    // This protects the client from backend regressions.
    return contract.responseSchema.parse(json) as z.infer<C['responseSchema']>;
  };
}

// Instantiate the client using the exact same contract object.
// TypeScript automatically infers the input/output types from the schemas.
const supportGeniusClient = createTypeSafeClient(chatContract);

// Example usage in a React Server Component or Server Action:
/*
  const result = await supportGeniusClient({
    systemPrompt: { role: 'system', content: 'You are a helpful assistant.' },
    userMessage: { role: 'user', content: 'Hello World' },
    temperature: 0.5
  });
  // result is typed as { reply: string, tokensUsed: number }
*/
