/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';
import { Effect, Stream } from 'effect';
import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';

/**
 * Zod Contract: Authoritative schema for the AI Generation feature.
 * Acts as the single source of truth for both Server Action and API Route.
 * This ensures that the client, server, and database layers share identical shape expectations.
 */
const AiGenerationContract = z.object({
  workspaceId: z.string().uuid(),
  prompt: z.string().min(20, 'Prompt too short for meaningful generation'),
  model: z.enum(['efficiency', 'creative', 'strict']).default('efficiency')
});

/** Inferred TypeScript type from the Zod contract (Type-Safe Client Generation) */
type AiGenerationInput = z.infer<typeof AiGenerationContract>;

/**
 * Simulates a Drizzle-backed data model type for audit logs.
 * In a production system, this would be imported from the Drizzle schema definitions
 * to ensure the API contract and database persistence are perfectly type-aligned.
 */
type AuditLog = {
  id: string;
  workspaceId: string;
  event: 'generation_requested';
};

/**
 * Edge-compatible streaming generator using Effect's Stream.
 * Simulates token-by-token delivery of AI output by splitting the prompt
 * and mapping each token to a Server-Sent Event formatted string.
 */
const buildAiResponseStream = (input: AiGenerationInput) => {
  const tokens = `Workspace ${input.workspaceId} via ${input.model}: ${input.prompt}`.split(' ');
  return Stream.fromIterable(tokens).pipe(
    Stream.map(chunk => `event: token\ndata: ${chunk}\n\n`)
  );
};

/**
 * Effect-based business logic for processing the generation request.
 * Handles stream creation and potential failures predictably using functional programming.
 */
const generateContentEffect = (input: AiGenerationInput) =>
  Effect.gen(function* (_) {
    // Simulate DB audit log insertion (Drizzle context)
    const log: AuditLog = { id: crypto.randomUUID(), workspaceId: input.workspaceId, event: 'generation_requested' };
    yield* _(Effect.log(`Audit log created: ${log.id}`));

    // Create the Effect stream
    const effectStream = buildAiResponseStream(input);
    
    // Convert Effect Stream to Web ReadableStream for the Edge runtime
    const readable = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        // Consume the Effect stream and push to the controller
        await Stream.runForEach(effectStream, (chunk) =>
          Effect.sync(() => controller.enqueue(encoder.encode(chunk)))
        ).pipe(Effect.runPromise);
        controller.close();
      }
    });
    return readable;
  });

/**
 * Server Action: Securely handles form submission or direct calls from Client Components.
 * Utilizes Type Narrowing on the Zod validation result to branch logic safely.
 */
'use server';
export async function submitGenerationRequest(rawFormData: unknown): Promise<{ ok: boolean; error?: string }> {
  // Type Narrowing: safeParse returns a discriminated union { success: true, data } | { success: false, error }
  const result = AiGenerationContract.safeParse(rawFormData);
  
  if (!result.success) {
    // Compiler has narrowed the type; result.error is now safely accessible
    return { ok: false, error: result.error.issues[0].message };
  }
  
  // Narrowed to success: result.data is strictly AiGenerationInput
  const validatedInput = result.data;
  await generateContentEffect(validatedInput).pipe(
    Effect.match({
      onFailure: () => Effect.sync(() => console.error('Failed to process generation')),
      onSuccess: () => Effect.sync(() => revalidatePath('/dashboard'))
    }),
    Effect.runPromise
  );
  return { ok: true };
}

/**
 * Streaming API Route: Exposes the generation capability via HTTP.
 * Configured for Edge runtime to ensure low-latency streaming and global distribution.
 */
export const runtime = 'edge';

export async function POST(req: NextRequest): Promise<Response> {
  // Parse the incoming JSON body safely
  const body = await req.json().catch(() => null);
  
  // Validate against the authoritative Zod contract
  const parsed = AiGenerationContract.safeParse(body);

  // Type Narrowing applied to the HTTP route context
  if (!parsed.success) {
    return NextResponse.json({ issues: parsed.error.flatten() }, { status: 422 });
  }

  // Execute Effect and handle lifecycle deterministically
  return Effect.match(generateContentEffect(parsed.data), {
    onFailure: (cause) => new Response('Internal Processing Error', { status: 500 }),
    onSuccess: (stream) => new Response(stream, {
      headers: { 'Content-Type': 'text/event-stream', 'Connection': 'keep-alive' }
    })
  }).pipe(Effect.runPromise) as Promise<Response>;
}
