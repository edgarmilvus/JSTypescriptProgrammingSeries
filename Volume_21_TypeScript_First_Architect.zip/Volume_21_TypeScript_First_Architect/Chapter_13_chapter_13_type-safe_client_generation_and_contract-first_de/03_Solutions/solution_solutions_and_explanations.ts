/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Schema Definition and Runtime Mapping
export const ProjectSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  // The "How" of Dates: JSON serializes dates as ISO strings. 
  // We keep it as a string to match the serialization boundary exactly. 
  // Transforming to Date would require a .transform() which changes the output type, 
  // but APIs typically communicate ISO strings to avoid timezone/serialization mismatches at the boundary.
  createdAt: z.string().datetime(), 
  status: z.enum(['active', 'archived'])
});

// 2. Type Inference Mechanics
/**
 * Under the Hood: The TypeScript compiler resolves `z.infer` by traversing the Zod schema's 
 * generic parameters. Zod's `z.object` returns a `ZodObject` type which exposes an `_output` 
 * generic. `z.infer` simply extracts this, recursively mapping `z.string()` to `string`, 
 * `z.enum()` to a literal union, effectively making the schema the "source code" for the type.
 */
type Project = z.infer<typeof ProjectSchema>;

// 3. Contract Structure (API as Data)
/**
 * Architectural Note: This contract is a runtime value, not just a type. 
 * Because `input` and `output` hold actual Zod schema instances, we can later iterate 
 * over this object programmatically (e.g., in a client factory) to extract validators 
 * and generate fully type-safe fetch wrappers without duplicating logic.
 */
export const getProjectContract = {
  method: 'GET',
  path: '/projects/:id',
  input: z.object({ id: z.string().uuid() }), // Route parameter schema
  output: ProjectSchema
};

// 4. Standardized Error Schema
export const ApiErrorSchema = z.object({
  code: z.number(),
  message: z.string()
});
