/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data } from 'effect';
import { z } from 'zod';
import { getProjectContract, type Project } from './exercise1';

// 1. Typed Error Modeling
/**
 * Why Tagged Errors? Tagged unions allow exhaustive pattern matching in consuming code. 
 * By extending Data.TaggedError, each error has a discriminable `_tag` property, ensuring 
 * no error path is accidentally unhandled by TypeScript's control flow analysis.
 */
export class NetworkError extends Data.TaggedError('NetworkError')<{ cause: unknown }> {}
export class ValidationError extends Data.TaggedError('ValidationError')<{ error: z.ZodError }> {}

// 2. Client Factory Implementation
export function createApiClient(contract: typeof getProjectContract) {
  return {
    // Under the Hood: The `Success` type is automatically inferred from `z.infer<typeof contract.output>` 
    // because we parse with that schema inside the effect, binding the Effect's success channel to it.
    getProject: (input: z.infer<typeof contract.input>): Effect.Effect<Project, NetworkError | ValidationError, never> => {
      return Effect.gen(function* (_) {
        // 3. Lifecycle Management with Effect.gen
        // Pedagogical Note: Unlike async/await where a throw exits immediately, `yield*` short-circuits 
        // the effect computation but remains within the typed error channel.
        const response = yield* _(
          Effect.tryPromise({
            try: () => fetch(`/projects/${input.id}`),
            catch: (cause) => new NetworkError({ cause })
          })
        );
        
        const json = yield* _(
          Effect.tryPromise({
            try: () => response.json(),
            catch: (cause) => new NetworkError({ cause })
          })
        );

        const validatedData = yield* _(
          Effect.try({
            try: () => contract.output.parse(json),
            catch: (e) => new ValidationError({ error: e as z.ZodError })
          })
        );

        return validatedData;
      });
    }
  };
}

/**
 * Type Safety Verification: The TypeScript compiler ensures the success channel of the Effect 
 * matches `z.infer<typeof contract.output>` (which is `Project`). This provides end-to-end type 
 * safety from the Drizzle database row (mapped to Zod) to the client variable, with zero manual annotations.
 */
