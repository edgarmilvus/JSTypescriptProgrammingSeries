/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// --- SERVER-SIDE: Server Action (Runs in secure enclave) ---
'use server';
import { Effect, Data } from 'effect';
import { z } from 'zod';

export const ChatQuerySchema = z.object({ query: z.string() });
export const ChatResponseSchema = z.object({ answer: z.string(), sources: z.string() });

// Type Propagation: This inferred type is what crosses the boundary to the client.
type ChatResponse = z.infer<typeof ChatResponseSchema>;

class ChatNetworkError extends Data.TaggedError('ChatNetworkError')<{ cause: unknown }> {}
class ChatValidationError extends Data.TaggedError('ChatValidationError')<{ error: z.ZodError }> {}

export async function submitChatQuery(query: string): Promise<ChatResponse | { error: string }> {
  const program = Effect.gen(function* (_) {
    const response = yield* _(Effect.tryPromise({
      try: () => fetch('/api/rag', { method: 'POST', body: JSON.stringify({ query }) }),
      catch: (cause) => new ChatNetworkError({ cause })
    }));
    const json = yield* _(Effect.tryPromise({
      try: () => response.json(),
      catch: (cause) => new ChatNetworkError({ cause })
    }));
    return yield* _(Effect.try({
      try: () => ChatResponseSchema.parse(json),
      catch: (e) => new ChatValidationError({ error: e as z.ZodError })
    }));
  });

  // Map errors to safe serializable format for the network boundary
  return await Effect.runPromise(
    program.pipe(Effect.mapError((e) => ({ error: e._tag })))
  ).catch((err) => err as { error: string });
}

// --- CLIENT-SIDE: React Component (Bundled to browser) ---
'use client';
import React, { useState, useTransition } from 'react';
// Constraint: Notice we do NOT import zod or effect here. Only the function and inferred type.
import { submitChatQuery, type ChatResponse } from './server-actions';

export function ChatInterface() {
  const [inputValue, setInputValue] = useState('');
  // The state variable is strictly typed via the inferred ChatResponse schema from the server.
  const [responseData, setResponseData] = useState<ChatResponse | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const result = await submitChatQuery(inputValue);
      if (!('error' in result)) {
        setResponseData(result);
      }
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={inputValue} onChange={(e) => setInputValue(e.target.value)} />
      <button type="submit" disabled={isPending}>{isPending ? 'Loading...' : 'Send'}</button>
      {responseData && <div>{responseData.answer}</div>}
    </form>
  );
}
