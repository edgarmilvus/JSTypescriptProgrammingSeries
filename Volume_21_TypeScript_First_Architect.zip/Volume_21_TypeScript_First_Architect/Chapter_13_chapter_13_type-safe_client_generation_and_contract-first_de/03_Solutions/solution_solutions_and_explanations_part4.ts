/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data } from 'effect';
import { z } from 'zod';

// 1. Schema Design for RAG Boundaries
export const RetrievedChunkSchema = z.object({
  id: z.string(),
  content: z.string(),
  score: z.number()
});
type RetrievedChunk = z.infer<typeof RetrievedChunkSchema>;

export const AugmentedPromptSchema = z.object({
  systemInstruction: z.string(),
  userQuery: z.string(),
  context: z.array(RetrievedChunkSchema)
});

class DbFetchError extends Data.TaggedError('DbFetchError')<{ cause: unknown }> {}
class PromptValidationError extends Data.TaggedError('PromptValidationError')<{ error: z.ZodError }> {}

// 2. Effect Workflow Construction
export const augmentContextProgram = (userQuery: string) => 
  Effect.gen(function* (_) {
    // b. Simulates or performs a Drizzle query. 
    // A real drizzle-orm query returns a Promise: `db.select().from(docs).where(...)`
    // which we would wrap in Effect.tryPromise mapping to DbFetchError.
    const chunks = yield* _(
      Effect.succeed<RetrievedChunk[]>([
        { id: 'c1', content: 'Relevant doc snippet', score: 0.95 }
      ])
      // Real implementation: Effect.tryPromise({ try: () => db.query.documents.findMany(), catch: (c) => new DbFetchError({cause: c}) })
    );

    // c. Combine into object matching AugmentedPromptSchema
    const promptPayload = {
      systemInstruction: 'You are a helpful assistant. Use context to answer.',
      userQuery,
      context: chunks
    };

    // d. Boundary check validation before sending to LLM
    return yield* _(
      Effect.try({
        try: () => AugmentedPromptSchema.parse(promptPayload),
        catch: (e) => new PromptValidationError({ error: e as z.ZodError })
      })
    );
  });
