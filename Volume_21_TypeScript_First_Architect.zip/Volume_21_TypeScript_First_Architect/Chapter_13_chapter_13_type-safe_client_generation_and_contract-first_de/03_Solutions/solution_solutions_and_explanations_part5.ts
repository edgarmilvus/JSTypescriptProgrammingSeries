/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Strictness Analysis
// Modified ProjectSchema with priority
const ProjectSchemaV2 = z.object({
  id: z.string().uuid(),
  name: z.string(),
  createdAt: z.string().datetime(),
  status: z.enum(['active', 'archived']),
  priority: z.enum(['low', 'medium', 'high'])
});

// If we use .strict():
const StrictProjectSchema = ProjectSchemaV2.strict();
// Under the Hood: .strict() inserts a runtime check that throws if unknown keys are present.
// TS Type Test pseudo-code:
// type StrictProject = z.infer<typeof StrictProjectSchema>;
// const p: StrictProject = { id: '...', name: '...', createdAt: '...', status: 'active', priority: 'low' }; // OK
// const bad: StrictProject = { ...p, extra: true }; // TS Error & Runtime Error (excess property)

// If we use .passthrough():
const PassthroughProjectSchema = ProjectSchemaV2.passthrough();
// Allows unknown keys to pass through silently, preventing breaking changes for older clients.

// 2. Backward Compatibility Strategy
/**
 * Architectural Proposal: To version the API contract, we maintain parallel Zod schemas 
 * (e.g., `ProjectSchemaV1` without priority, `ProjectSchemaV2` with priority). 
 * We define `contractV1` and `contractV2` objects pointing to `/v1/projects` and `/v2/projects`. 
 * Our `createApiClient` factory can generate both clients simultaneously from the same codebase 
 * by iterating over a dictionary of versioned contracts, ensuring old clients remain functional 
 * while new clients adopt the richer schema.
 */

// 3. Interactive Task
/**
 * Exact TypeScript Compiler Error Description:
 * If the server's Zod schema is updated to V2 (adding `priority`) and the client imports the 
 * updated contract but fails to handle `priority`, `tsc` will emit:
 * "Property 'priority' is missing in type '{ id: string; name: string; ... }' but required in type 
 * '{ id: string; name: string; ...; priority: "low" | "medium" | "high"; }'."
 * `z.infer` acts as a "compile-time breaker." Because the client's Effect success channel is bound 
 * to `z.infer<typeof contract.output>`, the type mismatch is caught before shipping, preventing a 
 * runtime crash where `project.priority` would be `undefined` in the UI.
 */
