/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/actions/waitlist.ts
// This module demonstrates the server-side boundary where validation occurs.
'use server';

import { z } from 'zod';

/**
 * Zod Schema defining the strict shape of our Waitlist Signup payload.
 * We use z.object to enforce a structural contract for the incoming data.
 */
const WaitlistSchema = z.object({
  email: z.string().email({ message: "Invalid email format provided" }),
  companyName: z.string().min(2, { message: "Company name must be at least 2 characters" }),
});

/**
 * The Server Action responsible for handling the waitlist submission.
 * It accepts raw, untrusted input from the client and validates it.
 * @param {unknown} rawInput - The untrusted payload sent from the browser.
 * @returns {Promise<{ success: boolean; message: string }>} A serializable response object.
 */
export async function submitWaitlist(rawInput: unknown): Promise<{ success: boolean; message: string }> {
  // 1. Runtime Validation Guardrail using Zod's safeParse
  const validationResult = WaitlistSchema.safeParse(rawInput);

  // 2. Guardrail failure path: Return structured error without throwing
  if (!validationResult.success) {
    return {
      success: false,
      message: "Validation failed: " + validationResult.error.issues[0].message,
    };
  }

  // 3. Guardrail success path: Data is now typed, parsed, and safe
  const { email, companyName } = validationResult.data;

  // 4. Simulated side-effect (e.g., Drizzle ORM insert would go here)
  console.log(`SaaS Waitlist Lead Captured: ${email} from ${companyName}`);

  return {
    success: true,
    message: "You have been added to the waitlist!",
  };
}
