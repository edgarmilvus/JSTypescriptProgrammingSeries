/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/components/WaitlistForm.tsx
// This Client Component handles user interaction and invokes the Server Action.
'use client';

import React, { useState, useTransition } from 'react';
import { submitWaitlist } from '../actions/waitlist';

/**
 * WaitlistForm Component
 * Renders a simple form, manages local state, and calls the Server Action.
 */
export default function WaitlistForm() {
  // Local state for form inputs
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  
  // State for server response feedback
  const [status, setStatus] = useState<{ type: 'idle' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  });

  // useTransition prevents the UI from freezing during the async Server Action call
  const [isPending, startTransition] = useTransition();

  /**
   * Handles the form submission event.
   * @param {React.FormEvent} e - The form event object.
   */
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    // Clear previous status
    setStatus({ type: 'idle', message: '' });

    // Wrap the Server Action call in a transition
    startTransition(async () => {
      const result = await submitWaitlist({ email, companyName });
      
      if (result.success) {
        setStatus({ type: 'success', message: result.message });
        setEmail('');
        setCompanyName('');
      } else {
        setStatus({ type: 'error', message: result.message });
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '400px' }}>
      <label htmlFor="email">Work Email</label>
      <input
        id="email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@company.com"
        required
      />
      
      <label htmlFor="company">Company Name</label>
      <input
        id="company"
        type="text"
        value={companyName}
        onChange={(e) => setCompanyName(e.target.value)}
        placeholder="Acme Corp"
        required
      />
      
      <button type="submit" disabled={isPending}>
        {isPending ? 'Submitting...' : 'Join Waitlist'}
      </button>
      
      {status.type !== 'idle' && (
        <p style={{ color: status.type === 'success' ? 'green' : 'red' }}>{status.message}</p>
      )}
    </form>
  );
}
