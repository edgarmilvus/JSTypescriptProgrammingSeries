/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

"use server";

import { z } from "zod";
import { Effect, Either } from "effect";
import { db } from "@/lib/db"; 
import { inferenceJobs, priorityQueue } from "@/lib/schema"; 

/**
 * Zod Schema enforcing strict validation guardrails at the network boundary.
 * This prevents malformed payloads from ever reaching the database or compute layer.
 * We define exact constraints to protect our headless inference cluster.
 */
const InferenceRequestSchema = z.object({
  prompt: z.string().min(10, "Prompt must be at least 10 chars for context"),
  modelId: z.enum(["llama-3-8b", "mistral-7b"]),
  priority: z.number().int().min(1).max(5).default(3),
});

/** Type inference from Zod schema for end-to-end type safety across the stack */
type InferenceRequest = z.infer<typeof InferenceRequestSchema>;

/**
 * Validates the runtime environment to ensure we are in a Node.js context.
 * Headless Inference cannot run in a browser; this guards against misconfiguration.
 */
const verifyHeadlessEnvironment = Effect.gen(function* (_) {
  const isServer = typeof window === "undefined";
  if (!isServer) {
    return yield* _(Effect.fail(new Error("Headless inference requires a server environment")));
  }
  return yield* _(Effect.succeed("Server environment confirmed"));
});

/**
 * Persists the validated job to the primary jobs table via Drizzle ORM.
 * Wrapped in Effect.tryPromise to capture database failures in the Effect context
 * rather than throwing traditional exceptions that crash the Node process.
 */
const persistJob = (data: InferenceRequest) => 
  Effect.tryPromise({
    try: () => db.insert(inferenceJobs).values({
      prompt: data.prompt,
      modelId: data.modelId,
      priority: data.priority,
      status: "queued"
    }).returning({ id: inferenceJobs.id }),
    catch: (e) => new Error(`DB Insert Failed: ${JSON.stringify(e)}`)
  });

/**
 * Routes high-priority jobs to a dedicated priority queue table.
 * This simulates a "Conditional Edge" where the graph state (priority level)
 * determines the name of the next execution node (standard vs priority queue).
 */
const routeConditionalEdge = (jobId: number, priority: number) =>
  priority > 3 
    ? Effect.tryPromise({
        try: () => db.insert(priorityQueue).values({ jobId }).execute(),
        catch: () => new Error("Priority routing failed")
      })
    : Effect.succeed("Routed to standard queue");

/**
 * Core Effect workflow orchestrating the Headless Inference lifecycle.
 * @param validatedData - The Zod-parsed request payload
 */
const orchestrateInference = (validatedData: InferenceRequest) =>
  Effect.gen(function* (_) {
    // Step 1: Ensure we are running in a headless (server-side) context
    yield* _(verifyHeadlessEnvironment);
    
    // Step 2: Persist the job to the database using Drizzle
    const dbResult = yield* _(persistJob(validatedData));
    const jobId = dbResult[0].id;
    
    // Step 3: Evaluate Conditional Edge (priority-based routing logic)
    yield* _(routeConditionalEdge(jobId, validatedData.priority));
    
    // Step 4: Log the headless inference trigger (server-side execution)
    yield* _(Effect.logInfo(`Headless Inference triggered for Job ${jobId}`));
    
    return { jobId, status: "queued" as const };
  });

/**
 * Next.js Server Action exposed to the client component.
 * Acts as the strict boundary enforcing Zod guardrails before Effect execution.
 * @param input - Unknown payload from the client
 */
export async function submitInferenceJob(input: unknown) {
  // Boundary validation using Zod's safeParse to avoid throwing
  const parsed = InferenceRequestSchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, errors: parsed.error.flatten() };
  }

  // Execute Effect workflow with built-in error handling via Either
  const program = orchestrateInference(parsed.data);
  const result = await Effect.runPromise(Effect.either(program));

  // Pattern match on Either to return strictly typed success/error responses
  if (Either.isLeft(result)) {
    return { success: false, errors: result.left.message };
  }
  return { success: true, data: result.right };
}
