/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// REQUIRED TYPE CONTRACT FOR EXERCISE 1
export type ActionResponse<T> = 
  | { status: "success"; data: T }
  | { status: "error"; validationErrors: Record<string, string[]> };

// 1. Schema Definition
export const CreateProjectSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters").max(50, "Name must be 50 characters or less"),
  description: z.string().max(200, "Description must be less than 200 characters").optional(),
  priority: z.enum(["low", "medium", "high"], { errorMap: () => ({ message: "Invalid priority level" }) }),
  tags: z.array(z.string()).max(5, "Cannot have more than 5 tags"),
});

// Infer the static type for compile-time safety
export type ProjectSuccessData = z.infer<typeof CreateProjectSchema>;

// 2. Server Action Implementation
"use server";
export async function createProjectAction(input: unknown): Promise<ActionResponse<ProjectSuccessData>> {
  // 3. Safe Parsing: safeParse returns a discriminated union and does NOT throw.
  // This is superior for Server Actions because throwing creates unhandled rejection 
  // states that crash the Node.js runtime or produce generic 500 errors to the client.
  const result = CreateProjectSchema.safeParse(input);

  if (!result.success) {
    // 4. Typed Error Response: Map Zod issues to the required Record format
    const validationErrors: Record<string, string[]> = {};
    for (const issue of result.error.issues) {
      const path = issue.path.join(".") || "root";
      if (!validationErrors[path]) {
        validationErrors[path] = [];
      }
      validationErrors[path].push(issue.message);
    }
    return { status: "error", validationErrors };
  }

  // In a real application, we would persist result.data here.
  return { status: "success", data: result.data };
}
