/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect } from "effect";
import { CreateProjectSchema, type ProjectSuccessData } from "./exercise1";

// 1. Error Modeling
export class ValidationError {
  readonly _tag = "ValidationError";
  constructor(readonly issues: z.ZodIssue[]) {}
}

export class UnexpectedError {
  readonly _tag = "UnexpectedError";
  constructor(readonly cause: unknown) {}
}

type AppError = ValidationError | UnexpectedError;

// 2. Effect Wrapping
export function createProjectPipeline(input: unknown): Effect.Effect<
  ProjectSuccessData,
  AppError,
  never
> {
  // 3. Generator Composition
  return Effect.gen(function* (_) {
    const parseResult = CreateProjectSchema.safeParse(input);
    
    if (!parseResult.success) {
      // Short-circuit the pipeline with a typed failure value
      yield* Effect.fail(new ValidationError(parseResult.error.issues));
    }
    
    // At this point, parseResult is successfully narrowed by Effect's control flow
    const validData = parseResult.data;
    
    // Conceptual DB step: yield* dbInsert(validData) would naturally propagate a PersistenceError
    // if we had modeled it in the AppError union.
    
    return validData;
  });
}

/*
 4. Error Recovery (Conceptual):
 To convert the Effect back to the ActionResponse<T> at the Server Action boundary, we use Effect.match:
 
 export async function createProjectAction(input: unknown): Promise<ActionResponse<ProjectSuccessData>> {
   const pipeline = createProjectPipeline(input);
   
   return await Effect.match(pipeline, {
     onFailure: (err) => {
       if (err._tag === "ValidationError") {
         const validationErrors: Record<string, string[]> = {};
         err.issues.forEach(i => {
           const path = i.path.join(".") || "root";
           (validationErrors[path] ??= []).push(i.message);
         });
         return { status: "error", validationErrors };
       }
       return { status: "error", validationErrors: { root: ["Unexpected error occurred"] } };
     },
     onSuccess: (data) => ({ status: "success", data })
   }).pipe(Effect.runPromise);
 }
*/
