/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { pgTable, pgEnum, varchar, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { Effect } from "effect";
import { db } from "./db-client"; // Conceptual Drizzle database instance

// 1. Drizzle Schema Definition
export const priorityEnum = pgEnum("priority", ["low", "medium", "high"]);

export const projects = pgTable("projects", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: varchar("name", { length: 50 }).notNull(),
  description: text("description"),
  priority: priorityEnum("priority").notNull(),
  tags: text("tags").array().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// 2. Schema Inference
// Omit DB-managed columns from the *input* validation schema
export const InsertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
}).extend({
  // Ensure strict business rules (e.g., min length) are enforced at runtime
  name: z.string().min(3).max(50),
  tags: z.array(z.string()).max(5),
});

export type ProjectSuccessData = z.infer<typeof InsertProjectSchema>;

// Error Modeling
export class ValidationError {
  readonly _tag = "ValidationError";
  constructor(readonly issues: z.ZodIssue[]) {}
}

export class DbError {
  readonly _tag = "DbError";
  constructor(readonly cause: unknown) {}
}

// 3 & 4. Effect Integration and Database Execution
export function createProjectPipeline(input: unknown): Effect.Effect<
  ProjectSuccessData,
  ValidationError | DbError,
  never
> {
  return Effect.gen(function* (_) {
    // Replace standalone Zod schema with Drizzle-inferred schema
    const parseResult = InsertProjectSchema.safeParse(input);
    if (!parseResult.success) {
      yield* Effect.fail(new ValidationError(parseResult.error.issues));
    }
    const validData = parseResult.data;

    // Wrap Drizzle's Promise-returning query in Effect.tryPromise
    const insertedRows = yield* Effect.tryPromise({
      try: () => db.insert(projects).values(validData).returning(),
    }).pipe(
      // Map any Promise rejection to a typed DbError using Effect.mapError
      Effect.mapError((e) => new DbError(e))
    );

    // 5. Return Type Alignment: returning() gives us the full row, structurally compatible
    return insertedRows[0] as ProjectSuccessData;
  });
}
