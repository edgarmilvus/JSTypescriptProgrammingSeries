/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

"use client";
import { useTransition, useState } from "react";
import { createProjectAction, type ActionResponse, type ProjectSuccessData } from "./server-actions";

export function ProjectCreationForm() {
  const [isPending, startTransition] = useTransition();
  
  // State for form fields
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high">("low");
  const [tags, setTags] = useState("");
  
  // State for consuming the discriminated union
  const [response, setResponse] = useState<ActionResponse<ProjectSuccessData> | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // 3. Form Submission: Wrap invocation in startTransition
    startTransition(async () => {
      const payload = {
        name,
        description: description || undefined,
        priority,
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
      };
      
      // 6. Type Safety: Server Action returns strictly typed Promise<ActionResponse<T>>
      const res = await createProjectAction(payload);
      setResponse(res);
      
      if (res.status === "success") {
        // Clear form on success
        setName(""); setDescription(""); setTags(""); setPriority("low");
      }
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <input 
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          placeholder="Project Name" 
          disabled={isPending} 
        />
        {/* 5. Consuming the Discriminated Union: Render validation errors */}
        {response?.status === "error" && response.validationErrors.name && (
          <span style={{ color: "red" }}>{response.validationErrors.name.join(", ")}</span>
        )}
      </div>
      
      <div>
        <input 
          value={tags} 
          onChange={(e) => setTags(e.target.value)} 
          placeholder="Comma-separated tags" 
          disabled={isPending}
        />
        {response?.status === "error" && response.validationErrors.tags && (
          <span style={{ color: "red" }}>{response.validationErrors.tags.join(", ")}</span>
        )}
      </div>

      {/* 4. Pending UI: Disable button and change text while isPending is true */}
      <button type="submit" disabled={isPending}>
        {isPending ? "Saving..." : "Create Project"}
      </button>

      {response?.status === "success" && (
        <p style={{ color: "green" }}>Project created successfully!</p>
      )}
    </form>
  );
}
