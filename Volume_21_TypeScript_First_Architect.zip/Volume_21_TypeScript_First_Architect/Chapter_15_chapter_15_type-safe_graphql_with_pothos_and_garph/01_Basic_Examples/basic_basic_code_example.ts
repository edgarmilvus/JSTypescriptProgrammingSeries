/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { createYoga, createSchema } from 'graphql-yoga';
import { createServer } from 'http';
import SchemaBuilder from '@pothos/core';

/**
 * Represents a user in our TaskFlow SaaS application.
 * This interface is the single source of truth for our TypeScript compiler.
 * In a production environment, this would likely be inferred from Drizzle ORM.
 */
interface TaskFlowUser {
  id: string;
  displayName: string;
  emailAddress: string;
  isSubscriptionActive: boolean;
}

// Simulating a database layer (e.g., Drizzle ORM would generate these types)
const mockUserDatabase: TaskFlowUser[] = [
  { id: 'usr_001', displayName: 'Alice Founder', emailAddress: 'alice@taskflow.io', isSubscriptionActive: true },
  { id: 'usr_002', displayName: 'Bob User', emailAddress: 'bob@taskflow.io', isSubscriptionActive: false },
];

// 1. Instantiate the Pothos Schema Builder
const builder = new SchemaBuilder({});

// 2. Define the 'User' Object Type using Pothos, binding it to our TypeScript interface
builder.objectType<TaskFlowUser>('User', {
  description: 'A registered user within the TaskFlow SaaS platform',
  fields: (t) => ({
    id: t.string({
      description: 'The unique identifier for the user',
      resolve: (parent) => parent.id,
    }),
    name: t.string({
      description: 'The display name of the user',
      resolve: (parent) => parent.displayName,
    }),
    email: t.string({
      description: 'The contact email of the user',
      resolve: (parent) => parent.emailAddress,
    }),
    isPro: t.boolean({
      description: 'Indicates if the user has an active subscription',
      resolve: (parent) => parent.isSubscriptionActive,
    }),
  }),
});

// 3. Define the Root Query Type
builder.queryType({
  fields: (t) => ({
    fetchUserById: t.field({
      type: 'User',
      description: 'Retrieves a single user by their unique ID',
      args: {
        userId: t.arg.string({ required: true, description: 'The ID of the user to fetch' }),
      },
      resolve: async (parent, args) => {
        // Simulate an asynchronous database lookup (non-blocking)
        const foundUser = mockUserDatabase.find((user) => user.id === args.userId);
        
        // Return null if not found, adhering to GraphQL nullable type
        return foundUser ?? null;
      },
    }),
  }),
});

// 4. Compile the TypeScript definitions into a runtime GraphQL Schema
const graphqlSchema = builder.toSchema();

// 5. Initialize the GraphQL Yoga server with our schema
const yogaServer = createYoga({ schema: graphqlSchema });

// 6. Bind to Node.js HTTP server to listen for requests
const httpServer = createServer(yogaServer);

httpServer.listen(4000, () => {
  console.log('TaskFlow GraphQL API is live at http://localhost:4000/graphql');
});
