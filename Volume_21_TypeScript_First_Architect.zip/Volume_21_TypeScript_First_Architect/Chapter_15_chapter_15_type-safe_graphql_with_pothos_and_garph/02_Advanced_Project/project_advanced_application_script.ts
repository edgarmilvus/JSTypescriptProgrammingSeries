/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createYoga } from 'graphql-yoga';
import SchemaBuilder from '@pothos/core';
import { z } from 'zod';
import { NextRequest } from 'next/server';

/**
 * Zod Schema for Runtime Validation of RAG Pipeline Inputs.
 * Enforces structural integrity and semantic constraints for external SaaS API consumers,
 * mitigating the risk of malformed payloads reaching the orchestration layer.
 */
const RagQueryInput = z.object({
  documentId: z.string().uuid(),
  userPrompt: z.string().min(10).max(500),
});

/**
 * Immutable State definition for the RAG Pipeline stages.
 * The `readonly` modifiers enforce compile-time immutability, ensuring that
 * state transitions must produce new objects rather than mutating existing ones.
 */
type RagPipelineState = {
  readonly stage: 'IDLE' | 'LOADING' | 'CHUNKING' | 'EMBEDDING' | 'RETRIEVAL' | 'SYNTHESIS' | 'COMPLETE';
  readonly context: ReadonlyArray<string>;
  readonly result?: string;
};

// Initialize Pothos Schema Builder for type-safe GraphQL construction
const builder = new SchemaBuilder({});

// Define RAG State Object Type in GraphQL via Pothos (Type-Safe mapping)
builder.objectType('RagState', {
  description: 'Immutable state tracking for the RAG Pipeline',
  fields: (t) => ({
    stage: t.string({ resolve: (parent: RagPipelineState) => parent.stage }),
    contextSize: t.int({ resolve: (parent: RagPipelineState) => parent.context.length }),
    result: t.string({ nullable: true, resolve: (parent: RagPipelineState) => parent.result ?? null }),
  }),
});

// Define Input Type for the GraphQL Mutation leveraging Pothos
builder.inputType('RagInput', {
  fields: (t) => ({
    documentId: t.string({ required: true }),
    userPrompt: t.string({ required: true }),
  }),
});

/**
 * Simulates vector embedding generation within the Node.js environment.
 * @param chunks The immutable context array containing document chunks.
 * @returns A new array representing vectorized data (mocked as prefixed strings).
 */
function generateEmbeddings(chunks: ReadonlyArray<string>): ReadonlyArray<string> {
  return chunks.map((chunk) => `vec_${chunk}`);
}

/**
 * Mock RAG Pipeline Orchestrator using Immutable State transitions.
 * Each stage produces a new state object rather than mutating the old one,
 * preventing race conditions in concurrent SaaS environments.
 */
async function runRagPipeline(input: z.infer<typeof RagQueryInput>): Promise<RagPipelineState> {
  let state: RagPipelineState = { stage: 'IDLE', context: [] };
  state = { ...state, stage: 'LOADING' }; // Immutable transition
  await new Promise((r) => setTimeout(r, 10)); // Simulate async I/O for document loading
  state = { ...state, stage: 'CHUNKING', context: [`chunk-${input.documentId}-1`, `chunk-${input.documentId}-2`] };
  const embedded = generateEmbeddings(state.context); // Simulate embedding stage
  state = { ...state, stage: 'EMBEDDING', context: embedded };
  state = { ...state, stage: 'RETRIEVAL' };
  state = { ...state, stage: 'SYNTHESIS', result: `Synthesized answer for: ${input.userPrompt}` };
  return { ...state, stage: 'COMPLETE' };
}

// Define GraphQL Query for basic health check of the SaaS service
builder.queryType({
  fields: (t) => ({
    ping: t.string({ resolve: () => 'pong' }),
  }),
});

// Define GraphQL Mutation for triggering the RAG pipeline
builder.mutationType({
  fields: (t) => ({
    executeRag: t.field({
      type: 'RagState',
      args: {
        input: t.arg({ type: 'RagInput', required: true }),
      },
      resolve: async (_parent, args) {
        // Runtime Validation using Zod at the application boundary
        const validated = RagQueryInput.parse(args.input);
        return runRagPipeline(validated);
      },
    }),
  }),
});

// Build the executable GraphQL Schema from the Pothos type definitions
const schema = builder.toSchema();

// Next.js Route Handler configuration for GraphQL Yoga
const yoga = createYoga({ schema, graphqlEndpoint: '/api/graphql' });

export async function POST(request: NextRequest) {
  return yoga.handleRequest(request, {});
}

export async function GET(request: NextRequest) {
  return yoga.handleRequest(request, {});
}
