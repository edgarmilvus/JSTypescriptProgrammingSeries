/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import SchemaBuilder from '@pothos/core';
import ZodPlugin from '@pothos/plugin-zod';
import { z } from 'zod';

// 1. Initialize Builder with Context and Zod Plugin
interface Context {
  requestId: string;
  userId: string | null;
  db: any; // Hypothetical DB client
}

const builder = new SchemaBuilder<{
  Context: Context;
  Zod: true; // Enables Zod plugin types
}>({
  plugins: [ZodPlugin],
});

// 2. Define Zod-Backed Input
const CreateUserInput = builder.inputType('CreateUserInput', {
  zod: z.object({
    username: z.string().min(3),
    email: z.string().email(),
    age: z.number().int().positive(),
  }),
});

// 3. Construct the Object Type
interface UserDomainModel {
  id: string;
  username: string;
  email: string;
  createdAt: Date;
}

const User = builder.objectType('User', {
  description: 'A registered user',
  fields: (t) => ({
    id: t.exposeString('id'),
    username: t.exposeString('username'),
    email: t.exposeString('email'),
    createdAt: t.expose('createdAt', { type: 'Date' }),
  }),
});

// 4. Implement the Resolver Logic (Mutation)
builder.mutationField('createUser', (t) =>
  t.field({
    type: User,
    args: {
      input: t.arg({ type: CreateUserInput }),
    },
    // Resolver receives validated args and typed context
    resolve: async (_parent, { input }, ctx) => {
      // input is statically typed and runtime-validated by Zod
      const newUser: UserDomainModel = {
        id: crypto.randomUUID(),
        username: input.username,
        email: input.email,
        createdAt: new Date(),
      };
      return newUser;
    },
  })
);
