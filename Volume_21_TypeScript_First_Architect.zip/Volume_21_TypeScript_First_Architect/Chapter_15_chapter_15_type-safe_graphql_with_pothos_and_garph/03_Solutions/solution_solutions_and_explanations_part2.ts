/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { InferSelectModel } from 'drizzle-orm';
import { pgTable, serial, text, integer } from 'drizzle-orm/pg-core';
import SchemaBuilder from '@pothos/core';

// Drizzle Schema
const posts = pgTable('posts', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  authorId: integer('author_id'), // Nullable
});
type PostModel = InferSelectModel<typeof posts>;

// 1 & 2. Pothos Object Type & Relational Resolution
const builder = new SchemaBuilder<{ Context: { db: any } }>({});

const Post = builder.objectType<PostModel>('Post', {
  fields: (t) => ({
    id: t.exposeInt('id'),
    title: t.exposeString('title'),
    content: t.exposeString('content'),
    // Reflect Drizzle nullability in Pothos explicitly
    authorId: t.exposeInt('authorId', { nullable: true }), 
  }),
});

const Author = builder.objectType('Author', {
  fields: (t) => ({ id: t.id({ resolve: (p: any) => p.id }) }),
});

// Lazy-loading Author via separate resolver using parent ID
builder.objectField(Post, 'author', (t) => 
  t.field({
    type: Author,
    nullable: true,
    resolve: async (parent, _args, ctx) => {
      if (!parent.authorId) return null;
      return ctx.db.query.authors.findFirst({ where: (a: any, { eq }: any) => eq(a.id, parent.authorId) });
    },
  })
);

// 3 & 4. Context DI and Transaction Safety in Mutation
builder.mutationField('createUserAndPost', (t) =>
  t.field({
    type: Post,
    args: { title: t.arg.string({ required: true }) },
    resolve: async (_parent, { title }, ctx) => {
      try {
        return await ctx.db.transaction(async (tx: any) => {
          const [user] = await tx.insert(users).values({ name: 'New' }).returning();
          const [post] = await tx.insert(posts).values({ title, authorId: user.id }).returning();
          return post;
        });
      } catch (err: any) {
        // Translate DB error to GraphQL-safe error
        throw new Error('Failed to create user and post due to a data constraint.');
      }
    },
  })
);
