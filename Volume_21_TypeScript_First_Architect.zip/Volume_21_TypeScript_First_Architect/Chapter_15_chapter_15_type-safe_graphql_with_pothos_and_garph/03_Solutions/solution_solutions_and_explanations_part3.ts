/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { g, buildSchema } from 'garph';
import { z } from 'zod';

const Task = g.object('Task', {
  id: g.string(),
  title: g.string(),
  completed: g.boolean(),
  priority: g.int(), // Expects number
});

const query = g.query({
  task: g.field({
    type: Task,
    // Zod-validated UUID argument replacing generic string
    args: {
      id: g.arg(z.string().uuid()),
    },
    resolve: (parent, args) => {
      // Intervention: Transform 'high' to a numeric priority to match g.int()
      const fakeDbTask = {
        id: args.id,
        title: 'Buy Groceries',
        completed: false,
        priority: 1, // Transformed to number to satisfy Garph's static inference
      };
      return fakeDbTask;
    },
  }),
});

export const schema = buildSchema({ query, mutation: undefined });
