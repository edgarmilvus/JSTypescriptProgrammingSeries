/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import { useQuery } from 'urql';
import { useUIState } from 'ai';
import { ComponentType, Suspense } from 'react';

// Inferred type from Garph/Pothos schema
type ConversationQueryResult = {
  conversation: {
    id: string;
    messages: Array<{ id: string; role: 'user' | 'assistant'; content: string }>;
  } | null;
};

const HISTORY_QUERY = `
  query GetHistory($id: String!) {
    conversation(id: $id) { id messages { id role content } }
  }
`;

// Architecture: Map GraphQL to UIState (React Nodes)
function mapGraphQLToUIState(data: ConversationQueryResult) {
  if (!data.conversation) return [];
  return data.conversation.messages.map((msg) => ({
    id: msg.id,
    display: (
      <div className={msg.role === 'user' ? 'text-right' : 'text-left'}>
        {msg.content}
      </div>
    ),
  }));
}

export function HistorySync({ conversationId }: { conversationId: string }) {
  const [result] = useQuery<ConversationQueryResult>({ query: HISTORY_QUERY, variables: { id: conversationId } });
  const [, setUIState] = useUIState();

  if (result.data) {
    setUIState((prev) => [...prev, ...mapGraphQLToUIState(result.data!)]);
  }
  return null; // Conceptual: actual render handled by Suspense/Error Boundary
}
