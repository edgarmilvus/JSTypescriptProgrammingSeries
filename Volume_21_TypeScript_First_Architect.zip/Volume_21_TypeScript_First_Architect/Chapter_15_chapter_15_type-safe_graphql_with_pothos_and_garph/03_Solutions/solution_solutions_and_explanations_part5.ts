/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import SchemaBuilder from '@pothos/core';
import { Effect, Context, Exit } from 'effect';
import { z } from 'zod';

// 1. Effect Type Definition
type RagSuccess = { answer: string; sources: string[] };
type RagError = 
  | { _tag: 'EmbeddingError'; msg: string }
  | { _tag: 'DbError'; msg: string }
  | { _tag: 'LLMTimeout'; msg: string };

// 4. Dependency Injection Tags
class EmbeddingClient extends Context.Tag('EmbeddingClient')<EmbeddingClient, { embed: (s: string) => Promise<string[]> }>() {}
class LLMClient extends Context.Tag('LLMClient')<LLMClient, { generate: (s: string) => Promise<string> }>() {}

const ragPipeline = Effect.gen(function* (_) {
  // ... pipeline logic using EmbeddingClient and LLMClient
  return yield* Effect.succeed({ answer: '...', sources: [] } as RagSuccess);
}).pipe(Effect.provide(EmbeddingClient), Effect.provide(LLMClient));

// 2. Pothos Mutation Bridge
const builder = new SchemaBuilder<{ Context: { db: any } }>({});

builder.mutationField('askKnowledgeBase', (t) =>
  t.field({
    type: 'String',
    args: { question: t.arg({ type: builder.inputType('QuestionInput', { zod: z.object({ q: z.string().min(1) }) }) }) },
    resolve: async (_parent, { question }, _ctx) => {
      // Run Effect and capture Exit
      const exit = await Effect.runPromiseExit(ragPipeline);
      if (Exit.isFailure(exit)) {
        // Map discriminated union error to GraphQL safe error
        throw new Error(`Pipeline failed: ${exit.cause._tag}`);
      }
      return exit.value.answer;
    },
  })
);
