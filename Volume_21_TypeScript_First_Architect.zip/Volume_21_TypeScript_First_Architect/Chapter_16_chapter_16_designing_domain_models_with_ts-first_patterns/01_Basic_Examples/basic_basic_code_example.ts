/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * Defines a branded type for User IDs.
 * In a multi-tenant SaaS platform, confusing a UserId with a TenantId or a SessionId 
 * is a critical, hard-to-debug bug. Branding enforces nominal typing within 
 * TypeScript's default structural type system.
 */
const UserIdSchema = z.string().uuid().brand<'UserId'>();

/** 
 * The inferred static TypeScript type for a UserId. 
 * It carries a phantom "brand" property that exists only at the type level.
 */
type UserId = z.infer<typeof UserIdSchema>;

/**
 * The central Domain Model for a SaaS User.
 * This Zod schema is the SINGLE SOURCE OF TRUTH for both the runtime validation 
 * pipeline and the static TypeScript type definition used throughout the app.
 */
const UserSchema = z.object({
  id: UserIdSchema,
  email: z.string().email({ message: "Invalid email format provided" }),
  subscriptionTier: z.enum(['free', 'pro', 'enterprise']),
  createdAt: z.date(),
  metadata: z.record(z.string(), z.unknown()).optional()
});

/** 
 * Inferred static type for our User domain model. 
 * If the schema changes, this type automatically updates everywhere it is used.
 */
type User = z.infer<typeof UserSchema>;

/**
 * Validates an untrusted payload from an API route (e.g., a Next.js route handler 
 * deployed on Vercel or a standard Express middleware).
 * @param rawInput - The completely unknown body of an HTTP request.
 * @returns A promise resolving to a fully validated, strongly-typed User domain object.
 */
async function validateIncomingUser(rawInput: unknown): Promise<User> {
  // Zod's parseAsync method runs the validation pipeline asynchronously
  return UserSchema.parseAsync(rawInput);
}

// --- Hello World Execution Context ---
// Simulating a raw JSON payload arriving from a client-side fetch or LLM tool call
const mockRequestPayload = {
  id: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
  email: 'admin@my-saas-app.com',
  subscriptionTier: 'pro',
  createdAt: new Date('2023-10-01T12:00:00Z'),
};

// Execute the validation and handle the strictly typed success or failure
validateIncomingUser(mockRequestPayload)
  .then((user) => {
    // Here, 'user' is guaranteed to match the User type exactly
    console.log(`User ${user.id} validated successfully with tier: ${user.subscriptionTier}`);
  })
  .catch((err) => {
    // Zod throws a ZodError containing detailed, path-specific validation issues
    console.error('Validation failed at boundary:', err);
  });
