/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useOptimistic, useEffect } from 'react';
import { z } from 'zod';
import { Effect } from 'effect';

// [1] BRANDING: Enforce nominal typing for Domain IDs at type-level
const UserId = z.string().uuid().brand<'UserId'>();
const TaskId = z.number().int().positive().brand<'TaskId'>();

// [2] DISCRIMINATED UNION: Model state transitions exhaustively
const TaskState = z.discriminatedUnion('status', [
  z.object({ status: z.literal('pending'), eta: z.number() }),
  z.object({ status: z.literal('active'), startedAt: z.number() }),
  z.object({ status: z.literal('done'), completedAt: z.number() }),
]);
type TaskState = z.infer<typeof TaskState>;

// [3] DOMAIN MODEL: Zod as single source of truth for types & runtime
const TaskSchema = z.object({
  id: TaskId,
  owner: UserId,
  title: z.string().min(3),
  state: TaskState,
});
type Task = z.infer<typeof TaskSchema>;

// [4] EDGE-FIRST & SAB: Shared memory for worker-based validation
const sab = typeof SharedArrayBuffer !== 'undefined' ? new SharedArrayBuffer(1024) : null;
const sharedView = sab ? new Int32Array(sab) : null;

/**
 * Simulates an Edge API call for low-latency task creation.
 * @param task - The task payload to validate and send to the edge
 */
async function postTaskToEdge(task: unknown): Promise<Task> {
  const res = await fetch('/api/tasks', {
    method: 'POST',
    body: JSON.stringify(task),
    headers: { 'Content-Type': 'application/json' },
  });
  const data = await res.json();
  return TaskSchema.parse(data); // Boundary validation
}

// [5] EFFECT INTEGRATION: Composable, fault-tolerant validation pipeline
const validateTaskEffect = (input: unknown) =>
  Effect.tryCatch(
    () => TaskSchema.parse(input),
    (e) => new Error(`Domain validation failed: ${JSON.stringify(e)}`)
  );

// [6] OPTIMISTIC UI COMPONENT: SaaS Task Manager
export default function TaskManager({ userId }: { userId: string }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [optimisticTasks, addOptimisticTask] = useOptimistic(
    tasks,
    (state, newTask: Task) => [...state, newTask]
  );

  /**
   * Handles submission with Optimistic UI and Reconciliation.
   */
  async function handleSubmit(formData: FormData) {
    const rawTitle = formData.get('title') as string;
    const tempTask: Task = {
      id: Math.floor(Math.random() * 100000) as z.infer<typeof TaskId>,
      owner: userId as z.infer<typeof UserId>,
      title: rawTitle,
      state: { status: 'pending', eta: 1000 },
    };

    addOptimisticTask(tempTask); // Immediate UI update

    const program = validateTaskEffect(tempTask).pipe(
      Effect.flatMap(() => Effect.tryPromise(() => postTaskToEdge(tempTask)))
    );

    try {
      const confirmed = await Effect.runPromise(program);
      // Reconciliation: replace temp with confirmed server state
      setTasks((prev) => prev.map((t) => (t.id === tempTask.id ? confirmed : t)));
    } catch (e) {
      // Rollback would remove the optimistic task here
      console.error('Task creation failed', e);
    }
  }

  // [7] WORKER RECONCILIATION LISTENER (Conceptual SAB usage)
  useEffect(() => {
    if (!sharedView) return;
    const interval = setInterval(() => {
      const status = Atomics.load(sharedView, 0);
      if (status === 1) console.log('Worker validation complete');
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <form action={handleSubmit}>
      <input name="title" placeholder="Task title" />
      <button type="submit">Add Task</button>
      <ul>
        {optimisticTasks.map((t) => (
          <li key={t.id}>{t.title} - {t.state.status}</li>
        ))}
      </ul>
    </form>
  );
}
