/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define Branded Schemas using transform + intersection for phantom brand
export const AccountIdSchema = z
  .string()
  .uuid()
  .transform((val) => val as string & { __brand: "AccountId" });

export const RoutingNumberSchema = z
  .string()
  .length(9)
  .transform((val) => val as string & { __brand: "RoutingNumber" });

// 2. Derive Static Types
export type AccountId = z.infer<typeof AccountIdSchema>;
export type RoutingNumber = z.infer<typeof RoutingNumberSchema>;

// Demonstrate non-assignability (commented to prevent compile errors in snippet)
// const badId: AccountId = "123" as RoutingNumber; // TS Error: Type 'RoutingNumber' is not assignable to type 'AccountId'.

// 3. Compose the Domain Model
export const LedgerEntrySchema = z.object({
  fromAccount: AccountIdSchema,
  toAccount: AccountIdSchema,
  amount: z.number().positive(),
});
export type LedgerEntry = z.infer<typeof LedgerEntrySchema>;

// 4. Function Signature Contract
export function transferFunds(entry: LedgerEntry): void {
  // Domain logic to process the ledger entry
}
