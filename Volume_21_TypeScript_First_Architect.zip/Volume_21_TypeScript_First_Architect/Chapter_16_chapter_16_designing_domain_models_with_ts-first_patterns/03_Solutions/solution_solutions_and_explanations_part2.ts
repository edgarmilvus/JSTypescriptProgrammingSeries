/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define individual state schemas with literal status discriminants
const PendingJob = z.object({
  status: z.literal("Pending"),
  jobId: z.string(),
});

const ProcessingJob = z.object({
  status: z.literal("Processing"),
  jobId: z.string(),
  startedAt: z.number(),
});

const CompletedJob = z.object({
  status: z.literal("Completed"),
  jobId: z.string(),
  originalPrecision: z.literal("fp32"),
  targetPrecision: z.literal("int8"),
  originalSizeMb: z.number(),
  quantizedSizeMb: z.number(),
}).refine((data) => data.quantizedSizeMb < data.originalSizeMb, {
  message: "Quantized size must be strictly less than original size",
  path: ["quantizedSizeMb"],
});

const FailedJob = z.object({
  status: z.literal("Failed"),
  jobId: z.string(),
  errorMessage: z.string(),
});

// 2. Combine into Discriminated Union
export const QuantizationJobSchema = z.discriminatedUnion("status", [
  PendingJob,
  ProcessingJob,
  CompletedJob,
  FailedJob,
]);

// 3. Type Inference
export type QuantizationJob = z.infer<typeof QuantizationJobSchema>;

// 4. Exhaustive Handler
export function handleJobState(job: QuantizationJob): string {
  switch (job.status) {
    case "Pending":
      return "Waiting in queue...";
    case "Processing":
      return `Processing started at ${job.startedAt}`;
    case "Completed":
      return `Done: ${job.originalSizeMb}mb to ${job.quantizedSizeMb}mb (${job.targetPrecision})`;
    case "Failed":
      return `Error: ${job.errorMessage}`;
    default:
      // Enforces exhaustiveness: if a state is missed, `job` is not `never`
      const _exhaustiveCheck: never = job;
      return _exhaustiveCheck;
  }
}
