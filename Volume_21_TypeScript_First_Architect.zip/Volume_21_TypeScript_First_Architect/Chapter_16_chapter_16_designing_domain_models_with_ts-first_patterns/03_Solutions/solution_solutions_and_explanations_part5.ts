/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { pgTable, text, uuid, index } from "drizzle-orm/pg-core";
import { vector } from "drizzle-orm/pg-vector";

// 1. Zod Pre-Validation
export const DocumentInputSchema = z.object({
  content: z.string(),
  sourceUrl: z.string().url(),
  embedding: z.array(z.number()).min(1),
});

// 2. Drizzle Schema with pgvector
export const documents = pgTable(
  "documents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    content: text("content").notNull(),
    sourceUrl: text("source_url").notNull(),
    // Vector column for 1536-dimensional embeddings
    embedding: vector("embedding", { dimensions: 1536 }).notNull(),
  },
  (table) => {
    // 3. HNSW Definition for cosine similarity
    // m: number of bi-directional links per node (higher = better recall, more memory)
    // ef_construction: candidate list size during build (higher = better quality, slower build)
    return {
      embeddingIdx: index("embedding_hnsw_idx").using(
        "hnsw",
        table.embedding.op("vector_cosine_ops")
      ), // Conceptual SQL: USING hnsw (embedding vector_cosine_ops) WITH (m=16, ef_construction=64)
    };
  }
);

// 4. The Bridge Function
export async function insertDocument(rawInput: unknown) {
  // Validate untrusted input before hitting the database
  const parsed = DocumentInputSchema.safeParse(rawInput);
  if (!parsed.success) {
    // Log issues and abort; saves a DB round-trip
    console.error("Validation failed:", parsed.error.issues);
    return;
  }
  // Map parsed.data to Drizzle insert (conceptual execution)
  // await db.insert(documents).values(parsed.data);
}
