/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

import { z } from "zod";
import { pgTable, text, uuid } from "drizzle-orm/pg-core";
import { vector } from "drizzle-orm/pg-vector";

// TODO: 1. Define Zod Schema for input validation
// export const DocumentInputSchema = z.object({ ... });

// TODO: 2. Define Drizzle Table with pgvector and HNSW
// export const documents = pgTable("documents", {
//   id: uuid("id").defaultRandom().primaryKey(),
//   content: text("content").notNull(),
//   sourceUrl: text("source_url").notNull(),
//   embedding: vector("embedding", { dimensions: 1536 }).notNull()
//   // TODO: Add HNSW index configuration here (e.g., using index or custom SQL)
// });

// TODO: 3. Stub the bridge function
// export async function insertDocument(rawInput: unknown) {
//   const parsed = DocumentInputSchema.safeParse(rawInput);
//   if (!parsed.success) {
//     // Handle Zod error, do not hit DB
//     return;
//   }
//   // TODO: Map parsed.data to drizzle insert
// }
