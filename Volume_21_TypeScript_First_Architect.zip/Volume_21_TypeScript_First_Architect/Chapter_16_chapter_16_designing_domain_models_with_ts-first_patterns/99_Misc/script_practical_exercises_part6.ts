/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part6.ts
// Description: Practical Exercises
// ==========================================

import { z } from "zod";

// Flaw 1 hides here:
const UserIdSchema = z.string(); 
type UserId = z.infer<typeof UserIdSchema>; 

const AdminIdSchema = z.string();
type AdminId = z.infer<typeof AdminIdSchema>;

// Discriminated Union for Actions
const ActionSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("GRANT"), userId: UserIdSchema, adminId: AdminIdSchema }),
  z.object({ type: z.literal("REVOKE"), userId: UserIdSchema })
]);

type Action = z.infer<typeof ActionSchema>;

function processAction(action: Action): string {
  switch (action.type) {
    case "GRANT":
      // Flaw 2 hides here:
      return `Granting user ${action.userId} by admin ${action.adminId}`;
    case "REVOKE":
      return `Revoking user ${action.userId}`;
    // Notice the missing default case
  }
}

// The following should be impossible but is currently allowed:
const fakeAdmin: AdminId = "user-string-123" as UserId; 
