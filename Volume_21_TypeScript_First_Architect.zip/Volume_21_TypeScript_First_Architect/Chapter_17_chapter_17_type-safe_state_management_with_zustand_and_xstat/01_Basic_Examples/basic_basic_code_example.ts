/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { create } from 'zustand';
import { createMachine, createActor, assign } from 'xstate';
import { z } from 'zod';

/**
 * @description Zod schema defining the runtime shape of our SaaS billing details.
 * This acts as the single source of truth for both runtime validation and static typing.
 */
const BillingSchema = z.object({
  plan: z.enum(['free', 'pro', 'enterprise']),
  seats: z.number().int().positive(),
  isActive: z.boolean(),
});

// Infer the TypeScript type directly from the Zod schema.
// This eliminates the "two sources of truth" anti-pattern where interfaces drift from validators.
type BillingState = z.infer<typeof BillingSchema>;

/**
 * @interface ProvisioningContext
 * @description The canonical data structure (context) passed between XState nodes during execution.
 */
interface ProvisioningContext {
  billing: BillingState | null;
  error: string | null;
}

/**
 * @typedef {Object} ProvisioningEvent
 * @description Discriminated union of events that can be sent to the machine.
 * TypeScript will enforce that we only send valid events with correct payloads.
 */
type ProvisioningEvent = 
  | { type: 'START_PROVISIONING'; payload: BillingState }
  | { type: 'PROVISION_SUCCESS' }
  | { type: 'PROVISION_FAILURE'; error: string };

// 1. Define the XState Machine for the provisioning workflow
const provisioningMachine = createMachine({
  id: 'saasProvisioning',
  // The initial state is 'idle' before any user interaction occurs
  initial: 'idle',
  // We cast the initial context to satisfy the ProvisioningContext interface
  context: { billing: null, error: null } as ProvisioningContext,
  states: {
    // State: idle (Waiting for user to click "Upgrade")
    idle: {
      on: {
        START_PROVISIONING: {
          target: 'validating',
          // Assign the payload from the event into the machine's context
          actions: assign(({ context, event }) => ({
            ...context,
            billing: event.payload,
          })),
        },
      },
    },
    // State: validating (Asynchronously checking seats and plan validity)
    validating: {
      invoke: {
        id: 'validateBilling',
        // The src function receives the current context and returns a Promise
        src: (context) => new Promise((resolve, reject) => {
          setTimeout(() => {
            if (context.billing?.seats && context.billing.seats > 0) resolve('done');
            else reject(new Error('Invalid seats'));
          }, 100);
        }),
        // If the promise resolves, move to active
        onDone: 'active',
        // If the promise rejects, move to failed and capture the error
        onError: {
          target: 'failed',
          actions: assign(({ context, event }) => ({
            ...context,
            error: (event.error as Error).message,
          })),
        },
      },
    },
    // State: active (Terminal success state)
    active: { type: 'final' },
    // State: failed (Allows retry)
    failed: {
      on: {
        START_PROVISIONING: 'validating',
      },
    },
  },
});

// 2. Define the Zustand Store for global UI state
interface UIStore {
  isSidebarCollapsed: boolean;
  toggleSidebar: () => void;
  provisioningSnapshot: string;
  setProvisioningSnapshot: (state: string) => void;
}

/**
 * @function useUIStore
 * @description A lightweight Zustand store created via the curried `create` generic.
 */
const useUIStore = create<UIStore>((set) => ({
  isSidebarCollapsed: false,
  // Functional update ensures we never mutate state directly
  toggleSidebar: () => set((state) => ({ isSidebarCollapsed: !state.isSidebarCollapsed })),
  provisioningSnapshot: 'idle',
  setProvisioningSnapshot: (state) => set({ provisioningSnapshot: state }),
}));

// 3. Bridge XState and Zustand
// Create an actor (instance) of the machine and start it immediately
const provisioningActor = createActor(provisioningMachine).start();

// Subscribe to state transitions and push the stringified state value into Zustand
provisioningActor.subscribe((state) => {
  useUIStore.getState().setProvisioningSnapshot(state.value.toString());
});

// Example usage demonstrating type-safety and runtime execution
const validBilling: BillingState = { plan: 'pro', seats: 5, isActive: false };
provisioningActor.send({ type: 'START_PROVISIONING', payload: validBilling });
