/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file Advanced SaaS Feature: Type-Safe AI Sentiment Analysis
 * @description Demonstrates integration of Zustand, XState, Zod, and Transformers.js
 * using TypeScript Generics for a robust client-side state management architecture.
 */
import React, { useEffect } from 'react';
import { create } from 'zustand';
import { createMachine, interpret, assign } from 'xstate';
import { z } from 'zod';
import { pipeline, type Pipeline } from '@xenova/transformers';

/**
 * @constant SentimentSchema
 * @description Zod schema for runtime validation of ML model output.
 * Acts as the single source of truth for the shape of data returned by the inference task.
 */
const SentimentSchema = z.object({
  label: z.string(),
  score: z.number(),
});

// Leveraging TypeScript's type inference to extract a static type from the Zod schema.
type Sentiment = z.infer<typeof SentimentSchema>;

/**
 * @interface StoreState
 * @description Generic Zustand store interface utilizing TypeScript Generics (<T>).
 * This allows the store to be strictly typed for any payload shape while maintaining
 * a consistent status and error lifecycle across the application.
 */
interface StoreState<T> {
  status: 'idle' | 'processing' | 'success' | 'error';
  payload: T | null;
  error: string | null;
  setStore: (partial: Partial<StoreState<T>>) => void;
}

// Initialize Zustand store with explicit generic type parameter (Sentiment).
const useSentimentStore = create<StoreState<Sentiment>>((set) => ({
  status: 'idle',
  payload: null,
  error: null,
  setStore: (partial) => set(partial),
}));

/**
 * @constant inferenceMachine
 * @description XState machine modeling the explicit lifecycle of Transformers.js inference.
 * Separates the concerns of model loading, readiness, and active analysis into discrete states.
 */
const inferenceMachine = createMachine({
  id: 'transformerInference',
  initial: 'idle',
  context: { model: null as Pipeline | null, result: null as Sentiment | null },
  states: {
    idle: { 
      on: { START: 'loading' } 
    },
    loading: {
      invoke: {
        id: 'loadModel',
        // Async service leveraging the Event Loop to fetch and instantiate the WASM/ONNX model
        src: async () => await pipeline('sentiment-analysis'),
        onDone: { 
          target: 'ready', 
          actions: assign({ model: (_, e) => e.data }) 
        },
        onError: 'failure',
      },
    },
    ready: { 
      on: { ANALYZE: 'analyzing' } 
    },
    analyzing: {
      invoke: {
        id: 'runInference',
        src: async (context, event: any) => {
          // Non-blocking inference call yielding to the Event Loop
          const output = await context.model!(event.text);
          // Runtime validation enforcing state shape integrity via Zod
          return SentimentSchema.parse(output[0]); 
        },
        onDone: {
          target: 'ready',
          actions: [(context, event) => {
            // Bridge XState outcome to Zustand global store
            useSentimentStore.getState().setStore({ status: 'success', payload: event.data });
          }],
        },
        onError: 'failure',
      },
    },
    failure: { 
      on: { RETRY: 'loading' } 
    },
  },
});

/**
 * @component SentimentAnalyzer
 * @description React/Next.js component utilizing the state machine and store.
 * Provides a reactive UI bound strictly to the type-safe state definitions.
 */
export const SentimentAnalyzer: React.FC = () => {
  const { status, payload, error, setStore } = useSentimentStore();
  const [service, setService] = React.useState(() => interpret(inferenceMachine).start());

  useEffect(() => {
    setService((s) => s.start());
    return () => service.stop();
  }, [service]);

  const handleAnalyze = async (text: string) => {
    setStore({ status: 'processing' });
    // Dispatch event to XState; orchestration handles the async lifecycle
    service.send({ type: 'ANALYZE', text });
  };

  return (
    <div>
      <h2>SaaS AI Sentiment Analyzer</h2>
      <button onClick={() => handleAnalyze('This TypeScript-first architecture is robust!')}>
        Analyze Feedback
      </button>
      {status === 'processing' && <p>Processing via Event Loop...</p>}
      {payload && <p>Result: {payload.label} ({(payload.score * 100).toFixed(1)}%)</p>}
      {error && <p>Error: {error}</p>}
    </div>
  );
};
