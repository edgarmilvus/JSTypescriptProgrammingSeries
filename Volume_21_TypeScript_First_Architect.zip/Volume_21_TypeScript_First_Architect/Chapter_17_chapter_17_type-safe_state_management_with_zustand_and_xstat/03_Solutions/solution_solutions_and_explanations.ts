/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { z } from 'zod';

// 1. Define Zod Schema for Session State
export const sessionSchema = z.object({
  user: z.object({
    id: z.string().uuid(),
    email: z.string().email(),
    roles: z.array(z.enum(['admin', 'user', 'editor'])),
  }),
  accessToken: z.string(),
  expiresAt: z.number(), // epoch time
});

// 2. Infer TypeScript Types from Zod (Single Source of Truth)
export type SessionData = z.infer<typeof sessionSchema>;

type LoggedOutState = {
  user: null;
  accessToken: null;
  expiresAt: null;
  roles: [];
};

type AuthState = (SessionData | LoggedOutState) & {
  login: (data: SessionData) => void;
  logout: () => void;
};

const defaultLoggedOut: LoggedOutState = {
  user: null,
  accessToken: null,
  expiresAt: null,
  roles: [],
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      ...defaultLoggedOut,
      login: (data) => set(data),
      logout: () => set(defaultLoggedOut),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => localStorage),
      // 3 & 4. Implement Type-Safe Hydration Guard using merge callback
      merge: (persistedState: unknown, currentState: AuthState) => {
        const result = sessionSchema.safeParse(persistedState);
        if (result.success) {
          // TypeScript narrows `result` to { success: true; data: SessionData }
          return { ...currentState, ...result.data };
        } else {
          // Log Zod error and return default "logged out" to prevent mismatch
          console.error('Hydration failed: Invalid auth state', result.error);
          return { ...currentState, ...defaultLoggedOut };
        }
      },
    }
  )
);

// 5. Selector Safety with Type Predicate
export function isAuthenticated(state: AuthState): state is SessionData & AuthState {
  return state.user !== null && state.accessToken !== null;
}

export function useHasRole(role: 'admin' | 'user' | 'editor'): boolean {
  return useAuthStore((state) => {
    if (isAuthenticated(state)) {
      // Type narrowing ensures state.roles is safely accessible and typed
      return state.roles.includes(role);
    }
    return false;
  });
}
