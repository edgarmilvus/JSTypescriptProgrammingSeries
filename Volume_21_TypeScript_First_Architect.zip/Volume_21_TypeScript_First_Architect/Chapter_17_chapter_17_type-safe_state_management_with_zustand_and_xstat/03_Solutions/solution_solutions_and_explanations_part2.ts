/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { setup, assign, createMachine } from 'xstate';

// 1. Define Context and Events with Discriminated Unions
interface CheckoutContext {
  validationToken?: string;
  orderId?: string;
  error?: string;
}

type CheckoutEvents =
  | { type: 'SUBMIT' }
  | { type: 'VALIDATION_SUCCESS'; token: string }
  | { type: 'VALIDATION_FAILURE'; error: string }
  | { type: 'PROCESS_SUCCESS'; orderId: string }
  | { type: 'PROCESS_FAILURE'; error: string };

// 5. Under the hood: `setup` creates a nominal linkage. By passing `types: { context, events }`,
// XState maps specific event types to specific state nodes, preventing invalid transitions at compile time.
export const checkoutMachine = setup({
  types: {
    context: {} as CheckoutContext,
    events: {} as CheckoutEvents,
  },
  actors: {
    // Mock actor invoking a promise
    validatePayment: async () => ({ token: 'mock-token-123' }),
    processOrder: async ({ context }: { context: CheckoutContext }) => {
      if (!context.validationToken) throw new Error('No token');
      return { orderId: 'order-abc' };
    },
  },
  guards: {
    // 3. Guard demonstrating context narrowing
    hasValidToken: ({ context }) => {
      // If we checked context.validationToken, TS narrows from `string | undefined` to `string`
      return context.validationToken !== undefined && context.validationToken.length > 0;
    },
  },
}).createMachine({
  id: 'checkout',
  initial: 'idle',
  context: {},
  states: {
    idle: {
      on: { SUBMIT: 'validatingPayment' },
    },
    validatingPayment: {
      // 2. Invoke promise actor; onDone narrows event to output type
      invoke: {
        src: 'validatePayment',
        onDone: {
          target: 'processingOrder',
          actions: assign({
            validationToken: ({ event }) => event.output.token,
          }),
        },
        onError: {
          target: 'failed',
          actions: assign({
            error: ({ event }) => (event.error as Error).message,
          }),
        },
      },
    },
    processingOrder: {
      invoke: {
        src: 'processOrder',
        onDone: {
          target: 'completed',
          actions: assign({
            orderId: ({ event }) => event.output.orderId,
          }),
        },
        onError: {
          target: 'failed',
          actions: assign({
            error: ({ event }) => (event.error as Error).message,
          }),
        },
      },
    },
    completed: { type: 'final' },
    failed: {
      // Explicit failure state handles errors safely
    },
  },
});
