/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

"use client";
import React from 'react';
import { create } from 'zustand';
import { z } from 'zod';
import { setup, assign, createMachine } from 'xstate';

// 1. Server-to-Client Boundary Zod Validation
const wizardFormSchema = z.object({
  firstName: z.string(),
  lastName: z.string(),
  company: z.string(),
  theme: z.enum(['light', 'dark']),
});
type WizardFormData = z.infer<typeof wizardFormSchema>;

const step1Schema = z.object({ firstName: z.string().min(1), lastName: z.string().min(1) });

// 2. Zustand Store Integration with Generic Constraint
type WizardDataState = WizardFormData & {
  updateField: <K extends keyof WizardFormData>(key: K, value: WizardFormData[K]) => void;
};

const useWizardData = create<WizardDataState>((set) => ({
  firstName: '', lastName: '', company: '', theme: 'light',
  updateField: (key, value) => set((state) => ({ ...state, [key]: value })),
}));

// 3. XState Navigation Machine
const wizardMachine = setup({
  types: {
    context: {} as { data: WizardFormData },
    events: {} as { type: 'NEXT'; data: WizardFormData } | { type: 'PREV' } | { type: 'SUBMIT' },
  },
  guards: {
    // 4. Zod Validation Guard with narrowing
    isStep1Valid: ({ event }) => {
      // event is narrowed to { type: 'NEXT'; data: WizardFormData }
      const result = step1Schema.safeParse(event.data);
      if (!result.success) {
        // result is narrowed to { success: false; error: ZodError }
        console.error(result.error.format());
        return false;
      }
      return true; // result narrowed to { success: true; data: ... }
    },
  },
}).createMachine({
  id: 'wizard',
  initial: 'step1',
  context: ({ input }: { input: { data: WizardFormData } }) => ({ data: input.data }),
  states: {
    step1: { on: { NEXT: { target: 'step2', guard: 'isStep1Valid' } } },
    step2: { on: { NEXT: 'step3', PREV: 'step1' } },
    step3: { on: { SUBMIT: 'submitted', PREV: 'step2' } },
    submitted: { type: 'final' },
  },
});

// 5. Rendering and Type Safety
export function OnboardingWizard({ initialData }: { initialData: unknown }) {
  // safeParse at top level for hydration stability
  const parsed = wizardFormSchema.safeParse(initialData);
  const fallbackData: WizardFormData = parsed.success 
    ? parsed.data 
    : { firstName: '', lastName: '', company: '', theme: 'light' };
  
  // In a real app: const [state, send] = useMachine(wizardMachine, { input: { data: fallbackData } });
  const [state, send] = [{ value: 'step1' }, (e: any) => {}] as any; // Mock for brevity
  
  const currentData = useWizardData((s) => s); // Zustand selector
  
  return (
    <div>
      {state.matches('step1') && (
        <input onChange={(e) => useWizardData.getState().updateField('firstName', e.target.value)} />
      )}
      {state.matches('step1') && (
        <button onClick={() => send({ type: 'NEXT', data: currentData })}>Next</button>
      )}
      {/* XState's typed `send` prevents dispatching NEXT while in `submitted` state */}
    </div>
  );
}
