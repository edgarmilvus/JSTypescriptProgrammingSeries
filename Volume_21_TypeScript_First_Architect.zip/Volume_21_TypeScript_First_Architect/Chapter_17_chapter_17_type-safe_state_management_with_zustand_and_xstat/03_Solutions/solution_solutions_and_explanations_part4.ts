/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { create } from 'zustand';
import { setup, createMachine, assign } from 'xstate';

// 2. Design the Zod Schema for API response
export const productSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  price: z.number().positive(),
});
export type Product = z.infer<typeof productSchema>;

export const cartResponseSchema = z.array(productSchema);

// 4. Zustand Strict Typing - Generic constraints eliminate `any`
type CartState = {
  items: Product[];
  addItem: (item: Product) => void; // Eliminates `item: any`
  updateItem: <K extends keyof Product>(id: string, key: K, value: Product[K]) => void;
};

export const useCartStore = create<CartState>((set) => ({
  items: [],
  addItem: (item) => set((s) => ({ items: [...s.items, item] })),
  updateItem: (id, key, value) => set((s) => ({ 
    items: s.items.map(i => i.id === id ? { ...i, [key]: value } : i) 
  })),
}));

// 3. XState Refactor Plan - Explicit states replacing `status: string`
export const cartMachine = setup({
  types: {
    context: {} as { items: Product[]; error?: string },
    events: {} as { type: 'FETCH' } | { type: 'RESOLVE'; items: Product[] } | { type: 'REJECT'; error: string },
  },
}).createMachine({
  initial: 'idle',
  states: {
    idle: { on: { FETCH: 'loading' } },
    loading: {
      invoke: {
        src: async () => {
          const res = await fetch('/api/cart');
          const data = await res.json();
          // safeParse narrows success/failure branches
          const parsed = cartResponseSchema.safeParse(data);
          if (!parsed.success) throw new Error('Invalid cart shape');
          return parsed.data; // Strictly Product[]
        },
        onDone: { target: 'ready', actions: assign({ items: ({ event }) => event.output }) },
        onError: { target: 'error', actions: assign({ error: ({ event }) => (event.error as Error).message }) },
      },
    },
    ready: { /* `error` context is inaccessible here via narrowing */ },
    error: { /* `error` context is strictly available */ },
  },
});
