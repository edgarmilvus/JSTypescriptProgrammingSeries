/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { Effect, Exit } from 'effect';
import { setup, createMachine, assign } from 'xstate';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

// 1. Define pgvector/Drizzle/Zod Contract
export const documentSchema = z.object({
  id: z.string(),
  content: z.string(),
  embedding: z.array(z.number()).length(1536), // Matches pgvector dimension
});
export type Document = z.infer<typeof documentSchema>;

// Conceptual Drizzle schema:
// import { pgTable, vector, text } from 'drizzle-orm/pg-core';
// export const documentsTable = pgTable('documents', { id: text('id'), content: text('content'), embedding: vector('embedding', { dimensions: 1536 }) });

// 2. Effect Workflow Definition
const searchDocuments = (queryVector: number[]) => {
  return Effect.gen(function* (_) {
    const rows = yield* _(
      Effect.try({
        try: async () => {
          // const result = await db.select().from(documentsTable).orderBy(sql`embedding <=> ${queryVector}`);
          return [] as unknown[]; // Mock DB response
        },
        catch: () => new Error('DB Query Failed'),
      })
    );
    // Zod validates and narrows the result
    const parsed = documentSchema.array().safeParse(rows);
    if (!parsed.success) return yield* _(Effect.fail(new Error('Validation Failed')));
    return parsed.data; // Document[]
  });
};

// 3. XState Machine Integration
export const semanticSearchMachine = setup({
  types: {
    context: {} as { documents?: Document[]; error?: string },
    events: {} as { type: 'SEARCH'; vector: number[] } | { type: 'RESOLVE'; documents: Document[] } | { type: 'REJECT'; error: string },
  },
}).createMachine({
  initial: 'inputting',
  states: {
    inputting: { on: { SEARCH: 'searching' } },
    searching: {
      invoke: {
        src: ({ event }) => 
          Effect.runPromiseExit(searchDocuments(event.vector)).then((exit) => {
            if (Exit.isSuccess(exit)) return { type: 'RESOLVE', documents: exit.value };
            return { type: 'REJECT', error: String(exit.cause) };
          }),
        onDone: { target: 'results', actions: assign({ documents: ({ event }) => event.output.documents }) },
        onError: { target: 'noResults', actions: assign({ error: ({ event }) => (event.error as Error).message }) },
      },
    },
    results: { 
      // 4. Type narrowing: state.context.documents is Document[] here
    },
    noResults: {},
  },
});

// 5. Resilience and Hydration with Zustand
export const useSearchStore = create(
  persist(() => ({ lastResults: [] as Document[] }), { name: 'search-cache', storage: createJSONStorage(() => localStorage) })
);

// In a React component, defer hydration to useEffect to avoid RSC mismatch:
// useEffect(() => { useSearchStore.persist.rehydrate(); }, []);
