/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Greeting Service - Basic Testing Example
 * Demonstrates Vitest + Effect/Test patterns for TS-First codebases.
 */

// Import testing primitives from Vitest
import { describe, it, expect } from "vitest";
// Import core Effect primitives for functional programming and DI
import { Effect, Context, Layer } from "effect";
// Import Effect/Test utilities to showcase the testing ecosystem
import { TestContext } from "effect/test";

/**
 * 1. DOMAIN MODEL
 * Defines the shape of a SaaS user. The `subscriptionTier` uses a union type,
 * which is essential for Type Narrowing later in the control flow.
 */
interface SaaSUser {
  readonly id: string;
  readonly name: string;
  readonly subscriptionTier: "Free" | "Pro" | "Enterprise";
}

/**
 * 2. SERVICE CONTRACT
 * An interface describing the operations our business logic needs.
 * It returns an `Effect` which might fail with an `Error` or succeed with `SaaSUser`.
 */
interface UserRepository {
  readonly findById: (id: string) => Effect.Effect<SaaSUser, Error>;
}

/**
 * 3. DEPENDENCY INJECTION TAG
 * Creates a type-safe, compile-time identifier for our service.
 * This leverages TypeScript's structural typing and phantom types.
 */
const UserRepositoryTag = Context.Tag<UserRepository>("UserRepository")<
  UserRepository
>();

/**
 * 4. BUSINESS LOGIC
 * Uses `Effect.gen` to compose asynchronous operations in a sequential, readable style.
 * Type Inference automatically deduces the success and error channels here.
 * 
 * @param userId - The unique identifier of the user
 * @returns An Effect that resolves to a welcome string
 */
const generateWelcomeMessage = (userId: string) =>
  Effect.gen(function* (ctx) {
    // Yield the injected repository (Type Inference identifies its type)
    const repo = yield* ctx(UserRepositoryTag);
    // Yield the user lookup (Type Inference assigns `SaaSUser` to `user`)
    const user = yield* repo.findById(userId);
    
    // Type Narrowing is implicitly safe here because `subscriptionTier` is a literal union
    return `Welcome ${user.name} to the ${user.subscriptionTier} tier!`;
  });

/**
 * 5. MOCK LAYER FOR TESTING
 * We construct a test double using `Layer.succeed`. This satisfies the
 * `UserRepositoryTag` dependency without touching a real database.
 */
const MockUserRepositoryLayer = Layer.succeed(UserRepositoryTag, {
  findById: (id: string) =>
    Effect.succeed({
      id,
      name: "Ada Lovelace",
      subscriptionTier: "Pro" as const, // `as const` ensures literal type narrowing
    }),
});

/**
 * 6. TEST SUITE
 * Utilizing Vitest's BDD-style API combined with Effect's runtime.
 */
describe("SaaS Greeting Service", () => {
  it("should generate a correct welcome message for a Pro user", async () => {
    // Construct the program and inject the mock layer
    const program = generateWelcomeMessage("user-001").pipe(
      Effect.provide(MockUserRepositoryLayer)
    );

    // Execute the Effect within a Promise boundary for Vitest
    const result = await Effect.runPromise(program);

    // Type-safe assertion provided by Vitest
    expect(result).toEqual("Welcome Ada Lovelace to the Pro tier!");
  });
});
