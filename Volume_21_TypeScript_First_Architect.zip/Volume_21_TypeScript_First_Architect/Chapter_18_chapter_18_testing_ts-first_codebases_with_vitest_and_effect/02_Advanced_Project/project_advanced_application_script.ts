/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Application Script for testing a TS-First SaaS AI Agent.
 * Demonstrates Vitest + Effect/Test patterns for Dependency Injection and Zod validation.
 * Focuses on the Entry Point Node, Thought-Action-Observation triple, and Optimistic UI Reconciliation.
 */
import { describe, it, expect } from 'vitest';
import { Effect, Context, Layer, Data } from 'effect';
import { z } from 'zod';
import { NextRequest, NextResponse } from 'next/server';

// 1. Zod Schema defining the Observation atomic unit of the ReAct framework.
// This acts as the runtime guardian for our Optimistic UI Reconciliation.
const ObservationSchema = z.object({
  userId: z.string().min(1),
  reconciled: z.boolean(),
  data: z.record(z.string(), z.unknown())
});
type Observation = z.infer<typeof ObservationSchema>;

// 2. Typed error for Reconciliation (Optimistic UI) failures.
// Using Effect's Data.TaggedError for pattern-matching in the test layer.
class ReconciliationError extends Data.TaggedError('ReconciliationError')<{ reason: string }> {}

/**
 * The LLM Client interface representing the external AI service.
 * Used for Dependency Injection via Effect Context, allowing us to swap
 * real API calls with mocks during testing.
 */
interface LLMClient {
  readonly invokeEntryPoint: (thought: string) => Effect.Effect<unknown, Error>;
}
const LLMClient = Context.Tag<LLMClient>('LLMClient');

/**
 * Agent Orchestrator service handling the LangGraph Entry Point Node
 * and Optimistic UI Reconciliation via the Thought-Action-Observation cycle.
 */
const AgentOrchestrator = {
  /**
   * Executes the initial Thought-Action-Observation cycle.
   * @param initialThought The user's starting reasoning prompt (The "Thought").
   */
  runWorkflow: (initialThought: string): Effect.Effect<Observation, ReconciliationError | Error, LLMClient> =>
    Effect.gen(function* (_) {
      // Acquire the injected LLM client dependency
      const client = yield* _(LLMClient);
      
      // Action: Call LLM to generate initial Observation (The "Action")
      const rawObs = yield* _(client.invokeEntryPoint(initialThought));
      
      // Reconciliation: Validate the optimistically rendered state (The "Observation")
      const parsed = ObservationSchema.safeParse(rawObs);
      if (!parsed.success) {
        // Fail declaratively if the LLM returned malformed data
        return yield* _(Effect.fail(new ReconciliationError({ reason: 'Schema mismatch in Observation' })));
      }
      
      // Mark as reconciled once Zod confirms the shape matches client expectations
      return { ...parsed.data, reconciled: true };
    })
};

// 3. Simulating a background computation service for Optimistic UI resolution.
interface BackgroundJob {
  readonly computeFinalState: (obs: Observation) => Effect.Effect<Observation, Error>;
}
const BackgroundJob = Context.Tag<BackgroundJob>('BackgroundJob');

// 4. Live implementation of the background job for production context.
const backgroundJobLive = BackgroundJob.of({
  computeFinalState: (obs) => Effect.succeed({ ...obs, data: { ...obs.data, computed: true } })
});

// 5. Next.js Route Handler acting as the application's HTTP Entry Point.
export async function POST(req: NextRequest) {
  const { thought } = await req.json();
  // Compose the full workflow by providing the mock layer (in prod, use Live layers)
  const program = AgentOrchestrator.runWorkflow(thought).pipe(Effect.provide(MockLLMLayer));
  const result = await Effect.runPromise(program);
  return NextResponse.json(result);
}

// 6. Mock Layer for deterministic Effect/Test execution.
// We simulate the LLM returning an unreconciled observation.
const mockLLMClient = LLMClient.of({
  invokeEntryPoint: (thought: string) =>
    Effect.succeed({ userId: 'usr_123', reconciled: false, data: { thought, action: 'process' } })
});
const MockLLMLayer = Layer.succeed(LLMClient, mockLLMClient);

// 7. Extended workflow incorporating background reconciliation for a full SaaS transaction.
const runFullWorkflow = (thought: string) =>
  Effect.gen(function* (_) {
    const initial = yield* _(AgentOrchestrator.runWorkflow(thought));
    const job = yield* _(BackgroundJob);
    return yield* _(job.computeFinalState(initial));
  }).pipe(
    Effect.provide(MockLLMLayer),
    Effect.provide(Layer.succeed(BackgroundJob, backgroundJobLive))
  );

// 8. Vitest Test Suite utilizing Effect/Test paradigms (Dependency Injection & Type-Safety).
describe('SaaS Agent Orchestrator', () => {
  it('should reconcile the Observation triple correctly via Entry Point', async () => {
    // Arrange & Act: Run the effect with the mock layer
    const program = AgentOrchestrator.runWorkflow('Start').pipe(Effect.provide(MockLLMLayer));
    const result = await Effect.runPromise(program);
    
    // Assert: Type-safe check confirming Optimistic UI Reconciliation succeeded
    expect(result.reconciled).toBe(true);
    expect(result.userId).toBe('usr_123');
  });

  it('should throw ReconciliationError on invalid LLM payload (Malformed Observation)', async () => {
    // Arrange: Mock a bad response that violates the Zod schema
    const badMock = LLMClient.of({ invokeEntryPoint: () => Effect.succeed({ bad: true }) });
    const BadLayer = Layer.succeed(LLMClient, badMock);
    
    // Act & Assert: Ensure the Effect fails gracefully and is caught by Vitest
    const program = AgentOrchestrator.runWorkflow('Fail').pipe(Effect.provide(BadLayer));
    await expect(Effect.runPromise(program)).rejects.toThrow();
  });

  it('should process through background job after entry point node', async () => {
    // Act: Execute the extended full workflow
    const result = await Effect.runPromise(runFullWorkflow('Deep thought'));
    
    // Assert: Verify the background computation augmented the Observation
    expect(result.data.computed).toBe(true);
    expect(result.reconciled).toBe(true);
  });
});
