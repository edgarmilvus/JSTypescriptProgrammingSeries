/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Context, Layer, Exit, Cause } from "effect";
import { it, expect, describe } from "vitest";

// Domain error types
export class SmsGatewayError {
  readonly _tag = "SmsGatewayError";
  constructor(readonly message: string) {}
}

// Service interface
export interface NotificationService {
  readonly send: (to: string, body: string) => Effect.Effect<void, SmsGatewayError>;
}

// Context Tag
export class NotificationServiceTag extends Context.Tag("NotificationService")<
  NotificationServiceTag,
  NotificationService
>() {}

// The program under test
export const notifyUser = (to: string, msg: string) =>
  Effect.gen(function* () {
    const service = yield* NotificationServiceTag;
    return yield* service.send(to, msg);
  });

// Layer-based mocking is superior to global vi.mock() because it provides dependency injection
// scoped to the Effect runtime, eliminating hidden global state and enabling safe concurrent
// test execution without cross-test pollution or ordering dependencies.
export const makeTestNotificationService = (shouldFail: boolean): Layer.Layer<NotificationServiceTag> => {
  const testService: NotificationService = {
    send: (to, body) =>
      shouldFail
        ? Effect.fail(new SmsGatewayError("Simulated gateway timeout"))
        : Effect.succeed(undefined),
  };
  return Layer.succeed(NotificationServiceTag, testService);
};

describe("NotificationService with Effect Layers", () => {
  it("succeeds when the mock returns success", async () => {
    const successLayer = makeTestNotificationService(false);
    const exit = await Effect.runPromiseExit(Effect.provide(notifyUser("+123", "Hi"), successLayer));
    expect(Exit.isSuccess(exit)).toBe(true);
  });

  it("fails with SmsGatewayError when the mock throws", async () => {
    const failLayer = makeTestNotificationService(true);
    const exit = await Effect.runPromiseExit(Effect.provide(notifyUser("+123", "Hi"), failLayer));
    expect(Exit.isFailure(exit)).toBe(true);
    if (Exit.isFailure(exit)) {
      const maybeError = Cause.find(exit.cause, (e): e is SmsGatewayError => e instanceof SmsGatewayError);
      expect(maybeError).toBeInstanceOf(SmsGatewayError);
    }
  });
});
