/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { Effect, Exit } from "effect";
import { it, expect, describe, expectTypeOf } from "vitest";

export const UserSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  age: z.number().int().positive(),
  email: z.string().email(),
});

export type ValidUser = z.infer<typeof UserSchema>;

export class ValidationError {
  readonly _tag = "ValidationError";
  constructor(readonly cause: z.ZodError) {}
}

// The function under test
export const parseUserEffect = (input: unknown): Effect.Effect<ValidUser, ValidationError> =>
  Effect.try({
    try: () => UserSchema.parse(input),
    catch: (e) => new ValidationError(e as z.ZodError),
  });

describe("parseUserEffect", () => {
  it("parses valid user", async () => {
    const validUser = { id: "123e4567-e89b-12d3-a456-426614174000", name: "Alice", age: 30, email: "alice@example.com" };
    const result = await Effect.runPromise(parseUserEffect(validUser));
    expect(result).toEqual(validUser);
  });

  it("fails on invalid age", async () => {
    const invalidUser = { id: "123e4567-e89b-12d3-a456-426614174000", name: "Bob", age: "old", email: "bob@example.com" };
    // Flip the effect to bring the error into the success channel for easy assertion
    const flipped = Effect.flip(parseUserEffect(invalidUser));
    const error = await Effect.runPromise(flipped);
    
    expect(error).toBeInstanceOf(ValidationError);
    expect(error.cause).toBeInstanceOf(z.ZodError);
    expect(error.cause.issues).toContainEqual(expect.objectContaining({ path: ["age"] }));
  });

  it("type checks", () => {
    // Ensure the Effect's success type perfectly matches the Zod inference
    expectTypeOf(parseUserEffect).returns.toMatchTypeOf<Effect.Effect<ValidUser, ValidationError>>();
    expectTypeOf<ValidUser>().toEqualTypeOf<z.infer<typeof UserSchema>>();
  });
});
