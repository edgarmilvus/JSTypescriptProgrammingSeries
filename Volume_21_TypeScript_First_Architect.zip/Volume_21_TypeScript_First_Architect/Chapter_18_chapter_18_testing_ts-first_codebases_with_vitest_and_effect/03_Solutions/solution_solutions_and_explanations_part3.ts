/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { drizzle, BetterSQLite3Database } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { Effect, Context, Layer } from "effect";
import { it, expect, describe } from "vitest";
import { z } from "zod";

const UserSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  age: z.number().int().positive(),
  email: z.string().email(),
});

export const usersTable = sqliteTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  email: text("email").notNull(),
});

export interface DatabaseService {
  readonly db: BetterSQLite3Database<Record<string, never>>;
}
export class DatabaseTag extends Context.Tag("Database")<DatabaseTag, DatabaseService>() {}

export const getUserById = (id: string) =>
  Effect.gen(function* () {
    const { db } = yield* DatabaseTag;
    // Wrap the Drizzle promise in Effect.tryPromise for exhaustive async resilience
    return yield* Effect.tryPromise({
      try: async () => {
        const result = await db.query.usersTable.findFirst({ where: (u, { eq }) => eq(u.id, id) });
        return result;
      },
      catch: (e) => new Error(`DB Error: ${String(e)}`),
    });
  });

// TestDatabaseLayer using Layer.scoped to guarantee cleanup (acquireRelease under the hood)
export const TestDatabaseLayer = Layer.scoped(
  DatabaseTag,
  Effect.gen(function* () {
    const sqlite = new Database(":memory:");
    const db = drizzle(sqlite);
    sqlite.exec("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, age INTEGER NOT NULL, email TEXT NOT NULL);");
    
    // Exhaustive Asynchronous Resilience: finalizer ensures connection close even on test failure
    yield* Effect.addFinalizer(() => Effect.sync(() => sqlite.close()));
    return { db };
  })
);

describe("getUserById with Drizzle", () => {
  it("inserts and retrieves a valid user", async () => {
    const program = Effect.gen(function* () {
      const { db } = yield* DatabaseTag;
      const testUser = { id: "123e4567-e89b-12d3-a456-426614174000", name: "Test", age: 25, email: "test@example.com" };
      yield* Effect.tryPromise(() => db.insert(usersTable).values(testUser).execute());
      return yield* getUserById(testUser.id);
    });

    const result = await Effect.runPromise(Effect.provide(program, TestDatabaseLayer));
    expect(result).toMatchObject({ name: "Test", age: 25 });
    expect(UserSchema.safeParse(result).success).toBe(true);
  });
});
