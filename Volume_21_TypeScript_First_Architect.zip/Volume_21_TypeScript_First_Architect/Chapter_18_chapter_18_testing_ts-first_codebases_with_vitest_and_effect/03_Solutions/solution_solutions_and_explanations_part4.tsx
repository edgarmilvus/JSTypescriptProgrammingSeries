/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from "react";
import { Effect, Layer, Context } from "effect";
import { it, expect, describe } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { DatabaseTag, getUserById } from "./exercise3"; // Conceptual import

// Mock ML Inference Service
export interface InferenceService {
  readonly runHeadlessInference: (text: string) => Effect.Effect<string, Error>;
}
export class InferenceTag extends Context.Tag("Inference")<InferenceTag, InferenceService>() {}

// ML Session mock with explicit close for resource cleanup
class MLSession {
  summarize(text: string): Promise<string> { return Promise.resolve(`Summary: ${text}`); }
  close(): void { console.log("ML session closed"); }
}

// Construct Inference Layer with acquireRelease for Exhaustive Asynchronous Resilience
export const makeInferenceLayer = (shouldFail: boolean) =>
  Layer.scoped(
    InferenceTag,
    Effect.acquireRelease(
      Effect.sync(() => new MLSession()),
      (session) => Effect.sync(() => session.close()) // finally equivalent
    )
  ).pipe(
    Layer.map((session) => ({
      runHeadlessInference: (text: string) =>
        shouldFail ? Effect.fail(new Error("ML Model crashed")) : Effect.tryPromise(() => session.summarize(text)),
    }))
  );

// Headless Inference logic
const runHeadlessInference = (userId: string) =>
  Effect.gen(function* () {
    const user = yield* getUserById(userId);
    const inference = yield* InferenceTag;
    return yield* inference.runHeadlessInference(`Profile: ${user.name}`);
  });

// The Server Component (RSC) with graceful degradation
export async function AIProfileSummary({ 
  userId, 
  dbLayer, 
  infLayer 
}: { 
  userId: string; 
  dbLayer: Layer.Layer<DatabaseTag>; 
  infLayer: Layer.Layer<InferenceTag>;
}) {
  const program = runHeadlessInference(userId).pipe(Effect.provide(infLayer), Effect.provide(dbLayer));
  try {
    const summary = await Effect.runPromise(program);
    return <div data-testid="summary">{summary}</div>;
  } catch (e) {
    // Graceful degradation to default message if ML or DB fails
    return <div data-testid="fallback">Default profile message</div>;
  }
}

// Vitest Test verifying both success and fallback
describe("AIProfileSummary RSC", () => {
  it("renders summary on success (mocked DB + Inference)", async () => {
    const mockDb = Layer.succeed(DatabaseTag, { db: { query: { usersTable: { findFirst: async () => ({ id: "1", name: "Alice", age: 30, email: "a@b.c" }) } } } } as any);
    const html = renderToStaticMarkup(<AIProfileSummary userId="1" dbLayer={mockDb} infLayer={makeInferenceLayer(false)} />);
    expect(html).toContain("Summary");
  });

  it("renders fallback on ML failure", async () => {
    const mockDb = Layer.succeed(DatabaseTag, { db: { query: { usersTable: { findFirst: async () => ({ id: "1", name: "Alice", age: 30, email: "a@b.c" }) } } } } as any);
    const html = renderToStaticMarkup(<AIProfileSummary userId="1" dbLayer={mockDb} infLayer={makeInferenceLayer(true)} />);
    expect(html).toContain("Default profile message");
  });
});
