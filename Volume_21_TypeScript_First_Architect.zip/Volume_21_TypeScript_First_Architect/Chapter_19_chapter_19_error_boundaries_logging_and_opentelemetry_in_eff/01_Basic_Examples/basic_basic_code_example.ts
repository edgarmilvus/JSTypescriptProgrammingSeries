/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Subscription Service - Basic Effect Example
 * Demonstrates Error Boundaries (Typed Errors), Structured Logging, and OpenTelemetry Tracing
 * @module SaaSSubscriptionEffect
 */
import { Effect, Console, Log, Data, Cause } from "effect";

/**
 * Strictly typed domain error representing a missing or failed subscription lookup.
 * Utilizes Effect's `Data.TaggedError` to enforce Strict Type Discipline (no implicit any,
 * explicit discriminant unions) and to integrate seamlessly with `strictNullChecks`.
 */
export class SubscriptionNotFoundError extends Data.TaggedError("SubscriptionNotFoundError")<{
  readonly tenantId: string;
  readonly reason: string;
}> {}

/**
 * Defines the shape of our SaaS domain model for a Subscription.
 * Under Strict Type Discipline, all properties are required and explicitly typed.
 */
interface Subscription {
  readonly id: string;
  readonly tenantId: string;
  readonly plan: "free" | "pro" | "enterprise";
  readonly active: boolean;
}

/**
 * Simulates a database fetch (e.g., using Drizzle ORM against a Postgres instance).
 * Returns a Promise that resolves to `Subscription | null` to simulate a missing record.
 * @param tenantId - The unique identifier for the SaaS tenant
 */
const mockDbFetch = (tenantId: string): Promise<Subscription | null> => {
  // Simulate a database miss to demonstrate error boundaries
  return Promise.resolve(null);
};

/**
 * The core Effect program. It fetches a subscription, logs the attempt,
 * and wraps the async call in a typed error boundary.
 * @param tenantId - The tenant identifier
 * @returns An Effect that yields a Subscription or fails with SubscriptionNotFoundError
 */
const fetchSubscription = (tenantId: string) =>
  Effect.gen(function* () {
    // 1. Structured Logging: Emits a log with contextual information
    yield* Log.info(`Attempting to fetch subscription for tenant: ${tenantId}`);

    // 2. Error Boundary via tryPromise: Converts untyped Promise rejections into typed failures
    const result = yield* Effect.tryPromise({
      try: () => mockDbFetch(tenantId),
      catch: (e) =>
        new SubscriptionNotFoundError({
          tenantId,
          reason: `Database query failed: ${String(e)}`,
        }),
    });

    // 3. Strict Null Check Handling: enforced by strictNullChecks in tsconfig
    if (result === null) {
      return yield* Effect.fail(
        new SubscriptionNotFoundError({
          tenantId,
          reason: "Subscription record does not exist in the system",
        })
      );
    }

    // 4. Success Logging
    yield* Log.info(`Successfully retrieved subscription for ${tenantId}`);
    return result;
  }).pipe(
    // 5. OpenTelemetry Tracing: Attaches a span to the Effect for distributed tracing
    Effect.withSpan("SaaS.fetchSubscription", { attributes: { tenantId } })
  );

/**
 * The main execution program. Simulates a Next.js Route Handler or Server Action
 * that recovers from the typed error boundary to provide a fallback state.
 */
const program = Effect.gen(function* () {
  const sub = yield* fetchSubscription("tenant_123").pipe(
    // Typed Error Boundary Recovery: Catches only the specific tagged error
    Effect.catchTag("SubscriptionNotFoundError", (err) =>
      Effect.gen(function* () {
        yield* Log.error(`Handled domain error: ${err.reason}`);
        // Return a safe default fallback state for the SaaS UI
        return { id: "default", tenantId: err.tenantId, plan: "free", active: false } as const;
      })
    )
  );

  // Final output to console (simulating a JSON response to the client)
  yield* Console.log(`Final Subscription State: ${JSON.stringify(sub)}`);
});

/**
 * Bootstrap the Effect runtime. In a real Next.js app, this would be wrapped
 * in a Route Handler's `GET` method or a Server Action.
 */
Effect.runPromise(program).catch((e) => {
  // Fallback catch for any unexpected defects (not domain errors)
  Console.error(`Unrecoverable defect: ${Cause.pretty(e as Cause.Cause<never>)}`);
});
