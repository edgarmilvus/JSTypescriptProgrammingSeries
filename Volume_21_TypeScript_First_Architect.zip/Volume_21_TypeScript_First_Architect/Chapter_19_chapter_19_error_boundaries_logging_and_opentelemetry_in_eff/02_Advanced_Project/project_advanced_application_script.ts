/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @module BillingResilience
 * @description Advanced SaaS billing pipeline demonstrating Effect error boundaries,
 * structured logging, OpenTelemetry tracing, and strict TypeScript resilience patterns.
 */
import { Effect, pipe } from "effect";
import { NextResponse } from "next/server";
import { z } from "zod";

// Strict Type Discipline: Explicit interfaces, enforcing strictNullChecks.
interface BillingConfig {
  readonly apiEndpoint: string;
  readonly timeoutMs: number;
}

// Strict Type Discipline: Literal unions prevent invalid state assignments.
interface SubscriptionState {
  readonly userId: string;
  readonly plan: "free" | "pro" | "enterprise";
  readonly isActive: boolean;
}

// Immutable State Management: Pure function returning a new reference via spread.
const transitionSubscriptionState = (
  current: SubscriptionState,
  updates: Partial<Omit<SubscriptionState, "userId">>
): SubscriptionState => ({ ...current, ...updates });

// Zod schema for runtime validation (Strict Type Discipline at I/O boundaries)
const UserIdSchema = z.object({ userId: z.string().uuid() });

/**
 * Exhaustive Asynchronous Resilience:
 * Raw async wrapped in try/catch/finally to guarantee cleanup and graceful degradation.
 */
async function safeFetchSubscription(
  config: BillingConfig,
  userId: string
): Promise<SubscriptionState> {
  let connection: { id: string } | null = null;
  try {
    // Acquire resource (simulated)
    connection = { id: `conn_${Math.random().toString(36).slice(2)}` };
    // Simulated external API call (may fail randomly)
    if (Math.random() > 0.7) throw new Error("Upstream API Unreachable");
    return { userId, plan: "pro", isActive: true };
  } catch (error) {
    // Graceful degradation and error logging
    console.error("Resilience: Degrading gracefully", error);
    return { userId, plan: "free", isActive: false };
  } finally {
    // Guaranteed resource cleanup regardless of success/failure (finally pattern)
    if (connection) console.log(`Resilience: Releasing ${connection.id}`);
  }
}

/**
 * Effect Program: Typed Error Boundaries & Structured Logging.
 * Bridges raw resilience into Effect's typed ecosystem.
 */
const billingPipeline = (userId: string, config: BillingConfig) =>
  pipe(
    Effect.succeed(userId),
    // OpenTelemetry Simulation: Structured logging acts as span start
    Effect.tap((id) => Effect.logInfo(`[OTel] Starting span for user ${id}`)),
    // Bridge Promise with Effect (Typed Error Boundary)
    Effect.mapEffect((id) => Effect.promise(() => safeFetchSubscription(config, id))),
    // Immutable State transition applied within the Effect context
    Effect.map((state) => transitionSubscriptionState(state, { isActive: true })),
    // Structured Logging of committed state
    Effect.tap((state) => Effect.logInfo("State committed immutably", state)),
    // Typed Error Boundary: Catch all failures and recover safely with fallback
    Effect.catchAll((e) =>
      Effect.gen(function* () {
        yield* Effect.logError("Boundary caught failure", e);
        return { userId, plan: "free", isActive: false } as SubscriptionState;
      })
    )
  );

// Next.js API Route Handler
export async function POST(request: Request) {
  const config: BillingConfig = { apiEndpoint: "/api/v1", timeoutMs: 3000 };
  const body = await request.json();
  // Validate input with Zod at the boundary
  const parsed = UserIdSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid UUID" }, { status: 400 });
  
  // Execute the Effect pipeline and await the Promise resolution
  const result = await Effect.runPromise(billingPipeline(parsed.data.userId, config));
  return NextResponse.json(result);
}
