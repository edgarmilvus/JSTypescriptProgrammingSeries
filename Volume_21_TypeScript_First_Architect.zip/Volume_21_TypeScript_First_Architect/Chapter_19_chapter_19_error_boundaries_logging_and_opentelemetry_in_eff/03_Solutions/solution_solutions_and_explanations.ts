/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Data, Effect, Schedule, Either } from "effect"

// Requirement 1: Define Tagged Errors with strict payloads
class NetworkError extends Data.TaggedError("NetworkError")<{ url: string; statusCode: number }> {}
class ParseError extends Data.TaggedError("ParseError")<{ body: string }> {}
class ValidationError extends Data.TaggedError("ValidationError")<{ issues: string[] }> {}

// Mock implementations to satisfy strict typing without full runtime logic
const fetchNetwork = Effect.succeed("{}")
const parseAndValidate = (_body: string) => Effect.succeed({} as unknown)

// Requirement 2: Define the pipeline signature explicitly declaring the error channel
const fetchAndProcess: Effect.Effect<
  unknown, 
  NetworkError | ParseError | ValidationError, 
  never
> = Effect.gen(function* () {
  const body = yield* fetchNetwork
  return yield* parseAndValidate(body)
})

// Requirement 3 & 4: Define the resilient wrapper
const resilientPipeline: Effect.Effect<
  Either.Either<unknown, ParseError | ValidationError>, 
  never, 
  never
> = fetchAndProcess.pipe(
  // Intercept NetworkError via retry policy (type-guarded) with bounded exponential backoff (5 attempts)
  Effect.retry({
    schedule: Schedule.exponential("100 millis").pipe(Schedule.intersect(Schedule.recurs(4))),
    while: (e): e is NetworkError => e._tag === "NetworkError"
  }),
  // Extract remaining errors (ParseError | ValidationError) safely into an Either
  Effect.either
)
