/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, FiberRef, Logger } from "effect"
import { randomUUID } from "crypto"

// Requirement 1: Define FiberRef for correlationId and userId
const correlationIdRef = FiberRef.unsafeMake<string>("unknown-correlation-id")
const userIdRef = FiberRef.unsafeMake<string>("anonymous")

// Requirement 2 & 3: Build the forking logic with structured logs
const mockTask = (taskName: string) => 
  Effect.gen(function* () {
    // Business logic does NOT take correlationId as a parameter
    yield* Effect.logInfo("Chunk processed", { task: taskName, status: "complete" })
  })

const processUpload = Effect.gen(function* () {
  const id = randomUUID()
  // Set FiberRef locally; child fibers inherit this immutable context
  return yield* Effect.locally(correlationIdRef, id)(
    Effect.gen(function* () {
      yield* Effect.logInfo("Upload initiated", { stage: "entry" })
      
      // Fork three child fibers concurrently
      yield* Effect.fork(mockTask("chunk-1"))
      yield* Effect.fork(mockTask("chunk-2"))
      yield* Effect.fork(mockTask("chunk-3"))
      
      yield* Effect.sleep("50 millis") // Allow forks to execute in demo
    })
  )
})

// Requirement 4 & 5: Logger setup conceptualization
// In development, we use pretty-printed logs:
const devLogger = Logger.pretty
// In production, we swap to structured JSON for ELK/Datadog ingestion:
// const prodLogger = Logger.json
