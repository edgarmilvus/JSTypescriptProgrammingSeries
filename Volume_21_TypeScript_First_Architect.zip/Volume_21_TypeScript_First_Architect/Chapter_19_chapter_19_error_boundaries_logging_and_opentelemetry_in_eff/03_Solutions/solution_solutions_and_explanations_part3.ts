/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect } from "effect"
import { NodeSdk } from "@effect/opentelemetry"
import { ConsoleSpanExporter } from "@opentelemetry/sdk-trace-base"
import { BatchSpanProcessor } from "@opentelemetry/sdk-trace-node"

// Requirement 1: Setup SDK Layer with Console exporter for local debugging
const OtelSdk = NodeSdk.layer(() => ({ 
  resource: { serviceName: "gateway" }, 
  spanProcessors: [new BatchSpanProcessor(new ConsoleSpanExporter())] 
}))

// Mock child services with their own spans and attributes
const authenticateUser = Effect.trackSpan("AuthService").pipe(
  Effect.annotateSpans("user.tier", "gold")
)
const processBilling = Effect.trackSpan("BillingService").pipe(
  Effect.annotateSpans("billing.amount", 99.99)
)

// Requirement 2 & 3: Instrument the gateway pipeline
const gatewayLogic = Effect.gen(function* () {
  yield* authenticateUser
  yield* processBilling
}).pipe(
  Effect.trackSpan("GatewayRequest"), // Root span
  Effect.provide(OtelSdk) // Provide the OTel SDK layer
)

// Effect.runPromise(gatewayLogic)
