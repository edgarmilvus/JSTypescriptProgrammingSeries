/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Data, Schedule, FiberRef } from "effect"

class InventoryTimeoutError extends Data.TaggedError("InventoryTimeoutError")<{ itemId: string }> {}
class PaymentDeclinedError extends Data.TaggedError("PaymentDeclinedError")<{ reason: string }> {}
class CartValidationError extends Data.TaggedError("CartValidationError")<{ cartId: string }> {}

declare const validateCart: Effect.Effect<void, CartValidationError, never>
declare const reserveInventory: Effect.Effect<void, InventoryTimeoutError, never>
declare const chargeCard: Effect.Effect<void, PaymentDeclinedError, never>
declare const sendReceipt: Effect.Effect<void, never, never>

// Requirement 1 & 2: FiberRef for orderId context propagation
const orderIdRef = FiberRef.unsafeMake<string>("unknown-order")

// Requirements 3, 4, 5: Type-annotated insertion for checkoutFlow
const checkoutFlow: Effect.Effect<void, CartValidationError | PaymentDeclinedError, never> = 
  Effect.gen(function* () {
    yield* validateCart
    
    // INTERACTIVE INSERTION: Retry reserveInventory on InventoryTimeoutError (max 2 retries)
    yield* reserveInventory.pipe(
      Effect.retry(Schedule.recurs(2)) // Bounded retry, excludes error from channel post-success
    )
    
    // INTERACTIVE INSERTION: Log before charging
    yield* Effect.logInfo("Initiating card charge", { action: "charge" })
    yield* chargeCard // If fails, PaymentDeclinedError surfaces (modeled separately)
    
    yield* sendReceipt
  }).pipe(
    // Attach orderId to all logs immutably via FiberRef/local context
    Effect.locally(orderIdRef, "order-123"),
    Effect.annotateLogs("orderId", "order-123")
  )
