/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { Suspense, Component, useState, useEffect } from "react"
import { Effect, Stream, Data } from "effect"
import { z } from "zod"

// Requirement 3: Define Typed Error
class ModelOverloadError extends Data.TaggedError("ModelOverloadError")<{ retryAfter: number }> {}

// Requirement 5: Zod Schema for strict initial dataset fetch
const DatasetSchema = z.object({ id: z.string(), content: z.string() })
type Dataset = z.infer<typeof DatasetSchema>

// The Effect that streams AI tokens
declare const summarizeEffect: Effect.Effect<Stream.Stream<string, ModelOverloadError>, never, never>

function LoadingSkeleton() {
  return <div className="spinner">Loading stream...</div>
}

// Requirement 1 & 4: React Component with immutable state accumulation
function AIStreamSummary() {
  const [tokens, setTokens] = useState<string[]>([])
  
  useEffect(() => {
    const program = summarizeEffect.pipe(
      Effect.flatMap((stream) => 
        Stream.runForEach(stream, (chunk) => 
          // Immutable concatenation: creates new array copy rather than mutating buffer
          Effect.sync(() => setTokens((prev) => [...prev, chunk]))
        )
      )
    )
    Effect.runPromise(program).catch(() => {})
  }, [])
  
  return <div>{tokens.join("")}</div>
}

// Requirement 1 & 3: Error Boundary catching serialized Effect errors
export class ErrorBoundary extends Component<
  { fallback: React.ReactNode; children: React.ReactNode }, 
  { hasError: boolean }
> {
  state = { hasError: false }
  
  static getDerivedStateFromError() {
    return { hasError: true }
  }
  
  componentDidCatch(error: unknown) {
    // Narrow the unknown error to our tagged domain error
    if (error instanceof ModelOverloadError) {
      this.setState({ hasError: true })
    }
  }
  
  render() { 
    return this.state.hasError ? this.props.fallback : this.props.children 
  }
}

export function DashboardWidget() {
  return (
    <ErrorBoundary fallback={<button onClick={() => location.reload()}>Retry</button>}>
      <Suspense fallback={<LoadingSkeleton />}>
        <AIStreamSummary />
      </Suspense>
    </ErrorBoundary>
  )
}
