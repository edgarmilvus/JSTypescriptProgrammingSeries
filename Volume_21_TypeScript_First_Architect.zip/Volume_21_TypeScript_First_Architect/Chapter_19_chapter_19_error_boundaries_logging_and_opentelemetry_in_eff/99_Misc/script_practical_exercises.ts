/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { Data, Effect, Schedule, Either } from "effect"

// Requirement 1: Define Tagged Errors here
// class NetworkError extends Data.TaggedError("NetworkError")<{ url: string; statusCode: number }> {}
// class ParseError extends Data.TaggedError("ParseError")<{ body: string }> {}
// class ValidationError extends Data.TaggedError("ValidationError")<{ issues: string[] }> {}

// Requirement 2: Define the pipeline signature
// const fetchAndProcess: Effect.Effect<unknown, NetworkError | ParseError | ValidationError, never> = 
//   Effect.gen(function* () {
//     // TODO: Implement fetch, parse, and validate
//     return yield* Effect.succeed({})
//   })

// Requirement 3 & 4: Define the resilient wrapper
// const resilientPipeline: Effect.Effect<
//   Either.Either<unknown, ParseError | ValidationError>, 
//   never, 
//   never
// > = 
//   fetchAndProcess.pipe(
//     // TODO: Apply catchTag and retry, then convert to Either
//   )
