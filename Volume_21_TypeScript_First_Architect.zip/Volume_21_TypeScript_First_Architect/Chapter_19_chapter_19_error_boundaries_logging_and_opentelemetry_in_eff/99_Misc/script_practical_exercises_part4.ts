/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import { Effect, Data, Schedule, FiberRef } from "effect"

class InventoryTimeoutError extends Data.TaggedError("InventoryTimeoutError")<{ itemId: string }> {}
class PaymentDeclinedError extends Data.TaggedError("PaymentDeclinedError")<{ reason: string }> {}
class CartValidationError extends Data.TaggedError("CartValidationError")<{ cartId: string }> {}

declare const validateCart: Effect.Effect<void, CartValidationError, never>
declare const reserveInventory: Effect.Effect<void, InventoryTimeoutError, never>
declare const chargeCard: Effect.Effect<void, PaymentDeclinedError, never>
declare const sendReceipt: Effect.Effect<void, never, never>

const checkoutFlow = Effect.gen(function* () {
  yield* validateCart
  
  // TODO INTERACTIVE: Add retry logic for reserveInventory here
  
  yield* chargeCard // TODO INTERACTIVE: Add logging before this
  yield* sendReceipt
})
