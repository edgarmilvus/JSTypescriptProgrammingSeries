/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A self-contained "Hello World" level example of a Financial Ledger SaaS API.
 * Demonstrates Zod (validation), Drizzle (ORM typing), and Effect (orchestration) 
 * within a Server-Sent Events (SSE) Web App context.
 */

// Import Zod for schema definition and runtime parsing.
import { z } from 'zod';
// Import Effect and its primitives for functional error handling and dependency injection.
import { Effect, Context, Layer, Console, Data } from 'effect';
// Import Drizzle ORM core utilities for defining the database schema.
import { pgTable, serial, varchar, integer, timestamp } from 'drizzle-orm/pg-core';

/**
 * @const LedgerLegSchema
 * @description Defines the strict shape of a single leg in a double-entry transaction using Zod.
 * We utilize integer cents to avoid IEEE-754 floating-point precision errors inherent in JavaScript.
 */
const LedgerLegSchema = z.object({
  accountId: z.string().uuid(),
  amountInCents: z.number().int().positive(),
  entryType: z.enum(['DEBIT', 'CREDIT']),
});

/**
 * @const TransactionSchema
 * @description The aggregate transaction schema. It requires at least two legs and uses 
 * Zod's `.refine` method to enforce the fundamental double-entry accounting constraint: 
 * total debits must exactly equal total credits.
 */
const TransactionSchema = z.object({
  transactionId: z.string().uuid(),
  legs: z.array(LedgerLegSchema).min(2),
  description: z.string().min(1),
}).refine(
  (tx) => {
    const debits = tx.legs.filter(l => l.entryType === 'DEBIT').reduce((s, l) => s + l.amountInCents, 0);
    const credits = tx.legs.filter(l => l.entryType === 'CREDIT').reduce((s, l) => s + l.amountInCents, 0);
    return debits === credits;
  },
  { message: "Double-entry constraint violated: Debits must equal Credits" }
);

/**
 * @const ledgerEntries
 * @description The Drizzle ORM representation of our Postgres table.
 * Drizzle allows us to define the schema in TypeScript, which simultaneously acts as a 
 * migration definition and a source of truth for our query types.
 */
const ledgerEntries = pgTable('ledger_entries', {
  id: serial('id').primaryKey(),
  transactionId: varchar('transaction_id', { length: 36 }).notNull(),
  accountId: varchar('account_id', { length: 36 }).notNull(),
  amountInCents: integer('amount_in_cents').notNull(),
  entryType: varchar('entry_type', { length: 6 }).notNull(),
  description: varchar('description', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

/**
 * @class LedgerError
 * @extends Data.TaggedError
 * @description A domain-specific, typed error. By extending `Data.TaggedError`, we create 
 * an error that carries a `_tag` property, enabling exhaustive pattern matching later.
 */
class LedgerError extends Data.TaggedError('LedgerError')<{ message: string }> {}

/**
 * @class DbService
 * @extends Context.Tag
 * @description Effect's Dependency Injection mechanism. We define a "tag" representing a 
 * service that can save ledger legs to the database.
 */
class DbService extends Context.Tag('DbService')<
  DbService,
  { saveLegs: (legs: z.infer<typeof LedgerLegSchema>[], txId: string, desc: string) => Effect.Effect<void, LedgerError> }
>() {}

/**
 * @const DbServiceLive
 * @description The concrete implementation (Layer) of our DbService. In this Hello World 
 * example, we mock the database insertion using `Effect.sync` and a console log.
 */
const DbServiceLive = Layer.succeed(DbService, DbService.of({
  saveLegs: (legs, txId, desc) => 
    Effect.sync(() => {
      Console.log(`[MOCK DB] Persisting ${legs.length} legs for TX: ${txId}`);
    })
}));

/**
 * @function processTransaction
 * @description The core business logic, orchestrated via `Effect.gen`. This creates a 
 * declarative description of our workflow rather than executing it immediately.
 * @param rawPayload - The unknown JSON payload arriving from the SaaS client.
 */
const processTransaction = (rawPayload: unknown) =>
  Effect.gen(function* (_) {
    // Step 1: Validate the raw payload against our Zod schema.
    yield* Console.log("Step 1: Validating payload with Zod...");
    const parsed = TransactionSchema.safeParse(rawPayload);
    if (!parsed.success) {
      return yield* Effect.fail(new LedgerError({ message: parsed.error.message }));
    }

    // Step 2: Resolve the DbService dependency and persist the data.
    yield* Console.log("Step 2: Injecting DbService and saving...");
    const db = yield* DbService;
    yield* db.saveLegs(parsed.data.legs, parsed.data.transactionId, parsed.data.description);

    // Step 3: Return a success log.
    return yield* Console.log("Step 3: Transaction committed successfully.");
  });

/**
 * @function POST
 * @description A Web Standard API Route Handler (e.g., Next.js App Router) that accepts 
 * a transaction and streams the processing status back to the client using SSE.
 */
export async function POST(request: Request): Promise<Response> {
  // Extract the raw JSON from the incoming request.
  const rawPayload = await request.json();

  // Instantiate a ReadableStream to facilitate Server-Sent Events (SSE).
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder();
      
      // Execute the Effect workflow, providing the live database layer.
      Effect.runPromise(
        processTransaction(rawPayload).pipe(Effect.provide(DbServiceLive))
      ).then(() => {
        // On success, push a compliant SSE message and close the stream.
        controller.enqueue(encoder.encode(`data: {"status": "completed"}\n\n`));
        controller.close();
      }).catch((e) => {
        // On failure, push an error SSE message and close the stream.
        controller.enqueue(encoder.encode(`data: {"status": "error", "message": "${e.message}"}\n\n`));
        controller.close();
      });
    }
  });

  // Return the stream with the appropriate SSE headers.
  return new Response(stream, {
    headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' },
  });
}
