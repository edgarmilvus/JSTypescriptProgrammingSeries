/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { Effect, Context, Layer, Exit, Console } from 'effect';
import { drizzle } from 'drizzle-orm/node-postgres';
import { pgTable, serial, text, numeric, vector, cosineDistance, sql, gt } from 'drizzle-orm/pg-core';
import OpenAI from 'openai';

/**
 * Zod Schema defining the strict double-entry structure for LLM JSON Schema Output.
 * This acts as the single source of truth for both runtime validation and TypeScript types.
 */
const LedgerEntrySchema = z.object({
  description: z.string(), // The natural language description of the transaction
  debitAccount: z.enum(["Cash", "AccountsReceivable", "Expense"]), // Restricted to valid chart of accounts
  creditAccount: z.enum(["Revenue", "AccountsPayable", "Equity"]), // Restricted to valid chart of accounts
  amount: z.number().positive(), // Ensures accounting entries have a positive magnitude
  currency: z.string().length(3) // ISO 4217 currency code
});
type LedgerEntry = z.infer<typeof LedgerEntrySchema>;

// Drizzle Schema utilizing pgvector for HNSW indexing (defined in migrations)
const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  embedding: vector('embedding', { dimensions: 1536 }), // 1536-dim vector for OpenAI embeddings
  rawText: text('raw_text').notNull(),
  debit: text('debit').notNull(),
  credit: text('credit').notNull(),
  amount: numeric('amount').notNull()
});

/**
 * Effect Service Tag for LLM Interactions.
 * Abstracts the LLM provider to allow mock implementations during testing.
 */
interface LLMService {
  readonly extract: (raw: string) => Effect.Effect<LedgerEntry, Error>;
}
const LLMService = Context.Tag<LLMService>();

/**
 * Effect Service Tag for Database Interactions.
 * Abstracts Drizzle queries to facilitate dependency injection.
 */
interface DbService {
  readonly findSimilar: (vec: number[]) => Effect.Effect<Array<typeof transactions.$inferSelect>, Error>;
}
const DbService = Context.Tag<DbService>();

/**
 * The Core Orchestration Workflow using Effect.
 * Sequentially processes the financial event with typed errors and DI.
 */
const processFinancialEvent = (rawText: string) => Effect.gen(function* (_) {
  yield* _(Console.log("[Workflow] Invoking LLM with JSON Schema constraints..."));
  const llm = yield* _(LLMService); // Dependency injection via Context
  const entry = yield* _(llm.extract(rawText)); // Zod validation happens inside service

  yield* _(Console.log("[Workflow] Querying pgvector HNSW index for similar ledgers..."));
  const db = yield* _(DbService);
  const mockEmbedding = Array(1536).fill(0.1); // Mock embedding generation for the new entry
  const similarTx = yield* _(db.findSimilar(mockEmbedding));

  yield* _(Console.log("[Workflow] Enforcing double-entry accounting invariants..."));
  // Invariant: Amounts must be positive to represent valid ledger postings
  if (entry.amount <= 0) return yield* _(Effect.fail(new Error("Amount must be positive")));

  return { entry, similarCount: similarTx.length };
});

// Next.js Route Handler implementing Server-Sent Events (SSE)
export async function POST(req: NextRequest) {
  const { rawText } = await req.json();
  const encoder = new TextEncoder();

  // Create a ReadableStream to push SSE events to the client
  const stream = new ReadableStream({
    async start(controller) {
      // Helper to format and enqueue SSE messages
      const sseSend = (event: string, data: unknown) => 
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));

      // Live Layer implementation for LLM using OpenAI JSON Schema Output
      const OpenAILayer = Layer.succeed(LLMService, {
        extract: (text) => Effect.tryPromise({
          try: async () => {
            const openai = new OpenAI();
            // Instruct LLM to output strict JSON adhering to our Zod schema structure
            const completion = await openai.chat.completions.create({
              model: "gpt-4o",
              response_format: { type: "json_schema", json_schema: { name: "ledger", schema: LedgerEntrySchema } },
              messages: [{ role: "user", content: text }]
            });
            // Parse and validate the LLM response with Zod
            return LedgerEntrySchema.parse(JSON.parse(completion.choices[0].message.content!));
          },
          catch: (e) => new Error(`LLM Failed: ${e}`)
        })
      });

      // Live Layer implementation for Database using Drizzle and pgvector HNSW
      const DrizzleLayer = Layer.succeed(DbService, {
        findSimilar: (vec) => Effect.tryPromise({
          try: async () => {
            const db = drizzle(process.env.DATABASE_URL!);
            // Compute cosine distance using pgvector operator
            const distance = sql`${cosineDistance(transactions.embedding, vec)}`;
            // Query top 5 similar transactions using HNSW index
            return await db.select().from(transactions).where(gt(distance, 0.5)).orderBy(distance).limit(5);
          },
          catch: (e) => new Error(`DB Failed: ${e}`)
        })
      });

      sseSend("status", { phase: "start" });
      // Compose the program and provide dependencies
      const program = processFinancialEvent(rawText).pipe(
        Effect.provide(OpenAILayer),
        Effect.provide(DrizzleLayer)
      );

      // Execute the Effect program and handle the Exit type
      const exit = await Effect.runPromiseExit(program);
      if (Exit.isSuccess(exit)) {
        sseSend("result", exit.value);
      } else {
        sseSend("error", { message: String(exit.cause) });
      }
      controller.close();
    }
  });

  // Return the stream with appropriate SSE headers
  return new NextResponse(stream, { headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' } });
}
