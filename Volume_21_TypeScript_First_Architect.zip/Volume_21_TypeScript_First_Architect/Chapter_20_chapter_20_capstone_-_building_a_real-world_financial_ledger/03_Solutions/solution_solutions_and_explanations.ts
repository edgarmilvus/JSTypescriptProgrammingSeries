/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { pgTable, serial, varchar, numeric, integer, boolean, relations } from 'drizzle-orm/pg-core';
import { z } from 'zod';

// 2. Branded Types Implementation
declare const brand: unique symbol;
type Brand<T, TBrand extends string> = T & { readonly [brand]: TBrand };

export type AccountId = Brand<number, 'AccountId'>;
export type JournalEntryId = Brand<number, 'JournalEntryId'>;
export type PostingId = Brand<number, 'PostingId'>;

// Helper transforms to cast primitives to Branded Types
const asAccountId = (id: number) => id as AccountId;
const asJournalEntryId = (id: number) => id as JournalEntryId;
const asPostingId = (id: number) => id as PostingId;

// 1. Drizzle Schema Definition
export const accounts = pgTable('accounts', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  balance: numeric('balance', { precision: 18, scale: 4 }).notNull().default('0'),
});

export const journalEntries = pgTable('journal_entries', {
  id: serial('id').primaryKey(),
  description: varchar('description', { length: 500 }).notNull(),
});

export const postings = pgTable('postings', {
  id: serial('id').primaryKey(),
  journalEntryId: integer('journal_entry_id').notNull().references(() => journalEntries.id),
  accountId: integer('account_id').notNull().references(() => accounts.id),
  isDebit: boolean('is_debit').notNull(),
  amount: numeric('amount', { precision: 18, scale: 4 }).notNull(),
});

// 4. Relational Integrity: Using Drizzle's `relations` API to define one-to-many links
export const accountsRelations = relations(accounts, ({ many }) => ({
  postings: many(postings),
}));

export const journalEntriesRelations = relations(journalEntries, ({ many }) => ({
  postings: many(postings),
}));

export const postingsRelations = relations(postings, ({ one }) => ({
  account: one(accounts, { fields: [postings.accountId], references: [accounts.id] }),
  journalEntry: one(journalEntries, { fields: [postings.journalEntryId], references: [journalEntries.id] }),
}));

// 3. Zod Validation Layer
export const AccountSchema = z.object({
  id: z.number().transform(asAccountId),
  name: z.string().max(255),
  balance: z.string(), // numeric returns as string from DB to preserve precision
});
export type Account = z.infer<typeof AccountSchema>;

export const JournalEntrySchema = z.object({
  id: z.number().transform(asJournalEntryId),
  description: z.string().max(500),
});
export type JournalEntry = z.infer<typeof JournalEntrySchema>;

export const PostingSchema = z.object({
  id: z.number().transform(asPostingId),
  journalEntryId: z.number().transform(asJournalEntryId),
  accountId: z.number().transform(asAccountId),
  isDebit: z.boolean(),
  amount: z.string(),
});
export type Posting = z.infer<typeof PostingSchema>;
