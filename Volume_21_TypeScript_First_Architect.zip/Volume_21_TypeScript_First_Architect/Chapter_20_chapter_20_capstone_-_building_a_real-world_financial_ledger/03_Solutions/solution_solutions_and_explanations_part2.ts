/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Effect, Context, Data, Layer } from 'effect';
import { db } from './db'; // Pseudo-import for Drizzle database instance
import { journalEntries, postings, type JournalEntry, type Posting } from './exercise1';

// 2. Custom Typed Errors
export class UnbalancedEntryError extends Data.TaggedError('UnbalancedEntryError')<{ message: string }> {}
export class AccountFrozenError extends Data.TaggedError('AccountFrozenError')<{ accountId: number }> {}
export class PersistenceError extends Data.TaggedError('PersistenceError')<{ cause: unknown }> {}

// 1. Define the Service Interface via Context.Tag
export interface LedgerRepository {
  saveEntry: (entry: JournalEntry, postingsList: Posting[]) => Effect.Effect<void, PersistenceError>;
}
export const LedgerRepository = Context.Tag<LedgerRepository>();

// 3. The Workflow Implementation
export const postJournalEntry = (entry: JournalEntry, postingsList: Posting[]) => 
  Effect.gen(function* (_) {
    // (a) Validate balance mathematically
    const totalDebits = postingsList.filter(p => p.isDebit).reduce((acc, p) => acc + Number(p.amount), 0);
    const totalCredits = postingsList.filter(p => !p.isDebit).reduce((acc, p) => acc + Number(p.amount), 0);
    
    if (totalDebits !== totalCredits) {
      return yield* _(Effect.fail(new UnbalancedEntryError({ message: 'Sum of debits must equal sum of credits' })));
    }

    // (b) Inject repository and check account statuses (simulated)
    const repo = yield* _(LedgerRepository);
    
    // (c) Perform atomic insert via Effect.tryPromise wrapping Drizzle's transaction
    yield* _(Effect.tryPromise({
      try: () => db.transaction(async (tx) => {
        await tx.insert(journalEntries).values({ id: Number(entry.id), description: entry.description });
        await tx.insert(postings).values(postingsList.map(p => ({ ...p, id: Number(p.id) })));
      }),
      catch: (e) => new PersistenceError({ cause: e })
    }));
  });

// 4. Layer Composition
export const LedgerRepositoryLive = Layer.effect(
  LedgerRepository,
  Effect.succeed({
    saveEntry: (entry, postingsList) => Effect.tryPromise({
      try: () => db.transaction(async (tx) => { /* ...insert logic... */ }),
      catch: (e) => new PersistenceError({ cause: e })
    })
  })
);

// Providing the layer to the workflow
const executedWorkflow = postJournalEntry(/* ... */).pipe(
  Effect.provide(LedgerRepositoryLive)
);
