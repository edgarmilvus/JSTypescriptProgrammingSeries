/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { Effect, Data } from 'effect';

// 1. Zod Schema Definition
export const TransactionCategorizationSchema = z.object({
  category: z.enum(['Software', 'Payroll', 'Revenue', 'Tax']),
  confidenceScore: z.number().min(0).max(1),
  isTaxDeductible: z.boolean(),
});
export type TransactionCategorization = z.infer<typeof TransactionCategorizationSchema>;

// 4. Custom Typed Error for Effect
export class ModelHallucinationError extends Data.TaggedError('ModelHallucinationError')<{ 
  rawOutput: string; 
  zodError?: z.ZodError 
}> {}

// 3. Safe Validation and Effect Integration
export const categorizeTransaction = (rawLLMOutput: string) => 
  Effect.gen(function* (_) {
    // Using safeParse to avoid throwing and to explicitly handle failure
    let parsedOutput: TransactionCategorization;
    try {
      const result = TransactionCategorizationSchema.safeParse(JSON.parse(rawLLMOutput));
      if (!result.success) {
        // Fallback mechanism: Route to human review conceptually
        console.warn('Validation failed. Routing to human review queue.');
        return yield* _(Effect.fail(new ModelHallucinationError({ rawOutput, zodError: result.error })));
      }
      parsedOutput = result.data;
    } catch (e) {
      return yield* _(Effect.fail(new ModelHallucinationError({ rawOutput })));
    }
    
    return parsedOutput;
  });

/*
// 2. JSON Schema Conversion Description:
// We use `zod-to-json-schema` or native Vercel AI SDK features to convert 
// `TransactionCategorizationSchema` to a JSON Schema. We send this to the LLM API.
// `z.enum` is critical because it enables constrained decoding (grammar-constrained sampling),
// restricting the model's logits so it can only generate valid categories, preventing hallucinations.
*/
