/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { db } from './db'; // Pseudo-import
import { accounts, postings } from './exercise1'; // Pseudo-import
import { Effect, Stream } from 'effect';
import { z } from 'zod';

// 1. Drizzle Query Intent (Conceptual)
const getRawLedgerData = async () => {
  // Using the `with` relational API to fetch accounts and their associated postings
  return db.query.accounts.findMany({
    with: { postings: true },
  });
};

// 3. Zod Final Contract
export const TrialBalanceSchema = z.object({
  accountBalances: z.array(z.object({
    accountId: z.number(),
    debitTotal: z.string(),
    creditTotal: z.string(),
  })),
  isBalanced: z.boolean(),
});
export type TrialBalanceReport = z.infer<typeof TrialBalanceSchema>;

// 2. Effect Stream Aggregation
export const generateTrialBalance = (rawData: Awaited<ReturnType<typeof getRawLedgerData>>) => 
  Effect.gen(function* (_) {
    const folded = yield* _(
      Stream.fromIterable(rawData).pipe(
        // Using Stream.runFold to efficiently reduce large datasets
        Stream.runFold({ accountBalances: [] as any[], totalDebits: 0, totalCredits: 0 }, (acc, account) => {
          const debitTotal = account.postings.filter(p => p.isDebit).reduce((s, p) => s + Number(p.amount), 0);
          const creditTotal = account.postings.filter(p => !p.isDebit).reduce((s, p) => s + Number(p.amount), 0);
          return {
            accountBalances: [...acc.accountBalances, { accountId: account.id, debitTotal: String(debitTotal), creditTotal: String(creditTotal) }],
            totalDebits: acc.totalDebits + debitTotal,
            totalCredits: acc.totalCredits + creditTotal,
          };
        })
      )
    );
    
    // Final parse to guarantee shape and infer strict type
    return TrialBalanceSchema.parse({
      accountBalances: folded.accountBalances,
      isBalanced: folded.totalDebits === folded.totalCredits,
    });
  });

// 4. API Route Handler
export async function POST(request: NextRequest) {
  const rawData = await getRawLedgerData();
  const trialBalance: TrialBalanceReport = await Effect.runPromise(generateTrialBalance(rawData));
  
  // Returning a strictly typed JSON response
  return NextResponse.json<TrialBalanceReport>(trialBalance);
}
