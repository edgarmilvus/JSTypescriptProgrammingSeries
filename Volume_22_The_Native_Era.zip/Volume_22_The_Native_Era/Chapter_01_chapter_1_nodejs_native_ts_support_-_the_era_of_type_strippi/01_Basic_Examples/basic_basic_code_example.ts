/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic demonstration of Node.js Native TypeScript Type Stripping.
 * This script simulates a minimal SaaS backend operation: processing a new user signup.
 * It runs directly via `node index.ts` without any build step.
 */

/**
 * @interface Tenant
 * @description Represents a SaaS tenant record.
 * Note: Interfaces are entirely removed during type stripping, leaving zero runtime footprint.
 */
interface Tenant {
  id: string;
  email: string;
  plan: 'free' | 'pro';
}

/**
 * @function provisionTenant
 * @description Acts as a Server Action: securely processes a new tenant on the server.
 * @param {string} userEmail - The email of the user to provision.
 * @returns {Promise<Tenant>} A promise resolving to the created tenant object.
 */
async function provisionTenant(userEmail: string): Promise<Tenant> {
  // 1. Utilize Type Inference: 'newTenant' type is inferred from the object literal
  // The 'plan' property uses literal type inference via 'as const'
  const newTenant = {
    id: crypto.randomUUID(), // Native Web Crypto API available in Node.js
    email: userEmail,
    plan: 'free' as const
  };

  // 2. Asynchronous Tool Handling: External API call wrapped in Promise via fetch (native)
  // The 'await' keyword pauses function execution without blocking the Node.js event loop
  const crmResponse = await fetch('https://api.mock-saas.com/crm/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newTenant)
  });

  // 3. Error handling for the async tool interaction
  if (!crmResponse.ok) {
    throw new Error(`CRM Sync Failed: ${crmResponse.status}`);
  }

  // 4. Return the inferred typed object (types are stripped, plain JS object returned)
  return newTenant;
}

/**
 * @function main
 * @description Orchestrates the SaaS onboarding flow and handles top-level errors.
 */
async function main(): Promise<void> {
  try {
    // Execute the server action
    const tenant = await provisionTenant('developer@saas.app');
    
    // Type inference allows safe, autocompleted property access here
    console.log(`[SaaS Onboarding] Success: ${tenant.email} on ${tenant.plan} plan.`);
  } catch (error) {
    // Defensive logging for production SaaS environments
    console.error('[SaaS Onboarding] Error:', (error as Error).message);
  }
}

// Invoke the async main function to start the process
main();
