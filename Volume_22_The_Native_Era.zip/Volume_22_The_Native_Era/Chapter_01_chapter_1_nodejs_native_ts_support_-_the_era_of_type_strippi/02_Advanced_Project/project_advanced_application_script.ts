/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Native TypeScript SaaS Webhook Ingestion Microservice.
 * Executes directly via Node.js (v22+) type stripping. No transpilers used.
 */

// Import native Node.js ESM modules (HTTP server, File System, Crypto)
import { createServer } from 'node:http';
import { writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
// Import Zod for Runtime Validation (since TS types are stripped at runtime)
import { z } from 'zod';

/**
 * @const {z.ZodObject} WebhookSchema
 * @description Defines the runtime shape of an external SaaS webhook.
 * This is the ONLY boundary enforcement because TS types are erased.
 */
const WebhookSchema = z.object({
  event: z.enum(['user.created', 'user.deleted', 'subscription.updated']),
  payload: z.object({
    userId: z.string().uuid(),
    email: z.string().email(),
    tier: z.union([z.literal('free'), z.literal('pro'), z.literal('enterprise')]),
    metadata: z.record(z.string()).optional(),
  }),
  timestamp: z.number().int().positive(),
});

// Type inference: Exists only at compile-time for IDE support (erased at runtime)
type WebhookEvent = z.infer<typeof WebhookSchema>;

/**
 * @async
 * @function persistAuditLog
 * @description Simulates an I/O-bound background task (writing to disk/DB).
 * Offloaded to the Node.js Event Loop's Task Queue upon invocation.
 * @param {WebhookEvent} data - The validated webhook data
 * @returns {Promise<void>}
 */
async function persistAuditLog(data: WebhookEvent): Promise<void> {
  // Simulate network/DB latency to demonstrate non-blocking Event Loop behavior
  await new Promise((resolve) => setTimeout(resolve, 100));
  
  // Prepare a structured audit log entry
  const logEntry = JSON.stringify({
    id: randomUUID(),
    event: data.event,
    userId: data.payload.userId,
    processedAt: new Date().toISOString(),
  });
  
  // Async file write: Delegated to libuv thread pool, non-blocking to Call Stack
  await writeFile(`./logs/audit-${randomUUID()}.json`, logEntry, 'utf-8');
}

/**
 * @async
 * @function handleIngest
 * @description Core business logic for the SaaS ingestion pipeline.
 * @param {unknown} rawBody - Untrusted raw JSON from the HTTP request
 * @returns {Promise<{ status: number; body: string }>}
 */
async function handleIngest(rawBody: unknown): Promise<{ status: number; body: string }> {
  // 1. Runtime Validation: TS types are gone, Zod protects the app boundary
  const parsed = WebhookSchema.safeParse(rawBody);
  if (!parsed.success) {
    // Return 400 immediately if external data fails structural checks
    return { status: 400, body: JSON.stringify({ error: 'Validation Failed' }) };
  }

  // Data is now guaranteed to match the WebhookEvent shape
  const validatedData = parsed.data;

  // 2. Event Loop Utilization: Fire-and-forget async I/O
  // We intentionally do NOT await here. This pushes the promise to the Microtask
  // Queue, allowing the HTTP response to be sent immediately while I/O processes.
  persistAuditLog(validatedData).catch((err) => {
    console.error('[Event Loop] Background I/O task failed:', err);
  });

  // 3. Immediate Response: Frees the Call Stack for the next request
  return { status: 202, body: JSON.stringify({ message: 'Accepted for processing' }) };
}

/**
 * @const {http.Server} server
 * @description Instantiates a native ESM HTTP server. The Event Loop manages
 * incoming TCP connections and routes them to the Call Stack via callbacks.
 */
const server = createServer(async (req, res) => {
  // Route handling for the webhook endpoint
  if (req.method === 'POST' && req.url === '/api/webhooks') {
    let body = '';
    
    // Stream parsing: Uses Event Loop's I/O observers for incoming network data
    for await (const chunk of req) {
      body += chunk;
    }

    // Parse raw string to JSON safely
    let parsedBody: unknown;
    try {
      parsedBody = JSON.parse(body);
    } catch {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid JSON' }));
      return;
    }

    // Delegate to business logic
    const result = await handleIngest(parsedBody);
    res.writeHead(result.status, { 'Content-Type': 'application/json' });
    res.end(result.body);
  } else {
    // 404 for unmatched routes
    res.writeHead(404);
    res.end('Not Found');
  }
});

// Bind the server to port 3000 and start the Event Loop's polling phase
server.listen(3000, () => {
  console.log('[SaaS Native TS Worker] Listening on port 3000');
});
