/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// user_account.ts

// 1. Eliminate Enums: Using a const object with 'as const' and deriving a union type.
// This is zero-cost at runtime because 'as const' only affects compile-time types, 
// and the object itself is a plain JS object literal that requires no special 
// compiler-generated bidirectional mapping logic like 'enum' does.
const UserRole = {
  Admin: "ADMIN",
  Editor: "EDITOR",
  Viewer: "VIEWER"
} as const;

type UserRoleType = typeof UserRole[keyof typeof UserRole];

// 2. Refactor Parameter Properties: Explicitly declare fields and assign in constructor.
class UserAccount {
  username: string;
  role: UserRoleType;

  constructor(username: string, role: UserRoleType) {
    // Explicit assignment instead of parameter properties (e.g., public username: string)
    this.username = username;
    this.role = role;
  }

  getPermissions(): string[] {
    if (this.role === UserRole.Admin) {
      return ["read", "write", "delete"];
    }
    return ["read"];
  }
}

// 3. Type Inference Utilization: No annotation on 'account' or 'perms', compiler deduces them.
const account = new UserAccount("alice", UserRole.Admin);
const perms = account.getPermissions();
console.log(`${account.username} has permissions: ${perms.join(", ")}`);

// 4. Execution Command (Node.js 22.6+):
// node --experimental-strip-types user_account.ts
// OR if using Bun:
// bun run user_account.ts
