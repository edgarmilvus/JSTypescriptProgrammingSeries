/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// event_loop_demo.ts

// Zero explicit annotations: Relying entirely on Type Inference.
// The compiler infers 'string' for messages, 'Promise<void>' for async functions, etc.

console.log("1. Synchronous Code");

process.nextTick(() => {
  console.log("2. Next-Tick Queue (process.nextTick)");
});

Promise.resolve().then(() => {
  console.log("3. Microtask Queue (Promise.then)");
});

setTimeout(() => {
  console.log("4. Macrotask Queue (setTimeout)");
}, 0);

// Async/Await Integration with native fetch
const runFetch = async () => {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/todos/1");
    console.log(`5. Fetch Status: ${response.status} (Resolved as Microtask)`);
  } catch (error) {
    console.log("Fetch failed", error);
  }
};

// Top-level await (supported natively in ESM .ts)
await runFetch();

console.log("6. Synchronous Code After Await");

// Execution Command:
// node --experimental-strip-types event_loop_demo.ts
// OR
// bun run event_loop_demo.ts
