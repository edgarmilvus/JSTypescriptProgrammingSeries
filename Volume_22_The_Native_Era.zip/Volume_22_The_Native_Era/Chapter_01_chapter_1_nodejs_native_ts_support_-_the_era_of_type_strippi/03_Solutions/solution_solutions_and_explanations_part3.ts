/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// rag.native.ts
import { readFile } from "node:fs/promises";

// Interface for Chunk (safely stripped at runtime)
interface Chunk {
  id: number;
  text: string;
  embedding: number[];
}

// 1. Data Loading (Async, non-blocking via Event Loop)
async function loadData(filePath: string) {
  // Type Inference deduces 'data' as string
  const data = await readFile(filePath, "utf-8");
  return data;
}

// 2. Chunking Logic
function chunkText(text: string, size: number, overlap: number) {
  const chunks = [];
  let start = 0;
  while (start < text.length) {
    const end = Math.min(start + size, text.length);
    chunks.push({ id: chunks.length, text: text.slice(start, end) });
    start += size - overlap;
  }
  return chunks;
}

// 3. Embedding & Storage (Simulated)
// Relies on inference for the returned array of objects
function generateEmbedding(text: string) {
  // Simple hash-based mock embedding (5 dimensions)
  const embedding = new Array(5).fill(0);
  for (let i = 0; i < text.length; i++) {
    embedding[i % 5] += text.charCodeAt(i);
  }
  return embedding;
}

// 4. Retrieval (Vector Search - Cosine Similarity)
function cosineSimilarity(a: number[], b: number[]) {
  const dot = a.reduce((sum, val, i) => sum + val * b[i], 0);
  const magA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
  const magB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));
  return dot / (magA * magB);
}

// Orchestration
async function runRAGPipeline() {
  // Note: fs/promises read is handled by the Event Loop, not blocking the Call Stack
  const rawText = await loadData("./sample.txt"); 
  const textChunks = chunkText(rawText, 50, 10);
  
  // Inference: 'storedChunks' type is deduced from the map return
  const storedChunks = textChunks.map(chunk => ({
    ...chunk,
    embedding: generateEmbedding(chunk.text)
  }));

  const queryEmbedding = generateEmbedding("specific topic");
  
  // Find best match
  let bestMatch = storedChunks[0];
  let highestSim = -1;
  for (const chunk of storedChunks) {
    const sim = cosineSimilarity(queryEmbedding, chunk.embedding);
    if (sim > highestSim) {
      highestSim = sim;
      bestMatch = chunk;
    }
  }

  // 5. Synthesis
  console.log("Retrieved Chunk:", bestMatch.text);
  console.log("Mock LLM Synthesis: Based on the retrieved context, the answer is...");
}

await runRAGPipeline();

// Execution: node --experimental-strip-types rag.native.ts
