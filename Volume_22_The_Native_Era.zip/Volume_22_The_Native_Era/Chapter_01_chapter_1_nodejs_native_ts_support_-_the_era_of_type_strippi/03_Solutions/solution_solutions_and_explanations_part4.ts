/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// debug.fixed.ts
// Fixed using ES Modules, const objects, explicit assignments, and zero namespaces.

// 1. Replaced 'enum' with a const object (zero-cost at runtime)
const LogLevel = {
  Info: 1,
  Warn: 2,
  Error: 3
} as const;

type LogLevelType = typeof LogLevel[keyof typeof LogLevel];

// 2. Removed 'namespace' wrapper, using standard module scope/exports
function log(message: string, level: LogLevelType): void {
  console.log(`[${level}] ${message}`);
}

// 3. Refactored class to avoid parameter properties
class Service {
  serviceName: string;

  constructor(serviceName: string) {
    // Explicit assignment instead of 'private serviceName: string' in params
    this.serviceName = serviceName;
  }
  
  start() {
    log(`${this.serviceName} started`, LogLevel.Info);
  }
}

const s = new Service("Auth");
s.start();

// Execution: node --experimental-strip-types debug.fixed.ts
