/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// UserProfileCard.tsx
import React, { useState } from "react";
import { renderToString } from "react-dom/server";

type UserStatus = "online" | "offline" | "away";

interface UserProfileProps {
  name: string;
  status: UserStatus;
  initialClicks?: number;
}

// Functional component using hooks. No enums, no parameter properties.
// Type Inference automatically deduces the 'event' type in onClick.
function UserProfileCard(props: UserProfileProps) {
  const { name, status, initialClicks = 0 } = props;
  const [clicks, setClicks] = useState(initialClicks);

  return (
    <div onClick={(event) => { 
      // 'event' is inferred as React.MouseEvent<HTMLDivElement>
      console.log("Clicked via", event.type);
      setClicks(clicks + 1); 
    }}>
      <h2>{name}</h2>
      <span>Status: {status}</span>
      <p>Clicks: {clicks}</p>
    </div>
  );
}

// Native execution via Bun/Deno (no babel/webpack needed):
// bun run UserProfileCard.tsx (with a small server entry rendering it)
const html = renderToString(<UserProfileCard name="Alice" status="online" />);
console.log(html);

// Execution Command (Bun):
// bun run UserProfileCard.tsx
