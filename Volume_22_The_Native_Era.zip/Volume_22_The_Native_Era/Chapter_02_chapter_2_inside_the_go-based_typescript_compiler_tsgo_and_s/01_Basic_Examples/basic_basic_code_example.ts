/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Local AI Utility Module
 * Demonstrates native TypeScript execution, Type Inference, and Function Calling Schemas
 * optimized for environments using tsgo or SWC (Bun/Deno/Node 22+)
 */

// Logical Block 1: Define a Function Calling Schema using Type Inference
// The compiler automatically deduces the structural shape and literal types of this object
const reportGenerationTool = {
  name: "generateSaaSReport",
  description: "Creates a comprehensive PDF report for enterprise users",
  parameters: {
    type: "object",
    properties: {
      workspaceId: { type: "string" },
      includeCharts: { type: "boolean" }
    },
    required: ["workspaceId"]
  }
};

// Logical Block 2: Simulate Local AI Cold Start initialization
// This async function models the delay of fetching weights and compiling WASM/WebGPU
async function initializeLocalAI(modelPath: string) {
  // Log the fetching phase to standard output
  console.log(`[SaaS Boot]: Fetching model weights from ${modelPath}`);
  
  // Simulate WASM/WebGPU compilation delay (Cold Start) using a Promise
  await new Promise<void>((resolve) => setTimeout(resolve, 50));
  
  // Log readiness and return an object (type inferred by the compiler)
  console.log(`[SaaS Boot]: Local AI model ready. Cold start mitigated.`);
  return { modelId: "ts-native-llm", isReady: true };
}

// Logical Block 3: Primary workflow executor for the Web App
// Orchestrates the AI initialization and schema registration
async function executeWorkflow() {
  // Await the AI initialization promise to resolve
  const aiAgent = await initializeLocalAI("./wasm/llm_backend.wasm");
  
  // Type Inference deduces 'toolName' as the string literal type "generateSaaSReport"
  const toolName = reportGenerationTool.name;
  
  // Output the registered tool to the console using template literals
  console.log(`[SaaS Runtime]: Agent ${aiAgent.modelId} registered tool: ${toolName}`);
}

// Logical Block 4: Self-invoking execution context typical in modern native TS environments
executeWorkflow();
