/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/agentic-transform/route.ts
import { NextRequest, NextResponse } from 'next/server';

/**
 * JSDoc: Interface mapping to the exports of our WebAssembly module.
 * This module is conceptually compiled from Rust (like SWC) or Go (like tsgo),
 * providing near-native AST traversal and type-stripping capabilities.
 */
interface NativeTransformerWASM extends WebAssembly.Instance['exports'] {
  memory: WebAssembly.Memory;
  alloc(size: number): number;
  dealloc(ptr: number, size: number): void;
  strip_types(ptr: number, len: number): number;
}

// Module-level cache to persist WASM instance across serverless invocations
let nativeModule: NativeTransformerWASM | null = null;

/**
 * Instantiates the WASM binary. In the "Native Era", we bypass JS bundlers
 * by directly loading pre-compiled WASM artifacts.
 */
async function bootstrapNativeEngine(): Promise<NativeTransformerWASM> {
  if (nativeModule) return nativeModule;
  const res = await fetch(new URL('./swc_native.wasm', import.meta.url));
  const bytes = await res.arrayBuffer();
  const { instance } = await WebAssembly.instantiate(bytes, {});
  nativeModule = instance.exports as unknown as NativeTransformerWASM;
  return nativeModule;
}

/**
 * The Function Calling Schema (OpenAI/Anthropic compatible).
 * It teaches the LLM about the available "Tool" for native code transformation.
 */
const transformationToolSchema = {
  name: 'invoke_native_transformer',
  description: 'Utilizes a WebAssembly-compiled native engine (SWC/tsgo style) to strip TypeScript types from source code.',
  parameters: {
    type: 'object',
    properties: {
      sourceCode: { type: 'string', description: 'Raw TypeScript code submitted by the user.' }
    },
    required: ['sourceCode']
  }
};

/**
 * Helper: Copies a JS string into WASM linear memory and returns the pointer.
 */
function writeStringToWASM(wasm: NativeTransformerWASM, str: string): { ptr: number; len: number } {
  const encoder = new TextEncoder();
  const bytes = encoder.encode(str);
  const ptr = wasm.alloc(bytes.length);
  new Uint8Array(wasm.memory.buffer).set(bytes, ptr);
  return { ptr, len: bytes.length };
}

/**
 * Helper: Reads a null-terminated string from WASM linear memory.
 */
function readStringFromWASM(wasm: NativeTransformerWASM, ptr: number): string {
  const memory = new Uint8Array(wasm.memory.buffer);
  let end = ptr;
  while (memory[end] !== 0) end++;
  return new TextDecoder().decode(memory.subarray(ptr, end));
}

/**
 * Next.js Route Handler: Orchestrates LLM Tool Calling and Native WASM Execution.
 */
export async function POST(req: NextRequest) {
  const { userInput } = await req.json();

  // 1. AI Inference Layer: Send user input and Tool Schema to the LLM
  const llmReply = await fetch('https://api.llm.saas.internal/v1/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: userInput,
      tools: [transformationToolSchema] // Exposing the tool via Function Calling Schema
    })
  }).then(r => r.json());

  // 2. Tool Calling Evaluation: Check if the model requested our native tool
  const toolInvocation = llmReply?.tool_calls?.[0];
  if (toolInvocation?.name === 'invoke_native_transformer') {
    const { sourceCode } = JSON.parse(toolInvocation.arguments);
    
    // 3. Load the Native Engine (SWC/tsgo logic in WASM)
    const wasm = await bootstrapNativeEngine();
    
    // 4. Memory Marshalling: Transfer JS string to WASM
    const { ptr, len } = writeStringToWASM(wasm, sourceCode);
    
    // 5. Execution: Perform AST transformation & type stripping natively
    const resultPtr = wasm.strip_types(ptr, len);
    
    // 6. Memory Marshalling: Retrieve transformed JS from WASM
    const strippedCode = readStringFromWASM(wasm, resultPtr);
    
    // 7. Cleanup: Free WASM memory to prevent leaks in the SaaS backend
    wasm.dealloc(ptr, len);
    
    return NextResponse.json({
      status: 'success',
      engine: 'wasm-native',
      output: strippedCode
    });
  }

  // Fallback: Return standard LLM response if no tool was called
  return NextResponse.json({ status: 'no-op', llmReply });
}
