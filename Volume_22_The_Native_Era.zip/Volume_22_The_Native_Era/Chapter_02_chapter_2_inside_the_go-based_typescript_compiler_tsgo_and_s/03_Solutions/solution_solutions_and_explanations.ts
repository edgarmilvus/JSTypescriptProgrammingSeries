/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { parse, transform } from '@swc/core';
import { readFileSync, writeFileSync } from 'fs'; 

const targetFile = process.argv[2];
if (!targetFile) {
  // Structured error mimicking native runtime behavior
  console.error(JSON.stringify({ error: 'MissingFilePath', message: 'Please provide a TypeScript file path.' }));
  process.exit(1);
}

async function main() {
  try {
    const sourceCode = readFileSync(targetFile, 'utf-8');

    // SWC Parse: Generates raw AST using Rust's hand-written lexer
    const ast = parse(sourceCode, {
      syntax: 'typescript',
      target: 'es2022',
      isModule: true, 
    });

    let interfaceCount = 0;
    let typeAliasCount = 0;

    // A visitor pattern in SWC (swc_ecma_visit) would typically use a Rust struct 
    // implementing the 'Visit' trait to walk nodes safely. In JS, we manually recurse.
    function walk(node: any) {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) {
        node.forEach(walk);
        return;
      }
      if (node.type === 'TsInterfaceDeclaration') interfaceCount++;
      if (node.type === 'TsTypeAliasDeclaration') typeAliasCount++;
      
      for (const key in node) {
        if (node.hasOwnProperty(key)) walk(node[key]);
      }
    }
    walk(ast.body);

    console.log(`Analysis: Found ${interfaceCount} interfaces and ${typeAliasCount} type aliases.`);

    // SWC Transform: Strips types via internal TypeScript preset
    const output = await transform(sourceCode, { 
      jsc: { 
        parser: { syntax: 'typescript' },
        target: 'es2022'
      } 
    });

    // Write emitted JS to .compiled.js in the same directory
    const outFile = targetFile.replace(/\.ts$/, '') + '.compiled.js';
    writeFileSync(outFile, output.code);
    console.log(`Emitted stripped JavaScript to: ${outFile}`);

  } catch (err: any) {
    // Graceful structured error handling
    console.error(JSON.stringify({ 
      error: 'CompilationError', 
      message: err.message 
    }));
    process.exit(1);
  }
}

main();
