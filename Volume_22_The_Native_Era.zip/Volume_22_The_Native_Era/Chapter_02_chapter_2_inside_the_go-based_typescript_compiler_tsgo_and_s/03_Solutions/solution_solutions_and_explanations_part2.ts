/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface CompilerBenchmark {
  fileCount: number;
  simulateLegacyCheck(): Promise<number>; 
  simulateNativeConcurrentCheck(): Promise<number>; 
}

// MOCK DATA: Simulate a large TS file content
const mockFileContent = `export interface A { b: string; c: number; }`.repeat(1000);

// CPU-bound task to simulate type resolution
function fakeTypeCheck(content: string): void {
  for (let i = 0; i < 500; i++) {
    content.match(/interface/g); // Simulate lexical analysis/type resolution
  }
}

class BenchmarkRunner implements CompilerBenchmark {
  fileCount: number;

  constructor(fileCount: number) {
    this.fileCount = fileCount;
  }

  async simulateLegacyCheck(): Promise<number> {
    const start = performance.now();
    // Synchronous, single-threaded loop (blocks V8 event loop like legacy tsc)
    for (let i = 0; i < this.fileCount; i++) {
      fakeTypeCheck(mockFileContent);
    }
    return performance.now() - start;
  }

  async simulateNativeConcurrentCheck(): Promise<number> {
    const start = performance.now();
    
    // Simulate tsgo's parallel parsing using Promise.all.
    // In a real Bun environment, you would spawn Workers or use Bun.spawn:
    // const proc = Bun.spawn(['bun', 'worker.ts', '--file', fileName]);
    // Here we chunk the work and use async promises to simulate concurrency.
    const promises: Promise<void>[] = [];
    const chunkSize = 50;
    
    for (let i = 0; i < this.fileCount; i += chunkSize) {
      promises.push(
        new Promise<void>((resolve) => {
          setTimeout(() => {
            for (let j = 0; j < chunkSize && (i + j) < this.fileCount; j++) {
              fakeTypeCheck(mockFileContent);
            }
            resolve();
          }, 0);
        })
      );
    }
    
    await Promise.all(promises);
    return performance.now() - start;
  }
}

// EXPLANATION OF GO SCHEDULER (tsgo):
// In tsgo (Go), a 'sync.WaitGroup' would replace Promise.all. 
// We would spawn N goroutines (go func() { ... }) and call wg.Add(1) before each, 
// wg.Done() after the check, and wg.Wait() to block until all finish. 
// Go's M:N scheduler maps these goroutines to OS threads automatically, 
// providing true parallel CPU execution across cores, unlike Node's libuv 
// which only parallelizes I/O, not CPU-bound JS execution.

async function runBenchmarks() {
  const bench = new BenchmarkRunner(1000);
  const legacyTime = await bench.simulateLegacyCheck();
  const nativeTime = await bench.simulateNativeConcurrentCheck();
  
  console.log(`Legacy tsc (simulated): ${legacyTime.toFixed(2)}ms`);
  console.log(`tsgo (simulated concurrent): ${nativeTime.toFixed(2)}ms`);
}

runBenchmarks();
