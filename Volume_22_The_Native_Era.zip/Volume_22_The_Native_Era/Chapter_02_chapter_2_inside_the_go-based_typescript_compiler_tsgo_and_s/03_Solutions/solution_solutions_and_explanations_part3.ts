/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// WinterCG compliant: No Node.js imports (no 'fs', 'path', or 'require')

interface FunctionCallingSchema {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<string, { type: string; description: string }>;
    required: string[];
  };
}

// Tool 1: getWeather (Pure function using standard fetch)
async function getWeather(args: { city: string; unit: string }): Promise<string> {
  const res = await fetch(`https://api.weather.example?city=${args.city}&unit=${args.unit}`);
  return res.status === 200 ? `Weather fetched for ${args.city}` : 'Error';
}

// Tool 2: calculateSentiment (Pure function)
function calculateSentiment(args: { text: string }): string {
  const positive = ['good', 'great', 'excellent'];
  const hasPositive = positive.some(word => args.text.toLowerCase().includes(word));
  return hasPositive ? 'positive' : 'neutral';
}

// ToolRouter class
class ToolRouter {
  private schemas: Map<string, FunctionCallingSchema>;
  private tools: Map<string, (args: any) => any>;

  constructor(schemaArray: FunctionCallingSchema[]) {
    this.schemas = new Map();
    this.tools = new Map();
    schemaArray.forEach(schema => this.schemas.set(schema.name, schema));
  }

  registerTool(name: string, fn: (args: any) => any) {
    this.tools.set(name, fn);
  }

  async route(toolCall: { name: string; args: object }): Promise<any> {
    const schema = this.schemas.get(toolCall.name);
    if (!schema) throw new Error(`Tool ${toolCall.name} not found in schema.`);
    
    // Validate required args (basic structural check)
    for (const req of schema.parameters.required) {
      if (!(req in (toolCall.args as object))) {
        throw new Error(`Missing required argument: ${req}`);
      }
    }

    const toolFn = this.tools.get(toolCall.name);
    if (!toolFn) throw new Error(`No implementation registered for ${toolCall.name}`);
    
    return toolFn(toolCall.args);
  }
}

// V8 ISOLATE MEMORY COMMENT:
// In an Edge Runtime, this module is loaded into a V8 Isolate. Unlike a Node.js 
// process which initializes a large heap, libuv, and a module cache, an Isolate 
// is a lightweight, isolated heap within a shared V8 instance. Memory for these 
// TypeScript interfaces is stripped at compile time (SWC) and the resulting JS 
// objects are allocated in the Isolate's small, efficiently garbage-collected heap, 
// enabling sub-millisecond cold starts.

// Usage Example (runs natively in Deno/Bun):
const weatherSchema: FunctionCallingSchema = {
  name: 'getWeather',
  description: 'Fetches current temperature for a given city',
  parameters: {
    type: 'object',
    properties: {
      city: { type: 'string', description: 'The city name' },
      unit: { type: 'string', description: 'celsius or fahrenheit' }
    },
    required: ['city']
  }
};

const router = new ToolRouter([weatherSchema]);
router.registerTool('getWeather', getWeather);
