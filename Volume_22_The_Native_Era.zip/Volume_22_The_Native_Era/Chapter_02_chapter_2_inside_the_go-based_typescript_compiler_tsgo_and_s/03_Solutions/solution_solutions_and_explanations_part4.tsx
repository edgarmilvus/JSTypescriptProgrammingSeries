/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

interface FunctionCallingSchema {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<string, { type: string; description: string }>;
    required: string[];
  };
}

interface ToolSchemaVisualizerProps {
  schemas: FunctionCallingSchema[];
  selectedToolName: string | null;
}

// Child component for rendering parameters
function ParameterList({ properties }: { properties: Record<string, { type: string; description: string }> }) {
  return (
    <ul style={{ margin: 0, paddingLeft: '20px' }}>
      {Object.entries(properties).map(([key, val]) => (
        <li key={key} style={{ fontSize: '0.9em' }}>
          <strong>{key}</strong>: <em>{val.type}</em> - {val.description}
        </li>
      ))}
    </ul>
  );
}

export function ToolSchemaVisualizer({ schemas, selectedToolName }: ToolSchemaVisualizerProps) {
  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h3>Active AI Tools</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {schemas.map((schema) => {
          const isSelected = schema.name === selectedToolName;
          return (
            <div 
              key={schema.name} 
              style={{
                border: isSelected ? '2px solid #3b82f6' : '1px solid #e5e7eb',
                borderRadius: '8px',
                padding: '12px',
                background: isSelected ? '#eff6ff' : 'white',
                transition: 'all 0.2s ease'
              }}
            >
              <h4 style={{ margin: '0 0 4px 0', color: isSelected ? '#1d4ed8' : '#111827' }}>
                {schema.name}
              </h4>
              <p style={{ margin: '0 0 8px 0', fontSize: '0.85em', color: '#6b7280' }}>
                {schema.description}
              </p>
              {isSelected && <ParameterList properties={schema.parameters.properties} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/*
  UNDER THE HOOD COMMENT:
  SWC's 'jsc.transform.react.refresh' flag injects 'RefreshRuntime.register' calls 
  at the end of the module and wraps exported components. When a file is saved in 
  Deno/Bun, the native transpiler (SWC) generates a new function reference but calls 
  'RefreshRuntime.performReactRefresh()'. React's dev runtime then preserves the hook 
  state by mapping the old fiber to the new function. Webpack's HMR relies on 
  'module.hot.accept' and often uses module-level proxy objects, which can cause 
  full remounts or lost state because it invalidates the entire module closure. 
  SWC's AST-level precision avoids this, making zero-config native DX superior.
*/
