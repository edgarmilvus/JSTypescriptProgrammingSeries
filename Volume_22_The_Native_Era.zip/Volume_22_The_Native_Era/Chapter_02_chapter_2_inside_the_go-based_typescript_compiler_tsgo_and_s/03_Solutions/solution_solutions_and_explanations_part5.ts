/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Shared TS Code Snippet to be analyzed:
const enum HttpStatus {
  OK = 200,
  NotFound = 404,
  InternalServerError = 500
}

function handleResponse(code: HttpStatus): string {
  switch (code) {
    case HttpStatus.OK:
      return "Success";
    case HttpStatus.NotFound:
      return "Missing";
    case HttpStatus.InternalServerError:
      return "Crash";
    default:
      return "unknown";
  }
}

/*
  TSGO / GO MEMORY MODEL COMMENT:
  In tsgo (Go), the 'const enum' would be parsed into a compile-time 
  'map[string]int32' or a Go struct with constant fields. During AST 
  transformation, Go's type-checker performs O(1) hash map lookups to inline 
  the literal values (200, 404) directly into the switch statement, emitting 
  no JS object. Edge Runtimes prefer this stripping because it reduces the 
  Isolate's payload size; a reverse-mapped enum object (e.g., HttpStatus[200] === 'OK') 
  would add unnecessary bytes and memory allocation to the cold start path.
*/
