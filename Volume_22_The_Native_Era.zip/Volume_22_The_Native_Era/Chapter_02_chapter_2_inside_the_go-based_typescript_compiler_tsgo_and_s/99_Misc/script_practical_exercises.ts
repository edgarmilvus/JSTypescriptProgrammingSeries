/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { parse, transform } from '@swc/core';
import { readFileSync, writeFileSync } from 'fs'; 

// ARCHITECTURAL NOTE: In a true Edge Runtime, 'fs' is absent. 
// We use it here only because we are analyzing local files in a Node/Bun context.
// In Deno, this would be Deno.readTextFileSync.

const targetFile = process.argv[2];
if (!targetFile) {
  console.error('Please provide a TypeScript file path.');
  process.exit(1);
}

const sourceCode = readFileSync(targetFile, 'utf-8');

// SWC Parse Options: 
// 'isModule' determines if SWC treats the file as a module (affecting scope analysis)
// 'target' tells the lexer which JS features to expect (e.g., es2022 allows top-level await)
const ast = parse(sourceCode, {
  syntax: 'typescript',
  target: 'es2022',
  isModule: true, 
});

// TODO: Implement the AST traversal.
// Hint: You will need to recursively walk the 'ast.body' array.
// Look for node types: 'TsInterfaceDeclaration' and 'TsTypeAliasDeclaration'.

// TODO: Implement the transform call to strip types.
// const output = await transform(sourceCode, { jsc: { parser: { syntax: 'typescript' } } });

// TODO: Write the output.code to a .compiled.js file.
