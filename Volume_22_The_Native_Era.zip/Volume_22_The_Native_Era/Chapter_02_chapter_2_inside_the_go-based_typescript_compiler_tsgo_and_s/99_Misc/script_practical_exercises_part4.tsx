/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React from 'react';

// Re-defining the schema for component prop typing
interface FunctionCallingSchema {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<string, { type: string; description: string }>;
    required: string[];
  };
}

interface ToolSchemaVisualizerProps {
  schemas: FunctionCallingSchema[];
  selectedToolName: string | null;
}

// TODO: Implement the ToolSchemaVisualizer component.
// Use the automatic JSX runtime (jsx: 'react-jsx') as supported by SWC natively.
// Render a div containing a map of schemas. Highlight the selected one.

// TODO: Implement the ParameterList sub-component.
// It should accept a 'properties' object and render a <ul> of keys and types.

export function ToolSchemaVisualizer({ schemas, selectedToolName }: ToolSchemaVisualizerProps) {
  // YOUR ARCHITECTURE HERE:
  // 1. Filter or find the selected schema.
  // 2. Map over schemas to create buttons or list items.
  // 3. Conditionally apply style={{ border: '2px solid blue' }} if selected.
  
  return (
    <div style={{ fontFamily: 'sans-serif' }}>
      {/* TODO: Render the visualization based on requirements */}
      <h3>Active AI Tools</h3>
    </div>
  );
}

/*
  UNDER THE HOOD COMMENT REQUIRED:
  Explain how SWC's 'jsc.transform.react.refresh' flag injects 
  'RefreshRuntime.register' calls, and why this is faster than Webpack's 
  'module.hot.accept' approach in a native Deno/Bun environment.
*/
