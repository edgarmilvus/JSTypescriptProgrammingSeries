/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// advanced-augmentation.ts
// ESM-only module: safe from dual-package hazards when "type": "module" is set
// and "exports" maps "./advanced-augmentation" to this file for both "import" and "require".

/**
 * Represents the presentation-layer state for the SaaS dashboard.
 * UIState drives which React components render during streaming.
 */
export interface UIState {
  /** Unique identifier for the current view session */
  sessionId: string;
  /** Components queued for render based on AIState */
  activeComponents: string[];
  /** Flag indicating whether GPU acceleration is active */
  gpuAccelerated: boolean;
}

/**
 * Minimal shape of a retrieved context chunk from the RAG store.
 */
interface RetrievedChunk {
  id: string;
  text: string;
  score: number;
}

/**
 * Detects whether the current runtime supports WebGPU.
 * Uses lazy evaluation to avoid referencing `navigator` on the server.
 * @returns {boolean} True if WebGPU is available.
 */
function hasWebGPU(): boolean {
  // On Node.js this is undefined; on modern browsers it exists.
  return typeof navigator !== 'undefined' && 'gpu' in navigator;
}

/**
 * Performs client-side embedding acceleration using WebGPU.
 * Falls back to a naive CPU loop if WebGPU is unavailable.
 * @param {string[]} texts - Chunks to embed.
 * @returns {Promise<number[][]>} Simulated vector embeddings.
 */
async function accelerateEmbeddings(texts: string[]): Promise<number[][]> {
  if (hasWebGPU()) {
    // Under the hood: requestAdapter() returns a GPUAdapter; we mock the compute.
    // This avoids dual-package issues because we do not import a CJS GPU lib.
    const adapter = await (navigator as any).gpu.requestAdapter();
    if (adapter) {
      // Simulated GPGPU pass: real code would encode GPUComputePassEncoder.
      return texts.map((t) => [t.length, t.length * 0.5]);
    }
  }
  // CPU fallback: ensures server and client both get deterministic shape.
  return texts.map((t) => [t.length, t.length * 0.5]);
}

/**
 * Core SaaS function: Augments context and updates UIState.
 * This is the single source of truth imported by both runtimes.
 * @param {RetrievedChunk[]} chunks - Retrieved RAG chunks.
 * @param {string} userQuery - Original user question.
 * @param {UIState} currentUI - Existing presentation state.
 * @returns {Promise<{ augmentedPrompt: string; nextUI: UIState }>}
 */
export async function runContextAugmentation(
  chunks: RetrievedChunk[],
  userQuery: string,
  currentUI: UIState
): Promise<{ augmentedPrompt: string; nextUI: UIState }> {
  // 1. Sort chunks by relevance score (descending)
  const ranked = chunks.sort((a, b) => b.score - a.score);

  // 2. Accelerate embedding via WebGPU if possible (no CJS dep)
  const embeddings = await accelerateEmbeddings(ranked.map((c) => c.text));

  // 3. Package context: join top-3 chunks with query (Context Augmentation)
  const contextBlock = ranked
    .slice(0, 3)
    .map((c) => `[[${c.id}]] ${c.text}`)
    .join('\n');
  const augmentedPrompt = `USER QUERY: ${userQuery}\nCONTEXT:\n${contextBlock}`;

  // 4. Update UIState: signal that a streaming component should mount
  const nextUI: UIState = {
    ...currentUI,
    activeComponents: [...currentUI.activeComponents, 'AugmentedAnswerStream'],
    gpuAccelerated: hasWebGPU(),
  };

  // 5. Return both the LLM-ready prompt and the new UIState
  return { augmentedPrompt, nextUI };
}
