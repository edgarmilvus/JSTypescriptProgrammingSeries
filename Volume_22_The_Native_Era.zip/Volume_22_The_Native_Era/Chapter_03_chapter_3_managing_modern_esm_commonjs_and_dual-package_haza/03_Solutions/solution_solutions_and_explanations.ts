/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// safe-json.ts
// We author a SINGLE ESM source file. No separate CJS build is emitted.
// Parallel builds are avoided because duplicated module graphs (CJS + ESM)
// cause distinct class identities; sharing one module preserves `instanceof`
// safety via a single resolved module instance per runtime.

/**
 * Returns the current JS runtime without throwing.
 * Uses only safe globals: process.versions (Node/Bun), navigator (Deno).
 */
export function getRuntime(): 'node' | 'bun' | 'deno' {
  // Deno exposes navigator.userAgent containing "Deno"
  // @ts-ignore - navigator exists under Deno
  if (typeof navigator !== 'undefined' && navigator.userAgent?.includes('Deno')) {
    return 'deno';
  }
  // Bun sets process.versions.bun
  if (typeof process !== 'undefined' && (process.versions as any).bun) {
    return 'bun';
  }
  // Fallback to Node
  if (typeof process !== 'undefined') {
    return 'node';
  }
  return 'node';
}

export interface SafeJsonResult<T> {
  ok: boolean;
  value?: T;
  error?: Error;
}

export function parseSafe<T>(input: string): SafeJsonResult<T> {
  try {
    return { ok: true, value: JSON.parse(input) as T };
  } catch (e) {
    return { ok: false, error: e as Error };
  }
}

// Default export for CJS interop via require() without .default confusion
export default { getRuntime, parseSafe };
