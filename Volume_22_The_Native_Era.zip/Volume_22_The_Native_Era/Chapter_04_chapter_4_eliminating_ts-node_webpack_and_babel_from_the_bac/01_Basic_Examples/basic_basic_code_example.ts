/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal native TypeScript SaaS backend snippet.
 * Runs directly on Node.js 22+, Bun, or Deno without ts-node/Webpack/Babel.
 */

// Node's built-in HTTP module (no external framework needed)
import http from 'node:http';

/**
 * Simulates a non-blocking embedding generation step in a RAG pipeline.
 * Uses setTimeout to mimic async I/O without blocking the event loop.
 * @param text The user query to embed
 * @returns A promise resolving to a fake vector (array of numbers)
 */
function generateEmbedding(text: string): Promise<number[]> {
  return new Promise((resolve) => {
    // Non-blocking I/O: delegate to timer, event loop continues
    setTimeout(() => {
      const fakeVector = text.split('').map((c) => c.charCodeAt(0) % 10);
      resolve(fakeVector);
    }, 10);
  });
}

/**
 * Simulates vector storage retrieval (non-blocking DB read).
 * @param vector The embedding to search with
 * @returns A promise resolving to a retrieved document string
 */
function retrieveDocument(vector: number[]): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`Doc matching vector ${vector.toString()}`);
    }, 10);
  });
}

/**
 * Simulates LLM synthesis (non-blocking network call).
 * @param doc The retrieved context
 * @returns A promise resolving to a final answer
 */
function synthesizeAnswer(doc: string): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`SaaS Answer based on: ${doc}`);
    }, 10);
  });
}

/**
 * The core request handler implementing a tiny RAG pipeline.
 * Demonstrates cyclical retry (graph loop) and non-blocking I/O.
 */
const server = http.createServer(async (req, res) => {
  // 1. Only handle GET /query
  if (req.url === '/query' && req.method === 'GET') {
    let attempts = 0;
    const maxAttempts = 3;
    let finalAnswer = '';

    // 2. Cyclical graph structure: retry loop until success or limit
    while (attempts < maxAttempts) {
      try {
        // 3. Non-blocking embedding
        const embedding = await generateEmbedding('Hello SaaS');
        // 4. Non-blocking retrieval
        const doc = await retrieveDocument(embedding);
        // 5. Non-blocking synthesis
        finalAnswer = await synthesizeAnswer(doc);
        break; // exit loop on success
      } catch (err) {
        attempts++;
        if (attempts === maxAttempts) {
          finalAnswer = 'Failed to process query';
        }
      }
    }

    // 6. Send response (non-blocking write)
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(finalAnswer);
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

// 7. Start server on port 3000 (native ESM, no transpile needed)
server.listen(3000, () => {
  console.log('Native TS SaaS server on http://localhost:3000');
});
