/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Native TypeScript LangGraph example for a SaaS billing risk workflow.
 * Runs directly under Node.js 22+ (--experimental-strip-types) or Bun/Deno.
 */

// 1. Define the canonical Graph State shared across all nodes.
/** @interface BillingGraphState Canonical data passed between LangGraph nodes. */
interface BillingGraphState {
  tenantId: string;            // SaaS customer identifier
  monthlyRevenue: number;      // Current MRR for the tenant
  riskScore: number;           // Aggregated risk value (0-100)
  flags: string[];             // Detected risk flags
  recommendation?: string;     // Final human-readable advice
}

// 2. Tool Invocation Signature for external credit check.
/**
 * Invokes a third-party risk API.
 * @param params - Object containing tenantId and revenue.
 * @returns Promise resolving to a risk delta and flag list.
 */
async function invokeCreditTool(params: {
  tenantId: string;
  revenue: number;
}): Promise<{ delta: number; flag: string }> {
  // Simulate native fetch (no bundler needed)
  const res = await fetch(`https://api.saas-risk.test/${params.tenantId}`);
  const data = await res.json();
  return { delta: data.riskDelta, flag: data.flag };
}

// 3. Entry Point Node: initializes workflow and seeds state.
/**
 * Entry point node logic.
 * @param state - Initial partial state from API trigger.
 * @returns Augmented state with baseline risk.
 */
async function entryPointNode(
  state: Partial<BillingGraphState>
): Promise<BillingGraphState> {
  // Seed canonical state with defaults
  return {
    tenantId: state.tenantId ?? "unknown",
    monthlyRevenue: state.monthlyRevenue ?? 0,
    riskScore: 10, // baseline
    flags: [],
  };
}

// 4. Risk aggregation node using the tool signature.
/**
 * Middle node that calls the tool and updates Graph State.
 * @param state - Current canonical state.
 * @returns Updated state with new risk inputs.
 */
async function assessNode(
  state: BillingGraphState
): Promise<Partial<BillingGraphState>> {
  const toolResult = await invokeCreditTool({
    tenantId: state.tenantId,
    revenue: state.monthlyRevenue,
  });
  return {
    riskScore: state.riskScore + toolResult.delta,
    flags: [...state.flags, toolResult.flag],
  };
}

// 5. Final recommendation node.
/**
 * Terminal node producing SaaS admin recommendation.
 * @param state - Fully aggregated state.
 * @returns Final recommendation string.
 */
async function recommendNode(
  state: BillingGraphState
): Promise<Partial<BillingGraphState>> {
  const level = state.riskScore > 70 ? "HIGH" : "NORMAL";
  return { recommendation: `${level} risk for ${state.tenantId}` };
}

// 6. Native orchestration (no LangGraph lib required for demo).
/** @function runWorkflow Executes nodes in sequence like StateGraph. */
async function runWorkflow(initial: Partial<BillingGraphState>) {
  let state = await entryPointNode(initial); // Entry Point Node
  state = { ...state, ...(await assessNode(state)) };
  state = { ...state, ...(await recommendNode(state)) };
  return state;
}

// 7. Direct native execution (no webpack/ts-node).
runWorkflow({ tenantId: "acme_001", monthlyRevenue: 4200 })
  .then((s) => console.log(JSON.stringify(s, null, 2)));
