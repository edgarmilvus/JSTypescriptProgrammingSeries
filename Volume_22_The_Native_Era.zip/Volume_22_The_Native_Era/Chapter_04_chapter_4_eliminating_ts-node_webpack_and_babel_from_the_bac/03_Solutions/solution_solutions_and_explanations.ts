/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// package.json should contain: { "type": "module" }
// Node.js requires: node --experimental-strip-types server.ts
// V8 strips types syntactically without type-checking; it only removes type annotations at parse time.

// routes.ts
import type { HealthStatus } from "./server.ts";

export async function getHealth(): Promise<HealthStatus> {
  return { status: "ok", uptime: process.uptime() };
}

export async function echo(body: unknown) {
  return { echoed: body };
}

// server.ts
import http from "node:http";
import type { HealthStatus } from "./server.ts"; // type-only, stripped natively
import { getHealth, echo } from "./routes.ts";

type HealthStatus = { status: "ok"; uptime: number };

const server = http.createServer(async (req, res) => {
  if (req.url === "/health") {
    const data = await getHealth();
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(data));
  } else if (req.url === "/echo") {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    const body = JSON.parse(Buffer.concat(chunks).toString());
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(await echo(body)));
  } else {
    res.statusCode = 404;
    res.end();
  }
});

server.listen(3000, () => console.log("Listening on :3000"));
// No .js files are emitted; node executes .ts directly via type stripping.
