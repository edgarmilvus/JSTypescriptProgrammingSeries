/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// file: src/saas/signup.ts

/**
 * JSDoc: Define the raw shape of a signup request as received from the client.
 * This is the "input contract" for our SaaS API layer.
 */
interface RawSignupRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  age: number;
}

/**
 * JSDoc: Utility type that makes all properties of RawSignupRequest optional.
 * Used when partially updating a user profile later in the SaaS lifecycle.
 */
type PartialSignup = Partial<RawSignupRequest>;

/**
 * JSDoc: Module responsible ONLY for validating signup data.
 * SRP: This module has one reason to change – validation rules.
 */
function validateSignup(input: RawSignupRequest): boolean {
  // 1. Check email is non-empty and contains "@"
  if (!input.email.includes("@")) return false;
  // 2. Password must be at least 8 chars (SaaS security baseline)
  if (input.password.length < 8) return false;
  // 3. Age must be a positive integer within allowed range
  if (input.age < 13 || input.age > 120) return false;
  // 4. Names must not be empty
  if (input.firstName.trim() === "" || input.lastName.trim() === "") return false;
  return true;
}

/**
 * JSDoc: Module responsible ONLY for normalizing the validated request.
 * SRP: Isolates data transformation from validation and persistence.
 */
function normalizeSignup(input: RawSignupRequest): Readonly<RawSignupRequest> {
  // Create immutable copy with trimmed strings
  return Object.freeze({
    email: input.email.toLowerCase().trim(),
    password: input.password, // assume hashed later in separate module
    firstName: input.firstName.trim(),
    lastName: input.lastName.trim(),
    age: input.age,
  });
}

/**
 * JSDoc: API presentation layer – only formats output for the client.
 * SRP: No business logic, only HTTP‑adjacent response shaping.
 */
function formatSignupResponse(user: Readonly<RawSignupRequest>): string {
  return `Welcome ${user.firstName} ${user.lastName} (${user.email})!`;
}

// --- Native ESM entrypoint (no bundler needed) ---
// Simulate an incoming request in a SaaS web app
const incomingRequest: RawSignupRequest = {
  email: "Alice@Example.com",
  password: "supersecret",
  firstName: " Alice ",
  lastName: "Smith",
  age: 29,
};

// Logical block 1: Validate
if (!validateSignup(incomingRequest)) {
  console.error("Invalid signup");
  throw new Error("Validation failed");
}

// Logical block 2: Normalize (SRP separation)
const cleanUser = normalizeSignup(incomingRequest);

// Logical block 3: Present (SRP separation)
const response = formatSignupResponse(cleanUser);
console.log(response);
