/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// File: app/actions/chatRouter.ts
// Context: Next.js Server Action module for a SaaS AI assistant.
// Assumes tsconfig.json with strict: true, noUncheckedIndexedAccess: true,
// verbatimModuleSyntax: true, and native ESM runtime type stripping.
// ============================================================================

import { z } from "zod";
import type { ChatToolName, ValidatedToolCall } from "@/lib/types";

/**
 * Zod schema for the raw client payload.
 * Defines shape of incoming chat command before runtime validation.
 */
const RawChatPayloadSchema = z.object({
  tool: z.enum(["summarize", "translate", "refund"]),
  args: z.record(z.string(), z.unknown()),
});

/**
 * Zod schema for the 'summarize' tool arguments.
 * Enforces non-empty text and max length for SaaS tier limits.
 */
const SummarizeArgsSchema = z.object({
  text: z.string().min(1).max(5000),
  tone: z.enum(["formal", "casual"]).default("formal"),
});

/**
 * Zod schema for the 'translate' tool arguments.
 */
const TranslateArgsSchema = z.object({
  text: z.string().min(1),
  targetLang: z.string().length(2),
});

/**
 * Zod schema for the 'refund' tool arguments (admin-only).
 */
const RefundArgsSchema = z.object({
  orderId: z.string().uuid(),
  reason: z.string().min(3),
});

/**
 * User-defined type guard: checks if parsed data matches SummarizeArgs.
 * Returns `value is z.infer<typeof SummarizeArgsSchema>` for compiler narrowing.
 */
function isSummarizeArgs(
  value: unknown
): value is z.infer<typeof SummarizeArgsSchema> {
  return SummarizeArgsSchema.safeParse(value).success;
}

/**
 * User-defined type guard for TranslateArgs.
 */
function isTranslateArgs(
  value: unknown
): value is z.infer<typeof TranslateArgsSchema> {
  return TranslateArgsSchema.safeParse(value).success;
}

/**
 * User-defined type guard for RefundArgs.
 */
function isRefundArgs(
  value: unknown
): value is z.infer<typeof RefundArgsSchema> {
  return RefundArgsSchema.safeParse(value).success;
}

/**
 * Server Action: receives raw payload, validates, and routes.
 * Uses Zod inference + type guards under strict flags.
 */
export async function routeChatTool(
  rawInput: unknown
): Promise<{ ok: true; result: string } | { ok: false; error: string }> {
  // 1. Validate outer payload shape with Zod.
  const parsed = RawChatPayloadSchema.safeParse(rawInput);
  if (!parsed.success) {
    return { ok: false, error: "Invalid payload structure" };
  }

  // 2. Destructure validated tool name and args record.
  const { tool, args } = parsed.data;

  // 3. Branch using type guards to achieve compile-time narrowing.
  if (tool === "summarize" && isSummarizeArgs(args)) {
    // args is now strongly typed as SummarizeArgs
    const out = await summarizeService(args.text, args.tone);
    return { ok: true, result: out };
  }

  if (tool === "translate" && isTranslateArgs(args)) {
    const out = await translateService(args.text, args.targetLang);
    return { ok: true, result: out };
  }

  if (tool === "refund" && isRefundArgs(args)) {
    const out = await refundService(args.orderId, args.reason);
    return { ok: true, result: out };
  }

  // 4. Fallthrough: unknown combination under noUncheckedIndexedAccess safety.
  return { ok: false, error: "Tool/args mismatch or unauthorized" };
}

// --- Simulated SaaS micro-services (server-only) ---
async function summarizeService(text: string, tone: "formal" | "casual") {
  return `Summary (${tone}): ${text.slice(0, 50)}…`;
}
async function translateService(text: string, lang: string) {
  return `Translated(${lang}): ${text}`;
}
async function refundService(orderId: string, reason: string) {
  return `Refund issued for ${orderId} due to ${reason}`;
}
