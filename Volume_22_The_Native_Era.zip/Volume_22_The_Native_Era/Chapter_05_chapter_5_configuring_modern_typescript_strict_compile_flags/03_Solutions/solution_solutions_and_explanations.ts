/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Expected shape of a User record from the API
interface User {
  id: number;
  name: string;
  roles: string[];
}

// User-defined type guard to validate unknown data at runtime
function isUser(obj: unknown): obj is User {
  if (typeof obj !== "object" || obj === null) return false;
  const o = obj as Record<string, unknown>;
  return (
    typeof o.id === "number" &&
    typeof o.name === "string" &&
    Array.isArray(o.roles) &&
    o.roles.every((r) => typeof r === "string")
  );
}

// Fetch and safely extract the primary role, returning string | null
async function getPrimaryRole(url: string): Promise<string | null> {
  const res = await fetch(url);
  const data: unknown = await res.json();

  // Ensure we got an array
  if (!Array.isArray(data)) return null;

  // noUncheckedIndexedAccess: data.at(0) is User | undefined
  const first = data.at(0);
  if (first === undefined) return null;

  // Narrow with guard; first is now User
  if (!isUser(first)) return null;

  // roles may be empty; handle sparse/undefined access
  const primary = first.roles.at(0);
  return primary === undefined ? null : primary;
}

// Top-level await usage in native ESM (Deno/Node/Bun 2026)
const role = await getPrimaryRole("https://api.example.com/users");
console.log(role);
