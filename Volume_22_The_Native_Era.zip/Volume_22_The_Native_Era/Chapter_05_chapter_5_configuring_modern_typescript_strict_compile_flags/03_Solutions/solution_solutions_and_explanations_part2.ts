/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Generic contract: each entity provides its own guard
interface EntityGuard<T> {
  isT: (v: unknown) => v is T;
}

// Repository constrained to object types with a required guard
class Repository<T extends object> {
  constructor(private guard: EntityGuard<T>) {}

  async findAll(path: string): Promise<T[]> {
    const file = Bun.file(path);
    const text = await file.text();
    const parsed: unknown = JSON.parse(text);

    if (!Array.isArray(parsed)) return [];

    const out: T[] = [];
    // noUncheckedIndexedAccess: parsed[i] is unknown | undefined
    for (let i = 0; i < parsed.length; i++) {
      const item = parsed[i];
      if (item !== undefined && this.guard.isT(item)) {
        out.push(item);
      }
    }
    return out;
  }
}

// Concrete entity: Product
interface Product {
  sku: string;
  price: number;
}
const productGuard: EntityGuard<Product> = {
  isT: (v): v is Product =>
    typeof v === "object" && v !== null &&
    typeof (v as any).sku === "string" &&
    typeof (v as any).price === "number",
};

// Concrete entity: Invoice
interface Invoice {
  id: string;
  total: number;
}
const invoiceGuard: EntityGuard<Invoice> = {
  isT: (v): v is Invoice =>
    typeof v === "object" && v !== null &&
    typeof (v as any).id === "string" &&
    typeof (v as any).total === "number",
};

// Instances
const productRepo = new Repository<Product>(productGuard);
const invoiceRepo = new Repository<Invoice>(invoiceGuard);
