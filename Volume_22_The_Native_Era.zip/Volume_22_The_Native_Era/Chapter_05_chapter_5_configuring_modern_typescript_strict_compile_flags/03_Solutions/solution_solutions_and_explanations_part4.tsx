/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// Type-only import (verbatimModuleSyntax compliant)
import type { Message } from "./types";

// Value import for server rendering
import { renderToStaticMarkup } from "react-dom/server";

// Generic message shape
type Message<TKind extends string> = {
  id: string;
  kind: TKind;
  payload: unknown;
};

// Guard for text messages
function isTextMessage(m: Message<string>): m is Message<"text"> & { payload: string } {
  return m.kind === "text" && typeof m.payload === "string";
}

// Server Component (no "use client")
function ChatHistory<T extends Message<string>>(props: { messages: T[] }) {
  const texts = props.messages.filter(isTextMessage);
  return (
    <ul>
      {texts.map((m) => (
        <li key={m.id}>{m.payload}</li>
      ))}
    </ul>
  );
}

// Server Action stub
async function loadHistory(): Promise<Message<string>[]> {
  const res = await fetch("https://ai.example.com/history");
  const data: unknown = await res.json();
  return Array.isArray(data) ? (data as Message<string>[]) : [];
}

export { ChatHistory, loadHistory };
