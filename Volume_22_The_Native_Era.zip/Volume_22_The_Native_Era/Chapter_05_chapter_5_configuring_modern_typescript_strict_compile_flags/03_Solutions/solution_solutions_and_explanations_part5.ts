/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

1. `tsc --noEmit` is still necessary because it performs type-checking that runtime stripping does not; stripping only removes types, it does not validate them, so errors like invalid property access are caught only at compile time.
2. With `noUncheckedIndexedAccess`, `arr[3].name` where `arr` length is 2 causes `arr[3]` to be `T | undefined`. The compiler forces a check for `undefined` before `.name`; if unchecked, it errors. At runtime, `arr[3]` is `undefined` and `.name` throws.
3. `verbatimModuleSyntax` changes the source.ts box by requiring explicit `import type` for types; during stripping, those type-only nodes are erased exactly as written, leaving no value imports for types and ensuring emitted ESM matches the developer’s intent without ambiguity.
