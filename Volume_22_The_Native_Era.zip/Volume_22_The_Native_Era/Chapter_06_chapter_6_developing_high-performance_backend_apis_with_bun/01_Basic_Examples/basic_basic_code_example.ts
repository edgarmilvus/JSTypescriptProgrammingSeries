/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Backend API - Basic Bun HTTP Server
 * File: index.ts
 * Runtime: Bun (native TypeScript execution)
 */

// 1. Import the Bun global `Bun` namespace and `Server` type from Bun's built-in APIs
import type { Server } from "bun";

/**
 * 2. Define a minimal SaaS context interface to illustrate typed routing
 */
interface SaaSContext {
  tenantId: string;
  environment: "production" | "staging" | "dev";
}

/**
 * 3. Create a basic configuration object representing our SaaS deployment
 */
const saasConfig: SaaSContext = {
  tenantId: "tenant_001",
  environment: "production",
};

/**
 * 4. Initialize the Bun HTTP server using Bun.serve()
 * This method creates a high-performance HTTP/1.1 and HTTP/2 capable server
 * backed by Bun's native Swift-based networking layer (not Node.js libuv).
 */
const server: Server = Bun.serve({
  // 5. Port binding for the SaaS API
  port: 3000,

  // 6. Hostname binding (0.0.0.0 allows external access in containerized envs)
  hostname: "0.0.0.0",

  /**
   * 7. Request handler function
   * This async function receives a standard Request object and returns a Response.
   * Bun uses the Web Standard Fetch API model, reducing context-switching for frontend devs.
   */
  async fetch(request: Request): Promise<Response> {
    // 8. Extract the URL from the incoming request
    const url = new URL(request.url);

    // 9. Route: Health check endpoint for uptime monitoring
    if (url.pathname === "/api/health") {
      return new Response(
        JSON.stringify({
          status: "ok",
          tenantId: saasConfig.tenantId,
          environment: saasConfig.environment,
          runtime: "bun",
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    // 10. Route: User greeting endpoint (simulated SaaS personalization)
    if (url.pathname === "/api/greet") {
      // 11. Parse query parameter for username
      const username = url.searchParams.get("user") ?? "anonymous";

      // 12. Construct a SaaS-style greeting response
      return new Response(
        JSON.stringify({
          message: `Hello ${username}, welcome to Tenant ${saasConfig.tenantId}!`,
          timestamp: new Date().toISOString(),
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    // 13. Fallback route for unmatched paths
    return new Response("Not Found", { status: 404 });
  },
});

/**
 * 14. Log server startup details to stdout
 * Bun writes to stdout efficiently via native syscalls.
 */
console.log(`SaaS API running at http://${server.hostname}:${server.port}`);
