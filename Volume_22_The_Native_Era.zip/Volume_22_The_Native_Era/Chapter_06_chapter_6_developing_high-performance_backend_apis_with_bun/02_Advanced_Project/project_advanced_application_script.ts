/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * SaaS Supervisor Node for Agentic Workflows on Bun
 * Demonstrates Exhaustive Asynchronous Resilience and JSON Schema Output enforcement.
 */

import { z } from "zod"; // Bun supports native ESM imports of Zod without config

/**
 * JSON Schema Output contract for LLM routing decisions.
 * We mirror this with Zod for runtime validation.
 */
const RoutingSchema = z.object({
  nextAgent: z.enum(["BillingAgent", "SupportAgent", "AnalyticsAgent"]),
  confidence: z.number().min(0).max(1),
  reason: z.string().min(1),
});

type RoutingDecision = z.infer<typeof RoutingSchema>;

/**
 * Simulated Graph State shared across the multi-agent system.
 */
interface GraphState {
  ticketId: string;
  userTier: "free" | "pro" | "enterprise";
  message: string;
  attempts: number;
}

/**
 * Mock LLM call returning raw JSON (simulates JSON Schema Output mode).
 * In reality, this would be `fetch("https://api.llm.dev/v1/chat", ...)`
 */
async function callLLMForRouting(state: GraphState): Promise<unknown> {
  // Simulate latency and occasional failure
  await new Promise((r) => setTimeout(r, 50));
  if (state.attempts > 2) throw new Error("LLM quota exceeded");
  return {
    nextAgent: state.userTier === "enterprise" ? "SupportAgent" : "BillingAgent",
    confidence: 0.92,
    reason: "Enterprise users routed to priority support",
  };
}

/**
 * Supervisor Node: routes tasks with exhaustive async resilience.
 * @param state - Current Graph State
 * @returns Validated RoutingDecision or null on graceful failure
 */
async function supervisorRoute(state: GraphState): Promise<RoutingDecision | null> {
  let connection: { close: () => void } | null = null;

  try {
    // 1. Acquire pseudo-resource (e.g., trace connection)
    connection = { close: () => console.log("Trace closed") };

    // 2. Call LLM with JSON Schema Output expectation
    const raw = await callLLMForRouting(state);

    // 3. Validate against JSON Schema (Zod)
    const parsed = RoutingSchema.safeParse(raw);
    if (!parsed.success) {
      throw new Error("Invalid JSON Schema Output from LLM");
    }

    // 4. Return validated decision
    return parsed.data;
  } catch (err) {
    // 5. Graceful degradation + logging
    console.error("[Supervisor] Routing failed:", (err as Error).message);
    return null;
  } finally {
    // 6. Mandatory cleanup regardless of outcome
    connection?.close();
  }
}

// 7. Bun-native HTTP server exposing the supervisor
Bun.serve({
  port: 3000,
  async fetch(req) {
    const state: GraphState = {
      ticketId: "T-123",
      userTier: "enterprise",
      message: "Urgent API outage",
      attempts: 1,
    };

    const decision = await supervisorRoute(state);
    return new Response(JSON.stringify(decision), {
      headers: { "Content-Type": "application/json" },
    });
  },
});
