/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// server.ts
// Bun's native Response object implements the Web Standard Fetch API Response interface.
// This makes it compliant with browsers, workers, and edge runtimes (e.g., Cloudflare Workers),
// improving interoperability because the same code can run client-side, server-side, or at the edge.

const users = new Map<number, string>([
  [1, "Alice"],
  [2, "Bob"],
]);

Bun.serve({
  port: 3000,
  fetch(request: Request): Response {
    const url = new URL(request.url);
    const path = url.pathname;
    console.log(`${request.method} ${path}`);

    // Health check route
    if (request.method === "GET" && path === "/health") {
      return new Response(
        JSON.stringify({ status: "ok", runtime: "bun" }),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    // Dynamic user lookup: /users/:id
    if (request.method === "GET" && path.startsWith("/users/")) {
      const id = Number(path.split("/")[2]);
      if (Number.isNaN(id)) {
        return new Response("Invalid ID", { status: 400 });
      }
      const name = users.get(id);
      if (!name) {
        return new Response("User not found", { status: 404 });
      }
      return new Response(
        JSON.stringify({ id, name }),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    return new Response("Not Found", { status: 404 });
  },
});
