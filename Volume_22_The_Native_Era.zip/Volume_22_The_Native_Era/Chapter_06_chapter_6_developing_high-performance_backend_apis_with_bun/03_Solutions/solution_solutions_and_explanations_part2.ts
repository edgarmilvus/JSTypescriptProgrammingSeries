/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// primes.ts
// Edge-First Deployment Strategy: moving pre-computation to an edge function means heavy work
// happens once per edge node boot, not per user request, slashing latency for global users.

function computePrimes(limit: number): number[] {
  const primes: number[] = [];
  for (let n = 2; n <= limit; n++) {
    let isPrime = true;
    for (let d = 2; d * d <= n; d++) {
      if (n % d === 0) { isPrime = false; break; }
    }
    if (isPrime) primes.push(n);
  }
  return primes;
}

// Pre-compute once at module load (server boot)
const FAST_PRIMES = computePrimes(100000);

Bun.serve({
  port: 3000,
  fetch(request: Request): Response {
    const url = new URL(request.url);

    if (url.pathname === "/primes-slow") {
      const start = performance.now();
      const data = computePrimes(100000);
      const time = performance.now() - start;
      return new Response(JSON.stringify(data), {
        headers: {
          "Content-Type": "application/json",
          "X-Compute-Time": time.toFixed(2),
        },
      });
    }

    if (url.pathname === "/primes-fast") {
      const start = performance.now();
      const data = FAST_PRIMES; // memory access only
      const time = performance.now() - start;
      return new Response(JSON.stringify(data), {
        headers: {
          "Content-Type": "application/json",
          "X-Compute-Time": time.toFixed(2),
        },
      });
    }

    return new Response("Not Found", { status: 404 });
  },
});
