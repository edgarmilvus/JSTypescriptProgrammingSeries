/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// UserNameEditor.tsx (frontend contract)
// Optimistic UI reduces perceived latency by showing the result before server confirmation.
// Bun's fast native JSON parsing minimizes round-trip overhead, helping the confirm/revert cycle.

/*
interface UserNameEditorProps {
  userId: number;
  initialName: string;
}

Behavior:
- Render <input> with initialName and a Save button.
- On click: setLocalName(newName) immediately (optimistic).
- fetch(`/users/${userId}`, { method: "PATCH", body: JSON.stringify({ name: newName }) })
- On non-OK: setLocalName(initialName) and show error.
*/

// server.ts (backend contract)
// PATCH /users/:id
/*
const users = new Map<number, string>([[1, "Alice"]]);
Bun.serve({
  fetch: async (req) => {
    const url = new URL(req.url);
    if (req.method === "PATCH" && url.pathname.startsWith("/users/")) {
      const id = Number(url.pathname.split("/")[2]);
      const body = await req.json() as { name: string };
      if (!users.has(id)) return new Response("404", { status: 404 });
      users.set(id, body.name);
      return Response.json({ id, name: body.name });
    }
  }
});
*/
