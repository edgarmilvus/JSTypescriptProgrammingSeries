/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * hello_saas.ts
 * A minimal Deno 2+ "Hello World" style example for a SaaS tenant welcome flow.
 * Demonstrates: native import, permission model, generics, and std lib usage.
 */

// 1. Native import from Deno's standard library via URL (no package manager needed)
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

// 2. Define a generic interface for a SaaS tenant record
//    Generics (<T>) allow the same shape to carry different metadata types
interface Tenant<T> {
  id: string;
  name: string;
  meta: T;
}

// 3. Concrete metadata type for our demo
type WelcomeMeta = {
  plan: "free" | "pro" | "enterprise";
  region: string;
};

// 4. Create a typed tenant using the generic Tenant interface
const demoTenant: Tenant<WelcomeMeta> = {
  id: "tnt_001",
  name: "Acme Analytics",
  meta: {
    plan: "pro",
    region: "eu-central",
  },
};

// 5. Generic function that formats a welcome message for any tenant type
//    The <T> ensures the input tenant type matches the return string context
function formatWelcome<T>(tenant: Tenant<T>): string {
  return `Hello ${tenant.name} (${tenant.id})! Welcome to our SaaS.`;
}

// 6. Start a native HTTP server using Deno's std http serve
//    This requires the --allow-net flag at runtime
const handler = (request: Request): Response => {
  // 7. Build a JSON response containing the welcome message
  const message = formatWelcome(demoTenant);
  const payload = {
    tenant: demoTenant,
    message,
    timestamp: new Date().toISOString(),
  };

  return new Response(JSON.stringify(payload, null, 2), {
    headers: { "content-type": "application/json" },
  });
};

// 8. Serve the handler on port 8000
console.log("SaaS welcome service running on http://localhost:8000");
serve(handler, { port: 8000 });
