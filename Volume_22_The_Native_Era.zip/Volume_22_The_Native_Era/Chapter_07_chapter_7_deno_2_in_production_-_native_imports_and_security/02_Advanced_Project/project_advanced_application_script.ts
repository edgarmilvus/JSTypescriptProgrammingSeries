/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Deno 2+ Production Webhook Processor for SaaS CRM
 * Uses native imports, security flags, and V8-compiled TS.
 */

// 1. Native remote import of standard crypto module (no bundler needed)
import { crypto } from "https://deno.land/std@0.200.0/crypto/mod.ts";

// 2. Native import of environment access (granted via --allow-env)
import { env } from "https://deno.land/std@0.200.0/dotenv/mod.ts";

// 3. Define JSDoc interface for inbound webhook payload
/** @interface WebhookEvent Shape of third-party webhook from provider */
interface WebhookEvent {
  id: string;
  tenantId: string;
  eventType: "invoice.paid" | "user.created";
  payload: Record<string, unknown>;
  signature: string;
}

// 4. Load tenant-specific policy from local file (granted via --allow-read)
/** @function loadPolicy Reads JSON policy for tenant isolation */
async function loadPolicy(tenantId: string): Promise<{ allowedEvents: string[] }> {
  // Read static policy file using Deno native FS
  const raw = await Deno.readTextFile("./policies.json");
  const all = JSON.parse(raw);
  return all[tenantId] ?? { allowedEvents: [] };
}

// 5. Verify HMAC signature using V8-optimized crypto
/** @function verifySignature Ensures webhook integrity */
async function verifySignature(ev: WebhookEvent, secret: string): Promise<boolean> {
  const data = `${ev.id}.${ev.eventType}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
  const hex = Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
  return hex === ev.signature;
}

// 6. Send event to internal DB via allowed net host
/** @function storeEvent Persists to SaaS internal DB */
async function storeEvent(ev: WebhookEvent): Promise<void> {
  const dbHost = "db.saas.internal";
  await fetch(`https://${dbHost}/v1/events`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(ev)
  });
}

// 7. Main handler invoked by Next.js Server Action (via Deno runtime)
/** @function handleWebhook Core logic with granular permission use */
export async function handleWebhook(req: Request): Promise<Response> {
  // Parse request as WebhookEvent
  const ev: WebhookEvent = await req.json();
  // Load env secret (Deno permission --allow-env)
  const secret = env.get("webhook_secret") ?? "";
  // Policy check for tenant
  const policy = await loadPolicy(ev.tenantId);
  if (!policy.allowedEvents.includes(ev.eventType)) {
    return new Response("Forbidden", { status: 403 });
  }
  // Signature verification
  if (!await verifySignature(ev, secret)) {
    return new Response("Unauthorized", { status: 401 });
  }
  // Store securely
  await storeEvent(ev);
  return new Response("OK", { status: 200 });
}

// 8. Deno native server bootstrap (no transpile)
if (import.meta.main) {
  Deno.serve({ port: 8000 }, handleWebhook);
}
