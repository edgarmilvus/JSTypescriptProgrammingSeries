/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// main.ts - entrypoint (pseudo-structured, not fully implemented)
// Import remote utility via full HTTPS URL (cached + integrity-checked)
import { getRates } from "https://deno.land/x/rates@2.1.0/mod.ts";

// Import local config loader
import { loadConfig } from "./config.ts";

// Read only allowed env vars
const PORT = Number(Deno.env.get("PORT"));
const CONFIG_PATH = Deno.env.get("CONFIG_PATH")!;

// Load local config (scoped read)
const config = await loadConfig(CONFIG_PATH);

// Serve HTTP on fixed port (scoped net listen)
Deno.serve({ port: PORT }, async (req) => {
  // Fetch from single trusted API (scoped net fetch)
  const rates = await getRates("https://api.trusted-rates.com/v1");
  return new Response(JSON.stringify({ config, rates }), {
    headers: { "content-type": "application/json" },
  });
});

/*
Required CLI flags (scoped vs global):
--allow-read=/etc/app/config.json        (scoped read)
--allow-net=api.trusted-rates.com,localhost  (scoped net: remote API + listen)
--allow-env=PORT,CONFIG_PATH             (scoped env)
(NO --allow-write, NO --allow-run)
*/
