/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal cross-runtime SaaS status service using Hono + UnJS.
 * Runs natively on Node.js, Bun, and Deno without bundlers.
 */

// Import Hono core (works on all runtimes via its built-in adapters)
import { Hono } from 'hono';

// Import UnJS universal deep-merge utility (runtime-agnostic)
import { defu } from 'defu';

/**
 * JSDoc: ImmutableConfig
 * Represents an immutable base configuration for our SaaS service.
 * Once defined, it should never be mutated in place.
 */
interface ImmutableConfig {
  readonly serviceName: string;
  readonly version: string;
  readonly features: ReadonlyArray<string>;
}

/**
 * JSDoc: createBaseConfig
 * Returns a frozen base configuration object.
 * Object.freeze prevents accidental mutation (shallow, but enough for demo).
 */
function createBaseConfig(): ImmutableConfig {
  return Object.freeze({
    serviceName: 'NativeSaaS',
    version: '1.0.0',
    features: ['auth', 'billing'] as const,
  });
}

/**
 * JSDoc: mergeConfig
 * Uses UnJS defu to immutably merge user config with base config.
 * Returns a NEW object; original configs are not modified.
 */
function mergeConfig(userConfig: Partial<ImmutableConfig>): ImmutableConfig {
  const base = createBaseConfig();
  // defu creates a new merged object (no in-place mutation)
  const merged = defu(userConfig, base) as ImmutableConfig;
  return Object.freeze(merged);
}

// Initialize Hono app (no platform-specific imports needed)
const app = new Hono();

// Define a GET route for SaaS health status
app.get('/api/status', (c) => {
  // Create an immutable merged config for this request
  const config = mergeConfig({ version: '1.0.1' });

  // Build response payload (new object, no mutation of config)
  const payload = {
    ok: true,
    service: config.serviceName,
    version: config.version,
    features: [...config.features, 'metrics'], // new array, not mutated
    runtime: typeof process !== 'undefined' ? 'node-or-bun' : 'deno',
  };

  // Return JSON response (Hono handles content-type natively)
  return c.json(payload);
});

// Start server based on runtime (Hono's serve works everywhere)
export default app;
