/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file advanced-chat-reconciliation.ts
 * @description Cross-runtime compatible optimistic UI reconciliation for a SaaS support chat.
 * Uses UnJS-style universal helpers and Hono-compatible interfaces.
 */

// ----------------------------------------------------------------------------
// 1. UNJS-STYLE UNIVERSAL TYPES & TYPE GUARDS
// ----------------------------------------------------------------------------

/**
 * Represents a chat message in the SaaS support console.
 */
interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  /** Present only after server/local confirmation */
  confirmedAt?: number;
}

/**
 * Shape of an optimistic (tentative) message sent by the client.
 */
interface OptimisticMessage extends ChatMessage {
  confirmedAt: undefined;
}

/**
 * Shape of a confirmed message returned by local AI or server.
 */
interface ConfirmedMessage extends ChatMessage {
  confirmedAt: number;
}

/**
 * User-defined type guard: narrows a ChatMessage to a ConfirmedMessage.
 * @param msg The message to inspect
 * @returns true if msg is a confirmed message with a numeric confirmedAt
 */
function isConfirmed(msg: ChatMessage): msg is ConfirmedMessage {
  // Runtime check using typeof to guarantee type within this scope
  return typeof msg.confirmedAt === 'number';
}

// ----------------------------------------------------------------------------
// 2. UNJS UNIVERSAL ENV DETECTION (no node:Deno:Bun specifics)
// ----------------------------------------------------------------------------

/**
 * Universal runtime identifier (works on Node, Bun, Deno).
 * Uses globalThis checks instead of process or Deno namespaces.
 */
type Runtime = 'node' | 'bun' | 'deno' | 'unknown';

function detectRuntime(): Runtime {
  // typeof checks are safe across all JS runtimes
  if (typeof (globalThis as any).Bun !== 'undefined') return 'bun';
  if (typeof (globalThis as any).Deno !== 'undefined') return 'deno';
  if (typeof (globalThis as any).process !== 'undefined') return 'node';
  return 'unknown';
}

// ----------------------------------------------------------------------------
// 3. HONO-COMPATIBLE CONTEXT SHAPE (for future edge migration)
// ----------------------------------------------------------------------------

/**
 * Minimal Hono-style context binding for cross-runtime HTTP handling.
 */
interface HonoLikeCtx {
  req: { json: () => Promise<unknown> };
  json: (data: unknown, status?: number) => void;
}

// ----------------------------------------------------------------------------
// 4. CORE RECONCILIATION LOGIC (Optimistic UI)
// ----------------------------------------------------------------------------

/**
 * Reconciles an optimistic message with the confirmed state.
 * @param optimistic The tentative UI message
 * @param actual The post-inference result
 * @returns The resolved ChatMessage (either corrected or confirmed)
 */
function reconcile(
  optimistic: OptimisticMessage,
  actual: ChatMessage
): ChatMessage {
  // Type guard ensures we can safely access confirmedAt
  if (isConfirmed(actual)) {
    // No discrepancy: return confirmed
    return actual;
  }
  // Discrepancy: server returned unconfirmed (rare) – fallback
  return { ...optimistic, content: actual.content };
}

// ----------------------------------------------------------------------------
// 5. MOCK LOCAL AI INFERENCE (runtime-agnostic)
// ----------------------------------------------------------------------------

/**
 * Simulates local AI inference (could be a WASM model in Bun/Deno).
 * @param text User input
 * @returns A confirmed assistant message
 */
async function localInfer(text: string): Promise<ConfirmedMessage> {
  // Universal await – no transpile needed
  await new Promise((r) => setTimeout(r, 10));
  return {
    id: crypto.randomUUID(),
    role: 'assistant',
    content: `Local AI: ${text.slice(0, 20)}…`,
    confirmedAt: Date.now(),
  };
}

// ----------------------------------------------------------------------------
// 6. NEXT.JS SERVER ACTION (also usable in Hono handler)
// ----------------------------------------------------------------------------

/**
 * Server Action invoked from a Client Component.
 * @param optimisticMsg Optimistic message from UI
 */
export async function submitSupportChat(
  optimisticMsg: OptimisticMessage
): Promise<ChatMessage> {
  const rt = detectRuntime(); // 'node' in Next.js
  // Run background computation (local AI or remote)
  const result = await localInfer(optimisticMsg.content);
  // Reconcile optimistic UI with actual
  return reconcile(optimisticMsg, result);
}

// ----------------------------------------------------------------------------
// 7. HONO ADAPTER EXAMPLE (showing cross-runtime parity)
// ----------------------------------------------------------------------------

/**
 * Hono route equivalent – same logic, different shell.
 * @param ctx Hono-like context
 */
export async function honoChatRoute(ctx: HonoLikeCtx) {
  const body = (await ctx.req.json()) as OptimisticMessage;
  const out = await submitSupportChat(body);
  ctx.json(out, 200);
}
