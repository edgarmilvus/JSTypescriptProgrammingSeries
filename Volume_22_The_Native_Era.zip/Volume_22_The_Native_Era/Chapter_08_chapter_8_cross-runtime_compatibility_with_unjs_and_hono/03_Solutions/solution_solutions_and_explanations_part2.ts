/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Hono } from 'hono'
import { runtime } from 'std-env'

const app = new Hono()
let reqCount = 0

function delay(ms: number) {
  return new Promise(r => setTimeout(r, ms))
}

app.get('/health', async c => {
  try {
    await delay(50) // simulate downstream
    return c.json({
      runtime,
      uptime: process.uptime?.() ?? (performance.now() / 1000),
      randomId: crypto.randomUUID()
    })
  } catch {
    return c.body('Service unavailable', 503)
  } finally {
    reqCount++
  }
})

const server = app.listen(3000, () => console.log('Listening'))

function shutdown() {
  console.log('Cleanup')
  server.close?.()
  Deno?.close?.()
}

if (runtime === 'deno') {
  Deno.addSignalListener('SIGINT', shutdown)
} else {
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}
