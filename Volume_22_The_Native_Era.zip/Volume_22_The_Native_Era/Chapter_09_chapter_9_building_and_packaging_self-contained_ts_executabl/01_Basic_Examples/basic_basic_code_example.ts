/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Self-Contained TS Executable - Hello World SaaS Style
 * 
 * This file is intended to be compiled to a standalone binary using:
 * - Node.js: `node --experimental-sea-config` + SEA blob
 * - Bun:     `bun build --compile hello.ts`
 * - Deno:    `deno compile hello.ts`
 * 
 * No bundlers or transpilers are required beyond the runtime itself.
 */

// 1. Import only from standard runtime libraries
import http from 'node:http';

/**
 * JSON Schema definition for our greeting response.
 * In a real SaaS app this would validate LLM or API output.
 */
const GreetingSchema = {
  type: 'object',
  properties: {
    message: { type: 'string' },
    timestamp: { type: 'number' }
  },
  required: ['message', 'timestamp']
} as const;

/**
 * Type derived manually (no Zod needed for Hello World)
 */
type Greeting = {
  message: string;
  timestamp: number;
};

/**
 * 2. Core business logic: create greeting object
 * @returns {Greeting} compliant with GreetingSchema
 */
function createGreeting(): Greeting {
  // Simulate a SaaS welcome message
  const greeting: Greeting = {
    message: 'Hello from your self-contained TS executable!',
    timestamp: Date.now()
  };
  return greeting;
}

/**
 * 3. HTTP server factory
 * @param {Greeting} data - payload to send
 */
function startServer(data: Greeting): void {
  // Create server instance
  const server = http.createServer((req, res) => {
    // Set headers for JSON Schema Output compatibility
    res.writeHead(200, { 'Content-Type': 'application/json' });
    // Send serialized greeting
    res.end(JSON.stringify(data));
  });

  // Listen on port 3000 (common SaaS dev port)
  server.listen(3000, () => {
    console.log('Executable running at http://localhost:3000');
  });
}

// 4. Main execution block
const greeting = createGreeting();
startServer(greeting);
