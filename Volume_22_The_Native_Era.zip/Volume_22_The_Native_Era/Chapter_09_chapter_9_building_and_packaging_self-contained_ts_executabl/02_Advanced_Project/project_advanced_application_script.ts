/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * SaaS Billing Agent — Advanced Application Script
 * Compiled into a self-contained TS executable (Node SEA / Bun / Deno)
 * Enforces JSON Schema Output and applies Tool Use Reflection.
 */

import { z } from "zod";
import { generateObject, generateText } from "ai";
import { openai } from "@ai-sdk/openai";

// 1. Define the JSON Schema output contract for the LLM
const billingAdjustmentSchema = z.object({
  customerId: z.string().min(5),
  amount: z.number().positive(),
  currency: z.enum(["USD", "EUR", "GBP"]),
  reason: z.string().max(200),
});

type BillingAdjustment = z.infer<typeof billingAdjustmentSchema>;

// 2. Mock external billing tool (would be a DB call in real SaaS)
async function applyBillingTool(input: BillingAdjustment): Promise<{
  success: boolean;
  message: string;
}> {
  // Simulate rejection if amount exceeds policy limit
  if (input.amount > 1000) {
    return { success: false, message: "Amount exceeds max policy of 1000" };
  }
  return { success: true, message: `Applied ${input.amount} ${input.currency}` };
}

// 3. Core agent function with Tool Use Reflection loop
export async function runBillingAgent(userQuery: string) {
  // 3.1 First LLM call: enforce JSON Schema Output
  const { object: draft } = await generateObject({
    model: openai("gpt-4o"),
    schema: billingAdjustmentSchema,
    prompt: `Propose a billing adjustment for: ${userQuery}`,
  });

  // 3.2 Invoke the tool with the draft
  const observation = await applyBillingTool(draft);

  // 3.3 Tool Use Reflection: analyze observation and self-correct
  let finalAdjustment = draft;
  if (!observation.success) {
    const { text: reflection } = await generateText({
      model: openai("gpt-4o"),
      prompt: `The tool returned: ${observation.message}.
               Original draft: ${JSON.stringify(draft)}.
               Return a corrected JSON only.`,
    });
    finalAdjustment = billingAdjustmentSchema.parse(JSON.parse(reflection));
  }

  // 3.4 Return validated, reflected result
  return { finalAdjustment, observation };
}
