/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// cli.ts
// Simple CLI that prints a welcome message and reads embedded config.json

// In Node SEA, embedded assets are exposed via the 'node:sea' module (Node 20+) or
// a configured virtual path. Here we use 'node:sea' to read our injected config.
import { getAsset } from 'node:sea';
import { readFileSync } from 'node:fs';

// For older SEA versions using a require shim, you might do:
// const config = require('node:sea').getAsset('config.json', 'utf8');

function main(): void {
  console.log('Welcome to the Node SEA demo CLI!');

  // Read the embedded config asset as UTF-8 text
  const configRaw = getAsset('config.json', 'utf8');
  const config = JSON.parse(configRaw) as { appName: string; maxRetries: number };

  console.log(`App Name: ${config.appName}`);
  console.log(`Max Retries: ${config.maxRetries}`);
}

main();
