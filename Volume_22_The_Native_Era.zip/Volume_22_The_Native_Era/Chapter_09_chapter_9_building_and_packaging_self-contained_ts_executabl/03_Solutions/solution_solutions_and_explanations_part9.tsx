/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// StructuredAssistant.tsx
import React, { useEffect } from 'react';
import { useChat } from 'ai/react';
import { z } from 'zod';
import { spawn } from 'child_process';

// Zod schema derived from given JSON Schema
const ResponseSchema = z.object({
  intent: z.string(),
  confidence: z.number(),
  nextAction: z.string(),
});

export function StructuredAssistant() {
  // useChat manages conversation message state
  const { messages, input, handleInputChange, handleSubmit, append } = useChat();

  // Spawn local executable built in Exercise 2/3
  const exe = spawn('./bin/assistant', [], { stdio: ['pipe', 'pipe', 'pipe'] });

  async function sendToExe(prompt: string): Promise<unknown> {
    return new Promise((resolve) => {
      exe.stdin.write(prompt + '\n');
      exe.stdout.once('data', (d) => resolve(JSON.parse(d.toString())));
    });
  }

  // Reflection loop on user submit
  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const prompt = input;
    let raw = await sendToExe(prompt);
    // Tool Use Reflection: if Zod fails, append system error and retry
    const parsed = ResponseSchema.safeParse(raw);
    if (!parsed.success) {
      append({ role: 'system', content: `Validation error: ${parsed.error}` });
      raw = await sendToExe(`Adjust context: ${parsed.error}`);
    }
    const final = ResponseSchema.parse(raw);
    append({ role: 'assistant', content: JSON.stringify(final) });
  }

  return (
    <div>
      {messages.map((m) => (
        <div key={m.id}>{m.role}: {m.content}</div>
      ))}
      <form onSubmit={onSubmit}>
        <input value={input} onChange={handleInputChange} />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
