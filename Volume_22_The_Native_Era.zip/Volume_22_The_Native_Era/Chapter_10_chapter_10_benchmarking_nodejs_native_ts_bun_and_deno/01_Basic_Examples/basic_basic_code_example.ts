/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Tenant Greeter - Native TS Basic Example
 * Runs on Node.js 22+, Bun, and Deno without bundlers or transpilers.
 */

// 1. Import the file system module using promise-based API
// In Node.js/Bun: 'node:fs/promises' is standard.
// In Deno: 'node:fs/promises' is also supported via Node compatibility.
import { readFile } from 'node:fs/promises';

/**
 * Represents a minimal SaaS tenant configuration loaded from disk.
 */
interface TenantConfig {
  tenantId: string;
  plan: 'free' | 'pro' | 'enterprise';
}

/**
 * Loads a tenant config from a local JSON file using Non-Blocking I/O.
 * @param path - Absolute or relative path to the config file
 * @returns Promise resolving to TenantConfig
 */
async function loadTenantConfig(path: string): Promise<TenantConfig> {
  // Non-blocking: delegates file read to OS, event loop continues
  const raw: string = await readFile(path, 'utf-8');
  return JSON.parse(raw) as TenantConfig;
}

/**
 * Main entry point for the SaaS greeter.
 */
async function main(): Promise<void> {
  // Start high-resolution timer (built-in performance API)
  const start: number = performance.now();

  // Simulate SaaS multi-tenant context: load config asynchronously
  const config: TenantConfig = await loadTenantConfig('./tenant.json');

  // Compute greeting based on plan
  const greeting: string = `Hello ${config.tenantId} on ${config.plan} plan!`;

  // Log output (non-blocking stdout under the hood)
  console.log(greeting);

  // End timer and print execution duration
  const duration: number = performance.now() - start;
  console.log(`Executed in ${duration.toFixed(2)}ms`);
}

// Execute main and catch any errors (e.g., missing file)
main().catch((err: unknown) => {
  console.error('Failed to start SaaS greeter:', err);
  process.exit(1);
});
