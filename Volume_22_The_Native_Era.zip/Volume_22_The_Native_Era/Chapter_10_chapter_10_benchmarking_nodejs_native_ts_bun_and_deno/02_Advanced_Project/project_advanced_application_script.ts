/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Benchmark harness for native TS runtimes (Node/Bun/Deno)
 * Context: SaaS semantic search via Pinecone + WASM fallback
 */

// Generic wrapper to preserve input/output types across benchmarks
type BenchmarkResult<T> = {
  runtime: string;
  durationMs: number;
  memoryMb: number;
  payload: T;
};

// Minimal Pinecone client shape (official SDK is similar)
interface PineconeClient {
  query(index: string, vector: number[]): Promise<{ matches: number[] }>;
}

// WASM similarity module (compiled from Rust/C)
interface WasmSimilarity {
  cosine(a: Float64Array, b: Float64Array): number;
}

// 1. Runtime detector (works natively in Node/Bun/Deno)
function detectRuntime(): string {
  // @ts-ignore - Deno global
  if (typeof Deno !== 'undefined') return 'Deno';
  // @ts-ignore - Bun global
  if (typeof Bun !== 'undefined') return 'Bun';
  return 'Node.js';
}

// 2. Mock Pinecone client factory (swap with real SDK in prod)
function createPinecone(): PineconeClient {
  return {
    async query(_index: string, vec: number[]) {
      // Simulate network + index latency
      await new Promise(r => setTimeout(r, 15));
      return { matches: vec.map(v => v * 0.99) };
    }
  };
}

// 3. Load WASM (dynamic import works natively in all three)
async function loadWasm(): Promise<WasmSimilarity> {
  // In real case: await WebAssembly.instantiateStreaming(fetch('./sim.wasm'))
  return {
    cosine: (a, b) => {
      let dot = 0, na = 0, nb = 0;
      for (let i = 0; i < a.length; i++) {
        dot += a[i] * b[i]; na += a[i] ** 2; nb += b[i] ** 2;
      }
      return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
  };
}

// 4. Generic benchmark executor with memory sampling
async function runBenchmark<T>(
  fn: () => Promise<T>,
  runtime: string
): Promise<BenchmarkResult<T>> {
  const start = performance.now();
  const before = process.memoryUsage?.().heapUsed ?? 0;
  const payload = await fn();
  const after = process.memoryUsage?.().heapUsed ?? 0;
  const durationMs = performance.now() - start;
  return {
    runtime,
    durationMs,
    memoryMb: (after - before) / 1024 / 1024,
    payload
  };
}

// 5. Main SaaS routine: hybrid Pinecone + WASM re-rank
async function saasSearch(
  pc: PineconeClient,
  wasm: WasmSimilarity,
  queryVec: number[]
): Promise<number[]> {
  const res = await pc.query('prod-index', queryVec);
  const ref = Float64Array.from(queryVec);
  const reranked = res.matches
    .map(m => wasm.cosine(ref, Float64Array.from([m])))
    .sort((a, b) => b - a);
  return reranked;
}

// 6. Orchestration
(async () => {
  const rt = detectRuntime();
  const pc = createPinecone();
  const wasm = await loadWasm();
  const vec = Array.from({ length: 128 }, () => Math.random());

  const result = await runBenchmark(
    () => saasSearch(pc, wasm, vec),
    rt
  );

  console.log(JSON.stringify(result, null, 2));
})();
