/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// memory-test.ts
interface GraphState {
  id: number;
  payload: string[];
}

// Snapshot before allocation (Node/Bun global; Deno uses Deno.memoryUsage)
const before = (globalThis as any).Deno
  ? (globalThis as any).Deno.memoryUsage().heapUsed
  : process.memoryUsage().heapUsed;

const states: GraphState[] = [];
for (let i = 0; i < 100000; i++) {
  states.push({ id: i, payload: Array.from({ length: 10 }, () => 'x') });
}

const after = (globalThis as any).Deno
  ? (globalThis as any).Deno.memoryUsage().heapUsed
  : process.memoryUsage().heapUsed;

console.log(`Heap delta: ${(after - before) / 1024 / 1024} MB`);

// Optional GC if exposed (node --expose-gc)
if (typeof global !== 'undefined' && (global as any).gc) {
  (global as any).gc();
  const postGc = (globalThis as any).Deno
    ? (globalThis as any).Deno.memoryUsage().heapUsed
    : process.memoryUsage().heapUsed;
  console.log(`Post-GC heap: ${postGc / 1024 / 1024} MB`);
}
