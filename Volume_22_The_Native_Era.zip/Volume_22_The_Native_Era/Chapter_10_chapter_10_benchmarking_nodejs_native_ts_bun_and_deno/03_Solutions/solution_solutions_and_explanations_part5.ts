/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// consensus-bench.ts
interface GraphState {
  responses: string[];
  finalized: string;
}

async function worker(id: number): Promise<string> {
  await new Promise(r => setTimeout(r, 50));
  return `Worker ${id} done`;
}

function supervisor(state: GraphState): void {
  state.finalized = state.responses.join(', ');
}

async function main() {
  for (const count of [2, 4, 6, 8, 10]) {
    const start = performance.now();
    const state: GraphState = { responses: [], finalized: '' };
    state.responses = await Promise.all(
      Array.from({ length: count }, (_, i) => worker(i))
    );
    supervisor(state);
    console.log(`Workers: ${count}, Time: ${performance.now() - start}ms`);
  }
}
main();
