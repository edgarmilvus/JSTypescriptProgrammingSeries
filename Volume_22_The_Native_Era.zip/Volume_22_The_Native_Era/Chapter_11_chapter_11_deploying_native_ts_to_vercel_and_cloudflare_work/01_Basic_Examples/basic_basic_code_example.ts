/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// api/hello.ts
/**
 * Native TypeScript Vercel Serverless Function (Node.js runtime).
 * No bundler or transpiler step is required; Vercel executes this directly.
 */

// Import the Vercel request/response types for type safety
import type { VercelRequest, VercelResponse } from '@vercel/node';

// We declare a constant for our SaaS product name
const SAAS_PRODUCT_NAME = 'CloudTag';

/**
 * Default export required by Vercel for serverless functions.
 * @param req - Incoming HTTP request
 * @param res - Outgoing HTTP response
 */
export default function handler(req: VercelRequest, res: VercelResponse) {
  // 1. Set CORS header to allow our frontend origin (simplified for demo)
  res.setHeader('Access-Control-Allow-Origin', '*');

  // 2. Check if the request method is GET; otherwise return 405
  if (req.method !== 'GET') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  // 3. (Conceptual) Allocate a SharedArrayBuffer for future WASM threading
  //    Not used in Hello World but shows awareness of SAB in native TS
  const sab = new SharedArrayBuffer(1024);
  const view = new Int32Array(sab);
  view[0] = 0; // dummy write to demonstrate SAB usage

  // 4. Construct a JSON payload with a greeting and a seed prompt
  const payload = {
    message: `Hello from ${SAAS_PRODUCT_NAME} API!`,
    seedPrompt: `Write a one-line tagline for ${SAAS_PRODUCT_NAME}, a tool for auto-generating social posts.`
  };

  // 5. Send the JSON response with a 200 status
  res.status(200).json(payload);
}
