/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
/**
 * Native TypeScript React component for Vercel deployment.
 * Uses the Vercel AI SDK useCompletion hook to generate a tagline.
 */

// Import React hooks
import React, { useState } from 'react';
// Import the useCompletion hook from Vercel AI SDK
import { useCompletion } from 'ai/react';

/**
 * Main page component for our SaaS landing page.
 * @returns JSX.Element
 */
export default function HomePage(): JSX.Element {
  // 1. Local state to store the API greeting
  const [greeting, setGreeting] = useState<string>('Loading...');

  // 2. Initialize the useCompletion hook for AI tagline generation
  const { completion, complete, isLoading } = useCompletion({
    api: '/api/generate', // we will assume this route exists elsewhere
  });

  // 3. Fetch greeting from our Hello World API on mount
  React.useEffect(() => {
    fetch('/api/hello')
      .then((r) => r.json())
      .then((data: { message: string; seedPrompt: string }) => {
        setGreeting(data.message);
        // 4. Automatically trigger AI completion with the seed prompt
        complete(data.seedPrompt);
      })
      .catch(() => setGreeting('Failed to load'));
  }, [complete]);

  // 5. Render the SaaS UI
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>{greeting}</h1>
      <section>
        <h2>AI-Generated Tagline</h2>
        {isLoading ? <p>Generating...</p> : <p>{completion || 'No tagline yet'}</p>}
      </section>
    </main>
  );
}
