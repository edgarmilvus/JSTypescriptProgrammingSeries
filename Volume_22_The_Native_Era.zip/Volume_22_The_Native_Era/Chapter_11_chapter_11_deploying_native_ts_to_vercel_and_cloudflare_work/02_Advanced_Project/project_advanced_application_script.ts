/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /app/api/digest/route.ts
// Native Edge Route Handler (Vercel + Cloudflare Workers compatible)
// No bundler or transpiler required; runs as pure TypeScript on edge runtimes.

import { NextRequest, NextResponse } from 'next/server';
import { AIState, createAIState } from '@vercel/ai'; // Conceptual server state
import { readFile } from 'node:fs/promises'; // Allowed in Vercel Edge with native Node compat

/**
 * JSDoc: WASM Interface for the lexical tokenizer compiled from Rust.
 * Exposes a single exported function `tokenize(ptr: number, len: number): number`.
 */
interface WasmTokenizer {
  memory: WebAssembly.Memory;
  tokenize(inputPtr: number, inputLen: number): number;
}

/**
 * JSDoc: AIStateShape defines the structure of our server-side AIState.
 * It captures the model's understanding, raw output, and tool invocation metadata.
 */
type AIStateShape = {
  reportId: string;
  rawOutput: string;
  toolCalls: Array<{ name: string; args: unknown }>;
  sanitizedTokens: number;
};

// Module-level cache for the WASM instance (edge-friendly singleton)
let tokenizerInstance: WasmTokenizer | null = null;

/**
 * Loads and instantiates the WASM tokenizer from the native filesystem.
 * On Vercel/Cloudflare this resolves via the platform's edge asset layer.
 */
async function loadTokenizer(): Promise<WasmTokenizer> {
  if (tokenizerInstance) return tokenizerInstance;
  // Read the compiled .wasm binary as a Uint8Array
  const wasmBinary = await readFile('./lib/tokenizer.wasm');
  const { instance } = await WebAssembly.instantiate(wasmBinary, {});
  tokenizerInstance = instance.exports as unknown as WasmTokenizer;
  return tokenizerInstance;
}

/**
 * Sanitizes and tokenizes a raw report string using WASM for near-native speed.
 * Returns the token count to be stored in AIState.
 */
async function sanitizeWithWasm(report: string): Promise<number> {
  const tokenizer = await loadTokenizer();
  const encoder = new TextEncoder();
  const inputBytes = encoder.encode(report);
  // Allocate memory in the WASM linear memory
  const ptr = tokenizer.memory.grow(1) * 65536;
  new Uint8Array(tokenizer.memory.buffer, ptr, inputBytes.length).set(inputBytes);
  // Call the exported tokenize function
  const tokenCount = tokenizer.tokenize(ptr, inputBytes.length);
  return tokenCount;
}

/**
 * POST handler for /api/digest
 * Receives a report, sanitizes it via WASM, and initializes AIState.
 */
export async function POST(req: NextRequest) {
  // 1. Parse the incoming SaaS request body
  const { reportId, reportText } = await req.json<{ reportId: string; reportText: string }>();

  // 2. Run WASM-accelerated preprocessing at the edge
  const tokenCount = await sanitizeWithWasm(reportText);

  // 3. Initialize the conceptual AIState for this session
  const state: AIState<AIStateShape> = createAIState({
    reportId,
    rawOutput: '',
    toolCalls: [],
    sanitizedTokens: tokenCount,
  });

  // 4. Return the seeded state and token count to the client
  return NextResponse.json({
    aiState: state.get(),
    message: 'Sanitization complete. Ready for useCompletion.',
  });
}
