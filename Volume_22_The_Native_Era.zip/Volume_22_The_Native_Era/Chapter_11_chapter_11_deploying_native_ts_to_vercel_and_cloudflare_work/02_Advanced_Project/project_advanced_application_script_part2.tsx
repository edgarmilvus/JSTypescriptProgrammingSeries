/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// /app/components/ReportDigest.tsx
// Client component using the useCompletion hook (no transpile step needed)

'use client';
import { useCompletion } from '@vercel/ai/react';
import { useState } from 'react';

/**
 * JSDoc: ReportDigest component enables users to summarize reports
 * using edge-preprocessed data and the Vercel AI SDK useCompletion hook.
 */
export function ReportDigest({ reportId }: { reportId: string }) {
  // 1. Local state to hold the raw report text from the SaaS UI
  const [reportText, setReportText] = useState('');

  // 2. useCompletion configured for single-output summarization
  const { completion, complete, isLoading } = useCompletion({
    api: '/api/digest',
    onResponse: (res) => {
      // 3. Side-effect: log edge AIState acknowledgement
      console.log('Edge sanitization acknowledged:', res.status);
    },
  });

  // 4. Handler to submit the report and trigger summarization
  async function handleSummarize() {
    await fetch('/api/digest', {
      method: 'POST',
      body: JSON.stringify({ reportId, reportText }),
    });
    // 5. Invoke the completion with a strict summarization prompt
    await complete(`Summarize the following tokenized report: ${reportText}`);
  }

  return (
    <div className="saas-panel">
      <textarea
        value={reportText}
        onChange={(e) => setReportText(e.target.value)}
        placeholder="Paste quarterly report..."
      />
      <button onClick={handleSummarize} disabled={isLoading}>
        {isLoading ? 'Summarizing...' : 'Generate Summary'}
      </button>
      <pre>{completion}</pre>
    </div>
  );
}
