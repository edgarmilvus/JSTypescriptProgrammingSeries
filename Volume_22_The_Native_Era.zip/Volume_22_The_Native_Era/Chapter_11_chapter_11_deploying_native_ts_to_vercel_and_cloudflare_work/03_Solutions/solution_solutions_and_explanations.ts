/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// api/health.ts
import type { VercelRequest, VercelResponse } from '@vercel/node';

/*
 * WHY process.env TYPING IS UNSAFE:
 * In Node.js, `process.env` is typed as `Record<string, string | undefined>` by
 * @types/node, but this is a compile-time illusion. Environment variables are
 * injected at runtime by the platform (Vercel). A missing or malformed variable
 * will not be caught by `tsc` strict mode because the type system assumes the
 * key exists with a string value. Our `assertEnv` guard performs an explicit
 * runtime check to mitigate this and prevents silent failures in production.
 */

function assertEnv(): { keyPresent: boolean } {
  const requiredKey = process.env.REQUIRED_API_KEY;
  return {
    keyPresent: typeof requiredKey === 'string' && requiredKey.length > 0
  };
}

export default async function handler(
  _req: VercelRequest,
  res: VercelResponse
): Promise<void> {
  const { keyPresent } = assertEnv();
  const region = process.env.VERCEL_REGION;

  res.status(200).json({
    region,
    keyPresent,
    tsNative: true
  });
}
