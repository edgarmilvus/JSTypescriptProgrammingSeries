/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// worker.ts

/*
 * V8 ISOLATE WASM VS NODE.JS WASM:
 * In Cloudflare Workers, WASM is instantiated inside a V8 isolate where memory
 * is linear and shared per isolate unless carefully scoped; there is no `fs` or
 * `Buffer`. In Node.js, WASM can load via file system or Buffer with richer
 * memory management. In Workers, `WebAssembly.Memory` must be explicitly sized
 * and reused cautiously because isolates have strict memory limits and no
 * Node-style polyfills for binary data handling.
 */

const wasmBase64 =
  'AGFzbQAAAAEAAAAAAAAAA0AgA2NvbXB1dGULAAH+Ag=='; // trivial sum_bytes modulo 256

async function getWasmInstance(): Promise<WebAssembly.Instance> {
  const binary = Uint8Array.from(atob(wasmBase64), c => c.charCodeAt(0));
  const module = await WebAssembly.compile(binary);
  return WebAssembly.instantiate(module);
}

export default {
  async fetch(request: Request): Promise<Response> {
    if (request.method !== 'POST') {
      return new Response('Method Not Allowed', { status: 405 });
    }
    const contentType = request.headers.get('content-type');
    if (contentType !== 'application/octet-stream') {
      return new Response('Unsupported Media Type', { status: 415 });
    }

    const buf: ArrayBuffer = await request.arrayBuffer();
    const bytes = new Uint8Array(buf);
    const instance = await getWasmInstance();
    // Assume export "compute" takes pointer and length, returns sum % 256
    const ptr = (instance.exports as any).alloc(bytes.length);
    (instance.exports as any).fill(ptr, bytes);
    const hash = (instance.exports as any).compute(ptr, bytes.length) as number;

    return new Response(
      JSON.stringify({ hash, bytes: bytes.length }),
      { headers: { 'content-type': 'application/json' } }
    );
  }
};
