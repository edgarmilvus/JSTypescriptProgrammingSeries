/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// ai-state.ts

export type AIState = {
  messages: {
    role: 'user' | 'assistant' | 'tool';
    content: string;
    toolName?: string;
  }[];
  bookingRef?: string;
};

export function validateAIState(s: unknown): s is AIState {
  if (typeof s !== 'object' || s === null) return false;
  const obj = s as Record<string, unknown>;
  if (!Array.isArray(obj.messages)) return false;
  for (const m of obj.messages) {
    if (typeof m.role !== 'string' || typeof m.content !== 'string') return false;
    if (m.toolName !== undefined && typeof m.toolName !== 'string') return false;
  }
  if (obj.bookingRef !== undefined && typeof obj.bookingRef !== 'string') return false;
  return true;
}

/*
 * RATIONALE: If the edge runtime evicts state after 30s, how does your AIState
 * remain consistent with the client’s React state given no bundler and no
 * external store?
 * Answer: AIState is a plain serializable object sent over the wire on every
 * streaming chunk via native ReadableStream. The client keeps the canonical
 * copy in React state; the edge only validates and echoes it. No class
 * instances are used, so structural typing + runtime validation via
 * validateAIState ensures consistency without a shared server memory.
 */

// Zero-build note: vercel.json { "buildCommand": null } or wrangler.toml without
// [build] both allow this TS module to be used natively.

/*
 * MOCK DIALOGUE:
 * Teammate: "Native TS on Edge for AIState? Sounds risky without a bundler."
 * You: "Structural typing catches shape errors at author time, and our
 *       validateAIState guard runs on every payload. Edge just streams plain
 *       JSON; React owns the state. No bundler needed."
 * Teammate: "But what about eviction?"
 * You: "Exactly why we serialize—client is source of truth, edge is stateless
 *       validator. Native TS makes that contract explicit."
 */
