/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/chat/route.ts
import type { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

// No `next build` occurs because experimental.zeroBuild (or platform zero-config)
// lets Vercel serve this TS natively on edge; Vercel AI SDK runs without bundlers.

/*
 * A React Server Component cannot inline WASM logic from Exercise 2 because RSC
 * executes in a Node/server context with different memory rules and cannot use
 * WebAssembly.Memory in the same isolate model as Workers; it must delegate to
 * this edge route which has isolate-scoped WASM support.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // Typed handler signature only; logic omitted per exercise scope
  return new NextResponse('ok');
}
