/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// deploy-matrix.ts

type Runtime = 'node' | 'bun' | 'deno' | 'worker';
type Platform = 'vercel' | 'cloudflare' | 'local';

function detectRuntime(): Runtime {
  if (typeof (globalThis as any).Bun !== 'undefined') return 'bun';
  if (typeof (globalThis as any).Deno !== 'undefined') return 'deno';
  if (typeof (globalThis as any).WorkerGlobalScope !== 'undefined') return 'worker';
  return 'node';
}

function detectPlatform(): Platform {
  if (process.env.VERCEL) return 'vercel';
  if ((globalThis as any).navigator?.userAgent?.includes('Cloudflare')) return 'cloudflare';
  return 'local';
}

/*
 * RUNTIME -> PLATFORM -> ZERO-BUILD NUANCE:
 * node    -> vercel   -> api/* uses Node default, zero-build via vercel.json
 * bun     -> local    -> Bun.serve, no build needed
 * deno    -> local    -> Deno.serve, native TS
 * worker  -> cloudflare -> wrangler entry, no package main, zero-build toml
 * vercel edge -> uses export const runtime='edge' in route files
 * Workers ignore package.json main; Bun/Deno can target both via adapters.
 */
export async function handler(): Promise<Response> {
  return new Response('ok');
}

const rt = detectRuntime();
const pf = detectPlatform();

if (rt === 'worker' || (pf === 'vercel' && rt === 'node')) {
  // For Worker or Vercel Edge, export fetch
  (globalThis as any).fetch = handler;
} else {
  // Local node/bun/deno would use their serve; omitted beyond Response
}
