/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/hello-edge/route.ts
// This file is a Next.js Edge API Route using native TypeScript ESM.
// No bundlers or transpilers are required beyond Next.js native edge support.

/**
 * JSDoc: Edge runtime configuration.
 * Tells Next.js to execute this route on the Edge Runtime (V8 isolate)
 * instead of the Node.js runtime. This reduces cold-start latency.
 */
export const runtime = 'edge';

/**
 * JSDoc: HTTP GET handler for the SaaS welcome stream.
 * @param {Request} request - The incoming Web Standard Request object.
 * @returns {Response} A streaming Response using ReadableStream.
 */
export async function GET(request: Request): Promise<Response> {
  // 1. Extract the user name from the URL query parameters.
  // In a SaaS app, this might represent a tenant or user identifier.
  const url = new URL(request.url);
  const userName = url.searchParams.get('name') ?? 'SaaS User';

  // 2. Create a ReadableStream that will push text chunks to the client.
  // This avoids buffering the entire response and improves perceived latency.
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      // 2a. Use TextEncoder to convert strings to Uint8Array (required by streams).
      const encoder = new TextEncoder();

      // 2b. First chunk: personalized greeting for the MetricFlow dashboard.
      controller.enqueue(
        encoder.encode(`Hello ${userName}, welcome to MetricFlow Edge!\n`)
      );

      // 2c. Second chunk: simulated system status line.
      controller.enqueue(
        encoder.encode('Cold-start optimized via native ESM on edge.\n')
      );

      // 2d. Close the stream to signal end-of-response.
      controller.close();
    },
  });

  // 3. Return a Response object wrapping the stream.
  // Setting appropriate headers ensures correct streaming behavior.
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-store',
    },
  });
}
