/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Next.js Edge Route Handler (app/api/agent/route.ts)
 * Demonstrates cold-start optimization for a LangGraph StateGraph on edge runtimes.
 */

// Use Edge runtime to avoid Node.js monolith cold starts and enable global scope caching
export const runtime = 'edge';

// Trim dependencies: import only the minimal LangGraph core (no bundler needed)
import { StateGraph, END, START } from '@langchain/langgraph';

/**
 * Shared Graph State shape for the ticket-triage agent.
 * Kept minimal to reduce serialization and memory footprint on cold start.
 */
interface TriageState {
  ticketText: string;
  category?: string;
  attempts: number;
  resolved: boolean;
}

/**
 * Global scope cache: on edge platforms, module scope persists across warm requests.
 * This avoids recompiling the StateGraph on every cold start after first init.
 */
declare const globalThis: {
  __triageGraph?: ReturnType<typeof buildTriageGraph>;
} & typeof global;

/**
 * Builds the cyclical StateGraph for iterative ticket categorization.
 * Uses a ReAct-like loop: classify -> check confidence -> either resolve or refine.
 */
function buildTriageGraph() {
  // 1. Initialize graph with strict state interface (no extra fields = less cold-start weight)
  const graph = new StateGraph<TriageState>({
    channels: {
      ticketText: { value: '', default: () => '' },
      category: { value: undefined, default: () => undefined },
      attempts: { value: 0, default: () => 0 },
      resolved: { value: false, default: () => false },
    },
  });

  // 2. Node: lightweight keyword classifier (no external AI call to keep cold start tiny)
  graph.addNode('classify', async (state) => {
    const text = state.ticketText.toLowerCase();
    let category = 'general';
    if (text.includes('bug')) category = 'engineering';
    if (text.includes('invoice')) category = 'billing';
    return { category, attempts: state.attempts + 1 };
  });

  // 3. Node: confidence gate (cyclical edge target)
  graph.addNode('gate', async (state) => {
    const ok = state.category !== 'general' || state.attempts >= 3;
    return { resolved: ok };
  });

  // 4. Edges: START -> classify -> gate
  graph.addEdge(START, 'classify');
  graph.addEdge('classify', 'gate');

  // 5. Cyclical structure: if not resolved, loop back to classify for refinement
  graph.addConditionalEdges(
    'gate',
    (state) => (state.resolved ? END : 'classify'),
    { [END]: END, classify: 'classify' }
  );

  // 6. Compile once; returned object is cached in global scope
  return graph.compile();
}

/**
 * Returns cached graph or builds it once per cold start.
 */
function getGraph() {
  if (!globalThis.__triageGraph) {
    globalThis.__triageGraph = buildTriageGraph();
  }
  return globalThis.__triageGraph;
}

/**
 * POST handler: receives a ticket and runs the optimized edge agent.
 */
export async function POST(req: Request): Promise<Response> {
  // Parse request without heavy middleware (zero-build native ESM)
  const { ticket } = await req.json();

  // Retrieve cached compiled graph (minimizes cold-start latency)
  const app = getGraph();

  // Invoke with minimal state object
  const result = await app.invoke({
    ticketText: ticket ?? '',
    attempts: 0,
    resolved: false,
  });

  // Return lean JSON response
  return new Response(JSON.stringify(result), {
    headers: { 'content-type': 'application/json' },
  });
}
