/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// validate_edge.ts
// Deno Deploy compatible, zero third-party imports

// Global scope timing: module evaluation start
const globalStart = performance.now();

// No third-party imports; only native Web APIs used

export default {
  async fetch(req: Request): Promise<Response> {
    const handlerStart = performance.now();

    // Ensure method is POST
    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    // Parse JSON via native Request.json()
    let payload: unknown;
    try {
      payload = await req.json();
    } catch {
      return new Response("Invalid JSON", { status: 400 });
    }

    // Manual validation of shape and types
    if (
      typeof payload !== "object" || payload === null ||
      typeof (payload as any).userId !== "string" ||
      typeof (payload as any).region !== "string" ||
      typeof (payload as any).token !== "string"
    ) {
      return new Response("Validation Failed", { status: 422 });
    }

    const elapsed = performance.now() - handlerStart;
    // Log time from module eval to response start
    console.log(`Global init: ${(globalStart)}ms; Handler elapsed: ${elapsed}ms`);

    return new Response(
      JSON.stringify({ ok: true, forwarded: payload }),
      { status: 200, headers: { "content-type": "application/json" } }
    );
  }
};
