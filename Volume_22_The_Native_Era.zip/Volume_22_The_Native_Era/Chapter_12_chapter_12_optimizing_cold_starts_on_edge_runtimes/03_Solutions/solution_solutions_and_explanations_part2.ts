/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// bun_edge_cache.ts
// Targets Bun edge runtime, native ESM

// Mark global init start
performance.mark("global-start");

// Simulate lightweight model inference artifact in global scope
const modelMap = new Map<string, number>();
for (let i = 0; i < 10000; i++) {
  modelMap.set(`key-${i}`, i * Math.random());
}

performance.mark("global-end");
performance.measure("global-init", "global-start", "global-end");

/*
 * Placing `modelMap` outside the handler means it is built once per cold
 * isolate start, not per request. This reduces per-request latency but does
 * NOT guarantee cross-isolate persistence because each new isolate gets a
 * fresh global scope on cold start.
 */

export default {
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const key = url.searchParams.get("key") ?? "key-0";
    const result = modelMap.get(key) ?? null;

    return new Response(
      JSON.stringify({ key, value: result }),
      { headers: { "content-type": "application/json" } }
    );
  }
};

// To verify global scope is not re-created on warm requests, add a global counter:
// let reqCount = 0; inside fetch: reqCount++; console.log(reqCount);
// If it increments across requests without reset, global scope persists while warm.
