/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Flowship SaaS – Native Runtime Test Example
 * File: userOnboarding.test.ts
 * 
 * This test verifies the core logic of generating a workspace
 * slug for new SaaS tenants. It runs natively in Node.js, Bun,
 * and Deno without any bundler or transpiler step.
 */

// 1. Import the test primitives from the global runtime scope.
// Node.js, Bun, and Deno all expose `test` and `describe` globally
// in their native test runners (no npm install required).
import { test, describe } from "node:test"; // Node-style import; Bun/Deno also accept this
import assert from "node:assert"; // Built-in assertion library

/**
 * Simulated SaaS business logic: create a URL-safe workspace slug.
 * In a real Flowship backend, this would be used during signup.
 * @param companyName - Raw user input from the onboarding form
 * @returns A lowercase, dash-separated slug string
 */
function createWorkspaceSlug(companyName: string): string {
  // 2. Convert to lowercase for URL consistency
  const lower = companyName.toLowerCase();
  // 3. Replace spaces and underscores with dashes
  const dashed = lower.replace(/[\s_]+/g, "-");
  // 4. Strip non-alphanumeric characters except dashes
  const cleaned = dashed.replace(/[^a-z0-9-]/g, "");
  return cleaned;
}

// 5. Group related tests under a descriptive suite name
describe("Flowship Workspace Slug Generator", () => {
  // 6. Define an individual test case
  test("generates a clean slug from a normal company name", () => {
    // 7. Arrange: input from a hypothetical signup form
    const input = "Flowship Inc";
    // 8. Act: run the function
    const result = createWorkspaceSlug(input);
    // 9. Assert: expected deterministic output
    assert.strictEqual(result, "flowship-inc");
  });

  // 10. Second test case for edge cases
  test("handles weird characters and capitals", () => {
    const input = "Big_Corp 2000 !!";
    const result = createWorkspaceSlug(input);
    assert.strictEqual(result, "big-corp-2000");
  });
});
