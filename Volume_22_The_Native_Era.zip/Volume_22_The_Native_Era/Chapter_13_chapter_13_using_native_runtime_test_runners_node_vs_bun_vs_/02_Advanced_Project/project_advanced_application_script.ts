/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Knowledge Base Ingestion Pipeline using LangGraph + Native Runtime Test Runners
 * Context: SaaS "DocsAI" app needs zero-config testing across Node, Bun, Deno.
 */

// 1. Define the canonical Graph State shared across all nodes
/** @interface GraphState */
interface GraphState {
  /** Raw text uploaded by SaaS user */
  rawText: string;
  /** Text split into chunks for embedding */
  chunks: string[];
  /** Numerical vectors returned from embedding API */
  embeddings: number[][];
  /** Tenant ID for SaaS isolation */
  tenantId: string;
}

// 2. Import LangGraph core (native ESM, no transpile needed)
import { StateGraph } from "@langchain/langgraph";

// 3. Node 1: Split raw text into chunks (simulated SaaS preprocessor)
async function chunkText(state: GraphState): Promise<Partial<GraphState>> {
  // Simple split by sentence for demo; real SaaS uses token-aware splitter
  const chunks = state.rawText.split(/(?<=\.)\s+/).filter(Boolean);
  return { chunks };
}

// 4. Node 2: Generate embeddings via async API call (mocked for native tests)
async function generateEmbeddings(state: GraphState): Promise<Partial<GraphState>> {
  // In production: await openai.embeddings.create({ input: state.chunks })
  const embeddings = state.chunks.map((_, i) => [0.1 * i, 0.2 * i]);
  return { embeddings };
}

// 5. Build the StateGraph with shared Graph State type
const workflow = new StateGraph<GraphState>({})
  .addNode("chunk", chunkText)
  .addNode("embed", generateEmbeddings)
  .addEdge("__start__", "chunk")
  .addEdge("chunk", "embed")
  .addEdge("embed", "__end__");

// 6. Compile graph for execution
const app = workflow.compile();

// 7. SaaS runner function (used by Next.js API route or script)
export async function runIngestion(tenantId: string, text: string) {
  const initialState: GraphState = {
    rawText: text,
    chunks: [],
    embeddings: [],
    tenantId,
  };
  return await app.invoke(initialState);
}

// 8. Native test block – works under Node, Bun, Deno (conditional import)
// @ts-ignore - runtime-specific test globals
const test = globalThis.Deno?.test ?? globalThis.bun?.test ?? (await import("node:test")).test;

// 9. Test: Graph produces chunks and embeddings
test("DocsAI ingestion graph populates state", async () => {
  const result = await runIngestion("tnt_123", "Hello world. Native testing is fast.");
  if (result.chunks.length !== 2) throw new Error("Chunking failed");
  if (result.embeddings.length !== 2) throw new Error("Embedding failed");
});

// 10. Test: Tenant isolation preserved
test("Tenant ID retained in state", async () => {
  const result = await runIngestion("tnt_999", "SaaS data.");
  if (result.tenantId !== "tnt_999") throw new Error("Tenant leak");
});
