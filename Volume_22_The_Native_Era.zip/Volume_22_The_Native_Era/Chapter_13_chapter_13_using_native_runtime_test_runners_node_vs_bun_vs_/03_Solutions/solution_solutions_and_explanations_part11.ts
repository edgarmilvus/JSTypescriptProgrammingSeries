/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

// math.cross.test.ts
// Conditional imports let one file run on all three runners without Vitest/Jest.
declare const Bun: any;
declare const Deno: any;

let test: any, assert: any;
if (typeof Bun !== 'undefined') {
  ({ test, expect: assert } = require('bun:test'));
} else if (typeof Deno !== 'undefined') {
  test = Deno.test;
  assert = await import('jsr:@std/assert');
} else {
  ({ test } = await import('node:test'));
  assert = await import('node:assert/strict');
}

test('add', () => {
  if (assert.equal) assert.equal(add(1, 2), 3);
  else assert.assertEquals(add(1, 2), 3);
});
test('divide', () => {
  if (assert.equal) assert.equal(divide(4, 2), 2);
  else assert.assertEquals(divide(4, 2), 2);
});
