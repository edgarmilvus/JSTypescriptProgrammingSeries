/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// lib/llm.ts

/**
 * Minimal LLM JSON Schema output simulation.
 * In a real app, this calls an LLM with response_format: json_schema.
 */
import { z } from "zod";

/**
 * Define the expected JSON Schema output using Zod.
 * This acts as our runtime validator and TypeScript type.
 */
export const TicketSchema = z.object({
  /** Short category predicted by the LLM */
  category: z.string(),
  /** Priority level from 1 (low) to 5 (critical) */
  priority: z.number().int().min(1).max(5),
  /** Whether human escalation is required */
  escalate: z.boolean(),
});

export type Ticket = z.infer<typeof TicketSchema>;

/**
 * Fake LLM call that returns a hardcoded JSON object.
 * In reality, the model is instructed via JSON Schema.
 */
export async function classifyTicket(text: string): Promise<Ticket> {
  // Simulate network latency
  await new Promise((r) => setTimeout(r, 10));

  const raw = {
    category: "billing",
    priority: 3,
    escalate: false,
  };

  // Validate and parse with Zod
  return TicketSchema.parse(raw);
}
