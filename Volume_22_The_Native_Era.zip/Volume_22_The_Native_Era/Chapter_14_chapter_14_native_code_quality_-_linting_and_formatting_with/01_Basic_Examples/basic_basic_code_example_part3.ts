/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

// app/actions.ts

"use server";

/**
 * Server Action: securely runs on the server.
 * It classifies a ticket, then stores its vector in Pinecone.
 */
import { supportIndex } from "@/db/pinecone";
import { classifyTicket } from "@/lib/llm";

/**
 * Dummy embedding function (normally from an embedding model).
 */
async function embed(text: string): Promise<number[]> {
  // 3-dimensional fake vector for demo
  return [text.length, text.length % 3, text.length % 5];
}

/**
 * Server Action exposed to the client.
 * @param formData - submitted form data from a web app
 */
export async function submitSupportTicket(formData: FormData) {
  // 1. Extract user input
  const message = formData.get("message")?.toString() ?? "";

  // 2. Classify using LLM JSON Schema output
  const classification = await classifyTicket(message);

  // 3. Create embedding vector
  const vector = await embed(message);

  // 4. Upsert to Pinecone
  await supportIndex.upsert([
    {
      id: crypto.randomUUID(),
      values: vector,
      metadata: {
        message,
        ...classification,
      },
    },
  ]);

  // 5. Return result to client
  return { ok: true, classification };
}
