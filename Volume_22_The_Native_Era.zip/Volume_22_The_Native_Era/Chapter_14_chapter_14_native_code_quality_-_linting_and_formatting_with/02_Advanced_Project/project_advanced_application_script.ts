/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// File: app/dashboard/ai-context/assemblePrompt.ts
// Context: Next.js 14+ Server Component utility (native ESM, no bundler needed)
// Tooling: Biome (zero-config lint + format) enforces consistent style below
// ============================================================================

/**
 * Represents a user profile fetched from the SaaS backend.
 * Only the fields needed for AI context assembly are included.
 */
interface UserProfile {
  id: string;
  displayName: string;
  role: 'admin' | 'member' | 'viewer';
  recentTasks: string[];
}

/**
 * Represents system-level context such as workspace name and tier.
 */
interface SystemContext {
  workspaceName: string;
  planTier: 'free' | 'pro' | 'enterprise';
}

/**
 * Union type returned by our data fetcher to demonstrate type narrowing.
 * It is either a successful payload or an error object.
 */
type FetchResult =
  | { status: 'ok'; data: UserProfile & SystemContext }
  | { status: 'error'; message: string };

/**
 * Fetches initial conversation context directly inside the Server Component.
 * In a real SaaS this would call an internal API or DB driver (e.g., Bun.sql).
 * @returns {Promise<FetchResult>} Resolved fetch result with narrowed shape.
 */
async function fetchDashboardContext(): Promise<FetchResult> {
  // Simulate async native fetch (no transpile required in Node/Bun/Deno)
  // Biome will flag any unhandled promise rejections if not awaited.
  try {
    const res = await fetch('https://api.saas.internal/v1/context', {
      // Native ESM: use standard RequestInit, no polyfills
      headers: { 'content-type': 'application/json' },
      cache: 'no-store', // SCs should avoid stale AI context
    });
    if (!res.ok) {
      // Return error branch of union for type-safe downstream handling
      return { status: 'error', message: `HTTP ${res.status}` };
    }
    const json = (await res.json()) as UserProfile & SystemContext;
    return { status: 'ok', data: json };
  } catch (err) {
    // Narrowing not needed here; we explicitly return error shape
    return { status: 'error', message: (err as Error).message };
  }
}

/**
 * Few-shot examples embedded as constants to guide the LLM.
 * These are static high-quality input/output pairs for task summarization.
 */
const FEW_SHOT_EXAMPLES: Array<{ input: string; output: string }> = [
  {
    input: 'Task: Finalize Q3 report',
    output: 'Summary: Wrap up the quarterly financial report for Q3.',
  },
  {
    input: 'Task: Onboard new dev',
    output: 'Summary: Set up accounts and mentor the newly hired engineer.',
  },
];

/**
 * Builds a few-shot prompt string using fetched context and type narrowing.
 * @param {FetchResult} result The fetched context result (union type).
 * @returns {string} A formatted prompt ready for LLM invocation.
 */
function buildFewShotPrompt(result: FetchResult): string {
  // --- Type Narrowing Block ---
  // The compiler refines FetchResult to the 'error' variant here.
  if (result.status === 'error') {
    // Safe: result.message is accessible because of narrowing
    return `System: Unable to load context (${result.message}). Use generic tone.`;
  }

  // --- Narrowed Success Block ---
  // Outside the above guard, TS knows result is the 'ok' branch.
  const { data } = result;
  const userName = data.displayName;
  const taskList = data.recentTasks.slice(0, 3).join(', ');

  // Compose few-shot section from constant examples
  const fewShotText = FEW_SHOT_EXAMPLES.map(
    (ex) => `Input: ${ex.input}\nOutput: ${ex.output}`,
  ).join('\n');

  // Final assembled prompt for the AI model
  return [
    `System: You are assisting ${userName} in ${data.workspaceName}.`,
    `Plan: ${data.planTier}. Context tasks: ${taskList}.`,
    `Few-shot examples:\n${fewShotText}`,
    `Now summarize: "${taskList}"`,
  ].join('\n');
}

/**
 * Server Component entry: fetches context and returns prompt for UI display.
 * @returns {Promise<{ prompt: string }>} Object containing the safe prompt.
 */
export async function assembleAIPrompt(): Promise<{ prompt: string }> {
  // Step 1: Fetch context via native async function
  const ctx = await fetchDashboardContext();

  // Step 2: Build prompt (type narrowing happens internally)
  const prompt = buildFewShotPrompt(ctx);

  // Step 3: Return to SC for rendering (no client-side waterfall)
  return { prompt };
}
