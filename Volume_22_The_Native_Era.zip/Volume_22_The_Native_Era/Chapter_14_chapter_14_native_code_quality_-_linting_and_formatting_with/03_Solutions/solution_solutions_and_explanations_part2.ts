/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1) Remove legacy files:
//    rm .eslintrc.cjs .prettierrc
// 2) Migrate:
//    deno task biome migrate --from-eslint --from-prettier

// biome.json (adjusted)
{
  "files": { "includes": ["**/*.ts", "**/*.js"] },
  "formatter": {
    "enabled": true,
    "lineWidth": 100,
    "semicolons": "never",
    "javascript": { "quoteStyle": "single" }
  },
  "linter": {
    "enabled": true,
    "rules": {
      "recommended": true,
      "lint": {
        "noUnusedVars": "error",
        "noConsole": "warn",
        "useNodejsImportProtocol": "error"
      }
    }
  }
}

// ragPipeline.ts (must pass biome check)
import { embed } from "./embeddings.ts";
import { search } from "./vectorStore.ts";

export async function runRag(query: string): Promise<string> {
  const vector = await embed(query);
  const docs = await search(vector);
  return synthesize(docs);
}

function synthesize(docs: string[]): string {
  return docs.join("\n");
}
