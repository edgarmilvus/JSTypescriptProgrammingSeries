/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: apps/server/src/index.ts
//
// This file represents the entry point of a minimal SaaS server
// inside a Turborepo monorepo. It uses native type stripping,
// so no bundler or transpiler is involved.

/**
 * A minimal SaaS tenant object inferred from its initializer.
 * Type Inference deduces the shape without explicit annotations.
 */
const tenant = {
  id: "org_123",
  name: "Acme Cloud",
  plan: "pro",
};

/**
 * Server Action: a function that simulates sending a welcome email.
 * In a real SaaS app this would run on the server only.
 *
 * @param t - inferred tenant object
 * @returns void
 */
async function sendWelcomeEmail(t: typeof tenant): Promise<void> {
  // Simulate async server-side work
  await new Promise((resolve) => setTimeout(resolve, 10));
  console.log(`[SaaS] Welcome email sent to ${t.name} (${t.plan} plan)`);
}

/**
 * Worker Agent Pool simulation: a list of lightweight agents.
 * Each agent has a name and a run function.
 */
const workerPool = [
  {
    name: "Notifier",
    run: async () => {
      await sendWelcomeEmail(tenant);
    },
  },
];

/**
 * Supervisor Node: triggers the worker agents.
 */
async function supervisor() {
  for (const agent of workerPool) {
    await agent.run();
  }
}

// Bootstrap the SaaS server simulation
supervisor().then(() => {
  console.log("Server simulation complete.");
});
