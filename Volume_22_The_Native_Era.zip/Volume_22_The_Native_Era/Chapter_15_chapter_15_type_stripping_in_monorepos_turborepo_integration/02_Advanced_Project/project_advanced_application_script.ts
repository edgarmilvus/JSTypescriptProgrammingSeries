/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file advancedGraphState.ts
 * @description Advanced LangGraph state orchestration for a SaaS trial-conversion flow.
 * Runs natively under Node.js 22 type stripping (no ts-node, no bundler).
 */

import { z } from 'zod';
import type { GraphState, TrialEvent, ConversionResult } from '@saas/core-graph';

// 1. Define the canonical Graph State schema using Zod for runtime validation + type inference.
const GraphStateSchema = z.object({
  tenantId: z.string().uuid(),
  trialStart: z.number(),
  events: z.array(z.object({
    type: z.enum(['signup', 'activation', 'payment']),
    at: z.number(),
    meta: z.record(z.unknown()).optional(),
  })),
  converted: z.boolean().default(false),
  score: z.number().min(0).max(100).default(0),
});

// 2. Infer the precise TypeScript type from the Zod schema (bridging runtime + compile time).
type InferredGraphState = z.infer<typeof GraphStateSchema>;

// 3. User-defined Type Guard: narrows an event to a 'payment' trial event.
function isPaymentEvent(e: TrialEvent): e is TrialEvent & { type: 'payment' } {
  return e.type === 'payment';
}

// 4. User-defined Type Guard: checks if Graph State is eligible for conversion logic.
function isConversionReady(s: GraphState): s is GraphState & { score: number } {
  return typeof s.score === 'number' && s.score >= 50;
}

// 5. Simulated LangGraph node: ingest raw API payload and validate into Graph State.
function ingestNode(raw: unknown): InferredGraphState {
  // Validate at runtime; throws if shape/constraints violated.
  const parsed = GraphStateSchema.parse(raw);
  return parsed;
}

// 6. Simulated LangGraph node: score the trial based on event sequence.
function scoringNode(state: InferredGraphState): InferredGraphState {
  let score = 0;
  for (const ev of state.events) {
    if (ev.type === 'signup') score += 10;
    if (ev.type === 'activation') score += 30;
    // Type guard ensures safe access to payment.meta inside this block.
    if (isPaymentEvent(ev) && ev.meta?.amount) score += 40;
  }
  return { ...state, score: Math.min(score, 100) };
}

// 7. Simulated LangGraph node: conditionally convert using type-narrowed state.
function conversionNode(state: InferredGraphState): ConversionResult {
  // Guard prevents execution unless score threshold met (type narrowing applied).
  if (!isConversionReady(state)) {
    return { converted: false, reason: 'insufficient_score' };
  }
  return { converted: true, tenantId: state.tenantId, at: Date.now() };
}

// 8. Orchestrator: wires nodes together passing the singular Graph State object.
export function runTrialWorkflow(rawApiInput: unknown): ConversionResult {
  const s1 = ingestNode(rawApiInput); // Step 1: validate + strip types natively
  const s2 = scoringNode(s1);         // Step 2: mutate score in canonical state
  const result = conversionNode(s2);  // Step 3: decide conversion
  return result;
}

// 9. Example execution (would be a Turborepo task entry in real app).
const demoInput = {
  tenantId: '123e4567-e89b-12d3-a456-426614174000',
  trialStart: Date.now() - 86400000,
  events: [
    { type: 'signup', at: Date.now() - 80000000 },
    { type: 'activation', at: Date.now() - 40000000 },
    { type: 'payment', at: Date.now() - 1000000, meta: { amount: 49 } },
  ],
};

const output = runTrialWorkflow(demoInput);
console.log('Conversion Output:', output);
