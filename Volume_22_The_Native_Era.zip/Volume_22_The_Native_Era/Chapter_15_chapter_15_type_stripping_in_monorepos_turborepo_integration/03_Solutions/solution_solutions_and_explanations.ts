/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// root tsconfig.json
{
  "compilerOptions": {
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "target": "ES2022",
    "noEmit": true,
    "strict": true,
    "verbatimModuleSyntax": true
  },
  "files": [],
  "references": [
    { "path": "./packages/core" },
    { "path": "./packages/api" }
  ]
}

// packages/core/src/math.ts
export function add(a: number, b: number): number {
  return a + b;
}

// packages/api/src/index.ts
import { add } from "@monorepo/core/src/math.ts"; // ESM with explicit .ts extension

console.log("Result:", add(2, 3));

// turbo.json
{
  "pipeline": {
    "typecheck": {
      "outputs": [],
      "command": "tsc --noEmit"
    },
    "run": {
      "dependsOn": ["typecheck"],
      "outputs": [],
      "commands": {
        "core": "node --experimental-strip-types src/math.ts",
        "api": "bun run src/index.ts"
      }
    }
  }
}

// README.md note:
// noEmit is required because type stripping executes .ts directly; tsc is only a checker.
// Type stripping erases types at load time (Node/Bun/Deno) instead of emitting JS like a transpiler.
