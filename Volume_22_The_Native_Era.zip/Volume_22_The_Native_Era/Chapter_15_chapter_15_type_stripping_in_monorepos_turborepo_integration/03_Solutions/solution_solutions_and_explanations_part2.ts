/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// packages/utils/src/guards.ts
export interface Animal {
  kind: "cat" | "dog";
  name: string;
}

export function isAnimal(value: unknown): value is Animal {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return (
    (v.kind === "cat" || v.kind === "dog") &&
    typeof v.name === "string"
  );
}

// packages/service/src/handle.ts
import { isAnimal } from "@monorepo/utils/src/guards.ts";

export function handle(input: unknown): void {
  if (isAnimal(input)) {
    console.log(`Valid animal: ${input.kind} named ${input.name}`);
  } else {
    console.log("Received non-animal data; skipping safely.");
  }
}

// demo script (packages/service/src/demo.ts)
handle({ kind: "cat", name: "Whiskers" });
handle({ kind: "fish", name: 123 });

// turbo.json snippet
{
  "pipeline": {
    "test": {
      "outputs": [],
      "commands": {
        "utils": "node --experimental-strip-types src/guards.ts",
        "service": "bun run src/demo.ts"
      }
    }
  }
}

// README: instanceof fails for plain literals because they are not class instances.
