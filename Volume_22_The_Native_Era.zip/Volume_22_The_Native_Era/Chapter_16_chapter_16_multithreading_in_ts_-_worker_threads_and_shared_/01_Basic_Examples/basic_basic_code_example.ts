/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * main.ts
 * Entry point for a minimal SaaS backend demonstration.
 * Runs directly via `node --experimental-strip-types main.ts` (Node 22+)
 * or `bun run main.ts` / `deno run --allow-read main.ts`.
 */

// Import only what we need from the native worker_threads module.
import { Worker } from 'node:worker_threads';

/**
 * SaaS context:
 * A fake "tenant" ID and a payload representing a request to
 * generate a lightweight usage report off the main thread.
 */
interface ReportRequest {
  tenantId: string;
  month: string;
}

interface ReportResponse {
  tenantId: string;
  month: string;
  totalRequests: number;
  generatedBy: string;
}

/**
 * Spawns a worker thread to compute a report.
 * @param req The report request from the web layer.
 * @returns A promise that resolves with the computed report.
 */
function requestReportFromWorker(req: ReportRequest): Promise<ReportResponse> {
  // 1. Create a new Worker instance pointing to the worker file.
  //    Using `new URL` keeps the path resolution native and ESM-friendly.
  const worker = new Worker(
    new URL('./report-worker.ts', import.meta.url)
  );

  // 2. Return a Promise so the caller can await the result naturally.
  return new Promise<ReportResponse>((resolve, reject) => {
    // 3. Listen for the first message from the worker (our result).
    worker.on('message', (data: ReportResponse) => {
      resolve(data);
      // 4. Terminate the worker once we have our answer.
      worker.terminate();
    });

    // 5. Handle any uncaught errors inside the worker.
    worker.on('error', (err) => {
      reject(err);
      worker.terminate();
    });

    // 6. Send the request payload to the worker's message port.
    worker.postMessage(req);
  });
}

/**
 * Main async bootstrap simulating an incoming HTTP request.
 */
async function main(): Promise<void> {
  console.log('SaaS Main Thread: Received request for monthly report.');

  const fakeRequest: ReportRequest = {
    tenantId: 'acme-corp',
    month: '2025-06'
  };

  // 7. Delegate the CPU task to the worker thread.
  const report = await requestReportFromWorker(fakeRequest);

  // 8. Log the result as if responding to an API call.
  console.log('SaaS Main Thread: Report ready ->', report);
}

// 9. Execute the bootstrap.
main().catch((e) => console.error(e));
