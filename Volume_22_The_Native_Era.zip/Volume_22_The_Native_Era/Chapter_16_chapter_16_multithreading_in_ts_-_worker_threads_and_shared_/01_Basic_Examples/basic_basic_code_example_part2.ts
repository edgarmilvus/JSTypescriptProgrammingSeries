/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * report-worker.ts
 * This file runs in a SEPARATE V8 isolate (thread) from main.ts.
 * It receives a ReportRequest, simulates heavy work, and replies.
 */

// Import the message types and parent port from worker_threads.
import { parentPort } from 'node:worker_threads';

/**
 * Type definitions mirrored from main thread (in real apps, share via a types file).
 */
interface ReportRequest {
  tenantId: string;
  month: string;
}

interface ReportResponse {
  tenantId: string;
  month: string;
  totalRequests: number;
  generatedBy: string;
}

/**
 * The parentPort is the communication channel to the main thread.
 * If it's null, this file was not run as a worker (defensive check).
 */
if (parentPort) {
  // 1. Listen for messages sent via worker.postMessage().
  parentPort.on('message', (req: ReportRequest) => {
    // 2. Simulate CPU-bound work (e.g., headless inference or WASM threads).
    //    In a real SaaS, this might call a Worker Agent in a Pool.
    let totalRequests = 0;
    for (let i = 0; i < 1_000_000; i++) {
      totalRequests += i % 7 === 0 ? 1 : 0;
    }

    // 3. Construct the response object.
    const response: ReportResponse = {
      tenantId: req.tenantId,
      month: req.month,
      totalRequests,
      generatedBy: 'Worker Thread #1'
    };

    // 4. Send the result back to the main thread.
    parentPort.postMessage(response);
  });
}
