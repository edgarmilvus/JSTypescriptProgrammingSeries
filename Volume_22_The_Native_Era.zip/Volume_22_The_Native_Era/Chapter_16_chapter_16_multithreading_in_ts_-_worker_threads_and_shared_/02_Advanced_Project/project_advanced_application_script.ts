/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// inference-coordinator.ts
// Context: SaaS backend service performing parallel headless inference using Worker Threads + SAB.

import { Worker } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';

/**
 * SaaS inference configuration.
 * Defines how many worker threads to spawn and the tensor dimensions.
 */
interface InferenceConfig {
  /** Number of parallel worker threads for inference. */
  workerCount: number;
  /** Length of each input feature vector. */
  featureSize: number;
  /** Number of output classes predicted by the model. */
  outputSize: number;
}

/**
 * Default configuration for a lightweight SaaS text-classification service.
 * Model weights are assumed already compressed (quantized to Int8).
 */
const config: InferenceConfig = {
  workerCount: 4,
  featureSize: 128,
  outputSize: 8,
};

/**
 * Allocates a SharedArrayBuffer for model weights (read-only semantic)
 * and another for inference outputs (writeable by workers).
 * Using SAB prevents costly copying of large weight matrices.
 */
const weightSAB = new SharedArrayBuffer(config.featureSize * config.outputSize);
const weightView = new Int8Array(weightSAB);
// Simulate model compression: fill with pseudo-quantized weights.
weightView.fill(1);

const outputSAB = new SharedArrayBuffer(config.workerCount * config.outputSize * 4);
const outputView = new Int32Array(outputSAB);

/**
 * Spawns worker threads and returns a pool handle.
 * Each worker receives SABs via workerData (zero-copy).
 */
function createInferencePool(cfg: InferenceConfig) {
  const workers: Worker[] = [];
  const scriptPath = fileURLToPath(new URL('./inference-worker.ts', import.meta.url));

  for (let i = 0; i < cfg.workerCount; i++) {
    const worker = new Worker(scriptPath, {
      workerData: {
        workerId: i,
        weightSAB,
        outputSAB,
        featureSize: cfg.featureSize,
        outputSize: cfg.outputSize,
      },
    });
    workers.push(worker);
  }
  return workers;
}

/**
 * Main SaaS entry: run parallel inference for a batch of requests.
 * @param inputs - Array of feature vectors (each length = featureSize)
 */
export async function runInference(inputs: Int8Array[]): Promise<Int32Array> {
  const pool = createInferencePool(config);
  const inputSAB = new SharedArrayBuffer(inputs.length * config.featureSize);
  const inputView = new Int8Array(inputSAB);
  inputs.forEach((vec, idx) => inputView.set(vec, idx * config.featureSize));

  // Dispatch inputs to workers round-robin.
  pool.forEach((worker, i) => {
    worker.postMessage({ type: 'INFER', inputSAB, batchOffset: i });
  });

  // Await completion via message events.
  await new Promise<void>((resolve) => {
    let done = 0;
    pool.forEach((worker) => {
      worker.on('message', () => {
        if (++done === pool.length) resolve();
      });
    });
  });

  pool.forEach((w) => w.terminate());
  return outputView;
}
