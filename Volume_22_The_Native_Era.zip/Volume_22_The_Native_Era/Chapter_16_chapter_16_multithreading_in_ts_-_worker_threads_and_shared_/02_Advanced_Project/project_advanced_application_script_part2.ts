/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// inference-worker.ts
// Headless inference worker: reads shared weights, computes, writes shared output.

import { parentPort, workerData } from 'node:worker_threads';

interface WorkerData {
  workerId: number;
  weightSAB: SharedArrayBuffer;
  outputSAB: SharedArrayBuffer;
  featureSize: number;
  outputSize: number;
}

const { workerId, weightSAB, outputSAB, featureSize, outputSize } =
  workerData as WorkerData;

const weights = new Int8Array(weightSAB);
const outputs = new Int32Array(outputSAB);

/**
 * Performs a trivial matrix multiplication (dot product) as a stand-in
 * for compressed-model headless inference.
 */
function infer(input: Int8Array): Int32Array {
  const result = new Int32Array(outputSize);
  for (let o = 0; o < outputSize; o++) {
    let sum = 0;
    for (let f = 0; f < featureSize; f++) {
      sum += weights[o * featureSize + f] * input[f];
    }
    result[o] = sum;
  }
  return result;
}

/**
 * Listens for inference jobs from the main SaaS thread.
 */
parentPort?.on('message', (msg: { type: string; inputSAB: SharedArrayBuffer; batchOffset: number }) => {
  if (msg.type !== 'INFER') return;
  const inputView = new Int8Array(msg.inputSAB);
  const start = workerId * featureSize;
  const inputSlice = inputView.slice(start, start + featureSize);
  const out = infer(inputSlice);
  outputs.set(out, workerId * outputSize);
  parentPort?.postMessage({ done: true });
});
