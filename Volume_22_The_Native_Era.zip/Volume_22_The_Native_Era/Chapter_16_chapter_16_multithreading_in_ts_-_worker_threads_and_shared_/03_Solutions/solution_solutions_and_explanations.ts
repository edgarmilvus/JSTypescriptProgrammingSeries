/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// supervisor.ts (main thread)
import { Worker } from 'node:worker_threads'; // Node built-in; Bun/Deno provide compatible globals

// 1. Structured envelope contract
export interface DelegationEnvelope<T> {
  taskId: string;
  payload: T;
  timeoutMs: number;
  expectedSchema: string;
}

// 2. Unified pool factory
export function createWorkerPool(runtime: 'node' | 'bun' | 'deno', size: number) {
  // Portable worker file path: use .ts for Bun/Deno, .js for Node native strip-types
  const workerFile = runtime === 'node' ? './worker.js' : './worker.ts';
  const workers: Worker[] = [];
  for (let i = 0; i < size; i++) {
    workers.push(new Worker(workerFile)); // Bun/Deno accept same constructor signature
  }
  let idx = 0;

  return {
    execute<T>(task: DelegationEnvelope<T>): Promise<unknown> {
      const worker = workers[idx++ % size];
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error(`Timeout ${task.timeoutMs}ms`));
          worker.terminate(); // recycle
          workers[idx % size] = new Worker(workerFile);
        }, task.timeoutMs);

        const onMsg = (msg: any) => {
          if (msg.taskId === task.taskId) {
            clearTimeout(timer);
            worker.off('message', onMsg);
            resolve(msg.result);
          }
        };
        worker.on('message', onMsg);
        worker.postMessage(task); // Structured Clone Algorithm
      });
    }
  };
}

// 6. Benchmark
async function bench() {
  const pool = createWorkerPool('bun', 4);
  const start = Date.now();
  await Promise.all(Array.from({ length: 100 }, (_, i) =>
    pool.execute({ taskId: `t${i}`, payload: i, timeoutMs: 5000, expectedSchema: 'number' })
  ));
  console.log(`Throughput: ${100 / ((Date.now() - start) / 1000)} tasks/s`);
}
bench();

// worker.ts (entry for Bun/Deno; rename to worker.js for Node with --experimental-strip-types)
// 3. Worker logic
import { parentPort } from 'node:worker_threads';
parentPort!.on('message', (env: DelegationEnvelope<number>) => {
  // CPU-bound fake: factorial-ish
  let r = 0; for (let i = 0; i < 1e6; i++) r += Math.sqrt(env.payload + i);
  parentPort!.postMessage({ taskId: env.taskId, result: r });
});
// 4. Portability: Node requires .js import extensions in native TS; Bun/Deno allow .ts directly.
