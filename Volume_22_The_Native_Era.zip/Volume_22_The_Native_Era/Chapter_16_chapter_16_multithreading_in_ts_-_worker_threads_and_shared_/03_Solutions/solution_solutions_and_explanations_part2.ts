/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// supervisor.ts
const width = 3840, height = 2160;
const pixelSAB = new SharedArrayBuffer(width * height * 4);
const controlSAB = new SharedArrayBuffer((4 + 1) * 4); // Int32Array length 5
const control = new Int32Array(controlSAB);
const workerCount = 4;

for (let w = 0; w < workerCount; w++) {
  control[w] = w * (height / workerCount); // band offset
  control[w + 1] = (w + 1) * (height / workerCount); // band end
}
const workers = Array.from({ length: workerCount }, () =>
  new Worker('./image-worker.ts'));
workers.forEach((wk, i) => {
  wk.postMessage({ pixelSAB, controlSAB, id: i });
  Atomics.notify(control, i); // wake
});

// image-worker.ts
import { parentPort } from 'node:worker_threads';
parentPort!.on('message', ({ pixelSAB, controlSAB, id }) => {
  const pixels = new Uint8ClampedArray(pixelSAB);
  const ctrl = new Int32Array(controlSAB);
  while (true) {
    Atomics.wait(ctrl, id, 0); // wait for job
    const start = ctrl[id], end = ctrl[id + 1];
    for (let y = start; y < end; y++) {
      for (let x = 0; x < 3840; x++) {
        const i = (y * 3840 + x) * 4;
        const g = (pixels[i] + pixels[i+1] + pixels[i+2]) / 3;
        pixels[i] = pixels[i+1] = pixels[i+2] = g;
      }
    }
    Atomics.store(ctrl, id, 0); // mark done
    Atomics.notify(ctrl, workerCount); // notify supervisor
  }
});

// 4. CLI launch: node --experimental-strip-types supervisor.ts (SAB available by default in CLI)
// 5. TSX component (sketch)
// <ImageProcessor> uses OffscreenCanvas, transfers pixelSAB, rAF polls ctrl[workerCount] done flag.
