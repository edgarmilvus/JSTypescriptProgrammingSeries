/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// PrimeCalculator.tsx
import React, { useEffect, useRef, useState } from 'react';

export function PrimeCalculator() {
  const [limit, setLimit] = useState(1000);
  const [primes, setPrimes] = useState<number[]>([]);
  const [progress, setProgress] = useState(0);
  const workerRef = useRef<Worker | null>(null);
  const reqId = useRef(0);

  useEffect(() => {
    reqId.current++;
    const worker = new Worker(new URL('./prime-worker.ts', import.meta.url), { type: 'module' });
    workerRef.current = worker;
    worker.postMessage({ limit, requestId: reqId.current });
    worker.onmessage = (e) => {
      if (e.data.requestId !== reqId.current) return; // stale filter
      setPrimes(e.data.primes); setProgress(e.data.progress);
    };
    return () => worker.terminate();
  }, [limit]);

  return (
    <div>
      <input type="number" value={limit} onChange={e => setLimit(+e.target.value)} />
      <progress value={progress} max={100} />
      <ul>{primes.slice(0, 100).map(p => <li key={p}>{p}</li>)}</ul>
    </div>
  );
}

// prime-worker.ts: sieve in chunks, post every 1% progress with requestId
