/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Recommendation Refresher — Basic Native TS Example
 * Runs in Node.js / Bun / Deno without bundlers or transpilers.
 */

// 1. Import Pinecone Client (Node.js SDK) for vector DB access.
import { Pinecone } from "@pinecone-database/pinecone";

// 2. Define a minimal WASM simulation using WebAssembly text format compiled at runtime.
// This mimics a heavy re-ranker compiled from Rust/C++.
const wasmSource = `(module
  (func $fakeRank (param $i i32) (result i32)
    local.get $i
    i32.const 1
    i32.add)
  (export "fakeRank" (func $fakeRank))
)`;

// 3. JSDoc: Configuration interface for our SaaS job.
interface SaaSConfig {
  /** Pinecone API key from env */
  apiKey: string;
  /** Index name in Pinecone */
  indexName: string;
  /** How many items to fetch */
  topK: number;
}

// 4. Load and instantiate the WASM module from text.
async function loadWasm(): Promise<WebAssembly.Instance> {
  // Compile the WAT string into a module.
  const mod = await WebAssembly.compile(
    new Uint8Array(new TextEncoder().encode(wasmSource))
  );
  // Instantiate with no imports.
  return new WebAssembly.Instance(mod);
}

// 5. Main SaaS refresh function.
async function refreshRecommendations(cfg: SaaSConfig): Promise<void> {
  // 5a. Create Pinecone client (native Node.js).
  const pc = new Pinecone({ apiKey: cfg.apiKey });

  // 5b. Point to the target index.
  const index = pc.index(cfg.indexName);

  // 5c. Perceived performance: log optimistic start immediately.
  console.log("[Perceived] Starting recommendation refresh...");

  // 5d. Query Pinecone for similar vectors (dummy id + vector).
  const queryResponse = await index.query({
    id: "user-session-1",
    topK: cfg.topK,
    includeValues: false,
  });

  // 5e. Load WASM re-ranker.
  const wasm = await loadWasm();
  // @ts-ignore – minimal example
  const rank = wasm.exports.fakeRank as (n: number) => number;

  // 5f. Apply fake ranking to result count (simulate CPU work).
  const rankedCount = rank(queryResponse.matches.length);

  // 5g. Log completion with perceived performance note.
  console.log(`[Perceived] Refreshed ${rankedCount} items (optimistic).`);
}

// 6. Bootstrap the SaaS job using env vars.
const config: SaaSConfig = {
  apiKey: process.env.PINECONE_API_KEY ?? "dummy",
  indexName: "saas-prod-index",
  topK: 5,
};

// 7. Execute with top-level await (native TS runtime).
await refreshRecommendations(config);
