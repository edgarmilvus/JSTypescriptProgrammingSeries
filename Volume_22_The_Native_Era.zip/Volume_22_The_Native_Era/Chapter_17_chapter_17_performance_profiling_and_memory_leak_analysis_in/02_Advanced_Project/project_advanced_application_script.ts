/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file advanced-vector-cache.ts
 * @description Native TS SaaS vector cache with profiling and leak-safe design.
 * Target runtimes: Node.js, Bun, Deno (no bundler/transpiler needed).
 */

// 1. Import native performance APIs (available in Node, Bun, Deno)
import { performance, PerformanceObserver } from 'node:perf_hooks';

// 2. Pinecone Client (Node.js) for managed vector search
import { Pinecone } from '@pinecone-database/pinecone';

// 3. Supabase pgvector access (via postgres.js, native TS friendly)
import postgres from 'postgres';

// 4. Define a unified query result shape for both backends
interface VectorResult {
  id: string;
  score: number;
  payload: Record<string, unknown>;
}

// 5. Bounded cache to prevent memory leaks (Chapter 17: heap snapshot safe)
class BoundedVectorCache {
  private store = new Map<string, VectorResult[]>();
  private maxEntries: number;

  constructor(maxEntries = 500) {
    this.maxEntries = maxEntries;
  }

  // 6. Insert with eviction (oldest first) to bound memory
  set(key: string, value: VectorResult[]): void {
    if (this.store.size >= this.maxEntries) {
      const oldest = this.store.keys().next().value;
      if (oldest) this.store.delete(oldest);
    }
    this.store.set(key, value);
  }

  get(key: string): VectorResult[] | undefined {
    return this.store.get(key);
  }
}

// 7. Initialize backends (Pinecone + pgvector)
const pinecone = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const pg = postgres(process.env.SUPABASE_URL!, { max: 5 });

// 8. Cache instance shared at module scope (safe due to bounds)
const cache = new BoundedVectorCache(1000);

// 9. Performance observer to log long tasks (CPU profiling)
const obs = new PerformanceObserver((list) => {
  for (const entry of list.getEntries()) {
    // 10. Detect slow vector ops (>50ms) for profiling
    if (entry.duration > 50) {
      console.warn(`[PROFILE] Slow op: ${entry.name} ${entry.duration}ms`);
    }
  }
});
obs.observe({ entryTypes: ['measure'], buffered: true });

// 11. Pinecone similarity search wrapper
async function searchPinecone(index: string, vector: number[]): Promise<VectorResult[]> {
  const idx = pinecone.index(index);
  const res = await idx.query({ vector, topK: 10, includeMetadata: true });
  return res.matches.map(m => ({
    id: m.id,
    score: m.score ?? 0,
    payload: m.metadata ?? {}
  }));
}

// 12. pgvector similarity search wrapper
async function searchPgvector(embed: number[]): Promise<VectorResult[]> {
  const rows = await pg`
    SELECT id, 1 - (vec <=> ${JSON.stringify(embed)}::vector) AS score, payload
    FROM documents ORDER BY vec <=> ${JSON.stringify(embed)}::vector LIMIT 10
  `;
  return rows.map(r => ({ id: r.id, score: r.score, payload: r.payload }));
}

// 13. Main SaaS function: get recommendations with cache + precompute
export async function getRecommendations(
  userId: string,
  embedding: number[]
): Promise<VectorResult[]> {
  const cacheKey = `${userId}:${embedding.slice(0, 3).join(',')}`;

  // 14. Fast path: perceived performance via cache hit
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  // 15. Profiled remote fetch
  performance.mark('vec-start');
  const results = process.env.USE_PINECONE
    ? await searchPinecone('prod-index', embedding)
    : await searchPgvector(embedding);
  performance.mark('vec-end');
  performance.measure('vector-search', 'vec-start', 'vec-end');

  // 16. Store bounded cache (no leak)
  cache.set(cacheKey, results);
  return results;
}

// 17. Idle pre-computation to improve perceived performance
function schedulePrecompute(commonEmbeddings: number[][]) {
  // 18. Use setImmediate to avoid blocking request path
  setImmediate(async () => {
    for (const emb of commonEmbeddings) {
      const key = `pre:${emb.slice(0, 3).join(',')}`;
      if (!cache.get(key)) {
        const r = await searchPgvector(emb);
        cache.set(key, r);
      }
    }
  });
}

// 19. Example Next.js route usage
// export async function GET(req: Request) {
//   const data = await getRecommendations('u1', [0.1, 0.2, 0.3]);
//   schedulePrecompute([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]);
//   return Response.json(data);
// }
