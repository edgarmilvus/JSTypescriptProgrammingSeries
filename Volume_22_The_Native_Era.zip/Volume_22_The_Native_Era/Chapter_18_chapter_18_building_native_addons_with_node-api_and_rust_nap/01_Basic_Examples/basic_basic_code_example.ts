/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Simulated NAPI-RS native module binding.
 * In a real NAPI-RS project, this import resolves to a compiled
 * .node file generated from Rust code via `napi build`.
 */
import { greetUser } from './native-greet';

/**
 * SaaS platform user session context.
 * Represents a minimal shape of data received from an auth middleware.
 */
interface SaaSUserSession {
  /** Unique user identifier from the identity provider */
  userId: string;
  /** Display name used in UI and notifications */
  displayName: string;
  /** Active workspace or tenant ID for multi-tenancy */
  tenantId: string;
}

/**
 * Generates a personalized greeting using a native NAPI-RS function.
 * This is useful in a web app onboarding flow or notification service.
 *
 * @param session - The current user session from the SaaS platform
 * @returns A formatted greeting string produced by the native layer
 */
function createOnboardingGreeting(session: SaaSUserSession): string {
  // 1. Delegate string composition to the Rust-compiled native addon
  //    This avoids JS string allocation overhead for high-throughput paths
  const message = greetUser(session.displayName);

  // 2. Attach SaaS-specific contextual metadata
  return `[Tenant:${session.tenantId}] ${message}`;
}

// 3. Example usage inside a fictional SaaS API route handler
const demoSession: SaaSUserSession = {
  userId: 'usr_8291',
  displayName: 'Ada',
  tenantId: 'org_acme',
};

// 4. Invoke the greeting builder
const greeting = createOnboardingGreeting(demoSession);

// 5. Output the result (in a real app this would be sent via HTTP response)
console.log(greeting);
