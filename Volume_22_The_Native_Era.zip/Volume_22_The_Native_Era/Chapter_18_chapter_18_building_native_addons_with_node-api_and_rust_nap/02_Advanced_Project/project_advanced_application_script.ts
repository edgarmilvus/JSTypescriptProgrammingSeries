/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/classify/route.ts
// Next.js 14 App Router API route that uses a NAPI-RS native addon for headless LLM inference.

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
// NAPI-RS compiled addon: exposes Rust functions via Node-API (ABI-stable, no transpile needed)
import { classifyTicket } from '@saas/ticket-classifier';

/**
 * Zod schema mirroring the JSON Schema enforced by the native addon.
 * Used for runtime validation of the LLM response on the TypeScript side.
 */
const TicketCategorySchema = z.object({
  category: z.enum(['billing', 'technical', 'account', 'feedback']),
  priority: z.enum(['low', 'medium', 'high']),
  confidence: z.number().min(0).max(1),
  rationale: z.string().max(280),
});

// Infer the TypeScript type directly from Zod for end-to-end type safety.
type TicketCategory = z.infer<typeof TicketCategorySchema>;

/**
 * Few-shot examples passed to the native layer to guide the LLM.
 * These are serialized into the prompt inside the Rust addon.
 */
const FEW_SHOT_EXAMPLES = [
  {
    input: 'I was charged twice for my subscription.',
    output: { category: 'billing', priority: 'high', confidence: 0.98, rationale: 'Duplicate charge reported' },
  },
  {
    input: 'The dashboard fails to load on Safari.',
    output: { category: 'technical', priority: 'medium', confidence: 0.91, rationale: 'Browser-specific rendering bug' },
  },
] as const;

/**
 * JSON Schema string sent to the native addon to constrain LLM output.
 * The Rust side uses this to validate tokens before returning.
 */
const JSON_SCHEMA = JSON.stringify({
  type: 'object',
  properties: {
    category: { enum: ['billing', 'technical', 'account', 'feedback'] },
    priority: { enum: ['low', 'medium', 'high'] },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    rationale: { type: 'string', maxLength: 280 },
  },
  required: ['category', 'priority', 'confidence', 'rationale'],
});

/**
 * POST /api/classify
 * Receives a support ticket and returns a structured classification.
 *
 * @param req - Incoming Next.js request with { ticketText: string }
 * @returns NextResponse with validated TicketCategory or error
 */
export async function POST(req: NextRequest) {
  // 1. Parse the incoming request body from the SaaS client.
  const body = await req.json();
  const ticketText: string | undefined = body?.ticketText;

  // 2. Guard clause: ensure the required field is present.
  if (!ticketText || typeof ticketText !== 'string') {
    return NextResponse.json({ error: 'ticketText is required' }, { status: 400 });
  }

  try {
    // 3. Invoke the NAPI-RS native addon (Rust function exposed via Node-API).
    // The addon runs headless inference using few-shot prompting and JSON Schema output.
    const rawResult = await classifyTicket(
      ticketText,
      JSON_SCHEMA,
      FEW_SHOT_EXAMPLES
    );

    // 4. Parse the native addon's string output into a JavaScript object.
    const parsed = JSON.parse(rawResult);

    // 5. Validate the object against the Zod schema (defensive TS-side check).
    const validated: TicketCategory = TicketCategorySchema.parse(parsed);

    // 6. Return the strongly-typed classification to the frontend.
    return NextResponse.json({ success: true, data: validated });
  } catch (err) {
    // 7. Handle native addon errors or Zod validation failures gracefully.
    console.error('Classification failed:', err);
    return NextResponse.json(
      { error: 'Failed to classify ticket' },
      { status: 500 }
    );
  }
}
