/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// index.d.ts - Type declarations for the native module
/**
 * Computes the BLAKE3 hash of a binary buffer.
 * @param input Binary data as Uint8Array or Node Buffer
 * @returns Lowercase hexadecimal BLAKE3 digest (64 characters)
 */
export function hash_with_blake3(input: Uint8Array): string;

// node.test.mjs
import { hash_with_blake3 } from './index.js';
const out = hash_with_blake3(Uint8Array.from([1, 2, 3, 4]));
console.assert(out.length === 64, 'expected 64-char hex');
console.log('node ok', out);

// bun.test.ts
import { hash_with_blake3 } from './index.ts';
const out = hash_with_blake3(Uint8Array.from([1, 2, 3, 4]));
if (out.length !== 64) throw new Error('bad');
console.log('bun ok', out);

// deno.test.ts
import { hash_with_blake3 } from './index.ts';
const out = hash_with_blake3(Uint8Array.from([1, 2, 3, 4]));
if (out.length !== 64) throw new Error('bad');
console.log('deno ok', out);
