/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface GraphState {
  messages: Array<{ role: string; content: string }>;
  scratchpad: Record<string, unknown>;
  confidence: number;
}

// native.d.ts
export function reduce_agent_state(states: Partial<GraphState>[]): Promise<GraphState>;

// langgraph-node.ts
import { StateGraph } from "@langchain/langgraph";
import { reduce_agent_state } from './native.js';

const node = async (partials: Partial<GraphState>[]) => {
  const merged = await reduce_agent_state(partials);
  return merged;
};

// test.ts
import { reduce_agent_state } from './native.js';
const start = Date.now();
const states = Array.from({ length: 50 }, () => ({
  messages: [{ role: 'user', content: 'x' }],
  scratchpad: { k: Math.random() },
  confidence: Math.random()
}));
reduce_agent_state(states).then(() => {
  setImmediate(() => console.log('lag ms', Date.now() - start));
});
