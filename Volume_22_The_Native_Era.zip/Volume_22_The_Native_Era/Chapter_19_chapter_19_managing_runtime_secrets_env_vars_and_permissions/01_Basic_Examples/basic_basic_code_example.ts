/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Runtime Secret Loader (No Bundlers, No Transpilers)
 * 
 * This module demonstrates the minimal "Hello World" pattern for
 * managing runtime secrets safely in modern JavaScript runtimes.
 */

// 1. Import Zod for runtime validation and TypeScript inference
import { z } from "zod";

// 2. Define the shape of required environment variables for our SaaS
const SaasEnvSchema = z.object({
  /** Database connection string (NEVER log this) */
  DATABASE_URL: z.string().url(),
  /** Secret used to sign sessions */
  SESSION_SECRET: z.string().min(16),
  /** Public site URL used in emails */
  PUBLIC_SITE_URL: z.string().url(),
});

// 3. Infer the exact TypeScript type from the Zod schema
type SaasEnv = z.infer<typeof SaasEnvSchema>;

// 4. Load and validate environment variables at startup
function loadSecrets(): SaasEnv {
  // Node/Bun: process.env is populated by .env automatically in Bun/Node 20+
  // Deno: use Deno.env.toObject() instead of process.env
  const rawEnv =
    typeof process !== "undefined" && process.env
      ? process.env
      : (globalThis as any).Deno?.env.toObject() ?? {};

  // Validate and parse; throws if invalid
  const parsed = SaasEnvSchema.safeParse(rawEnv);

  if (!parsed.success) {
    console.error("Invalid environment configuration");
    throw new Error(parsed.error.message);
  }

  return parsed.data;
}

// 5. Single safe accessor used across the app
const env = loadSecrets();

// 6. Example SaaS usage: a fake "billing service" init
/**
 * Initializes the billing subsystem using validated secrets.
 */
function initBillingService() {
  // Uses only validated, typed secrets
  const dbUrl = env.DATABASE_URL;
  // NEVER: console.log(dbUrl);
  return { status: "ready", site: env.PUBLIC_SITE_URL };
}

// 7. Demonstrate safe startup
const billing = initBillingService();
console.log("Billing service:", billing.status);
