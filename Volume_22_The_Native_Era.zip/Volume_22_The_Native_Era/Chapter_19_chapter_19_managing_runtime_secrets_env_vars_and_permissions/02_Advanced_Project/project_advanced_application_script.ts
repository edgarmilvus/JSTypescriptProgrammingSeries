/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script: Secure Runtime Secret Management
 * Context: SaaS Web App using Next.js (App Router) + Modern Runtime
 * 
 * This module demonstrates:
 *  - Native env loading without bundlers/transpilers
 *  - Runtime-agnostic secret access (Node/Bun vs Deno)
 *  - Type narrowing via custom type guards
 *  - Prevention of secret leakage into logs and UIState
 */

// ----------------------------------------------------------------------------
// 1. DEFINE RUNTIME ABSTRACTION TYPES
// ----------------------------------------------------------------------------

/**
 * Represents the shape of a Node.js or Bun process environment.
 */
type NodeLikeEnv = {
  readonly kind: "node" | "bun";
  get(key: string): string | undefined;
};

/**
 * Represents the shape of the Deno environment API.
 * Deno requires explicit permission flags (e.g., --allow-env=DB_URL).
 */
type DenoLikeEnv = {
  readonly kind: "deno";
  get(key: string): string | undefined;
};

/**
 * Union of supported runtime environments.
 */
type RuntimeEnv = NodeLikeEnv | DenoLikeEnv;

// ----------------------------------------------------------------------------
// 2. TYPE GUARD FOR DENO RUNTIME
// ----------------------------------------------------------------------------

/**
 * Type Guard: checks whether the provided env object is Deno-like.
 * Under the hood, Deno exposes a global `Deno` namespace with `Deno.env`.
 * This guard eliminates the other union members for the compiler.
 */
function isDenoEnv(env: RuntimeEnv): env is DenoLikeEnv {
  return env.kind === "deno";
}

// ----------------------------------------------------------------------------
// 3. SECURE ENVIRONMENT LOADER
// ----------------------------------------------------------------------------

/**
 * Detects the current runtime and returns a normalized env accessor.
 * No bundlers/transpilers are used; this runs natively.
 */
function loadRuntimeEnv(): RuntimeEnv {
  // Deno explicitly grants env permissions; if absent, this throws at runtime.
  if (typeof (globalThis as any).Deno !== "undefined") {
    const deno = (globalThis as any).Deno;
    return {
      kind: "deno",
      get: (k: string) => deno.env.get(k),
    };
  }

  // Node.js and Bun both expose process.env natively.
  const node = globalThis as any;
  const envSource = node.process?.env ?? {};
  return {
    kind: "node", // Bun is API-compatible with Node for env access
    get: (k: string) => envSource[k],
  };
}

// ----------------------------------------------------------------------------
// 4. SECRET CONFIGURATION SCHEMA & VALIDATION
// ----------------------------------------------------------------------------

/**
 * Strongly-typed secret configuration.
 * Never expose this object directly to UIState.
 */
interface SanitizedSecrets {
  dbPoolSize: number;
  aiProvider: "openai" | "local";
  isProd: boolean;
}

/**
 * Reads and validates required secrets.
 * Throws if misconfigured to fail fast (secure by default).
 */
function loadSecrets(env: RuntimeEnv): SanitizedSecrets {
  const rawDbUrl = env.get("DB_URL");
  const rawAiKey = env.get("OPENAI_KEY");
  const rawEnv = env.get("NODE_ENV");

  // Type narrowing on runtime kind for permission-aware logging
  if (isDenoEnv(env)) {
    // Deno already enforced --allow-env; we log minimally
    console.info("[secure-boot] Deno env permission model active");
  } else {
    console.info("[secure-boot] Node/Bun native env loaded");
  }

  // Validate presence without echoing values
  if (!rawDbUrl) throw new Error("Missing DB_URL");
  if (!rawEnv) throw new Error("Missing NODE_ENV");

  // Use AI key only if present; otherwise local transformer
  const aiProvider = rawAiKey ? "openai" : "local";

  return {
    dbPoolSize: 10,
    aiProvider,
    isProd: rawEnv === "production",
  };
}

// ----------------------------------------------------------------------------
// 5. SAFE UI STATE MAPPING (NO SECRET LEAKAGE)
// ----------------------------------------------------------------------------

/**
 * Maps sanitized secrets to a presentational UIState slice.
 * UIState never receives raw credentials.
 */
function toUIState(secrets: SanitizedSecrets) {
  return {
    showAiPanel: secrets.aiProvider === "openai",
    environment: secrets.isProd ? "Production" : "Development",
  };
}

// ----------------------------------------------------------------------------
// 6. MAIN EXECUTION (Next.js Route Handler Context)
// ----------------------------------------------------------------------------

/** Example invocation from a Next.js server action or route. */
export async function getDashboardConfig() {
  const env = loadRuntimeEnv();
  const secrets = loadSecrets(env);
  const ui = toUIState(secrets);
  return ui; // Safe to stream to client UIState
}
