/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// secrets-cli.ts
// Run with: node --env-file=.env secrets-cli.ts  (Node 20.6+)
// or: bun run secrets-cli.ts (Bun auto-loads .env)
// or: deno run --env-file=.env --allow-env secrets-cli.ts (Deno)

// Deno vs Node/Bun permission model:
// Deno requires explicit --allow-env to read ANY env var (capability-based).
// Node/Bun give unrestricted process.env access by default (fail-open).

// DANGER: console.log(process.env) prints ALL secrets to stdout/logs.
// In large codebases, intercept by overriding console.log or using a
// redacting logger that strips known secret keys before emission.

import { spawn } from "node:child_process";

// For Deno compatibility, use a unified getter:
function getEnv(key: string): string | undefined {
  // @ts-ignore - Deno global
  if (typeof Deno !== "undefined") return Deno.env.get(key);
  return process.env[key];
}

const API_SECRET = getEnv("API_SECRET");
if (!API_SECRET) {
  throw new Error("API_SECRET is missing from environment");
}

// Masked view only
console.log("API_SECRET=****");

// Spawn child WITHOUT forwarding API_SECRET explicitly.
// We pass a shallow clone of env minus the secret.
const childEnv = { ...(process.env || {}), LOG_LEVEL: getEnv("LOG_LEVEL") || "info" };
delete (childEnv as any).API_SECRET;

spawn("printenv", [], {
  env: childEnv, // child cannot see API_SECRET
  stdio: "inherit",
});
