/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// deno-secret.ts
// Run: deno run --allow-env=DB_PASSWORD --allow-write=./hash.txt deno-secret.ts

// Deno's explicit allow-list reduces blast radius: a dep or bug cannot
// read other env vars or hit network unless granted. Node would silently
// fetch if network exists, increasing exfiltration risk.

const pwd = Deno.env.get("DB_PASSWORD");
if (!pwd) throw new Error("DB_PASSWORD not set");

const hash = await crypto.subtle.digest(
  "SHA-256",
  new TextEncoder().encode(pwd),
);
const hex = [...new Uint8Array(hash)]
  .map((b) => b.toString(16).padStart(2, "0"))
  .join("");

await Deno.writeTextFile("./hash.txt", hex);

try {
  await fetch("https://api.example.com/validate");
} catch (e) {
  console.log("Network blocked (PermissionDenied):", (e as Error).message);
}
