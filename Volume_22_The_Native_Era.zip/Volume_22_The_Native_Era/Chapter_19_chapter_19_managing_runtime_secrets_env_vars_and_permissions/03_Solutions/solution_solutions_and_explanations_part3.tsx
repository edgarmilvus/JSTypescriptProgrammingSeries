/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SecretStatusPanel.tsx
// Use: bunx tsx app.tsx or deno run with JSX support

function getSecretValue(name: string): string | undefined {
  // @ts-ignore
  if (typeof Deno !== "undefined") return Deno.env.get(name);
  // Edge/Node/Bun
  return globalThis.process?.env[name];
}

export function SecretStatusPanel({
  expectedSecrets,
  allowPreview,
}: {
  expectedSecrets: string[];
  allowPreview: boolean;
}) {
  // SECURITY: never interpolate full secret
  return (
    <ul>
      {expectedSecrets.map((name) => {
        const val = getSecretValue(name);
        const present = !!val;
        // Edge Runtime: no Deno.env, only process.env injected at deploy.
        // Logging must be minimal to avoid leaking in edge logs.
        const masked = allowPreview && val ? val.slice(0, 4) + "***" : "";
        return (
          <li key={name}>
            <span style={{ color: present ? "green" : "red" }}>●</span>
            {name}: {present ? "loaded" : "missing"}
            {allowPreview && masked && <code> ({masked})</code>}
          </li>
        );
      })}
    </ul>
  );
}
// Avoid leaking via React DevTools: do not store raw secret in useState/state.
