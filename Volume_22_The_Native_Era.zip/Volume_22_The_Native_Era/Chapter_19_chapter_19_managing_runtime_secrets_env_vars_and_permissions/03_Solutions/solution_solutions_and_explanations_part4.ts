/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// critique.md (analysis only, no corrected code)

// Snippet A (Node):
// 1) Leaks to logs: YES (console.log(process.env))
// 2) Leaks to subprocess: YES (spawns curl with key in header + full env)
// 3) Permission model: Node has none; Deno --allow-env/--allow-run would block.

// Snippet B (Bun):
// 1) Leaks to logs: YES (console.log key)
// 2) Leaks outbound: YES (fetch with auth header)
// 3) Permission model: Bun unrestricted; Deno --allow-net/--allow-env needed.

// Snippet C (Deno):
// 1) Leaks to logs: NO (masked)
// 2) Leaks outbound/subprocess: NO (no key passed)
// 3) Permission model: Deno permissions satisfied minimally; SAFE.

// Snippet D (Edge):
// 1) Leaks to logs: YES (JSON.stringify process.env)
// 2) Leaks outbound: N/A shown, but env exposed
// 3) Permission model: Edge has no flag; deploy-time isolation only.
