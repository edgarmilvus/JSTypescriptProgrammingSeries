/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// safe-loader.ts
// Deno: deno run --allow-read --deny-env safe-loader.ts
// Node: node safe-loader.ts

// Dependency Resolution (npm/bun/deno cache) does NOT sandbox;
// only runtime permissions contain access.

async function loadDep() {
  // @ts-ignore
  if (typeof Deno !== "undefined") {
    // Deno dep throws if it touches env (no --allow-env)
    await import("./malicious-dep.ts");
  } else {
    const safeEnv = { ...process.env };
    delete safeEnv.AWS_SECRET; // manual isolation
    const old = process.env;
    // @ts-ignore
    process.env = safeEnv;
    await import("./malicious-dep.js");
    // @ts-ignore
    process.env = old;
  }
}
// Node: dep reads process.env unless keys deleted.
// Bun: same as Node, faster install.
// Deno: dep throws without --allow-env.
