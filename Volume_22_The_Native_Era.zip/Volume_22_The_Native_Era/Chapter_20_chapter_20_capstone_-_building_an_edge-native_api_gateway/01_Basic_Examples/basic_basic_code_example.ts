/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Edge-native API Gateway - Basic Example
 * Runs on Node.js (>=18), Bun, and Deno without bundlers or transpilers.
 * Context: A SaaS platform where each request belongs to a tenant.
 */

// Deno/Bun/Node edge entrypoint uses the standard `fetch` handler.
// We export a default function named `fetch` to satisfy runtime contracts.
export default {
  /**
   * Handles an incoming HTTP request at the edge.
   * @param req Standard Web Request object provided by the runtime.
   * @returns A standard Web Response object.
   */
  async fetch(req: Request): Promise<Response> {
    // 1. Extract the tenant identifier from the `x-tenant-id` header.
    // In a SaaS edge gateway, routing and auth often start with tenant context.
    const tenantId: string | null = req.headers.get("x-tenant-id");

    // 2. If no tenant header is present, reject early with 400.
    // Edge runtimes excel at cheap, fast middleware-like rejections.
    if (!tenantId) {
      return new Response(
        JSON.stringify({ error: "Missing x-tenant-id header" }),
        {
          status: 400,
          headers: { "content-type": "application/json" },
        }
      );
    }

    // 3. Construct a minimal SaaS-style greeting payload.
    // This simulates a gateway forwarding to a downstream service.
    const payload = {
      message: `Hello tenant ${tenantId}, welcome to the edge gateway.`,
      region: "edge-auto",
      timestamp: new Date().toISOString(),
    };

    // 4. Return a JSON response using the native Response class.
    // No transpiler needed: TypeScript types are erased at runtime by the JS engine.
    return new Response(JSON.stringify(payload), {
      status: 200,
      headers: {
        "content-type": "application/json",
        "cache-control": "no-store",
      },
    });
  },
};
