/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/gateway/route.ts
// Next.js Edge Route Handler (runs on Edge Runtime: V8 Isolate, no Node polyfills)

import { NextRequest, NextResponse } from 'next/server';
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * JSON Schema used to force the LLM to return a predictable structure.
 * This avoids fragile string parsing and enables strict runtime validation.
 */
const insightSchema = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    riskLevel: { type: 'string', enum: ['low', 'medium', 'high'] },
    recommendations: {
      type: 'array',
      items: { type: 'string' }
    }
  },
  required: ['summary', 'riskLevel', 'recommendations']
} as const;

/**
 * Zod mirror of the JSON Schema for runtime parsing at the edge.
 * Same shape, but executable validation in TypeScript.
 */
const InsightZod = z.object({
  summary: z.string(),
  riskLevel: z.enum(['low', 'medium', 'high']),
  recommendations: z.array(z.string())
});

/**
 * Mock tenant registry (in real SaaS this is a KV store or DB).
 * Demonstrates edge-native routing without a bundler config.
 */
const TENANTS = new Map<string, { plan: string; region: string }>([
  ['acme', { plan: 'pro', region: 'us-east' }],
  ['globex', { plan: 'enterprise', region: 'eu-west' }]
]);

/**
 * Authenticates the request using a Bearer token.
 * Returns tenant key or null if invalid.
 */
function authenticate(req: NextRequest): string | null {
  const auth = req.headers.get('authorization');
  if (!auth?.startsWith('Bearer ')) return null;
  const token = auth.slice(7);
  // Simple demo token equals tenant key
  return TENANTS.has(token) ? token : null;
}

/**
 * Main Edge API Gateway handler.
 * Supports GET (health), POST (chat + JSON Schema LLM insight).
 */
export async function POST(req: NextRequest) {
  // 1. Authenticate at the edge before any heavy work
  const tenant = authenticate(req);
  if (!tenant) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // 2. Parse inbound payload (native Request.json() – no body-parser needed)
  const body = await req.json();
  const userMessage: string = body.message ?? '';

  // 3. Route based on tenant plan (edge logic, zero build step)
  const meta = TENANTS.get(tenant)!;
  if (meta.plan === 'enterprise') {
    // Enterprise gets higher token limit and stricter schema
    // (demonstrates runtime-aware gateway behavior)
  }

  // 4. Call LLM with JSON Schema output mode
  // Under the hood: model returns text that conforms to insightSchema
  const result = await streamText({
    model: openai('gpt-4o-mini'),
    messages: [{ role: 'user', content: userMessage }],
    // Instruct model to emit JSON matching schema
    experimental_output: insightSchema
  });

  // 5. Stream response to client (Edge Runtime supports streaming)
  // We intercept the final text to validate with Zod
  const reader = result.textStream.getReader();
  let full = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    full += value;
  }

  // 6. Parse and validate structured LLM output
  try {
    const parsed = InsightZod.parse(JSON.parse(full));
    return NextResponse.json({
      tenant,
      region: meta.region,
      insight: parsed
    });
  } catch (e) {
    return NextResponse.json(
      { error: 'Invalid LLM output', detail: String(e) },
      { status: 502 }
    );
  }
}

/**
 * Lightweight health check for gateway liveness.
 */
export async function GET() {
  return NextResponse.json({ status: 'edge-gateway-ok' });
}
