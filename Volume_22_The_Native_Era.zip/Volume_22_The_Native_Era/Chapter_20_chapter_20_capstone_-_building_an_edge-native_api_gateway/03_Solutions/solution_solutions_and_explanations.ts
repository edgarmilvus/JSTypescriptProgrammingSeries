/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// edge-router.ts

// Runtime detection (must be first)
const runtime = typeof Bun !== 'undefined' ? 'bun'
  : typeof Deno !== 'undefined' ? 'deno'
  : 'node';

// URLPattern is preferred at the edge because it is a web standard (WinterCG compliant),
// parses paths/queries/hosts consistently across runtimes, and avoids regex pitfalls
// (regex routing is error-prone, non-standard, and harder to secure at the edge).
const routes: { method: string; pattern: URLPattern; handler: (req: Request) => Response | Promise<Response> }[] = [];

function route(method: string, path: string, handler: (req: Request) => Response | Promise<Response>) {
  routes.push({ method, pattern: new URLPattern({ pathname: path }), handler });
}

// Define routes
route('GET', '/health', () => new Response('OK'));
route('POST', '/echo', async (req) => new Response(await req.text(), { status: 200 }));
route('GET', '/runtime', () => Response.json({ runtime }));

async function handle(req: Request): Promise<Response> {
  const url = new URL(req.url);
  for (const r of routes) {
    if (r.method === req.method && r.pattern.test(url)) {
      return await r.handler(req);
    }
  }
  return new Response('Not Found', { status: 404 });
}

function listen(port: number) {
  if (runtime === 'bun') {
    Bun.serve({ port, fetch: handle });
  } else if (runtime === 'deno') {
    Deno.serve({ port, handler: handle });
  } else {
    // Node.js via node:http adapted to fetch
    const http = require('node:http');
    http.createServer(async (req, res) => {
      const body = req.method === 'GET' ? undefined : await new Promise<Buffer>((r) => {
        const c: Buffer[] = []; req.on('data', d => c.push(d)); req.on('end', () => r(Buffer.concat(c)));
      });
      const request = new Request(`http://${req.headers.host}${req.url}`, {
        method: req.method, headers: req.headers as any, body
      });
      const response = await handle(request);
      res.statusCode = response.status;
      response.headers.forEach((v, k) => res.setHeader(k, v));
      res.end(await response.text());
    }).listen(port);
  }
  console.log(`Listening on ${port} via ${runtime}`);
}

listen(3000);
