/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// ws-proxy.ts
const backend = Deno.env.get('BACKEND_WS') || Bun.env.BACKEND_WS || process.env.BACKEND_WS!;
const runtime = typeof Bun !== 'undefined' ? 'bun' : typeof Deno !== 'undefined' ? 'deno' : 'node';

// MessageEvent is used in browser-like runtimes (Deno/Bun); Node 22+ global WebSocket also emits 'message' with similar shape.
function start() {
  if (runtime === 'deno') {
    Deno.serve({ handler: (req) => {
      if (req.headers.get('upgrade') === 'websocket') {
        const { socket, response } = Deno.upgradeWebSocket(req);
        const bw = new WebSocket(backend);
        socket.onmessage = (e) => { bw.send(e.data); };
        bw.onmessage = (e) => { socket.send(e.data); };
        setInterval(() => socket.send('ping'), 30000);
        return response;
      }
      return new Response('No WS');
    }});
  } else if (runtime === 'bun') {
    Bun.serve({ fetch: (req) => {
      if (req.headers.get('upgrade') === 'websocket') {
        const ws = new WebSocket(backend);
        const up = new Bun.WebSocket(req);
        up.onmessage = (e) => ws.send(e.data);
        ws.onmessage = (e) => up.send(e.data);
        setInterval(() => up.ping(), 30000);
        return new Response();
      }
      return new Response('No WS');
    }});
  } else {
    const http = require('node:http');
    http.createServer().on('upgrade', (req, sock) => {
      const ws = new WebSocket(backend);
      ws.onmessage = (e) => sock.write(e.data);
      sock.on('data', (d) => ws.send(d.toString()));
      setInterval(() => ws.ping(), 30000);
    }).listen(3000);
  }
}
start();
