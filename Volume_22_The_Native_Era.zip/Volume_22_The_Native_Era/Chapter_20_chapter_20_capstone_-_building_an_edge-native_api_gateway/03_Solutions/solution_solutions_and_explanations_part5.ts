/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// rate-limit-graph.ts
interface GraphState { ip: string; count: number; blocked: boolean; }

const state: Record<string, GraphState> = {};

function increment(s: GraphState): GraphState { s.count++; return s; }
function checkLimit(s: GraphState): GraphState {
  if (s.count > 10) return deny(s); return allow(s);
}
function deny(s: GraphState): GraphState { s.blocked = true; return s; }
function allow(s: GraphState): GraphState { return s; }

export function process(ip: string): GraphState {
  const s = state[ip] || (state[ip] = { ip, count: 0, blocked: false });
  // increment -> checkLimit -> (deny|allow)
  return checkLimit(increment(s));
}
// Mirrors LangGraph StateGraph: nodes mutate shared state; Max Iteration Policy = deny at >10.
