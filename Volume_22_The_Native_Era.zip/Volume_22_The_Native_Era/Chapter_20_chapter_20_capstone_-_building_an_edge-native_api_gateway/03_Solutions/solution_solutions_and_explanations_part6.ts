/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// json-guard.ts
const schema = {
  type: 'object',
  properties: { action: { type: 'string' }, confidence: { type: 'number' } },
  required: ['action', 'confidence']
};

function validate<T>(data: any, sch: any): T {
  for (const k of sch.required) if (!(k in data)) throw new Error(`Missing ${k}`);
  if (typeof data.action !== 'string' || typeof data.confidence !== 'number') throw new Error('Type error');
  return data as T;
}

// Route usage (pseudo with Exercise 1 router)
route('POST', '/llm', async (req) => {
  try {
    const body = await req.json();
    const v = validate<{action:string;confidence:number}>(body, schema);
    return Response.json(v);
  } catch (e:any) { return new Response(e.message, { status: 422 }); }
});
// JSON Schema Output ensures predictable parsing in intelligent edge apps.
