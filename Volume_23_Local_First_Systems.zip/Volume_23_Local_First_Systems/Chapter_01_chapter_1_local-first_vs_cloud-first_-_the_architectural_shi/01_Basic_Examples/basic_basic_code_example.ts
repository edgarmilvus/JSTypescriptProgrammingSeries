/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Local-First SaaS Starter: Minimal Note Sync
 * Demonstrates local ownership of data before cloud replication.
 */

// ----------------------------------------------------------------------------
// 1. DOMAIN MODEL
// ----------------------------------------------------------------------------

/**
 * Represents a user-created note in our SaaS app.
 * The `localId` is generated on-device and is the source of truth.
 */
interface LocalNote {
  localId: string;      // UUID created locally
  content: string;     // User text
  updatedAt: number;   // Device timestamp (ms)
  synced: boolean;     // Whether cloud has acknowledged
}

// ----------------------------------------------------------------------------
// 2. LOCAL STORE (THE "SOURCE OF TRUTH")
// ----------------------------------------------------------------------------

/**
 * A naive in-memory store standing in for IndexedDB.
 * In production, this would be a WASM DB or CRDT-backed store.
 */
class LocalNoteStore {
  private notes: Map<string, LocalNote> = new Map();

  /**
   * Persist a note locally first—no network involved.
   */
  saveLocal(note: LocalNote): void {
    this.notes.set(note.localId, note);
  }

  /**
   * Retrieve all locally stored notes.
   */
  getAllLocal(): LocalNote[] {
    return Array.from(this.notes.values());
  }

  /**
   * Mark a note as synced after cloud confirmation.
   */
  markSynced(localId: string): void {
    const note = this.notes.get(localId);
    if (note) {
      note.synced = true;
    }
  }
}

// ----------------------------------------------------------------------------
// 3. CLOUD STUB (THE "SECONDARY" REPLICA)
// ----------------------------------------------------------------------------

/**
 * Simulates a cloud API that only accepts already-created local notes.
 */
class CloudSyncStub {
  private cloudNotes: Map<string, LocalNote> = new Map();

  /**
   * Pretend HTTP POST to server.
   * Returns true if "accepted".
   */
  async pushToCloud(note: LocalNote): Promise<boolean> {
    // Simulate latency
    await new Promise((r) => setTimeout(r, 100));
    this.cloudNotes.set(note.localId, { ...note, synced: true });
    return true;
  }
}

// ----------------------------------------------------------------------------
// 4. APP SERVICE (LOCAL-FIRST ORCHESTRATION)
// ----------------------------------------------------------------------------

/**
 * Orchestrates local save then background sync.
 */
class NoteAppService {
  private store = new LocalNoteStore();
  private cloud = new CloudSyncStub();

  /**
   * Create a note locally first (offline-ready).
   */
  createNote(content: string): LocalNote {
    const note: LocalNote = {
      localId: crypto.randomUUID(),
      content,
      updatedAt: Date.now(),
      synced: false,
    };
    this.store.saveLocal(note); // (A) Local-first write
    return note;
  }

  /**
   * Sync all unsynced local notes to cloud.
   */
  async syncPending(): Promise<void> {
    const pending = this.store.getAllLocal().filter((n) => !n.synced);
    for (const note of pending) {
      const ok = await this.cloud.pushToCloud(note); // (B) Cloud is secondary
      if (ok) this.store.markSynced(note.localId);
    }
  }
}

// ----------------------------------------------------------------------------
// 5. USAGE (SAAS CONTEXT)
// ----------------------------------------------------------------------------

/**
 * Bootstrap the app and demonstrate local-first flow.
 */
async function main(): Promise<void> {
  const app = new NoteAppService();

  // User types offline
  const n1 = app.createNote("Draft Q3 plan (offline)");
  console.log("Saved locally:", n1.localId, "synced:", n1.synced);

  // Later, connection returns
  await app.syncPending();
  console.log("After sync, all notes:", app.store.getAllLocal());
}

main();
