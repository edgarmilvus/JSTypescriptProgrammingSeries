/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// File: app/actions/syncAndStream.tsx
// Context: Next.js 14+ Server Action used in a Local-First SaaS Control Panel
// ============================================================================

import "server-only";
import { renderToPipeableStream } from "react-dom/server";
import { PassThrough } from "node:stream";
import type { Readable } from "node:stream";
import type { ActionResult } from "@/lib/types";

/**
 * Strict Type Discipline is applied project-wide via tsconfig `strict: true`.
 * We explicitly model the sync request to avoid implicit any and null hazards.
 */
interface SyncRequest {
  readonly deviceId: string;
  readonly pendingOps: ReadonlyArray<{
    readonly opId: string;
    readonly table: string;
    readonly payload: unknown;
  }>;
  readonly lastSyncVector: Record<string, number>;
}

/**
 * Dependency Resolution ensures that the required CRDT and WASM DB packages
 * are present in node_modules before the server attempts to compute a diff.
 * Here we lazily import the WASM DB binding to avoid cold-start overhead.
 */
async function resolveSyncDependencies(): Promise<{
  wasmDb: typeof import("@localfirst/wasm-db");
}> {
  // npm/yarn already placed @localfirst/wasm-db in node_modules; we resolve it.
  const wasmDb = await import("@localfirst/wasm-db");
  await wasmDb.init(); // load WASM binary from local dependency tree
  return { wasmDb };
}

/**
 * streamable-ui pattern: we return a React Node that the Vercel AI SDK can
 * stream. The server sends text tokens and a component in one response.
 */
function ConflictResolverCard(props: {
  conflicts: number;
}): JSX.Element {
  return (
    <div className="rounded border p-4">
      <p>You have {props.conflicts} merge conflicts from offline edits.</p>
      <button onClick={() => console.log("resolve")}>Resolve Now</button>
    </div>
  );
}

/**
 * Server Action entry point.
 * Demonstrates local-first philosophy: server only *reconciles*, not *owns*.
 */
export async function streamSyncSummary(
  req: SyncRequest
): Promise<ActionResult> {
  // 1. Enforce strict null checks on incoming device identity
  if (!req.deviceId) {
    throw new Error("deviceId must be present (strictNullChecks enforced)");
  }

  // 2. Dependency Resolution for WASM DB used to compute CRDT diff
  const { wasmDb } = await resolveSyncDependencies();

  // 3. Local-first reconciliation: server merges, does not overwrite
  const conflicts = wasmDb.computeConflicts(req.pendingOps, req.lastSyncVector);

  // 4. Build a streamable UI node (text + interactive component)
  const ui = (
    <div>
      <p>Streaming summary for device {req.deviceId}…</p>
      <ConflictResolverCard conflicts={conflicts.length} />
    </div>
  );

  // 5. Convert React tree to stream using Next.js streaming primitives
  const stream: Readable = new PassThrough();
  renderToPipeableStream(ui, {
    onShellReady() {
      // 6. Push raw AI tokens after shell (simulated local-first AI proxy)
      stream.push("Offline edits analyzed. ");
      stream.push("Awaiting user merge confirmation.\n");
    },
    onAllReady() {
      stream.push(null);
    },
  });

  return { stream, conflicts: conflicts.length };
}
