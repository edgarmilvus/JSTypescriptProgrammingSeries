/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Local-first notes model

export type Note = {
  id: string;            // client-generated UUID
  content: string;       // note body
  updatedAt: number;     // local device time (ms since epoch)
  syncState: 'local' | 'synced' | 'conflict'; // local sync status
};

export interface LocalNoteStore {
  loadAll(): Promise<Note[]>;
  save(note: Note): Promise<void>;
  markSynced(id: string): Promise<void>;
}

export async function simulateColdStart(store: LocalNoteStore): Promise<Note[]> {
  /*
   * COLD START IN LOCAL-FIRST VS CLOUD-FIRST:
   * In a cloud-first app, "cold start" means the client boots, then must wait for a network
   * round-trip to fetch initial data from a remote server before the UI is usable. If offline,
   * the app is unusable or shows a spinner indefinitely.
   * In a local-first web app, "cold start" means loading persisted state (e.g., IndexedDB)
   * from the device itself. The data is immediately available with no network dependency.
   * The cost is local disk read time and potential migration, not latency to a data center.
   * This function measures that local load time to highlight the difference.
   */
  const start = performance.now();
  const notes = await store.loadAll();
  const duration = performance.now() - start;
  console.log(`Local-first cold start loaded ${notes.length} notes in ${duration}ms`);
  return notes;
}

/*
 * LOCAL-FIRST ARCHITECTURE NOTES (>=200 words):
 * 
 * Latency is reduced in local-first editing because every keystroke mutates state that lives
 * on the user's device. There is no debounce-to-server round trip; the UI updates synchronously
 * from a local store such as IndexedDB or an in-memory CRDT. The user perceives zero network
 * latency, even on flaky connections.
 * 
 * Resilience improves when the server is not the source of truth because the device remains
 * fully functional during network partitions, server outages, or airplane mode. Data is never
 * locked behind a failed fetch. The user retains read and write autonomy, and sync becomes a
 * background concern rather than a blocking dependency.
 * 
 * New complexity appears when two devices edit the same note offline: without a central server
 * to enforce last-write-wins, both edits diverge. On reconnect, the system must detect concurrent
 * changes and either merge them (e.g., via CRDTs) or surface a conflict state to the user.
 * This requires explicit versioning, conflict UI, and deterministic merge logic that cloud-first
 * apps offload to a transactional backend. Local-first shifts that burden into the client.
 */
