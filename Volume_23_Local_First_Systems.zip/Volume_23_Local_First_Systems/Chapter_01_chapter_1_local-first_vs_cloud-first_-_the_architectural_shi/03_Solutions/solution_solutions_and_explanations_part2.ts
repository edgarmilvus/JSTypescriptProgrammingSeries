/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type ZeroShotInput = {
  text: string;
  candidateLabels: string[];
};

export type ZeroShotResult = {
  labels: string[];
  scores: number[];
};

export interface LocalZeroShotClassifier {
  isReady(): boolean;
  classify(input: ZeroShotInput): Promise<ZeroShotResult>;
}

export type EdgeFirstStrategy = {
  local: LocalZeroShotClassifier | null;
  cloudFallback: (input: ZeroShotInput) => Promise<ZeroShotResult>;
  maxColdStartMs: number;
};

export async function routeClassification(
  strategy: EdgeFirstStrategy,
  input: ZeroShotInput
): Promise<ZeroShotResult> {
  // No local model available -> must use cloud
  if (!strategy.local) {
    return strategy.cloudFallback(input);
  }

  // Local model exists but not ready: estimate cold start cost
  if (!strategy.local.isReady()) {
    const estStart = performance.now();
    // In real code we'd await warm-up; here we approximate with a timeout check
    if (strategy.maxColdStartMs < 50) {
      return strategy.cloudFallback(input);
    }
    void estStart;
  }

  // Local is ready (or acceptable cold start) -> classify on device
  return strategy.local.classify(input);
}

/*
 * EDGE-FIRST CLASSIFICATION NOTES:
 * Zero-shot classification locally means a small Transformer (WASM/WebGPU) labels text into
 * arbitrary candidate categories without task-specific training, entirely on the client.
 * Cold start matters because model weights must download and initialize; a long spin-up hurts UX.
 * Edge-first deployment reduces cloud load by keeping inference on-device, cutting latency and
 * bandwidth, and preserving user privacy since text never leaves the browser.
 */
