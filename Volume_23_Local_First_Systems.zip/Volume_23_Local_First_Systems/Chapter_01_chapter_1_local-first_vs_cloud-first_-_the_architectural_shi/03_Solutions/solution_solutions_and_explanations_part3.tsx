/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export type LocalFirstSession = {
  online: boolean;
  pendingChanges: number;
  modelStatus: 'cold' | 'ready' | 'error';
};

export function useLocalFirstSession(): LocalFirstSession {
  // Mock state: in production this comes from a local store / CRDT subscriber
  return { online: true, pendingChanges: 2, modelStatus: 'cold' };
}

export const SyncStatusBanner: React.FC = () => {
  // No props: fully client-side, no cloud polling used to derive this UI
  const session = useLocalFirstSession();

  // Local-first: state is observed from device, not fetched from server
  if (session.modelStatus === 'cold') {
    return <div className="spinner">Preparing local AI…</div>;
  }
  if (session.pendingChanges > 0) {
    return <div>{session.pendingChanges} changes waiting for sync</div>;
  }
  if (session.online) {
    return <div>All changes saved locally and synced</div>;
  }
  return <div>Offline – working locally</div>;
};

/*
 * USER AUTONOMY & COLD-START UI:
 * This component improves user autonomy by making local state visible; the user knows their
 * work is safe on-device without server confirmation. Showing cold-start state is important for
 * local AI because the brief model load delay is a new client-side phase that users must understand
 * to trust offline intelligence.
 */
