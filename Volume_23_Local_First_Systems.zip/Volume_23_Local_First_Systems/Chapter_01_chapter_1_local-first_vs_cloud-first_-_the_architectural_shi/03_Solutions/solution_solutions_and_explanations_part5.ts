/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export type ArchitectureMode = 'cloud-first' | 'local-first';

export type TradeoffAnalysis = {
  latency: string;
  resilience: string;
  autonomy: string;
  complexity: string;
};

/*
 * ARCHITECTURAL TRADE-OFF MEMO (300+ words):
 * 
 * Cold start differs sharply between modes. Cloud-first SPAs boot to a shell, then block on a
 * network fetch for data; cold start is bounded by WAN latency and server load. Local-first SPAs
 * read from IndexedDB at device speed, so cold start is near-instant and offline-safe, though
 * they may need one-time model or CRDT warm-up.
 * 
 * Edge-first is a hybrid: it keeps cloud fallback but pushes inference and validation to the
 * browser/edge. This shrinks cloud traffic and lets the app stay useful with zero backend contact.
 * 
 * Zero-shot local classification is a user-autonomy win: the user gets moderation or labeling
 * without sending text to a vendor. They own the model execution and their words never leave the
 * device. The cost is client complexity—model loading, cold-start UX, and fallback logic—which
 * this chapter frames as the new normal for local-first TypeScript engineering.
 */
