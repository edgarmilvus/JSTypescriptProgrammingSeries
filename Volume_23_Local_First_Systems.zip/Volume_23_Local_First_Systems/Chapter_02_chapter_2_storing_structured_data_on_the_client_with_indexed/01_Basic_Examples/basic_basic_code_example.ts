/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal IndexedDB example for a local-first SaaS app.
 * Stores a single user setting object and reads it back.
 */

// Define the shape of the data we want to persist locally.
interface UserPreference {
  userId: string;
  theme: 'light' | 'dark';
  lastUpdated: number;
}

/**
 * Opens (or creates) the IndexedDB database for the app.
 * @returns Promise<IDBDatabase> resolved when the DB is ready.
 */
function openDatabase(): Promise<IDBDatabase> {
  // Use the browser's indexedDB global object.
  return new Promise((resolve, reject) => {
    // Request a database named 'saas_local_db' at version 1.
    const request: IDBOpenDBRequest = indexedDB.open('saas_local_db', 1);

    // Fired if the DB version is new or upgraded.
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      // Create an object store 'preferences' with keyPath 'userId'.
      if (!db.objectStoreNames.contains('preferences')) {
        db.createObjectStore('preferences', { keyPath: 'userId' });
      }
    };

    // Success handler.
    request.onsuccess = () => resolve(request.result);
    // Error handler.
    request.onerror = () => reject(request.error);
  });
}

/**
 * Saves a user preference to IndexedDB.
 * @param pref The preference object to store.
 */
async function savePreference(pref: UserPreference): Promise<void> {
  const db = await openDatabase();
  // Start a readwrite transaction on the 'preferences' store.
  const tx = db.transaction('preferences', 'readwrite');
  const store = tx.objectStore('preferences');
  // Put (insert or update) the record.
  store.put(pref);

  // Wait for the transaction to complete.
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Loads a user preference by userId.
 * @param userId The key to look up.
 * @returns Promise<UserPreference | undefined>
 */
async function loadPreference(userId: string): Promise<UserPreference | undefined> {
  const db = await openDatabase();
  // Readonly transaction is sufficient for reads.
  const tx = db.transaction('preferences', 'readonly');
  const store = tx.objectStore('preferences');
  // Create a get request for the key.
  const getReq = store.get(userId);

  return new Promise((resolve, reject) => {
    getReq.onsuccess = () => resolve(getReq.result as UserPreference | undefined);
    getReq.onerror = () => reject(getReq.error);
  });
}

// --- Demo usage in a SaaS context ---
(async () => {
  const demoUser: UserPreference = {
    userId: 'user_42',
    theme: 'dark',
    lastUpdated: Date.now(),
  };

  await savePreference(demoUser);
  const loaded = await loadPreference('user_42');
  console.log('Loaded preference:', loaded);
})();
