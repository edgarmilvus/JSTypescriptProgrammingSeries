/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// Next.js client-side module: lib/localFirstStorage.ts
// Context: Local-first SaaS inspection app (Chapter 2 advanced patterns)

/**
 * Shapes the structured inspection record stored in IndexedDB.
 * Keeping this narrow ensures CRDT sync later only merges small rows.
 */
interface InspectionRecord {
  id: string;            // UUID generated client-side
  technicianId: string;  // offline actor identifier
  siteCode: string;      // logical partition key
  createdAt: number;     // epoch ms for ordering
  status: 'draft' | 'synced';
  opfsFilePath: string;  // pointer to binary payload in OPFS
  summary: string;       // short text, easily diffable
}

/**
 * Opens (or upgrades) the IndexedDB database used for structured storage.
 * We use a single object store with keyPath 'id' and an index on siteCode.
 */
function openInspectionDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    // Request DB version 1; upgrade path can add stores later for CRDT logs
    const req = indexedDB.open('inspectionDB', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      // Create store if missing; use out-of-line keys via keyPath
      if (!db.objectStoreNames.contains('inspections')) {
        const store = db.createObjectStore('inspections', { keyPath: 'id' });
        store.createIndex('bySite', 'siteCode', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/**
 * Writes the structured record inside a single readwrite transaction.
 * Transactions auto-commit; we await completion to guarantee durability.
 */
async function saveInspectionMeta(db: IDBDatabase, rec: InspectionRecord): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('inspections', 'readwrite');
    const store = tx.objectStore('inspections');
    store.put(rec); // insert or update by id
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Persists a large binary report to OPFS using a sync-access handle.
 * OPFS gives us low-overhead file I/O safe for big blobs offline.
 */
async function writeReportToOPFS(path: string, blob: Blob): Promise<void> {
  // Obtain root directory of Origin Private File System
  const root = await navigator.storage.getDirectory();
  // Create or overwrite the file at given path
  const fileHandle = await root.getFileHandle(path, { create: true });
  // Request synchronous access handle (available in workers / modern browsers)
  const accessHandle = await (fileHandle as any).createSyncAccessHandle();
  try {
    // Convert blob to ArrayBuffer for writing
    const buffer = await blob.arrayBuffer();
    // Write entire buffer from offset 0
    accessHandle.write(buffer, { at: 0 });
    // Truncate to exact length to avoid stale trailing bytes
    accessHandle.truncate(buffer.byteLength);
  } finally {
    // Always flush and close to persist correctly
    accessHandle.flush();
    accessHandle.close();
  }
}

/**
 * High-level orchestrator: saves inspection offline with both stores.
 * Used by Next.js client component on "Save Offline" action.
 */
export async function persistInspectionOffline(
  technicianId: string,
  siteCode: string,
  summary: string,
  reportBlob: Blob
): Promise<string> {
  // 1. Generate client-side UUID (no server round-trip needed)
  const id = crypto.randomUUID();
  // 2. Define OPFS relative path namespaced by site and id
  const opfsFilePath = `inspections/${siteCode}/${id}.bin`;
  // 3. Write binary payload to OPFS first (fail fast if quota exceeded)
  await writeReportToOPFS(opfsFilePath, reportBlob);
  // 4. Open IndexedDB and write small structured pointer record
  const db = await openInspectionDB();
  const record: InspectionRecord = {
    id, technicianId, siteCode,
    createdAt: Date.now(), status: 'draft',
    opfsFilePath, summary
  };
  await saveInspectionMeta(db, record);
  db.close();
  // 5. Return id so UI can track local entity before sync
  return id;
}
