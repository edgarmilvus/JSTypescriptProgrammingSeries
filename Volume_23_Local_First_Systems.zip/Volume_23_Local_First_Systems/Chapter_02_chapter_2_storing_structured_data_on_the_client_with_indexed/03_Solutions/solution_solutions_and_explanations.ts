/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Core domain interfaces with utility types
interface Notebook {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  version: number;
  deleted: boolean;
}

interface Note {
  id: string;
  notebookId: string;
  title: string;
  body: string;
  assetRefs: string[]; // references to AssetRef ids, not inlined blobs
  createdAt: number;
  updatedAt: number;
  version: number;
  deleted: boolean;
}

interface AssetRef {
  id: string;
  noteId: string;
  opfsPath: string;
}

// Derived draft type
type NoteDraft = Omit<Note, 'id' | 'createdAt' | 'version'> & Partial<Pick<Note, 'id' | 'createdAt' | 'version'>>;

// 5. Immutable snapshot
type NoteSnapshot = Readonly<Note>;

// 2-3. DB open pseudocode
function openDB(): IDBOpenDBRequest {
  const req = indexedDB.open('localfirst', 1);
  req.onupgradeneeded = (event) => {
    const db = (event.target as IDBOpenDBRequest).result;
    // notebooks store
    const notebooks = db.createObjectStore('notebooks', { keyPath: 'id', autoIncrement: false });
    notebooks.createIndex('by_updated_at', 'updatedAt', { unique: false });
    notebooks.createIndex('by_deleted', 'deleted', { unique: false });
    // notes store
    const notes = db.createObjectStore('notes', { keyPath: 'id', autoIncrement: false });
    notes.createIndex('by_notebook_id', 'notebookId', { unique: false });
    notes.createIndex('by_updated_at', 'updatedAt', { unique: false });
  };
  return req;
}

// 5. Function signature only
function putNote(db: IDBDatabase, note: Note): Promise<void>;
