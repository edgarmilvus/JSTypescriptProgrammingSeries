/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Local-First Sync Pipeline — Minimal SaaS Example
 * Context: A task-management web app that works offline and syncs later.
 */

// ------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// ------------------------------------------------------------------

/**
 * Represents a task entity in our SaaS app.
 */
interface Task {
  id: string;
  title: string;
  done: boolean;
  updatedAt: number;
}

/**
 * Shape of a sync result returned by the remote API.
 */
interface SyncResponse {
  accepted: Task[];
  rejected: Task[];
}

// ------------------------------------------------------------------
// 2. TYPE GUARD
// ------------------------------------------------------------------

/**
 * User-defined type guard that narrows an unknown value to Task.
 * This protects the pipeline from malformed JSON from IndexedDB or network.
 * @param value Unknown incoming object
 * @returns True if value matches Task structure
 */
function isTask(value: unknown): value is Task {
  // Check that value is a non-null object
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  // Validate each field with primitive type checks
  return (
    typeof v.id === "string" &&
    typeof v.title === "string" &&
    typeof v.done === "boolean" &&
    typeof v.updatedAt === "number"
  );
}

// ------------------------------------------------------------------
// 3. LOCAL STORAGE LAYER (WASM DB STUB)
// ------------------------------------------------------------------

/**
 * Simulated WASM-backed embedded DB interface.
 * In production this would wrap a WASM module like sql.js or surrealdb-wasm.
 */
class LocalDB {
  private store: Map<string, Task> = new Map();

  /** Persist a task locally (offline-ready). */
  async put(task: Task): Promise<void> {
    this.store.set(task.id, task);
  }

  /** Retrieve all local tasks. */
  async all(): Promise<Task[]> {
    return Array.from(this.store.values());
  }
}

// ------------------------------------------------------------------
// 4. SERVICE WORKER CACHING FOR AI ASSETS
// ------------------------------------------------------------------

/**
 * Registers a service worker that caches large ONNX model weights.
 * This ensures instant offline load of AI features in the SaaS app.
 */
async function registerAIAssetCache(): Promise<void> {
  if (!("serviceWorker" in navigator)) return;
  await navigator.serviceWorker.register("/sw.js");
  // The SW itself would use caches.open('ai-assets') and fetch + put weights
}

// ------------------------------------------------------------------
// 5. NETWORK SYNC LAYER
// ------------------------------------------------------------------

/**
 * Pushes local tasks to the remote API and returns the server response.
 * @param tasks Local tasks to sync
 */
async function pushToRemote(tasks: Task[]): Promise<SyncResponse> {
  const res = await fetch("/api/sync", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tasks),
  });
  const data: unknown = await res.json();
  // Defensive parse: ensure we got a valid SyncResponse
  if (
    typeof data === "object" &&
    data !== null &&
    Array.isArray((data as any).accepted) &&
    Array.isArray((data as any).rejected)
  ) {
    return data as SyncResponse;
  }
  throw new Error("Invalid sync response from server");
}

// ------------------------------------------------------------------
// 6. LANGGRAPH TOOL INVOCATION SIGNATURE
// ------------------------------------------------------------------

/**
 * Tool handler compatible with LangGraph.
 * Accepts LLM-derived params and returns a serializable result.
 * @param params Parameters from LLM function call
 */
async function createTaskTool(
  params: { title: string }
): Promise<{ taskId: string }> {
  const task: Task = {
    id: crypto.randomUUID(),
    title: params.title,
    done: false,
    updatedAt: Date.now(),
  };
  await db.put(task);
  return { taskId: task.id };
}

// ------------------------------------------------------------------
// 7. PIPELINE ORCHESTRATION
// ------------------------------------------------------------------

const db = new LocalDB();

/**
 * Runs the local-first sync pipeline:
 * 1. Ensure AI assets cached
 * 2. Load local tasks
 * 3. Push to remote when online
 */
async function runSyncPipeline(): Promise<void> {
  await registerAIAssetCache();

  const localTasks = await db.all();
  // Type guard usage: filter any corrupt entries just in case
  const safeTasks = localTasks.filter(isTask);

  if (navigator.onLine) {
    try {
      const result = await pushToRemote(safeTasks);
      console.log("Synced:", result.accepted.length, "tasks");
    } catch (err) {
      console.error("Sync failed, will retry later", err);
    }
  } else {
    console.log("Offline — data stored locally");
  }
}

// Kick off pipeline (e.g., on app boot)
runSyncPipeline();
