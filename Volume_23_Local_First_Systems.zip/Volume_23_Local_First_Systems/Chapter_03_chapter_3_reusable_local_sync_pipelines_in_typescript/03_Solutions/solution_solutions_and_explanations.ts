/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Generic storage backend interface (Requirement 1)
export interface LocalStorageBackend {
  open(collection: string): Promise<void>;
  commit(crdtState: Uint8Array): Promise<void>;
  load(collection: string): Promise<Uint8Array | null>;
}

// CRDT codec interface for encode/decode
export interface CrdtCodec<T> {
  encode(state: T): Uint8Array;
  decode(bytes: Uint8Array): T;
}

// WASM DB storage implementation (Requirement 2)
export class WasmDbStorage implements LocalStorageBackend {
  private db: any; // WASM DB instance (e.g., SQLite WASM)
  private ready: Promise<void>;

  constructor(wasmDbFactory: () => Promise<any>) {
    this.ready = wasmDbFactory().then(instance => { this.db = instance; });
  }

  async open(collection: string): Promise<void> {
    await this.ready;
    // Ensure table/space exists for collection inside transaction
    await this.db.exec(`CREATE TABLE IF NOT EXISTS "${collection}" (id INTEGER PRIMARY KEY, state BLOB)`);
  }

  async commit(crdtState: Uint8Array): Promise<void> {
    await this.ready;
    // Wrap write in transaction to avoid split writes
    await this.db.transaction(async () => {
      await this.db.exec(`DELETE FROM "main"`);
      await this.db.bindAndRun(`INSERT INTO "main" (state) VALUES (?)`, [crdtState]);
    });
  }

  async load(collection: string): Promise<Uint8Array | null> {
    await this.ready;
    const row = await this.db.exec(`SELECT state FROM "${collection}" LIMIT 1`);
    return row?.state ?? null;
  }
}

// Generic CRDT collection (Requirement 3, 5)
import { EventEmitter } from 'events';

export class CrdtCollection<T> {
  private state: T;
  private emitter = new EventEmitter();

  constructor(
    private backend: LocalStorageBackend,
    private codec: CrdtCodec<T>,
    private initial: T
  ) {
    this.state = initial;
  }

  async init(collection: string): Promise<void> {
    await this.backend.open(collection);
    const raw = await this.backend.load(collection);
    if (raw) this.state = this.codec.decode(raw);
  }

  async applyMutation(mutator: (s: T) => T): Promise<void> {
    const next = mutator(this.state);
    const encoded = this.codec.encode(next);
    await this.backend.commit(encoded); // atomic; throws abort whole op on failure
    this.state = next;
    // Use setImmediate to emit without blocking (Node Event Loop)
    setImmediate(() => this.emitter.emit('local', this.state));
  }

  subscribeToLocalChanges(cb: (state: T) => void): void {
    this.emitter.on('local', cb);
  }
}
