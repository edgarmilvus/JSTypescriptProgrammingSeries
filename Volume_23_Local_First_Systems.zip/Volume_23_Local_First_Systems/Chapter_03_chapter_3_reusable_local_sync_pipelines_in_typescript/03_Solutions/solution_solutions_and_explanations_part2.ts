/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Requirement 1
export interface SyncContext {
  networkType: 'wifi' | 'cellular' | 'none';
  batteryLevel: number;
  lastSyncTimestamp: number;
  failureCount: number;
  userOverride: 'force' | 'defer' | null;
}

// Requirement 2
export type SyncDecision =
  | { type: 'Push' }
  | { type: 'Pull' }
  | { type: 'FullSync' }
  | { type: 'Idle' };

export type SyncPolicy = (ctx: SyncContext) => SyncDecision;

// Requirement 3
export class PolicyComposer {
  static compose(policies: SyncPolicy[]): SyncPolicy {
    return (ctx: SyncContext) => {
      if (ctx.userOverride === 'force') return { type: 'FullSync' };
      for (const p of policies) {
        const d = p(ctx);
        if (d.type !== 'Idle') return d; // short-circuit
      }
      return { type: 'Idle' };
    };
  }
}

// Example policies
const wifiOnly: SyncPolicy = (ctx) =>
  ctx.networkType === 'wifi' ? { type: 'Push' } : { type: 'Idle' };

const batteryGuard: SyncPolicy = (ctx) =>
  ctx.batteryLevel < 20 && ctx.userOverride !== 'force'
    ? { type: 'Idle' }
    : { type: 'Pull' };

const backoff: SyncPolicy = (ctx) =>
  ctx.failureCount >= 3 ? { type: 'Idle' } : { type: 'Push' };
