/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal Grow-Only Set (G-Set) CRDT for a SaaS feature-starring widget.
 *
 * Property guarantees:
 * - Commutativity: merge(a, b) === merge(b, a)
 * - Associativity: merge(merge(a, b), c) === merge(a, merge(b, c))
 * - Idempotence:  merge(a, a) === a
 */

/** Utility Type: derive an immutable list of user IDs from string */
type StarredUserIds = ReadonlyArray<string>;

/**
 * Represents the CRDT state for one client replica.
 * We use a frozen object to enforce Immutable State Management.
 */
interface StarSetState {
  readonly members: StarredUserIds;
}

/**
 * Factory to create an empty G-Set replica.
 * @returns A new immutable StarSetState with no members.
 */
function createEmptyStarSet(): StarSetState {
  // We return a frozen object to prevent accidental in-place mutation.
  return Object.freeze({ members: [] });
}

/**
 * Add a user ID to the set.
 * IMPORTANT: Returns a NEW state (immutable update), never mutates the input.
 * @param state Current replica state
 * @param userId Unique user identifier from the SaaS auth system
 * @returns New StarSetState containing the added user (if not already present)
 */
function addUser(state: StarSetState, userId: string): StarSetState {
  // Check membership without mutating the original array.
  if (state.members.includes(userId)) {
    // Already a member; return the same frozen reference (idempotent).
    return state;
  }
  // Create a new array (spread) -> satisfies Immutable State Management.
  const nextMembers: StarredUserIds = [...state.members, userId];
  // Return a new frozen object.
  return Object.freeze({ members: nextMembers });
}

/**
 * Merge two replicas. Union of members.
 * This is the core CRDT merge function.
 * @param local Local replica state
 * @param remote Remote replica state received via sync
 * @returns Merged StarSetState (union of both member lists)
 */
function mergeStars(local: StarSetState, remote: StarSetState): StarSetState {
  // Use a Set for deduplication, then convert back to ReadonlyArray.
  const union = new Set<string>([...local.members, ...remote.members]);
  const merged: StarredUserIds = Array.from(union);
  return Object.freeze({ members: merged });
}

// ---- Demo in a fake SaaS API handler context ----

// Replica A runs in the browser of user "alice"
let replicaA = createEmptyStarSet();
replicaA = addUser(replicaA, "alice");
replicaA = addUser(replicaA, "bob");

// Replica B runs offline on the phone of user "carol"
let replicaB = createEmptyStarSet();
replicaB = addUser(replicaB, "carol");

// Network sync occurs: both replicas merge each other's state
const syncedA = mergeStars(replicaA, replicaB);
const syncedB = mergeStars(replicaB, replicaA);

// Both must be deeply equal (same members)
console.log("Replica A after sync:", syncedA.members.sort());
console.log("Replica B after sync:", syncedB.members.sort());
console.log("Converged:", JSON.stringify(syncedA) === JSON.stringify(syncedB));
