/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// Next.js API Route + Edge Worker Simulation for Local-First CRDT Board
// Context: SaaS project management app using CRDTs (Chapter 4 concepts)
// ============================================================================

import type { NextRequest, NextResponse } from "next/server";

/**
 * Graph State shared across LangGraph nodes.
 * In a local-first system, this state is replicated via CRDTs so every
 * client holds a convergent copy without central coordination.
 */
interface GraphState {
  boardId: string;
  /** CRDT Grow-Only Set of task IDs */
  taskIds: Set<string>;
  /** CRDT Last-Writer-Wins Map of task metadata */
  tasks: Map<string, { title: string; done: boolean; updatedAt: number }>;
  /** Edge preprocessing log */
  edgeLogs: string[];
}

/**
 * Worker Agent Pool representation.
 * Supervisor delegates validation/preprocessing to an Edge Worker.
 */
interface WorkerAgent {
  name: string;
  execute: (state: GraphState, patch: TaskPatch) => GraphState;
}

/** Minimal patch shape for a board update */
interface TaskPatch {
  taskId: string;
  title?: string;
  done?: boolean;
  actorTime: number;
}

/**
 * Edge-First Deployment Strategy:
 * We run this lightweight inference/validation at the edge (or browser)
 * to reduce latency and offload the cloud.
 */
const edgeWorker: WorkerAgent = {
  name: "EdgeValidator",
  // Merges patch using CRDT semantics (LWW-Map + G-Set)
  execute(state, patch) {
    // 1. Validate patch shape at the edge
    if (!patch.taskId) {
      state.edgeLogs.push("Rejected: missing taskId");
      return state;
    }

    // 2. G-Set: add task id if absent (idempotent, commutative)
    state.taskIds.add(patch.taskId);

    // 3. LWW-Map: merge using timestamp precedence
    const existing = state.tasks.get(patch.taskId);
    if (!existing || patch.actorTime >= existing.updatedAt) {
      state.tasks.set(patch.taskId, {
        title: patch.title ?? existing?.title ?? "Untitled",
        done: patch.done ?? existing?.done ?? false,
        updatedAt: patch.actorTime,
      });
      state.edgeLogs.push(`Merged task ${patch.taskId} @${patch.actorTime}`);
    } else {
      state.edgeLogs.push(`Ignored stale patch for ${patch.taskId}`);
    }
    return state;
  },
};

/**
 * Next.js Edge API Route demonstrating offline-ready sync.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 4. Parse incoming offline-generated patch
  const patch = (await req.json()) as TaskPatch;

  // 5. Initialize convergent graph state (simulated local replica)
  const state: GraphState = {
    boardId: "board-123",
    taskIds: new Set(),
    tasks: new Map(),
    edgeLogs: [],
  };

  // 6. Edge worker preprocesses & merges via CRDT rules
  const merged = edgeWorker.execute(state, patch);

  // 7. Return merged state to client for local persistence
  return new Response(JSON.stringify({
    boardId: merged.boardId,
    taskIds: Array.from(merged.taskIds),
    tasks: Array.from(merged.tasks.entries()),
    edgeLogs: merged.edgeLogs,
  })) as unknown as NextResponse;
}
