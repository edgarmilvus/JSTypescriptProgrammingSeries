/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// gset.ts
// ESM module for a Grow-Only Set (G-Set) CRDT.
// Merge must be idempotent: applying the same merge multiple times yields the same state.
// In offline-first apps, sync cycles may deliver the same payload repeatedly; idempotency
// ensures no duplicates or state corruption occur during reconnection storms.

export type SerializableValue = string | number | boolean;

export interface GSet<T extends SerializableValue> {
  add(value: T): void;
  has(value: T): boolean;
  merge(other: GSet<T>): void;
  toArray(): T[];
  clone(): GSet<T>;
}

function isSerializableValue(x: unknown): x is SerializableValue {
  return typeof x === 'string' || typeof x === 'number' || typeof x === 'boolean';
}

export function createGSet<T extends SerializableValue>(): GSet<T> {
  const internal = new Set<T>();
  return {
    add(value: T): void {
      internal.add(value);
    },
    has(value: T): boolean {
      return internal.has(value);
    },
    merge(other: GSet<T>): void {
      // Only accepts same-type GSet; TS prevents GSet<number> vs GSet<string>
      for (const v of other.toArray()) {
        internal.add(v);
      }
    },
    toArray(): T[] {
      return Array.from(internal);
    },
    clone(): GSet<T> {
      const copy = createGSet<T>();
      copy.merge({ toArray: () => this.toArray() } as GSet<T>);
      return copy;
    }
  };
}

export function mergeFromSerialized<T extends SerializableValue>(
  serialized: string,
  local: GSet<T>
): GSet<T> {
  const parsed: unknown = JSON.parse(serialized);
  if (Array.isArray(parsed)) {
    for (const item of parsed) {
      if (isSerializableValue(item)) {
        // Type guard ensures only valid serializable values inserted
        local.add(item as T);
      }
    }
  }
  return local;
}
