/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// lww.ts
// LWW-Register CRDT: resolves conflicts by highest (timestamp, actorId).
// Wall-clock skew can cause incorrect ordering; a hybrid logical clock (HLC) later
// combines physical time with a counter to mitigate this.

export type ActorId = string;
export type Timestamp = number;

interface LWWEnvelope<T> {
  value: T;
  ts: Timestamp;
  actor: ActorId;
}

export interface LWWRegister<T> {
  set(value: T, timestamp?: Timestamp): void;
  get(): T | undefined;
  merge(other: LWWRegister<T>): void;
  getMeta(): { actorId: ActorId; timestamp: Timestamp };
}

let monotonicCounter = 0;

export function createLWWRegister<T>(actorId: ActorId): LWWRegister<T> {
  let current: LWWEnvelope<T> | undefined;
  return {
    set(value: T, timestamp?: Timestamp): void {
      const ts = timestamp ?? (Date.now() + monotonicCounter++);
      if (!current || ts > current.ts || (ts === current.ts && actorId > current.actor)) {
        current = { value, ts, actor: actorId };
      }
    },
    get(): T | undefined {
      return current?.value;
    },
    merge(other: LWWRegister<T>): void {
      const o = other.getMeta();
      const oVal = other.get();
      if (oVal === undefined) return;
      if (!current || o.timestamp > current.ts || (o.timestamp === current.ts && o.actorId > current.actor)) {
        current = { value: oVal, ts: o.timestamp, actor: o.actorId };
      }
    },
    getMeta(): { actorId: ActorId; timestamp: Timestamp } {
      return { actorId: current?.actor ?? actorId, timestamp: current?.ts ?? 0 };
    }
  };
}

export function isLWWEnvelope<T>(x: unknown): x is LWWEnvelope<T> {
  return (
    typeof x === 'object' && x !== null &&
    'value' in x && 'ts' in x && 'actor' in x &&
    typeof (x as any).ts === 'number' && typeof (x as any).actor === 'string'
  );
}

export function syncFromWASM(
  db: { read(key: string): Uint8Array },
  key: string,
  reg: LWWRegister<unknown>
): void {
  const bytes = db.read(key);
  const text = new TextDecoder().decode(bytes);
  const parsed: unknown = JSON.parse(text);
  if (isLWWEnvelope(parsed)) {
    // Type narrowed; safe to set via merge-like update
    reg.set(parsed.value, parsed.ts);
  }
}
