/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// pncounter.ts
export class PNCounter {
  private inc = new Map<string, number>();
  private dec = new Map<string, number>();
  increment(actor: string, amount = 1): void {
    this.inc.set(actor, (this.inc.get(actor) ?? 0) + amount);
  }
  decrement(actor: string, amount = 1): void {
    this.dec.set(actor, (this.dec.get(actor) ?? 0) + amount);
  }
  value(): number {
    let sum = 0;
    for (const v of this.inc.values()) sum += v;
    for (const v of this.dec.values()) sum -= v;
    return sum;
  }
  merge(other: PNCounter): void {
    for (const [a, v] of other.inc) this.inc.set(a, Math.max(this.inc.get(a) ?? 0, v));
    for (const [a, v] of other.dec) this.dec.set(a, Math.max(this.dec.get(a) ?? 0, v));
  }
  serialize(): string { return JSON.stringify({ inc: [...this.inc], dec: [...this.dec] }); }
}

// CollaborativeCounter.tsx
import React, { useState, useEffect } from 'react';
import { PNCounter } from './pncounter';

interface LocalFirstStorage {
  save(key: string, data: Uint8Array): Promise<void>;
  load(key: string): Promise<Uint8Array | null>;
}

// React re-renders on useState change; background sync uses merge to converge remotely.
export function CollaborativeCounter({ actorId, initialSerialized, storage }: {
  actorId: string; initialSerialized?: string; storage: LocalFirstStorage;
}) {
  const [counter] = useState(() => {
    const c = new PNCounter();
    if (initialSerialized) { /* parse and merge */ }
    return c;
  });
  const [val, setVal] = useState(counter.value());

  useEffect(() => {
    storage.load(actorId).then(bytes => {
      if (bytes) { /* decode, parse, counter.merge, setVal */ }
    });
  }, []);

  const onClick = async (dir: 1 | -1) => {
    dir === 1 ? counter.increment(actorId) : counter.decrement(actorId);
    setVal(counter.value());
    await storage.save(actorId, new TextEncoder().encode(counter.serialize()));
  };
  return <div><button onClick={() => onClick(-1)}>-1</button>{val}<button onClick={() => onClick(1)}>+1</button></div>;
}
// Metadata filtering: to scope sync to notebook 'author', query WASM DB for notes with
// author meta and only merge counters whose key matches that author prefix.
