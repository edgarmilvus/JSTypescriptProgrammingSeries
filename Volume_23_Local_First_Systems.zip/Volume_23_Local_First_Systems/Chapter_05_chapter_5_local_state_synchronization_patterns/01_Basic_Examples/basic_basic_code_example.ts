/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Local-first SaaS note service (Hello World level).
 * Demonstrates offline write, local persistence stub, and merge-ready state.
 */

// ---------------------------------------------------------------------------
// 1. Domain Model
// ---------------------------------------------------------------------------

/**
 * Represents a single collaborative note in our SaaS app.
 * `text` is the user-facing content.
 * `version` is a monotonically increasing local counter (naive CRDT hint).
 */
interface Note {
  id: string;
  text: string;
  version: number;
}

// ---------------------------------------------------------------------------
// 2. In-Memory "WASM DB" Stub
// ---------------------------------------------------------------------------

/**
 * A fake persistence layer standing in for a WASM-powered DB (e.g., sql.js-wasm).
 * In reality this would be backed by IndexedDB + a WASM SQLite core.
 */
class LocalDB {
  private store: Map<string, Note> = new Map();

  /** Persist or overwrite a note by ID. */
  save(note: Note): void {
    this.store.set(note.id, note);
  }

  /** Retrieve a note or return undefined. */
  get(id: string): Note | undefined {
    return this.store.get(id);
  }
}

// ---------------------------------------------------------------------------
// 3. Service Worker Cache Stub (AI Assets)
// ---------------------------------------------------------------------------

/**
 * Simulates Service Worker caching of large AI model assets.
 * In a real app this caches ONNX tensors for offline summarization.
 */
class ModelCache {
  private cached: boolean = false;

  /** Pretend to cache gigabytes of model weights. */
  async cacheModel(): Promise<void> {
    // Simulated async SW registration + cache.addAll()
    await new Promise((r) => setTimeout(r, 10));
    this.cached = true;
  }

  isReady(): boolean {
    return this.cached;
  }
}

// ---------------------------------------------------------------------------
// 4. Note Service (Business Logic)
// ---------------------------------------------------------------------------

/**
 * High-level service used by the UI layer.
 */
class NoteService {
  private db = new LocalDB();
  private modelCache = new ModelCache();

  /** Ensure AI assets are available offline. */
  async init(): Promise<void> {
    await this.modelCache.cacheModel();
  }

  /** Offline-safe write: increments local version. */
  writeNote(id: string, text: string): Note {
    const existing = this.db.get(id);
    const nextVersion = (existing?.version ?? 0) + 1;
    const note: Note = { id, text, version: nextVersion };
    this.db.save(note);
    return note;
  }

  /** Read local state. */
  readNote(id: string): Note | undefined {
    return this.db.get(id);
  }
}

// ---------------------------------------------------------------------------
// 5. App Bootstrap
// ---------------------------------------------------------------------------

/**
 * Entry point simulating a SaaS frontend mount.
 */
async function main(): Promise<void> {
  const service = new NoteService();
  await service.init();

  // User edits offline
  service.writeNote("note-1", "Hello local-first world");
  const local = service.readNote("note-1");
  console.log("Local note:", local);
}

main();
