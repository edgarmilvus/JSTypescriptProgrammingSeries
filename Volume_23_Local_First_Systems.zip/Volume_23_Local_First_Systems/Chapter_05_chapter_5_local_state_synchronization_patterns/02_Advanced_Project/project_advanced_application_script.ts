/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// types.ts — Domain and sync-related types for the local-first task board

/**
 * Represents a collaborative task inside a SaaS project board.
 * Uses CRDT-friendly fields: `id` is a UUID, `updatedAt` is a Lamport-ish timestamp.
 */
export interface Task {
  id: string;
  title: string;
  done: boolean;
  updatedAt: number; // logical clock for CRDT last-write-wins merge
  origin: string;    // device/user id that created or last mutated
}

/**
 * Optimistic task wrapper used by the UI before reconciliation.
 */
export interface OptimisticTask extends Task {
  pending: boolean; // true if not yet confirmed by background job or peer
}

// syncEngine.ts — Core local-first synchronization logic

import { Task, OptimisticTask } from './types';

/**
 * Simulated WASM-powered local database handle.
 * In a real app this would wrap a WASM SQLite or IndexedDB+CRDT WASM module.
 */
class WasmDB {
  private store = new Map<string, Task>();

  /** Persist a task into the local WASM DB (offline-safe). */
  put(task: Task): void {
    this.store.set(task.id, task);
  }

  /** Retrieve all tasks from local persistence. */
  all(): Task[] {
    return Array.from(this.store.values());
  }
}

/**
 * Very small CRDT merge utility (last-writer-wins by updatedAt + origin).
 * This is the heart of conflict-free replication across devices.
 */
function mergeTasks(local: Task, remote: Task): Task {
  if (remote.updatedAt > local.updatedAt) return remote;
  if (remote.updatedAt === local.updatedAt && remote.origin > local.origin) return remote;
  return local;
}

/**
 * Background "local AI" stub that infers priority and confirms task.
 * In reality this could be a WASM inference model running on-device.
 */
async function localAiInfer(task: OptimisticTask): Promise<Task> {
  // simulate async inference latency
  await new Promise((r) => setTimeout(r, 50));
  return { ...task, pending: false, updatedAt: Date.now() } as Task;
}

/**
 * Next.js-friendly sync hook/service for a SaaS task board.
 */
export class TaskSyncService {
  private db = new WasmDB();
  private deviceId = 'dev-' + Math.random().toString(36).slice(2, 8);

  /**
   * 1. Offline write: create task optimistically and persist locally.
   */
  async createTask(title: string): Promise<OptimisticTask> {
    const optimistic: OptimisticTask = {
      id: crypto.randomUUID(),
      title,
      done: false,
      updatedAt: Date.now(),
      origin: this.deviceId,
      pending: true,
    };
    this.db.put(optimistic);
    return optimistic;
  }

  /**
   * 2. Reconcile with local AI: confirm optimistic state.
   */
  async reconcileWithAi(task: OptimisticTask): Promise<Task> {
    const confirmed = await localAiInfer(task);
    this.db.put(confirmed);
    return confirmed;
  }

  /**
   * 3. Merge remote peer tasks using CRDT rules.
   */
  syncRemote(remoteTasks: Task[]): Task[] {
    const merged: Task[] = this.db.all();
    for (const rt of remoteTasks) {
      const idx = merged.findIndex((t) => t.id === rt.id);
      if (idx === -1) merged.push(rt);
      else merged[idx] = mergeTasks(merged[idx], rt);
    }
    merged.forEach((t) => this.db.put(t));
    return merged;
  }

  /** Fetch current local state for UI rendering. */
  getTasks(): OptimisticTask[] {
    return this.db.all() as OptimisticTask[];
  }
}
