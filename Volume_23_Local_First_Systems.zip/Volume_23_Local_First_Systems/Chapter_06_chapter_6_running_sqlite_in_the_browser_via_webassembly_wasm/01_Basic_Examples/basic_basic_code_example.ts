/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal local-first SaaS example using SQLite via WebAssembly in the browser.
 * This module demonstrates loading a WASM SQLite instance, creating a tenant-scoped
 * table, inserting a record, and querying it back—all client-side.
 */

// Import the SQLite WASM factory from the official sql.js distribution.
// sql.js is a compiled-to-WASM build of SQLite exposed through a JS-friendly API.
import initSqlJs from "@sql-js/sql-wasm";

/**
 * Main bootstrap function for the local-first note store.
 * This would typically be invoked once when a SaaS user logs into their workspace.
 */
async function bootstrapLocalSaasDb(): Promise<void> {
  // 1. Initialize the WASM SQLite module.
  // Under the hood, this fetches and compiles the .wasm binary, then instantiates
  // a stack-based virtual machine inside the browser's JS heap via WebAssembly.
  const SQL = await initSqlJs({
    // In a real SaaS bundle, this path would be served from a CDN or hashed asset.
    locateFile: (file) => `https://cdn.example.com/sqlite/${file}`,
  });

  // 2. Create an in-memory database instance.
  // This DB lives entirely in the browser's memory for now. Persistence to
  // Origin Private File System or IndexedDB is shown later in the chapter.
  const db = new SQL.Database();

  // 3. Execute DDL to create a tenant-scoped notes table.
  // In a multi-tenant SaaS app, scoping by tenant_id prevents cross-tenant leaks.
  db.run(`
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT,
      created_at INTEGER NOT NULL
    );
  `);

  // 4. Insert a sample note for the current tenant.
  // Parameter binding prevents SQL injection even in local-first contexts.
  const tenantId = "acme-corp";
  db.run(
    `INSERT INTO notes (tenant_id, title, body, created_at)
     VALUES (?, ?, ?, ?)`,
    [tenantId, "Welcome", "Local-first sync enabled.", Date.now()]
  );

  // 5. Query the note back using a prepared statement.
  const stmt = db.prepare(
    `SELECT id, title, body FROM notes WHERE tenant_id = ?`
  );
  stmt.bind([tenantId]);

  // 6. Iterate over the result set.
  // sql.js prepared statements are stepped manually, similar to native SQLite.
  while (stmt.step()) {
    const row = stmt.getAsObject();
    console.log("Loaded note:", row);
  }

  // 7. Finalize the statement to free WASM memory.
  stmt.free();

  // 8. Export the database to a Uint8Array for persistence (demo only).
  const binaryArray = db.export();
  console.log("DB binary size:", binaryArray.byteLength);

  // 9. Close the database handle.
  db.close();
}

// Self-invoking execution for the example.
bootstrapLocalSaasDb().catch((err) => {
  console.error("Local DB init failed:", err);
});
