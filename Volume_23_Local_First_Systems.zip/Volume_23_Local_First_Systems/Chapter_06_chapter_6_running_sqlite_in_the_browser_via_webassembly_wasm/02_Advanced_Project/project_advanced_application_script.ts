/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// auditRepository.ts
// Advanced Application Script: WASM SQLite in Next.js for Offline-First SaaS

import { sqlite3InitModule } from '@sqlite.org/sqlite-wasm';
import type { Database, Sqlite3Static } from '@sqlite.org/sqlite-wasm';

/**
 * Represents a single compliance audit entry stored locally.
 */
interface AuditEvent {
  id?: number;
  actor: string;
  action: string;
  timestamp: number;
  synced: 0 | 1;
}

/**
 * Performance metrics for WASM SQLite initialization.
 * Mirrors Cold Start / Warm Start concepts from local AI workloads.
 */
interface StartupMetrics {
  coldStartMs: number;
  warmStartMs: number;
}

/**
 * High-level repository for audit events using WASM SQLite.
 * Context: SaaS compliance dashboard with offline support.
 */
export class AuditRepository {
  private db!: Database;
  private static sqlite3!: Sqlite3Static;

  /**
   * Initializes the SQLite WASM module and opens OPFS-backed DB.
   * Measures cold start on first call, warm start on subsequent.
   */
  static async bootstrap(): Promise<StartupMetrics> {
    const t0 = performance.now();

    // 1. Load and compile the SQLite WASM module (Cold Start)
    if (!AuditRepository.sqlite3) {
      AuditRepository.sqlite3 = await sqlite3InitModule();
    }

    const t1 = performance.now();
    const coldStartMs = t1 - t0;

    // 2. Open DB using OPFS (Origin Private File System) for persistence
    const sqlite3 = AuditRepository.sqlite3;
    const db = new sqlite3.oo1.OpfsDb('/audit.sqlite3');

    // 3. Create table if not exists (idempotent schema init)
    db.exec(`
      CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor TEXT NOT NULL,
        action TEXT NOT NULL,
        timestamp INTEGER NOT NULL,
        synced INTEGER DEFAULT 0
      );
    `);

    const t2 = performance.now();
    const warmStartMs = t2 - t1;

    return { coldStartMs, warmStartMs };
  }

  /**
   * Attaches a ready database instance to the repository.
   */
  constructor(db: Database) {
    this.db = db;
  }

  /**
   * Inserts a new audit event into the local WASM SQLite store.
   * @param event Partial audit event without id/synced
   */
  async addEvent(event: Omit<AuditEvent, 'id' | 'synced'>): Promise<void> {
    // 4. Parameterized insert to prevent SQL injection
    this.db.exec({
      sql: `INSERT INTO audit_log (actor, action, timestamp, synced)
            VALUES (?, ?, ?, 0)`,
      bind: [event.actor, event.action, event.timestamp],
    });
  }

  /**
   * Retrieves all unsynced events for later background sync.
   */
  getPendingSync(): AuditEvent[] {
    // 5. Query using typed row mapping
    const rows = this.db.exec({
      sql: `SELECT * FROM audit_log WHERE synced = 0`,
      returnValue: 'resultRows',
    }) as unknown as AuditEvent[];

    return rows;
  }

  /**
   * Marks given IDs as synced after successful server push.
   * @param ids List of local row IDs
   */
  markSynced(ids: number[]): void {
    // 6. Batch update using transaction for atomicity
    this.db.transaction(() => {
      for (const id of ids) {
        this.db.exec({
          sql: `UPDATE audit_log SET synced = 1 WHERE id = ?`,
          bind: [id],
        });
      }
    });
  }
}
