/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// AuditDashboard.tsx
// Next.js client component using the repository

'use client';

import { useEffect, useState } from 'react';
import { AuditRepository, StartupMetrics } from './auditRepository';

/**
 * React component demonstrating offline-first audit logging.
 */
export default function AuditDashboard() {
  const [metrics, setMetrics] = useState<StartupMetrics | null>(null);
  const [repo, setRepo] = useState<AuditRepository | null>(null);

  useEffect(() => {
    (async () => {
      // 7. Bootstrap WASM SQLite and measure startup latency
      const m = await AuditRepository.bootstrap();
      const db = new (await import('@sqlite.org/sqlite-wasm')).sqlite3.oo1.OpfsDb('/audit.sqlite3');
      setMetrics(m);
      setRepo(new AuditRepository(db));
    })();
  }, []);

  return (
    <div>
      <h2>Local-First Audit Log</h2>
      {metrics && (
        <p>Cold Start: {metrics.coldStartMs.toFixed(1)}ms | Warm Start: {metrics.warmStartMs.toFixed(1)}ms</p>
      )}
    </div>
  );
}
