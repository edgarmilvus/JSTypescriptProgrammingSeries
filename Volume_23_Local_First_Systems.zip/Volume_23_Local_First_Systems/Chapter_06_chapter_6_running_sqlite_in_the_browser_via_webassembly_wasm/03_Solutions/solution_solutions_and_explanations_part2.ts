/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Interface-only specification; no implementation

export interface Repository<T> {
  insert(entity: T): Promise<void>;
  getById(id: string): Promise<T | null>;
  update(entity: T): Promise<void>;
  delete(id: string): Promise<void>;
  query(sql: string, params: unknown[]): Promise<T[]>;
}

export type WorkerRequest =
  | { type: 'open'; path: string }
  | { type: 'exec'; sql: string; params: unknown[] }
  | { type: 'migrate'; version: number };

export type WorkerResponse =
  | { type: 'ready'; backend: 'OPFS' | 'IndexedDB' }
  | { type: 'result'; rows: unknown[] }
  | { type: 'error'; message: string };

export class SqliteWorkerBridge {
  constructor(worker: Worker) {}
  post(msg: WorkerRequest): Promise<WorkerResponse> {
    throw new Error('Not implemented');
  }
}

export class MigrationRunner {
  constructor(manifest: { version: number; sql: string }[]) {}
  apply(db: unknown): Promise<void> {
    throw new Error('Not implemented');
  }
}

/*
WORKER TOPOLOGY:
Main Thread -> SqliteWorkerBridge -> Web Worker (WASM SQLite + OPFS sync handle)
Entities serialized as JSON before postMessage.
All SQL must use ? placeholders (parameterized).
ACCEPTANCE: OPFS path /local-first-app/db.sqlite; fallback recorded; migrations typed.
*/
