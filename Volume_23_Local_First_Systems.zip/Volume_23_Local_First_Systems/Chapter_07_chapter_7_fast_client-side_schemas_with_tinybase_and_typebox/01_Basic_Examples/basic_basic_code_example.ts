/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * TinyBase + TypeBox minimal local-first schema example.
 * Context: A SaaS app where each user has projects stored locally first.
 */

// 1. Import TinyBase core and TypeBox validator/schema tools.
import { createStore, type Store } from 'tinybase';
import { Type, type Static, type TObject } from '@sinclair/typebox';
import { Value } from '@sinclair/typebox/value';

// 2. Define a TypeBox schema for a SaaS project row.
// This acts as both a runtime validator and a source of truth for types.
const ProjectSchema = Type.Object({
  id: Type.String({ format: 'uuid' }),
  name: Type.String({ minLength: 1, maxLength: 80 }),
  ownerId: Type.String(),
  createdAt: Type.Number(), // epoch ms
  isArchived: Type.Boolean(),
});

// 3. Infer the TypeScript type from the schema (compile-time safety).
type Project = Static<typeof ProjectSchema>;

// 4. Create a TinyBase store (in-browser, no server needed).
const store: Store = createStore();

// 5. Define the table name used by the SaaS client.
const PROJECTS_TABLE = 'projects';

// 6. Initialize the table so TinyBase knows it exists.
store.setTable(PROJECTS_TABLE, {});

/**
 * Inserts a project into the local TinyBase store after validating it.
 * @param project - The project object to insert.
 * @returns boolean indicating success.
 */
function addProject(project: unknown): boolean {
  // 7. Runtime validation using TypeBox's Value utility.
  if (!Value.Check(ProjectSchema, project)) {
    // 8. Fail safely if schema is violated.
    console.error('Invalid project payload', Value.Errors(project));
    return false;
  }

  // 9. Cast to known type after validation passes.
  const safeProject = project as Project;

  // 10. Write to TinyBase using the project's id as the row id.
  store.setRow(PROJECTS_TABLE, safeProject.id, safeProject);
  return true;
}

// 11. Example usage simulating a SaaS user creating a project offline.
const exampleProject = {
  id: '123e4567-e89b-12d3-a456-426614174000',
  name: 'Local-First MVP',
  ownerId: 'user_42',
  createdAt: Date.now(),
  isArchived: false,
};

// 12. Attempt to insert the example project.
const inserted = addProject(exampleProject);
console.log('Inserted:', inserted);

// 13. Read all projects back from the store.
const allProjects = store.getTable(PROJECTS_TABLE);
console.log('All projects:', allProjects);

// 14. Read a single project by id.
const single = store.getRow(PROJECTS_TABLE, exampleProject.id);
console.log('Single project:', single);
