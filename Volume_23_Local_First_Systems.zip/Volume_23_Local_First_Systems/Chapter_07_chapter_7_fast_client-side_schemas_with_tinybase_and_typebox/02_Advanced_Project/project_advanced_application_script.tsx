/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/research-dashboard/DocumentExplorer.tsx

import React, { useState, useTransition } from 'react';
import { createStore, createIndexes } from 'tinybase';
import { Type, Static } from '@sinclair/typebox';
import { useStore } from 'tinybase/ui-react';

/**
 * JSDoc: TypeBox schema for a locally cached research document.
 * We enforce structure so that only valid rows enter TinyBase.
 */
const DocumentSchema = Type.Object({
  id: Type.String(),
  title: Type.String(),
  author: Type.String(),
  workspaceId: Type.String(),
  embedding: Type.Array(Type.Number()), // 1536-dim vector from OpenAI-like model
  updatedAt: Type.Number(),
});

/** Inferred TypeScript type from the TypeBox schema */
type DocumentRow = Static<typeof DocumentSchema>;

/**
 * JSDoc: TinyBase store factory.
 * Creates an isolated in-browser store for offline-ready document state.
 */
const store = createStore();

/**
 * JSDoc: Validate a raw unknown payload against DocumentSchema.
 * Returns null if invalid to prevent corrupt local state.
 */
function validateDocument(raw: unknown): DocumentRow | null {
  const result = DocumentSchema.Check(raw);
  if (!result) return null;
  return raw as DocumentRow;
}

/**
 * JSDoc: Server Action (Next.js) that performs metadata-filtered vector search.
 * Uses pgvector HNSW index for ANN lookup after scalar filtering.
 */
async function searchDocuments(
  workspaceId: string,
  author: string,
  queryVector: number[]
): Promise<unknown[]> {
  // In real app: call Postgres with pgvector HNSW + metadata WHERE clause
  const res = await fetch('/api/vector-search', {
    method: 'POST',
    body: JSON.stringify({ workspaceId, author, queryVector }),
  });
  return res.json();
}

/**
 * JSDoc: React component using useTransition for non-blocking UI.
 */
export default function DocumentExplorer() {
  const [isPending, startTransition] = useTransition();
  const [authorFilter, setAuthorFilter] = useState('Smith');
  const localStore = useStore(store);

  /**
   * 1. Handler triggers metadata-filtered vector search.
   * 2. Wraps slow Server Action in useTransition.
   * 3. Validates each returned row with TypeBox.
   * 4. Writes safe rows into TinyBase for instant local rendering.
   */
  function runSearch(queryVector: number[]) {
    startTransition(async () => {
      const rawRows = await searchDocuments('ws-1', authorFilter, queryVector);
      rawRows.forEach((raw) => {
        const doc = validateDocument(raw);
        if (doc) {
          localStore.setRow('documents', doc.id, doc);
        }
      });
    });
  }

  return (
    <div>
      <input
        value={authorFilter}
        onChange={(e) => setAuthorFilter(e.target.value)}
        placeholder="Filter by author"
      />
      <button onClick={() => runSearch(Array(1536).fill(0.1))}>
        {isPending ? 'Searching…' : 'Search Docs'}
      </button>
    </div>
  );
}
