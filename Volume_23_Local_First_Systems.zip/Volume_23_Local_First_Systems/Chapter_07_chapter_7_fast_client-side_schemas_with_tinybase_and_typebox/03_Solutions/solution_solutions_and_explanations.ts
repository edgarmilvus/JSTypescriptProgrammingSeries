/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Type, Static, Value } from '@sinclair/typebox';
import { createStore, TablesSchema } from 'tinybase';

// 1. Define TaskSchema with TypeBox
// Runtime validation is necessary even when TypeScript types exist because
// TS types are erased at compile time and cannot guard against invalid data
// arriving at runtime from IndexedDB, network sync, or user input.
export const TaskSchema = Type.Object({
  id: Type.String({ format: 'uuid' }),
  title: Type.String({ minLength: 1, maxLength: 200 }),
  status: Type.Union([
    Type.Literal('todo'),
    Type.Literal('doing'),
    Type.Literal('done'),
  ]),
  priority: Type.Optional(Type.Number({ minimum: 1, maximum: 5 })),
  createdAt: Type.Number(),
});

// 2. Derive Task type from schema
export type Task = Static<typeof TaskSchema>;

// 3. TinyBase TablesSchema (primitives only, no value-level constraints)
export const tablesSchema: TablesSchema = {
  tasks: {
    id: { type: 'string' },
    title: { type: 'string' },
    status: { type: 'string' },
    priority: { type: 'number' },
    createdAt: { type: 'number' },
  },
};

// 4. Validate and coerce before writing to TinyBase
export function validateTask(data: unknown): Task {
  // Value.Parse throws if invalid; alternatively use Value.Check for boolean
  return Value.Parse(TaskSchema, data);
}

// Example store usage
const store = createStore().setTablesSchema(tablesSchema);
const raw = { id: crypto.randomUUID(), title: 'Test', status: 'todo', createdAt: Date.now() };
const task = validateTask(raw);
store.setRow('tasks', task.id, task);
