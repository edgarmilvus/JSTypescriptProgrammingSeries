/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Type, Static, Value } from '@sinclair/typebox';
import { createStore, Store, TablesSchema } from 'tinybase';

// ProjectSchema definition
export const ProjectSchema = Type.Object({
  id: Type.String(),
  name: Type.String(),
  archived: Type.Boolean(),
  memberCount: Type.Number(),
});
type Project = Static<typeof ProjectSchema>;

const tablesSchema: TablesSchema = {
  projects: { id: 'string', name: 'string', archived: 'boolean', memberCount: 'number' },
  errors: { id: 'string', reason: 'string' },
};

// Wrapper intercepts writes and validates
export function createValidatingStore(): Store {
  const store = createStore().setTablesSchema(tablesSchema);

  // Log failed rows to errors table instead of throwing
  store.addRowListener('projects', null, (store, tableId, rowId, row) => {
    if (!Value.Check(ProjectSchema, row)) {
      store.setRow('errors', rowId, { id: rowId, reason: 'Invalid project row' });
    }
  });

  // Wrap setRow to gate writes (simplified interception)
  const originalSetRow = store.setRow.bind(store);
  store.setRow = (table, rowId, row) => {
    if (table === 'projects' && !Value.Check(ProjectSchema, row)) {
      store.setRow('errors', rowId, { id: rowId, reason: 'Blocked write' });
      return store;
    }
    return originalSetRow(table, rowId, row);
  };

  // This pattern prevents CRDT merge corruption by ensuring only valid rows
  // are accepted locally; invalid peer data is quarantined in errors.
  return store;
}
