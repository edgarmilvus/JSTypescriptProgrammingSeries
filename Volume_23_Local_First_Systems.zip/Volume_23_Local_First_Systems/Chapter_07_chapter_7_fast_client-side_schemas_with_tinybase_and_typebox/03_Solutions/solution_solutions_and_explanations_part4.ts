/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Type, Static, Value } from '@sinclair/typebox';

// 1. NoteSchema with 1536-dim embedding
export const NoteSchema = Type.Object({
  id: Type.String(),
  body: Type.String(),
  embedding: Type.Array(Type.Number(), { minLength: 1536, maxLength: 1536 }),
  updatedAt: Type.Number(),
});
type Note = Static<typeof NoteSchema>;

// 2. Stub to validate and POST to Supabase Edge Function
export async function syncToPgVector(note: unknown) {
  const valid = Value.Parse(NoteSchema, note); // throws if bad
  await fetch('/api/embed', {
    method: 'POST',
    body: JSON.stringify(valid),
  });
}

// 3. WASM DB receives validated rows via exec
// wasmDb.exec(`INSERT INTO notes VALUES (?,?,?,?)`, [valid.id, valid.body, ...]);

// 4. TinyBase Relationships link notes to embeddings metadata table
// store.setRelationshipsSchema({ embeds: { from: 'notes', to: 'embeddings' } });
