/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// tasks-server.ts
// -----------------------------------------------------------------------------
// SaaS Context: A lightweight project management web app where users create tasks.
// This file simulates the server-side mutation endpoint using a Server Action.
// -----------------------------------------------------------------------------

/**
 * Represents a task created by a user in the SaaS app.
 */
interface Task {
  id: string;
  title: string;
  done: boolean;
}

/**
 * Type Guard: ensures an unknown value conforms to the Task shape.
 * Used to safely narrow types after receiving data from the client.
 * @param value - The unknown payload sent from the browser.
 * @returns true if value is a valid Task, enabling type narrowing.
 */
function isTask(value: unknown): value is Task {
  // First, confirm the value is a non-null object (not null or primitive).
  if (typeof value !== 'object' || value === null) {
    return false;
  }

  // Cast to a record so we can inspect properties dynamically.
  const record = value as Record<string, unknown>;

  // Validate the 'id' field: must be a string.
  if (typeof record['id'] !== 'string') {
    return false;
  }

  // Validate the 'title' field: must be a string and non-empty.
  if (typeof record['title'] !== 'string' || record['title'].trim() === '') {
    return false;
  }

  // Validate the 'done' field: must be a boolean.
  if (typeof record['done'] !== 'boolean') {
    return false;
  }

  // All checks passed; TypeScript now knows value is Task inside calling scope.
  return true;
}

/**
 * Server Action: persists a new task to the backend.
 * In a real local-first app, this would eventually sync via ElectricSQL or Replicache.
 * @param formData - Data submitted from a client form or direct call.
 */
export async function createTaskAction(formData: FormData): Promise<Task | null> {
  // Extract raw values from FormData (always strings or File objects).
  const rawId = formData.get('id');
  const rawTitle = formData.get('title');
  const rawDone = formData.get('done');

  // Build a loosely typed object from the form entries.
  const candidate = {
    id: typeof rawId === 'string' ? rawId : '',
    title: typeof rawTitle === 'string' ? rawTitle : '',
    done: rawDone === 'true', // checkbox or string coercion
  };

  // Use the Type Guard to validate before trusting the shape.
  if (!isTask(candidate)) {
    // Invalid payload: fail safely without crashing the server.
    return null;
  }

  // At this point, 'candidate' is narrowed to type Task.
  // Simulate database persistence (e.g., via Drizzle, Prisma, or Supabase).
  const savedTask: Task = {
    ...candidate,
    id: candidate.id || crypto.randomUUID(),
  };

  // In a full app, we would await db.insert(tasks).values(savedTask)
  // and later broadcast via replication log.
  return savedTask;
}
