/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * AdvancedApplicationScript.tsx
 * Demonstrates dynamic synchronization using Replicache + LangGraph + Vercel AI SDK UIState
 * in a local-first Next.js SaaS task-board application.
 */

// Import Next.js and React essentials
import React from 'react';
import { useUIState, useAIState } from 'ai/rsc';

// Import Replicache for local-first optimistic mutation caching
import { Replicache } from 'replicache';

// Import LangGraph primitives for workflow orchestration
import { StateGraph, END } from '@langchain/langgraph';

/**
 * JSDoc: UIState type representing the presentation layer components.
 * Each entry is a React node rendered based on AIState transitions.
 */
type UIState = {
  component: React.ReactNode;
  role: 'assistant' | 'user';
};

/**
 * JSDoc: AIState type holding the backend workflow state.
 * Tracks boardId, pendingMutations, and syncStatus.
 */
type AIState = {
  boardId: string;
  pendingMutations: number;
  syncStatus: 'idle' | 'syncing' | 'conflict';
};

// 1. Initialize Replicache with a unique client group per board session
const rep = new Replicache({
  name: 'task-board-session',
  // Pull endpoint dynamically replicates PostgreSQL changes via WASM DB
  pullURL: '/api/replicache/pull',
  // Push endpoint sends local mutations to the sync engine
  pushURL: '/api/replicache/push',
  // Use CRDT-like mutation handlers for conflict-free merges
  mutators: {
    async moveTask(tx, { taskId, toColumn }: { taskId: string; toColumn: string }) {
      // Optimistically update local index without waiting for server
      await tx.set(`task/${taskId}`, { column: toColumn, updatedAt: Date.now() });
    },
  },
});

/**
 * JSDoc: Entry Point Node of the LangGraph StateGraph.
 * This node initializes the workflow by loading board state into AIState.
 */
async function entryNode(state: AIState): Promise<Partial<AIState>> {
  // Mark sync as idle and reset pending mutations
  return { ...state, syncStatus: 'idle', pendingMutations: 0 };
}

/**
 * JSDoc: Conditional Edge predicate.
 * Inspects AIState and returns the next node name based on sync status.
 */
function routeBasedOnSync(state: AIState): string {
  if (state.pendingMutations > 0) return 'syncNode';
  if (state.syncStatus === 'conflict') return 'resolveNode';
  return 'renderNode';
}

/**
 * JSDoc: syncNode pushes Replicache mutations to the server.
 * Demonstrates dynamic synchronization with optimistic UI support.
 */
async function syncNode(state: AIState): Promise<Partial<AIState>> {
  // Trigger Replicache push; WASM DB serializes mutations
  await rep.push();
  return { ...state, syncStatus: 'syncing', pendingMutations: 0 };
}

/**
 * JSDoc: resolveNode handles CRDT conflicts detected by the sync engine.
 */
async function resolveNode(state: AIState): Promise<Partial<AIState>> {
  // In a real app, merge logic would run here using last-write-wins or CRDT
  return { ...state, syncStatus: 'idle' };
}

/**
 * JSDoc: renderNode updates Vercel AI SDK UIState with streamable React UI.
 */
async function renderNode(state: AIState, setUIState: (u: UIState) => void) {
  // Push a presentation-layer component reflecting current board
  setUIState({
    role: 'assistant',
    component: <BoardView boardId={state.boardId} rep={rep} />,
  });
  return state;
}

// 2. Build the LangGraph StateGraph with entry and conditional edges
const graph = new StateGraph<AIState>({ channels: {} })
  .addNode('entry', entryNode)
  .addNode('syncNode', syncNode)
  .addNode('resolveNode', resolveNode)
  .addNode('renderNode', renderNode)
  .setEntryPoint('entry') // Entry Point Node designation
  .addConditionalEdges('entry', routeBasedOnSync) // Conditional Edge from entry
  .addEdge('syncNode', 'renderNode')
  .addEdge('resolveNode', 'renderNode')
  .addEdge('renderNode', END);

// 3. React component that uses UIState to show dynamic board
function BoardView({ boardId, rep }: { boardId: string; rep: Replicache }) {
  const [tasks, setTasks] = React.useState<Record<string, any>>({});
  React.useEffect(() => {
    // Subscribe to Replicache changes for reactive local-first UI
    return rep.subscribe(async (tx) => {
      const all = await tx.scan({ prefix: 'task/' }).values().toArray();
      setTasks(Object.fromEntries(all.map((v, i) => [i, v])));
    });
  }, [rep]);
  return <div>Board {boardId}: {JSON.stringify(tasks)}</div>;
}

// 4. Exported assistant hook used in Next.js RSC route
export async function runAssistant(boardId: string) {
  const [_, setUIState] = useUIState<UIState>();
  const [aiState] = useAIState<AIState>();
  const app = graph.compile();
  // Execute workflow starting at Entry Point Node
  await app.invoke({ ...aiState, boardId });
  // UIState updated via renderNode for streaming interface
}
