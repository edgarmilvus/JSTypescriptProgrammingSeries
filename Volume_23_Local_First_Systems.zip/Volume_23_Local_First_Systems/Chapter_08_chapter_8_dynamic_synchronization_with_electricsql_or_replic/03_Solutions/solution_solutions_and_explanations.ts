/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Sync state union representing the lifecycle of the replication connection
export type SyncState =
  | 'connecting'
  | 'replicating'
  | 'paused-offline'
  | 'error';

// Configuration interface for the sync engine
export interface SyncEngineConfig {
  postgresUrl: string;
  jwtTokenProvider: () => Promise<string>;
  clientId: string;
  persistenceMode: 'in-memory' | 'indexeddb' | 'opfs';
  onConnectionStateChange: (state: SyncState) => void;
}

// Handle returned after initialization, exposing control methods
export interface ElectricSyncHandle {
  start(): Promise<void>;
  stop(): Promise<void>;
  getReplicationLag(): number;
}

// Function signature only — no implementation as per exercise constraints
export function initializeElectricSync(config: SyncEngineConfig): Promise<ElectricSyncHandle> {
  // Implementation appears in next chapter
  return Promise.resolve({} as ElectricSyncHandle);
}

/*
Exercise Notes (prose):
The satellite protocol resumes from a stored LSN by sending a `START` message that includes the
last persisted LSN. The PostgreSQL logical replication slot then streams only transactions after
that point, avoiding a full resync. If the client crashes, the LSN is read from the chosen
persistence layer on boot. `persistenceMode: 'opfs'` is preferable in modern browsers because the
Origin Private File System allows synchronous file access inside a Web Worker, delivering near-native
write throughput and avoiding the serialization overhead of IndexedDB for WASM SQLite pages.

Unit-test walkthrough (Vitest + fake timers):
To test jwtTokenProvider refresh logic, mount the module with a mocked provider returning an
expiring token. Use vi.useFakeTimers() to advance time past the expiry window, then await
vi.advanceTimersByTimeAsync() to let the refresh callback fire. Assert that a new token was
requested and the connection state stayed 'replicating' without a full reconnect.
*/
