/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import { Replicache } from 'replicache';
import { useEffect, useState } from 'react';

// Mutators interface (signatures only)
export interface Mutators {
  setTaskDone: (args: { id: string; done: boolean }) => Promise<void>;
}

// Component specification
export function TaskRow({
  taskId,
  initialDone,
  rep,
}: {
  taskId: string;
  initialDone: boolean;
  rep: Replicache<Mutators>;
}) {
  const [done, setDone] = useState(initialDone);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    // Reactive subscription to local cache
    return rep.subscribe(
      async (tx) => {
        const val = await tx.get(`task/${taskId}/done`);
        return val ?? initialDone;
      },
      (val) => setDone(val as boolean)
    );
  }, [rep, taskId, initialDone]);

  async function onToggle(e: React.ChangeEvent<HTMLInputElement>) {
    const next = e.target.checked;
    setDone(next);
    setSyncing(true);
    await rep.mutate.setTaskDone({ id: taskId, done: next });
    setSyncing(false);
  }

  return (
    <label>
      <input type="checkbox" checked={done} onChange={onToggle} />
      {syncing && <span className="badge">syncing</span>}
    </label>
  );
}

/*
Push mechanism notes (prose):
Replicache batches mutations in the local log and sends them to the server on a timer or visibility
change. Each mutation carries a monotonically increasing `lastMutationID` per client. The server
applies only mutations with ID greater than the stored `lastMutationID` for that client, making
replays idempotent and preventing duplicates.

Local-first violation note:
A naive fetch() in the handler blocks UI on network and writes to the server first, breaking
offline use. In LangGraph.js, Asynchronous Tool Handling wraps such calls in a node that returns a
Promise; the graph awaits it without freezing the client, preserving local-first by keeping the
mutation local until the tool resolves.
*/
