/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Immutable token for RGA-style sequence
export type RgaToken = {
  id: string;
  prev: string | null;
  value: string;
  deleted: boolean;
};

// Merge signature (no implementation)
export function mergeTokens(local: RgaToken[], remote: RgaToken[]): RgaToken[] {
  // Commutative merge by id and prev pointers
  return [];
}

/*
Storage note:
Tokens are stored under Replicache keys like `doc/<docId>/tokens/<tokenId>` or as a map value at
`doc/<docId>/tokens` so subscriptions can observe the whole sequence.

Thought-Action-Observation example (prose):
Thought: "Two token sets diverged offline; I should merge them."
Action: Call mergeTokens(local, remote) tool.
Observation: Merged array length is sum minus overlaps; no deletion conflict.
Thought: "Length increased by both edits, so both intent preserved — no manual fix needed."

RGA vs LWW note:
RGA keeps prev-pointer ordering from the replication stream, so inserts by A and B reference
distinct anchors and both survive. Last-write-wins would drop one edit based on timestamp,
erasing user intent.
*/
