/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Guard to enforce no direct DB calls after init
export function guardAgainstDirectDbCall(): never {
  throw new Error('Direct Supabase DB call post-init violates local-first');
}

/*
Challenge notes (prose):
1. The edge Client -> Supa bypasses Replicache/ElectricSQL, so reads/writes skip the local cache
   and fail offline, breaking local-first guarantees.
2. Correct offline flow: User edits hit Replicache local cache; mutations queue. After 10 min,
   on reconnect, Replicache pushes the queue and ElectricSQL pulls missed changes via satellite.
3. Refactor: Supabase JS only used pre-init for auth token refresh and bootstrap snapshot; all
   ongoing traffic goes Client -> Replicache -> ElectricSQL -> Postgres.
4. Pseudo-signature shown above throws if a post-init query is attempted.
5. TAO review: Thought "Why is latency high?" -> Action: scan for Supa calls -> Observation:
   direct query found -> Thought: "Architecture violation, must route via local cache."
*/
