/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export type PersistenceStrategy = 'in-memory' | 'indexeddb' | 'opfs';

// Selection based on device and criticality
export function selectPersistence(opts: {
  supportsOPFS: boolean;
  isCritical: boolean;
  maxOfflineHours: number;
}): PersistenceStrategy {
  if (opts.supportsOPFS) return 'opfs';
  if (opts.isCritical || opts.maxOfflineHours > 4) return 'indexeddb';
  return 'in-memory';
}

/*
Persistence notes (prose):
ElectricSQL backs WASM SQLite with the chosen strategy; the LSN persists with it. In-memory loses
LSN on reload; indexeddb/opfs keep it for resume.

Under the hood: IndexedDB uses async transactional JS APIs on the main thread; OPFS sync access
handles in a Worker allow blocking file I/O without janking the UI.

Degraded scenario: maxOfflineHours 12, no OPFS -> indexeddb; UI shows "Offline mode: changes saved
locally, will sync later" to set expectation.

LangGraph.js probe: A node awaits an async OPFS capability check (Asynchronous Tool Handling) before
calling selectPersistence, so the graph never blocks on sync FS access.
*/
