/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Basic WebRTC Data Channel Example for Local-First SaaS Apps
 * 
 * This module demonstrates the minimal steps required to open a
 * peer-to-peer data channel between two RTCPeerConnection instances
 * running in the same browser context (e.g., two tabs scripted together
 * for testing). In a real SaaS deployment, signaling would be performed
 * via WebSocket or WebTransport to a lightweight broker.
 */

// 1. Create two peer connections representing two SaaS client sessions.
//    In production these would live in different browsers/devices.
const peerA: RTCPeerConnection = new RTCPeerConnection();
const peerB: RTCPeerConnection = new RTCPeerConnection();

// 2. Create a data channel on Peer A. This channel will be used to send
//    collaborative messages (later CRDT updates) directly to Peer B.
const channelA: RTCDataChannel = peerA.createDataChannel("saas-sync");

// 3. Handle incoming data channel on Peer B. When Peer A creates the
//    channel, Peer B receives it via the 'datachannel' event.
peerB.ondatachannel = (event: RTCDataChannelEvent) => {
  const channelB: RTCDataChannel = event.channel;

  // 4. When Peer B receives the channel, attach a message listener.
  channelB.onmessage = (msgEvent: MessageEvent) => {
    // 5. Log the received message in the SaaS debug console.
    console.log(`Peer B received: ${msgEvent.data}`);
  };
};

// 6. Wire up ICE candidate exchange. In a real app this goes over signaling.
peerA.onicecandidate = (e: RTCPeerConnectionIceEvent) => {
  if (e.candidate) {
    // 7. Simulate signaling by directly adding to Peer B.
    peerB.addIceCandidate(e.candidate).catch(console.error);
  }
};

peerB.onicecandidate = (e: RTCPeerConnectionIceEvent) => {
  if (e.candidate) {
    // 8. Simulate signaling by directly adding to Peer A.
    peerA.addIceCandidate(e.candidate).catch(console.error);
  }
};

// 9. Create an offer from Peer A to start negotiation.
peerA.createOffer()
  .then((offer: RTCSessionDescriptionInit) => {
    // 10. Set local description on A and remote on B.
    return peerA.setLocalDescription(offer)
      .then(() => peerB.setRemoteDescription(offer));
  })
  .then(() => {
    // 11. Peer B creates an answer to complete the handshake.
    return peerB.createAnswer();
  })
  .then((answer: RTCSessionDescriptionInit) => {
    // 12. Set local on B and remote on A.
    return peerB.setLocalDescription(answer)
      .then(() => peerA.setRemoteDescription(answer));
  })
  .then(() => {
    // 13. Wait for channel to open then send a hello world.
    channelA.onopen = () => {
      channelA.send("Hello World from Peer A");
    };
  })
  .catch((err: Error) => console.error("Negotiation failed:", err));
