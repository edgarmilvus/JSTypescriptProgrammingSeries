/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// peerSyncManager.ts
// Advanced Application Script: P2P Data Transfer via WebRTC and WebTransport in a Next.js SaaS Context

import { createClient } from '@supabase/supabase-js';
// Supabase Client (JS): SDK to interface with PostgreSQL + pgvector for durable vector metadata.
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

/**
 * Supported transport types for local-first peer sync.
 * WebRTC is preferred for low-latency browser-to-browser transfer.
 * WebTransport is used when NAT traversal fails or enterprise proxies block UDP.
 */
type TransportKind = 'webrtc' | 'webtransport';

/**
 * Represents a negotiated peer connection with a unified send interface.
 */
interface PeerChannel {
  kind: TransportKind;
  send: (data: Uint8Array) => void;
  close: () => void;
}

/**
 * PeerSyncManager handles connection establishment, fallback logic,
 * and CRDT/WASM payload delivery between collaborators.
 */
export class PeerSyncManager {
  private rtcPeer: RTCPeerConnection | null = null;
  private wtTransport: WebTransport | null = null;
  private activeChannel: PeerChannel | null = null;

  /**
   * Initializes a WebRTC offer and returns the SDP for signaling.
   * In a real SaaS app, this SDP would be exchanged via Supabase Realtime or a WebSocket lobby.
   */
  async createWebRTCOffer(): Promise<RTCSessionDescriptionInit> {
    // 1. Create RTCPeerConnection with STUN for NAT traversal.
    this.rtcPeer = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    // 2. Open a reliable DataChannel for CRDT binary updates.
    const dc = this.rtcPeer.createDataChannel('crdt-sync', {
      ordered: true,
    });

    // 3. Wrap DataChannel into our unified PeerChannel interface.
    this.activeChannel = {
      kind: 'webrtc',
      send: (data) => dc.readyState === 'open' && dc.send(data),
      close: () => dc.close(),
    };

    // 4. Generate and return the offer SDP for signaling exchange.
    const offer = await this.rtcPeer.createOffer();
    await this.rtcPeer.setLocalDescription(offer);
    return offer;
  }

  /**
   * Falls back to WebTransport when WebRTC negotiation fails.
   * WebTransport uses HTTP/3 and is TCP/UDP hybrid friendly.
   */
  async fallbackToWebTransport(peerUrl: string): Promise<void> {
    // 1. Instantiate WebTransport with a secure HTTPS/3 endpoint.
    this.wtTransport = new WebTransport(peerUrl);

    // 2. Wait for the transport to be ready before sending.
    await this.wtTransport.ready;

    // 3. Open a unidirectional stream for CRDT bursts.
    const stream = await this.wtTransport.createUnidirectionalStream();
    const writer = stream.writable.getWriter();

    // 4. Adapt WebTransport stream into PeerChannel interface.
    this.activeChannel = {
      kind: 'webtransport',
      send: (data) => writer.write(data),
      close: () => writer.close(),
    };
  }

  /**
   * Sends a CRDT update and conditionally upserts a vector ID to Supabase
   * for server-side LangGraph conditional edge routing.
   */
  async syncUpdate(payload: Uint8Array, vectorId: string, embedding: number[]) {
    // 1. Ensure we have an active channel (WebRTC or WebTransport).
    if (!this.activeChannel) throw new Error('No active peer channel');

    // 2. Push binary CRDT update directly to the peer.
    this.activeChannel.send(payload);

    // 3. Upsert vector metadata to Supabase for durable graph state.
    // Upsert Operation: update if vectorId exists, else insert.
    const { error } = await supabase.from('graph_vectors').upsert({
      id: vectorId,
      embedding,
      updated_at: new Date().toISOString(),
    });

    if (error) console.error('Supabase upsert failed', error);
  }
}
