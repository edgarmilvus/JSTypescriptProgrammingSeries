/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// secureWebRTC.ts

// Minimal event emitter for typed events
type PeerEvent = 'open' | 'message' | 'icecandidate';
class Emitter {
  private handlers: Record<PeerEvent, ((data: any) => void)[]> = {
    open: [], message: [], icecandidate: []
  };
  on(ev: PeerEvent, cb: (data: any) => void) {
    this.handlers[ev].push(cb);
  }
  emit(ev: PeerEvent, data: any) {
    this.handlers[ev].forEach(cb => cb(data));
  }
}

export class ManualSignalingPeer {
  private pc: RTCPeerConnection;
  private channel: RTCDataChannel | null = null;
  public events = new Emitter();

  constructor(stunUrl: string) {
    this.pc = new RTCPeerConnection({ iceServers: [{ urls: stunUrl }] });
    // Create ordered data channel with retransmits for reliability
    this.channel = this.pc.createDataChannel('crdt', { ordered: true, maxRetransmits: 30 });
    this.channel.onopen = () => this.events.emit('open', null);
    this.channel.onmessage = (e) => this.events.emit('message', e.data);
    // Emit local ICE candidates for manual exchange
    this.pc.onicecandidate = (e) => {
      if (e.candidate) this.events.emit('icecandidate', JSON.stringify(e.candidate));
    };
  }

  async createOffer(): Promise<string> {
    const offer = await this.pc.createOffer();
    await this.pc.setLocalDescription(offer);
    return JSON.stringify(this.pc.localDescription);
  }

  async acceptAnswer(answerSdp: string): Promise<void> {
    const desc = JSON.parse(answerSdp);
    await this.pc.setRemoteDescription(desc);
  }

  async createAnswer(offerSdp: string): Promise<string> {
    const desc = JSON.parse(offerSdp);
    await this.pc.setRemoteDescription(desc);
    const answer = await this.pc.createAnswer();
    await this.pc.setLocalDescription(answer);
    return JSON.stringify(this.pc.localDescription);
  }

  sendData(payload: Uint8Array): void {
    if (this.channel?.readyState === 'open') {
      this.channel.send(payload);
    }
  }
}

/*
DOT_DIAGRAM:
digraph ManualSignaling {
  PeerA -> PeerB [label="copy offer SDP"];
  PeerB -> PeerA [label="copy answer SDP"];
  PeerA -> PeerB [label="ICE candidates (manual)"];
  PeerB -> PeerA [label="ICE candidates (manual)"];
  PeerA -> PeerB [label="Uint8Array CRDT over DataChannel"];
}
*/
