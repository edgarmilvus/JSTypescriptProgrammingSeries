/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// TransportSelector.ts

export interface P2PTransport {
  send(bytes: Uint8Array): void;
  onMessage(cb: (b: Uint8Array) => void): void;
  close(): Promise<void>;
}

export interface Logger {
  log(state: string): void;
}

class WebRTCTransport implements P2PTransport {
  private channel: RTCDataChannel;
  private msgCb: (b: Uint8Array) => void = () => {};
  constructor(channel: RTCDataChannel) {
    this.channel = channel;
    this.channel.onmessage = (e) => this.msgCb(e.data);
  }
  send(bytes: Uint8Array) { this.channel.send(bytes); }
  onMessage(cb: (b: Uint8Array) => void) { this.msgCb = cb; }
  async close() { this.channel.close(); }
}

class WebTransportFallback implements P2PTransport {
  private wt: WebTransport;
  private reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  private msgCb: (b: Uint8Array) => void = () => {};
  constructor(url: string) { this.wt = new WebTransport(url); }
  async init() {
    await this.wt.ready;
    const ds = this.wt.datagrams;
    this.reader = ds.readable.getReader();
    this.readLoop();
  }
  private async readLoop() {
    // Reconstruct fragmented datagrams (max 1200 bytes)
    let buffer: Uint8Array = new Uint8Array(0);
    while (true) {
      const { value, done } = await this.reader!.read();
      if (done) break;
      if (value) {
        buffer = new Uint8Array([...buffer, ...value]);
        if (buffer.length >= 1200 || value.length < 1200) {
          this.msgCb(buffer); buffer = new Uint8Array(0);
        }
      }
    }
  }
  send(bytes: Uint8Array) { this.wt.datagrams.writable.getWriter().write(bytes); }
  onMessage(cb: (b: Uint8Array) => void) { this.msgCb = cb; }
  async close() { await this.wt.close(); }
}

export class TransportSelector {
  private logger: Logger;
  private relayUrl: string;
  current: P2PTransport | null = null;
  constructor(logger: Logger, relayUrl = 'https://relay.example.com') {
    this.logger = logger; this.relayUrl = relayUrl;
  }
  async connect(rtcFactory: () => Promise<WebRTCTransport>) {
    this.logger.log('connecting');
    try {
      const timeout = new Promise((_, rej) => setTimeout(() => rej('timeout'), 4000));
      this.current = await Promise.race([rtcFactory(), timeout]) as WebRTCTransport;
    } catch {
      this.logger.log('webrtc-failed');
      const fb = new WebTransportFallback(this.relayUrl);
      await fb.init();
      this.current = fb;
      this.logger.log('webtransport-active');
    }
  }
}

/*
DOT_DIAGRAM:
digraph Fallback {
  Start -> Connecting [label="begin"];
  Connecting -> WebRTC [label="try 4s"];
  WebRTC -> Failed [label="timeout/error"];
  Failed -> WebTransport [label="instantiate"];
  WebTransport -> Active [label="ready"];
}
*/
