/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// PeerStatusBoard.tsx
import React, { useEffect, useRef, useState } from 'react';
import type { TransportSelector } from './TransportSelector';

type PeerState = { peerId: string; transportType: 'webrtc' | 'webtransport'; lastSeen: number };

export function PeerStatusBoard({ transport }: { transport: TransportSelector }) {
  const [peers, setPeers] = useState<PeerState[]>([]);
  const buffer = useRef<PeerState[]>([]);
  const raf = useRef<number>();

  useEffect(() => {
    const onPeer = (p: PeerState) => {
      buffer.current.push(p);
      if (!raf.current) {
        raf.current = requestAnimationFrame(() => {
          setPeers([...buffer.current]);
          buffer.current = [];
          raf.current = undefined;
        });
      }
    };
    transport.onPeerEvent?.(onPeer); // assume selector exposes this
    return () => {
      cancelAnimationFrame(raf.current!);
      transport.offPeerEvent?.(onPeer);
    };
  }, [transport]);

  return (
    <div>
      <h3>Peer Status Board</h3>
      <ul>
        {peers.map(p => (
          <li key={p.peerId}>
            {p.peerId} - {p.transportType} - {Math.round((Date.now() - p.lastSeen) / 1000)}s ago
          </li>
        ))}
      </ul>
      <details>
        <summary>Raw Stats</summary>
        <pre>{JSON.stringify(peers, null, 2)}</pre>
      </details>
    </div>
  );
}
