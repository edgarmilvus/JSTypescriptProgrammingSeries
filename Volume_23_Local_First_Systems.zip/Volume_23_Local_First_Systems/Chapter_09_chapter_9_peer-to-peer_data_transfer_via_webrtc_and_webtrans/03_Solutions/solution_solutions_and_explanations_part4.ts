/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// CRDTSyncManager.ts
export type SyncMessage = { type: 'sync-request' | 'sync-response' | 'op'; clock: Uint8Array; payload: Uint8Array };

export interface WasmDB {
  applyOp(payload: Uint8Array): void;
  getStateVector(): Uint8Array;
}

export class CRDTSyncManager {
  private transport: P2PTransport;
  private db: WasmDB;
  private seenClocks = new Set<string>();

  constructor(transport: P2PTransport, db: WasmDB) {
    this.transport = transport;
    this.db = db;
    this.transport.onMessage((b) => this.handle(new Uint8Array(b)));
  }

  start() {
    const sv = this.db.getStateVector();
    this.send({ type: 'sync-request', clock: sv, payload: new Uint8Array() });
  }

  private send(msg: SyncMessage) {
    this.transport.send(new Uint8Array(Object.values(msg).flatMap(x => Array.from(x))));
  }

  private handle(raw: Uint8Array) {
    // simplified parse: assume structured as concatenated fields
    const msg = this.parse(raw);
    const key = Array.from(msg.clock).join(',');
    if (this.seenClocks.has(key)) return;
    this.seenClocks.add(key);

    if (msg.type === 'sync-request') {
      const diff = this.db.getStateVector(); // mock diff
      this.send({ type: 'sync-response', clock: msg.clock, payload: diff });
    } else if (msg.type === 'sync-response' || msg.type === 'op') {
      this.db.applyOp(msg.payload.slice());
      // broadcast to others except sender (mock: just log)
    }
  }

  private parse(raw: Uint8Array): SyncMessage {
    // mock parser
    return { type: 'op', clock: raw.slice(0, 4), payload: raw.slice(4) };
  }
}

/*
DOT_DIAGRAM:
digraph Sync {
  A -> B [label="sync-request (state vector)"];
  B -> A [label="sync-response (diff ops)"];
  A -> B [label="op (applyOp)"];
}
*/
