/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

# NAT Traversal Observation Lab Journal

## Test Topology (DOT_DIAGRAM)
digraph Topology {
  BrowserA -> STUN;
  BrowserB -> SymmetricNAT -> STUN;
  BrowserA -> BrowserB [label="WebRTC DataChannel", style=dashed];
}

## Tasks
1. Same LAN: host candidates = 2, srflx = 1 (STUN worked).
2. Symmetric NAT: connection failed without TURN (ICE state: failed).
3. Invalid STUN: iceconnectionstate went checking -> disconnected -> failed.
4. chrome://webrtc-internals: onopen fired 120ms after ICE gathering complete.
5. WebTransport latency: 15ms avg vs 8ms WebRTC on same payload.

## Snippets
const peer = new ManualSignalingPeer('stun:stun.l.google.com:19302');
console.log(await peer.createOffer());
