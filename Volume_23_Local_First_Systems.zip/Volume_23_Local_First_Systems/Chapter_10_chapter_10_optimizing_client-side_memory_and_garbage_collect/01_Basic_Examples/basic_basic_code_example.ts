/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Simulated local-first database for a SaaS project management app.
 * This is a Hello World level example to show memory bounding and
 * explicit garbage collection of retained state.
 */
type DocId = string;

/** Shape of a collaborative document in our offline-ready board. */
interface BoardDoc {
  id: DocId;
  title: string;
  /** Simulated CRDT byte payload (e.g., from a WASM lib). */
  crdtBytes: Uint8Array;
}

/**
 * A tiny fake WASM heap manager.
 * In real apps this would be a binding to a Rust/CPP WASM DB.
 */
class FakeWasmHeap {
  private allocated: number = 0;

  /**
   * Allocate fake bytes on the WASM heap.
   * @param size number of bytes
   */
  alloc(size: number): void {
    this.allocated += size;
  }

  /**
   * Free bytes from the WASM heap.
   * @param size number of bytes
   */
  free(size: number): void {
    this.allocated = Math.max(0, this.allocated - size);
  }

  /** Report current heap usage. */
  usage(): number {
    return this.allocated;
  }
}

/**
 * Local-first board store with bounded memory.
 */
class LocalBoardStore {
  private docs: Map<DocId, BoardDoc> = new Map();
  private wasm: FakeWasmHeap = new FakeWasmHeap();
  private maxDocs: number;

  /**
   * @param maxDocs maximum number of docs to keep in memory
   */
  constructor(maxDocs: number) {
    this.maxDocs = maxDocs;
  }

  /**
   * Add or update a board document.
   * @param doc the board document
   */
  upsert(doc: BoardDoc): void {
    // If we already have it, free old CRDT bytes first
    const existing = this.docs.get(doc.id);
    if (existing) {
      this.wasm.free(existing.crdtBytes.length);
    }
    this.docs.set(doc.id, doc);
    this.wasm.alloc(doc.crdtBytes.length);

    // Enforce memory bound by evicting oldest
    if (this.docs.size > this.maxDocs) {
      const oldestId = this.docs.keys().next().value as DocId;
      const removed = this.docs.get(oldestId)!;
      this.wasm.free(removed.crdtBytes.length);
      this.docs.delete(oldestId);
    }
  }

  /**
   * Explicitly clear all retained docs and reclaim WASM memory.
   * Simulates a manual GC trigger for local-first apps.
   */
  collectGarbage(): void {
    for (const doc of this.docs.values()) {
      this.wasm.free(doc.crdtBytes.length);
    }
    this.docs.clear();
  }

  /** Current in-memory doc count. */
  docCount(): number {
    return this.docs.size;
  }

  /** Current WASM heap usage. */
  heapUsage(): number {
    return this.wasm.usage();
  }
}

// --- SaaS App Usage Example ---
const store = new LocalBoardStore(2); // keep at most 2 docs

// Simulate offline board edits
store.upsert({
  id: "board-1",
  title: "Q3 Roadmap",
  crdtBytes: new Uint8Array(1024),
});
store.upsert({
  id: "board-2",
  title: "Sprint 12",
  crdtBytes: new Uint8Array(2048),
});
store.upsert({
  id: "board-3",
  title: "Design Review",
  crdtBytes: new Uint8Array(512),
});

console.log("Docs in memory:", store.docCount());
console.log("Heap usage:", store.heapUsage());

// User logs out or switches workspace: reclaim memory
store.collectGarbage();
console.log("After GC docs:", store.docCount());
console.log("After GC heap:", store.heapUsage());
