/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// Advanced Application Script: Memory-bounded local-first collaboration client
// Context: SaaS app using WASM DB + CRDT + Pinecone recall + SSE model streaming

import React, { useEffect, useRef, useState } from "react";
// Pinecone client is used server-side; here we call our own API route that proxies it.
// We import the WASM DB factory and CRDT type from our local-first SDK.
import { createWasmLocalDb, WasmLocalDb, CrdtDoc } from "@saas/local-first";
import { useEventSource } from "@/hooks/useEventSource";

/**
 * Shape of streamed model tokens received from the Next.js backend.
 */
interface ModelToken {
  delta: string;
  done: boolean;
}

/**
 * Props for the collaborative editor client component.
 */
interface CollaborativeEditorProps {
  docId: string;
  userId: string;
}

/**
 * Client Component that renders a collaborative, offline-ready editor.
 * It streams AI output, writes to a CRDT-backed WASM DB, and reclaims memory.
 */
export const CollaborativeEditor: React.FC<CollaborativeEditorProps> = ({
  docId,
  userId,
}) => {
  // 1. Local UI state for streamed text (kept small; not the source of truth)
  const [streamedText, setStreamedText] = useState<string>("");

  // 2. Ref to the WASM DB instance (must be explicitly closed)
  const dbRef = useRef<WasmLocalDb | null>(null);

  // 3. Ref to the CRDT document handle (must be dropped to free memory)
  const crdtRef = useRef<CrdtDoc | null>(null);

  // 4. Ref to the EventSource used for model streaming (must be closed)
  const eventRef = useRef<EventSource | null>(null);

  // 5. Ref to interval timer for periodic WASM heap compaction
  const compactionTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  // 6. Initialize the local-first DB and CRDT doc on mount
  useEffect(() => {
    // 6a. Create the WASM DB; this allocates a bounded WASM heap
    const db = createWasmLocalDb({ maxHeapPages: 256 });
    dbRef.current = db;

    // 6b. Open or create the CRDT document for this docId
    const crdt = db.openCrdt(docId);
    crdtRef.current = crdt;

    // 6c. Subscribe to remote CRDT updates (retained listener!)
    const onRemote = (patch: Uint8Array) => {
      // Apply remote patch and trim local retained buffers
      crdt.apply(patch);
      crdt.trimHistory(1000); // keep only last 1000 ops in memory
    };
    crdt.subscribe(onRemote);

    // 6d. Start periodic compaction of WASM memory
    compactionTimer.current = setInterval(() => {
      // Ask WASM DB to run GC and shrink linear memory if possible
      db.compact();
      // Explicitly hint V8 to collect (no-op in most browsers, but safe)
      if (typeof globalThis.gc === "function") globalThis.gc();
    }, 30_000);

    // 6e. Cleanup function ensures no leaks on unmount
    return () => {
      if (eventRef.current) eventRef.current.close();
      if (compactionTimer.current) clearInterval(compactionTimer.current);
      crdt.unsubscribe(onRemote);
      crdt.drop(); // free CRDT state from WASM heap
      db.close(); // release WASM instance and memory
      dbRef.current = null;
      crdtRef.current = null;
    };
  }, [docId]);

  // 7. Stream model output via SSE and write deltas into CRDT
  const startStreaming = () => {
    // 7a. Open SSE connection to Next.js backend
    const es = new EventSource(`/api/stream?docId=${docId}`);
    eventRef.current = es;

    // 7b. Handle token events
    es.onmessage = (ev) => {
      const token: ModelToken = JSON.parse(ev.data);
      setStreamedText((prev) => prev + token.delta);

      // 7c. Append token to CRDT (bounded by trimHistory)
      crdtRef.current?.appendText(token.delta);

      // 7d. Close stream when done to free network + buffer memory
      if (token.done) {
        es.close();
        eventRef.current = null;
      }
    };
  };

  // 8. Manual "reset session" to reclaim all memory immediately
  const resetSession = () => {
    eventRef.current?.close();
    compactionTimer.current && clearInterval(compactionTimer.current);
    crdtRef.current?.unsubscribeAll();
    crdtRef.current?.drop();
    dbRef.current?.close();
    setStreamedText("");
  };

  return (
    <div>
      <button onClick={startStreaming}>Stream AI Draft</button>
      <button onClick={resetSession}>Reset (Reclaim Memory)</button>
      <textarea value={streamedText} readOnly />
    </div>
  );
};
