/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// CRDTOp and CRDTDoc and ColdStorage provided in exercise brief
interface CRDTOp {
  id: string;
  lamport: number;
  author: string;
  timestamp: number;
  payload: Uint8Array;
}

interface CRDTDoc {
  root: unknown;
  versionVector: Record<string, number>;
}

interface ColdStorage {
  append(ops: CRDTOp[]): Promise<void>;
  loadHistoricalRange(from: number, to: number): Promise<CRDTOp[]>;
}

interface CRDTWindowManager {
  ingest(operation: CRDTOp): void;
  evictBefore(timestamp: number): Promise<void>;
  getActiveState(): CRDTDoc;
  onEviction(callback: (evicted: CRDTOp[]) => void): () => void;
}

// Stub implementation notes:
// - ingest(): push op into hot WASM CRDT and buffer; if performance.memory.usedJSHeapSize
//   exceeds soft threshold, call evictBefore(Date.now() - N*60000).
// - evictBefore(): remove ops with timestamp < given from WASM doc, send to ColdStorage.append,
//   fire onEviction callbacks.
// - Vector clocks / Lamport timestamps: because every op carries lamport + author, remote peers
//   can still merge by comparing version vectors. Evicted ops are NOT discarded—they live in
//   ColdStorage, so a peer sending an old op triggers a loadHistoricalRange and re-ingest,
//   avoiding conflicts.
// - loadHistoricalRange is on ColdStorage, keeping WindowManager focused on hot state.

import React from 'react';

function useEvictionSubscription(manager: CRDTWindowManager) {
  const [heapPct, setHeapPct] = React.useState(0);
  React.useEffect(() => {
    const off = manager.onEviction(() => {
      const mem = (performance as any).memory;
      if (mem) setHeapPct(mem.usedJSHeapSize / mem.jsHeapSizeLimit);
    });
    return off;
  }, [manager]);
  return heapPct;
}

export function MemoryBadge({ manager }: { manager: CRDTWindowManager }) {
  const pct = useEvictionSubscription(manager);
  return (
    <div style={{ width: 100, background: '#eee' }}>
      <div style={{ width: `${pct * 100}%`, background: 'tomato' }}>&nbsp;</div>
    </div>
  );
}
