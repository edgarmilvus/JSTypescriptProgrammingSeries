/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface TelemetryRow {
  ts: number;
  sensor: string;
  value: Float64Array;
}

interface WASMDBHandle {
  importBatch(rows: TelemetryRow[]): Promise<void>;
  compact(): Promise<void>;
  trackHeap(): { used: number; capacity: number };
}

// Stub strategy for compact():
// 1. Write full DB snapshot to OPFS (e.g., /sqlite/snapshot.bin)
// 2. Call WASM export to destroy instance (free linear memory)
// 3. Reinit WASM with smaller initial heap flag
// 4. Load snapshot from OPFS into fresh instance
// NOTE: WeakRef/FinalizationRegistry cannot free WASM linear memory because it is
// not JS-owned; only host-level destroy()/reinit suffices.

import React from 'react';

export function useWASMHeapWatchdog(
  handle: WASMDBHandle,
  thresholdMB: number
) {
  React.useEffect(() => {
    let idleId: number;
    const check = () => {
      const { capacity } = handle.trackHeap();
      if (capacity / 1e6 > thresholdMB) {
        const ric = (window as any).requestIdleCallback;
        if (ric) idleId = ric(() => handle.compact());
      }
    };
    const t = setInterval(check, 5000);
    return () => {
      clearInterval(t);
      if (idleId) (window as any).cancelIdleCallback(idleId);
    };
  }, [handle, thresholdMB]);
}
