/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { useSyncExternalStore } from 'react';

type Props = {
  noteId: string;
  offline: boolean;
  streamEndpoint: string;
};

// Cleanup signature to be called on hide/unmount
export function cleanupNoteResources(noteId: string): void {
  // TODO: close EventSource, drop Yjs observers, free WASM buffers
}

export function CollaborativeNoteStream(props: Props) {
  // useSyncExternalStore avoids SSR mismatch by using server snapshot
  const crdtState = useSyncExternalStore(
    (cb) => subscribeNote(props.noteId, cb),
    () => getNoteSnapshot(props.noteId),
    () => getServerSnapshot(props.noteId) // hydration-safe
  );

  // Ghost text state (optimistic UI reconciliation point)
  const [ghost, setGhost] = React.useState('');

  React.useEffect(() => {
    if (props.offline) return; // no streaming offline
    const es = new EventSource(props.streamEndpoint);
    es.onmessage = (e) => setGhost((g) => g + e.data); // Reconciliation: merge stream into local
    return () => {
      es.close();
      cleanupNoteResources(props.noteId);
    };
  }, [props.noteId, props.offline, props.streamEndpoint]);

  React.useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === 'hidden') cleanupNoteResources(props.noteId);
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, [props.noteId]);

  return <div>{crdtState}{ghost && <span className="ghost">{ghost}</span>}</div>;
}

// Hydration: server renders crdtState only; ghost text empty until post-hydration
// effect attaches EventSource. Handlers attached after hydration prevent leaks.
