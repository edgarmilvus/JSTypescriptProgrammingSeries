/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

class SubscriptionRegistry {
  private map = new Map<string, () => void>();
  register(key: string, unsubscribe: () => void): void {
    // stub: store unsubscribe, overwrite if exists
  }
  release(key: string): void {
    // stub: call and delete
  }
  audit(): { active: string[]; leaked: string[] } {
    return { active: [], leaked: [] };
  }
}

// BoardView controller stub:
// const reg = new SubscriptionRegistry();
// on disconnect: reg.release(boardId);
// setInterval(() => { const a = reg.audit(); if (a.active.length) warn(a); }, 5000);

// FinalizationRegistry catches forgotten releases:
// const fin = new FinalizationRegistry((key) => reg.release(key));
// fin.register(componentObj, boardId);

import React from 'react';

export function BoardSwitcher({
  registry,
  boards,
}: {
  registry: SubscriptionRegistry;
  boards: string[];
}) {
  const [prev, setPrev] = React.useState(boards[0]);
  const [isPending, startTransition] = React.useTransition();
  const switchTo = (b: string) => {
    startTransition(() => {
      registry.release(prev); // cleanup old before paint
      setPrev(b);
    });
  };
  return <div>{boards.map((b) => <button onClick={() => switchTo(b)}>{b}</button>)}</div>;
}
