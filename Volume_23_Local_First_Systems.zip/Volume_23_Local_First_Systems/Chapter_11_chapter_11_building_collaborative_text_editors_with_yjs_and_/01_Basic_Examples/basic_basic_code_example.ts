/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Minimal Yjs collaborative text example for a local-first SaaS note app.
 * This simulates two clients (User A and User B) editing the same document
 * without a server, using Yjs CRDT primitives.
 */

// Import the core Yjs library
import * as Y from 'yjs';

/**
 * Represents a single client in our SaaS app (e.g., a browser tab).
 */
class NoteClient {
  /**
   * The Yjs document holding CRDT state for this client.
   */
  public doc: Y.Doc;

  /**
   * The shared text type mapped to the "note-content" key.
   * Y.Text is a CRDT string optimized for collaborative editing.
   */
  public text: Y.Text;

  /**
   * Human-readable client name for logging.
   */
  public clientName: string;

  /**
   * @param clientName - Identifier for the simulated user/client.
   */
  constructor(clientName: string) {
    // 1. Create a new Yjs document instance for this client
    this.doc = new Y.Doc();

    // 2. Obtain a Y.Text instance from the document's shared map
    this.text = this.doc.getText('note-content');

    // 3. Store the client name for debug output
    this.clientName = clientName;
  }

  /**
   * Inserts text at a given index in the shared note.
   * @param index - Position in the text where insertion occurs
   * @param content - The string to insert
   */
  insertText(index: number, content: string): void {
    // 4. Perform a CRDT-safe insert operation
    this.text.insert(index, content);
  }

  /**
   * Deletes text from a given index.
   * @param index - Start position of deletion
   * @param length - Number of characters to delete
   */
  deleteText(index: number, length: number): void {
    // 5. Perform a CRDT-safe delete operation
    this.text.delete(index, length);
  }

  /**
   * Returns the current plain-text value of the note.
   * @returns The merged string content from the CRDT
   */
  getContent(): string {
    // 6. Read the current state of the Y.Text as a normal string
    return this.text.toString();
  }
}

/**
 * Simulates a SaaS backend sync layer by manually copying
 * updates from one doc to another (in real apps this is a provider).
 * @param from - Source Y.Doc
 * @param to - Target Y.Doc
 */
function syncDocs(from: Y.Doc, to: Y.Doc): void {
  // 7. Encode the entire state of the source doc as a binary update
  const update = Y.encodeStateAsUpdate(from);

  // 8. Apply the binary update to the target doc (CRDT merge)
  Y.applyUpdate(to, update);
}

// === Demo Execution (Simulating two SaaS users) ===

// 9. Create two clients representing User A and User B
const userA = new NoteClient('UserA');
const userB = new NoteClient('UserB');

// 10. User A types the first sentence of a note
userA.insertText(0, 'Hello World');

// 11. Sync User A's changes to User B (simulated network push)
syncDocs(userA.doc, userB.doc);

// 12. User B appends a collaborative reply
userB.insertText(userB.getContent().length, ' from B!');

// 13. Sync User B's changes back to User A
syncDocs(userB.doc, userA.doc);

// 14. Output the final merged note content for both clients
console.log(`${userA.clientName} sees: ${userA.getContent()}`);
console.log(`${userB.clientName} sees: ${userB.getContent()}`);
