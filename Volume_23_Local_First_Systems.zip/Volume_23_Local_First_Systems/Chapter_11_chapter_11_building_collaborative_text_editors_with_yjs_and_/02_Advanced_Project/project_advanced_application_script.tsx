/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/collab/streamAction.tsx
import { createStreamableUI, createStreamableValue } from "ai/rsc";
import { YDoc } from "yjs";
import { WebsocketProvider } from "y-websocket";
import React from "react";

/**
 * Generic streaming helper that binds a CRDT text type to a streamable UI.
 * @template T - The CRDT container type (e.g., Y.Text)
 * @param doc - The shared Yjs document instance
 * @param roomName - Collaboration room identifier
 */
function useCollabStream<T extends { insert: (pos: number, text: string) => void }>(
  doc: YDoc,
  roomName: string
) {
  // 1. Establish real-time sync provider for local-first behavior
  const provider = new WebsocketProvider("wss://collab.saas.app", roomName, doc);

  // 2. Obtain the shared text type from the document root
  const yText = doc.getText("editor") as unknown as T;

  return { provider, yText };
}

/**
 * Server Action: streams AI tokens + interactive component into Yjs doc.
 * Demonstrates streamable-ui + CRDT integration in a SaaS editor context.
 */
export async function streamAIIntoEditor(roomId: string) {
  // 3. Create streamable text value for token-by-token output
  const streamableText = createStreamableValue<string>();

  // 4. Create streamable UI for injecting React components mid-stream
  const streamableUI = createStreamableUI(
    <div className="loading">Generating…</div>
  );

  // 5. Simulate background AI generation (e.g., via LLM)
  (async () => {
    const tokens = ["Draft", " ", "summary", ":", " ", "Q3", " ", "growth"];
    for (const tok of tokens) {
      // 6. Push token to client stream (renders live in editor)
      streamableText.update(tok);

      // 7. Mirror token into CRDT for offline-ready persistence
      // (Client would normally do this; shown here for architecture clarity)
      // yText.insert(yText.length, tok);
      await new Promise((r) => setTimeout(r, 50));
    }

    // 8. Stream a structured interactive approval component
    streamableUI.update(
      <ApprovalCard
        onApprove={async () => {
          // 9. Commit approved text to Yjs on client approval
          streamableUI.done(<div>Approved ✅</div>);
        }}
      />
    );

    streamableText.done();
    streamableUI.done();
  })();

  return {
    text: streamableText.value,
    ui: streamableUI.value,
  };
}

/** Interactive component streamed via streamable-ui */
function ApprovalCard({ onApprove }: { onApprove: () => void }) {
  return (
    <div className="approval">
      <span>Accept AI draft?</span>
      <button onClick={onApprove}>Approve</button>
    </div>
  );
}
