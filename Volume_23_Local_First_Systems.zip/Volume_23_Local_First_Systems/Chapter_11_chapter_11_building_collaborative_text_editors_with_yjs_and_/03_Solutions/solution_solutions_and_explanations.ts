/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';

type DocMeta = {
  title: string;
  revision: number | Y.Text; // Extended: legacy docs may use Y.Text
  locked: boolean;
};

// Type Guard for DocMeta
function isDocMeta(value: unknown): value is DocMeta {
  if (typeof value !== 'object' || value === null) return false;
  const v = value as Record<string, unknown>;
  if (typeof v['title'] !== 'string') return false;
  // revision: number (>=0) OR Y.Text instance
  if (typeof v['revision'] === 'number') {
    if (v['revision'] < 0) return false;
  } else if (!(v['revision'] instanceof Y.Text)) {
    return false;
  }
  if (typeof v['locked'] !== 'boolean') return false;
  return true;
}

// Extract with null fallback
function extractDocMeta(map: Y.Map<unknown>): DocMeta | null {
  const title = map.get('title');
  const revision = map.get('revision');
  const locked = map.get('locked');
  const candidate = { title, revision, locked };
  // Y.Map<unknown> is safer than Y.Map<any> because unknown forces explicit
  // narrowing; any would silence mismatches when older peers write incompatible
  // shapes (e.g., deleted key -> undefined), preventing silent corruption.
  if (isDocMeta(candidate)) return candidate;
  return null;
}

// Merge note: Yjs concurrent title set (string) vs delete (key removed) means
// get() may return undefined; narrowing must account for undefined to avoid
// assuming presence. Yjs last-writer per-key wins for map entries.
