/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// LoroSyncService interface
interface LoroSyncService {
  open(localId: string): Promise<void>;
  editText(container: string, pos: number, insert: string): void;
  exportLocalUpdates(): Uint8Array;
  mergeRemote(update: Uint8Array): void;
}

// PersistenceAdapter (type-only)
interface PersistenceAdapter {
  save(snapshot: Uint8Array): Promise<void>;
  load(): Promise<Uint8Array | null>;
}

// Loro WASM differs from pure-JS CRDT: memory owned in WASM heap, so Uint8Array
// (binary) avoids JSON parse overhead and preserves op encoding.
// Conflict: A inserts "hello"@0, B inserts "world"@0 offline. Loro uses tree/
// fractional indexing -> deterministic order (e.g., by actor id tie-break).
// JSON.stringify loses concurrent ops; Loro version vectors enable partial merge.
