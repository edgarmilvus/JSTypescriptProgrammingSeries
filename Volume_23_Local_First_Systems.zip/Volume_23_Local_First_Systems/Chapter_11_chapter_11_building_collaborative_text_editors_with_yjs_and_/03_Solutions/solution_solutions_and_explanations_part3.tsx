/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';
import { useSyncExternalStore } from 'react';

type Collaborator = {
  clientId: number;
  name: string;
  color: string;
  line: number | null;
};

export function CollaboratorPresence({ doc }: { doc: Y.Doc }): JSX.Element {
  const awareness = new Y.Awareness(doc);
  // awareness state is ephemeral, not in Y.Text/Y.Map.
  // setLocalStateField('user', { name, color, line }) on cursor move.
  // useSyncExternalStore to subscribe; throttled via rAF or 50ms debounce.
  return <div />;
}
// Trace: C1 {Ada,3}, C2 {Linus,5}; C1 closes -> C2 gets null for Ada, removes.
