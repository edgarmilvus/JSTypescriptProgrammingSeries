/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal local-first shared canvas example for a SaaS visual editor.
 * This code models a canvas as a map of shape IDs to shape objects.
 * It uses a simplified CRDT-style last-writer-wins register per shape
 * to demonstrate offline edits and merge behavior.
 */

// ---------------------------------------------------------------------------
// Type Definitions
// ---------------------------------------------------------------------------

/** Represents a single shape on the collaborative canvas. */
interface CanvasShape {
  id: string;
  x: number;
  y: number;
  color: string;
  /** Lamport-style logical clock for CRDT ordering. */
  version: number;
  /** Identity of the device/user that produced this version. */
  actor: string;
}

/** The full canvas state modeled as a CRDT map of shapes. */
interface CanvasState {
  shapes: Map<string, CanvasShape>;
}

// ---------------------------------------------------------------------------
// Local-First Canvas Store (Simulated WASM DB Layer)
// ---------------------------------------------------------------------------

/**
 * Simulates a WASM-powered local database that persists canvas state.
 * In production this would be a WASM SQLite or IndexedDB wrapper.
 */
class LocalCanvasDB {
  private state: CanvasState = { shapes: new Map() };

  /** Persist the current canvas state locally (no network needed). */
  save(state: CanvasState): void {
    // In a real WASM DB, this would serialize to a binary page.
    this.state = structuredClone(state);
  }

  /** Load the persisted canvas state for offline rendering. */
  load(): CanvasState {
    return structuredClone(this.state);
  }
}

// ---------------------------------------------------------------------------
// CRDT Merge Logic
// ---------------------------------------------------------------------------

/**
 * Merges two canvas states using a last-writer-wins strategy per shape.
 * This is the core of local-first concurrency resolution.
 */
function mergeCanvasState(
  local: CanvasState,
  remote: CanvasState
): CanvasState {
  const merged: CanvasState = { shapes: new Map(local.shapes) };

  for (const [id, remoteShape] of remote.shapes) {
    const localShape = merged.shapes.get(id);
    if (!localShape || remoteShape.version > localShape.version) {
      merged.shapes.set(id, remoteShape);
    }
  }

  return merged;
}

// ---------------------------------------------------------------------------
// SaaS App Context: Collaborative Canvas Service
// ---------------------------------------------------------------------------

/**
 * High-level service used by the SaaS frontend to manage canvas edits.
 */
class CollaborativeCanvas {
  private db = new LocalCanvasDB();
  private state: CanvasState;

  constructor(initial?: CanvasState) {
    this.state = initial ?? { shapes: new Map() };
    this.db.save(this.state);
  }

  /**
   * Applies a local edit to a shape and persists it immediately.
   * This keeps the UI responsive while offline.
   */
  editShape(shapeId: string, patch: Partial<CanvasShape>, actor: string): void {
    const existing = this.state.shapes.get(shapeId);
    const nextVersion = (existing?.version ?? 0) + 1;
    const updated: CanvasShape = {
      id: shapeId,
      x: patch.x ?? existing?.x ?? 0,
      y: patch.y ?? existing?.y ?? 0,
      color: patch.color ?? existing?.color ?? '#000',
      version: nextVersion,
      actor,
    };
    this.state.shapes.set(shapeId, updated);
    this.db.save(this.state);
  }

  /**
   * Simulates receiving a remote update from another user after reconnect.
   */
  syncFromRemote(remote: CanvasState): void {
    const loaded = this.db.load();
    const merged = mergeCanvasState(loaded, remote);
    this.state = merged;
    this.db.save(this.state);
  }

  getShapes(): CanvasShape[] {
    return Array.from(this.state.shapes.values());
  }
}

// ---------------------------------------------------------------------------
// Demo Execution (Hello World Level)
// ---------------------------------------------------------------------------

// Create a canvas for User A on Device 1
const canvasA = new CollaborativeCanvas();
canvasA.editShape('rect1', { x: 10, y: 20, color: 'blue' }, 'userA');

// User A goes offline and edits again
canvasA.editShape('rect1', { x: 15, y: 25, color: 'blue' }, 'userA');

// Meanwhile, User B on Device 2 edits the same shape via cloud
const canvasB = new CollaborativeCanvas();
canvasB.editShape('rect1', { x: 12, y: 30, color: 'red' }, 'userB');

// User A reconnects and syncs
canvasA.syncFromRemote(canvasB.getShapes().length
  ? { shapes: new Map(canvasB.getShapes().map(s => [s.id, s])) }
  : { shapes: new Map() });

console.log('Merged Canvas State:', canvasA.getShapes());
