/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/collab-canvas/AdvancedCanvasAgent.tsx

import React, { useEffect, useRef } from "react";
// LangGraph JS core (conceptual import; in real SaaS you'd use @langchain/langgraph)
import { StateGraph, END, START } from "@langchain/langgraph";
// WASM module compiled with thread support + SharedArrayBuffer
import initWasm, { CanvasInferencePool } from "@/wasm/canvas_infer";

/**
 * JSDoc: SharedCanvasState
 * Represents the mutable graph state shared across LangGraph nodes.
 * In a local-first app this mirrors a CRDT document subset.
 */
interface SharedCanvasState {
  /** Array of user drawing events not yet annotated */
  pendingStrokes: { id: string; points: number[] }[];
  /** Inference results to be merged into canvas */
  annotations: { strokeId: string; label: string; confidence: number }[];
  /** Flag indicating offline queue status */
  isOffline: boolean;
}

/**
 * JSDoc: useSharedArrayBuffer
 * Creates a SharedArrayBuffer for WASM threads to read stroke data
 * without copying between main thread and workers.
 */
function useSharedArrayBuffer(size: number): SharedArrayBuffer {
  // SAB requires COOP/COEP headers in Next.js (see next.config.js)
  const sab = new SharedArrayBuffer(size);
  return sab;
}

/**
 * JSDoc: CanvasAgentComponent
 * Next.js client component orchestrating StateGraph + WASM threads.
 */
export default function CanvasAgentComponent() {
  const sabRef = useRef<SharedArrayBuffer>();

  useEffect(() => {
    // 1. Allocate shared memory for 1MB of stroke coordinates
    sabRef.current = useSharedArrayBuffer(1024 * 1024);

    // 2. Initialize WASM with thread support (uses Web Workers internally)
    initWasm().then((_) => {
      const pool = new CanvasInferencePool(sabRef.current!);
      runAgent(pool);
    });
  }, []);

  /**
   * JSDoc: runAgent
   * Builds and compiles a LangGraph StateGraph to route canvas tasks.
   */
  async function runAgent(pool: CanvasInferencePool) {
    // 3. Define the initial state for the graph
    const initialState: SharedCanvasState = {
      pendingStrokes: [{ id: "s1", points: [10, 20, 30, 40] }],
      annotations: [],
      isOffline: navigator.onLine === false,
    };

    // 4. Node: Prepare strokes into SharedArrayBuffer
    const prepareNode = (state: SharedCanvasState) => {
      const view = new Float32Array(sabRef.current!);
      state.pendingStrokes.forEach((s, i) => {
        s.points.forEach((p, j) => (view[i * 4 + j] = p));
      });
      return state;
    };

    // 5. Node: Run WASM threads for inference
    const inferNode = async (state: SharedCanvasState) => {
      // WASM spawns Web Workers sharing SAB
      const results = await pool.runInference(state.pendingStrokes.length);
      state.annotations = results;
      return state;
    };

    // 6. Node: Sync to CRDT (mocked)
    const syncNode = (state: SharedCanvasState) => {
      // In real app: Y.CanvasDoc.transact(() => { ... })
      console.log("Synced annotations", state.annotations);
      return state;
    };

    // 7. Construct StateGraph with nodes
    const graph = new StateGraph<SharedCanvasState>({ channels: [] })
      .addNode("prepare", prepareNode)
      .addNode("infer", inferNode)
      .addNode("sync", syncNode)
      .addEdge(START, "prepare")
      .addEdge("prepare", "infer")
      .addEdge("infer", "sync")
      .addEdge("sync", END);

    // 8. Compile and invoke
    const app = graph.compile();
    await app.invoke(initialState);
  }

  return <canvas id="collab-canvas" width={800} height={600} />;
}
