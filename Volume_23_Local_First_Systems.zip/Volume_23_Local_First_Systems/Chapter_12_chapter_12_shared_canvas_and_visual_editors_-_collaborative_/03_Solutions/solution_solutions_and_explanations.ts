/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';

// Base interface for all canvas objects
interface CanvasObject {
  id: string;
  type: 'rectangle' | 'ellipse' | 'freehand';
  // Position is stored as a Y.Map to allow concurrent x/y edits
  position: Y.Map<number>;
  color: Y.Text; // using Y.Text allows concurrent color string edits
  zIndex: number;
  createdAtLamport: number;
}

// CRDT map from object id -> CanvasObject (nested Y.Map per object)
interface CRDTShapeMap {
  // key: object id, value: Y.Map representing the object's CRDT fields
  shapes: Y.Map<Y.Map<unknown>>;
}

// Tombstone set: grow-only, never removes ids (prevents resurrection)
interface TombstoneSet {
  deleted: Y.Set<string>; // GSet semantics: add-only
}

// Full canvas document
interface CanvasDocument {
  shapes: CRDTShapeMap['shapes'];
  tombstones: TombstoneSet['deleted'];
  // viewport transform could also be a Y.Map for concurrent pan/zoom
}

/**
 * WHY Y.Map PREVENTS LOST UPDATES:
 * If User A drags rect to (10,10) and User B drags same rect to (20,5) offline,
 * each edits the nested Y.Map's 'position' key. On merge, Yjs keeps both as a
 * map of primitive values; last writer per-key wins but position is a map so
 * x and y can be independently merged without clobbering the other user's drag axis.
 */

/**
 * MERGE SEMANTICS (A moves X to (10,10) offline, B recolors X red offline):
 * Canonical merged state: X.position = (10,10) from A, X.color = 'red' from B.
 * Because position and color are separate CRDT nodes, both intentions are preserved.
 * No data loss: this is the essence of commutative replication.
 */

/**
 * WHY PLAIN BOOLEAN deleted FAILS:
 * A deletes (deleted=true), B edits color offline. On merge, LWW may keep
 * deleted=false and resurrect the object. GSet tombstone ensures once deleted,
 * id stays in set forever; render layer hides it regardless of other edits.
 */
