/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// Pseudo-code: conflict resolution callback
// CRDT ensures S1 and S2 are independent objects (no split).
// Z-order: by createdAtLamport (higher = newer on top). User priority fallback.
// Merge tool: union paths into S3 with new id, add S1/S2 to tombstone set (GSet).
// Idempotent: re-applying same union patch yields same S3, tombstones ignore dupes.

// If both erase segment of other's stroke pre-sync:
// Each erase is a tombstone sub-path in CRDT; merge keeps both erasures.
// Strokes remain but with holes; no resurrection.

type ConflictResolutionProps = {
  onConflictResolve: (
    local: CanvasObject,
    remote: CanvasObject
  ) => { action: 'z-order' | 'merge'; by: 'lamport' | 'priority' };
};
