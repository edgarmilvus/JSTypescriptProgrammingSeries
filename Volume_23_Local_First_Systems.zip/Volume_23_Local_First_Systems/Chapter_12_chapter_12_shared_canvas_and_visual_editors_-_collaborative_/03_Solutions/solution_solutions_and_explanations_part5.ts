/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';

// LangGraph-compatible state
interface CanvasAgentState {
  nodes: { doc: Uint8Array; suggestions: Y.Doc[] };
  // Server action returns Y.Update (CRDT patch), not coords
}

/**
 * SERVER ACTION RETURNS PATCH:
 * Instead of {x:10,y:10}, returns Y.encodeStateAsUpdate(diffDoc).
 * Client applies via Y.applyUpdate(localDoc, patch) — offline safe.
 */

/**
 * WASM THREADS IRRELEVANT SERVER-SIDE:
 * Server runs Node, no UI thread bottleneck. Client needs WASM threads
 * to apply patch + rebuild spatial index without dropping frames.
 */
