/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Local-First Identity & Permission "Hello World"
 * Context: A SaaS task-management web app (e.g., offline-capable Trello clone)
 * Stack: TypeScript, in-memory WASM-style store (simulated), CRDT-like permission log
 */

/**
 * Represents a user-owned identity.
 * In production, the private key never leaves the device.
 */
interface LocalUser {
  userId: string;
  publicKey: string;
  displayName: string;}

/**
 * Workspace role in a shared SaaS board.
 */
type WorkspaceRole = 'owner' | 'editor' | 'viewer';

/**
 * A permission entry replicated via CRDT semantics.
 * Each entry is append-only and merges by latest timestamp.
 */
interface PermissionEntry {
  userId: string;
  workspaceId: string;
  role: WorkspaceRole;
  updatedAt: number;
  actorId: string; // who granted this
}

/**
 * Simulated local-first datastore (WASM DB stand-in).
 * Persists to memory; in reality this is a WASM SQLite / IndexedDB hybrid.
 */
class LocalFirstStore {
  private users = new Map<string, LocalUser>();
  private permissions: PermissionEntry[] = [];

  /** Create a user-owned identity on the device */
  createUser(userId: string, displayName: string): LocalUser {
    const user: LocalUser = {
      userId,
      publicKey: `pk_${userId}`, // simulated key
      displayName,
    };
    this.users.set(userId, user);
    return user;
  }

  /** Offline-safe role assignment (CRDT append) */
  assignRole(entry: PermissionEntry): void {
    this.permissions.push(entry);
  }

  /** Read effective role (last-write-wins by timestamp) */
  getRole(userId: string, workspaceId: string): WorkspaceRole | null {
    const entries = this.permissions
      .filter(p => p.userId === userId && p.workspaceId === workspaceId)
      .sort((a, b) => b.updatedAt - a.updatedAt);
    return entries.length ? entries[0].role : null;
  }
}

// --- SaaS App Bootstrap ---
const store = new LocalFirstStore();

// 1. User opens app on laptop without Wi-Fi
const alice = store.createUser('u_alice', 'Alice');

// 2. Alice creates a workspace and grants herself owner
store.assignRole({
  userId: alice.userId,
  workspaceId: 'ws_tasks',
  role: 'owner',
  updatedAt: Date.now(),
  actorId: alice.userId,
});

// 3. Later, offline, she invites Bob as editor
store.createUser('u_bob', 'Bob');
store.assignRole({
  userId: 'u_bob',
  workspaceId: 'ws_tasks',
  role: 'editor',
  updatedAt: Date.now(),
  actorId: alice.userId,
});

// 4. UI checks permission locally
const bobRole = store.getRole('u_bob', 'ws_tasks');
console.log(`Bob's role: ${bobRole}`); // "editor"
