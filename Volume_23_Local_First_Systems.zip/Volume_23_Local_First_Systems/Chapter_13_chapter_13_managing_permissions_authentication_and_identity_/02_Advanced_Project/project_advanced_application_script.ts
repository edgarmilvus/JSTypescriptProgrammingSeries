/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/local-first-auth.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { WebAuthnCredential } from "@/lib/auth/webauthn";
import { PermissionCRDT } from "@/lib/crdt/permission";
import { ServiceWorkerCache } from "@/lib/ai/swCache";

/**
 * Local-first SaaS auth and permission bootstrap endpoint.
 * This runs in a Next.js API route but is designed to be callable
 * from an offline-capable client after initial sync.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 1. Validate request shape for local-first login
  // We expect a raw WebAuthn assertion from the client.
  const { assertion, workspaceId } = req.body as {
    assertion: ArrayBuffer;
    workspaceId: string;
  };

  // 2. Verify user-owned credential without central trust
  // The credential is self-custodied; we check against local public key.
  const credential = new WebAuthnCredential();
  const userId = await credential.verify(assertion);
  if (!userId) {
    return res.status(401).json({ error: "Invalid local credential" });
  }

  // 3. Load CRDT permission set for the requested workspace
  // This CRDT is synced peer-to-peer and conflict-free.
  const perms = new PermissionCRDT(workspaceId);
  await perms.loadFromWasmStore();

  // 4. Check if user has at least 'viewer' role offline
  // Authorization is granular and sync-safe.
  const role = perms.getRole(userId);
  if (!role) {
    return res.status(403).json({ error: "No workspace access" });
  }

  // 5. Ensure AI model assets are cached via Service Worker
  // Avoids cold start on subsequent offline visits.
  const swCache = new ServiceWorkerCache();
  await swCache.registerAndCacheModel("task-summarizer.onnx");

  // 6. Return minimal identity token (non-central)
  // Token is signed locally and verified by peers.
  const token = await credential.issueLocalToken(userId, role);
  res.status(200).json({ token, role, cached: true });
}
