/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// components/WorkspaceGate.tsx
import { useEffect, useState } from "react";
import { PermissionCRDT } from "@/lib/crdt/permission";

/**
 * React component that gates UI based on local-first roles.
 */
export function WorkspaceGate({ workspaceId }: { workspaceId: string }) {
  const [role, setRole] = useState<string | null>(null);

  // 1. On mount, load CRDT and read local role
  useEffect(() => {
    const perms = new PermissionCRDT(workspaceId);
    perms.loadFromWasmStore().then(() => {
      setRole(perms.getRole("local-user-id"));
    });
  }, [workspaceId]);

  // 2. Render based on sync-safe authorization
  if (role === "admin") return <AdminPanel />;
  if (role === "viewer") return <ReadOnlyBoard />;
  return <p>Access denied on this device.</p>;
}
