/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// lib/crdt/permission.ts
import { WasmKV } from "@/lib/wasm/kv";

/**
 * Conflict-free permission set for local-first workspaces.
 */
export class PermissionCRDT {
  private store: WasmKV;
  private workspace: string;

  constructor(workspaceId: string) {
    this.workspace = workspaceId;
    this.store = new WasmKV("perms.db");
  }

  /** Load CRDT state from WASM-backed IndexedDB */
  async loadFromWasmStore() {
    await this.store.open();
  }

  /** Add or update a role (idempotent, commutative) */
  async grant(userId: string, role: string, ts: number) {
    await this.store.put(`${this.workspace}:${userId}`, { role, ts });
  }

  /** Resolve current role using max timestamp */
  getRole(userId: string): string | null {
    const rec = this.store.get(`${this.workspace}:${userId}`);
    return rec ? rec.role : null;
  }
}
