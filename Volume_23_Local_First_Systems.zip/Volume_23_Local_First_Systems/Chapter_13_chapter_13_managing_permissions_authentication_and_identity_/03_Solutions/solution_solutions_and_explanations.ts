/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Minimal type definitions and pseudo-implementations for local-first auth
import { generateKeyPair, sign, verify } from 'wasm-crypto-ed25519';
import { argon2id } from 'wasm-argon2';
import { Database } from 'wasm-sqlite';

// 1. LocalIdentity interface
export interface LocalIdentity {
  userId: string; // hash of public key
  publicKey: Uint8Array;
  encryptedPrivateKey: Uint8Array;
  createdAt: number; // CRDT timestamp (logical or wall-clock hybrid)
}

// 2. Create identity
export async function createLocalIdentity(passphrase: string): Promise<LocalIdentity> {
  const { publicKey, privateKey } = await generateKeyPair();
  const userId = await hashPublicKey(publicKey);
  const encryptedPrivateKey = await argon2idEncrypt(privateKey, passphrase);
  const identity: LocalIdentity = {
    userId,
    publicKey,
    encryptedPrivateKey,
    createdAt: Date.now(),
  };
  const db = await Database.open('local.db');
  await db.run(
    'INSERT INTO identities (userId, publicKey, encryptedPrivateKey, createdAt) VALUES (?, ?, ?, ?)',
    [userId, publicKey, encryptedPrivateKey, identity.createdAt]
  );
  return identity;
}

// 3. CRDT for revocation (LWW-Map keyed by userId)
export class CredentialRevocationSet {
  private map: Map<string, { revoked: boolean; ts: number }> = new Map();
  markRevoked(userId: string, ts: number) {
    const existing = this.map.get(userId);
    if (!existing || ts > existing.ts) this.map.set(userId, { revoked: true, ts });
  }
  merge(other: CredentialRevocationSet) {
    for (const [userId, rec] of other.map) {
      const existing = this.map.get(userId);
      if (!existing || rec.ts > existing.ts) this.map.set(userId, rec);
    }
  }
  isRevoked(userId: string): boolean {
    return this.map.get(userId)?.revoked ?? false;
  }
}

// 4. Verify assertion
export function verifyLocalAssertion(assertion: Uint8Array, publicKey: Uint8Array): boolean {
  // assertion = challenge + signature; verify with Ed25519
  return verify(assertion, publicKey);
}

// 5. New device join: explained in comments
// A new device must be introduced by an existing trusted device via out-of-band sharing
// of a signed invitation. The invitation adds the device's userId to the trusted set
// in the revocation CRDT (with revoked=false). Only then can it write to revocation CRDT.

// 6. UIState integration notes:
// Using Vercel AI SDK UIState, we can render:
// - "authenticated but unverified by peers": local key unlock succeeded, but peer signatures missing
// - "fully trusted": CRDT shows device in trusted set and not revoked
// Example: uiState.push({ type: 'authStatus', status: 'unverified' })
