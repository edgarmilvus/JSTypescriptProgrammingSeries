/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type Role = 'admin' | 'editor' | 'viewer';
interface HLC { time: number; counter: number; }
interface MemberPermission {
  userId: string;
  role: Role;
  updatedAt: HLC;
  tombstone: boolean;
}

const ROLE_RANK: Record<Role, number> = { viewer: 1, editor: 2, admin: 3 };

export class WorkspacePermissions {
  private members: Map<string, MemberPermission> = new Map();

  assignRole(userId: string, role: Role, actorId: string) {
    const hlc = getHLC();
    this.members.set(userId, { userId, role, updatedAt: hlc, tombstone: false });
  }

  revokeMember(userId: string, actorId: string) {
    const hlc = getHLC();
    this.members.set(userId, { userId, role: 'viewer', updatedAt: hlc, tombstone: true });
  }

  merge(other: WorkspacePermissions) {
    for (const [userId, remote] of other.members) {
      const local = this.members.get(userId);
      if (!local) { this.members.set(userId, remote); continue; }
      // Tombstones win
      if (remote.tombstone && !local.tombstone) { this.members.set(userId, remote); continue; }
      if (!remote.tombstone && local.tombstone) continue;
      // Both live or both tomb: higher HLC wins, tie-break by role rank
      if (remote.updatedAt.time > local.updatedAt.time ||
         (remote.updatedAt.time === local.updatedAt.time && remote.updatedAt.counter > local.updatedAt.counter) ||
         (remote.updatedAt.time === local.updatedAt.time && remote.updatedAt.counter === local.updatedAt.counter && ROLE_RANK[remote.role] > ROLE_RANK[local.role])) {
        this.members.set(userId, remote);
      }
    }
  }

  canPerformAction(userId: string, action: 'write' | 'manage' | 'read'): boolean {
    const m = this.members.get(userId);
    if (!m || m.tombstone) return false;
    if (action === 'read') return true;
    if (action === 'write') return m.role === 'editor' || m.role === 'admin';
    if (action === 'manage') return m.role === 'admin';
    return false;
  }
}

// Simulation: two offline nodes
const nodeA = new WorkspacePermissions(); nodeA.assignRole('c', 'editor', 'a');
const nodeB = new WorkspacePermissions(); nodeB.assignRole('c', 'admin', 'b');
nodeA.merge(nodeB); // admin wins by rank on equal HLC assumption or later time

// UIState: React hides admin panel if !canPerformAction(localUser, 'manage')
