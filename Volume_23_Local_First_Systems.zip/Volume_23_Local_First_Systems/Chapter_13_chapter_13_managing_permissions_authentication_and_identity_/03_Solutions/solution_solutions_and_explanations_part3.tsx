/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { UIState } from 'ai';
import { useEffect, useState } from 'react';

type Role = 'admin' | 'editor' | 'viewer';
interface MemberRow { userId: string; role: Role; optimistic?: boolean; }

function useOptimisticPermissions(workspaceId: string) {
  const [optimisticState, setOpt] = useState<MemberRow[]>([]);
  const [confirmedState, setConf] = useState<MemberRow[]>([]);
  const reconcile = () => {
    setOpt(prev => prev.map(o => {
      const c = confirmedState.find(x => x.userId === o.userId);
      if (c && c.role !== o.role) return { ...o, optimistic: true };
      if (c?.optimistic === undefined && !confirmedState.find(x => x.userId === o.userId)) setTimeout(() => setOpt(p => p.filter(x => x.userId !== o.userId)), 500);
      return o;
    }));
  };
  return { optimisticState, confirmedState, reconcile };
}

export function PermissionBoard({ workspaceId }: { workspaceId: string }) {
  const { optimisticState, confirmedState, reconcile } = useOptimisticPermissions(workspaceId);
  const [uiState, setUiState] = useState<UIState>([]);

  useEffect(() => {
    // listen to WASM CRDT merge events
    wasmDb.onMerge(() => { setConf(getConfirmedFromDb()); reconcile(); });
  }, []);

  // UIState streams MemberCard nodes
  uiState.push({ type: 'memberList', rows: optimisticState.map(m => ({ userId: m.userId, role: m.role, badge: m.optimistic ? 'syncing' : 'ok' })) });

  // Secure: hide admin controls if local user lacks permission
  const localCanManage = canPerformAction(localUserId, 'manage');
  return (
    <div>
      {optimisticState.map(m => <MemberCard key={m.userId} row={m} />)}
      {localCanManage && <AdminPanel />}
      {/* Untrusted devices: if device not in trusted set, render locked overlay */}
    </div>
  );
}
