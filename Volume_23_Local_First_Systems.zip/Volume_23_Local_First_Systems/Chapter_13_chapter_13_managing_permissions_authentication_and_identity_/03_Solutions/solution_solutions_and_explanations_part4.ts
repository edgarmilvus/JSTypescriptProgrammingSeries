/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface CapabilityToken {
  deviceId: string;
  workspaceId: string;
  scope: { folderId: string; level: 'read' | 'none' }[];
  expiresAt: number;
  signature: Uint8Array;
}

class DeviceRevocationMap {
  private revoked: Map<string, number> = new Map(); // deviceId -> HLC ts
  mark(deviceId: string, ts: number) { if (!this.revoked.has(deviceId) || ts > this.revoked.get(deviceId)!) this.revoked.set(deviceId, ts); }
  merge(o: DeviceRevocationMap) { for (const [d, t] of o.revoked) this.mark(d, t); }
}

export function issueCapability(adminId: string, devicePubKey: Uint8Array): CapabilityToken {
  const token: CapabilityToken = {
    deviceId: hash(devicePubKey),
    workspaceId: 'ws1',
    scope: [{ folderId: 'f1', level: 'read' }],
    expiresAt: Date.now() + 3600_000,
    signature: sign(structure(token), adminPrivateKey),
  };
  wasmDb.run('INSERT INTO capabilities VALUES (?)', [token]);
  return token;
}

export function isDeviceRevoked(deviceId: string): boolean {
  return deviceRevocationMap.isRevoked(deviceId);
}

// UIState: show "limited session" banner when capability active and not revoked
// Reconciliation: if capability revoked mid-edit, optimistic UI shows error and drops edits after merge
