/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

type Role = 'admin' | 'editor' | 'viewer';
interface FieldKey { fieldId: string; encryptedKey: Uint8Array; roleBinding: Role; }

export function getDecryptionKey(fieldId: string, userId: string): Uint8Array | null {
  const role = workspacePermissions.getRole(userId); // from CRDT
  const fk = wasmDb.getFieldKey(fieldId) as FieldKey;
  if (!fk || ROLE_RANK[fk.roleBinding] > ROLE_RANK[role]) return null;
  return decrypt(fk.encryptedKey, userKey);
}

export function rotateFieldKeys(workspaceId: string) {
  const members = workspacePermissions.all();
  for (const fk of wasmDb.allFieldKeys()) {
    const newRole = leastPrivilegeRole(members);
    fk.encryptedKey = reEncrypt(fk.fieldId, newRole);
    fk.roleBinding = newRole;
    wasmDb.updateFieldKey(fk);
  }
}

// UIState shows <LockedField> when getDecryptionKey returns null
// Reconciliation: if field was editable optimistically but confirmed role locks it, UI swaps to locked after merge
