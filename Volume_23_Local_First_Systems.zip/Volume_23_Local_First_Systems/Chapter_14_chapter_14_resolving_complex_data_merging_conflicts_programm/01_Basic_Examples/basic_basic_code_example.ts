/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// @ts-ignore
import { TaskCRDT } from "@localfirst/crdt";

/**
 * Represents a single task in our SaaS project management tool.
 */
interface Task {
  id: string;
  title: string;
  updatedAt: number;
}

/**
 * Simulates a local-first WASM-backed database read.
 * In a real app, this would call into a WASM module.
 */
async function getLocalTask(taskId: string): Promise<Task> {
  // Mock local state (e.g., from IndexedDB via WASM)
  return {
    id: taskId,
    title: "Offline Draft",
    updatedAt: 1000,
  };
}

/**
 * Simulates a remote CRDT state pull from another collaborator.
 */
async function getRemoteTask(taskId: string): Promise<Task> {
  return {
    id: taskId,
    title: "Remote Update",
    updatedAt: 1200,
  };
}

/**
 * Basic merge resolver using Last-Write-Wins based on timestamp.
 * @param local Local task state
 * @param remote Remote task state
 * @returns Resolved task
 */
function resolveConflict(local: Task, remote: Task): Task {
  // Compare timestamps to decide which write wins
  if (local.updatedAt >= remote.updatedAt) {
    return local;
  }
  return remote;
}

/**
 * Main function demonstrating the merge flow.
 */
async function syncTask(taskId: string): Promise<Task> {
  const local = await getLocalTask(taskId);
  const remote = await getRemoteTask(taskId);
  const resolved = resolveConflict(local, remote);
  return resolved;
}

// Execute in a browser-like context
syncTask("task-1").then((t) => console.log("Resolved Task:", t));
