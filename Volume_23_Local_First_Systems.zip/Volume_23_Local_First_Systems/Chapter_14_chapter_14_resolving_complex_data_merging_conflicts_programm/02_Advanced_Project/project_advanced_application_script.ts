/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /lib/conflict/resolveTaskMerge.ts
import { WasmDb } from "@localfirst/wasm-db";
import { Pinecone } from "@pinecone/client";
import { WorkerPool } from "@utils/wasmThreads";

/**
 * Domain model for a collaborative task in the SaaS app.
 */
interface Task {
  id: string;
  title: string;
  status: "Open" | "In Review" | "Blocked" | "Done";
  updatedAt: number;
  version: number;
}

/**
 * Represents a detected merge conflict between two task states.
 */
interface MergeConflict {
  taskId: string;
  local: Task;
  remote: Task;
  reason: string;
}

/**
 * Custom resolver result containing the winning task and audit note.
 */
interface ResolvedTask {
  task: Task;
  resolutionLog: string;
}

/**
 * Module Responsibility: Detect invalid status transitions.
 * SRP: Only knows domain rules about status precedence.
 */
function detectStatusConflict(local: Task, remote: Task): MergeConflict | null {
  // If statuses differ and neither is a legal superset, flag conflict
  if (local.status !== remote.status) {
    const precedence = { Open: 0, "In Review": 1, Blocked: 2, Done: 3 };
    // Blocked should never be overridden by In Review silently
    if (
      (local.status === "Blocked" && remote.status === "In Review") ||
      (remote.status === "Blocked" && local.status === "In Review")
    ) {
      return {
        taskId: local.id,
        local,
        remote,
        reason: "Blocked/In Review semantic collision",
      };
    }
  }
  return null;
}

/**
 * Module Responsibility: Apply business-specific merge resolver.
 * SRP: Isolated from detection and IO.
 */
function resolveByDomainPolicy(conflict: MergeConflict): ResolvedTask {
  // Domain rule: Blocked takes precedence over In Review for compliance
  const winner =
    conflict.local.status === "Blocked" ? conflict.local : conflict.remote;
  return {
    task: { ...winner, version: winner.version + 1 },
    resolutionLog: `Resolved via policy: ${winner.status} prioritized`,
  };
}

/**
 * Fallback heuristic when no domain rule applies.
 * SRP: Pure function, no side effects.
 */
function fallbackLastWriter(taskA: Task, taskB: Task): ResolvedTask {
  const winner = taskA.updatedAt > taskB.updatedAt ? taskA : taskB;
  return {
    task: winner,
    resolutionLog: "Fallback: last writer wins",
  };
}

/**
 * WASM-threaded conflict scanner for large task sets.
 * Uses shared memory across Web Workers.
 */
async function scanConflictsWithWasm(
  tasks: [Task, Task][]
): Promise<MergeConflict[]> {
  const pool = new WorkerPool({ threads: 4 });
  // Offload pairwise comparison to WASM threads
  const results = await pool.map(tasks, ([l, r]) => detectStatusConflict(l, r));
  return results.filter((r): r is MergeConflict => r !== null);
}

/**
 * Next.js API route handler demonstrating full resolution pipeline.
 */
export async function POST(req: Request) {
  const { localTasks, remoteTasks } = await req.json();
  // 1. Pair local and remote by id
  const pairs = localTasks.map((l: Task) => {
    const r = remoteTasks.find((t: Task) => t.id === l.id);
    return [l, r] as [Task, Task];
  });

  // 2. Detect conflicts using WASM threads
  const conflicts = await scanConflictsWithWasm(pairs);

  // 3. Resolve each conflict
  const resolved = conflicts.map((c) => resolveByDomainPolicy(c));

  // 4. Persist to WASM DB and Pinecone namespace
  const db = await WasmDb.open("saas-tasks");
  const pine = new Pinecone({ apiKey: process.env.PINECONE_KEY! });
  const ns = pine.index("tasks").namespace("proj-alpha");

  for (const r of resolved) {
    await db.put(r.task.id, r.task);
    await ns.upsert([
      { id: r.task.id, values: [r.task.version], metadata: r.resolutionLog },
    ]);
  }

  return Response.json({ resolvedCount: resolved.length });
}
