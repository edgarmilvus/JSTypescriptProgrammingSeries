/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

 
// Deep immutability helper to enforce read-only data contracts
type DeepReadonly<T> = {
  readonly [K in keyof T]: T[K] extends object ? DeepReadonly<T[K]> : T[K];
};

export interface Annotation {
  readonly id: string;
  readonly rangeStart: number;
  readonly rangeEnd: number;
  readonly severity: 1 | 2 | 3; // 3 = critical, 1 = low
  readonly note: string;
  readonly deleted?: boolean;
}

export interface DocModel {
  readonly title: string;
  readonly body: string;
  readonly annotations: ReadonlyArray<Annotation>;
}

export interface MergeConflict {
  readonly base: DeepReadonly<Annotation>;
  readonly local: DeepReadonly<Annotation>;
  readonly remote: DeepReadonly<Annotation>;
}

export type ResolveAnnotationConflict = (
  base: DeepReadonly<Annotation>,
  local: DeepReadonly<Annotation>,
  remote: DeepReadonly<Annotation>
) => DeepReadonly<Annotation>;

/**
 * Implements domain-specific merge rules for conflicting annotations.
 */
export const resolveAnnotationConflict: ResolveAnnotationConflict = (
  base,
  local,
  remote
) => {
  // 1. Fallback Heuristic: Tombstone vs Edit
  // If one replica deleted the annotation while the other edited it,
  // we prioritize the deletion (tombstone wins) to maintain safety.
  if (local.deleted && !remote.deleted) {
    return local;
  }
  if (remote.deleted && !local.deleted) {
    return remote;
  }

  // 2. Domain Rule: Higher severity wins
  if (local.severity > remote.severity) {
    return local;
  }
  if (remote.severity > local.severity) {
    return remote;
  }

  // 3. Tie-breaker: If severities are equal, the longer explanatory note wins.
  if (local.note.length >= remote.note.length) {
    return local;
  }
  return remote;
};

// Interface for the hypothetical WASM DB registration
export interface LocalWasmDB {
  registerMergeResolver(
    collection: string,
    resolver: (conflict: MergeConflict) => DeepReadonly<Annotation>
  ): void;
}