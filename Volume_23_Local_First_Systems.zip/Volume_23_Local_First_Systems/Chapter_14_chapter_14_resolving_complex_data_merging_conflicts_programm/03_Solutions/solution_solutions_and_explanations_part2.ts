/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
export interface Task {
  readonly id: string;
  readonly title: string;
  readonly status: 'open' | 'completed';
  readonly progress: number; // 0 to 100
  readonly createdDate: number; // epoch ms
  readonly dueDate: number; // epoch ms
}

export type CorrectionEvent = {
  readonly taskId: string;
  readonly ruleViolated: string;
  readonly previousState: Task;
  readonly correctedState: Task;
};

export interface PostMergeValidator<T> {
  validate(state: DeepReadonly<T>): {
    valid: boolean;
    correctedState: DeepReadonly<T>;
    events: ReadonlyArray<CorrectionEvent>;
  };
}

const DEFAULT_DUE_DELTA_MS = 24 * 60 * 60 * 1000; // 1 day

export class TaskPostMergeValidator implements PostMergeValidator<Task> {
  validate(state: DeepReadonly<Task>) {
    let current = { ...state } as Task;
    const events: CorrectionEvent[] = [];

    // Rule 1: dueDate must not be earlier than createdDate
    if (current.dueDate < current.createdDate) {
      const original = { ...current };
      current = {
        ...current,
        dueDate: current.createdDate + DEFAULT_DUE_DELTA_MS,
      };
      events.push({
        taskId: current.id,
        ruleViolated: "dueDate_before_createdDate",
        previousState: original,
        correctedState: current,
      });
    }

    // Rule 2: completed status must match 100% progress
    if (current.status === "completed" && current.progress < 100) {
      const original = { ...current };
      current = {
        ...current,
        progress: 100,
      };
      events.push({
        taskId: current.id,
        ruleViolated: "completed_status_low_progress",
        previousState: original,
        correctedState: current,
      });
    }

    // Rule 3: open status with 100% progress should be corrected to completed
    if (current.status === "open" && current.progress === 100) {
      const original = { ...current };
      current = {
        ...current,
        status: "completed",
      };
      events.push({
        taskId: current.id,
        ruleViolated: "open_status_max_progress",
        previousState: original,
        correctedState: current,
      });
    }

    return {
      valid: events.length === 0,
      correctedState: Object.freeze(current) as DeepReadonly<Task>,
      events,
    };
  }
}