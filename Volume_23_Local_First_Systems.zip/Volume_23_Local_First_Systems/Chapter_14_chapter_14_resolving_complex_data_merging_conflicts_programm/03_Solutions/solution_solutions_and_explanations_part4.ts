/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
 
import React, { useSyncExternalStore } from "react";

export type ResolutionChoice =
  | { readonly type: "auto" }
  | { readonly type: "manual"; readonly chosen: "local" | "remote" }
  | { readonly type: "discard" };

export interface ConflictRecord {
  readonly id: string;
  readonly base: Record<string, unknown>;
  readonly local: Record<string, unknown>;
  readonly remote: Record<string, unknown>;
}

export interface WasmDbHandle {
  onConflict(cb: () => void): () => void;
  getPendingConflicts(): ReadonlyArray<ConflictRecord>;
  resolve(conflictId: string, choice: ResolutionChoice): Promise<void>;
}

export interface ConflictInspectorProps {
  readonly collection: string;
  readonly wasmDb: WasmDbHandle;
  readonly onResolve: (conflictId: string, choice: ResolutionChoice) => void;
}

export function ConflictInspector({
  collection,
  wasmDb,
  onResolve,
}: ConflictInspectorProps): JSX.Element {
  // Subscribe to WASM DB conflict events using useSyncExternalStore
  const conflicts = useSyncExternalStore(
    (onChange) => wasmDb.onConflict(onChange),
    () => wasmDb.getPendingConflicts()
  );

  const handleResolve = (conflictId: string, choice: ResolutionChoice) => {
    // Safe: notify the handler rather than mutating local state directly
    onResolve(conflictId, choice);
  };

  if (conflicts.length === 0) {
    return <div>No pending conflicts in {collection}.</div>;
  }

  return (
    <div className="conflict-inspector">
      {conflicts.map((c) => (
        <div key={c.id} className="conflict-card">
          <div className="panel">Base: {JSON.stringify(c.base)}</div>
          <div className="panel">Local: {JSON.stringify(c.local)}</div>
          <div className="panel">Remote: {JSON.stringify(c.remote)}</div>
          <div className="actions">
            <button onClick={() => handleResolve(c.id, { type: "manual", chosen: "local" })}>
              Keep Local
            </button>
            <button onClick={() => handleResolve(c.id, { type: "manual", chosen: "remote" })}>
              Keep Remote
            </button>
            <button onClick={() => handleResolve(c.id, { type: "auto" })}>
              Auto Resolve
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}