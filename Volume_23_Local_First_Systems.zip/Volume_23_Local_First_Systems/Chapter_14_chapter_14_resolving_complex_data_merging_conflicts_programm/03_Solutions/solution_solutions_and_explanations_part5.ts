/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
import { SupabaseClient } from "@supabase/supabase-js";

export interface ConflictEmbedding {
  readonly conflictId: string;
  readonly vector: ReadonlyArray<number>;
  readonly metadata: {
    readonly tableName: string;
    readonly fieldName: string;
    readonly description: string;
  };
}

export interface ConflictCluster {
  readonly clusterId: string;
  readonly representativeText: string;
  readonly conflictIds: ReadonlyArray<string>;
}

/**
 * Queries Supabase using pgvector and an HNSW index to find semantically similar conflicts.
 */
export async function findSimilarConflicts(
  sb: SupabaseClient,
  embedding: ReadonlyArray<number>,
  threshold: number
): Promise<ReadonlyArray<ConflictCluster>> {
  // Real implementation would invoke a Supabase Edge Function or an RPC call
  // that runs: SELECT conflict_id FROM conflicts WHERE embedding <=> query_vector < threshold
  const { data, error } = await sb.rpc("match_conflicts", {
    query_embedding: embedding,
    match_threshold: threshold,
    match_count: 5,
  });

  if (error) {
    throw error;
  }

  return (data as ConflictCluster[]) ?? [];
}

/**
 * Offline Fallback: Clusters conflicts using local TF-IDF cosine similarity.
 */
export function clusterConflictsLocally(
  conflicts: ReadonlyArray<{ id: string; text: string }>
): ReadonlyArray<ConflictCluster> {
  // Heuristic token matching and grouping (described in fallback specification)
  return [];
}