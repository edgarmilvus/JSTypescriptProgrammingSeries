/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
export interface MergeLogEntry {
  readonly entryId: string;
  readonly conflictId: string;
  readonly resolvedHash: string; // hash of the resulting state
  readonly resolvedBy: "auto_crdt" | "custom_resolver" | "manual_ui" | "ai_agent";
  readonly timestamp: number;
}

export type MergeLog = ReadonlyArray<DeepReadonly<MergeLogEntry>>;

/**
 * Merges two independent, append-only merge logs.
 * Because the log is an append-only set, duplicates are eliminated by ID hashing.
 */
export function mergeLogs(
  a: MergeLog,
  b: MergeLog
): MergeLog {
  const mergedMap = new Map<string, DeepReadonly<MergeLogEntry>>();
  
  // Add entries from log A
  for (const entry of a) {
    mergedMap.set(entry.entryId, entry);
  }
  
  // Add entries from log B (idempotent, duplicates naturally overwrite identically)
  for (const entry of b) {
    mergedMap.set(entry.entryId, entry);
  }

  // Return a sorted immutable list
  return Object.freeze(
    Array.from(mergedMap.values()).sort((x, y) => x.timestamp - y.timestamp)
  );
}