/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Basic schema migration example for a local-first SaaS app.
 * Demonstrates immutable state management and versioned schemas.
 */

// ---------------------------------------------------------------------------
// 1. Type Definitions (Versioned Schemas)
// ---------------------------------------------------------------------------

/**
 * v1 schema for a Project entity in our SaaS dashboard.
 * Used before the migration.
 */
interface ProjectV1 {
  readonly id: string;
  readonly name: string;
  readonly createdAt: number;
}

/**
 * v2 schema for a Project entity.
 * Adds an optional `archived` flag without breaking old data.
 */
interface ProjectV2 {
  readonly id: string;
  readonly name: string;
  readonly createdAt: number;
  readonly archived: boolean;
}

/**
 * Union type representing any known project shape.
 */
type Project = ProjectV1 | ProjectV2;

// ---------------------------------------------------------------------------
// 2. Client-Side Store (Simulated WASM-backed local DB)
// ---------------------------------------------------------------------------

/**
 * Simulated local store that holds projects in memory.
 * In a real app this would be backed by a WASM DB like SQLite or a CRDT store.
 */
class LocalProjectStore {
  private records: ReadonlyArray<Project> = [];

  /**
   * Loads raw records (e.g., from IndexedDB or WASM memory).
   * @param initial - array of project records in any version
   */
  hydrate(initial: ReadonlyArray<Project>): void {
    this.records = initial;
  }

  /**
   * Returns a shallow copy of current records (immutable access).
   */
  getAll(): ReadonlyArray<Project> {
    return this.records;
  }

  /**
   * Replaces the entire record set with a new immutable array.
   * @param next - new array of migrated records
   */
  private replaceAll(next: ReadonlyArray<Project>): void {
    this.records = next;
  }

  /**
   * Applies a migration function across all records immutably.
   * @param migrate - pure function mapping old to new project
   */
  applyMigration(migrate: (p: Project) => Project): void {
    const migrated = this.records.map((p) => migrate(p));
    this.replaceAll(migrated);
  }
}

// ---------------------------------------------------------------------------
// 3. Migration Function (Pure & Conflict-Free)
// ---------------------------------------------------------------------------

/**
 * Migrates a Project from v1 to v2 by adding `archived: false`.
 * If already v2, returns a new copy (immutable update).
 * @param project - incoming project of any version
 * @returns migrated ProjectV2
 */
function migrateToV2(project: Project): ProjectV2 {
  // Destructure known fields; archived is added below.
  const { id, name, createdAt } = project;

  // Create a NEW object instead of mutating the old one.
  return {
    id,
    name,
    createdAt,
    archived: false,
  };
}

// ---------------------------------------------------------------------------
// 4. SaaS App Bootstrap (Hello World Usage)
// ---------------------------------------------------------------------------

/**
 * Entry point simulating a local-first SaaS dashboard startup.
 */
function bootstrapSaaSApp(): void {
  // Simulate existing v1 data stored on the client.
  const legacyData: ReadonlyArray<Project> = [
    { id: 'p1', name: 'Website Redesign', createdAt: 1700000000 },
    { id: 'p2', name: 'Mobile App', createdAt: 1700001000 },
  ];

  // Hydrate the local store (no network needed).
  const store = new LocalProjectStore();
  store.hydrate(legacyData);

  // Apply schema migration locally and offline-safe.
  store.applyMigration(migrateToV2);

  // Verify the new schema shape.
  const upgraded = store.getAll();
  console.log('Migrated projects:', upgraded);
}

// Run the example.
bootstrapSaaSApp();
