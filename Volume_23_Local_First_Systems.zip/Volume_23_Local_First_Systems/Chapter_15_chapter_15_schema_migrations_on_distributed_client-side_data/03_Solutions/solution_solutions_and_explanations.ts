/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Minimal local WASM DB abstraction for illustration
interface LocalWasmDB {
  exec(sql: string): Promise<void>;
  query(sql: string): Promise<any[]>;
  // CRDT merge simulation
  merge(peerState: any): Promise<void>;
}

// 1. SchemaVersion interface
interface SchemaVersion {
  version: number;
  migrateUp: (db: LocalWasmDB) => Promise<void>;
  migrateDown: (db: LocalWasmDB) => Promise<void>;
  supportsPeerVersion: (v: number) => boolean;
}

// Structured error for gap detection
class SchemaGapError extends Error {
  constructor(from: number, to: number) {
    super(`Schema gap detected between v${from} and v${to}`);
    this.name = 'SchemaGapError';
  }
}

// 2. SchemaRegistry class
class SchemaRegistry {
  private versions: SchemaVersion[];
  constructor(versions: SchemaVersion[]) {
    this.versions = versions.sort((a, b) => a.version - b.version);
  }

  private async getCurrentVersion(db: LocalWasmDB): Promise<number> {
    await db.exec(`CREATE TABLE IF NOT EXISTS _meta (key TEXT PRIMARY KEY, value TEXT)`);
    const rows = await db.query(`SELECT value FROM _meta WHERE key='schema_version'`);
    return rows.length ? parseInt(rows[0].value, 10) : 0;
  }

  private async setCurrentVersion(db: LocalWasmDB, v: number): Promise<void> {
    await db.exec(`INSERT OR REPLACE INTO _meta (key, value) VALUES ('schema_version', '${v}')`);
  }

  async ensureMigrated(db: LocalWasmDB, targetVersion?: number): Promise<void> {
    const target = targetVersion ?? this.versions[this.versions.length - 1].version;
    const current = await this.getCurrentVersion(db);
    if (current === target) return;
    if (current > target) {
      // migrate down if needed
      for (let v = current; v > target; v--) {
        const sv = this.versions.find(s => s.version === v);
        if (!sv) throw new SchemaGapError(v, v - 1);
        await sv.migrateDown(db);
        await this.setCurrentVersion(db, v - 1);
      }
      return;
    }
    for (let v = current + 1; v <= target; v++) {
      const sv = this.versions.find(s => s.version === v);
      if (!sv) throw new SchemaGapError(v - 1, v);
      await sv.migrateUp(db);
      await this.setCurrentVersion(db, v);
    }
  }
}

// 3. Simulate three schema versions
const v1: SchemaVersion = {
  version: 1,
  migrateUp: async (db) => {
    await db.exec(`CREATE TABLE notes (id TEXT PRIMARY KEY, text TEXT)`);
  },
  migrateDown: async (db) => {
    await db.exec(`DROP TABLE IF EXISTS notes`);
  },
  supportsPeerVersion: (v) => v === 1
};

const v2: SchemaVersion = {
  version: 2,
  migrateUp: async (db) => {
    await db.exec(`ALTER TABLE notes ADD COLUMN created_at INTEGER DEFAULT 0`);
  },
  migrateDown: async (db) => {
    // simplified: sqlite cannot drop column easily; treat as no-op for demo
  },
  supportsPeerVersion: (v) => v >= 1 && v <= 2
};

const v3: SchemaVersion = {
  version: 3,
  migrateUp: async (db) => {
    await db.exec(`ALTER TABLE notes ADD COLUMN title TEXT DEFAULT ''`);
    await db.exec(`ALTER TABLE notes ADD COLUMN body TEXT DEFAULT ''`);
    await db.exec(`UPDATE notes SET title = substr(text, 1, 20), body = text WHERE title = ''`);
  },
  migrateDown: async (db) => {
    // forward compat: older clients ignore title/body
  },
  supportsPeerVersion: (v) => v >= 1 && v <= 3
};

const registry = new SchemaRegistry([v1, v2, v3]);

// 4. Test scenario
async function testSync() {
  const dbA: LocalWasmDB = { /* mock */ exec: async () => {}, query: async () => [], merge: async () => {} };
  const dbB: LocalWasmDB = { /* mock */ exec: async () => {}, query: async () => [], merge: async () => {} };
  await registry.ensureMigrated(dbA, 3); // Client A to v3 offline
  await registry.ensureMigrated(dbB, 1); // Client B stays v1
  // CRDT merge: both exchange states, no data loss due to optional columns
  await dbA.merge({ notes: [{ id: '1', text: 'hello' }] }); // B's v1 data
  await dbB.merge({ notes: [{ id: '1', title: 'hell', body: 'hello' }] }); // A's v3 data degraded
}

// 5. Conflict-free properties (comments)
// migrateUp steps are commutative with CRDT merges because they only add optional
// columns or derive deterministic data from existing rows; no destructive locking.
// Older clients ignore unknown columns (forward compat), newer read old shape (backward compat).
