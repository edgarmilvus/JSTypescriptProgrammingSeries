/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Extended DB interface
interface LocalWasmDB {
  applySchemaPatch(patch: SchemaPatch): Promise<void>;
  // ... other methods
}

// 2. SchemaPatch type
type SchemaPatch =
  | { op: 'addOptionalColumn'; table: string; column: string; defaultValueExpr: string }
  | { op: 'addCrdtMapKey'; mapName: string; key: string; mergeStrategy: 'last-write' | 'add-wins' };

// 3. Migration v2->v3 using patch
async function migrateV2ToV3Patch(db: LocalWasmDB): Promise<void> {
  await db.applySchemaPatch({
    op: 'addOptionalColumn',
    table: 'notes',
    column: 'created_at',
    defaultValueExpr: 'COALESCE(existing.created_at, 0)'
  });
  await db.applySchemaPatch({
    op: 'addCrdtMapKey',
    mapName: 'notes_map',
    key: 'title',
    mergeStrategy: 'last-write'
  });
  await db.applySchemaPatch({
    op: 'addCrdtMapKey',
    mapName: 'notes_map',
    key: 'body',
    mergeStrategy: 'last-write'
  });
}

// 4. Concurrency test outline
async function concurrencyTest() {
  const dbV2: LocalWasmDB = { applySchemaPatch: async () => {}, /* mock */ };
  // 100 offline writes on v2 clients (simulated)
  for (let i = 0; i < 100; i++) { /* dbV2 write */ }
  const dbV3: LocalWasmDB = { applySchemaPatch: async () => {}, /* mock */ };
  await migrateV2ToV3Patch(dbV3);
  // sync: all rows get new column from CRDT state
}

// 5. Analysis: default values must be deterministic per row (e.g., from existing
// CRDT fields) not Date.now()/UUID, else peers compute different values -> conflict.
