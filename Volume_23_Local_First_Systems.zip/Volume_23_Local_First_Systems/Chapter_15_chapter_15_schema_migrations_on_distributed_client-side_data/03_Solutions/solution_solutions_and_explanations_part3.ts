/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. MigrationEvent shape (extended)
type MigrationEvent =
  | { type: 'start'; from: number; to: number; ts: number }
  | { type: 'step'; stepId: string; ok: boolean }
  | { type: 'crash'; reason: string }
  | { type: 'restart' }
  | { type: 'apply'; version: number; idempotentKey: string };

// 2. Algorithm outline (signatures)
function parseLog(events: MigrationEvent[]): ParsedLog;
function detectDuplicates(log: ParsedLog): string[];
function simulateReplay(log: ParsedLog, migrations: Map<string, () => Promise<void>>): StateGraph;
function toDot(graph: StateGraph): string;

// 3. Expected DOT output structure
// digraph G { "v1" -> "v2" [label="idempotent apply"]; "crash" [shape=diamond]; }
