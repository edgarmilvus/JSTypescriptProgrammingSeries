/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal PartyKit server definition for a SaaS collaboration hub.
 * This example shows how a centralized hub can receive and broadcast messages.
 */

/// <reference types="partykit/server" />

import type * as Party from "partykit/server";

/**
 * HelloWorldParty represents a single PartyKit room.
 * In a SaaS context, each room could be a workspace, document, or team hub.
 */
export default class HelloWorldParty implements Party.Server {
  /**
   * PartyKit injects a Party.ConnectionContext and Party.Room
   * when the room is initialized.
   */
  constructor(public room: Party.Room) {}

  /**
   * Called when a new client connects to this party (room).
   * @param conn The incoming WebSocket connection
   */
  onConnect(conn: Party.Connection) {
    // Notify the new connection that it has joined the hub
    conn.send(
      JSON.stringify({
        type: "system",
        message: "Welcome to the SaaS collaboration hub!"
      })
    );

    // Broadcast to all other connections that someone joined
    this.room.broadcast(
      JSON.stringify({
        type: "presence",
        message: `A new user connected: ${conn.id}`
      }),
      [conn.id] // exclude the sender from this broadcast
    );
  }

  /**
   * Called when a client sends a message to the hub.
   * @param message Raw message string from the client
   * @param conn The connection that sent the message
   */
  onMessage(message: string, conn: Party.Connection) {
    // Parse the incoming message safely
    let parsed: unknown;
    try {
      parsed = JSON.parse(message);
    } catch {
      conn.send(
        JSON.stringify({
          type: "error",
          message: "Invalid JSON received"
        })
      );
      return;
    }

    // Broadcast the parsed message to everyone in the room
    this.room.broadcast(
      JSON.stringify({
        type: "broadcast",
        from: conn.id,
        payload: parsed
      })
    );
  }

  /**
   * Called when a client disconnects.
   * @param conn The disconnected connection
   */
  onClose(conn: Party.Connection) {
    this.room.broadcast(
      JSON.stringify({
        type: "presence",
        message: `User disconnected: ${conn.id}`
      })
    );
  }
}

/**
 * PartyKit configuration used for local development and deployment.
 */
HelloWorldParty satisfies Party.Worker;
