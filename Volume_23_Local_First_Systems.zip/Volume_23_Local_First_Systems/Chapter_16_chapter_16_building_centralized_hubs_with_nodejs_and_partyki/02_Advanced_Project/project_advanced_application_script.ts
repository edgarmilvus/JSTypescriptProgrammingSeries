/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/api/design-hub/route.ts
 * Context: SaaS Collaborative Design Platform (Next.js App Router)
 * Purpose: Centralized Hub endpoint that receives CRDT batches from PartyKit,
 * runs headless inference via Vercel AI SDK, and applies a consensus mechanism.
 */

import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@ai-sdk/openai';
import { streamText, Message } from 'ai';

/**
 * JSDoc: WorkerAgent
 * A simple in-process agent that proposes a summary for a given CRDT delta.
 * In a real system this could be a separate thread or PartyKit connection.
 */
interface WorkerAgent {
  id: string;
  proposeSummary: (delta: string) => Promise<string>;
}

/**
 * JSDoc: SupervisorNode
 * Compiles multiple worker proposals into a single robust summary.
 * Implements a naive consensus: longest shared prefix + merge.
 */
class SupervisorNode {
  async synthesize(agents: WorkerAgent[], delta: string): Promise<string> {
    // 1. Collect proposals concurrently from all worker agents
    const proposals = await Promise.all(
      agents.map((agent) => agent.proposeSummary(delta))
    );

    // 2. Naive consensus: pick the most detailed proposal (by length)
    const best = proposals.sort((a, b) => b.length - a.length)[0];
    return `Consensus: ${best}`;
  }
}

/**
 * JSDoc: createWorkerAgent
 * Factory for headless inference agents using Vercel AI SDK's streamText
 * in a non-graphical Node.js environment (Headless Inference).
 */
function createWorkerAgent(id: string): WorkerAgent {
  return {
    id,
    async proposeSummary(delta: string): Promise<string> {
      // 3. Run headless inference (no UI rendering)
      const { text } = await streamText({
        model: openai('gpt-4o-mini'),
        prompt: `Summarize this CRDT delta for a design app: ${delta}`,
      }).complete();
      return text;
    },
  };
}

/**
 * JSDoc: POST Handler
 * Receives a CRDT batch from PartyKit, triggers consensus, returns stream.
 */
export async function POST(req: NextRequest) {
  // 4. Parse the incoming CRDT batch from PartyKit room
  const { roomId, crdtDelta } = await req.json<{
    roomId: string;
    crdtDelta: string;
  }>();

  // 5. Initialize supervisor and three worker agents (multi-agent pattern)
  const supervisor = new SupervisorNode();
  const agents = [
    createWorkerAgent('w1'),
    createWorkerAgent('w2'),
    createWorkerAgent('w3'),
  ];

  // 6. Synthesize a consensus summary via headless inference
  const consensus = await supervisor.synthesize(agents, crdtDelta);

  // 7. Return a streaming response mimicking useChat hook behavior
  const messages: Message[] = [
    { role: 'user', content: crdtDelta },
    { role: 'assistant', content: consensus },
  ];

  return new NextResponse(
    JSON.stringify({ roomId, summary: consensus, messages }),
    { headers: { 'content-type': 'application/json' } }
  );
}
