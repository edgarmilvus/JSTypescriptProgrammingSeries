/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// CRDT Hub state interface as required
interface CRDTHubState {
  doc: Uint8Array; // serialized CRDT document
  lastUpdated: number;
  connectedClients: Set<string>;
}

// PartyKit-style server class (pseudocode / method signatures)
class CRDTMergeProxy {
  state: CRDTHubState;

  // 1. Initialize empty CRDT doc on room start
  onStart(): void {
    this.state = {
      doc: Y.encodeStateAsUpdate(new Y.Doc()), // empty Yjs doc
      lastUpdated: Date.now(),
      connectedClients: new Set()
    };
  }

  // 2. Handle new connections: send full snapshot
  onConnect(conn: Connection): void {
    this.state.connectedClients.add(conn.id);
    conn.send(this.state.doc); // full snapshot to late joiner
  }

  // 3. Receive and merge binary CRDT updates
  onMessage(conn: Connection, msg: Uint8Array): void {
    try {
      const merged = Y.mergeUpdates([this.state.doc, msg]);
      this.state.doc = merged;
      this.state.lastUpdated = Date.now();
      // Broadcast merged update to all except sender
      this.broadcast(merged, [conn.id]);
    } catch (e) {
      // malformed update ignored, doc untouched
      console.warn('Invalid CRDT update dropped', e);
    }
  }

  // Broadcast helper (excludes specified client ids)
  broadcast(update: Uint8Array, exclude: string[]): void {
    for (const c of this.state.connectedClients) {
      if (!exclude.includes(c)) this.getConnection(c).send(update);
    }
  }
}
