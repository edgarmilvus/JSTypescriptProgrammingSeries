/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Presence payload as specified
type CursorPresence = {
  clientId: string;
  x: number;
  y: number;
  selection?: { start: number; end: number };
  timestamp: number;
};

// Broker inside PartyKit room (signatures + core logic)
class PresenceBroker {
  private map = new Map<string, CursorPresence>();
  private throttleTimer: ReturnType<typeof setTimeout> | null = null;

  onMessage(connId: string, data: Uint8Array): void {
    const p = JSON.parse(new TextDecoder().decode(data)) as CursorPresence;
    p.clientId = connId; // server-attached id
    p.timestamp = Date.now();
    this.map.set(p.clientId, p);
    this.scheduleBroadcast();
  }

  private scheduleBroadcast(): void {
    if (this.throttleTimer) return;
    this.throttleTimer = setTimeout(() => {
      const list = Array.from(this.map.values());
      this.broadcast(JSON.stringify(list));
      this.throttleTimer = null;
    }, 30);
  }

  private broadcast(payload: string): void {
    // send to all connections except self handled by caller
  }
}
