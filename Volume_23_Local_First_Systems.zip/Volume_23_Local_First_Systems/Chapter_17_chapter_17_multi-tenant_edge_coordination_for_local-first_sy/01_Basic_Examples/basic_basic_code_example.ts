/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * TenantEdgeCoordinator.ts
 * 
 * A minimal, self-contained example of multi-tenant edge coordination
 * for local-first sync in a SaaS context.
 * 
 * Concepts demonstrated:
 * - Tenant-aware edge relay simulation
 * - Streaming API Route using Edge Runtime primitives (ReadableStream)
 * - Warm Start (Local AI) simulation
 * - Consensus Mechanism between worker agents
 */

// ----------------------------------------------------------------------------
// Type Definitions
// ----------------------------------------------------------------------------

/** Represents a single SaaS tenant in our system. */
interface Tenant {
  id: string;
  region: string;
  quotaMb: number;
}

/** Output produced by a worker agent monitoring sync health. */
interface AgentReport {
  agentId: string;
  healthy: boolean;
  latencyMs: number;
}

/** Final synthesized report after consensus. */
interface ConsensusReport {
  tenantId: string;
  healthy: boolean;
  avgLatencyMs: number;
  sources: number;
}

// ----------------------------------------------------------------------------
// In-Memory Tenant Registry (simulated SaaS backend)
// ----------------------------------------------------------------------------

const TENANTS: Record<string, Tenant> = {
  "tenant-a": { id: "tenant-a", region: "us-east", quotaMb: 50 },
  "tenant-b": { id: "tenant-b", region: "eu-west", quotaMb: 20 },
};

// ----------------------------------------------------------------------------
// Edge Relay Simulation
// ----------------------------------------------------------------------------

/**
 * Simulates a lightweight regional edge relay that isolates tenant data.
 * In a real system this would be a Cloudflare Worker or Vercel Edge Function.
 */
class EdgeRelay {
  constructor(private tenant: Tenant) {}

  /** Returns tenant-scoped sync configuration. */
  getSyncConfig(): string {
    return JSON.stringify({
      tenantId: this.tenant.id,
      region: this.tenant.region,
      quotaMb: this.tenant.quotaMb,
      crdtPartition: `crdt-${this.tenant.id}`,
    });
  }
}

// ----------------------------------------------------------------------------
// Warm Start Local AI Simulation
// ----------------------------------------------------------------------------

/**
 * Simulates a local AI model used for anomaly detection in sync traffic.
 * First call = cold start; subsequent = warm start.
 */
class LocalAI {
  private initialized = false;

  /** Mimics model initialization (WASM/WebGPU pipelines). */
  private coldStart(): void {
    this.initialized = true;
  }

  /**
   * Runs inference. If warm started, latency is low.
   * @param input Dummy sync metric
   * @returns Risk score 0-1
   */
  infer(input: number): number {
    if (!this.initialized) {
      this.coldStart();
      return 0.9; // cold start penalty
    }
    return Math.min(1, input * 0.1); // warm start fast path
  }
}

// ----------------------------------------------------------------------------
// Consensus Mechanism (Multi-Agent)
// ----------------------------------------------------------------------------

/**
 * Two worker agents report sync health; supervisor synthesizes.
 */
function runConsensus(tenantId: string): ConsensusReport {
  const agents: AgentReport[] = [
    { agentId: "w1", healthy: true, latencyMs: 12 },
    { agentId: "w2", healthy: true, latencyMs: 18 },
  ];

  const healthy = agents.every((a) => a.healthy);
  const avg = agents.reduce((s, a) => s + a.latencyMs, 0) / agents.length;

  return {
    tenantId,
    healthy,
    avgLatencyMs: avg,
    sources: agents.length,
  };
}

// ----------------------------------------------------------------------------
// Streaming API Route (Edge Runtime style)
// ----------------------------------------------------------------------------

/**
 * Simulates a Next.js Edge API route returning a ReadableStream.
 * @param tenantId Tenant identifier from request
 */
export function streamingSyncRoute(tenantId: string): Response {
  const tenant = TENANTS[tenantId];
  if (!tenant) {
    return new Response("Tenant not found", { status: 404 });
  }

  const relay = new EdgeRelay(tenant);
  const ai = new LocalAI();
  const consensus = runConsensus(tenantId);

  const stream = new ReadableStream({
    start(controller) {
      const enc = new TextEncoder();
      controller.enqueue(enc.encode(`CONFIG:${relay.getSyncConfig()}\n`));
      controller.enqueue(enc.encode(`AI_RISK:${ai.infer(5)}\n`));
      controller.enqueue(enc.encode(`CONSENSUS:${JSON.stringify(consensus)}\n`));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}

// ----------------------------------------------------------------------------
// Demo Execution (Hello World)
// ----------------------------------------------------------------------------

const res = streamingSyncRoute("tenant-a");
console.log("Edge stream ready:", res.status);
