/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// Next.js Edge Route Handler for multi-tenant local-first sync
// Runs on Edge Runtime (V8 Isolate) for low-latency tenant coordination

import { NextRequest, NextResponse } from 'next/server';
import { verifyTenantToken } from '@/lib/edge/auth'; // Edge-compatible JWT verify
import { checkTenantQuota } from '@/lib/edge/kv';    // Uses edge KV (e.g., Workers KV)
import { validateCrdtOp } from '@/lib/edge/crdt';   // Lightweight CRDT schema check
import { routeToRegionalRelay } from '@/lib/edge/relay'; // Tenant-aware relay picker

/**
 * Graph State shape used by the conditional edge logic.
 * Mirrors LangGraph state passed between nodes in an agent workflow.
 */
interface SyncGraphState {
  tenantId: string;
  tier: 'free' | 'pro' | 'enterprise';
  opSize: number;
  valid: boolean;
  quotaOk: boolean;
  nextNode: 'commit' | 'resolve' | 'reject';
}

/**
 * Conditional Edge predicate.
 * Inspects SyncGraphState and returns the next node name.
 * This is the data-driven branching core of the coordination flow.
 */
function conditionalEdge(state: SyncGraphState): SyncGraphState['nextNode'] {
  if (!state.valid || !state.quotaOk) return 'reject';
  // Enterprise tenants with large ops use conflict-resolution node
  if (state.tier === 'enterprise' && state.opSize > 2048) return 'resolve';
  return 'commit';
}

/**
 * POST /api/edge/sync
 * Handles local-first CRDT push from a tenant-specific client.
 */
export async function POST(req: NextRequest) {
  // 1. Extract and verify tenant from Authorization header (edge auth)
  const token = req.headers.get('authorization')?.replace('Bearer ', '');
  const tenant = await verifyTenantToken(token);
  if (!tenant) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // 2. Parse CRDT operation from request body
  const body = await req.json();
  const opSize = JSON.stringify(body).length;

  // 3. Parallel Tool Execution: run quota check and CRDT validation concurrently
  const [quotaOk, valid] = await Promise.all([
    checkTenantQuota(tenant.id, opSize),  // edge KV read/write
    validateCrdtOp(body, tenant.namespace) // tenant-aware CRDT partition
  ]);

  // 4. Build graph state for conditional edge evaluation
  const state: SyncGraphState = {
    tenantId: tenant.id,
    tier: tenant.tier,
    opSize,
    valid,
    quotaOk,
    nextNode: 'reject'
  };

  // 5. Apply conditional edge to determine routing
  state.nextNode = conditionalEdge(state);

  // 6. Branch based on nextNode (simulated LangGraph transition)
  switch (state.nextNode) {
    case 'reject':
      return NextResponse.json({ error: 'Rejected by edge policy' }, { status: 403 });
    case 'resolve':
      // Route to regional WASM DB isolate for conflict resolution
      await routeToRegionalRelay(tenant.region, 'resolve', body);
      break;
    case 'commit':
    default:
      // Direct commit to tenant partition in edge WASM DB
      await routeToRegionalRelay(tenant.region, 'commit', body);
      break;
  }

  // 7. Return success with edge coordination metadata
  return NextResponse.json({
    synced: true,
    node: state.nextNode,
    tenant: tenant.id
  });
}
