/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Tenant-scoped CRDT batch interface
export interface TenantScopedCrdtBatch {
  tenantId: string;
  partitionKey: string;
  clientId: string;
  encodedCrdtOps: Uint8Array;
  hmacSignature: Uint8Array;
}

// Edge runtime context (e.g., Cloudflare Worker or Next.js Edge)
export interface EdgeRuntimeContext {
  region: string;
  tenantHmacSecrets: Map<string, Uint8Array>;
  quotaEnforcer: QuotaEnforcer;
}

// Routing decision returned by relay
export type RelayRoutingDecision =
  | { kind: 'accepted'; partitionKey: string }
  | { kind: 'rejected'; reason: string }
  | { kind: 'quarantined'; reason: string };

// 2. Routing function signature
export async function routeTenantBatch(
  batch: TenantScopedCrdtBatch,
  edgeContext: EdgeRuntimeContext
): Promise<RelayRoutingDecision> {
  // Implementation uses LangGraph StateGraph (see analysis)
  // Pseudocode: validate -> verify HMAC -> check quota -> route
  return { kind: 'accepted', partitionKey: batch.partitionKey };
}

// 3. Partition key derivation (non-leaking)
// Derived via HMAC-SHA256(tenantId + ':' + docNamespace, tenantSecret)
// Stored as opaque hex; never exposes tenantId in plaintext to co-located tenants
export function derivePartitionKey(tenantId: string, docNs: string, secret: Uint8Array): string {
  // ... crypto.subtle.hmac => base64url
  return 'pk_' + hashed;
}

// 5. ClientId accidental collision guard
// CRDT actor IDs must be namespaced: `${tenantId}::${clientId}`
// This ensures T1/clientX != T2/clientX in merge logic
