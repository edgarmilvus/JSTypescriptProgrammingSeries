/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Local-First Telemetry "Hello World"
 * SaaS Context: A lightweight analytics module for a project management web app.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents a single telemetry event stored on the device.
 * Immutable by design: once created, never mutated in place.
 */
interface TelemetryEvent {
  /** Unique Vector ID for this event chunk */
  vectorId: string;
  /** User or device identifier */
  userId: string;
  /** Event type, e.g., "page_view" */
  eventType: string;
  /** Timestamp in ISO format */
  timestamp: string;
  /** Optional payload */
  payload?: Record<string, unknown>;
}

// -----------------------------------------------------------------------------
// 2. MOCK LOCAL DATABASE (Simulates WASM-powered embedded DB)
// -----------------------------------------------------------------------------

/**
 * A minimal in-memory store mimicking an immutable append-only log.
 * In production this would be a WASM SQLite or IndexedDB wrapper.
 */
class LocalTelemetryStore {
  private events: TelemetryEvent[] = [];

  /**
   * Append a new event using immutable state management.
   * We never modify existing events; we create a new array.
   */
  addEvent(event: TelemetryEvent): void {
    // Create a new array instead of pushing (immutability)
    this.events = [...this.events, event];
  }

  /**
   * Retrieve all events (returns a copy to prevent external mutation)
   */
  getAllEvents(): TelemetryEvent[] {
    return [...this.events];
  }
}

// -----------------------------------------------------------------------------
// 3. SERVICE WORKER CACHING FOR AI ASSETS
// -----------------------------------------------------------------------------

/**
 * Simulated Service Worker registration for caching AI model weights.
 * In reality this would call navigator.serviceWorker.register('/sw.js')
 */
async function cacheAiAssets(): Promise<void> {
  // Mock: Assume we cache a small ONNX model for offline inference
  const modelUrl = '/models/telemetry-anomaly.onnx';
  console.log(`[ServiceWorker] Caching AI asset: ${modelUrl}`);
  // In real code: caches.open('ai-assets').then(c => c.add(modelUrl));
}

// -----------------------------------------------------------------------------
// 4. TELEMETRY TRACKER (SaaS Module)
// -----------------------------------------------------------------------------

/**
 * Main telemetry tracker used by the web app.
 */
class TelemetryTracker {
  private store: LocalTelemetryStore;

  constructor(store: LocalTelemetryStore) {
    this.store = store;
  }

  /**
   * Track a new event with a generated Vector ID.
   * @param userId - Current user
   * @param eventType - Type of event
   * @param payload - Optional data
   */
  track(userId: string, eventType: string, payload?: Record<string, unknown>): void {
    const event: TelemetryEvent = {
      vectorId: crypto.randomUUID(), // Unique Vector ID
      userId,
      eventType,
      timestamp: new Date().toISOString(),
      payload
    };
    // Immutable append
    this.store.addEvent(event);
    console.log(`Tracked event ${event.vectorId} offline.`);
  }
}

// -----------------------------------------------------------------------------
// 5. APP BOOTSTRAP
// -----------------------------------------------------------------------------

async function main(): Promise<void> {
  // Cache AI assets via Service Worker
  await cacheAiAssets();

  // Initialize local store and tracker
  const store = new LocalTelemetryStore();
  const tracker = new TelemetryTracker(store);

  // Simulate user activity in a SaaS dashboard
  tracker.track('user-123', 'dashboard_view');
  tracker.track('user-123', 'task_created', { taskId: 't-001' });

  // Display stored events
  console.log('Stored telemetry:', store.getAllEvents());
}

main();
