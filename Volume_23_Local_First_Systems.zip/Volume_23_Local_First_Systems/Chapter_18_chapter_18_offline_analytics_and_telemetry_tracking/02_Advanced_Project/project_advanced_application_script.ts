/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// telemetrySW.ts – Next.js offline analytics + AI asset caching module

/// <reference lib="webworker" />

/**
 * Vector ID utility: generates a stable unique identifier for each telemetry chunk.
 * Used to track, update, or delete specific vectors inside the local WASM DB.
 */
function createVectorId(sessionId: string, chunkIndex: number): string {
  // Combines session and index to ensure global uniqueness across devices
  return `vec_${sessionId}_${chunkIndex}`;
}

/**
 * Immutable telemetry event factory.
 * Returns a NEW object instead of mutating existing state.
 */
function appendTelemetryEvent(
  currentState: ReadonlyArray<Record<string, unknown>>,
  newEvent: Record<string, unknown>
): Array<Record<string, unknown>> {
  // Immutable State Management: never mutate, always return new array
  return [...currentState, newEvent];
}

/// Service Worker install: cache AI model weights for offline use
self.addEventListener('install', (event: ExtendableEvent) => {
  // Pre-cache large ONNX tensors via Service Worker Caching (AI Assets)
  event.waitUntil(
    caches.open('ai-assets-v1').then((cache) => {
      return cache.addAll([
        '/models/analytics-onnx/weights.bin',
        '/models/analytics-onnx/config.json'
      ]);
    })
  );
});

/// Intercept fetch to serve cached AI assets when offline
self.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url);
  // Only handle AI asset routes
  if (url.pathname.startsWith('/models/analytics-onnx/')) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        // Return cached tensor or fall back to network
        return cached || fetch(event.request);
      })
    );
  }
});

/// Background sync for telemetry reconciliation
self.addEventListener('sync', (event: SyncEvent) => {
  if (event.tag === 'telemetry-sync') {
    event.waitUntil(syncTelemetryWithCRDT());
  }
});

/**
 * Simulated local WASM DB write using Vector ID tracking.
 */
async function storeTelemetryChunk(vectorId: string, payload: unknown) {
  // In real app: write to DuckDB-WASM or similar embedded DB
  const db = await openWasmDb();
  await db.execute(
    `INSERT INTO telemetry (vector_id, data) VALUES (?, ?)`,
    [vectorId, JSON.stringify(payload)]
  );
}

/**
 * Sync locally queued telemetry to remote CRDT store.
 */
async function syncTelemetryWithCRDT() {
  const localChunks = await readLocalTelemetry();
  for (const chunk of localChunks) {
    // Reconcile using Vector ID to avoid duplicates
    await fetch('/api/telemetry/crdt', {
      method: 'POST',
      body: JSON.stringify(chunk)
    });
  }
}
