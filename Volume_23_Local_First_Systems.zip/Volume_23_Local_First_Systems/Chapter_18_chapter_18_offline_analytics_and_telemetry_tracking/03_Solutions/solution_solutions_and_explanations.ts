/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. TelemetryEvent interface with required fields
export interface TelemetryEvent {
  type: string;
  timestamp: number;
  payload: Record<string, unknown>;
  deviceId: string;
  vectorId: string; // UUID v4 or structured string
}

// 2. queueEvent function (immutable, generates Vector ID)
import { v4 as uuidv4 } from 'uuid';

export function queueEvent(event: Omit<TelemetryEvent, 'vectorId'>): TelemetryEvent {
  // Do not mutate input; create new object with generated vectorId
  const vectorId = uuidv4();
  return {
    ...event,
    vectorId,
  };
}

// 3. CRDT log structure note:
// We use an append-only grow-only set keyed by vectorId. During merge(),
// the set union is taken; because vectorId is unique per event, duplicates
// are naturally ignored. LWW could be used for corrections, but base log
// is grow-only to preserve all original events.

// 4. CrdtTelemetryLog interface (no internal logic)
export interface CrdtTelemetryLog {
  put(event: TelemetryEvent): void;
  merge(other: CrdtTelemetryLog): void;
}

// 5. Vector ID retraction explanation:
// After reconciliation, if a device must retract a mistaken event, it sends
// a tombstone or delete instruction referencing the exact vectorId. The WASM
// DB uses the vectorId to locate and remove or mark that specific chunk,
// ensuring only the erroneous entry is affected without disturbing others.
