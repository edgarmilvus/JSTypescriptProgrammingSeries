/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. AggregatedMetric interface
export interface AggregatedMetric {
  metricName: string;
  windowStart: number;
  windowEnd: number;
  value: number;
  noiseApplied: boolean;
}

// 2. Immutable QueryConfig
export type QueryConfig = {
  readonly metric: string;
  readonly groupBy: 'device' | 'session' | 'none';
  readonly timeBucket: 'hour' | 'day';
  readonly epsilon?: number;
};

// 3. runLocalAggregation signature
/**
 * Executes aggregation inside WASM DB.
 * Never returns raw telemetry rows; only AggregatedMetric[].
 */
export function runLocalAggregation(config: QueryConfig): Promise<AggregatedMetric[]> {
  // implementation omitted
  return Promise.resolve([]);
}

// 4. Service Worker registration and offline check
export async function registerAnalyticsSW(): Promise<boolean> {
  if (!('serviceWorker' in navigator)) return false;
  await navigator.serviceWorker.register('/sw.js');
  // cache-first for analytics-engine.wasm handled in sw.js
  const ready = await navigator.serviceWorker.ready;
  const cache = await caches.open('wasm-cache');
  const wasm = await cache.match('analytics-engine.wasm');
  return !!wasm;
}

// 5. Why immutable QueryConfig prevents race conditions:
// Because QueryConfig is readonly, concurrent React components each hold
// their own frozen object. No component can mutate a shared config, so
// simultaneous queries cannot interfere or corrupt each other's parameters.
