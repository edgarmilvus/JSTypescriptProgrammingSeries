/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// Feature Request Specification Only – No Solution Code
type TelemetryState = {
  readonly eventsByType: Readonly<Record<string, number>>;
  readonly lastSync: number | null;
};

type Props = {
  readonly telemetryState: Readonly<TelemetryState>;
  readonly modelCacheStatus: 'cached' | 'loading' | 'unsupported';
};

export function OfflineTelemetryDashboard({ telemetryState, modelCacheStatus }: Props) {
  // useEffect to subscribe to CRDT log (immutable updates)
  // e.g., useEffect(() => { /* subscribe, set new TelemetryState */ }, []);
  
  // Render event type table from telemetryState.eventsByType
  // using Object.entries for immutable access, no push/sort mutation
  const rows = Object.entries(telemetryState.eventsByType);

  // Show modelCacheStatus badge (Service Worker AI asset cache)
  // Comment: modelCacheStatus reflects SW caching of ONNX tensors;
  // offline on-device inference needs those weights, so badge tells
  // user if AI features are fully available offline.

  return (
    <div>
      <table>
        <tbody>
          {rows.map(([type, count]) => (
            <tr key={type}><td>{type}</td><td>{count}</td></tr>
          ))}
        </tbody>
      </table>
      <span>AI Model: {modelCacheStatus}</span>
      <span>Last Sync: {telemetryState.lastSync}</span>
    </div>
  );
}
