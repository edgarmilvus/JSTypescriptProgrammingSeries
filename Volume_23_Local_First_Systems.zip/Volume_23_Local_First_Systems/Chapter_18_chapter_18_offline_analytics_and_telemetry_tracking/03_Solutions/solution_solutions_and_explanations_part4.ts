/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Type aliases
export type VectorId = string;
export type TelemetryLogState = ReadonlyArray<Readonly<TelemetryEvent>>;

// 2. Prune function (no mutation)
export function pruneAcknowledged(
  state: TelemetryLogState,
  acked: ReadonlyArray<VectorId>
): TelemetryLogState {
  const ackSet = new Set(acked);
  return state.filter(e => !ackSet.has(e.vectorId));
}

// 3. BandwidthReporter interface
export interface BandwidthReporter {
  // used to display bandwidth savings in UI
  reportCompressionRatio(before: number, after: number): void;
}

// 4. Immutable state and recovery note:
// Because pruneAcknowledged returns a new array, the old TelemetryLogState
// remains referenced in memory. This allows undo or crash recovery by
// falling back to the un-pruned snapshot while the new one syncs.
