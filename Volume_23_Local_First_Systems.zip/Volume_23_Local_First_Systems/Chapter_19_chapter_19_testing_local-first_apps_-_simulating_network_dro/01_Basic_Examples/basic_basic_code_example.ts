/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal local-first SaaS note service simulation.
 * This example demonstrates a basic offline toggle and non-blocking I/O
 * using a mock sync layer and an in-memory local store.
 */

// ---------------------------------------------------------------------------
// Types and Interfaces
// ---------------------------------------------------------------------------

/**
 * Represents a single collaborative note in our SaaS app.
 */
interface Note {
  id: string;
  content: string;
  updatedAt: number;
}

/**
 * The contract for our mock sync layer.
 * In a real app this would talk to a server or peer-to-peer network.
 */
interface SyncLayer {
  isOnline(): boolean;
  setOnline(state: boolean): void;
  push(note: Note): Promise<void>;
}

// ---------------------------------------------------------------------------
// Mock Implementations
// ---------------------------------------------------------------------------

/**
 * A fake local store standing in for a WASM DB.
 * Uses a simple Map to simulate non-blocking local persistence.
 */
class LocalStore {
  private notes = new Map<string, Note>();

  /**
   * Save a note using non-blocking I/O simulation.
   * We use setTimeout to mimic async disk/WASM write.
   */
  async save(note: Note): Promise<void> {
    // Simulate non-blocking I/O: delegate to event loop
    await new Promise<void>((resolve) => {
      setTimeout(() => {
        this.notes.set(note.id, note);
        resolve();
      }, 0);
    });
  }

  /**
   * Retrieve a note by ID.
   */
  async get(id: string): Promise<Note | undefined> {
    return new Promise<Note | undefined>((resolve) => {
      setTimeout(() => {
        resolve(this.notes.get(id));
      }, 0);
    });
  }
}

/**
 * A mock sync layer that can be taken offline for testing.
 */
class MockSyncLayer implements SyncLayer {
  private online = true;

  isOnline(): boolean {
    return this.online;
  }

  setOnline(state: boolean): void {
    this.online = state;
  }

  /**
   * Push a note to the "server". If offline, reject to simulate failure.
   */
  async push(note: Note): Promise<void> {
    if (!this.online) {
      throw new Error('Network drop: cannot push while offline');
    }
    // Simulate network latency with non-blocking delay
    await new Promise<void>((resolve) => setTimeout(resolve, 10));
  }
}

// ---------------------------------------------------------------------------
// SaaS App Service
// ---------------------------------------------------------------------------

/**
 * The core note service used by the web app UI.
 */
class NoteService {
  constructor(
    private local: LocalStore,
    private sync: SyncLayer
  ) {}

  /**
   * Create or update a note. Always writes locally first (local-first!),
   * then attempts sync if online.
   */
  async upsertNote(id: string, content: string): Promise<void> {
    const note: Note = { id, content, updatedAt: Date.now() };

    // 1. Local non-blocking write (WASM DB would happen here)
    await this.local.save(note);

    // 2. Attempt to sync if network is available
    if (this.sync.isOnline()) {
      await this.sync.push(note);
    }
  }

  /**
   * Fetch a note for display in the SaaS dashboard.
   */
  async readNote(id: string): Promise<Note | undefined> {
    return this.local.get(id);
  }
}

// ---------------------------------------------------------------------------
// Test Harness (Hello World Level)
// ---------------------------------------------------------------------------

/**
 * Demonstrates basic offline simulation in a local-first app.
 */
async function main(): Promise<void> {
  const store = new LocalStore();
  const sync = new MockSyncLayer();
  const service = new NoteService(store, sync);

  // Scenario A: Online write
  await service.upsertNote('n1', 'Hello World');
  console.log('Online write succeeded');

  // Scenario B: Simulate network drop
  sync.setOnline(false);
  try {
    await service.upsertNote('n2', 'Offline note');
    console.log('Unexpected: write succeeded while offline');
  } catch (err) {
    console.log('Caught expected offline error:', (err as Error).message);
  }

  // Scenario C: Local read still works while offline
  const localNote = await service.readNote('n1');
  console.log('Local note available offline:', localNote?.content);
}

// Run the harness
main();
