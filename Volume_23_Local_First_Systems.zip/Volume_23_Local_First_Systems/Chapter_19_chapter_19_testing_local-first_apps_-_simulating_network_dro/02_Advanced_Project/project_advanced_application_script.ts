/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// CollabStudio – Local-First Resilience & Race Condition Test Harness
// Next.js 14+ (App Router) TypeScript utility executed in a Node test env
// or client-side via a debug panel. Simulates network drops and CRDT races.

import { CRDTDocument } from '@collab/crdt-wasm'; // WASM-backed CRDT
import { MockSyncLayer } from '@collab/test-mocks'; // Simulated sync layer
import { logResilienceEvent } from '@collab/telemetry'; // Centralized logging

/**
 * Configuration for the chaos test.
 */
interface ChaosConfig {
  dropProbability: number; // 0..1 chance sync fails mid-call
  concurrentEdits: number; // Number of parallel CRDT edits to simulate
  offlineFirst: boolean; // Start the test fully offline
}

/**
 * Result object returned after the resilience simulation completes.
 */
interface ResilienceReport {
  crdtMerged: boolean;
  aiAssetLoaded: boolean;
  syncRecovered: boolean;
  errorsCaptured: string[];
}

/**
 * Simulates a network drop by randomly throwing after a delay.
 * Used to mimic intermittent connectivity in local-first apps.
 */
async function simulateNetworkDrop(chance: number): Promise<void> {
  await new Promise((r) => setTimeout(r, 50));
  if (Math.random() < chance) {
    throw new Error('Simulated network partition during sync');
  }
}

/**
 * Loads a cached ONNX model via Service Worker cache.
 * Exhaustive resilience: try/catch/finally ensures SW registration
 * is always cleaned up even if asset fetch fails.
 */
async function loadCachedAiAsset(modelUrl: string): Promise<boolean> {
  let swRegistration: ServiceWorkerRegistration | null = null;
  try {
    swRegistration = await navigator.serviceWorker.ready;
    const cache = await caches.open('ai-assets-v1');
    const match = await cache.match(modelUrl);
    if (!match) throw new Error('AI asset not in SW cache');
    return true;
  } catch (err) {
    logResilienceEvent('ai_asset_load_failed', err);
    return false;
  } finally {
    // Always close any open SW connection references
    swRegistration = null;
  }
}

/**
 * Main chaos test entrypoint used by CollabStudio QA panel.
 */
export async function runLocalFirstChaosTest(
  cfg: ChaosConfig
): Promise<ResilienceReport> {
  const report: ResilienceReport = {
    crdtMerged: false,
    aiAssetLoaded: false,
    syncRecovered: false,
    errorsCaptured: [],
  };

  // 1. Initialize WASM CRDT document
  let doc: CRDTDocument | null = null;
  try {
    doc = new CRDTDocument('doc-123');
  } catch (err) {
    report.errorsCaptured.push(`CRDT init: ${err}`);
    return report;
  }

  // 2. Simulate concurrent edits (race conditions)
  const editPromises: Promise<void>[] = [];
  for (let i = 0; i < cfg.concurrentEdits; i++) {
    editPromises.push(
      (async () => {
        try {
          // Random offline delay to force race
          await new Promise((r) => setTimeout(r, Math.random() * 30));
          doc!.localEdit({ user: `u${i}`, text: `Edit ${i}` });
        } catch (err) {
          report.errorsCaptured.push(`Edit ${i}: ${err}`);
        }
      })()
    );
  }
  await Promise.all(editPromises);

  // 3. Attempt sync with simulated drops
  const sync = new MockSyncLayer();
  try {
    await simulateNetworkDrop(cfg.dropProbability);
    await sync.push(doc!.getState());
    report.crdtMerged = true;
  } catch (err) {
    report.errorsCaptured.push(`Sync: ${err}`);
    // Retry once to simulate reconnection
    try {
      await sync.push(doc!.getState());
      report.syncRecovered = true;
    } catch (err2) {
      report.errorsCaptured.push(`SyncRetry: ${err2}`);
    }
  } finally {
    sync.close(); // Guaranteed cleanup
  }

  // 4. Load AI asset via SW (offline ready)
  report.aiAssetLoaded = await loadCachedAiAsset('/models/llm.onnx');

  return report;
}
