/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// CRDT Operation type
type CRDTOperation = {
  id: string;        // UUID
  clientId: string;
  timestamp: number;
  payload: unknown;
};

// Seeded PRNG (mulberry32)
function makePRNG(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

class MockSyncLayer {
  private outbox: CRDTOperation[] = [];
  private applied = new Set<string>(); // idempotency
  private peers: MockSyncLayer[] = [];
  private uplink = 100;
  private downlink = 100;
  private rng: () => number;

  constructor(seed: number, private clientId: string) {
    this.rng = makePRNG(seed);
  }

  connect(peer: MockSyncLayer) {
    this.peers.push(peer);
    peer.peers.push(this);
  }

  enqueueLocalOp(op: CRDTOperation) {
    this.outbox.push(op);
  }

  setUplinkReliability(percent: number) {
    this.uplink = percent;
  }

  setDownlinkReliability(percent: number) {
    this.downlink = percent;
  }

  tick(ms: number) {
    // try flush outbox
    const remaining: CRDTOperation[] = [];
    for (const op of this.outbox) {
      if (this.rng() * 100 < this.uplink) {
        // "send" to peers
        for (const p of this.peers) {
          if (this.rng() * 100 < p.downlink) {
            p.receive(op);
          }
        }
      } else {
        remaining.push(op); // drop -> retry later
      }
    }
    this.outbox = remaining;
  }

  private receive(op: CRDTOperation) {
    if (this.applied.has(op.id)) return; // idempotent
    this.applied.add(op.id);
    // simulate local WASM DB apply
  }

  get appliedCount() {
    return this.applied.size;
  }
}

// Test (Vitest)
import { describe, it, expect } from 'vitest';

describe('MockSyncLayer convergence', () => {
  it('converges with intermittent uplink', () => {
    const a = new MockSyncLayer(1, 'A');
    const b = new MockSyncLayer(2, 'B');
    a.connect(b);

    a.setUplinkReliability(30);
    b.setUplinkReliability(30);

    for (let i = 0; i < 5; i++) {
      a.enqueueLocalOp({ id: `a${i}`, clientId: 'A', timestamp: i, payload: {} });
      b.enqueueLocalOp({ id: `b${i}`, clientId: 'B', timestamp: i, payload: {} });
      a.tick(10); b.tick(10);
    }

    a.setUplinkReliability(100);
    b.setUplinkReliability(100);
    for (let i = 0; i < 5; i++) {
      a.tick(10); b.tick(10);
    }

    expect(a.appliedCount).toBe(10);
    expect(b.appliedCount).toBe(10);
  });
});
