/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type Step = () => Promise<void>;

class DeterministicScheduler {
  private queues = new Map<string, Step[]>();
  private order: string[] = [];

  schedule(clientId: string, step: Step) {
    if (!this.queues.has(clientId)) {
      this.queues.set(clientId, []);
      this.order.push(clientId);
    }
    this.queues.get(clientId)!.push(step);
  }

  async runUntilIdle() {
    let active = true;
    while (active) {
      active = false;
      for (const id of this.order) {
        const q = this.queues.get(id)!;
        if (q.length) {
          const s = q.shift()!;
          await s();
          active = true;
        }
      }
    }
  }

  yield() {
    return Promise.resolve();
  }
}

// Fake WASM doc
class FakeDoc {
  text = '';
  insert(pos: number, s: string) { this.text = this.text.slice(0, pos) + s + this.text.slice(pos); }
}

describe('race interleaving', () => {
  it('reproduces race', async () => {
    const sched = new DeterministicScheduler();
    const docA = new FakeDoc();
    const docB = new FakeDoc();

    sched.schedule('A', async () => docA.insert(0, 'Hello'));
    sched.schedule('B', async () => docB.insert(0, 'Hello'));
    sched.schedule('A', async () => { await sched.yield(); docA.insert(5, ' World'); });
    sched.schedule('B', async () => { await sched.yield(); docB.insert(5, ' World'); });

    await sched.runUntilIdle();
    console.log(docA.text, docB.text); // both "Hello World"
  });
});
