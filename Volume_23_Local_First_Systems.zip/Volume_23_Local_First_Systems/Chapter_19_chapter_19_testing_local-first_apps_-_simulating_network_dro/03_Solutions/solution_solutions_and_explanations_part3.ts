/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

type WasmDbHandle = {
  applyOp: (op: CRDTOperation) => void;
  sync: (n: number) => void;
  close: () => void;
  outbox: CRDTOperation[];
  durable: CRDTOperation[];
};

function forceCrash(db: WasmDbHandle): void {
  (db as any)._ptr = null;
  throw new Error('simulated crash');
}

function reopen(dbFactory: () => WasmDbHandle, storage: any): WasmDbHandle {
  return dbFactory();
}

// Test sketch
it('recovers after crash', () => {
  const db = { applyOp(){}, sync(){}, close(){}, outbox:[], durable:[] } as WasmDbHandle;
  for (let i=0;i<10;i++) db.applyOp({id:`op${i}`,clientId:'x',timestamp:i,payload:{}});
  db.sync(5);
  try { forceCrash(db); } catch {}
  const t0 = performance.now();
  const db2 = reopen(()=>db, null);
  console.log('rehydrate ms', performance.now()-t0);
  expect(db2.durable.length).toBe(5);
  expect(db2.outbox.length).toBe(5);
});
