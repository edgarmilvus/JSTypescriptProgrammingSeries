/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal Edge-ready Pinecone example for a collaborative SaaS backend.
 * Demonstrates strict TypeScript usage with vector storage for project tasks.
 */

// Import the Pinecone client from the official SDK.
import { Pinecone } from "@pinecone-database/pinecone";

/**
 * Strict data contract for a task embedding record.
 * Ensures no implicit any and explicit nullability.
 */
interface TaskEmbedding {
  /** Unique ID of the task within the project board. */
  id: string;
  /** Vector representation of the task title + description. */
  values: number[];
  /** Associated metadata stored alongside the vector. */
  metadata: {
    boardId: string;
    title: string;
    assignee: string | null;
  };
}

/**
 * Environment-bound configuration.
 * Uses string literals to avoid loose typing.
 */
const PINECONE_API_KEY: string = process.env.PINECONE_API_KEY ?? "";
const INDEX_NAME: string = "project-board-embeddings";

/**
 * Initializes a Pinecone client with strict error handling.
 * @returns {Pinecone} A configured Pinecone client instance.
 */
function createPineconeClient(): Pinecone {
  if (PINECONE_API_KEY.length === 0) {
    throw new Error("Missing PINECONE_API_KEY environment variable.");
  }
  return new Pinecone({ apiKey: PINECONE_API_KEY });
}

/**
 * Upserts a single task embedding into the index.
 * @param {Pinecone} client - The Pinecone client.
 * @param {TaskEmbedding} task - The strictly typed task embedding.
 */
async function saveTaskEmbedding(
  client: Pinecone,
  task: TaskEmbedding
): Promise<void> {
  const index = client.index<TaskEmbedding["metadata"]>(INDEX_NAME);
  await index.upsert([
    {
      id: task.id,
      values: task.values,
      metadata: task.metadata,
    },
  ]);
}

/**
 * Queries similar tasks by vector in the Edge runtime.
 * @param {Pinecone} client - The Pinecone client.
 * @param {number[]} queryVector - The vector to compare against.
 * @param {string} boardId - Scope the query to a board.
 * @returns {Promise<string[]>} List of matching task IDs.
 */
async function findSimilarTasks(
  client: Pinecone,
  queryVector: number[],
  boardId: string
): Promise<string[]> {
  const index = client.index<TaskEmbedding["metadata"]>(INDEX_NAME);
  const result = await index.query({
    vector: queryVector,
    topK: 3,
    filter: { boardId: { $eq: boardId } },
    includeMetadata: false,
  });

  return result.matches.map((match) => match.id);
}

/**
 * Main entrypoint simulating an Edge function handler.
 */
async function main(): Promise<void> {
  const client = createPineconeClient();

  const sampleTask: TaskEmbedding = {
    id: "task-001",
    values: [0.1, 0.2, 0.3, 0.4],
    metadata: {
      boardId: "board-abc",
      title: "Draft Q3 roadmap",
      assignee: null,
    },
  };

  await saveTaskEmbedding(client, sampleTask);
  const similar = await findSimilarTasks(client, sampleTask.values, "board-abc");

  console.log("Similar task IDs:", similar);
}

// Execute in Edge-compatible manner (top-level await allowed in modules).
await main();
