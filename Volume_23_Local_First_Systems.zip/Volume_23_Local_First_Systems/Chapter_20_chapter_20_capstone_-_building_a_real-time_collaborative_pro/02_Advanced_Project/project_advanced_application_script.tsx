/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/board/[boardId]/page.tsx
// This file represents a Next.js App Router Client Component that hydrates
// after Server Components have rendered the initial static HTML for a board.

import * as React from "react";
// React 18+ hydration APIs allow us to attach event handlers to SSR HTML.
import { useEffect, useReducer, useRef } from "react";

// ESM import of a hypothetical CRDT library compiled to WASM.
// In a real SaaS we would use Automerge, Yjs, or a custom WASM CRDT core.
import { CRDTBoard, BoardChange } from "@localfirst/crdt-wasm";
// ESM import of a WASM embedded DB (e.g., a SQLite WASM build or IndexedDB wrapper).
import { WasmDB } from "@localfirst/wasm-db";

/**
 * JSDoc: BoardState
 * Immutable representation of a project management board after CRDT merge.
 * We never mutate this object; we replace it with a new reference on change.
 */
interface BoardState {
  readonly id: string;
  readonly columns: ReadonlyArray<{
    readonly id: string;
    readonly title: string;
    readonly cards: ReadonlyArray<{
      readonly id: string;
      readonly text: string;
    }>;
  }>;
}

/**
 * JSDoc: Action
 * Discriminated union describing immutable state transitions.
 * Reducer returns new BoardState instead of mutating old one.
 */
type Action =
  | { type: "HYDRATE"; payload: BoardState }
  | { type: "APPLY_CRDT"; payload: BoardChange };

/**
 * Reducer implementing immutable state management.
 * Every case returns a new object graph, satisfying local-first traceability.
 */
function boardReducer(state: BoardState | null, action: Action): BoardState | null {
  switch (action.type) {
    case "HYDRATE":
      // 1. Replace null with server-safe snapshot for first paint.
      return action.payload;
    case "APPLY_CRDT":
      // 2. Produce new immutable state from CRDT change set.
      return applyChangeImmutably(state!, action.payload);
    default:
      return state;
  }
}

/**
 * Helper: applyChangeImmutably
 * Demonstrates immutable update by spreading columns and cards.
 */
function applyChangeImmutably(state: BoardState, change: BoardChange): BoardState {
  // 3. Map over columns, returning new array references.
  const columns = state.columns.map((col) => {
    if (col.id !== change.columnId) return col;
    // 4. For target column, return new card array with appended card.
    return {
      ...col,
      cards: [...col.cards, { id: change.cardId, text: change.text }],
    };
  });
  // 5. Return entirely new BoardState object.
  return { ...state, columns };
}

/**
 * JSDoc: BoardClient
 * Client Component responsible for hydration and local-first sync.
 */
export default function BoardClient({ boardId }: { boardId: string }) {
  // 6. useReducer holds immutable board state after hydration.
  const [board, dispatch] = useReducer(boardReducer, null);

  // 7. Ref to CRDT document instance (WASM-backed).
  const crdtRef = useRef<CRDTBoard | null>(null);
  // 8. Ref to WASM DB used for offline persistence.
  const dbRef = useRef<WasmDB | null>(null);

  useEffect(() => {
    // 9. Hydration step: attach JS to SSR HTML and boot local-first layer.
    (async () => {
      // 10. Instantiate WASM DB (IndexedDB-backed offline store).
      dbRef.current = await WasmDB.open(`board-${boardId}`);

      // 11. Load last known snapshot from WASM DB for offline readiness.
      const snapshot = await dbRef.current.getSnapshot();

      // 12. Hydrate React with immutable state from local snapshot.
      if (snapshot) dispatch({ type: "HYDRATE", payload: snapshot });

      // 13. Create CRDT board document (WASM CRDT core).
      crdtRef.current = await CRDTBoard.load(boardId, snapshot ?? undefined);

      // 14. Subscribe to remote + local CRDT changes.
      crdtRef.current.onChange((change: BoardChange) => {
        // 15. Dispatch immutable reducer action on every CRDT update.
        dispatch({ type: "APPLY_CRDT", payload: change });
        // 16. Persist new snapshot to WASM DB for offline resilience.
        dbRef.current?.saveSnapshot(crdtRef.current!.getState());
      });
    })();
  }, [boardId]);

  // 17. Render hydrated board using immutable state.
  if (!board) return <div>Loading board…</div>;

  return (
    <div className="board">
      {board.columns.map((col) => (
        <div key={col.id} className="column">
          <h3>{col.title}</h3>
          {col.cards.map((card) => (
            <div key={card.id} className="card">
              {card.text}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
