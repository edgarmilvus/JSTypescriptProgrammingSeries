/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// tsconfig.json (excerpt): { "strict": true, "noImplicitAny": true, "strictNullChecks": true }

// 1. Branded / opaque types
type Brand<T, B> = T & { readonly __brand: B };
type BoardId = Brand<string, 'BoardId'>;
type TaskId = Brand<string, 'TaskId'>;
type ColumnId = Brand<string, 'ColumnId'>;
type UserId = Brand<string, 'UserId'>;

// 2. Task entity
interface Task {
  id: TaskId;
  title: string; // runtime max-length guard applied elsewhere
  assignee: UserId | null; // explicit null, never undefined
  completedAt: number | null; // epoch ms or null
}

// 3. Column entity
interface Column {
  title: string;
  taskIds: TaskId[];
}

// 4. Board CRDT container
interface Board {
  id: BoardId;
  columns: Record<ColumnId, Column>;
  tasks: Record<TaskId, Task>;
  updatedAt: number;
}

// 5. Runtime validation guard with branded checks
function isTask(value: unknown): value is Task {
  if (typeof value !== 'object' || value === null) return false;
  const v = value as Record<string, unknown>;
  if (typeof v.id !== 'string') return false;
  // branded check: must have __brand marker (simulated)
  if (!(v.id as any).__brand === 'TaskId') return false;
  if (typeof v.title !== 'string') return false;
  if (!(v.assignee === null || typeof v.assignee === 'string')) return false;
  if (!(v.completedAt === null || typeof v.completedAt === 'number')) return false;
  return true;
}

// 6. Compiler rejects implicit any in map:
// board.columns['c1'].taskIds.map(id => id.toUpperCase()); // id is TaskId, not any
// If we did: taskIds.map(x => x) with no type, strict noImplicitAny errors.

// 7. strictNullChecks explanation:
// With strictNullChecks, `assignee?: UserId` is not allowed; must be `| null`.
// This prevents CRDT merge treating missing field as deletion vs absence:
// a missing `assignee` (undefined) would diverge from explicit `null` (unassigned).
// Compiler forces explicit presence, so merge logic sees real state, not omitted value.
