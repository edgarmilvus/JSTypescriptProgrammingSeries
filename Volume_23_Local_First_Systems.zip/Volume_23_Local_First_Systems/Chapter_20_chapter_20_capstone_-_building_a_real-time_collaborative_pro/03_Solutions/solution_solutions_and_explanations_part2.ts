/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// From Exercise 1
type TaskId = Brand<string, 'TaskId'>;
type ColumnId = Brand<string, 'ColumnId'>;
type UserId = Brand<string, 'UserId'>;
interface Task { id: TaskId; title: string; assignee: UserId | null; completedAt: number | null; }

// 1. typeof-based guard for board meta
function isBoardMeta(v: unknown): v is { id: string; name: string } {
  return typeof v === 'object' && v !== null &&
    typeof (v as any).id === 'string' && typeof (v as any).name === 'string';
}

// 2. instanceof guard for ConflictError
class ConflictError extends Error {
  constructor(msg: string) { super(msg); this.name = 'ConflictError'; }
}
function isConflictError(e: unknown): e is ConflictError {
  return e instanceof ConflictError;
}

// 3. Discriminated union and guard
type BoardMutation =
  | { type: 'addTask'; task: Task }
  | { type: 'moveTask'; taskId: TaskId; toColumn: ColumnId; index: number }
  | { type: 'setAssignee'; taskId: TaskId; assignee: UserId | null };

function isBoardMutation(cmd: unknown): cmd is BoardMutation {
  if (typeof cmd !== 'object' || cmd === null) return false;
  const c = cmd as Record<string, unknown>;
  switch (c.type) {
    case 'addTask': return isTask(c.task);
    case 'moveTask': return typeof c.taskId === 'string' && typeof c.toColumn === 'string' && typeof c.index === 'number';
    case 'setAssignee': return typeof c.taskId === 'string' && (c.assignee === null || typeof c.assignee === 'string');
    default: return false;
  }
}

// 4. Safe write
type WriteError = { reason: string };
type Result<T, E> = { ok: true; value: T } | { ok: false; error: E };
declare const wasmDb: { put(cmd: BoardMutation): void };
function safeWrite(db: typeof wasmDb, cmd: unknown): Result<void, WriteError> {
  if (!isBoardMutation(cmd)) return { ok: false, error: { reason: 'Invalid mutation' } };
  db.put(cmd); // type-confident
  return { ok: true, value: undefined };
}

// 5. V8 isolate comment:
// Guarded objects have stable hidden classes because shape is known; unguarded
// objects may mutate shape, causing deoptimization in the isolate.
