/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Reuse isBoardMutation from Exercise 2
type BoardMutation = /* ... */;

// 1. EdgeSyncRequest wraps Request
type EdgeSyncRequest = Request & { batch: unknown[] };
// 2. EdgeSyncResponse discriminated
type EdgeSyncResponse =
  | { status: 'ok' }
  | { status: 'partial'; failed: { index: number; reason: string }[] }
  | { status: 'rejected'; error: string };

// 3. Handler
export async function sync(req: EdgeSyncRequest): Promise<Response> {
  const raw: unknown = await req.json().catch(() => null);
  const batch = Array.isArray(raw) ? raw : [];
  const failed: { index: number; reason: string }[] = [];
  batch.forEach((item, i) => {
    if (!isBoardMutation(item)) failed.push({ index: i, reason: 'bad shape' });
  });
  let body: EdgeSyncResponse;
  if (failed.length === 0) body = { status: 'ok' };
  else if (failed.length < batch.length) body = { status: 'partial', failed };
  else body = { status: 'rejected', error: 'all invalid' };
  return Response.json(body);
}

// 5. Tree-shakeable type-only imports keep edge bundle small.
// 6. strictNullChecks: Response.json() returns Promise<unknown>, forcing narrow.
