/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

type UserId = Brand<string, 'UserId'>;
type BoardId = Brand<string, 'BoardId'>;

// 1. PresenceUser
type PresenceUser = { userId: UserId; name: string; color: string; lastSeen: number };

// 2. Hook result
type UsePresenceResult = { users: PresenceUser[]; error?: string };
declare function useBoardPresence(boardId: BoardId): UsePresenceResult;

// 3. Guard and component
function isPresenceUser(u: unknown): u is PresenceUser {
  return typeof u === 'object' && u !== null &&
    typeof (u as any).userId === 'string' &&
    typeof (u as any).name === 'string' &&
    typeof (u as any).color === 'string' &&
    typeof (u as any).lastSeen === 'number';
}

export function PresenceAvatarStack({ boardId, max = 5 }: { boardId: BoardId; max?: number }) {
  const { users } = useBoardPresence(boardId);
  const safe = users.filter(isPresenceUser);
  const shown = safe.slice(0, max);
  const overflow = safe.length - shown.length;
  return (
    <div>
      {shown.map(u => <span key={u.userId} style={{ background: u.color }}>{u.name?.slice(0,1)}</span>)}
      {overflow > 0 && <span>+{overflow}</span>}
    </div>
  );
}
// 4. Subscribes only to presence CRDT map, not board doc, avoiding full re-render.
