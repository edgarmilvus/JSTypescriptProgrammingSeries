/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

type BoardId = Brand<string, 'BoardId'>;
type LatencyMs = Brand<number, 'LatencyMs'>;
type ConflictCount = Brand<number, 'ConflictCount'>;
type TelemetryTimestamp = Brand<number, 'TelemetryTimestamp'>;

type BoardTelemetry =
  | { kind: 'latency'; boardId: BoardId; value: LatencyMs; at: TelemetryTimestamp }
  | { kind: 'conflict'; boardId: BoardId; value: ConflictCount; at: TelemetryTimestamp };

function isBoardTelemetry(x: unknown): x is BoardTelemetry {
  if (typeof x !== 'object' || x === null) return false;
  const o = x as Record<string, unknown>;
  if (o.kind !== 'latency' && o.kind !== 'conflict') return false;
  return typeof o.boardId === 'string' && typeof o.value === 'number' && typeof o.at === 'number';
}

function emitTelemetry(e: BoardTelemetry): void {
  fetch('/analytics', { method: 'POST', body: JSON.stringify(e) });
}
// 5. Brands stop LatencyMs used as ConflictCount in WASM+Edge.
// 6. strictNullChecks: `at` required, never omitted accidentally.
