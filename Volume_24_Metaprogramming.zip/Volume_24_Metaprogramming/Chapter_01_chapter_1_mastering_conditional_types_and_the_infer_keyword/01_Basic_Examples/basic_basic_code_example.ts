/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Billing Context
 * 
 * We simulate an API response wrapper that may or may not be a Promise.
 */

// 1. Define a generic utility type that extracts the inner type of a Promise
/**
 * @type UnwrapPromise
 * @description Given a type T, if T is a Promise of U, return U; otherwise return T.
 * This uses a conditional type with the `infer` keyword to capture the inner type.
 */
type UnwrapPromise<T> = T extends Promise<infer U> ? U : T;

// 2. Simulate a SaaS billing record shape
/**
 * @interface BillingRecord
 * @description The resolved payload from our billing service.
 */
interface BillingRecord {
  id: string;
  amount: number;
  currency: string;
}

// 3. A function that returns a Promise of a BillingRecord (typical async API)
/**
 * @function fetchBillingRecord
 * @description Mimics an async call to a SaaS billing microservice.
 * @returns Promise<BillingRecord>
 */
function fetchBillingRecord(): Promise<BillingRecord> {
  return Promise.resolve({ id: "inv_123", amount: 49.99, currency: "USD" });
}

// 4. Use the conditional type to extract the resolved type
/**
 * @type ResolvedBilling
 * @description ResolvedBilling evaluates to BillingRecord because fetchBillingRecord returns a Promise<BillingRecord>.
 */
type ResolvedBilling = UnwrapPromise<ReturnType<typeof fetchBillingRecord>>;

// 5. A consumer function that uses the extracted type
/**
 * @function logBilling
 * @description Takes the resolved billing record and logs it.
 * @param record The unwrapped billing record.
 */
function logBilling(record: ResolvedBilling): void {
  // TypeScript knows `record` is BillingRecord, not a Promise
  console.log(`Invoice ${record.id} for ${record.amount} ${record.currency}`);
}

// 6. Execute the flow
fetchBillingRecord().then(logBilling);
