/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script: Conditional Types & Infer in a SaaS Event Pipeline
 * Context: Next.js analytics dashboard consuming mixed async data sources.
 */

// -----------------------------------------------------------------------------
// 1. CORE UTILITY TYPES USING CONDITIONAL TYPES AND INFER
// -----------------------------------------------------------------------------

/**
 * Extracts the resolved value type from any Promise-like structure.
 * If T is a Promise<U>, we infer U; otherwise we return T unchanged.
 */
type Unwrap<T> = T extends Promise<infer U> ? U : T;

/**
 * Recursively unwraps nested promises (common in chained async SaaS APIs).
 */
type DeepUnwrap<T> = T extends Promise<infer U> ? DeepUnwrap<U> : T;

/**
 * Extracts the payload type from a standard SaaS API envelope.
 * Envelope shape: { data: X; meta: {...} }
 */
type ExtractData<T> = T extends { data: infer D } ? D : never;

/**
 * Distributive conditional type to handle union of response shapes.
 * Maps over each member of T to extract its data payload.
 */
type AllPayloads<T> = T extends any ? ExtractData<T> : never;

// -----------------------------------------------------------------------------
// 2. DOMAIN MODELS FOR A SaaS ANALYTICS PLATFORM
// -----------------------------------------------------------------------------

/** Interface defining a REST analytics response envelope */
interface RestAnalyticsResponse {
  data: {
    userId: string;
    sessions: number;
    revenue: number;
  };
  meta: { latencyMs: number };
}

/** Interface defining a GraphQL-style response (promised) */
interface GraphQLAnalyticsResponse {
  data: {
    organization: {
      id: string;
      activeUsers: number;
    };
  };
  errors?: string[];
}

/** Interface for a WebSocket stream message (already resolved) */
interface WsRealtimeEvent {
  data: {
    eventType: 'click' | 'view';
    timestamp: number;
  };
}

// -----------------------------------------------------------------------------
// 3. SIMULATED ASYNC FETCHERS (NEXT.JS SERVER OR CLIENT SIDE)
// -----------------------------------------------------------------------------

/**
 * Simulates a REST call returning a promise of analytics data.
 */
async function fetchRestAnalytics(): Promise<RestAnalyticsResponse> {
  return {
    data: { userId: 'u_1', sessions: 12, revenue: 499.99 },
    meta: { latencyMs: 42 }
  };
}

/**
 * Simulates a GraphQL query that resolves to a promised payload.
 */
async function queryGraphQLAnalytics(): Promise<GraphQLAnalyticsResponse> {
  return {
    data: { organization: { id: 'org_9', activeUsers: 134 } }
  };
}

/**
 * Simulates a WebSocket message resolver (non-promised).
 */
function onWsEvent(): WsRealtimeEvent {
  return { data: { eventType: 'view', timestamp: Date.now() } };
}

// -----------------------------------------------------------------------------
// 4. TYPE-LEVEL ORCHESTRATION OF HETEROGENEOUS SOURCES
// -----------------------------------------------------------------------------

/**
 * Union of all possible raw responses in the system.
 */
type RawAnalyticsUnion =
  | RestAnalyticsResponse
  | Promise<GraphQLAnalyticsResponse>
  | WsRealtimeEvent;

/**
 * Using conditional + infer to build a normalized payload union:
 * 1. DeepUnwrap removes promises
 * 2. ExtractData pulls out the `data` field
 */
type NormalizedAnalytics = ExtractData<DeepUnwrap<RawAnalyticsUnion>>;

// NormalizedAnalytics resolves to:
//  | { userId: string; sessions: number; revenue: number }
//  | { organization: { id: string; activeUsers: number } }
//  | { eventType: 'click' | 'view'; timestamp: number }

// -----------------------------------------------------------------------------
// 5. RUNTIME INGESTION PIPELINE (NEXT.JS API ROUTE OR HOOK)
// -----------------------------------------------------------------------------

/**
 * Safely resolves any raw source and normalizes its payload.
 * The return type is inferred from our conditional utilities.
 */
async function ingestAnalytics(): Promise<NormalizedAnalytics[]> {
  const rest = await fetchRestAnalytics();          // Promise<RestAnalyticsResponse>
  const graphql = await queryGraphQLAnalytics();    // Promise<GraphQLAnalyticsResponse>
  const ws = onWsEvent();                           // WsRealtimeEvent

  // Manually align at runtime; types guarantee shape correctness
  const normalized: NormalizedAnalytics[] = [
    rest.data,
    graphql.data,
    ws.data
  ];

  return normalized;
}

// -----------------------------------------------------------------------------
// 6. NEXT.JS REACT COMPONENT CONSUMER (TSX)
// -----------------------------------------------------------------------------

/**
 * Dashboard component that renders normalized analytics.
 * Demonstrates end-to-end type safety from fetch to UI.
 */
export default function AnalyticsDashboard() {
  // In a real app, this would be a useEffect + useState or SWR hook
  const dummy: NormalizedAnalytics[] = [
    { userId: 'u_2', sessions: 3, revenue: 0 },
    { organization: { id: 'org_2', activeUsers: 9 } },
    { eventType: 'click', timestamp: 123 }
  ];

  return (
    <ul>
      {dummy.map((item, idx) => (
        <li key={idx}>
          {/* Type narrowing via conditional checks at runtime */}
          {'userId' in item && <span>User Sessions: {item.sessions}</span>}
          {'organization' in item && (
            <span>Org Active Users: {item.organization.activeUsers}</span>
          )}
          {'eventType' in item && <span>Event: {item.eventType}</span>}
        </li>
      ))}
    </ul>
  );
}
