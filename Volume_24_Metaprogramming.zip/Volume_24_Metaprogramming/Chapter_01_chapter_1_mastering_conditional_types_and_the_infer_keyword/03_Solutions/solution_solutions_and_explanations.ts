/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// UnwrapPromise: shallow unwrap of a single Promise layer
// `infer` is necessary here because we need to capture the inner type U of Promise<U>.
// If we used `T extends Promise<any>` without `infer`, we could only know that T is a Promise,
// but we could not extract and return the specific inner type; we'd lose type information.
// We support PromiseLike as well to cover thenable objects commonly used in async code.
export type UnwrapPromise<T> = 
  T extends PromiseLike<infer U> ? U : T;

// DeepUnwrapPromise: recursively removes all Promise/PromiseLike layers
export type DeepUnwrapPromise<T> = 
  T extends PromiseLike<infer U> ? DeepUnwrapPromise<U> : T;

// Type-level demonstrations (no runtime code)
type Test1 = UnwrapPromise<Promise<string>>;      // string
type Test2 = UnwrapPromise<number>;               // number
type Test3 = UnwrapPromise<Promise<Promise<boolean>>>; // Promise<boolean> (shallow)
type Test4 = DeepUnwrapPromise<Promise<Promise<boolean>>>; // boolean (deep)

// Note: PromiseLike<T> is supported because many async abstractions (e.g., custom thenables)
// implement PromiseLike but not the full Promise interface. Using PromiseLike makes the
// utility more robust in real-world code.
