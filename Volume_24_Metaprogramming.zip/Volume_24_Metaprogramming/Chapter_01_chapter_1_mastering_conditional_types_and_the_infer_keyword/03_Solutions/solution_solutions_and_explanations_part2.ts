/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Reuse shallow unwrap from Exercise 1 concept (local definition)
type UnwrapPromise<T> = T extends PromiseLike<infer U> ? U : T;

// Extract parameter tuple from a function, or never if not a function
export type FunctionParameters<F> = 
  F extends (...args: infer A) => any ? A : never;

// Extract return type and unwrap Promise if present
export type FunctionReturnType<F> = 
  F extends (...args: any) => infer R ? UnwrapPromise<R> : never;

// Check if function returns a Promise/PromiseLike
export type IsAsyncFunction<F> = 
  F extends (...args: any) => infer R 
    ? R extends PromiseLike<unknown> ? true : false 
    : never;

// Type-level tests
type User = { id: number };
type P1 = FunctionParameters<(a: string, b: number) => void>; // [string, number]
type R1 = FunctionReturnType<() => Promise<User>>;             // User
type A1 = IsAsyncFunction<() => number>;                      // false

// Pedagogical note: Built-in Parameters<T> and ReturnType<T> are similar but ReturnType
// does not unwrap promises. Re-implementing teaches conditional inference and custom unwrapping.
// Edge case: non-function input resolves to never (e.g., FunctionParameters<string> = never).
