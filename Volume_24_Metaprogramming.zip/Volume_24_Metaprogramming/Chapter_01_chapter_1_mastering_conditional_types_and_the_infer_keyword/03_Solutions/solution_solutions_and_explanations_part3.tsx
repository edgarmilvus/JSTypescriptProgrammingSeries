/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// Utility to unwrap promise (local)
type Unwrap<T> = T extends PromiseLike<infer U> ? U : T;

// Infer resolved data type D from loader L
type ResolvedData<L> = L extends (...args: any) => infer R ? Unwrap<R> : never;

// Compute status union based on whether loader returns Promise
type StatusType<L> = L extends (...args: any) => infer R
  ? R extends PromiseLike<unknown> ? 'loading' | 'ready' : 'ready'
  : never;

type SafeDataViewProps<L> = {
  loader: L;
  render: (data: ResolvedData<L>, status: StatusType<L>) => React.ReactNode;
};

// Component contract only (no impl)
declare function SafeDataView<L>(props: SafeDataViewProps<L>): JSX.Element;

// Mock usage (typed JSX, no logic)
type User = { name: string };
const SyncExample = (
  <SafeDataView
    loader={() => ['a', 'b']}
    render={(data, status) => <span>{data.join(',')} {status}</span>}
  />
);

const AsyncExample = (
  <SafeDataView
    loader={() => Promise.resolve({ name: 'Alice' } as User)}
    render={(data, status) => <span>{data.name} {status}</span>}
  />
);

// `infer` is used in ResolvedData and StatusType to extract R from L's return.
// Distributive conditionals could explode prop unions if L is a union of functions;
// boxing [L] would prevent that if needed. This pattern avoids `any` states.
