/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Distributive: naked T distributes over unions
export type DistributiveToString<T> = 
  T extends any ? `value:${string}` : never; // simplified consistent mapping

// Non-distributive: boxed [T] prevents distribution
export type StrictToString<T> = 
  [T] extends [any] ? `value:${string}` : never;

type D1 = DistributiveToString<string | number | boolean>; // `value:${string}` (union of same)
type S1 = StrictToString<string | number | boolean>;        // `value:${string}` (single)

// Nullable variants
export type Nullable<T> = T | null; // distributive by default on T
export type StrictNullable<T> = T | null; // if T is union, boxes via [T] in conditional would differ

// Actually show algebra:
type Union = string | number;
type DistNull = Nullable<Union>;        // string | number | null
type StrictNull = Union | null;         // same here, but if using [T] extends [Union] pattern it stays grouped

// `infer` inside distributive vs non-distributive:
// Distributive: Array<infer U> on (string[] | number[]) yields string | number
// Non-distributive: [T] extends [Array<infer U>] yields U for whole union if homogeneous
