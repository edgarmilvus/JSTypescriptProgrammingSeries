/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS User Profile - Basic Type Gymnastics Example
 * Demonstrates Mapped Types, Key Remapping, Template Literal Types,
 * Zod Schemas, Utility Types, and Type Narrowing.
 */

// 1. Import Zod for runtime validation and type inference
import { z } from 'zod';

// -----------------------------------------------------------------------------
// SECTION A: Zod Schema & Base Type Inference
// -----------------------------------------------------------------------------

/**
 * Zod Schema defining the expected shape of a user from an auth API.
 * This acts as a single source of truth for both runtime validation
 * and compile-time types.
 */
const UserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  isActive: z.boolean(),
  role: z.enum(['admin', 'member', 'guest']),
});

// Infer the TypeScript type directly from the Zod schema.
// This is a Utility-Type-like operation provided by Zod (z.infer).
type User = z.infer<typeof UserSchema>;

// -----------------------------------------------------------------------------
// SECTION B: Mapped Type (Readonly View for Cache)
// -----------------------------------------------------------------------------

/**
 * A mapped type that takes any object type T and returns a new type
 * where every property is marked as readonly. This is similar to the
 * built-in Utility Type Readonly<T>, but written manually to show the mechanics.
 *
 * [K in keyof T]: iterates over every key in T.
 * readonly: prefix makes the property immutable.
 * T[K]: preserves the original type of the property.
 */
type ManualReadonly<T> = {
  readonly [K in keyof T]: T[K];
};

// Apply our mapped type to the inferred User type.
// In a SaaS app, this could represent a cached, immutable user snapshot.
type CachedUser = ManualReadonly<User>;

// -----------------------------------------------------------------------------
// SECTION C: Key Remapping (Prefixing for DB DTO)
// -----------------------------------------------------------------------------

/**
 * Key remapping using the `as` clause.
 * We iterate over keys of T, but instead of keeping the original key name,
 * we use a Template Literal Type to prefix it with "db_".
 * This is useful when mapping domain models to database DTOs.
 */
type WithDbPrefix<T> = {
  [K in keyof T as `db_${string & K}`]: T[K];
};

// Resulting type: { db_id: string; db_email: string; ... }
type DbUserDTO = WithDbPrefix<User>;

// -----------------------------------------------------------------------------
// SECTION D: Template Literal Types (Event Names)
// -----------------------------------------------------------------------------

/**
 * Template Literal Types allow us to construct string types like string interpolation.
 * Here we create a union of possible analytics event names based on user roles.
 */
type UserRole = User['role']; // 'admin' | 'member' | 'guest'
type UserEvent = `user_${UserRole}_action`; // 'user_admin_action' | 'user_member_action' | 'user_guest_action'

// -----------------------------------------------------------------------------
// SECTION E: Runtime Validation & Type Narrowing
// -----------------------------------------------------------------------------

/**
 * Simulated API payload (e.g., from a fetch call to /api/user)
 */
const rawApiPayload: unknown = {
  id: '123e4567-e89b-12d3-a456-426614174000',
  email: 'dev@saas.app',
  isActive: true,
  role: 'admin',
};

/**
 * Function that validates the payload and returns a strongly typed User.
 * Uses Type Narrowing via Zod's parse (which throws if invalid).
 */
function authenticateUser(data: unknown): User {
  // Type Guard / Runtime check: Zod refines `unknown` to `User`
  const validated = UserSchema.parse(data);
  return validated;
}

// -----------------------------------------------------------------------------
// SECTION F: Putting It Together (Self-Contained Execution)
// -----------------------------------------------------------------------------

// 1. Validate and narrow the type
const currentUser: User = authenticateUser(rawApiPayload);

// 2. Create a cached (readonly) version using our mapped type
const cachedUser: CachedUser = {
  id: currentUser.id,
  email: currentUser.email,
  isActive: currentUser.isActive,
  role: currentUser.role,
};

// 3. Create a DB DTO using key remapping
const dbPayload: DbUserDTO = {
  db_id: currentUser.id,
  db_email: currentUser.email,
  db_isActive: currentUser.isActive,
  db_role: currentUser.role,
};

// 4. Use Template Literal Type for an event
const analyticsEvent: UserEvent = `user_${currentUser.role}_action`;

// 5. Demonstrate Type Narrowing in a conditional block
function handleRoleSpecificLogic(user: User): string {
  // Type Guard: typeof user.role === 'admin' narrows the literal type
  if (user.role === 'admin') {
    // Inside this block, TS knows user.role is 'admin'
    return `Welcome admin ${user.email}`;
  } else {
    // Here, user.role is narrowed to 'member' | 'guest'
    return `Welcome user ${user.email}`;
  }
}

// Console output to prove the concept works at runtime
console.log('Cached User:', cachedUser);
console.log('DB DTO:', dbPayload);
console.log('Analytics Event:', analyticsEvent);
console.log('Role Logic:', handleRoleSpecificLogic(currentUser));
