/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// Next.js / TypeScript strict-mode utility for dashboard state projection
// tsconfig.json must include: "strict": true, "strictNullChecks": true

/**
 * The canonical GraphState passed between LangGraph nodes.
 * Strict Type Discipline: no implicit any, all fields explicitly typed.
 */
interface GraphState {
  userId: string;
  planTier: 'free' | 'pro' | 'enterprise';
  monthlyRevenue: number;
  lastSessionAt: Date | null;
  isTrialActive: boolean;
}

/**
 * Mapped type with key remapping and template literal types.
 * - Iterates over every key `K` in `GraphState`
 * - Remaps key to `ui_${K}` using template literal type
 * - Enforces readonly + strict nullability for public layer
 */
type PublicDashboardState = {
  readonly [K in keyof GraphState as `ui_${K}`]: GraphState[K] | null;
};

/**
 * Generates dynamic event handler names using template literal types.
 * For each remapped key, produce `onUiChange<OriginalKey>`.
 */
type UiChangeHandlers = {
  [K in keyof GraphState as `onUiChange${Capitalize<K>}`]: (
    value: GraphState[K] | null
  ) => void;
};

/**
 * Assembles the full view-model consumed by the React component.
 */
type DashboardViewModel = PublicDashboardState & UiChangeHandlers;

/**
 * Simulated LangGraph node output (Graph State).
 */
const internalGraphState: GraphState = {
  userId: 'usr_9921',
  planTier: 'pro',
  monthlyRevenue: 499,
  lastSessionAt: new Date(),
  isTrialActive: false,
};

/**
 * Projects internal state into public view-model.
 * Type narrowing ensures null-safety under strictNullChecks.
 */
function projectToPublic(state: GraphState): PublicDashboardState {
  // Mapped runtime projection mirroring the type-level mapping
  const projected = {} as PublicDashboardState;
  (Object.keys(state) as (keyof GraphState)[]).forEach((k) => {
    // Template literal key construction at runtime
    const publicKey = `ui_${k}` as keyof PublicDashboardState;
    // Strict null assignment allowed due to | null in mapped type
    (projected as Record<string, unknown>)[publicKey] = state[k] ?? null;
  });
  return projected;
}

/**
 * Next.js Server Component receiving the GraphState.
 */
export async function getDashboardViewModel(): Promise<DashboardViewModel> {
  const publicState = projectToPublic(internalGraphState);

  // Build handler stubs using template literal key patterns
  const handlers = {
    onUiChangeUserId: (v: string | null) => console.log('userId', v),
    onUiChangePlanTier: (v: GraphState['planTier'] | null) =>
      console.log('plan', v),
    onUiChangeMonthlyRevenue: (v: number | null) => console.log('rev', v),
    onUiChangeLastSessionAt: (v: Date | null) => console.log('sess', v),
    onUiChangeIsTrialActive: (v: boolean | null) => console.log('trial', v),
  };

  return { ...publicState, ...handlers };
}

/**
 * Client Component consuming the strictly typed view-model.
 */
export function DashboardView(model: DashboardViewModel) {
  // Type narrowing on possibly-null fields
  const revenue = model.ui_monthlyRevenue;
  if (revenue !== null) {
    // Safe numeric operation due to narrowing
    return `<div>Revenue: ${revenue.toFixed(2)}</div>`;
  }
  return `<div>No revenue data</div>`;
}
