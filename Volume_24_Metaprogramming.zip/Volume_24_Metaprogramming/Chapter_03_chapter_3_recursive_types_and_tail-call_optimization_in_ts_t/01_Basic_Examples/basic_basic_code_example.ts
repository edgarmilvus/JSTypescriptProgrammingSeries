/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// @filename: saas-string-utils.ts
// ESM-style module for a fictional SaaS web app backend utility.

/**
 * Reverses a string literal type character by character at the type level.
 * Used in a SaaS app to normalize reversed audit-log tokens before storage.
 */
type ReverseString<S extends string> =
  S extends `${infer First}${infer Rest}`
    ? `${ReverseString<Rest>}${First}`
    : S;

/**
 * Demo function that simply returns the input string.
 * The type system guarantees the literal type is reversed in typing only.
 */
export function reverseToken<T extends string>(token: T): ReverseString<T> {
  // Runtime implementation is naive; this is a type-gymnastics demo.
  return token.split('').reverse().join('') as ReverseString<T>;
}

// Example usage in a web app context:
const originalToken = 'abc123';
const reversed = reverseToken(originalToken);

// `reversed` is typed as '321cba' thanks to recursive type evaluation.
export type ReversedDemo = typeof reversed; // '321cba'
