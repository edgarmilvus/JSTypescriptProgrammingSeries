/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * SaaS Role Permission Tree — Advanced Recursive Type Demonstration
 * Context: Multi-tenant dashboard where roles contain nested sub-role permissions.
 */

import { z } from "zod";
import type { NextApiRequest, NextApiResponse } from "next";

/* ------------------------------------------------------------------ */
/* 1. TAIL-CALL-OPTIMIZED RECURSIVE TYPE DEFINITION                    */
/* ------------------------------------------------------------------ */

/**
 * Tuple-based accumulator pattern to mimic Tail-Call Optimization (TCO)
 * at the type level. Instead of naive recursion `type T = ... | T`,
 * we thread an accumulator to keep instantiation depth flat.
 */
type Prev = [never, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

/**
 * Internal helper: builds a recursive permission node up to Depth limit.
 * @param Depth remaining allowed nesting depth (prevents infinite instantiation)
 */
type PermissionNodeInner<Depth extends number> =
  Depth extends 0
    ? boolean
    : boolean | {
        [key: string]: PermissionNodeInner<Prev[Depth]>;
      };

/**
 * Public type: starts with a safe max depth of 10.
 * This avoids "Type instantiation is excessively deep" compiler errors.
 */
export type RolePermissionTree = PermissionNodeInner<10>;

/* ------------------------------------------------------------------ */
/* 2. RUNTIME VALIDATION SCHEMA (Zod) MIRRORING TYPE                   */
/* ------------------------------------------------------------------ */

/**
 * Zod schema using .lazy() to support cyclical/recursive validation.
 * Runtime checks are mandatory because external API payloads are untrusted.
 */
const permissionNodeSchema: z.ZodType<RolePermissionTree> = z.lazy(() =>
  z.union([
    z.boolean(),
    z.record(z.string(), permissionNodeSchema),
  ])
);

/* ------------------------------------------------------------------ */
/* 3. TYPE GUARD FOR NARROWING AT RUNTIME                              */
/* ------------------------------------------------------------------ */

/**
 * User-defined type guard using `value is` for safe narrowing.
 * @param val unknown input from request body
 */
export function isRolePermissionTree(
  val: unknown
): val is RolePermissionTree {
  return permissionNodeSchema.safeParse(val).success;
}

/* ------------------------------------------------------------------ */
/* 4. NEXT.JS API ROUTE USING RECURSIVE TYPES                          */
/* ------------------------------------------------------------------ */

/**
 * POST /api/roles/validate
 * Validates incoming permission tree from frontend SaaS client.
 */
export default function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 1. Extract raw payload (untrusted external input)
  const body = req.body;

  // 2. Runtime validation via Zod (compile-time types are erased)
  if (!isRolePermissionTree(body)) {
    return res.status(400).json({ error: "Invalid permission structure" });
  }

  // 3. Type narrowing now allows safe recursive traversal
  const normalized = normalizeTree(body);

  // 4. Return sanitized config to client
  return res.status(200).json({ normalized });
}

/* ------------------------------------------------------------------ */
/* 5. TAIL-RECURSIVE RUNTIME NORMALIZER (Mimics Type-Level TCO)        */
/* ------------------------------------------------------------------ */

/**
 * Flattens nested `true` booleans into explicit grant list.
 * Uses explicit accumulator to avoid call-stack overflow (TCO style).
 */
function normalizeTree(
  tree: RolePermissionTree,
  path: string[] = [],
  acc: string[] = []
): string[] {
  // Base case: boolean leaf
  if (typeof tree === "boolean") {
    if (tree) acc.push(path.join("."));
    return acc;
  }
  // Recursive case: iterate nested keys (tail position via accumulator)
  for (const key of Object.keys(tree)) {
    normalizeTree(tree[key], [...path, key], acc);
  }
  return acc;
}
