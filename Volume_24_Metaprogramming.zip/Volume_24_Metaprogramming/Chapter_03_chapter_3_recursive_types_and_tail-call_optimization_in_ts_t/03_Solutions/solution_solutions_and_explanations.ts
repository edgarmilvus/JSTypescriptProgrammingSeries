/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Sample enterprise config (>=15 levels nested)
type EnterpriseConfig = {
  region: {
    eu: {
      cache: {
        redis: {
          ttl: {
            short: {
              value: {
                ms: {
                  default: {
                    override: {
                      flag: {
                        enabled: {
                          meta: {
                            owner: {
                              team: {
                                name: string;
                              };
                            };
                          };
                        };
                      };
                    };
                  };
                };
              };
            };
          };
        };
      };
    };
  };
};

// Recursive conditional counting of nesting depth
// This is "stack-like": each level adds a +1 before recursing, so compiler
// must hold intermediate sums -> stresses instantiation depth linearly.
type DepthEstimate<T, Acc extends number = 0> =
  T extends object
    ? T extends readonly unknown[]
      ? DepthEstimate<T[number], Increment<Acc>>
      : { [K in keyof T]: DepthEstimate<T[K], Increment<Acc>> }[keyof T]
    : Acc;

// Helper to bump a tuple-length-based number (safe small counter)
type Increment<N extends number, T extends unknown[] = []> =
  N extends T['length'] ? [...T, unknown]['length'] : Increment<N, [...T, unknown]>;

// DeepKeys: tail-position recursion on accumulators to aid caching
type DeepKeys<T, Prefix extends string = ""> =
  T extends readonly unknown[]
    ? // array/tuple: index paths like items.0.name
      T extends [infer Head, ...infer Tail]
        ? DeepKeys<Head, `${Prefix}0`> | DeepKeys<Tail, Prefix> // non-tail mix for demo
        : never
    : T extends object
      ? T extends infer O
        ? { [K in keyof O]:
            K extends string
              ? O[K] extends object
                // recursive call in conditional branch (stack-like for objects)
                ? `${Prefix}${K}` | DeepKeys<O[K], `${Prefix}${K}.`>
                : `${Prefix}${K}`
              : never }[keyof O]
        : never
      : Prefix;

// Demonstration of intent
type ConfigKeys = DeepKeys<EnterpriseConfig>;
