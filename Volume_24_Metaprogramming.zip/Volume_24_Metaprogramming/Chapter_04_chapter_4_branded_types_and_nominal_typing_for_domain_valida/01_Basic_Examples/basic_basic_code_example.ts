/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Context:
 * We are building a multi-tenant web app.
 * We want to ensure that a UserId is never confused with a TenantId,
 * even though both are stored as strings at runtime.
 */

// 1. Define a unique symbol to act as our brand marker.
// Symbols are unique and cannot be recreated, making them ideal for branding.
declare const userIdBrand: unique symbol;

/**
 * 2. Create the Branded Type using an intersection.
 * We intersect `string` with an object containing our brand symbol.
 * This makes `UserId` assignable ONLY from a value that has been explicitly cast.
 */
type UserId = string & { readonly [userIdBrand]: true };

/**
 * 3. Ergonomic constructor function.
 * This acts as the ONLY safe way to create a UserId in our app.
 * In a real SaaS app, this would include regex or UUID validation.
 * @param rawId - The raw string from the database or API
 * @returns A branded UserId
 */
function createUserId(rawId: string): UserId {
  // Runtime check (simplified for Hello World)
  if (typeof rawId !== 'string' || rawId.length === 0) {
    throw new Error('Invalid UserId format');
  }
  // Cast through unknown to bypass structural checks (safe because we validated)
  return rawId as unknown as UserId;
}

/**
 * 4. Type guard to narrow types at runtime.
 * @param value - Unknown input
 * @returns Boolean indicating if value is a branded UserId
 */
function isUserId(value: unknown): value is UserId {
  return typeof value === 'string' && (value as UserId)[userIdBrand] === true;
}

// 5. Simulate a SaaS service function
function getUserName(id: UserId): string {
  // Pretend we look up the user in a DB
  return `User-${id}`;
}

// 6. Usage in a web route handler (simulated)
const rawFromRequest = 'usr_12345';
const brandedId = createUserId(rawFromRequest);

console.log(getUserName(brandedId)); // ✅ Works
// console.log(getUserName('usr_12345')); // ❌ Compile error: string not assignable to UserId

// 7. Demonstrate Type Narrowing with the guard
const maybeId: unknown = 'usr_999';
if (isUserId(maybeId)) {
  // Inside this block, TS knows maybeId is UserId
  console.log(getUserName(maybeId));
}
