/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// Advanced Application Script: Branded Types in a Next.js SaaS Billing Context
// Demonstrates nominal typing, Zod runtime validation, and ESM architecture.
// ============================================================================

import { z } from 'zod'; // Zod for runtime schema validation and type inference

/**
 * Branded type helper.
 * Uses intersection with a unique symbolic tag to create nominal-like types.
 */
type Brand<T, B extends string> = T & { readonly __brand: B };

// ----------------------------------------------------------------------------
// 1. Define Branded Domain Primitives
// ----------------------------------------------------------------------------

/** A UserId is a string branded to prevent confusion with other IDs. */
type UserId = Brand<string, 'UserId'>;

/** A TenantId identifies a SaaS organization account. */
type TenantId = Brand<string, 'TenantId'>;

/** A PlanId identifies a subscription plan. */
type PlanId = Brand<string, 'PlanId'>;

// ----------------------------------------------------------------------------
// 2. Ergonomic Constructors with Runtime Validation
// ----------------------------------------------------------------------------

/**
 * Safely constructs a UserId from a raw string.
 * Throws if the value is not a valid UUID-like identifier.
 */
function createUserId(raw: string): UserId {
  // Basic runtime guard: must be non-empty and match UUID shape
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(raw)) {
    throw new Error(`Invalid UserId: ${raw}`);
  }
  return raw as UserId; // Branding via assertion after validation
}

/** Safely constructs a TenantId. */
function createTenantId(raw: string): TenantId {
  if (!/^tenant_[a-z0-9]{12}$/.test(raw)) {
    throw new Error(`Invalid TenantId: ${raw}`);
  }
  return raw as TenantId;
}

/** Safely constructs a PlanId. */
function createPlanId(raw: string): PlanId {
  if (!/^plan_(basic|pro|enterprise)$/.test(raw)) {
    throw new Error(`Invalid PlanId: ${raw}`);
  }
  return raw as PlanId;
}

// ----------------------------------------------------------------------------
// 3. Zod Schema for Incoming API Payload (Runtime + Inferred Types)
// ----------------------------------------------------------------------------

/**
 * Zod schema describing the expected shape of a subscription request.
 * Validates at runtime; inferred type used for internal handling.
 */
const SubscriptionRequestSchema = z.object({
  userId: z.string().uuid(),
  tenantId: z.string().regex(/^tenant_[a-z0-9]{12}$/),
  planId: z.enum(['plan_basic', 'plan_pro', 'plan_enterprise']),
});

/** Type inferred from Zod schema (pre-branding). */
type SubscriptionRequest = z.infer<typeof SubscriptionRequestSchema>;

// ----------------------------------------------------------------------------
// 4. Domain Entity Using Branded Types
// ----------------------------------------------------------------------------

/**
 * Subscription entity using branded IDs to enforce correct usage.
 */
interface Subscription {
  userId: UserId;
  tenantId: TenantId;
  planId: PlanId;
  createdAt: Date;
}

// ----------------------------------------------------------------------------
// 5. Next.js API Route Handler (ESM)
// ----------------------------------------------------------------------------

/**
 * POST /api/subscription
 * Validates payload, brands IDs, and returns a created subscription.
 */
export async function POST(request: Request): Promise<Response> {
  // Parse JSON body
  const body = await request.json();

  // Runtime validation via Zod
  const parsed = SubscriptionRequestSchema.safeParse(body);
  if (!parsed.success) {
    return new Response(JSON.stringify({ error: parsed.error.issues }), {
      status: 400,
      headers: { 'content-type': 'application/json' },
    });
  }

  // Construct branded types from validated data
  const userId = createUserId(parsed.data.userId);
  const tenantId = createTenantId(parsed.data.tenantId);
  const planId = createPlanId(parsed.data.planId);

  // Build domain entity
  const subscription: Subscription = {
    userId,
    tenantId,
    planId,
    createdAt: new Date(),
  };

  // Return success (in real app, persist to DB)
  return new Response(JSON.stringify(subscription), {
    status: 201,
    headers: { 'content-type': 'application/json' },
  });
}
