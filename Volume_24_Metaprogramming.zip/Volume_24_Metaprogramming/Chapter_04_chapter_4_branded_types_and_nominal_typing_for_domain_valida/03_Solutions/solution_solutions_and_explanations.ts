/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Base branding helper using a unique symbol for the brand marker
declare const brandKey: unique symbol;

type Brand<T, B extends string> = T & { readonly [brandKey]: B };

// Distinct branded types for the financial ledger
type AccountId = Brand<string, 'AccountId'>;
type TransactionId = Brand<string, 'TransactionId'>;
type AuditLogId = Brand<string, 'AuditLogId'>;

// Factory functions with basic runtime validation
function createAccountId(raw: string): AccountId {
  if (typeof raw !== 'string' || raw.trim() === '') {
    throw new Error('Invalid AccountId: must be a non-empty string');
  }
  return raw as AccountId;
}

function createTransactionId(raw: string): TransactionId {
  if (typeof raw !== 'string' || raw.trim() === '') {
    throw new Error('Invalid TransactionId: must be a non-empty string');
  }
  return raw as TransactionId;
}

function createAuditLogId(raw: string): AuditLogId {
  if (typeof raw !== 'string' || raw.trim() === '') {
    throw new Error('Invalid AuditLogId: must be a non-empty string');
  }
  return raw as AuditLogId;
}

// User-defined type guards
function isAccountId(x: unknown): x is AccountId {
  return typeof x === 'string' && x.trim() !== '';
}

function isTransactionId(x: unknown): x is TransactionId {
  return typeof x === 'string' && x.trim() !== '';
}

function isAuditLogId(x: unknown): x is AuditLogId {
  return typeof x === 'string' && x.trim() !== '';
}

// Domain function requiring distinct branded types
function linkTransactionToAccount(tx: TransactionId, acc: AccountId): void {
  console.log(`Linked tx ${tx} to account ${acc}`);
}

// Demonstration of compile-time errors:
// const bad1 = linkTransactionToAccount('tx1', createAccountId('acc1')); // Error: 'string' not assignable to TransactionId
// const bad2 = linkTransactionToAccount(createAccountId('acc1'), createAccountId('acc1')); // Error: AccountId not assignable to TransactionId

/*
 * Why use a symbol for the brand key?
 * A symbol is unique and not enumerable as a plain string literal would be.
 * It avoids accidental name collisions and prevents the brand marker from
 * being easily spoofed or inspected in the object structure.
 *
 * Memory & serialization:
 * Because the symbol key is not a runtime property (it exists only at the type level
 * via intersection), the value is a plain string at runtime. JSON.stringify will output
 * just the string, dropping any notion of the brand. This is safe for cross-module
 * boundaries but means deserialization requires re-running factories/guards.
 */
