/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

declare const centsBrand: unique symbol;
declare const emailBrand: unique symbol;

type UsdCents = number & { readonly [centsBrand]: 'UsdCents' };
type EmailAddress = string & { readonly [emailBrand]: 'EmailAddress' };

// Factory with strict validation
function createUsdCents(value: number): UsdCents {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error('UsdCents must be a non-negative integer');
  }
  return value as UsdCents;
}

// Factory with regex check
function createEmailAddress(value: string): EmailAddress {
  const simplifiedEmailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!simplifiedEmailRegex.test(value)) {
    throw new Error('Invalid email format');
  }
  return value as EmailAddress;
}

// Addition preserving brand; we trust inputs as they are already branded
function addUsdCents(a: UsdCents, b: UsdCents): UsdCents {
  // Inputs are branded so they passed validation at creation; no re-validation needed.
  return (a + b) as UsdCents;
}

interface Customer {
  email: EmailAddress;
  balance: UsdCents;
}

function sendPromoEmail(customer: Customer, amount: UsdCents): string {
  return `Sent promo with ${amount} cents to ${customer.email}`;
}

// Demonstration:
// const wrong = sendPromoEmail({ email: createEmailAddress('a@b.com'), balance: createUsdCents(10) }, 50); // Error: number not UsdCents

/*
 * Trade-off analysis:
 * If you do Number(usdCents) you get a plain number. Passing that to a function
 * expecting number is fine, but passing it where UsdCents is required fails.
 * Branding protects by making invalid states unrepresentable; explicit unboxing
 * is a deliberate act, so misuse is localized and reviewable.
 */
