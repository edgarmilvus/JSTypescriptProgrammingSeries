/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// auth-types.ts (assumed separate)
declare const uidBrand: unique symbol;
declare const tokenBrand: unique symbol;

export type BrandedUserId = string & { readonly [uidBrand]: 'UserId' };
export type BrandedApiToken = string & { readonly [tokenBrand]: 'ApiToken' };

export function createBrandedUserId(s: string): BrandedUserId {
  if (!s) throw new Error('empty');
  return s as BrandedUserId;
}
export function createBrandedApiToken(s: string): BrandedApiToken {
  if (!s) throw new Error('empty');
  return s as BrandedApiToken;
}
export function isBrandedUserId(x: unknown): x is BrandedUserId {
  return typeof x === 'string' && x.length > 0;
}
export function isBrandedApiToken(x: unknown): x is BrandedApiToken {
  return typeof x === 'string' && x.length > 0;
}

// UserBadge.tsx
import { BrandedUserId, BrandedApiToken } from './auth-types';

interface UserBadgeProps {
  userId: BrandedUserId;
  apiToken: BrandedApiToken;
  onExpire?: (token: BrandedApiToken) => void;
}

export function UserBadge({ userId, apiToken, onExpire }: UserBadgeProps) {
  const last4 = userId.slice(-4);
  const dot = apiToken ? '🟢' : '';
  return (
    <div>
      <span>{last4}</span>
      <span>{dot}</span>
      {onExpire && <button onClick={() => onExpire(apiToken)}>Expire</button>}
    </div>
  );
}

// App.tsx demonstration
// <UserBadge userId="123" apiToken="tok" /> // TS error: string not assignable
// Correct usage:
// <UserBadge userId={createBrandedUserId('u123')} apiToken={createBrandedApiToken('t123')} />

/*
 * React component contracts benefit from nominal typing by enforcing exact
 * prop types across teams. Branding stops "props drift" where a raw string
 * silently replaces a domain type, keeping shared libraries safe.
 */
