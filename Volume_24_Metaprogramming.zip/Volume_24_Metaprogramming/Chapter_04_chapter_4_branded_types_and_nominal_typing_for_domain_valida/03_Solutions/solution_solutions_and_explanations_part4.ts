/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

declare const tId: unique symbol;
declare const aId: unique symbol;
declare const sev: unique symbol;

type TicketId = string & { readonly [tId]: 'TicketId' };
type AgentId = string & { readonly [aId]: 'AgentId' };
type SeverityLevel = number & { readonly [sev]: 'Severity' };

interface GraphState {
  ticketId: TicketId;
  assignedAgent?: AgentId;
  severity: SeverityLevel;
  notes: string;
}

function createTicketId(s: string): TicketId { return s as TicketId; }
function createAgentId(s: string): AgentId { return s as AgentId; }
function createSeverity(n: number): SeverityLevel {
  if (n < 1 || n > 5) throw new Error('Severity must be 1-5');
  return n as SeverityLevel;
}

function assignAgentNode(state: GraphState): Partial<GraphState> {
  return { assignedAgent: createAgentId('agent-1') };
}

function escalateNode(state: GraphState): Partial<GraphState> {
  const next = Math.min(5, state.severity + 1);
  return { severity: createSeverity(next) };
}

function validateStateTransition(old: GraphState, next: Partial<GraphState>): GraphState {
  const merged = { ...old, ...next };
  if (typeof merged.ticketId !== 'string') throw new Error('bad ticket');
  if (merged.assignedAgent !== undefined && typeof merged.assignedAgent !== 'string') throw new Error('bad agent');
  if (typeof merged.severity !== 'number' || merged.severity < 1 || merged.severity > 5) throw new Error('bad severity');
  return merged as GraphState;
}

/*
 * Branded types stop a node from writing raw string to ticketId because
 * TypeScript requires the brand. Inside a node, type guards narrow and
 * preserve brand info, aiding safe flows.
 */

::: {style="text-align: center"}
![A Graphviz node-flow diagram illustrating how `validateStateTransition` merges and re-validates branded `GraphState` fields at runtime.](images/b24_c4_s4_diag1.png){width=80% caption="A Graphviz node-flow diagram illustrating how `validateStateTransition` merges and re-validates branded `GraphState` fields at runtime."}
:::
