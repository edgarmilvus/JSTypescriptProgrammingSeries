/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Step-by-step narrowing sketch:
// const data: unknown = { id: 'evt_123', ts: 1700000000000 };
// if (data && typeof data === 'object') {
//   const d = data as Record<string, unknown>;
//   if (isWebhookEventId(d.id)) { /* d.id is WebhookEventId */ }
//   if (typeof d.ts === 'number') { const ts = d.ts as UnixMs; /* narrow manually */ }
// }

// 2. TypeScript does NOT mutate parent object type; narrowing is local to block.
// 3. processEvent(d.id, d.ts); // Error before guard: id is unknown, ts is unknown.
// After guard: processEvent(d.id as WebhookEventId, d.ts as UnixMs);

/*
 * 4. Declaration merging of interface could add brand marker across files,
 * but it weakens guarantee vs type intersection because merged interface
 * is still structurally open; intersection with unique symbol is tighter.
 */
