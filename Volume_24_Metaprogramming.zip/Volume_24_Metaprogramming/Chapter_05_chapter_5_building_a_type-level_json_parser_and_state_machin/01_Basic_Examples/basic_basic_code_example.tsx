/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// ===========================================================================
// File: BasicCodeExample.tsx
// Framework: React 18+ with TypeScript (SaaS dashboard widget example)
// ===========================================================================

/**
 * UIState represents the presentation-layer state of our SaaS widget.
 * In the Vercel AI SDK mental model, UIState drives which React nodes render.
 * Here we keep it as a simple string union for clarity.
 */
type UIState = "idle" | "loading";

/**
 * DashboardWidgetProps is the public API contract for our component.
 * Using an interface (not a type alias) follows TS best practices for
 * component props and allows declaration merging if extended later.
 */
interface DashboardWidgetProps {
  /** Label shown on the trigger button */
  buttonLabel: string;
  /** Callback that simulates a slow server action */
  onActivate: () => Promise<void>;
}

import React, { useState, useTransition } from "react";

/**
 * DashboardWidget is a minimal SaaS-style component.
 * It uses UIState to decide what to render and useTransition to avoid
 * blocking the UI while a fake async task runs.
 */
function DashboardWidget(props: DashboardWidgetProps): JSX.Element {
  // 1. Local presentation state, typed via our UIState union.
  const [uiState, setUiState] = useState<UIState>("idle");

  // 2. useTransition gives us a pending flag and a non-blocking setter.
  const [isPending, startTransition] = useTransition();

  /**
   * handleClick wraps the slow call in startTransition.
   * React keeps the UI responsive and isPending becomes true.
   */
  async function handleClick(): Promise<void> {
    // 3. Immediately mark presentation state as loading (non-blocking).
    startTransition(() => {
      setUiState("loading");
    });

    // 4. Await the simulated server action.
    await props.onActivate();

    // 5. Return to idle inside another transition for consistency.
    startTransition(() => {
      setUiState("idle");
    });
  }

  // 6. Render based on UIState.
  return (
    <div className="saas-widget">
      <button onClick={handleClick} disabled={isPending}>
        {props.buttonLabel}
      </button>
      {uiState === "loading" && <p>Loading… (non-blocking)</p>}
      {isPending && <small>Transition pending</small>}
    </div>
  );
}

// ===========================================================================
// Demo usage inside a fictional SaaS app
// ===========================================================================

/**
 * fakeServerAction simulates a Vercel Server Action that takes ~1s.
 */
async function fakeServerAction(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 1000));
}

/**
 * App demonstrates the widget in a SaaS context.
 */
export function App(): JSX.Element {
  return (
    <main>
      <h1>SaaS Analytics</h1>
      <DashboardWidget
        buttonLabel="Refresh Metrics"
        onActivate={fakeServerAction}
      />
    </main>
  );
}
