/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// Advanced Application Script: Type-Level JSON Parser & State Machine
// Context: SaaS Subscription Webhook Processor (Next.js API Route)
// ============================================================================

/**
 * Strict Type Discipline is assumed via tsconfig:
 * {
 *   "compilerOptions": {
 *     "strict": true,
 *     "strictNullChecks": true,
 *     "noImplicitAny": true
 *   }
 * }
 */

// ----------------------------------------------------------------------------
// 1. TYPE-LEVEL JSON PARSER PRIMITIVES
// ----------------------------------------------------------------------------

/**
 * Removes leading/trailing whitespace from a string literal type.
 * Used to preprocess JSON strings at the type level.
 */
type Trim<S extends string> =
  S extends ` ${infer R}` ? Trim<R> :
  S extends `${infer R} ` ? Trim<R> :
  S;

/**
 * Recursively parses a JSON string literal into a TypeScript value type.
 * Supports strings, numbers, booleans, null, and nested objects/arrays.
 */
type ParseJSON<S extends string> =
  Trim<S> extends `{${infer Body}}`
    ? ParseObject<Body>
    : Trim<S> extends `[${infer Arr}]`
    ? ParseArray<Arr>
    : Trim<S> extends `"${infer Str}"`
    ? Str
    : Trim<S> extends `true` | `false`
    ? boolean
    : Trim<S> extends `null`
    ? null
    : Trim<S> extends `${infer N extends number}`
    ? N
    : never;

/**
 * Parses a comma-separated list of object key-value pairs.
 */
type ParseObject<S extends string> =
  S extends `${infer Pair},${infer Rest}`
    ? Merge<ParsePair<Pair>, ParseObject<Rest>>
    : S extends `${infer Pair}`
    ? ParsePair<Pair> extends infer P
      ? P extends Record<string, unknown> ? P : {}
      : {}
    : {};

/**
 * Merges two object types.
 */
type Merge<A, B> = A & B;

/**
 * Parses a single "key":value pair inside an object body.
 */
type ParsePair<S extends string> =
  S extends `"${infer K}":${infer V}`
    ? { [P in K]: ParseJSON<V> }
    : {};

/**
 * Parses a JSON array body into a tuple type.
 */
type ParseArray<S extends string> =
  Trim<S> extends `${infer Item},${infer Rest}`
    ? [ParseJSON<Item>, ...ParseArray<Rest>]
    : Trim<S> extends `${infer Item}`
    ? Trim<Item> extends "" ? [] : [ParseJSON<Item>]
    : [];

// ----------------------------------------------------------------------------
// 2. TYPE-LEVEL STATE MACHINE FOR SUBSCRIPTION LIFECYCLE
// ----------------------------------------------------------------------------

/**
 * Discriminated union of valid subscription states.
 * Each state declares the set of states it may transition to.
 */
type SubscriptionState =
  | { status: "trial"; next: "active" | "cancelled" }
  | { status: "active"; next: "past_due" | "cancelled" }
  | { status: "past_due"; next: "active" | "cancelled" }
  | { status: "cancelled"; next: never };

/**
 * Enforces that a transition from S to T is permitted by the state machine.
 */
type Transition<S extends SubscriptionState["status"], T extends string> =
  Extract<SubscriptionState, { status: S }> extends { next: infer N }
    ? T extends N ? T : never
    : never;

// ----------------------------------------------------------------------------
// 3. WEBHOOK PAYLOAD VALIDATION VIA TYPE-LEVEL PARSER
// ----------------------------------------------------------------------------

/**
 * Example raw webhook body received from payment provider.
 */
type RawWebhook = `{"event":"invoice.paid","subscription":{"id":"sub_123","status":"active"}}`;

/**
 * Parsed shape inferred entirely at compile time.
 */
type WebhookData = ParseJSON<RawWebhook>;

// ----------------------------------------------------------------------------
// 4. NEXT.JS API ROUTE HANDLER
// ----------------------------------------------------------------------------

import type { NextApiRequest, NextApiResponse } from "next";

/**
 * Runtime handler that leverages compile-time guarantees.
 * The generic TState tracks the current subscription status.
 */
function assertTransition<
  Current extends SubscriptionState["status"],
  Next extends string
>(current: Current, next: Next): Next is Transition<Current, Next> {
  // Runtime guard backing the type-level state machine
  const allowed = (current === "trial" && (next === "active" || next === "cancelled")) ||
                  (current === "active" && (next === "past_due" || next === "cancelled")) ||
                  (current === "past_due" && (next === "active" || next === "cancelled"));
  return allowed;
}

/**
 * API route processing subscription webhooks.
 */
export default function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 1. Extract raw body (already typed as template literal via const assertion)
  const raw = req.body as RawWebhook;

  // 2. Compile-time parsed structure (no runtime JSON.parse needed for types)
  type Parsed = WebhookData;
  const parsed: Parsed = JSON.parse(raw) as Parsed;

  // 3. Narrow the subscription status via type guard
  const currentStatus = parsed.subscription.status; // inferred as "active"
  const intendedNext = "cancelled" as string;

  // 4. Enforce state machine transition
  if (!assertTransition(currentStatus, intendedNext)) {
    res.status(400).json({ error: "Invalid state transition" });
    return;
  }

  // 5. Transition is valid per type system; proceed with SaaS logic
  res.status(200).json({ ok: true, from: currentStatus, to: intendedNext });
}
