/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Base token union
type Token =
  | "{"
  | "}"
  | "["
  | "]"
  | ":"
  | ","
  | "string"
  | "number"
  | "boolean"
  | "null";

// Custom error type
type ParseError = { error: "MalformedJSON" };

// Helper to skip whitespace (space, tab, newline)
type Trim<
  T extends string,
  Acc extends Token[] = []
> = T extends ` ${infer R}`
  ? Trim<R, Acc>
  : T extends `\t${infer R}`
  ? Trim<R, Acc>
  : T extends `\n${infer R}`
  ? Trim<R, Acc>
  : { rest: T; acc: Acc };

// Tokenize main type
type Tokenize<
  T extends string,
  Acc extends Token[] = []
> = T extends ""
  ? Acc
  : Trim<T, Acc> extends { rest: infer R extends string; acc: infer A extends Token[] }
  ? R extends `{${infer Rest}`
    ? Tokenize<Rest, [...A, "{"]>
    : R extends `}${infer Rest}`
    ? Tokenize<Rest, [...A, "}"]>
    : R extends `[${infer Rest}`
    ? Tokenize<Rest, [...A, "["]>
    : R extends `]${infer Rest}`
    ? Tokenize<Rest, [...A, "]"]>
    : R extends `:${infer Rest}`
    ? Tokenize<Rest, [...A, ":"]>
    : R extends `,${infer Rest}`
    ? Tokenize<Rest, [...A, ","]>
    : R extends `"${infer Body}"${infer Rest}`
    ? Tokenize<Rest, [...A, "string"]>
    : R extends `${infer Num extends number}${infer Rest}`
    ? Tokenize<Rest, [...A, "number"]>
    : R extends `true${infer Rest}`
    ? Tokenize<Rest, [...A, "boolean"]>
    : R extends `false${infer Rest}`
    ? Tokenize<Rest, [...A, "boolean"]>
    : R extends `null${infer Rest}`
    ? Tokenize<Rest, [...A, "null"]>
    : ParseError
  : ParseError;

/*
 * NOTE ON COMPILER LIMITS:
 * TypeScript has a recursion depth limit (approx. 1000 instantiations by default).
 * Very long JSON strings will hit "Type instantiation is excessively deep" errors.
 * This is tied to the compiler's internal stack for conditional type evaluation
 * and cannot be increased without changing tsconfig or using iterative tricks.
 */
