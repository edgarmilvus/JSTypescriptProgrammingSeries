/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type ParseError = { error: "InvalidJSON" };

// Strip outer whitespace
type Whitespace = " " | "\t" | "\n";
type Strip<T extends string> =
  T extends `${Whitespace}${infer R}`
    ? Strip<R>
    : T extends `${infer R}${Whitespace}`
    ? Strip<R>
    : T;

// Parse a single value
type ParseValue<T extends string> =
  T extends `"${infer S}"${infer Rest}`
    ? { value: S; rest: Rest }
    : T extends `{${infer Rest}`
    ? ParseObject<Rest>
    : T extends `[${infer Rest}`
    ? ParseArray<Rest>
    : T extends `true${infer Rest}`
    ? { value: true; rest: Rest }
    : T extends `false${infer Rest}`
    ? { value: false; rest: Rest }
    : T extends `null${infer Rest}`
    ? { value: null; rest: Rest }
    : T extends `${infer N extends number}${infer Rest}`
    ? { value: N; rest: Rest }
    : ParseError;

// Parse object recursively
type ParseObject<
  T extends string,
  Acc extends Record<string, unknown> = {}
> = T extends `}${infer Rest}`
  ? { value: Acc; rest: Rest }
  : T extends `"${infer K}"${infer AfterK}`
  ? AfterK extends `:${infer V}`
    ? ParseValue<Strip<V>> extends { value: infer Val; rest: infer R }
      ? R extends `,${infer Next}`
        ? ParseObject<Strip<Next>, Acc & Record<K, Val>>
        : R extends `}${infer End}`
        ? { value: Acc & Record<K, Val>; rest: End }
        : ParseError
      : ParseError
    : ParseError
  : ParseError;

// Parse array recursively
type ParseArray<
  T extends string,
  Acc extends unknown[] = []
> = T extends `]${infer Rest}`
  ? { value: Acc; rest: Rest }
  : ParseValue<Strip<T>> extends { value: infer Val; rest: infer R }
  ? R extends `,${infer Next}`
    ? ParseArray<Strip<Next>, [...Acc, Val]>
    : R extends `]${infer End}`
    ? { value: [...Acc, Val]; rest: End }
    : ParseError
  : ParseError;

// Top-level entry
type ParseJSON<T extends string> =
  Strip<T> extends infer S extends string
    ? ParseValue<S> extends { value: infer V; rest: "" }
      ? V
      : ParseError
    : ParseError;

/*
 * TAIL RECURSION NOTE:
 * TS 4.5+ supports tail recursive conditional types when the recursive call
 * is in the tail position of the ternary. Our ParseObject/ParseArray are
 * mostly tail-recursive, but intermediate intersections (Acc & ...) may
 * block full optimization; thus deep nesting can still hit depth limits.
 */
