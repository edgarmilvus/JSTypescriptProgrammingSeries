/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

type TrafficState = "Red" | "Green" | "Yellow";

// Lookup for valid next states
type TransitionMap = {
  Red: "Green";
  Green: "Yellow";
  Yellow: "Red";
};

type Transition<
  S extends TrafficState,
  N extends TrafficState
> = N extends TransitionMap[S] ? N : never;

// Validate a sequence of states
type Sequence<States extends TrafficState[]> =
  States extends [infer First, infer Second, ...infer Rest]
    ? First extends TrafficState
      ? Second extends TrafficState
        ? Transition<First, Second> extends never
          ? false
          : Rest extends TrafficState[]
          ? Sequence<[Second, ...Rest]>
          : false
        : false
      : false
    : true;

// State machine wrapper
type StateMachine<S extends TrafficState = "Red"> = {
  current: S;
  next<N extends TrafficState>: N extends TransitionMap[S]
    ? StateMachine<N>
    : never;
};

/*
 * EXTENSION NOTE:
 * This pattern scales to finite automata with emitted events by adding
 * event payloads to TransitionMap values (e.g., { state: "Green"; event: "go" })
 * and mapping them in a similar conditional lookup.
 */
