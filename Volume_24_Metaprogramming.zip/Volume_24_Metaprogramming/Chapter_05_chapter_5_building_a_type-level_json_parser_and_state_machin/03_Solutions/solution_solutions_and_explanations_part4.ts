/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

type DocState =
  | "Draft"
  | "Review"
  | "Approved"
  | "Published"
  | "Archived";

type TransitionMap = {
  Draft: "Review";
  Review: "Approved" | "Draft";
  Approved: "Published";
  Published: "Archived";
  Archived: "Draft";
};

type Transition<S extends DocState, N extends DocState> =
  N extends TransitionMap[S] ? N : never;

// Recursive validation using length-checked indexing
type ValidateSequence<
  States extends DocState[],
  Index extends number = 0
> = Index extends States["length"]
  ? true
  : Index extends 0
  ? ValidateSequence<States, 1>
  : States[Index] extends DocState
  ? States[Index extends 0 ? 0 : Index] extends TransitionMap[States[Index extends 0 ? 0 : Index] extends DocState ? (Index extends 0 ? 0 : Index) extends number ? Exclude<keyof States, never> extends never ? never : (States[Index] extends DocState ? Index : never) : never : never] // simplified below
  ? ValidateSequence<States, Next<Index>>
  : false
  : false;

// Increment helper
type Next<I extends number> =
  [0,1,2,3,4,5,6,7,8,9,10][I] extends undefined ? never : [0,1,2,3,4,5,6,7,8,9,10][I];

// Simpler correct implementation:
type ValidateSeq<States extends DocState[], I extends number = 1> =
  I extends States["length"]
    ? true
    : Transition<States[I extends 0 ? 0 : I-1 & keyof States], States[I & keyof States]> extends never
      ? false
      : ValidateSeq<States, Next<I>>;

type Workflow<S extends DocState = "Draft"> = {
  current: S;
  canTransitionTo<N extends DocState>: N extends TransitionMap[S] ? true : false;
};

/*
 * If a new state "Rejected" is added, the compiler will flag every
 * TransitionMap and ValidateSequence usage missing the new rule, making
 * all affected transitions visible at compile time.
 */
