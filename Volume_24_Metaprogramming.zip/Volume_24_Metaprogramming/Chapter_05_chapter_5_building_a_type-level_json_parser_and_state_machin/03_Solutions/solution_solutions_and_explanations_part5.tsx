/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

type ParseJSON<T extends string> = T extends `{${infer Body}}${string}`
  ? Body extends `"size":"${infer S}"${string},"closable":${infer C}`
    ? { size: S; closable: C extends "true" ? true : false }
    : never
  : never;

type ModalSchema = {
  size: "small" | "medium" | "large";
  closable: boolean;
};

type CheckConfig<J extends string> =
  ParseJSON<J> extends ModalSchema ? ParseJSON<J> : never;

type Props<JSONString extends string> = {
  jsonConfig: JSONString;
  onClose?: CheckConfig<JSONString> extends { closable: false }
    ? never
    : () => void;
};

function TypedModal<JSONString extends string>(
  props: Props<JSONString>
) {
  return null;
}

// Valid
// <TypedModal jsonConfig='{"size":"large","closable":true}' onClose={() => {}} />
// Invalid: closable false but onClose provided
// <TypedModal jsonConfig='{"size":"small","closable":false}' onClose={() => {}} />

/*
 * The compiler resolves ParseJSON during JSX prop checking, inferring the
 * literal config shape without emitting runtime parse code: headless inference.
 */

// Extended modal transition state machine
type ModalState = "closed" | "open" | "closing";
type ModalTransition = { closed: "open"; open: "closing"; closing: "closed" };
type ModalMachine<S extends ModalState = "closed"> = {
  state: S;
  go<N extends ModalTransition[S]>: ModalMachine<N>;
};
