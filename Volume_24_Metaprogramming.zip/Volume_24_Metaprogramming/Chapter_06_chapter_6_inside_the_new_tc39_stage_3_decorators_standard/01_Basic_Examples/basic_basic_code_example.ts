/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: saas-platform.mts
// We use .mts so Node.js treats this as an ECMAScript Module (ESM).
// ESM gives us static import/export and tree-shaking in bundlers.

/**
 * Context object provided by the TC39 Stage 3 decorator proposal.
 * For a class decorator, the context includes the class kind and name.
 */
type ClassDecoratorContext = {
  kind: 'class';
  name: string;
};

/**
 * Context object for a method decorator under Stage 3.
 * It includes the method name and the class the method belongs to.
 */
type MethodDecoratorContext = {
  kind: 'method';
  name: string;
  static: boolean;
  private: boolean;
};

/**
 * A basic class decorator that flags a SaaS service as registered.
 * It returns the original class unchanged, satisfying the new model.
 *
 * @param target The class being decorated
 * @param context The decorator context from the JS engine
 */
function RegisteredService(
  target: Function,
  context: ClassDecoratorContext
): Function {
  // Attach a static marker property used by the SaaS platform registry.
  (target as any).__registered__ = true;
  console.log(`[SaaS Registry] Class "${context.name}" is now registered.`);
  return target;
}

/**
 * A basic method decorator that logs invocations of critical SaaS methods.
 *
 * @param target The method function being decorated
 * @param context The decorator context from the JS engine
 */
function LoggedMethod(
  target: Function,
  context: MethodDecoratorContext
): Function {
  const methodName = context.name;
  // Return a new function wrapping the original method.
  return function (this: any, ...args: any[]) {
    console.log(`[SaaS Log] Calling method "${methodName}" with`, args);
    const result = target.apply(this, args);
    console.log(`[SaaS Log] Method "${methodName}" finished.`);
    return result;
  };
}

// Apply the class decorator to a SaaS billing service.
@RegisteredService
export class BillingService {
  /**
   * Charges a customer for a subscription.
   * The method decorator logs the call for audit purposes.
   */
  @LoggedMethod
  chargeCustomer(userId: string, amount: number): string {
    return `Charged ${userId} $${amount}`;
  }
}

// Demo usage inside an ESM module.
const billing = new BillingService();
console.log(billing.chargeCustomer('user_123', 49));
