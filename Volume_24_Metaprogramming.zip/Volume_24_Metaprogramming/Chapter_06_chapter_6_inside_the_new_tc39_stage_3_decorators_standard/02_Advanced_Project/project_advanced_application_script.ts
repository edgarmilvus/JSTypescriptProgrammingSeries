/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file edgeApiDecorators.ts
 * @description Advanced TC39 Stage 3 Decorators for Next.js Edge API handlers.
 * Demonstrates unified decorator model, DecoratorContext, and metadata usage.
 */

// -----------------------------------------------------------------------------
// 1. Core Type Definitions for Decorator Context and Handler Metadata
// -----------------------------------------------------------------------------

/**
 * Shape of the metadata we attach to Edge API handlers via decorators.
 */
interface EdgeHandlerMeta {
  rateLimit: number;          // Max requests per minute
  schema: string;             // Logical input schema identifier
  track: boolean;             // Whether to emit telemetry
}

/**
 * Minimal contract for an Edge API request in a SaaS context.
 */
interface SaaSRequest {
  ip: string;
  body: unknown;
}

/**
 * Response shape returned by handlers (simplified for demo).
 */
interface SaaSResponse {
  status: number;
  json: () => Promise<unknown>;
}

// -----------------------------------------------------------------------------
// 2. Decorator Implementation Using Stage 3 Function-Based Model
// -----------------------------------------------------------------------------

/**
 * @decorator edgeHandler
 * @description Stage 3 decorator that wraps a method with Edge Runtime
 * policies: rate limiting, schema validation, and telemetry.
 * Uses DecoratorContext to read class/method identity and store metadata.
 */
function edgeHandler(meta: EdgeHandlerMeta) {
  // The decorator returns a function compatible with TC39 Stage 3 signature
  return function (
    target: (req: SaaSRequest) => Promise<SaaSResponse>,
    context: DecoratorContext
  ) {
    // context.kind === 'method' in this usage
    if (context.kind !== 'method') {
      throw new Error('edgeHandler can only decorate methods');
    }

    // Store metadata on the method for later introspection by the framework
    context.metadata.edgeHandler = meta;

    // Return a new function that wraps the original handler
    return function (this: unknown, req: SaaSRequest) {
      // --- Policy 1: Rate Limiting (simulated) ---
      console.log(
        `[edge] rate-limit=${meta.rateLimit} for ${context.name as string}`
      );

      // --- Policy 2: Schema Validation (simulated) ---
      if (meta.schema !== 'public') {
        console.log(`[edge] validating body against ${meta.schema}`);
      }

      // --- Policy 3: Telemetry ---
      if (meta.track) {
        console.log(`[edge] telemetry: invoke ${context.name as string}`);
      }

      // Delegate to original method
      return target.call(this, req);
    };
  };
}

// -----------------------------------------------------------------------------
// 3. SaaS API Controller Class Using Modern Decorators
// -----------------------------------------------------------------------------

class BillingAPI {
  /**
   * Decorated Edge handler for creating invoices.
   * Uses Stage 3 decorator with inline metadata.
   */
  @edgeHandler({ rateLimit: 60, schema: 'invoice.create', track: true })
  async createInvoice(req: SaaSRequest): Promise<SaaSResponse> {
    // Business logic (omitted for brevity)
    return { status: 201, json: async () => ({ ok: true }) };
  }

  /**
   * Public endpoint with relaxed policy.
   */
  @edgeHandler({ rateLimit: 120, schema: 'public', track: false })
  async health(req: SaaSRequest): Promise<SaaSResponse> {
    return { status: 200, json: async () => ({ healthy: true }) };
  }
}

// -----------------------------------------------------------------------------
// 4. Next.js Edge Route Adapter (ESM)
// -----------------------------------------------------------------------------

/**
 * Exports a default Edge handler for Next.js routing.
 * Imports the controller and invokes the decorated method.
 */
import type { NextRequest } from 'next/server';

export default async function GET(request: NextRequest) {
  const api = new BillingAPI();
  const res = await api.health({ ip: request.ip ?? 'local', body: null });
  return new Response(JSON.stringify(await res.json()), {
    status: res.status
  });
}
