/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// ESM module: validators.ts
import { ClassFieldDecoratorContext } from "typescript";

// Module-level WeakMap to store per-instance values without polluting instances
const fieldStorage = new WeakMap<object, Map<string | symbol, unknown>>();

// Decorator factory per requirements
function Validate(
  predicate: (value: unknown) => boolean,
  message: string
): (target: undefined, context: ClassFieldDecoratorContext) => (initialValue: unknown) => { get(): unknown; set(v: unknown): void } | void {
  return (_, context) => {
    // Register validated field name in metadata
    if (!context.metadata.validatedFields) {
      (context.metadata as any).validatedFields = [];
    }
    (context.metadata as any).validatedFields.push(context.name);

    // Return initializer that yields accessor pair
    return (initialValue: unknown) => {
      if (!predicate(initialValue)) {
        throw new TypeError(`Invalid initial value for ${String(context.name)}: ${message}`);
      }
      return {
        get() {
          const store = fieldStorage.get(this)!;
          return store.get(context.name);
        },
        set(v: unknown) {
          if (!predicate(v)) {
            throw new TypeError(`${message} (field: ${String(context.name)})`);
          }
          let store = fieldStorage.get(this);
          if (!store) {
            store = new Map();
            fieldStorage.set(this, store);
          }
          store.set(context.name, v);
        }
      };
    };
  };
}

// Sample class with two validated fields
export class User {
  @Validate((v) => typeof v === "number" && (v as number) >= 0, "Age must be a non-negative number")
  age: unknown;

  @Validate((v) => typeof v === "string" && /^[^@]+@[^@]+$/.test(v as string), "Email must match simple pattern")
  email: unknown;

  constructor(age: number, email: string) {
    this.age = age;
    this.email = email;
  }
}

/*
 Demonstration (comments only):
 const u = new User(25, "a@b.com"); // ok
 u.age = -5; // throws TypeError: Age must be a non-negative number (field: age)
 u.email = "bad"; // throws TypeError: Email must match simple pattern (field: email)
*/
