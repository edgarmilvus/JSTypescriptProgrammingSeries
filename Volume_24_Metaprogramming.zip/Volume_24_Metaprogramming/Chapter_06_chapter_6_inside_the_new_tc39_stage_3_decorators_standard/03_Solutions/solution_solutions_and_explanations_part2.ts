/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// ESM module: timing.ts
import { ClassMethodDecoratorContext } from "typescript";

function Timed(label?: string): (
  originalMethod: Function,
  context: ClassMethodDecoratorContext
) => Function {
  return function (originalMethod: Function, context: ClassMethodDecoratorContext) {
    // Ensure metadata maps exist
    if (!context.metadata.timings) {
      (context.metadata as any).timings = new Map();
    }
    if (!context.metadata.errors) {
      (context.metadata as any).errors = new Map();
    }

    return function (this: any, ...args: any[]) {
      const start = performance.now();
      try {
        const result = originalMethod.apply(this, args);
        const duration = performance.now() - start;
        const key = String(context.name);
        const t = (context.metadata as any).timings.get(key) || { total: 0, calls: 0 };
        t.total += duration;
        t.calls += 1;
        (context.metadata as any).timings.set(key, t);
        console.log(`Method ${key} (${label ?? "no-label"}): ${duration.toFixed(2)}ms`);
        return result;
      } catch (err) {
        const duration = performance.now() - start;
        const key = String(context.name);
        const e = (context.metadata as any).errors.get(key) || { total: 0, calls: 0 };
        e.total += duration;
        e.calls += 1;
        (context.metadata as any).errors.set(key, e);
        throw err;
      }
    };
  };
}

export { Timed };

export class ReportGenerator {
  @Timed("instance-generate")
  generate() {
    return "report";
  }

  @Timed("static-template")
  static createTemplate() {
    return "template";
  }
}

/*
 React Performance Panel skeleton (no full solution):
 import { ReportGenerator } from "./timing";
 type TimingEntry = { total: number; calls: number };
 export function PerformancePanel() {
   const meta = (ReportGenerator as any)[Symbol.metadata];
   const timings: Map<string, TimingEntry> = meta?.timings ?? new Map();
   return (
     <aside>
       <h3>Performance</h3>
       <ul>
         {[...timings.entries()].map(([k, v]) => (
           <li key={k}>{k}: {v.total.toFixed(2)}ms over {v.calls} calls</li>
         ))}
       </ul>
     </aside>
   );
 }
*/
