/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// CounterStore.ts
import { ClassAccessorDecoratorContext } from "typescript";

function Tracked(
  original: { get(): unknown; set(v: unknown): void },
  context: ClassAccessorDecoratorContext
): { get(): unknown; set(v: unknown): void } {
  // Decorator declared per spec; body omitted
  return {
    get() { return original.get.call(this); },
    set(v: unknown) {
      original.set.call(this, v);
      (this as any).notify();
    }
  };
}

export class CounterStore {
  @Tracked accessor count = 0;
  private listeners = new Set<() => void>();
  subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }
  private notify() {
    this.listeners.forEach((l) => l());
  }
}

// Counter.tsx
import { useSyncExternalStore } from "react";
import { CounterStore } from "./CounterStore";

export function Counter() {
  const store = new CounterStore();
  const count = useSyncExternalStore(
    store.subscribe.bind(store),
    () => store.count
  );
  return <button onClick={() => (store.count += 1)}>{count}</button>;
}

/*
 Stage 3 accessor decorators intercept get/set natively, unlike legacy
 method decorators that wrapped functions, making fine-grained store
 notification straightforward and type-safe.
*/
