/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// 1. IMPORTS & POLYFILLS
// ============================================================================
// We use reflect-metadata to enable rich design-time metadata at runtime.
// In a real SaaS app this would be installed via `npm i reflect-metadata`.
import 'reflect-metadata';

// ============================================================================
// 2. DECORATOR DEFINITIONS (DECORATOR FACTORIES)
// ============================================================================

/**
 * Class decorator factory that marks a class as a registered SaaS service.
 * It attaches metadata under the 'saas:service' key.
 *
 * @param serviceName Public name shown in the admin dashboard.
 */
function SaaSService(serviceName: string) {
  // The returned function is the actual decorator applied by TS.
  return function <T extends { new (...args: any[]): {} }>(target: T): T {
    // Reflect metadata API stores key/value pairs on the constructor.
    Reflect.defineMetadata('saas:service', serviceName, target);
    // Return the original class (unchanged shape).
    return target;
  };
}

/**
 * Method decorator factory that logs entry/exit of a method.
 * Useful for auditing API calls in a web app.
 *
 * @param label Human-readable label for logs.
 */
function Logged(label: string) {
  // Decorator receives prototype, method name, and descriptor.
  return function (
    target: Object,
    propertyKey: string,
    descriptor: PropertyDescriptor
  ): PropertyDescriptor {
    // Keep a reference to the original method.
    const original = descriptor.value;

    // Replace the method with a wrapped version.
    descriptor.value = function (...args: any[]) {
      console.log(`[LOG] Entering ${label}`);
      const result = original.apply(this, args);
      console.log(`[LOG] Exiting ${label}`);
      return result;
    };

    // Return the modified descriptor.
    return descriptor;
  };
}

/**
 * Property decorator that enforces a default tenant id.
 * In a SaaS context every entity belongs to a tenant.
 */
function TenantScoped(target: Object, propertyKey: string): void {
  // Define metadata indicating this property is tenant-scoped.
  Reflect.defineMetadata('saas:tenantScoped', true, target, propertyKey);
}

// ============================================================================
// 3. INTERFACE DEFINITION
// ============================================================================

/**
 * Contract for any object that can be persisted in our web app.
 */
interface Persistable {
  id: string;
  save(): void;
}

// ============================================================================
// 4. USAGE OF DECORATORS IN A CLASS
// ============================================================================

@SaaSService('Tenant Management')
class TenantService implements Persistable {
  // Property decorator marks this as tenant-scoped.
  @TenantScoped
  public tenantId: string = 'default-tenant';

  public id: string = 'svc-001';

  // Method decorator adds logging around the method.
  @Logged('fetchTenant')
  public getTenantName(): string {
    return `Tenant: ${this.tenantId}`;
  }

  public save(): void {
    console.log(`Saving tenant ${this.tenantId}`);
  }
}

// ============================================================================
// 5. RUNTIME DEMO (SELF-CONTAINED)
// ============================================================================

// Instantiate the decorated class.
const service = new TenantService();

// Read metadata defined by class decorator.
const serviceName = Reflect.getMetadata('saas:service', TenantService);
console.log(`Registered service: ${serviceName}`);

// Read metadata defined by property decorator.
const isTenantScoped = Reflect.getMetadata(
  'saas:tenantScoped',
  service,
  'tenantId'
);
console.log(`tenantId is tenant-scoped: ${isTenantScoped}`);

// Call the logged method.
console.log(service.getTenantName());

// Call the save method.
service.save();
