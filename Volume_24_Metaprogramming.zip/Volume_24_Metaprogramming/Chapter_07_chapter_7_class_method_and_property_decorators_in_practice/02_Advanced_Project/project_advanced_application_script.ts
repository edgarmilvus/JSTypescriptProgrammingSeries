/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// Next.js API route context (App Router style, but logic is framework-agnostic)
// File: app/api/billing/route.ts

import 'reflect-metadata'; // Enables metadata reflection for decorators

/**
 * Strict Type Discipline is assumed via tsconfig:
 * {
 *   "compilerOptions": {
 *     "strict": true,
 *     "strictNullChecks": true,
 *     "noImplicitAny": true,
 *     "experimentalDecorators": true,
 *     "emitDecoratorMetadata": true
 *   }
 * }
 */

// ----------------------------------------------------------------------------
// 1. GENERIC VALIDATION CONTRACT
// ----------------------------------------------------------------------------

/**
 * Generic validator type that enforces Strict Type Discipline.
 * @template T - The type of value being validated.
 */
type Validator<T> = (value: T) => boolean;

// ----------------------------------------------------------------------------
// 2. PROPERTY DECORATOR: @Validate
// ----------------------------------------------------------------------------

/**
 * Property decorator that binds a validator to a class property via metadata.
 * This enforces compile-time-aware runtime validation in SaaS data models.
 */
function Validate<T>(validator: Validator<T>) {
  return function (target: object, propertyKey: string): void {
    // Store validator in a metadata key scoped to the property
    Reflect.defineMetadata(`validate:${propertyKey}`, validator, target);
  };
}

// ----------------------------------------------------------------------------
// 3. METHOD DECORATOR: @LogCall
// ----------------------------------------------------------------------------

/**
 * Method decorator that logs entry/exit and enforces audit trails.
 * Uses generics to remain type-safe across any method signature.
 */
function LogCall(
  target: object,
  propertyKey: string,
  descriptor: PropertyDescriptor
): void {
  const original = descriptor.value as (...args: unknown[]) => unknown;

  descriptor.value = function (...args: unknown[]) {
    console.info(`[AUDIT] Entering ${propertyKey}`, args);
    const result = original.apply(this, args);
    console.info(`[AUDIT] Exiting ${propertyKey}`);
    return result;
  };
}

// ----------------------------------------------------------------------------
// 4. CLASS DECORATOR: @Injectable
// ----------------------------------------------------------------------------

/**
 * Class decorator that registers the class in a DI container.
 * Demonstrates modern decorator use for SaaS service layers.
 */
const DI_CONTAINER = new Map<string, new () => unknown>();

function Injectable(token: string) {
  return function <T extends new (...args: never[]) => object>(ctor: T): T {
    DI_CONTAINER.set(token, ctor);
    return ctor;
  };
}

// ----------------------------------------------------------------------------
// 5. DOMAIN MODEL WITH DECORATORS
// ----------------------------------------------------------------------------

/**
 * TenantBillingInput uses property decorators to guard SaaS input.
 */
class TenantBillingInput {
  @Validate<number>((v) => v > 0)
  amount!: number;

  @Validate<string>((v) => v.startsWith('tok_'))
  tenantId!: string;
}

// ----------------------------------------------------------------------------
// 6. SERVICE CLASS WITH ALL DECORATORS
// ----------------------------------------------------------------------------

/**
 * BillingService is registered via class decorator,
 * logs via method decorator, and validates via property metadata.
 */
@Injectable('BillingService')
class BillingService {
  @LogCall
  charge<T extends TenantBillingInput>(input: T): string {
    // Runtime validation driven by property decorators
    const keys = Object.keys(input) as (keyof T)[];
    for (const key of keys) {
      const validator = Reflect.getMetadata(
        `validate:${String(key)}`,
        TenantBillingInput.prototype
      ) as Validator<unknown> | undefined;

      if (validator && !validator(input[key])) {
        throw new Error(`Validation failed for ${String(key)}`);
      }
    }
    return `Charged ${input.amount} to ${input.tenantId}`;
  }
}

// ----------------------------------------------------------------------------
// 7. NEXT.JS ROUTE HANDLER
// ----------------------------------------------------------------------------

/**
 * Next.js POST handler demonstrating decorator-driven architecture.
 */
export async function POST(req: Request): Promise<Response> {
  const body = (await req.json()) as TenantBillingInput;
  const svc = new (DI_CONTAINER.get('BillingService') as new () => BillingService)();
  const receipt = svc.charge(body);
  return Response.json({ receipt });
}
