/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import 'reflect-metadata';

// Known metadata key for validation rules
const VALIDATION_KEY = 'validation:rules';

// Validator type
type Validator = (value: any) => boolean;

// Structure stored in metadata
interface ValidationRule {
  validator: Validator;
  message: string;
}

// Decorator factory
// Generic keeps validator loosely typed without breaking class inference
export function Validate(
  validator: Validator,
  message: string = 'Invalid value'
) {
  return function (target: any, propertyKey: string): void {
    // Read existing rules from prototype (inherited-safe)
    const existing: Record<string, ValidationRule> =
      Reflect.getMetadata(VALIDATION_KEY, target) || {};
    existing[propertyKey] = { validator, message };
    // Attach updated rules to the prototype
    Reflect.defineMetadata(VALIDATION_KEY, existing, target);
  };
}

// Generic validation utility
export function validateInstance<T>(instance: T): string[] {
  const errors: string[] = [];
  const target = Object.getPrototypeOf(instance);
  const rules: Record<string, ValidationRule> =
    Reflect.getMetadata(VALIDATION_KEY, target) || {};

  // Iterate own + inherited keys
  const keys = [
    ...Object.keys(instance),
    ...Object.getOwnPropertyNames(target),
  ];
  const uniqueKeys = Array.from(new Set(keys));

  for (const key of uniqueKeys) {
    const rule = rules[key];
    if (rule) {
      const value = (instance as any)[key];
      if (!rule.validator(value)) {
        errors.push(`${key}: ${rule.message}`);
      }
    }
  }
  return errors;
}

// Demo class
class UserAccount {
  @Validate(
    (v) => typeof v === 'string' && /.+@.+\..+/.test(v),
    'Email format is invalid'
  )
  email!: string;

  @Validate(
    (v) => typeof v === 'number' && v >= 18 && v <= 120,
    'Age must be between 18 and 120'
  )
  age!: number;

  @Validate(
    (v) => typeof v === 'string' && v.length >= 3,
    'Username too short'
  )
  username!: string;
}

/*
 * NOTE ON COMPILER:
 * `experimentalDecorators` enables legacy decorator syntax.
 * `emitDecoratorMetadata` emits design-time type metadata (e.g. design:type),
 * but `reflect-metadata` is still required to store/read custom metadata
 * like our validation rules, because TS does not persist arbitrary data.
 */
