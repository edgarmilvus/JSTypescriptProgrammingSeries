/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Allowed method signature constraint
type VoidishMethod = (...args: any[]) => void | Promise<void>;

// Config type
interface LogConfig {
  logArgs?: boolean;
  label?: string;
}

// Decorator factory with conditional constraint
export function LogExecution<
  T extends VoidishMethod
>(config: LogConfig = {}) {
  return function (
    _target: any,
    propertyKey: string,
    descriptor: TypedPropertyDescriptor<T>
  ): TypedPropertyDescriptor<T> {
    const original = descriptor.value!;

    descriptor.value = function (this: any, ...args: any[]) {
      const label = config.label ?? propertyKey;
      if (config.logArgs) console.log(`[${label}] args:`, args);
      const start = performance.now();
      const result = original.apply(this, args);
      if (isPromise(result)) {
        return result.finally(() => {
          const dur = performance.now() - start;
          console.log(`[${label}] took ${dur}ms`);
        });
      }
      const dur = performance.now() - start;
      console.log(`[${label}] took ${dur}ms`);
      return result;
    } as T;

    return descriptor;
  };
}

// Type narrowing helper
function isPromise(v: any): v is Promise<void> {
  return v && typeof v.then === 'function';
}

// Demo class
class ReportGenerator {
  @LogExecution({ logArgs: true })
  generate(): void {
    console.log('Generating report...');
  }

  @LogExecution({ label: 'cloud' })
  async syncToCloud(): Promise<void> {
    await new Promise((r) => setTimeout(r, 10));
  }
}
