/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// (Illustrative shape only, not full implementation)
import React from 'react';

// Dummy service types
class ApiClient { fetch() {} }
class Logger { log(m: string) {} }

// Container and decorators (signatures only)
const container = new Map<string, any>();
function Injectable(token?: string) {
  return (target: any) => {
    container.set(token ?? target.name, target);
  };
}
function Inject(token: string) {
  return (target: any, key: string) => {
    Reflect.defineMetadata('inject:token', token, target, key);
  };
}

@Injectable('DataFetcher')
class DataFetcher extends React.Component<{ url: string }> {
  @Inject('ApiClient') apiClient!: ApiClient;
  @Inject('Logger') logger!: Logger;

  async componentDidMount() {
    this.logger.log('mounted');
    this.apiClient.fetch();
  }

  render() { return <div>Loading...</div>; }
}
