/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Shared state shape
type GraphState = Record<string, any>;

// Minimal StateGraph
class StateGraph<S extends GraphState> {
  addNode(name: string, node: { run(state: S): Partial<S> }) {
    // register node
  }
}

// Type guard
function isGraphNode<S extends GraphState>(
  obj: any
): obj is { run(state: S): Partial<S> } {
  return obj && typeof obj.run === 'function';
}

// Decorator factory
export function RegisterNode<S extends GraphState>(
  graph: StateGraph<S>,
  name: string
) {
  return function (target: any): void {
    const proto = target.prototype;
    if (!isGraphNode<S>(proto)) {
      throw new Error(`Class ${target.name} lacks run(state): Partial<S>`);
    }
    const instance = new target();
    graph.addNode(name, instance);
    Reflect.defineMetadata('graph:node', name, target);
  };
}

// Demo nodes
class FetchNode {
  run(state: { url: string }): Partial<{ url: string; data: any }> {
    return { data: 'fetched' };
  }
}
class SummarizeNode {
  run(state: { data: any }): Partial<{ summary: string }> {
    return { summary: 'ok' };
  }
}

const g = new StateGraph<{ url: string; data: any }>();
RegisterNode(g, 'fetch')(FetchNode);
