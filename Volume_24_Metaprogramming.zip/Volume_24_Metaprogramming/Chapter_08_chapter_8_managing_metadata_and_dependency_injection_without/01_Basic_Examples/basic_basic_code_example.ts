/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// FILE: saas-di-basic.ts
// CONTEXT: Minimal Dependency Injection without reflect-metadata
// ============================================================================

/**
 * JSDoc: ServiceToken
 * A strongly-typed identifier used to register and resolve services.
 * We use a generic <T> so the container knows the exact return type.
 */
interface ServiceToken<T> {
  /** Unique name for the service (used as a key in our metadata map) */
  name: string;
  /** Phantom type to preserve compile-time type information */
  __type?: T;
}

/**
 * JSDoc: LoggerService
 * A simple logging service typical in a SaaS backend.
 */
class LoggerService {
  log(message: string): void {
    // In a real app this might send to Datadog or CloudWatch
    console.log(`[LOG]: ${message}`);
  }
}

/**
 * JSDoc: ReportService
 * A business service that depends on LoggerService.
 * We inject the dependency via constructor (manual DI).
 */
class ReportService {
  constructor(private logger: LoggerService) {}

  generateReport(): string {
    this.logger.log('Report generation started');
    return 'SaaS Monthly Active Users: 42,000';
  }
}

// ----------------------------------------------------------------------------
// Explicit Metadata Map (replaces reflect-metadata)
// ----------------------------------------------------------------------------
/**
 * JSDoc: Container
 * Our lightweight DI container holding explicit class references.
 */
const container = new Map<string, new (...args: any[]) => any>();

/**
 * JSDoc: register
 * Decorator factory that registers a class in the container map.
 * Uses Generics <T> to keep type inference intact for the class.
 */
function Register<T extends new (...args: any[]) => any>(token: string) {
  return (target: T): T => {
    // Store the class constructor under the given token name
    container.set(token, target);
    return target;
  };
}

// ----------------------------------------------------------------------------
// Manual Dependency Registration (no reflection)
// ----------------------------------------------------------------------------
// We explicitly associate string tokens with classes
const LOGGER_TOKEN = 'LoggerService';
const REPORT_TOKEN = 'ReportService';

// Apply our decorator to register classes
@Register(LOGGER_TOKEN)
class RegisteredLogger extends LoggerService {}

@Register(REPORT_TOKEN)
class RegisteredReport extends ReportService {}

// ----------------------------------------------------------------------------
// Resolution Function (type-safe factory)
// ----------------------------------------------------------------------------
/**
 * JSDoc: resolve
 * Retrieves an instance from the container and manually wires deps.
 * Uses Type Inference to return the correct type based on token.
 */
function resolve<T>(token: string): T {
  const ctor = container.get(token);
  if (!ctor) {
    throw new Error(`Service ${token} not registered`);
  }
  // Manual metadata: we know ReportService needs LoggerService
  if (token === REPORT_TOKEN) {
    const logger = new (container.get(LOGGER_TOKEN) as new () => LoggerService)();
    return new ctor(logger) as T;
  }
  return new ctor() as T;
}

// ----------------------------------------------------------------------------
// SaaS App Bootstrap
// ----------------------------------------------------------------------------
// In a real Next.js or Express SaaS route, we would do this on request
const reportService = resolve<ReportService>(REPORT_TOKEN);
console.log(reportService.generateReport());
