/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// Advanced Application Script: DI without reflect-metadata in a SaaS context
// ============================================================================

/**
 * UIState conceptual model from Vercel AI SDK.
 * Represents the presentation layer state: which React components to render.
 */
export interface UIState {
  components: string[];
  streamed: boolean;
}

/**
 * SharedArrayBuffer wrapper for parallel WASM/Worker compute.
 * Avoids copying large tensors between threads.
 */
export interface ComputeBuffer {
  sab: SharedArrayBuffer;
  view: Int32Array;
}

// ----------------------------------------------------------------------------
// 1. Explicit Metadata Map (no reflect-metadata)
// ----------------------------------------------------------------------------

/**
 * A manual registry mapping class constructors to their string identifiers.
 * This replaces the hidden Reflect metadata store.
 */
const METADATA_REGISTRY = new Map<string, { token: string; singleton: boolean }>();

/**
 * Decorator factory that registers a class into our explicit metadata map.
 * @param token Unique DI token
 * @param singleton Whether the container should cache the instance
 */
function Injectable(token: string, singleton = true) {
  return function <T extends { new (...args: any[]): {} }>(target: T) {
    METADATA_REGISTRY.set(token, { token, singleton });
    return target;
  };
}

// ----------------------------------------------------------------------------
// 2. Generic Lightweight DI Container
// ----------------------------------------------------------------------------

/**
 * Container that resolves dependencies via the explicit map and constructor inference.
 * Uses Generics to retain type safety without runtime reflection.
 */
class Container {
  private instances = new Map<string, any>();

  /**
   * Resolves a dependency by token.
   * @param token The DI token registered via @Injectable
   */
  resolve<T>(token: string): T {
    const meta = METADATA_REGISTRY.get(token);
    if (!meta) throw new Error(`No metadata for token: ${token}`);
    if (meta.singleton && this.instances.has(token)) {
      return this.instances.get(token) as T;
    }
    // In real apps, we would inspect constructor params; here we simplify.
    const ctor = (METADATA_REGISTRY as any).get(token).ctor;
    const instance = new ctor();
    if (meta.singleton) this.instances.set(token, instance);
    return instance as T;
  }
}

// ----------------------------------------------------------------------------
// 3. Domain Services for SaaS Dashboard
// ----------------------------------------------------------------------------

@Injectable('UIStateService')
class UIStateService {
  buildState(): UIState {
    return { components: ['Chart', 'Table'], streamed: true };
  }
}

@Injectable('ComputeService')
class ComputeService {
  createBuffer(): ComputeBuffer {
    const sab = new SharedArrayBuffer(1024);
    return { sab, view: new Int32Array(sab) };
  }
}

// ----------------------------------------------------------------------------
// 4. Next.js API Route using the Container
// ----------------------------------------------------------------------------

import type { NextApiRequest, NextApiResponse } from 'next';

const container = new Container();
// Manual ctor attachment (simulating decorator enhancement)
(METADATA_REGISTRY as any).get('UIStateService').ctor = UIStateService;
(METADATA_REGISTRY as any).get('ComputeService').ctor = ComputeService;

/**
 * API handler streaming UIState and preparing SAB for workers.
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const ui = container.resolve<UIStateService>('UIStateService');
  const compute = container.resolve<ComputeService>('ComputeService');
  const state = ui.buildState();
  const buffer = compute.createBuffer();
  res.status(200).json({ ui: state, bufferLength: buffer.sab.byteLength });
}
