/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Branded token carrying phantom type T (no runtime cost)
export type ServiceToken<T> = string & { __brand: 'ServiceToken'; __type?: T };

// Module-scoped registry (ESM safe, no globals)
export const serviceRegistry = new Map<string, new () => any>();

// Decorator factory registering class under token string
export function Service<T>(token: ServiceToken<T>): ClassDecorator {
  return (target: Function) => {
    serviceRegistry.set(token, target as new () => T);
  };
}

// Typed retrieval and instantiation
export function getService<T>(token: ServiceToken<T>): T {
  const ctor = serviceRegistry.get(token as string);
  if (!ctor) throw new Error(`No service for ${token}`);
  return new ctor();
}

// Usage example (API shape only):
// type UserServiceToken = ServiceToken<UserService>;
// const USER_SERVICE: UserServiceToken = 'user-service' as UserServiceToken;
// @Service(USER_SERVICE) class UserService { /* ... */ }
// const svc = getService(USER_SERVICE);
