/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Token with name and phantom type
export interface Token<T> {
  name: string;
  __type?: T;
}

// Container with explicit dependency map
export class Container<Deps extends Record<string, any> = {}> {
  private factories = new Map<string, () => any>();
  private cache = new Map<string, any>();

  register<K extends keyof Deps>(token: Token<Deps[K]>, factory: () => Deps[K]): void {
    this.factories.set(token.name, factory);
  }

  resolve<K extends keyof Deps>(token: Token<Deps[K]>): Deps[K] {
    if (!this.cache.has(token.name)) {
      const f = this.factories.get(token.name);
      if (!f) throw new Error(`Unregistered: ${token.name}`);
      this.cache.set(token.name, f());
    }
    return this.cache.get(token.name);
  }
}

// Example usage
interface Database { query(): void }
interface UserRepository { find(): void }
interface AppDeps { db: Database; repo: UserRepository }

const dbToken: Token<Database> = { name: 'db' };
const repoToken: Token<UserRepository> = { name: 'repo' };

const container = new Container<AppDeps>();
container.register(dbToken, () => ({ query: () => {} }));
container.register(repoToken, () => {
  const db = container.resolve(dbToken); // manual wiring
  return { find: () => db.query() };
});

// Interactive challenge answer:
// The call `container.register(loggerToken, () => 42)` with Deps.logger: string
// and Token<string> causes a TS error because factory returns number, not string.
// To guarantee rejection, register signature is:
// register<K extends keyof Deps>(token: Token<Deps[K]>, factory: () => Deps[K])
// This binds return type to Deps[K] via the token's associated type.
