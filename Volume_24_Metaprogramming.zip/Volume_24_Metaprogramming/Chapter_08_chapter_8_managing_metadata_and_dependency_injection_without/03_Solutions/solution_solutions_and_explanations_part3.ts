/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// chatTokens.ts
import { Token } from './container';
export interface ChatAnalyticsService { track(msg: string): void }
export interface MessageFormatter { format(msg: string): string }
export const ChatAnalyticsServiceToken: Token<ChatAnalyticsService> = { name: 'chatAnalytics' };
export const MessageFormatterToken: Token<MessageFormatter> = { name: 'msgFormatter' };

// chatProviders.ts
import { Container } from './container';
import { ChatAnalyticsServiceToken, MessageFormatterToken } from './chatTokens';
export const chatContainer = new Container<{
  analytics: ChatAnalyticsService;
  formatter: MessageFormatter;
}>();
chatContainer.register(ChatAnalyticsServiceToken, () => ({ track: () => {} }));
chatContainer.register(MessageFormatterToken, () => ({ format: (m) => m }));

// ChatContainerContext.tsx
import { createContext } from 'react';
import { Container } from './container';
export const ChatContainerContext = createContext<Container<any>>(chatContainer);

// useChatServices.ts
import { useContext } from 'react';
import { ChatContainerContext } from './ChatContainerContext';
import { ChatAnalyticsServiceToken, MessageFormatterToken } from './chatTokens';
export function useChatServices() {
  const container = useContext(ChatContainerContext);
  return {
    analytics: container.resolve(ChatAnalyticsServiceToken),
    formatter: container.resolve(MessageFormatterToken)
  };
}

// AIChatPanel.tsx
import { useChat } from 'ai/react';
import { useChatServices } from './useChatServices';
export function AIChatPanel() {
  const { messages, input, handleInputChange, handleSubmit } = useChat();
  const { formatter } = useChatServices();
  // UIState maps to streamable components; messages rendered via formatter
  return <form onSubmit={handleSubmit}>{messages.map(m => <p>{formatter.format(m.content)}</p>)}</form>;
}
