/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Explicit route map keyed by class and method
export const RouteMap: Record<string, Record<string, { method: string; path: string }>> = {};

export function Controller(basePath: string): ClassDecorator {
  return (target: Function) => {
    RouteMap[target.name] = RouteMap[target.name] || {};
    (RouteMap[target.name] as any).basePath = basePath;
  };
}

export function Get(path: string): MethodDecorator {
  return (target: Object, key: string | symbol) => {
    const cls = target.constructor.name;
    RouteMap[cls] = RouteMap[cls] || {};
    RouteMap[cls][key as string] = { method: 'GET', path };
  };
}

// Annotated controller (signature)
// @Controller('/users') class UserController {
//   @Get('/:id') getUser() {}
// }

export function buildRouter() {
  const endpoints: { cls: string; method: string; path: string }[] = [];
  for (const cls in RouteMap) {
    for (const m in RouteMap[cls]) {
      if (m === 'basePath') continue;
      endpoints.push({ cls, ...RouteMap[cls][m] });
    }
  }
  return endpoints;
}
