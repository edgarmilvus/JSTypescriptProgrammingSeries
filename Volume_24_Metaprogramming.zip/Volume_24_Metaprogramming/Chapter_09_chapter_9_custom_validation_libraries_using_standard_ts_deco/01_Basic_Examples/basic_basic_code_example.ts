/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// tenantValidation.ts
// ESM module: uses export/import and is enabled by "type": "module" in package.json

/**
 * A minimal property decorator that enforces a non-empty string at runtime.
 * This is the "Hello World" of custom validation decorators.
 *
 * @param target The prototype of the class (for instance properties)
 * @param propertyKey The name of the decorated property
 */
function RequiredString(target: object, propertyKey: string): void {
  // Store original descriptor if present (not strictly needed here, but good practice)
  const descriptor = Object.getOwnPropertyDescriptor(target, propertyKey);

  // Define a hidden validator map on the prototype if not present
  if (!Object.prototype.hasOwnProperty.call(target, '__validators')) {
    // Copy inherited validators to own property to avoid mutating parent prototypes
    const inherited = (target as any).__validators || {};
    Object.defineProperty(target, '__validators', {
      value: { ...inherited },
      enumerable: false,
      writable: true,
      configurable: true,
    });
  }

  // Register this property as requiring a non-empty string
  (target as any).__validators[propertyKey] = (value: unknown) => {
    if (typeof value !== 'string' || value.trim().length === 0) {
      return `Property "${propertyKey}" must be a non-empty string`;
    }
    return null;
  };
}

/**
 * Runs all registered validators on an instance and returns aggregated errors.
 * This bridges compile-time structure with runtime checks.
 *
 * @param instance The class instance to validate
 * @returns Array of error messages (empty if valid)
 */
function validateInstance(instance: object): string[] {
  const validators = (Object.getPrototypeOf(instance) as any).__validators || {};
  const errors: string[] = [];

  for (const key of Object.keys(validators)) {
    const error = validators[key]((instance as any)[key]);
    if (error) errors.push(error);
  }
  return errors;
}

/**
 * SaaS tenant settings shape.
 * In a real app this might come from a DB or onboarding form.
 */
class TenantSettings {
  @RequiredString
  tenantName!: string;

  @RequiredString
  region!: string;

  constructor(data: Partial<TenantSettings>) {
    // Assign provided (possibly untrusted) data
    Object.assign(this, data);
  }
}

/**
 * Simulated Server Action receiving external input.
 * Server Actions run on the server and must validate external data.
 *
 * @param formData Untrusted payload from a client form or API
 */
export async function saveTenantSettings(formData: Partial<TenantSettings>) {
  // Create instance from untrusted input
  const settings = new TenantSettings(formData);

  // Perform runtime validation
  const errors = validateInstance(settings);
  if (errors.length > 0) {
    return { success: false, errors };
  }

  // In a real SaaS app, persist to database here
  return { success: true, settings };
}

// Self-contained demo (would be removed in production)
(async () => {
  const badInput = { tenantName: '', region: 'us-east' };
  const result = await saveTenantSettings(badInput);
  console.log(result);
})();
