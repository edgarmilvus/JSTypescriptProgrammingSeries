/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// subscription.validator.ts
// ESM module for Next.js Edge API route validation
// Uses standard TS decorators (no experimentalDecorators legacy mode required in TS 5.8+)

/**
 * Symbol used to store validation metadata on class prototypes.
 * This bridges compile-time decorator calls to runtime reflection.
 */
const VALIDATION_META = Symbol('validation:rules');

/**
 * Interface describing a single validation rule attached to a property.
 */
interface ValidationRule {
  property: string;
  validator: (value: unknown) => string | null; // returns error message or null
  label: string;
}

/**
 * Internal helper to register a validation rule on a class prototype.
 * This is the "under the hood" metadata aggregation mechanism.
 */
function registerRule(
  target: object,
  property: string,
  rule: Omit<ValidationRule, 'property'>
) {
  const proto = target as any;
  if (!proto[VALIDATION_META]) {
    proto[VALIDATION_META] = [] as ValidationRule[];
  }
  proto[VALIDATION_META].push({ property, ...rule });
}

/**
 * Decorator: @Required()
 * Marks a property as non-nullable and non-undefined at runtime.
 */
function Required() {
  return function (target: object, propertyKey: string) {
    registerRule(target, propertyKey, {
      label: 'Required',
      validator: (v) =>
        v === null || v === undefined ? `${propertyKey} is required` : null,
    });
  };
}

/**
 * Decorator: @StringRange(min, max)
 * Ensures string length is within bounds (SaaS plan codes, etc.).
 */
function StringRange(min: number, max: number) {
  return function (target: object, propertyKey: string) {
    registerRule(target, propertyKey, {
      label: `StringRange(${min},${max})`,
      validator: (v) => {
        if (typeof v !== 'string') return `${propertyKey} must be string`;
        if (v.length < min || v.length > max)
          return `${propertyKey} length must be ${min}-${max}`;
        return null;
      },
    });
  };
}

/**
 * Decorator: @IsEmail()
 * Basic email shape check for account owner field.
 */
function IsEmail() {
  return function (target: object, propertyKey: string) {
    registerRule(target, propertyKey, {
      label: 'IsEmail',
      validator: (v) =>
        typeof v === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
          ? null
          : `${propertyKey} must be valid email`,
    });
  };
}

/**
 * Runtime validator function that aggregates all decorator-based rules.
 * This is the bridge between decorators and Edge Runtime API logic.
 */
export function validateModel<T extends object>(instance: T): string[] {
  const rules = (Object.getPrototypeOf(instance) as any)[VALIDATION_META] as
    | ValidationRule[]
    | undefined;
  if (!rules) return [];
  const errors: string[] = [];
  for (const rule of rules) {
    const err = rule.validator((instance as any)[rule.property]);
    if (err) errors.push(err);
  }
  return errors;
}

/**
 * DTO class representing a SaaS subscription upgrade request.
 * Decorators enforce constraints without external schema libs.
 */
export class UpgradeRequestDto {
  @Required()
  @IsEmail()
  accountOwner!: string;

  @Required()
  @StringRange(3, 12)
  targetPlan!: string;

  @Required()
  billingCycle!: 'monthly' | 'yearly';
}

/**
 * Next.js Edge Route Handler using the custom validation library.
 * Runs on Edge Runtime (V8 isolate) with ESM imports.
 */
export const runtime = 'edge';

export async function POST(req: Request): Promise<Response> {
  // 1. Parse JSON from inbound request (Edge-safe)
  const body = await req.json();

  // 2. Instantiate DTO and assign parsed fields
  const dto = Object.assign(new UpgradeRequestDto(), body);

  // 3. Execute decorator-driven validation
  const errors = validateModel(dto);
  if (errors.length > 0) {
    // 4. Aggregate and return errors as JSON (SaaS API contract)
    return new Response(
      JSON.stringify({ ok: false, errors }),
      { status: 422, headers: { 'content-type': 'application/json' } }
    );
  }

  // 5. Simulated upgrade processing (no external DB in this snippet)
  return new Response(
    JSON.stringify({ ok: true, upgradedTo: dto.targetPlan }),
    { status: 200, headers: { 'content-type': 'application/json' } }
  );
}
