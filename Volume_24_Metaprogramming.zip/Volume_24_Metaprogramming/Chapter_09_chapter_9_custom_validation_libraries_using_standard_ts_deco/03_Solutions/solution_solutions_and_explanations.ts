/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Decorator factory returning a standard property decorator
function Range(min: number, max: number) {
  return function (target: object, propertyKey: string | symbol): void {
    // Store range constraint in metadata keyed by class prototype and property
    Reflect.defineMetadata('validation:range', { min, max }, target, propertyKey);
  };
}

// Central validator that aggregates range errors
function validate(instance: object): void {
  const target = Object.getPrototypeOf(instance);
  const keys = Reflect.getMetadataKeys(target) as (string | symbol)[];
  for (const propertyKey of keys) {
    const range = Reflect.getMetadata('validation:range', target, propertyKey);
    if (range) {
      const value = Reflect.get(instance, propertyKey);
      if (value < range.min || value > range.max) {
        throw new Error(`Property ${String(propertyKey)} out of range`);
      }
    }
  }
}

// API sketch for UserAccount
class UserAccount {
  @Range(18, 120)
  age!: number;

  @Range(0, 100000)
  creditLimit!: number;
}
