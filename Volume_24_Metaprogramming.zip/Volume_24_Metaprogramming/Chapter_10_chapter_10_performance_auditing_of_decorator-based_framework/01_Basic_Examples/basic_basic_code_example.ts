/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// SaaS Context: Minimal Billing Service with a Basic Method Decorator
// ============================================================================

/**
 * A simple method decorator that logs entry and exit of a function.
 * This mimics cross-cutting logging behavior found in SaaS frameworks.
 *
 * @param target - The prototype of the class (for instance methods)
 * @param propertyKey - The name of the method being decorated
 * @param descriptor - The property descriptor for the method
 */
function LogMethod(
  target: Object,
  propertyKey: string,
  descriptor: PropertyDescriptor
): PropertyDescriptor {
  // Save a reference to the original method
  const originalMethod = descriptor.value;

  // Replace the method with a wrapped version
  descriptor.value = function (...args: any[]) {
    // Log method entry with arguments
    console.log(`[LOG] Entering ${propertyKey} with args:`, args);

    // Call the original method with the correct `this` context
    const result = originalMethod.apply(this, args);

    // Log method exit with result
    console.log(`[LOG] Exiting ${propertyKey} with result:`, result);

    // Return the original result to keep behavior identical
    return result;
  };

  // Return the modified descriptor
  return descriptor;
}

/**
 * Simulated SaaS billing service.
 * In a real app this might talk to Stripe or a database.
 */
class BillingService {
  /**
   * Computes a discounted price for a given base price and discount rate.
   * @param basePrice - Original price in cents
   * @param discountRate - Value between 0 and 1
   */
  @LogMethod
  calculateDiscountedPrice(basePrice: number, discountRate: number): number {
    return basePrice * (1 - discountRate);
  }
}

// --- Usage in a fictional web route handler ---

const billing = new BillingService();

// Simulate a request from a web app
const finalPrice = billing.calculateDiscountedPrice(10000, 0.2);

console.log('Final price sent to client:', finalPrice);
