/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// tsconfig.json (relevant parts)
// {
//   "compilerOptions": {
//     "experimentalDecorators": true,
//     "emitDecoratorMetadata": true,
//     "target": "ES2018",
//     "module": "CommonJS"
//   }
// }

// profiler.ts
import { performance } from 'perf_hooks';

type DecoratorFn = (...args: any[]) => any;

const globalStats = new Map<string, { total: number; count: number }>();

export function profileDecorator<T extends DecoratorFn>(dec: T, name: string): T {
  return function (this: any, ...args: any[]) {
    const start = performance.now();
    const result = dec.apply(this, args);
    const end = performance.now();
    const stat = globalStats.get(name) ?? { total: 0, count: 0 };
    stat.total += end - start;
    stat.count += 1;
    globalStats.set(name, stat);
    return result;
  } as T;
}

export function printReport(): void {
  console.log('Decorator Audit Report:');
  for (const [name, { total, count }] of globalStats) {
    console.log(
      `  ${name}: total=${total.toFixed(2)}ms, invocations=${count}, avg=${(total / count).toFixed(4)}ms`
    );
  }
}

// orm.ts
import { profileDecorator } from './profiler';

function EntityImpl(tableName: string) {
  return function (target: Function) {
    // simulate registry work
    (target as any).__table = tableName;
  };
}

function ColumnImpl(options?: { type?: string; index?: boolean }) {
  return function (target: Object, propertyKey: string) {
    (target.constructor as any).__cols = (target.constructor as any).__cols ?? [];
    (target.constructor as any).__cols.push(propertyKey);
  };
}

function PrimaryKeyImpl() {
  return function (target: Object, propertyKey: string) {
    (target.constructor as any).__pk = propertyKey;
  };
}

export const Entity = profileDecorator(EntityImpl, 'Entity');
export const Column = profileDecorator(ColumnImpl, 'Column');
export const PrimaryKey = profileDecorator(PrimaryKeyImpl, 'PrimaryKey');

// generate 50 mock entities
function makeEntity(i: number) {
  class MockEntity {}
  Entity(`table_${i}`)(MockEntity);
  Column({ type: 'string', index: true })(new MockEntity(), 'id');
  PrimaryKey()(new MockEntity(), 'id');
  return MockEntity;
}

for (let i = 0; i < 50; i++) makeEntity(i);

printReport();

// Discussion (in comments):
// Unavoidable: decorator must run to attach metadata for ORM at class definition.
// Deferrable: building indexes or validating schemas could be lazy on first query.
// emitDecoratorMetadata adds Reflect.metadata calls increasing eval cost.
