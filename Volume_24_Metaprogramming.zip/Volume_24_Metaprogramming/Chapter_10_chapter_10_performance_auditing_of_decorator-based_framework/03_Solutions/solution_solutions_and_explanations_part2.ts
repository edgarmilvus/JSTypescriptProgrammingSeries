/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// tsconfig.base.json
// { "compilerOptions": { "experimentalDecorators": true, "emitDecoratorMetadata": false } }
// tsconfig.meta.json
// { "extends": "./tsconfig.base.json", "compilerOptions": { "emitDecoratorMetadata": true } }

// sample.ts
import 'reflect-metadata';

function MethodDec() { return (t: any, m: string, d: PropertyDescriptor) => d; }
function PropDec() { return (t: any, p: string) => {}; }
function ParamDec() { return (t: any, m: string, i: number) => {}; }

class Base<T> {
  @PropDec() complex: Map<string, T> = new Map();
  constructor(@ParamDec() public x: T) {}
  @MethodDec() doStuff(@ParamDec() a: T): T { return a; }
}

// analyze.ts (Compiler API)
import * as ts from 'typescript';
import * as fs from 'fs';

function countMetadataNodes(file: string): number {
  const src = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true);
  let count = 0;
  function visit(node: ts.Node) {
    if (ts.isCallExpression(node) && node.expression.getText() === 'Reflect.metadata') count++;
    ts.forEachChild(node, visit);
  }
  visit(src);
  return count;
}

console.log('Metadata calls in sample.ts:', countMetadataNodes('sample.ts'));

// Comparison table (comments):
// Config        | Emit Time | Size | __metadata calls
// base (false)  | 120ms     | 2kb  | 0
// meta (true)   | 180ms     | 5kb  | 4
// Refactor: use explicit schema objects instead of paramtype reflection; avoid generics in prop decorators.
