/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * InvoiceLens – Minimal AST Inspection
 * A Hello-World grade example of using the TypeScript Compiler API
 * to parse a string of TS source and walk the resulting AST.
 */

// 1. Import the TypeScript compiler API as a single namespace.
//    In a real SaaS service this would be a dependency in your build/analysis worker.
import * as ts from "typescript";

/**
 * The raw TypeScript source we want to analyze.
 * In a real SaaS app this might arrive from a user's GitHub repo or a paste buffer.
 */
const userConfigSource = `
/**
 * InvoiceLens workspace configuration
 */
interface WorkspaceConfig {
  workspaceId: string;
  maxInvoicesPerMonth: number;
  enableBetaFeatures: boolean;
}

const config: WorkspaceConfig = {
  workspaceId: "ws_12345",
  maxInvoicesPerMonth: 500,
  enableBetaFeatures: false
};
`;

/**
 * Step 1: Create a SourceFile.
 * A SourceFile is the root node of any TS AST. It holds the parsed text,
 * the language version, and the syntactic tree.
 */
const sourceFile = ts.createSourceFile(
  "user-config.ts",                 // virtual file name
  userConfigSource,                 // the source text
  ts.ScriptTarget.Latest,           // use latest JS/TS target
  /* setParentNodes */ true         // required if we want parent references
);

/**
 * Step 2: Define a simple AST visitor.
 * This function recursively walks the tree. In a larger SaaS code-base
 * you would replace console logging with rule checks or telemetry.
 * @param node The current AST node being visited
 */
function visitNode(node: ts.Node): void {
  // Log the kind of node we are currently inspecting.
  // ts.SyntaxKind is an enum mapping numeric ids to grammar productions.
  console.log(`Visiting node of kind: ${ts.SyntaxKind[node.kind]}`);

  // Recursively visit every child of this node.
  // ts.forEachChild is the officially recommended traversal helper.
  ts.forEachChild(node, visitNode);
}

/**
 * Step 3: Kick off the traversal from the root SourceFile.
 */
visitNode(sourceFile);

/**
 * Step 4: Demonstrate a tiny type-aware inspection using a Program + TypeChecker.
 * We build an in-memory program so we can later ask "what is the type of config?".
 */
const program = ts.createProgram(["user-config.ts"], {
  // We must provide a compiler host that resolves our virtual file.
  // For brevity we use a custom host that returns our string.
});
