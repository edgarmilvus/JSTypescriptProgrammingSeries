/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * InvoiceLens – Fully Self-Contained AST + TypeChecker Example
 */
import * as ts from "typescript";

// The same fictional user config source.
const userConfigSource = `
interface WorkspaceConfig {
  workspaceId: string;
  maxInvoicesPerMonth: number;
  enableBetaFeatures: boolean;
}

const config: WorkspaceConfig = {
  workspaceId: "ws_12345",
  maxInvoicesPerMonth: 500,
  enableBetaFeatures: false
};
`;

// We create a virtual source file in memory.
const fileName = "user-config.ts";
const sourceFile = ts.createSourceFile(
  fileName,
  userConfigSource,
  ts.ScriptTarget.Latest,
  true
);

// A minimal CompilerHost that only knows about our one virtual file.
const host: ts.CompilerHost = {
  getSourceFile: (name) => (name === fileName ? sourceFile : undefined),
  getDefaultLibFileName: () => "lib.d.ts",
  writeFile: () => {},
  getCurrentDirectory: () => "",
  getDirectories: () => [],
  fileExists: (name) => name === fileName,
  readFile: (name) => (name === fileName ? userConfigSource : undefined),
  getCanonicalFileName: (name) => name,
  useCaseSensitiveFileNames: () => true,
  getNewLine: () => "\n",
};

// Create an in-memory program.
const program = ts.createProgram([fileName], {
  noLib: true,
  target: ts.ScriptTarget.Latest,
}, host);

// The TypeChecker is the bridge between syntax (AST) and semantics (types).
const typeChecker = program.getTypeChecker();

/**
 * Visitor that logs syntax kinds and, for variable declarations,
 * prints the inferred/declared type using the TypeChecker.
 * @param node Current AST node
 */
function visit(node: ts.Node): void {
  console.log(`Node: ${ts.SyntaxKind[node.kind]}`);

  if (ts.isVariableDeclaration(node) && node.name) {
    const symbol = typeChecker.getSymbolAtLocation(node.name);
    if (symbol) {
      const type = typeChecker.getTypeOfSymbolAtLocation(symbol, node);
      console.log(`  ↳ Variable "${symbol.getName()}" has type: ${
        typeChecker.typeToString(type)
      }`);
    }
  }

  ts.forEachChild(node, visit);
}

visit(sourceFile);
