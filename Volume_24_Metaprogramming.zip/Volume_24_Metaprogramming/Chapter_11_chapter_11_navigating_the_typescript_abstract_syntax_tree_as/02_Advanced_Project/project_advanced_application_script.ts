/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/analyze-ast.ts
// Next.js API route that exposes AST inspection as a service.

import type { NextApiRequest, NextApiResponse } from "next";
import * as ts from "typescript";
import { Redis } from "ioredis";

/**
 * Checkpointer abstraction (LangGraph style) used to persist analysis state.
 * In a SaaS context this allows resuming long AST scans after server restarts.
 */
interface Checkpointer {
  save(state: AnalysisState): Promise<void>;
  load(txId: string): Promise<AnalysisState | null>;
}

/**
 * Minimal Redis-backed checkpointer implementation.
 */
class RedisCheckpointer implements Checkpointer {
  private client: Redis;

  constructor() {
    this.client = new Redis(process.env.REDIS_URL!);
  }

  async save(state: AnalysisState): Promise<void> {
    // Persist the entire graph state after node execution.
    await this.client.set(`ast:${state.txId}`, JSON.stringify(state));
  }

  async load(txId: string): Promise<AnalysisState | null> {
    const raw = await this.client.get(`ast:${txId}`);
    return raw ? JSON.parse(raw) : null;
  }
}

/**
 * Shape of the analysis state stored by the checkpointer.
 */
interface AnalysisState {
  txId: string;
  source: string;
  foundUtilityTypes: string[];
  nodeCount: number;
  completed: boolean;
}

/**
 * Utility type extracted from source using AST.
 */
interface UtilityTypeUsage {
  name: string;       // e.g., "Partial"
  typeArgument: string; // e.g., "User"
  position: number;
}

/**
 * Main API handler.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 1. Receive source code from SaaS client.
  const { source, txId } = req.body as { source: string; txId?: string };

  // 2. Initialize checkpointer for state hydration.
  const checkpointer = new RedisCheckpointer();
  let state: AnalysisState =
    (txId && (await checkpointer.load(txId))) ||
    {
      txId: txId ?? `tx_${Date.now()}`,
      source,
      foundUtilityTypes: [],
      nodeCount: 0,
      completed: false,
    };

  // 3. Create TypeScript AST from source string.
  const sourceFile = ts.createSourceFile(
    "virtual.ts",
    state.source,
    ts.ScriptTarget.Latest,
    true
  );

  // 4. Prepare collector for utility type usages.
  const usages: UtilityTypeUsage[] = [];

  // 5. Recursive AST visitor function.
  function visit(node: ts.Node) {
    state.nodeCount++;
    // Detect type references (e.g., Partial<User>)
    if (ts.isTypeReferenceNode(node)) {
      const typeName = node.typeName.getText(sourceFile);
      if (["Partial", "Readonly", "Pick"].includes(typeName)) {
        const arg = node.typeArguments?.[0]?.getText(sourceFile) ?? "unknown";
        usages.push({
          name: typeName,
          typeArgument: arg,
          position: node.getStart(sourceFile),
        });
        state.foundUtilityTypes.push(typeName);
      }
    }
    // Continue traversal recursively.
    ts.forEachChild(node, visit);
  }

  // 6. Execute traversal.
  visit(sourceFile);

  // 7. Mark state completed and persist.
  state.completed = true;
  await checkpointer.save(state);

  // 8. Return JSON report to SaaS dashboard.
  res.status(200).json({
    txId: state.txId,
    nodeCount: state.nodeCount,
    usages,
  });
}
