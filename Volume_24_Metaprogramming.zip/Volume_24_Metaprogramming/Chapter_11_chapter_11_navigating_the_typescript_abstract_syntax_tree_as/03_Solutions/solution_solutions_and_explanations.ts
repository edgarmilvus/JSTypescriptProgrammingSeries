/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

/**
 * Counts InterfaceDeclaration nodes in the given source text.
 * Note: ts.forEachChild is safer than manual getChildren() recursion without
 * a source file because forEachChild automatically provides the correct
 * parent/source context and visits only the syntactic children owned by the
 * node, avoiding missing nodes or mis-resolving positions that can happen
 * when getChildren() is called without the SourceFile context.
 */
export function countInterfaces(sourceText: string): number {
  const sourceFile = ts.createSourceFile(
    'sample.ts',
    sourceText,
    ts.ScriptTarget.Latest,
    true // setParentNodes
  );

  let count = 0;

  function visit(node: ts.Node): void {
    if (node.kind === ts.SyntaxKind.InterfaceDeclaration) {
      count++;
    }
    ts.forEachChild(node, visit);
  }

  visit(sourceFile);
  return count;
}

/*
Sample input shape (not executed here):
const sample = `
  interface TopLevel { a: number }
  namespace Nested {
    interface Inner { b: string }
  }
`;
// Contains 2 interfaces: one top-level, one inside namespace.
*/
