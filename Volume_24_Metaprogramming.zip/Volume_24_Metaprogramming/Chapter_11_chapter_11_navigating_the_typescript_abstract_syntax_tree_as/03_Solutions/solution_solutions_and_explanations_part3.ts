/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

interface Report { name: string; reason: string; }

function checkValidation(sourceText: string): Report[] {
  const sf = ts.createSourceFile('f.ts', sourceText, ts.ScriptTarget.Latest, true);
  const reports: Report[] = [];

  function hasValidateCall(node: ts.Node): boolean {
    let found = false;
    function v(n: ts.Node) {
      if (ts.isCallExpression(n) && n.expression.getText(sf) === 'validate') found = true;
      ts.forEachChild(n, v);
    }
    v(node);
    return found;
  }

  function visit(n: ts.Node) {
    if (ts.isFunctionDeclaration(n) && n.body) {
      const hasExternal = n.getFullText(sf).includes('// @external');
      const hasAny = n.parameters.some(p => p.type?.kind === ts.SyntaxKind.AnyKeyword);
      if ((hasExternal || hasAny) && !hasValidateCall(n.body)) {
        reports.push({ name: n.name?.text ?? 'anon', reason: hasAny ? 'any param' : '@external' });
      }
    }
    ts.forEachChild(n, visit);
  }
  visit(sf);
  return reports;
}
