/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// @ts-nocheck
// The above directive is only for standalone snippet execution;
// in a real ESLint plugin project, TypeScript strictness is enabled.

import { ESLintUtils } from "@typescript-eslint/utils";
import type { TSESTree } from "@typescript-eslint/typescript-estree";
import type { ParserServices } from "@typescript-eslint/parser";

/**
 * A minimal SaaS context type used to simulate our dashboard's route definitions.
 */
type SaaSRouteContext = {
  tenantId: string;
  plan: "free" | "pro" | "enterprise";
};

/**
 * Simulated Zod-like namespace for demonstration (real code imports 'zod').
 */
declare namespace z {
  export interface ZodTypeAny {
    readonly __brand: "zod";
  }
  export function object<T extends z.ZodTypeAny>(shape: T): T;
}

/**
 * The RuleCreator provided by @typescript-eslint/utils standardizes rule metadata.
 */
const createRule = ESLintUtils.RuleCreator(
  (name) => `https://saas-docs.internal/rules/${name}`
);

/**
 * Our custom rule: enforces that any function tagged with @saas-route
 * returns a Zod schema type, ensuring LLM JSON Schema output aligns
 * with our System Prompt contracts.
 */
export const requireZodReturn = createRule({
  name: "require-zod-return-for-saas-route",
  meta: {
    type: "problem",
    docs: {
      description:
        "Enforce that SaaS route handlers declare a Zod return schema for LLM JSON output",
      recommended: "error",
    },
    schema: [],
    messages: {
      missingZod:
        "SaaS route handler must return a Zod schema (z.ZodTypeAny) to validate LLM JSON Schema output.",
    },
  },
  defaultOptions: [],
  create(context) {
    // Obtain TypeScript parser services to access the type checker.
    const services = ESLintUtils.getParserServices(context) as ParserServices;
    const checker = services.program.getTypeChecker();

    return {
      /**
       * Visitor: inspect every function declaration in the AST.
       */
      FunctionDeclaration(node: TSESTree.FunctionDeclaration) {
        // 1. Check for JSDoc tag @saas-route
        const jsdoc = context.getSourceCode().getJSDocComment(node);
        if (!jsdoc) return;
        const hasTag = jsdoc.tags?.some((t) => t.tag === "saas-route");
        if (!hasTag) return;

        // 2. Map AST node to TypeScript type node
        const tsNode = services.esTreeNodeToTSNodeMap.get(node);
        if (!tsNode) return;

        // 3. Retrieve the function's return type from the checker
        const signature = checker.getSignatureFromDeclaration(tsNode);
        if (!signature) return;
        const returnType = checker.getReturnTypeOfSignature(signature);

        // 4. Check if return type is or derives from z.ZodTypeAny
        const isZod = isTypeZod(returnType, checker);
        if (!isZod) {
          context.report({
            node,
            messageId: "missingZod",
          });
        }
      },
    };

    /**
     * Helper: walk the type to see if it is ZodTypeAny or a Promise thereof.
     */
    function isTypeZod(type: any, chk: typeof checker): boolean {
      // Unwrap Promise<T>
      if (type.symbol?.name === "Promise") {
        const typeArgs = (type as any).typeArguments;
        if (typeArgs && typeArgs.length > 0) {
          return isTypeZod(typeArgs[0], chk);
        }
      }
      // Check symbol name or brand property
      const sym = type.symbol;
      if (sym && sym.name === "ZodTypeAny") return true;
      // Fallback: check properties for __brand
      const props = chk.getPropertiesOfType(type);
      return props.some((p) => p.getName() === "__brand");
    }
  },
});

/**
 * Example usage in a SaaS route file (this would be linted):
 *
 * @saas-route
 * function getTenantSchema() {
 *   return z.object({ tenantId: "string" }); // passes
 * }
 *
 * @saas-route
 * function badRoute() {
 *   return { foo: "bar" }; // fails lint
 * }
 */
