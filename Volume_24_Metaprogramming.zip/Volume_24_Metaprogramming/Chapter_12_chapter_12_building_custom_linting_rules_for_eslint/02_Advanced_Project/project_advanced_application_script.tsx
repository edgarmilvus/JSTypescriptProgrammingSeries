/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// pages/api/lint-billing.tsx
import type { NextApiRequest, NextApiResponse } from "next";
import { Linter } from "eslint";
import * as ts from "typescript";
import { parseForESLint } from "@typescript-eslint/parser";

/**
 * Custom TypeScript-aware ESLint rule definition.
 * Detects usage of raw 'string' where a branded 'PlanTier' type is required.
 */
const noRawStringPlanTierRule: Linter.RuleModule = {
  meta: {
    type: "problem",
    docs: { description: "Enforce branded PlanTier type in billing functions" },
    schema: [],
    messages: { invalid: "Use PlanTier branded type, not raw string" },
  },
  create(context) {
    // Access TypeScript type checker from parser services
    const parserServices = context.parserServices as any;
    const checker: ts.TypeChecker = parserServices.program.getTypeChecker();

    return {
      // Visit every function call expression in the SaaS codebase
      CallExpression(node: any) {
        const callee = node.callee;
        if (callee.name !== "assignPlan") return;

        const arg = node.arguments[0];
        const tsNode = parserServices.esTreeNodeToTSNodeMap.get(arg);
        const type = checker.getTypeAtLocation(tsNode);

        // If the argument is a primitive string, flag violation
        if (checker.typeToString(type) === "string") {
          context.report({ node: arg, messageId: "invalid" });
        }
      },
    };
  },
};

/**
 * Next.js API handler that lints a submitted billing code snippet.
 * Returns JSON Schema-like violation report for LLM or dashboard consumption.
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Extract code snippet from request body (SaaS internal tooling)
  const { code } = req.body as { code: string };

  // 2. Configure ESLint Linter with TypeScript parser and custom rule
  const linter = new Linter();
  linter.defineParser("@typescript-eslint/parser", {
    parseForESLint: (text: string) =>
      parseForESLint(text, {
        project: "./tsconfig.json",
        tsconfigRootDir: process.cwd(),
      }),
  });
  linter.defineRule("saas/no-raw-string-plan-tier", noRawStringPlanTierRule);

  // 3. Execute linting against the provided code
  const messages = linter.verify(code, {
    parser: "@typescript-eslint/parser",
    rules: { "saas/no-raw-string-plan-tier": "error" },
    parserOptions: { project: "./tsconfig.json" },
  });

  // 4. Shape output as JSON Schema-friendly object for downstream LLM use
  const report = {
    violations: messages.map((m) => ({
      line: m.line,
      column: m.column,
      message: m.message,
    })),
  };

  res.status(200).json(report);
}
