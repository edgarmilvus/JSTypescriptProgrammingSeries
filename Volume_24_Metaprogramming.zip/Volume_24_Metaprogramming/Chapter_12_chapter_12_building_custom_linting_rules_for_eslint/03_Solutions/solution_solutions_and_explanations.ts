/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { ESLintUtils } from '@typescript-eslint/utils';
import * as ts from 'typescript';

export const ruleCreator = ESLintUtils.RuleCreator(
  (name) => `https://example.com/rule/${name}`
);

export const noUntypedEventParams = ruleCreator({
  name: 'ts/no-untyped-event-params',
  meta: {
    type: 'problem',
    docs: { description: 'Disallow untyped event handler params (any)' },
    schema: [{
      type: 'object',
      properties: {
        allowedHandlers: {
          type: 'array',
          items: { type: 'string' }
        }
      },
      additionalProperties: false
    }],
    messages: {
      untyped: 'Event param is any. Use explicit React event type (e.g. React.MouseEvent).'
    }
  },
  defaultOptions: [{ allowedHandlers: ['onClick', 'onChange'] }],
  create(context, [options]) {
    const parserServices = ESLintUtils.getParserServices(context);
    const checker = parserServices.program.getTypeChecker();
    const allowed = new Set(options.allowedHandlers);

    return {
      JSXAttribute(node) {
        if (node.name.type !== 'JSXIdentifier') return;
        if (!allowed.has(node.name.name)) return;
        const value = node.value;
        if (!value || value.type !== 'JSXExpressionContainer') return;
        const expr = value.expression;
        if (expr.type !== 'ArrowFunctionExpression' && expr.type !== 'FunctionExpression') return;

        for (const param of expr.params) {
          const tsNode = parserServices.eslintNodeToTSNodeMap.get(param);
          if (!tsNode) continue;
          const type = checker.getTypeAtLocation(tsNode);
          if (type.flags & ts.TypeFlags.Any) {
            context.report({ node: param, messageId: 'untyped' });
          }
        }
      }
    };
  }
});
