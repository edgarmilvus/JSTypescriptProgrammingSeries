/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { ESLintUtils } from '@typescript-eslint/utils';
import * as ts from 'typescript';

export const requireBrandedTypes = ESLintUtils.RuleCreator(
  (n) => `https://example.com/${n}`
)({
  name: 'ts/require-branded-types-at-boundary',
  meta: {
    type: 'problem',
    docs: { description: 'Require branded types at API boundaries' },
    schema: [{
      type: 'object',
      properties: {
        boundaryFunctions: { type: 'array', items: { type: 'string' } },
        brandPattern: { type: 'string' }
      },
      additionalProperties: false
    }],
    messages: { notBranded: 'Argument must be branded type, got primitive.' }
  },
  defaultOptions: [{ boundaryFunctions: [], brandPattern: '^__brand' }],
  create(context, [options]) {
    const services = ESLintUtils.getParserServices(context);
    const checker = services.program.getTypeChecker();
    const boundaries = new Set(options.boundaryFunctions);
    const brandRe = new RegExp(options.brandPattern);

    function isBranded(type: ts.Type): boolean {
      const apparent = checker.getApparentType(type);
      if (apparent.isIntersection()) {
        return apparent.types.some(t =>
          t.getProperties().some(p => brandRe.test(p.getName()))
        );
      }
      return false;
    }

    return {
      CallExpression(node) {
        const tsNode = services.eslintNodeToTSNodeMap.get(node);
        const sig = checker.getResolvedSignature(tsNode as ts.CallExpression);
        if (!sig) return;
        const decl = sig.declaration;
        if (!decl || !ts.isFunctionLikeDeclaration(decl)) return;
        const fname = checker.getFullyQualifiedName(decl as ts.Symbol as any);
        if (!boundaries.has(fname)) return;

        node.arguments.forEach((arg, i) => {
          const param = sig.parameters[i];
          if (!param) return;
          const paramType = checker.getTypeOfSymbolAtLocation(param, tsNode!);
          if (!isBranded(paramType)) return;
          const argTs = services.eslintNodeToTSNodeMap.get(arg);
          const argType = checker.getTypeAtLocation(argTs!);
          if (argType.isStringLiteral() || argType.isNumberLiteral()) {
            const leading = context.getSourceCode().getCommentsBefore(arg);
            if (leading.some(c => c.value.includes('@brand-ok'))) return;
          }
          if (argType.isString() || argType.isNumber()) {
            context.report({ node: arg, messageId: 'notBranded' });
          }
        });
      }
    };
  }
});
