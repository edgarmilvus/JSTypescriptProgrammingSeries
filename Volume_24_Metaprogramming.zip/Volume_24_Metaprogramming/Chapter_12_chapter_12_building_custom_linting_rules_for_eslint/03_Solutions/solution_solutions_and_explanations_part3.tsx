/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { useChat } from 'ai/react';
import { z } from 'zod';
import { useState } from 'react';

const SYSTEM_PROMPT = `You are a TypeScript lint educator. Given code and a rule, return violations using JSON Schema Output.`; // hidden from UI

const ViolationSchema = z.object({
  line: z.number(),
  column: z.number(),
  ruleId: z.string(),
  message: z.string(),
  suggestion: z.string()
});

export function LintPlayground() {
  const [code, setCode] = useState('');
  const [selectedRule, setSelectedRule] = useState('ts/no-untyped-event-params');
  const { messages, append, isLoading } = useChat();

  const analyze = () => {
    append({
      role: 'user',
      content: `${SYSTEM_PROMPT}\nRule: ${selectedRule}\nCode:\n${code}`
    });
  };

  return (
    <div>
      <textarea value={code} onChange={e => setCode(e.target.value)} />
      <select value={selectedRule} onChange={e => setSelectedRule(e.target.value)}>
        <option value="ts/no-untyped-event-params">no-untyped-event-params</option>
      </select>
      <button onClick={analyze}>Analyze</button>
      {messages.map(m => {
        try {
          const parsed = JSON.parse(m.content);
          const violations = z.array(ViolationSchema).parse(parsed.violations);
          return (
            <table>{violations.map(v => (
              <tr key={v.line}><td>{v.ruleId}</td><td>{v.message}</td><td>{v.suggestion}</td></tr>
            ))}</table>
          );
        } catch {
          return <div>Fallback: malformed response</div>;
        }
      })}
    </div>
  );
}
