/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { ESLintUtils } from '@typescript-eslint/utils';
import * as ts from 'typescript';

export const noImplicitNullAsync = ESLintUtils.RuleCreator(
  (n) => `https://example.com/${n}`
)({
  name: 'ts/no-implicit-null-in-async',
  meta: {
    type: 'problem',
    docs: { description: 'No implicit null in async' },
    schema: [],
    messages: { implicit: 'Promise function returns implicit null/undefined' }
  },
  defaultOptions: [],
  create(context) {
    const services = ESLintUtils.getParserServices(context);
    const checker = services.program.getTypeChecker();

    return {
      'FunctionDeclaration, ArrowFunctionExpression'(node: any) {
        const tsNode = services.eslintNodeToTSNodeMap.get(node);
        const sig = checker.getSignatureFromDeclaration(tsNode as ts.SignatureDeclaration);
        if (!sig) return;
        const retType = checker.getReturnTypeOfSignature(sig);
        if (!retType.getSymbol()?.getName().includes('Promise')) return;
        if (node.async !== true) return;
        const body = tsNode.body;
        if (!body) return;
        ts.forEachChild(body, function visit(n) {
          if (ts.isReturnStatement(n)) {
            if (!n.expression) context.report({ node, messageId: 'implicit' });
            else {
              const t = checker.getTypeAtLocation(n.expression);
              if (t.flags & (ts.TypeFlags.Null | ts.TypeFlags.Undefined))
                context.report({ node, messageId: 'implicit' });
            }
          }
          ts.forEachChild(n, visit);
        });
      }
    };
  }
});
