/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { ESLintUtils } from '@typescript-eslint/utils';
import * as ts from 'typescript';

export const consistentDecorator = ESLintUtils.RuleCreator(
  (n) => `https://example.com/${n}`
)({
  name: 'ts/consistent-decorator-factory',
  meta: {
    type: 'problem',
    docs: { description: 'Enforce decorator factory usage' },
    schema: [{
      type: 'object',
      additionalProperties: {
        type: 'object',
        properties: { args: { type: 'array', items: { type: 'string' } } }
      }
    }],
    messages: {
      needFactory: 'Decorator must be called as factory',
      badArg: 'Decorator argument type mismatch'
    }
  },
  defaultOptions: [{}],
  create(context, [options]) {
    const services = ESLintUtils.getParserServices(context);
    const checker = services.program.getTypeChecker();

    return {
      Decorator(node: any) {
        const expr = node.expression;
        if (expr.type === 'Identifier') {
          if (options[expr.name]) context.report({ node, messageId: 'needFactory' });
        } else if (expr.type === 'CallExpression') {
          const callee = expr.callee;
          if (callee.type === 'Identifier' && options[callee.name]) {
            const expected = options[callee.name].args;
            expr.arguments.forEach((arg: any, i: number) => {
              const tsArg = services.eslintNodeToTSNodeMap.get(arg);
              const t = checker.getTypeAtLocation(tsArg);
              if (checker.typeToString(t) !== expected[i])
                context.report({ node: arg, messageId: 'badArg' });
            });
          }
        }
      }
    };
  }
});
