/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// index.ts
import { noUntypedEventParams } from './exercise1';
import { requireBrandedTypes } from './exercise2';
import { noImplicitNullAsync } from './exercise4';
import { consistentDecorator } from './exercise5';

export const rules = {
  'no-untyped-event-params': noUntypedEventParams,
  'require-branded-types-at-boundary': requireBrandedTypes,
  'no-implicit-null-in-async': noImplicitNullAsync,
  'consistent-decorator-factory': consistentDecorator
};

export const configs = {
  recommended: {
    plugins: ['ts-team'],
    parserOptions: { project: './tsconfig.json' },
    rules: {
      'ts-team/no-untyped-event-params': 'error',
      'ts-team/require-branded-types-at-boundary': 'error',
      'ts-team/no-implicit-null-in-async': 'error',
      'ts-team/consistent-decorator-factory': 'error'
    }
  }
};
