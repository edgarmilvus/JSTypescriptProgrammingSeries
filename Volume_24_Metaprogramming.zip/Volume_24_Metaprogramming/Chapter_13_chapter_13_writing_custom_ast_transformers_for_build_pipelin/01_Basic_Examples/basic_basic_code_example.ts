/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file helloTransformer.ts
 * @description A minimal TypeScript AST transformer example for a SaaS build pipeline.
 * This script uses the TypeScript Compiler API to programmatically modify source files
 * before they are emitted as JavaScript.
 */

// Import the TypeScript compiler API as a namespace.
// In a real SaaS monorepo, this would be a devDependency.
import * as ts from "typescript";

/**
 * @function createAppIdInjectorTransformer
 * @description Factory that returns a TypeScript Transformer factory.
 * The transformer scans for `trackEvent(...)` calls and injects `appId: "saas-hello"`.
 * @param {string} appId - The static application ID to inject into analytics calls.
 * @returns {ts.TransformerFactory<ts.SourceFile>} A transformer factory.
 */
function createAppIdInjectorTransformer(appId: string): ts.TransformerFactory<ts.SourceFile> {
  return (context: ts.TransformationContext) => {
    // The root visitor function for the SourceFile node.
    const visit: ts.Visitor = (node: ts.Node): ts.Node => {
      // Check if the current node is a CallExpression (i.e., a function call).
      if (ts.isCallExpression(node)) {
        const expr = node.expression;
        // We only care about direct calls named `trackEvent`.
        if (ts.isIdentifier(expr) && expr.text === "trackEvent") {
          // Build a new property assignment: appId: "saas-hello"
          const appIdProp = ts.factory.createPropertyAssignment(
            ts.factory.createIdentifier("appId"),
            ts.factory.createStringLiteral(appId)
          );

          // If the first argument is an object literal, add appId to it.
          if (node.arguments.length > 0 && ts.isObjectLiteralExpression(node.arguments[0])) {
            const objLit = node.arguments[0] as ts.ObjectLiteralExpression;
            const newObj = ts.factory.createObjectLiteralExpression(
              [...objLit.properties, appIdProp],
              true // multi-line formatting
            );
            return ts.factory.createCallExpression(
              expr,
              node.typeArguments,
              [newObj, ...node.arguments.slice(1)]
            );
          }
        }
      }
      // Recurse into child nodes.
      return ts.visitEachChild(node, visit, context);
    };

    return (sourceFile: ts.SourceFile) => ts.visitNode(sourceFile, visit) as ts.SourceFile;
  };
}

/**
 * @function buildHelloSaaS
 * @description Simulates a SaaS build step using the TypeScript compiler programmatically.
 */
function buildHelloSaaS(): void {
  const appId = "saas-hello";
  const fileName = "sample.ts";
  const sourceText = `
    function trackEvent(payload: any) { console.log(payload); }
    trackEvent({ type: "signup", email: "user@saas.app" });
  `;

  // Create an in-memory program with strict settings.
  const compilerOptions: ts.CompilerOptions = {
    strict: true,
    strictNullChecks: true,
    noImplicitAny: true,
    module: ts.ModuleKind.CommonJS,
    target: ts.ScriptTarget.ES2019
  };

  const sourceFile = ts.createSourceFile(
    fileName,
    sourceText,
    ts.ScriptTarget.ES2019,
    true
  );

  const transformer = createAppIdInjectorTransformer(appId);
  const result = ts.transform(sourceFile, [transformer]);
  const transformed = result.transformed[0];

  // Emit the transformed AST to a string.
  const printer = ts.createPrinter();
  const output = printer.printFile(transformed);

  console.log("--- Transformed SaaS Output ---");
  console.log(output);
}

// Execute the build simulation.
buildHelloSaaS();
