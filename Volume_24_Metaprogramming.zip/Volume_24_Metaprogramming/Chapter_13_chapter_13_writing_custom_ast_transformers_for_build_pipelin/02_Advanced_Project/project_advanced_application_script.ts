/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * aiTelemetryTransformer.ts
 * 
 * Custom AST transformer for Next.js SaaS builds.
 * Enforces AI SDK usage conventions and injects telemetry.
 */

import * as ts from 'typescript';
import { JSDoc } from 'typescript';

/**
 * Configuration interface for the transformer.
 */
interface TelemetryTransformerConfig {
  /** Project name used in injected metadata */
  saasProjectName: string;
  /** Whether to enforce Transformer.js client-only rule */
  enforceClientOnlyModels: boolean;
}

/**
 * Factory returning a TypeScript TransformerFactory.
 * @param config - Telemetry and enforcement configuration
 */
export function createAiTelemetryTransformer(
  config: TelemetryTransformerConfig
): ts.TransformerFactory<ts.SourceFile> {
  return (context: ts.TransformationContext) => {
    // 1. Capture type checker for semantic analysis
    const typeChecker = context.getCompilerOptions();

    // 2. Recursive visitor function
    function visit(node: ts.Node, source: ts.SourceFile): ts.Node {
      // 3. Detect import declarations from Vercel AI SDK
      if (ts.isImportDeclaration(node)) {
        const moduleName = (node.moduleSpecifier as ts.StringLiteral).text;
        if (moduleName === 'ai/react' || moduleName === 'ai') {
          // 4. Mark file as using AI SDK
          (source as any).__usesAiSdk = true;
        }
      }

      // 5. Detect function calls to useCompletion / useChat
      if (
        ts.isCallExpression(node) &&
        ts.isIdentifier(node.expression) &&
        (node.expression.text === 'useCompletion' ||
          node.expression.text === 'useChat')
      ) {
        // 6. Inject telemetry object as first argument if object literal not present
        const args = node.arguments;
        if (args.length === 0 || !ts.isObjectLiteralExpression(args[0])) {
          const telemetryProp = ts.factory.createPropertyAssignment(
            'telemetry',
            ts.factory.createObjectLiteralExpression([
              ts.factory.createPropertyAssignment(
                'project',
                ts.factory.createStringLiteral(config.saasProjectName)
              ),
              ts.factory.createPropertyAssignment(
                'hook',
                ts.factory.createStringLiteral(node.expression.text)
              ),
            ])
          );
          const newArg = ts.factory.createObjectLiteralExpression(
            [telemetryProp],
            true
          );
          return ts.factory.updateCallExpression(
            node,
            node.expression,
            node.typeArguments,
            [newArg, ...args]
          );
        }
      }

      // 7. Enforce Transformer.js client-only usage
      if (
        config.enforceClientOnlyModels &&
        ts.isCallExpression(node) &&
        ts.isPropertyAccessExpression(node.expression) &&
        node.expression.expression.getText() === 'transformers' &&
        node.expression.name.text === 'pipeline'
      ) {
        const hasClientDirective = source.statements.some(
          (s) =>
            ts.isExpressionStatement(s) &&
            s.expression.getText().includes('use client')
        );
        if (!hasClientDirective) {
          // 8. Emit build-time diagnostic
          console.error(
            `[AST Transformer] Transformer.js pipeline used in server component: ${source.fileName}`
          );
        }
      }

      // 9. Continue traversal
      return ts.visitEachChild(node, (child) => visit(child, source), context);
    }

    // 10. Transformer entry: transform each source file
    return (source: ts.SourceFile) => {
      const updated = ts.visitNode(source, (node) =>
        visit(node, source)
      ) as ts.SourceFile;
      return updated;
    };
  };
}
