/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

interface Options {
  mode: 'error' | 'annotate';
}

export function createExplicitReturnTypeTransformer(options: Options) {
  return (ctx: ts.TransformationContext): ts.Transformer<ts.SourceFile> => {
    const typeChecker = ctx.program?.getTypeChecker();
    return (sourceFile: ts.SourceFile) => {
      function hasApiComment(node: ts.Node): boolean {
        const text = sourceFile.text.substring(node.getFullStart(), node.getStart());
        return /@api/.test(text);
      }

      function isExported(node: ts.Node): boolean {
        return (ts.getModifiers(node) || []).some(m => m.kind === ts.SyntaxKind.ExportKeyword);
      }

      function visit(node: ts.Node): ts.Node {
        if (
          (ts.isFunctionDeclaration(node) || ts.isArrowFunction(node)) &&
          (isExported(node) || hasApiComment(node))
        ) {
          const hasType = ts.isFunctionDeclaration(node)
            ? !!node.type
            : !!(node as ts.ArrowFunction).type;

          if (!hasType) {
            if (options.mode === 'error') {
              const diag = ts.createDiagnosticForNode(
                node,
                ts.DiagnosticCategory.Error,
                'Explicit return type required on API function.',
                9999
              );
              ctx.diagnostics?.push(diag);
              return node;
            } else if (options.mode === 'annotate' && typeChecker) {
              const signature = typeChecker.getSignatureFromDeclaration(node as ts.SignatureDeclaration);
              const returnType = signature?.getReturnType();
              const typeStr = returnType ? typeChecker.typeToString(returnType) : 'unknown';
              const comment = ts.addSyntheticLeadingComment(
                node,
                ts.SyntaxKind.MultiLineCommentTrivia,
                ` @api-return ${typeStr} `,
                true
              );
              if (ts.isFunctionDeclaration(node)) {
                return ts.factory.updateFunctionDeclaration(
                  node,
                  node.modifiers,
                  node.asteriskToken,
                  node.name,
                  node.typeParameters,
                  node.parameters,
                  node.type,
                  node.body
                );
              }
              return node;
            }
          }
        }
        return ts.visitEachChild(node, visit, ctx);
      }

      return ts.visitNode(sourceFile, visit);
    };
  };
}
