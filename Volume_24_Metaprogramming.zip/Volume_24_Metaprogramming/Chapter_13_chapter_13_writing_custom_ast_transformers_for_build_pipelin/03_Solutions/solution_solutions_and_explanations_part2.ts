/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

export function createComponentMetaTransformer() {
  return (ctx: ts.TransformationContext): ts.Transformer<ts.SourceFile> => {
    return (sourceFile: ts.SourceFile) => {
      if (sourceFile.fileName.includes('.spec.')) return sourceFile;

      const statements: ts.Statement[] = [];
      let needsImport = true;

      function hasTrackComment(node: ts.Node): boolean {
        const text = sourceFile.text.substring(node.getFullStart(), node.getStart());
        return /@track/.test(text);
      }

      function isComponent(node: ts.Node): boolean {
        if (ts.isFunctionDeclaration(node) && node.body) {
          return node.body.statements.some(s => s.getText().includes('<'));
        }
        return false;
      }

      function visit(node: ts.Node): ts.Node {
        if (ts.isFunctionDeclaration(node) && hasTrackComment(node) && isComponent(node)) {
          const name = node.name?.text || 'Anonymous';
          const call = ts.factory.createExpressionStatement(
            ts.factory.createCallExpression(
              ts.factory.createIdentifier('registerComponentMeta'),
              undefined,
              [ts.factory.createStringLiteral(name), ts.factory.createObjectLiteralExpression([
                ts.factory.createPropertyAssignment('track', ts.factory.createStringLiteral('checkout-button'))
              ])]
            )
          );
          statements.push(call);
          if (needsImport) {
            statements.unshift(ts.factory.createImportDeclaration(
              undefined, undefined,
              ts.factory.createImportClause(false, ts.factory.createIdentifier('registerComponentMeta'), undefined),
              ts.factory.createStringLiteral('@/analytics')
            ));
            needsImport = false;
          }
        }
        return ts.visitEachChild(node, visit, ctx);
      }

      const updated = ts.visitNode(sourceFile, visit);
      return ctx.factory.updateSourceFile(updated, [...statements, ...updated.statements]);
    };
  };
}
