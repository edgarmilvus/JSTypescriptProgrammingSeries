/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

export function createAISDKGuardTransformer(env: 'development' | 'production') {
  return (ctx: ts.TransformationContext): ts.Transformer<ts.SourceFile> => {
    return (sourceFile: ts.SourceFile) => {
      const imported = new Set<string>();
      ts.forEachChild(sourceFile, node => {
        if (ts.isImportDeclaration(node)) {
          const module = (node.moduleSpecifier as ts.StringLiteral).text;
          if (module === 'ai/react') {
            node.importClause?.namedBindings &&
            ts.isNamedImports(node.importClause.namedBindings) &&
            node.importClause.namedBindings.elements.forEach(e => imported.add(e.name.text));
          }
        }
      });

      if (imported.has('useCompletion') && imported.has('useChat')) {
        ctx.diagnostics?.push(ts.createDiagnosticForNode(
          sourceFile, ts.DiagnosticCategory.Error,
          'Build failed: useCompletion and useChat cannot coexist in the same module due to local WASM context collision.', 10000
        ));
      }

      function visit(node: ts.Node): ts.Node {
        if (ts.isFunctionDeclaration(node) && node.name?.text === 'SmartSummary' && env === 'production') {
          // inject attribute on root JSX via manual child loop (omitted for brevity)
        }
        return ts.visitEachChild(node, visit, ctx);
      }

      return ts.visitNode(sourceFile, visit);
    };
  };
}
