/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

export function createRouteCollectorTransformer(outFile: string) {
  return (ctx: ts.TransformationContext): ts.Transformer<ts.SourceFile> => {
    return (sourceFile: ts.SourceFile) => {
      const program = ctx.program;
      const routes: ts.ObjectLiteralElementLike[] = [];
      program?.getSourceFiles().forEach(sf => {
        if (/src\/pages\/.*\.tsx$/.test(sf.fileName)) {
          ts.forEachChild(sf, n => {
            if (ts.isExportAssignment(n) && n.isExportEquals === false) {
              routes.push(ts.factory.createPropertyAssignment(
                ts.factory.createStringLiteral(sf.fileName.split('/').pop()!.replace('.tsx', '')),
                ts.factory.createArrowFunction(undefined, undefined, [], undefined,
                  ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
                  ts.factory.createCallExpression(ts.factory.createIdentifier('import'), undefined,
                    [ts.factory.createStringLiteral('./' + sf.fileName)]))
              ));
            }
          });
        }
      });
      const routeFile = ts.factory.createSourceFile([
        ts.factory.createExportDeclaration(undefined, false, ts.factory.createNamedExports([
          ts.factory.createExportSpecifier(false, undefined, ts.factory.createIdentifier('routes'))
        ])),
        ts.factory.createVariableStatement(undefined, ts.factory.createVariableDeclarationList([
          ts.factory.createVariableDeclaration('routes', undefined, undefined,
            ts.factory.createObjectLiteralExpression(routes, true))
        ], ts.NodeFlags.Const))
      ], ts.factory.createToken(ts.SyntaxKind.EndOfFileToken), ts.NodeFlags.None);
      return sourceFile;
    };
  };
}
