/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

export function createInterfaceRenamerTransformer() {
  return (ctx: ts.TransformationContext): ts.Transformer<ts.SourceFile> => {
    return (sourceFile: ts.SourceFile) => {
      const renames = new Map<string, string>();
      ts.forEachChild(sourceFile, node => {
        if (ts.isInterfaceDeclaration(node) && node.name.text.startsWith('I')) {
          renames.set(node.name.text, node.name.text.slice(1));
        }
      });

      function visit(node: ts.Node): ts.Node {
        if (ts.isInterfaceDeclaration(node) && renames.has(node.name.text)) {
          const newName = ts.factory.createIdentifier(renames.get(node.name.text)!);
          ts.setSourceMapRange(newName, ts.getSourceMapRange(node.name));
          return ts.factory.updateInterfaceDeclaration(node, node.modifiers, newName,
            node.typeParameters, node.heritageClauses, node.members);
        }
        if (ts.isTypeReferenceNode(node) && ts.isIdentifier(node.typeName) && renames.has(node.typeName.text)) {
          const newId = ts.factory.createIdentifier(renames.get(node.typeName.text)!);
          ts.setSourceMapRange(newId, ts.getSourceMapRange(node.typeName));
          return ts.factory.updateTypeReferenceNode(node, newId, node.typeArguments);
        }
        return ts.visitEachChild(node, visit, ctx);
      }

      return ts.visitNode(sourceFile, visit);
    };
  };
}
