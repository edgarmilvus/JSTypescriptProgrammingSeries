/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Analytics Config Inspector
 * A minimal demonstration of the TypeScript Compiler API:
 * Program, SourceFile, and TypeChecker.
 */

// 1. Import the TypeScript compiler API as a single namespace.
import * as ts from "typescript";

/**
 * Represents the Graph State passed through a LangGraph workflow.
 * In a real SaaS tool this would accumulate analysis results.
 */
interface GraphState {
  /** Raw source code submitted by a tenant user. */
  sourceCode: string;
  /** Inferred return type of the user's metric function. */
  inferredType?: string;
  /** Whether the metric passed static validation. */
  isValid?: boolean;
}

/**
 * Creates an in‑memory TypeScript Program from a single source string.
 * @param fileName Virtual file name used for module resolution.
 * @param sourceCode The TypeScript source to compile.
 * @returns A ts.Program instance.
 */
function createProgram(fileName: string, sourceCode: string): ts.Program {
  // 2. Compiler options tuned for a lightweight browser‑like SaaS snippet.
  const compilerOptions: ts.CompilerOptions = {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.ESNext,
    strict: true,
    noEmit: true, // We only analyze, we do not emit JS.
  };

  // 3. Wrap the source code in a virtual file system entry.
  const sourceFile = ts.createSourceFile(
    fileName,
    sourceCode,
    ts.ScriptTarget.ES2020,
    true // setParentNodes = true so we can walk the AST upward.
  );

  // 4. Build a Program using a custom compiler host.
  const host = ts.createCompilerHost(compilerOptions);
  const originalGetSourceFile = host.getSourceFile;
  host.getSourceFile = (name, languageVersion, onError, shouldCreateNewSourceFile) => {
    if (name === fileName) {
      return sourceFile;
    }
    return originalGetSourceFile(name, languageVersion, onError, shouldCreateNewSourceFile);
  };

  return ts.createProgram([fileName], compilerOptions, host);
}

/**
 * Extracts the inferred return type of the first function declaration
 * found in the SourceFile using the TypeChecker.
 * @param program The compiled Program.
 * @returns The human‑readable inferred type or "unknown".
 */
function inspectMetricFunction(program: ts.Program): string {
  const typeChecker = program.getTypeChecker();
  const sourceFile = program.getSourceFiles().find((sf) => !sf.isDeclarationFile);

  if (!sourceFile) {
    return "unknown";
  }

  let inferred = "unknown";

  // 5. Walk the AST of the SourceFile.
  ts.forEachChild(sourceFile, (node) => {
    // 6. Use a Type Guard to ensure this node is a function declaration.
    if (ts.isFunctionDeclaration(node) && node.name) {
      const signature = typeChecker.getSignatureFromDeclaration(node);
      if (signature) {
        const returnType = typeChecker.getReturnTypeOfSignature(signature);
        inferred = typeChecker.typeToString(returnType);
      }
    }
  });

  return inferred;
}

/**
 * Main entry point simulating a LangGraph node.
 * @param state The current Graph State.
 * @returns Updated Graph State with inferred type.
 */
function analyzeTenantMetric(state: GraphState): GraphState {
  const program = createProgram("tenant-metric.ts", state.sourceCode);
  const inferredType = inspectMetricFunction(program);
  return {
    ...state,
    inferredType,
    isValid: inferredType === "number", // SaaS requires numeric metrics.
  };
}

// 7. Example usage inside a SaaS request handler.
const initialState: GraphState = {
  sourceCode: `
    export function calculateConversionRate(visits: number, signups: number) {
      return (signups / visits) * 100;
    }
  `,
};

const result = analyzeTenantMetric(initialState);
console.log("Inferred Type:", result.inferredType);
console.log("Is Valid:", result.isValid);
