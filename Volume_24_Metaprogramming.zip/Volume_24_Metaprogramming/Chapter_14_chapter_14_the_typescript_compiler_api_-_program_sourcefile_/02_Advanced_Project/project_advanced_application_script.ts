/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file compiler-guard.ts
 * @description Advanced Application Script for a Next.js SaaS platform.
 * Uses the TypeScript Compiler API to statically verify that all API route
 * handlers export a Zod-validated schema and comply with strict type discipline.
 */

import * as ts from 'typescript';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * @typedef {Object} ContractViolation
 * @property {string} file - Absolute path of the offending source file.
 * @property {number} line - Line number of the violation.
 * @property {string} message - Human-readable explanation of the contract breach.
 */
interface ContractViolation {
  file: string;
  line: number;
  message: string;
}

/**
 * 1. Configure the TypeScript compiler options to mirror the SaaS project's
 *    strict configuration. This enforces strictNullChecks and prohibits implicit any.
 */
const compilerOptions: ts.CompilerOptions = {
  strict: true,
  strictNullChecks: true,
  noImplicitAny: true,
  module: ts.ModuleKind.ESNext,
  target: ts.ScriptTarget.ES2022,
  moduleResolution: ts.ModuleResolutionKind.NodeNext,
  esModuleInterop: true,
  skipLibCheck: true,
  // Reflect the ESM standard used in modern Next.js apps
  allowJs: false,
};

/**
 * 2. Resolve the absolute path to the Next.js API routes directory.
 *    In this SaaS context, all contract-critical handlers live under /app/api.
 */
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const apiRoutesRoot = path.resolve(__dirname, '../app/api');

/**
 * 3. Create a TypeScript Program instance. The Program is the central compiler
 *    object that ties together source files, options, and the type checker.
 */
function createCompilerProgram(): ts.Program {
  // Use a glob-like manual list for demonstration; in production use fs.walk
  const sourceFiles = [
    path.join(apiRoutesRoot, 'billing/route.ts'),
    path.join(apiRoutesRoot, 'analytics/route.ts'),
  ];

  // The Program bundles syntactic and semantic analysis capabilities
  const program = ts.createProgram(sourceFiles, compilerOptions);
  return program;
}

/**
 * 4. Traverse a SourceFile AST to locate exported function declarations.
 *    We use the TypeChecker to resolve the apparent type of each export.
 */
function analyzeSourceFile(
  program: ts.Program,
  sourceFile: ts.SourceFile,
  violations: ContractViolation[]
): void {
  const typeChecker = program.getTypeChecker();

  // Recursive AST visitor patterned after the compiler's own traversal utilities
  function visit(node: ts.Node): void {
    // Detect exported function declarations (e.g., `export async function GET`)
    if (ts.isFunctionDeclaration(node) && node.modifiers?.some(m => m.kind === ts.SyntaxKind.ExportKeyword)) {
      const functionName = node.name?.getText(sourceFile) ?? 'anonymous';
      const line = sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1;

      // Use TypeChecker to inspect the function's return type semantics
      const signature = typeChecker.getSignatureFromDeclaration(node);
      if (!signature) {
        violations.push({
          file: sourceFile.fileName,
          line,
          message: `Exported function ${functionName} has no resolvable signature.`,
        });
        return;
      }

      // Enforce that the function references a Zod schema export in its scope
      const hasZodImport = sourceFile.statements.some(stmt =>
        ts.isImportDeclaration(stmt) &&
        stmt.moduleSpecifier.getText(sourceFile).includes('zod')
      );

      if (!hasZodImport) {
        violations.push({
          file: sourceFile.fileName,
          line,
          message: `Exported function ${functionName} does not import Zod; strict data contract missing.`,
        });
      }

      // Verify strict null checks: ensure no parameter is implicitly nullable
      signature.parameters.forEach(param => {
        const paramType = typeChecker.getTypeAtLocation(param);
        const isNullable = typeChecker.isNullableType(paramType);
        if (isNullable && !typeChecker.isOptionalType(paramType)) {
          violations.push({
            file: sourceFile.fileName,
            line,
            message: `Parameter in ${functionName} is nullable without explicit optionality (strictNullChecks breach).`,
          });
        }
      });
    }

    ts.forEachChild(node, visit);
  }

  visit(sourceFile);
}

/**
 * 5. Execute the guard and print a SaaS-oriented compliance report.
 */
function runContractGuard(): void {
  const program = createCompilerProgram();
  const violations: ContractViolation[] = [];

  program.getSourceFiles().forEach(sf => {
    if (sf.fileName.includes(apiRoutesRoot)) {
      analyzeSourceFile(program, sf, violations);
    }
  });

  if (violations.length > 0) {
    console.error('🚨 SaaS Contract Violations Detected:');
    violations.forEach(v => {
      console.error(`- ${v.file}:${v.line} => ${v.message}`);
    });
    process.exit(1);
  } else {
    console.log('✅ All API routes comply with strict TypeScript data contracts.');
  }
}

// Invoke the guard when executed directly in the Next.js build pipeline
runContractGuard();
