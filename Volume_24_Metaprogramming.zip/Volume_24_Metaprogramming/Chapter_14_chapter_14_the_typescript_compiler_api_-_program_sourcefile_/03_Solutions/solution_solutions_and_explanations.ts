/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';
import * as path from 'path';

interface InterfaceInfo {
  name: string;
  filePath: string;
  line: number;
  column: number;
  extendedInterfaces: string[];
  memberCount: number;
  memberKinds: string[];
}

function createScanner(tsconfigPath: string, includeNodeModules = false) {
  const configFile = ts.readConfigFile(tsconfigPath, ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(
    configFile.config,
    ts.sys,
    path.dirname(tsconfigPath)
  );

  const program = ts.createProgram(parsed.fileNames, parsed.options);
  const results: InterfaceInfo[] = [];

  // Recursive AST walker
  function visit(node: ts.Node, sourceFile: ts.SourceFile) {
    if (ts.isInterfaceDeclaration(node)) {
      const isDeclFile = sourceFile.fileName.endsWith('.d.ts');
      const isInNodeModules = sourceFile.fileName.includes('node_modules');
      if ((isDeclFile || isInNodeModules) && !includeNodeModules) return;

      const { line, character } = sourceFile.getLineAndCharacterOfPosition(
        node.getStart()
      );
      const heritage = node.heritageClauses || [];
      const extended = heritage
        .filter(h => h.token === ts.SyntaxKind.ExtendsKeyword)
        .flatMap(h => h.types.map(t => t.getText(sourceFile)));

      results.push({
        name: node.name.text,
        filePath: sourceFile.fileName,
        line: line + 1,
        column: character + 1,
        extendedInterfaces: extended,
        memberCount: node.members.length,
        memberKinds: node.members.map(m => ts.SyntaxKind[m.kind])
      });
    }
    ts.forEachChild(node, child => visit(child, sourceFile));
  }

  for (const sf of program.getSourceFiles()) {
    visit(sf, sf);
  }
  return results;
}

// CLI entry
const data = createScanner('./tsconfig.json', process.argv.includes('--all'));
console.log(JSON.stringify(data, null, 2));
