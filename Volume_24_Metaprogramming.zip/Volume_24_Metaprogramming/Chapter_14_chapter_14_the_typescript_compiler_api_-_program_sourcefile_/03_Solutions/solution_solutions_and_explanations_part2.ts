/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

function validateContracts(program: ts.Program) {
  const checker = program.getTypeChecker();
  const diagnostics: string[] = [];

  for (const sf of program.getSourceFiles()) {
    if (sf.fileName.endsWith('.d.ts')) continue;

    function visit(node: ts.Node) {
      if (ts.isClassDeclaration(node) && node.heritageClauses) {
        const impl = node.heritageClauses.find(
          h => h.token === ts.SyntaxKind.ImplementsKeyword
        );
        if (!impl) return;

        const classType = checker.getDeclaredTypeOfSymbol(
          checker.getSymbolAtLocation(node)!
        );

        for (const expr of impl.types) {
          const ifaceType = checker.getTypeAtLocation(expr);
          const props = checker.getPropertiesOfType(ifaceType);
          for (const prop of props) {
            const classProp = checker.getPropertyOfType(classType, prop.name);
            if (!classProp) {
              const { line } = sf.getLineAndCharacterOfPosition(
                node.getStart()
              );
              diagnostics.push(
                `${sf.fileName}:${line + 1} - Class ${
                  node.name?.text
                } does not implement interface member ${prop.name}`
              );
            }
          }
        }
      }
      ts.forEachChild(node, visit);
    }
    visit(sf);
  }
  return diagnostics;
}
