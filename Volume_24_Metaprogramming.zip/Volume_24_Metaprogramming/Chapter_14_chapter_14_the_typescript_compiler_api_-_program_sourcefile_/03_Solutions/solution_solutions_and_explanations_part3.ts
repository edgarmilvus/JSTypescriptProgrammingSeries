/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

interface FunctionMeta {
  name: string;
  params: string;
  returnType: string;
  doc: string;
}

function extractFunctionMetas(program: ts.Program): FunctionMeta[] {
  const checker = program.getTypeChecker();
  const metas: FunctionMeta[] = [];

  for (const sf of program.getSourceFiles()) {
    if (sf.fileName.endsWith('.d.ts')) continue;
    function visit(node: ts.Node) {
      if (ts.isFunctionDeclaration(node) && node.modifiers?.some(
        m => m.kind === ts.SyntaxKind.ExportKeyword
      )) {
        const sig = checker.getSignatureFromDeclaration(node);
        metas.push({
          name: node.name?.text || 'anonymous',
          params: sig?.parameters.map(p => p.getName()).join(', ') || '',
          returnType: sig
            ? checker.typeToString(sig.getReturnType())
            : 'void',
          doc: ts.displayPartsToString(
            sig?.getDocumentationComment(checker) || []
          )
        });
      }
      ts.forEachChild(node, visit);
    }
    visit(sf);
  }
  return metas; // plain serializable objects
}

async function generateEmbeddings(batch: FunctionMeta[]): Promise<number[][]> {
  // simulate API; real: await fetch(...)
  return batch.map(() => [0.1, 0.2]);
}

async function searchVectors(embeddings: number[][]) {
  return embeddings.map(e => ({ similarity: e[0] }));
}

export async function processProject(tsconfigPath: string) {
  const program = ts.createProgram(
    [tsconfigPath],
    {}
  );
  const metas = extractFunctionMetas(program); // SYNC BOUNDARY ENDS
  const embeddings = await generateEmbeddings(metas); // ASYNC BOUNDARY
  return searchVectors(embeddings);
}
