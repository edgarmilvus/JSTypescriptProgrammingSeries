/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

function lintTsxComponents(program: ts.Program) {
  const checker = program.getTypeChecker();
  const warnings: string[] = [];

  for (const sf of program.getSourceFiles()) {
    if (!sf.fileName.endsWith('.tsx')) continue;

    function visit(node: ts.Node) {
      if (
        ts.isFunctionDeclaration(node) &&
        node.body &&
        node.parameters.length > 0
      ) {
        const propsParam = node.parameters[0];
        const propsType = checker.getTypeAtLocation(propsParam);
        const props = checker.getPropertiesOfType(propsType);

        for (const p of props) {
          const t = checker.getTypeOfSymbolAtLocation(p, propsParam);
          if (t.isUnion() && t.types.length > 1) {
            // check narrowing in body via if/ternary + getTypeAtLocation
            const hasGuard = node.body.getChildren().some(c =>
              ts.isIfStatement(c) || ts.isConditionalExpression(c)
            );
            if (!hasGuard) {
              const { line } = sf.getLineAndCharacterOfPosition(
                propsParam.getStart()
              );
              warnings.push(
                `Component ${node.name?.text}: prop ${
                  p.name
                } is union but not narrowed before use in JSX at line ${
                  line + 1
                }`
              );
            }
          }
        }
      }
      ts.forEachChild(node, visit);
    }
    visit(sf);
  }
  return warnings;
}
