/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

function reportNarrowing(program: ts.Program, fileName: string) {
  const sf = program.getSourceFiles().find(f => f.fileName === fileName)!;
  const checker = program.getTypeChecker();

  function visit(node: ts.Node) {
    if (ts.isFunctionDeclaration(node) && node.parameters.length) {
      const param = node.parameters[0];
      const entryType = checker.getTypeAtLocation(param);

      ts.forEachChild(node.body!, child => {
        if (ts.isIfStatement(child)) {
          const inTrue = checker.getTypeAtLocation(
            (child.thenStatement as ts.Block).statements[0] || child.thenStatement
          );
          const inFalse = child.elseStatement
            ? checker.getTypeAtLocation(
                (child.elseStatement as ts.Block).statements[0] ||
                  child.elseStatement
              )
            : entryType;

          console.log({
            entry: checker.typeToString(entryType),
            narrowedTrue: checker.typeToString(inTrue),
            narrowedFalse: checker.typeToString(inFalse)
          });
        }
      });
    }
    ts.forEachChild(node, visit);
  }
  visit(sf);
}
