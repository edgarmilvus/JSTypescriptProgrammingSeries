/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Web App Context:
 * This script simulates a build-time tool used by a small SaaS platform
 * to auto-generate type declarations and type docs for the public `User` model.
 */

// 1. Import the TypeScript compiler API as a singleton namespace.
import * as ts from "typescript";

// 2. Define the canonical User model exactly as it appears in our SaaS app source.
/**
 * Represents a user in the SaaS platform.
 */
interface User {
  id: string;
  email: string;
  isActive: boolean;
}

// 3. Create a minimal in-memory source file containing the User interface.
//    In a real app, you would read this from disk (fs.readFileSync).
const sourceText = `
/**
 * Represents a user in the SaaS platform.
 */
export interface User {
  id: string;
  email: string;
  isActive: boolean;
}
`;

// 4. Create a SourceFile object from the raw text using the compiler API.
const sourceFile = ts.createSourceFile(
  "user.model.ts",        // virtual file name
  sourceText,             // file content
  ts.ScriptTarget.Latest, // emit to latest JS/TS syntax
  true                    // setParentNodes = true for AST traversal
);

// 5. Prepare a string buffer that will hold the generated .d.ts content.
let declarationOutput = "";

// 6. Prepare a string buffer for the Markdown type documentation.
let markdownDoc = "# Type Documentation\n\n";

// 7. Traverse the AST (Abstract Syntax Tree) of the source file.
function visit(node: ts.Node) {
  // 8. Check if the current node is an Interface Declaration.
  if (ts.isInterfaceDeclaration(node)) {
    const interfaceName = node.name.text;

    // 9. Start building the .d.ts export for this interface.
    declarationOutput += `export interface ${interfaceName} {\n`;

    // 10. Add a heading to the markdown doc.
    markdownDoc += `## ${interfaceName}\n\n`;

    // 11. Iterate over every member (property) of the interface.
    node.members.forEach((member) => {
      if (ts.isPropertySignature(member) && member.type) {
        const propName = member.name.getText(sourceFile);
        const propType = member.type.getText(sourceFile);

        // 12. Append property to declaration file.
        declarationOutput += `  ${propName}: ${propType};\n`;

        // 13. Append property to markdown doc.
        markdownDoc += `- **${propName}**: \`${propType}\`\n`;
      }
    });

    declarationOutput += `}\n\n`;
    markdownDoc += `\n`;
  }

  // 14. Continue visiting child nodes recursively.
  ts.forEachChild(node, visit);
}

// 15. Kick off the AST traversal from the root source file.
visit(sourceFile);

// 16. Print the generated declaration file to the console (simulating write).
console.log("--- Generated .d.ts ---");
console.log(declarationOutput);

// 17. Print the generated markdown docs to the console.
console.log("--- Generated Type Docs ---");
console.log(markdownDoc);
