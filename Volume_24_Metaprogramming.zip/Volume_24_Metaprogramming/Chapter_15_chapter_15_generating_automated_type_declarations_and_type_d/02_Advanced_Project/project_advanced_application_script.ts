/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file automatedTypeDocs.ts
 * @description Next.js API route utility that extracts type metadata from a Graph State
 * interface, validates runtime payloads with Zod, and emits .d.ts + Markdown docs.
 */

import * as ts from "typescript"; // TS Compiler API for AST traversal
import { z } from "zod";           // Runtime validation library
import * as fs from "fs/promises"; // Node file system promises
import * as path from "path";      // Path utilities

/**
 * Strict Type Discipline: no implicit any, strict null checks enforced.
 */
interface GraphState {
  userId: string;
  sessionToken: string | null; // strictNullChecks requires explicit null
  fetchedDocs: Array<{ id: string; title: string }>;
  nodeTrace: string[];
}

/**
 * Zod schema mirroring GraphState for Runtime Validation at API boundary.
 */
const GraphStateSchema = z.object({
  userId: z.string(),
  sessionToken: z.string().nullable(),
  fetchedDocs: z.array(z.object({ id: z.string(), title: z.string() })),
  nodeTrace: z.array(z.string()),
});

/**
 * 1. Parse source file containing GraphState using TS Compiler API.
 */
function loadSourceAST(filePath: string): ts.SourceFile {
  const sourceText = ts.sys.readFile(filePath)!;
  return ts.createSourceFile(
    filePath,
    sourceText,
    ts.ScriptTarget.Latest,
    true
  );
}

/**
 * 2. Traverse AST to locate interface declaration and extract members.
 */
function extractInterfaceMembers(
  source: ts.SourceFile,
  name: string
): ts.NodeArray<ts.TypeElement> | null {
  let members: ts.NodeArray<ts.TypeElement> | null = null;
  ts.forEachChild(source, (node) => {
    if (
      ts.isInterfaceDeclaration(node) &&
      node.name.getText(source) === name
    ) {
      members = node.members;
    }
  });
  return members;
}

/**
 * 3. Generate .d.ts declaration text from extracted members.
 */
function emitDeclaration(
  interfaceName: string,
  members: ts.NodeArray<ts.TypeElement>,
  source: ts.SourceFile
): string {
  const lines = members.map((m) => `  ${m.getText(source)}`);
  return `export interface ${interfaceName} {\n${lines.join("\n")}\n}\n`;
}

/**
 * 4. Generate Markdown documentation from members with JSDoc inference.
 */
function emitMarkdownDocs(
  interfaceName: string,
  members: ts.NodeArray<ts.TypeElement>,
  source: ts.SourceFile
): string {
  let md = `## ${interfaceName}\n\n`;
  members.forEach((m) => {
    const jsDoc = ts.getJSDocCommentsAndTags(m)[0];
    const desc = jsDoc ? jsDoc.comment ?? "" : "No description";
    md += `- **${m.getText(source).split(":")[0]}**: ${desc}\n`;
  });
  return md;
}

/**
 * 5. Next.js API handler that orchestrates validation + generation.
 */
export async function POST(req: Request) {
  const body = await req.json();
  // Runtime Validation of external input
  const parsed = GraphStateSchema.safeParse(body);
  if (!parsed.success) {
    return new Response(JSON.stringify({ error: parsed.error }), {
      status: 400,
    });
  }

  const srcPath = path.join(process.cwd(), "types/graphState.ts");
  const ast = loadSourceAST(srcPath);
  const members = extractInterfaceMembers(ast, "GraphState");
  if (!members) return new Response("Interface not found", { status: 404 });

  const dts = emitDeclaration("GraphState", members, ast);
  const md = emitMarkdownDocs("GraphState", members, ast);

  await fs.writeFile("out/graphState.d.ts", dts);
  await fs.writeFile("out/graphState.md", md);

  return new Response("Generated", { status: 200 });
}
