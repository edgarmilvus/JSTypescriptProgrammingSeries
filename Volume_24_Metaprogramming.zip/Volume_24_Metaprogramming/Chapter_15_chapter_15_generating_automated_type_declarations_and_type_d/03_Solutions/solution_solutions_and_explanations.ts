/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';
import * as fs from 'fs';

// 1. Create program with strict tsconfig
const configPath = './tsconfig.json';
const configFile = ts.readConfigFile(configPath, ts.sys.readFile);
const parsedCmd = ts.parseJsonConfigFileContent(
  configFile.config,
  ts.sys,
  './'
);
// Force strict true (as required)
parsedCmd.options.strict = true;

const program = ts.createProgram(parsedCmd.fileNames, parsedCmd.options);
const checker = program.getTypeChecker();

// 2. Locate GraphState interface
const sourceFile = program.getSourceFile('graphState.ts')!;
let graphStateNode: ts.InterfaceDeclaration | undefined;

ts.forEachChild(sourceFile, node => {
  if (
    ts.isInterfaceDeclaration(node) &&
    node.name.text === 'GraphState'
  ) {
    graphStateNode = node;
  }
});

if (!graphStateNode) throw new Error('GraphState not found');

const metadata: Array<{
  name: string;
  type: string;
  optional: boolean;
  nullable: boolean;
  undefinedable: boolean;
  anyViolation: boolean;
}> = [];

// 3. Iterate property signatures
for (const member of graphStateNode.members) {
  if (ts.isPropertySignature(member)) {
    const propName = member.name.getText(sourceFile);
    const symbol = checker.getSymbolAtLocation(member.name)!;
    const declaredType = checker.getDeclaredTypeOfSymbol(symbol);
    const typeStr = checker.typeToString(declaredType);

    // 4. Optionality + nullability
    const optional = (member.questionToken !== undefined) ||
      ((symbol.flags & ts.SymbolFlags.Optional) !== 0);
    const nullable = (declaredType.flags & ts.TypeFlags.Null) !== 0;
    const undefinedable = (declaredType.flags & ts.TypeFlags.Undefined) !== 0;

    // 6. Implicit any check
    const anyType = checker.getAnyType();
    const anyViolation = declaredType === anyType;
    if (anyViolation) {
      console.warn(`Strict-type-violation: ${propName} is implicit any`);
    }

    metadata.push({
      name: propName,
      type: typeStr,
      optional,
      nullable,
      undefinedable,
      anyViolation
    });
  }
}

// 5. Emit JSON
fs.writeFileSync('graphState.meta.json', JSON.stringify(metadata, null, 2));
