/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';
import * as fs from 'fs';

const sourceFile = ts.createSourceFile(
  'input.ts',
  fs.readFileSync('input.ts', 'utf8'),
  ts.ScriptTarget.Latest,
  true
);

// 1. Transformer to strip decorators
const stripDecorators: ts.TransformerFactory<ts.SourceFile> =
  context => {
    return sourceFile => {
      const visit: ts.Visitor = node => {
        if (ts.isClassDeclaration(node)) {
          const members = node.members
            .filter(m => !ts.isPropertyDeclaration(m) ||
              (m.modifiers?.some(mod =>
                mod.kind === ts.SyntaxKind.PrivateKeyword ||
                mod.kind === ts.SyntaxKind.ProtectedKeyword
              ) ? false : true))
            .map(m => ts.visitEachChild(m, visit, context));
          return ts.factory.updateClassDeclaration(
            node,
            undefined, // remove decorators
            node.modifiers,
            node.name,
            node.typeParameters,
            node.heritageClauses,
            members
          );
        }
        return ts.visitEachChild(node, visit, context);
      };
      return ts.visitNode(sourceFile, visit);
    };
  };

// 2. Emit declaration only
const program = ts.createProgram(['input.ts'], {
  declaration: true,
  emitDeclarationOnly: true,
  strict: true
});
const emitter = program.emit(undefined, undefined, undefined, false, {
  before: [stripDecorators]
});

// 4. Append utility types conceptually
const output = emitter.outputFiles.find(f => f.name.endsWith('.d.ts'))!;
const augmented = output.text +
  '\ntype PartialGraph = Partial<Graph>;\ntype ReadonlyGraph = Readonly<Graph>;';
fs.writeFileSync('output.d.ts', augmented);
