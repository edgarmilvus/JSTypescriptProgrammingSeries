/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Feature Flag DSL — Hello World Example
 * Demonstrates a minimal type-safe internal DSL using
 * Utility Types, Generics, and Fluent Builders.
 */

// ---------------------------------------------------------------------------
// 1. DOMAIN MODEL
// ---------------------------------------------------------------------------

/**
 * Represents the lifecycle status of a feature flag in the SaaS app.
 */
type FlagStatus = 'draft' | 'published';

/**
 * Core domain entity for a feature flag.
 * @template S - The current lifecycle status (phantom type marker).
 */
interface FeatureFlag<S extends FlagStatus> {
  /** Unique key used in the web app config */
  key: string;
  /** Human-readable name shown in dashboard */
  name: string;
  /** Whether the flag is enabled for end users */
  enabled: boolean;
  /** Phantom status field (not used at runtime) */
  _status?: S;
}

// ---------------------------------------------------------------------------
// 2. UTILITY TYPES (from TypeScript standard library)
// ---------------------------------------------------------------------------

/**
 * We use Readonly<T> (built-in utility type) to enforce immutability
 * on published flags. This prevents accidental changes post-publish.
 */
type PublishedFlag = Readonly<FeatureFlag<'published'>>;

/**
 * We use Pick<T, K> (built-in utility type) to extract only
 * the user-supplied fields when building a draft.
 */
type FlagDraftInput = Pick<FeatureFlag<'draft'>, 'key' | 'name' | 'enabled'>;

// ---------------------------------------------------------------------------
// 3. GENERIC BUILDER (Fluent DSL)
// ---------------------------------------------------------------------------

/**
 * Fluent builder for constructing feature flags in a type-safe way.
 * @template S - Current status in the builder chain.
 */
class FlagBuilder<S extends FlagStatus> {
  private draft: FlagDraftInput;

  /**
   * @param input - Initial draft data from the web app admin UI
   */
  constructor(input: FlagDraftInput) {
    this.draft = input;
  }

  /**
   * Marks the flag as published.
   * Returns a new builder narrowed to published status.
   */
  publish(): FlagBuilder<'published'> {
    return new FlagBuilder<'published'>(this.draft);
  }

  /**
   * Builds the final flag object.
   * Uses generics to return the correct typed entity.
   */
  build(): FeatureFlag<S> {
    return this.draft as FeatureFlag<S>;
  }
}

// ---------------------------------------------------------------------------
// 4. DSL ENTRY POINT (Generic Function)
// ---------------------------------------------------------------------------

/**
 * Starts the DSL chain for a new feature flag.
 * @param input - Draft data entered by SaaS admin
 * @returns A builder generic over 'draft' status
 */
function createFlag(input: FlagDraftInput): FlagBuilder<'draft'> {
  return new FlagBuilder<'draft'>(input);
}

// ---------------------------------------------------------------------------
// 5. USAGE EXAMPLE (SaaS Context)
// ---------------------------------------------------------------------------

// Admin creates a new flag for a beta feature
const betaFlag = createFlag({
  key: 'new_dashboard',
  name: 'New Dashboard Beta',
  enabled: false
})
  .publish()           // Compiler knows we are now in 'published' state
  .build();            // Typed as FeatureFlag<'published'>

// The following would be a COMPILE ERROR if uncommented:
// betaFlag.enabled = true; // Cannot assign because PublishedFlag is Readonly

// A draft flag remains mutable
const draftFlag = createFlag({
  key: 'experimental_search',
  name: 'Experimental Search',
  enabled: false
}).build();

draftFlag.enabled = true; // OK: draft is not Readonly
