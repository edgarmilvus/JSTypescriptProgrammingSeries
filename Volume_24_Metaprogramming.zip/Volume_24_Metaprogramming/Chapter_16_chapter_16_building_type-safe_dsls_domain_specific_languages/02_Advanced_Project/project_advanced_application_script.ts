/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// Type-Safe DSL for SaaS Subscription Workflows
// Next.js API Route Context (app/api/subscription/route.ts)
// ============================================================================

import { NextResponse } from 'next/server';
import { z } from 'zod';

/**
 * Phantom types to encode subscription plan states at the type level.
 * These carry no runtime data but restrict which transitions are legal.
 */
declare const __plan: unique symbol;
type Plan<Name extends string> = { readonly [__plan]: Name };

type FreePlan = Plan<'free'>;
type ProPlan = Plan<'pro'>;
type EnterprisePlan = Plan<'enterprise'>;

/**
 * Runtime representation of plans (used for payload emission).
 */
const PLAN_NAMES = ['free', 'pro', 'enterprise'] as const;
type PlanName = typeof PLAN_NAMES[number];

/**
 * Zod schema for runtime validation of external API input.
 * Even though our DSL is type-safe, external data must be validated.
 */
const ExternalChangeRequestSchema = z.object({
  from: z.enum(PLAN_NAMES),
  to: z.enum(PLAN_NAMES),
  reason: z.string().min(1),
});
type ExternalChangeRequest = z.infer<typeof ExternalChangeRequestSchema>;

/**
 * DSL Builder using fluent interface + conditional types.
 * Each method returns a new builder narrowed by the prior state.
 */
class SubscriptionDSL<Current extends PlanName> {
  private constructor(private readonly current: Current) {}

  /** Entry point: start DSL from a known plan */
  static start<Name extends PlanName>(plan: Name): SubscriptionDSL<Name> {
    return new SubscriptionDSL(plan);
  }

  /**
   * Upgrade rule: free -> pro -> enterprise only.
   * Conditional type ensures only legal upgrades compile.
   */
  upgrade(): Current extends 'free'
    ? SubscriptionDSL<'pro'>
    : Current extends 'pro'
    ? SubscriptionDSL<'enterprise'>
    : never {
    if (this.current === 'free') return new SubscriptionDSL('pro') as any;
    if (this.current === 'pro') return new SubscriptionDSL('enterprise') as any;
    throw new Error('Illegal upgrade from ' + this.current);
  }

  /**
   * Downgrade rule: enterprise -> pro -> free only.
   */
  downgrade(): Current extends 'enterprise'
    ? SubscriptionDSL<'pro'>
    : Current extends 'pro'
    ? SubscriptionDSL<'free'>
    : never {
    if (this.current === 'enterprise') return new SubscriptionDSL('pro') as any;
    if (this.current === 'pro') return new SubscriptionDSL('free') as any;
    throw new Error('Illegal downgrade from ' + this.current);
  }

  /** Cancel is allowed from any paid plan, moves to free */
  cancel(): SubscriptionDSL<'free'> {
    return new SubscriptionDSL('free');
  }

  /** Emit runtime payload (safe to send to API) */
  toRequest(reason: string): ExternalChangeRequest {
    return { from: this.current, to: this.current, reason };
  }
}

/**
 * Next.js POST handler demonstrating DSL usage in a real SaaS flow.
 */
export async function POST(req: Request) {
  // 1. Parse external input with runtime validation (Zod)
  const body = await req.json();
  const parsed = ExternalChangeRequestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input' }, { status: 400 });
  }

  // 2. Build DSL from current plan (type-safe transition modeling)
  const dsl = SubscriptionDSL.start(parsed.data.from as PlanName);

  // 3. Compose a legal transition via fluent methods
  //    (Compiler blocks illegal chains like free.cancel().upgrade())
  const built = dsl.upgrade().upgrade(); // free -> pro -> enterprise

  // 4. Emit payload for downstream API
  const payload = built.toRequest('Customer upgraded via admin panel');

  // 5. Return response
  return NextResponse.json({ ok: true, payload });
}
