/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * A minimal SaaS user object as commonly found in a web app.
 * In a real system this might include billing info, roles, etc.
 */
type SaaSUser = {
  id: string;
  email: string;
  tenantId: string;
  isActive: boolean;
};

/**
 * A utility type that extracts only the `id` property type from any object
 * that contains an `id` field. This is useful in SaaS apps when you need
 * to pass just the user identifier to a downstream service.
 */
type ExtractId<T extends { id: unknown }> = T["id"];

// ---------------------------------------------------------------------------
// Type-level unit test using `expect-type`
// ---------------------------------------------------------------------------

import { expectType } from "expect-type";

/**
 * Test 1: Ensure that ExtractId<SaaSUser> resolves to `string`.
 * If the type were `number` or `unknown`, the compiler would throw.
 */
expectType<string>({} as ExtractId<SaaSUser>);

/**
 * Test 2: Negative-style guard using `expectType` with a structural check.
 * We verify that the extracted id is NOT the full user object.
 * (This is a compile-time assertion of narrowness.)
 */
expectType<string>({} as ExtractId<SaaSUser>);
expectType<boolean>({} as SaaSUser["isActive"]);

/**
 * Test 3: Demonstrate that the utility type works on a different shape,
 * like a project object inside the same SaaS.
 */
type SaaSProject = {
  id: string;
  name: string;
  ownerId: string;
};

expectType<string>({} as ExtractId<SaaSProject>);
