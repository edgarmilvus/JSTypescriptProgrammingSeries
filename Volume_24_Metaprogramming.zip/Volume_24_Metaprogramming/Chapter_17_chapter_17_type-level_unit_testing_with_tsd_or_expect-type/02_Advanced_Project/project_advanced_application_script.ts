/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file analytics-type-tests.ts
 * @description Type-level unit tests for a SaaS analytics query builder.
 * Uses `expect-type` to assert compile-time correctness of derived types
 * used by SharedArrayBuffer workers and Next.js Server Actions.
 */

import { expectTypeOf, type Equal } from 'expect-type';

// ---------------------------------------------------------------------------
// 1. DOMAIN MODEL: Core SaaS analytics primitives
// ---------------------------------------------------------------------------

/**
 * Supported metric keys in the dashboard.
 * These map to columns in our warehouse.
 */
type MetricKey = 'revenue' | 'activeUsers' | 'churnRate';

/**
 * Supported dimension keys for grouping.
 */
type DimensionKey = 'region' | 'plan' | 'cohort';

/**
 * A strongly typed analytics query accepted by the Server Action.
 */
type AnalyticsQuery = {
  metrics: MetricKey[];
  groupBy: DimensionKey[];
  dateRange: { start: Date; end: Date };
};

// ---------------------------------------------------------------------------
// 2. TYPE GYMNASTICS: Derive worker payload from query
// ---------------------------------------------------------------------------

/**
 * Converts an AnalyticsQuery into a serializable worker payload.
 * Dates become ISO strings; arrays remain but are readonly.
 */
type WorkerPayload<T extends AnalyticsQuery> = {
  metrics: readonly T['metrics'][number][];
  groupBy: readonly T['groupBy'][number][];
  startISO: string;
  endISO: string;
};

/**
 * Helper to transform a runtime query into the worker payload shape.
 */
function toWorkerPayload<T extends AnalyticsQuery>(q: T): WorkerPayload<T> {
  return {
    metrics: q.metrics,
    groupBy: q.groupBy,
    startISO: q.dateRange.start.toISOString(),
    endISO: q.dateRange.end.toISOString(),
  };
}

// ---------------------------------------------------------------------------
// 3. TYPE-LEVEL UNIT TESTS (Chapter 17 Core Technique)
// ---------------------------------------------------------------------------

/**
 * Test block: ensure WorkerPayload derivation is correct.
 */
type SampleQuery = {
  metrics: ['revenue', 'churnRate'];
  groupBy: ['region'];
  dateRange: { start: Date; end: Date };
};

// Assert metrics tuple is narrowed correctly
expectTypeOf<WorkerPayload<SampleQuery>['metrics']>().toEqualTypeOf<
  readonly ('revenue' | 'churnRate')[]
>();

// Assert groupBy is a readonly singleton tuple
expectTypeOf<WorkerPayload<SampleQuery>['groupBy']>().toEqualTypeOf<
  readonly ('region')[]
>();

// Assert ISO strings are plain strings
expectTypeOf<WorkerPayload<SampleQuery>['startISO']>().toBeString();
expectTypeOf<WorkerPayload<SampleQuery>['endISO']>().toBeString();

// Assert structural equivalence using Equal
type _Check = Expect<Equal<WorkerPayload<SampleQuery>, {
  metrics: readonly ('revenue' | 'churnRate')[];
  groupBy: readonly ('region')[];
  startISO: string;
  endISO: string;
}>>;

// ---------------------------------------------------------------------------
// 4. NEXT.JS SERVER ACTION + CLIENT BRIDGE
// ---------------------------------------------------------------------------

'use server';

/**
 * Server Action that validates query and posts to SharedArrayBuffer worker.
 */
async function runAnalytics(query: AnalyticsQuery): Promise<number> {
  const payload = toWorkerPayload(query);
  // Imagine SAB setup here for parallel execution
  return payload.metrics.length * 10;
}

// ---------------------------------------------------------------------------
// 5. REACT CLIENT COMPONENT USING useTransition
// ---------------------------------------------------------------------------

import { useTransition } from 'react';

/**
 * Dashboard component that triggers Server Action without blocking UI.
 */
export function AnalyticsDashboard() {
  const [isPending, startTransition] = useTransition();

  function handleRun() {
    startTransition(async () => {
      const q: AnalyticsQuery = {
        metrics: ['revenue'],
        groupBy: ['plan'],
        dateRange: { start: new Date(), end: new Date() },
      };
      await runAnalytics(q);
    });
  }

  return <button disabled={isPending} onClick={handleRun}>Run</button>;
}

// ---------------------------------------------------------------------------
// 6. LOCAL EXPECT HELPER (tsd-style)
// ---------------------------------------------------------------------------

type Expect<T extends true> = T;
