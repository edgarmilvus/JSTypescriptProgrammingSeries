/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { expectType, Expect, Equal } from 'expect-type';

// Canonical contract representing the JSON Schema Output expected from the LLM
type LLMResponse = {
  status: 'success' | 'error';
  data: { id: string; confidence: number };
  metadata?: string[];
};

// Zod schema believed to mirror the above contract
const LLMResponseSchema = z.object({
  status: z.union([z.literal('success'), z.literal('error')]),
  data: z.object({
    id: z.string(),
    confidence: z.number(),
  }),
  metadata: z.array(z.string()).optional(),
});

// 1. Exact structural equality between inferred and canonical types
expectType<Expect<Equal<z.infer<typeof LLMResponseSchema>, LLMResponse>>>(true);

// 2. Status is not widened to string
expectType<Expect<Equal<z.infer<typeof LLMResponseSchema>['status'], 'success' | 'error'>>>(true);

// 3. Metadata is string[] | undefined, not any/unknown
expectType<Expect<Equal<z.infer<typeof LLMResponseSchema>['metadata'], string[] | undefined>>>(true);

// Negative test: broken schema (status as plain string) would fail Equal
// const BrokenSchema = z.object({ status: z.string(), data: z.object({ id: z.string(), confidence: z.number() }), metadata: z.array(z.string()).optional() });
// expectType<Expect<Equal<z.infer<typeof BrokenSchema>, LLMResponse>>>(true);
// ^ Expected compiler error: Type 'string' is not assignable to type '"success" | "error"'

// tsd is preferable to runtime assert because it catches contract drift at compile time,
// before any LLM output is parsed or deployed, eliminating silent runtime mismatches.
