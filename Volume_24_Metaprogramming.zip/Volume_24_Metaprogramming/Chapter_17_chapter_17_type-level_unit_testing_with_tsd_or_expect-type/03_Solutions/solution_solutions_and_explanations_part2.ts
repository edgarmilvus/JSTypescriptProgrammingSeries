/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { expectType, Expect, Equal } from 'expect-type';

type Event =
  | { kind: 'click'; x: number; y: number }
  | { kind: 'keypress'; key: string }
  | { kind: 'blur'; duration: number };

// Correct guards using precise Extract predicates
function isClick(e: Event): e is Extract<Event, { kind: 'click' }> {
  return e.kind === 'click';
}
function isKeypress(e: Event): e is Extract<Event, { kind: 'keypress' }> {
  return e.kind === 'keypress';
}

function describe(e: Event): string {
  if (isClick(e)) {
    // 1. Inside if: e is exactly click variant
    expectType<Expect<Equal<typeof e, { kind: 'click'; x: number; y: number }>>>(true);
    return `click at ${e.x},${e.y}`;
  } else if (isKeypress(e)) {
    // 2. Inside else if: e is exactly keypress variant
    expectType<Expect<Equal<typeof e, { kind: 'keypress'; key: string }>>>(true);
    return `key: ${e.key}`;
  } else {
    // 3. After both fail: e narrowed to blur variant
    expectType<Expect<Equal<typeof e, { kind: 'blur'; duration: number }>>>(true);
    return `blur ${e.duration}`;
  }
}

// Incorrect guard: claims broad Event but checks only click
function brokenGuard(e: Event): e is Event {
  return e.kind === 'click';
}
// Usage would break narrowing:
// if (brokenGuard(e)) {
//   expectType<Expect<Equal<typeof e, { kind: 'click'; x: number; y: number }>>>(true); // fails: e is Event
// }

// tsd complements runtime tests by verifying the guard's compile-time contract,
// not just its runtime truthiness, preventing unsafe narrowing bugs.
