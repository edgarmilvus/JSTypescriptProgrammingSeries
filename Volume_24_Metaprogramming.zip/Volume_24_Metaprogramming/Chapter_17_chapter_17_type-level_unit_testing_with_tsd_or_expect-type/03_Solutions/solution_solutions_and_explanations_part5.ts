/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { expectType, Expect, Equal } from 'expect-type';

class Account {
  @Validate() id: string = '';
  @Validate() balance: number = 0;
}
// Assume @Validate is a no-op decorator for this test context

declare function getMetadata<K extends keyof Account>(k: K): Account[K];

// 1. id metadata is string
expectType<Expect<Equal<ReturnType<typeof getMetadata<'id'>>, string>>>(true);

// 2. balance metadata is number
expectType<Expect<Equal<ReturnType<typeof getMetadata<'balance'>>, number>>>(true);

// Negative case: typo 'balace' is not a key of Account
// getMetadata<'balace'>; // Compiler error: Argument of type '"balace"' is not assignable to parameter of type 'keyof Account'

// tsd prevents metadata drift by statically binding decorator metadata to property types,
// so renamed or retyped fields break tests immediately.
