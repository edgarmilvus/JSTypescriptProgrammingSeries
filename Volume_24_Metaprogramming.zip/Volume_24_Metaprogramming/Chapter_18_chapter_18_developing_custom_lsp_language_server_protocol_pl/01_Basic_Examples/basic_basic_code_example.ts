/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * TypeBoard LSP Plugin - Hello World Example
 * A minimal Language Server Protocol server that greets opened TS documents.
 */

// Import the core LSP server abstraction from the official library.
import {
  createConnection,
  TextDocuments,
  ProposedFeatures,
  TextDocumentSyncKind,
  type InitializeParams,
  type InitializeResult,
} from 'vscode-languageserver/node';

// Import the text document implementation that manages open files.
import { TextDocument } from 'vscode-languageserver-textdocument';

// Import the TypeScript compiler API to perform lightweight type-aware inspection.
import * as ts from 'typescript';

/**
 * Creates a connection to the language client (e.g., VS Code) over stdio.
 * ProposedFeatures includes all standard LSP capabilities.
 */
const connection = createConnection(ProposedFeatures.all);

/**
 * Manages a collection of open text documents keyed by URI.
 * This is the document store for our SaaS editor backend.
 */
const documents = new TextDocuments(TextDocument);

/**
 * The SaaS tenant identifier is hardcoded here for simplicity.
 * In a real deployment this would come from auth headers.
 */
const SAAS_TENANT = 'acme-corp';

/**
 * Initializes the language server when the client sends `initialize`.
 * We declare that we support full document sync (not incremental).
 */
connection.onInitialize((params: InitializeParams): InitializeResult => {
  // Log the client info for debugging inside the TypeBoard backend.
  connection.console.info(`Client ${params.clientInfo?.name} connected for tenant ${SAAS_TENANT}`);

  // Return the server capabilities expected by the LSP client.
  return {
    capabilities: {
      // Tell the editor we want to receive the full document on open/change.
      textDocumentSync: TextDocumentSyncKind.Full,
    },
  };
});

/**
 * Handles the `textDocument/didOpen` notification.
 * This is triggered when a user opens a .ts file in the SaaS editor.
 */
documents.onDidOpen(async (event) => {
  // Extract the opened document and its TypeScript source text.
  const doc = event.document;
  const fileName = doc.uri;
  const sourceText = doc.getText();

  // Use the TypeScript compiler API to create a lightweight source file.
  // This does NOT type-check the whole project; it just parses one file.
  const sourceFile = ts.createSourceFile(
    fileName,
    sourceText,
    ts.ScriptTarget.Latest,
    /* setParentNodes */ true
  );

  // Count the top-level statements to simulate a "type-aware" metric.
  let statementCount = 0;
  ts.forEachChild(sourceFile, () => {
    statementCount++;
  });

  // Build a friendly greeting message using SaaS and TS concepts.
  const greeting = `TypeBoard: Hello from LSP! Tenant ${SAAS_TENANT} opened ` +
    `${fileName} with ${statementCount} top-level statements.`;

  // Send a notification back to the IDE to display the message.
  // This mimics a contextual diagnostic without blocking the user.
  connection.window.showInformationMessage(greeting);
});

// Start listening for document open/close/change events.
documents.listen(connection);

// Activate the connection and begin processing JSON-RPC messages.
connection.listen();
