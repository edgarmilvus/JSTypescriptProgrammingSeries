/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * LSP-style TypeScript Analyzer for SaaS Code Review
 * Adapted from Chapter 18: Custom LSP Plugins & TS Compiler Internals
 */

import * as ts from "typescript";
import { Pinecone } from "@pinecone-database/pinecone";

/**
 * Represents an LSP Diagnostic mirrored from vscode-languageserver-protocol
 */
interface LspDiagnostic {
  range: {
    start: { line: number; character: number };
    end: { line: number; character: number };
  };
  message: string;
  severity: number; // 1 = Error, 2 = Warning, 3 = Info
  code?: string;
}

/**
 * Decorator-derived metadata used for contextual AI prompts
 */
interface DecoratorMeta {
  className: string;
  methodName: string;
  aiIntent: string;
}

/**
 * Initialize Pinecone client for namespace-separated vector context
 * (Namespace per SaaS tenant/project)
 */
const pinecone = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const index = pinecone.index("saas-code-review");
const namespace = index.namespace("ts-decorator-meta");

/**
 * Creates a minimal TS compiler program from in-memory source
 */
function createProgram(sourceCode: string, fileName: string): ts.Program {
  // 1. Build a mock compiler host to avoid filesystem dependency
  const host = ts.createCompilerHost({});
  const originalGetSource = host.getSourceFile;
  host.getSourceFile = (name, languageVersion) => {
    if (name === fileName) {
      return ts.createSourceFile(name, sourceCode, languageVersion, true);
    }
    return originalGetSource(name, languageVersion);
  };
  return ts.createProgram([fileName], { strict: true }, host);
}

/**
 * Visits AST nodes to extract @AiIntent decorator metadata
 */
function extractDecoratorMeta(
  program: ts.Program,
  sourceFile: ts.SourceFile
): DecoratorMeta[] {
  const meta: DecoratorMeta[] = [];
  const checker = program.getTypeChecker();

  // 2. Recursive AST walk
  function visit(node: ts.Node) {
    if (ts.isMethodDeclaration(node) && node.decorators) {
      node.decorators.forEach((dec) => {
        const expr = dec.expression;
        if (ts.isCallExpression(expr) && ts.isIdentifier(expr.expression)) {
          if (expr.expression.text === "AiIntent") {
            const intent = expr.arguments[0]?.getText().replace(/['"]/g, "");
            const methodName = node.name.getText();
            const className = node.parent &&
              ts.isClassDeclaration(node.parent) && node.parent.name
              ? node.parent.name.getText()
              : "Anonymous";
            meta.push({ className, methodName, aiIntent: intent! });
          }
        }
      });
    }
    ts.forEachChild(node, visit);
  }
  visit(sourceFile);
  return meta;
}

/**
 * Generates LSP-style diagnostics from compiler errors
 */
function generateDiagnostics(program: ts.Program): LspDiagnostic[] {
  const diagnostics: LspDiagnostic[] = [];
  const allDiags = ts.getPreEmitDiagnostics(program);
  for (const d of allDiags) {
    if (!d.file || !d.start) continue;
    const { line, character } = d.file.getLineAndCharacterOfPosition(d.start);
    diagnostics.push({
      range: {
        start: { line, character },
        end: { line, character: character + 1 },
      },
      message: ts.flattenDiagnosticMessageText(d.messageText, "\n"),
      severity: d.category === ts.DiagnosticCategory.Error ? 1 : 2,
    });
  }
  return diagnostics;
}

/**
 * Main exported analyzer used by Next.js API route
 */
export async function analyzeTenantCode(
  tenantId: string,
  sourceCode: string
): Promise<{ diagnostics: LspDiagnostic[]; meta: DecoratorMeta[] }> {
  const fileName = `tenant_${tenantId}.ts`;
  const program = createProgram(sourceCode, fileName);
  const sourceFile = program.getSourceFile(fileName)!;
  const meta = extractDecoratorMeta(program, sourceFile);
  const diagnostics = generateDiagnostics(program);

  // 3. Store decorator metadata vectors in isolated namespace
  await namespace.upsert([
    {
      id: fileName,
      values: Array(8).fill(0.1), // simplified embedding
      metadata: { tenantId, meta },
    },
  ]);

  return { diagnostics, meta };
}
