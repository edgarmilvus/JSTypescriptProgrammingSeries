/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

/**
 * Iterates class declarations and inspects method decorators.
 * Emits Warning diagnostics for @Route() on non-Promise<Response> methods.
 */
export function getDecoratorDiagnostics(
  sourceFile: ts.SourceFile,
  program: ts.Program
): ts.Diagnostic[] {
  const diagnostics: ts.Diagnostic[] = [];
  const checker = program.getTypeChecker();

  // Visit all nodes to find class declarations
  function visit(node: ts.Node) {
    if (ts.isClassDeclaration(node)) {
      node.members.forEach(member => {
        if (ts.isMethodDeclaration(member)) {
          const decorators = member.decorators ?? [];
          decorators.forEach(dec => {
            const decSymbol = checker.getSymbolAtLocation(dec.expression);
            if (decSymbol?.getName() === 'Route') {
              const sig = checker.getSignatureFromDeclaration(member);
              const returnType = sig?.getReturnType();
              if (!returnType) return;
              // Check for Promise<Response>
              const promiseType = checker.getTypeArguments(
                returnType as ts.TypeReference
              )[0];
              const isResponse = promiseType &&
                checker.getFullyQualifiedName(promiseType).endsWith('Response');
              if (!(returnType.symbol?.name === 'Promise' && isResponse)) {
                diagnostics.push({
                  file: sourceFile,
                  start: member.getStart(sourceFile),
                  length: member.getWidth(sourceFile),
                  messageText: '@Route() must be applied to a method returning Promise<Response>',
                  category: ts.DiagnosticCategory.Warning,
                  code: 9001
                });
              }
            }
          });
        }
      });
    }
    ts.forEachChild(node, visit);
  }
  visit(sourceFile);
  return diagnostics;
}

// Plugin entry point
export function init({ typescript }: { typescript: typeof ts }) {
  return {
    create(info: ts.server.PluginCreateInfo) {
      const originalGetSemanticDiagnostics =
        info.languageService.getSemanticDiagnostics.bind(info.languageService);
      info.languageService.getSemanticDiagnostics = (fileName) => {
        const def = originalGetSemanticDiagnostics(fileName);
        const sf = info.languageService.getProgram()!.getSourceFile(fileName)!;
        const custom = getDecoratorDiagnostics(sf, info.languageService.getProgram()!);
        return [...def, ...custom];
      };
      return info.languageService;
    }
  };
}

/*
 * Incremental updates: The TS compiler already does incremental binding.
 * When only the decorator line changes, the Program's AST node for that
 * method is replaced; our visitor re-runs on the new SourceFile snapshot,
 * so only affected methods are re-checked. We rely on the host's
 * file-change events to invalidate and recompute diagnostics lazily.
 */

// Sample triggering warning
// class UserController {
//   @Route('/users')
//   listUsers(): User[] { return []; }
// }

// Sample clean
// class UserController {
//   @Route('/users')
//   async listUsers(): Promise<Response> { return new Response(); }
// }
