/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

interface HostContext {
  program: ts.Program;
  sourceFile: ts.SourceFile;
}

export function getDecoratorCodeActions(
  ctx: HostContext,
  range: ts.TextRange
): ts.CodeFixAction[] {
  const { sourceFile, program } = ctx;
  const checker = program.getTypeChecker();
  const node = getMethodAtRange(sourceFile, range);
  if (!node) return [];

  const decorators = node.decorators ?? [];
  const hasRoute = decorators.some(d =>
    checker.getSymbolAtLocation(d.expression)?.getName() === 'Route'
  );
  if (!hasRoute) return [];

  // Build replacement: insert 'async' and change return type
  const methodStart = node.getStart(sourceFile);
  const returnPos = findReturnTypePos(node, sourceFile);
  const changes: ts.FileTextChanges[] = [{
    fileName: sourceFile.fileName,
    textChanges: [
      { span: { start: methodStart, length: 0 }, newText: 'async ' },
      { span: { start: returnPos, length: 0 }, newText: ': Promise<Response>' }
    ]
  }];

  return [{
    fixName: 'decorator-route-async-fix',
    description: 'Convert method to async returning Promise<Response>',
    changes,
    commands: []
  }];
}

function getMethodAtRange(sf: ts.SourceFile, r: ts.TextRange): ts.MethodDeclaration | undefined {
  let result: ts.MethodDeclaration | undefined;
  function visit(n: ts.Node) {
    if (ts.isMethodDeclaration(n) &&
        n.getStart(sf) <= r.pos && n.getEnd() >= r.end) result = n;
    ts.forEachChild(n, visit);
  }
  visit(sf);
  return result;
}

function findReturnTypePos(node: ts.MethodDeclaration, sf: ts.SourceFile): number {
  return node.type ? node.type.getStart(sf) : node.body!.getStart(sf);
}

/*
 * Testing: Use vscode-test to launch Extension Development Host.
 * Set breakpoints in ts.server.project.ts (on getCodeFixesAtPosition)
 * and in this plugin's getDecoratorCodeActions to observe requests.
 * Decorator metadata (e.g., '/users' path) is preserved because we
 * only modify the keyword and return type, not the decorator node.
 */
