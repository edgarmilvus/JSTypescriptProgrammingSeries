/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as ts from 'typescript';

export function augmentCompletions(
  sourceFile: ts.SourceFile,
  position: number,
  program: ts.Program
): ts.CompletionEntry[] {
  const checker = program.getTypeChecker();
  const entries: ts.CompletionEntry[] = [];
  const token = getTokenBeforeDot(sourceFile, position);
  if (!token) return entries;

  const symbol = checker.getSymbolAtLocation(token);
  if (!symbol) return entries;

  // Check if property has @Inject
  const decl = symbol.declarations?.find(ts.isPropertyDeclaration);
  if (decl && (decl.decorators ?? []).some(d =>
      checker.getSymbolAtLocation(d.expression)?.getName() === 'Inject')) {
    const type = checker.getTypeOfSymbolAtLocation(symbol, decl);
    const props = checker.getPropertiesOfType(type);
    props.forEach(p => {
      if (checker.getTypeOfSymbol(p).getCallSignatures().length > 0) {
        entries.push({
          name: p.getName(),
          kind: ts.ScriptElementKind.methodElement,
          sortText: '11'
        });
      }
    });
  }
  return entries;
}

function getTokenBeforeDot(sf: ts.SourceFile, pos: number): ts.Node | undefined {
  const node = findNode(sf, pos);
  if (node && ts.isPropertyAccessExpression(node)) return node.expression;
  return undefined;
}

function findNode(sf: ts.SourceFile, pos: number): ts.Node | undefined {
  let res: ts.Node | undefined;
  function visit(n: ts.Node) {
    if (n.getStart(sf) <= pos && n.getEnd() >= pos) res = n;
    ts.forEachChild(n, visit);
  }
  visit(sf);
  return res;
}

/*
 * Generic handling: For Repository<User>, getPropertiesOfType returns
 * methods of the instantiated generic; we filter by type parameters
 * via checker.getTypeArguments to ensure User-bound methods are shown.
 * Native completions are kept by merging with languageService results.
 */

// TSX snippet:
// class ProfilePage {
//   @Inject() private api: HttpClient;
//   async load() { this.api. /* suggestions: get, post */ }
// }
