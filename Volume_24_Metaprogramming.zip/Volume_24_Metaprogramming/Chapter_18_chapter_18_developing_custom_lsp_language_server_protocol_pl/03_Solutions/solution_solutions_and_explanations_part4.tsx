/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. TSX Component Stub
export default async function DiagnosticPanel({ filePath }: { filePath: string }) {
  const data = await fetchDiagnosticsWithExplanation(filePath);
  return (
    <div>
      {data.diagnostics.map(d => (
        <div key={d.code} className={`sev-${d.severity}`}>
          <strong>{d.code}:</strong> {d.message}
          <p>{d.explanation}</p>
        </div>
      ))}
    </div>
  );
}

// 2. Server Action
export async function fetchDiagnosticsWithExplanation(filePath: string) {
  // Conceptual: calls LSP bridge then LLM
  const raw = await callLSPAndLLM(filePath);
  return LLMSchema.parse(raw);
}

// 3. JSON Schema as TS constant
export const LLMSchema = z.object({
  diagnostics: z.array(z.object({
    code: z.number(),
    message: z.string(),
    severity: z.enum(['warning', 'error']),
    explanation: z.string()
  }))
});

// 4. Graphviz data flow
const diagram = `
digraph {
  Editor -> LSPLlugin [label="file changes"];
  LSPLlugin -> ServerAction [label="diagnostics"];
  ServerAction -> LLM [label="prompt+schema"];
  LLM -> ServerAction [label="JSON"];
  ServerAction -> ServerComponent [label="parsed"];
  ServerComponent -> ClientComponent [label="render"];
}
`;
