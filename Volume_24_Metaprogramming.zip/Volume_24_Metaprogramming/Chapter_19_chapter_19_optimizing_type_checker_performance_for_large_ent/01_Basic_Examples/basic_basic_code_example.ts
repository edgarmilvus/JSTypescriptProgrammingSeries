/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * NimbusBoard SaaS - Package: @nimbusboard/shared-config
 * File: src/tenantConfig.ts
 *
 * This module demonstrates a Hello-World-level example of isolating
 * a Zod schema to avoid unnecessary type-checker work in a monorepo.
 */

// 1. Import Zod for runtime validation and type inference.
import { z } from 'zod';

// 2. Define a minimal Zod schema for a tenant configuration payload.
//    This is the ONLY heavy-ish import needed at runtime.
const TenantConfigSchema = z.object({
  tenantId: z.string().uuid(),
  featureFlags: z.array(z.string()),
  maxSeats: z.number().int().positive(),
});

// 3. Infer the TypeScript type from the Zod schema.
//    This avoids duplicating a hand-written interface that the
//    type checker would otherwise need to cross-reference.
export type TenantConfig = z.infer<typeof TenantConfigSchema>;

// 4. A simple validator function used by the web app at runtime.
export function validateTenantConfig(input: unknown): TenantConfig {
  // Throws if input does not match schema.
  return TenantConfigSchema.parse(input);
}

// 5. Simulated SaaS entrypoint usage (Hello World level).
const rawConfig = {
  tenantId: '123e4567-e89b-12d3-a456-426614174000',
  featureFlags: ['darkMode', 'betaAnalytics'],
  maxSeats: 50,
};

const config = validateTenantConfig(rawConfig);
console.log(`Loaded tenant ${config.tenantId} with ${config.maxSeats} seats`);
