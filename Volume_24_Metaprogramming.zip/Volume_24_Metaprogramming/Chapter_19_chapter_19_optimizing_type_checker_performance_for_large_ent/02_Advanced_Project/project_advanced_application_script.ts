/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file advanced-application-script.ts
 * @description Enterprise monorepo type-check optimization demo for a SaaS analytics platform.
 * Demonstrates constrained generics, strict type discipline, and compiler-friendly isolation.
 */

// 1. Strict type discipline: explicit tenant-scoped data contract.
// We avoid `any` and enforce null-safety for AI pipeline outputs.
type TenantId = string & { readonly __brand: 'TenantId' };

// 2. Constrained generic to limit type-level computation in large monorepos.
// Instead of unbounded `T extends object`, we constrain to a known event shape.
interface AnalyticsEventBase {
  readonly eventId: string;
  readonly tenantId: TenantId;
  readonly timestamp: number;
}

// 3. Discriminated union reduces checker work vs. structural recursion.
type PageViewEvent = AnalyticsEventBase & {
  readonly type: 'page_view';
  readonly path: string;
};

type ClickEvent = AnalyticsEventBase & {
  readonly type: 'click';
  readonly elementId: string;
};

type AnalyticsEvent = PageViewEvent | ClickEvent;

// 4. Project-reference-friendly pure transformer (no cross-project deep imports).
// Keeps type graph shallow for incremental compilation.
function sanitizeEvent<E extends AnalyticsEvent>(
  event: E,
  redactedPaths: ReadonlySet<string>
): E {
  // Shallow clone avoids recursive type instantiation.
  const clone = { ...event } as E;
  if (clone.type === 'page_view' && redactedPaths.has(clone.path)) {
    // StrictNullChecks-safe mutation.
    return { ...clone, path: '/redacted' };
  }
  return clone;
}

// 5. Next.js API route handler (App Router style) with strict typing.
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

export async function POST(req: NextRequest): Promise<NextResponse> {
  // 6. Parse with explicit failure contract (no implicit any).
  const body = await req.json().catch(() => null);
  if (!body || typeof body.tenantId !== 'string') {
    return NextResponse.json({ error: 'invalid_tenant' }, { status: 400 });
  }

  const tenantId = body.tenantId as TenantId;
  const redacted = new Set<string>(['/admin']);

  // 7. Constrained mapping keeps checker fast even with 10k event types.
  const incoming = body.events as AnalyticsEvent[] | undefined;
  if (!incoming) {
    return NextResponse.json({ error: 'no_events' }, { status: 422 });
  }

  const cleaned = incoming.map((e) => sanitizeEvent(e, redacted));
  return NextResponse.json({ processed: cleaned.length });
}
