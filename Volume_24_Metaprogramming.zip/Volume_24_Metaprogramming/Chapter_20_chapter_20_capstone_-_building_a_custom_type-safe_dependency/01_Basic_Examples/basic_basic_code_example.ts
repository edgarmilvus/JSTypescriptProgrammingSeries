/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// CloudDesk SaaS - Minimal Type-Safe DI "Hello World" Example

/**
 * A generic service container interface.
 * It stores constructors keyed by a token (the class type itself).
 */
interface Container {
  /**
   * Registers a class as a singleton provider.
   * @param token The class constructor used as the lookup key.
   * @param instance Already-created instance to return on resolve.
   */
  register<T>(token: new (...args: any[]) => T, instance: T): void;

  /**
   * Resolves a previously registered service.
   * @param token The class constructor used as the lookup key.
   * @returns The stored instance.
   */
  resolve<T>(token: new (...args: any[]) => T): T;
}

/**
 * Concrete implementation of the minimal container.
 * Uses a Map to hold instances keyed by constructor reference.
 */
class CloudDeskContainer implements Container {
  // Internal storage: constructor -> instance
  private registry = new Map<new (...args: any[]) => any, any>();

  /** Stores a pre-built instance against its class token. */
  register<T>(token: new (...args: any[]) => T, instance: T): void {
    this.registry.set(token, instance);
  }

  /** Retrieves the instance linked to the given class token. */
  resolve<T>(token: new (...args: any[]) => T): T {
    const found = this.registry.get(token);
    if (!found) {
      throw new Error(`Service not registered: ${token.name}`);
    }
    return found;
  }
}

/**
 * Example SaaS service: a notifier that sends trial reminders.
 */
class TrialNotifier {
  /** Simple method simulating an email send. */
  sendReminder(user: string): string {
    return `Hello ${user}, your CloudDesk trial ends soon!`;
  }
}

/**
 * Consumer class representing a background job in our web app.
 */
class TrialReminderJob {
  // The injected dependency (resolved by the container)
  private notifier: TrialNotifier;

  /**
   * Constructor receives the notifier via manual injection.
   * @param notifier Injected TrialNotifier instance.
   */
  constructor(notifier: TrialNotifier) {
    this.notifier = notifier;
  }

  /** Runs the job for a given user. */
  run(user: string): void {
    console.log(this.notifier.sendReminder(user));
  }
}

// ---- Wiring everything together (composition root) ----

// 1. Create the container
const container = new CloudDeskContainer();

// 2. Register the notifier as a singleton
container.register(TrialNotifier, new TrialNotifier());

// 3. Resolve the notifier from the container
const notifier = container.resolve(TrialNotifier);

// 4. Inject it into the job (constructor injection)
const job = new TrialReminderJob(notifier);

// 5. Execute the job in our SaaS backend
job.run("alice@startup.io");
