/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script — Type-Safe DI in a SaaS Billing Context
 * Demonstrates: Modern decorators, conditional/mapped types, compiler-emitted metadata,
 * and zero-runtime type safety for Server Actions.
 */

// -----------------------------------------------------------------------------
// 1. CORE TYPE-LEVEL PRIMITIVES (Compiler Internals & Generic Constraints)
// -----------------------------------------------------------------------------

/**
 * Symbol used to store reflected dependency metadata on class constructors.
 * This mimics what `reflect-metadata` does but shows the manual emission path.
 */
const DI_DEPS = Symbol.for('di:deps');

/**
 * Generic identity type that forces the compiler to retain the literal type of T.
 * Used later to infer provider shapes without erasing generics.
 */
type Strict<T> = T extends infer U ? U : never;

/**
 * Conditional type that extracts constructor parameters from a class type.
 * Under the hood, TypeScript uses `ConstructorParameters<T>` which is itself
 * a mapped tuple derived from the class signature.
 */
type DepsOf<T> = T extends new (...args: infer P) => any ? P : never;

/**
 * Mapped type that validates every dependency is a class with a prototype.
 * If a dependency is not a constructor, it resolves to `never`, causing a
 * compile-time error at the injection site.
 */
type ValidateDeps<T extends any[]> = {
  [K in keyof T]: T[K] extends new (...args: any[]) => any ? T[K] : never;
};

// -----------------------------------------------------------------------------
// 2. MODERN DECORATORS (Parameter & Class Level)
// -----------------------------------------------------------------------------

/**
 * Class decorator that registers a service in the global container map.
 * Uses `Reflect.metadata` emission (or manual Symbol assignment) to tag deps.
 */
function Service<T extends { new (...args: any[]): {} }>(target: T) {
  // Emulate compiler-emitted design:paramtypes metadata
  const paramTypes: any[] =
    Reflect.getMetadata('design:paramtypes', target) ?? [];
  (target as any)[DI_DEPS] = paramTypes;
  Container.register(target);
  return target;
}

/**
 * Parameter decorator that marks a constructor argument as injectable.
 * In TS 5.0+ decorators, this simply validates index position.
 */
function Inject(_target: any, _key: string, index: number) {
  // No-op at runtime; compile-time safety comes from the generic container.
  void index;
}

// -----------------------------------------------------------------------------
// 3. LIGHTWEIGHT IOC CONTAINER (Type-Safe Resolution)
// -----------------------------------------------------------------------------

/**
 * Container holds constructors keyed by their own type identity.
 */
class Container {
  private static services = new Map<Function, Function>();

  static register<T extends Function>(ctor: T) {
    this.services.set(ctor, ctor);
  }

  /**
   * Resolves an instance using mapped + conditional types to guarantee
   * that the returned instance matches the requested class exactly.
   */
  static resolve<C extends new (...args: any[]) => any>(
    ctor: C
  ): InstanceType<C> {
    const deps = (ctor as any)[DI_DEPS] as ValidateDeps<DepsOf<C>>;
    const injected = (deps ?? []).map((d) => this.resolve(d));
    return new ctor(...injected);
  }
}

// -----------------------------------------------------------------------------
// 4. DOMAIN SERVICES (SaaS Billing Example)
// -----------------------------------------------------------------------------

/** Zod schema for validating inbound plan change payloads at runtime. */
import { z } from 'zod';
const PlanChangeSchema = z.object({
  userId: z.string(),
  newPlan: z.enum(['free', 'pro', 'enterprise']),
});
type PlanChange = z.infer<typeof PlanChangeSchema>;

/** Logger dependency (no deps). */
@Service
class LoggerService {
  log(msg: string) {
    console.info(`[billing] ${msg}`);
  }
}

/** Payment gateway abstraction (depends on Logger). */
@Service
class PaymentService {
  constructor(@Inject() private logger: LoggerService) {}
  charge(userId: string, amount: number) {
    this.logger.log(`Charging ${userId} $${amount}`);
  }
}

/** Subscription orchestrator (depends on Payment + Logger). */
@Service
class SubscriptionService {
  constructor(
    @Inject() private payment: PaymentService,
    @Inject() private logger: LoggerService
  ) {}

  changePlan(input: PlanChange) {
    this.payment.charge(input.userId, 25);
    this.logger.log(`Plan updated to ${input.newPlan}`);
  }
}

// -----------------------------------------------------------------------------
// 5. SERVER ACTION (Type-Safe Mutation Endpoint)
// -----------------------------------------------------------------------------

/**
 * Next.js Server Action — executed only on the server.
 * Uses the DI container to resolve the subscription service with zero manual wiring.
 */
'use server';
export async function updateSubscriptionAction(formData: FormData) {
  // Runtime validation via Zod bridges to compile-time PlanChange type.
  const parsed = PlanChangeSchema.parse({
    userId: formData.get('userId'),
    newPlan: formData.get('newPlan'),
  });

  // Compile-time inferred dependency graph: Subscription -> Payment -> Logger
  const subService = Container.resolve(SubscriptionService);
  subService.changePlan(parsed);
  return { ok: true };
}
