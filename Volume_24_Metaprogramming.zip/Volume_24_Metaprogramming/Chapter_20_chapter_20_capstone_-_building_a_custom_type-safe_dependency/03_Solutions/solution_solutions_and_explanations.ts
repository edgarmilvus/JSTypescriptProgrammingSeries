/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Branded token wrapping class ctor or symbol
declare const tokenBrand: unique symbol;
type ProviderToken<T> = (new (...args: never) => T) | (symbol & { [tokenBrand]?: T });

// Infer dependency types from tokens (simplified association)
type InferDeps<DepTokens extends readonly ProviderToken<any>[]> = {
  [I in keyof DepTokens]: DepTokens[I] extends ProviderToken<infer D> ? D : never
};

// Provider definition with deps and factory
type ProviderDef<DepTokens extends readonly ProviderToken<any>[], R> = {
  deps: DepTokens;
  factory: (...deps: InferDeps<DepTokens>) => R;
};

// Schema: record of token name to ProviderDef
type ContainerSchema = Record<string, ProviderDef<readonly ProviderToken<any>[], any>>;

// Human-readable error helper
type ErrorMsg<M extends string> = { __error: M };

// Validate no missing tokens
type ValidateRegistered<S extends ContainerSchema, K extends keyof S> =
  S[K]['deps'] extends readonly ProviderToken<any>[]
    ? S[K]['deps'][number] extends infer T
      ? T extends ProviderToken<infer _U>
        ? string extends keyof S ? ErrorMsg<`Token "${string}" is not registered in ContainerSchema`> : true
        : true
      : true
    : true;

// Recursive acyclic check
type ValidateAcyclic<S extends ContainerSchema, K extends keyof S, Seen extends keyof S = never> =
  K extends Seen
    ? ErrorMsg<`Circular dependency detected at "${string & K}"`>
    : S[K]['deps'] extends readonly ProviderToken<any>[]
      ? S[K]['deps'][number] extends ProviderToken<infer _D>
        ? keyof S extends infer DepK
          ? DepK extends keyof S
            ? ValidateAcyclic<S, DepK, Seen | K> extends true ? true : ValidateAcyclic<S, DepK, Seen | K>
            : true
          : true
        : true
      : true;

type ValidSchema<S extends ContainerSchema> = {
  [K in keyof S]: ValidateRegistered<S, K> extends true
    ? ValidateAcyclic<S, K> extends true ? S[K] : ValidateAcyclic<S, K>
    : ValidateRegistered<S, K>;
};

type BuildContainer<S extends ContainerSchema> = {
  [K in keyof S]: ReturnType<S[K]['factory']>;
};
