/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type ProviderToken<T> = (new (...args: never) => T) | (symbol & { __brand?: T });

// Class decorator: augments static __token
function Injectable<T>(token: ProviderToken<T>):
  <C extends new (...args: any) => any>(target: C) => C & { __token: ProviderToken<T> } {
  return (target) => Object.assign(target, { __token: token });
}

// Parameter decorator: type-level only, no runtime metadata
function Inject<T>(token: ProviderToken<T>): ParameterDecorator {
  return () => {};
}

// Resolve token from a type (assume 1:1 mapping for inference)
type ResolveTokenFromType<T> = ProviderToken<T>;

// Extract schema from class list
type ExtractSchema<Classes extends readonly (new (...args: any) => any)[]> = {
  [I in keyof Classes]: Classes[I] extends new (...args: infer A) => infer R
    ? {
        token: Classes[I] extends { __token: infer TK } ? TK : ProviderToken<R>;
        deps: { [J in keyof A]: ResolveTokenFromType<A[J]> };
        factory: (...args: A) => R;
      }
    : never;
};

// Compile-time register signature
declare function compileTimeRegister<Classes extends readonly (new (...args: any) => any)[]>(
  ...classes: Classes
): ExtractSchema<Classes>;
