/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

type Phantom<T> = { __phantom?: (t: T) => void };

function emit<T>(): Phantom<T> {
  return {};
}

type ProviderToken<T> = (new (...args: never) => T) | (symbol & { __brand?: T });

class ContainerBuilder {
  addProvider<Token, Deps extends readonly ProviderToken<any>[]>(
    anchor: Phantom<InferDeps<Deps>>,
    def: ProviderDef<Deps, Token>
  ): void {}
}

type InferDeps<DepTokens extends readonly ProviderToken<any>[]> = {
  [I in keyof DepTokens]: DepTokens[I] extends ProviderToken<infer D> ? D : never
};
type ProviderDef<DepTokens extends readonly ProviderToken<any>[], R> = {
  deps: DepTokens; factory: (...d: InferDeps<DepTokens>) => R;
};

// Simulate tsc decorator lowering: preserves A only if emitDecoratorMetadata off
type DecoratedCtor<Q> = Q extends abstract new (...args: infer A) => infer R
  ? { token: ProviderToken<R>; deps: { [I in keyof A]: ProviderToken<A[I]> } }
  : never;
