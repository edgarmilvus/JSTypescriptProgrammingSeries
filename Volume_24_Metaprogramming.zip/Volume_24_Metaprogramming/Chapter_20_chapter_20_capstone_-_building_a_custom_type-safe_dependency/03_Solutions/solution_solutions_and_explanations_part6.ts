/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

interface GraphState { input: string; intermediate: Record<string, unknown>; output: string | null; errors: string[]; }
type SameRef<T> = T & { readonly __ref: unique symbol };
type ProviderToken<T> = (new (...args: never) => T) | (symbol & { __brand?: T });
type ProviderDef<DepTokens extends readonly ProviderToken<any>[], R> = { deps: DepTokens; factory: (...d: any) => R; };
type ContainerSchema = Record<string, ProviderDef<readonly ProviderToken<any>[], any>>;

type DeepValidate<S extends ContainerSchema, K extends keyof S, Visited extends keyof S = never> =
  K extends Visited ? ErrorMsg<`Cycle at ${string & K}`> :
  S[K]['deps'][number] extends ProviderToken<infer _D> ?
    keyof S extends infer DepK ? DepK extends keyof S ? DeepValidate<S, DepK, Visited | K> : true : true : true;

type ErrorMsg<M extends string> = { __error: M };
type ValidSchema<S extends ContainerSchema> = { [K in keyof S]: DeepValidate<S, K> extends true ? S[K] : DeepValidate<S, K> };

declare const GraphStateToken: ProviderToken<SameRef<GraphState>>;
declare const LoggerToken: ProviderToken<LoggerService>;
declare const TokenizerToken: ProviderToken<TokenizerService>;
declare const SummarizerToken: ProviderToken<SummarizerService>;
declare const NodeContextToken: ProviderToken<NodeContext>;
declare const ReactDebuggerToken: ProviderToken<ReactDebuggerService>;

type AppContainerSchema = {
  graph: ProviderDef<[], SameRef<GraphState>>;
  logger: ProviderDef<[], LoggerService>;
  tokenizer: ProviderDef<[typeof LoggerToken], TokenizerService>;
  summarizer: ProviderDef<[typeof TokenizerToken], SummarizerService>;
  nodeCtx: ProviderDef<[typeof GraphStateToken, typeof LoggerToken], NodeContext>;
  reactDebug: ProviderDef<[typeof GraphStateToken], ReactDebuggerService>;
};

type AssertApp = ValidSchema<AppContainerSchema>;
