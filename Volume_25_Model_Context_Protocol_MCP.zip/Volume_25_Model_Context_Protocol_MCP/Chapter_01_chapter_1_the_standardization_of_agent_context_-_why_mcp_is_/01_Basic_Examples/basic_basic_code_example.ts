/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file mcp-saas-server.ts
 * @description A foundational, self-contained Model Context Protocol (MCP) server 
 * built in TypeScript for a SaaS customer support environment. It exposes standardized 
 * tools and resource schemas over standard input/output (stdio) transport.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ErrorCode,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";

// ==========================================
// MOCK DATABASE & DATA LAYER
// ==========================================

/**
 * Interface representing a SaaS Customer Profile.
 */
interface CustomerProfile {
  id: string;
  email: string;
  plan: "starter" | "pro" | "enterprise";
  mrr: number;
  status: "active" | "churned" | "trial";
  supportTier: "standard" | "priority" | "dedicated";
}

/**
 * In-memory data store acting as our SaaS backend database.
 */
const MOCK_SAAS_DATABASE: Record<string, CustomerProfile> = {
  "usr_101": {
    id: "usr_101",
    email: "alice@acme-corp.io",
    plan: "enterprise",
    mrr: 1250.00,
    status: "active",
    supportTier: "dedicated",
  },
  "usr_102": {
    id: "usr_102",
    email: "bob@startup-labs.com",
    plan: "pro",
    mrr: 150.00,
    status: "active",
    supportTier: "priority",
  },
};

// ==========================================
// MCP SERVER INITIALIZATION
// ==========================================

/**
 * Initialize the MCP Server instance with metadata describing the service.
 * This metadata is shared with the client during the capability negotiation handshake.
 */
const server = new Server(
  {
    name: "saas-support-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},      // Indicates this server provides executable functions
      resources: {},  // Indicates this server provides readable data URIs
    },
  }
);

// ==========================================
// TOOL REGISTRATION (Executable Capabilities)
// ==========================================

/**
 * Handler for listing available tools. 
 * When an LLM client connects, it calls this endpoint to discover what actions it can execute.
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "get_customer_profile",
        description: "Retrieves billing, plan, and support tier details for a specific SaaS customer by their unique user ID.",
        inputSchema: {
          type: "object",
          properties: {
            userId: {
              type: "string",
              description: "The unique user identifier, e.g., usr_101",
            },
          },
          required: ["userId"],
        },
      },
    ],
  };
});

/**
 * Handler for executing tool calls requested by the LLM client.
 * Validates inputs, interacts with the mock database, and returns a structured content response.
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name !== "get_customer_profile") {
    throw new McpError(
      ErrorCode.MethodNotFound,
      `Unknown tool: ${request.params.name}`
    );
  }

  const args = request.params.arguments as { userId?: string };

  if (!args || typeof args.userId !== "string") {
    throw new McpError(
      ErrorCode.InvalidParams,
      "Invalid or missing 'userId' parameter in tool arguments."
    );
  }

  const customer = MOCK_SAAS_DATABASE[args.userId];

  if (!customer) {
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({
            error: `Customer with ID '${args.userId}' not found in the SaaS database.`,
          }),
        },
      ],
      isError: true,
    };
  }

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(customer, null, 2),
      },
    ],
  };
});

// ==========================================
// RESOURCE REGISTRATION (Data Context)
// ==========================================

/**
 * Handler for listing static or dynamic resources. 
 * Resources represent passive context (documents, system health, static policies) 
 * that can be read directly by the LLM context window.
 */
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "saas://policies/sla",
        name: "SaaS Service Level Agreement (SLA)",
        mimeType: "text/markdown",
        description: "Defines uptime guarantees, response times, and credit refunds by support tier.",
      },
    ],
  };
});

/**
 * Handler for reading a specific resource content via its URI.
 */
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const uri = request.params.uri;

  if (uri === "saas://policies/sla") {
    const slaContent = `# SaaS Service Level Agreement (SLA)
- **Dedicated Support Tier**: 1-hour response time guarantee for critical incidents. 99.99% uptime.
- **Priority Support Tier**: 4-hour response time guarantee. 99.9% uptime.
- **Standard Support Tier**: 24-hour response time. 99.5% uptime.`;

    return {
      contents: [
        {
          uri,
          mimeType: "text/markdown",
          text: slaContent,
        },
      ],
    };
  }

  throw new McpError(
    ErrorCode.InvalidRequest,
    `Resource not found: ${uri}`
  );
});

// ==========================================
// TRANSPORT & SERVER STARTUP
// ==========================================

/**
 * Asynchronous function to establish the standard I/O transport layer 
 * and bind the MCP server instance to it.
 */
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  
  // Log startup to stderr so stdout remains pristine for MCP JSON-RPC protocol frames
  console.error("SaaS Support MCP Server running on stdio transport.");
}

main().catch((error) => {
  console.error("Fatal error running MCP server:", error);
  process.exit(1);
});
