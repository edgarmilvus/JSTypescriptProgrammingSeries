/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { 
  CallToolRequestSchema, 
  ListToolsRequestSchema 
} from "@modelcontextprotocol/sdk/types.js";
import { NextRequest, NextResponse } from "next/server";
import * as fs from "fs/promises";
import * as path from "path";

/**
 * Interface representing the structure of our SaaS application logs payload.
 */
interface LogAnalysisRequest {
  targetDirectory: string;
  query: string;
}

/**
 * MCP Server Implementation for Secure Enterprise File & Log Analysis.
 * Exposes specialized tools to the connected MCP client over standard I/O.
 */
class EnterpriseMCPServer {
  private server: Server;

  constructor() {
    // Initialize the underlying MCP Server with metadata
    this.server = new Server(
      {
        name: "enterprise-saas-mcp-server",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
  }

  /**
   * Registers tool handlers for listing available operations and executing tool calls.
   */
  private setupToolHandlers(): void {
    // 1. Define the schema for listing tools
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: "read_saas_logs",
            description: "Safely reads and filters application log files within the designated directory.",
            inputSchema: {
              type: "object",
              properties: {
                directory: { type: "string", description: "Target directory path containing logs" },
                filterKeyword: { type: "string", description: "Keyword to filter log entries (e.g., 'ERROR', 'WARN')" }
              },
              required: ["directory", "filterKeyword"]
            }
          }
        ]
      };
    });

    // 2. Define execution logic for when the LLM invokes the registered tool
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      if (request.params.name === "read_saas_logs") {
        const args = request.params.arguments as { directory: string; filterKeyword: string };
        const safePath = path.resolve(process.cwd(), args.directory);

        try {
          const files = await fs.readdir(safePath);
          let combinedLogs = "";

          for (const file of files) {
            if (file.endsWith(".log")) {
              const filePath = path.join(safePath, file);
              const content = await fs.readFile(filePath, "utf-8");
              const lines = content.split("\n");
              const matchingLines = lines.filter(line => line.includes(args.filterKeyword));
              combinedLogs += `--- File: ${file} ---\n` + matchingLines.join("\n") + "\n";
            }
          }

          return {
            content: [
              {
                type: "text",
                text: combinedLogs || "No matching log entries found for the specified keyword."
              }
            ]
          };
        } catch (error: unknown) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          return {
            content: [
              {
                type: "text",
                text: `Error accessing filesystem: ${errorMessage}`
              }
            ],
            isError: true
          };
        }
      }

      throw new Error(`Unknown tool requested: ${request.params.name}`);
    });
  }

  /**
   * Starts the MCP server using standard input/output transport streams.
   */
  public async start(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Enterprise MCP Server running on Stdio transport.");
  }
}

/**
 * Next.js API Route Handler implementing the MCP Client.
 * Acts as the bridge between incoming SaaS HTTP requests and the MCP Server execution environment.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body: LogAnalysisRequest = await req.json();
    const { targetDirectory, query } = body;

    // Instantiate the MCP Client
    const mcpClient = new Client(
      {
        name: "nextjs-saas-mcp-client",
        version: "1.0.0",
      },
      {
        capabilities: {},
      }
    );

    // Establish transport layer connection to the server process
    // In a production setup, this would spawn the compiled MCP server process securely.
    const transport = new StdioClientTransport({
      command: "node",
      args: ["./dist/mcp-server.js"]
    });

    await mcpClient.connect(transport);

    // Discover tools available from the connected server
    const availableTools = await mcpClient.listTools();
    console.log("Discovered tools from MCP server:", availableTools.tools.map(t => t.name));

    // Execute the discovered tool dynamically based on client intent
    const toolResult = await mcpClient.callTool({
      name: "read_saas_logs",
      arguments: {
        directory: targetDirectory,
        filterKeyword: query
      }
    });

    // Clean up client connection
    await mcpClient.close();

    return NextResponse.json({
      success: true,
      analysis: toolResult.content
    }, { status: 200 });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json({
      success: false,
      error: errorMessage
    }, { status: 500 });
  }
}
