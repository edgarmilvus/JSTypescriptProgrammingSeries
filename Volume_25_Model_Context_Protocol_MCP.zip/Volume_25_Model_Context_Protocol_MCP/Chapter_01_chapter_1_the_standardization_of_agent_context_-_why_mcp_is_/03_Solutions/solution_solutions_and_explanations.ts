/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  McpError,
  ErrorCode,
} from "@modelcontextprotocol/sdk/types.js";

// Initialize the MCP Server instance
const server = new Server(
  {
    name: "enterprise-infra-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Register available tools definition
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "get_system_logs",
        description: "Retrieve recent log lines from a specified enterprise service.",
        inputSchema: {
          type: "object",
          properties: {
            serviceName: {
              type: "string",
              description: "The name of the service to query logs from.",
            },
            lines: {
              type: "number",
              description: "Number of lines to retrieve (default: 50).",
              default: 50,
            },
          },
          required: ["serviceName"],
        },
      },
      {
        name: "search_config",
        description: "Search configuration keys matching a specific query.",
        inputSchema: {
          type: "object",
          properties: {
            query: {
              type: "string",
              description: "The search query string for configuration keys.",
            },
          },
          required: ["query"],
        },
      },
    ],
  };
});

// Handle tool execution requests
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "get_system_logs") {
    const serviceName = args?.serviceName as string;
    const lines = (args?.lines as number) || 50;

    if (!serviceName) {
      throw new McpError(ErrorCode.InvalidParams, "Missing required argument: serviceName");
    }

    // Mock implementation of log retrieval
    const mockLogs = Array.from({ length: lines }, (_, i) => 
      `[${new Date().toISOString()}] [INFO] [${serviceName}] Process execution heartbeat - code: ${i + 100}`
    ).join("\n");

    return {
      content: [
        {
          type: "text",
          text: mockLogs,
        },
      ],
    };
  }

  if (name === "search_config") {
    const query = args?.query as string;

    if (!query) {
      throw new McpError(ErrorCode.InvalidParams, "Missing required argument: query");
    }

    // Mock configuration matching logic
    const mockConfigs = {
      "database.connection.pool_size": 20,
      "database.timeout_ms": 5000,
      "auth.jwt.expiration": "2h",
      "logging.level": "debug",
    };

    const matches = Object.entries(mockConfigs)
      .filter(([k]) => k.includes(query))
      .map(([k, v]) => `${k} = ${v}`)
      .join("\n");

    return {
      content: [
        {
          type: "text",
          text: matches || "No matching configuration keys found.",
        },
      ],
    };
  }

  throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
});

// Connect using Stdio transport and run the server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Enterprise Infra MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error running server:", error);
  process.exit(1);
});
