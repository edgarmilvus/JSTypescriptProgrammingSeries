/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { ListToolsRequestSchema, CallToolRequestSchema } from "@modelcontextprotocol/sdk/types.js";

interface ManagedServer {
  id: string;
  client: Client;
  transport: StdioClientTransport;
  tools: Array<{ name: string; description: string; inputSchema: any }>;
}

export class MCPOrchestrationGateway {
  private servers: Map<string, ManagedServer> = new Map();

  // 1. Connect and initialize a subprocess-based MCP server
  async registerServer(id: string, command: string, args: string[]): Promise<void> {
    const transport = new StdioClientTransport({ command, args });
    const client = new Client(
      { name: `gateway-client-${id}`, version: "1.0.0" },
      { capabilities: {} }
    );

    await client.connect(transport);

    // 2. Discover available capabilities and tools immediately after connection
    const toolsResponse = await client.request(ListToolsRequestSchema, {});
    
    this.servers.set(id, {
      id,
      client,
      transport,
      tools: toolsResponse.tools,
    });
  }

  // 3. Aggregate all tools from all connected MCP servers into a unified array
  getUnifiedToolCatalog(): Array<{ serverId: string; name: string; description: string; inputSchema: any }> {
    const catalog: Array<{ serverId: string; name: string; description: string; inputSchema: any }> = [];
    
    for (const [serverId, serverData] of this.servers.entries()) {
      for (const tool of serverData.tools) {
        catalog.push({
          serverId,
          ...tool,
        });
      }
    }
    
    return catalog;
  }

  // 4. Route an incoming execution request to the specific server owning the target tool
  async executeToolCall(toolName: string, args: Record<string, unknown>): Promise<any> {
    let targetServer: ManagedServer | undefined;

    for (const serverData of this.servers.values()) {
      if (serverData.tools.some((t) => t.name === toolName)) {
        targetServer = serverData;
        break;
      }
    }

    if (!targetServer) {
      throw new Error(`Tool '${toolName}' is not registered with any connected MCP server.`);
    }

    const response = await targetServer.client.request(
      CallToolRequestSchema,
      {
        name: toolName,
        arguments: args,
      }
    );

    return response;
  }

  async shutdown(): Promise<void> {
    for (const serverData of this.servers.values()) {
      await serverData.transport.close();
    }
    this.servers.clear();
  }
}
