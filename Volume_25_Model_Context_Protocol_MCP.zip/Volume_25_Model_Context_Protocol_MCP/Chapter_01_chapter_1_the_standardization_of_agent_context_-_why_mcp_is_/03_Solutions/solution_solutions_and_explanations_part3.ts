/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  McpError,
  ErrorCode,
} from "@modelcontextprotocol/sdk/types.js";

const resourceServer = new Server(
  {
    name: "context-injection-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      resources: {},
    },
  }
);

// 1. & 2. Register available static and dynamic resources
resourceServer.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "env://current",
        name: "Runtime Environment Configuration",
        mimeType: "application/json",
        description: "Exposes active environment settings and service configs.",
      },
      {
        uri: "session://{userId}/profile",
        name: "User Session Profile Context",
        mimeType: "application/json",
        description: "Template for fetching user-specific context variables.",
      },
    ],
  };
});

// 3. Handle resource reading with security sanitization middleware logic
resourceServer.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const uriString = request.params.uri;
  const uri = new URL(uriString);

  if (uri.protocol === "env:") {
    // Check for admin authorization token simulation in headers/metadata if applicable
    const isAdmin = request.meta?.["x-admin-token"] === "secure-admin-token-value";

    const envData = {
      NODE_ENV: process.env.NODE_ENV || "production",
      PORT: process.env.PORT || "8080",
      // Sensitive variables that must be filtered out unless admin token is present
      DATABASE_URL: isAdmin ? process.env.DATABASE_URL || "postgres://user:pass@localhost:5432/db" : "[REDACTED]",
      JWT_SECRET: isAdmin ? process.env.JWT_SECRET || "super-secret-key" : "[REDACTED]",
    };

    return {
      contents: [
        {
          uri: uriString,
          mimeType: "application/json",
          text: JSON.stringify(envData, null, 2),
        },
      ],
    };
  }

  if (uri.protocol === "session:") {
    const pathSegments = uri.pathname.split("/");
    const userId = pathSegments[1] || "anonymous";

    const userProfile = {
      userId,
      roles: ["standard-agent"],
      lastActiveSession: new Date().toISOString(),
    };

    return {
      contents: [
        {
          uri: uriString,
          mimeType: "application/json",
          text: JSON.stringify(userProfile, null, 2),
        },
      ],
    };
  }

  throw new McpError(ErrorCode.InvalidRequest, `Unsupported resource URI schema: ${uriString}`);
});

// 4. Client-side utility function to parse prompts and inject context resources
export async function injectContextResources(
  prompt: string,
  mcpClientReadHandler: (uri: string) => Promise<string>
): Promise<string> {
  const resourceRegex = /@(env:\/\/[^\s]+|session:\/\/[^\s]+)/g;
  let enrichedPrompt = prompt;
  let match: RegExpExecArray | null;

  while ((match = resourceRegex.exec(prompt)) !== null) {
    const targetUri = match[1];
    try {
      const resourceContent = await mcpClientReadHandler(targetUri);
      // Replace the resource reference in the prompt with the resolved content block
      enrichedPrompt = enrichedPrompt.replace(
        `@${targetUri}`,
        `\n[INJECTED_CONTEXT URI="${targetUri}"]\n${resourceContent}\n[/INJECTED_CONTEXT]\n`
      );
    } catch (error) {
      console.error(`Failed to fetch resource context for ${targetUri}:`, error);
    }
  }

  return enrichedPrompt;
}
