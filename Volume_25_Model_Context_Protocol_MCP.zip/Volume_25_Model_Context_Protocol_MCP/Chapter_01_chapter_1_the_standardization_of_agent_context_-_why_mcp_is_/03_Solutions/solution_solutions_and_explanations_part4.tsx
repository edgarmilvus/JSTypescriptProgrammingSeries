/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface MCPServerStatus {
  id: string;
  name: string;
  version: string;
  status: 'connected' | 'disconnected' | 'error';
  latencyMs: number;
  tools: Array<{ name: string; description: string; inputSchema: Record<string, any> }>;
  resources: Array<{ uri: string; name: string; mimeType?: string }>;
}

export interface RPCLogEntry {
  id: string;
  timestamp: string;
  type: 'request' | 'response' | 'notification' | 'error';
  payload: Record<string, unknown>;
}

interface MCPInspectorDashboardProps {
  initialServers: MCPServerStatus[];
  initialLogs?: RPCLogEntry[];
}

export const MCPInspectorDashboard: React.FC<MCPInspectorDashboardProps> = ({
  initialServers,
  initialLogs = [],
}) => {
  const [servers] = useState<MCPServerStatus[]>(initialServers);
  const [logs] = useState<RPCLogEntry[]>(initialLogs);
  const [selectedServerId, setSelectedServerId] = useState<string>(initialServers[0]?.id || '');
  const [selectedToolName, setSelectedToolName] = useState<string>('');
  const [toolArgsInput, setToolArgsInput] = useState<string>('{}');
  const [executionResult, setExecutionResult] = useState<string | null>(null);

  const activeServer = servers.find((s) => s.id === selectedServerId);
  const activeTool = activeServer?.tools.find((t) => t.name === selectedToolName);

  const handleExecuteTool = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsedArgs = JSON.parse(toolArgsInput);
      // Simulate execution response display
      setExecutionResult(
        JSON.stringify({ status: "success", executedTool: selectedToolName, args: parsedArgs }, null, 2)
      );
    } catch (err: any) {
      setExecutionResult(JSON.stringify({ status: "error", message: err.message }, null, 2));
    }
  };

  const getLogColorClass = (type: RPCLogEntry['type']) => {
    switch (type) {
      case 'request': return 'text-blue-400';
      case 'response': return 'text-green-400';
      case 'notification': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-300';
    }
  };

  return (
    <div className="mcp-inspector-container flex flex-col h-screen bg-gray-900 text-white font-sans p-4 gap-4">
      {/* Top Section: Server Status Grid */}
      <div className="grid grid-cols-3 gap-4">
        {servers.map((server) => (
          <div
            key={server.id}
            onClick={() => setSelectedServerId(server.id)}
            className={`p-4 rounded-lg border cursor-pointer transition-all ${
              selectedServerId === server.id ? 'border-indigo-500 bg-gray-800' : 'border-gray-700 bg-gray-900/50'
            }`}
          >
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-bold text-lg">{server.name}</h3>
              <span className={`px-2 py-0.5 text-xs rounded-full ${
                server.status === 'connected' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'
              }`}>
                {server.status}
              </span>
            </div>
            <p className="text-xs text-gray-400">Version: {server.version}</p>
            <p className="text-xs text-gray-400">Latency: {server.latencyMs}ms</p>
            <div className="mt-3 text-xs text-indigo-300">
              {server.tools.length} Tools | {server.resources.length} Resources
            </div>
          </div>
        ))}
      </div>

      {/* Middle Section: Interactive Tool Tester */}
      <div className="flex flex-1 gap-4 overflow-hidden">
        <div className="w-1/3 bg-gray-800 p-4 rounded-lg overflow-y-auto border border-gray-700">
          <h4 className="font-semibold text-sm text-gray-300 mb-3 uppercase tracking-wider">Available Tools</h4>
          <ul className="space-y-2">
            {activeServer?.tools.map((tool) => (
              <li
                key={tool.name}
                onClick={() => {
                  setSelectedToolName(tool.name);
                  setToolArgsInput(JSON.stringify(tool.inputSchema?.properties || {}, null, 2));
                }}
                className={`p-2 rounded cursor-pointer text-sm ${
                  selectedToolName === tool.name ? 'bg-indigo-600 text-white' : 'hover:bg-gray-700 text-gray-300'
                }`}
              >
                <div className="font-medium">{tool.name}</div>
                <div className="text-xs opacity-75 truncate">{tool.description}</div>
              </li>
            ))}
          </ul>
        </div>

        <div className="w-2/3 bg-gray-800 p-4 rounded-lg flex flex-col border border-gray-700">
          <h4 className="font-semibold text-sm text-gray-300 mb-3 uppercase tracking-wider">
            Tool Tester {activeTool ? `- ${activeTool.name}` : ''}
          </h4>
          {activeTool ? (
            <form onSubmit={handleExecuteTool} className="flex flex-col flex-1 gap-3">
              <p className="text-xs text-gray-400">{activeTool.description}</p>
              <label className="text-xs font-mono text-gray-400">Arguments JSON Schema Input:</label>
              <textarea
                value={toolArgsInput}
                onChange={(e) => setToolArgsInput(e.target.value)}
                className="flex-1 bg-gray-900 border border-gray-700 rounded p-2 font-mono text-xs text-green-300 resize-none"
              />
              <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded text-sm font-medium">
                Execute Tool Call
              </button>
              {executionResult && (
                <div className="mt-2 p-2 bg-gray-900 border border-gray-700 rounded font-mono text-xs text-yellow-300 overflow-x-auto">
                  <pre>{executionResult}</pre>
                </div>
              )}
            </form>
          ) : (
            <div className="flex items-center justify-center flex-1 text-gray-500 text-sm">
              Select a tool from the left to inspect and test.
            </div>
          )}
        </div>
      </div>

      {/* Bottom Section: Real-Time Execution Log Stream Console Drawer */}
      <div className="h-40 bg-black/80 rounded-lg p-3 border border-gray-800 overflow-y-auto font-mono text-xs">
        <div className="text-gray-500 uppercase tracking-widest text-[10px] mb-2 border-b border-gray-800 pb-1">
          JSON-RPC Real-Time Message Stream
        </div>
        {logs.map((log) => (
          <div key={log.id} className="flex gap-2 py-0.5">
            <span className="text-gray-500">[{log.timestamp}]</span>
            <span className={`uppercase font-bold ${getLogColorClass(log.type)}`}>[{log.type}]</span>
            <span className="text-gray-300">{JSON.stringify(log.payload)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
