/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

#!/usr/bin/env node
/**
 * SaaS Customer Support MCP Server
 * 
 * This self-contained TypeScript file sets up a Model Context Protocol (MCP) server
 * using the official @modelcontextprotocol/sdk. It exposes a tool for querying 
 * user account metrics and fetching application logs, designed to integrate with 
 * an AI assistant or supervisor agent running inside an MCP-compatible host.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";

// ============================================================================
// Mock Database / SaaS Data Layer
// ============================================================================

/**
 * Interface representing a user record in our SaaS database.
 */
interface SaaSUser {
  id: string;
  email: string;
  plan: "free" | "pro" | "enterprise";
  mrr: number; // Monthly Recurring Revenue
  status: "active" | "suspended" | "churned";
  lastActive: string;
}

/**
 * In-memory mock database storing SaaS user profiles.
 */
const MOCK_USERS: Record<string, SaaSUser> = {
  "usr_101": {
    id: "usr_101",
    email: "alice@acme-corp.com",
    plan: "enterprise",
    mrr: 499.00,
    status: "active",
    lastActive: "2023-10-25T14:32:00Z",
  },
  "usr_102": {
    id: "usr_102",
    email: "bob@startup-io.net",
    plan: "pro",
    mrr: 49.00,
    status: "active",
    lastActive: "2023-10-24T09:15:00Z",
  },
};

/**
 * In-memory mock system logs for diagnostics.
 */
const MOCK_SYSTEM_LOGS = `[2023-10-25T14:30:00Z] [INFO] System health nominal. DB connection pool: 12/50.
[2023-10-25T14:31:12Z] [WARN] Rate limit approached for client usr_102 (92% capacity).
[2023-10-25T14:32:00Z] [INFO] User usr_101 successfully authenticated via OAuth2.`;

// ============================================================================
// Server Initialization
// ============================================================================

/**
 * Initialize the MCP Server instance with metadata describing our SaaS capabilities.
 */
const server = new Server(
  {
    name: "saas-support-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
      resources: {},
    },
  }
);

// ============================================================================
// Tool Schema Definitions (Using Zod)
// ============================================================================

/**
 * Schema defining the input arguments for the 'get_user_metrics' tool.
 * Zod validates and casts parameters passed from the LLM host.
 */
const GetUserMetricsSchema = z.object({
  userId: z.string().describe("The unique identifier of the user (e.g., usr_101)"),
});

// ============================================================================
// Request Handlers Setup
// ============================================================================

/**
 * Handler for listing available tools. Tells the MCP host what operations 
 * this server can perform.
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "get_user_metrics",
        description: "Retrieves billing, plan, and activity status for a given SaaS user.",
        inputSchema: {
          type: "object",
          properties: {
            userId: {
              type: "string",
              description: "The unique identifier of the user (e.g., usr_101)",
            },
          },
          required: ["userId"],
        },
      },
    ],
  };
});

/**
 * Handler for tool execution. When the host requests a tool run, 
 * this function parses inputs, validates them, and executes the business logic.
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "get_user_metrics") {
    // Validate inputs using Zod to ensure runtime safety against model hallucinations
    const parseResult = GetUserMetricsSchema.safeParse(args);
    
    if (!parseResult.success) {
      throw new Error(
        `Invalid arguments for get_user_metrics: ${parseResult.error.message}`
      );
    }

    const { userId } = parseResult.data;
    const user = MOCK_USERS[userId];

    if (!user) {
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({ error: `User with ID ${userId} not found.` }),
          },
        ],
        isError: true,
      };
    }

    // Return the successful result formatted as text content back to the host
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(user, null, 2),
        },
      ],
    };
  }

  throw new Error(`Unknown tool: ${name}`);
});

// ============================================================================
// Resource Handlers Setup
// ============================================================================

/**
 * Handler for listing resources. Exposes static or dynamic data URIs 
 * that the LLM host can read directly into its context window.
 */
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "saas://logs/system",
        name: "System Activity Logs",
        description: "Real-time diagnostic logs from the SaaS application backend.",
        mimeType: "text/plain",
      },
    ],
  };
});

/**
 * Handler for reading resource contents when requested by the host.
 */
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;

  if (uri === "saas://logs/system") {
    return {
      contents: [
        {
          uri,
          mimeType: "text/plain",
          text: MOCK_SYSTEM_LOGS,
        },
      ],
    };
  }

  throw new Error(`Resource not found: ${uri}`);
});

// ============================================================================
// Transport Connection & Execution
// ============================================================================

/**
 * Connects the server to standard input and output streams.
 * Stdio transport enables seamless spawning by MCP hosts like Claude Desktop.
 */
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("SaaS Support MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error in MCP server initialization:", error);
  process.exit(1);
});
