/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ErrorCode,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";

/**
 * Interface representing a managed cloud server instance within our SaaS platform.
 */
interface CloudInstance {
  id: string;
  name: string;
  region: string;
  status: "running" | "stopped" | "provisioning";
  cpuUtilizationPercent: number;
  memoryUtilizationPercent: number;
}

/**
 * In-memory data store simulating our SaaS infrastructure layer.
 */
const cloudDatabase: Record<string, CloudInstance> = {
  "inst-001": {
    id: "inst-001",
    name: "production-api-primary",
    region: "us-east-1",
    status: "running",
    cpuUtilizationPercent: 78.4,
    memoryUtilizationPercent: 82.1,
  },
  "inst-002": {
    id: "inst-002",
    name: "analytics-worker-01",
    region: "eu-west-1",
    status: "running",
    cpuUtilizationPercent: 42.0,
    memoryUtilizationPercent: 55.6,
  },
  "inst-003": {
    id: "inst-003",
    name: "staging-db-replica",
    region: "us-west-2",
    status: "stopped",
    cpuUtilizationPercent: 0.0,
    memoryUtilizationPercent: 0.0,
  },
};

/**
 * Zod schema defining the strict input parameters for scaling a cloud instance.
 */
const ScaleInstanceSchema = z.object({
  instanceId: z.string().describe("The unique identifier of the cloud instance"),
  targetRegion: z.enum(["us-east-1", "us-west-2", "eu-west-1"]).describe("Deployment region"),
  replicaCount: z.number().int().min(1).max(10).describe("Target number of scaling replicas"),
});

/**
 * Generic type helper for wrapping tool execution outputs uniformly.
 * Ensures consistent JSON Schema Output structures across all MCP tool responses.
 */
interface ToolExecutionResult<T> {
  success: boolean;
  data: T;
  timestamp: string;
}

/**
 * Core Enterprise MCP Server class leveraging the Model Context Protocol SDK.
 */
class EnterpriseCloudMcpServer {
  private server: Server;

  constructor() {
    // Initialize the MCP Server with metadata identifying our SaaS integration
    this.server = new Server(
      {
        name: "saas-cloud-control-plane",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
          resources: {},
        },
      }
    );

    this.setupRequestHandlers();
    this.setupErrorHandling();
  }

  /**
   * Configures global error handling for the transport and protocol layers.
   */
  private setupErrorHandling(): void {
    this.server.onerror = (error: Error) => {
      console.error("[MCP Protocol Error]", error);
    };

    process.on("SIGINT", async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  /**
   * Registers all tools and resource handlers with the MCP server instance.
   */
  private setupRequestHandlers(): void {
    // 1. Register Tool Discovery Handler
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: "scale_cloud_instance",
          description: "Scales a designated cloud infrastructure instance up or down based on load requirements.",
          inputSchema: {
            type: "object",
            properties: {
              instanceId: { type: "string", description: "The unique identifier of the cloud instance" },
              targetRegion: { type: "string", enum: ["us-east-1", "us-west-2", "eu-west-1"], description: "Deployment region" },
              replicaCount: { type: "number", description: "Target number of scaling replicas (1-10)" },
            },
            required: ["instanceId", "targetRegion", "replicaCount"],
          },
        },
      ],
    }));

    // 2. Register Tool Execution Handler
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      if (request.params.name === "scale_cloud_instance") {
        // Validate incoming arguments against our Zod Schema
        const parseResult = ScaleInstanceSchema.safeParse(request.params.arguments);
        
        if (!parseResult.success) {
          throw new McpError(
            ErrorCode.InvalidParams,
            `Invalid input parameters: ${parseResult.error.message}`
          );
        }

        const { instanceId, targetRegion, replicaCount } = parseResult.data;
        
        const instance = cloudDatabase[instanceId];
        if (!instance) {
          throw new McpError(
            ErrorCode.InternalError,
            `Cloud instance with ID '${instanceId}' not found in region ${targetRegion}.`
          );
        }

        // Simulate scaling action execution
        instance.status = "provisioning";

        const resultPayload: ToolExecutionResult<{ instanceId: string; newReplicas: number }> = {
          success: true,
          data: {
            instanceId,
            newReplicas: replicaCount,
          },
          timestamp: new Date().toISOString(),
        };

        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(resultPayload, null, 2),
            },
          ],
        };
      }

      throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${request.params.name}`);
    });

    // 3. Register Resource Discovery Handler
    this.server.setRequestHandler(ListResourcesRequestSchema, async () => ({
      resources: Object.values(cloudDatabase).map((inst) => ({
        uri: `cloud://instances/${inst.id}`,
        name: `Cloud Instance: ${inst.name}`,
        mimeType: "application/json",
        description: `Live telemetry and metadata for server ${inst.id} in ${inst.region}`,
      })),
    }));

    // 4. Register Resource Read Handler
    this.server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
      const match = request.params.uri.match(/^cloud:\/\/instances\/(inst-\d+)$/);
      if (!match) {
        throw new McpError(ErrorCode.InvalidParams, `Unsupported resource URI: ${request.params.uri}`);
      }

      const instanceId = match[1];
      const instance = cloudDatabase[instanceId];

      if (!instance) {
        throw new McpError(ErrorCode.InternalError, `Instance not found for URI: ${request.params.uri}`);
      }

      return {
        contents: [
          {
            uri: request.params.uri,
            mimeType: "application/json",
            text: JSON.stringify(instance, null, 2),
          },
        ],
      };
    });
  }

  /**
   * Starts the MCP server using Standard I/O (stdio) transport.
   */
  public async run(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Enterprise SaaS MCP Server running on stdio transport.");
  }
}

// Instantiate and execute the server process
const mcpServer = new EnterpriseCloudMcpServer();
mcpServer.run().catch((error) => {
  console.error("Fatal error running MCP server:", error);
  process.exit(1);
});
