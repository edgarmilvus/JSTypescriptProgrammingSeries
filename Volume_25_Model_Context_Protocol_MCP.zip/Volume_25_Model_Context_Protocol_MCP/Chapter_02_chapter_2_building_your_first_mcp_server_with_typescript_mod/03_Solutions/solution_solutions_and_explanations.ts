/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { z } from "zod";

// 1. Define strict Zod validation schema including the interactive encoding whitelist
const ReadSecureFileSchema = z.object({
  path: z
    .string()
    .min(1, "Path cannot be empty")
    .refine((val) => !val.includes(".."), {
      message: "Directory traversal attempts (..) are forbidden",
    }),
  encoding: z.enum(["utf8", "ascii", "base64"]).default("utf8"),
});

// 2. Instantiate MCP Server with tool capabilities
const server = new Server(
  {
    name: "secure-file-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// 3. Register available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "read_secure_file",
        description: "Safely reads a file from the local file system with path traversal protection.",
        inputSchema: {
          type: "object",
          properties: {
            path: { type: "string", description: "Target file path relative to root" },
            encoding: { type: "string", enum: ["utf8", "ascii", "base64"], description: "File encoding" },
          },
          required: ["path"],
        },
      },
    ],
  };
});

// 4. Implement tool execution handler with error boundaries and validation
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name !== "read_secure_file") {
    throw new Error(`Unknown tool: ${request.params.name}`);
  }

  // Validate inputs using Zod
  const validationResult = ReadSecureFileSchema.safeParse(request.params.arguments);
  if (!validationResult.success) {
    return {
      content: [
        {
          type: "text",
          text: `Validation Error: ${JSON.stringify(validationResult.error.format())}`,
        },
      ],
      isError: true,
    };
  }

  const { path: filePath, encoding } = validationResult.data;
  const absolutePath = path.resolve(process.cwd(), filePath);

  try {
    // 5. Asynchronous file read operation
    const fileContent = await fs.readFile(absolutePath, { encoding });
    return {
      content: [
        {
          type: "text",
          text: fileContent,
        },
      ],
    };
  } catch (error: any) {
    // Gracefully catch I/O errors and return MCP-compliant error responses
    return {
      content: [
        {
          type: "text",
          text: `File System Error: ${error.message}`,
        },
      ],
      isError: true,
    };
  }
});

// 6. Connect via Stdio Server Transport
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Secure File MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Server fatal error:", error);
  process.exit(1);
});
