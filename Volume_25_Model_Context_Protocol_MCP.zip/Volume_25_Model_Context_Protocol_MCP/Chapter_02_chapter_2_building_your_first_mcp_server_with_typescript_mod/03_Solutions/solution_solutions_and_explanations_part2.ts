/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ListResourceTemplatesRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import * as os from "node:os";

const server = new Server(
  {
    name: "telemetry-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      resources: {},
    },
  }
);

// 1. Register static and parameterized resource listings
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "system://telemetry/current",
        name: "Current System Telemetry",
        description: "Real-time CPU load, memory utilization, and uptime metrics.",
        mimeType: "application/json",
      },
    ],
  };
});

server.setRequestHandler(ListResourceTemplatesRequestSchema, async () => {
  return {
    resourceTemplates: [
      {
        uriTemplate: "system://logs/{category}",
        name: "System Logs by Category",
        description: "Retrieve simulated log entries filtered by category (error, access, debug).",
        mimeType: "application/json",
      },
    ],
  };
});

// 2. Implement resource reader handling dynamic metrics and URI templates
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const uri = request.params.uri;

  // Handle static telemetry resource
  if (uri === "system://telemetry/current") {
    // 3. Gather real-time metrics using Node.js os module dynamically at request time
    const telemetryData = {
      freeMemory: os.freemem(),
      totalMemory: os.totalmem(),
      uptime: os.uptime(),
      loadAvg: os.loadavg(),
      timestamp: new Date().toISOString(),
    };

    return {
      contents: [
        {
          uri,
          mimeType: "application/json",
          text: JSON.stringify(telemetryData, null, 2),
        },
      ],
    };
  }

  // Handle dynamic resource templates (e.g., system://logs/{category})
  const logMatch = uri.match(/^system:\/\/logs\/(error|access|debug)$/);
  if (logMatch) {
    const category = logMatch[1];
    
    // Simulate filtered log entries based on category parameter
    const simulatedLogs = [
      { id: 1, level: category, message: `Sample ${category} log entry alpha`, timestamp: new Date().toISOString() },
      { id: 2, level: category, message: `Sample ${category} log entry beta`, timestamp: new Date().toISOString() },
    ];

    return {
      contents: [
        {
          uri,
          mimeType: "application/json",
          text: JSON.stringify(simulatedLogs, null, 2),
        },
      ],
    };
  }

  throw new Error(`Resource not found: ${uri}`);
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
