/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";

const QuerySchema = z.object({
  query: z.string().min(1),
  timeoutMs: z.number().positive().default(5000),
});

const server = new Server(
  { name: "async-db-server", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "query_remote_database",
      description: "Executes a remote database query with timeout and automatic retry logic.",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string" },
          timeoutMs: { type: "number" },
        },
        required: ["query"],
      },
    },
  ],
}));

// Helper function simulating a flaky database call with retry and exponential backoff
async function executeWithRetry(query: string, timeoutMs: number, maxRetries = 3): Promise<string> {
  let attempt = 0;
  
  while (attempt < maxRetries) {
    attempt++;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    try {
      // Simulate remote async query operation
      const result = await new Promise<string>((resolve, reject) => {
        const timer = setTimeout(() => {
          // Simulate a transient network error on early attempts
          if (attempt < 3) {
            reject(new Error("ERR_TRANSIENT_NETWORK"));
          } else {
            resolve(JSON.stringify({ status: "success", query, executedAt: new Date() }));
          }
        }, 1000);

        controller.signal.addEventListener("abort", () => {
          clearTimeout(timer);
          reject(new Error("Operation timed out"));
        });
      });

      clearTimeout(timeoutId);
      return result;
    } catch (error: any) {
      clearTimeout(timeoutId);
      // Only retry on transient custom network errors, throw immediately otherwise
      if (error.message !== "ERR_TRANSIENT_NETWORK" || attempt >= maxRetries) {
        throw error;
      }
      // Exponential backoff delay: 2^attempt * 100ms
      const backoffDelay = Math.pow(2, attempt) * 100;
      await new Promise((res) => setTimeout(res, backoffDelay));
    }
  }
  throw new Error("Max retry attempts reached without success.");
}

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name !== "query_remote_database") {
    throw new Error("Unknown tool");
  }

  const validation = QuerySchema.safeParse(request.params.arguments);
  if (!validation.success) {
    return {
      content: [{ type: "text", text: `Invalid arguments: ${validation.error.message}` }],
      isError: true,
    };
  }

  const { query, timeoutMs } = validation.data;

  try {
    const data = await executeWithRetry(query, timeoutMs);
    return {
      content: [{ type: "text", text: data }],
    };
  } catch (error: any) {
    return {
      content: [{ type: "text", text: `Database Query Failed: ${error.message}` }],
      isError: true,
    };
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
