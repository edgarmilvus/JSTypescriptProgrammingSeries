/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useOptimistic, useState, useTransition } from 'react';

interface ToolCall {
  id: string;
  toolName: string;
  status: 'pending' | 'success' | 'error' | 'cancelled';
  result?: string;
}

export function ToolExecutionPanel({ initialTools }: { initialTools: ToolCall[] }) {
  const [tools, setTools] = useState<ToolCall[]>(initialTools);
  const [isPending, startTransition] = useTransition();

  // 1. Implement useOptimistic hook to manage optimistic tool execution states
  const [optimisticTools, setOptimisticTools] = useOptimistic(
    tools,
    (state, newTool: ToolCall) => [...state, newTool]
  );

  // Interactive Challenge: Support cancellation via AbortController mapping
  const [abortControllers, setAbortControllers] = useState<Map<string, AbortController>>(new Map());

  const handleExecuteTool = async (toolName: string) => {
    const toolId = Math.random().toString(36.substring(2, 9));
    const newTool: ToolCall = { id: toolId, toolName, status: 'pending' };
    
    const controller = new AbortController();
    setAbortControllers(prev => new Map(prev).set(toolId, controller));

    startTransition(async () => {
      // Apply optimistic update immediately
      setOptimisticTools(newTool);

      try {
        // Simulate network call to MCP server with cancellation support
        const response = await simulateMcpToolExecution(toolName, controller.signal);
        setTools(current =>
          current.map(t => (t.id === toolId ? { ...t, status: 'success', result: response } : t))
        );
      } catch (error: any) {
        const status = error.name === 'AbortError' ? 'cancelled' : 'error';
        setTools(current =>
          current.map(t => (t.id === toolId ? { ...t, status, result: error.message } : t))
        );
      } finally {
        setAbortControllers(prev => {
          const next = new Map(prev);
          next.delete(toolId);
          return next;
        });
      }
    });
  };

  const handleCancelTool = (toolId: string) => {
    const controller = abortControllers.get(toolId);
    if (controller) {
      controller.abort();
    }
  };

  return (
    <div className="p-4 border rounded-lg shadow-sm max-w-xl mx-auto">
      <h2 className="text-lg font-semibold mb-4">MCP Tool Execution Monitor</h2>
      <button
        onClick={() => handleExecuteTool("read_secure_file")}
        className="mb-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Execute File Read Tool
      </button>

      <div className="space-y-3">
        {optimisticTools.map((tool) => (
          <div key={tool.id} className="p-3 border rounded flex justify-between items-center bg-gray-50">
            <div>
              <p className="font-medium">Tool: {tool.toolName}</p>
              <p className="text-sm text-gray-600">Status: <span className="font-semibold">{tool.status}</span></p>
              {tool.result && <p className="text-xs text-gray-500 mt-1">Result: {tool.result}</p>}
            </div>
            {tool.status === 'pending' && (
              <button
                onClick={() => handleCancelTool(tool.id)}
                className="px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600"
              >
                Cancel
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// Simulated MCP server tool call helper
async function simulateMcpToolExecution(toolName: string, signal: AbortSignal): Promise<string> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      resolve(`Successfully executed ${toolName}`);
    }, 3000);

    signal.addEventListener('abort', () => {
      clearTimeout(timer);
      const err = new Error('Execution cancelled by user.');
      err.name = 'AbortError';
      reject(err);
    });
  });
}
