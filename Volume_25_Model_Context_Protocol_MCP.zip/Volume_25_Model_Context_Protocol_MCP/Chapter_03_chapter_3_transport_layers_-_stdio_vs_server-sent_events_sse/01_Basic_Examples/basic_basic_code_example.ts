/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { 
  CallToolRequestSchema, 
  ListToolsRequestSchema,
  Tool 
} from "@modelcontextprotocol/sdk/types.js";
import express, { Request, Response } from "express";
import { z } from "zod";

/**
 * Define the SaaS Customer Analytics Tool schema using Zod.
 * This guarantees our LLM agent receives properly typed parameters.
 */
const AnalyzeBillingInputSchema = z.object({
  customerId: z.string().describe("The unique UUID of the SaaS tenant customer."),
  billingCycle: z.string().describe("The billing cycle to audit (e.g., '2023-11')."),
});

/**
 * Define the MCP Tool metadata exposed to connected agents.
 */
const ANALYZE_BILLING_TOOL: Tool = {
  name: "analyze_customer_billing",
  description: "Audits Stripe and internal ledger records for anomalies during a specified billing cycle.",
  inputSchema: {
    type: "object",
    properties: {
      customerId: { type: "string", description: "The unique UUID of the SaaS tenant customer." },
      billingCycle: { type: "string", description: "The billing cycle to audit (e.g., '2023-11')." },
    },
    required: ["customerId", "billingCycle"],
  },
};

/**
 * Factory function to instantiate and configure the core MCP Server instance.
 * Encapsulates capability declarations and request handlers to allow sharing 
 * across both Stdio and SSE transports.
 */
function createSaaSMcpServer(): Server {
  const server = new Server(
    {
      name: "saas-analytics-mcp-server",
      version: "1.0.0",
    },
    {
      capabilities: {
        tools: {},
      },
    }
  );

  // Register available tools handler
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools: [ANALYZE_BILLING_TOOL],
    };
  });

  // Register tool execution handler
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    if (request.params.name !== "analyze_customer_billing") {
      throw new Error(`Unknown tool: ${request.params.name}`);
    }

    // Validate inputs using Zod runtime parsing
    const args = AnalyzeBillingInputSchema.parse(request.params.arguments);
    
    // Simulate complex SaaS ledger analysis logic
    const auditResult = {
      customerId: args.customerId,
      billingCycle: args.billingCycle,
      status: "COMPLETED",
      discrepancyDetected: false,
      calculatedTotal: 499.00,
      timestamp: new Date().toISOString(),
    };

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(auditResult, null, 2),
        },
      ],
    };
  });

  return server;
}

/**
 * Main execution bootstrapper determining the transport layer via CLI arguments.
 * Usage: 
 *   - Local Stdio mode: `npx ts-node server.ts stdio`
 *   - Remote SSE mode:  `npx ts-node server.ts sse`
 */
async function main() {
  const transportMode = process.argv[2] || "stdio";
  const server = createSaaSMcpServer();

  if (transportMode === "stdio") {
    console.error("Starting SaaS MCP Server using Stdio Transport...");
    const stdioTransport = new StdioServerTransport();
    await server.connect(stdioTransport);
    console.error("MCP Stdio Server successfully connected and listening on stdin/stdout.");
  } else if (transportMode === "sse") {
    console.error("Starting SaaS MCP Server using HTTP Server-Sent Events (SSE) Transport...");
    
    const app = express();
    // Maintain a map of active SSE transports keyed by session ID
    const activeTransports = new Map<string, SSEServerTransport>();

    // SSE connection endpoint for remote agents
    app.get("/sse", async (req: Request, res: Response) => {
      console.log("New inbound SSE connection request from remote client.");
      const sseTransport = new SSEServerTransport("/messages", res);
      activeTransports.set(sseTransport.sessionId, sseTransport);

      res.on("close", () => {
        console.log(`SSE connection closed for session: ${sseTransport.sessionId}`);
        activeTransports.delete(sseTransport.sessionId);
      });

      await server.connect(sseTransport);
    });

    // Inbound message handling endpoint matching the SSE transport path
    app.post("/messages", async (req: Request, res: Response) => {
      const sessionId = req.query.sessionId as string;
      const transport = activeTransports.get(sessionId);

      if (!transport) {
        res.status(404).send(`Active SSE session not found for ID: ${sessionId}`);
        return;
      }

      await transport.handlePostMessage(req, res);
    });

    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
      console.log(`MCP SSE Server listening on http://localhost:${PORT}`);
      console.log(`- SSE Endpoint: http://localhost:${PORT}/sse`);
      console.log(`- Message Endpoint: http://localhost:${PORT}/messages?sessionId=<ID>`);
    });
  } else {
    console.error(`Invalid transport mode: "${transportMode}". Use "stdio" or "sse".`);
    process.exit(1);
  }
}

// Execute main application bootstrapper with top-level error handling
main().catch((error) => {
  console.error("Fatal error during SaaS MCP server startup:", error);
  process.exit(1);
});
