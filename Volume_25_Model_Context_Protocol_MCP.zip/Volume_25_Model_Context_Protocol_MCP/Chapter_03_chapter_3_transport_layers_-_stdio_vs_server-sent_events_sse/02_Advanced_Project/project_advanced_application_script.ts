/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file mcp-hybrid-transport-manager.ts
 * @description Enterprise SaaS integration layer managing dual MCP transports:
 * Stdio for localized, high-throughput file system tooling and SSE for 
 * remote, multi-client cloud agent orchestration.
 */

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { SSEClientTransport } from "@modelcontextprotocol/sdk/client/sse.js";
import { NextRequest, NextResponse } from "next/server";

/**
 * Interface representing the unified state of our dual-transport MCP manager.
 */
interface MCPSessionState {
  stdioClient: Client | null;
  sseClient: Client | null;
  isInitialized: boolean;
  activeTools: string[];
}

// Global session singleton for demonstration purposes (in production, use Redis/Memcached)
const globalSession: MCPSessionState = {
  stdioClient: null,
  sseClient: null,
  isInitialized: false,
  activeTools: [],
};

/**
 * 1. Initialize and configure the Stdio Transport for local secure execution.
 * Spawns a child process running a local MCP server script.
 */
async function initializeStdioTransport(): Promise<Client> {
  // Define the process execution parameters securely
  const transport = new StdioClientTransport({
    command: "node",
    args: ["./dist/local-mcp-server.js"],
    env: {
      ...process.env,
      NODE_ENV: "production",
    },
  });

  const client = new Client(
    {
      name: "SaaS-Local-Agent-Client",
      version: "1.0.0",
    },
    {
      capabilities: {
        tools: {},
      },
    }
  );

  // Establish connection across the standard input/output stream boundary
  await client.connect(transport);
  console.log("[Stdio Transport] Successfully connected to local subprocess.");
  return client;
}

/**
 * 2. Initialize and configure the SSE Transport for remote cloud agent coordination.
 * Connects to an HTTP endpoint emitting Server-Sent Events.
 */
async function initializeSSETransport(sseEndpointUrl: string): Promise<Client> {
  const url = new URL(sseEndpointUrl);
  const transport = new SSEClientTransport(url);

  const client = new Client(
    {
      name: "SaaS-Cloud-Agent-Client",
      version: "1.0.0",
    },
    {
      capabilities: {
        tools: {},
      },
    }
  );

  // Connect via HTTP chunked transfer encoding and establish SSE event listeners
  await client.connect(transport);
  console.log(`[SSE Transport] Successfully connected to remote endpoint: ${sseEndpointUrl}`);
  return client;
}

/**
 * 3. Unified Bootstrap Handler
 * Coordinates the startup lifecycle of both transport layers.
 */
export async function bootstrapMCPTransports(sseUrl: string): Promise<void> {
  if (globalSession.isInitialized) {
    console.log("[MCP Manager] Transports already initialized.");
    return;
  }

  try {
    // Instantiate both clients concurrently for optimal startup performance
    const [stdioClient, sseClient] = await Promise.all([
      initializeStdioTransport(),
      initializeSSETransport(sseUrl),
    ]);

    globalSession.stdioClient = stdioClient;
    globalSession.sseClient = sseClient;
    globalSession.isInitialized = true;

    // Aggregate available tools from both transport layers
    const stdioToolsResponse = await stdioClient.listTools();
    const sseToolsResponse = await sseClient.listTools();

    globalSession.activeTools = [
      ...stdioToolsResponse.tools.map((t) => `stdio:${t.name}`),
      ...sseToolsResponse.tools.map((t) => `sse:${t.name}`),
    ];

    console.log(`[MCP Manager] Initialization complete. Active tools:`, globalSession.activeTools);
  } catch (error) {
    console.error("[MCP Manager] Critical failure during transport bootstrap:", error);
    throw new Error("Failed to initialize MCP transport layers.");
  }
}

/**
 * 4. Next.js API Route Handler for Dynamic Tool Execution
 * Receives execution intents from the SaaS frontend and routes them to the correct MCP transport.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const { toolName, arguments: toolArgs } = body;

    if (!globalSession.isInitialized) {
      await bootstrapMCPTransports(process.env.REMOTE_MCP_SSE_URL || "http://localhost:4000/sse");
    }

    let result;
    // Route execution based on namespaced tool prefixes
    if (toolName.startsWith("stdio:")) {
      const actualName = toolName.replace("stdio:", "");
      if (!globalSession.stdioClient) throw new Error("Stdio client is uninitialized.");
      
      console.log(`[Router] Dispatching execution to Stdio transport for tool: ${actualName}`);
      result = await globalSession.stdioClient.callTool({
        name: actualName,
        arguments: toolArgs,
      });
    } else if (toolName.startsWith("sse:")) {
      const actualName = toolName.replace("sse:", "");
      if (!globalSession.sseClient) throw new Error("SSE client is uninitialized.");

      console.log(`[Router] Dispatching execution to SSE transport for tool: ${actualName}`);
      result = await globalSession.sseClient.callTool({
        name: actualName,
        arguments: toolArgs,
      });
    } else {
      return NextResponse.json(
        { error: `Invalid or unrecognized tool namespace: ${toolName}` },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, data: result }, { status: 200 });
  } catch (error: any) {
    console.error("[API Route Error]", error);
    return NextResponse.json(
      { success: false, error: error.message || "Internal server error" },
      { status: 500 }
    );
  }
}
