/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ErrorCode,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import * as fs from "node:fs/promises";
import * as path from "node:path";

// Initialize the MCP Server instance with appropriate metadata and capabilities
const server = new Server(
  {
    name: "mcp-filesystem-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Register the ListToolsRequestSchema handler to expose your file system tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "list_directory",
        description: "List contents of an absolute directory path.",
        inputSchema: {
          type: "object",
          properties: {
            dirPath: { type: "string", description: "Absolute path to list" },
          },
          required: ["dirPath"],
        },
      },
      {
        name: "read_file_block",
        description: "Read a specific line block from a file.",
        inputSchema: {
          type: "object",
          properties: {
            filePath: { type: "string", description: "Absolute path to the file" },
            startLine: { type: "number", description: "Starting line number (1-indexed)" },
            lineCount: { type: "number", description: "Number of lines to read" },
          },
          required: ["filePath", "startLine", "lineCount"],
        },
      },
      {
        name: "write_file_patch",
        description: "Safely write text content to a file.",
        inputSchema: {
          type: "object",
          properties: {
            filePath: { type: "string", description: "Absolute path to the file" },
            content: { type: "string", description: "Content to write" },
          },
          required: ["filePath", "content"],
        },
      },
    ],
  };
});

// Register the CallToolRequestSchema handler to execute tool logic safely with error boundaries
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    if (name === "list_directory") {
      const dirPath = String(args?.dirPath);
      const entries = await fs.readdir(dirPath, { withFileTypes: true });
      const results = entries.map((entry) => ({
        name: entry.name,
        type: entry.isDirectory() ? "directory" : "file",
      }));
      return { content: [{ type: "text", text: JSON.stringify(results, null, 2) }] };
    }

    if (name === "read_file_block") {
      const filePath = String(args?.filePath);
      const startLine = Number(args?.startLine);
      const lineCount = Number(args?.lineCount);

      const fileContent = await fs.readFile(filePath, "utf-8");
      const lines = fileContent.split(/\r?\n/);
      const targetLines = lines.slice(startLine - 1, startLine - 1 + lineCount);

      return { content: [{ type: "text", text: targetLines.join("\n") }] };
    }

    if (name === "write_file_patch") {
      const filePath = String(args?.filePath);
      const content = String(args?.content);

      await fs.mkdir(path.dirname(filePath), { recursive: true });
      await fs.writeFile(filePath, content, "utf-8");

      return { content: [{ type: "text", text: `Successfully wrote to ${filePath}` }] };
    }

    throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
  } catch (error: any) {
    // Translate native Node errors into standardized MCP JSON-RPC error responses
    if (error.code === "ENOENT") {
      throw new McpError(ErrorCode.InvalidParams, `File or directory not found: ${error.path}`);
    }
    if (error.code === "EACCES") {
      throw new McpError(ErrorCode.InternalError, `Permission denied: ${error.path}`);
    }
    throw new McpError(ErrorCode.InternalError, error.message || String(error));
  }
});

// Instantiate StdioServerTransport and connect the server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  process.stderr.write("MCP File System Stdio Server running...\n");
}

// Lifecycle Management: Graceful Shutdown
const handleShutdown = async () => {
  process.stderr.write("Shutting down Stdio server gracefully...\n");
  try {
    await server.close();
    process.exit(0);
  } catch (err) {
    process.stderr.write(`Error during shutdown: ${err}\n`);
    process.exit(1);
  }
};

process.on("SIGINT", handleShutdown);
process.on("SIGTERM", handleShutdown);

main().catch((error) => {
  process.stderr.write(`Server initialization failed: ${error}\n`);
  process.exit(1);
});
