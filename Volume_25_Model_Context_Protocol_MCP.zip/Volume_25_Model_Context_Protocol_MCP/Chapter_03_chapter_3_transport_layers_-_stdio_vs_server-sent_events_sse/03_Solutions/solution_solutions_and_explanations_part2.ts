/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from "express";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import crypto from "node:crypto";

const app = express();
app.use(express.json());

// Store active transport sessions mapping session IDs to transport instances
const activeTransports = new Map<string, SSEServerTransport>();

// Implement GET /sse route to initialize the SSE connection and send the endpoint event
app.get("/sse", async (req: Request, res: Response) => {
  const transport = new SSEServerTransport("/messages", res);
  const sessionId = transport.sessionId;
  activeTransports.set(sessionId, transport);

  res.on("close", () => {
    activeTransports.delete(sessionId);
    console.error(`Session closed and cleaned up: ${sessionId}`);
  });

  // Connect to a mock or fully instantiated MCP server instance
  const server = new Server(
    { name: "remote-agent-hub", version: "1.0.0" },
    { capabilities: { tools: {} } }
  );

  await server.connect(transport);
});

// Implement POST /messages route to handle incoming client JSON-RPC messages
app.post("/messages", async (req: Request, res: Response) => {
  const sessionId = String(req.query.sessionId);
  const transport = activeTransports.get(sessionId);

  if (!transport) {
    res.status(404).json({ error: "Session not found or expired" });
    return;
  }

  try {
    await transport.handlePostMessage(req, res);
  } catch (error) {
    console.error(`Error handling message for session ${sessionId}:`, error);
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal transport message handling error" });
    }
  }
});

// Background task simulator to broadcast periodic system metrics
setInterval(() => {
  // Broadcast simulated notifications across active transport connections if needed
  activeTransports.forEach((transport, sessionId) => {
    // Demonstration of background asynchronous notification hooks
  });
}, 10000);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.error(`MCP SSE Server running on port ${PORT}`);
});
