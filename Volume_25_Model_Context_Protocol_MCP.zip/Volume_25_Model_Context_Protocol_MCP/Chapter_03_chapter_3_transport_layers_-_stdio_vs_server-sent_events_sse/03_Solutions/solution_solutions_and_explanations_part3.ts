/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface ResilientTransportConfig {
  serverUrl: string;
  maxRetries: number;
  baseIntervalMs: number;
  maxBufferCapacity: number;
}

export class ResilientSSEClientWrapper {
  private state: 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'RECONNECTING' = 'DISCONNECTED';
  private messageQueue: any[] = [];
  private retryCount = 0;
  private eventSource: EventSource | null = null;
  private messageEndpoint: string | null = null;

  constructor(private config: ResilientTransportConfig) {}

  // Implement the connection initialization method with event listeners
  public connect(): void {
    if (this.state === 'CONNECTED' || this.state === 'CONNECTING') return;

    this.state = this.retryCount > 0 ? 'RECONNECTING' : 'CONNECTING';
    
    // Note: EventSource is native to browsers; in Node.js environments, use 'eventsource' package
    this.eventSource = new EventSource(this.config.serverUrl);

    this.eventSource.onopen = () => {
      this.state = 'CONNECTED';
      this.retryCount = 0;
      this.flushBuffer();
    };

    this.eventSource.addEventListener('endpoint', (event: MessageEvent) => {
      this.messageEndpoint = event.data;
    });

    this.eventSource.onerror = () => {
      this.handleConnectionLoss();
    };
  }

  // Implement the send() method that checks state and buffers if disconnected
  public async send(payload: any): Promise<void> {
    if (this.state !== 'CONNECTED' || !this.messageEndpoint) {
      if (this.messageQueue.length < this.config.maxBufferCapacity) {
        this.messageQueue.push(payload);
      } else {
        throw new Error('Transport buffer capacity exceeded. Message dropped.');
      }
      return;
    }

    try {
      await this.dispatchMessage(payload);
    } catch (error) {
      this.messageQueue.push(payload);
      this.handleConnectionLoss();
    }
  }

  // Implement the exponential backoff algorithm with jitter for retries
  private handleConnectionLoss(): void {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }

    if (this.retryCount >= this.config.maxRetries) {
      this.state = 'DISCONNECTED';
      return;
    }

    this.state = 'RECONNECTING';
    this.retryCount++;

    const exponentialDelay = this.config.baseIntervalMs * Math.pow(2, this.retryCount);
    // Apply ±20% jitter factor
    const jitter = exponentialDelay * (Math.random() * 0.4 - 0.2);
    const totalDelay = Math.max(0, exponentialDelay + jitter);

    setTimeout(() => {
      this.connect();
    }, totalDelay);
  }

  // Implement the buffer flushing mechanism upon successful reconnection
  private async flushBuffer(): Promise<void> {
    while (this.messageQueue.length > 0 && this.state === 'CONNECTED') {
      const payload = this.messageQueue.shift();
      try {
        await this.dispatchMessage(payload);
      } catch (error) {
        this.messageQueue.unshift(payload);
        this.handleConnectionLoss();
        break;
      }
    }
  }

  private async dispatchMessage(payload: any): Promise<void> {
    if (!this.messageEndpoint) throw new Error('No message endpoint established');
    const response = await fetch(this.messageEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
  }
}
