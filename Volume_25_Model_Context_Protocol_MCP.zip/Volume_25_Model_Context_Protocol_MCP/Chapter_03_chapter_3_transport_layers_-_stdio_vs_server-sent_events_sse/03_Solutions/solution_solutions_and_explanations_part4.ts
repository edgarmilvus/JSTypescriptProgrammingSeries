/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { ChildProcess, spawn } from "node:child_process";
import * as readline from "node:readline";

interface SubAgentConfig {
  name: string;
  executablePath: string;
  args: string[];
}

export class StdioBridgeSupervisor {
  private subAgents = new Map<string, { process: ChildProcess; queue: any[] }>();
  private pendingRequests = new Map<string | number, { resolve: Function; reject: Function }>();

  constructor(private configs: SubAgentConfig[]) {
    for (const config of configs) {
      this.spawnSubAgent(config);
    }
  }

  // Spawn each sub-agent and attach stdout/stderr line parsers
  private spawnSubAgent(config: SubAgentConfig): void {
    const child = spawn(config.executablePath, config.args, {
      stdio: ["pipe", "pipe", "inherit"],
    });

    const rl = readline.createInterface({
      input: child.stdout!,
      terminal: false,
    });

    rl.on("line", (line) => {
      try {
        const response = JSON.parse(line);
        const id = response.id;
        if (id !== undefined && this.pendingRequests.has(id)) {
          const { resolve } = this.pendingRequests.get(id)!;
          this.pendingRequests.delete(id);
          resolve(response);
        }
      } catch (err) {
        process.stderr.write(`[Bridge] Failed to parse JSON from sub-agent ${config.name}: ${line}\n`);
      }
    });

    child.on("exit", (code) => {
      process.stderr.write(`[Bridge] Sub-agent ${config.name} exited with code ${code}. Restarting...\n`);
      // Reject pending in-flight requests associated with this crash if necessary
      this.spawnSubAgent(config);
    });

    this.subAgents.set(config.name, { process: child, queue: [] });
  }

  // Implement method to route incoming JSON-RPC requests to the correct child process stdin
  public async sendRequest(subAgentName: string, request: { id: string | number; method: string; params?: any }): Promise<any> {
    const agentEntry = this.subAgents.get(subAgentName);
    if (!agentEntry) {
      throw new Error(`Sub-agent not found: ${subAgentName}`);
    }

    return new Promise((resolve, reject) => {
      this.pendingRequests.set(request.id, { resolve, reject });
      const payload = JSON.stringify(request) + "\n";
      
      const success = agentEntry.process.stdin?.write(payload);
      if (!success) {
        agentEntry.process.stdin?.once("drain", () => {});
      }
    });
  }
}
