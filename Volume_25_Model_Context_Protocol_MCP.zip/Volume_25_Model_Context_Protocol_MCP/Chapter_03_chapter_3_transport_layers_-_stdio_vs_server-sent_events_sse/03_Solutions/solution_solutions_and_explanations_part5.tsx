/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

export interface TransportDashboardProps {
  telemetryUrl: string;
  refreshIntervalMs?: number;
}

interface LogEntry {
  id: string;
  timestamp: string;
  direction: 'INBOUND' | 'OUTBOUND' | 'SYSTEM';
  method: string;
  payload: any;
}

export const MCPTransportDashboard: React.FC<TransportDashboardProps> = ({
  telemetryUrl,
  refreshIntervalMs = 1000,
}) => {
  const [connectionState, setConnectionState] = useState<'CONNECTED' | 'RECONNECTING' | 'DISCONNECTED'>('DISCONNECTED');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [rtt, setRtt] = useState<number>(0);
  const [throughput, setThroughput] = useState<{ in: number; out: number }>({ in: 0, out: 0 });
  const eventSourceRef = useRef<EventSource | null>(null);

  // Establish EventSource connection to telemetryUrl
  useEffect(() => {
    const es = new EventSource(telemetryUrl);
    eventSourceRef.current = es;

    es.onopen = () => setConnectionState('CONNECTED');
    es.onerror = () => setConnectionState('RECONNECTING');

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const newLog: LogEntry = {
          id: Math.random().toString(36.substring(2, 9)),
          timestamp: new Date().toLocaleTimeString(),
          direction: data.direction || 'INBOUND',
          method: data.method || 'telemetry',
          payload: data,
        };
        setLogs((prev) => [newLog, ...prev].slice(0, 50));
        if (data.rtt) setRtt(data.rtt);
      } catch (err) {
        console.error('Failed to parse telemetry event data');
      }
    };

    return () => {
      es.close();
    };
  }, [telemetryUrl]);

  // Manual action handlers
  const handleForceDisconnect = () => {
    eventSourceRef.current?.close();
    setConnectionState('DISCONNECTED');
  };

  const handleClearLogs = () => setLogs([]);

  const getStateColor = () => {
    switch (connectionState) {
      case 'CONNECTED': return 'bg-emerald-500';
      case 'RECONNECTING': return 'bg-amber-500';
      case 'DISCONNECTED': return 'bg-rose-500';
    }
  };

  return (
    <div className="mcp-dashboard p-6 bg-slate-900 text-slate-100 rounded-xl shadow-2xl font-sans max-w-4xl mx-auto">
      <header className="flex justify-between items-center mb-6 border-b border-slate-700 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">MCP Transport Monitor</h1>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-slate-800 px-3 py-1.5 rounded-full border border-slate-700">
            <span className={`h-3 w-3 rounded-full ${getStateColor()} animate-pulse`} />
            <span className="text-xs font-semibold tracking-wider uppercase">{connectionState}</span>
          </div>
          <span className="text-sm font-medium bg-slate-800 px-3 py-1.5 rounded-full border border-slate-700">RTT: {rtt}ms</span>
        </div>
      </header>

      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-xs text-slate-400 font-medium">Inbound Rate</p>
          <p className="text-xl font-bold mt-1 text-emerald-400">{throughput.in} msg/s</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-xs text-slate-400 font-medium">Outbound Rate</p>
          <p className="text-xl font-bold mt-1 text-sky-400">{throughput.out} msg/s</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-xs text-slate-400 font-medium">Buffered Logs</p>
          <p className="text-xl font-bold mt-1 text-purple-400">{logs.length} entries</p>
        </div>
      </div>

      {/* Interactive Message Inspector Log Stream */}
      <div className="bg-slate-950 rounded-lg border border-slate-800 h-80 overflow-y-auto p-4 font-mono text-xs space-y-2">
        {logs.length === 0 ? (
          <div className="text-center text-slate-600 py-24">Awaiting transport telemetry stream...</div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className="p-2 rounded bg-slate-900/80 border border-slate-800 flex flex-col space-y-1">
              <div className="flex justify-between text-slate-400">
                <span className="font-bold text-slate-300">{log.method}</span>
                <span>{log.timestamp}</span>
              </div>
              <pre className="text-slate-300 overflow-x-auto">{JSON.stringify(log.payload, null, 2)}</pre>
            </div>
          ))
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4 mt-6">
        <button onClick={handleForceDisconnect} className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-semibold transition">
          Force Disconnect
        </button>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-sm font-semibold transition">
          Trigger Reconnection
        </button>
        <button onClick={handleClearLogs} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm font-semibold transition border border-slate-700">
          Clear Log Buffer
        </button>
      </div>
    </div>
  );
};
