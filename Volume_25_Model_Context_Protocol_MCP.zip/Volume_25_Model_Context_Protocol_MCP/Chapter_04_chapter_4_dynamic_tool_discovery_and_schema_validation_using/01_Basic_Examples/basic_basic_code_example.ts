/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from "zod";

/**
 * @file mcp-dynamic-tool-example.ts
 * @description A self-contained TypeScript example demonstrating dynamic tool discovery,
 * Zod schema validation, and safe execution within a Model Context Protocol (MCP) SaaS context.
 */

// ==========================================
// 1. MCP Server Registry Simulation
// ==========================================

/**
 * Represents the structure of a tool discovered dynamically via the MCP wire protocol.
 */
interface MCPToolDefinition {
  name: string;
  description: string;
  inputSchema: z.ZodTypeAny;
  // eslint-violation-ignore-next-line
  handler: (args: any) => Promise<string>;
}

/**
 * Mock remote MCP server registry holding available SaaS tools.
 */
class MCPServerRegistry {
  private tools: Map<string, MCPToolDefinition> = new Map();

  /**
   * Registers a tool into the server registry.
   */
  public registerTool(tool: MCPToolDefinition): void {
    this.tools.set(tool.name, tool);
    console.log(`[MCP Server] Tool registered successfully: "${tool.name}"`);
  }

  /**
   * Discovers and returns all tool metadata (schemas) for client consumption.
   */
  public listTools(): Array<{ name: string; description: string; inputSchema: object }> {
    const list: Array<{ name: string; description: string; inputSchema: object }> = [];
    for (const [name, tool] of this.tools.entries()) {
      list.push({
        name,
        description: tool.description,
        inputSchema: zodToJsonSchema(tool.inputSchema), // Conceptual serialization
      });
    }
    return list;
  }

  /**
   * Fetches a specific tool definition by name.
   */
  public getTool(name: string): MCPToolDefinition | undefined {
    return this.tools.get(name);
  }
}

/**
 * Helper to convert a Zod schema to a JSON schema representation for MCP metadata transmission.
 */
function zodToJsonSchema(schema: z.ZodTypeAny): object {
  // Simplified mock conversion for demonstration purposes
  return {
    type: "object",
    properties: {
      userId: { type: "string", description: "The unique identifier of the user" }
    },
    required: ["userId"],
  };
}

// ==========================================
// 2. Client-Side Agent Runtime & Validation
// ==========================================

/**
 * Simulates a SaaS LLM Client that discovers tools dynamically and validates inputs.
 */
class MCPSaaSClientAgent {
  private registry: MCPServerRegistry;

  constructor(registry: MCPServerRegistry) {
    this.registry = registry;
  }

  /**
   * Step 1: Dynamically discover available capabilities from the MCP server.
   */
  public discoverCapabilities(): void {
    console.log("\n[Client Agent] Querying MCP Server for available tools...");
    const availableTools = this.registry.listTools();
    console.log("[Client Agent] Discovered tools:", JSON.stringify(availableTools, null, 2));
  }

  /**
   * Step 2 & 3: Execute a tool safely by fetching its Zod schema and validating inputs at runtime.
   */
  public async executeToolCall(toolName: string, rawArguments: unknown): Promise<string> {
    console.log(`\n[Client Agent] Requesting execution payload for tool: "${toolName}"`);
    
    // Fetch tool definition dynamically
    const tool = this.registry.getTool(toolName);
    if (!tool) {
      throw new Error(`[Client Agent Error] Tool "${toolName}" not found in registry.`);
    }

    console.log(`[Client Agent] Validating arguments against Zod schema for "${toolName}"...`);
    
    // Strict runtime validation using Zod
    const validationResult = tool.inputSchema.safeParse(rawArguments);
    
    if (!validationResult.success) {
      // Prevent malformed agent execution by catching errors before network/function dispatch
      console.error(`[Client Agent Validation Error] Invalid arguments provided:`, validationResult.error.format());
      throw new Error(`Schema validation failed for tool ${toolName}: ${validationResult.error.message}`);
    }

    console.log(`[Client Agent] Validation passed. Executing tool handler securely...`);
    
    // Invoke handler with types safely enforced by Zod parsing output
    const result = await tool.handler(validationResult.data);
    return result;
  }
}

// ==========================================
// 3. Execution & Demonstration Pipeline
// ==========================================

async function runDemo() {
  // Initialize server registry
  const mcpServer = new MCPServerRegistry();

  // Define a SaaS customer support tool using Zod for strict schema validation
  const getUserProfileTool: MCPToolDefinition = {
    name: "get_user_profile",
    description: "Fetches subscription and account status for a given SaaS user ID.",
    inputSchema: z.object({
      userId: z.string().uuid({ message: "userId must be a valid UUID string." }),
    }),
    handler: async (args: { userId: string }) => {
      // Simulated database fetch
      return JSON.stringify({
        userId: args.userId,
        status: "active",
        plan: "Enterprise",
        email: "customer@saascompany.com",
      });
    },
  };

  // Register the tool on the server
  mcpServer.registerTool(getUserProfileTool);

  // Initialize the client agent
  const clientAgent = new MCPSaaSClientAgent(mcpServer);

  // 1. Discover tools dynamically
  clientAgent.discoverCapabilities();

  // 2. Test successful execution with a valid UUID
  try {
    const validArgs = { userId: "123e4567-e89b-12d3-a456-426614174000" };
    const response = await clientAgent.executeToolCall("get_user_profile", validArgs);
    console.log(`[Success Output] Tool Result:\n${response}`);
  } catch (error: any) {
    console.error(error.message);
  }

  // 3. Test failed execution with malformed arguments (preventing malformed agent execution)
  try {
    console.log("\n--------------------------------------------------");
    console.log("[Test Case] Attempting execution with malformed arguments...");
    const invalidArgs = { userId: "not-a-valid-uuid" };
    await clientAgent.executeToolCall("get_user_profile", invalidArgs);
  } catch (error: any) {
    console.error(`[Caught Expected Error]: ${error.message}`);
  }
}

// Execute the simulation
runDemo();
