/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { z } from "zod";
import { generateText, tool } from "ai";
import { openai } from "@ai-sdk/openai";

/**
 * Interface representing a dynamically discovered MCP tool mapped 
 * to a Vercel AI SDK compatible execution structure.
 */
interface ExecutableTool {
  description: string;
  parameters: z.ZodObject<any>;
  execute: (args: Record<string, any>) => Promise<any>;
}

/**
 * Converts a JSON Schema object received dynamically from an MCP server 
 * into a runtime-validated Zod schema.
 * 
 * @param jsonSchema - The raw JSON schema extracted from the MCP tool description.
 * @returns A fully validated Zod schema object matching the parameters.
 */
function jsonSchemaToZod(jsonSchema: Record<string, any>): z.ZodObject<any> {
  const shape: Record<string, z.ZodTypeAny> = {};
  const properties = jsonSchema.properties || {};
  const requiredFields = jsonSchema.required || [];

  for (const [key, value] of Object.entries<any>(properties)) {
    let zodField: z.ZodTypeAny;

    switch (value.type) {
      case "string":
        zodField = z.string();
        if (value.description) zodField = (zodField as z.ZodString).describe(value.description);
        break;
      case "number":
      case "integer":
        zodField = z.number();
        if (value.description) zodField = (zodField as z.ZodNumber).describe(value.description);
        break;
      case "boolean":
        zodField = z.boolean();
        if (value.description) zodField = (zodField as z.ZodBoolean).describe(value.description);
        break;
      case "array":
        zodField = z.array(z.string()); // Simplified array handling for brevity
        break;
      default:
        zodField = z.any();
    }

    // Apply optional or required constraints based on JSON Schema specifications
    if (!requiredFields.includes(key)) {
      zodField = zodField.optional();
    }

    shape[key] = zodField;
  }

  return z.object(shape);
}

/**
 * Main orchestration function initializing the MCP client, dynamically discovering
 * tools, converting their schemas, and executing an agentic workflow.
 * 
 * @param userPrompt - The natural language instruction provided by the SaaS user.
 */
export async function runDynamicAgentWorkflow(userPrompt: string): Promise<string> {
  // 1. Initialize the Stdio Transport for local or containerized MCP server communication
  const transport = new StdioClientTransport({
    command: "node",
    args: ["./dist/mcp-server.js"],
  });

  const mcpClient = new Client(
    { name: "SaaS-Agent-Client", version: "1.0.0" },
    { capabilities: {} }
  );

  try {
    // 2. Establish connection to the MCP Server
    await mcpClient.connect(transport);
    console.log("[MCP Client] Connected successfully to server.");

    // 3. Dynamically discover available tools from the server capabilities
    const listToolsResponse = await mcpClient.listTools();
    const dynamicTools: Record<string, any> = {};

    console.log(`[MCP Client] Discovered ${listToolsResponse.tools.length} tools dynamically.`);

    // 4. Iterate and transform each MCP tool into an AI SDK executable tool
    for (const mcpTool of listToolsResponse.tools) {
      const zodParameters = jsonSchemaToZod(mcpTool.inputSchema);

      dynamicTools[mcpTool.name] = tool({
        description: mcpTool.description || "No description provided.",
        parameters: zodParameters,
        execute: async (args: Record<string, any>) => {
          console.log(`[Runtime Execution] Invoking MCP Tool: '${mcpTool.name}' with args:`, args);
          
          // Execute the tool remotely via the MCP protocol layer
          const result = await mcpClient.callTool({
            name: mcpTool.name,
            arguments: args,
          });

          return result;
        },
      });
    }

    // 5. Invoke the LLM with the dynamically registered runtime tools
    const response = await generateText({
      model: openai("gpt-4o"),
      prompt: userPrompt,
      tools: dynamicTools,
      maxSteps: 5, // Allow multi-step tool execution loops
    });

    console.log("[Agent Workflow] Execution completed successfully.");
    return response.text;

  } catch (error) {
    console.error("[Agent Error] Failed during dynamic tool discovery or execution:", error);
    throw new Error(`Dynamic tool execution failed: ${(error as Error).message}`);
  } finally {
    // 6. Ensure clean disconnection of the underlying transport layer
    await mcpClient.close();
    console.log("[MCP Client] Connection closed safely.");
  }
}
