/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Custom Logger Interface
interface Logger {
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, meta?: Record<string, unknown>): void;
}

const consoleLogger: Logger = {
  warn: (msg, meta) => console.warn(`[WARN] ${msg}`, meta || ''),
  error: (msg, meta) => console.error(`[ERROR] ${msg}`, meta || ''),
};

export interface McpToolDefinition {
  name: string;
  description: string;
  inputSchema: {
    type: string;
    properties?: Record<string, any>;
    required?: string[];
    [key: string]: any;
  };
}

export interface McpClient {
  listTools(): Promise<{ tools: McpToolDefinition[] }>;
  callTool(name: string, args: unknown): Promise<any>;
}

export type RegisteredToolRegistry = Record<
  string,
  {
    schema: z.ZodTypeAny;
    execute: (args: unknown) => Promise<any>;
  }
>;

/**
 * Recursively converts a JSON Schema object into a Zod schema,
 * handling circular references via z.lazy().
 */
function jsonSchemaToZod(
  schema: any,
  visited = new Map<string, z.ZodTypeAny>(),
  logger: Logger = consoleLogger
): z.ZodTypeAny {
  if (!schema || typeof schema !== 'object') {
    return z.any();
  }

  // Handle circular references using a unique identifier (e.g., $id or reference object)
  const schemaId = schema.$id || schema.title;
  if (schemaId && visited.has(schemaId)) {
    return z.lazy(() => visited.get(schemaId)!);
  }

  let zodSchema: z.ZodTypeAny;

  switch (schema.type) {
    case 'string':
      zodSchema = z.string();
      if (schema.enum) {
        zodSchema = z.enum(schema.enum as [string, ...string[]]);
      }
      break;
    case 'number':
    case 'integer':
      zodSchema = z.number();
      break;
    case 'boolean':
      zodSchema = z.boolean();
      break;
    case 'array':
      zodSchema = z.array(
        schema.items ? jsonSchemaToZod(schema.items, visited, logger) : z.any()
      );
      break;
    case 'object': {
      const shape: Record<string, z.ZodTypeAny> = {};
      const properties = schema.properties || {};
      const requiredFields = new Set<string>(schema.required || []);

      // Temporary placeholder for circular safety if $id exists
      if (schemaId) {
        const lazyPlaceholder = z.lazy(() => zodSchema);
        visited.set(schemaId, lazyPlaceholder);
      }

      for (const [key, propSchema] of Object.entries(properties)) {
        let fieldSchema = jsonSchemaToZod(propSchema, visited, logger);
        if (!requiredFields.has(key)) {
          fieldSchema = fieldSchema.optional();
        }
        shape[key] = fieldSchema;
      }

      zodSchema = z.object(shape);
      break;
    }
    default:
      logger.warn(`Unsupported or missing JSON schema type: "${schema.type}". Falling back to z.any().`, { schema });
      zodSchema = z.any();
      break;
  }

  if (schemaId) {
    visited.set(schemaId, zodSchema);
  }

  return zodSchema;
}

/**
 * Synchronizes tools from an MCP server, generating validated Zod registries.
 */
export async function syncMcpTools(
  mcpClient: McpClient,
  logger: Logger = consoleLogger
): Promise<RegisteredToolRegistry> {
  const response = await mcpClient.listTools();
  const registry: RegisteredToolRegistry = {};

  for (const tool of response.tools) {
    try {
      const dynamicSchema = jsonSchemaToZod(tool.inputSchema, new Map(), logger);

      registry[tool.name] = {
        schema: dynamicSchema,
        execute: async (rawArgs: unknown) => {
          // Type-safe boundary validation
          const parseResult = dynamicSchema.safeParse(rawArgs);
          if (!parseResult.success) {
            logger.error(`Validation failed for tool: ${tool.name}`, {
              errors: parseResult.error.format(),
            });
            throw parseResult.error;
          }

          // Execute with validated data
          return await mcpClient.callTool(tool.name, parseResult.data);
        },
      };
    } catch (error) {
      logger.error(`Failed to initialize dynamic schema for tool: ${tool.name}`, { error });
    }
  }

  return registry;
}
