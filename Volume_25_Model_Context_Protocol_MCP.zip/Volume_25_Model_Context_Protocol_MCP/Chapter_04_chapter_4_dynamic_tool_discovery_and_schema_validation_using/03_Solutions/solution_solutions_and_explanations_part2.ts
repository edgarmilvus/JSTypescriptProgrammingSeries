/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z, ZodError } from 'zod';

export type Result<T, E> = 
  | { success: true; data: T } 
  | { success: false; error: E };

export interface ToolError {
  category: 'VALIDATION' | 'NETWORK' | 'TIMEOUT' | 'INTERNAL';
  message: string;
  details?: unknown;
}

export interface ResilienceOptions {
  retries?: number;
  baseDelayMs?: number;
  circuitBreakerThreshold?: number;
  circuitBreakerResetTimeMs?: number;
  fallbackExecutor?: (args: unknown) => Promise<any>;
}

enum CircuitState {
  CLOSED,
  OPEN,
  HALF_OPEN,
}

export function createResilientTool<TInput extends z.ZodTypeAny, TOutput>(
  toolName: string,
  schema: TInput,
  executor: (args: z.infer<TInput>) => Promise<TOutput>,
  options: ResilienceOptions = {}
) {
  const {
    retries = 3,
    baseDelayMs = 500,
    circuitBreakerThreshold = 5,
    circuitBreakerResetTimeMs = 60000,
    fallbackExecutor,
  } = options;

  let state = CircuitState.CLOSED;
  let consecutiveFailures = 0;
  let lastFailureTimestamp = 0;

  return async (args: unknown): Promise<Result<TOutput, ToolError>> => {
    // 1. Check Circuit Breaker State
    if (state === CircuitState.OPEN) {
      if (Date.now() - lastFailureTimestamp > circuitBreakerResetTimeMs) {
        state = CircuitState.HALF_OPEN;
      } else {
        if (fallbackExecutor) {
          try {
            const fallbackData = await fallbackExecutor(args);
            return { success: true, data: fallbackData };
          } catch (fbError) {
            return {
              success: false,
              category: 'INTERNAL',
              message: `Circuit breaker OPEN. Fallback also failed: ${(fbError as Error).message}`,
            } as any;
          }
        }
        return {
          success: false,
          error: {
            category: 'INTERNAL',
            message: `Circuit breaker is OPEN for tool "${toolName}". Execution blocked.`,
          },
        };
      }
    }

    // 2. Validate Inputs
    const validationResult = schema.safeParse(args);
    if (!validationResult.success) {
      const zodErr: ZodError = validationResult.error;
      const formattedIssues = zodErr.issues
        .map((i) => `Path [${i.path.join('.') > '' ? i.path.join('.') : 'root'}]: ${i.message}`)
        .join('; ');

      return {
        success: false,
        error: {
          category: 'VALIDATION',
          message: `Input validation failed for tool "${toolName}": ${formattedIssues}`,
          details: zodErr.format(),
        },
      };
    }

    // 3. Execute with Exponential Backoff & Jitter
    let attempt = 0;
    while (attempt <= retries) {
      try {
        const result = await executor(validationResult.data);

        // Reset circuit breaker on success
        if (state === CircuitState.HALF_OPEN || state === CircuitState.CLOSED) {
          state = CircuitState.CLOSED;
          consecutiveFailures = 0;
        }

        return { success: true, data: result };
      } catch (error: any) {
        attempt++;
        const isNetworkOrTimeout = 
          error.code === 'ETIMEDOUT' || 
          error.code === 'ECONNREFUSED' || 
          error.message?.includes('timeout');

        const errorCategory = isNetworkOrTimeout ? 'NETWORK' : 'INTERNAL';

        if (attempt > retries || !isNetworkOrTimeout) {
          consecutiveFailures++;
          lastFailureTimestamp = Date.now();

          if (consecutiveFailures >= circuitBreakerThreshold) {
            state = CircuitState.OPEN;
          }

          if (fallbackExecutor && state === CircuitState.OPEN) {
            try {
              const fallbackData = await fallbackExecutor(validationResult.data);
              return { success: true, data: fallbackData };
            } catch (fbErr) {
              // Fallback failed too
            }
          }

          return {
            success: false,
            error: {
              category: errorCategory,
              message: `Tool "${toolName}" failed after ${attempt} attempts: ${error.message}`,
              details: error,
            },
          };
        }

        // Exponential backoff with jitter
        const jitter = Math.random() * 200;
        const delay = baseDelayMs * Math.pow(2, attempt - 1) + jitter;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    return {
      success: false,
      error: { category: 'INTERNAL', message: 'Unexpected termination of execution loop.' },
    };
  };
}
