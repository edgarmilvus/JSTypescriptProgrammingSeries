/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

export interface ToolMetric {
  executionCount: number;
  successCount: number;
  failureCount: number;
  averageLatencyMs: number;
}

export interface McpDashboardTool {
  name: string;
  description: string;
  schema: z.ZodTypeAny;
  metrics: ToolMetric;
  execute: (args: unknown) => Promise<any>;
}

interface McpToolDashboardProps {
  tools: McpDashboardTool[];
}

export const McpToolDashboard: React.FC<McpToolDashboardProps> = ({ tools }) => {
  const [selectedToolName, setSelectedToolName] = useState<string>(tools[0]?.name || '');
  const [testPayload, setTestPayload] = useState<string>('{}');
  const [executionResult, setExecutionResult] = useState<string | null>(null);
  const [isError, setIsError] = useState<boolean>(false);

  const selectedTool = tools.find((t) => t.name === selectedToolName);

  const handleTestExecution = async () => {
    if (!selectedTool) return;
    try {
      let parsedJson: unknown;
      try {
        parsedJson = JSON.parse(testPayload);
      } catch (parseErr: any) {
        setIsError(true);
        setExecutionResult(JSON.stringify({ error: `Invalid JSON syntax: ${parseErr.message}` }, null, 2));
        return;
      }

      const startTime = performance.now();
      const result = await selectedTool.execute(parsedJson);
      const duration = performance.now() - startTime;

      setIsError(false);
      setExecutionResult(JSON.stringify({ latencyMs: Math.round(duration), result }, null, 2));
    } catch (err: any) {
      setIsError(true);
      setExecutionResult(
        JSON.stringify(
          {
            errorType: err instanceof z.ZodError ? 'ZodValidationFailure' : 'ExecutionError',
            details: err instanceof z.ZodError ? err.format() : err.message,
          },
          null,
          2
        )
      );
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans">
      {/* Sidebar: Tool List */}
      <div className="w-1/4 border-r border-gray-800 p-4 overflow-y-auto">
        <h2 className="text-xl font-bold mb-4 text-emerald-400">MCP Tool Inspector</h2>
        <ul className="space-y-2">
          {tools.map((tool) => (
            <li
              key={tool.name}
              onClick={() => {
                setSelectedToolName(tool.name);
                setExecutionResult(null);
              }}
              className={`p-3 rounded-lg cursor-pointer transition-colors ${
                selectedToolName === tool.name ? 'bg-emerald-600 text-white' : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <div className="font-semibold">{tool.name}</div>
              <div className="text-xs text-gray-400 truncate">{tool.description}</div>
            </li>
          ))}
        </ul>
      </div>

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col overflow-y-auto p-6 space-y-6">
        {selectedTool ? (
          <>
            {/* Metrics Header */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400">Total Executions</div>
                <div className="text-2xl font-bold">{selectedTool.metrics.executionCount}</div>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400">Success Rate</div>
                <div className="text-2xl font-bold text-emerald-400">
                  {selectedTool.metrics.executionCount > 0
                    ? `${Math.round((selectedTool.metrics.successCount / selectedTool.metrics.executionCount) * 100)}%`
                    : 'N/A'}
                </div>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400">Failure Rate</div>
                <div className="text-2xl font-bold text-rose-400">
                  {selectedTool.metrics.executionCount > 0
                    ? `${Math.round((selectedTool.metrics.failureCount / selectedTool.metrics.executionCount) * 100)}%`
                    : 'N/A'}
                </div>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="text-xs text-gray-400">Avg Latency</div>
                <div className="text-2xl font-bold">{Math.round(selectedTool.metrics.averageLatencyMs)} ms</div>
              </div>
            </div>

            {/* Sandbox & Schema View */}
            <div className="grid grid-cols-2 gap-6 flex-1">
              {/* Sandbox Input */}
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex flex-col">
                <h3 className="text-lg font-semibold mb-2 text-emerald-300">Test Sandbox</h3>
                <textarea
                  value={testPayload}
                  onChange={(e) => setTestPayload(e.target.value)}
                  className="flex-1 bg-gray-900 border border-gray-700 rounded p-3 font-mono text-sm text-emerald-200 focus:outline-none focus:border-emerald-500 resize-none"
                  placeholder="Enter JSON payload..."
                />
                <button
                  onClick={handleTestExecution}
                  className="mt-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 px-4 rounded transition-colors"
                >
                  Execute Tool
                </button>
              </div>

              {/* Execution Output */}
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex flex-col">
                <h3 className="text-lg font-semibold mb-2 text-gray-300">Execution Output & Validation</h3>
                <pre
                  className={`flex-1 bg-gray-900 border rounded p-3 font-mono text-xs overflow-auto ${
                    isError ? 'border-rose-500 text-rose-300' : 'border-gray-700 text-emerald-300'
                  }`}
                >
                  {executionResult || '// Results will appear here after execution...'}
                </pre>
              </div>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">Select a tool to inspect.</div>
        )}
      </div>
    </div>
  );
};
