/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Minimal definition matching Vercel AI SDK tool structure
export interface CoreTool<PARAMS extends z.ZodTypeAny = z.ZodTypeAny, RESULT = any> {
  description: string;
  parameters: PARAMS;
  execute: (args: z.infer<PARAMS>) => Promise<RESULT>;
}

export class McpAgentBridge<TTools extends Record<string, CoreTool>> {
  private tools: Partial<TTools> = {};

  /**
   * Registers a strongly typed tool with compile-time schema inference.
   */
  public registerTool<
    TName extends string,
    TSchema extends z.ZodTypeAny,
    TResult
  >(
    name: TName,
    description: string,
    schema: TSchema,
    handler: (args: z.infer<TSchema>) => Promise<TResult>
  ): void {
    const wrappedTool: CoreTool<TSchema, TResult> = {
      description,
      parameters: schema,
      execute: async (rawArgs: unknown) => {
        // Safe runtime validation protecting handler implementation
        const parsedArgs = await schema.parseAsync(rawArgs);
        return await handler(parsedArgs);
      },
    };

    this.tools = {
      ...this.tools,
      [name]: wrappedTool,
    };
  }

  /**
   * Exports registered tools directly into Vercel AI SDK compatible record format.
   */
  public exportToVercelAiTools(): Record<string, CoreTool> {
    return this.tools as Record<string, CoreTool>;
  }
}
