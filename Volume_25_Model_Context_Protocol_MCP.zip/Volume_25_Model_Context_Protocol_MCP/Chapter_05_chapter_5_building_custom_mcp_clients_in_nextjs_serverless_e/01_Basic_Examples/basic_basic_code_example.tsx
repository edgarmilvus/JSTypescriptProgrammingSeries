/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// ============================================================================
// FILE: app/dashboard/mcp-client/page.tsx
// ============================================================================
'use client';

import React, { useState, useEffect, useRef } from 'react';

/**
 * Interface representing a chat message in our SaaS tenant dashboard.
 */
interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  toolsUsed?: string[];
}

/**
 * SaaS Dashboard Component acting as the User Interface for the MCP Client.
 * Demonstrates streaming interactions and state management inside the browser.
 */
export default function MCPDashboardClient() {
  const [input, setInput] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the bottom of the chat window on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  /**
   * Handles submission of user prompts to the Next.js Serverless MCP Client API.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Dispatch request to our Next.js API Route which encapsulates the MCP client logic
      const response = await fetch('/api/mcp-agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMessage.content }),
      });

      if (!response.ok) {
        throw new Error(`Serverless MCP Gateway error: ${response.statusText}`);
      }

      // Read the ReadableStream returned by the Edge Runtime API Route
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      
      if (!reader) throw new Error('ReadableStream not supported on response.');

      let assistantMessage: Message = { role: 'assistant', content: '', toolsUsed: [] };
      setMessages((prev) => [...prev, assistantMessage]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        
        // Parse custom streaming chunks (simplified for example: text or tool markers)
        assistantMessage.content += chunk;
        
        setMessages((prev) => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1] = { ...assistantMessage };
          return newMessages;
        });
      }
    } catch (error: any) {
      console.error('Failed to communicate with MCP client route:', error);
      setMessages((prev) => [
        ...prev,
        { role: 'system', content: `Error: ${error.message || 'Unknown error occurred.'}` },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto p-4 bg-slate-900 text-slate-100">
      <header className="mb-4 border-b border-slate-700 pb-2">
        <h1 className="text-2xl font-bold">Enterprise SaaS MCP Client Console</h1>
        <p className="text-sm text-slate-400">Powered by Model Context Protocol & Next.js Serverless Engines</p>
      </header>

      {/* Chat History Viewport */}
      <div className="flex-1 overflow-y-auto space-y-4 p-4 bg-slate-950 rounded-lg border border-slate-800">
        {messages.length === 0 && (
          <div className="text-center text-slate-500 mt-20">
            <p>Ask a question about your cloud resources, database metrics, or system logs.</p>
          </div>
        )}
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${
              msg.role === 'user' ? 'items-end' : msg.role === 'system' ? 'items-center' : 'items-start'
            }`}
          >
            <div
              className={`max-w-[80%] rounded-xl p-3 text-sm ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : msg.role === 'system'
                  ? 'bg-red-900/50 text-red-200 border border-red-700'
                  : 'bg-slate-800 text-slate-200 border border-slate-700'
              }`}
            >
              <div className="font-semibold text-xs opacity-75 mb-1 uppercase tracking-wider">
                {msg.role}
              </div>
              <div className="whitespace-pre-wrap">{msg.content}</div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g., 'List all active tenant databases and check their storage usage'"
          disabled={isLoading}
          className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:border-blue-500 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
        >
          {isLoading ? 'Executing...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
