/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// FILE: app/api/mcp-agent/route.ts
// ============================================================================

import { NextRequest } from 'next/server';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';
import { z } from 'zod';

// Force Edge Runtime for low latency streaming and serverless execution
export const runtime = 'edge';

/**
 * Zod schema validating the incoming request payload from the client component.
 */
const RequestSchema = z.object({
  prompt: z.string().min(1, 'Prompt cannot be empty').max(2000, 'Prompt exceeds maximum length'),
});

/**
 * Next.js API Route acting as an MCP Client and Serverless Agent Gateway.
 * Establishes an ephemeral or persistent connection to an MCP server, queries tools,
 * and streams LLM output back to the browser.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Parse and validate incoming JSON body
    const body = await req.json();
    const validationResult = RequestSchema.safeParse(body);

    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid request payload', details: validationResult.error.format() }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const { prompt } = validationResult.data;

    // 2. Initialize the MCP Client instance
    // Note: In serverless environments, connection reuse strategies or per-request
    // initialization must be balanced against execution time limits.
    const mcpClient = new Client(
      {
        name: 'enterprise-saas-nextjs-client',
        version: '1.0.0',
      },
      {
        capabilities: {
          prompts: {},
          resources: {},
          tools: {},
        },
      }
    );

    // 3. Configure the Transport Layer (Connecting to a remote or sidecar MCP server via SSE)
    // In production, this URL would point to a secure internal cluster service or managed MCP container.
    const mcpServerUrl = process.env.MCP_SERVER_SSE_URL || 'http://localhost:3001/sse';
    const transport = new SSEClientTransport(new URL(mcpServerUrl));

    // 4. Establish connection between MCP Client and MCP Server
    await mcpClient.connect(transport);

    // 5. Discover available tools exposed by the MCP Server
    const toolsListResponse = await mcpClient.listTools();
    const availableTools = toolsListResponse.tools;

    // 6. Setup a ReadableStream to stream tokens back to the Next.js Client Component
    const encoder = new TextDecoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Send system notification chunk regarding discovered tools
          const toolNames = availableTools.map((t) => t.name).join(', ');
          controller.enqueue(
            new TextEncoder().encode(`[System: Connected to MCP Server. Available tools: ${toolNames}]\n\n`)
          );

          // Simulated agent decision loop: Evaluate prompt against available MCP tools
          // In a full production implementation, you would pass these tools to an LLM provider 
          // (e.g., Anthropic Claude, OpenAI) using tool use schemas.
          
          if (prompt.toLowerCase().includes('database') || prompt.toLowerCase().includes('storage')) {
            controller.enqueue(
              new TextEncoder().encode(`[System: Invoking MCP tool 'query_tenant_database'...]\n\n`)
            );

            // Execute tool on the remote MCP Server
            const toolResult = await mcpClient.callTool({
              name: 'query_tenant_database',
              arguments: { query: prompt },
            });

            // Extract text content from the MCP tool call result structure
            const contentBlock = toolResult.content as Array<{ type: string; text?: string }>;
            const textOutput = contentBlock
              .filter((c) => c.type === 'text')
              .map((c) => c.text)
              .join('\n');

            controller.enqueue(new TextEncoder().encode(textOutput));
          } else {
            // Fallback response simulating standard LLM generation
            controller.enqueue(
              new TextEncoder().encode(
                `Hello! I received your prompt: "${prompt}". I am your SaaS AI assistant connected via the Model Context Protocol. Ask me about your databases or system metrics to leverage advanced MCP server tools.`
              )
            );
          }
        } catch (toolError: any) {
          controller.enqueue(
            new TextEncoder().encode(`\n[Error executing MCP operation: ${toolError.message}]`)
          );
        } finally {
          // 7. Ensure clean disconnection of the transport layer to prevent socket leaks
          await mcpClient.close();
          controller.close();
        }
      },
    });

    // Return the stream with appropriate headers for chunked transfer encoding
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
      },
    });
  } catch (error: any) {
    console.error('Serverless MCP Route Fatal Error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal Server Error', message: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
