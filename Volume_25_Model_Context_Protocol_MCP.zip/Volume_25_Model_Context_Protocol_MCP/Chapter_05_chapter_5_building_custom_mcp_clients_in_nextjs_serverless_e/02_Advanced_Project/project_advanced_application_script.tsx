/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// FILE: app/components/McpChatWorkspace.tsx
// ============================================================================
"use client";

import React, { useState } from "react";
import { useChat } from "@ai-sdk/react";

/**
 * Interface representing a dynamically discovered tool from the remote MCP server.
 */
interface McpToolMetadata {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
}

/**
 * McpChatWorkspace: A Client Component (CC) that serves as the primary UI workspace
 * for interacting with an LLM augmented by remote Model Context Protocol (MCP) servers.
 * It manages chat state via the Vercel AI SDK `useChat` hook and displays active MCP tools.
 */
export default function McpChatWorkspace() {
  // Local state to store tools discovered via the MCP proxy route
  const [mcpTools, setMcpTools] = useState<McpToolMetadata[]>([]);
  const [isDiscovering, setIsDiscovering] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Initialize the Vercel AI SDK useChat hook for real-time streaming conversations
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/mcp-agent",
    onError: (err) => {
      setErrorBanner(`Chat Execution Error: ${err.message}`);
    },
  });

  /**
   * Triggers a metadata fetch from the Next.js MCP proxy route to discover
   * available tools exposed by the remote SSE-backed MCP server.
   */
  const handleDiscoverTools = async () => {
    setIsDiscovering(true);
    setErrorBanner(null);
    try {
      const response = await fetch("/api/mcp-agent?action=discover");
      if (!response.ok) {
        throw new Error(`Failed to fetch MCP tools: ${response.statusText}`);
      }
      const data = await response.json();
      setMcpTools(data.tools || []);
    } catch (err: any) {
      setErrorBanner(err.message || "Unknown error during tool discovery.");
    } finally {
      setIsDiscovering(false);
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto p-4 bg-slate-950 text-slate-100 font-sans">
      {/* Header & Tool Discovery Bar */}
      <header className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Enterprise MCP Workspace</h1>
          <p className="text-xs text-slate-400">Next.js App Router + Serverless SSE MCP Client</p>
        </div>
        <button
          onClick={handleDiscoverTools}
          disabled={isDiscovering}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900 text-sm font-medium rounded-md transition-colors"
        >
          {isDiscovering ? "Discovering Tools..." : "Refresh MCP Tools"}
        </button>
      </header>

      {/* Error Notification Banner */}
      {errorBanner && (
        <div className="mb-4 p-3 bg-red-950 border border-red-800 text-red-200 text-sm rounded-md">
          {errorBanner}
        </div>
      )}

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 flex-1 overflow-hidden">
        {/* Sidebar: Discovered MCP Tools */}
        <aside className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-lg p-4 overflow-y-auto">
          <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
            Active MCP Tools ({mcpTools.length})
          </h2>
          {mcpTools.length === 0 ? (
            <p className="text-xs text-slate-500 italic">
              No tools loaded. Click &quot;Refresh MCP Tools&quot; to query the MCP server.
            </p>
          ) : (
            <ul className="space-y-3">
              {mcpTools.map((tool) => (
                <li key={tool.name} className="p-2.5 bg-slate-950 border border-slate-800 rounded">
                  <div className="text-xs font-mono font-bold text-indigo-400">{tool.name}</div>
                  <div className="text-xs text-slate-400 mt-1 line-clamp-2">{tool.description}</div>
                </li>
              ))}
            </ul>
          )}
        </aside>

        {/* Chat Interface Panel */}
        <section className="lg:col-span-3 flex flex-col bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          {/* Message History Feed */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500">
                <p className="text-sm">Start a conversation to invoke secure serverless MCP tools.</p>
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}
                >
                  <span className="text-[10px] uppercase font-semibold text-slate-500 mb-1">
                    {m.role}
                  </span>
                  <div
                    className={`max-w-[80%] p-3 rounded-lg text-sm ${
                      m.role === "user"
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-800 text-slate-200 border border-slate-700"
                    }`}
                  >
                    {m.content}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="text-xs text-slate-400 italic animate-pulse">
                AI Agent is processing and consulting MCP tools...
              </div>
            )}
          </div>

          {/* Chat Input Form */}
          <form onSubmit={handleSubmit} className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Ask a question or request a database query..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-900 text-sm font-medium rounded-md transition-colors"
            >
              Send
            </button>
          </form>
        </section>
      </div>
    </div>
  );
}
