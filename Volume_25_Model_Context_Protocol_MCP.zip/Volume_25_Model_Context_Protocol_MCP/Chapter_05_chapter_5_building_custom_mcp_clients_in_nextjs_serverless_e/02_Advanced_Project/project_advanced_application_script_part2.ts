/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// FILE: app/api/mcp-agent/route.ts
// ============================================================================
import { NextRequest, NextResponse } from "next/server";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { SSEClientTransport } from "@modelcontextprotocol/sdk/client/sse.js";
import { generateText, tool } from "ai";
import { openai } from "@ai-sdk/openai";
import { z } from "zod";

// Ensure this route runs on Node.js runtime to support standard networking primitives for SSE
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Helper factory to establish a temporary connection to a remote SSE-backed MCP server,
 * execute an operation, and cleanly close the connection to respect serverless constraints.
 */
async function withMcpClient<T>(
  serverUrl: string,
  operation: (client: Client) => Promise<T>
): Promise<T> {
  // Initialize the SSE transport pointing to the remote MCP server endpoint
  const transport = new SSEClientTransport(new URL(serverUrl));
  
  // Initialize the base Model Context Protocol Client
  const mcpClient = new Client(
    {
      name: "nextjs-serverless-mcp-client",
      version: "1.0.0",
    },
    {
      capabilities: {},
    }
  );

  try {
    // Connect the client over Server-Sent Events
    await mcpClient.connect(transport);
    // Execute the caller's closure passing the active client instance
    return await operation(mcpClient);
  } finally {
    // Ensure transport and underlying sockets are closed to prevent memory leaks in serverless functions
    try {
      await transport.close();
    } catch {
      // Swallow cleanup errors during teardown
    }
  }
}

/**
 * GET Handler: Discovers tools available on the remote SSE MCP server.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");
  const mcpServerUrl = process.env.MCP_SERVER_SSE_URL || "http://localhost:4000/sse";

  if (action === "discover") {
    try {
      const toolsMetadata = await withMcpClient(mcpServerUrl, async (client) => {
        const response = await client.listTools();
        return response.tools;
      });

      return NextResponse.json({ success: true, tools: toolsMetadata });
    } catch (error: any) {
      console.error("[MCP_DISCOVERY_ERROR]", error);
      return NextResponse.json(
        { success: false, error: error.message || "Failed to list tools from MCP server" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ error: "Invalid action parameter" }, { status: 400 });
}

/**
 * POST Handler: Orchestrates LLM execution via Vercel AI SDK, dynamically binding
 * remote MCP tools to the execution context.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages } = body;
    const mcpServerUrl = process.env.MCP_SERVER_SSE_URL || "http://localhost:4000/sse";

    // 1. Discover tools dynamically from the remote MCP server within a ephemeral connection
    const remoteTools = await withMcpClient(mcpServerUrl, async (client) => {
      const res = await client.listTools();
      return res.tools;
    });

    // 2. Map remote MCP tools into Vercel AI SDK compatible tool definitions
    const executableTools: Record<string, any> = {};

    for (const t of remoteTools) {
      // Construct dynamic Zod schema from JSON schema input properties
      const shape: Record<string, any> = {};
      const properties = (t.inputSchema?.properties as Record<string, any>) || {};

      for (const [propName, propVal] of Object.entries(properties)) {
        shape[propName] = z.string().describe(propVal.description || "Parameter");
      }

      executableTools[t.name] = tool({
        description: t.description || "Remote MCP Tool",
        parameters: z.object(shape),
        execute: async (args) => {
          // Re-establish connection to execute the tool call on the remote MCP server
          return await withMcpClient(mcpServerUrl, async (client) => {
            const toolResult = await client.callTool({
              name: t.name,
              arguments: args,
            });
            return toolResult;
          });
        },
      });
    }

    // 3. Execute generateText with the model and bound MCP tools
    const result = await generateText({
      model: openai("gpt-4o"),
      messages,
      tools: executableTools,
      maxSteps: 5, // Allow multi-step tool execution loops
      system: "You are an advanced enterprise AI agent equipped with remote Model Context Protocol (MCP) tools. Use them whenever necessary to fulfill user requests.",
    });

    return NextResponse.json({
      role: "assistant",
      content: result.text,
      toolCalls: result.toolCalls,
    });
  } catch (error: any) {
    console.error("[MCP_AGENT_EXECUTION_ERROR]", error);
    return NextResponse.json(
      { error: error.message || "Internal server error during agent execution." },
      { status: 500 }
    );
  }
}
