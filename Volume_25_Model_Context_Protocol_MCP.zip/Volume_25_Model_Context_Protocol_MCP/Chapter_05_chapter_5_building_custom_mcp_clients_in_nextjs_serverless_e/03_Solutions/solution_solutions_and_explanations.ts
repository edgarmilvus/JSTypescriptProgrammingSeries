/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/mcp/sse/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// Zod schema for validating incoming JSON-RPC payloads
const JsonRpcRequestSchema = z.object({
  jsonrpc: z.literal('2.0'),
  method: z.string(),
  params: z.any().optional(),
  id: z.union([z.string(), z.number()]),
});

// In-memory or external store mock for active sessions
// In production, replace this with @upstash/redis or a persistent key-value store
const activeSessions = new Map<string, { controller: ReadableStreamDefaultController; lastActive: number }>();

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get('sessionId') || crypto.randomUUID();

  const stream = new ReadableStream({
    start(controller) {
      // Store session controller for broadcasting/messaging
      activeSessions.set(sessionId, { controller, lastActive: Date.now() });

      // Send initial connection handshake event
      const initPayload = JSON.stringify({ type: 'connected', sessionId });
      controller.enqueue(new TextEncoder().encode(`data: ${initPayload}\n\n`));

      // Handle client disconnect via abort signal
      req.signal.addEventListener('abort', () => {
        activeSessions.delete(sessionId);
        try {
          controller.close();
        } catch {
          // Stream might already be closed
        }
      });
    },
    cancel() {
      activeSessions.delete(sessionId);
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const sessionId = req.nextUrl.searchParams.get('sessionId');

    if (!sessionId || !activeSessions.has(sessionId)) {
      return NextResponse.json({ error: 'Invalid or missing session ID' }, { status: 400 });
    }

    // Validate payload against JSON-RPC spec using Zod
    const validationResult = JsonRpcRequestSchema.safeParse(body);
    if (!validationResult.success) {
      return NextResponse.json({ error: 'Invalid JSON-RPC payload', details: validationResult.error.format() }, { status: 422 });
    }

    const jsonRpcRequest = validationResult.data;

    // Forward message to MCP Server transport bridge (simulated execution here)
    const session = activeSessions.get(sessionId)!;
    
    // Process JSON-RPC method (e.g., calling MCP tools)
    const responsePayload = JSON.stringify({
      jsonrpc: '2.0',
      id: jsonRpcRequest.id,
      result: { status: 'executed', method: jsonRpcRequest.method }
    });

    // Push execution output down the SSE stream
    session.controller.enqueue(new TextEncoder().encode(`data: ${responsePayload}\n\n`));

    return NextResponse.json({ status: 'dispatched', id: jsonRpcRequest.id });
  } catch (error) {
    return NextResponse.json({ error: 'Internal Server Error', details: (error as Error).message }, { status: 500 });
  }
}
