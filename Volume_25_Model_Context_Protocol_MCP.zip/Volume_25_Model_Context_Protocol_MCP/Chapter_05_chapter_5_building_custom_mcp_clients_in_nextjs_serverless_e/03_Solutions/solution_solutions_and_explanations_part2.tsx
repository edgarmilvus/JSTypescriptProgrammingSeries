/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/mcp-tool-execution-stream.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { z } from 'zod';

const ToolExecutionSchema = z.object({
  id: z.string(),
  toolName: z.string(),
  status: z.enum(['pending', 'executing', 'success', 'error']),
  arguments: z.record(z.any()),
  output: z.any().optional(),
  error: z.string().optional(),
});

type ToolExecution = z.infer<typeof ToolExecutionSchema>;

interface MCPToolExecutionProps {
  endpoint: string;
  sessionId: string;
}

export const MCPToolExecutionStream: React.FC<MCPToolExecutionProps> = ({ endpoint, sessionId }) => {
  const [executions, setExecutions] = useState<ToolExecution[]>([]);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');

  useEffect(() => {
    const eventSource = new EventSource(`${endpoint}?sessionId=${sessionId}`);

    eventSource.onopen = () => setConnectionStatus('connected');
    eventSource.onerror = () => setConnectionStatus('disconnected');

    eventSource.onmessage = (event) => {
      if (isPaused) return;
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'connected') return;

        // Parse and validate incoming tool execution state chunk
        const parsed = ToolExecutionSchema.safeParse(data);
        if (parsed.success) {
          setExecutions((prev) => {
            const index = prev.findIndex((item) => item.id === parsed.data.id);
            if (index !== -1) {
              const updated = [...prev];
              updated[index] = parsed.data;
              return updated;
            }
            return [...prev, parsed.data];
          });
        }
      } catch (err) {
        console.error('Failed to parse SSE chunk:', err);
      }
    };

    return () => {
      eventSource.close();
    };
  }, [endpoint, sessionId, isPaused]);

  const handleRetry = async (execution: ToolExecution) => {
    try {
      await fetch(`${endpoint}?sessionId=${sessionId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: `tools/call/${execution.toolName}`,
          params: execution.arguments,
          id: crypto.randomUUID(),
        }),
      });
    } catch (err) {
      console.error('Retry dispatch failed:', err);
    }
  };

  return (
    <div className="p-4 border rounded-lg shadow-sm bg-slate-900 text-slate-100 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">MCP Agent & Tool Stream</h3>
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${connectionStatus === 'connected' ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-xs uppercase tracking-wider">{connectionStatus}</span>
          <button 
            onClick={() => setIsPaused(!isPaused)}
            className="ml-4 px-3 py-1 text-xs bg-slate-700 hover:bg-slate-600 rounded transition"
          >
            {isPaused ? 'Resume Stream' : 'Pause Stream'}
          </button>
        </div>
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
        {executions.map((ex) => (
          <div key={ex.id} className="p-3 bg-slate-800 rounded border border-slate-700 text-sm">
            <div className="flex justify-between font-mono text-xs text-slate-400">
              <span>Tool: {ex.toolName}</span>
              <span className={`uppercase font-bold ${ex.status === 'success' ? 'text-green-400' : ex.status === 'error' ? 'text-red-400' : 'text-yellow-400'}`}>
                {ex.status}
              </span>
            </div>
            <div className="mt-2">
              <span className="text-xs text-slate-500 block">Arguments:</span>
              <pre className="bg-slate-950 p-2 rounded text-xs overflow-x-auto">{JSON.stringify(ex.arguments, null, 2)}</pre>
            </div>
            {ex.output && (
              <div className="mt-2">
                <span className="text-xs text-slate-500 block">Output:</span>
                <pre className="bg-slate-950 p-2 rounded text-xs overflow-x-auto">{JSON.stringify(ex.output, null, 2)}</pre>
              </div>
            )}
            {ex.status === 'error' && (
              <div className="mt-3 flex justify-between items-center">
                <span className="text-xs text-red-400">{ex.error}</span>
                <button 
                  onClick={() => handleRetry(ex)}
                  className="px-2 py-1 bg-red-600 hover:bg-red-500 text-xs rounded font-semibold text-white"
                >
                  Retry Execution
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
