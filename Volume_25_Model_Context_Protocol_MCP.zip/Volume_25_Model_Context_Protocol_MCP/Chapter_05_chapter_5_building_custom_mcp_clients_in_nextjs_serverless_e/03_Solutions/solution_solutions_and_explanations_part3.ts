/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// lib/agents/supervisor.ts
import { z } from 'zod';
import OpenAI from 'openai';

export const SupervisorDecisionSchema = z.object({
  nextAgent: z.enum(['filesystem_worker', 'browser_worker', 'terminal_worker', 'FINISH']),
  reasoning: z.string().min(10, "Supervisor must provide detailed routing rationale."),
  toolArguments: z.record(z.any()).optional(),
});

export type SupervisorDecision = z.infer<typeof SupervisorDecisionSchema>;

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function evaluateGraphState(stateSnapshot: unknown): Promise<SupervisorDecision> {
  const prompt = `
    Analyze the current graph execution state and decide the next agent or finish the task.
    Current State: ${JSON.stringify(stateSnapshot, null, 2)}
    
    Available Workers: filesystem_worker, browser_worker, terminal_worker, FINISH.
    You must respond with a JSON object matching the required schema.
  `;

  let retries = 3;
  while (retries > 0) {
    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'system', content: 'You are an advanced agent supervisor routing tasks.' }, { role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
      });

      const content = response.choices[0].message.content;
      if (!content) throw new Error("Empty model response received.");

      const rawJson = JSON.parse(content);
      const validationResult = SupervisorDecisionSchema.safeParse(rawJson);

      if (validationResult.success) {
        return validationResult.data;
      }

      retries--;
    } catch (err) {
      retries--;
      if (retries === 0) {
        throw new Error(`Supervisor evaluation failed after multiple retries: ${(err as Error).message}`);
      }
    }
  }

  throw new Error("Failed to produce valid supervisor decision.");
}

export async function dispatchWorker(decision: SupervisorDecision): Promise<unknown> {
  switch (decision.nextAgent) {
    case 'filesystem_worker':
      // Invoke MCP FileSystem client transport
      return { status: 'dispatched', worker: 'filesystem', args: decision.toolArguments };
    case 'browser_worker':
      // Invoke MCP Browser automation client transport
      return { status: 'dispatched', worker: 'browser', args: decision.toolArguments };
    case 'terminal_worker':
      // Invoke MCP Shell execution client transport
      return { status: 'dispatched', worker: 'terminal', args: decision.toolArguments };
    case 'FINISH':
      return { status: 'completed' };
    default:
      throw new Error(`Unknown target agent: ${decision.nextAgent}`);
  }
}
