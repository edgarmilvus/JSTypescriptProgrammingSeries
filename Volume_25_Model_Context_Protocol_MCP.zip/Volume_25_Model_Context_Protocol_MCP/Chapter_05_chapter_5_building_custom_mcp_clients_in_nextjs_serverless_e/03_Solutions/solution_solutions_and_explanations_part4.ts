/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// lib/mcp/lifecycle-manager.ts
import { Client } from '@modelcontextprotocol/sdk/client/index.js';

export interface ManagerOptions {
  heartbeatIntervalMs: number;
  maxRetries: number;
  backoffFactor: number;
}

export class MCPLifecycleManager {
  private client: Client | null = null;
  private isConnected: boolean = false;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private retryCount: number = 0;

  constructor(private options: ManagerOptions, private clientFactory: () => Promise<Client>) {}

  public async connectWithRetry(): Promise<void> {
    while (this.retryCount < this.options.maxRetries) {
      try {
        this.client = await this.clientFactory();
        this.isConnected = true;
        this.retryCount = 0; // Reset counter on success
        this.startHeartbeat();
        return;
      } catch (error) {
        this.retryCount++;
        this.isConnected = false;
        
        if (this.retryCount >= this.options.maxRetries) {
          throw new Error(`Max retries exceeded (${this.options.maxRetries}). Connection failed: ${(error as Error).message}`);
        }

        const delay = Math.pow(this.options.backoffFactor, this.retryCount) * 1000;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  private startHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);

    this.heartbeatTimer = setInterval(async () => {
      if (!this.isConnected || !this.client) return;

      try {
        // Send lightweight ping/inspection request over MCP
        // Assuming client implements standard ping or resource listing for health
        await this.client.listResources();
      } catch (error) {
        this.handleDisconnection(error as Error);
      }
    }, this.options.heartbeatIntervalMs);
  }

  public async handleDisconnection(error: Error): Promise<void> {
    this.isConnected = false;
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);

    // Snapshot critical state memory before container or pipe drop
    await this.serializeStateSnapshot({ error: error.message, timestamp: Date.now() });

    try {
      await this.connectWithRetry();
    } catch (reconnectError) {
      console.error('Lifecycle recovery failed to reconnect:', reconnectError);
    }
  }

  private async serializeStateSnapshot(snapshotData: unknown): Promise<void> {
    // Persist memory context to Redis or PostgreSQL to maintain execution continuity
    // e.g., await redis.set('mcp:snapshot:latest', JSON.stringify(snapshotData));
    console.warn('State snapshot serialized due to connection loss:', snapshotData);
  }
}
