/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file computer-use-agent.ts
 * @description A foundational, self-contained TypeScript example demonstrating a vision-driven 
 * computer use agent execution loop within a SaaS web automation context.
 */

import { chromium, Page, Browser } from 'playwright';

// ============================================================================
// Types & Interfaces
// ============================================================================

/**
 * Represents the bounding box or target coordinate for an action.
 */
interface Coordinates {
  x: number;
  y: number;
}

/**
 * Represents a discrete action commanded by the vision-driven agent.
 */
type AgentAction = 
  | { type: 'click'; coordinates: Coordinates; description: string }
  | { type: 'type'; text: string; description: string }
  | { type: 'wait'; durationMs: number; description: string }
  | { type: 'terminate'; reason: string };

/**
 * Represents the contextual state passed to the multimodal reasoning engine.
 */
interface AgentObservation {
  screenshotBuffer: Buffer;
  url: string;
  domSummary: string;
  stepCount: number;
}

// ============================================================================
// Mock Multimodal LLM Reasoning Engine
// ============================================================================

/**
 * Simulates a multimodal LLM call (e.g., GPT-4o or Claude 3.5 Sonnet) that accepts 
 * a visual buffer and DOM state, returning the next structured agent action.
 * 
 * @param observation The current state of the browser.
 * @returns Promise<AgentAction> The next deterministic action for the loop.
 */
async function mockMultimodalReasoningEngine(observation: AgentObservation): Promise<AgentAction> {
  console.log(`[LLM Engine] Analyzing step ${observation.stepCount} at URL: ${observation.url}...`);
  
  // In a real-world system, observation.screenshotBuffer is sent via base64 encoding 
  // to an API endpoint alongside prompt instructions. Here, we simulate progression.
  await new Promise((resolve) => setTimeout(resolve, 1000));

  if (observation.stepCount === 1) {
    return {
      type: 'click',
      coordinates: { x: 150, y: 250 },
      description: 'Clicking the SaaS Dashboard "Start Onboarding" button.'
    };
  } else if (observation.stepCount === 2) {
    return {
      type: 'type',
      text: 'enterprise-client-alpha',
      description: 'Typing the organization name into the input field.'
    };
  } else {
    return {
      type: 'terminate',
      reason: 'Onboarding flow successfully completed based on visual confirmation.'
    };
  }
}

// ============================================================================
// Agent Core Execution Loop
// ============================================================================

/**
 * Executes the core vision-driven control loop, bridging Playwright automation 
 * with multimodal decision-making.
 */
async function runComputerUseAgent(): Promise<void> {
  console.log('[Agent Init] Launching headless browser instance...');
  
  const browser: Browser = await chromium.launch({ 
    headless: false, // Set to true for production headless runs
    slowMo: 100      // Slows down actions for visual debugging
  });

  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 }
  });

  const page: Page = await context.newPage();

  try {
    // Navigate to our target SaaS application page
    console.log('[Navigation] Navigating to target SaaS application...');
    await page.goto('https://example.com/saas-dashboard', { waitUntil: 'networkidle' });

    let stepCount = 0;
    const maxSteps = 5;
    let keepRunning = true;

    while (keepRunning && stepCount < maxSteps) {
      stepCount++;
      console.log(`\n----------------------------------------`);
      console.log(`[Control Loop] Starting Iteration: ${stepCount}`);

      // 1. Capture Vision State (Screenshot)
      const screenshotBuffer = await page.screenshot({ 
        fullPage: false,
        type: 'png' 
      });

      // 2. Capture Environmental State (URL & simplified DOM context)
      const currentUrl = page.url();
      const domSummary = await page.evaluate(() => document.body.innerText.slice(0, 500));

      const observation: AgentObservation = {
        screenshotBuffer,
        url: currentUrl,
        domSummary,
        stepCount
      };

      // 3. Query the Multimodal Reasoning Engine
      const nextAction: AgentAction = await mockMultimodalReasoningEngine(observation);
      console.log(`[Agent Decision] Action chosen: ${nextAction.type} - "${nextAction.description}"`);

      // 4. Execute Action via OS/Browser Primitives
      switch (nextAction.type) {
        case 'click':
          console.log(`[Executor] Moving mouse to (${nextAction.coordinates.x}, ${nextAction.coordinates.y}) and clicking.`);
          await page.mouse.click(nextAction.coordinates.x, nextAction.coordinates.y);
          break;

        case 'type':
          console.log(`[Executor] Typing text into focused element: "${nextAction.text}"`);
          await page.keyboard.type(nextAction.text, { delay: 50 });
          break;

        case 'wait':
          console.log(`[Executor] Waiting for ${nextAction.durationMs}ms...`);
          await page.newTimeout(nextAction.durationMs);
          break;

        case 'terminate':
          console.log(`[Executor] Agent requested termination. Reason: ${nextAction.reason}`);
          keepRunning = false;
          break;
        
        default:
          const exhaustiveCheck: never = nextAction;
          throw new Error(`Unhandled action type: ${JSON.stringify(exhaustiveCheck)}`);
      }

      // Allow DOM to settle post-action
      await page.waitForTimeout(1500);
    }

    console.log('\n[Agent Loop] Session completed successfully.');

  } catch (error) {
    console.error('[Agent Error] An unhandled exception occurred during execution:', error);
  } finally {
    console.log('[Cleanup] Closing browser instance...');
    await browser.close();
  }
}

// Execute the agent if this script is run directly
if (require.main === module) {
  runComputerUseAgent();
}
