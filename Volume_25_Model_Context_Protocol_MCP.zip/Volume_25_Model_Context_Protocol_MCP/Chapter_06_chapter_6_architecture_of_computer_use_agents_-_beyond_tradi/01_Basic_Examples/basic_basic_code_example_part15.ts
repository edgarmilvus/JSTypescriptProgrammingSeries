/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part15.ts
// Description: Basic Code Example
// ==========================================

      switch (nextAction.type) {
        case 'click':
          console.log(`[Executor] Moving mouse to (${nextAction.coordinates.x}, ${nextAction.coordinates.y}) and clicking.`);
          await page.mouse.click(nextAction.coordinates.x, nextAction.coordinates.y);
          break;

        case 'type':
          console.log(`[Executor] Typing text into focused element: "${nextAction.text}"`);
          await page.keyboard.type(nextAction.text, { delay: 50 });
          break;

        case 'wait':
          console.log(`[Executor] Waiting for ${nextAction.durationMs}ms...`);
          await page.newTimeout(nextAction.durationMs);
          break;

        case 'terminate':
          console.log(`[Executor] Agent requested termination. Reason: ${nextAction.reason}`);
          keepRunning = false;
          break;
        
        default:
          const exhaustiveCheck: never = nextAction;
          throw new Error(`Unhandled action type: ${JSON.stringify(exhaustiveCheck)}`);
      }
