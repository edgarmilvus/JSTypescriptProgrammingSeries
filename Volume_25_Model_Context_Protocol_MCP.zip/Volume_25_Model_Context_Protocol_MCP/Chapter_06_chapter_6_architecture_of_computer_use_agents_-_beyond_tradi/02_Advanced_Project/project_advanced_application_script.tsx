/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useRef } from 'react';

/**
 * Interface defining the exact shape of an MCP-compliant Computer Use tool payload.
 * Adheres strictly to the structural requirements for safe agent governance.
 */
interface IMCPToolAction {
  actionId: string;
  toolName: 'browser_navigate' | 'click_coordinate' | 'type_text' | 'extract_dom';
  payload: {
    url?: string;
    x?: number;
    y?: number;
    text?: string;
    selector?: string;
  };
  securityContext: {
    requiresUserApproval: boolean;
    authorizedScope: string;
  };
}

/**
 * Interface representing the multimodal observation returned by the browser loop.
 */
interface IVisionObservation {
  frameId: string;
  timestamp: number;
  viewportScreenshotBase64: string;
  detectedElementsCount: number;
  activeDOMSnippet: string;
}

/**
 * Interface defining the state of the SaaS Autonomous Browser Agent execution.
 */
interface IAgentExecutionState {
  status: 'IDLE' | 'CAPTURING' | 'ANALYZING' | 'EXECUTING' | 'PAUSED_FOR_APPROVAL' | 'COMPLETED' | 'ERROR';
  currentStep: number;
  logs: string[];
  lastObservation: IVisionObservation | null;
}

export default function ComputerUseAgentDashboard() {
  // 1. Initialize core state using React hooks for UI reactivity and thread safety
  const [executionState, setExecutionState] = useState<IAgentExecutionState>({
    status: 'IDLE',
    currentStep: 0,
    logs: ['System initialized. Awaiting user prompt for browser automation...'],
    lastObservation: null,
  });

  const [promptInput, setPromptInput] = useState<string>('');
  const [isSandboxActive, setIsSandboxActive] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  /**
   * 2. Simulates the secure MCP connection handshake and initializes the headless browser sandbox.
   */
  const handleInitializeSandbox = async () => {
    setExecutionState((prev) => ({
      ...prev,
      status: 'CAPTURING',
      logs: [...prev.logs, 'Establishing secure MCP transport layer...', 'Sandbox container spun up successfully.'],
    }));
    setIsSandboxActive(true);
    
    // Simulate initial viewport capture
    setTimeout(() => {
      const mockObservation: IVisionObservation = {
        frameId: 'frm_001_init',
        timestamp: Date.now(),
        viewportScreenshotBase64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        detectedElementsCount: 14,
        activeDOMSnippet: '<div id="app-root"><header>SaaS Dashboard</header><button id="login-btn">Sign In</button></div>',
      };
      setExecutionState((prev) => ({
        ...prev,
        status: 'IDLE',
        lastObservation: mockObservation,
        logs: [...prev.logs, `Frame captured: ${mockObservation.frameId} (${mockObservation.detectedElementsCount} interactive elements detected).`],
      }));
    }, 1000);
  };

  /**
   * 3. Core Vision-Driven Control Loop: Processes UI state via multimodal model and schedules MCP tool execution.
   */
  const handleRunAgentLoop = async () => {
    if (!promptInput.trim()) return;

    setExecutionState((prev) => ({
      ...prev,
      status: 'ANALYZING',
      currentStep: prev.currentStep + 1,
      logs: [...prev.logs, `[Step ${prev.currentStep + 1}] Processing goal: "${promptInput}" via Multimodal LLM...`],
    }));

    // Step A: Multimodal Reasoning Phase (Simulated)
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Construct an MCP compliant tool action payload based on visual analysis
    const plannedAction: IMCPToolAction = {
      actionId: `act_${Math.random().toString(36).substring(2, 9)}`,
      toolName: 'click_coordinate',
      payload: {
        x: 150,
        y: 85,
      },
      securityContext: {
        requiresUserApproval: true,
        authorizedScope: 'sandbox:browser:navigation',
      },
    };

    setExecutionState((prev) => ({
      ...prev,
      status: 'PAUSED_FOR_APPROVAL',
      logs: [
        ...prev.logs,
        `[Governance] Action evaluated: Tool '${plannedAction.toolName}' targeted at coordinates (${plannedAction.payload.x}, ${plannedAction.payload.y}). Awaiting human authorization.`,
      ],
    }));
  };

  /**
   * 4. Human-in-the-Loop Governance Hook: Approves and executes the pending MCP tool action.
   */
  const handleApproveAction = async () => {
    setExecutionState((prev) => ({
      ...prev,
      status: 'EXECUTING',
      logs: [...prev.logs, '[Governance] Action approved by operator. Executing instruction via MCP protocol...'],
    }));

    // Simulate action execution against the browser DOM
    await new Promise((resolve) => setTimeout(resolve, 1200));

    const updatedObservation: IVisionObservation = {
      frameId: `frm_${Date.now()}`,
      timestamp: Date.now(),
      viewportScreenshotBase64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
      detectedElementsCount: 22,
      activeDOMSnippet: '<main class="dashboard-home"><h1>Welcome back, Operator</h1><input type="text" placeholder="Search accounts..." /></main>',
    };

    setExecutionState((prev) => ({
      ...prev,
      status: 'IDLE',
      lastObservation: updatedObservation,
      logs: [...prev.logs, 'Action executed successfully. New viewport state acquired and processed.'],
    }));
  };

  // Render the enterprise SaaS interface
  return (
    <div style={{ padding: '24px', fontFamily: 'Inter, sans-serif', backgroundColor: '#0f172a', color: '#f8fafc', minHeight: '100vh' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #334155', paddingBottom: '16px', marginBottom: '24px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>MCP Computer Use Orchestrator</h1>
          <p style={{ color: '#94a3b8', fontSize: '14px', margin: '4px 0 0 0' }}>Vision-Driven Browser Automation & Governance Dashboard</p>
        </div>
        <div>
          <span style={{ padding: '6px 12px', borderRadius: '9999px', fontSize: '12px', fontWeight: 600, backgroundColor: isSandboxActive ? '#065f46' : '#991b1b', color: '#fff' }}>
            {isSandboxActive ? 'SANDBOX ACTIVE' : 'SANDBOX OFFLINE'}
          </span>
        </div>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        {/* Left Column: Controls & Vision Viewport */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ backgroundColor: '#1e293b', padding: '16px', borderRadius: '8px', border: '1px solid #334155' }}>
            <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>Sandbox Controls</h2>
            {!isSandboxActive ? (
              <button
                onClick={handleInitializeSandbox}
                style={{ backgroundColor: '#3b82f6', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer', fontWeight: 600 }}
              >
                Initialize Secure Sandbox
              </button>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <textarea
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  placeholder="Enter objective (e.g., 'Log into dashboard and export user metrics')..."
                  style={{ width: '100%', height: '80px', backgroundColor: '#0f172a', color: '#f8fafc', border: '1px solid #475569', borderRadius: '6px', padding: '8px', resize: 'none' }}
                />
                <button
                  onClick={handleRunAgentLoop}
                  disabled={executionState.status === 'ANALYZING' || executionState.status === 'EXECUTING'}
                  style={{ backgroundColor: '#10b981', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer', fontWeight: 600 }}
                >
                  {executionState.status === 'ANALYZING' ? 'Analyzing UI State...' : 'Run Vision Control Loop'}
                </button>
              </div>
            )}
          </div>

          {/* Vision Viewport Rendering Box */}
          <div style={{ backgroundColor: '#1e293b', padding: '16px', borderRadius: '8px', border: '1px solid #334155' }}>
            <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Active Viewport Stream</h3>
            <div style={{ width: '100%', height: '200px', backgroundColor: '#0f172a', border: '1px dashed #475569', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              {executionState.lastObservation ? (
                <div style={{ textAlign: 'center' }}>
                  <p style={{ fontSize: '12px', color: '#38bdf8' }}>Frame ID: {executionState.lastObservation.frameId}</p>
                  <p style={{ fontSize: '12px', color: '#94a3b8' }}>Detected Elements: {executionState.lastObservation.detectedElementsCount}</p>
                </div>
              ) : (
                <span style={{ color: '#64748b', fontSize: '13px' }}>Awaiting frame capture...</span>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Governance & Execution Logs */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ backgroundColor: '#1e293b', padding: '16px', borderRadius: '8px', border: '1px solid #334155', display: 'flex', flexDirection: 'column', height: '100%' }}>
            <h2 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>Agent Governance & Audit Log</h2>
            
            {executionState.status === 'PAUSED_FOR_APPROVAL' && (
              <div style={{ backgroundColor: '#78350f', border: '1px solid #d97706', padding: '12px', borderRadius: '6px', marginBottom: '12px' }}>
                <p style={{ fontSize: '13px', fontWeight: 600, color: '#fef3c7', margin: '0 0 8px 0' }}>Security Checkpoint: Tool execution requires human sign-off.</p>
                <button
                  onClick={handleApproveAction}
                  style={{ backgroundColor: '#d97706', color: '#fff', border: 'none', padding: '6px 12px', borderRadius: '4px', cursor: 'pointer', fontWeight: 600, fontSize: '12px' }}
                >
                  Approve & Execute Action
                </button>
              </div>
            )}

            <div style={{ flex: 1, backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '6px', padding: '12px', overflowY: 'auto', maxHeight: '320px', fontFamily: 'monospace', fontSize: '12px' }}>
              {executionState.logs.map((log, index) => (
                <div key={index} style={{ marginBottom: '6px', color: log.includes('Governance') ? '#fbbf24' : '#cbd5e1' }}>
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
