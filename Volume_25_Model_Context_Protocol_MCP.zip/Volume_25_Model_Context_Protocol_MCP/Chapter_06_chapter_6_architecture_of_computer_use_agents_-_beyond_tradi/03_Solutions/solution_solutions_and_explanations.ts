/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { EventEmitter } from 'events';

export interface ScreenDimensions {
  width: number;
  height: number;
}

export interface AgentAction {
  type: 'click' | 'type' | 'scroll' | 'wait';
  x?: number; // Normalized 0.0 to 1.0
  y?: number; // Normalized 0.0 to 1.0
  text?: string;
  duration?: number;
}

export interface MCPClient {
  sendVisionPayload(base64Image: string): Promise<AgentAction>;
}

export class SafetyViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SafetyViolationError';
  }
}

export interface VisionAgentConfig {
  frameRateLimit: number;
  screenDimensions: ScreenDimensions;
  mcpClient: MCPClient;
  restrictedRegions?: Array<{ xMin: number; xMax: number; yMin: number; yMax: number; }>;
}

export class VisionAgentLoop extends EventEmitter {
  private config: VisionAgentConfig;
  private isRunning: boolean = false;

  constructor(config: VisionAgentConfig) {
    super();
    this.config = config;
  }

  public async captureAndAnalyze(screenshotBuffer: Buffer): Promise<AgentAction> {
    const base64Image = screenshotBuffer.toString('base64');
    const action = await this.executeWithRetry(() => 
      this.config.mcpClient.sendVisionPayload(base64Image)
    );

    this.validateActionSafety(action);
    return this.scaleCoordinates(action);
  }

  private async executeWithRetry<T>(operation: () => Promise<T>, maxRetries = 3, delayMs = 1000): Promise<T> {
    let attempts = 0;
    while (true) {
      try {
        return await operation();
      } catch (error: any) {
        attempts++;
        if (error?.status === 429 && attempts <= maxRetries) {
          const backoff = delayMs * Math.pow(2, attempts - 1);
          await new Promise((resolve) => setTimeout(resolve, backoff));
          continue;
        }
        throw error;
      }
    }
  }

  private validateActionSafety(action: AgentAction): void {
    if (action.x !== undefined && action.y !== undefined) {
      // Check absolute normalized boundaries [0, 1]
      if (action.x < 0 || action.x > 1 || action.y < 0 || action.y > 1) {
        throw new SafetyViolationError(`Coordinates out of bounds: (${action.x}, ${action.y})`);
      }

      // Check restricted system regions (e.g., top OS bar: y < 0.05)
      if (this.config.restrictedRegions) {
        for (const region of this.config.restrictedRegions) {
          if (
            action.x >= region.xMin && action.x <= region.xMax &&
            action.y >= region.yMin && action.y <= region.yMax
          ) {
            throw new SafetyViolationError(`Action targeted restricted UI component at (${action.x}, ${action.y})`);
          }
        }
      }
    }
  }

  private scaleCoordinates(action: AgentAction): AgentAction {
    if (action.x !== undefined && action.y !== undefined) {
      return {
        ...action,
        x: Math.round(action.x * this.config.screenDimensions.width),
        y: Math.round(action.y * this.config.screenDimensions.height),
      };
    }
    return action;
  }
}
