/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';

export interface AgentTelemetryEvent {
  timestamp: number;
  screenshotUrl: string;
  action: {
    type: string;
    x?: number;
    y?: number;
    description: string;
  };
  reasoning: string;
}

interface AgentMonitorDashboardProps {
  telemetryStream: AgentTelemetryEvent[];
  onPauseToggle: (paused: boolean) => void;
  onStepForward: () => void;
  onInjectCommand: (command: string) => void;
}

export const AgentMonitorDashboard: React.FC<AgentMonitorDashboardProps> = ({
  telemetryStream,
  onPauseToggle,
  onStepForward,
  onInjectCommand,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [commandInput, setCommandInput] = useState<string>('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Keep index synchronized with live stream when not paused
  useEffect(() => {
    if (!isPaused && telemetryStream.length > 0) {
      setCurrentIndex(telemetryStream.length - 1);
    }
  }, [telemetryStream, isPaused]);

  const currentEvent = useMemo(() => {
    return telemetryStream[currentIndex] || null;
  }, [telemetryStream, currentIndex]);

  // Render canvas overlay efficiently
  const renderCanvasOverlay = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !currentEvent) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = currentEvent.screenshotUrl;
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);

      // Draw bounding box / coordinate marker if action has coordinates
      if (currentEvent.action.x !== undefined && currentEvent.action.y !== undefined) {
        const x = currentEvent.action.x;
        const y = currentEvent.action.y;

        ctx.beginPath();
        ctx.arc(x, y, 12, 0, 2 * Math.PI);
        ctx.fillStyle = 'rgba(255, 0, 0, 0.4)';
        ctx.fill();
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#ff0000';
        ctx.stroke();

        // Label
        ctx.font = '14px Arial';
        ctx.fillStyle = '#ff0000';
        ctx.fillText(`${currentEvent.action.type}: ${currentEvent.action.description}`, x + 15, y);
      }
    };
  }, [currentEvent]);

  useEffect(() => {
    renderCanvasOverlay();
  }, [renderCanvasOverlay]);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsPaused(true);
    setCurrentIndex(Number(e.target.value));
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">Autonomous Agent Monitor</h1>
        <div className="flex gap-2">
          <button
            onClick={() => {
              const nextState = !isPaused;
              setIsPaused(nextState);
              onPauseToggle(nextState);
            }}
            className={`px-4 py-2 rounded ${isPaused ? 'bg-green-600' : 'bg-yellow-600'}`}
          >
            {isPaused ? 'Resume' : 'Pause'}
          </button>
          <button
            onClick={onStepForward}
            disabled={!isPaused}
            className="px-4 py-2 bg-blue-600 rounded disabled:opacity-50"
          >
            Step Forward
          </button>
        </div>
      </div>

      <div className="relative flex-1 flex justify-center items-center bg-black border border-gray-700 overflow-hidden">
        <canvas ref={canvasRef} className="max-h-full max-w-full object-contain" />
      </div>

      <div className="my-4">
        <input
          type="range"
          min={0}
          max={Math.max(0, telemetryStream.length - 1)}
          value={currentIndex}
          onChange={handleSliderChange}
          className="w-full cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-400 mt-1">
          <span>Frame 0</span>
          <span>Current: {currentIndex} / {telemetryStream.length}</span>
          <span>Latest</span>
        </div>
      </div>

      <div className="p-4 bg-gray-800 rounded flex gap-2">
        <input
          type="text"
          value={commandInput}
          onChange={(e) => setCommandInput(e.target.value)}
          placeholder="Inject steering command..."
          className="flex-1 p-2 bg-gray-700 rounded border border-gray-600"
        />
        <button
          onClick={() => {
            onInjectCommand(commandInput);
            setCommandInput('');
          }}
          className="px-4 py-2 bg-purple-600 rounded"
        >
          Inject
        </button>
      </div>
    </div>
  );
};
