/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface TaskNode {
  id: string;
  type: 'browser' | 'desktop';
  payload: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: any;
}

export interface AgentMessage {
  sender: string;
  recipient: string;
  action: string;
  data: any;
}

export interface MCPToolDefinition {
  name: string;
  execute(params: any): Promise<any>;
}

export interface IExecutionAgent {
  executeTask(task: TaskNode): Promise<any>;
}

export class BrowserExecutionAgent implements IExecutionAgent {
  public async executeTask(task: TaskNode): Promise<any> {
    // Simulate browser automation tasks (DOM/Vision interaction)
    console.log(`[BrowserAgent] Executing web task:`, task.payload);
    return { success: true, data: "Web interaction finished" };
  }
}

export class DesktopExecutionAgent implements IExecutionAgent {
  public async executeTask(task: TaskNode): Promise<any> {
    // Simulate desktop OS operations (file read/write, native app invocation)
    console.log(`[DesktopAgent] Executing desktop task:`, task.payload);
    return { success: true, csvData: [{ name: "Alice", value: 42 }] };
  }
}

export class SupervisorAgent {
  private browserAgent: IExecutionAgent;
  private desktopAgent: IExecutionAgent;

  constructor(browserAgent: IExecutionAgent, desktopAgent: IExecutionAgent) {
    this.browserAgent = browserAgent;
    this.desktopAgent = desktopAgent;
  }

  public async orchestrate(objective: string): Promise<void> {
    console.log(`[Supervisor] Decomposing objective: "${objective}"`);
    
    // Decomposed DAG task simulation
    const tasks: TaskNode[] = [
      { id: 't1', type: 'desktop', payload: { action: 'read_csv', path: '/local/data.csv' }, status: 'pending' },
      { id: 't2', type: 'browser', payload: { action: 'populate_crm' }, status: 'pending' }
    ];

    for (const task of tasks) {
      task.status = 'running';
      let agent = task.type === 'browser' ? this.browserAgent : this.desktopAgent;
      
      let attempts = 0;
      let success = false;
      while (attempts < 3 && !success) {
        try {
          if (task.id === 't2' && tasks[0].result) {
            // Pass state handoff from desktop agent output to browser task payload
            task.payload.sourceData = tasks[0].result.csvData;
          }
          task.result = await agent.executeTask(task);
          task.status = 'completed';
          success = true;
        } catch (error) {
          attempts++;
          console.warn(`[Supervisor] Task ${task.id} failed (Attempt ${attempts}). Re-planning...`);
          if (attempts >= 3) {
            task.status = 'failed';
            throw new Error(`Critical workflow failure at task ${task.id}`);
          }
        }
      }
    }
    console.log(`[Supervisor] Workflow completed successfully.`);
  }
}
