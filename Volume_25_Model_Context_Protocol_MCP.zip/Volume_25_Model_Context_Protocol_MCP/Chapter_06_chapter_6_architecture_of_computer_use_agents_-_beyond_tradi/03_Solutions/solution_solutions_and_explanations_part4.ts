/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface AgentAction {
  type: 'navigate' | 'click' | 'type' | 'file_io';
  target: string; // URL or File path
  payload?: string;
  coordinates?: { x: number; y: number };
}

export interface ExecutionResult {
  success: boolean;
  output?: any;
  error?: string;
}

export class SecurityInterceptor {
  private allowedDomains: string[];
  private allowedPaths: string[];

  constructor(allowedDomains: string[], allowedPaths: string[]) {
    this.allowedDomains = allowedDomains;
    this.allowedPaths = allowedPaths;
  }

  public async executeWithGuardrails(
    action: AgentAction, 
    manualApprovalCallback?: () => Promise<boolean>
  ): Promise<ExecutionResult> {
    try {
      this.scanForPIIAndSecrets(action);
      this.verifySandboxBoundaries(action);
      
      const riskScore = this.calculateRiskScore(action);
      if (riskScore > 0.7) {
        if (!manualApprovalCallback || !(await manualApprovalCallback())) {
          throw new Error(`Action blocked by security guardrails: Risk score ${riskScore} exceeded threshold.`);
        }
      }

      return { success: true, output: "Action passed guardrail checks and executed." };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  private scanForPIIAndSecrets(action: AgentAction): void {
    const textToCheck = `${action.target} ${action.payload || ''}`;
    
    // Regex patterns for API keys, Credit cards, SSNs, and Base64-obfuscated secrets markers
    const piiPatterns = [
      /sk-[a-zA-Z0-9]{20,}/, // OpenAI keys format
      /\b\d{4}[-. ]?\d{4}[-. ]?\d{4}[-. ]?\d{4}\b/, // Credit Card
      /\b\d{3}-\d{2}-\d{4}\b/, // SSN
      /password\s*[:=]\s*[^\s]+/i
    ];

    for (const pattern of piiPatterns) {
      if (pattern.test(textToCheck)) {
        throw new Error(`Security Violation: Potential PII or Secret detected in action payload.`);
      }
    }
  }

  private verifySandboxBoundaries(action: AgentAction): void {
    // Sanitize invisible zero-width characters that might mask path spoofing
    const sanitizedTarget = action.target.replace(/[\u200B-\u200D\uFEFF]/g, '');

    if (action.type === 'navigate') {
      const isAllowed = this.allowedDomains.some(domain => sanitizedTarget.includes(domain));
      if (!isAllowed) {
        throw new Error(`Sandbox Violation: Domain ${sanitizedTarget} is not whitelisted.`);
      }
    }

    if (action.type === 'file_io') {
      const isAllowed = this.allowedPaths.some(path => sanitizedTarget.startsWith(path));
      if (!isAllowed) {
        throw new Error(`Sandbox Violation: File path ${sanitizedTarget} falls outside permitted boundaries.`);
      }
    }
  }

  private calculateRiskScore(action: AgentAction): number {
    let score = 0.0;
    if (action.type === 'file_io') score += 0.4;
    if (action.payload && action.payload.length > 500) score += 0.3;
    if (action.target.includes('admin') || action.target.includes('root')) score += 0.4;
    return Math.min(score, 1.0);
  }
}
