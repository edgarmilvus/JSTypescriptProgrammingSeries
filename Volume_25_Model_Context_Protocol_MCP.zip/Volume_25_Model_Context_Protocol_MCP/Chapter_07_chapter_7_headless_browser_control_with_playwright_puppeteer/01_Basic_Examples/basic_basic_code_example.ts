/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { chromium, Page } from 'playwright';
import OpenAI from 'openai';
import * as fs from 'fs/promises';
import * as path from 'path';

/**
 * Interface representing the structured JSON response expected from the Vision LLM.
 * Defines the next interaction action for the browser automation loop.
 */
interface VisionActionDecision {
  thought: string;
  action: 'click' | 'type' | 'wait' | 'complete';
  selectorOrCoordinates?: { x: number; y: number };
  textValue?: string;
  reasoning: string;
}

/**
 * Initializes the OpenAI client and Playwright browser instance, executing a 
 * vision-driven browser automation workflow for a SaaS login page.
 */
async function runVisionBrowserAgent(): Promise<void> {
  // 1. Initialize the OpenAI client for multimodal reasoning
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || 'mock-api-key-for-execution',
  });

  // 2. Launch the headless browser instance using Playwright
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
  });
  const page = await context.newPage();

  try {
    // 3. Navigate to the target SaaS application login page
    console.log('Navigating to the target SaaS application...');
    await page.goto('https://example.com/login', { waitUntil: 'networkidle' });

    // 4. Capture a live screenshot of the current viewport for the Vision LLM
    const screenshotPath = path.join(process.cwd(), 'current_state.png');
    await page.screenshot({ path: screenshotPath, fullPage: false });
    console.log(`Screenshot captured at: ${screenshotPath}`);

    // 5. Read the screenshot file and convert it to a base64 data URL
    const imageBuffer = await fs.readFile(screenshotPath);
    const base64Image = imageBuffer.toString('base64');
    const dataUrl = `data:image/png;base64,${base64Image}`;

    // 6. Construct the prompt for the Vision LLM containing the Thought-Action-Observation context
    console.log('Sending screenshot and prompt to the Vision LLM...');
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are an autonomous browser automation agent operating within a SaaS application testing framework. 
          Analyze the provided UI screenshot. 
          Your goal is to log into the application. 
          Identify the email input field, type 'admin@saas-app.com', click the password field, type 'SecurePassword123!', and click the submit button.
          Return ONLY valid JSON matching the following structure:
          {
            "thought": "Step-by-step reasoning about the current UI state",
            "action": "click" | "type" | "wait" | "complete",
            "selectorOrCoordinates": { "x": number, "y": number },
            "textValue": "string to type if action is type",
            "reasoning": "Detailed justification for the chosen action"
          }`,
        },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Here is the current browser viewport. What is the next action to take to progress the login flow?',
            },
            {
              type: 'image_url',
              image_url: {
                url: dataUrl,
              },
            },
          ],
        },
      ],
      response_format: { type: 'json_object' },
      max_tokens: 500,
    });

    // 7. Parse the structured JSON response from the LLM
    const responseContent = response.choices[0].message.content;
    if (!responseContent) {
      throw new Error('Received empty response from Vision LLM.');
    }

    const decision: VisionActionDecision = JSON.parse(responseContent);
    console.log(`[LLM Thought]: ${decision.thought}`);
    console.log(`[LLM Action]: ${decision.action}`);
    console.log(`[LLM Reasoning]: ${decision.reasoning}`);

    // 8. Execute the requested action inside the Playwright browser loop
    if (decision.action === 'click' && decision.selectorOrCoordinates) {
      const { x, y } = decision.selectorOrCoordinates;
      console.log(`Executing click at coordinates: X=${x}, Y=${y}`);
      await page.mouse.click(x, y);
    } else if (decision.action === 'type' && decision.selectorOrCoordinates && decision.textValue) {
      const { x, y } = decision.selectorOrCoordinates;
      console.log(`Clicking and typing "${decision.textValue}" at coordinates: X=${x}, Y=${y}`);
      await page.mouse.click(x, y);
      await page.keyboard.type(decision.textValue, { delay: 50 });
    } else if (decision.action === 'complete') {
      console.log('Agent successfully completed the target browser flow.');
    } else {
      console.warn(`Unhandled action type or missing coordinates: ${decision.action}`);
    }

    // 9. Wait briefly to observe the visual mutation resulting from the action
    await page.waitForTimeout(2000);

  } catch (error) {
    console.error('An error occurred during vision-driven browser automation:', error);
  } finally {
    // 10. Clean up and close the browser instance to prevent memory leaks
    console.log('Closing browser instance...');
    await browser.close();
  }
}

// Execute the automation script
runVisionBrowserAgent();
