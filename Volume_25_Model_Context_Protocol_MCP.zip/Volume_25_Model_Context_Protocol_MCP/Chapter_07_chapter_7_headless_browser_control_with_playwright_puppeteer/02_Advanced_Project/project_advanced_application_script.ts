/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { chromium, Page } from 'playwright';
import { GoogleGenAI } from '@google/genai';

// Initialize the Gemini client utilizing standard environment configuration
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

/**
 * Defines the contract for an autonomous step execution plan derived from UI inspection.
 */
interface ExecutionStep {
    action: 'click' | 'type' | 'scroll' | 'assert' | 'complete';
    selector?: string;
    text?: string;
    coordinates?: { x: number; y: number };
    reasoning: string;
}

/**
 * User-defined type guard to validate that an arbitrary API response 
 * conforms strictly to the ExecutionStep interface at runtime.
 */
function isExecutionStep(response: unknown): response is ExecutionStep {
    if (typeof response !== 'object' || response === null) {
        return false;
    }
    const candidate = response as Record<string, unknown>;
    return (
        typeof candidate.action === 'string' &&
        ['click', 'type', 'scroll', 'assert', 'complete'].includes(candidate.action) &&
        typeof candidate.reasoning === 'string'
    );
}

/**
 * Captures a high-resolution screenshot of the current viewport and requests 
 * the next operational step from the Vision LLM.
 * 
 * @param page - The active Playwright page instance.
 * @param objective - The high-level user goal for the automation session.
 * @returns A validated ExecutionStep containing instructions for the browser loop.
 */
async function determineNextAction(page: Page, objective: string): Promise<ExecutionStep> {
    // Capture the current viewport as a base64 encoded PNG buffer
    const screenshotBuffer = await page.screenshot({ fullPage: false, type: 'png' });
    const base64Image = screenshotBuffer.toString('base64');

    const prompt = `
    You are an autonomous browser agent navigating a web application to fulfill this objective: "${objective}".
    Analyze the attached screenshot of the current application state.
    Determine the single next logical interaction required to progress toward the objective.
    
    Respond ONLY with a JSON object matching this TypeScript structure:
    {
      "action": "click" | "type" | "scroll" | "assert" | "complete",
      "selector": "CSS selector if applicable",
      "text": "Text to type if action is 'type'",
      "coordinates": { "x": number, "y": number },
      "reasoning": "Detailed explanation of why this action was chosen."
    }
    `;

    // Perform headless inference by passing multimodal context to Gemini 2.5 Flash
    const modelResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            {
                inlineData: {
                    mimeType: 'image/png',
                    data: base64Image,
                },
            },
            prompt,
        ],
    });

    const rawText = modelResponse.text;
    if (!rawText) {
        throw new Error('Vision LLM returned an empty response during step evaluation.');
    }

    // Sanitize and parse JSON output from the model
    const cleanedJson = rawText.replace(/