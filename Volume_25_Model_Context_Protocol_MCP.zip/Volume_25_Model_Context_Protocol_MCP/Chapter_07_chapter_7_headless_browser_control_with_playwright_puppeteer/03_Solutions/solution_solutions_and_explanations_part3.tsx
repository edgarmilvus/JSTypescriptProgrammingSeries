/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface AgentStepRecord {
  id: string;
  stepNumber: number;
  thought: string;
  actionType: string;
  screenshotBase64: string;
  status: 'SUCCESS' | 'FAILED' | 'ROLLED_BACK';
  timestamp: number;
}

export interface AgentVisualInspectorProps {
  steps: AgentStepRecord[];
  onStepSelect?: (step: AgentStepRecord) => void;
}

export const AgentVisualInspector: React.FC<AgentVisualInspectorProps> = ({ steps, onStepSelect }) => {
  const [selectedStepId, setSelectedStepId] = useState<string | null>(
    steps.length > 0 ? steps[0].id : null
  );

  const activeStep = steps.find((s) => s.id === selectedStepId) || steps[0];

  const handleStepClick = (step: AgentStepRecord) => {
    setSelectedStepId(step.id);
    if (onStepSelect) {
      onStepSelect(step);
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Left Pane: Timeline List */}
      <div className="w-1/3 border-r border-gray-800 overflow-y-auto p-4">
        <h2 className="text-xl font-bold mb-4">Agent Execution Timeline</h2>
        <div className="space-y-3">
          {steps.map((step) => (
            <div
              key={step.id}
              onClick={() => handleStepClick(step)}
              className={`p-3 rounded-lg cursor-pointer transition-colors ${
                selectedStepId === step.id ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-semibold">Step {step.stepNumber}: {step.actionType}</span>
                <span className={`text-xs px-2 py-0.5 rounded ${
                  step.status === 'SUCCESS' ? 'bg-green-500 text-black' :
                  step.status === 'FAILED' ? 'bg-red-500 text-white' : 'bg-yellow-500 text-black'
                }`}>
                  {step.status}
                </span>
              </div>
              <p className="text-sm text-gray-300 truncate">{step.thought}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right Pane: Visual & Thought Inspector */}
      <div className="w-2/3 p-6 flex flex-col overflow-y-auto">
        <h2 className="text-xl font-bold mb-4">Step Inspector</h2>
        {activeStep ? (
          <div className="flex flex-col space-y-6">
            <div className="bg-gray-800 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-400 mb-2">Thought Process</h3>
              <p className="text-gray-100">{activeStep.thought}</p>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg flex-1">
              <h3 className="text-sm font-semibold text-gray-400 mb-2">Captured Screenshot</h3>
              <div className="border border-gray-700 rounded overflow-hidden bg-black flex justify-center">
                <img 
                  src={`data:image/png;base64,${activeStep.screenshotBase64}`} 
                  alt={`Step ${activeStep.stepNumber} execution state`}
                  className="max-h-96 object-contain"
                />
              </div>
            </div>
          </div>
        ) : (
          <p className="text-gray-400">Select a step to inspect details.</p>
        )}
      </div>
    </div>
  );
};
