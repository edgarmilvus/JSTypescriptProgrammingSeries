/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Page } from 'playwright';

interface MCPToolResponse {
  content: Array<{
    type: 'text' | 'image';
    text?: string;
    data?: string; // base64 string for images
    mimeType?: string;
  }>;
  isError?: boolean;
}

interface NavigateToolArguments {
  url: string;
  clickSelector?: string;
}

export const browserNavigateToolSchema = {
  name: "browser_navigate_and_click",
  description: "Navigates to a URL using Playwright and optionally clicks an element based on a visual or CSS selector.",
  inputSchema: {
    type: "object",
    properties: {
      url: { type: "string", description: "The destination URL to navigate to." },
      clickSelector: { type: "string", description: "Optional CSS selector to click after page load." }
    },
    required: ["url"]
  }
};

export async function executeBrowserNavigateTool(
  page: Page, 
  args: NavigateToolArguments
): Promise<MCPToolResponse> {
  try {
    await page.goto(args.url, { waitUntil: 'networkidle' });

    if (args.clickSelector) {
      await page.click(args.clickSelector);
    }

    // Capture confirmation screenshot
    const screenshotBuffer = await page.screenshot({ fullPage: true });
    const base64Image = screenshotBuffer.toString('base64');

    return {
      content: [
        {
          type: 'text',
          text: `Successfully navigated to ${args.url}${args.clickSelector ? ` and clicked ${args.clickSelector}` : ''}.`
        },
        {
          type: 'image',
          data: base64Image,
          mimeType: 'image/png'
        }
      ]
    };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    // Capture debug screenshot of the error state
    let errorBase64 = '';
    try {
      const errorBuffer = await page.screenshot({ fullPage: true });
      errorBase64 = errorBuffer.toString('base64');
    } catch (screenshotError) {
      console.error('Failed to capture error state screenshot:', screenshotError);
    }

    return {
      isError: true,
      content: [
        {
          type: 'text',
          text: `Error executing browser navigation tool: ${errorMessage}`
        },
        ...(errorBase64 ? [{
          type: 'image' as const,
          data: errorBase64,
          mimeType: 'image/png'
        }] : [])
      ]
    };
  }
}
