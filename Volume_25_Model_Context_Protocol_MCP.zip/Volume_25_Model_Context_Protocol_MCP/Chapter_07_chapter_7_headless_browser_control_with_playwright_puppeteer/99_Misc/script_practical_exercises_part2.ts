/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

interface AgentStepState {
  currentUrl: string;
  activeInputSelector: string | null;
  lastActionError: string | null;
}

class OptimisticStateManager<TState> {
  private officialState: TState;
  private pendingState: TState;
  private transactionHistory: Map<string, TState> = new Map();

  constructor(initialState: TState) {
    this.officialState = initialState;
    this.pendingState = { ...initialState };
  }

  public getPendingState(): TState {
    return this.pendingState;
  }

  public getOfficialState(): TState {
    return this.officialState;
  }

  public applyOptimisticUpdate(updateFn: (current: TState) => TState, txId: string): TState {
    // Save current official/pending baseline
    this.transactionHistory.set(txId, { ...this.pendingState });
    
    // Apply optimistic mutation
    this.pendingState = updateFn({ ...this.pendingState });
    return this.pendingState;
  }

  public reconcile(txId: string, verifiedState: TState, isSuccess: boolean): void {
    // TODO: Implement reconciliation logic
    // If successful, promote pendingState/verifiedState to officialState.
    // If failed, restore pendingState from transactionHistory using txId, 
    // and set officialState back to the safe baseline.
  }
}
