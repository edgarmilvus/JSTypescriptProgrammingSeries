/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';

export interface AgentStepRecord {
  id: string;
  stepNumber: number;
  thought: string;
  actionType: string;
  screenshotBase64: string;
  status: 'SUCCESS' | 'FAILED' | 'ROLLED_BACK';
  timestamp: number;
}

export interface AgentVisualInspectorProps {
  steps: AgentStepRecord[];
  onStepSelect?: (step: AgentStepRecord) => void;
}

export const AgentVisualInspector: React.FC<AgentVisualInspectorProps> = ({ steps, onStepSelect }) => {
  // TODO: Initialize state for the currently selected step index (default to 0 or null)
  const [selectedStepId, setSelectedStepId] = useState<string | null>(
    steps.length > 0 ? steps[0].id : null
  );

  const activeStep = steps.find((s) => s.id === selectedStepId) || steps[0];

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Left Pane: Timeline List */}
      <div className="w-1/3 border-r border-gray-800 overflow-y-auto p-4">
        <h2 className="text-xl font-bold mb-4">Agent Execution Timeline</h2>
        {/* TODO: Map over steps and render clickable timeline items */}
      </div>

      {/* Right Pane: Visual & Thought Inspector */}
      <div className="w-2/3 p-6 flex flex-col">
        <h2 className="text-xl font-bold mb-4">Step Inspector</h2>
        {activeStep ? (
          <div className="flex flex-col space-y-4">
            {/* TODO: Render screenshot preview and JSON payload view */}
          </div>
        ) : (
          <p className="text-gray-400">Select a step to inspect details.</p>
        )}
      </div>
    </div>
  );
};
