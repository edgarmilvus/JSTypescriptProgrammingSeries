/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

import { Page } from 'playwright';

// Mock function representing the Vision LLM coordinate resolver fallback
async function resolveCoordinatesViaVision(page: Page, targetDescription: string): Promise<{ x: number; y: number }> {
  const screenshot = await page.screenshot();
  // Simulated API call to Vision LLM
  return { x: 500, y: 300 };
}

export async function smartInteract(
  page: Page, 
  selector: string, 
  description: string,
  action: 'click' | 'type', 
  textValue?: string
): Promise<boolean> {
  try {
    // Attempt 1: Deterministic DOM Interaction
    const locator = page.locator(selector);
    await locator.waitFor({ state: 'visible', timeout: 3000 });

    if (action === 'click') {
      await locator.click();
    } else if (action === 'type' && textValue) {
      await locator.fill(textValue);
    }
    return true; // DOM interaction successful
  } catch (domError) {
    console.warn(`DOM interaction failed for selector "${selector}". Escalating to Vision Fallback...`, domError);

    try {
      // Attempt 2: Vision LLM Fallback
      const viewport = page.viewportSize();
      if (!viewport) return false;

      const coords = await resolveCoordinatesViaVision(page, description);

      if (action === 'click') {
        await page.mouse.click(coords.x, coords.y);
      } else if (action === 'type' && textValue) {
        await page.mouse.click(coords.x, coords.y);
        await page.keyboard.type(textValue);
      }
      return true; // Vision fallback successful
    } catch (visionError) {
      console.error('Both DOM interaction and Vision fallback failed.', visionError);
      return false;
    }
  }
}
