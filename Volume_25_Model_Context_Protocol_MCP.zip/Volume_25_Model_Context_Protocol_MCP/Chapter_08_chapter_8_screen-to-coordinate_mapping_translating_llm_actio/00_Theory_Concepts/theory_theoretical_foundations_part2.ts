/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

digraph HitTestingPipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor=lightblue, fontname="Arial", fontsize=12];

    Start [label="Start: Viewport Coordinates (x_v, y_v)", fillcolor=lightyellow];
    ElementFromPoint [label="Execute document.elementFromPoint(x_v, y_v)", fillcolor=lightblue];
    ShadowCheck [label="Does Element Contain Shadow DOM?", fillcolor=lightyellow];
    TraverseShadow [label="Traverse shadowRoot.elementFromPoint()", fillcolor=lightblue];
    OcclusionCheck [label="Is Element Occluded by Overlay/Modal?", fillcolor=lightyellow];
    HandleOcclusion [label="Trigger Dismissal or Fallback", fillcolor=lightcoral];
    DispatchClick [label="Dispatch Native Mouse Events", fillcolor=lightgreen];

    Start -> ElementFromPoint;
    ElementFromPoint -> ShadowCheck;
    ShadowCheck -> TraverseShadow [label="Yes"];
    ShadowCheck -> OcclusionCheck [label="No"];
    TraverseShadow -> OcclusionCheck;
    OcclusionCheck -> HandleOcclusion [label="Yes"];
    OcclusionCheck -> DispatchClick [label="No"];
    HandleOcclusion -> ElementFromPoint;
}
