/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { JSDOM } from 'jsdom';

/**
 * Represents the normalized bounding box returned by an LLM's vision model.
 * All values are expressed as floating-point ratios between 0.0 and 1.0
 * relative to the source screenshot's native dimensions.
 */
interface NormalizedBoundingBox {
  ymin: number;
  xmin: number;
  ymax: number;
  xmax: number;
}

/**
 * Represents the physical dimensions of the viewport captured by the LLM.
 */
interface ViewportDimensions {
  width: number;
  height: number;
}

/**
 * Configuration payload sent to the screen-to-coordinate mapping engine.
 */
interface ClickExecutionPayload {
  box: NormalizedBoundingBox;
  viewport: ViewportDimensions;
}

/**
 * Result of the coordinate translation and event dispatch process.
 */
interface ExecutionResult {
  success: boolean;
  targetElement: string;
  absoluteX: number;
  absoluteY: number;
  error?: string;
}

/**
 * Simulates a SaaS application environment where an agent interacts with a DOM node.
 * 
 * @param payload - The normalized bounding box and source viewport dimensions.
 * @param documentHtml - The raw HTML string representing the current browser DOM state.
 * @returns An execution result object detailing the outcome of the simulated click.
 */
function executeAgentClick(
  payload: ClickExecutionPayload,
  documentHtml: string
): ExecutionResult {
  // Step 1: Initialize a virtual DOM environment using jsdom to simulate a browser runtime
  const dom = new JSDOM(documentHtml, {
    url: 'https://app.saas-analytics.internal/dashboard',
    runScripts: 'dangerously',
  });
  const { document, window } = dom;

  // Step 2: Extract source viewport dimensions from the payload
  const { width: sourceWidth, height: sourceHeight } = payload.viewport;
  const { ymin, xmin, ymax, xmax } = payload.box;

  // Step 3: Denormalize relative LLM coordinates into absolute pixel coordinates
  const absoluteXCenterNormalized = (xmin + xmax) / 2;
  const absoluteYCenterNormalized = (ymin + ymax) / 2;

  const targetPixelX = Math.round(absoluteXCenterNormalized * sourceWidth);
  const targetPixelY = Math.round(absoluteYCenterNormalized * sourceHeight);

  // Step 4: Perform hit-testing on the virtual DOM at the calculated absolute coordinates
  const hitElement = window.document.elementFromPoint(targetPixelX, targetPixelY);

  if (!hitElement) {
    return {
      success: false,
      targetElement: 'None',
      absoluteX: targetPixelX,
      absoluteY: targetPixelY,
      error: `Hit-test failed: No DOM element found at coordinates (${targetPixelX}, ${targetPixelY}).`,
    };
  }

  // Step 5: Validate that the hit-tested element matches expected interactive semantics
  const tagName = hitElement.tagName.toLowerCase();
  const isInteractive =
    tagName === 'button' ||
    tagName === 'a' ||
    tagName === 'input' ||
    hitElement.hasAttribute('role') ||
    hitElement.hasAttribute('onclick');

  if (!isInteractive) {
    // Attempt fallback: traverse up the DOM tree to find the nearest interactive ancestor
    let currentElement: Element | null = hitElement;
    let foundInteractiveParent = false;

    while (currentElement && currentElement !== document.body) {
      const parentTag = currentElement.tagName.toLowerCase();
      if (
        parentTag === 'button' ||
        parentTag === 'a' ||
        parentTag === 'div' && currentElement.hasAttribute('data-action')
      ) {
        foundInteractiveParent = true;
        break;
      }
      currentElement = currentElement.parentElement;
    }

    if (!foundInteractiveParent) {
      return {
        success: false,
        targetElement: `${tagName}#${hitElement.id || 'unnamed'}`,
        absoluteX: targetPixelX,
        absoluteY: targetPixelY,
        error: `Element at (${targetPixelX}, ${targetPixelY}) is non-interactive and no interactive ancestor was found.`,
      };
    }
  }

  // Step 6: Construct and dispatch a native MouseEvent to the resolved target element
  try {
    const clickEvent = new window.MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: targetPixelX,
      clientY: targetPixelY,
    });

    hitElement.dispatchEvent(clickEvent);

    return {
      success: true,
      targetElement: `${tagName}#${hitElement.id || 'unnamed'} (Classes: ${hitElement.className})`,
      absoluteX: targetPixelX,
      absoluteY: targetPixelY,
    };
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      targetElement: `${tagName}`,
      absoluteX: targetPixelX,
      absoluteY: targetPixelY,
      error: `Failed to dispatch click event: ${errorMessage}`,
    };
  }
}

// ==========================================
// Execution Example within a SaaS Dashboard
// ==========================================

const saasDashboardHtml = `
<!DOCTYPE html>
<html>
  <head>
    <title>SaaS Analytics Overview</title>
  </head>
  <body>
    <div id="app-root" style="width: 1440px; height: 900px; position: relative;">
      <header style="height: 60px;">
        <h1>Dashboard</h1>
      </header>
      <main style="padding: 20px;">
        <!-- The target export button located by the LLM vision model -->
        <button 
          id="export-csv-btn" 
          data-action="export-data"
          style="position: absolute; left: 1200px; top: 100px; width: 150px; height: 40px;"
          onclick="console.log('CSV Export Triggered successfully.');"
        >
          Export CSV
        </button>
      </main>
    </div>
  </body>
</html>
`;

// Simulated payload from an LLM vision parser analyzing a 1440x900 screenshot
// Bounding box targeting the 'Export CSV' button: [ymin: 0.10, xmin: 0.83, ymax: 0.15, xmax: 0.93]
const samplePayload: ClickExecutionPayload = {
  box: {
    ymin: 0.10,
    xmin: 0.83,
    ymax: 0.15,
    xmax: 0.93,
  },
  viewport: {
    width: 1440,
    height: 900,
  },
};

const executionOutcome = executeAgentClick(samplePayload, saasDashboardHtml);
console.log('Agent Click Execution Outcome:', JSON.stringify(executionOutcome, null, 2));
