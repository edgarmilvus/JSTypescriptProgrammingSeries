/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file viewport-mapper.ts
 * @description Advanced screen-to-coordinate mapping engine for translating LLM visual 
 * inference coordinates into precise DOM interactions in a TypeScript/Next.js environment.
 */

import { chromium, Page, ElementHandle } from 'playwright';

/**
 * Represents the normalized bounding box or point returned by a vision-capable LLM.
 * Coordinates are typically scaled between 0 and 1000 for model quantization independence.
 */
export interface ModelVisualPoint {
  x: number; // Normalized X coordinate (0 - 1000)
  y: number; // Normalized Y coordinate (0 - 1000)
  label: string; // Semantic label of the target element
}

/**
 * Represents the physical viewport dimensions of the target browser instance.
 */
export interface ViewportDimensions {
  width: number;
  height: number;
  deviceScaleFactor: number;
}

/**
 * Configuration options for the translation and execution pipeline.
 */
export interface ExecutionOptions {
  paddingThreshold?: number; // Max acceptable distance for fallback snapping
  highlightTarget?: boolean; // Visual debugging aid in browser
  timeoutMs?: number;
}

/**
 * Translates normalized LLM visual coordinates to absolute DOM coordinates,
 * accounts for viewport scaling variations, and dispatches a precise click event.
 * 
 * @param page - Playwright Page instance representing the browser context.
 * @param point - The normalized point from the LLM inference output.
 * @param viewport - Current physical viewport settings.
 * @param options - Execution safeguards and debugging parameters.
 * @returns Promise<boolean> indicating click success status.
 */
export async function executeNormalizedClick(
  page: Page,
  point: ModelVisualPoint,
  viewport: ViewportDimensions,
  options: ExecutionOptions = {}
): { success: boolean; error?: string } {
  const {
    paddingThreshold = 15,
    highlightTarget = true,
    timeoutMs = 5000,
  } = options;

  try {
    // 1. De-normalize coordinates from the 1000x1000 model space to absolute pixel space
    const absoluteX = (point.x / 1000) * viewport.width;
    const absoluteY = (point.y / 1000) * viewport.height;

    console.log(`[Mapping Engine] De-normalized target '${point.label}': (${point.x}, ${point.y}) -> Absolute: (${absoluteX.toFixed(2)}, ${absoluteY.toFixed(2)})`);

    // 2. Optional: Inject a visual marker into the DOM for execution transparency and debugging
    if (highlightTarget) {
      await page.evaluate(
        ({ x, y, label }) => {
          const marker = document.createElement('div');
          marker.className = 'mcp-vision-debug-marker';
          marker.style.position = 'fixed';
          marker.style.left = `${x}px`;
          marker.style.top = `${y}px`;
          marker.style.width = '12px';
          marker.style.height = '12px';
          marker.style.marginLeft = '-6px';
          marker.style.marginTop = '-6px';
          marker.style.backgroundColor = 'rgba(255, 0, 0, 0.7)';
          marker.style.borderRadius = '50%';
          marker.style.zIndex = '999999';
          marker.style.pointerEvents = 'none';
          marker.style.border = '2px solid white';
          marker.title = `LLM Target: ${label}`;
          document.body.appendChild(marker);
          
          setTimeout(() => marker.remove(), 3000);
        },
        { x: absoluteX, y: absoluteY, label: point.label }
      );
    }

    // 3. Query the DOM element located directly beneath the calculated absolute coordinates
    const targetElementHandle = await page.evaluateHandle(
      ({ x, y }) => document.elementFromPoint(x, y),
      { x: absoluteX, y: absoluteY }
    );

    if (!targetElementHandle) {
      return { success: false, error: `No element found at absolute coordinates (${absoluteX}, ${absoluteY})` };
    }

    // 4. Validate if the targeted element is interactable or if we need spatial fallback correction
    const boundingBox = await targetElementHandle.boundingBox();

    if (!boundingBox) {
      // Fallback: Element exists but lacks layout metrics (e.g., display: contents or inline text node)
      console.warn(`[Mapping Engine] Target element lacks bounding box. Executing blind coordinate click.`);
      await page.mouse.click(absoluteX, absoluteY);
      return { success: true };
    }

    // 5. Check if absolute coordinates fall within the bounding box of the identified element
    const isInsideBox =
      absoluteX >= boundingBox.x &&
      absoluteX <= boundingBox.x + boundingBox.width &&
      absoluteY >= boundingBox.y &&
      absoluteY <= boundingBox.y + boundingBox.height;

    if (!isInsideBox) {
      console.warn(`[Mapping Engine] Coordinate drift detected! Target (${absoluteX}, ${absoluteY}) outside element box [${JSON.stringify(boundingBox)}]. Applying centroid fallback.`);
      
      // Calculate geometric center of the actual DOM bounding box as a safe fallback
      const centerX = boundingBox.x + boundingBox.width / 2;
      const centerY = boundingBox.y + boundingBox.height / 2;

      await page.mouse.click(centerX, centerY);
      return { success: true };
    }

    // 6. Execute precise click at the validated coordinates
    await page.mouse.click(absoluteX, absoluteY);
    return { success: true };

  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error(`[Mapping Engine Error] Failed to execute click for target '${point.label}':`, errorMessage);
    return { success: false, error: errorMessage };
  }
}
