/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface NormalizedPoint {
  x: number; // Range 0.0 - 1000.0
  y: number; // Range 0.0 - 1000.0
}

export interface ViewportConfig {
  width: number;
  height: number;
  dpr?: number;
  offsetX?: number;
  offsetY?: number;
}

export interface AbsolutePixelPoint {
  x: number;
  y: number;
}

export function denormalizeCoordinates(
  point: NormalizedPoint,
  viewport: ViewportConfig
): AbsolutePixelPoint {
  const dpr = viewport.dpr ?? 1;
  const offsetX = viewport.offsetX ?? 0;
  const offsetY = viewport.offsetY ?? 0;

  // Scale normalized [0, 1000] space to the viewport dimensions
  const rawX = (point.x / 1000) * viewport.width + offsetX;
  const rawY = (point.y / 1000) * viewport.height + offsetY;

  // Account for Device Pixel Ratio if coordinate mapping requires physical pixel alignment
  const scaledX = rawX / dpr;
  const scaledY = rawY / dpr;

  // Clamp safety checks to keep coordinates within strict viewport bounds
  const clampedX = Math.max(0, Math.min(scaledX, viewport.width));
  const clampedY = Math.max(0, Math.min(scaledY, viewport.height));

  return {
    x: Math.round(clampedX),
    y: Math.round(clampedY),
  };
}
