/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState } from 'react';

export interface AgentInteractionEvent {
  id: string;
  timestamp: number;
  normalizedBox: { ymin: number; xmin: number; ymax: number; xmax: number };
  targetPoint: { x: number; y: number };
  confidence: number;
  label: string;
  status: 'success' | 'misaligned' | 'failed';
}

interface AgentDebugOverlayProps {
  events: AgentInteractionEvent[];
  activeEventId?: string;
  onSelectEvent?: (id: string) => void;
}

export const AgentDebugOverlay: React.FC<AgentDebugOverlayProps> = ({
  events,
  activeEventId,
  onSelectEvent,
}) => {
  const [selectedId, setSelectedId] = useState<string | undefined>(activeEventId);

  const handleEventClick = (id: string) => {
    setSelectedId(id);
    if (onSelectEvent) {
      onSelectEvent(id);
    }
  };

  return (
    <div className="agent-debug-overlay-container" style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 9999 }}>
      {/* SVG Container for Bounding Boxes and Target Reticles */}
      <svg className="absolute inset-0 w-full h-full">
        {events.map((event) => {
          const isActive = event.id === selectedId;
          const strokeColor = 
            event.status === 'success' ? '#10B981' : 
            event.status === 'misaligned' ? '#F59E0B' : '#EF4444';

          // Convert normalized coordinates (0-1000) to percentage strings for responsive SVG scaling
          const x = (event.normalizedBox.xmin / 1000) * 100;
          const y = (event.normalizedBox.ymin / 1000) * 100;
          const width = ((event.normalizedBox.xmax - event.normalizedBox.xmin) / 1000) * 100;
          const height = ((event.normalizedBox.ymax - event.normalizedBox.ymin) / 1000) * 100;

          const targetX = (event.targetPoint.x / 1000) * 100;
          const targetY = (event.targetPoint.y / 1000) * 100;

          return (
            <g key={event.id} style={{ pointerEvents: 'auto', cursor: 'pointer' }} onClick={() => handleEventClick(event.id)}>
              <rect
                x={`${x}%`}
                y={`${y}%`}
                width={`${width}%`}
                height={`${height}%`}
                fill={isActive ? 'rgba(59, 130, 246, 0.2)' : 'transparent'}
                stroke={strokeColor}
                strokeWidth={isActive ? 3 : 1.5}
                strokeDasharray={event.status === 'misaligned' ? '4 4' : undefined}
              />
              <circle
                cx={`${targetX}%`}
                cy={`${targetY}%`}
                r="6"
                fill={strokeColor}
                className="animate-pulse"
              />
              <text x={`${targetX}%`} y={`${targetY - 1}%`} fill="#FFFFFF" fontSize="10" textAnchor="middle">
                {event.label}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Progressive Enhancement Fallback */}
      <div style={{ position: 'absolute', bottom: 10, left: 10, pointerEvents: 'auto', background: 'white', padding: '8px', borderRadius: '4px' }}>
        <details>
          <summary>View Raw Coordinate Logs</summary>
          <pre style={{ maxHeight: '200px', overflowY: 'auto', fontSize: '12px' }}>
            {JSON.stringify(events, null, 2)}
          </pre>
        </details>
      </div>
    </div>
  );
};
