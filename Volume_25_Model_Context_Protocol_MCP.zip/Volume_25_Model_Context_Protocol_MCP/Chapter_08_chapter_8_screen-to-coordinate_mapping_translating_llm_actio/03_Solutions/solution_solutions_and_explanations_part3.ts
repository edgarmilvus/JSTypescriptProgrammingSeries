/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface BrowserAgentGraphState {
  attemptCount: number;
  maxAttempts: number;
  lastCoordinates: { x: number; y: number };
  targetSelectorDescription: string;
  domMutationDetected: boolean;
  errorLog: string[];
}

export type GraphNodeResult = {
  nextNode: 'execute_click' | 'apply_fallback' | 'terminate_success' | 'terminate_failure';
  updatedState: Partial<BrowserAgentGraphState>;
};

export function evaluateClickResult(state: BrowserAgentGraphState): GraphNodeResult {
  const { attemptCount, maxAttempts, domMutationDetected, errorLog } = state;

  if (domMutationDetected) {
    return {
      nextNode: 'terminate_success',
      updatedState: {
        errorLog: [...errorLog, `Attempt ${attemptCount}: Click successfully triggered DOM mutation.`]
      }
    };
  }

  if (attemptCount >= maxAttempts) {
    return {
      nextNode: 'terminate_failure',
      updatedState: {
        errorLog: [...errorLog, `Attempt ${attemptCount}: Max retry attempts reached without mutation. Failing workflow.`]
      }
    };
  }

  return {
    nextNode: 'apply_fallback',
    updatedState: {
      attemptCount: attemptCount + 1,
      errorLog: [...errorLog, `Attempt ${attemptCount}: Click failed to trigger mutation. Routing to fallback strategy.`]
    }
  };
}
