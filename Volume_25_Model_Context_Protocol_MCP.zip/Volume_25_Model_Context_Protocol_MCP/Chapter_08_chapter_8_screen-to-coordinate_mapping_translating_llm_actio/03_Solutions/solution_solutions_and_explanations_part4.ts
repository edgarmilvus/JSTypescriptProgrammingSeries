/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface BoundingBox {
  xmin: number;
  ymin: number;
  xmax: number;
  ymax: number;
}

export interface Point {
  x: number;
  y: number;
}

export function resolveTargetElement(
  point: Point,
  box?: BoundingBox
): HTMLElement | null {
  const elements = document.elementsFromPoint(point.x, point.y);
  if (elements.length === 0) return null;

  // Filter out non-interactive overlays based on computed styles
  const validCandidates = elements.filter((el): el is HTMLElement => {
    if (!(el instanceof HTMLElement)) return false;
    const styles = window.getComputedStyle(el);
    
    const pointerEvents = styles.pointerEvents !== 'none';
    const isVisible = styles.visibility !== 'hidden' && styles.display !== 'none';
    const hasOpacity = parseFloat(styles.opacity) > 0;

    return pointerEvents && isVisible && hasOpacity;
  });

  if (validCandidates.length === 0) return null;

  // If a bounding box is supplied, calculate Intersection over Union (IoU) to find the best match
  if (box) {
    let bestCandidate: HTMLElement = validCandidates[0];
    let maxIoU = -1;

    for (const el of validCandidates) {
      const rect = el.getBoundingClientRect();
      const iou = calculateIoU(
        { xmin: rect.left, ymin: rect.top, xmax: rect.right, ymax: rect.bottom },
        box
      );

      if (iou > maxIoU) {
        maxIoU = iou;
        bestCandidate = el;
      }
    }

    return bestCandidate;
  }

  // Fallback to the top-most interactive element if no bounding box was provided
  return validCandidates[0];
}

function calculateIoU(box1: BoundingBox, box2: BoundingBox): number {
  const xOverlap = Math.max(0, Math.min(box1.xmax, box2.xmax) - Math.max(box1.xmin, box2.xmin));
  const yOverlap = Math.max(0, Math.min(box1.ymax, box2.ymax) - Math.max(box1.ymin, box2.ymin));
  const intersectionArea = xOverlap * yOverlap;

  const box1Area = (box1.xmax - box1.xmin) * (box1.ymax - box1.ymin);
  const box2Area = (box2.xmax - box2.xmin) * (box2.ymax - box2.ymin);
  const unionArea = box1Area + box2Area - intersectionArea;

  return unionArea === 0 ? 0 : intersectionArea / unionArea;
}
