/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { chromium, Browser, Page, Frame, ElementHandle } from 'playwright';

/**
 * Interface representing the structured payload extracted by the AI Agent
 * from complex, multi-layered web components.
 */
interface SaaSWidgetData {
  shadowComponentValue: string;
  canvasAnalysisText: string;
  iframeInvoiceTotal: string;
}

/**
 * Executes a simulated AI agent browser navigation routine to parse complex
 * web interfaces (Shadow DOM, Canvas, and iFrames) within a SaaS dashboard.
 * 
 * @param targetUrl The URL of the SaaS dashboard application.
 * @returns A promise resolving to the consolidated extracted metrics.
 */
async function runComplexDomAgent(targetUrl: string): Promise<SaaSWidgetData> {
  // 1. Initialize the Playwright automation runtime engine (headless browser)
  const browser: Browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page: Page = await context.newPage();

  try {
    // 2. Navigate to the SaaS Dashboard target endpoint
    console.log(`[Agent] Navigating to target environment: ${targetUrl}`);
    await page.goto(targetUrl, { waitUntil: 'networkidle' });

    // 3. Piercing the Shadow DOM: Locate a custom web component and query inside its shadow root
    console.log('[Agent] Attempting to pierce Shadow DOM boundary...');
    
    // In Playwright, CSS selectors pierce open shadow roots natively using standard combinators
    const shadowElementHandle: ElementHandle<SVGElement | HTMLElement> | null = await page.waitForSelector(
      'saas-metrics-card >>> div.metric-value',
      { timeout: 5000 }
    );

    let shadowComponentValue = 'NOT_FOUND';
    if (shadowElementHandle) {
      const textContent = await shadowElementHandle.textContent();
      shadowComponentValue = textContent ? textContent.trim() : 'EMPTY';
      console.log(`[Agent] Successfully extracted Shadow DOM metric: ${shadowComponentValue}`);
    }

    // 4. Interpreting HTML5 Canvas: Capture snapshot data of a canvas element for AI computer vision evaluation
    console.log('[Agent] Locating HTML5 Canvas for visual inspection...');
    const canvasHandle: ElementHandle<HTMLCanvasElement> | null = await page.waitForSelector(
      'canvas#usage-analytics-chart',
      { timeout: 5000 }
    );

    let canvasAnalysisText = 'CANVAS_UNREADABLE';
    if (canvasHandle) {
      // Extract the canvas content as a base64 encoded PNG data URL to be sent to a vision LLM
      const dataUrl = await canvasHandle.evaluate((canvas: HTMLCanvasElement) => {
        return canvas.toDataURL('image/png');
      });
      
      console.log(`[Agent] Captured canvas rendering snapshot (Base64 length: ${dataUrl.length}). Sending to Vision LLM...`);
      
      // Simulate calling a Multimodal Vision Model (e.g., GPT-4o / Claude 3.5 Sonnet) via Tool Calling
      canvasAnalysisText = await simulateVisionModelInference(dataUrl);
    }

    // 5. Traversing Nested iFrames: Locate an embedded payment processing or billing frame
    console.log('[Agent] Traversing down into nested iFrames...');
    
    // Retrieve the frame handle using its frame name or CSS selector matching the iframe element
    const iframeElement = await page.waitForSelector('iframe#billing-widget-frame', { timeout: 5000 });
    const frame: Frame | null = await iframeElement.contentFrame();

    let iframeInvoiceTotal = 'IFRAME_UNREACHABLE';
    if (frame) {
      console.log('[Agent] Successfully hooked into target iFrame context. Querying invoice data...');
      
      // Execute DOM queries directly inside the isolated iframe execution context
      const invoiceElement = await frame.waitForSelector('.invoice-due-amount', { timeout: 5000 });
      if (invoiceElement) {
        const invoiceText = await invoiceElement.textContent();
        iframeInvoiceTotal = invoiceText ? invoiceText.trim() : 'ZERO';
        console.log(`[Agent] Extracted invoice value from iFrame: ${iframeInvoiceTotal}`);
      }
    }

    // 6. Assemble the final structured result package for downstream agentic decision-making
    const extractedData: SaaSWidgetData = {
      shadowComponentValue,
      canvasAnalysisText,
      iframeInvoiceTotal,
    };

    return extractedData;

  } catch (error) {
    console.error('[Agent Error] Exception encountered during complex DOM traversal:', error);
    throw error;
  } finally {
    // 7. Ensure system resources are freed by closing the browser context
    console.log('[Agent] Teardown: Closing browser session.');
    await browser.close();
  }
}

/**
 * Simulated helper function mimicking an async multimodal LLM vision inference call.
 * In a real-world production setup, this would invoke the OpenAI or Anthropic API
 * passing the base64 image data to parse charts and graphs.
 * 
 * @param base64Image The PNG image string extracted from the HTML5 canvas element.
 * @returns A simulated natural language description of the chart metrics.
 */
async function simulateVisionModelInference(base64Image: string): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Mocked output representing a vision model analyzing CPU utilization trends on a canvas
      resolve('Trend: Upward trajectory, Peak utilization at 84.5% on Tuesday.');
    }, 1000);
  });
}

// Example execution loop for development testing
(async () => {
  const dashboardUrl = 'https://app.saas-metrics-example.internal/dashboard';
  try {
    const result = await runComplexDomAgent(dashboardUrl);
    console.log('--- FINAL AGENT EXTRACTION REPORT ---');
    console.log(JSON.stringify(result, null, 2));
  } catch (err) {
    console.error('Execution failed:', err);
  }
})();
