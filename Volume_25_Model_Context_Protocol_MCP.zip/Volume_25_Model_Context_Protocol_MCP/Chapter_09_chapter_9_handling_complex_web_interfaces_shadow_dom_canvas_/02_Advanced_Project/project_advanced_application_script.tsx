/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { chromium, Page, ElementHandle, Frame } from 'playwright';

/**
 * SaaS Analytics Auditor Configuration & Domain Models
 */
interface AuditTaskConfig {
  targetUrl: string;
  viewport: { width: number; height: number };
  timeoutMs: number;
}

/**
 * Extracted Canvas Analysis Payload utilizing Utility Types
 * Derived strictly from dynamic DOM evaluation steps.
 */
interface CanvasAuditMetrics {
  dataPointsDetected: number;
  dominantColorHex: string;
  visualAnomalyScore: number;
}

interface ShadowComponentPayload {
  hostSelector: string;
  innerElementText: string;
  ariaRole: string;
}

/**
 * Comprehensive Audit Result utilizing Partial and Readonly utility concepts
 * to enforce immutability across the agent's decision-making pipeline.
 */
type FinalAuditReport = Readonly<{
  timestamp: string;
  iframeMetrics: Record<string, string>;
  shadowDOMData: ShadowComponentPayload[];
  canvasMetrics: CanvasAuditMetrics;
  status: 'SUCCESS' | 'PARTIAL_FAILURE' | 'CRITICAL_ERROR';
}>;

/**
 * Core Automation Engine for Complex Web Interfaces
 */
export async function executeSaaSAnalyticsAudit(
  config: AuditTaskConfig
): Promise<FinalAuditReport> {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: config.viewport });
  const page = await context.newPage();

  const shadowDataCollection: ShadowComponentPayload[] = [];
  let iframeDataCollection: Record<string, string> = {};
  let canvasMetricsResult: CanvasAuditMetrics = {
    dataPointsDetected: 0,
    dominantColorHex: '#000000',
    visualAnomalyScore: 0.0,
  };

  try {
    // Step 1: Navigate to target SaaS analytics dashboard
    await page.goto(config.targetUrl, { waitUntil: 'networkidle', timeout: config.timeoutMs });

    // Step 2: Piercing Shadow DOM Boundaries
    // Locate a custom web component (e.g., <saas-metric-card>) and query its internal shadowRoot
    const shadowHostHandle = await page.$('saas-metric-card');
    if (shadowHostHandle) {
      const innerText = await page.evaluate((host) => {
        // Accessing the shadowRoot directly within browser context
        const shadowRoot = host.shadowRoot;
        if (!shadowRoot) return null;
        const targetElement = shadowRoot.querySelector('.metric-value');
        return targetElement ? targetElement.textContent : null;
      }, shadowHostHandle);

      shadowDataCollection.push({
        hostSelector: 'saas-metric-card',
        innerElementText: innerText || 'UNRESOLVABLE',
        ariaRole: 'region',
      });
    }

    // Step 3: Traversing Nested iFrames
    // Locate dynamic reporting frames embedded within the dashboard
    const analyticsFrameElement = await page.$('iframe#embedded-report-frame');
    if (analyticsFrameElement) {
      const frame: Frame | null = await analyticsFrameElement.contentFrame();
      if (frame) {
        // Extract metrics securely from inside the isolated iframe context
        const kpiValue = await frame.$eval('.kpi-total', (el) => el.textContent);
        iframeDataCollection['embedded-report-frame'] = kpiValue?.trim() || 'NO_DATA';
      }
    }

    // Step 4: Interpreting HTML5 Canvas Elements via Computer Vision Simulation
    const canvasHandle = await page.$('canvas#analytics-trend-chart');
    if (canvasHandle) {
      canvasMetricsResult = await page.evaluate((canvas) => {
        const htmlCanvas = canvas as HTMLCanvasElement;
        const ctx = htmlCanvas.getContext('2d');
        if (!ctx) return { dataPointsDetected: 0, dominantColorHex: '#000000', visualAnomalyScore: 1.0 };

        // Extract raw pixel buffer for computer vision analysis
        const imageData = ctx.getImageData(0, 0, htmlCanvas.width, htmlCanvas.height);
        const pixels = imageData.data;
        
        let nonZeroCount = 0;
        for (let i = 0; i < pixels.length; i += 4) {
          // Check for non-transparent pixels representing visual data points
          if (pixels[i + 3] > 128) {
            nonZeroCount++;
          }
        }

        return {
          dataPointsDetected: Math.floor(nonZeroCount / 100), // Normalized metric estimation
          dominantColorHex: '#2563EB', // Simulated dominant brand color extraction
          visualAnomalyScore: nonZeroCount > 5000 ? 0.05 : 0.85,
        };
      }, canvasHandle);
    }

    await browser.close();

    return {
      timestamp: new Date().toISOString(),
      iframeMetrics: iframeDataCollection,
      shadowDOMData: shadowDataCollection,
      canvasMetrics: canvasMetricsResult,
      status: 'SUCCESS',
    };

  } catch (error) {
    console.error('Critical failure during complex UI audit execution:', error);
    await browser.close();
    
    return {
      timestamp: new Date().toISOString(),
      iframeMetrics: {},
      shadowDOMData: [],
      canvasMetrics: canvasMetricsResult,
      status: 'CRITICAL_ERROR',
    };
  }
}
