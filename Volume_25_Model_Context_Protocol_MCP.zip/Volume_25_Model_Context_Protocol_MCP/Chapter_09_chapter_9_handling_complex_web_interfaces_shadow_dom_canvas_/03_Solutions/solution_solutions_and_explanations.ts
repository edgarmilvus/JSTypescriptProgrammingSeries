/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Page, Locator } from 'playwright';

interface ShadowTraversalStep {
  hostSelector: string;
}

interface ShadowTargetConfig {
  path: ShadowTraversalStep[];
  targetSelector: string;
  valueToFill: string;
}

/**
 * Traverses nested shadow DOM boundaries and fills a target input field.
 */
export async function locateAndFillShadowElement(
  page: Page,
  config: ShadowTargetConfig
): {
  let currentLocator: Locator = page.locator(config.path[0].hostSelector);

  // Traverse through each shadow host sequentially
  for (let i = 0; i < config.path.length; i++) {
    const step = config.path[i];
    
    // Retry loop for slow hydration / lazy loading of shadow roots
    let attempts = 0;
    const maxAttempts = 10;
    let shadowAttached = false;

    while (attempts < maxAttempts && !shadowAttached) {
      try {
        const hostElement = i === 0 ? page.locator(step.hostSelector) : currentLocator;
        await hostElement.waitFor({ state: 'attached', timeout: 2000 });
        
        // Evaluate if shadowRoot exists on the host
        const hasShadow = await hostElement.evaluate((el: HTMLElement) => !!el.shadowRoot);
        if (hasShadow) {
          shadowAttached = true;
        } else {
          await page.waitForTimeout(500);
          attempts++;
        }
      } catch (error) {
        attempts++;
        await page.waitForTimeout(500);
      }
    }

    if (!shadowAttached) {
      throw new Error(`Shadow root for host selector "${step.hostSelector}" failed to attach.`);
    }

    // Build or refine locator entering the shadow root via Playwright's native syntax
    if (i < config.path.length - 1) {
      currentLocator = currentLocator.locator(`>> :scope > * >> ${config.path[i + 1].hostSelector}`);
    }
  }

  // Once final shadow root is reached, query and fill the target element
  const finalHost = currentLocator;
  const targetInput = finalHost.locator(`>> ${config.targetSelector}`);
  
  await targetInput.waitFor({ state: 'visible', timeout: 5000 });
  await targetInput.fill(config.valueToFill);
}
