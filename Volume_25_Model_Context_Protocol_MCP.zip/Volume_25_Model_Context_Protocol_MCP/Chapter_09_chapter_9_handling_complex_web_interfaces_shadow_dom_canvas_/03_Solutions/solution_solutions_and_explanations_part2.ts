/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Page } from 'playwright';
import * as fs from 'fs';

interface CanvasInteractionResult {
  success: boolean;
  detectedElement: string;
  clickCoordinates: { x: number; y: number };
}

/**
 * Captures an HTML5 canvas, queries vision semantics, and clicks targeted coordinates.
 */
export async function interactWithCanvasByVision(
  page: Page,
  canvasSelector: string,
  targetDescription: string,
  mockLlmVisionCallback: (imageBuffer: Buffer, prompt: string) => Promise<{ x: number; y: number }>
): Promise<CanvasInteractionResult> {
  const canvasLocator = page.locator(canvasSelector);
  await canvasLocator.waitFor({ state: 'visible' });

  // 1. Capture high-resolution buffer screenshot of the specific canvas bounding box
  const boundingBox = await canvasLocator.boundingBox();
  if (!boundingBox) {
    throw new Error(`Could not determine bounding box for canvas: ${canvasSelector}`);
  }

  const screenshotBuffer = await canvasLocator.screenshot({ type: 'png' });

  // 2. Prompt multimodal LLM to parse canvas visual assets and return relative coordinates
  const prompt = `Analyze this canvas screenshot. Find the bounding box or center point for: "${targetDescription}". Return normalized coordinates between 0 and 1000 for x and y.`;
  const normalizedCoords = await mockLlmVisionCallback(screenshotBuffer, prompt);

  // 3. Transform normalized relative coordinates to absolute viewport coordinates
  const absoluteX = boundingBox.x + (normalizedCoords.x / 1000) * boundingBox.width;
  const absoluteY = boundingBox.y + (normalizedCoords.y / 1000) * boundingBox.height;

  // Dispatch native mouse click via Playwright controller
  await page.mouse.click(absoluteX, absoluteY);

  return {
    success: true,
    detectedElement: targetDescription,
    clickCoordinates: { x: absoluteX, y: absoluteY }
  };
}
