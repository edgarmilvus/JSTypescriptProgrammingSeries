/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Page, Frame } from 'playwright';

interface FrameTraversalPath {
  frameNameOrId?: string;
  frameIndex?: number;
  urlPattern?: string | RegExp;
}

/**
 * Recursively traverses a multi-tier iframe hierarchy to reach the target frame context.
 */
export async function traverseAndInteractFrame(
  page: Page,
  path: FrameTraversalPath[]
): Promise<Frame> {
  let currentFrame: Page | Frame = page;

  for (const step of path) {
    let targetFrame: Frame | null = null;
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts && !targetFrame) {
      const frames = currentFrame.childFrames();

      targetFrame = frames.find((f) => {
        if (step.frameNameOrId && (f.name() === step.frameNameOrId || f.url().includes(step.frameNameOrId))) {
          return true;
        }
        if (step.urlPattern && f.url().match(step.urlPattern)) {
          return true;
        }
        return false;
      }) || null;

      if (!targetFrame && step.frameIndex !== undefined && frames[step.frameIndex]) {
        targetFrame = frames[step.frameIndex];
      }

      if (!targetFrame) {
        await page.waitForTimeout(500);
        attempts++;
      }
    }

    if (!targetFrame) {
      throw new Error(`Failed to resolve iframe matching criteria: ${JSON.stringify(step)}`);
    }

    currentFrame = targetFrame;
  }

  // Hydration polling: Ensure the inner document has fully loaded and stabilized
  await currentFrame.waitForLoadState('load');
  await currentFrame.evaluate(() => {
    return new Promise<void>((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        window.addEventListener('load', () => resolve(), { once: true });
      }
    });
  });

  return currentFrame as Frame;
}
