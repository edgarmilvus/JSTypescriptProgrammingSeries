/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect, useImperativeHandle, forwardRef } from 'react';

export interface AIWorkspaceCanvasHandle {
  triggerAgentAction: (actionType: 'zoomIn' | 'resetView' | 'exportData') => void;
  getCanvasMetrics: () => Record<string, any>;
}

export interface AIWorkspaceCanvasProps {
  dataPoints: Array<{ id: string; x: number; y: number; label: string }>;
  onNodeClick?: (nodeId: string) => void;
  theme?: 'light' | 'dark';
}

export const AIWorkspaceCanvas = forwardRef<AIWorkspaceCanvasHandle, AIWorkspaceCanvasProps>(
  ({ dataPoints, onNodeClick, theme = 'light' }, ref) => {
    const shadowHostRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const zoomLevelRef = useRef<number>(1);

    // Expose imperative agent hooks
    useImperativeHandle(ref, () => ({
      triggerAgentAction: (actionType) => {
        if (actionType === 'zoomIn') zoomLevelRef.current += 0.2;
        if (actionType === 'resetView') zoomLevelRef.current = 1;
      },
      getCanvasMetrics: () => ({
        totalNodes: dataPoints.length,
        currentZoom: zoomLevelRef.current,
        themeActive: theme
      })
    }));

    // Setup Shadow DOM isolation for control panel
    useEffect(() => {
      if (shadowHostRef.current && !shadowHostRef.current.shadowRoot) {
        const shadowRoot = shadowHostRef.current.attachShadow({ mode: 'open' });
        shadowRoot.innerHTML = `
          <style>
            .control-panel {
              background: ${theme === 'dark' ? '#1e1e1e' : '#f5f5f5'};
              color: ${theme === 'dark' ? '#ffffff' : '#000000'};
              padding: 12px;
              border-radius: 6px;
              font-family: sans-serif;
            }
            button { cursor: pointer; padding: 6px 12px; }
          </style>
          <div class="control-panel">
            <h3>AI Workspace Controls</h3>
            <button id="agent-action-btn">Optimize Nodes</button>
          </div>
        `;
      }
    }, [theme]);

    // Canvas Rendering Loop
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let animationFrameId: number;

      const render = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.scale(zoomLevelRef.current, zoomLevelRef.current);

        // Render data points
        dataPoints.forEach((point) => {
          ctx.beginPath();
          ctx.arc(point.x, point.y, 6, 0, Math.PI * 2);
          ctx.fillStyle = theme === 'dark' ? '#61dafb' : '#007acc';
          ctx.fill();
          ctx.lineWidth = 2;
          ctx.strokeStyle = '#ffffff';
          ctx.stroke();
        });

        ctx.restore();
        animationFrameId = requestAnimationFrame(render);
      };

      render();

      return () => {
        cancelAnimationFrame(animationFrameId);
      };
    }, [dataPoints, theme]);

    return (
      <div className="ai-workspace-container">
        <div ref={shadowHostRef} data-testid="shadow-host" />
        <canvas
          ref={canvasRef}
          width={600}
          height={400}
          style={{ border: '1px solid #ccc', display: 'block', marginTop: '10px' }}
        />
      </div>
    );
  }
);

AIWorkspaceCanvas.displayName = 'AIWorkspaceCanvas';
