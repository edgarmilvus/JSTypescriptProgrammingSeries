/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { chromium, Page } from 'playwright';
import { GoogleGenAI } from '@google/genai';

/**
 * Interface representing the target element location determined by the vision model.
 */
interface ElementTarget {
  selector: string;
  x: number;
  y: number;
  confidence: number;
  fallbackReason?: string;
}

/**
 * Interface representing the schema for Few-Shot Prompting examples.
 */
interface FewShotExample {
  domSnippet: string;
  userIntent: string;
  outputJson: ElementTarget;
}

/**
 * SaaS Automation Agent: Handles resilient, self-healing form submission.
 */
class SelfHealingFormAssistant {
  private ai: GoogleGenAI;
  private page!: Page;

  constructor() {
    // Initialize the Gemini API client using standard environment variables
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  }

  /**
   * Initializes the browser automation context.
   */
  public async initialize(): Promise<void> {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 1280, height: 800 }
    });
    this.page = await context.newPage();
  }

  /**
   * Provides few-shot examples to guide the model on how to map visual UI elements
   * and DOM nodes to precise coordinate/selector targets.
   */
  private getFewShotContext(): FewShotExample[] {
    return [
      {
        domSnippet: '<button id="submit-btn" class="primary">Sign Up</button>',
        userIntent: "Click the primary registration button",
        outputJson: {
          selector: "#submit-btn",
          x: 150,
          y: 300,
          confidence: 0.98
        }
      },
      {
        domSnippet: '<input name="email_address" type="text" placeholder="Enter email..." />',
        userIntent: "Fill in the user email field",
        outputJson: {
          selector: "input[name='email_address']",
          x: 200,
          y: 120,
          confidence: 0.95
        }
      }
    ];
  }

  /**
   * Captures the current DOM and screenshot, then uses Gemini to locate the target element,
   * falling back to visual interpretation if the standard CSS selector fails.
   */
  public async locateAndAct(intent: string, standardSelector: string): Promise<boolean> {
    try {
      // Step 1: Attempt standard CSS selector lookup
      const element = await this.page.$(standardSelector);
      if (element) {
        console.log(`[DOM Match] Successfully located element via standard selector: ${standardSelector}`);
        await element.click();
        return true;
      }
      
      console.warn(`[Self-Healing Triggered] Standard selector "${standardSelector}" failed. Engaging Vision & LLM fallback...`);

      // Step 2: Capture visual state (Screenshot) and structural state (DOM snippet)
      const screenshotBuffer = await this.page.screenshot({ fullPage: false });
      const base64Image = screenshotBuffer.toString('base64');
      const pageHtml = await this.page.content();
      const domSnippet = pageHtml.slice(0, 4000); // Truncate to fit context window safely

      // Step 3: Construct Few-Shot Prompt payload
      const fewShots = this.getFewShotContext();
      const prompt = `
You are an expert autonomous web automation agent. Your job is to locate a UI element on a SaaS application interface to satisfy the user's intent. 
If the standard CSS selector has broken due to UI refactoring, use the provided visual screenshot and DOM snippet to determine the new target.

Here are examples of how to format your JSON output:
${JSON.stringify(fewShots, null, 2)}

Current User Intent: "${intent}"
Current Target Description: "${standardSelector}"
DOM Snippet:
${domSnippet}

Analyze the attached screenshot and DOM snippet. Return ONLY a valid JSON object matching the ElementTarget interface (selector, x, y, confidence, fallbackReason). Do not include markdown code block syntax.
      `;

      // Step 4: Call Multimodal LLM (Gemini 2.5 Flash / Pro)
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            inlineData: {
              mimeType: 'image/png',
              data: base64Image
            }
          },
          prompt
        ]
      });

      const responseText = response.text();
      if (!responseText) {
        throw new Error("Received empty response from multimodal LLM.");
      }

      // Clean up markdown block formatting if accidentally included by the model
      const cleanedJsonString = responseText.replace(/