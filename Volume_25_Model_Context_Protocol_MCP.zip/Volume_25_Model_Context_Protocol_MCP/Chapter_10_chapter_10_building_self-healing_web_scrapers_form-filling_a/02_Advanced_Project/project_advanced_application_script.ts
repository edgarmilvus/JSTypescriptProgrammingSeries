/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { chromium, Page, Locator } from 'playwright';
import { GoogleGenerativeAI } from '@google/generative-ai';

/**
 * Interface representing the extracted payload from a self-healing scraping cycle.
 */
interface ScrapedLeadData {
  companyName: string;
  revenueEstimate: string;
  employeeCount: number;
  extractedAt: string;
}

/**
 * Type Guard to validate that an arbitrary runtime object matches the ScrapedLeadData shape.
 * This guarantees type safety at runtime before database persistence or API forwarding.
 * 
 * @param data - Unknown input from LLM or DOM extraction
 */
function isValidLeadData(data: unknown): data is ScrapedLeadData {
  if (typeof data !== 'object' || data === null) return false;
  const candidate = data as Record<string, unknown>;
  return (
    typeof candidate.companyName === 'string' &&
    typeof candidate.revenueEstimate === 'string' &&
    typeof candidate.employeeCount === 'number' &&
    typeof candidate.extractedAt === 'string'
  );
}

/**
 * SelfHealingWebAgent orchestrates resilient browser automation tasks,
 * leveraging both strict CSS/XPath selectors and vision-based coordinate fallback.
 */
export class SelfHealingWebAgent {
  private page!: Page;
  private genAI: GoogleGenerativeAI;
  
  constructor(geminiApiKey: string) {
    this.genAI = new GoogleGenerativeAI(geminiApiKey);
  }

  /**
   * Initializes the headless Chromium browser instance via Playwright.
   */
  public async initialize(): Promise<void> {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    this.page = await context.newPage();
  }

  /**
   * Attempts to locate an element using standard selectors. If the selector fails
   * or times out, it captures a screenshot, consults the vision model to locate 
   * the UI element visually, and clicks the derived coordinates.
   * 
   * @param primarySelector - Standard CSS or XPath selector
   * @param semanticDescription - Plain-English description for the vision model
   */
  public async resilientClick(primarySelector: string, semanticDescription: string): Promise<void> {
    try {
      const locator: Locator = this.page.locator(primarySelector).first();
      await locator.waitFor({ state: 'visible', timeout: 5000 });
      await locator.click();
      console.log(`[DOM Success]: Successfully clicked element via selector: ${primarySelector}`);
    } catch (error) {
      console.warn(`[DOM Failure]: Selector '${primarySelector}' failed. Initiating vision fallback...`);
      await this.executeVisionFallbackClick(semanticDescription);
    }
  }

  /**
   * Captures a visual snapshot of the current viewport and sends it to the V8/Gemini engine
   * to resolve the precise target pixel coordinates for a broken UI component.
   */
  private async executeVisionFallbackClick(description: string): Promise<void> {
    const screenshotBuffer = await this.page.screenshot({ fullPage: false });
    const base64Image = screenshotBuffer.toString('base64');

    const model = this.genAI.getGenerativeModel({ model: 'gemini-1.5-pro' });
    
    const prompt = `
      Analyze this UI screenshot. Locate the interactive element matching this description: "${description}".
      Return ONLY a JSON object containing the absolute pixel coordinates { "x": number, "y": number } 
      representing the center point of the target element. Do not include markdown formatting.
    `;

    const result = await model.generateContent([
      prompt,
      {
        inlineData: {
          data: base64Image,
          mimeType: 'image/png',
        },
      },
    ]);

    const responseText = result.response.text().trim();
    // Clean potential markdown blocks if present
    const cleanedJson = responseText.replace(/^