/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define individual schemas for click and type actions
export const ClickActionSchema = z.object({
  action: z.literal('click'),
  selector: z.string().min(1, "Selector cannot be empty"),
  offsetX: z.number().optional(),
  offsetY: z.number().optional(),
  vectorId: z.string().optional(),
});

export const TypeActionSchema = z.object({
  action: z.literal('type'),
  selector: z.string().min(1, "Selector cannot be empty"),
  text: z.string(),
  vectorId: z.string().optional(),
});

// 2. Combine into a discriminated union schema
export const BrowserActionSchema = z.discriminatedUnion('action', [
  ClickActionSchema,
  TypeActionSchema,
]);

export type BrowserAction = z.infer<typeof BrowserActionSchema>;
export type ClickAction = z.infer<typeof ClickActionSchema>;
export type TypeAction = z.infer<typeof TypeActionSchema>;

// 3. Implement the runtime type guard function for type narrowing
export function isTypeAction(action: unknown): action is TypeAction {
  return (
    typeof action === 'object' &&
    action !== null &&
    'action' in action &&
    (action as { action: unknown }).action === 'type'
  );
}

// 4. Implement processAgentCommand with validation, vector tracking, and type narrowing
export async function processAgentCommand(rawInput: unknown): Promise<string> {
  try {
    // Validate raw input against the union schema
    const validatedAction = BrowserActionSchema.parse(rawInput);

    // Check for optional Vector ID metadata and log if present
    if (validatedAction.vectorId) {
      console.log(`[Tracking] Processing command with Vector ID: ${validatedAction.vectorId}`);
    }

    // 5. Branch execution safely using type narrowing
    if (validatedAction.action === 'click') {
      const coords = validatedAction.offsetX !== undefined && validatedAction.offsetY !== undefined
        ? ` at (${validatedAction.offsetX}, ${validatedAction.offsetY})`
        : '';
      return `Successfully executed click on selector: "${validatedAction.selector}"${coords}`;
    } else if (isTypeAction(validatedAction)) {
      return `Successfully typed text "${validatedAction.text}" into selector: "${validatedAction.selector}"`;
    }

    // Exhaustiveness check
    const exhaustiveCheck: never = validatedAction;
    return `Unhandled action type: ${JSON.stringify(exhaustiveCheck)}`;
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Validation failed for agent command: ${JSON.stringify(error.errors)}`);
    }
    throw error;
  }
}
