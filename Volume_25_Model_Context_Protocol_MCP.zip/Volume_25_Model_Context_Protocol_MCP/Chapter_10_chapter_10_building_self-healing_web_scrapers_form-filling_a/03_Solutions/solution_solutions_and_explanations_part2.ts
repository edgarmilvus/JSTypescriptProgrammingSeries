/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export interface DOMElementNode {
  tagName: string;
  id?: string;
  className?: string;
  innerText?: string;
  boundingBox?: { x: number; y: number; width: number; height: number };
}

// 1. Define the LLM vision response schema using Zod
export const VisionFallbackResponseSchema = z.object({
  correctedSelector: z.string().optional(),
  coordinates: z.object({
    x: z.number(),
    y: z.number(),
  }).optional(),
  confidence: z.number(),
  reasoning: z.string(),
});

export type VisionFallbackResponse = z.infer<typeof VisionFallbackResponseSchema>;

// Failure metrics tracker map: selector -> failure count
const selectorFailureCounts = new Map<string, number>();
const FAILURE_THRESHOLD = 3;

// Mock LLM Vision Client Interface for demonstration
interface VisionLLMClient {
  analyzeImageAndDOM(screenshotBuffer: Buffer, domDump: string, description: string): Promise<VisionFallbackResponse>;
}

// 2. Implement findRobustElement with primary selector and visual fallback logic
export async function findRobustElement(
  page: any,
  primarySelector: string,
  semanticDescription: string,
  llmClient: VisionLLMClient,
  vectorId?: string
): Promise<DOMElementNode> {
  try {
    // Attempt standard CSS selector lookup
    const elementHandle = await page.$(primarySelector);
    if (!elementHandle) {
      throw new Error(`Primary selector "${primarySelector}" returned null node.`);
    }

    const nodeData: DOMElementNode = await page.evaluate((el: HTMLElement) => {
      const rect = el.getBoundingClientRect();
      return {
        tagName: el.tagName.toLowerCase(),
        id: el.id || undefined,
        className: el.className || undefined,
        innerText: el.innerText?.slice(0, 100),
        boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
      };
    }, elementHandle);

    // Reset failure count upon success
    selectorFailureCounts.set(primarySelector, 0);
    return nodeData;

  } catch (error) {
    // Increment failure metrics
    const currentFailures = (selectorFailureCounts.get(primarySelector) || 0) + 1;
    selectorFailureCounts.set(primarySelector, currentFailures);

    // 4. Check if failure count exceeds threshold for warnings & telemetry
    if (currentFailures >= FAILURE_THRESHOLD) {
      console.warn(`[WARNING] Selector "${primarySelector}" has failed ${currentFailures} times. Vector ID: ${vectorId || 'N/A'}`);
    }

    console.info(`[Fallback] Primary selector "${primarySelector}" failed. Initiating vision-driven recovery...`);

    // Capture screenshot and DOM state for visual fallback
    const screenshotBuffer: Buffer = await page.screenshot();
    const domDump: string = await page.content();

    // Invoke Vision LLM with network timeout handling
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Vision model request timed out')), 10000)
    );

    const visionPromise = llmClient.analyzeImageAndDOM(screenshotBuffer, domDump, semanticDescription);
    const visionResult = await Promise.race([visionPromise, timeoutPromise]) as VisionFallbackResponse;

    // Validate structured output via Zod
    const validatedVision = VisionFallbackResponseSchema.parse(visionResult);

    if (validatedVision.correctedSelector) {
      return findRobustElement(page, validatedVision.correctedSelector, semanticDescription, llmClient, vectorId);
    } else if (validatedVision.coordinates) {
      return {
        tagName: 'unknown-vision-node',
        boundingBox: {
          x: validatedVision.coordinates.x,
          y: validatedVision.coordinates.y,
          width: 0,
          height: 0
        }
      };
    }

    throw new Error(`Vision fallback failed to resolve element for description: "${semanticDescription}"`);
  }
}
