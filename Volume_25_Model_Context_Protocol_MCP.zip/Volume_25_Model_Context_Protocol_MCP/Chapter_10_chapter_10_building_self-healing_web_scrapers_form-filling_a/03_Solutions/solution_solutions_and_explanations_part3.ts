/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the FormStepState discriminated union
export type FormStepState =
  | { status: 'Idle' }
  | { status: 'AnalyzingDOM'; stepId: string }
  | { status: 'ValidatingInput'; stepId: string; rawData: unknown }
  | { status: 'ExecutingAction'; stepId: string; sanitizedData: Record<string, unknown> }
  | { status: 'StepCompleted'; stepId: string; resultHash: string }
  | { status: 'WorkflowFailed'; stepId: string; error: string };

export interface FormStepDefinition<T extends z.ZodType = z.ZodType> {
  stepId: string;
  schema: T;
  action: (data: z.infer<T>) => Promise<string>;
}

export interface RollbackLogEntry {
  stepId: string;
  timestamp: number;
  domStateHash: string;
  payload: unknown;
}

// 2. Implement the SecureFormAssistant class
export class SecureFormAssistant {
  private currentState: FormStepState = { status: 'Idle' };
  private rollbackLog: RollbackLogEntry[] = [];
  private allowedDomains: string[];

  constructor(allowedDomains: string[]) {
    this.allowedDomains = allowedDomains;
  }

  public getState(): FormStepState {
    return this.currentState;
  }

  // 3. Validate step input using Zod schemas to strip unexpected properties and prevent prompt injection
  public validateStepInput<T extends z.ZodType>(schema: T, data: unknown): z.infer<T> {
    // .parse() automatically strips unknown keys not defined in the schema (preventing prompt injection)
    return schema.parse(data);
  }

  private recordRollbackEntry(entry: RollbackLogEntry): void {
    this.rollbackLog.push(entry);
  }

  // 4. Execute workflow sequentially with transaction tracking and automatic rollback on failure
  public async executeWorkflow(steps: FormStepDefinition[], getCurrentDomHash: () => Promise<string>): Promise<void> {
    for (const step of steps) {
      try {
        // Transition: Analyzing DOM
        this.currentState = { status: 'AnalyzingDOM', stepId: step.stepId };
        const domHash = await getCurrentDomHash();

        // Transition: Validating Input (Simulated input acquisition)
        this.currentState = { status: 'ValidatingInput', stepId: step.stepId, rawData: {} };
        
        // Mock data fetch for step
        const rawCollectedData = { fieldInput: "User provided input safely sanitized" };
        const sanitizedData = this.validateStepInput(step.schema, rawCollectedData);

        // Record entry for potential transactional rollback
        this.recordRollbackEntry({
          stepId: step.stepId,
          timestamp: Date.now(),
          domStateHash: domHash,
          payload: sanitizedData,
        });

        // Transition: Executing Action
        this.currentState = { status: 'ExecutingAction', stepId: step.stepId, sanitizedData };
        await step.action(sanitizedData);

        // Transition: Step Completed
        this.currentState = { status: 'StepCompleted', stepId: step.stepId, resultHash: domHash };

      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        this.currentState = { status: 'WorkflowFailed', stepId: step.stepId, error: errorMessage };
        
        await this.rollbackWorkflow();
        throw new Error(`Workflow halted at step "${step.stepId}" due to: ${errorMessage}`);
      }
    }
  }

  private async rollbackWorkflow(): Promise<void> {
    console.warn(`[TRANSACTION] Initiating rollback across ${this.rollbackLog.length} completed actions...`);
    // Replay or reverse operations using recorded rollback log entries
    while (this.rollbackLog.length > 0) {
      const entry = this.rollbackLog.pop()!;
      console.info(`[ROLLBACK] Reversing state changes for step: ${entry.stepId} at DOM hash ${entry.domStateHash}`);
    }
  }
}
