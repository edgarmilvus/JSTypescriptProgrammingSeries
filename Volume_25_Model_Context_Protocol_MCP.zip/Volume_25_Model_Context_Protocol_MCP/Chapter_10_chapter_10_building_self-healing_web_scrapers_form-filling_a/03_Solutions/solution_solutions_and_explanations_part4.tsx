/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define discriminated AgentEvent interfaces
export type AgentEvent =
  | { id: string; type: 'TOOL_INVOCATION'; timestamp: number; payload: { toolName: string; args: unknown } }
  | { id: string; type: 'DOM_FALLBACK_TRIGGERED'; timestamp: number; payload: { selector: string; vectorId: string } }
  | { id: string; type: 'VALIDATION_ERROR'; timestamp: number; payload: { errorDetails: string } }
  | { id: string; type: 'WORKFLOW_SUCCESS'; timestamp: number; payload: { summary: string } };

export type EventFilter = 'ALL' | 'FALLBACKS_ONLY' | 'GOVERNANCE_VIOLATIONS';

interface ScraperDashboardMonitorProps {
  agentEvents$: {
    subscribe: (callback: (event: AgentEvent) => void) => { unsubscribe: () => void };
  };
}

// 2. Implement the ScraperDashboardMonitor functional component
export const ScraperDashboardMonitor: React.FC<ScraperDashboardMonitorProps> = ({ agentEvents$ }) => {
  const [events, setEvents] = useState<AgentEvent[]>([]);
  const [filter, setFilter] = useState<EventFilter>('ALL');

  useEffect(() => {
    const subscription = agentEvents$.subscribe((newEvent) => {
      setEvents((prev) => [newEvent, ...prev].slice(0, 100)); // Keep last 100 events
    });
    return () => subscription.unsubscribe();
  }, [agentEvents$]);

  // Type-safe filtering logic
  const filteredEvents = events.filter((event) => {
    if (filter === 'FALLBACKS_ONLY') return event.type === 'DOM_FALLBACK_TRIGGERED';
    if (filter === 'GOVERNANCE_VIOLATIONS') return event.type === 'VALIDATION_ERROR';
    return true;
  });

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', background: '#1e1e1e', color: '#fff', minHeight: '100vh' }}>
      <h2>Self-Healing Scraping Dashboard Monitor</h2>

      {/* Interactive Filtering Toolbar */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
        {(['ALL', 'FALLBACKS_ONLY', 'GOVERNANCE_VIOLATIONS'] as EventFilter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: '8px 16px',
              background: filter === f ? '#007acc' : '#333',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            {f.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Event Stream Feed */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {filteredEvents.map((event) => (
          <div key={event.id} style={{ padding: '12px', background: '#2d2d2d', borderRadius: '6px', borderLeft: '4px solid #007acc' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
              <span style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{event.type}</span>
              <span style={{ fontSize: '0.8rem', color: '#aaa' }}>{new Date(event.timestamp).toLocaleTimeString()}</span>
            </div>

            {/* Conditional Type-Narrowing Payload Rendering */}
            {event.type === 'TOOL_INVOCATION' && (
              <div style={{ fontSize: '0.85rem' }}>
                Tool: <code>{event.payload.toolName}</code> | Args: {JSON.stringify(event.payload.args)}
              </div>
            )}
            {event.type === 'DOM_FALLBACK_TRIGGERED' && (
              <div style={{ fontSize: '0.85rem', color: '#ce9178' }}>
                Failed Selector: <code>{event.payload.selector}</code> | Vector ID: <strong>{event.payload.vectorId}</strong>
              </div>
            )}
            {event.type === 'VALIDATION_ERROR' && (
              <div style={{ fontSize: '0.85rem', color: '#f44747' }}>
                Error: {event.payload.errorDetails}
              </div>
            )}
            {event.type === 'WORKFLOW_SUCCESS' && (
              <div style={{ fontSize: '0.85rem', color: '#4ec9b0' }}>
                {event.payload.summary}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
