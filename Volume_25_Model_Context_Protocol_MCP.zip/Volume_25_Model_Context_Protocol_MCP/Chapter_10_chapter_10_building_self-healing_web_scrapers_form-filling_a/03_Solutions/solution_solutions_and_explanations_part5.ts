/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export interface MCPToolDefinition<T extends z.ZodType = z.ZodType> {
  name: string;
  description: string;
  inputSchema: T;
  handler: (args: z.infer<T>) => Promise<unknown>;
}

export interface AuditLogEntry {
  vectorId: string;
  toolName: string;
  timestamp: number;
  success: boolean;
  error?: string;
}

// 1. Implement MCPToolRegistry with Zod validation and domain restriction governance
export class MCPToolRegistry {
  private tools = new Map<string, MCPToolDefinition>();
  private auditTrail: AuditLogEntry[] = [];
  private allowedDomains: string[];

  constructor(allowedDomains: string[]) {
    this.allowedDomains = allowedDomains;
  }

  public registerTool<T extends z.ZodType>(tool: MCPToolDefinition<T>): void {
    this.tools.set(tool.name, tool);
  }

  // 3 & 4. Invoke tool with validation, governance checks, and audit logging
  public async invokeTool(toolName: string, rawArguments: unknown, vectorId: string): Promise<unknown> {
    const tool = this.tools.get(toolName);
    if (!tool) {
      throw new Error(`MCP Tool "${toolName}" is not registered.`);
    }

    // Domain governance check if tool accepts a URL
    if (typeof rawArguments === 'object' && rawArguments !== null && 'url' in rawArguments) {
      const urlStr = (rawArguments as { url: string }).url;
      try {
        const parsedUrl = new URL(urlStr);
        const isAllowed = this.allowedDomains.some(domain => parsedUrl.hostname.endsWith(domain));
        if (!isAllowed) {
          const violationError = `Governance Violation: Domain "${parsedUrl.hostname}" is not authorized.`;
          this.logAudit(vectorId, toolName, false, violationError);
          throw new Error(violationError);
        }
      } catch (err) {
        if (err instanceof Error && err.message.includes('Governance Violation')) throw err;
      }
    }

    try {
      // Validate raw arguments against tool's Zod schema
      const validatedArgs = tool.inputSchema.parse(rawArguments);
      
      // Execute underlying action handler
      const result = await tool.handler(validatedArgs);

      this.logAudit(vectorId, toolName, true);
      return result;

    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logAudit(vectorId, toolName, false, errorMessage);
      return {
        error: true,
        message: `MCP Execution Error: ${errorMessage}`,
      };
    }
  }

  private logAudit(vectorId: string, toolName: string, success: boolean, error?: string): void {
    const entry: AuditLogEntry = {
      vectorId,
      toolName,
      timestamp: Date.now(),
      success,
      error,
    };
    this.auditTrail.push(entry);
  }

  public getAuditTrail(): AuditLogEntry[] {
    return [...this.auditTrail];
  }
}
