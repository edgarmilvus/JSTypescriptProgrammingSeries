/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file federated_mcp_hierarchy.ts
 * @description A self-contained TypeScript implementation of a Hierarchical Agentic Workflow
 * using a federated Model Context Protocol (MCP) server registry for a SaaS analytics application.
 */

import { EventEmitter } from 'node:events';

// ============================================================================
// Types & Interfaces
// ============================================================================

type AgentRole = 'SUPERVISOR' | 'EXECUTOR';

type TaskStatus = 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';

interface MCPToolDefinition {
  name: string;
  description: string;
  schema: Record<string, string>;
}

interface AgentContext {
  sessionId: string;
  tenantId: string;
  state: Record<string, unknown>;
}

interface MCPMessage {
  id: string;
  senderId: string;
  recipientId: string;
  action: string;
  payload: Record<string, unknown>;
  timestamp: number;
}

// ============================================================================
// Federated MCP Registry & Event Bus
// ============================================================================

/**
 * Manages tool registration and message routing across distributed agents.
 */
class FederatedMCPRegistry extends EventEmitter {
  private static instance: FederatedMCPRegistry;
  private tools: Map<string, MCPToolDefinition> = new Map();
  private agents: Map<string, AgentNode> = new Map();

  private constructor() {
    super();
  }

  public static getInstance(): FederatedMCPRegistry {
    if (!FederatedMCPRegistry.instance) {
      FederatedMCPRegistry.instance = new FederatedMCPRegistry();
    }
    return FederatedMCPRegistry.instance;
  }

  public registerTool(tool: MCPToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  public registerAgent(agent: AgentNode): void {
    this.agents.set(agent.getId(), agent);
  }

  public routeMessage(message: MCPMessage): void {
    const recipient = this.agents.get(message.recipientId);
    if (!recipient) {
      throw new Error(`Routing Error: Agent ${message.recipientId} not found in registry.`);
    }
    recipient.handleIncomingMessage(message);
  }
}

// ============================================================================
// Base Agent Node Class
// ============================================================================

/**
 * Abstract base class representing an autonomous agent node in the MCP network.
 */
abstract class AgentNode {
  protected id: string;
  protected role: AgentRole;
  protected registry: FederatedMCPRegistry;
  protected context: AgentContext;

  constructor(id: string, role: AgentRole, context: AgentContext) {
    this.id = id;
    this.role = role;
    this.registry = FederatedMCPRegistry.getInstance();
    this.context = context;
    this.registry.registerAgent(this);
  }

  public getId(): string {
    return this.id;
  }

  public abstract handleIncomingMessage(message: MCPMessage): void;

  protected sendMCPMessage(recipientId: string, action: string, payload: Record<string, unknown>): void {
    const message: MCPMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      senderId: this.id,
      recipientId,
      action,
      payload,
      timestamp: Date.now(),
    };
    this.registry.routeMessage(message);
  }
}

// ============================================================================
// Supervisor Agent Implementation
// ============================================================================

/**
 * Supervisor Agent breaks down high-level SaaS requests and delegates to executors.
 */
class SupervisorAgent extends AgentNode {
  private activeSubtasks: Map<string, TaskStatus> = new Map();

  constructor(id: string, context: AgentContext) {
    super(id, 'SUPERVISOR', context);
  }

  public handleIncomingMessage(message: MCPMessage): void {
    switch (message.action) {
      case 'TASK_RESULT':
        this.handleTaskResult(message);
        break;
      default:
        console.warn(`[Supervisor: ${this.id}] Unknown action received: ${message.action}`);
    }
  }

  /**
   * Evaluates user prompt and orchestrates execution flow.
   */
  public coordinateWorkflow(directive: string, executorIds: string[]): void {
    console.log(`[Supervisor: ${this.id}] Processing high-level directive: "${directive}"`);
    
    // Decompose directive into granular subtasks for available executors
    executorIds.forEach((executorId, index) => {
      const subtaskId = `subtask_${Date.now()}_${index}`;
      this.activeSubtasks.set(subtaskId, 'IN_PROGRESS');
      
      console.log(`[Supervisor: ${this.id}] Delegating subtask ${subtaskId} to Executor ${executorId}`);
      
      this.sendMCPMessage(executorId, 'EXECUTE_SUBTASK', {
        subtaskId,
        directive: `Execute specialized operation part ${index + 1} for: ${directive}`,
      });
    });
  }

  private handleTaskResult(message: MCPMessage): void {
    const { subtaskId, status, result } = message.payload as { subtaskId: string; status: TaskStatus; result: unknown };
    this.activeSubtasks.set(subtaskId, status);
    
    console.log(`[Supervisor: ${this.id}] Received result for ${subtaskId}. Status: ${status}`);
    console.log(`[Supervisor: ${this.id}] Payload data:`, result);

    // Check if all subtasks are finished
    const allCompleted = Array.from(this.activeSubtasks.values()).every(s => s === 'COMPLETED');
    if (allCompleted) {
      console.log(`[Supervisor: ${this.id}] All federated subtasks completed successfully. Aggregating SaaS report...`);
    }
  }
}

// ============================================================================
// Executor Agent Implementation
// ============================================================================

/**
 * Executor Agent performs isolated operations using registered MCP tools.
 */
class ExecutorAgent extends AgentNode {
  constructor(id: string, context: AgentContext) {
    super(id, 'EXECUTOR', context);
  }

  public handleIncomingMessage(message: MCPMessage): void {
    switch (message.action) {
      case 'EXECUTE_SUBTASK':
        this.executeAssignedTask(message);
        break;
      default:
        console.warn(`[Executor: ${this.id}] Unknown action received: ${message.action}`);
    }
  }

  private executeAssignedTask(message: MCPMessage): void {
    const { subtaskId, directive } = message.payload as { subtaskId: string; directive: string };
    console.log(`[Executor: ${this.id}] Executing MCP tool integration for: "${directive}"`);

    // Simulate non-blocking asynchronous execution via the Node.js Event Loop
    setTimeout(() => {
      const simulatedResult = {
        metricsAnalyzed: 1420,
        confidenceScore: 0.96,
        timestamp: new Date().toISOString(),
      };

      console.log(`[Executor: ${this.id}] Subtask ${subtaskId} execution completed.`);

      this.sendMCPMessage(message.senderId, 'TASK_RESULT', {
        subtaskId,
        status: 'COMPLETED',
        result: simulatedResult,
      });
    }, 100);
  }
}

// ============================================================================
// SaaS Runtime Execution & Orchestration
// ============================================================================

async function runSaaSWorkflow(): Promise<void> {
  console.log('--- Initializing Federated MCP SaaS Environment ---');

  const tenantContext: AgentContext = {
    sessionId: 'sess_9981abc',
    tenantId: 'tenant_enterprise_42',
    state: {},
  };

  // 1. Initialize Federated Registry
  const registry = FederatedMCPRegistry.getInstance();

  // 2. Register Global MCP Tools
  registry.registerTool({
    name: 'browser_automation_tool',
    description: 'Drives headless browser for competitor visual scraping.',
    schema: { url: 'string', action: 'string' },
  });

  // 3. Instantiate Agents
  const supervisor = new SupervisorAgent('supervisor_main', tenantContext);
  const executorOne = new ExecutorAgent('executor_browser_node', tenantContext);
  const executorTwo = new ExecutorAgent('executor_analytics_node', tenantContext);

  // 4. Trigger Hierarchical Workflow
  supervisor.coordinateWorkflow(
    'Gather pricing data from competitor dashboard and compute variance.',
    [executorOne.getId(), executorTwo.getId()]
  );
}

// Execute the workflow
runSaaSWorkflow().catch(console.error);
