/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";
import { Client as MCPClient } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

/**
 * Define the shared state structure for the multi-agent graph.
 * This state is hydrated and persisted across turns using enterprise checkpointers.
 */
const GraphState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (left, right) => left.concat(right),
    default: () => [],
  }),
  nextWorker: Annotation<string>({
    reducer: (_, right) => right,
    default: () => "FINISH",
  }),
  activeSessionId: Annotation<string>({
    reducer: (_, right) => right,
    default: () => "default-session",
  }),
});

type AgentState = typeof GraphState.spec;

/**
 * Initialize federated MCP clients for distinct specialized domains.
 * In a real-world SaaS deployment, these connect to isolated microservices.
 */
async function initializeMCPConnections() {
  const browserTransport = new StdioClientTransport({
    command: "npx",
    args: ["-y", "@modelcontextprotocol/server-puppeteer"],
  });

  const dbTransport = new StdioClientTransport({
    command: "node",
    args: ["/var/mcp/enterprise-db-server.js"],
  });

  const browserClient = new MCPClient({ name: "browser-agent", version: "1.0.0" });
  const dbClient = new MCPClient({ name: "db-agent", version: "1.0.0" });

  await browserClient.connect(browserTransport);
  await dbClient.connect(dbTransport);

  return { browserClient, dbClient };
}

/**
 * Supervisor Node: Analyzes the graph state and decides whether to route 
 * execution to a specialized worker or terminate the workflow.
 */
async function supervisorNode(state: AgentState): Promise<Partial<AgentState>> {
  const model = new ChatOpenAI({ modelName: "gpt-4o", temperature: 0 });
  
  const systemPrompt = `
    You are a central enterprise supervisor managing federated worker agents.
    Available workers:
    - 'browserWorker': Handles web automation, visual extraction, and DOM interaction.
    - 'dbWorker': Handles secure SQL queries and data validation.
    
    Analyze the conversation history and select the next worker to execute, or output 'FINISH' if the user's objective is fully resolved.
    Return a JSON object with keys 'nextWorker' and 'reasoning'.
  `;

  const response = await model.invoke([
    { role: "system", content: systemPrompt },
    ...state.messages,
  ]);

  // Parse supervisor decision (simplified for illustration)
  const content = typeof response.content === 'string' ? response.content : "FINISH";
  let decision = { nextWorker: "FINISH" };
  
  try {
    decision = JSON.parse(content);
  } catch {
    if (content.includes("browser")) decision.nextWorker = "browserWorker";
    else if (content.includes("db")) decision.nextWorker = "dbWorker";
  }

  return { nextWorker: decision.nextWorker };
}

/**
 * Browser Worker Node: Executes vision-driven browser automation tasks via MCP.
 */
async function browserWorkerNode(state: AgentState): Promise<Partial<AgentState>> {
  const model = new ChatOpenAI({ modelName: "gpt-4o", temperature: 0.2 });
  
  // Bind tools dynamically acquired from the Browser MCP server
  const response = await model.invoke([
    { role: "system", content: "You are a specialized browser automation agent. Use available vision and DOM tools to complete the objective." },
    ...state.messages,
  ]);

  return {
    messages: [new AIMessage({ content: response.content, name: "browserWorker" })],
  };
}

/**
 * Database Worker Node: Executes enterprise SQL operations securely via MCP.
 */
async function dbWorkerNode(state: AgentState): Promise<Partial<AgentState>> {
  const model = new ChatOpenAI({ modelName: "gpt-4o", temperature: 0.1 });
  
  const response = await model.invoke([
    { role: "system", content: "You are a specialized database query agent. Execute secure queries and validate schema constraints." },
    ...state.messages,
  ]);

  return {
    messages: [new AIMessage({ content: response.content, name: "dbWorker" })],
  };
}

/**
 * Compiles the federated multi-agent graph with conditional routing logic.
 */
export async function createFederatedAgentGraph() {
  const workflow = new StateGraph(GraphState)
    .addNode("supervisor", supervisorNode)
    .addNode("browserWorker", browserWorkerNode)
    .addNode("dbWorker", dbWorkerNode);

  // Define conditional edges driven by the supervisor's routing output
  workflow.addConditionalEdges(
    "supervisor",
    (state) => state.nextWorker,
    {
      browserWorker: "browserWorker",
      dbWorker: "dbWorker",
      FINISH: END,
    }
  );

  // Workers return execution control back to the supervisor for evaluation
  workflow.addEdge("browserWorker", "supervisor");
  workflow.addEdge("dbWorker", "supervisor");

  workflow.setEntryPoint("supervisor");

  return workflow.compile();
}

/**
 * Next.js API Route Handler demonstrating Persistent Graph State Hydration.
 */
export async function POST(req: Request) {
  try {
    const { sessionId, prompt } = await req.json();
    
    // 1. Initialize MCP federated tool connections
    const { browserClient, dbClient } = await initializeMCPConnections();
    
    // 2. Compile graph workflow
    const graph = await createFederatedAgentGraph();

    // 3. Persistent Graph State Hydration
    // In production, fetch state from Redis or PostgreSQL checkpointer using sessionId
    const initialCheckpoint = {
      messages: [new HumanMessage(prompt)],
      activeSessionId: sessionId,
    };

    // 4. Execute graph run with parallel tool support enabled
    const finalState = await graph.invoke(initialCheckpoint, {
      configurable: { thread_id: sessionId },
    });

    // Clean up MCP transports
    await browserClient.close();
    await dbClient.close();

    return Response.json({
      success: true,
      sessionId,
      messages: finalState.messages.map((m: BaseMessage) => ({
        role: m._getType(),
        content: m.content,
        name: m.name,
      })),
    });
  } catch (error: any) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}
