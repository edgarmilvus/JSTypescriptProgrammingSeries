/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { WebSocketClientTransport } from "@modelcontextprotocol/sdk/client/websocket.js";
import { SSEClientTransport } from "@modelcontextprotocol/sdk/client/sse.js";
import { z } from "zod";

// Define schema for federated server metadata
export const ToolCapabilitySchema = z.object({
  name: z.string(),
  description: z.string(),
  inputSchema: z.record(z.any()),
});

export const FederatedServerMetadataSchema = z.object({
  id: z.string().uuid(),
  transportType: z.enum(["websocket", "sse"]),
  baseUrl: z.string().url(),
  protocolVersion: z.string(),
  capabilities: z.array(ToolCapabilitySchema),
  lastHeartbeat: z.number(),
});

export type FederatedServerMetadata = z.infer<typeof FederatedServerMetadataSchema>;

export class ServerUnreachableError extends Error {
  constructor(serverId: string, message: string) {
    super(`Server ${serverId} is unreachable: ${message}`);
    this.name = "ServerUnreachableError";
  }
}

export class RegistryManager {
  private registry: Map<string, FederatedServerMetadata> = new Map();

  public registerServer(meta: FederatedServerMetadata): void {
    const validated = FederatedServerMetadataSchema.parse(meta);
    this.registry.set(validated.id, { ...validated, lastHeartbeat: Date.now() });
  }

  public deregisterServer(id: string): void {
    this.registry.delete(id);
  }

  public async discoverCapabilities(toolNamePattern: string): Promise<FederatedServerMetadata[]> {
    const results: FederatedServerMetadata[] = [];
    const regex = new RegExp(toolNamePattern.replace("*", ".*"));

    for (const server of this.registry.values()) {
      const matches = server.capabilities.some((cap) => regex.test(cap.name));
      if (matches) {
        results.push(server);
      }
    }
    return results;
  }
}

export class FederatedMCPClient {
  private clientInstance: Client | null = null;

  constructor(private metadata: FederatedServerMetadata) {}

  public async initializeConnection(): Promise<void> {
    const transport =
      this.metadata.transportType === "websocket"
        ? new WebSocketClientTransport(new URL(this.metadata.baseUrl))
        : new SSEClientTransport(new URL(this.metadata.baseUrl));

    this.clientInstance = new Client(
      { name: "FederatedAgentClient", version: "1.0.0" },
      { capabilities: {} }
    );

    const connectPromise = this.clientInstance.connect(transport);
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new ServerUnreachableError(this.metadata.id, "Handshake timed out")), 1500)
    );

    try {
      await Promise.race([connectPromise, timeoutPromise]);
    } catch (error) {
      throw new ServerUnreachableError(this.metadata.id, (error as Error).message);
    }
  }

  public async callTool<TInput, TOutput>(toolName: string, args: TInput): Promise<TOutput> {
    if (!this.clientInstance) {
      throw new Error("Client not initialized. Call initializeConnection() first.");
    }
    const response = await this.clientInstance.callTool({
      name: toolName,
      arguments: args as Record<string, unknown>,
    });
    return response.content as unknown as TOutput;
  }
}
