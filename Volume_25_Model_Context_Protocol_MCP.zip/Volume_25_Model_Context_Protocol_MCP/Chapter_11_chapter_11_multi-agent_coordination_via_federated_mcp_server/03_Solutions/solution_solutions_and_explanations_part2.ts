/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { chromium, Browser, Page } from "playwright";

export interface BrowserExecutionState {
  sharedBuffer: SharedArrayBuffer;
  statusIndex: number; // Index in the Int32Array view
}

export enum SyncStatus {
  IDLE = 0,
  NAVIGATING = 1,
  SCREENSHOT_CAPTURED = 2,
  WAITING_FOR_VISION_ANALYSIS = 3,
  ACTION_EXECUTING = 4,
  ERROR = -1,
}

export class VisionBrowserAgentMCPNode {
  private browser: Browser | null = null;
  private page: Page | null = null;
  private state: BrowserExecutionState;

  constructor(state: BrowserExecutionState) {
    this.state = state;
  }

  public async initialize(): Promise<void> {
    this.browser = await chromium.launch({ headless: true });
    const context = await this.browser.newContext({ viewport: { width: 1280, height: 800 } });
    this.page = await context.newPage();
  }

  public async navigateAndCapture(url: string): Promise<{ domSnapshot: string; screenshotBuffer: Buffer }> {
    if (!this.page) throw new Error("Browser not initialized");

    this.setSyncStatus(SyncStatus.NAVIGATING);
    await this.page.goto(url, { waitUntil: "domcontentloaded" });

    this.setSyncStatus(SyncStatus.SCREENSHOT_CAPTURED);
    const screenshotBuffer = await this.page.screenshot({ fullPage: true });

    const domSnapshot = await this.page.content();
    this.setSyncStatus(SyncStatus.WAITING_FOR_VISION_ANALYSIS);

    return { domSnapshot, screenshotBuffer };
  }

  public async executeVisualClick(x: number, y: number): Promise<void> {
    if (!this.page) throw new Error("Browser not initialized");

    const viewport = this.page.viewportSize();
    if (!viewport || x < 0 || y < 0 || x > viewport.width || y > viewport.height) {
      this.setSyncStatus(SyncStatus.ERROR);
      throw new Error(`Coordinates (${x}, ${y}) are out of viewport bounds.`);
    }

    this.setSyncStatus(SyncStatus.ACTION_EXECUTING);
    await this.page.mouse.click(x, y);
    this.setSyncStatus(SyncStatus.IDLE);
  }

  public getSyncStatus(): SyncStatus {
    const int32View = new Int32Array(this.state.sharedBuffer);
    return Atomics.load(int32View, this.state.statusIndex) as SyncStatus;
  }

  public setSyncStatus(status: SyncStatus): void {
    const int32View = new Int32Array(this.state.sharedBuffer);
    Atomics.store(int32View, this.state.statusIndex, status);
    Atomics.notify(int32View, this.state.statusIndex);
  }
}
