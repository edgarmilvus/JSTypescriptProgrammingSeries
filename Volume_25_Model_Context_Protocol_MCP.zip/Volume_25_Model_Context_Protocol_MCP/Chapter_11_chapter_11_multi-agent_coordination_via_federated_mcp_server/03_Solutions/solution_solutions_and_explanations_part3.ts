/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import * as crypto from "crypto";

export const AgentRoleSchema = z.enum([
  "supervisor",
  "worker_researcher",
  "worker_executor",
  "auditor",
]);

export type AgentRole = z.infer<typeof AgentRoleSchema>;

export interface AgentContext {
  agentId: string;
  role: AgentRole;
  permissions: string[]; // Allowed tool name patterns, e.g., ["browser:*", "db:read"]
}

export interface AuditLogEntry {
  sequenceId: number;
  timestamp: number;
  agentId: string;
  role: AgentRole;
  toolName: string;
  payloadHash: string;
  previousHash: string;
  signature: string;
}

export class AuditLogChain {
  private chain: AuditLogEntry[] = [];

  public appendEntry(entryData: Omit<AuditLogEntry, "sequenceId" | "previousHash" | "signature">): AuditLogEntry {
    const sequenceId = this.chain.length + 1;
    const previousEntry = this.chain[this.chain.length - 1];
    const previousHash = previousEntry ? this.computeEntryHash(previousEntry) : "0".repeat(64);

    const rawString = `${sequenceId}:${entryData.timestamp}:${entryData.agentId}:${entryData.toolName}:${entryData.payloadHash}:${previousHash}`;
    const signature = crypto.createHmac("sha256", "enterprise-audit-secret").update(rawString).digest("hex");

    const newEntry: AuditLogEntry = {
      ...entryData,
      sequenceId,
      previousHash,
      signature,
    };

    this.chain.push(newEntry);
    return newEntry;
  }

  public verifyIntegrity(): boolean {
    for (let i = 0; i < this.chain.length; i++) {
      const current = this.chain[i];
      const expectedPrevHash = i === 0 ? "0".repeat(64) : this.computeEntryHash(this.chain[i - 1]);

      if (current.previousHash !== expectedPrevHash) {
        return false;
      }

      const rawString = `${current.sequenceId}:${current.timestamp}:${current.agentId}:${current.toolName}:${current.payloadHash}:${current.previousHash}`;
      const expectedSignature = crypto.createHmac("sha256", "enterprise-audit-secret").update(rawString).digest("hex");

      if (current.signature !== expectedSignature) {
        return false;
      }
    }
    return true;
  }

  private computeEntryHash(entry: AuditLogEntry): string {
    return crypto.createHash("sha256").update(JSON.stringify(entry)).digest("hex");
  }
}

export class GovernanceMiddleware {
  constructor(private auditChain: AuditLogChain) {}

  public async evaluateToolCall(
    context: AgentContext,
    toolName: string,
    args: Record<string, unknown>
  ): Promise<boolean> {
    const isAllowed = context.permissions.some((pattern) => {
      const regex = new RegExp(`^${pattern.replace("*", ".*")}$`);
      return regex.test(toolName);
    });

    const payloadHash = crypto.createHash("sha256").update(JSON.stringify(args)).digest("hex");

    this.auditChain.appendEntry({
      timestamp: Date.now(),
      agentId: context.agentId,
      role: context.role,
      toolName,
      payloadHash,
    });

    if (!isAllowed && context.role !== "supervisor") {
      return false;
    }

    return true;
  }
}
