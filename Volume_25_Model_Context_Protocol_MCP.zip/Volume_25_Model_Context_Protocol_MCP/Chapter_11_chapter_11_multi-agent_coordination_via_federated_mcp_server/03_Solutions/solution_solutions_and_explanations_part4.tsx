/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";

export type TelemetryMessage =
  | { type: "SERVER_REGISTERED"; payload: { id: string; baseUrl: string; transportType: string } }
  | { type: "TOOL_EXECUTION_STARTED"; payload: { agentId: string; toolName: string; timestamp: number } }
  | { type: "TOOL_EXECUTION_COMPLETED"; payload: { agentId: string; toolName: string; durationMs: number; success: boolean } }
  | { type: "POLICY_VIOLATION_ALERT"; payload: { agentId: string; reason: string; severity: "HIGH" | "CRITICAL" } };

interface DashboardProps {
  websocketEndpoint: string;
  initialAuthToken: string;
}

export const FederatedAgentDashboard: React.FC<DashboardProps> = ({
  websocketEndpoint,
  initialAuthToken,
}) => {
  const [servers, setServers] = useState<Map<string, any>>(new Map());
  const [activeWorkflows, setActiveWorkflows] = useState<any[]>([]);
  const [auditStream, setAuditStream] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<"CONNECTING" | "CONNECTED" | "DISCONNECTED">("CONNECTING");

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttempts = useRef(0);

  useEffect(() => {
    let isMounted = true;

    const connectWebSocket = () => {
      setConnectionStatus("CONNECTING");
      const ws = new WebSocket(`${websocketEndpoint}?token=${initialAuthToken}`);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!isMounted) return;
        setConnectionStatus("CONNECTED");
        reconnectAttempts.current = 0;
      };

      ws.onmessage = (event) => {
        if (!isMounted) return;
        try {
          const message: TelemetryMessage = JSON.parse(event.data);
          switch (message.type) {
            case "SERVER_REGISTERED":
              setServers((prev) => new Map(prev.set(message.payload.id, message.payload)));
              break;
            case "TOOL_EXECUTION_STARTED":
              setActiveWorkflows((prev) => [...prev, message.payload]);
              break;
            case "TOOL_EXECUTION_COMPLETED":
              setActiveWorkflows((prev) => prev.filter((w) => w.agentId !== message.payload.agentId));
              setAuditStream((prev) => [message.payload, ...prev]);
              break;
            case "POLICY_VIOLATION_ALERT":
              setAuditStream((prev) => [message.payload, ...prev]);
              break;
          }
        } catch (err) {
          console.error("Failed to parse telemetry message", err);
        }
      };

      ws.onclose = () => {
        if (!isMounted) return;
        setConnectionStatus("DISCONNECTED");
        const timeout = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
        reconnectAttempts.current += 1;
        setTimeout(connectWebSocket, timeout);
      };
    };

    connectWebSocket();

    return () => {
      isMounted = false;
      wsRef.current?.close();
    };
  }, [websocketEndpoint, initialAuthToken]);

  const handleRevokeToken = useCallback(async (agentId: string) => {
    try {
      await fetch(`/api/agents/${agentId}/revoke`, {
        method: "POST",
        headers: { Authorization: `Bearer ${initialAuthToken}` },
      });
      setActiveWorkflows((prev) => prev.filter((w) => w.agentId !== agentId));
    } catch (err) {
      console.error(`Failed to revoke token for agent ${agentId}`, err);
    }
  }, [initialAuthToken]);

  const memoizedAuditSummary = useMemo(() => {
    const totalViolations = auditStream.filter((item) => item.severity || !item.success).length;
    const completedItems = auditStream.filter((item) => item.durationMs);
    const avgLatencyMs = completedItems.length > 0
      ? completedItems.reduce((acc, curr) => acc + curr.durationMs, 0) / completedItems.length
      : 0;
    return { totalViolations, avgLatencyMs };
  }, [auditStream]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 min-h-screen font-sans">
      <header className="flex justify-between items-center mb-6 border-b border-slate-700 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">Federated MCP Agent Control Plane</h1>
        <div className="flex items-center space-x-2">
          <span
            className={`inline-block w-3 h-3 rounded-full ${
              connectionStatus === "CONNECTED"
                ? "bg-emerald-500 animate-pulse"
                : connectionStatus === "CONNECTING"
                ? "bg-amber-500"
                : "bg-rose-500"
            }`}
          />
          <span className="text-sm font-medium uppercase">{connectionStatus}</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Registry Servers ({servers.size})</h2>
          <ul className="space-y-2">
            {Array.from(servers.values()).map((server) => (
              <li key={server.id} className="p-2 bg-slate-700 rounded text-sm">
                <div className="font-mono text-xs text-indigo-300">{server.id}</div>
                <div>{server.baseUrl} ({server.transportType})</div>
              </li>
            ))}
          </ul>
        </section>

        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Active ReAct Workflows ({activeWorkflows.length})</h2>
          <ul className="space-y-2">
            {activeWorkflows.map((workflow, idx) => (
              <li key={idx} className="p-2 bg-slate-700 rounded text-sm flex justify-between items-center">
                <div>
                  <div className="font-mono text-xs">{workflow.agentId}</div>
                  <div className="text-xs text-slate-300">{workflow.toolName}</div>
                </div>
                <button
                  onClick={() => handleRevokeToken(workflow.agentId)}
                  className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-xs rounded text-white"
                >
                  Revoke
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Governance Audit Stream</h2>
          <div className="text-xs text-slate-400 mb-2">
            Violations: {memoizedAuditSummary.totalViolations} | Avg Latency: {memoizedAuditSummary.avgLatencyMs.toFixed(1)}ms
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {auditStream.map((item, idx) => (
              <div key={idx} className="p-2 bg-slate-700 rounded text-xs">
                <span className="font-mono">{item.agentId || item.toolName}</span> - Status: {item.success !== false ? "SUCCESS" : "ALERT"}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default FederatedAgentDashboard;
