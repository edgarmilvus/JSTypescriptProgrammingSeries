/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END } from "@langchain/langgraph";
import { z } from "zod";

export const WorkerOutputSchema = z.object({
  workerId: z.string(),
  thought: z.string(),
  actionTaken: z.string(),
  observationResult: z.any(),
  confidenceScore: z.number().min(0).max(1),
});

export type WorkerOutput = z.infer<typeof WorkerOutputSchema>;

export interface ConsensusGraphState {
  taskDescription: string;
  currentRound: number;
  maxRounds: number;
  workerOutputs: WorkerOutput[];
  consensusReached: boolean;
  finalSynthesizedAnswer: string | null;
  errorLog: string[];
}

export const consensusGraphChannels = {
  taskDescription: null,
  currentRound: {
    value: (x: number, y: number) => y ?? x,
    default: () => 1,
  },
  maxRounds: {
    value: (x: number, y: number) => y ?? x,
    default: () => 3,
  },
  workerOutputs: {
    value: (x: WorkerOutput[], y: WorkerOutput[]) => [...x, ...y],
    default: () => [],
  },
  consensusReached: {
    value: (x: boolean, y: boolean) => y ?? x,
    default: () => false,
  },
  finalSynthesizedAnswer: {
    value: (x: string | null, y: string | null) => y ?? x,
    default: () => null,
  },
  errorLog: {
    value: (x: string[], y: string[]) => [...x, ...y],
    default: () => [],
  },
};

export async function supervisorReviewNode(state: ConsensusGraphState): Promise<Partial<ConsensusGraphState>> {
  const recentOutputs = state.workerOutputs.slice(-2); // Evaluate latest round outputs
  if (recentOutputs.length === 0) {
    return { errorLog: ["No worker outputs found for review."] };
  }

  const avgConfidence = recentOutputs.reduce((acc, curr) => acc + curr.confidenceScore, 0) / recentOutputs.length;
  const threshold = 0.85;

  if (avgConfidence >= threshold) {
    return {
      consensusReached: true,
      finalSynthesizedAnswer: JSON.stringify(recentOutputs.map((o) => o.observationResult)),
    };
  }

  if (state.currentRound >= state.maxRounds) {
    return {
      consensusReached: false,
      finalSynthesizedAnswer: "Max retry rounds reached without quorum consensus.",
      errorLog: [`Consensus failed after ${state.maxRounds} rounds due to low confidence (${avgConfidence}).`],
    };
  }

  return {
    consensusReached: false,
    currentRound: state.currentRound + 1,
  };
}

export async function conflictResolutionNode(state: ConsensusGraphState): Promise<Partial<ConsensusGraphState>> {
  return {
    errorLog: [`Initiating conflict resolution for round ${state.currentRound}. Adjusting parameters for re-evaluation.`],
    workerOutputs: [], // Clear previous outputs for fresh re-execution
  };
}

export function shouldContinue(state: ConsensusGraphState): string {
  if (state.consensusReached || state.currentRound > state.maxRounds) {
    return END;
  }
  return "conflictResolution";
}

export function createConsensusWorkflow() {
  const workflow = new StateGraph({ channels: consensusGraphChannels })
    .addNode("supervisorReview", supervisorReviewNode)
    .addNode("conflictResolution", conflictResolutionNode)
    .addEdge("conflictResolution", END) // Or route back to workers in a full cyclic graph
    .addConditionalEdges("supervisorReview", shouldContinue);

  return workflow.compile();
}
