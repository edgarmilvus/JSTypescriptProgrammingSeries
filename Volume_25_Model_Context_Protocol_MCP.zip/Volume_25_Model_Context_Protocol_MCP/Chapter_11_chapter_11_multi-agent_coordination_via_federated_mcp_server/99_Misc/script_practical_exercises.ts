/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { WebSocketClientTransport } from "@modelcontextprotocol/sdk/client/websocket.js";
import { z } from "zod";

// Define schema for federated server metadata
export const ToolCapabilitySchema = z.object({
  name: z.string(),
  description: z.string(),
  inputSchema: z.record(z.any()),
});

export const FederatedServerMetadataSchema = z.object({
  id: z.string().uuid(),
  transportType: z.enum(["websocket", "sse"]),
  baseUrl: z.string().url(),
  protocolVersion: z.string(),
  capabilities: z.array(ToolCapabilitySchema),
  lastHeartbeat: z.number(),
});

export type FederatedServerMetadata = z.infer<typeof FederatedServerMetadataSchema>;

export class ServerUnreachableError extends Error {
  constructor(serverId: string, message: string) {
    super(`Server ${serverId} is unreachable: ${message}`);
    this.name = "ServerUnreachableError";
  }
}

export class RegistryManager {
  private registry: Map<string, FederatedServerMetadata> = new Map();

  public registerServer(meta: FederatedServerMetadata): void {
    // TODO: Implement validation and registration logic
    throw new Error("Not implemented");
  }

  public deregisterServer(id: string): void {
    // TODO: Implement cleanup logic
    throw new Error("Not implemented");
  }

  public async discoverCapabilities(toolNamePattern: string): Promise<FederatedServerMetadata[]> {
    // TODO: Implement filtering logic based on tool capabilities
    throw new Error("Not implemented");
  }
}

export class FederatedMCPClient {
  private clientInstance: Client | null = null;

  constructor(private metadata: FederatedServerMetadata) {}

  public async initializeConnection(): Promise<void> {
    // TODO: Implement dynamic transport instantiation (WebSocket vs SSE)
    // with a 1500ms handshake timeout, throwing ServerUnreachableError if failed.
    throw new Error("Not implemented");
  }

  public async callTool<TInput, TOutput>(toolName: string, args: TInput): Promise<TOutput> {
    // TODO: Route tool execution to the connected transport client
    throw new Error("Not implemented");
  }
}
