/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { z } from "zod";
import * as crypto from "crypto";

export const AgentRoleSchema = z.enum([
  "supervisor",
  "worker_researcher",
  "worker_executor",
  "auditor",
]);

export type AgentRole = z.infer<typeof AgentRoleSchema>;

export interface AgentContext {
  agentId: string;
  role: AgentRole;
  permissions: string[]; // Allowed tool name patterns, e.g., ["browser:*", "db:read"]
}

export interface AuditLogEntry {
  sequenceId: number;
  timestamp: number;
  agentId: string;
  role: AgentRole;
  toolName: string;
  payloadHash: string;
  previousHash: string;
  signature: string;
}

export class AuditLogChain {
  private chain: AuditLogEntry[] = [];

  public appendEntry(entryData: Omit<AuditLogEntry, "sequenceId" | "previousHash" | "signature">): AuditLogEntry {
    // TODO: Compute cryptographic hash chain, sign entry, and push to chain.
    throw new Error("Not implemented");
  }

  public verifyIntegrity(): boolean {
    // TODO: Iterate through chain and verify cryptographic hashes match.
    throw new Error("Not implemented");
  }
}

export class GovernanceMiddleware {
  constructor(private auditChain: AuditLogChain) {}

  public async evaluateToolCall(
    context: AgentContext,
    toolName: string,
    args: Record<string, unknown>
  ): Promise<boolean> {
    // TODO: Validate agent role against requested toolName, check rate limits,
    // generate audit log entry, and return true if allowed, false otherwise.
    throw new Error("Not implemented");
  }
}
