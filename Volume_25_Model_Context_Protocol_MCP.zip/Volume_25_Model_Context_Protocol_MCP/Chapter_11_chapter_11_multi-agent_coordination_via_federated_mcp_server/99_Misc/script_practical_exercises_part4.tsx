/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect, useCallback, useMemo } from "react";

// Define Discriminated Unions for WebSocket Telemetry Payloads
export type TelemetryMessage =
  | { type: "SERVER_REGISTERED"; payload: { id: string; baseUrl: string; transportType: string } }
  | { type: "TOOL_EXECUTION_STARTED"; payload: { agentId: string; toolName: string; timestamp: number } }
  | { type: "TOOL_EXECUTION_COMPLETED"; payload: { agentId: string; toolName: string; durationMs: number; success: boolean } }
  | { type: "POLICY_VIOLATION_ALERT"; payload: { agentId: string; reason: string; severity: "HIGH" | "CRITICAL" } };

interface DashboardProps {
  websocketEndpoint: string;
  initialAuthToken: string;
}

export const FederatedAgentDashboard: React.FC<DashboardProps> = ({
  websocketEndpoint,
  initialAuthToken,
}) => {
  const [servers, setServers] = useState<Map<string, any>>(new Map());
  const [activeWorkflows, setActiveWorkflows] = useState<any[]>([]);
  const [auditStream, setAuditStream] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<"CONNECTING" | "CONNECTED" | "DISCONNECTED">("CONNECTING");

  // TODO: Implement WebSocket connection lifecycle with exponential backoff reconnection
  useEffect(() => {
    // Implement WS connection, message parsing, and cleanup on unmount
  }, [websocketEndpoint, initialAuthToken]);

  const handleRevokeToken = useCallback(async (agentId: string) => {
    // TODO: Dispatch API call to revoke agent token and update UI state
  }, []);

  const memoizedAuditSummary = useMemo(() => {
    // TODO: Calculate high-level metrics (total violations, average latency)
    return { totalViolations: 0, avgLatencyMs: 0 };
  }, [auditStream]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 min-h-screen font-sans">
      <header className="flex justify-between items-center mb-6 border-b border-slate-700 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">Federated MCP Agent Control Plane</h1>
        <div className="flex items-center space-x-2">
          <span
            className={`inline-block w-3 h-3 rounded-full ${
              connectionStatus === "CONNECTED"
                ? "bg-emerald-500 animate-pulse"
                : connectionStatus === "CONNECTING"
                ? "bg-amber-500"
                : "bg-rose-500"
            }`}
          />
          <span className="text-sm font-medium uppercase">{connectionStatus}</span>
        </div>
      </header>

      {/* TODO: Render Registry Overview, Active Workflows, and Audit Stream panels */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Registry Servers</h2>
          {/* Server list implementation */}
        </section>

        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Active ReAct Workflows</h2>
          {/* Workflow list implementation */}
        </section>

        <section className="bg-slate-800 p-4 rounded-lg shadow-md border border-slate-700">
          <h2 className="text-lg font-semibold mb-3">Governance Audit Stream</h2>
          {/* Audit stream table implementation */}
        </section>
      </div>
    </div>
  );
};

export default FederatedAgentDashboard;
