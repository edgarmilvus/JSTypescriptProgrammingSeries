/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file distributed-automation.ts
 * @description Enterprise Next.js API Route for Distributed Browser Automation with MCP & CRDT Sync.
 * Implements parallel tool execution, immutable state management, and real-time session synchronization.
 */

import { NextResponse } from 'next/router';
import type { NextApiRequest, NextApiResponse } from 'next';
import { EventEmitter } from 'events';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

export type AgentStatus = 'IDLE' | 'EXECUTING' | 'SYNCING' | 'ERROR' | 'COMPLETED';

export interface BrowserContextState {
  sessionId: string;
  url: string;
  domSnapshotHash: string;
  vectorClock: Record<string, number>;
  extractedData: Record<string, unknown>;
  status: AgentStatus;
}

export interface MCPToolCall {
  toolId: string;
  arguments: Record<string, unknown>;
}

export interface MCPToolResult {
  toolId: string;
  success: boolean;
  data?: unknown;
  error?: string;
  executionTimeMs: number;
}

// Global distributed event bus for cross-node replication simulation
class DistributedEventBus extends EventEmitter {}
const globalSyncBus = new DistributedEventBus();

// ==========================================
// 2. CORE IMMUTABLE CRDT STATE MANAGER
// ==========================================

/**
 * Manages the browser automation session state using an immutable paradigm
 * combined with a vector clock to resolve distributed conflict resolution.
 */
class DistributedStateManager {
  private state: BrowserContextState;
  private readonly nodeId: string;

  constructor(sessionId: string, nodeId: string) {
    this.nodeId = nodeId;
    this.state = {
      sessionId,
      url: 'about:blank',
      domSnapshotHash: '',
      vectorClock: { [nodeId]: 1 },
      extractedData: {},
      status: 'IDLE',
    };
  }

  /**
   * Returns a deeply frozen, immutable copy of the current state.
   */
  public getState(): Readonly<BrowserContextState> {
    return Object.freeze(JSON.parse(JSON.stringify(this.state)));
  }

  /**
   * Applies an immutable state transition incrementing the vector clock.
   */
  public commitTransition(partialUpdate: Partial<BrowserContextState>): Readonly<BrowserContextState> {
    const currentClock = this.state.vectorClock[this.nodeId] || 0;
    
    this.state = Object.freeze({
      ...this.state,
      ...partialUpdate,
      vectorClock: {
        ...this.state.vectorClock,
        [this.nodeId]: currentClock + 1,
      },
    });

    // Broadcast state update across the distributed network layer
    globalSyncBus.emit('state-replicated', this.getState());
    return this.getState();
  }

  /**
   * Merges remote states via Last-Write-Wins (LWW) vector clock comparison.
   */
  public mergeRemoteState(remoteState: BrowserContextState): Readonly<BrowserContextState> {
    const localClock = this.state.vectorClock[this.nodeId] || 0;
    const remoteNodeId = Object.keys(remoteState.vectorClock).find(id => id !== this.nodeId) || 'remote';
    const remoteClock = remoteState.vectorClock[remoteNodeId] || 0;

    // Vector clock conflict resolution check
    if (remoteClock >= localClock) {
      this.state = Object.freeze({
        ...remoteState,
        vectorClock: {
          ...this.state.vectorClock,
          [remoteNodeId]: remoteClock,
          [this.nodeId]: localClock,
        },
      });
    }
    return this.getState();
  }
}

// ==========================================
// 3. PARALLEL MCP TOOL EXECUTION ENGINE
// ==========================================

/**
 * Simulates executing multiple independent browser interaction tools
 * concurrently using Promise.allSettled for fault-tolerant batch execution.
 */
async function executeParallelMCPTools(
  tools: MCPToolCall[],
  stateManager: DistributedStateManager
): Promise<MCPToolResult[]> {
  stateManager.commitTransition({ status: 'EXECUTING' });

  // Map each tool call to a concurrent async execution promise
  const executionPromises = tools.map(async (tool): Promise<MCPToolResult> => {
    const startTime = Date.now();
    try {
      // Simulate network roundtrip to isolated MCP execution containers
      await new Promise((resolve) => setTimeout(resolve, Math.random() * 200 + 100));

      if (tool.toolId === 'fail_test') {
        throw new Error('Simulated MCP Tool Execution Failure');
      }

      return {
        toolId: tool.toolId,
        success: true,
        data: { actedUpon: tool.arguments.selector || 'body', timestamp: Date.now() },
        executionTimeMs: Date.now() - startTime,
      };
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      return {
        toolId: tool.toolId,
        success: false,
        error: errorMessage,
        executionTimeMs: Date.now() - startTime,
      };
    }
  });

  const results = await Promise.all(executionPromises);
  stateManager.commitTransition({ status: 'SYNCING' });
  return results;
}

// ==========================================
// 4. NEXT.JS API HANDLER ROUTE
// ==========================================

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }

  const { sessionId, targetUrl, tools } = req.body;

  if (!sessionId || !targetUrl || !Array.isArray(tools)) {
    return res.status(400).json({ error: 'Missing required parameters: sessionId, targetUrl, tools[]' });
  }

  const workerNodeId = `node_${process.pid}_${Date.now()}`;
  const stateManager = new DistributedStateManager(sessionId, workerNodeId);

  // Listen to simulated cluster replication events
  const syncListener = (replicatedState: BrowserContextState) => {
    if (replicatedState.sessionId === sessionId && replicatedState.vectorClock[workerNodeId] === undefined) {
      stateManager.mergeRemoteState(replicatedState);
    }
  };
  globalSyncBus.on('state-replicated', syncListener);

  try {
    // 1. Initialize session state
    stateManager.commitTransition({ url: targetUrl, status: 'IDLE' });

    // 2. Execute parallel tool calls via MCP integration layer
    const toolResults = await executeParallelMCPTools(tools, stateManager);

    // 3. Aggregate successful extractions into immutable context
    const successfulData = toolResults
      .filter((r) => r.success)
      .reduce((acc, curr) => ({ ...acc, [curr.toolId]: curr.data }), {});

    const finalState = stateManager.commitTransition({
      extractedData: successfulData,
      domSnapshotHash: `sha256_${Math.random().toString(36).substring(7)}`,
      status: 'COMPLETED',
    });

    // Clean up event listener
    globalSyncBus.off('state-replicated', syncListener);

    return res.status(200).json({
      success: true,
      nodeId: workerNodeId,
      results: toolResults,
      state: finalState,
    });
  } catch (error: unknown) {
    globalSyncBus.off('state-replicated', syncListener);
    const message = error instanceof Error ? error.message : 'Internal Server Error';
    stateManager.commitTransition({ status: 'ERROR' });
    return res.status(500).json({ success: false, error: message });
  }
}
