/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';
import { randomUUID } from 'crypto';

export class DistributedLockManager {
  private redis: Redis;

  constructor(redisUrl: string) {
    this.redis = new Redis(redisUrl);
  }

  /**
   * Acquires an exclusive lease on a specific resource key.
   */
  async acquireLock(resourceKey: string, ttlMs: number): Promise<string | null> {
    const token = randomUUID();
    // Using 'PX' for millisecond precision and 'NX' to ensure the key is set only if it does not exist.
    const result = await this.redis.set(resourceKey, token, 'PX', ttlMs, 'NX');
    return result === 'OK' ? token : null;
  }

  /**
   * Safely releases the lock using an atomic Lua script to verify token ownership.
   */
  async releaseLock(resourceKey: string, token: string): Promise<boolean> {
    const luaScript = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
      else
        return 0
      end
    `;
    const result = await this.redis.eval(luaScript, 1, resourceKey, token);
    return result === 1;
  }

  /**
   * Wrapper executing an operation under a distributed lock with automatic retries and exponential backoff.
   */
  async withLock<T>(
    resourceKey: string,
    ttlMs: number,
    operation: () => Promise<T>,
    maxRetries: number = 3,
    baseDelayMs: number = 200
  ): Promise<T> {
    let attempt = 0;
    let token: string | null = null;

    while (attempt < maxRetries) {
      token = await this.acquireLock(resourceKey, ttlMs);
      if (token) {
        break;
      }
      attempt++;
      if (attempt >= maxRetries) {
        throw new Error(`Failed to acquire lock for resource: ${resourceKey} after ${maxRetries} attempts.`);
      }
      // Exponential backoff with jitter
      const delay = baseDelayMs * Math.pow(2, attempt) + Math.random() * 50;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }

    if (!token) {
      throw new Error(`Critical error: Lock acquired without a valid token for ${resourceKey}`);
    }

    try {
      return await operation();
    } finally {
      await this.releaseLock(resourceKey, token).catch((err) => {
        console.error(`Failed to release lock for ${resourceKey}:`, err);
      });
    }
  }
}
