/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';

export class StateReplicator {
  private redis: Redis;
  private streamKey: string;
  private groupName: string;
  private consumerName: string;

  constructor(redis: Redis, streamKey: string, groupName: string, consumerName: string) {
    this.redis = redis;
    this.streamKey = streamKey;
    this.groupName = groupName;
    this.consumerName = consumerName;
  }

  async startListening(
    onEvent: (eventId: string, data: Record<string, string>) => Promise<void>
  ): Promise<void> {
    // Ensure consumer group exists (ignoring error if it already exists)
    try {
      await this.redis.xgroup('CREATE', this.streamKey, this.groupName, '0', 'MKSTREAM');
    } catch (err: any) {
      if (!err.message.includes('BUSYGROUP')) {
        throw err;
      }
    }

    while (true) {
      try {
        const response = await this.redis.xreadgroup(
          'GROUP',
          this.groupName,
          this.consumerName,
          'COUNT',
          10,
          'BLOCK',
          5000,
          'STREAMS',
          this.streamKey,
          '>'
        );

        if (response) {
          for (const [_, messages] of response as [string, [string, string[]][]][]) {
            for (const [eventId, rawFields] of messages) {
              // Convert Redis flat array response into a Record object
              const data: Record<string, string> = {};
              for (let i = 0; i < rawFields.length; i += 2) {
                data[rawFields[i]] = rawFields[i + 1];
              }

              try {
                // Process event through the application handler
                await onEvent(eventId, data);
                
                // Explicitly acknowledge successful processing to remove from pending entries list (PEL)
                await this.redis.xack(this.streamKey, this.groupName, eventId);
              } catch (processingError) {
                console.error(`Error processing event ${eventId}:`, processingError);
                // Message remains in PEL for subsequent claim/retry procedures
              }
            }
          }
        }
      } catch (networkError) {
        console.error('Redis stream reading error:', networkError);
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
    }
  }
}
