/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

interface WorkerNode {
  id: string;
  status: 'IDLE' | 'BUSY' | 'LOCKED' | 'ERROR';
  currentTask: string;
}

interface DashboardProps {
  workers: WorkerNode[];
  onSyncWorker: (workerId: string) => Promise<void>;
}

export const AgentClusterDashboard: React.FC<DashboardProps> = ({ workers, onSyncWorker }) => {
  const [isPending, startTransition] = useTransition();
  const [activeSyncingId, setActiveSyncingId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSyncClick = (workerId: string) => {
    setActiveSyncingId(workerId);
    setErrorMessage(null);

    startTransition(async () => {
      try {
        await onSyncWorker(workerId);
      } catch (err: any) {
        setErrorMessage(`Failed to sync worker ${workerId}: ${err.message || 'Unknown error'}`);
      } finally {
        setActiveSyncingId(null);
      }
    });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Supervisor Node & Worker Pool Status</h2>
      
      {errorMessage && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
          {errorMessage}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {workers.map((worker) => {
          const isCurrentWorkerSyncing = isPending && activeSyncingId === worker.id;
          
          return (
            <div key={worker.id} className="border p-4 rounded-lg shadow bg-white">
              <h3 className="font-semibold text-lg">Worker: {worker.id}</h3>
              <p className="text-sm text-gray-600">Status: <span className="font-medium">{worker.status}</span></p>
              <p className="text-sm text-gray-600 mb-4">Task: {worker.currentTask}</p>
              
              <button
                onClick={() => handleSyncClick(worker.id)}
                disabled={isCurrentWorkerSyncing}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50 transition-colors flex items-center justify-center w-full"
              >
                {isCurrentWorkerSyncing ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Syncing State...
                  </>
                ) : (
                  'Force Sync State'
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
