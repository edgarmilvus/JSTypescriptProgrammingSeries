/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useTransition } from 'react';

interface WorkerNode {
  id: string;
  status: 'IDLE' | 'BUSY' | 'LOCKED' | 'ERROR';
  currentTask: string;
}

interface DashboardProps {
  workers: WorkerNode[];
  onSyncWorker: (workerId: string) => Promise<void>;
}

export const AgentClusterDashboard: React.FC<DashboardProps> = ({ workers, onSyncWorker }) => {
  const [isPending, startTransition] = useTransition();
  const [activeSyncingId, setActiveSyncingId] = useState<string | null>(null);

  const handleSyncClick = (workerId: string) => {
    setActiveSyncingId(workerId);
    // TODO: Wrap the asynchronous sync call inside startTransition
    // and reset the activeSyncingId once complete.
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Supervisor Node & Worker Pool Status</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {workers.map((worker) => (
          <div key={worker.id} className="border p-4 rounded-lg shadow">
            <h3 className="font-semibold">Worker: {worker.id}</h3>
            <p className="text-sm text-gray-600">Status: {worker.status}</p>
            <p className="text-sm text-gray-600 mb-4">Task: {worker.currentTask}</p>
            <button
              onClick={() => handleSyncClick(worker.id)}
              disabled={isPending && activeSyncingId === worker.id}
              className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
            >
              {isPending && activeSyncingId === worker.id ? 'Syncing...' : 'Force Sync State'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
