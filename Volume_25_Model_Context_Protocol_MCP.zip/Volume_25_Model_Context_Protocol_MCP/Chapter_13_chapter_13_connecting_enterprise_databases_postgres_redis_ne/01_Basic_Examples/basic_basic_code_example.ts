/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import pkg from 'pg';
const { Pool } = pkg;

/**
 * SaaS Analytics Database MCP Server
 * 
 * This self-contained TypeScript server establishes a secure, read-only bridge 
 * between an AI agent and an enterprise Postgres database. It enforces 
 * parameterized queries to prevent SQL injection and restricts operations 
 * to analytical introspection.
 */

// 1. Initialize the PostgreSQL connection pool using environment variables
const dbPool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://saas_user:secure_password@localhost:5432/saas_analytics",
  max: 5, // Limit concurrent connections for resource governance
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// 2. Instantiate the MCP Server with metadata identifying its scope and capabilities
const server = new Server(
  {
    name: "saas-postgres-analytics-mcp",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

/**
 * 3. Define the tools exposed to the connected MCP client/agent.
 * Here we provide a single, highly constrained tool for executing safe SELECT queries
 * against subscription metrics.
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "query_subscription_metrics",
        description: "Executes a read-only SQL query against the SaaS subscription metrics table. Only SELECT statements are permitted. Tables available: subscriptions, plans, users.",
        inputSchema: {
          type: "object",
          properties: {
            sqlQuery: {
              type: "string",
              description: "A valid PostgreSQL SELECT statement targeting public SaaS tables.",
            },
          },
          required: ["sqlQuery"],
        },
      },
    ],
  };
});

/**
 * 4. Handle tool execution requests from the agent.
 * Implements strict security validations, checking for read-only constraints 
 * before passing the query to the Postgres connection pool.
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name !== "query_subscription_metrics") {
    throw new Error(`Unknown tool: ${request.params.name}`);
  }

  const args = request.params.arguments as { sqlQuery?: string };
  const sqlQuery = args?.sqlQuery;

  if (!sqlQuery || typeof sqlQuery !== "string") {
    throw new Error("Invalid arguments: 'sqlQuery' string is required.");
  }

  // Governance Check 1: Enforce Read-Only Execution Mode
  const sanitizedQuery = sqlQuery.trim().toLowerCase();
  if (!sanitizedQuery.startsWith("select")) {
    throw new Error("Governance Policy Violation: Only read-only 'SELECT' statements are permitted through this MCP server.");
  }

  // Governance Check 2: Block destructive SQL keywords in the body
  const forbiddenKeywords = [; "drop", "delete", "insert", "update", "alter", "truncate", "grant", "revoke", "exec", "execute" ];
  for (const keyword of forbiddenKeywords) {
    // Basic word-boundary check to prevent injection via subqueries
    const regex = new RegExp(`\\b${keyword}\\b`, "i");
    if (regex.test(sanitizedQuery)) {
      throw new Error(`Governance Policy Violation: Forbidden SQL keyword detected: '${keyword}'.`);
    }
  }

  // Execute the validated query against the database pool
  const client = await dbPool.connect();
  try {
    // Set a statement timeout to prevent runaway agent queries (e.g., 5 seconds)
    await client.query("SET statement_timeout = 5000;");
    
    const result = await client.query(sqlQuery);

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({
            rowCount: result.rowCount,
            rows: result.rows,
          }, null, 2),
        },
      ],
    };
  } catch (error: any) {
    // Return structured error back to the agent so it can self-correct its query syntax
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({
            error: true,
            message: error.message,
          }, null, 2),
        },
      ],
      isError: true,
    };
  } finally {
    // Always release the client back to the pool
    client.release();
  }
});

/**
 * 5. Start the MCP server using standard input/output (stdio) transport.
 * This allows containerized or host-managed AI runtimes to communicate securely with the server process.
 */
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("SaaS Postgres Analytics MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error in MCP server initialization:", error);
  process.exit(1);
});
