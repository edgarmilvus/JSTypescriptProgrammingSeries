/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { SSEClientTransport } from "@modelcontextprotocol/sdk/client/sse.js";
import { z } from "zod";
import { Pool } from "pg";
import { createClient as createRedisClient } from "redis";
import neo4j, { Driver as Neo4jDriver } from "neo4j-driver";

/**
 * Enterprise Audit Log Event Schema
 */
const AuditLogSchema = z.object({
  timestamp: z.string().datetime(),
  agentId: z.string(),
  databaseType: z.enum(["postgres", "redis", "neo4j"]),
  operation: z.string(),
  queryOrKey: z.string(),
  status: z.enum(["SUCCESS", "DENIED", "ERROR"]),
  executionTimeMs: z.number(),
  errorMessage: z.string().optional(),
});

type AuditLogEvent = z.infer<typeof AuditLogSchema>;

/**
 * Enterprise Database Gateway for MCP Agents.
 * Coordinates multi-database execution with strict security barriers.
 */
export class EnterpriseDatabaseGateway {
  private pgPool: Pool;
  private redisClient: ReturnType<typeof createRedisClient>;
  private neo4jDriver: Neo4jDriver;
  private auditLogBuffer: AuditLogEvent[] = [];

  constructor(
    pgConnectionString: string,
    redisUrl: string,
    neo4jUri: string,
    neo4jUser: string,
    neo4jPass: string
  ) {
    // Initialize PostgreSQL Connection Pool
    this.pgPool = new Pool({
      connectionString: pgConnectionString,
      max: 10,
      idleTimeoutMillis: 30000,
    });

    // Initialize Redis Client
    this.redisClient = createRedisClient({ url: redisUrl });
    this.redisClient.on("error", (err) => console.error("Redis Client Error", err));

    // Initialize Neo4j Driver
    this.neo4jDriver = neo4j.driver(neo4jUri, neo4j.auth.basic(neo4jUser, neo4jPass));
  }

  /**
   * Connects to all underlying database instances.
   */
  public async initialize(): Promise<void> {
    await this.redisClient.connect();
    // Test Postgres connection
    const client = await this.pgPool.connect();
    client.release();
    // Verify Neo4j connectivity
    await this.neo4jDriver.verifyConnectivity();
    console.log("Enterprise Database Gateway successfully initialized.");
  }

  /**
   * Securely executes a read-only query against PostgreSQL with strict parameterization.
   */
  public async executePostgresQuery(
    agentId: string,
    sqlQuery: string,
    params: any[] = []
  ): Promise<any[]> {
    const startTime = Date.now();
    const normalizedQuery = sqlQuery.trim().toUpperCase();

    // Enforce strict read-only execution at the gateway level
    if (!normalizedQuery.startsWith("SELECT") && !normalizedQuery.startsWith("WITH")) {
      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "postgres",
        operation: "WRITE_ATTEMPT",
        queryOrKey: sqlQuery,
        status: "DENIED",
        executionTimeMs: Date.now() - startTime,
        errorMessage: "Write operations strictly forbidden by agent governance policy.",
      });
      throw new Error("Security Violation: Only SELECT/WITH queries are permitted.");
    }

    const client = await this.pgPool.connect();
    try {
      // Set query timeout to prevent denial of service (DoS) via expensive joins
      await client.query("SET LOCAL statement_timeout = '5000';");
      const result = await client.query(sqlQuery, params);

      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "postgres",
        operation: "SELECT",
        queryOrKey: sqlQuery,
        status: "SUCCESS",
        executionTimeMs: Date.now() - startTime,
      });

      return result.rows;
    } catch (error: any) {
      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "postgres",
        operation: "SELECT",
        queryOrKey: sqlQuery,
        status: "ERROR",
        executionTimeMs: Date.now() - startTime,
        errorMessage: error.message,
      });
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Retrieves keys/values from Redis with namespace isolation.
   */
  public async executeRedisGet(agentId: string, key: string): Promise<string | null> {
    const startTime = Date.now();
    // Enforce tenant or agent namespace isolation
    const safeKey = `agent:cache:${key}`;

    try {
      const value = await this.redisClient.get(safeKey);
      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "redis",
        operation: "GET",
        queryOrKey: safeKey,
        status: "SUCCESS",
        executionTimeMs: Date.now() - startTime,
      });
      return value;
    } catch (error: any) {
      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "redis",
        operation: "GET",
        queryOrKey: safeKey,
        status: "ERROR",
        executionTimeMs: Date.now() - startTime,
        errorMessage: error.message,
      });
      throw error;
    }
  }

  /**
   * Executes a read-only Cypher query against Neo4j.
   */
  public async executeNeo4jTraversal(
    agentId: string,
    cypherQuery: string,
    parameters: Record<string, any> = {}
  ): Promise<any[]> {
    const startTime = Date.now();
    const session = this.neo4jDriver.session({ defaultAccessMode: neo4j.session.READ });

    try {
      // Execute within a read transaction context
      const result = await session.executeRead(async (tx) => {
        const res = await tx.run(cypherQuery, parameters);
        return res.records.map((record) => record.toObject());
      });

      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "neo4j",
        operation: "TRAVERSAL",
        queryOrKey: cypherQuery,
        status: "SUCCESS",
        executionTimeMs: Date.now() - startTime,
      });

      return result;
    } catch (error: any) {
      this.logAudit({
        timestamp: new Date().toISOString(),
        agentId,
        databaseType: "neo4j",
        operation: "TRAVERSAL",
        queryOrKey: cypherQuery,
        status: "ERROR",
        executionTimeMs: Date.now() - startTime,
        errorMessage: error.message,
      });
      throw error;
    } finally {
      await session.close();
    }
  }

  /**
   * Internal audit logging mechanism.
   */
  private logAudit(event: AuditLogEvent): void {
    const validated = AuditLogSchema.parse(event);
    this.auditLogBuffer.push(validated);
    // In production, stream this to an external SIEM or persistent log store (e.g., Datadog, AWS CloudWatch)
    console.log(`[AUDIT] [${validated.status}] Agent: ${validated.agentId} | DB: ${validated.databaseType} | Op: ${validated.operation} | Time: ${validated.executionTimeMs}ms`);
  }

  /**
   * Gracefully shuts down all database connections.
   */
  public async close(): Promise<void> {
    await this.pgPool.end();
    await this.redisClient.quit();
    await this.neo4jDriver.close();
    console.log("Enterprise Database Gateway connections closed.");
  }
}
