/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import pg from "pg";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

/**
 * Validates a SQL query string to ensure it is strictly a read-only SELECT statement
 * and catches SQL injection attempts like stacked queries and comment evasion.
 */
export function validateReadonlyQuery(query: string): void {
  const trimmed = query.trim();
  
  // 1. Must start with SELECT (case-insensitive)
  if (!/^select\s/i.test(trimmed)) {
    throw new Error("Security Violation: Only SELECT queries are permitted.");
  }

  // 2. Check for dangerous/mutating keywords as standalone words or statement breaks
  const forbiddenKeywords = /\b(insert|update|delete|drop|alter|truncate|grant|revoke|create|replace)\b/i;
  if (forbiddenKeywords.test(trimmed)) {
    throw new Error("Security Violation: Mutating keywords detected in query.");
  }

  // 3. Prevent stacked queries using semicolons (allowing a single trailing semicolon)
  const cleanedQuery = trimmed.replace(/;\s*$/, "");
  if (cleanedQuery.includes(";")) {
    throw new Error("Security Violation: Stacked queries separated by semicolons are strictly prohibited.");
  }

  // 4. Check for comment-based evasion techniques (-- or /* */)
  if (/(--|\/\*|\*\/)/.test(trimmed)) {
    throw new Error("Security Violation: SQL comments are not allowed to prevent evasion techniques.");
  }
}

const server = new Server(
  { name: "postgres-secure-mcp", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "get_database_schema",
      description: "Returns a token-optimized JSON representation of tables, columns, and foreign keys.",
      inputSchema: { type: "object", properties: {} }
    },
    {
      name: "execute_readonly_query",
      description: "Executes a validated read-only SQL query with forced pagination limits.",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string" },
          limit: { type: "number", default: 50, maximum: 200 }
        },
        required: ["query"]
      }
    }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "get_database_schema") {
    const client = await pool.connect();
    try {
      const query = `
        SELECT 
            t.table_name,
            c.column_name,
            c.data_type,
            c.is_nullable
        FROM information_schema.tables t
        JOIN information_schema.columns c ON t.table_name = c.table_name
        WHERE t.table_schema = 'public' 
          AND t.table_type = 'BASE TABLE'
        ORDER BY t.table_name, c.ordinal_position;
      `;
      const result = await client.query(query);
      return { content: [{ type: "text", text: JSON.stringify(result.rows, null, 2) }] };
    } finally {
      client.release();
    }
  }

  if (name === "execute_readonly_query") {
    const rawQuery = (args as any).query;
    let limit = Math.min(Number((args as any).limit) || 50, 200);

    try {
      validateReadonlyQuery(rawQuery);

      // Enforce hard pagination limit by wrapping or appending limit if missing
      let finalQuery = rawQuery.trim().replace(/;\s*$/, "");
      if (!/\blimit\s+\d+/i.test(finalQuery)) {
        finalQuery = `${finalQuery} LIMIT ${limit}`;
      } else {
        // Ensure user-supplied limit doesn't exceed 200
        finalQuery = finalQuery.replace(/\blimit\s+(\d+)/i, (match, p1) => {
          const userLimit = parseInt(p1, 10);
          return `LIMIT ${Math.min(userLimit, 200)}`;
        });
      }

      const client = await pool.connect();
      try {
        // Set statement timeout to 5 seconds to prevent resource exhaustion
        await client.query("SET statement_timeout = 5000");
        const result = await client.query(finalQuery);
        return { content: [{ type: "text", text: JSON.stringify(result.rows, null, 2) }] };
      } finally {
        client.release();
      }
    } catch (error: any) {
      return { content: [{ type: "text", text: `Error: ${error.message}` }], isError: true };
    }
  }

  throw new Error(`Tool not found: ${name}`);
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

// main().catch(console.error);
