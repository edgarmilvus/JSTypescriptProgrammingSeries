/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import Redis from "ioredis";
import crypto from "crypto";

const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379");

/**
 * Implements a sliding-window rate limiter using Redis sorted sets (ZSET).
 * Ensures a single client does not exceed maxRequests within the windowSizeInSeconds.
 */
export async function checkRateLimit(
  clientId: string,
  currentTimestamp: number,
  maxRequests: number = 30,
  windowSizeInSeconds: number = 60
): Promise<boolean> {
  const key = `ratelimit:${clientId}`;
  const windowStart = currentTimestamp - windowSizeInSeconds * 1000;

  const pipeline = redis.pipeline();
  // Remove expired entries outside the sliding window
  pipeline.zremrangebyscore(key, 0, windowStart);
  // Add current request timestamp
  pipeline.zadd(key, currentTimestamp, `${currentTimestamp}-${Math.random()}`);
  // Count requests in the current window
  pipeline.zcard(key);
  // Set expiry on the rate limit key to clean up idle resources
  pipeline.expire(key, windowSizeInSeconds);

  const results = await pipeline.exec();
  if (!results) return false;

  const requestCount = results[2][1] as number;
  return requestCount <= maxRequests;
}

const redisServer = new Server(
  { name: "redis-state-mcp", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

redisServer.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "set_agent_memory",
      description: "Stores JSON memory payloads with a mandatory TTL.",
      inputSchema: {
        type: "object",
        properties: {
          tenantId: { type: "string" },
          key: { type: "string" },
          value: { type: "string" },
          ttlSeconds: { type: "number", default: 300 }
        },
        required: ["tenantId", "key", "value"]
      }
    },
    {
      name: "get_agent_memory",
      description: "Retrieves memory blocks by namespaced keys.",
      inputSchema: {
        type: "object",
        properties: {
          tenantId: { type: "string" },
          key: { type: "string" }
        },
        required: ["tenantId", "key"]
      }
    },
    {
      name: "cache_query_result",
      description: "Caches large query results and returns a compact reference token.",
      inputSchema: {
        type: "object",
        properties: {
          tenantId: { type: "string" },
          payload: { type: "string" }
        },
        required: ["tenantId", "payload"]
      }
    }
  ]
}));

redisServer.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  const tenantId = (args as any).tenantId;

  if (!tenantId) {
    throw new Error("Unauthorized: tenantId is required for namespace isolation.");
  }

  // Enforce rate limiting per tenant/client
  const allowed = await checkRateLimit(tenantId, Date.now());
  if (!allowed) {
    return { content: [{ type: "text", text: "Rate limit exceeded. Try again later." }], isError: true };
  }

  const namespacedKey = (subKey: string) => `tenant:${tenantId}:${subKey}`;

  if (name === "set_agent_memory") {
    const { key, value, ttlSeconds } = args as any;
    await redis.set(namespacedKey(key), value, "EX", ttlSeconds || 300);
    return { content: [{ type: "text", text: `Memory stored successfully at key: ${key}` }] };
  }

  if (name === "get_agent_memory") {
    const { key } = args as any;
    const data = await redis.get(namespacedKey(key));
    if (!data) {
      return { content: [{ type: "text", text: "Memory key not found or expired." }] };
    }
    return { content: [{ type: "text", text: data }] };
  }

  if (name === "cache_query_result") {
    const { payload } = args as any;
    const hash = crypto.createHash("sha256").update(payload).digest("hex");
    const cacheKey = namespacedKey(`cache:${hash}`);
    
    await redis.set(cacheKey, payload, "EX", 300); // 5-minute TTL
    
    return { 
      content: [{ 
        type: "text", 
        text: JSON.stringify({ referenceToken: `ref:${hash}`, status: "cached", expiresIn: 300 }) 
      }] 
    };
  }

  throw new Error(`Tool not found: ${name}`);
});
