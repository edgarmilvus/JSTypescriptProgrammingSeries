/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import neo4j, { Driver } from "neo4j-driver";

const driver: Driver = neo4j.driver(
  process.env.NEO4J_URI || "bolt://localhost:7687",
  neo4j.auth.basic(process.env.NEO4J_USER || "neo4j", process.env.NEO4J_PASSWORD || "password")
);

/**
 * Parses and rewrites an incoming Cypher query to enforce maximum depth caps
 * on unbounded variable-length relationship patterns and appends limits.
 */
export function sanitizeAndRewriteCypher(query: string): string {
  let sanitized = query.trim();

  // 1. Detect and rewrite unbounded variable-length patterns like -[r*]- or -[r*1..]-
  // Replace with a strict upper-bound cap of depth 3 (-[r*1..3]-)
  const unboundedPattern = /-\s*\[\s*([a-zA-Z0-9_]*\s*\*\s*)\]\s*-/g;
  sanitized = sanitized.replace(unboundedPattern, "-[$1..3]-");

  const unboundedRangePattern = /-\s*\[\s*([a-zA-Z0-9_]*\s*\*\s*\d+\s*\.\.)\s*\]\s*-/g;
  sanitized = sanitized.replace(unboundedRangePattern, "-[$1 3]-");

  // 2. Ensure a LIMIT clause exists (default to 50)
  if (!/\blimit\s+\d+/i.test(sanitized)) {
    sanitized = `${sanitized} LIMIT 50`;
  }

  return sanitized;
}

const neoServer = new Server(
  { name: "neo4j-graph-mcp", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

neoServer.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "get_entity_neighborhood",
      description: "Extracts an entity's local neighborhood graph up to a max depth of 3.",
      inputSchema: {
        type: "object",
        properties: {
          entityId: { type: "string" },
          maxDepth: { type: "number", default: 2, maximum: 3 }
        },
        required: ["entityId"]
      }
    },
    {
      name: "execute_cypher",
      description: "Executes a sanitized Cypher query with automated depth and limit guards.",
      inputSchema: {
        type: "object",
        properties: {
          query: { type: "string" }
        },
        required: ["query"]
      }
    }
  ]
}));

neoServer.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  const session = driver.session();

  try {
    if (name === "get_entity_neighborhood") {
      const { entityId, maxDepth } = args as any;
      const depth = Math.min(Number(maxDepth) || 2, 3);

      const cypher = `
        MATCH (n {id: $entityId})
        CALL apoc.path.subgraphAll(n, {maxLevel: $depth})
        YIELD nodes, relationships
        RETURN nodes, relationships
      `;
      
      // Fallback standard Cypher if APOC is unavailable
      const standardCypher = `
        MATCH path = (n {id: $entityId})-[r*1..${depth}]-(m)
        RETURN path LIMIT 50
      `;

      const result = await session.run(standardCypher, { entityId });
      const records = result.records.map(r => r.toObject());
      return { content: [{ type: "text", text: JSON.stringify(records, null, 2) }] };
    }

    if (name === "execute_cypher") {
      const rawQuery = (args as any).query;
      const safeQuery = sanitizeAndRewriteCypher(rawQuery);

      const result = await session.run(safeQuery);
      const records = result.records.map(r => r.toObject());
      return { content: [{ type: "text", text: JSON.stringify(records, null, 2) }] };
    }

    throw new Error(`Tool not found: ${name}`);
  } finally {
    await session.close();
  }
});
