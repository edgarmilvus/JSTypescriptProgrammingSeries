/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

interface QueryInspectorModalProps {
  queryData: {
    id: string;
    query: string;
    sourceAgent: string;
    executionTimeMs: number;
    validationStatus: 'PASSED' | 'BLOCKED_MUTATION' | 'RATE_LIMITED' | 'UNBOUNDED_GRAPH';
    sanitizedParameters?: string;
  } | null;
  isOpen: boolean;
  onClose: () => void;
  onRevoke: (agentId: string) => void;
}

export const QueryInspectorModal: React.FC<QueryInspectorModalProps> = ({
  queryData,
  isOpen,
  onClose,
  onRevoke
}) => {
  const [revoked, setRevoked] = useState(false);

  if (!isOpen || !queryData) return null;

  const handleRevokeAction = () => {
    onRevoke(queryData.sourceAgent);
    setRevoked(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-xl bg-slate-900 border border-slate-700 p-6 text-slate-100 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="text-lg font-semibold text-indigo-400">Query Audit Inspector</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-sm font-bold px-2 py-1 rounded bg-slate-800"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-slate-400">Agent ID:</span>
              <p className="font-mono text-slate-200">{queryData.sourceAgent}</p>
            </div>
            <div>
              <span className="text-slate-400">Execution Status:</span>
              <span className={`inline-block ml-2 px-2 py-0.5 text-xs font-bold rounded ${
                queryData.validationStatus === 'PASSED' ? 'bg-emerald-900 text-emerald-300' : 'bg-rose-900 text-rose-300'
              }`}>
                {queryData.validationStatus}
              </span>
            </div>
            <div>
              <span className="text-slate-400">Execution Time:</span>
              <p className="font-mono text-slate-200">{queryData.executionTimeMs} ms</p>
            </div>
          </div>

          <div>
            <span className="text-slate-400 text-sm">Raw Agent Query / Statement:</span>
            <pre className="mt-1 p-3 rounded bg-slate-950 font-mono text-xs text-amber-300 overflow-x-auto border border-slate-800">
              {queryData.query}
            </pre>
          </div>

          {queryData.sanitizedParameters && (
            <div>
              <span className="text-slate-400 text-sm">Sanitized AST Parameters:</span>
              <pre className="mt-1 p-3 rounded bg-slate-950 font-mono text-xs text-cyan-300 overflow-x-auto border border-slate-800">
                {queryData.sanitizedParameters}
              </pre>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-2">
          <button
            onClick={handleRevokeAction}
            disabled={revoked}
            className={`px-4 py-2 rounded text-sm font-medium transition-colors ${
              revoked ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-rose-600 hover:bg-rose-700 text-white'
            }`}
          >
            {revoked ? 'Agent Token Revoked' : 'Revoke Agent Session Token'}
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-sm text-slate-300"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
