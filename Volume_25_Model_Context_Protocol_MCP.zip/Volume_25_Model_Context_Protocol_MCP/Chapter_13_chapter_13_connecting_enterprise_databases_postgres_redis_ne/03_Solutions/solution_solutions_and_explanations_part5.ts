/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

interface Task {
  id: string;
  targetWorker: 'postgres' | 'redis' | 'neo4j';
  payload: string;
}

interface WorkflowResult {
  taskId: string;
  success: boolean;
  data?: any;
  error?: string;
}

export class EnterpriseWorkflowOrchestrator {
  private auditLog: Array<{ timestamp: number; worker: string; payloadHash: string; status: string }> = [];

  private async simulateWorkerExecution(worker: string, payload: string): Promise<any> {
    // Simulated worker execution throwing governance exceptions on malicious patterns
    if (payload.includes("DROP") || payload.includes("UNBOUNDED")) {
      throw new Error(`Governance Exception: Unsafe operation detected on ${worker} worker.`);
    }
    return { status: "success", result: `Processed by ${worker}` };
  }

  /**
   * Fault-tolerant task dispatcher method that handles execution timeouts,
   * catches governance exceptions, and triggers safe fallbacks.
   */
  public async dispatchTasks(tasks: Task[]): Promise<WorkflowResult[]> {
    const results: WorkflowResult[] = [];

    for (const task of tasks) {
      const timestamp = Date.now();
      const payloadHash = Buffer.from(task.payload).toString("base64").slice(0, 16);

      try {
        // Implement a hard execution timeout per task (e.g., 3 seconds)
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Worker Execution Timeout")), 3000)
        );

        const executionPromise = this.simulateWorkerExecution(task.targetWorker, task.payload);
        const data = await Promise.race([executionPromise, timeoutPromise]);

        this.auditLog.push({ timestamp, worker: task.targetWorker, payloadHash, status: "SUCCESS" });
        results.push({ taskId: task.id, success: true, data });

      } catch (error: any) {
        // Catch governance violations or timeouts and formulate a safe fallback
        this.auditLog.push({ timestamp, worker: task.targetWorker, payloadHash, status: `FAILED: ${error.message}` });

        results.push({
          taskId: task.id,
          success: false,
          error: error.message,
          data: { fallback: "Task quarantined due to governance or timeout policy. Returning empty result set." }
        });
      }
    }

    return results;
  }

  public getAuditTrail() {
    return this.auditLog;
  }
}
