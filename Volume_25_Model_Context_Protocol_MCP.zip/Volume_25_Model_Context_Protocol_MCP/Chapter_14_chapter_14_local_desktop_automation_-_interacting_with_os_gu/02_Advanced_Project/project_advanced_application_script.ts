/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { screen, mouse, keyboard, Point, Key } from "@nut-tree/nut-js";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { EventEmitter } from "events";

/**
 * Interface representing a structured automation step received from 
 * an LLM vision agent or an MCP (Model Context Protocol) supervisor node.
 */
interface AutomationStep {
  id: string;
  action: "click" | "type" | "scroll" | "screenshot" | "wait";
  coordinates?: { x: number; y: number };
  text?: string;
  durationMs?: number;
}

/**
 * Interface representing the execution result of an automation sequence.
 */
interface ExecutionResult {
  stepId: string;
  success: boolean;
  timestamp: string;
  screenshotPath?: string;
  error?: string;
}

/**
 * DesktopAutomationEngine orchestrates native OS interaction.
 * It acts as the local bridge between high-level Model Context Protocol (MCP)
 * instructions and low-level operating system event loops.
 */
export class DesktopAutomationEngine extends EventEmitter {
  private workingDirectory: string;
  private isRunning: boolean = false;

  constructor(outputDir: string = "./captures") {
    super();
    this.workingDirectory = outputDir;
    this.configureNutJs();
  }

  /**
   * Configures global parameters for the underlying native OS automation library.
   */
  private configureNutJs(): void {
    // Adjust mouse movement speed (pixels per millisecond)
    mouse.config.mouseSpeed = 1000;
    // Set delay between individual keystrokes to mimic human typing safely
    keyboard.config.autoDelayMs = 50;
  }

  /**
   * Initializes the execution environment by ensuring artifact directories exist.
   */
  public async initialize(): Promise<void> {
    await mkdir(this.workingDirectory, { recursive: true });
    this.emit("initialized", { directory: this.workingDirectory });
  }

  /**
   * Captures the primary display framebuffer and saves it as a PNG image.
   * Essential for feeding fresh visual state back into vision-driven agents.
   */
  public async captureScreen(stepId: string): Promise<string> {
    const fileName = `screenshot-${stepId}-${Date.now()}.png`;
    const filePath = join(this.workingDirectory, fileName);

    // Grab the screen region buffer via native OS bindings
    const screenImage = await screen.grab();
    const imageBuffer = await screenImage.toPNG();

    await writeFile(filePath, imageBuffer);
    this.emit("screenshotCaptured", { stepId, filePath });
    
    return filePath;
  }

  /**
   * Executes a single discrete automation step against the host OS GUI.
   */
  public async executeStep(step: AutomationStep): Promise<ExecutionResult> {
    const timestamp = new Date().toISOString();

    try {
      switch (step.action) {
        case "click": {
          if (!step.coordinates) {
            throw new Error(`Coordinates required for click action on step ${step.id}`);
          }
          const targetPoint = new Point(step.coordinates.x, step.coordinates.y);
          await mouse.setPosition(targetPoint);
          await mouse.leftClick();
          break;
        }

        case "type": {
          if (!step.text) {
            throw new Error(`Text required for type action on step ${step.id}`);
          }
          await keyboard.type(step.text);
          break;
        }

        case "scroll": {
          // Positive values scroll down, negative scroll up depending on platform bindings
          await mouse.scrollDown(5);
          break;
        }

        case "wait": {
          const delay = step.durationMs || 1000;
          await new Promise((resolve) => setTimeout(resolve, delay));
          break;
        }

        case "screenshot": {
          // Handled post-step execution loop
          break;
        }

        default:
          throw new Error(`Unsupported automation action: ${(step as any).action}`);
      }

      // Capture resulting visual state for verification
      const screenshotPath = await this.captureScreen(step.id);

      return {
        stepId: step.id,
        success: true,
        timestamp,
        screenshotPath,
      };
    } catch (error: any) {
      return {
        stepId: step.id,
        success: false,
        timestamp,
        error: error.message || String(error),
      };
    }
  }

  /**
   * Sequentially executes a batch of automation instructions derived from an MCP agent plan.
   */
  public async executeBatch(steps: AutomationStep[]): Promise<ExecutionResult[]> {
    this.isRunning = true;
    const results: ExecutionResult[] = [];

    for (const step of steps) {
      if (!this.isRunning) {
        break;
      }

      this.emit("stepStart", step);
      const result = await this.executeStep(step);
      results.push(result);
      this.emit("stepComplete", result);

      if (!result.success) {
        // Halt execution chain upon critical failure to prevent unintended OS state mutation
        break;
      }
    }

    this.isRunning = false;
    return results;
  }

  /**
   * Emergency stop mechanism to immediately halt automation loops.
   */
  public stop(): void {
    this.isRunning = false;
    this.emit("stopped", { timestamp: new Date().toISOString() });
  }
}
