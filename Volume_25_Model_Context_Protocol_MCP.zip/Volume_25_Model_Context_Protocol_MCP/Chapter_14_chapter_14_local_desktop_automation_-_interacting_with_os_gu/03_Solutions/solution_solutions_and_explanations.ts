/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import bindings from 'bindings';

// Load the compiled native addon binary (.node)
const native = bindings('native_desktop_automation');

export interface ScreenCaptureResult {
  width: number;
  height: number;
  stride: number;
  data: Buffer;
  timestamp: number;
}

export class NativeScreenCapturer {
  private isDisposed: boolean = false;

  constructor() {
    // Perform initial platform capability check via native binding
    const initialized = native.initScreenCapturer();
    if (!initialized) {
      throw new Error(
        'Failed to initialize screen capturer. Check OS permissions (Screen Recording / TCC).'
      );
    }
  }

  public async capture(): Promise<ScreenCaptureResult> {
    if (this.isDisposed) {
      throw new Error('NativeScreenCapturer has already been disposed.');
    }

    return new Promise((resolve, reject) => {
      // Offload or invoke native capture asynchronously to avoid blocking the event loop
      setImmediate(() => {
        try {
          const rawResult = native.captureScreen();
          if (!rawResult || !rawResult.buffer) {
            throw new Error('Native screen capture returned an invalid buffer pointer.');
          }

          resolve({
            width: rawResult.width,
            height: rawResult.height,
            stride: rawResult.stride,
            data: rawResult.buffer, // Zero-copy Node.js Buffer linked to native memory
            timestamp: Date.now(),
          });
        } catch (error: any) {
          reject(new Error(`Native screen capture failure: ${error.message}`));
        }
      });
    });
  }

  public dispose(): void {
    if (!this.isDisposed) {
      native.releaseScreenCapturer();
      this.isDisposed = true;
    }
  }
}
