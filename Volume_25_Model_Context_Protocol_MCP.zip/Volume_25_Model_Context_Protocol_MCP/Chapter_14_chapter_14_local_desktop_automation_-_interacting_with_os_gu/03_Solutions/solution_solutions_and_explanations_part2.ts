/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import bindings from 'bindings';

const native = bindings('native_desktop_automation');

export enum MouseButton {
  Left = 0,
  Right = 1,
  Middle = 2,
}

export interface Point {
  x: number;
  y: number;
}

export class OutOfBoundsError extends Error {
  constructor(x: number, y: number, maxWidth: number, maxHeight: number) {
    super(`Coordinates (${x}, ${y}) are out of bounds for screen size ${maxWidth}x${maxHeight}.`);
    this.name = 'OutOfBoundsError';
  }
}

export class InputSimulator {
  private screenWidth: number;
  private screenHeight: number;

  constructor(screenWidth: number, screenHeight: number) {
    this.screenWidth = screenWidth;
    this.screenHeight = screenHeight;
  }

  private validateCoordinates(point: Point): void {
    if (
      point.x < 0 ||
      point.x > this.screenWidth ||
      point.y < 0 ||
      point.y > this.screenHeight
    ) {
      throw new OutOfBoundsError(point.x, point.y, this.screenWidth, this.screenHeight);
    }
  }

  private async delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  public async move(to: Point, durationMs: number = 0): Promise<void> {
    this.validateCoordinates(to);
    
    if (durationMs > 0) {
      // Simple linear interpolation for smooth human-like mouse drags
      const startX = native.getMouseX();
      const startY = native.getMouseY();
      const steps = Math.max(10, Math.floor(durationMs / 16)); // ~60fps steps
      
      for (let i = 1; i <= steps; i++) {
        const factor = i / steps;
        const currentX = Math.round(startX + (to.x - startX) * factor);
        const currentY = Math.round(startY + (to.y - startY) * factor);
        native.moveMouse(currentX, currentY);
        await this.delay(durationMs / steps);
      }
    } else {
      native.moveMouse(to.x, to.y);
    }
  }

  public async click(button: MouseButton, point?: Point): Promise<void> {
    if (point) {
      await this.move(point);
    }
    native.mouseDown(button);
    await this.delay(50); // Natural dwell time
    native.mouseUp(button);
  }

  public async type(text: string, delayBetweenCharsMs: number = 30): Promise<void> {
    for (const char of text) {
      native.typeString(char);
      if (delayBetweenCharsMs > 0) {
        await this.delay(delayBetweenCharsMs);
      }
    }
  }

  public async pressCombination(keys: string[]): Promise<void> {
    // Dispatch down sequence hierarchically
    for (const key of keys) {
      native.keyDown(key);
    }
    await this.delay(50);
    // Dispatch up sequence in reverse order
    for (const key of keys.reverse()) {
      native.keyUp(key);
    }
  }
}
