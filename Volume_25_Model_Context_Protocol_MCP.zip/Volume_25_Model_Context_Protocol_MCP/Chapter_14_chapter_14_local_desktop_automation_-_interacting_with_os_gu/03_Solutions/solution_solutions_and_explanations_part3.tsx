/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { FC, useState, useEffect, useRef } from 'react';

export interface AgentTelemetryEvent {
  id: string;
  timestamp: number;
  actionType: 'click' | 'type' | 'drag' | 'capture';
  status: 'success' | 'failed' | 'pending';
  latencyMs: number;
  details?: string;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
}

export interface AgentControlCenterProps {
  wsEndpoint: string;
  onEmergencyStop: () => void;
  onToggleManualOverride: (isActive: boolean) => void;
}

export const AgentControlCenter: FC<AgentControlCenterProps> = ({
  wsEndpoint,
  onEmergencyStop,
  onToggleManualOverride,
}) => {
  const [isManualMode, setIsManualMode] = useState<boolean>(false);
  const [telemetryLogs, setTelemetryLogs] = useState<AgentTelemetryEvent[]>([]);
  const [boxes, setBoxes] = useState<BoundingBox[]>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const ws = new WebSocket(wsEndpoint);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'frame' && canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        const img = new Image();
        img.onload = () => {
          ctx?.drawImage(img, 0, 0, canvasRef.current!.width, canvasRef.current!.height);
        };
        img.src = `data:image/jpeg;base64,${data.payload}`;
      } else if (data.type === 'telemetry') {
        setTelemetryLogs((prev) => [data.event, ...prev.slice(0, 99)]);
      } else if (data.type === 'bboxes') {
        setBoxes(data.boxes);
      }
    };

    return () => ws.close();
  }, [wsEndpoint]);

  const handleManualToggle = () => {
    const nextState = !isManualMode;
    setIsManualMode(nextState);
    onToggleManualOverride(nextState);
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 font-sans">
      <div className="flex-1 flex flex-col p-4">
        <header className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
          <h1 className="text-xl font-bold tracking-wide">Desktop Agent Control Center</h1>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <span className="text-sm">Manual Override (HITL)</span>
              <input
                type="checkbox"
                checked={isManualMode}
                onChange={handleManualToggle}
                className="toggle toggle-primary"
              />
            </label>
            <button
              onClick={onEmergencyStop}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded font-semibold transition"
            >
              EMERGENCY STOP
            </button>
          </div>
        </header>

        <div className="relative flex-1 bg-black rounded-lg overflow-hidden border border-slate-800 flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            className="max-h-full max-w-full object-contain"
          />
          {boxes.map((box, idx) => (
            <div
              key={idx}
              className="absolute border-2 border-emerald-400 bg-emerald-500/10 pointer-events-none"
              style={{
                left: `${box.x}px`,
                top: `${box.y}px`,
                width: `${box.width}px`,
                height: `${box.height}px`,
              }}
            >
              <span className="bg-emerald-600 text-xs px-1 text-white absolute -top-5 left-0">
                {box.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      <aside className="w-96 border-l border-slate-800 p-4 flex flex-col bg-slate-900">
        <h2 className="font-semibold text-lg mb-3 border-b border-slate-800 pb-2">Telemetry Logs</h2>
        <div className="flex-1 overflow-y-auto space-y-2 font-mono text-xs">
          {telemetryLogs.map((log) => (
            <div key={log.id} className="p-2 bg-slate-950 rounded border border-slate-800">
              <div className="flex justify-between text-slate-400">
                <span>{log.actionType.toUpperCase()}</span>
                <span>{log.latencyMs}ms</span>
              </div>
              <div className={log.status === 'success' ? 'text-emerald-400' : 'text-red-400'}>
                {log.status.toUpperCase()} {log.details && `- ${log.details}`}
              </div>
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
};
