/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { NativeScreenCapturer } from './NativeScreenCapturer';
import { InputSimulator } from './InputSimulator';

export interface MCPToolCall {
  name: string;
  arguments: Record<string, any>;
}

export interface VisionModelResponse {
  thought: string;
  toolCall?: MCPToolCall;
  isComplete: boolean;
}

export class MCPDesktopAgentLoop {
  private capturer: NativeScreenCapturer;
  private simulator: InputSimulator;
  private vlmClient: any;
  private isCancelled: boolean = false;

  constructor(
    capturer: NativeScreenCapturer,
    simulator: InputSimulator,
    vlmClient: any
  ) {
    this.capturer = capturer;
    this.simulator = simulator;
    this.vlmClient = vlmClient;
  }

  public async runLoop(goal: string, maxSteps: number = 10): Promise<void> {
    this.isCancelled = false;
    let step = 0;
    let previousImageHash: string | null = null;

    while (step < maxSteps && !this.isCancelled) {
      step++;
      
      // 1. Capture Frame
      const captureResult = await this.capturer.capture();
      
      // Compute simple buffer hash for state mutation verification
      const currentImageHash = captureResult.data.toString('hex').slice(0, 64);
      if (previousImageHash && previousImageHash === currentImageHash && step > 1) {
        console.warn(`[AgentLoop] Warning: Screen state did not mutate after previous action.`);
      }
      previousImageHash = currentImageHash;

      // 2. Query Vision Model
      const vlmResponse: VisionModelResponse = await this.vlmClient.analyze({
        goal,
        step,
        imageBuffer: captureResult.data,
        dimensions: { width: captureResult.width, height: captureResult.height },
      });

      console.log(`[Step ${step}] Thought: ${vlmResponse.thought}`);

      if (vlmResponse.isComplete) {
        console.log(`[AgentLoop] Goal successfully achieved.`);
        return;
      }

      // 3. Parse & Execute Tool Call
      if (vlmResponse.toolCall) {
        const { name, arguments: args } = vlmResponse.toolCall;
        
        try {
          switch (name) {
            case 'desktop_click':
              await this.simulator.click(args.button ?? 0, { x: args.x, y: args.y });
              break;
            case 'desktop_type':
              await this.simulator.type(args.text, args.delay);
              break;
            case 'desktop_key_combination':
              await this.simulator.pressCombination(args.keys);
              break;
            default:
              throw new Error(`Unknown MCP tool call: ${name}`);
          }
        } catch (error: any) {
          console.error(`[AgentLoop] Execution error during tool ${name}: ${error.message}`);
          // Feed error context back into VLM prompt on next iteration
        }
      }

      // Brief pause between loop iterations
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }

    if (this.isCancelled) {
      console.log(`[AgentLoop] Execution loop cancelled by user.`);
    } else {
      throw new Error(`[AgentLoop] Maximum steps (${maxSteps}) reached without completing goal.`);
    }
  }

  public cancel(): void {
    this.isCancelled = true;
  }
}
