/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { execSync } from 'child_process';
import bindings from 'bindings';

const native = bindings('native_desktop_automation');

export interface RestrictedZone {
  xMin: number;
  xMax: number;
  yMin: number;
  yMax: number;
  label: string;
}

export class SecurityViolationError extends Error {
  constructor(zone: RestrictedZone, x: number, y: number) {
    super(`Security Violation: Attempted interaction at (${x}, ${y}) inside restricted zone "${zone.label}".`);
    this.name = 'SecurityViolationError';
  }
}

export class OSGuardrailManager {
  private restrictedZones: RestrictedZone[];

  constructor(restrictedZones: RestrictedZone[]) {
    this.restrictedZones = restrictedZones;
  }

  public verifyPermissions(): boolean {
    const platform = process.platform;
    const hasPermissions = native.checkSystemPermissions();

    if (!hasPermissions) {
      console.warn(`[Security] Missing required OS permissions for platform: ${platform}`);
      this.remediatePermissions(platform);
      return false;
    }
    return true;
  }

  private remediatePermissions(platform: string): void {
    if (platform === 'darwin') {
      console.log('[Security] Opening macOS Privacy & Security settings...');
      try {
        execSync('open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"');
      } catch (err) {
        console.error('Failed to open macOS system preferences automatically.');
      }
    } else if (platform === 'win32') {
      console.log('[Security] Windows requires manual UAI/UIPI privilege elevation verification.');
    } else {
      console.log('[Security] Linux environment: ensure X11/Wayland portal permissions are granted.');
    }
  }

  public assertWithinSandbox(x: number, y: number): void {
    for (const zone of this.restrictedZones) {
      if (
        x >= zone.xMin &&
        x <= zone.xMax &&
        y >= zone.yMin &&
        y <= zone.yMax
      ) {
        throw new SecurityViolationError(zone, x, y);
      }
    }
  }
}
