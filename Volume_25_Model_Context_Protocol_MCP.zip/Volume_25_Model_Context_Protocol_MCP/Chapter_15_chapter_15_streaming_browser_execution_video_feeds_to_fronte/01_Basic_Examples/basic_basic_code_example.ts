/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// FILE: server.ts (Backend Headless Browser & WebSocket Streamer)
// ==========================================

import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';
import { chromium, Browser, Page } from 'playwright';

/**
 * Interface representing metadata associated with a browser action overlay.
 */
interface AgentActionOverlay {
    type: 'click' | 'type' | 'scroll';
    x: number;
    y: number;
    timestamp: number;
}

const app = express();
const server = createServer(app);
const io = new SocketIOServer(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST']
    }
});

const PORT = process.env.PORT || 4000;

/**
 * Manages the lifecycle of the headless browser session and frame broadcasting.
 */
class BrowserStreamManager {
    private browser: Browser | null = null;
    private page: Page | null = null;
    private isStreaming: boolean = false;
    private intervalId: NodeJS.Timeout | null = null;

    /**
     * Initializes the Playwright chromium instance and navigates to a target URL.
     * @param targetUrl The URL for the agent to automate.
     */
    public async startSession(targetUrl: string, socket: Socket): Promise<void> {
        try {
            console.log(`[BrowserStreamManager] Launching headless browser for target: ${targetUrl}`);
            this.browser = await chromium.launch({ headless: true });
            const context = await this.browser.newContext({
                viewport: { width: 1280, height: 720 }
            });
            this.page = await context.newPage();
            
            await this.page.goto(targetUrl, { waitUntil: 'networkidle' });
            this.isStreaming = true;

            // Begin streaming frames to the connected client
            this.startFrameLoop(socket);

        } catch (error) {
            console.error('[BrowserStreamManager] Failed to start browser session:', error);
            socket.emit('session_error', { message: 'Failed to initialize browser session.' });
        }
    }

    /**
     * Captures screenshot buffers at a fixed interval and emits them over WebSockets.
     * @param socket The active Socket.io client socket.
     */
    private startFrameLoop(socket: Socket): void {
        if (!this.page) return;

        // Target approximately 10 frames per second (100ms interval) to balance bandwidth and smoothness
        const FPS_INTERVAL = 100; 

        this.intervalId = setInterval(async () => {
            if (!this.isStreaming || !this.page) return;

            try {
                // Capture viewport as a compressed JPEG buffer
                const screenshotBuffer = await this.page.screenshot({
                    type: 'jpeg',
                    quality: 60,
                    fullPage: false
                });

                // Emit binary frame data to the frontend React component
                socket.emit('browser_frame', {
                    buffer: screenshotBuffer,
                    timestamp: Date.now()
                });

            } catch (err) {
                // Handle cases where the page might have crashed or closed unexpectedly
                console.warn('[BrowserStreamManager] Frame capture error:', err);
                this.stopSession();
            }
        }, FPS_INTERVAL);
    }

    /**
     * Terminates the browser session and clears background polling intervals.
     */
    public async stopSession(): Promise<void> {
        this.isStreaming = false;
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
            this.page = null;
        }
        console.log('[BrowserStreamManager] Browser session terminated.');
    }
}

// Socket.io connection handling for real-time SaaS dashboard clients
io.on('connection', (socket: Socket) => {
    console.log(`[WebSocket] Client connected: ${socket.id}`);
    const streamManager = new BrowserStreamManager();

    socket.on('start_agent_session', async (data: { url: string }) => {
        const targetUrl = data.url || 'https://example.com';
        await streamManager.startSession(targetUrl, socket);
    });

    socket.on('disconnect', async () => {
        console.log(`[WebSocket] Client disconnected: ${socket.id}`);
        await streamManager.stopSession();
    });
});

server.listen(PORT, () => {
    console.log(`[Server] SaaS Browser Streaming Backend running on port ${PORT}`);
});
