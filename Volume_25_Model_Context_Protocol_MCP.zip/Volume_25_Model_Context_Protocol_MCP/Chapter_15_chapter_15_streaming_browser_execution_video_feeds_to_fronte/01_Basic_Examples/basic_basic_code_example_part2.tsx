/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// ==========================================
// FILE: BrowserAgentDashboard.tsx (Frontend React Component)
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

/**
 * Interface defining metadata for real-time agent bounding box overlays.
 */
interface AgentOverlay {
    id: string;
    label: string;
    x: number;
    y: number;
    width: number;
    height: number;
    actionType: 'click' | 'type' | 'scroll';
}

export const BrowserAgentDashboard: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const [isConnected, setIsConnected] = useState<boolean>(false);
    const [agentStatus, setAgentStatus] = useState<string>('Idle');
    const [overlays, setOverlays] = useState<AgentOverlay[]>([]);
    const socketRef = useRef<Socket | null>(null);

    useEffect(() => {
        // Initialize Socket.io client connection to the SaaS backend
        socketRef.current = io('http://localhost:4000');

        socketRef.current.on('connect', () => {
            setIsConnected(true);
            setAgentStatus('Connected to Agent Stream');
        });

        socketRef.current.on('disconnect', () => {
            setIsConnected(false);
            setAgentStatus('Disconnected');
        });

        // Listen for incoming binary JPEG frames from the headless browser
        socketRef.current.on('browser_frame', (data: { buffer: ArrayBuffer; timestamp: number }) => {
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;

            // Convert incoming raw buffer into a Blob and subsequently an Image bitmap/object
            const blob = new Blob([data.buffer], { type: 'image/jpeg' });
            const imageUrl = URL.createObjectURL(blob);
            const image = new Image();

            image.onload = () => {
                // Clear canvas and draw the new frame matching viewport dimensions (1280x720)
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

                // Revoke object URL to prevent memory leaks in the browser DOM
                URL.revokeObjectURL(imageUrl);
            };

            image.src = imageUrl;
        });

        return () => {
            if (socketRef.current) {
                socketRef.current.disconnect();
            }
        };
    }, []);

    /**
     * Handler to trigger the start of an automated browser agent session.
     */
    const handleStartAgent = () => {
        if (socketRef.current) {
            setAgentStatus('Initializing Autonomous Browser...');
            socketRef.current.emit('start_agent_session', { url: 'https://news.ycombinator.com' });
        }
    };

    return (
        <div style={{ padding: '24px', fontFamily: 'Inter, sans-serif', backgroundColor: '#0f172a', color: '#f8fafc', minHeight: '100vh' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h1>Autonomous Browser Agent Live Stream</h1>
                <div>
                    <span style={{ marginRight: '12px', padding: '6px 12px', borderRadius: '4px', backgroundColor: isConnected ? '#10b981' : '#ef4444' }}>
                        {agentStatus}
                    </span>
                    <button 
                        onClick={handleStartAgent} 
                        style={{ padding: '8px 16px', backgroundColor: '#3b82f6', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}
                    >
                        Start Agent Session
                    </button>
                </div>
            </header>

            <div style={{ position: 'relative', width: '1280px', height: '720px', margin: '0 auto', border: '2px solid #334155', borderRadius: '8px', overflow: 'hidden', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.5)' }}>
                {/* HTML5 Canvas rendering the real-time JPEG stream */}
                <canvas 
                    ref={canvasRef} 
                    width={1280} 
                    height={720} 
                    style={{ width: '100%', height: '100%', display: 'block' }}
                />

                {/* State synchronization overlay layer for agent bounding boxes */}
                {overlays.map((overlay) => (
                    <div
                        key={overlay.id}
                        style={{
                            position: 'absolute',
                            left: `${overlay.x}px`,
                            top: `${overlay.y}px`,
                            width: `${overlay.width}px`,
                            height: `${overlay.height}px`,
                            border: '2px dashed #f59e0b',
                            backgroundColor: 'rgba(245, 158, 11, 0.2)',
                            pointerEvents: 'none',
                            display: 'flex',
                            alignItems: 'flex-start',
                            justifyContent: 'flex-start',
                        }}
                    >
                        <span style={{ backgroundColor: '#f59e0b', color: '#000', fontSize: '10px', fontWeight: 'bold', padding: '2px 4px' }}>
                            {overlay.label} ({overlay.actionType})
                        </span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BrowserAgentDashboard;
