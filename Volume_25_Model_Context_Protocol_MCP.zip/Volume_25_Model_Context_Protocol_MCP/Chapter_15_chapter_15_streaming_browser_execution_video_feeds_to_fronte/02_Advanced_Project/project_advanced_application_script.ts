/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// SaaS Agent Execution & Live Browser Streaming Engine
// ============================================================================
// This production script orchestrates a headless browser session using Playwright,
// streams compressed JPEG frame buffers over a WebSocket server to a Next.js frontend,
// and enforces a Max Iteration Policy to protect against infinite loops.
// ============================================================================

import { chromium, Browser, Page } from 'playwright';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';

// Interface definitions for system telemetry and agent state
interface AgentState {
  currentIteration: number;
  maxIterations: number;
  status: 'IDLE' | 'RUNNING' | 'TERMINATED_MAX_ITERATIONS' | 'COMPLETED';
  lastAction: string;
  boundingBoxes: Array<{ x: number; y: number; width: number; height: number; label: string }>;
}

// Global configuration constants for enterprise SaaS limits
const PORT = process.env.WS_PORT ? parseInt(process.env.WS_PORT, 10) : 8080;
const MAX_ITERATIONS = 10;
const FRAME_CAPTURE_INTERVAL_MS = 200; // 5 FPS streaming balance

/**
 * Initializes the WebSocket broadcasting infrastructure and binds the Playwright 
 * browser automation pipeline with real-time frame extraction.
 */
async function bootstrapAgentStreamServer() {
  // 1. Initialize HTTP and WebSocket servers for real-time frame broadcasting
  const server = createServer();
  const wss = new WebSocketServer({ server });

  console.log(`[WebSocket] Enterprise streaming engine mounting on port ${PORT}...`);

  wss.on('connection', (ws: WebSocket) => {
    console.log('[WebSocket] Client dashboard connected. Initializing telemetry feed.');
    
    ws.send(JSON.stringify({ 
      type: 'SYSTEM_STATUS', 
      message: 'Connected to Enterprise Browser Streamer' 
    }));
  });

  // 2. Launch headless browser infrastructure via Playwright
  const browser: Browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
  });

  const context = await browser.newContext({
    viewport: { width: 1280, height: 720 }
  });

  const page: Page = await context.newPage();
  
  // 3. Define the Agent State with Max Iteration Policy Guardrail
  const state: AgentState = {
    currentIteration: 0,
    maxIterations: MAX_ITERATIONS,
    status: 'RUNNING',
    lastAction: 'Initializing browser session',
    boundingBoxes: []
  };

  // Start HTTP server binding
  server.listen(PORT, () => {
    console.log(`[Server] Live stream telemetry active at ws://localhost:${PORT}`);
  });

  // 4. Execute the automated browser workflow with integrated frame broadcasting
  try {
    await page.goto('https://news.ycombinator.com', { waitUntil: 'networkidle' });
    
    // Background interval to capture and broadcast screenshots + bounding boxes
    const frameStreamInterval = setInterval(async () => {
      if (state.status !== 'RUNNING') {
        clearInterval(frameStreamInterval);
        return;
      }

      try {
        // Enforce Max Iteration Policy check continuously
        if (state.currentIteration >= state.maxIterations) {
          state.status = 'TERMINATED_MAX_ITERATIONS';
          state.lastAction = 'Max Iteration Policy triggered. Halting workflow.';
          clearInterval(frameStreamInterval);
          broadcastState(wss, state, null);
          return;
        }

        state.currentIteration++;

        // Capture viewport frame buffer as compressed JPEG
        const buffer = await page.screenshot({ 
          type: 'jpeg', 
          quality: 60,
          fullPage: false 
        });

        // Simulate dynamic agent element detection (e.g., locating target links)
        const targetElement = await page.$('.titleline > a');
        if (targetElement) {
          const box = await targetElement.boundingBox();
          if (box) {
            state.boundingBoxes = [{
              x: box.x,
              y: box.y,
              width: box.width,
              height: box.height,
              label: `Action Target #${state.currentIteration}`
            }];
          }
        }

        state.lastAction = `Processed ReAct cycle iteration ${state.currentIteration}`;
        
        // Broadcast binary frame and JSON telemetry state to all connected dashboard clients
        broadcastState(wss, state, buffer);

      } catch (err) {
        console.error('[Error] Frame capture iteration failed:', err);
      }
    }, FRAME_CAPTURE_INTERVAL_MS);

    // Keep session alive for demonstration purposes
    await new Promise((resolve) => setTimeout(resolve, 30000));

  } catch (error) {
    console.error('[Fatal Error] Browser automation workflow crashed:', error);
  } finally {
    state.status = 'COMPLETED';
    await browser.close();
    server.close();
    console.log('[Shutdown] Enterprise browser stream engine cleanly terminated.');
  }
}

/**
 * Broadcasts system state JSON metadata followed by binary frame buffers 
 * to active WebSocket clients.
 */
function broadcastState(wss: WebSocketServer, state: AgentState, frameBuffer: Buffer | null) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      // Send metadata first
      client.send(JSON.stringify({
        type: 'AGENT_STATE',
        ...state
      }));

      // Send binary JPEG frame if available
      if (frameBuffer) {
        client.send(frameBuffer);
      }
    }
  });
}

// Execute the bootstrapping sequence if run directly
if (require.main === module) {
  bootstrapAgentStreamServer().catch(console.error);
}
