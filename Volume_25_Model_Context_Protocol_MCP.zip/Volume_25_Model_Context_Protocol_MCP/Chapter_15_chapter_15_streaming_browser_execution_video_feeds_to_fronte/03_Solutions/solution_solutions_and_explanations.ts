/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { chromium, Browser, Page } from 'playwright';
import { WebSocket, WebSocketServer } from 'ws';

export interface BroadcasterConfig {
  port: number;
  targetUrl: string;
  fps: number;
}

export class BrowserStreamBroadcaster {
  private browser: Browser | null = null;
  private page: Page | null = null;
  private wss: WebSocketServer;
  private clients: Set<WebSocket> = new Set();
  private isStreaming: boolean = false;
  private captureInterval: NodeJS.Timeout | null = null;

  constructor(private config: BroadcasterConfig) {
    this.wss = new WebSocketServer({ port: config.port });
    this.setupWebSocketServer();
  }

  private setupWebSocketServer(): void {
    this.wss.on('connection', (ws: WebSocket) => {
      this.clients.add(ws);
      console.log(`[WebSocket] Client connected. Total clients: ${this.clients.size}`);

      ws.on('close', () => {
        this.clients.delete(ws);
        console.log(`[WebSocket] Client disconnected. Total clients: ${this.clients.size}`);
      });

      ws.on('error', (err) => {
        console.error('[WebSocket] Client error:', err);
        ws.terminate();
        this.clients.delete(ws);
      });
    });
  }

  public async start(): Promise<void> {
    this.browser = await chromium.launch({ headless: true });
    const context = await this.browser.newContext({
      viewport: { width: 1280, height: 720 },
    });
    this.page = await context.newPage();
    await this.page.goto(this.config.targetUrl, { waitUntil: 'networkidle' });

    this.isStreaming = true;
    const intervalMs = Math.floor(1000 / this.config.fps);

    this.captureInterval = setInterval(async () => {
      await this.captureAndBroadcast();
    }, intervalMs);

    console.log(`[Broadcaster] Started streaming at ${this.config.fps} FPS on port ${this.config.port}`);
  }

  private async captureAndBroadcast(): Promise<void> {
    if (!this.page || !this.isStreaming || this.clients.size === 0) return;

    try {
      // Capture JPEG screenshot buffer for compact binary transmission
      const buffer = await this.page.screenshot({ type: 'jpeg', quality: 80 });

      for (const client of this.clients) {
        if (client.readyState === WebSocket.OPEN) {
          // Implement backpressure check: drop frame if socket buffer is too full (> 64KB backlog)
          if (client.bufferedAmount > 64 * 1024) {
            continue; 
          }
          client.send(buffer);
        }
      }
    } catch (error) {
      console.error('[Broadcaster] Frame capture error:', error);
    }
  }

  public async stop(): Promise<void> {
    this.isStreaming = false;
    if (this.captureInterval) {
      clearInterval(this.captureInterval);
      this.captureInterval = null;
    }
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
    this.wss.close();
    console.log('[Broadcaster] Stopped streaming service.');
  }
}
