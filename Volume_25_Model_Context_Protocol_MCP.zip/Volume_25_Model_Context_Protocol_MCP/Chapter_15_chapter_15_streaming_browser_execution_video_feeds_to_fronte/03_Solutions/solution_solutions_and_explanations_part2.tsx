/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';

interface LiveBrowserStreamProps {
  wsUrl: string;
  width?: number;
  height?: number;
}

export const LiveBrowserStream: React.FC<LiveBrowserStreamProps> = ({
  wsUrl,
  width = 1280,
  height = 720,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<'connecting' | 'live' | 'disconnected'>('connecting');
  const wsRef = useRef<WebSocket | null>(null);
  const latestFrameRef = useRef<ImageBitmap | null>(null);
  const animationFrameId = useRef<number | null>(null);

  useEffect(() => {
    const ws = new WebSocket(wsUrl);
    ws.binaryType = 'arraybuffer';
    wsRef.current = ws;

    ws.onopen = () => setStatus('live');
    ws.onclose = () => setStatus('disconnected');
    ws.onerror = () => setStatus('disconnected');

    ws.onmessage = async (event) => {
      try {
        const blob = new Blob([event.data], { type: 'image/jpeg' });
        const imageBitmap = await createImageBitmap(blob);
        
        // Clean up previous bitmap reference to prevent memory leaks
        if (latestFrameRef.current) {
          latestFrameRef.current.close();
        }
        latestFrameRef.current = imageBitmap;
      } catch (err) {
        console.error('Failed to parse incoming frame:', err);
      }
    };

    return () => {
      ws.close();
      if (latestFrameRef.current) {
        latestFrameRef.current.close();
      }
    };
  }, [wsUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const renderLoop = () => {
      if (ctx && latestFrameRef.current) {
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(latestFrameRef.current, 0, 0, width, height);
      }
      animationFrameId.current = requestAnimationFrame(renderLoop);
    };

    animationFrameId.current = requestAnimationFrame(renderLoop);

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [width, height]);

  return (
    <div className="relative border border-slate-700 rounded-lg overflow-hidden bg-black shadow-2xl">
      <div className="absolute top-3 right-3 z-10 flex items-center space-x-2 bg-slate-900/80 px-3 py-1 rounded-full backdrop-blur-md">
        <span className={`w-2.5 h-2.5 rounded-full ${
          status === 'live' ? 'bg-emerald-500 animate-pulse' :
          status === 'connecting' ? 'bg-amber-500' : 'bg-rose-500'
        }`} />
        <span className="text-xs font-mono uppercase tracking-wider text-slate-200">
          {status}
        </span>
      </div>
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className="w-full h-auto object-contain block"
      />
    </div>
  );
};
