/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import { useEffect, RefObject } from 'react';

interface UseRemoteControlOptions {
  containerRef: RefObject<HTMLElement | null>;
  ws: WebSocket | null;
  naturalWidth: number;
  naturalHeight: number;
  isEnabled: boolean;
}

export const useRemoteControl = ({
  containerRef,
  ws,
  naturalWidth,
  naturalHeight,
  isEnabled,
}: UseRemoteControlOptions) => {
  useEffect(() => {
    const element = containerRef.current;
    if (!element || !isEnabled || !ws) return;

    const handleCanvasClick = (event: MouseEvent) => {
      const rect = element.getBoundingClientRect();
      const clientX = event.clientX - rect.left;
      const clientY = event.clientY - rect.top;

      // Normalize client coordinates to browser viewport natural dimensions
      const scaleX = naturalWidth / rect.width;
      const scaleY = naturalHeight / rect.height;

      const x = Math.round(clientX * scaleX);
      const y = Math.round(clientY * scaleY);

      const payload = JSON.stringify({
        type: 'input_click',
        x,
        y,
        button: event.button,
      });

      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      const payload = JSON.stringify({
        type: 'input_keydown',
        key: event.key,
        code: event.code,
      });

      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    };

    element.addEventListener('click', handleCanvasClick);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      element.removeEventListener('click', handleCanvasClick);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [containerRef, ws, naturalWidth, naturalHeight, isEnabled]);
};
