/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React from 'react';

export interface BoundingBox {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
  actionType: 'click' | 'type' | 'scroll' | 'navigate';
}

interface AgentOverlayProps {
  boxes: BoundingBox[];
  naturalWidth: number;
  naturalHeight: number;
  currentThought?: string;
}

export const AgentOverlay: React.FC<AgentOverlayProps> = ({
  boxes,
  naturalWidth,
  naturalHeight,
  currentThought,
}) => {
  // TODO: Compute scaling factors based on container dimensions vs natural dimensions.
  
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <svg className="w-full h-full" viewBox={`0 0 ${naturalWidth} ${naturalHeight}`}>
        {boxes.map((box) => (
          <g key={box.id} className="transition-all duration-300 ease-out">
            {/* TODO: Render SVG rect with dashed stroke, glowing filter, and action badge */}
          </g>
        ))}
      </svg>
      {currentThought && (
        <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 border border-slate-700 p-3 rounded-md backdrop-blur-md shadow-lg">
          <p className="text-xs font-mono text-cyan-400 mb-1 uppercase tracking-wider">Agent Reasoning</p>
          <p className="text-sm text-slate-100 font-sans">{currentThought}</p>
        </div>
      )}
    </div>
  );
};
