/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

/**
 * Interface representing an observation returned to the agentic loop.
 */
interface AgentObservation {
    status: 'SUCCESS' | 'FAILURE';
    data?: unknown;
    errorDiagnostic?: string;
    reflectionPrompt?: string;
}

/**
 * Agent orchestrator loop demonstrating sandbox integration and reflection.
 */
export class AgentOrchestrator {
    private sandbox: AgentCodeSandbox;

    constructor() {
        this.sandbox = new AgentCodeSandbox({ timeoutMs: 1500 });
    }

    /**
     * Executes an agent-generated tool call and handles runtime failures via reflection.
     */
    public async runAgentStep(
        generatedCode: string,
        initialDataset: Record<string, unknown>
    ): Promise<AgentObservation> {
        console.log('[ORCHESTRATOR]: Dispatching generated script to secure sandbox...');

        // Execute code inside the isolated sandbox
        const executionResult = await this.sandbox.execute(generatedCode, initialDataset);

        if (executionResult.success) {
            console.log(`[ORCHESTRATOR]: Sandbox execution succeeded in ${executionResult.executionTimeMs}ms.`);
            return {
                status: 'SUCCESS',
                data: executionResult.result,
            };
        } else {
            console.warn(`[ORCHESTRATOR]: Sandbox execution failed: ${executionResult.error}`);
            
            // Trigger Tool Use Reflection: Formulate a reflection prompt for the LLM
            // so it can analyze the failure and self-correct in the next iteration.
            const reflectionPrompt = `
                Your previous dynamically generated script failed to execute correctly inside the sandbox.
                Error Encountered: "${executionResult.error}".
                Execution Time: ${executionResult.executionTimeMs}ms.
                
                Please analyze this error. Check for syntax issues, undefined property accesses on the 'input' object, 
                or prohibited API calls. Refine your script and emit a corrected tool call.
            `.trim();

            return {
                status: 'FAILURE',
                errorDiagnostic: executionResult.error,
                reflectionPrompt,
            };
        }
    }
}
