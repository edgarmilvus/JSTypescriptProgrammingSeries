/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as vm from 'node:vm';

/**
 * Interface representing the runtime context provided to the sandboxed code.
 */
interface SandboxContext {
  cart: {
    items: Array<{ id: string; price: number; quantity: number }>;
    subtotal: number;
  };
  discountApplied: boolean;
  finalTotal: number;
}

/**
 * Interface representing the result of the sandboxed execution.
 */
interface ExecutionResult {
  success: boolean;
  finalTotal: number;
  error?: string;
}

/**
 * Safely executes untrusted user discount logic within a V8 VM sandbox.
 * 
 * @param userScript - Raw JavaScript string provided by the tenant/user.
 * @param initialCart - The shopping cart data to expose to the script.
 * @returns ExecutionResult detailing the outcome of the sandbox run.
 */
function executeUserDiscountScript(
  userScript: string,
  initialCart: SandboxContext['cart']
): ExecutionResult {
  // 1. Establish the explicit global context sandbox object.
  // We explicitly deny access to dangerous globals like 'process', 'require', 'Buffer', and 'global'.
  const sandbox: SandboxContext = {
    cart: initialCart,
    discountApplied: false,
    finalTotal: initialCart.subtotal,
  };

  // 2. Compile the context into a secure VM context object
  const context = vm.createContext(sandbox);

  // 3. Wrap user script in an IIFE to prevent global scope pollution inside the sandbox
  const wrappedScript = `
    (function() {
      try {
        // User-provided logic execution zone
        ${userScript}
        
        // Ensure finalTotal is updated back to the sandbox state
        if (typeof calculateTotal === 'function') {
          finalTotal = calculateTotal(cart);
          discountApplied = true;
        }
      } catch (err) {
        throw new Error('Sandbox Execution Error: ' + err.message);
      }
    })();
  `;

  try {
    // 4. Compile the script to catch syntax errors before execution
    const script = new vm.Script(wrappedScript, {
      filename: 'user-discount-plugin.vm',
    });

    // 5. Run the script with strict execution timeouts (e.g., 100ms)
    // This blocks infinite loops or heavy synchronous computations.
    script.runInContext(context, {
      timeout: 100, // milliseconds
      displayErrors: true,
    });

    return {
      success: true,
      finalTotal: sandbox.finalTotal,
    };
  } catch (error: any) {
    // 6. Handle syntax errors, runtime crashes, or timeout violations safely
    return {
      success: false,
      finalTotal: initialCart.subtotal, // Fallback to original subtotal
      error: error.message,
    };
  }
}

// --- Example SaaS Usage ---

const customerCart = {
  items: [
    { id: 'item_1', price: 50.0, quantity: 2 },
    { id: 'item_2', price: 25.0, quantity: 1 },
  ],
  subtotal: 125.0,
};

// Malicious or valid user script trying to calculate a 20% discount
const untrustedTypeScript = `
  function calculateTotal(cart) {
    let total = 0;
    for (const item of cart.items) {
      total += item.price * item.quantity;
    }
    // Apply 20% discount
    return total * 0.80;
  }
`;

console.log('--- Running Valid Sandbox Script ---');
const result = executeUserDiscountScript(untrustedTypeScript, customerCart);
console.log(result); 
// Output: { success: true, finalTotal: 100 }

// Malicious script attempting to invoke an infinite loop
const infiniteLoopScript = `
  function calculateTotal(cart) {
    while(true) {
      // Simulate CPU exhaustion attack
    }
  }
`;

console.log('--- Running Malicious Infinite Loop Script ---');
const badResult = executeUserDiscountScript(infiniteLoopScript, customerCart);
console.log(badResult);
// Output: { success: false, finalTotal: 125, error: 'Script execution timed out after 100ms' }
