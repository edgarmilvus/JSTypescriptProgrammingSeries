/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import vm from 'node:vm';
import { performance } from 'node:perf_hooks';

/**
 * Interface representing the configuration constraints for the sandbox execution environment.
 */
interface SandboxConfig {
  /** Maximum execution time allowed in milliseconds before the script is forcibly terminated. */
  timeoutMs: number;
  /** Maximum memory allocation allowed (hint for V8 context execution). */
  memoryLimitMb?: number;
  /** Custom global variables or modules exposed safely to the sandbox context. */
  allowedGlobals?: Record<string, unknown>;
}

/**
 * Structured result returned from the sandboxed execution engine.
 */
interface SandboxResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
  metrics: {
    executionTimeMs: number;
  };
}

/**
 * Type Guard to check if an unknown error object conforms to a standard JavaScript Error shape.
 * 
 * @param error - The unknown object caught during execution.
 * @returns Boolean indicating whether the object is an Error instance.
 */
function isStandardError(error: unknown): error is Error {
  return (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof (error as Record<string, unknown>).message === 'string'
  );
}

/**
 * Type Guard to validate that the result of an agent script conforms to a expected analytics output schema.
 * 
 * @param output - The raw output returned from the sandboxed script.
 * @returns Boolean indicating structural validity.
 */
interface AnalyticsPayload {
  processedRows: number;
  summaryMetric: number;
  tags: string[];
}

function isAnalyticsPayload(output: unknown): output is AnalyticsPayload {
  if (typeof output !== 'object' || output === null) return false;
  
  const candidate = output as Record<string, unknown>;
  
  return (
    typeof candidate.processedRows === 'number' &&
    typeof candidate.summaryMetric === 'number' &&
    Array.isArray(candidate.tags) &&
    candidate.tags.every(tag => typeof tag === 'string')
  );
}

/**
 * Executes untrusted agent-generated JavaScript code inside a secure Node.js VM sandbox.
 * 
 * @param code - The raw string of JavaScript code produced by the AI agent.
 * @param config - Execution constraints including timeouts and exposed globals.
 * @returns A promise resolving to a SandboxResult containing metrics and safety validations.
 */
async function executeAgentScript<T>(
  code: string,
  config: SandboxConfig
): Promise<SandboxResult<T>> {
  const startTime = performance.now();

  // 1. Construct a hardened sandbox context object with minimal privileges.
  // We explicitly omit access to process, require, globalThis, and file system APIs.
  const sandboxEnvironment = {
    console: {
      log: (...args: unknown[]) => {
        // Safe interception of agent logs for debugging and auditing
        ('[Agent Sandbox Log]:', ...args);
      },
      error: (...args: unknown[]): void => {
        console.error('[Agent Sandbox Error]:', ...args);
      }
    },
    Math,
    Date,
    JSON,
    // Inject custom safe globals provided by the caller
    ...(config.allowedGlobals || {})
  };

  // 2. Create a secure context from the sandbox environment map
  const context = vm.createContext(sandboxEnvironment, {
    codeGeneration: {
      strings: false, // Prevent dynamic code generation via eval() or new Function() inside sandbox
      wasm: false     // Disable WebAssembly compilation for security
    }
  });

  try {
    // 3. Wrap the untrusted code in an IIFE to enable async/await patterns securely
    const wrappedCode = `
      (async () => {
        ${code}
      })();
    `;

    // 4. Compile the script with timeout protections
    const script = new vm.Script(wrappedCode, {
      filename: 'agent-autonomous-script.js'
    });

    // 5. Execute the compiled script within the isolated context
    const executionPromise = script.runInContext(context, {
      timeout: config.timeoutMs,
      displayErrors: true
    });

    // Await execution with a strict safety race condition against timeouts
    const result = await executionPromise;
    const endTime = performance.now();

    return {
      success: true,
      data: result as T,
      metrics: {
        executionTimeMs: Number((endTime - startTime).toFixed(2))
      }
    };

  } catch (err: unknown) {
    const endTime = performance.now();
    const errorDetails = isStandardError(err)
      ? { name: err.name, message: err.message, stack: err.stack }
      : { name: 'UnknownExecutionError', message: String(err) };

    return {
      success: false,
      error: errorDetails,
      metrics: {
        executionTimeMs: Number((endTime - startTime).toFixed(2))
      }
    };
  }
}

/**
 * Example Next.js Server Action demonstrating how the sandboxed execution engine
 * integrates into an AI Agent workflow.
 * 
 * @param rawAgentCode - Code generated by an LLM via the Model Context Protocol.
 */
export async function runAgentToolAction(rawAgentCode: string) {
  // Define strict resource governance parameters
  const sandboxConfig: SandboxConfig = {
    timeoutMs: 1500, // Terminate execution if it exceeds 1.5 seconds (prevents infinite loops)
    allowedGlobals: {
      dataset: [
        { id: 1, value: 42, category: 'A' },
        { id: 2, value: 84, category: 'B' },
        { id: 3, value: 12, category: 'A' }
      ]
    }
  };

  // Execute the code safely
  const result = await executeAgentScript<unknown>(rawAgentCode, sandboxConfig);

  // Handle security violations or runtime failures gracefully
  if (!result.success) {
    return {
      status: 'error',
      message: `Agent execution failed or violated security policy: ${result.error?.message}`,
      metrics: result.metrics
    };
  }

  // Apply strict Type Guard validation on the output before passing to downstream systems
  if (!isAnalyticsPayload(result.data)) {
    return {
      status: 'error',
      message: 'Agent script executed successfully, but returned data violating the expected AnalyticsPayload schema.',
      metrics: result.metrics
    };
  }

  // Safe data handling downstream
  return {
    status: 'success',
    validatedData: result.data,
    metrics: result.metrics
  };
}
