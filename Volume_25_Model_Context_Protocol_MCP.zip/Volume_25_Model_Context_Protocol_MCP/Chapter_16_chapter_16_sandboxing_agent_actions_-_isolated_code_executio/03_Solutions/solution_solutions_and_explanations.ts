/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import vm from 'node:vm';

export class VmTimeoutError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'VmTimeoutError';
  }
}

export class VmSyntaxError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'VmSyntaxError';
  }
}

export class VmRuntimeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'VmRuntimeError';
  }
}

/**
 * Executes untrusted JavaScript code inside an isolated Node.js VM context.
 * 
 * @param code - The string of JavaScript code to evaluate.
 * @param timeoutMs - The maximum allowed execution time in milliseconds.
 * @returns The final expression or return value of the script.
 */
export async function executeInVm(code: string, timeoutMs: number = 1000): Promise<unknown> {
  // Create a completely stripped-down global context to prevent prototype pollution and escapes
  const sandbox = Object.create(null);
  
  // Provide safe globals if necessary, or leave completely empty for pure computation
  sandbox.console = {
    log: (...args: unknown[]) => {
      // Safely capture or suppress logs if needed
    }
  };

  const context = vm.createContext(sandbox);

  try {
    const script = new vm.Script(code);
    
    // Execute with a strict wall-clock timeout and the locked-down context
    const result = script.runInContext(context, {
      timeout: timeoutMs,
      displayErrors: true,
    });

    return result;
  } catch (error: any) {
    // Map native errors to custom typed error classes
    if (error.code === 'ERR_SCRIPT_EXECUTION_TIMEOUT' || error.message?.includes('Script execution timed out')) {
      throw new VmTimeoutError(`Execution timed out after ${timeoutMs}ms`);
    }
    
    if (error instanceof SyntaxError || error.message?.includes('Unexpected token')) {
      throw new VmSyntaxError(`Syntax error in sandbox code: ${error.message}`);
    }

    throw new VmRuntimeError(`Runtime error in sandbox code: ${error.message}`);
  }
}
