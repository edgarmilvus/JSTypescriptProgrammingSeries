/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const execAsync = promisify(exec);

export interface ExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

export class DockerSandboxExecutor {
  private imageName: string;

  constructor(imageName: string = 'node:20-alpine') {
    this.imageName = imageName;
  }

  /**
   * Executes a string of code inside an ephemeral, hardened Docker container.
   */
  async runCodeInContainer(
    code: string,
    timeoutMs: number = 5000
  ): Promise<ExecutionResult> {
    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'agent-sandbox-'));
    const filePath = path.join(tmpDir, 'script.js');

    try {
      await fs.writeFile(filePath, code, 'utf-8');

      // Construct a hardened docker run command:
      // --network none: isolates network access
      // --read-only: makes root filesystem read-only
      // --tmpfs /tmp: provides temporary writable space
      // --memory=128m --cpus="0.5": enforces resource caps
      // --user 1000:1000: runs as non-root user
      const containerCommand = [
        'docker run',
        '--rm',
        '--network none',
        '--read-only',
        '--tmpfs /tmp:rw,noexec,nosuid,size=65536k',
        '--memory="128m"',
        '--cpus="0.5"',
        '--user 1000:1000',
        `-v "${tmpDir}:/app:ro"`,
        this.imageName,
        'node /app/script.js'
      ].join(' ');

      const { stdout, stderr } = await execAsync(containerCommand, {
        timeout: timeoutMs,
        killSignal: 'SIGKILL'
      });

      return {
        stdout,
        stderr,
        exitCode: 0
      };
    } catch (error: any) {
      return {
        stdout: error.stdout || '',
        stderr: error.stderr || error.message || 'Unknown container execution error',
        exitCode: error.code ?? 1
      };
    } finally {
      // Guarantee cleanup of the temporary host directory
      try {
        await fs.rm(tmpDir, { recursive: true, force: true });
      } catch (cleanupError) {
        console.error('Failed to clean up temporary sandbox directory:', cleanupError);
      }
    }
  }
}
