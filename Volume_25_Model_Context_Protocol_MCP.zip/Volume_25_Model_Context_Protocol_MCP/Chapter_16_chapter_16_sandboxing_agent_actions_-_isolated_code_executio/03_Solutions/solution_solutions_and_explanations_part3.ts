/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface PolicyRule {
  toolName: string;
  forbiddenArgumentPatterns?: Record<string, RegExp>;
  requiredWhitelists?: Record<string, string[]>;
  allowDestructiveOperations?: boolean;
}

export interface ValidationResult {
  allowed: boolean;
  reason?: string;
}

export class AgentToolGuard {
  private rules: Map<string, PolicyRule> = new Map();

  constructor(rules: PolicyRule[]) {
    rules.forEach((rule) => this.rules.set(rule.toolName, rule));
  }

  /**
   * Intercepts and validates an incoming tool call from an agent.
   */
  public validate(toolName: string, args: Record<string, unknown>): ValidationResult {
    const rule = this.rules.get(toolName);

    // If no explicit rules are defined for a tool, deny by default in strict environments, 
    // or allow with caution. Here we default to allowed if untracked, or enforce strictness.
    if (!rule) {
      return { allowed: true };
    }

    // 1. Inspect arguments against forbidden regex patterns
    if (rule.forbiddenArgumentPatterns) {
      for (const [argKey, pattern] of Object.entries(rule.forbiddenArgumentPatterns)) {
        const val = args[argKey];
        if (typeof val === 'string' && pattern.test(val)) {
          // Special domain check for destructive SQL if applicable
          if (toolName === 'ExecuteSql' && !rule.allowDestructiveOperations) {
            const upperSql = val.toUpperCase();
            if (['DROP', 'DELETE', 'TRUNCATE', 'ALTER'].some(keyword => upperSql.includes(keyword))) {
              return {
                allowed: false,
                reason: `Policy Violation: Destructive SQL keyword detected in argument '${argKey}' without override permission.`
              };
            }
          }

          return {
            allowed: false,
            reason: `Policy Violation: Argument '${argKey}' matched forbidden pattern: ${pattern.toString()}`
          };
        }
      }
    }

    // 2. Validate against required whitelists (e.g., allowed file paths or table names)
    if (rule.requiredWhitelists) {
      for (const [argKey, whitelist] of Object.entries(rule.requiredWhitelists)) {
        const val = args[argKey];
        if (typeof val === 'string' && !whitelist.includes(val)) {
          return {
            allowed: false,
            reason: `Policy Violation: Value '${val}' for argument '${argKey}' is not present in the allowed whitelist.`
          };
        }
      }
    }

    return { allowed: true };
  }
}
