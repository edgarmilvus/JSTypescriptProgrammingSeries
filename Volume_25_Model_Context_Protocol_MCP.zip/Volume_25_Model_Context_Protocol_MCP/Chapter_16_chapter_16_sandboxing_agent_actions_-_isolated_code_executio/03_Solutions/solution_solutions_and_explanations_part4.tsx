/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState, useEffect } from 'react';

export type SandboxEvent = 
  | { type: 'STARTED'; sessionId: string; code: string }
  | { type: 'VIOLATION'; sessionId: string; reason: string }
  | { type: 'SUCCESS'; sessionId: string; output: string }
  | { type: 'TIMEOUT'; sessionId: string };

interface AgentSandboxMonitorProps {
  eventStream: AsyncIterable<SandboxEvent>;
  onTerminateSession: (sessionId: string) => Promise<void>;
}

/**
 * A streamable-ui React component that monitors agent sandbox execution in real-time,
 * displaying security telemetry and offering manual override controls.
 */
export function AgentSandboxMonitor({ eventStream, onTerminateSession }: AgentSandboxMonitorProps) {
  const [events, setEvents] = useState<SandboxEvent[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isTerminating, setIsTerminating] = useState<boolean>(false);

  useEffect(() => {
    async function consumeStream() {
      try {
        for await (const event of eventStream) {
          setActiveSessionId(event.sessionId);
          setEvents((prev) => [event, ...prev]);
        }
      } catch (err) {
        console.error('Error consuming sandbox event stream:', err);
      }
    }

    consumeStream();
  }, [eventStream]);

  const handleEmergencyKill = async () => {
    if (!activeSessionId) return;
    setIsTerminating(true);
    try {
      await onTerminateSession(activeSessionId);
    } finally {
      setIsTerminating(false);
    }
  };

  const getBadgeStyle = (type: SandboxEvent['type']) => {
    switch (type) {
      case 'SUCCESS': return 'bg-green-900 text-green-300 border-green-700';
      case 'VIOLATION': return 'bg-red-900 text-red-300 border-red-700';
      case 'TIMEOUT': return 'bg-yellow-900 text-yellow-300 border-yellow-700';
      default: return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="p-4 border rounded-lg shadow-md bg-slate-900 text-slate-100 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Agent Sandbox Security Monitor</h2>
        {activeSessionId && (
          <button
            onClick={handleEmergencyKill}
            disabled={isTerminating}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-semibold rounded text-sm transition-colors"
          >
            {isTerminating ? 'Terminating...' : '🚨 Emergency Kill Switch'}
          </button>
        )}
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
        {events.length === 0 ? (
          <p className="text-slate-500 italic text-center py-6">Awaiting sandbox events stream...</p>
        ) : (
          events.map((evt, idx) => (
            <div key={idx} className={`p-3 border rounded text-sm ${getBadgeStyle(evt.type)}`}>
              <div className="flex justify-between font-semibold mb-1">
                <span>EVENT: {evt.type}</span>
                <span className="text-xs opacity-75">Session: {evt.sessionId}</span>
              </div>
              {evt.type === 'STARTED' && <p className="font-mono text-xs truncate">Code: {evt.code}</p>}
              {evt.type === 'VIOLATION' && <p>Reason: {evt.reason}</p>}
              {evt.type === 'SUCCESS' && <p className="font-mono text-xs">Output: {evt.output}</p>}
              {evt.type === 'TIMEOUT' && <p>Execution exceeded allocated wall-clock time limit.</p>}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
