/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface AgentContext {
  model: string;
  generateReflection(errorLog: string): Promise<Record<string, unknown>>;
}

export interface ExecutionResult {
  success: boolean;
  output?: string;
  error?: string;
  attempts: number;
}

/**
 * Executes a tool call within a secure sandbox, automatically feeding sandbox errors
 * back to the agent for self-correction and retry.
 */
export async function executeWithSelfCorrection(
  context: AgentContext,
  toolExecutor: (args: Record<string, unknown>) => Promise<string>,
  initialArgs: Record<string, unknown>,
  maxRetries: number = 3
): Promise<ExecutionResult> {
  let currentArgs = initialArgs;
  let attempts = 0;
  let lastError = '';

  while (attempts < maxRetries) {
    attempts++;
    try {
      const output = await toolExecutor(currentArgs);
      return {
        success: true,
        output,
        attempts
      };
    } catch (error: any) {
      lastError = error.message || String(error);

      // Circuit Breaker / Max Retries Check
      if (attempts >= maxRetries) {
        break;
      }

      try {
        // Generate reflection prompt and request corrected arguments from the agent
        const reflectionPrompt = `The previous tool execution failed with the following error: "${lastError}". Please adjust your parameters and provide corrected arguments.`;
        currentArgs = await context.generateReflection(reflectionPrompt);
      } catch (reflectionError: any) {
        return {
          success: false,
          error: `Execution failed and reflection generation failed: ${reflectionError.message}`,
          attempts
        };
      }
    }
  }

  return {
    success: false,
    error: `Circuit breaker tripped after ${maxRetries} consecutive failures. Last error: ${lastError}`,
    attempts
  };
}
