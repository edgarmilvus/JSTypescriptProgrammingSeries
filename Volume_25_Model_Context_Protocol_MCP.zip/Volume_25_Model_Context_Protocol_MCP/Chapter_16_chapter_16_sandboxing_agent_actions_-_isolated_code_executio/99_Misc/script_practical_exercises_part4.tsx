/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

'use client';

import React, { useState, useEffect } from 'react';

export type SandboxEvent = 
  | { type: 'STARTED'; sessionId: string; code: string }
  | { type: 'VIOLATION'; sessionId: string; reason: string }
  | { type: 'SUCCESS'; sessionId: string; output: string }
  | { type: 'TIMEOUT'; sessionId: string };

interface AgentSandboxMonitorProps {
  eventStream: AsyncIterable<SandboxEvent>;
  onTerminateSession: (sessionId: string) => Promise<void>;
}

/**
 * A streamable-ui React component that monitors agent sandbox execution in real-time,
 * displaying security telemetry and offering manual override controls.
 */
export function AgentSandboxMonitor({ eventStream, onTerminateSession }: AgentSandboxMonitorProps) {
  // TODO: Implement state management for events, active session tracking, 
  // and event handlers for the emergency kill switch.
  
  return (
    <div className="p-4 border rounded-lg shadow-md bg-slate-900 text-slate-100">
      <h2 className="text-xl font-bold mb-4">Agent Sandbox Security Monitor</h2>
      {/* TODO: Render streaming logs and interactive controls here */}
    </div>
  );
}
