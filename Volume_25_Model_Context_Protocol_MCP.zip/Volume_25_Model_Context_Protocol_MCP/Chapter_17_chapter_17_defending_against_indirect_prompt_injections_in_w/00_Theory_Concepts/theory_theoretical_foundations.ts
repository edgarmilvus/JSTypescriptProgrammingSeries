/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph IPI_Theoretical_Foundations {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fontsize=12];
    
    subgraph cluster_trusted {
        label = "Trusted Control Plane";
        style=filled;
        color=lightblue;
        SystemPrompt [label="System Instructions\n(Privileged Intent)", fillcolor=white];
        AgentRuntime [label="Agent Reasoning Loop\n(LLM Core)", fillcolor=white];
        SystemPrompt -> AgentRuntime [label="Initializes Context"];
    }
    
    subgraph cluster_untrusted {
        label = "Untrusted Environment";
        style=filled;
        color=lightcoral;
        ExternalWebpage [label="Malicious Webpage / Data Feed\n(Hidden IPI Payload)", fillcolor=white];
        MCPTool [label="MCP Tool Execution\n(Browser / File System)", fillcolor=white];
        ExternalWebpage -> MCPTool [label="Ingested via Tool Output"];
    }
    
    MCPTool -> AgentRuntime [label="Pollutes Context Window\n(Instruction Hierarchical Collapse)", color=red, penwidth=2];
    AgentRuntime -> UnauthorizedAction [label="Executes Malicious Tool Call\n(Exfiltration / Destruction)", color=red, penwidth=2];
    UnauthorizedAction [label="Compromised System State", fillcolor=pink];
}
