/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

digraph MCP_Microservice_Mesh {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fontsize=12];
    
    LLMCore [label="LLM Orchestration Core\n(Monolithic Router)", fillcolor=gold];
    
    subgraph cluster_mcp_servers {
        label = "MCP Tool Servers (Microservices)";
        style=filled;
        color=lightgray;
        FileSystemTool [label="File System MCP Server\n(/etc, /home)", fillcolor=white];
        BrowserTool [label="Browser Automation MCP Server\n(Headless Chromium)", fillcolor=white];
        DatabaseTool [label="Database MCP Server\n(PostgreSQL Connector)", fillcolor=white];
    }
    
    LLMCore -> BrowserTool [label="1. Browse Untrusted URL", color=blue];
    BrowserTool -> LLMCore [label="2. Returns Malicious Webpage Content\n(Contains IPI Payload)", color=blue];
    
    LLMCore -> FileSystemTool [label="3. Triggered by IPI:\nRead /etc/passwd", color=red, penwidth=2];
    FileSystemTool -> LLMCore [label="4. Sensitive Data Leak", color=red, penwidth=2];
}
