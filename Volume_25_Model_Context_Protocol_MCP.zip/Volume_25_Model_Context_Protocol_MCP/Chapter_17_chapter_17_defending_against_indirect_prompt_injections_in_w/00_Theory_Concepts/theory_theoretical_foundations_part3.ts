/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

digraph Strict_Boundary_Enforcement {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fontsize=12];
    
    subgraph cluster_sandbox {
        label = "Isolated Execution Sandbox";
        style=filled;
        color=lightyellow;
        
        SystemInstructions [label="Immutable System Instructions\n(Signed & Encapsulated)", fillcolor=white];
        DataFeedWrapper [label="Data Feed Wrapper\n(<untrusted_external_data> tags)", fillcolor=white];
        
        SystemInstructions -> AgentCore [label="Primary Control Plane"];
        DataFeedWrapper -> AgentCore [label="Sandboxed Observation Plane", style=dashed];
    }
    
    AgentCore [label="Agent Reasoning Core", fillcolor=gold];
    
    AgentCore -> MCPToolRegistry [label="Request Tool Execution"];
    
    MCPToolRegistry -> GuardrailProxy [label="Intercepts Tool Call"];
    GuardrailProxy -> PolicyEngine [label="Validates against Least-Privilege Policy\n(Dual-LLM / Deterministic Check)"];
    
    PolicyEngine -> AllowedAction [label="Authorized", color=green];
    PolicyEngine -> BlockedAction [label="Unauthorized / Anomalous", color=red];
}
