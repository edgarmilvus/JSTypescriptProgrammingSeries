/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import 'server-only';
import React from 'react';
import DOMPurify from 'isomorphic-dompurify';

export interface SanitizedWebPreviewProps {
  rawHtml: string;
  sourceUrl: string;
  susposityScore: number;
}

/**
 * A Next.js Server Component that renders untrusted web content safely,
 * stripping malicious DOM structures and highlighting potential indirect prompt injections.
 */
export async function SanitizedWebPreview({
  rawHtml,
  sourceUrl,
  susposityScore,
}: SanitizedWebPreviewProps): Promise<JSX.Element> {
  // Sanitize the raw HTML string strictly, removing script tags, event handlers, and hidden tricks
  const cleanHtml = DOMPurify.sanitize(rawHtml, {
    ALLOWED_TAGS: ['div', 'span', 'p', 'a', 'ul', 'li', 'strong', 'em', 'br'],
    ALLOWED_ATTR: ['href', 'class'],
    FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'style'], // Strip inline styles to prevent display:none tricks
  });

  const isSuspicious = susposityScore > 0.7;

  return (
    <div className="border border-slate-700 rounded-lg p-4 bg-slate-900 text-slate-100">
      <h3 className="text-sm font-semibold text-slate-400">Secure Web Preview: {sourceUrl}</h3>
      
      {isSuspicious && (
        <div className="my-3 p-3 bg-red-950/50 border border-red-500 rounded text-red-200 text-xs flex items-center gap-2">
          <span className="font-bold">[SECURITY WARNING]:</span> 
          High injection probability detected (Score: {susposityScore.toFixed(2)}). Hidden elements or adversarial instructions may be present.
        </div>
      )}

      <div 
        className="mt-4 p-3 bg-slate-950 rounded border border-slate-800 prose prose-invert max-w-none text-sm"
        dangerouslySetInnerHTML={{ __html: cleanHtml }}
      />
    </div>
  );
}
