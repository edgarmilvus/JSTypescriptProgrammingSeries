/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { z } from 'zod';

export const MemoryChunkSchema = z.object({
  id: z.string().uuid(),
  content: z.string(),
  similarity: z.number(),
  source_url: z.string().url(),
  is_flagged: z.boolean(),
});

export type MemoryChunk = z.infer<typeof MemoryChunkSchema>;

export class ContextRetrievalGuard {
  constructor(private supabase: SupabaseClient) {}

  public async querySafeContext(embedding: number[], matchThreshold: number): Promise<string> {
    // Perform secure RPC call to Supabase pgvector function
    const { data, error } = await this.supabase.rpc('match_page_chunks', {
      query_embedding: embedding,
      match_threshold: matchThreshold,
      match_count: 5,
    });

    if (error) {
      throw new Error(`Failed to retrieve vector context from Supabase: ${error.message}`);
    }

    // Validate incoming database rows against strict Zod schema at runtime
    const parseResult = z.array(MemoryChunkSchema).safeParse(data);
    if (!parseResult.success) {
      throw new Error(`Retrieved memory chunks failed validation schema: ${parseResult.error.message}`);
    }

    const validChunks = parseResult.data;

    // Filter out chunks explicitly flagged as malicious
    const safeChunks = validChunks.filter((chunk) => !chunk.is_flagged);

    // Wrap clean chunks in strict XML-style boundary delimiters to prevent context bleed
    const encapsulatedContext = safeChunks
      .map(
        (chunk) =>
          `<untrusted_external_data source="${encodeURIComponent(chunk.source_url)}" id="${chunk.id}">\n${chunk.content}\n</untrusted_external_data>`
      )
      .join('\n\n');

    return encapsulatedContext;
  }
}
