/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface BoundingBox {
  id: string;
  xMin: number;
  yMin: number;
  xMax: number;
  yMax: number;
  selector: string;
  isTrusted: boolean;
}

export class UnauthorizedInteractionError extends Error {
  constructor(public x: number, public y: number, public reason: string) {
    super(`Action blocked at coordinates (${x}, ${y}): ${reason}`);
    this.name = 'UnauthorizedInteractionError';
  }
}

export class BrowserRuntimeGuardrail {
  constructor(private allowedElements: BoundingBox[]) {}

  public validateAction(coordinates: { x: number; y: number }, targetSelector: string): void {
    const { x, y } = coordinates;

    // Find if the target coordinates fall within any authorized, trusted bounding box
    const matchingElement = this.allowedElements.find((element) => {
      const isInside = x >= element.xMin && x <= element.xMax && y >= element.yMin && y <= element.yMax;
      return isInside && element.isTrusted;
    });

    if (!matchingElement) {
      throw new UnauthorizedInteractionError(
        x,
        y,
        `Coordinates (${x}, ${y}) do not map to any trusted, authorized bounding box for selector '${targetSelector}'.`
      );
    }

    // Optional secondary verification ensuring the matched element matches the intended selector
    if (matchingElement.selector !== targetSelector) {
      throw new UnauthorizedInteractionError(
        x,
        y,
        `Selector mismatch: coordinates target element '${matchingElement.selector}' instead of expected '${targetSelector}'. Potential clickjacking or overlay injection detected.`
      );
    }
  }
}
