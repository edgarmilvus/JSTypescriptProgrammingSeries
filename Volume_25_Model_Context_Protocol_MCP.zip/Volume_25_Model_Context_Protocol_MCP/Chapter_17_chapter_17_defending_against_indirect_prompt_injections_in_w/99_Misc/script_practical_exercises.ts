/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { z } from 'zod';

// Define strict schemas for MCP tool payloads
export const BrowserNavigateSchema = z.object({
  url: z.string().url(),
  action: z.enum(['click', 'type', 'extract']),
  selector: z.string().optional(),
  value: z.string().optional(),
});

export type BrowserNavigatePayload = z.infer<typeof BrowserNavigateSchema>;

export class IndirectInjectionDetectedError extends Error {
  constructor(public toolName: string, public reason: string) {
    super(`Security violation detected in tool '${toolName}': ${reason}`);
    this.name = 'IndirectInjectionDetectedError';
  }
}

export interface GuardrailClient {
  validatePayload(toolName: string, payload: unknown, pageContext: string): Promise<{ safe: boolean; reason?: string }>;
}

export class SecureMCPExecutor {
  constructor(private guardrail: GuardrailClient) {}

  public async executeTool(toolName: string, payload: unknown, pageContext: string): Promise<unknown> {
    // TODO: Implement strict validation and guardrail checks before executing the MCP tool.
    throw new Error('Not implemented');
  }
}
