/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import 'server-only';
import React from 'react';

export interface SanitizedWebPreviewProps {
  rawHtml: string;
  sourceUrl: string;
  susposityScore: number;
}

/**
 * A Next.js Server Component that renders untrusted web content safely,
 * stripping malicious DOM structures and highlighting potential indirect prompt injections.
 */
export async function SanitizedWebPreview({
  rawHtml,
  sourceUrl,
  susposityScore,
}: SanitizedWebPreviewProps): Promise<JSX.Element> {
  // TODO: Implement server-side DOM sanitization and injection highlighting.
  return (
    <div className="border border-slate-700 rounded-lg p-4 bg-slate-900 text-slate-100">
      <h3 className="text-sm font-semibold text-slate-400">Secure Web Preview: {sourceUrl}</h3>
      {/* Render sanitized output here */}
    </div>
  );
}
