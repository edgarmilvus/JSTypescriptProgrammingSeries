/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { randomUUID } from 'crypto';

/**
 * Represents the execution status of an autonomous tool call.
 */
type ExecutionStatus = 'SUCCESS' | 'FAILURE' | 'REPLAYED';

/**
 * Interface defining the payload structure for an MCP tool execution audit log.
 */
interface AuditLogEntry {
  readonly auditId: string;
  readonly sessionId: string;
  readonly timestamp: number;
  readonly toolName: string;
  readonly inputPayload: Record<string, unknown>;
  outputPayload?: unknown;
  error?: string;
  durationMs: number;
  status: ExecutionStatus;
}

/**
 * Interface representing a mock database row for a SaaS workspace resource.
 */
interface WorkspaceResource {
  id: string;
  name: string;
  tier: 'free' | 'pro' | 'enterprise';
  updatedAt: string;
}

/**
 * In-memory data store simulating a SaaS backend database.
 */
class SaaSWorkspaceDatabase {
  private store: Map<string, WorkspaceResource> = new Map([
    ['res_123', { id: 'res_123', name: 'Alpha Project', tier: 'free', updatedAt: new Date().toISOString() }]
  ]);

  /**
   * Updates a workspace resource tier.
   */
  public async updateResourceTier(id: string, newTier: 'free' | 'pro' | 'enterprise'): Promise<WorkspaceResource> {
    // Simulate network or database latency
    await new Promise((resolve) => setTimeout(resolve, 50));
    
    const resource = this.store.get(id);
    if (!resource) {
      throw new Error(`Resource with ID ${id} not found.`);
    }

    const updated: WorkspaceResource = {
      ...resource,
      tier: newTier,
      updatedAt: new Date().toISOString(),
    };

    this.store.set(id, updated);
    return updated;
  }

  /**
   * Retrieves a resource by ID.
   */
  public async getResource(id: string): Promise<WorkspaceResource | null> {
    await new Promise((resolve) => setTimeout(resolve, 20));
    return this.store.get(id) || null;
  }
}

/**
 * In-memory Audit Log Store acting as an append-only ledger.
 */
class AuditLogLedger {
  private logs: AuditLogEntry[] = [];

  /**
   * Appends an audit entry to the immutable ledger.
   */
  public append(entry: AuditLogEntry): void {
    // Freeze the object to prevent mutation after writing
    this.logs.push(Object.freeze({ ...entry }));
  }

  /**
   * Retrieves all audit logs for a given session.
   */
  public getSessionLogs(sessionId: string): AuditLogEntry[] {
    return this.logs.filter((log) => log.sessionId === sessionId);
  }
}

/**
 * MCP Tool Handler with built-in audit logging interception.
 */
class AuditedMCPToolServer {
  private db: SaaSWorkspaceDatabase;
  private ledger: AuditLogLedger;
  private sessionId: string;

  constructor(db: SaaSWorkspaceDatabase, ledger: AuditLogLedger, sessionId: string) {
    this.db = db;
    this.ledger = ledger;
    this.sessionId = sessionId;
  }

  /**
   * Executes an MCP tool action with full audit instrumentation.
   * @param toolName The name of the registered MCP tool.
   * @param inputPayload The arguments passed by the autonomous agent.
   */
  public async executeTool(toolName: string, inputPayload: Record<string, unknown>): Promise<unknown> {
    const auditId = randomUUID();
    const startTime = Date.now();
    let status: ExecutionStatus = 'SUCCESS';
    let outputPayload: unknown = undefined;
    let errorMessage: string | undefined = undefined;

    try {
      // Route tool execution based on registered tool name
      switch (toolName) {
        case 'upgrade_workspace_tier': {
          const { resourceId, targetTier } = inputPayload as { resourceId: string; targetTier: 'free' | 'pro' | 'enterprise' };
          outputPayload = await this.db.updateResourceTier(resourceId, targetTier);
          break;
        }
        case 'get_workspace_resource': {
          const { resourceId } = inputPayload as { resourceId: string };
          outputPayload = await this.db.getResource(resourceId);
          break;
        }
        default:
          throw new Error(`Unrecognized MCP tool execution target: ${toolName}`);
      }
      return outputPayload;
    } catch (error) {
      status = 'FAILURE';
      errorMessage = error instanceof Error ? error.message : String(error);
      throw error;
    } finally {
      const durationMs = Date.now() - startTime;
      
      // Construct and write the immutable audit log entry
      const entry: AuditLogEntry = {
        auditId,
        sessionId: this.sessionId,
        timestamp: Date.now(),
        toolName,
        inputPayload,
        outputPayload,
        error: errorMessage,
        durationMs,
        status,
      };

      this.ledger.append(entry);
    }
  }
}

/**
 * Stateful Replay Engine capable of replaying past agent sessions using audit logs.
 */
class AgentReplayEngine {
  /**
   * Replays an entire session deterministically against a sandbox or mock state.
   * @param logs The sequence of audit log entries for a session.
   */
  public async replaySession(logs: AuditLogEntry[]): Promise<Map<string, unknown>> {
    const replayState = new Map<string, unknown>();
    // Sort logs chronologically to guarantee correct sequence ordering
    const sortedLogs = [...logs].sort((a, b) => a.timestamp - b.timestamp);

    console.log(`[ReplayEngine] Starting replay for session. Total actions: ${sortedLogs.length}`);

    for (const log of sortedLogs) {
      console.log(`[ReplayEngine] Replaying action: ${log.toolName} (Audit ID: ${log.auditId})`);
      
      if (log.status === 'FAILURE') {
        console.warn(`[ReplayEngine] Action ${log.auditId} previously failed with error: ${log.error}. Skipping state application.`);
        continue;
      }

      // Instead of hitting live external APIs or databases, the replay engine 
      // uses the recorded output payload to simulate state transitions.
      replayState.set(log.auditId, {
        toolName: log.toolName,
        input: log.inputPayload,
        simulatedOutput: log.outputPayload,
        replayedAt: new Date().toISOString()
      });
    }

    console.log(`[ReplayEngine] Replay completed successfully.`);
    return replayState;
  }
}

// ==========================================
// Execution Demonstration (Self-Contained)
// ==========================================
async function runDemo() {
  const db = new SaaSWorkspaceDatabase();
  const ledger = new AuditLogLedger();
  const sessionId = 'session_xyz_789';

  const mcpServer = new AuditedMCPToolServer(db, ledger, sessionId);

  console.log('--- Executing Autonomous Agent Actions ---');
  
  // Agent Action 1: Inspect resource
  await mcpServer.executeTool('get_workspace_resource', { resourceId: 'res_123' });

  // Agent Action 2: Upgrade resource tier
  await mcpServer.executeTool('upgrade_workspace_tier', { resourceId: 'res_123', targetTier: 'pro' });

  // Fetch session logs from immutable ledger
  const sessionLogs = ledger.getSessionLogs(sessionId);
  console.log(`Captured ${sessionLogs.length} audit log entries.`);

  console.log('\n--- Initiating Replay Engine ---');
  const replayEngine = new AgentReplayEngine();
  const replayResults = await replayEngine.replaySession(sessionLogs);

  console.log('\n--- Replay State Summary ---');
  for (const [auditId, state] of replayResults.entries()) {
    console.log(`Audit ID: ${auditId}`, JSON.stringify(state, null, 2));
  }
}

runDemo();
