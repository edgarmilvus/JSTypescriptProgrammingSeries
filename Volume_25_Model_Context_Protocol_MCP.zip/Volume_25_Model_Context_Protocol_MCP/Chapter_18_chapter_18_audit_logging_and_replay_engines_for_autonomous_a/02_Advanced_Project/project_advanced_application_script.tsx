/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { z } from "zod";
import { createStreamableUI, readStreamableValue } from "ai/rsc";
import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

// ==========================================
// 1. DOMAIN SCHEMAS & TYPES
// ==========================================

/**
 * Schema defining a single immutable audit event in an agent session.
 */
const AuditEventSchema = z.object({
  eventId: z.string().uuid(),
  sessionId: z.string(),
  timestamp: z.string().datetime(),
  actor: z.enum(["agent", "mcp_tool", "browser_vision", "system"]),
  actionType: z.string(),
  payload: z.record(z.any()),
  status: z.enum(["success", "error", "pending"]),
  errorDetails: z.string().optional(),
});

type AuditEvent = z.infer<typeof AuditEventSchema>;

/**
 * Replay configuration for stepping through recorded agent sessions.
 */
interface ReplayOptions {
  sessionId: string;
  speedMultiplier?: number;
  onStep?: (event: AuditEvent) => void;
}

// ==========================================
// 2. AUDIT LOGGING & REPLAY ENGINE CORE
// ==========================================

/**
 * Handles exhaustive asynchronous resilience, file-system persistence,
 * and deterministic state reconstruction for agent sessions.
 */
export class AgentAuditAndReplayEngine {
  private logDirectory: string;

  constructor(logDir: string = "./audit-logs") {
    this.logDirectory = path.resolve(logDir);
    this.initializeStorage();
  }

  /**
   * Ensures the audit log storage directory exists safely.
   */
  private async initializeStorage(): Promise<void> {
    try {
      await fs.mkdir(this.logDirectory, { recursive: true });
    } catch (error) {
      console.error("Failed to initialize audit log storage directory:", error);
      throw new Error("Audit storage initialization failed.");
    } finally {
      // Resource check hook if needed
    }
  }

  /**
   * Appends an event to the session audit trail with strict serialization.
   */
  public async logEvent(event: AuditEvent): Promise<void> {
    const validated = AuditEventSchema.parse(event);
    const filePath = path.join(this.logDirectory, `${validated.sessionId}.jsonl`);

    try {
      const serialized = JSON.stringify(validated) + "\n";
      await fs.appendFile(filePath, serialized, { encoding: "utf-8" });
    } catch (error) {
      console.error(`[Exhaustive Async Resilience] Failed to write audit event ${validated.eventId}:`, error);
      throw new Error("Audit log persistence failed.");
    } finally {
      // Guarantee any cleanup hooks fire if necessary
    }
  }

  /**
   * Loads an entire session's events for stateful replay.
   */
  public async loadSession(sessionId: string): Promise<AuditEvent[]> {
    const filePath = path.join(this.logDirectory, `${sessionId}.jsonl`);
    try {
      const data = await fs.readFile(filePath, { encoding: "utf-8" });
      return data
        .split("\n")
        .filter((line) => line.trim().length > 0)
        .map((line) => AuditEventSchema.parse(JSON.parse(line)));
    } catch (error) {
      console.error(`Failed to load session trace for ${sessionId}:`, error);
      return [];
    }
  }

  /**
   * Replays a session deterministically, simulating time delays or callbacks.
   */
  public async replaySession(options: ReplayOptions): Promise<void> {
    const events = await this.loadSession(options.sessionId);
    const speed = options.speedMultiplier || 1;

    for (let i = 0; i < events.length; i++) {
      const currentEvent = events[i];
      
      // Calculate realistic pause based on timestamps if next event exists
      if (i < events.length - 1) {
        const currentMs = new Date(currentEvent.timestamp).getTime();
        const nextMs = new Date(events[i + 1].timestamp).getTime();
        const delta = Math.max(0, nextMs - currentMs);
        
        if (delta > 0) {
          await new Promise((resolve) => setTimeout(resolve, delta / speed));
        }
      }

      if (options.onStep) {
        options.onStep(currentEvent);
      }
    }
  }
}

// ==========================================
// 3. NEXT.JS API ROUTE & STREAMABLE UI
// ==========================================

const engine = new AgentAuditAndReplayEngine();

/**
 * Next.js POST handler to execute a tool step, record it to the audit log,
 * and stream the dynamic UI component back to the client.
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { sessionId, toolName, arguments: toolArgs } = body;

    const streamable = createStreamableUI(
      <div className="p-4 border rounded-md bg-zinc-900 text-white animate-pulse">
        Initializing MCP Tool: {toolName}...
      </div>
    );

    // Execute the asynchronous agent workflow in the background
    (async () => {
      try {
        // Step 1: Log pending execution event
        const eventId = crypto.randomUUID();
        await engine.logEvent({
          eventId,
          sessionId,
          timestamp: new Date().toISOString(),
          actor: "mcp_tool",
          actionType: `EXECUTE_${toolName}`,
          payload: toolArgs,
          status: "pending",
        });

        // Simulate MCP Tool execution and Vision-driven Browser interaction
        await new Promise((resolve) => setTimeout(resolve, 1500));

        // Step 2: Log successful completion
        await engine.logEvent({
          eventId,
          sessionId,
          timestamp: new Date().toISOString(),
          actor: "mcp_tool",
          actionType: `EXECUTE_${toolName}`,
          payload: { result: "Success: Browser state captured." },
          status: "success",
        });

        // Update the Streamable UI with the final rendered React component
        streamable.update(
          <div className="p-4 border border-emerald-500 rounded-md bg-zinc-900 text-emerald-300">
            <h4 className="font-bold">MCP Tool Executed Successfully</h4>
            <p className="text-sm text-zinc-400">Tool: {toolName}</p>
            <pre className="mt-2 text-xs bg-zinc-950 p-2 rounded">
              {JSON.stringify(toolArgs, null, 2)}
            </pre>
          </div>
        );
        streamable.done();
      } catch (err: any) {
        streamable.update(
          <div className="p-4 border border-red-500 rounded-md bg-zinc-900 text-red-300">
            <h4 className="font-bold">Execution Failed</h4>
            <p className="text-sm">{err.message}</p>
          </div>
        );
        streamable.done();
      }
    })();

    return NextResponse.json({ ui: streamable.value });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
