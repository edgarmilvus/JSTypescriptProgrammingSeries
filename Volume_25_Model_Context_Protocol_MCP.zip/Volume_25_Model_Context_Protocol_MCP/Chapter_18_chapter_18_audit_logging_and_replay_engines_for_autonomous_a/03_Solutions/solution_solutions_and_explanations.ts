/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { randomUUID } from 'crypto';

export interface SerializedError {
  name: string;
  message: string;
  stack?: string;
}

export interface TraceRecord {
  traceId: string;
  stepIndex: number;
  timestamp: string;
  hrTime: string;
  toolName: string;
  input: unknown;
  output?: unknown;
  error?: SerializedError;
  durationMs: number;
}

export interface AuditStorageBackend {
  persist(record: TraceRecord): Promise<void>;
}

export class DeterministicTraceLogger {
  private traceId: string;
  private stepIndex: number = 0;
  private storage: AuditStorageBackend;

  constructor(storage: AuditStorageBackend, traceId?: string) {
    this.storage = storage;
    this.traceId = traceId ?? randomUUID();
  }

  public async interceptToolExecution<TInput, TOutput>(
    toolName: string,
    input: TInput,
    executor: () => Promise<TOutput>
  ): Promise<TOutput> {
    const currentStep = this.stepIndex++;
    const timestamp = new Date().toISOString();
    const startHr = process.hrtime.bigint();

    let output: TOutput | undefined;
    let serializedError: SerializedError | undefined;

    try {
      output = await executor();
      return output;
    } catch (error: unknown) {
      if (error instanceof Error) {
        serializedError = {
          name: error.name,
          message: error.message,
          stack: error.stack,
        };
      } else {
        serializedError = {
          name: 'UnknownError',
          message: String(error),
        };
      }
      throw error;
    } finally {
      const endHr = process.hrtime.bigint();
      const durationMs = Number(endHr - startHr) / 1_000_000;

      const record: TraceRecord = {
        traceId: this.traceId,
        stepIndex: currentStep,
        timestamp,
        hrTime: startHr.toString(),
        toolName,
        input,
        output,
        error: serializedError,
        durationMs,
      };

      try {
        await this.storage.persist(record);
      } catch (persistenceError) {
        console.error(
          `[DeterministicTraceLogger] CRITICAL: Failed to persist trace record for tool '${toolName}' (TraceId: ${this.traceId}, Step: ${currentStep}):`,
          persistenceError
        );
      }
    }
  }
}
