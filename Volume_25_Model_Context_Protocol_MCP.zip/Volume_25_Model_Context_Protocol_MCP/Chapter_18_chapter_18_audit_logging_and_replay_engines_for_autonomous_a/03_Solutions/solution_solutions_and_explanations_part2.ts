/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { TraceRecord } from './exercise-1';

export type ReplayState = 'IDLE' | 'LOADING' | 'PAUSED' | 'REPLAYING' | 'COMPLETED' | 'ERROR';

export type ActionReplayHandler = (record: TraceRecord) => Promise<boolean>;

export class StatefulReplayEngine {
  private records: TraceRecord[] = [];
  private currentIndex: number = 0;
  private state: ReplayState = 'IDLE';
  private handler: ActionReplayHandler;

  constructor(handler: ActionReplayHandler) {
    this.handler = handler;
  }

  public async loadTraceStream(recordsIterable: AsyncIterable<TraceRecord>): Promise<void> {
    this.state = 'LOADING';
    try {
      const loaded: TraceRecord[] = [];
      for await (const record of recordsIterable) {
        loaded.push(record);
      }
      this.records = loaded;
      this.currentIndex = 0;
      this.state = 'IDLE';
    } catch (error) {
      this.state = 'ERROR';
      throw new Error(`Failed to load trace stream: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  public async stepForward(): Promise<boolean> {
    if (this.state === 'COMPLETED' || this.state === 'ERROR') {
      throw new Error(`Cannot step forward while engine is in state: ${this.state}`);
    }

    if (this.currentIndex >= this.records.length) {
      this.state = 'COMPLETED';
      return false;
    }

    this.state = 'REPLAYING';
    const record = this.records[this.currentIndex];

    try {
      const success = await this.handler(record);
      if (!success) {
        this.state = 'ERROR';
        return false;
      }
      this.currentIndex++;
      this.state = this.currentIndex >= this.records.length ? 'COMPLETED' : 'PAUSED';
      return true;
    } catch (error) {
      this.state = 'ERROR';
      console.error(`[StatefulReplayEngine] Replay failed at step ${this.currentIndex} (${record.toolName}):`, error);
      throw error;
    } finally {
      if (this.state === 'REPLAYING') {
        this.state = 'ERROR';
      }
    }
  }

  public getState(): ReplayState {
    return this.state;
  }

  public getCurrentIndex(): number {
    return this.currentIndex;
  }
}
