/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { createHash } from 'crypto';
import { TraceRecord } from './exercise-1';

export interface ChainNode {
  record: TraceRecord;
  previousHash: string;
  nonce: number;
  currentHash: string;
}

export class ChainOfCustodyLogger {
  private lastHash: string = '0'.repeat(64); // Genesis hash
  private nonceCounter: number = 0;

  public async appendRecord(record: TraceRecord): Promise<ChainNode> {
    const nonce = this.nonceCounter++;
    const previousHash = this.lastHash;
    
    const payload = JSON.stringify({
      previousHash,
      nonce,
      record,
    });

    const currentHash = createHash('sha256').update(payload).digest('hex');
    this.lastHash = currentHash;

    return {
      record,
      previousHash,
      nonce,
      currentHash,
    };
  }

  public static async verifyChain(nodes: ChainNode[]): Promise<boolean> {
    if (!nodes || nodes.length === 0) return true;

    let expectedPreviousHash = '0'.repeat(64);

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];

      if (node.previousHash !== expectedPreviousHash) {
        return false;
      }

      const payload = JSON.stringify({
        previousHash: node.previousHash,
        nonce: node.nonce,
        record: node.record,
      });

      const recomputedHash = createHash('sha256').update(payload).digest('hex');

      if (recomputedHash !== node.currentHash) {
        return false;
      }

      expectedPreviousHash = node.currentHash;
    }

    return true;
  }
}
