/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { ChainNode } from './exercise-3';

export interface AuditStreamExplorerProps {
  nodes: ChainNode[];
  isVerified: boolean;
  onStepSelect?: (node: ChainNode, index: number) => void;
}

export const AuditStreamExplorer: React.FC<AuditStreamExplorerProps> = ({
  nodes,
  isVerified,
  onStepSelect,
}) => {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1000); // ms per step

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setActiveIndex((prevIndex) => {
          if (prevIndex >= nodes.length - 1) {
            setIsPlaying(false);
            return prevIndex;
          }
          const nextIndex = prevIndex + 1;
          if (onStepSelect && nodes[nextIndex]) {
            onStepSelect(nodes[nextIndex], nextIndex);
          }
          return nextIndex;
        });
      }, playbackSpeed);
    }
    return () => clearInterval(timer);
  }, [isPlaying, nodes, playbackSpeed, onStepSelect]);

  const handleSelectStep = (index: number) => {
    setActiveIndex(index);
    if (onStepSelect && nodes[index]) {
      onStepSelect(nodes[index], index);
    }
  };

  const currentNode = nodes[activeIndex];

  if (!nodes || nodes.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500">
        <p>No audit logs available for inspection.</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans">
      {/* Left Panel: Timeline & Verification Status */}
      <div className="w-1/3 border-r border-gray-800 flex flex-col">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h2 className="text-lg font-semibold">Audit Trace Timeline</h2>
          <span className={`px-2 py-1 text-xs rounded ${isVerified ? 'bg-green-800 text-green-200' : 'bg-red-800 text-red-200'}`}>
            {isVerified ? 'Chain Valid' : 'Tampered'}
          </span>
        </div>
        <div className="overflow-y-auto flex-1 p-4 space-y-2">
          {nodes.map((node, idx) => (
            <div
              key={`${node.currentHash}-${idx}`}
              onClick={() => handleSelectStep(idx)}
              className={`p-3 rounded cursor-pointer transition-colors ${
                idx === activeIndex ? 'bg-blue-600 text-white' : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
              }`}
            >
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono">#{idx}</span>
                <span>{node.record.timestamp}</span>
              </div>
              <div className="font-semibold text-sm mt-1">{node.record.toolName}</div>
              <div className="text-xs text-gray-400 mt-0.5">Duration: {node.record.durationMs.toFixed(2)}ms</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Panel: Step Detail Inspector & Playback Controls */}
      <div className="w-2/3 flex flex-col">
        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          {currentNode ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold">{currentNode.record.toolName}</h3>
                  <p className="text-sm text-gray-400">Timestamp: {currentNode.record.timestamp}</p>
                </div>
                <div className="text-right text-xs text-gray-400">
                  <p>Step Index: {activeIndex} / {nodes.length - 1}</p>
                  <p>Duration: {currentNode.record.durationMs.toFixed(2)}ms</p>
                </div>
              </div>

              <div className="bg-gray-800 p-4 rounded">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">Input Payload</h4>
                <pre className="text-xs font-mono overflow-x-auto text-blue-300 bg-gray-950 p-3 rounded">
                  {JSON.stringify(currentNode.record.input, null, 2)}
                </pre>
              </div>

              {currentNode.record.output && (
                <div className="bg-gray-800 p-4 rounded">
                  <h4 className="text-sm font-semibold text-gray-300 mb-2">Output Result</h4>
                  <pre className="text-xs font-mono overflow-x-auto text-green-300 bg-gray-950 p-3 rounded">
                    {JSON.stringify(currentNode.record.output, null, 2)}
                  </pre>
                </div>
              )}

              {currentNode.record.error && (
                <div className="bg-red-950/50 border border-red-800 p-4 rounded">
                  <h4 className="text-sm font-semibold text-red-300 mb-2">Captured Error</h4>
                  <p className="text-xs font-bold text-red-200">{currentNode.record.error.name}: {currentNode.record.error.message}</p>
                  {currentNode.record.error.stack && (
                    <pre className="text-xs font-mono mt-2 text-red-400 overflow-x-auto">{currentNode.record.error.stack}</pre>
                  )}
                </div>
              )}

              <div className="bg-gray-800 p-4 rounded">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">Cryptographic Hash</h4>
                <code className="text-xs font-mono text-green-400 break-all">{currentNode.currentHash}</code>
                <p className="text-xs text-gray-500 mt-1">Previous Hash: {currentNode.previousHash}</p>
              </div>
            </div>
          ) : (
            <p className="text-gray-500">Select a step to inspect details.</p>
          )}
        </div>

        {/* Playback Control Toolbar */}
        <div className="p-4 border-t border-gray-800 flex justify-between items-center bg-gray-950">
          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-400">Speed:</span>
            <select
              value={playbackSpeed}
              onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
              className="bg-gray-800 text-xs text-white rounded px-2 py-1 border border-gray-700"
            >
              <option value={2000}>0.5x</option>
              <option value={1000}>1x</option>
              <option value={500}>2x</option>
              <option value={200}>5x</option>
            </select>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => handleSelectStep(0)}
              disabled={activeIndex === 0}
              className="px-3 py-1 bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-xs rounded"
            >
              First
            </button>
            <button
              onClick={() => handleSelectStep(activeIndex - 1)}
              disabled={activeIndex === 0}
              className="px-3 py-1 bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-xs rounded"
            >
              Previous
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 font-semibold text-xs rounded"
            >
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              onClick={() => handleSelectStep(activeIndex + 1)}
              disabled={activeIndex >= nodes.length - 1}
              className="px-3 py-1 bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-xs rounded"
            >
              Next
            </button>
            <button
              onClick={() => handleSelectStep(nodes.length - 1)}
              disabled={activeIndex >= nodes.length - 1}
              className="px-3 py-1 bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-xs rounded"
            >
              Last
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
