/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { randomUUID } from 'crypto';

export interface SerializedError {
  name: string;
  message: string;
  stack?: string;
}

export interface TraceRecord {
  traceId: string;
  stepIndex: number;
  timestamp: string;
  hrTime: string;
  toolName: string;
  input: unknown;
  output?: unknown;
  error?: SerializedError;
  durationMs: number;
}

export interface AuditStorageBackend {
  persist(record: TraceRecord): Promise<void>;
}

export class DeterministicTraceLogger {
  private traceId: string;
  private stepIndex: number = 0;
  private storage: AuditStorageBackend;

  constructor(storage: AuditStorageBackend, traceId?: string) {
    this.storage = storage;
    this.traceId = traceId ?? randomUUID();
  }

  /**
   * TODO: Implement the wrapper method that intercepts an asynchronous tool execution,
   * measures its duration using process.hrtime.bigint(), serializes inputs and outputs,
   * and persists the record through the AuditStorageBackend while adhering to 
   * Exhaustive Asynchronous Resilience principles.
   */
  public async interceptToolExecution<TInput, TOutput>(
    toolName: string,
    input: TInput,
    executor: () => Promise<TOutput>
  ): Promise<TOutput> {
    // Write your implementation here
    throw new Error('Not implemented');
  }
}
