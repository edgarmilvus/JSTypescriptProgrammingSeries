/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { TraceRecord } from './exercise-1';

export type ReplayState = 'IDLE' | 'LOADING' | 'PAUSED' | 'REPLAYING' | 'COMPLETED' | 'ERROR';

export type ActionReplayHandler = (record: TraceRecord) => Promise<boolean>;

export class StatefulReplayEngine {
  private records: TraceRecord[] = [];
  private currentIndex: number = 0;
  private state: ReplayState = 'IDLE';
  private handler: ActionReplayHandler;

  constructor(handler: ActionReplayHandler) {
    this.handler = handler;
  }

  public async loadTraceStream(recordsIterable: AsyncIterable<TraceRecord>): Promise<void> {
    // TODO: Load records into memory and handle asynchronous iteration errors safely.
    throw new Error('Not implemented');
  }

  /**
   * TODO: Implement stepForward. It should check if the engine is in a valid state,
   * execute the current record via the handler, update the index, and manage state transitions.
   * Ensure exhaustive async resilience with try/catch/finally blocks.
   */
  public async stepForward(): Promise<boolean> {
    // Write your implementation here
    throw new Error('Not implemented');
  }

  public getState(): ReplayState {
    return this.state;
  }

  public getCurrentIndex(): number {
    return this.currentIndex;
  }
}
