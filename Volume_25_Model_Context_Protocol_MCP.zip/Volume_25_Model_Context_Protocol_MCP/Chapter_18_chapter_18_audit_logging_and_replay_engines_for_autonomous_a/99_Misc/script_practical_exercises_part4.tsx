/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect } from 'react';
import { ChainNode } from './exercise-3';

export interface AuditStreamExplorerProps {
  nodes: ChainNode[];
  isVerified: boolean;
  onStepSelect?: (node: ChainNode, index: number) => void;
}

export const AuditStreamExplorer: React.FC<AuditStreamExplorerProps> = ({
  nodes,
  isVerified,
  onStepSelect,
}) => {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // TODO: Implement the useEffect hook for auto-playback when isPlaying is true,
  // ensuring proper interval cleanup on unmount or pause.

  const currentNode = nodes[activeIndex];

  if (!nodes || nodes.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500">
        <p>No audit logs available for inspection.</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans">
      {/* Left Panel: Timeline & Verification Status */}
      <div className="w-1/3 border-r border-gray-800 flex flex-col">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h2 className="text-lg font-semibold">Audit Trace Timeline</h2>
          <span className={`px-2 py-1 text-xs rounded ${isVerified ? 'bg-green-800 text-green-200' : 'bg-red-800 text-red-200'}`}>
            {isVerified ? 'Chain Valid' : 'Tampered'}
          </span>
        </div>
        <div className="overflow-y-auto flex-1 p-4 space-y-2">
          {/* TODO: Map through nodes and render interactive timeline list items */}
        </div>
      </div>

      {/* Right Panel: Step Detail Inspector & Playback Controls */}
      <div className="w-2/3 flex flex-col">
        <div className="p-6 flex-1 overflow-y-auto">
          {currentNode ? (
            <div className="space-y-4">
              <h3 className="text-xl font-bold">{currentNode.record.toolName}</h3>
              <p className="text-sm text-gray-400">Timestamp: {currentNode.record.timestamp}</p>
              <div className="bg-gray-800 p-4 rounded">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">Input Payload</h4>
                <pre className="text-xs overflow-x-auto">{JSON.stringify(currentNode.record.input, null, 2)}</pre>
              </div>
              <div className="bg-gray-800 p-4 rounded">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">Cryptographic Hash</h4>
                <code className="text-xs text-green-400">{currentNode.currentHash}</code>
              </div>
            </div>
          ) : (
            <p className="text-gray-500">Select a step to inspect details.</p>
          )}
        </div>

        {/* Playback Control Toolbar */}
        <div className="p-4 border-t border-gray-800 flex justify-center items-center space-x-4 bg-gray-950">
          {/* TODO: Implement Play, Pause, Previous, and Next buttons */}
        </div>
      </div>
    </div>
  );
};
