/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';
import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';

/**
 * @file eu-ai-act-guardrail.ts
 * @description Demonstrates a foundational EU AI Act compliance pattern in TypeScript:
 * Enforcing structural risk classification and mandatory human-in-the-loop (HITL) 
 * approval parameters via LLM JSON Schema output validation for high-risk AI tools.
 */

// 1. Define the Zod schema representing an EU AI Act High-Risk System Decision payload.
// This structure maps directly to compliance metadata requirements under Article 14 
// (Human Oversight) and Article 15 (Accuracy, Robustness, and Cybersecurity).
const RiskEvaluationSchema = z.object({
  actionSummary: z.string().describe("A concise summary of the autonomous tool execution or browser action."),
  riskCategory: z.enum(['MINIMAL', 'HIGH_RISK', 'PROHIBITED']).describe(
    "EU AI Act risk classification tier based on intended use and domain."
  ),
  requiresHumanApproval: z.boolean().describe(
    "Mandatory flag. Must be true if riskCategory is HIGH_RISK or PROHIBITED, enforcing Article 14 HITL."
  ),
  justification: z.string().describe("Legal or operational justification for the assigned risk tier."),
});

// Infer the TypeScript type from the Zod schema for type-safe handling downstream.
type RiskEvaluation = z.infer<typeof RiskEvaluationSchema>;

/**
 * Evaluates an incoming autonomous agent action request against EU AI Act criteria.
 * Utilizes Vercel AI SDK's `generateObject` with strict JSON Schema output.
 * 
 * @param agentActionDescription - The raw textual description of the tool or browser action.
 * @returns A strictly typed RiskEvaluation object guaranteed to conform to the schema.
 */
async function evaluateAgentActionCompliance(agentActionDescription: string): Promise<RiskEvaluation> {
  console.log(`[Compliance Engine] Analyzing action against EU AI Act parameters...`);

  // 2. Call the underlying LLM with structured output enforcement.
  // This prevents malformed JSON responses and ensures the model populates 
// every required field with the correct data type.
  const response = await generateObject({
    model: openai('gpt-4o'),
    schema: RiskEvaluationSchema,
    system: `
      You are an automated regulatory compliance guardian embedded within an enterprise SaaS platform. 
      Your sole responsibility is to evaluate autonomous Model Context Protocol (MCP) agent actions 
      and browser-use automation tasks against the regulatory framework of the European Union AI Act.
      
      Classify actions accurately:
      - PROHIBITED: Manipulation, social scoring, biometric categorization of sensitive traits.
      - HIGH_RISK: Critical infrastructure, employment, educational evaluation, law enforcement, 
        or automated execution of financial/legal workflows.
      - MINIMAL: Routine data retrieval, text formatting, or low-impact internal administrative tasks.
      
      CRITICAL RULE: If the riskCategory is HIGH_RISK or PROHIBITED, you MUST set requiresHumanApproval to true.
    `,
    prompt: `Evaluate the following agent action: "${agentActionDescription}"`,
  });

  // 3. Return the fully typed and validated object.
  return response.object;
}

/**
 * Simulates a SaaS workflow dispatching an autonomous browser action.
 */
async function runSaaSWorkflowSimulation() {
  const sampleUserAction = "Execute an automated bulk update of customer credit limits in the core billing database via browser automation.";
  
  try {
    const evaluation = await evaluateAgentActionCompliance(sampleUserAction);
    
    console.log("\n--- EU AI ACT COMPLIANCE EVALUATION RESULT ---");
    console.log(JSON.stringify(evaluation, null, 2));

    // 4. Implement conditional gatekeeping based on compliance output
    if (evaluation.requiresHumanApproval) {
      console.warn("\n[GATEKEEPER] 🛑 ACTION HALTED: High-risk or prohibited AI operation detected.");
      console.warn("[GATEKEEPER] Routing execution payload to designated human compliance officer queue...");
      // In a production app, trigger WebSocket notification or insert into approval database table here.
    } else {
      console.log("\n[GATEKEEPER] ✅ ACTION APPROVED: Proceeding with autonomous MCP execution.");
    }

  } catch (error) {
    console.error("[Compliance Engine] Fatal error during schema generation or validation:", error);
  }
}

// Execute the simulation
runSaaSWorkflowSimulation();
