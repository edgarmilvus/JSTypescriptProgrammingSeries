/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createHash } from 'crypto';

/**
 * @file route.ts
 * @description Enterprise MCP & Computer-Use Agent Gateway with EU AI Act Compliance
 * Features: PII Redaction, Human-in-the-Loop (HITL) Interception, and Immutable Cryptographic Audit Trails.
 */

// ==========================================
// 1. SCHEMAS & TYPE DEFINITIONS (Zod & TS)
// ==========================================

/**
 * Schema defining incoming computer-use tool execution requests from the MCP client.
 */
const ToolExecutionRequestSchema = z.object({
  agentId: z.string().uuid(),
  sessionId: z.string().uuid(),
  actionType: z.enum(['CLICK', 'TYPE', 'NAVIGATE', 'EXECUTE_BASH', 'EXTRACT_DOM']),
  payload: z.record(z.any()),
  requiresHighRiskApproval: z.boolean().default(false),
});

type ToolExecutionRequest = z.infer<typeof ToolExecutionRequestSchema>;

/**
 * Schema for audit log entries required by EU AI Act Article 12 (Record-keeping).
 */
interface ImmutableAuditRecord {
  sequenceId: number;
  timestamp: string;
  agentId: string;
  sessionId: string;
  actionType: string;
  sanitizedPayload: Record<string, any>;
  riskLevel: 'MINIMAL' | 'HIGH';
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'EXECUTED' | 'REDACTED';
  previousHash: string;
  currentHash: string;
}

// In-memory simulation of an immutable ledger (in production, use append-only write-once-read-many storage)
const auditLedger: ImmutableAuditRecord[] = [];

// ==========================================
// 2. COMPLIANCE ENGINES (PII & HITL)
// ==========================================

/**
 * Regular expressions for detecting European PII (GDPR alignment).
 */
const PII_PATTERNS = {
  email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
  iban: /[A-Z]{2}\d{2}[a-zA-Z0-9]{4,30}/g,
  phone: /(\+\d{1,3}[- ]?)?\d{10}/g,
  creditCard: /\b(?:\d[ -]*?){13,16}\b/g,
};

/**
 * Recursively sanitizes payloads to strip or mask PII before it reaches logging or LLM context windows.
 * @param obj - The input data structure (string, object, or array)
 * @returns Sanitized structure with PII masked out.
 */
function redactPII(obj: any): any {
  if (typeof obj === 'string') {
    let sanitized = obj;
    sanitized = sanitized.replace(PII_PATTERNS.email, '[REDACTED_EMAIL]');
    sanitized = sanitized.replace(PII_PATTERNS.iban, '[REDACTED_IBAN]');
    sanitized = sanitized.replace(PII_PATTERNS.phone, '[REDACTED_PHONE]');
    sanitized = sanitized.replace(PII_PATTERNS.creditCard, '[REDACTED_CC]');
    return sanitized;
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => redactPII(item));
  }
  
  if (obj !== null && typeof obj === 'object') {
    const redactedObj: Record<string, any> = {};
    for (const key of Object.keys(obj)) {
      // Drop fields that inherently contain sensitive metadata
      if (['password', 'secret', 'authorization', 'token'].includes(key.toLowerCase())) {
        redactedObj[key] = '[REDACTED_SENSITIVE_KEY]';
      } else {
        redactedObj[key] = redactPII(obj[key]);
      }
    }
    return redactedObj;
  }
  
  return obj;
}

/**
 * Appends an entry to the cryptographic audit trail ensuring tamper evidence.
 */
function writeAuditRecord(
  agentId: string,
  sessionId: string,
  actionType: string,
  payload: Record<string, any>,
  riskLevel: 'MINIMAL' | 'HIGH',
  status: ImmutableAuditRecord['status']
): ImmutableAuditRecord {
  const sequenceId = auditLedger.length + 1;
  const timestamp = new Date().toISOString();
  const sanitizedPayload = redactPII(payload);
  
  const previousHash = sequenceId === 1 
    ? '0000000000000000000000000000000000000000000000000000000000000000' 
    : auditLedger[auditLedger.length - 1].currentHash;

  const rawStringData = `${sequenceId}:${timestamp}:${agentId}:${sessionId}:${actionType}:${JSON.stringify(sanitizedPayload)}:${previousHash}`;
  const currentHash = createHash('sha256').update(rawStringData).digest('hex');

  const record: ImmutableAuditRecord = {
    sequenceId,
    timestamp,
    agentId,
    sessionId,
    actionType,
    sanitizedPayload,
    riskLevel,
    status,
    previousHash,
    currentHash,
  };

  auditLedger.push(record);
  return record;
}

// ==========================================
// 3. NEXT.JS API ROUTE HANDLER
// ==========================================

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // 1. Validate incoming MCP tool execution payload against schema
    const parseResult = ToolExecutionRequestSchema.safeParse(body);
    if (!parseResult.success) {
      return NextResponse.json(
        { error: 'Invalid tool execution payload', details: parseResult.error.format() },
        { status: 400 }
      );
    }

    const { agentId, sessionId, actionType, payload, requiresHighRiskApproval } = parseResult.data;

    // 2. Determine risk category under EU AI Act guidelines
    // Actions like BASH execution or destructive DOM mutations are classified as high-risk
    const isHighRiskAction = actionType === 'EXECUTE_BASH' || requiresHighRiskApproval;
    const riskLevel = isHighRiskAction ? 'HIGH' : 'MINIMAL';

    // 3. Enforce Human-in-the-Loop (HITL) for High-Risk Interventions
    if (riskLevel === 'HIGH') {
      const approvalHeader = req.headers.get('X-Human-Approval-Token');
      
      if (!approvalHeader) {
        // Log the interception event
        writeAuditRecord(agentId, sessionId, actionType, payload, riskLevel, 'PENDING_APPROVAL');
        
        return NextResponse.json(
          {
            status: 'SUSPENDED_FOR_HUMAN_OVERSIGHT',
            message: 'EU AI Act Article 14 Compliance: This high-risk agent action requires explicit human verification and approval token.',
            agentId,
            sessionId,
            actionType,
          },
          { status: 422 }
        );
      }
      
      // In a production system, validate the cryptographic signature of the approval token here
    }

    // 4. Execute Real-time PII Redaction on Input Parameters
    const sanitizedPayload = redactPII(payload);

    // 5. Simulate Secure Execution of Browser Automation / MCP Tool
    // (e.g., interacting with Playwright or executing approved computer-use actions)
    const executionResult = {
      success: true,
      data: `Successfully executed ${actionType} with sanitized parameters.`,
      timestamp: new Date().toISOString(),
    };

    // 6. Record Immutable Audit Event
    const auditRecord = writeAuditRecord(
      agentId,
      sessionId,
      actionType,
      sanitizedPayload,
      riskLevel,
      'EXECUTED'
    );

    return NextResponse.json({
      status: 'SUCCESS',
      executionResult,
      complianceMetadata: {
        euAiActCompliant: true,
        auditSequenceId: auditRecord.sequenceId,
        auditHash: auditRecord.currentHash,
      },
    }, { status: 200 });

  } catch (error: any) {
    return NextResponse.json(
      { error: 'Internal Server Error during compliance gateway evaluation', message: error.message },
      { status: 500 }
    );
  }
}
