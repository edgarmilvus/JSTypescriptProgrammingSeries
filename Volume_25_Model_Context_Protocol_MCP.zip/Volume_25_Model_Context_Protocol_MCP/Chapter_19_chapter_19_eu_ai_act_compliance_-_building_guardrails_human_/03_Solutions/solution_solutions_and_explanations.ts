/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define Zod Schema for MCP Tool Execution Request
export const McpToolRequestSchema = z.object({
  toolName: z.string().min(1, "Tool name is required"),
  parameters: z.record(z.string(), z.unknown()),
  targetEnvironment: z.enum(["development", "staging", "production"]),
  rationale: z.string().min(10, "Rationale must be at least 10 characters explaining the invocation"),
});

export type McpToolRequest = z.infer<typeof McpToolRequestSchema>;

// Define Risk Assessment Result types
export type RiskLevel = "LOW_RISK" | "HIGH_RISK";

export interface RiskAssessmentResult {
  riskLevel: RiskLevel;
  triggeredArticle: string;
  requiresHitl: boolean;
  validatedRequest: McpToolRequest;
}

// Custom validation error class
export class ComplianceValidationError extends Error {
  constructor(public errors: z.ZodError | string) {
    super(typeof errors === "string" ? errors : JSON.stringify(errors.format(), null, 2));
    this.name = "ComplianceValidationError";
  }
}

// 2. Risk Classification Function
export function classifyMcpAction(request: McpToolRequest): RiskAssessmentResult {
  const dangerousTools = ["execute_shell", "modify_database_schema", "delete_file"];
  
  let riskLevel: RiskLevel = "LOW_RISK";
  let triggeredArticle = "Article 9 - Risk Management System";
  let requiresHitl = false;

  // Rule 1: Production environments are automatically HIGH_RISK (Article 14 - Human Oversight)
  if (request.targetEnvironment === "production") {
    riskLevel = "HIGH_RISK";
    triggeredArticle = "Article 14 - Human Oversight in Production Environments";
    requiresHitl = true;
  }

  // Rule 2: Specific dangerous operations trigger high risk regardless of environment
  if (dangerousTools.includes(request.toolName)) {
    riskLevel = "HIGH_RISK";
    triggeredArticle = "Article 15 - Accuracy, Robustness, and Cybersecurity (Dangerous Tool Execution)";
    requiresHitl = true;
  }

  return {
    riskLevel,
    triggeredArticle,
    requiresHitl,
    validatedRequest: request,
  };
}

// 3. Interactive Challenge: Validate and Classify Raw Agent Output
export async function validateAndClassifyAgentOutput(rawOutput: string): Promise<RiskAssessmentResult> {
  let parsedJson: unknown;
  
  try {
    parsedJson = JSON.parse(rawOutput);
  } catch (err) {
    throw new ComplianceValidationError(`Invalid JSON payload received from LLM: ${(err as Error).message}`);
  }

  const validationResult = McpToolRequestSchema.safeParse(parsedJson);

  if (!validationResult.success) {
    throw new ComplianceValidationError(validationResult.error);
  }

  // Proceed to risk classification upon successful Zod validation
  return classifyMcpAction(validationResult.data);
}
