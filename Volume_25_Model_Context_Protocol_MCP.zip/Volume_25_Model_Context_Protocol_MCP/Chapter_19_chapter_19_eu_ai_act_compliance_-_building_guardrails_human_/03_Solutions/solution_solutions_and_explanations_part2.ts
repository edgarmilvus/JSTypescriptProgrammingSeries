/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Buffer } from "buffer";

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface McpVisionPayload {
  textPrompt: string;
  imageBuffer?: Buffer;
  boundingBoxesToMask?: BoundingBox[];
}

export interface SanitizationResult {
  sanitizedPayload: McpVisionPayload;
  redactionCount: number;
}

// Compliance audit counter tracking state
let globalRedactionCounter = 0;

export function getRedactionCount(): number {
  return globalRedactionCounter;
}

// 1. Text Sanitization Function (Article 10 Data Governance & Privacy)
export function redactTextPii(input: string): string {
  let localCount = 0;

  // Credit Card Redaction: preserves last 4 digits
  const ccRegex = /\b(?:\d[ -]*?){13,16}\b/g;
  let text = input.replace(ccRegex, (match) => {
    localCount++;
    const digitsOnly = match.replace(/\D/g, "");
    const lastFour = digitsOnly.slice(-4);
    return `[REDACTED-CC-****-${lastFour}]`;
  });

  // Email Redaction: masks username
  const emailRegex = /\b[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/g;
  text = text.replace(emailRegex, (match, domain) => {
    localCount++;
    const username = match.split("@")[0];
    const maskedUser = username.charAt(0) + "***";
    return `${maskedUser}@${domain}`;
  });

  // IPv4 Address Redaction
  const ipRegex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  text = text.replace(ipRegex, () => {
    localCount++;
    return "[REDACTED-IP]";
  });

  globalRedactionCounter += localCount;
  return text;
}

// 2. Visual Redaction Simulator (Bounding Box Masking)
export async function redactImageBuffer(
  imageBuffer: Buffer, 
  boundingBoxes: BoundingBox[]
): Promise<Buffer> {
  // In a production Node.js environment, library like 'sharp' or 'jimp' would be used.
  // Here we simulate the buffer manipulation transformation.
  if (boundingBoxes.length === 0) {
    return imageBuffer;
  }

  // Simulating application of masking blocks over buffer metadata coordinates
  const simulatedModifiedBuffer = Buffer.from(imageBuffer);
  
  // Track visual masking events
  globalRedactionCounter += boundingBoxes.length;

  return simulatedModifiedBuffer;
}

// 3. Unified Middleware Function
export async function sanitizeMcpVisionPayload(payload: McpVisionPayload): Promise<SanitizationResult> {
  const initialCount = globalRedactionCounter;

  const sanitizedText = redactTextPii(payload.textPrompt);
  
  let sanitizedBuffer = payload.imageBuffer;
  if (payload.imageBuffer && payload.boundingBoxesToMask) {
    sanitizedBuffer = await redactImageBuffer(payload.imageBuffer, payload.boundingBoxesToMask);
  }

  const redactionCountThisRun = globalRedactionCounter - initialCount;

  return {
    sanitizedPayload: {
      textPrompt: sanitizedText,
      imageBuffer: sanitizedBuffer,
      boundingBoxesToMask: payload.boundingBoxesToMask,
    },
    redactionCount: redactionCountThisRun,
  };
}
