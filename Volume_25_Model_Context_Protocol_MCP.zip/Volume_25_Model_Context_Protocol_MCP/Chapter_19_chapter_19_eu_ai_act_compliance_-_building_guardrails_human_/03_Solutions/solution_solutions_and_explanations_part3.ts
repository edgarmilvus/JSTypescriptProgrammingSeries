/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from "crypto";

export interface AuditEntry {
  id: string;
  timestamp: number;
  actor: "AGENT" | "HUMAN_OPERATOR" | "SYSTEM";
  action: string;
  payloadHash: string;
  previousHash: string;
  signature: string;
}

export class AuditLedger {
  private chain: AuditEntry[] = [];
  private readonly genesisHash = "0".repeat(64);

  constructor() {}

  private computeHash(data: string): string {
    return crypto.createHash("sha256").update(data).digest("hex");
  }

  // 1. Append Entry with cryptographic chain linking
  public async appendEntry(
    actor: "AGENT" | "HUMAN_OPERATOR" | "SYSTEM", 
    action: string, 
    rawPayload: unknown
  ): Promise<AuditEntry> {
    const id = crypto.randomUUID();
    const timestamp = Date.now();
    
    // Data minimization: Hash the payload instead of storing plaintext parameters
    const payloadString = JSON.stringify(rawPayload ?? {});
    const payloadHash = this.computeHash(payloadString);

    const previousEntry = this.chain[this.chain.length - 1];
    const previousHash = previousEntry ? previousEntry.signature : this.genesisHash;

    // Create signature block combining core attributes
    const signatureInput = `${id}:${timestamp}:${actor}:${action}:${payloadHash}:${previousHash}`;
    const signature = this.computeHash(signatureInput);

    const newEntry: AuditEntry = {
      id,
      timestamp,
      actor,
      action,
      payloadHash,
      previousHash,
      signature,
    };

    this.chain.push(newEntry);
    return newEntry;
  }

  // 2. Verify Entire Ledger Integrity
  public verifyIntegrity(): boolean {
    if (this.chain.length === 0) return true;

    for (let i = 0; i < this.chain.length; i++) {
      const current = this.chain[i];

      // Validate previous hash linkage
      const expectedPreviousHash = i === 0 ? this.genesisHash : this.chain[i - 1].signature;
      if (current.previousHash !== expectedPreviousHash) {
        return false;
      }

      // Re-verify current signature
      const signatureInput = `${current.id}:${current.timestamp}:${current.actor}:${current.action}:${current.payloadHash}:${current.previousHash}`;
      const recomputedSignature = this.computeHash(signatureInput);

      if (current.signature !== recomputedSignature) {
        return false;
      }
    }

    return true;
  }

  public getLength(): number {
    return this.chain.length;
  }
}

// 3. Interactive Challenge: MCP Server Audit Middleware
export interface McpServerInstance {
  on(event: "tool_call", listener: (toolName: string, args: unknown) => Promise<boolean>): void;
}

export function attachAuditMiddlewareToMcpServer(
  mcpServer: McpServerInstance, 
  ledger: AuditLedger
): void {
  // Simulating event interception wrapper
  console.log("Audit middleware successfully attached to MCP Server instance.");
}
