/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from "react";

export interface PendingMcpAction {
  id: string;
  toolName: string;
  parameters: Record<string, unknown>;
  targetEnvironment: string;
  riskLevel: "HIGH_RISK" | "LOW_RISK";
  triggeredArticle: string;
}

export interface HitlApprovalGatewayProps {
  pendingAction: PendingMcpAction;
  onApproval: (actionId: string, rationale: string) => Promise<void>;
  onRejection: (actionId: string, rationale: string) => Promise<void>;
}

// 1. React HITL Approval Gateway Component
export const HitlApprovalGateway: React.FC<HitlApprovalGatewayProps> = ({
  pendingAction,
  onApproval,
  onRejection,
}) => {
  const [rationale, setRationale] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleActionClick = async (actionType: "approve" | "reject") => {
    if (rationale.trim().length < 5) {
      setErrorMsg("A detailed operational rationale (minimum 5 characters) is mandatory.");
      return;
    }
    setErrorMsg(null);
    setIsSubmitting(true);

    try {
      if (actionType === "approve") {
        await onApproval(pendingAction.id, rationale);
      } else {
        await onRejection(pendingAction.id, rationale);
      }
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full border border-red-200 overflow-hidden">
        {/* Header Header warning */}
        <div className="bg-red-600 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2">
            <span className="font-bold tracking-wide uppercase text-sm">EU AI Act Compliance Gateway</span>
          </div>
          <span className="bg-red-800 text-xs px-2.5 py-1 rounded font-semibold">
            {pendingAction.riskLevel}
          </span>
        </div>

        {/* Body content */}
        <div className="p-6 space-y-4">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Mandatory Human Oversight Required</h3>
            <p className="text-xs text-gray-500 mt-0.5">{pendingAction.triggeredArticle}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-sm space-y-2">
            <div className="flex justify-between">
              <span className="font-semibold text-gray-600">Target Tool:</span>
              <span className="font-mono text-indigo-600 font-medium">{pendingAction.toolName}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold text-gray-600">Environment:</span>
              <span className="uppercase text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">
                {pendingAction.targetEnvironment}
              </span>
            </div>
          </div>

          {/* Collapsible raw parameters viewer */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Payload Parameters</label>
            <pre className="bg-slate-900 text-emerald-400 p-3 rounded-md text-xs font-mono max-h-36 overflow-y-auto">
              {JSON.stringify(pendingAction.parameters, null, 2)}
            </pre>
          </div>

          {/* Mandatory Rationale Input */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
              Operator Justification & Rationale <span className="text-red-500">*</span>
            </label>
            <textarea
              className="w-full border border-gray-300 rounded-md p-2.5 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none"
              rows={3}
              placeholder="Provide explicit operational justification for auditing purposes..."
              value={rationale}
              onChange={(e) => setRationale(e.target.value)}
              disabled={isSubmitting}
            />
            {errorMsg && <p className="text-xs text-red-600 mt-1 font-medium">{errorMsg}</p>}
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="bg-gray-50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200">
          <button
            onClick={() => handleActionClick("reject")}
            disabled={isSubmitting}
            className="px-4 py-2 text-sm font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition"
          >
            {isSubmitting ? "Processing..." : "Reject Action"}
          </button>
          <button
            onClick={() => handleActionClick("approve")}
            disabled={isSubmitting}
            className="px-5 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow transition"
          >
            {isSubmitting ? "Processing..." : "Approve Execution"}
          </button>
        </div>
      </div>
    </div>
  );
};
