/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { AuditLedger } from "./AuditLedger";
import { redactTextPii, sanitizeMcpVisionPayload, McpVisionPayload } from "./RedactionModule";
import { validateAndClassifyAgentOutput, RiskAssessmentResult } from "./ValidationModule";

export interface ExecutionContext {
  userId: string;
  clientIp: string;
}

export interface PipelineResult {
  success: boolean;
  message: string;
  riskAssessment?: RiskAssessmentResult;
  redactionCount: number;
  auditEntryId?: string;
}

export class CompliantMcpPipeline {
  constructor(private auditLedger: AuditLedger) {}

  public async executeToolCall(rawInput: string, context: ExecutionContext): Promise<PipelineResult> {
    try {
      // Stage 1: Ingest raw input and run PII sanitization
      const sanitizedPrompt = redactTextPii(rawInput);
      const visionPayload: McpVisionPayload = { textPrompt: sanitizedPrompt };
      const sanitizedResult = await sanitizeMcpVisionPayload(visionPayload);

      // Stage 2 & 3: Parse, validate against schema, and classify risk
      let riskAssessment: RiskAssessmentResult;
      try {
        riskAssessment = await validateAndClassifyAgentOutput(sanitizedResult.sanitizedPayload.textPrompt);
      } catch (validationErr) {
        // Record validation failure in audit ledger before throwing
        await this.auditLedger.appendEntry("SYSTEM", "VALIDATION_FAILED", {
          error: (validationErr as Error).message,
          context,
        });
        return {
          success: false,
          message: `Compliance validation failed: ${(validationErr as Error).message}`,
          redactionCount: sanitizedResult.redactionCount,
        };
      }

      // Stage 4: High risk check & HITL gate simulation
      if (riskAssessment.requiresHitl) {
        const auditEntry = await this.auditLedger.appendEntry("AGENT", "HITL_GATE_PAUSED", {
          toolName: riskAssessment.validatedRequest.toolName,
          riskLevel: riskAssessment.riskLevel,
          article: riskAssessment.triggeredArticle,
        });

        return {
          success: false,
          message: `Execution paused. High-risk action intercepted under ${riskAssessment.triggeredArticle}. Awaiting HITL approval.`,
          riskAssessment,
          redactionCount: sanitizedResult.redactionCount,
          auditEntryId: auditEntry.id,
        };
      }

      // Stage 5: Record successful clearance into Audit Ledger
      const auditEntry = await this.auditLedger.appendEntry("AGENT", "TOOL_EXECUTION_APPROVED", {
        toolName: riskAssessment.validatedRequest.toolName,
        environment: riskAssessment.validatedRequest.targetEnvironment,
      });

      // Stage 6: Execute underlying tool (simulated success)
      return {
        success: true,
        message: "Tool executed successfully under EU AI Act compliance thresholds.",
        riskAssessment,
        redactionCount: sanitizedResult.redactionCount,
        auditEntryId: auditEntry.id,
      };

    } catch (unexpectedErr) {
      await this.auditLedger.appendEntry("SYSTEM", "PIPELINE_CRITICAL_FAILURE", {
        error: (unexpectedErr as Error).message,
      });
      return {
        success: false,
        message: `Pipeline crashed due to unexpected error: ${(unexpectedErr as Error).message}`,
        redactionCount: 0,
      };
    }
  }
}
