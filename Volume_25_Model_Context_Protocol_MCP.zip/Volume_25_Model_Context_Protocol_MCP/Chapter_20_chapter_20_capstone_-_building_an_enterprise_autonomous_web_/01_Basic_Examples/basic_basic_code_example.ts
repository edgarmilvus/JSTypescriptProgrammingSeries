/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Annotation, StateGraph, MemorySaver } from "@langgraph/sdk";
import { z } from "zod";

/**
 * @fileoverview Enterprise Autonomous Web Agent SaaS - Basic Delegation & Hydration Example
 * This script demonstrates a minimal, fully self-contained LangGraph.js setup featuring
 * a Supervisor Node using a Delegation Strategy and a Worker Agent executing an MCP-like browser tool,
 * backed by persistent state hydration via a memory checkpointer.
 */

// ==========================================
// 1. STATE DEFINITION & ZOD SCHEMAS
// ==========================================

/**
 * Defines the strict JSON Schema for the delegation payload.
 * In a production SaaS, this ensures the Supervisor Node cannot pass hallucinated or malformed tasks.
 */
const DelegationTaskSchema = z.object({
  action: z.enum(["navigate", "extract_text", "click"]),
  targetUrl: z.string().url(),
  selector: z.string().optional(),
});

type DelegationTask = z.infer<typeof DelegationTaskSchema>;

/**
 * The global Graph State Annotation channel. 
 * This shared state is persisted, hydrated, and modified across nodes.
 */
const AgentGraphState = Annotation.Root({
  tenantId: Annotation<string>(),
  sessionId: Annotation<string>(),
  userPrompt: Annotation<string>(),
  delegatedTask: Annotation<DelegationTask | null>(),
  executionLogs: Annotation<string[]>({
    reducer: (left, right) => [...left, ...right],
    default: () => [],
  }),
  finalOutput: Annotation<string | null>(),
});

// ==========================================
// 2. NODE IMPLEMENTATIONS
// ==========================================

/**
 * Supervisor Node: Analyzes the user prompt and executes the Delegation Strategy.
 * It parses the intent and populates the structured `delegatedTask` field using strict validation.
 */
async function supervisorNode(state: typeof AgentGraphState.State) {
  console.log(`[Supervisor] Processing session ${state.sessionId} for tenant ${state.tenantId}`);
  
  // Simulate LLM reasoning that generates a structured delegation payload
  const rawIntent = state.userPrompt.toLowerCase();
  let task: DelegationTask;

  if (rawIntent.includes("scrape") || rawIntent.includes("extract")) {
    task = {
      action: "extract_text",
      targetUrl: "https://example-saas-dashboard.com/metrics",
      selector: "h1.revenue-metric",
    };
  } else {
    task = {
      action: "navigate",
      targetUrl: "https://example-saas-dashboard.com",
    };
  }

  // Validate the payload against our enterprise schema before handing off to the worker
  const validatedTask = DelegationTaskSchema.parse(task);

  return {
    delegatedTask: validatedTask,
    executionLogs: [`[Supervisor] Successfully delegated action '${validatedTask.action}' for target: ${validatedTask.targetUrl}`],
  };
}

/**
 * Worker Agent Node: Executes the delegated browser task, mimicking an MCP-driven tool call.
 * It reads the `delegatedTask` from the shared state and performs the action.
 */
async function workerAgentNode(state: typeof AgentGraphState.State) {
  const task = state.delegatedTask;
  if (!task) {
    throw new Error("[Worker] Fatal: Worker invoked without a valid delegated task payload.");
  }

  console.log(`[Worker] Executing MCP browser automation tool for action: ${task.action}`);
  
  // Simulate asynchronous browser interaction (Puppeteer/Playwright over MCP)
  let simulatedToolResult = "";
  if (task.action === "extract_text") {
    simulatedToolResult = "Extracted Enterprise ARR: $1,240,000 (DOM Selector: " + task.selector + ")";
  } else {
    simulatedToolResult = "Successfully navigated to " + task.targetUrl + " and rendered viewport.";
  }

  return {
    executionLogs: [`[Worker] Tool execution completed successfully. Result: ${simulatedToolResult}`],
    finalOutput: simulatedToolResult,
  };
}

// ==========================================
// 3. GRAPH CONSTRUCTION & HYDRATION SETUP
// ==========================================

/**
 * Constructs the state graph, registers nodes, and defines conditional or direct edges.
 */
function createAutonomousAgentGraph() {
  const workflow = new StateGraph(AgentGraphState)
    .addNode("supervisor", supervisorNode)
    .addNode("worker", workerAgentNode)
    .addEdge("__start__", "supervisor")
    .addEdge("supervisor", "worker")
    .addEdge("worker", "__end__");

  // Initialize a persistent memory checkpointer for state hydration
  // In production, substitute MemorySaver with a Postgres or Redis checkpointer implementation
  const checkpointer = new MemorySaver();

  return workflow.compile({ checkpointer });
}

// ==========================================
// 4. SAAS EXECUTION RUNTIME & HYDRATION DEMO
// ==========================================

async function runSaaSExecutionPipeline() {
  const app = createAutonomousAgentGraph();

  // Unique identifiers for multi-tenant isolation tracking
  const config = {
    configurable: {
      thread_id: "tenant-alpha-session-9988",
    },
  };

  // Initial input payload representing an incoming SaaS API request
  const initialInput = {
    tenantId: "tenant-alpha",
    sessionId: "session-9988",
    userPrompt: "Extract the core metrics from the dashboard.",
    delegatedTask: null,
    executionLogs: [],
    finalOutput: null,
  };

  console.log("--- STARTING INITIAL AGENT RUN ---");
  const firstRunResult = await app.invoke(initialInput, config);
  console.log("First Run Output:", JSON.stringify(firstRunResult, null, 2));

  // --- DEMONSTRATING PERSISTENT GRAPH STATE HYDRATION ---
  // Suppose the user's browser agent session was interrupted or paused by a rate limiter.
  // We can retrieve the exact state from the checkpointer using the thread_id config without losing context.
  console.log("\n--- DEMONSTRATING STATE HYDRATION FROM CHECKPOINTER ---");
  const currentStateSnapshot = await app.getState(config);
  
  if (currentStateSnapshot && currentStateSnapshot.values) {
    console.log(`[Hydration Engine] Successfully reloaded state for thread: ${config.configurable.thread_id}`);
    console.log(`[Hydration Engine] Last recorded execution logs count: ${currentStateSnapshot.values.executionLogs.length}`);
    console.log(`[Hydration Engine] Resumed Final Output State: ${currentStateSnapshot.values.finalOutput}`);
  } else {
    console.log("[Hydration Engine] Error: Failed to hydrate state from persistent storage.");
  }
}

// Execute the simulation pipeline
runSaaSExecutionPipeline().catch((err) => {
  console.error("Critical error in SaaS Agent Execution:", err);
});
