/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file Enterprise Autonomous Web Agent SaaS - Conversational Runtime Component
 * @module components/agents/AutonomousAgentChat
 * @description Provides a Next.js client component that integrates the Vercel AI SDK's
 * useChat hook with enterprise-specific telemetry headers, multi-tenant workspace context,
 * and real-time agentic loop visualizations (Thought-Action-Observation).
 */

'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useChat } from 'ai/react';
import { 
  Bot, 
  User, 
  Send, 
  Cpu, 
  ShieldCheck, 
  Terminal, 
  AlertCircle, 
  Loader2,
  CheckCircle2,
  Eye
} from 'lucide-react';

/**
 * Interface defining the multi-tenant context required for enterprise requests.
 */
interface TenantContext {
  workspaceId: string;
  organizationId: string;
  userRole: 'ADMIN' | 'OPERATOR' | 'VIEWER';
  maxBudgetUsd: number;
}

/**
 * Props for the AutonomousAgentChat component.
 */
interface AutonomousAgentChatProps {
  tenant: TenantContext;
  agentId: string;
  initialMcpServers: string[];
}

/**
 * Extended message metadata structure for tracking ReAct loop steps.
 */
interface AgentStepMetadata {
  thought?: string;
  action?: {
    toolName: string;
    toolInput: Record<string, unknown>;
  };
  observation?: string;
  costUsd?: number;
  tokensUsed?: number;
}

export function AutonomousAgentChat({ 
  tenant, 
  agentId, 
  initialMcpServers 
}: AutonomousAgentChatProps) {
  // Local state for tracking active MCP servers bound to the session
  const [activeMcpServers, setActiveMcpServers] = useState<string[]>(initialMcpServers);
  const [selectedBudget, setSelectedBudget] = useState<number>(tenant.maxBudgetUsd);
  
  // Reference for auto-scrolling the chat container
  const messagesEndRef = useRef<HTMLDivElement>(null);

  /**
   * Initialize the Vercel AI SDK useChat hook.
   * We inject enterprise telemetry, tenant IDs, and active MCP server configurations
   * into the request body headers and payload.
   */
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/agent/execute',
    headers: {
      'x-workspace-id': tenant.workspaceId,
      'x-organization-id': tenant.organizationId,
      'x-user-role': tenant.userRole,
    },
    body: {
      agentId,
      activeMcpServers,
      maxBudgetUsd: selectedBudget,
    },
    onError: (err) => {
      console.error('[AutonomousAgentChat] Execution error encountered:', err);
    },
  });

  // Auto-scroll effect when new messages or agent thoughts stream in
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-100 font-sans">
      {/* Sidebar: Enterprise Telemetry & MCP Tooling Controls */}
      <aside className="w-80 border-r border-slate-800 bg-slate-900/50 p-6 flex flex-col justify-between hidden md:flex">
        <div className="space-y-6">
          {/* Header & Workspace Metadata */}
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 font-semibold mb-1">
              <Cpu className="w-5 h-5" />
              <span className="tracking-wide">MCP Enterprise Control</span>
            </div>
            <p className="text-xs text-slate-400">
              Workspace: <code className="text-slate-200">{tenant.workspaceId}</code>
            </p>
            <p className="text-xs text-slate-400">
              Role: <span className="text-emerald-400 font-medium">{tenant.userRole}</span>
            </p>
          </div>

          {/* Active MCP Servers Management */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Connected MCP Servers
            </h3>
            <div className="space-y-2">
              {activeMcpServers.map((server, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/50 text-sm"
                >
                  <div className="flex items-center space-x-2">
                    <Terminal className="w-4 h-4 text-indigo-400" />
                    <span className="font-mono text-xs text-slate-200">{server}</span>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
              ))}
            </div>
          </div>

          {/* Budget & Cost Governance */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Session Governance
            </h3>
            <div className="p-3 rounded-lg bg-slate-800/40 border border-slate-700/40 space-y-2">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Budget Cap:</span>
                <span className="font-mono text-indigo-300">${selectedBudget.toFixed(2)}</span>
              </div>
              <input 
                type="range" 
                min="0.50" 
                max="20.00" 
                step="0.50"
                value={selectedBudget}
                onChange={(e) => setSelectedBudget(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 bg-slate-700 h-1 rounded-lg cursor-pointer"
              />
              <div className="flex items-center space-x-1.5 text-[10px] text-slate-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Enforced via multi-tenant proxy limits</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer System Status */}
        <div className="border-t border-slate-800 pt-4 text-xs text-slate-500 flex items-center justify-between">
          <span>Agent ID: {agentId.slice(0, 8)}...</span>
          <span className="flex items-center space-x-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Online</span>
          </span>
        </div>
      </aside>

      {/* Main Chat & Execution Canvas */}
      <main className="flex-1 flex flex-col h-full bg-slate-950">
        {/* Top Navbar */}
        <header className="h-16 border-b border-slate-800 px-6 flex items-center justify-between bg-slate-900/20 backdrop-blur-md">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-semibold text-slate-200">Autonomous Web Agent Workspace</h1>
              <p className="text-xs text-slate-400">Vision-Driven Browser Automation & MCP Tool Integration</p>
            </div>
          </div>
        </header>

        {/* Message History Feed */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-3 text-slate-500">
              <Bot className="w-12 h-12 text-slate-600 stroke-1" />
              <div className="max-w-md">
                <h3 className="text-slate-300 font-medium mb-1">Ready for Autonomous Execution</h3>
                <p className="text-xs text-slate-400">
                  Provide a web automation goal. The agent will orchestrate browser actions, invoke MCP tools, and execute the ReAct loop securely within your isolated container environment.
                </p>
              </div>
            </div>
          )}

          {messages.map((m) => {
            const isUser = m.role === 'user';
            // Parse custom annotations if present in experimental attachments or data streams
            const metadata = (m as unknown as { metadata?: AgentStepMetadata }).metadata;

            return (
              <div 
                key={m.id} 
                className={`flex items-start space-x-3 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isUser ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-indigo-400 border border-slate-700'
                }`}>
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div className={`max-w-2xl space-y-3 ${isUser ? 'items-end' : 'items-start'}`}>
                  {/* Message Bubble */}
                  <div className={`p-4 rounded-xl text-sm leading-relaxed ${
                    isUser 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none shadow-xl'
                  }`}>
                    <div className="whitespace-pre-wrap">{m.content}</div>
                  </div>

                  {/* ReAct Loop Step Visualization (If present in Assistant response) */}
                  {!isUser && metadata && (
                    <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/80 space-y-2 text-xs font-mono">
                      {metadata.thought && (
                        <div className="text-indigo-300 flex items-start space-x-2">
                          <span className="text-slate-500">THOUGHT:</span>
                          <span className="flex-1">{metadata.thought}</span>
                        </div>
                      )}
                      {metadata.action && (
                        <div className="text-amber-300 flex items-start space-x-2">
                          <span className="text-slate-500">ACTION:</span>
                          <span className="flex-1">{metadata.action.toolName}({JSON.stringify(metadata.action.toolInput)})</span>
                        </div>
                      )}
                      {metadata.observation && (
                        <div className="text-emerald-300 flex items-start space-x-2">
                          <span className="text-slate-500">OBSERVATION:</span>
                          <span className="flex-1 truncate">{metadata.observation}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center space-x-3 text-slate-400 text-xs font-mono animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Agent executing ReAct cycle & interacting with browser MCP...</span>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center space-x-2 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>Execution failed: {error.message}</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-6 border-t border-slate-800 bg-slate-900/30 backdrop-blur-md">
          <form onSubmit={handleSubmit} className="flex items-center space-x-3">
            <div className="relative flex-1">
              <input
                type="text"
                value={input}
                onChange={handleInputChange}
                placeholder="Enter web automation objective (e.g., 'Navigate to AcmeCorp, extract pricing table, and save report')..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                disabled={isLoading}
              />
            </div>
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white px-5 py-3 rounded-xl font-medium text-sm flex items-center space-x-2 transition-all shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              <span>Execute</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
