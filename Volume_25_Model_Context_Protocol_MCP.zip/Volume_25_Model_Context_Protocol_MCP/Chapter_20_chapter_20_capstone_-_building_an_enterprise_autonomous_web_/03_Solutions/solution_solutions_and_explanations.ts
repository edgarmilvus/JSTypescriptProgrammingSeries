/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { BaseMessage, ToolMessage } from "@langchain/core/messages";
import { RunnableConfig } from "@langchain/core/runnables";

export interface ToolCallPayload {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface ParallelExecutionResult {
  toolCallId: string;
  success: boolean;
  output: unknown;
  error?: string;
}

/**
 * Executes multiple MCP tool calls in parallel using Promise.allSettled
 * and maps results back to LangChain ToolMessages.
 */
export async function executeToolsInParallel(
  toolCalls: ToolCallPayload[],
  toolRegistry: Map<string, (args: Record<string, unknown>) => Promise<unknown>>,
  config: RunnableConfig
): Promise<ToolMessage[]> {
  // Map each tool call payload to a concurrent promise execution
  const executionPromises = toolCalls.map(async (call): Promise<ParallelExecutionResult> => {
    const toolFunction = toolRegistry.get(call.name);
    
    if (!toolFunction) {
      return {
        toolCallId: call.id,
        success: false,
        output: null,
        error: `Tool '${call.name}' not found in registry.`
      };
    }

    try {
      // Invoke the registered tool with its arguments
      const result = await toolFunction(call.args);
      return {
        toolCallId: call.id,
        success: true,
        output: result
      };
    } catch (err: any) {
      return {
        toolCallId: call.id,
        success: false,
        output: null,
        error: err.message || String(err)
      };
    }
  });

  // Execute all tool promises concurrently with fault-isolation
  const settledResults = await Promise.allSettled(executionPromises);

  // Transform settled results into LangChain ToolMessage instances
  return settledResults.map((settled, index) => {
    const callId = toolCalls[index].id;

    if (settled.status === "fulfilled") {
      const res = settled.value;
      return new ToolMessage({
        tool_call_id: res.toolCallId,
        content: res.success 
          ? JSON.stringify(res.output) 
          : JSON.stringify({ error: res.error }),
        status: res.success ? "success" : "error"
      });
    } else {
      // Handle unexpected unhandled promise rejection at the allSettled boundary
      return new ToolMessage({
        tool_call_id: callId,
        content: JSON.stringify({ error: settled.reason?.message || "Unknown execution fault" }),
        status: "error"
      });
    }
  });
}
