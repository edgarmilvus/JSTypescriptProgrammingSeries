/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export enum GovernanceDecisionType {
  ALLOW = "ALLOW",
  DENY_RBAC = "DENY_RBAC",
  DENY_BUDGET = "DENY_BUDGET"
}

export interface GovernanceContext {
  tenantId: string;
  userRole: "ADMIN" | "OPERATOR" | "VIEWER";
  toolName: string;
  estimatedCostUSD: number;
}

export interface TenantBudgetStore {
  getRemainingBudget(tenantId: string): Promise<number>;
}

/**
 * Evaluates RBAC privileges and cost budgets before permitting tool invocation.
 */
export async function evaluateToolGovernance(
  context: GovernanceContext,
  budgetStore: TenantBudgetStore,
  restrictedToolsByRole: Record<string, string[]>
): Promise<GovernanceDecisionType> {
  // 1. Check if toolName is restricted for the given userRole
  const restrictedTools = restrictedToolsByRole[context.userRole] || [];
  if (restrictedTools.includes(context.toolName)) {
    return GovernanceDecisionType.DENY_RBAC;
  }

  // 2. Fetch remaining budget from budgetStore for the tenantId
  const remainingBudget = await budgetStore.getRemainingBudget(context.tenantId);

  // 3. Compare remaining budget against estimatedCostUSD
  if (remainingBudget < context.estimatedCostUSD) {
    return GovernanceDecisionType.DENY_BUDGET;
  }

  // 4. Return ALLOW decision if all guardrails pass
  return GovernanceDecisionType.ALLOW;
}
