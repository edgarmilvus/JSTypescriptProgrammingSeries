/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { BaseMessage, ToolMessage } from "@langchain/core/messages";
import { RunnableConfig } from "@langchain/core/runnables";

export interface ToolCallPayload {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface ParallelExecutionResult {
  toolCallId: string;
  success: boolean;
  output: unknown;
  error?: string;
}

/**
 * Challenge: Implement this function to execute multiple MCP tool calls in parallel.
 * It must handle failures gracefully using Promise.allSettled and map them 
 * back to LangChain ToolMessages for state re-injection.
 */
export async function executeToolsInParallel(
  toolCalls: ToolCallPayload[],
  toolRegistry: Map<string, (args: Record<string, unknown>) => Promise<unknown>>,
  config: RunnableConfig
): Promise<ToolMessage[]> {
  // TODO: Implement concurrent tool execution
  // 1. Map over toolCalls and invoke corresponding functions from toolRegistry
  // 2. Wrap executions in try/catch to ensure allsettled safety
  // 3. Construct and return an array of ToolMessage instances
  throw new Error("Not implemented");
}
