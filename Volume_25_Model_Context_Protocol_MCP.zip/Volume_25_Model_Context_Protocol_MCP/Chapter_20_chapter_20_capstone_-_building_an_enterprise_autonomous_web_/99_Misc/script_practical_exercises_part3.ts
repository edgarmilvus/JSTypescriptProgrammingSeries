/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export enum GovernanceDecisionType {
  ALLOW = "ALLOW",
  DENY_RBAC = "DENY_RBAC",
  DENY_BUDGET = "DENY_BUDGET"
}

export interface GovernanceContext {
  tenantId: string;
  userRole: "ADMIN" | "OPERATOR" | "VIEWER";
  toolName: string;
  estimatedCostUSD: number;
}

export interface TenantBudgetStore {
  getRemainingBudget(tenantId: string): Promise<number>;
}

/**
 * Challenge: Write the governance evaluation middleware logic.
 * Check if the user role is authorized for the tool, and if the tenant's 
 * remaining budget can cover the estimated cost of execution.
 */
export async function evaluateToolGovernance(
  context: GovernanceContext,
  budgetStore: TenantBudgetStore,
  restrictedToolsByRole: Record<string, string[]>
): Promise<GovernanceDecisionType> {
  // TODO: Implement governance evaluation
  // 1. Check if toolName is restricted for the given userRole
  // 2. Fetch remaining budget from budgetStore for the tenantId
  // 3. Compare remaining budget against estimatedCostUSD
  // 4. Return appropriate GovernanceDecisionType enum value
  throw new Error("Not implemented");
}
