/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect, useCallback } from "react";

export interface AgentLogEvent {
  id: string;
  timestamp: string;
  level: "info" | "warning" | "error" | "tool_call";
  message: string;
  costDeltaUSD: number;
}

interface AgentMonitorDashboardProps {
  tenantId: string;
  threadId: string;
  websocketEndpoint: string;
}

/**
 * Challenge: Complete the AgentMonitorDashboard component by establishing 
 * the WebSocket listener for incoming log streams and implementing the 
 * handleKillSwitch function to terminate active agent threads.
 */
export const AgentMonitorDashboard: React.FC<AgentMonitorDashboardProps> = ({
  tenantId,
  threadId,
  websocketEndpoint,
}) => {
  const [logs, setLogs] = useState<AgentLogEvent[]>([]);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [totalCost, setTotalCost] = useState<number>(0);
  const [isTerminated, setIsTerminated] = useState<boolean>(false);

  // TODO: Implement WebSocket connection logic and incoming event handling
  useEffect(() => {
    // 1. Establish WebSocket connection with query params (tenantId, threadId)
    // 2. On message, parse AgentLogEvent, append to logs state, update totalCost
    // 3. Handle cleanup on unmount
    return () => {};
  }, [tenantId, threadId, websocketEndpoint]);

  const handleKillSwitch = useCallback(async () => {
    // TODO: Implement API call to emergency termination endpoint
    // 1. POST request to /api/agents/terminate with threadId and tenantId
    // 2. On success, setIsTerminated(true) and append error log entry
  }, [threadId, tenantId]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl font-sans">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Agent Monitor: {threadId}</h2>
        <div className="flex items-center space-x-4">
          <span className={`px-2 py-1 text-xs rounded ${isConnected ? "bg-green-600" : "bg-red-600"}`}>
            {isConnected ? "Live Connected" : "Disconnected"}
          </span>
          <span className="text-sm font-mono">Cost: ${totalCost.toFixed(4)}</span>
          <button
            onClick={handleKillSwitch}
            disabled={isTerminated}
            className="px-4 py-2 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white text-sm font-semibold rounded transition"
          >
            {isTerminated ? "Terminated" : "Emergency Kill Switch"}
          </button>
        </div>
      </div>
      <div className="bg-slate-950 p-4 rounded h-96 overflow-y-auto font-mono text-xs space-y-2 border border-slate-800">
        {logs.map((log) => (
          <div key={log.id} className="flex space-x-2">
            <span className="text-slate-500">[{log.timestamp}]</span>
            <span className={`uppercase font-bold ${
              log.level === "error" ? "text-red-400" : 
              log.level === "tool_call" ? "text-blue-400" : "text-slate-300"
            }`}>
              {log.level}
            </span>
            <span className="text-slate-200">{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
