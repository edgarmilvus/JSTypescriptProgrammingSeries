/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file AIVisualCanvas.ts
 * @description A high-performance, self-contained rendering engine for AI visual node editors.
 * Implements a transformation matrix for pan/zoom, a dirty-flag render loop, and interactive node manipulation.
 */

/**
 * Represents the 2D spatial coordinates on the canvas workspace.
 */
interface Point {
  x: number;
  y: number;
}

/**
 * Defines the structural and state properties of a visual workflow node.
 */
interface NodeModel {
  id: string;
  title: string;
  position: Point;
  width: number;
  height: number;
  inputs: string[];
  outputs: string[];
  status: 'idle' | 'processing' | 'completed' | 'error';
}

/**
 * Defines a directional connection between two node ports.
 */
interface ConnectionModel {
  id: string;
  sourceNodeId: string;
  sourcePort: string;
  targetNodeId: string;
  targetPort: string;
}

/**
 * Core engine configuration options.
 */
interface CanvasEngineConfig {
  container: HTMLElement;
  width: number;
  height: number;
}

/**
 * A production-grade Canvas Engine for AI Visual Workflows.
 */
class AIVisualCanvasEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private nodes: Map<string, NodeModel> = new Map();
  private connections: Map<string, ConnectionModel> = new Map();
  
  // Viewport transformation state (Pan and Zoom)
  private scale: number = 1;
  private pan: Point = { x: 0, y: 0 };
  
  // Interaction states
  private isDragging: boolean = false;
  private dragStart: Point = { x: 0, y: 0 };
  private selectedNodeId: string | null = null;
  private isNodeDragging: boolean = false;
  private nodeDragOffset: Point = { x: 0, y: 0 };
  
  // Performance and rendering flags
  private isDirty: boolean = true;
  private animationFrameId: number | null = null;

  /**
   * Initializes the canvas engine, attaches DOM elements, and binds event listeners.
   * @param config Configuration object containing the container element and dimensions.
   */
  constructor(config: CanvasEngineConfig) {
    // 1. Create and configure the primary HTML5 Canvas element
    this.canvas = document.createElement('canvas');
    this.canvas.width = config.width;
    this.canvas.height = config.height;
    this.canvas.style.display = 'block';
    this.canvas.style.cursor = 'grab';
    config.container.appendChild(this.canvas);

    // 2. Obtain the 2D rendering context with performance optimizations
    const context = this.canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('Failed to acquire 2D rendering context from canvas.');
    }
    this.ctx = context;

    // 3. Bind input event listeners
    this.bindEvents();

    // 4. Seed initial SaaS nodes (e.g., Prompt Node -> Latent Sampler -> WebGPU Encoder)
    this.seedInitialNodes();

    // 5. Start the render loop
    this.startRenderLoop();
  }

  /**
   * Seeds the graph with default AI workflow nodes for demonstration purposes.
   */
  private seedInitialNodes(): void {
    const promptNode: NodeModel = {
      id: 'node-1',
      title: 'AI Prompt Generator',
      position: { x: 100, y: 100 },
      width: 220,
      height: 140,
      inputs: [],
      outputs: ['Prompt Text'],
      status: 'completed',
    };

    const samplerNode: NodeModel = {
      id: 'node-2',
      title: 'Latent Space Sampler',
      position: { x: 400, y: 150 },
      width: 240,
      height: 160,
      inputs: ['Prompt Text'],
      outputs: ['Raw Tensor'],
      status: 'processing',
    };

    this.nodes.set(promptNode.id, promptNode);
    this.nodes.set(samplerNode.id, samplerNode);

    const connection: ConnectionModel = {
      id: 'conn-1',
      sourceNodeId: 'node-1',
      sourcePort: 'Prompt Text',
      targetNodeId: 'node-2',
      targetPort: 'Prompt Text',
    };

    this.connections.set(connection.id, connection);
    this.markDirty();
  }

  /**
   * Attaches mouse and wheel event listeners for viewport manipulation and node dragging.
   */
  private bindEvents(): void {
    this.canvas.addEventListener('mousedown', this.handleMouseDown.bind(this));
    window.addEventListener('mousemove', this.handleMouseMove.bind(this));
    window.addEventListener('mouseup', this.handleMouseUp.bind(this));
    this.canvas.addEventListener('wheel', this.handleWheel.bind(this), { passive: false });
  }

  /**
   * Marks the canvas as dirty, forcing a re-render on the next animation frame.
   */
  public markDirty(): void {
    this.isDirty = true;
  }

  /**
   * Converts screen coordinates (pixel coordinates relative to the canvas bounding rect)
   * into world coordinates accounting for current pan and zoom transformations.
   */
  private screenToWorld(screenX: number, screenY: number): Point {
    const rect = this.canvas.getBoundingClientRect();
    const clientX = screenX - rect.left;
    const clientY = screenY - rect.top;

    return {
      x: (clientX - this.pan.x) / this.scale,
      y: (clientY - this.pan.y) / this.scale,
    };
  }

  /**
   * Handles mousedown events to initiate panning or node dragging.
   */
  private handleMouseDown(e: MouseEvent): void {
    const worldPos = this.screenToWorld(e.clientX, e.clientY);

    // Check if clicked inside any node (iterate in reverse order for top-to-bottom z-index picking)
    let clickedNode: NodeModel | null = null;
    for (const node of Array.from(this.nodes.values()).reverse()) {
      if (
        worldPos.x >= node.position.x &&
        worldPos.x <= node.position.x + node.width &&
        worldPos.y >= node.position.y &&
        worldPos.y <= node.position.y + node.height
      ) {
        clickedNode = node;
        break;
      }
    }

    if (clickedNode) {
      this.selectedNodeId = clickedNode.id;
      this.isNodeDragging = true;
      this.nodeDragOffset = {
        x: worldPos.x - clickedNode.position.x,
        y: worldPos.y - clickedNode.position.y,
      };
      this.canvas.style.cursor = 'move';
    } else {
      // Initiate canvas panning
      this.selectedNodeId = null;
      this.isDragging = true;
      this.dragStart = { x: e.clientX, y: e.clientY };
      this.canvas.style.cursor = 'grabbing';
    }
    this.markDirty();
  }

  /**
   * Handles mousemove events for updating node positions or panning the viewport.
   */
  private handleMouseMove(e: MouseEvent): void {
    if (this.isNodeDragging && this.selectedNodeId) {
      const worldPos = this.screenToWorld(e.clientX, e.clientY);
      const node = this.nodes.get(this.selectedNodeId);
      if (node) {
        node.position.x = worldPos.x - this.nodeDragOffset.x;
        node.position.y = worldPos.y - this.nodeDragOffset.y;
        this.markDirty();
      }
    } else if (this.isDragging) {
      const dx = e.clientX - this.dragStart.x;
      const dy = e.clientY - this.dragStart.y;
      this.pan.x += dx;
      this.pan.y += dy;
      this.dragStart = { x: e.clientX, y: e.clientY };
      this.markDirty();
    }
  }

  /**
   * Handles mouseup events to terminate drags and reset cursor states.
   */
  private handleMouseUp(): void {
    this.isDragging = false;
    this.isNodeDragging = false;
    this.canvas.style.cursor = 'grab';
  }

  /**
   * Handles mouse wheel events for smooth zooming centered on the cursor position.
   */
  private handleWheel(e: WheelEvent): void {
    e.preventDefault();

    const zoomIntensity = 0.1;
    const wheelDirection = e.deltaY < 0 ? 1 : -1;
    const oldScale = this.scale;

    // Calculate new scale with bounds [0.2, 5.0]
    this.scale = Math.max(0.2, Math.min(5.0, oldScale + wheelDirection * zoomIntensity));

    // Zoom toward mouse pointer
    const rect = this.canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    this.pan.x = mouseX - (mouseX - this.pan.x) * (this.scale / oldScale);
    this.pan.y = mouseY - (mouseY - this.pan.y) * (this.scale / oldScale);

    this.markDirty();
  }

  /**
   * Starts the requestAnimationFrame render loop.
   */
  private startRenderLoop(): void {
    const render = () => {
      if (this.isDirty) {
        this.drawScene();
        this.isDirty = false;
      }
      this.animationFrameId = requestAnimationFrame(render);
    };
    this.animationFrameId = requestAnimationFrame(render);
  }

  /**
   * Clears the canvas and renders the entire node graph transformation stack.
   */
  private drawScene(): void {
    const { width, height } = this.canvas;

    // 1. Clear background
    this.ctx.fillStyle = '#0f172a'; // Slate-900 dark background
    this.ctx.fillRect(0, 0, width, height);

    // 2. Save context and apply global viewport transformations (Pan & Zoom)
    this.ctx.save();
    this.ctx.translate(this.pan.x, this.pan.y);
    this.ctx.scale(this.scale, this.scale);

    // 3. Draw grid background
    this.drawGrid(width, height);

    // 4. Render connections (Bezier curves between node ports)
    this.drawConnections();

    // 5. Render workflow nodes
    this.drawNodes();

    // 6. Restore context state
    this.ctx.restore();
  }

  /**
   * Renders an infinite background grid that scales with the viewport.
   */
  private drawGrid(width: number, height: number): void {
    const gridSize = 40;
    this.ctx.strokeStyle = '#1e293b'; // Slate-800
    this.ctx.lineWidth = 1 / this.scale;

    const startX = -this.pan.x / this.scale;
    const startY = -this.pan.y / this.scale;
    const endX = startX + width / this.scale;
    const endY = startY + height / this.scale;

    const firstX = Math.floor(startX / gridSize) * gridSize;
    const firstY = Math.floor(startY / gridSize) * gridSize;

    this.ctx.beginPath();
    for (let x = firstX; x < endX; x += gridSize) {
      this.ctx.moveTo(x, startY);
      this.ctx.lineTo(x, endY);
    }
    for (let y = firstY; y < endY; y += gridSize) {
      this.ctx.moveTo(startX, y);
      this.ctx.lineTo(endX, y);
    }
    this.ctx.stroke();
  }

  /**
   * Renders bezier curves connecting node output ports to input ports.
   */
  private drawConnections(): void {
    this.connections.forEach((conn) => {
      const sourceNode = this.nodes.get(conn.sourceNodeId);
      const targetNode = this.nodes.get(conn.targetNodeId);

      if (!sourceNode || !targetNode) return;

      // Approximate port positions based on node layout
      const startX = sourceNode.position.x + sourceNode.width;
      const startY = sourceNode.position.y + sourceNode.height / 2;
      const endX = targetNode.position.x;
      const endY = targetNode.position.y + targetNode.height / 2;

      this.ctx.strokeStyle = '#38bdf8'; // Sky-400
      this.ctx.lineWidth = 2;
      this.ctx.beginPath();
      this.ctx.moveTo(startX, startY);

      // Control points for smooth cubic bezier curve
      const dx = Math.abs(endX - startX) * 0.5;
      this.ctx.bezierCurveTo(
        startX + dx, startY,
        endX - dx, endY,
        endX, endY
      );
      this.ctx.stroke();
    });
  }

  /**
   * Renders all active AI nodes with rounded headers, status badges, and port handles.
   */
  private drawNodes(): void {
    this.nodes.forEach((node) => {
      const isSelected = node.id === this.selectedNodeId;

      // Node background body
      this.ctx.fillStyle = '#1e293b'; // Slate-800
      this.ctx.strokeStyle = isSelected ? '#38bdf8' : '#334155';
      this.ctx.lineWidth = isSelected ? 2 : 1;

      // Draw rounded rectangle for node body
      this.roundRect(node.position.x, node.position.y, node.width, node.height, 8);
      this.ctx.fill();
      this.ctx.stroke();

      // Node Header
      this.ctx.fillStyle = '#334155';
      this.roundRectTop(node.position.x, node.position.y, node.width, 36, 8);
      this.ctx.fill();

      // Header Text (Node Title)
      this.ctx.fillStyle = '#f8fafc'; // Slate-50
      this.ctx.font = '12px Inter, sans-serif';
      this.ctx.fillText(node.title, node.position.x + 12, node.position.y + 23);

      // Status Indicator Dot
      const statusColors = {
        idle: '#64748b',
        processing: '#eab308', // Yellow
        completed: '#22c55e', // Green
        error: '#ef4444',     // Red
      };
      this.ctx.fillStyle = statusColors[node.status];
      this.ctx.beginPath();
      this.ctx.arc(node.position.x + node.width - 20, node.position.y + 18, 5, 0, Math.PI * 2);
      this.ctx.fill();

      // Render Ports
      this.renderPorts(node);
    });
  }

  /**
   * Renders input and output connection ports on the edges of nodes.
   */
  private renderPorts(node: NodeModel): void {
    const portRadius = 4;
    this.ctx.fillStyle = '#94a3b8'; // Slate-400

    // Render Inputs
    node.inputs.forEach((_, index) => {
      const yOffset = node.position.y + 60 + index * 24;
      this.ctx.beginPath();
      this.ctx.arc(node.position.x, yOffset, portRadius, 0, Math.PI * 2);
      this.ctx.fill();
    });

    // Render Outputs
    node.outputs.forEach((_, index) => {
      const yOffset = node.position.y + 60 + index * 24;
      this.ctx.beginPath();
      this.ctx.arc(node.position.x + node.width, yOffset, portRadius, 0, Math.PI * 2);
      this.ctx.fill();
    });
  }

  /**
   * Helper utility to draw a rectangle with rounded corners.
   */
  private roundRect(x: number, y: number, w: number, h: number, r: number): void {
    this.ctx.beginPath();
    this.ctx.moveTo(x + r, y);
    this.ctx.lineTo(x + w - r, y);
    this.ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    this.ctx.lineTo(x + w, y + h - r);
    this.ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    this.ctx.lineTo(x + r, y + h);
    this.ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    this.ctx.lineTo(x, y + r);
    this.ctx.quadraticCurveTo(x, y, x + r, y);
    this.ctx.closePath();
  }

  /**
   * Helper utility to draw a rectangle with only the top corners rounded.
   */
  private roundRectTop(x: number, y: number, w: number, h: number, r: number): void {
    this.ctx.beginPath();
    this.ctx.moveTo(x + r, y);
    this.ctx.lineTo(x + w - r, y);
    this.ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    this.ctx.lineTo(x + w, y + h);
    this.ctx.lineTo(x, y + h);
    this.ctx.lineTo(x, y + r);
    this.ctx.quadraticCurveTo(x, y, x + r, y);
    this.ctx.closePath();
  }

  /**
   * Public cleanup method to unbind listeners and cancel animation frames.
   */
  public destroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.canvas.remove();
  }
}
