/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';

/**
 * Interface representing a 2D coordinate space position on the canvas.
 */
interface IPoint {
  x: number;
  y: number;
}

/**
 * Interface defining the operational parameters and state of a visual node.
 */
interface INode {
  id: string;
  title: string;
  position: IPoint;
  width: number;
  height: number;
  inputs: string[];
  outputs: string[];
  selected?: boolean;
}

/**
 * Interface defining a connection wire between two node outputs and inputs.
 */
interface IConnection {
  id: string;
  fromNodeId: string;
  fromPin: string;
  toNodeId: string;
  toPin: string;
}

/**
 * Interface defining the viewport transformation matrix state (Pan and Zoom).
 */
interface IViewport {
  zoom: number;
  offset: IPoint;
}

/**
 * High-Performance Hybrid Canvas Engine Component for AI Visual Workflows.
 * Combines HTML5 Canvas for real-time wire rendering (bypassing DOM reflow overhead)
 * with an SVG/HTML layer for interactive node component management.
 */
export const AIVisualCanvasEngine: React.FC = () => {
  // References for imperative canvas rendering loop
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number>(0);

  // Core application state
  const [viewport, setViewport] = useState<IViewport>({ zoom: 1, offset: { x: 0, y: 0 } });
  const [nodes, setNodes] = useState<INode[]>([
    { id: 'node-1', title: 'ONNX WebGPU Generator', position: { x: 100, y: 100 }, width: 240, height: 160, inputs: ['in-1'], outputs: ['out-1'] },
    { id: 'node-2', title: 'Stable Diffusion Latent Upscaler', position: { x: 420, y: 220 }, width: 240, height: 160, inputs: ['in-1'], outputs: ['out-1'] }
  ]);
  const [connections, setConnections] = useState<IConnection[]>([
    { id: 'conn-1', fromNodeId: 'node-1', fromPin: 'out-1', toNodeId: 'node-2', toPin: 'in-1' }
  ]);

  // Interaction tracking state (refs to prevent mid-render state re-triggering)
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<IPoint>({ x: 0, y: 0 });
  const selectedNodeIdRef = useRef<string | null>(null);

  /**
   * Translates screen client coordinates into world/canvas coordinates
   * accounting for current pan offset and zoom scaling factor.
   */
  const screenToWorld = useCallback((screenX: number, screenY: number): IPoint => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: (screenX - rect.left - viewport.offset.x) / viewport.zoom,
      y: (screenY - rect.top - viewport.offset.y) / viewport.zoom,
    };
  }, [viewport]);

  /**
   * High-Performance Imperative Render Loop using requestAnimationFrame.
   * Clears and redraws connection wires and grid lines onto the HTML5 Canvas context.
   */
  const renderPipeline = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    // Handle high-DPI scaling dynamically
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
    }

    // 1. Clear background (Dark mode studio aesthetic)
    ctx.fillStyle = '#0f172a'; // Slate 900
    ctx.fillRect(0, 0, width, height);

    // Save context state for camera transform matrix application
    ctx.save();
    ctx.translate(viewport.offset.x, viewport.offset.y);
    ctx.scale(viewport.zoom, viewport.zoom);

    // 2. Render Infinite Grid Background
    const gridSize = 40;
    const left = -viewport.offset.x / viewport.zoom;
    const top = -viewport.offset.y / viewport.zoom;
    const right = left + (width / viewport.zoom);
    const bottom = top + (height / viewport.zoom);

    ctx.strokeStyle = '#1e293b'; // Slate 800
    ctx.lineWidth = 1 / viewport.zoom;
    ctx.beginPath();

    for (let x = Math.floor(left / gridSize) * gridSize; x < right; x += gridSize) {
      ctx.moveTo(x, top);
      ctx.lineTo(x, bottom);
    }
    for (let y = Math.floor(top / gridSize) * gridSize; y < bottom; y += gridSize) {
      ctx.moveTo(left, y);
      ctx.lineTo(right, y);
    }
    ctx.stroke();

    // 3. Render Node Connections (Cubic Bezier Curves)
    connections.forEach((conn) => {
      const sourceNode = nodes.find(n => n.id === conn.fromNodeId);
      const targetNode = nodes.find(n => n.id === conn.toNodeId);
      if (!sourceNode || !targetNode) return;

      // Compute pin absolute positions
      const startX = sourceNode.position.x + sourceNode.width;
      const startY = sourceNode.position.y + (sourceNode.height / 2);
      const endX = targetNode.position.x;
      const endY = targetNode.position.y + (targetNode.height / 2);

      // Draw glowing gradient or styled bezier curve
      const gradient = ctx.createLinearGradient(startX, startY, endX, endY);
      gradient.addColorStop(0, '#3b82f6'); // Blue 500
      gradient.addColorStop(1, '#8b5cf6'); // Purple 500

      ctx.strokeStyle = gradient;
      ctx.lineWidth = 3 / viewport.zoom;
      ctx.beginPath();
      ctx.moveTo(startX, startY);

      // Control points for smooth horizontal tension
      const distX = Math.abs(endX - startX) * 0.5;
      ctx.bezierCurveTo(startX + distX, startY, endX - distX, endY, endX, endY);
      ctx.stroke();
    });

    ctx.restore();

    // Loop continuation
    requestRef.current = requestAnimationFrame(renderPipeline);
  }, [viewport, nodes, connections]);

  // Initialize and run the render loop
  useEffect(() => {
    requestRef.current = requestAnimationFrame(renderPipeline);
    return () => cancelAnimationFrame(requestRef.current);
  }, [renderPipeline]);

  // Window resize handler for canvas sizing
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = canvasRef.current.clientWidth * (window.devicePixelRatio || 1);
        canvasRef.current.height = canvasRef.current.clientHeight * (window.devicePixelRatio || 1);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  /**
   * Pointer down event handling panning and node selection tracking.
   */
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
  };

  /**
   * Pointer move handler executing real-time viewport panning or node repositioning.
   */
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;

    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    dragStartRef.current = { x: e.clientX, y: e.clientY };

    if (selectedNodeIdRef.current) {
      // Reposition active node
      setNodes(prev => prev.map(node => {
        if (node.id === selectedNodeIdRef.current) {
          return {
            ...node,
            position: {
              x: node.position.x + (dx / viewport.zoom),
              y: node.position.y + (dy / viewport.zoom)
            }
          };
        }
        return node;
      }));
    } else {
      // Pan viewport
      setViewport(prev => ({
        ...prev,
        offset: { x: prev.offset.x + dx, y: prev.offset.y + dy }
      }));
    }
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
    selectedNodeIdRef.current = null;
  };

  /**
   * Zoom handling via mouse wheel with focal point preservation.
   */
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    const newZoom = Math.max(0.2, Math.min(3.0, viewport.zoom * zoomFactor));

    const worldPos = screenToWorld(e.clientX, e.clientY);

    setViewport({
      zoom: newZoom,
      offset: {
        x: e.clientX - worldPos.x * newZoom,
        y: e.clientY - worldPos.y * newZoom,
      }
    });
  };

  return (
    <div 
      className="relative w-full h-screen overflow-hidden bg-slate-950 select-none font-sans"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onWheel={handleWheel}
    >
      {/* 1. Underlying High-Performance Canvas for Wires and Grid */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block z-0"
      />

      {/* 2. Overlay DOM/React Layer for Interactive Nodes */}
      <div 
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          transform: `translate(${viewport.offset.x}px, ${viewport.offset.y}px) scale(${viewport.zoom})`,
          transformOrigin: '0 0'
        }}
      >
        {nodes.map(node => (
          <div
            key={node.id}
            onPointerDown={(e) => {
              e.stopPropagation();
              selectedNodeIdRef.current = node.id;
              isDraggingRef.current = true;
              dragStartRef.current = { x: e.clientX, y: e.clientY };
            }}
            style={{
              transform: `translate(${node.position.x}px, ${node.position.y}px)`,
              width: node.width,
              height: node.height,
            }}
            className="absolute pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-2xl flex flex-col overflow-hidden cursor-grab active:cursor-grabbing transition-shadow duration-200 hover:border-blue-500/50"
          >
            {/* Node Header */}
            <div className="bg-slate-800/80 px-3 py-2 border-b border-slate-700/50 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200 tracking-wide truncate">{node.title}</span>
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="GPU Pipeline Ready" />
            </div>

            {/* Node Body / GPU Preview Buffer Container */}
            <div className="flex-1 p-3 flex flex-col justify-between bg-slate-950/40">
              <div className="text-[10px] text-slate-400 font-mono">
                ID: {node.id}
              </div>
              <div className="h-10 bg-slate-900 rounded border border-slate-800 flex items-center justify-center text-[10px] text-blue-400 font-mono">
                WebGPU Context Active
              </div>
            </div>

            {/* Connection Pins */}
            <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-slate-700 border-2 border-blue-400 cursor-crosshair hover:scale-125 transition-transform" />
            <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-slate-700 border-2 border-purple-400 cursor-crosshair hover:scale-125 transition-transform" />
          </div>
        ))}
      </div>

      {/* Floating HUD Controller Toolbar */}
      <div className="absolute bottom-6 left-6 z-20 bg-slate-900/80 backdrop-blur border border-slate-800 px-4 py-2 rounded-lg text-xs text-slate-300 flex items-center gap-4 shadow-xl">
        <div>Zoom: {Math.round(viewport.zoom * 100)}%</div>
        <div className="h-4 w-[1px] bg-slate-700" />
        <button 
          onClick={() => setViewport({ zoom: 1, offset: { x: 0, y: 0 } })}
          className="hover:text-blue-400 transition-colors cursor-pointer"
        >
          Reset View
        </button>
      </div>
    </div>
  );
};

export default AIVisualCanvasEngine;
