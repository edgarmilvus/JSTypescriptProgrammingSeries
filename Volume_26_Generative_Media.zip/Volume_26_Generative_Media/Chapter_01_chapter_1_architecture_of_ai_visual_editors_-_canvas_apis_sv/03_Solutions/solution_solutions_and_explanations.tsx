/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/CanvasNodeEditor.tsx
'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';

interface Point {
  x: number;
  y: number;
}

interface Node {
  id: string;
  title: string;
  position: Point;
  width: number;
  height: number;
  inputs: string[];
  outputs: string[];
}

interface Viewport {
  x: number;
  y: number;
  zoom: number;
}

export function CanvasNodeEditor() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [viewport, setViewport] = useState<Viewport>({ x: 0, y: 0, zoom: 1 });
  const [nodes, setNodes] = useState<Node[]>([
    {
      id: 'node-1',
      title: 'AI Prompt Generator',
      position: { x: 100, y: 100 },
      width: 220,
      height: 140,
      inputs: ['in'],
      outputs: ['out', 'raw'],
    },
    {
      id: 'node-2',
      title: 'Latent Space Upscaler',
      position: { x: 450, y: 200 },
      width: 220,
      height: 140,
      inputs: ['prompt'],
      outputs: ['image'],
    },
  ]);
  const [isDirty, setIsDirty] = useState<boolean>(true);

  // Interaction tracking refs to avoid React re-render lag during drag/pan
  const isDraggingRef = useRef<boolean>(false);
  const dragTypeRef = useRef<'pan' | 'node' | null>(null);
  const activeNodeIdRef = useRef<string | null>(null);
  const dragStartRef = useRef<Point>({ x: 0, y: 0 });
  const viewportRef = useRef<Viewport>(viewport);
  const nodesRef = useRef<Node[]>(nodes);

  viewportRef.current = viewport;
  nodesRef.current = nodes;

  // Mark dirty on viewport or node state change
  useEffect(() => {
    setIsDirty(true);
  }, [viewport, nodes]);

  // Main Render Loop with requestAnimationFrame and Dirty Flag optimization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      if (!isDirty) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      // Handle High-DPI Scaling
      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      // Apply Viewport Transformation Matrix
      const { x: vx, y: vy, zoom } = viewportRef.current;
      ctx.translate(vx, vy);
      ctx.scale(zoom, zoom);

      // Render Infinite Grid Background
      const gridSize = 40 * zoom;
      const startX = (-vx % gridSize) / zoom;
      const startY = (-vy % gridSize) / zoom;
      const endX = startX + width / zoom;
      const endY = startY + height / zoom;

      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1 / zoom;
      ctx.beginPath();
      for (let x = startX; x < endX; x += 40) {
        ctx.moveTo(x, startY);
        ctx.lineTo(x, endY);
      }
      for (let y = startY; y < endY; y += 40) {
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
      }
      ctx.stroke();

      // Spatial Culling & Node Rendering Loop
      const viewBounds = {
        left: -vx / zoom,
        top: -vy / zoom,
        right: (-vx + width) / zoom,
        bottom: (-vy + height) / zoom,
      };

      for (const node of nodesRef.current) {
        // Frustum / Spatial Culling check
        if (
          node.position.x + node.width < viewBounds.left ||
          node.position.x > viewBounds.right ||
          node.position.y + node.height < viewBounds.top ||
          node.position.y > viewBounds.bottom
        ) {
          continue; // Skip off-screen nodes entirely
        }

        // Draw Node Background & Border
        ctx.fillStyle = '#0f172a';
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 2 / zoom;
        ctx.beginPath();
        ctx.roundRect(node.position.x, node.position.y, node.width, node.height, 8);
        ctx.fill();
        ctx.stroke();

        // Draw Node Header
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect(node.position.x, node.position.y, node.width, 32, [8, 8, 0, 0]);
        ctx.fill();

        // Draw Header Text
        ctx.fillStyle = '#f8fafc';
        ctx.font = '12px Inter, sans-serif';
        ctx.fillText(node.title, node.position.x + 12, node.position.y + 20);

        // Draw Ports
        node.inputs.forEach((_, idx) => {
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(
            node.position.x,
            node.position.y + 50 + idx * 24,
            5 / zoom,
            0,
            Math.PI * 2
          );
          ctx.fill();
        });

        node.outputs.forEach((_, idx) => {
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(
            node.position.x + node.width,
            node.position.y + 50 + idx * 24,
            5 / zoom,
            0,
            Math.PI * 2
          );
          ctx.fill();
        });
      }

      ctx.restore();
      setIsDirty(false);
      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isDirty]);

  // Mouse Handlers for Pan and Node Dragging
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = (e.clientX - rect.left - viewport.x) / viewport.zoom;
    const mouseY = (e.clientY - rect.top - viewport.y) / viewport.zoom;

    // Check if clicked inside any node
    const clickedNode = nodes.find(
      (n) =>
        mouseX >= n.position.x &&
        mouseX <= n.position.x + n.width &&
        mouseY >= n.position.y &&
        mouseY <= n.position.y + n.height
    );

    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };

    if (clickedNode) {
      dragTypeRef.current = 'node';
      activeNodeIdRef.current = clickedNode.id;
    } else {
      dragTypeRef.current = 'pan';
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;

    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    dragStartRef.current = { x: e.clientX, y: e.clientY };

    if (dragTypeRef.current === 'pan') {
      setViewport((prev) => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
    } else if (dragTypeRef.current === 'node' && activeNodeIdRef.current) {
      setNodes((prev) =>
        prev.map((n) =>
          n.id === activeNodeIdRef.current
            ? {
                ...n,
                position: {
                  x: n.position.x + dx / viewport.zoom,
                  y: n.position.y + dy / viewport.zoom,
                },
              }
            : n
        )
      );
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
    dragTypeRef.current = null;
    activeNodeIdRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    setViewport((prev) => ({
      ...prev,
      zoom: Math.max(0.2, Math.min(4, prev.zoom * zoomFactor)),
    }));
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950">
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"
      />
    </div>
  );
}
