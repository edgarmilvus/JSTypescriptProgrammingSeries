/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/VectorWireOverlay.tsx
'use client';

import React, { useState } from 'react';

interface Connection {
  id: string;
  sourceNodeId: string;
  sourcePort: string;
  targetNodeId: string;
  targetPort: string;
  isActive: boolean;
}

interface VectorWireOverlayProps {
  connections: Connection[];
  nodePositions: Record<string, { x: number; y: number; width: number; height: number }>;
  viewport: { x: number; y: number; zoom: number };
  onDeleteConnection: (id: string) => void;
}

export function VectorWireOverlay({
  connections,
  nodePositions,
  viewport,
  onDeleteConnection,
}: VectorWireOverlayProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  // Helper function to generate smooth cubic Bézier path strings
  const createBezierPath = (
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): string => {
    const dx = Math.abs(x2 - x1) * 0.5;
    // Control points curve horizontally to maintain organic graph wiring
    return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
  };

  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
      <defs>
        <linearGradient id="wire-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#818cf8" />
        </linearGradient>
      </defs>
      <g
        transform={`translate(${viewport.x}, ${viewport.y}) scale(${viewport.zoom})`}
      >
        {connections.map((conn) => {
          const source = nodePositions[conn.sourceNodeId];
          const target = nodePositions[conn.targetNodeId];

          if (!source || !target) return null;

          // Compute absolute port coordinates on nodes
          const x1 = source.x + source.width;
          const y1 = source.y + 70; // Hardcoded port offset for demonstration
          const x2 = target.x;
          const y2 = target.y + 70;

          const pathString = createBezierPath(x1, y1, x2, y2);
          const isHovered = hoveredId === conn.id;

          return (
            <g key={conn.id} className="pointer-events-auto cursor-pointer">
              {/* Invisible thick hit area for easier mouse selection */}
              <path
                d={pathString}
                fill="none"
                stroke="transparent"
                strokeWidth={16}
                onMouseEnter={() => setHoveredId(conn.id)}
                onMouseLeave={() => setHoveredId(null)}
                onClick={() => onDeleteConnection(conn.id)}
              />
              
              {/* Background glowing wire when active */}
              {conn.isActive && (
                <path
                  d={pathString}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth={6}
                  strokeOpacity={0.4}
                  className="blur-sm"
                />
              )}

              {/* Main Visible Wire Path */}
              <path
                d={pathString}
                fill="none"
                stroke={isHovered ? '#f43f5e' : 'url(#wire-gradient)'}
                strokeWidth={isHovered ? 4 : 3}
                strokeDasharray={conn.isActive ? '8 4' : undefined}
                className={conn.isActive ? 'animate-dash-flow' : ''}
              />
            </g>
          );
        })}
      </g>
    </svg>
  );
}
