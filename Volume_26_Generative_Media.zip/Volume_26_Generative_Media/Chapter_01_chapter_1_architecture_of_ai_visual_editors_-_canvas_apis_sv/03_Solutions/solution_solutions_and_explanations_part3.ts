/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// src/lib/webgl/WebGLImageProcessor.ts

export class WebGLImageProcessor {
  private gl: WebGL2RenderingContext;
  private program: WebGLProgram | null = null;
  private positionBuffer: WebGLBuffer | null = null;
  private texture: WebGLTexture | null = null;
  private uResolutionLocation: WebGLUniformLocation | null = null;
  private uKernelLocation: WebGLUniformLocation | null = null;

  constructor(canvas: HTMLCanvasElement) {
    const context = canvas.getContext('webgl2', { preserveDrawingBuffer: true });
    if (!context) {
      throw new Error('WebGL2 is not supported in this browser environment.');
    }
    this.gl = context;
    this.initializePipeline();
  }

  private initializePipeline(): void {
    const gl = this.gl;

    // Vertex Shader: Full-screen quad mapping
    const vsSource = `#version 300 es
      in vec2 a_position;
      out vec2 v_texCoord;
      void main() {
        v_texCoord = (a_position + 1.0) * 0.5;
        v_texCoord.y = 1.0 - v_texCoord.y; // Flip Y for WebGL texture orientation
        gl_Position = vec4(a_position, 0.0, 1.0);
      }
    `;

    // Fragment Shader: 3x3 Convolution Matrix Filter
    const fsSource = `#version 300 es
      precision highp float;
      in vec2 v_texCoord;
      uniform sampler2D u_image;
      uniform vec2 u_resolution;
      uniform float u_kernel[9];
      out vec4 fragColor;

      void main() {
        vec2 onePixel = 1.0 / u_resolution;
        vec4 colorSum = 
          texture(u_image, v_texCoord + onePixel * vec2(-1, -1)) * u_kernel[0] +
          texture(u_image, v_texCoord + onePixel * vec2( 0, -1)) * u_kernel[1] +
          texture(u_image, v_texCoord + onePixel * vec2( 1, -1)) * u_kernel[2] +
          texture(u_image, v_texCoord + onePixel * vec2(-1,  0)) * u_kernel[3] +
          texture(u_image, v_texCoord + onePixel * vec2( 0,  0)) * u_kernel[4] +
          texture(u_image, v_texCoord + onePixel * vec2( 1,  0)) * u_kernel[5] +
          texture(u_image, v_texCoord + onePixel * vec2(-1,  1)) * u_kernel[6] +
          texture(u_image, v_texCoord + onePixel * vec2( 0,  1)) * u_kernel[7] +
          texture(u_image, v_texCoord + onePixel * vec2( 1,  1)) * u_kernel[8];

        fragColor = vec4(colorSum.rgb, 1.0);
      }
    `;

    const vertexShader = this.compileShader(gl.VERTEX_SHADER, vsSource);
    const fragmentShader = this.compileShader(gl.FRAGMENT_SHADER, fsSource);

    this.program = gl.createProgram();
    if (!this.program) return;

    gl.attachShader(this.program, vertexShader);
    gl.attachShader(this.program, fragmentShader);
    gl.linkProgram(this.program);

    if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) {
      const info = gl.getProgramInfoLog(this.program);
      gl.deleteProgram(this.program);
      throw new Error(`Failed to compile WebGL program: ${info}`);
    }

    // Set up geometry buffer (Full-screen quad)
    this.positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    const positions = new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]);
    gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

    // Cache Uniform Locations
    this.uResolutionLocation = gl.getUniformLocation(this.program, 'u_resolution');
    this.uKernelLocation = gl.getUniformLocation(this.program, 'u_kernel');
  }

  private compileShader(type: number, source: string): WebGLShader {
    const gl = this.gl;
    const shader = gl.createShader(type);
    if (!shader) throw new Error('Unable to create WebGL shader.');

    gl.shaderSource(shader, source);
    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const info = gl.getShaderInfoLog(shader);
      gl.deleteShader(shader);
      throw new Error(`Shader compilation error: ${info}`);
    }
    return shader;
  }

  public loadTexture(imageSource: TexImageSource): void {
    const gl = this.gl;
    this.texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.texture);

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, imageSource);
  }

  public render(kernel: number[]): void {
    const gl = this.gl;
    if (!this.program || !this.positionBuffer || !this.texture) return;

    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(this.program);

    // Bind Uniforms
    gl.uniform2f(this.uResolutionLocation, gl.canvas.width, gl.canvas.height);
    gl.uniform1fv(this.uKernelLocation, kernel);

    // Bind Position Attribute
    const positionAttributeLocation = gl.getAttribLocation(this.program, 'a_position');
    gl.enableVertexAttribArray(positionAttributeLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    gl.vertexAttribPointer(positionAttributeLocation, 2, gl.FLOAT, false, 0, 0);

    // Draw Quad
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  public destroy(): void {
    const gl = this.gl;
    if (this.texture) gl.deleteTexture(this.texture);
    if (this.positionBuffer) gl.deleteBuffer(this.positionBuffer);
    if (this.program) gl.deleteProgram(this.program);
  }
}
