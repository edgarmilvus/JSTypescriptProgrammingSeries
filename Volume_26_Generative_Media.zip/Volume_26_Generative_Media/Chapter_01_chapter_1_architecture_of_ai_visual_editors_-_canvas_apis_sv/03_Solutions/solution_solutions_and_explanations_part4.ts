/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/lib/gpu/GPUResourceManager.ts

interface ManagedResource {
  id: string;
  type: 'texture' | 'buffer' | 'framebuffer';
  resource: WebGLObject;
  sizeInBytes: number;
  refCount: number;
}

export class GPUResourceManager {
  private static instance: GPUResourceManager;
  private resources: Map<string, ManagedResource> = new Map();
  private totalVRAMUsage: number = 0;

  private constructor() {}

  public static getInstance(): GPUResourceManager {
    if (!GPUResourceManager.instance) {
      GPUResourceManager.instance = new GPUResourceManager();
    }
    return GPUResourceManager.instance;
  }

  public registerResource(
    id: string,
    type: ManagedResource['type'],
    resource: WebGLObject,
    sizeInBytes: number
  ): void {
    if (this.resources.has(id)) {
      this.retainResource(id);
      return;
    }

    this.resources.set(id, {
      id,
      type,
      resource,
      sizeInBytes,
      refCount: 1,
    });

    this.totalVRAMUsage += sizeInBytes;
  }

  public retainResource(id: string): void {
    const item = this.resources.get(id);
    if (item) {
      item.refCount += 1;
    }
  }

  public releaseResource(id: string, gl: WebGL2RenderingContext): void {
    const item = this.resources.get(id);
    if (!item) return;

    item.refCount -= 1;

    if (item.refCount <= 0) {
      // Free VRAM on the GPU context
      if (item.type === 'texture') {
        gl.deleteTexture(item.resource as WebGLTexture);
      } else if (item.type === 'buffer') {
        gl.deleteBuffer(item.resource as WebGLBuffer);
      } else if (item.type === 'framebuffer') {
        gl.deleteFramebuffer(item.resource as WebGLFramebuffer);
      }

      this.totalVRAMUsage -= item.sizeInBytes;
      this.resources.delete(id);
    }
  }

  public getDiagnosticStats(): { totalBytes: number; activeCount: number; breakdown: Record<string, number> } {
    const breakdown: Record<string, number> = {};
    for (const [id, item] of this.resources.entries()) {
      breakdown[id] = item.sizeInBytes;
    }

    return {
      totalBytes: this.totalVRAMUsage,
      activeCount: this.resources.size,
      breakdown,
    };
  }
}
