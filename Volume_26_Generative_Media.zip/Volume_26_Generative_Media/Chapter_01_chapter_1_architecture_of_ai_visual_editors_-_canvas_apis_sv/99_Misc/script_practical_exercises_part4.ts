/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// src/lib/gpu/GPUResourceManager.ts

interface ManagedResource {
  id: string;
  type: 'texture' | 'buffer' | 'framebuffer';
  resource: WebGLObject;
  sizeInBytes: number;
  refCount: number;
}

export class GPUResourceManager {
  private static instance: GPUResourceManager;
  private resources: Map<string, ManagedResource> = new Map();
  private totalVRAMUsage: number = 0;

  private constructor() {}

  public static getInstance(): GPUResourceManager {
    if (!GPUResourceManager.instance) {
      GPUResourceManager.instance = new GPUResourceManager();
    }
    return GPUResourceManager.instance;
  }

  public registerResource(
    id: string,
    type: ManagedResource['type'],
    resource: WebGLObject,
    sizeInBytes: number
  ): void {
    // TODO: Implement resource registration with initial reference count of 1.
    // Track total VRAM usage and handle duplicate ID collisions.
  }

  public retainResource(id: string): void {
    // TODO: Increment reference count for shared GPU assets.
  }

  public releaseResource(id: string, gl: WebGL2RenderingContext): void {
    // TODO: Decrement reference count. If count reaches 0, delete the WebGLObject
    // using gl.deleteTexture / gl.deleteBuffer and update totalVRAMUsage.
  }

  public getDiagnosticStats(): { totalBytes: number; activeCount: number } {
    // TODO: Return current memory metrics for the diagnostic UI.
    return { totalBytes: this.totalVRAMUsage, activeCount: this.resources.size };
  }
}
