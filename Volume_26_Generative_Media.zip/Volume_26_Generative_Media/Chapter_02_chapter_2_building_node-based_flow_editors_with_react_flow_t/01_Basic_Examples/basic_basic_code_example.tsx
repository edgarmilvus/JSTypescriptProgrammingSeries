/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useCallback } from 'react';
import ReactFlow, {
  Controls,
  Background,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
  Connection,
  Edge,
  Node,
  NodeChange,
  EdgeChange,
  Handle,
  Position,
} from 'reactflow';
import 'reactflow/dist/style.css';

/**
 * Defines the custom data shape for an Entry Point Node.
 * Represents the starting point of an AI generation pipeline.
 */
interface EntryPointNodeData {
  label: string;
  onUpdatePrompt: (id: string, newPrompt: string) => void;
  promptValue: string;
}

/**
 * Custom React component for the Entry Point Node.
 * Uses a Source handle on the right to pass data downstream.
 */
const EntryPointNode: React.FC<{ id: string; data: EntryPointNodeData }> = ({ id, data }) => {
  return (
    <div style={{
      padding: '16px',
      borderRadius: '8px',
      background: '#1e1e2f',
      color: '#ffffff',
      border: '2px solid #6366f1',
      width: '240px',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    }}>
      <div style={{ fontSize: '12px', fontWeight: 600, color: '#818cf8', marginBottom: '8px' }}>
        ENTRY POINT NODE
      </div>
      <div style={{ fontSize: '14px', fontWeight: 500, marginBottom: '8px' }}>{data.label}</div>
      
      {/* Interactive prompt input bound to reactive state */}
      <input
        type="text"
        value={data.promptValue}
        onChange={(e) => data.onUpdatePrompt(id, e.target.value)}
        placeholder="Enter base generation prompt..."
        style={{
          width: '100%',
          padding: '6px',
          borderRadius: '4px',
          border: '1px solid #4b5563',
          background: '#111827',
          color: '#ffffff',
          fontSize: '12px',
        }}
      />

      {/* Output Handle pointing to downstream nodes */}
      <Handle
        type="source"
        position={Position.Right}
        style={{ background: '#6366f1', width: '10px', height: '10px' }}
      />
    </div>
  );
};

/**
 * Defines the custom data shape for a Generative Processing Node.
 */
interface GenerationNodeData {
  label: string;
  model: string;
}

/**
 * Custom React component for the Generative Processing Node.
 */
const GenerationNode: React.FC<{ data: GenerationNodeData }> = ({ data }) => {
  return (
    <div style={{
      padding: '16px',
      borderRadius: '8px',
      background: '#1e1e2f',
      color: '#ffffff',
      border: '2px solid #ec4899',
      width: '200px',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    }}>
      {/* Input Handle receiving data from upstream nodes */}
      <Handle
        type="target"
        position={Position.Left}
        style={{ background: '#ec4899', width: '10px', height: '10px' }}
      />
      
      <div style={{ fontSize: '12px', fontWeight: 600, color: '#f472b6', marginBottom: '4px' }}>
        AI PROCESSOR
      </div>
      <div style={{ fontSize: '14px', fontWeight: 500 }}>{data.label}</div>
      <div style={{ fontSize: '11px', color: '#9ca3af', marginTop: '4px' }}>Model: {data.model}</div>
    </div>
  );
};

// Register custom node types outside the component render scope to prevent re-creation loops
const nodeTypes = {
  entryPoint: EntryPointNode,
  generation: GenerationNode,
};

/**
 * Initial nodes representing a basic AI generation workflow.
 */
const initialNodes: Node[] = [
  {
    id: 'node-1',
    type: 'entryPoint',
    position: { x: 100, y: 200 },
    data: { 
      label: 'Pipeline Root', 
      promptValue: 'A cyberpunk cityscape at sunset' 
    },
  },
  {
    id: 'node-2',
    type: 'generation',
    position: { x: 450, y: 200 },
    data: { 
      label: 'Stable Diffusion XL', 
      model: 'sdxl-base-1.0' 
    },
  },
];

const initialEdges: Edge[] = [
  { id: 'edge-1-2', source: 'node-1', target: 'node-2', animated: true, stroke: '#6366f1' },
];

/**
 * Main Visual Workflow Canvas Component
 */
export default function GenerativeWorkflowCanvas() {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);

  /**
   * Callback to update the prompt value inside an Entry Point Node's data payload.
   */
  const handleUpdatePrompt = useCallback((id: string, newPrompt: string) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === id) {
          return {
            ...node,
            data: {
              ...node.data,
              promptValue: newPrompt,
            },
          };
        }
        return node;
      })
    );
  }, []);

  // Inject the update handler back into the initial nodes dynamically
  const nodesWithHandlers = nodes.map((node) => {
    if (node.type === 'entryPoint') {
      return {
        ...node,
        data: {
          ...node.data,
          onUpdatePrompt: handleUpdatePrompt,
        },
      };
    }
    return node;
  });

  const onNodesChange = useCallback(
    (changes: NodeChange[]) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge({ ...params, animated: true }, eds)),
    []
  );

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#0b0f19' }}>
      <ReactFlow
        nodes={nodesWithHandlers}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
      >
        <Controls />
        <Background color="#1f2937" gap={16} />
      </ReactFlow>
    </div>
  );
}
