/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useCallback, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  Handle,
  Position,
  NodeProps,
} from 'reactflow';
import 'reactflow/dist/style.css';

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & INTERFACES
 * ============================================================================
 */

/** Defines the operational categories available within our generative pipeline. */
type NodeType = 'promptNode' | 'inferenceNode' | 'webGpuFilterNode';

/** Represents the execution status of an individual node in the canvas. */
type ExecutionStatus = 'idle' | 'running' | 'success' | 'error';

/** Base data structure for all node types in the React Flow canvas. */
interface BaseNodeData {
  label: string;
  status: ExecutionStatus;
  progress: number;
  onExecute?: (nodeId: string) => Promise<void>;
}

/** Specific data payload for Prompt Engineering nodes. */
interface PromptNodeData extends BaseNodeData {
  promptText: string;
  temperature: number;
}

/** Specific data payload for AI Inference nodes (e.g., Stable Diffusion / LLM calls). */
interface InferenceNodeData extends BaseNodeData {
  modelName: string;
  outputResolution: string;
}

/** Specific data payload for WebGPU Image Processing nodes. */
interface WebGpuFilterData extends BaseNodeData {
  filterType: 'gaussianBlur' | 'chromaticAberration' | 'neuralUpscale';
  intensity: number;
}

/** Union type representing all valid node data configurations. */
type GenerativeNodeData = PromptNodeData | InferenceNodeData | WebGpuFilterData;

/** Defines the structure of the execution context passed through the graph pipeline. */
interface PipelineContext {
  executionId: string;
  artifacts: Map<string, any>;
  logger: (nodeId: string, message: string) => void;
}

/**
 * ============================================================================
 * 2. CUSTOM REACT FLOW NODE COMPONENTS
 * ============================================================================
 */

/**
 * Custom Prompt Node component for handling user-defined text inputs and hyperparameter tuning.
 */
const PromptNode: React.FC<NodeProps<PromptNodeData>> = ({ id, data }) => {
  return (
    <div className="bg-slate-900 border border-slate-700 rounded-lg p-4 shadow-xl text-slate-100 min-w-[240px]">
      <div className="flex justify-between items-center mb-2">
        <span className="font-semibold text-sm text-indigo-400">📝 Prompt Node</span>
        <span className={`text-xs px-2 py-0.5 rounded ${
          data.status === 'success' ? 'bg-emerald-900 text-emerald-300' :
          data.status === 'running' ? 'bg-amber-900 text-amber-300 animate-pulse' :
          'bg-slate-800 text-slate-400'
        }`}>
          {data.status}
        </span>
      </div>
      <div className="space-y-2">
        <input 
          type="text" 
          defaultValue={data.promptText} 
          className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          placeholder="Enter generation prompt..."
        />
        <div className="flex justify-between text-xs text-slate-400">
          <span>Temp: {data.temperature}</span>
          <span>ID: {id.slice(0, 6)}</span>
        </div>
      </div>
      {/* Output Handle for downstream nodes */}
      <Handle type="source" position={Position.Right} className="w-3 h-3 bg-indigo-500 rounded-full" />
    </div>
  );
};

/**
 * Custom WebGPU Filter Node component for real-time visual pipeline processing.
 */
const WebGpuFilterNode: React.FC<NodeProps<WebGpuFilterData>> = ({ id, data }) => {
  return (
    <div className="bg-slate-900 border border-slate-700 rounded-lg p-4 shadow-xl text-slate-100 min-w-[240px]">
      {/* Input Handle for upstream dependency */}
      <Handle type="target" position={Position.Left} className="w-3 h-3 bg-purple-500 rounded-full" />
      
      <div className="flex justify-between items-center mb-2">
        <span className="font-semibold text-sm text-purple-400">⚡ WebGPU Filter</span>
        <span className={`text-xs px-2 py-0.5 rounded ${
          data.status === 'success' ? 'bg-emerald-900 text-emerald-300' :
          data.status === 'running' ? 'bg-amber-900 text-amber-300 animate-pulse' :
          'bg-slate-800 text-slate-400'
        }`}>
          {data.status}
        </span>
      </div>
      <div className="space-y-2 text-xs">
        <div className="text-slate-300">Filter: <span className="text-purple-300">{data.filterType}</span></div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div 
            className="bg-purple-500 h-full transition-all duration-300" 
            style={{ width: `${data.progress}%` }}
          />
        </div>
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 bg-purple-500 rounded-full" />
    </div>
  );
};

/**
 * ============================================================================
 * 3. INITIAL CANVAS STATE & CONFIGURATION
 * ============================================================================
 */

const initialNodes: Node<GenerativeNodeData>[] = [
  {
    id: 'node-1',
    type: 'promptNode',
    position: { x: 50, y: 150 },
    data: { 
      label: 'Main Prompt', 
      status: 'idle', 
      progress: 0, 
      promptText: 'A cyberpunk cityscape bathed in neon rain, cinematic lighting', 
      temperature: 0.7 
    },
  },
  {
    id: 'node-2',
    type: 'webGpuFilterNode',
    position: { x: 450, y: 150 },
    data: { 
      label: 'GPU Upscale', 
      status: 'idle', 
      progress: 0, 
      filterType: 'neuralUpscale', 
      intensity: 0.85 
    },
  },
];

const initialEdges: Edge[] = [
  { id: 'e1-2', source: 'node-1', target: 'node-2', animated: true, style: { stroke: '#6366f1' } }
];

/**
 * ============================================================================
 * 4. MAIN CONTAINER & PIPELINE EXECUTION ENGINE
 * ============================================================================
 */

export default function GenerativeWorkflowCanvas() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  /** Register custom node types with React Flow */
  const nodeTypes = useMemo(() => ({
    promptNode: PromptNode,
    webGpuFilterNode: WebGpuFilterNode,
  }), []);

  /** Handles connection creation between canvas nodes */
  const onConnect = useCallback((params: Connection) => {
    setEdges((eds) => addEdge({ ...params, animated: true, style: { stroke: '#6366f1' } }, eds));
  }, [setEdges]);

  /** 
   * Asynchronous graph execution engine simulating topological sort traversal,
   * non-blocking I/O dispatch, and real-time state mutation.
   */
  const executePipeline = async () => {
    setIsExecuting(true);
    const context: PipelineContext = {
      executionId: Math.random().toString(36.substring(7)),
      artifacts: new Map(),
      logger: (nodeId, msg) => console.log(`[PipelineExecution:${nodeId}] ${msg}`),
    };

    try {
      for (const node of nodes) {
        // Update node status to running
        setNodes((nds) => nds.map((n) => n.id === node.id ? { ...n, data: { ...n.data, status: 'running', progress: 25 } } : n));

        // Simulate asynchronous WebGPU processing or LLM inference delay (Non-blocking I/O simulation)
        await new Promise((resolve) => setTimeout(resolve, 1200));

        context.logger(node.id, 'Execution completed successfully.');

        // Update node status to success
        setNodes((nds) => nds.map((n) => n.id === node.id ? { ...n, data: { ...n.data, status: 'success', progress: 100 } } : n));
      }
    } catch (error) {
      console.error('Pipeline execution failed:', error);
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="w-full h-screen flex flex-col bg-slate-950">
      {/* Top Navigation & Controls Bar */}
      <header className="h-16 border-b border-slate-800 px-6 flex items-center justify-between bg-slate-900/50 backdrop-blur">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-indigo-500 animate-ping" />
          <h1 className="text-slate-100 font-bold text-lg tracking-tight">Generative Media Pipeline Studio</h1>
        </div>
        <button
          onClick={executePipeline}
          disabled={isExecuting}
          className={`px-5 py-2 rounded-lg font-medium text-sm transition-all shadow-lg ${
            isExecuting 
              ? 'bg-amber-600/50 text-amber-200 cursor-not-allowed' 
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20'
          }`}
        >
          {isExecuting ? 'Processing Pipeline...' : 'Execute Graph'}
        </button>
      </header>

      {/* React Flow Canvas Viewport */}
      <div className="flex-1 w-full h-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
          className="bg-slate-950"
        >
          <Background color="#1e293b" gap={24} size={1} />
          <Controls className="bg-slate-900 border border-slate-700 text-slate-100 rounded-lg shadow-xl" />
        </ReactFlow>
      </div>
    </div>
  );
}
