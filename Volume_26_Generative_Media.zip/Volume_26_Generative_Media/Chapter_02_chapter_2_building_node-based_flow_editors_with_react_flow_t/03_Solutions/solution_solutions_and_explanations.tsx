/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback, useMemo } from 'react';
import { Handle, Position, NodeProps, Node } from '@xyflow/react';

export interface PromptNodeData {
  label: string;
  prompt: string;
  model: 'sdxl' | 'flux-dev' | 'gpt-4o';
  guidanceScale: number;
  steps: number;
  onDataChange: (id: string, newData: Partial<PromptNodeData>) => void;
  [key: string]: unknown;
}

export type PromptEngineNodeType = Node<PromptNodeData, 'promptEngine'>;

export const PromptEngineNode: React.FC<NodeProps<PromptEngineNodeType>> = ({ id, data }) => {
  const [prompt, setPrompt] = useState<string>(data.prompt || '');
  const [model, setModel] = useState<'sdxl' | 'flux-dev' | 'gpt-4o'>(data.model || 'sdxl');
  const [guidanceScale, setGuidanceScale] = useState<number>(data.guidanceScale ?? 7.5);
  const [steps, setSteps] = useState<number>(data.steps ?? 30);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState<boolean>(false);

  // Approximate token count estimation using regex splitting
  const tokenCount = useMemo(() => {
    if (!prompt.trim()) return 0;
    const tokens = prompt.trim().split(/\s+|(?=[.,!?;:])|(?<=[.,!?;:])/);
    return tokens.filter(Boolean).length;
  }, [prompt]);

  const handlePromptChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newPrompt = e.target.value;
    setPrompt(newPrompt);
    data.onDataChange(id, { prompt: newPrompt });
  }, [id, data]);

  const handleModelChange = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const newModel = e.target.value as 'sdxl' | 'flux-dev' | 'gpt-4o';
    setModel(newModel);
    data.onDataChange(id, { model: newModel });
  }, [id, data]);

  const handleGuidanceChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setGuidanceScale(val);
    data.onDataChange(id, { guidanceScale: val });
  }, [id, data]);

  const handleStepsChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setSteps(val);
    data.onDataChange(id, { steps: val });
  }, [id, data]);

  return (
    <div className="prompt-engine-node" style={{ background: '#1e1e1e', color: '#fff', padding: 12, borderRadius: 8, width: 280 }}>
      <Handle type="target" position={Position.Top} id="input-context" />
      
      <div className="node-header" style={{ marginBottom: 8 }}>
        <strong>{data.label}</strong>
      </div>
      
      <div className="node-body" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <textarea
            value={prompt}
            onChange={handlePromptChange}
            placeholder="Enter prompt engineering script..."
            rows={3}
            style={{ width: '100%', resize: 'vertical', background: '#2d2d2d', color: '#fff', border: '1px solid #444', borderRadius: 4, padding: 6 }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', marginTop: 2 }}>
            <span style={{ color: tokenCount > 512 ? '#ff4d4f' : '#888' }}>
              Tokens: {tokenCount} / 512
            </span>
            {tokenCount > 512 && <span style={{ color: '#ff4d4f' }}>⚠️ Limit exceeded</span>}
          </div>
        </div>

        <div>
          <label style={{ fontSize: '12px', display: 'block', marginBottom: 2 }}>Model</label>
          <select value={model} onChange={handleModelChange} style={{ width: '100%', background: '#2d2d2d', color: '#fff', border: '1px solid #444', borderRadius: 4, padding: 4 }}>
            <option value="sdxl">Stable Diffusion XL</option>
            <option value="flux-dev">Flux.1 Dev</option>
            <option value="gpt-4o">GPT-4o Vision</option>
          </select>
        </div>

        <button 
          onClick={() => setIsAdvancedOpen(prev => !prev)}
          style={{ background: 'transparent', border: 'none', color: '#40a9ff', cursor: 'pointer', textAlign: 'left', padding: 0, fontSize: '12px' }}
        >
          {isAdvancedOpen ? '▾ Hide Advanced Settings' : '▸ Show Advanced Settings'}
        </button>

        {isAdvancedOpen && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, background: '#252525', padding: 8, borderRadius: 4 }}>
            <div>
              <label style={{ fontSize: '11px', display: 'block' }}>Guidance Scale: {guidanceScale}</label>
              <input type="range" min="1" max="20" step="0.5" value={guidanceScale} onChange={handleGuidanceChange} style={{ width: '100%' }} />
            </div>
            <div>
              <label style={{ fontSize: '11px', display: 'block' }}>Steps: {steps}</label>
              <input type="range" min="10" max="150" step="5" value={steps} onChange={handleStepsChange} style={{ width: '100%' }} />
            </div>
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Bottom} id="output-media" />
    </div>
  );
};
