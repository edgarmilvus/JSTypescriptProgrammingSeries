/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface NodePolicyMetadata {
  maxIterations?: number;
}

export interface ExecutionContext {
  runId: string;
  nodeVisitCounts: Map<string, number>;
  defaultMaxIterations: number;
  status: 'IDLE' | 'RUNNING' | 'TERMINATED_MAX_ITERATIONS' | 'COMPLETED';
}

export class WorkflowExecutionEngine {
  private context: ExecutionContext;

  constructor(runId: string, defaultMaxIterations: number = 5) {
    this.context = {
      runId,
      nodeVisitCounts: new Map<string, number>(),
      defaultMaxIterations,
      status: 'IDLE',
    };
  }

  /**
   * Evaluates iteration limits dynamically using runtime node metadata rules.
   * @param nodeId The target node identifier.
   * @param nodeData Optional React Flow node data payload carrying custom policy constraints.
   */
  public evaluateIterationPolicy(nodeId: string, nodeData?: NodePolicyMetadata): boolean {
    if (this.context.status === 'TERMINATED_MAX_ITERATIONS') {
      return false;
    }

    this.context.status = 'RUNNING';
    const currentCount = (this.context.nodeVisitCounts.get(nodeId) || 0) + 1;
    this.context.nodeVisitCounts.set(nodeId, currentCount);

    const limit = nodeData?.maxIterations ?? this.context.defaultMaxIterations;

    if (currentCount > limit) {
      this.context.status = 'TERMINATED_MAX_ITERATIONS';
      console.warn(`[WorkflowExecutionEngine] Max Iteration Policy breached for node "${nodeId}". Run ID: ${this.context.runId}. Executed ${currentCount} times (Limit: ${limit}).`);
      return false;
    }

    return true;
  }

  public resetContext(): void {
    this.context.nodeVisitCounts.clear();
    this.context.status = 'IDLE';
  }

  public getStatus(): string {
    return this.context.status;
  }
}
