/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface MediaChunk {
  sequenceId: number;
  data: Uint8Array;
  timestamp: number;
  isComplete: boolean;
}

export class MediaStreamChunker {
  private chunkSize: number;
  private minChunkSize: number;
  private sequenceCounter: number = 0;
  private buffer: Uint8Array = new Uint8Array(0);

  constructor(initialChunkSizeBytes: number = 65536, minChunkSizeBytes: number = 16384) {
    this.chunkSize = initialChunkSizeBytes;
    this.minChunkSize = minChunkSizeBytes;
  }

  /**
   * Concatenates buffers and yields exact byte-sized chunks with adaptive backpressure handling.
   */
  public *processIncomingBytes(incomingData: Uint8Array): Generator<MediaChunk, void, unknown> {
    // Check main thread performance metrics for adaptive throttling
    const startPerf = performance.now();

    // Combine existing remainder buffer with incoming bytes
    const combinedBuffer = new Uint8Array(this.buffer.length + incomingData.length);
    combinedBuffer.set(this.buffer, 0);
    combinedBuffer.set(incomingData, this.buffer.length);
    this.buffer = combinedBuffer;

    // Slice buffer into strict chunkSize blocks
    while (this.buffer.length >= this.chunkSize) {
      const chunkData = this.buffer.slice(0, this.chunkSize);
      this.buffer = this.buffer.slice(this.chunkSize);

      yield {
        sequenceId: this.sequenceCounter++,
        data: chunkData,
        timestamp: Date.now(),
        isComplete: false,
      };
    }

    // Adaptive chunk sizing based on execution frame lag
    const duration = performance.now() - startPerf;
    if (duration > 16.67 && this.chunkSize > this.minChunkSize) {
      // Main thread lag detected (>1 frame time), reduce chunk size by 50%
      this.chunkSize = Math.max(this.minChunkSize, Math.floor(this.chunkSize * 0.5));
      console.warn(`[MediaStreamChunker] Main thread lag detected (${duration.toFixed(2)}ms). Adapting chunk size down to: ${this.chunkSize} bytes.`);
    }
  }

  public flushRemaining(): MediaChunk | null {
    if (this.buffer.length === 0) return null;
    const finalChunk = {
      sequenceId: this.sequenceCounter++,
      data: this.buffer,
      timestamp: Date.now(),
      isComplete: true,
    };
    this.buffer = new Uint8Array(0);
    return finalChunk;
  }
}
