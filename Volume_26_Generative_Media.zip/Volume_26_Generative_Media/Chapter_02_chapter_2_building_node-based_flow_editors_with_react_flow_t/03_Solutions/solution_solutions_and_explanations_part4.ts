/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface VectorMatchResult {
  id: string;
  prompt: string;
  mediaUrl: string;
  similarity: number;
}

interface CacheEntry {
  timestamp: number;
  results: VectorMatchResult[];
}

export class SupabaseVectorPipelineNode {
  private supabase: SupabaseClient;
  private cache: Map<string, CacheEntry> = new Map();
  private cacheTtlMs: number = 5 * 60 * 1000; // 5 minutes window
  private maxCacheSize: number = 100;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  private hashEmbedding(embedding: number[]): string {
    // Quick sampling hash for LRU key derivation
    return `${embedding.length}:${embedding[0].toFixed(4)}:${embedding[Math.floor(embedding.length / 2)].toFixed(4)}`;
  }

  /**
   * Queries Supabase pgvector database with local LRU caching.
   */
  public async querySimilarAssets(
    embedding: number[],
    matchThreshold: number = 0.75,
    matchCount: number = 5
  ): Promise<VectorMatchResult[]> {
    const cacheKey = `${this.hashEmbedding(embedding)}_${matchThreshold}_${matchCount}`;
    const now = Date.now();

    // Check cache hit
    if (this.cache.has(cacheKey)) {
      const entry = this.cache.get(cacheKey)!;
      if (now - entry.timestamp < this.cacheTtlMs) {
        console.log(`[SupabaseVectorPipelineNode] Cache HIT for vector query.`);
        return entry.results;
      } else {
        this.cache.delete(cacheKey);
      }
    }

    console.log(`[SupabaseVectorPipelineNode] Cache MISS. Executing remote pgvector RPC call...`);
    
    const { data, error } = await this.supabase.rpc('match_media_embeddings', {
      query_embedding: embedding,
      match_threshold: matchThreshold,
      match_count: matchCount,
    });

    if (error) {
      throw new Error(`Supabase Vector Query Failed: ${error.message}`);
    }

    const results = (data as VectorMatchResult[]) || [];

    // Enforce max cache size limit (LRU eviction)
    if (this.cache.size >= this.maxCacheSize) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) this.cache.delete(oldestKey);
    }

    this.cache.set(cacheKey, { timestamp: now, results });
    return results;
  }
}
