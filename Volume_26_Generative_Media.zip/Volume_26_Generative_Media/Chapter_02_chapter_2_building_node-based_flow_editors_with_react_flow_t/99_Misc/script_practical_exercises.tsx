/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.tsx
// Description: Practical Exercises
// ==========================================

// Starter template for Exercise 1
import React, { useState, useCallback } from 'react';
import { Handle, Position, NodeProps, Node } from '@xyflow/react';

// TODO: Define the TypeScript interface for PromptNodeData
export interface PromptNodeData {
  label: string;
  prompt: string;
  model: 'sdxl' | 'flux-dev' | 'gpt-4o';
  guidanceScale: number;
  steps: number;
  onDataChange: (id: string, newData: Partial<PromptNodeData>) => void;
  [key: string]: unknown;
}

export type PromptEngineNodeType = Node<PromptNodeData, 'promptEngine'>;

export const PromptEngineNode: React.FC<NodeProps<PromptEngineNodeType>> = ({ id, data }) => {
  // TODO: Implement local state management and handlers for input changes, model selection, and slider adjustments
  
  return (
    <div className="prompt-engine-node">
      <Handle type="target" position={Position.Top} id="input-context" />
      
      <div className="node-header">
        <strong>{data.label}</strong>
      </div>
      
      <div className="node-body">
        {/* TODO: Insert text area for prompt engineering */}
        {/* TODO: Insert dropdown for model selection */}
        {/* TODO: Insert slider for guidance scale and steps */}
      </div>

      <Handle type="source" position={Position.Bottom} id="output-media" />
    </div>
  );
};
