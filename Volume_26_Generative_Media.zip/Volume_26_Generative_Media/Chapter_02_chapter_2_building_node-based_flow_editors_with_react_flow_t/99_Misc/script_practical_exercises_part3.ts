/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Starter template for Exercise 3
export interface MediaChunk {
  sequenceId: number;
  data: Uint8Array;
  timestamp: number;
  isComplete: boolean;
}

export class MediaStreamChunker {
  private chunkSize: number;
  private sequenceCounter: number = 0;
  private buffer: Uint8Array = new Uint8Array(0);

  constructor(chunkSizeBytes: number = 65536) {
    this.chunkSize = chunkSizeBytes;
  }

  /**
   * Ingests a new incoming binary chunk from the network stream and yields standardized MediaChunks.
   * @param incomingData Raw Uint8Array chunk from ReadableStream.
   */
  public *processIncomingBytes(incomingData: Uint8Array): Generator<MediaChunk, void, unknown> {
    // TODO: Combine existing buffer with incoming data
    // TODO: Slice buffer into chunks of exact chunkSize
    // TODO: Yield MediaChunk objects with incremented sequence IDs
    // TODO: Retain remainder in buffer for next iteration
  }
}
