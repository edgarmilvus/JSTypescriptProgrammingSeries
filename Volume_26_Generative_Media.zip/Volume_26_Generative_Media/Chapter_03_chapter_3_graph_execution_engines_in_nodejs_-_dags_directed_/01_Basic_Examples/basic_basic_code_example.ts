/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file DAG Execution Engine for Node.js AI Pipelines
 * @description A self-contained, production-grade implementation of a Directed Acyclic Graph 
 * execution engine designed for orchestrating asynchronous AI workloads in a SaaS context.
 */

/**
 * Represents the execution state of an individual node within the DAG.
 */
type NodeState = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';

/**
 * Generic interface for data payload flowing through the pipeline.
 */
interface PipelineContext {
    [key: string]: any;
}

/**
 * Definition of a single processing node in the AI pipeline graph.
 */
interface PipelineNode {
    id: string;
    dependencies: string[]; // IDs of parent nodes that must finish first
    /**
     * The asynchronous execution handler for the node.
     * @param context Current shared pipeline context and outputs from dependencies.
     * @returns A promise resolving to the output data of this node.
     */
    execute: (context: PipelineContext) => Promise<any>;
}

/**
 * Engine class responsible for validating, topologically sorting, 
 * and executing the AI pipeline graph.
 */
class AIWorkflowEngine {
    private nodes: Map<string, PipelineNode> = new Map();
    private nodeStates: Map<string, NodeState> = new Map();
    private outputs: Map<string, any> = new Map();

    /**
     * Registers a new node in the execution graph.
     * @param node The pipeline node configuration.
     */
    public addNode(node: PipelineNode): void {
        if (this.nodes.has(node.id)) {
            throw new Error(`Node with ID '${node.id}' already exists in the workflow graph.`);
        }
        this.nodes.set(node.id, node);
        this.nodeStates.set(node.id, 'PENDING');
    }

    /**
     * Validates the graph for missing dependencies and cyclic references,
     * then computes a valid topological sort using Kahn's algorithm.
     * 
     * @returns An array of node IDs in execution order.
     */
    private topologicalSort(): string[] {
        const inDegree: Map<string, number> = new Map();
        const adjList: Map<string, string[]> = new Map();

        // Initialize adjacency list and in-degree maps
        for (const [id] of this.nodes) {
            inDegree.set(id, 0);
            adjList.set(id, []);
        }

        // Build edges and compute in-degrees
        for (const [id, node] of this.nodes) {
            for (const depId of node.dependencies) {
                if (!this.nodes.has(depId)) {
                    throw new Error(`Execution failure: Node '${id}' depends on missing node '${depId}'.`);
                }
                // Add edge: depId -> id
                adjList.get(depId)!.push(id);
                // Increment in-degree of the target node
                inDegree.set(id, inDegree.get(id)! + 1);
            }
        }

        // Find all nodes with an in-degree of 0 (starting roots)
        const queue: string[] = [];
        for (const [id, degree] of inDegree) {
            if (degree === 0) {
                queue.push(id);
            }
        }

        const sortedOrder: string[] = [];

        // Process queue (Kahn's Algorithm)
        while (queue.length > 0) {
            const currentId = queue.shift()!;
            sortedOrder.push(currentId);

            // Reduce in-degree for all neighboring nodes
            const neighbors = adjList.get(currentId)!;
            for (const neighborId of neighbors) {
                const currentDegree = inDegree.get(neighborId)!;
                inDegree.set(neighborId, currentDegree - 1);

                // If in-degree drops to zero, push to execution queue
                if (currentDegree - 1 === 0) {
                    queue.push(neighborId);
                }
            }
        }

        // Cycle detection check: if sorted order doesn't include all nodes, a cycle exists
        if (sortedOrder.length !== this.nodes.size) {
            throw new Error('Cyclic dependency detected in AI pipeline graph. Execution aborted.');
        }

        return sortedOrder;
    }

    /**
     * Executes the pipeline asynchronously, respecting dependencies and optimizing 
     * concurrent execution paths where possible.
     * 
     * @param initialContext Initial parameters passed into the pipeline (e.g., user prompt, user ID).
     * @returns A map containing the execution results of all nodes.
     */
    public async executePipeline(initialContext: PipelineContext): Promise<Map<string, any>> {
        const executionOrder = this.topologicalSort();
        const sharedContext: PipelineContext = { ...initialContext };

        console.log(`[WorkflowEngine] Topological execution order resolved: ${executionOrder.join(' -> ')}`);

        // Execute nodes sequentially or resolve concurrency based on readiness
        for (const nodeId of executionOrder) {
            const node = this.nodes.get(nodeId)!;
            
            // Verify all dependency outputs are present
            const depOutputs: PipelineContext = {};
            for (const depId of node.dependencies) {
                if (!this.outputs.has(depId)) {
                    throw new Error(`Dependency '${depId}' for node '${nodeId}' did not produce an output.`);
                }
                depOutputs[depId] = this.outputs.get(depId);
            }

            // Build node execution context
            const nodeContext = {
                ...sharedContext,
                dependencies: depOutputs
            };

            try {
                this.nodeStates.set(nodeId, 'RUNNING');
                console.log(`[WorkflowEngine] Starting execution of node: '${nodeId}'`);
                
                // Execute the asynchronous node function (non-blocking I/O)
                const result = await node.execute(nodeContext);
                
                this.outputs.set(nodeId, result);
                this.nodeStates.set(nodeId, 'COMPLETED');
                console.log(`[WorkflowEngine] Successfully completed node: '${nodeId}'`);
            } catch (error: any) {
                this.nodeStates.set(nodeId, 'FAILED');
                console.error(`[WorkflowEngine] Error executing node '${nodeId}':`, error.message);
                throw new Error(`Pipeline execution failed at node '${nodeId}': ${error.message}`);
            }
        }

        return this.outputs;
    }
}

// ==========================================
// USAGE EXAMPLE: SaaS Multi-Modal AI Pipeline
// ==========================================

async function runSaaSPipeline() {
    const engine = new AIWorkflowEngine();

    // Node 1: Prompt Expansion (LLM API Call simulation)
    engine.addNode({
        id: 'prompt_expansion',
        dependencies: [],
        execute: async (context) => {
            console.log(`[LLM Service] Expanding raw user prompt: "${context.rawPrompt}"`);
            await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate network I/O
            return { expandedPrompt: `${context.rawPrompt}, cinematic lighting, 8k resolution, highly detailed masterpiece` };
        }
    });

    // Node 2: Safety & Moderation Check (Async Microservice simulation)
    engine.addNode({
        id: 'safety_check',
        dependencies: [],
        execute: async (context) => {
            console.log(`[Safety Guardrail] Scanning prompt for policy violations...`);
            await new Promise((resolve) => setTimeout(resolve, 200)); // Simulate fast I/O
            return { safe: true, score: 0.99 };
        }
    });

    // Node 3: Diffusion Image Generation (Depends on Prompt Expansion and Safety Check)
    engine.addNode({
        id: 'image_generation',
        dependencies: ['prompt_expansion', 'safety_check'],
        execute: async (context) => {
            const prompt = context.dependencies.prompt_expansion.expandedPrompt;
            const isSafe = context.dependencies.safety_check.safe;

            if (!isSafe) {
                throw new Error('Content policy violation detected.');
            }

            console.log(`[Diffusion Engine] Generating image using prompt: "${prompt}"`);
            await new Promise((resolve) => setTimeout(resolve, 1200)); // Simulate GPU inference delay
            return { imageBuffer: Buffer.from('mock-binary-image-data'), format: 'png' };
        }
    });

    // Node 4: Cloud Storage Upload & CDN Distribution (Depends on Image Generation)
    engine.addNode({
        id: 'cdn_upload',
        dependencies: ['image_generation'],
        execute: async (context) => {
            const imageSize = context.dependencies.image_generation.imageBuffer.length;
            console.log(`[S3 Storage] Uploading generated image (${imageSize} bytes) to AWS S3 bucket...`);
            await new Promise((resolve) => setTimeout(resolve, 400)); // Simulate S3 upload
            return { url: 'https://cdn.saas-ai.com/generated/uuid-asset-12345.png' };
        }
    });

    // Execute the workflow with initial SaaS context
    try {
        const finalResults = await engine.executePipeline({
            rawPrompt: 'A futuristic cybernetic city at sunset',
            userId: 'usr_998124'
        });

        console.log('\n--- Pipeline Execution Completed Successfully ---');
        console.log('Final Asset URL:', finalResults.get('cdn_upload').url);
    } catch (error: any) {
        console.error('\n--- Pipeline Execution Failed ---');
        console.error(error.message);
    }
}

// Uncomment to run in standalone Node.js environment
// runSaaSPipeline();
