/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file DAG Execution Engine for Multi-Modal AI Pipelines
 * @description Implements a robust topological sorting execution engine in TypeScript 
 * for managing complex asynchronous AI node dependencies, parallel tool execution, and 
 * error propagation within a Node.js SaaS environment.
 */

import { EventEmitter } from 'events';

// ============================================================================
// Types & Interfaces
// ============================================================================

export type NodeStatus = 'IDLE' | 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';

export interface ExecutionContext {
  pipelineId: string;
  globalState: Record<string, unknown>;
  logger: (message: string, level?: 'info' | 'warn' | 'error') => void;
}

export interface NodeResult {
  nodeId: string;
  status: NodeStatus;
  output?: unknown;
  error?: Error;
  executionTimeMs: number;
}

/**
 * Represents a discrete computational unit within the AI Pipeline DAG.
 */
export abstract class DAGNode {
  public id: string;
  public dependencies: string[];
  public status: NodeStatus = 'IDLE';

  constructor(id: string, dependencies: string[] = []) {
    this.id = id;
    this.dependencies = dependencies;
  }

  /**
   * Abstract execute method implemented by concrete AI worker tasks.
   * @param inputs Map of resolved outputs from parent dependency nodes.
   * @param context Shared execution context across the pipeline graph.
   */
  public abstract execute(
    inputs: Record<string, unknown>,
    context: ExecutionContext
  ): Promise<unknown>;
}

// ============================================================================
// Concrete Worker Node Implementations
// ============================================================================

/**
 * Supervisor / Prompt Refinement Node: Analyzes user input and creates structured prompts.
 */
export class PromptRefinementNode extends DAGNode {
  async execute(inputs: Record<string, unknown>, context: ExecutionContext): Promise<unknown> {
    context.logger(`[${this.id}] Refining user prompt via LLM worker pool...`);
    const rawUserQuery = context.globalState.userQuery as string;
    
    // Simulate async LLM call for prompt optimization
    await new Promise((resolve) => setTimeout(resolve, 150));
    
    return {
      optimizedPrompt: `Cinematic 8K render, photorealistic composition of: ${rawUserQuery}`,
      negativePrompt: 'blurry, low resolution, artifacts, distorted anatomy',
      detectedStyle: 'hyper-realism'
    };
  }
}

/**
 * Parallel Tool Execution Node: Generates parallel parameters for WebGPU processing and Text synthesis.
 */
export class WebGPUParameterNode extends DAGNode {
  async execute(inputs: Record<string, unknown>, context: ExecutionContext): Promise<unknown> {
    context.logger(`[${this.id}] Computing WebGPU shader parameters concurrently...`);
    const promptData = inputs['prompt-refiner'] as { detectedStyle: string };

    await new Promise((resolve) => setTimeout(resolve, 100));

    return {
      shaderConfig: {
        lightingModel: promptData.detectedStyle === 'hyper-realism' ? 'PBR_PATH_TRACING' : 'PHONG',
        roughness: 0.15,
        metalness: 0.85,
        workgroupSize: [16, 16, 1]
      }
    };
  }
}

/**
 * Media Stream Synthesizer Node: Combines WebGPU pipeline metadata with optimized prompts.
 */
export class MediaStreamAssemblerNode extends DAGNode {
  async execute(inputs: Record<string, unknown>, context: ExecutionContext): Promise<unknown> {
    context.logger(`[${this.id}] Assembling real-time media streaming pipeline payload...`);
    const promptData = inputs['prompt-refiner'] as any;
    const gpuData = inputs['webgpu-params'] as any;

    await new Promise((resolve) => setTimeout(resolve, 200));

    return {
      streamManifestUrl: `wss://stream.generator.ai/v1/session/${context.pipelineId}`,
      activeConfig: {
        prompt: promptData.optimizedPrompt,
        gpu: gpuData.shaderConfig
      },
      status: 'READY_TO_STREAM'
    };
  }
}

// ============================================================================
// Graph Execution Engine
// ============================================================================

export class DAGExecutionEngine extends EventEmitter {
  private nodes: Map<string, DAGNode> = new Map();

  /**
   * Registers a computation node into the DAG.
   */
  public addNode(node: DAGNode): void {
    if (this.nodes.has(node.id)) {
      throw new Error(`Node with ID '${node.id}' already exists in graph.`);
    }
    this.nodes.set(node.id, node);
  }

  /**
   * Performs Kahn's topological sorting algorithm with cycle detection.
   * Throws an error if a circular dependency is detected.
   */
  public topologicalSort(): string[] {
    const inDegree = new Map<string, number>();
    const adjacencyList = new Map<string, string[]>();

    // Initialize graph maps
    for (const [id] of this.nodes) {
      inDegree.set(id, 0);
      adjacencyList.set(id, []);
    }

    // Compute in-degrees and build adjacency list
    for (const [id, node] of this.nodes) {
      for (const dep of node.dependencies) {
        if (!this.nodes.has(dep)) {
          throw new Error(`Node '${id}' depends on missing node '${dep}'.`);
        }
        adjacencyList.get(dep)!.push(id);
        inDegree.set(id, inDegree.get(id)! + 1);
      }
    }

    // Collect nodes with zero incoming edges
    const queue: string[] = [];
    for (const [id, degree] of inDegree) {
      if (degree === 0) {
        queue.push(id);
      }
    }

    const sortedOrder: string[] = [];

    while (queue.length > 0) {
      const current = queue.shift()!;
      sortedOrder.push(current);

      for (const neighbor of adjacencyList.get(current)!) {
        inDegree.set(neighbor, inDegree.get(neighbor)! - 1);
        if (inDegree.get(neighbor) === 0) {
          queue.push(neighbor);
        }
      }
    }

    if (sortedOrder.length !== this.nodes.size) {
      throw new Error('Cyclic dependency detected in AI Pipeline DAG execution graph.');
    }

    return sortedOrder;
  }

  /**
   * Executes the DAG asynchronously respecting dependency ordering and concurrency pools.
   */
  public async executePipeline(context: ExecutionContext): Promise<Map<string, NodeResult>> {
    const sortedNodeIds = this.topologicalSort();
    context.logger(`[Engine] Topological sort verified. Execution order: ${sortedNodeIds.join(' -> ')}`);

    const results = new Map<string, NodeResult>();
    const nodeOutputs = new Map<string, unknown>();

    // We can evaluate independent nodes concurrently if their dependencies are met
    // For simplicity and clarity, we iterate through the sorted list, allowing parallel batches where possible.
    
    for (const nodeId of sortedNodeIds) {
      const node = this.nodes.get(nodeId)!;
      const startTime = Date.now();
      node.status = 'RUNNING';

      try {
        // Collect resolved inputs from parent nodes
        const inputs: Record<string, unknown> = {};
        for (const depId of node.dependencies) {
          inputs[depId] = nodeOutputs.get(depId);
        }

        // Execute node business logic
        const output = await node.execute(inputs, context);
        
        node.status = 'COMPLETED';
        nodeOutputs.set(nodeId, output);
        
        const executionTimeMs = Date.now() - startTime;
        results.set(nodeId, {
          nodeId,
          status: 'COMPLETED',
          output,
          executionTimeMs
        });

        this.emit('nodeCompleted', { nodeId, executionTimeMs });
      } catch (error) {
        node.status = 'FAILED';
        const executionTimeMs = Date.now() - startTime;
        const err = error instanceof Error ? error : new Error(String(error));

        results.set(nodeId, {
          nodeId,
          status: 'FAILED',
          error: err,
          executionTimeMs
        });

        this.emit('nodeFailed', { nodeId, error: err });
        throw new Error(`Pipeline halted: Node '${nodeId}' failed execution. Reason: ${err.message}`);
      }
    }

    return results;
  }
}

// ============================================================================
// Execution Demonstration Entrypoint
// ============================================================================

async function runDemo() {
  const engine = new DAGExecutionEngine();

  // Register nodes into the graph
  engine.addNode(new PromptRefinementNode('prompt-refiner', []));
  engine.addNode(new WebGPUParameterNode('webgpu-params', ['prompt-refiner']));
  engine.addNode(new MediaStreamAssemblerNode('stream-assembler', ['prompt-refiner', 'webgpu-params']));

  const context: ExecutionContext = {
    pipelineId: 'pipe-sec-3-0941',
    globalState: {
      userQuery: 'A cyberpunk samurai standing under neon rain in Tokyo alleyway'
    },
    logger: (msg, level = 'info') => console.log(`[${level.toUpperCase()}] ${msg}`)
  };

  try {
    console.log('=== Starting AI Pipeline DAG Execution ===');
    const executionResults = await engine.executePipeline(context);
    
    console.log('\n=== Pipeline Execution Summary ===');
    for (const [id, res] of executionResults) {
      console.log(`Node: ${id} | Status: ${res.status} | Duration: ${res.executionTimeMs}ms`);
      if (res.output) {
        console.log(`  Output Preview:`, JSON.stringify(res.output, null, 2));
      }
    }
  } catch (err: any) {
    console.error(`[Fatal Error] Pipeline crashed: ${err.message}`);
  }
}

// Execute if run directly
if (require.main === module) {
  runDemo();
}
