/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface GraphNode<T = unknown> {
  id: string;
  dependencies: string[]; // IDs of nodes this node depends on
  data: T;
}

export class GraphCycleError extends Error {
  constructor(public cyclePath: string[]) {
    super(`Circular dependency detected in graph: ${cyclePath.join(' -> ')}`);
    this.name = 'GraphCycleError';
  }
}

/**
 * Computes a topological sort using Kahn's algorithm while detecting cycles,
 * and organizes nodes into parallel execution layers.
 */
export function topologicalSortWithLayers<T>(nodes: GraphNode<T>[]): { flatOrder: string[]; layers: string[][] } {
  const nodeMap = new Map<string, GraphNode<T>>();
  const inDegree = new Map<string, number>();
  const adjList = new Map<string, string[]>();

  // Initialize graph structures
  for (const node of nodes) {
    nodeMap.set(node.id, node);
    inDegree.set(node.id, 0);
    adjList.set(node.id, []);
  }

  // Build adjacency list and compute initial in-degrees
  for (const node of nodes) {
    for (const depId of node.dependencies) {
      if (!nodeMap.has(depId)) {
        throw new Error(`Node ${node.id} depends on non-existent node ${depId}`);
      }
      adjList.get(depId)!.push(node.id);
      inDegree.set(node.id, (inDegree.get(node.id) || 0) + 1);
    }
  }

  const layers: string[][] = [];
  let currentLayer: string[] = [];

  // Find all nodes with an in-degree of 0 (root nodes)
  for (const [id, degree] of inDegree.entries()) {
    if (degree === 0) {
      currentLayer.push(id);
    }
  }

  const flatOrder: string[] = [];
  const inDegreeCopy = new Map(inDegree);

  while (currentLayer.length > 0) {
    layers.push([...currentLayer]);
    const nextLayer: string[] = [];

    for (const u of currentLayer) {
      flatOrder.push(u);
      for (const v of adjList.get(u) || []) {
        const currentDegree = inDegreeCopy.get(v)! - 1;
        inDegreeCopy.set(v, currentDegree);
        if (currentDegree === 0) {
          nextLayer.push(v);
        }
      }
    }
    currentLayer = nextLayer;
  }

  // If we haven't visited all nodes, a cycle exists
  if (flatOrder.length !== nodes.length) {
    // Isolate nodes involved in the cycle for diagnostic error reporting
    const remainingNodes = nodes.filter(n => !flatOrder.includes(n.id)).map(n => n.id);
    throw new GraphCycleError(remainingNodes);
  }

  return { flatOrder, layers };
}

export function topologicalSort<T>(nodes: GraphNode<T>[]): string[] {
  return topologicalSortWithLayers(nodes).flatOrder;
}
