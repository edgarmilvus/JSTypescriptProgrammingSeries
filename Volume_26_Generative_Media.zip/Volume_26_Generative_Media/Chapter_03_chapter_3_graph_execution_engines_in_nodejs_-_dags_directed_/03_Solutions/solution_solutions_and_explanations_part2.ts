/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { GraphNode, topologicalSortWithLayers } from './exercise-1';

export type NodeExecutor = (nodeId: string, upstreamResults: Map<string, unknown>) => Promise<unknown>;

export interface ExecutionResult {
  success: boolean;
  results: Map<string, unknown>;
  errors: Map<string, Error>;
}

export class DagEngine {
  private nodes: Map<string, GraphNode> = new Map();

  constructor(nodes: GraphNode[]) {
    for (const node of nodes) {
      this.nodes.set(node.id, node);
    }
  }

  public async execute(executor: NodeExecutor, abortSignal?: AbortSignal): Promise<ExecutionResult> {
    const results = new Map<string, unknown>();
    const errors = new Map<string, Error>();
    
    // Validate structure and fetch layered execution plan
    const { layers } = topologicalSortWithLayers(Array.from(this.nodes.values()));

    for (const layer of layers) {
      if (abortSignal?.aborted) {
        throw new Error('Pipeline execution aborted.');
      }

      // Execute all nodes in the current tier concurrently
      const tierPromises = layer.map(async (nodeId) => {
        if (abortSignal?.aborted) return;

        const node = this.nodes.get(nodeId)!;
        
        // Gather required upstream dependencies
        const upstreamResults = new Map<string, unknown>();
        for (const depId of node.dependencies) {
          if (results.has(depId)) {
            upstreamResults.set(depId, results.get(depId));
          }
        }

        try {
          const output = await executor(nodeId, upstreamResults);
          results.set(nodeId, output);
        } catch (err: unknown) {
          const errorInstance = err instanceof Error ? err : new Error(String(err));
          errors.set(nodeId, errorInstance);
          throw errorInstance; // Fail fast for the tier
        }
      });

      await Promise.all(tierPromises);
    }

    return {
      success: errors.size === 0,
      results,
      errors,
    };
  }
}
