/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const PromptNodeConfigSchema = z.object({
  promptText: z.string().min(1, 'Prompt cannot be empty').max(2000),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().int().positive().optional(),
});

export const EmbeddingNodeConfigSchema = z.object({
  modelName: z.string(),
  dimensions: z.number().int().positive(),
});

export const WebGPUTransformNodeConfigSchema = z.object({
  shaderId: z.string(),
  batchSize: z.number().int().positive(),
});

export type ErrorHandlingStrategy = 'fail-fast' | 'fallback' | 'ignore';

export interface ValidatedGraphNode<TConfig = unknown> {
  id: string;
  dependencies: string[];
  configSchema: z.ZodType<TConfig>;
  config: TConfig;
  errorStrategy: ErrorHandlingStrategy;
  fallbackValue?: unknown;
}

export function validateNodeConfig<T>(node: ValidatedGraphNode<T>): T {
  const result = node.configSchema.safeParse(node.config);
  if (!result.success) {
    throw new Error(`Validation failed for node ${node.id}: ${result.error.message}`);
  }
  return result.data;
}

export async function executeNodeResiliently(
  node: ValidatedGraphNode,
  executor: (config: unknown) => Promise<unknown>
): Promise<{ success: boolean; output: unknown; error?: Error }> {
  try {
    const validConfig = validateNodeConfig(node);
    const output = await executor(validConfig);
    return { success: true, output };
  } catch (err: unknown) {
    const error = err instanceof Error ? err : new Error(String(err));
    
    if (node.errorStrategy === 'fail-fast') {
      throw error;
    } else if (node.errorStrategy === 'fallback') {
      return { success: true, output: node.fallbackValue };
    } else {
      // 'ignore' strategy
      return { success: false, output: null, error };
    }
  }
}
