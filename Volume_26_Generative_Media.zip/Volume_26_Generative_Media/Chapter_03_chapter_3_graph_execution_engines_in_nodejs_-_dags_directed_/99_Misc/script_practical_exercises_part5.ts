/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// Skeleton code for Exercise 4
import { z } from 'zod';

// Define runtime validation schemas
export const PromptNodeConfigSchema = z.object({
  promptText: z.string().min(1, 'Prompt cannot be empty').max(2000),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().int().positive().optional(),
});

export type PromptNodeConfig = z.infer<typeof PromptNodeConfigSchema>;

export type ErrorHandlingStrategy = 'fail-fast' | 'fallback' | 'ignore';

export interface ValidatedGraphNode<TConfig = unknown> {
  id: string;
  dependencies: string[];
  configSchema: z.ZodType<TConfig>;
  config: TConfig;
  errorStrategy: ErrorHandlingStrategy;
  fallbackValue?: unknown;
}

export function validateNodeConfig<T>(node: ValidatedGraphNode<T>): T {
  // TODO: Use Zod safeParse to validate node configuration at runtime
  throw new Error('Not implemented');
}
