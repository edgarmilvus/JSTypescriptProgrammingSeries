/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as Y from 'yjs';
import { Observable } from 'rxjs';

/**
 * Represents a single computational or UI node on the generative media canvas.
 */
interface CanvasNode {
    id: string;
    type: string;
    x: number;
    y: number;
    parameters: Record<string, any>;
}

/**
 * Represents the live positional metadata of a collaborator's cursor.
 */
interface CollaboratorCursor {
    userId: string;
    userName: string;
    x: number;
    y: number;
    lastUpdated: number;
}

/**
 * Mock WebSocket Transport layer to simulate network conditions and bi-directional sync.
 */
class MockWebSocketTransport extends Observable<Uint8Array> {
    private listeners: ((data: Uint8Array) => void)[] = [];
    public remotePeer: MockWebSocketTransport | null = null;

    constructor(public readonly clientId: string) {
        super((subscriber) => {
            this.listeners.push((data) => subscriber.next(data));
            return () => {
                this.listeners = this.listeners.filter(l => l !== subscriber.next);
            };
        });
    }

    /**
     * Sends binary update payloads across the mock network channel.
     */
    public send(data: Uint8Array): void {
        // Simulate minor network jitter
        setTimeout(() => {
            if (this.remotePeer) {
                this.remotePeer.receive(data);
            }
        }, 15);
    }

    private receive(data: Uint8Array): void {
        this.listeners.forEach(listener => listener(data));
    }

    public connect(peer: MockWebSocketTransport): void {
        this.remotePeer = peer;
        peer.remotePeer = this;
    }
}

/**
 * CollaborativeCanvasEngine manages the Yjs document lifecycle, node map states,
 * awareness protocol for cursors, and transactional updates over WebSockets.
 */
export class CollaborativeCanvasEngine {
    public ydoc: Y.Doc;
    private nodesMap: Y.Map<CanvasNode>;
    private awarenessMap: Y.Map<CollaboratorCursor>;
    private transport: MockWebSocketTransport;
    public localUserId: string;
    public localUserName: string;

    constructor(localUserId: string, localUserName: string, transport: MockWebSocketTransport) {
        this.localUserId = localUserId;
        this.localUserName = localUserName;
        this.transport = transport;

        // 1. Initialize the core Yjs document instance
        this.ydoc = new Y.Doc();

        // 2. Bind typed shared data structures to the document namespace
        this.nodesMap = this.ydoc.getMap<CanvasNode>('canvas-nodes');
        this.awarenessMap = this.ydoc.getMap<CollaboratorCursor>('canvas-awareness');

        // 3. Set up local-to-remote network synchronization
        this.initSync();
    }

    /**
     * Establishes event listeners for local document mutations and incoming network updates.
     */
    private initSync(): void {
        // Listen to local document changes and broadcast binary update diffs over the transport
        this.ydoc.on('update', (update: Uint8Array, origin: any) => {
            if (origin !== 'remote') {
                this.transport.send(update);
            }
        });

        // Listen to incoming binary updates from remote peers and apply them locally
        this.transport.subscribe((data: Uint8Array) => {
            Y.applyUpdate(this.ydoc, data, 'remote');
        });
    }

    /**
     * Adds or updates a node on the canvas transactionally.
     */
    public upsertNode(node: CanvasNode): void {
        this.ydoc.transact(() => {
            this.nodesMap.set(node.id, node);
        }, 'local-user');
    }

    /**
     * Removes a node from the shared graph state.
     */
    public removeNode(nodeId: string): void {
        this.ydoc.transact(() => {
            this.nodesMap.delete(nodeId);
        }, 'local-user');
    }

    /**
     * Updates the local user's cursor position in the shared awareness state.
     */
    public updateCursor(x: number, y: number): void {
        this.ydoc.transact(() => {
            this.awarenessMap.set(this.localUserId, {
                userId: this.localUserId,
                userName: this.localUserName,
                x,
                y,
                lastUpdated: Date.now()
            });
        }, 'local-cursor');
    }

    /**
     * Subscribes to node map changes for reactive rendering in the UI layer.
     */
    public observeNodes(callback: (nodes: Map<string, CanvasNode>) => void): void {
        this.nodesMap.observe(() => {
            const nodeMapSnapshot = new Map<string, CanvasNode>();
            this.nodesMap.forEach((node, id) => {
                nodeMapSnapshot.set(id, node);
            });
            callback(nodeMapSnapshot);
        });
    }

    /**
     * Subscribes to remote cursor movements for rendering collaborator avatars.
     */
    public observeAwareness(callback: (cursors: CollaboratorCursor[]) => void): void {
        this.awarenessMap.observe(() => {
            const cursors: CollaboratorCursor[] = [];
            this.awarenessMap.forEach((cursor) => {
                if (cursor.userId !== this.localUserId) {
                    cursors.push(cursor);
                }
            });
            callback(cursors);
        });
    }
}

// ==========================================
// EXAMPLE EXECUTION / TEST HARNESS
// ==========================================

// Create two simulated transport channels representing Client A and Client B
const clientATransport = new MockWebSocketTransport('client-a-id');
const clientBTransport = new MockWebSocketTransport('client-b-id');

// Connect them directly to simulate network peering
clientATransport.connect(clientBTransport);

// Instantiate Client A Engine
const clientA = new CollaborativeCanvasEngine('client-a-id', 'Alice', clientATransport);

// Instantiate Client B Engine
const clientB = new CollaborativeCanvasEngine('client-b-id', 'Bob', clientBTransport);

// Client B observes incoming changes from Alice
clientB.observeNodes((nodes) => {
    console.log('[Bob\'s View] Canvas nodes updated:', Array.from(nodes.values()));
});

clientB.observeAwareness((cursors) => {
    console.log('[Bob\'s View] Collaborator cursors updated:', cursors);
});

// Alice adds a WebGPU Processing Node to her canvas
console.log('Alice creates a WebGPU node...');
clientA.upsertNode({
    id: 'node-webgpu-1',
    type: 'WebGPUImageFilter',
    x: 120,
    y: 250,
    parameters: { kernel: 'gaussian-blur', intensity: 0.8 }
});

// Alice moves her cursor
clientA.updateCursor(135, 260);
