/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';

/**
 * Interface representing a generative node on the canvas graph.
 */
interface CanvasNode {
  id: string;
  type: string;
  x: number;
  y: number;
  parameters: Record<string, any>;
}

/**
 * Interface representing a remote user's cursor position and metadata.
 */
interface RemoteCursor {
  clientId: number;
  x: number;
  y: number;
  name: string;
  color: string;
}

export default function CollaborativeCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [nodes, setNodes] = useState<CanvasNode[]>([]);
  const [remoteCursors, setRemoteCursors] = useState<Map<number, RemoteCursor>>(new Map());
  
  // Yjs document and provider refs to persist across renders without triggering re-runs
  const ydocRef = useRef<Y.Doc | null>(null);
  const providerRef = useRef<WebsocketProvider | null>(null);
  const yNodesMapRef = useRef<Y.Map<CanvasNode> | null>(null);
  
  // Local tracking for mouse movement throttle
  const lastMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const animationFrameId = useRef<number | null>(null);

  /**
   * 1. Initialize Yjs document, WebMap structures, and WebSocket provider connection.
   */
  useEffect(() => {
    const ydoc = new Y.Doc();
    ydocRef.current = ydoc;

    // Connect to the collaborative signaling server
    const wsProvider = new WebsocketProvider(
      'wss://demos.yjs.dev', 
      'generative-media-canvas-room', 
      ydoc
    );
    providerRef.current = wsProvider;

    // Access or create a shared Y.Map for canvas nodes
    const yNodesMap = ydoc.getMap<CanvasNode>('canvas-nodes');
    yNodesMapRef.current = yNodesMap;

    // Bind awareness for remote cursor tracking
    wsProvider.awareness.setLocalStateField('user', {
      name: `User-${Math.floor(Math.random() * 1000)}`,
      color: `#${Math.floor(Math.random()*16777215).toString(16)}`,
    });

    // Observer for Yjs map changes to sync state back to React
    const handleNodeChange = () => {
      const newNodes: CanvasNode[] = [];
      yNodesMap.forEach((node) => {
        newNodes.push(node);
      });
      setNodes(newNodes);
    };

    yNodesMap.observe(handleNodeChange);

    // Observer for remote awareness changes (cursors)
    wsProvider.awareness.on('change', () => {
      const states = wsProvider.awareness.getStates();
      const cursors = new Map<number, RemoteCursor>();
      
      states.forEach((state, clientId) => {
        if (clientId !== ydoc.clientID && state.cursor) {
          cursors.set(clientId, {
            clientId,
            x: state.cursor.x,
            y: state.cursor.y,
            name: state.user?.name || 'Anonymous',
            color: state.user?.color || '#000000',
          });
        }
      });
      setRemoteCursors(cursors);
    });

    // Cleanup listeners and connections on unmount
    return () => {
      yNodesMap.unobserve(handleNodeChange);
      wsProvider.disconnect();
      ydoc.destroy();
    };
  }, []);

  /**
   * 2. High-performance render loop using requestAnimationFrame for smooth canvas painting.
   */
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear viewport
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid background for visual workflow orientation
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x < canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Render all collaborative nodes
    nodes.forEach((node) => {
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
      ctx.fillRect(node.x, node.y, 160, 100);
      ctx.strokeRect(node.x, node.y, 160, 100);

      ctx.fillStyle = '#1e293b';
      ctx.font = '12px sans-serif';
      ctx.fillText(`${node.type} (${node.id.slice(0, 4)})`, node.x + 12, node.y + 24);
    });

    // Render remote collaborator cursors
    remoteCursors.forEach((cursor) => {
      ctx.fillStyle = cursor.color;
      ctx.beginPath();
      ctx.arc(cursor.x, cursor.y, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.font = '10px sans-serif';
      ctx.fillText(cursor.name, cursor.x + 10, cursor.y + 4);
    });

    animationFrameId.current = requestAnimationFrame(renderCanvas);
  }, [nodes, remoteCursors]);

  useEffect(() => {
    animationFrameId.current = requestAnimationFrame(renderCanvas);
    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [renderCanvas]);

  /**
   * 3. Handle local mouse interactions to publish cursor movements and node placement.
   */
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    lastMousePos.current = { x, y };

    // Broadcast local cursor position via Yjs awareness
    if (providerRef.current) {
      providerRef.current.awareness.setLocalStateField('cursor', { x, y });
    }
  };

  /**
   * 4. Add a new generative node into the Yjs shared map (triggers CRDT broadcast).
   */
  const handleAddNode = () => {
    if (!yNodesMapRef.current) return;
    const id = crypto.randomUUID();
    const newNode: CanvasNode = {
      id,
      type: 'WebGPU-Shader',
      x: Math.random() * 400 + 50,
      y: Math.random() * 300 + 50,
      parameters: { intensity: 0.8, frequency: 440 },
    };

    // Mutate the Yjs map inside a transaction for atomic synchronization
    ydocRef.current?.transact(() => {
      yNodesMapRef.current?.set(id, newNode);
    });
  };

  return (
    <div className="flex flex-col items-center p-6 bg-slate-900 min-h-screen text-white">
      <div className="flex justify-between w-full max-w-5xl mb-4 items-center">
        <h1 className="text-xl font-bold">Generative Media Collaborative Canvas</h1>
        <button
          onClick={handleAddNode}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg font-medium transition-colors"
        >
          Add Node
        </button>
      </div>
      <div className="border border-slate-700 rounded-xl overflow-hidden shadow-2xl bg-slate-950">
        <canvas
          ref={canvasRef}
          width={1000}
          height={600}
          onMouseMove={handleMouseMove}
          className="cursor-crosshair"
        />
      </div>
    </div>
  );
}
