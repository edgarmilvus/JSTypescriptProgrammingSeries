/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';
import { z } from 'zod';

export interface CanvasPort {
  id: string;
  name: string;
  type: 'string' | 'number' | 'boolean' | 'media-stream' | 'tensor';
}

export interface CanvasNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  ports: {
    inputs: CanvasPort[];
    outputs: CanvasPort[];
  };
  parameters: Record<string, any>;
}

export interface CanvasEdge {
  id: string;
  sourceNodeId: string;
  sourcePortId: string;
  targetNodeId: string;
  targetPortId: string;
}

// Zod schema for runtime validation
const canvasPortSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(['string', 'number', 'boolean', 'media-stream', 'tensor']),
});

const canvasNodeSchema = z.object({
  id: z.string(),
  type: z.string(),
  position: z.object({
    x: z.number(),
    y: z.number(),
  }),
  ports: z.object({
    inputs: z.array(canvasPortSchema),
    outputs: z.array(canvasPortSchema),
  }),
  parameters: z.record(z.any()),
});

export function initializeGraphDoc(doc: Y.Doc): {
  nodesMap: Y.Map<Y.Map<any>>;
  edgesMap: Y.Map<Y.Map<any>>;
  metaMap: Y.Map<any>;
} {
  const nodesMap = doc.getMap<Y.Map<any>>('nodes');
  const edgesMap = doc.getMap<Y.Map<any>>('edges');
  const metaMap = doc.getMap<any>('meta');

  return { nodesMap, edgesMap, metaMap };
}

export function addNodeToYDoc(doc: Y.Doc, node: CanvasNode): void {
  // Validate runtime input using Zod before mutating shared state
  const validationResult = canvasNodeSchema.safeParse(node);
  if (!validationResult.success) {
    throw new Error(`Invalid node schema: ${validationResult.error.message}`);
  }

  const nodesMap = doc.getMap<Y.Map<any>>('nodes');

  doc.transact(() => {
    let nodeMap = nodesMap.get(node.id);
    if (!nodeMap) {
      nodeMap = new Y.Map<any>();
      nodesMap.set(node.id, nodeMap);
    }

    nodeMap.set('id', node.id);
    nodeMap.set('type', node.type);

    // Position sub-map
    let posMap = nodeMap.get('position') as Y.Map<number> | undefined;
    if (!posMap) {
      posMap = new Y.Map<number>();
      nodeMap.set('position', posMap);
    }
    posMap.set('x', node.position.x);
    posMap.set('y', node.position.y);

    // Ports structure (Y.Maps containing Y.Arrays)
    let portsMap = nodeMap.get('ports') as Y.Map<Y.Array<any>> | undefined;
    if (!portsMap) {
      portsMap = new Y.Map<Y.Array<any>>();
      nodeMap.set('ports', portsMap);
    }

    let inputArr = portsMap.get('inputs');
    if (!inputArr) {
      inputArr = new Y.Array<any>();
      portsMap.set('inputs', inputArr);
    } else {
      inputArr.delete(0, inputArr.length);
    }
    inputArr.insert(0, node.ports.inputs);

    let outputArr = portsMap.get('outputs');
    if (!outputArr) {
      outputArr = new Y.Array<any>();
      portsMap.set('outputs', outputArr);
    } else {
      outputArr.delete(0, outputArr.length);
    }
    outputArr.insert(0, node.ports.outputs);

    // Parameters sub-map
    let paramMap = nodeMap.get('parameters') as Y.Map<any> | undefined;
    if (!paramMap) {
      paramMap = new Y.Map<any>();
      nodeMap.set('parameters', paramMap);
    }
    for (const [key, value] of Object.entries(node.parameters)) {
      paramMap.set(key, value);
    }
  });
}

export function addEdgeToYDoc(doc: Y.Doc, edge: CanvasEdge): void {
  const edgesMap = doc.getMap<Y.Map<any>>('edges');

  doc.transact(() => {
    let edgeMap = edgesMap.get(edge.id);
    if (!edgeMap) {
      edgeMap = new Y.Map<any>();
      edgesMap.set(edge.id, edgeMap);
    }

    edgeMap.set('id', edge.id);
    edgeMap.set('sourceNodeId', edge.sourceNodeId);
    edgeMap.set('sourcePortId', edge.sourcePortId);
    edgeMap.set('targetNodeId', edge.targetNodeId);
    edgeMap.set('targetPortId', edge.targetPortId);
  });
}
