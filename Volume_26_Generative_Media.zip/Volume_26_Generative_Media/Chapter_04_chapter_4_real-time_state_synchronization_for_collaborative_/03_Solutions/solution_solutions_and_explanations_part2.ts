/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as Y from 'yjs';
import { Awareness, encodeAwarenessUpdate, applyAwarenessUpdate } from 'y-protocols/awareness';

export interface UserProfile {
  id: string;
  name: string;
  color: string;
}

export interface CollaborativeSyncOptions {
  url: string;
  doc: Y.Doc;
  user: UserProfile;
}

enum MessageType {
  YJS_SYNC = 0x01,
  AWARENESS = 0x02,
}

export class CollaborativeSyncManager {
  private doc: Y.Doc;
  private url: string;
  private user: UserProfile;
  private ws: WebSocket | null = null;
  public awareness: Awareness;
  private isConnecting: boolean = false;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 10;
  private offlineQueue: Array<Uint8Array | ArrayBuffer> = [];

  constructor(options: CollaborativeSyncOptions) {
    this.doc = options.doc;
    this.url = options.url;
    this.user = options.user;
    this.awareness = new Awareness(this.doc);
    
    this.awareness.setLocalState({
      user: this.user,
      cursor: null,
      selectedNodeIds: [],
    });

    // Listen to local document updates to transmit over WebSocket
    this.doc.on('update', (update: Uint8Array) => {
      this.sendBinaryMessage(MessageType.YJS_SYNC, update);
    });

    // Listen to local awareness updates to transmit over WebSocket
    this.awareness.on('update', ({ added, updated, removed }: { added: number[], updated: number[], removed: number[] }) => {
      const changedClients = [...added, ...updated, ...removed];
      const awarenessUpdate = encodeAwarenessUpdate(this.awareness, changedClients);
      this.sendBinaryMessage(MessageType.AWARENESS, awarenessUpdate);
    });
  }

  public connect(): void {
    if (this.ws || this.isConnecting) return;
    this.isConnecting = true;

    try {
      this.ws = new WebSocket(this.url);
      this.ws.binaryType = 'arraybuffer';

      this.ws.onopen = () => {
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        this.flushOfflineQueue();
      };

      this.ws.onmessage = (event: MessageEvent) => {
        this.handleMessage(event.data);
      };

      this.ws.onclose = () => {
        this.ws = null;
        this.isConnecting = false;
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        this.ws?.close();
      };
    } catch {
      this.isConnecting = false;
      this.scheduleReconnect();
    }
  }

  public disconnect(): void {
    this.maxReconnectAttempts = 0; // Prevent reconnection loops on manual disconnect
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  public updateLocalAwareness(state: { cursor: { x: number; y: number } | null; selectedNodeIds: string[] }): void {
    const currentState = this.awareness.getLocalState() || {};
    this.awareness.setLocalState({
      ...currentState,
      ...state,
    });
  }

  private sendBinaryMessage(type: MessageType, payload: Uint8Array): void {
    const prefixedMessage = new Uint8Array(1 + payload.length);
    prefixedMessage[0] = type;
    prefixedMessage.set(payload, 1);

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(prefixedMessage);
    } else {
      // Buffer updates if offline
      this.offlineQueue.push(prefixedMessage);
    }
  }

  private flushOfflineQueue(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    while (this.offlineQueue.length > 0) {
      const payload = this.offlineQueue.shift();
      if (payload) {
        this.ws.send(payload);
      }
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) return;
    
    const jitter = Math.random() * 200;
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts) + jitter, 30000);
    this.reconnectAttempts++;

    setTimeout(() => {
      this.connect();
    }, delay);
  }

  private handleMessage(data: ArrayBuffer): void {
    const view = new Uint8Array(data);
    const messageType = view[0];
    const payload = view.subarray(1);

    switch (messageType) {
      case MessageType.YJS_SYNC:
        Y.applyUpdate(this.doc, payload);
        break;
      case MessageType.AWARENESS:
        applyAwarenessUpdate(this.awareness, payload, 'websocket');
        break;
      default:
        console.warn(`Unknown message protocol header: ${messageType}`);
    }
  }
}
