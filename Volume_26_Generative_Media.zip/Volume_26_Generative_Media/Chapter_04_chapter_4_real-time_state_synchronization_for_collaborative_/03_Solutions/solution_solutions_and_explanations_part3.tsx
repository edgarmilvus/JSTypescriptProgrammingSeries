/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState, useRef, useCallback } from 'react';
import * as Y from 'yjs';
import { CollaborativeSyncManager } from './CollaborativeSyncManager';

export interface CollaborativeCanvasProps {
  doc: Y.Doc;
  syncManager: CollaborativeSyncManager;
  width: number;
  height: number;
}

export const CollaborativeCanvas: React.FC<CollaborativeCanvasProps> = ({
  doc,
  syncManager,
  width,
  height,
}) => {
  const [nodes, setNodes] = useState<Map<string, any>>(new Map());
  const [edges, setEdges] = useState<Map<string, any>>(new Map());
  const [remoteAwareness, setRemoteAwareness] = useState<Map<number, any>>(new Map());
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const dragOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Sync Yjs maps to React state
  useEffect(() => {
    const nodesMap = doc.getMap<Y.Map<any>>('nodes');
    const edgesMap = doc.getMap<Y.Map<any>>('edges');

    const updateNodes = () => {
      const newNodes = new Map<string, any>();
      nodesMap.forEach((nodeMap, id) => {
        newNodes.set(id, {
          id: nodeMap.get('id'),
          type: nodeMap.get('type'),
          position: Object.fromEntries(nodeMap.get('position')?.entries() || []),
          parameters: Object.fromEntries(nodeMap.get('parameters')?.entries() || []),
        });
      });
      setNodes(newNodes);
    };

    const updateEdges = () => {
      const newEdges = new Map<string, any>();
      edgesMap.forEach((edgeMap, id) => {
        newEdges.set(id, {
          id: edgeMap.get('id'),
          sourceNodeId: edgeMap.get('sourceNodeId'),
          targetNodeId: edgeMap.get('targetNodeId'),
        });
      });
      setEdges(newEdges);
    };

    updateNodes();
    updateEdges();

    nodesMap.observeDeep(updateNodes);
    edgesMap.observeDeep(updateEdges);

    return () => {
      nodesMap.unobserveDeep(updateNodes);
      edgesMap.unobserveDeep(updateEdges);
    };
  }, [doc]);

  // Sync Awareness states
  useEffect(() => {
    const awareness = syncManager.awareness;

    const handleAwarenessUpdate = () => {
      const states = new Map<number, any>();
      awareness.getStates().forEach((state, clientId) => {
        if (clientId !== awareness.doc.clientID) {
          states.set(clientId, state);
        }
      });
      setRemoteAwareness(states);
    };

    awareness.on('change', handleAwarenessUpdate);
    return () => {
      awareness.off('change', handleAwarenessUpdate);
    };
  }, [syncManager]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, e.clientX - rect.left);
    const y = Math.max(0, e.clientY - rect.top);

    // Update local cursor awareness
    syncManager.updateLocalAwareness({
      cursor: { x, y },
      selectedNodeIds: draggingNodeId ? [draggingNodeId] : [],
    });

    // Handle node dragging with boundary clipping (>= 0)
    if (draggingNodeId) {
      const nodesMap = doc.getMap<Y.Map<any>>('nodes');
      const nodeMap = nodesMap.get(draggingNodeId);
      if (nodeMap) {
        const posMap = nodeMap.get('position') as Y.Map<number>;
        if (posMap) {
          const newX = Math.max(0, x - dragOffsetRef.current.x);
          const newY = Math.max(0, y - dragOffsetRef.current.y);
          doc.transact(() => {
            posMap.set('x', newX);
            posMap.set('y', newY);
          });
        }
      }
    }
  }, [draggingNodeId, doc, syncManager]);

  const handleMouseDown = (nodeId: string, posX: number, posY: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setDraggingNodeId(nodeId);
    dragOffsetRef.current = { x: e.clientX - posX, y: e.clientY - posY };
  };

  const handleMouseUp = () => {
    setDraggingNodeId(null);
  };

  return (
    <div 
      className="collaborative-canvas-container"
      style={{ width, height, position: 'relative', overflow: 'hidden', background: '#111' }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Nodes and Edges Layer */}
      {Array.from(nodes.values()).map((node) => (
        <div
          key={node.id}
          onMouseDown={(e) => handleMouseDown(node.id, node.position.x, node.position.y, e)}
          style={{
            position: 'absolute',
            left: node.position.x,
            top: node.position.y,
            width: 150,
            height: 100,
            background: '#222',
            border: '1px solid #444',
            borderRadius: 8,
            color: '#fff',
            padding: 8,
            cursor: 'grab',
            userSelect: 'none',
          }}
        >
          <div><strong>{node.type}</strong></div>
          <div style={{ fontSize: 10, color: '#aaa' }}>ID: {node.id}</div>
        </div>
      ))}

      {/* Remote Cursors Overlay Layer */}
      <div className="remote-cursors-layer" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {Array.from(remoteAwareness.entries()).map(([clientId, state]) => {
          if (!state.cursor) return null;
          return (
            <div
              key={clientId}
              style={{
                position: 'absolute',
                left: state.cursor.x,
                top: state.cursor.y,
                transform: 'translate(-2px, -2px)',
                pointerEvents: 'none',
              }}
            >
              <div
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: '50%',
                  background: state.user?.color || '#ff0000',
                }}
              />
              <span
                style={{
                  marginLeft: 16,
                  padding: '2px 6px',
                  background: state.user?.color || '#ff0000',
                  color: '#fff',
                  fontSize: 10,
                  borderRadius: 4,
                  whiteSpace: 'nowrap',
                }}
              >
                {state.user?.name || 'Anonymous'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
