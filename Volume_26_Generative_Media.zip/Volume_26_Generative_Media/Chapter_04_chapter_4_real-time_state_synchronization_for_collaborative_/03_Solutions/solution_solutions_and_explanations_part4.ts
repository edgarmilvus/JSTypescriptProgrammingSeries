/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { useRef, useCallback, useEffect } from 'react';
import * as Y from 'yjs';

export interface ThrottledDispatcherOptions {
  fps?: number;
  adaptive?: boolean;
  getRTT?: () => number;
}

export function createThrottledStateDispatcher<T extends (...args: any[]) => void>(
  callback: T,
  options: ThrottledDispatcherOptions = { fps: 60, adaptive: false }
): {
  dispatch: (...args: Parameters<T>) => void;
  cancel: () => void;
} {
  let rafId: number | null = null;
  let latestArgs: Parameters<T> | null = null;
  let lastExecutionTime = 0;

  const dispatch = (...args: Parameters<T>) => {
    latestArgs = args;

    if (rafId !== null) return;

    const computeInterval = () => {
      let targetFps = options.fps || 60;
      if (options.adaptive && options.getRTT) {
        const rtt = options.getRTT();
        if (rtt > 150) {
          targetFps = 30; // Fallback to 30 FPS on high latency
        }
      }
      return 1000 / targetFps;
    };

    const loop = (timestamp: DOMHighResTimeStamp) => {
      const interval = computeInterval();
      if (timestamp - lastExecutionTime >= interval) {
        lastExecutionTime = timestamp;
        rafId = null;
        if (latestArgs) {
          callback(...latestArgs);
          latestArgs = null;
        }
      } else {
        rafId = requestAnimationFrame(loop);
      }
    };

    rafId = requestAnimationFrame(loop);
  };

  const cancel = () => {
    if (rafId !== null) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }
    latestArgs = null;
  };

  return { dispatch, cancel };
}

export interface UseThrottledNodePositionProps {
  doc: Y.Doc;
  nodeId: string;
  getRTT?: () => number;
}

export function useThrottledNodePosition({ doc, nodeId, getRTT }: UseThrottledNodePositionProps) {
  const nodeRef = useRef<HTMLDivElement>(null);

  const commitPositionToYjs = useCallback((x: number, y: number) => {
    const nodesMap = doc.getMap<Y.Map<any>>('nodes');
    const nodeMap = nodesMap.get(nodeId);
    if (nodeMap) {
      const posMap = nodeMap.get('position') as Y.Map<number>;
      if (posMap) {
        doc.transact(() => {
          posMap.set('x', x);
          posMap.set('y', y);
        });
      }
    }
  }, [doc, nodeId]);

  const { dispatch, cancel } = createThrottledStateDispatcher(commitPositionToYjs, {
    fps: 60,
    adaptive: true,
    getRTT,
  });

  useEffect(() => {
    return () => {
      cancel();
    };
  }, [cancel]);

  const updateLocalPositionDirectly = (x: number, y: number) => {
    if (nodeRef.current) {
      nodeRef.current.style.transform = `translate(${x}px, ${y}px)`;
    }
    dispatch(x, y);
  };

  return {
    nodeRef,
    updateLocalPositionDirectly,
  };
}
