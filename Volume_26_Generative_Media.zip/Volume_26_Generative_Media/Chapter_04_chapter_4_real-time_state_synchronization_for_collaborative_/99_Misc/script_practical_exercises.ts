/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import * as Y from 'yjs';

export interface CanvasPort {
  id: string;
  name: string;
  type: 'string' | 'number' | 'boolean' | 'media-stream' | 'tensor';
}

export interface CanvasNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  ports: {
    inputs: CanvasPort[];
    outputs: CanvasPort[];
  };
  parameters: Record<string, any>;
}

export interface CanvasEdge {
  id: string;
  sourceNodeId: string;
  sourcePortId: string;
  targetNodeId: string;
  targetPortId: string;
}

// TODO: Implement the following functions according to the requirements

export function initializeGraphDoc(doc: Y.Doc): {
  nodesMap: Y.Map<Y.Map<any>>;
  edgesMap: Y.Map<Y.Map<any>>;
  metaMap: Y.Map<any>;
} {
  // Implement initialization logic here
  throw new Error('Not implemented');
}

export function addNodeToYDoc(doc: Y.Doc, node: CanvasNode): void {
  // Implement nested Y.Map / Y.Array conversion and insertion logic here
  throw new Error('Not implemented');
}

export function addEdgeToYDoc(doc: Y.Doc, edge: CanvasEdge): void {
  // Implement edge insertion logic here
  throw new Error('Not implemented');
}
