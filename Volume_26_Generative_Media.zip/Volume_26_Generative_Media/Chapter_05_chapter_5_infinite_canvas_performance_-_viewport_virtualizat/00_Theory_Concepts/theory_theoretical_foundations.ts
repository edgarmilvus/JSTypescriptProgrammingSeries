/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", fontsize=10];

    Viewport [label="Viewport Bounds\n[minX, minY, maxX, maxY]", fillcolor="#e0f2fe"];
    SpatialIndex [label="Spatial Indexing\n(Quadtree / RBush)", fillcolor="#fef3c7"];
    Culling [label="O(log n) Viewport Culling\nFilter Invisible Nodes", fillcolor="#fee2e2"];
    Virtualization [label="DOM & WebGPU Virtualization\nOnly Mount/Process Visible Nodes", fillcolor="#dcfce7"];
    RenderLoop [label="60 FPS Render Loop\nZero Garbage Collection / GPU Pipeline", fillcolor="#f3e8ff"];

    Viewport -> SpatialIndex [label=" Query Bounds"];
    SpatialIndex -> Culling [label=" Return Candidate Set"];
    Culling -> Virtualization [label=" Diff Against Active Set"];
    Virtualization -> RenderLoop [label=" Paint & Compute Pass"];
}
