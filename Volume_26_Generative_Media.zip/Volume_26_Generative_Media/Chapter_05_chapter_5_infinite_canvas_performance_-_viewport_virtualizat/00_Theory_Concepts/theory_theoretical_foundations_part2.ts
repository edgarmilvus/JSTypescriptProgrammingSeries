/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];

    Root [label="Root Quad [0, 0, 2048, 2048]", fillcolor="#e0f2fe"];
    NW [label="NW Quadrant\n(Capacity Exceeded)", fillcolor="#fef3c7"];
    NE [label="NE Quadrant\n(Empty / Sparse)", fillcolor="#fef3c7"];
    SW [label="SW Quadrant\n(Sparse)", fillcolor="#fef3c7"];
    SE [label="SE Quadrant\n(Dense Generative Nodes)", fillcolor="#fef3c7"];

    NW_NW [label="Sub-Quad NW-NW", fillcolor="#dcfce7"];
    NW_NE [label="Sub-Quad NW-NE", fillcolor="#dcfce7"];
    NW_SW [label="Sub-Quad NW-SW", fillcolor="#dcfce7"];
    NW_SE [label="Sub-Quad NW-SE", fillcolor="#dcfce7"];

    Root -> NW;
    Root -> NE;
    Root -> SW;
    Root -> SE;

    NW -> NW_NW;
    NW -> NW_NE;
    NW -> NW_SW;
    NW -> NW_SE;
}
