/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];

    FrameStart [label="RequestAnimationFrame (60 FPS)", fillcolor="#e0f2fe"];
    ViewportCalc [label="Calculate Current Viewport Matrix", fillcolor="#fef3c7"];
    SpatialSearch [label="Query RBush Spatial Index", fillcolor="#fee2e2"];
    DiffSets [label="Compute Diff: Active vs Previous Frame", fillcolor="#dcfce7"];
    
    SubCheck1 [label="Nodes Entered Viewport?", shape=diamond, fillcolor="#f3e8ff"];
    BindResources [label="Bind WebGPU Pipelines & Allocate Textures", fillcolor="#e0f2fe"];

    SubCheck2 [label="Nodes Left Viewport?", shape=diamond, fillcolor="#f3e8ff"];
    ReleaseResources [label="Suspend Compute Shaders & Recycle Buffers", fillcolor="#fee2e2"];

    RenderPass [label="Execute WebGPU Render & Compute Passes\n(Only for Visible Generative Nodes)", fillcolor="#dcfce7"];

    FrameStart -> ViewportCalc;
    ViewportCalc -> SpatialSearch;
    SpatialSearch -> DiffSets;
    DiffSets -> SubCheck1;
    SubCheck1 -> BindResources [label="Yes"];
    SubCheck1 -> SubCheck2 [label="No"];
    BindResources -> SubCheck2;
    SubCheck2 -> ReleaseResources [label="Yes"];
    SubCheck2 -> RenderPass [label="No"];
    ReleaseResources -> RenderPass;
}
