/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Interface representing a 2D bounding box or point payload within the canvas.
 */
interface CanvasNode {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'media-stream' | 'ai-generator' | 'transformer';
}

/**
 * Axis-Aligned Bounding Box (AABB) used for spatial partitioning and viewport culling.
 */
class Rectangle {
  constructor(
    public x: number,      // Top-left X coordinate
    public y: number,      // Top-left Y coordinate
    public width: number,  // Width of the box
    public height: number  // Height of the box
  ) {}

  /**
   * Determines if this bounding box intersects with another bounding box.
   */
  intersects(range: Rectangle): boolean {
    return !(
      range.x > this.x + this.width ||
      range.x + range.width < this.x ||
      range.y > this.y + this.height ||
      range.y + range.height < this.y
    );
  }

  /**
   * Determines if a point (x, y) is fully contained within this bounding box.
   */
  contains(node: CanvasNode): boolean {
    return (
      node.x >= this.x &&
      node.x <= this.x + this.width &&
      node.y >= this.y &&
      node.y <= this.y + this.height
    );
  }
}

/**
 * Quadtree spatial index optimized for real-time generative media node workflows.
 */
class Quadtree {
  private nodes: CanvasNode[] = [];
  private divided: boolean = false;
  private northeast!: Quadtree;
  private northwest!: Quadtree;
  private southeast!: Quadtree;
  private southwest!: Quadtree;

  /**
   * @param boundary The 2D spatial boundary this quadtree node governs.
   * @param capacity The maximum number of nodes allowed before subdivision occurs.
   */
  constructor(public boundary: Rectangle, public capacity: number = 4) {}

  /**
   * Subdivides the current quadtree node into four quadrants (NE, NW, SE, SW).
   */
  private subdivide(): void {
    const x = this.boundary.x;
    const y = this.boundary.y;
    const w = this.boundary.width / 2;
    const h = this.boundary.height / 2;

    this.northeast = new Quadtree(new Rectangle(x + w, y, w, h), this.capacity);
    this.northwest = new Quadtree(new Rectangle(x, y, w, h), this.capacity);
    this.southeast = new Quadtree(new Rectangle(x + w, y + h, w, h), this.capacity);
    this.southwest = new Quadtree(new Rectangle(x, y + h, w, h), this.capacity);

    this.divided = true;
  }

  /**
   * Inserts a canvas node into the quadtree spatial index.
   */
  insert(node: CanvasNode): boolean {
    // If the node does not fall within this boundary, reject insertion
    if (!this.boundary.contains(node)) {
      return false;
    }

    // If there is space and we haven't subdivided, push to local storage array
    if (this.nodes.length < this.capacity && !this.divided) {
      this.nodes.push(node);
      return true;
    }

    // If capacity is reached, subdivide if not already done
    if (!this.divided) {
      this.subdivide();
    }

    // Attempt insertion into the appropriate child quadrants
    if (this.northeast.insert(node)) return true;
    if (this.northwest.insert(node)) return true;
    if (this.southeast.insert(node)) return true;
    if (this.southwest.insert(node)) return true;

    return false;
  }

  /**
   * Queries the quadtree for all canvas nodes intersecting the current viewport.
   * @param range The viewport bounding box.
   * @param found Accumulator array for matching nodes.
   */
  query(range: Rectangle, found: CanvasNode[] = []): CanvasNode[] {
    // If the viewport range does not intersect this boundary, abort search
    if (!this.boundary.intersects(range)) {
      return found;
    }

    // Check nodes at this level
    for (const node of this.nodes) {
      // Create a bounding box representation for the canvas node for accurate intersection check
      const nodeBox = new Rectangle(node.x, node.y, node.width, node.height);
      if (range.intersects(nodeBox)) {
        found.push(node);
      }
    }

    // Recursively query child quadrants if they exist
    if (this.divided) {
      this.northeast.query(range, found);
      this.northwest.query(range, found);
      this.southeast.query(range, found);
      this.southwest.query(range, found);
    }

    return found;
  }
}

// --- SaaS Execution Context Example ---

// 1. Initialize the root canvas boundary (e.g., a massive 10,000x10,000 pixel virtual workspace)
const canvasBoundary = new Rectangle(0, 0, 10000, 10000);
const spatialIndex = new Quadtree(canvasBoundary, 8);

// 2. Populate the spatial index with generative media nodes from our workflow engine state
const sampleNodes: CanvasNode[] = [
  { id: 'node-ai-gen-1', x: 250, y: 300, width: 240, height: 160, type: 'ai-generator' },
  { id: 'node-stream-2', x: 1200, y: 450, width: 320, height: 200, type: 'media-stream' },
  { id: 'node-transform-3', x: 4500, y: 5000, width: 280, height: 180, type: 'transformer' },
];

sampleNodes.forEach(node => spatialIndex.insert(node));

// 3. Define the current viewport derived from camera pan and zoom matrix transformations
const userViewport = new Rectangle(100, 150, 1920, 1080);

// 4. Query the spatial index to isolate only visible nodes for the WebGPU render loop
const visibleNodes = spatialIndex.query(userViewport);

console.log(`[ViewEngine] Total canvas nodes: ${sampleNodes.length}`);
console.log(`[ViewEngine] Visible nodes culled for WebGPU paint: ${visibleNodes.length}`);
visibleNodes.forEach(vn => console.log(` - Rendering Node: ${vn.id} (${vn.type}) at [${vn.x}, ${vn.y}]`));
