/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useEffect, useRef, useState, useCallback } from 'react';
import RBush from 'rbush';

/**
 * Interface representing a node within the generative media canvas.
 * Implements RBush's SpatialIndex interface via minX, minY, maxX, maxY.
 */
interface GenerativeNode {
  id: string;
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  type: 'webgpu-shader' | 'media-stream' | 'llm-prompt';
  data: {
    label: string;
    status: 'idle' | 'processing' | 'streaming';
    computePayload?: Float32Array;
  };
}

/**
 * Viewport configuration for culling calculations.
 */
interface Viewport {
  x: number;
  y: number;
  width: number;
  height: number;
  zoom: number;
}

export function GenerativeInfiniteCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const spatialIndexRef = useRef<RBush<GenerativeNode>>(new RBush<GenerativeNode>());
  
  // Viewport state tracking pan (x, y) and zoom level
  const [viewport, setViewport] = useState<Viewport>({
    x: 0,
    y: 0,
    width: typeof window !== 'undefined' ? window.innerWidth : 1920,
    height: typeof window !== 'undefined' ? window.innerHeight : 1080,
    zoom: 1,
  });

  const [visibleNodes, setVisibleNodes] = useState<GenerativeNode[]>([]);
  const animationFrameId = useRef<number | null>(null);

  /**
   * 1. Initialize Spatial Index with 10,000 mock generative nodes.
   */
  useEffect(() => {
    const tree = spatialIndexRef.current;
    const nodes: GenerativeNode[] = [];

    for (let i = 0; i < 10000; i++) {
      const x = (Math.random() - 0.5) * 20000;
      const y = (Math.random() - 0.5) * 20000;
      const width = 280;
      const height = 160;

      nodes.push({
        id: `node-${i}`,
        minX: x,
        minY: y,
        maxX: x + width,
        maxY: y + height,
        type: i % 3 === 0 ? 'webgpu-shader' : i % 3 === 1 ? 'media-stream' : 'llm-prompt',
        data: {
          label: `Generative Engine #${i}`,
          status: 'idle',
        },
      });
    }

    // Bulk load nodes into RBush for O(log n) spatial querying efficiency
    tree.load(nodes);
  }, []);

  /**
   * 2. Calculate current viewport bounding box in world coordinates.
   */
  const getCullingBBox = useCallback((vp: Viewport) => {
    const worldMinX = -vp.x / vp.zoom;
    const worldMinY = -vp.y / vp.zoom;
    const worldMaxX = worldMinX + vp.width / vp.zoom;
    const worldMaxY = worldMinY + vp.height / vp.zoom;

    return {
      minX: worldMinX,
      minY: worldMinY,
      maxX: worldMaxX,
      maxY: worldMaxY,
    };
  }, []);

  /**
   * 3. High-performance render and culling loop executed via requestAnimationFrame.
   */
  const runRenderPipeline = useCallback(() => {
    const tree = spatialIndexRef.current;
    const bbox = getCullingBBox(viewport);

    // Query RBush spatial index for nodes intersecting the current viewport bbox
    const results = tree.search(bbox);
    setVisibleNodes(results);

    // Placeholder: Execute WebGPU kernel pipeline for visible webgpu-shader nodes
    results.forEach((node) => {
      if (node.type === 'webgpu-shader') {
        // Trigger WebGPU uniform buffer updates only for visible elements
      }
    });

    animationFrameId.current = requestAnimationFrame(runRenderPipeline);
  }, [viewport, getCullingBBox]);

  useEffect(() => {
    animationFrameId.current = requestAnimationFrame(runRenderPipeline);
    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [runRenderPipeline]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-zinc-950 text-white">
      {/* HUD overlay displaying virtualization stats */}
      <div className="absolute top-4 left-4 z-50 p-4 bg-zinc-9/80 backdrop-blur border border-zinc-800 rounded-lg shadow-xl font-mono text-xs">
        <h1 className="text-sm font-bold text-emerald-400 mb-1">WebGPU Canvas Engine</h1>
        <p>Visible Nodes: {visibleNodes.length} / 10,000</p>
        <p>Zoom Level: {viewport.zoom.toFixed(2)}x</p>
        <p>Viewport X/Y: {viewport.x.toFixed(0)}, {viewport.y.toFixed(0)}</p>
      </div>

      {/* Infinite Canvas Rendering Surface */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"
        onWheel={(e) => {
          setViewport((prev) => ({
            ...prev,
            zoom: Math.max(0.1, Math.min(5, prev.zoom - e.deltaY * 0.001)),
          }));
        }}
        onMouseMove={(e) => {
          if (e.buttons === 1) {
            setViewport((prev) => ({
              ...prev,
              x: prev.x + e.movementX,
              y: prev.y + e.movementY,
            }));
          }
        }}
      />

      {/* Virtualized DOM Node Layers */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`,
          transformOrigin: '0 0',
        }}
      >
        {visibleNodes.map((node) => (
          <div
            key={node.id}
            className="absolute p-4 bg-zinc-900 border border-zinc-700 rounded-lg shadow-2xl pointer-events-auto"
            style={{
              left: `${node.minX}px`,
              top: `${node.minY}px`,
              width: `${node.maxX - node.minX}px`,
              height: `${node.maxY - node.minY}px`,
            }}
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-semibold text-zinc-400">{node.type}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <h2 className="text-sm font-bold text-zinc-100">{node.data.label}</h2>
          </div>
        ))}
      </div>
    </div>
  );
}

export default GenerativeInfiniteCanvas;
