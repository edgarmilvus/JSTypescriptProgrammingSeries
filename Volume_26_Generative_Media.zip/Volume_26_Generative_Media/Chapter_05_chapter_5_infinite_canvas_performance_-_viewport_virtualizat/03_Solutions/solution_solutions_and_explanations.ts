/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import RBush from 'rbush';

export interface CanvasNodeBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  id: string;
  nodeType: 'media-stream' | 'webgpu-shader' | 'ai-prompt';
}

export class CanvasSpatialIndex {
  private tree: RBush<CanvasNodeBounds>;
  private nodeMap: Map<string, CanvasNodeBounds>;

  constructor() {
    this.tree = new RBush<CanvasNodeBounds>();
    this.nodeMap = new Map<string, CanvasNodeBounds>();
  }

  public insertNode(node: CanvasNodeBounds): void {
    if (this.nodeMap.has(node.id)) {
      this.removeNode(node.id);
    }
    this.tree.insert(node);
    this.nodeMap.set(node.id, node);
  }

  public removeNode(id: string): void {
    const node = this.nodeMap.get(id);
    if (node) {
      this.tree.remove(node, (a, b) => a.id === b.id);
      this.nodeMap.delete(id);
    }
  }

  public updateNodePosition(
    id: string, 
    newBounds: Omit<CanvasNodeBounds, 'id' | 'nodeType'>
  ): void {
    const existing = this.nodeMap.get(id);
    if (!existing) return;

    const updatedNode: CanvasNodeBounds = {
      ...existing,
      ...newBounds,
    };

    this.tree.remove(existing, (a, b) => a.id === b.id);
    this.tree.insert(updatedNode);
    this.nodeMap.set(id, updatedNode);
  }

  public queryViewport(
    viewport: { minX: number; minY: number; maxX: number; maxY: number },
    zoom: number = 1.0
  ): CanvasNodeBounds[] {
    const results = this.tree.search(viewport);

    // Interactive Challenge: LOD culling tier based on zoom scale
    if (zoom < 0.5) {
      return results.filter(node => node.nodeType !== 'webgpu-shader');
    }

    return results;
  }
}

/**
 * Utility function to convert camera matrix (pan, zoom) into world-space bounds.
 */
export function cameraToViewportBounds(
  panX: number,
  panY: number,
  zoom: number,
  screenWidth: number,
  screenHeight: number
): { minX: number; minY: number; maxX: number; maxY: number } {
  return {
    minX: -panX / zoom,
    minY: -panY / zoom,
    maxX: (screenWidth - panX) / zoom,
    maxY: (screenHeight - panY) / zoom,
  };
}
