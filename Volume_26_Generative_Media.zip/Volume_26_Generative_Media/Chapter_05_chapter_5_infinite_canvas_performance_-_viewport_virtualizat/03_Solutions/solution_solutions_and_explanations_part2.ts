/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface Point2D {
  x: number;
  y: number;
  id: string;
}

export interface RectangleBoundary {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class QuadtreeNode<T extends Point2D> {
  private boundary: RectangleBoundary;
  private capacity: number;
  private items: T[] = [];
  private divided: boolean = false;

  private northwest!: QuadtreeNode<T>;
  private northeast!: QuadtreeNode<T>;
  private southwest!: QuadtreeNode<T>;
  private southeast!: QuadtreeNode<T>;

  constructor(boundary: RectangleBoundary, capacity: number) {
    this.boundary = boundary;
    this.capacity = capacity;
  }

  public insert(item: T): boolean {
    if (!this.contains(this.boundary, item)) {
      return false;
    }

    if (this.items.length < this.capacity && !this.divided) {
      this.items.push(item);
      return true;
    }

    if (!this.divided) {
      this.subdivide();
    }

    return (
      this.northwest.insert(item) ||
      this.northeast.insert(item) ||
      this.southwest.insert(item) ||
      this.southeast.insert(item)
    );
  }

  private subdivide(): void {
    const { x, y, width, height } = this.boundary;
    const w = width / 2;
    const h = height / 2;

    this.northwest = new QuadtreeNode({ x, y, width: w, height: h }, this.capacity);
    this.northeast = new QuadtreeNode({ x: x + w, y, width: w, height: h }, this.capacity);
    this.southwest = new QuadtreeNode({ x, y: y + h, width: w, height: h }, this.capacity);
    this.southeast = new QuadtreeNode({ x: x + w, y: y + h, width: w, height: h }, this.capacity);

    this.divided = true;

    for (const item of this.items) {
      this.northwest.insert(item) ||
        this.northeast.insert(item) ||
        this.southwest.insert(item) ||
        this.southeast.insert(item);
    }
    this.items = [];
  }

  public query(range: RectangleBoundary, found: T[] = []): T[] {
    if (!this.intersects(this.boundary, range)) {
      return found;
    }

    for (const item of this.items) {
      if (this.contains(range, item)) {
        found.push(item);
      }
    }

    if (this.divided) {
      this.northwest.query(range, found);
      this.northeast.query(range, found);
      this.southwest.query(range, found);
      this.southeast.query(range, found);
    }

    return found;
  }

  public findNearestNeighbors(
    target: Point2D, 
    maxResults: number, 
    maxRadius: number, 
    found: { item: T; distSq: number }[] = []
  ): T[] {
    const range: RectangleBoundary = {
      x: target.x - maxRadius,
      y: target.y - maxRadius,
      width: maxRadius * 2,
      height: maxRadius * 2,
    };

    if (!this.intersects(this.boundary, range)) {
      return [];
    }

    for (const item of this.items) {
      const dx = item.x - target.x;
      const dy = item.y - target.y;
      const distSq = dx * dx + dy * dy;
      if (distSq <= maxRadius * maxRadius) {
        found.push({ item, distSq });
      }
    }

    if (this.divided) {
      this.northwest.findNearestNeighbors(target, maxResults, maxRadius, found);
      this.northeast.findNearestNeighbors(target, maxResults, maxRadius, found);
      this.southwest.findNearestNeighbors(target, maxResults, maxRadius, found);
      this.southeast.findNearestNeighbors(target, maxResults, maxRadius, found);
    }

    found.sort((a, b) => a.distSq - b.distSq);
    return found.slice(0, maxResults).map(f => f.item);
  }

  private contains(rect: RectangleBoundary, point: { x: number; y: number }): boolean {
    return (
      point.x >= rect.x &&
      point.x <= rect.x + rect.width &&
      point.y >= rect.y &&
      point.y <= rect.y + rect.height
    );
  }

  private intersects(rect1: RectangleBoundary, rect2: RectangleBoundary): boolean {
    return !(
      rect2.x > rect1.x + rect1.width ||
      rect2.x + rect2.width < rect1.x ||
      rect2.y > rect1.y + rect1.height ||
      rect2.y + rect2.height < rect1.y
    );
  }
}
