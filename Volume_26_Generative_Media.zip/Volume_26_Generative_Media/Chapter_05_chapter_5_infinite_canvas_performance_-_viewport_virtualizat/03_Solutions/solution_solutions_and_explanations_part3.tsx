/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CanvasSpatialIndex, CanvasNodeBounds } from './CanvasSpatialIndex';

export interface VirtualCanvasProps {
  nodes: Array<{
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
    nodeType: 'media-stream' | 'webgpu-shader' | 'ai-prompt';
    data: any;
  }>;
  width: number;
  height: number;
  renderNode: (node: any) => React.ReactNode;
}

export const VirtualCanvas: React.FC<VirtualCanvasProps> = ({
  nodes,
  width,
  height,
  renderNode,
}) => {
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [visibleNodes, setVisibleNodes] = useState<CanvasNodeBounds[]>([]);
  
  const spatialIndexRef = useRef<CanvasSpatialIndex>(new CanvasSpatialIndex());
  const domPoolRef = useRef<Map<string, HTMLDivElement>>(new Map());

  // Sync incoming nodes into the spatial index ref
  useEffect(() => {
    const index = spatialIndexRef.current;
    nodes.forEach(node => {
      index.insertNode({
        id: node.id,
        minX: node.x,
        minY: node.y,
        maxX: node.x + node.width,
        maxY: node.y + node.height,
        nodeType: node.nodeType,
      });
    });
  }, [nodes]);

  // Viewport calculation and active node filtering
  useEffect(() => {
    const minX = -pan.x / zoom;
    const minY = -pan.y / zoom;
    const maxX = (width - pan.x) / zoom;
    const maxY = (height - pan.y) / zoom;

    const results = spatialIndexRef.current.queryViewport({ minX, minY, maxX, maxY }, zoom);
    setVisibleNodes(results);
  }, [pan, zoom, width, height]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    
    setZoom(prevZoom => {
      const newZoom = Math.max(0.1, Math.min(5, prevZoom * zoomFactor));
      // Zoom-to-pointer pan calculation
      const rect = e.currentTarget.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      setPan(prevPan => ({
        x: mouseX - (mouseX - prevPan.x) * (newZoom / prevZoom),
        y: mouseY - (mouseY - prevPan.y) * (newZoom / prevZoom),
      }));

      return newZoom;
    });
  }, []);

  // DOM Recycling pool lookup for visible items
  const activeNodeMap = useRef(new Map(nodes.map(n => [n.id, n])));
  useEffect(() => {
    activeNodeMap.current = new Map(nodes.map(n => [n.id, n]));
  }, [nodes]);

  return (
    <div 
      className="virtual-canvas-container"
      style={{ width, height, overflow: 'hidden', position: 'relative' }}
      onWheel={handleWheel}
    >
      <div 
        className="canvas-transform-layer"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
          position: 'absolute',
          inset: 0,
        }}
      >
        {visibleNodes.map(bounds => {
          const nodeData = activeNodeMap.current.get(bounds.id);
          if (!nodeData) return null;

          return (
            <div
              key={bounds.id}
              style={{
                position: 'absolute',
                left: nodeData.x,
                top: nodeData.y,
                width: nodeData.width,
                height: nodeData.height,
              }}
            >
              {renderNode(nodeData)}
            </div>
          );
        })}
      </div>
    </div>
  );
};
