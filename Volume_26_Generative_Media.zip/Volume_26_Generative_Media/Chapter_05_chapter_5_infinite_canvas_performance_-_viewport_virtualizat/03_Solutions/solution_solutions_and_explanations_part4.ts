/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { CanvasSpatialIndex, CanvasNodeBounds } from './CanvasSpatialIndex';

export interface ViewportBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export class WebGPURenderPipeline {
  private device!: GPUDevice;
  private context!: GPUCanvasContext;
  private computePipeline!: GPUComputePipeline;
  private uniformBuffer!: GPUBuffer;
  private consecutiveSlowFrames: number = 0;
  private qualityTier: 'high' | 'low' = 'high';

  public async initialize(canvas: HTMLCanvasElement): Promise<void> {
    if (!navigator.gpu) {
      throw new Error("WebGPU not supported on this browser.");
    }
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) throw new Error("Failed to secure WebGPU adapter.");

    this.device = await adapter.requestDevice();
    const ctx = canvas.getContext('webgpu');
    if (!ctx) throw new Error("Failed to acquire WebGPU canvas context.");

    this.context = ctx;
    this.context.configure({
      device: this.device,
      format: navigator.gpu.getPreferredCanvasFormat(),
      alphaMode: 'premultiplied',
    });
  }

  public async loadShaders(): Promise<void> {
    const computeShaderCode = `
      struct NodeTransform {
        posX: f32,
        posY: f32,
        scaleX: f32,
        scaleY: f32,
      };

      @group(0) @binding(0) var<storage, read_write> nodes: array<NodeTransform>;

      @compute @workgroup_size(64)
      fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
        let index = global_id.x;
        if (index >= arrayLength(&nodes)) {
          return;
        }
        // Apply parallel compute transformation matrix adjustments
        nodes[index].posX = nodes[index].posX + 0.0;
      }
    `;

    const shaderModule = this.device.createShaderModule({ code: computeShaderCode });
    this.computePipeline = await this.device.createComputePipelineAsync({
      layout: 'auto',
      compute: {
        module: shaderModule,
        entryPoint: 'main',
      },
    });

    this.uniformBuffer = this.device.createBuffer({
      size: 1024 * 16,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
    });
  }

  public renderFrame(spatialIndex: CanvasSpatialIndex, viewport: ViewportBounds): void {
    const startTime = performance.now();

    // 1. Query spatial index for visible nodes
    const visibleNodes = spatialIndex.queryViewport(viewport);

    // 2. Map visible nodes data to GPU storage buffer
    const rawData = new Float32Array(visibleNodes.length * 4);
    visibleNodes.forEach((node, i) => {
      rawData[i * 4 + 0] = node.minX;
      rawData[i * 4 + 1] = node.minY;
      rawData[i * 4 + 2] = node.maxX - node.minX;
      rawData[i * 4 + 3] = node.maxY - node.minY;
    });

    this.device.queue.writeBuffer(this.uniformBuffer, 0, rawData);

    // 3. Begin command encoder and dispatch compute pass
    const commandEncoder = this.device.createCommandEncoder();
    const passEncoder = commandEncoder.beginComputePass();
    passEncoder.setPipeline(this.computePipeline);

    const bindGroup = this.device.createBindGroup({
      layout: this.computePipeline.getBindGroupLayout(0),
      entries: [{ binding: 0, resource: { buffer: this.uniformBuffer } }],
    });

    passEncoder.setBindGroup(0, bindGroup);
    passEncoder.dispatchWorkgroups(Math.ceil(visibleNodes.length / 64));
    passEncoder.end();

    this.device.queue.submit([commandEncoder.finish()]);

    // Interactive Challenge: Workload shedding based on frame duration telemetry
    const duration = performance.now() - startTime;
    if (duration > 16.6) {
      this.consecutiveSlowFrames++;
      if (this.consecutiveSlowFrames >= 3 && this.qualityTier === 'high') {
        this.qualityTier = 'low';
        window.dispatchEvent(
          new CustomEvent('canvas-performance-degraded', {
            detail: { droppedFrames: this.consecutiveSlowFrames, activeNodes: visibleNodes.length },
          })
        );
      }
    } else {
      this.consecutiveSlowFrames = Math.max(0, this.consecutiveSlowFrames - 1);
      if (this.consecutiveSlowFrames === 0 && this.qualityTier === 'low') {
        this.qualityTier = 'high';
      }
    }
  }
}
