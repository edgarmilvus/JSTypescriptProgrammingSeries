/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Skeleton code provided for Exercise 1
import RBush from 'rbush';

export interface CanvasNodeBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  id: string;
  nodeType: 'media-stream' | 'webgpu-shader' | 'ai-prompt';
}

export class CanvasSpatialIndex {
  private tree: RBush<CanvasNodeBounds>;

  constructor() {
    this.tree = new RBush<CanvasNodeBounds>();
  }

  public insertNode(node: CanvasNodeBounds): void {
    // TODO: Implement insertion logic
  }

  public removeNode(id: string): void {
    // TODO: Implement removal logic using a stored lookup map or search
  }

  public updateNodePosition(id: string, newBounds: Omit<CanvasNodeBounds, 'id' | 'nodeType'>): void {
    // TODO: Implement update logic
  }

  public queryViewport(viewport: { minX: number; minY: number; maxX: number; maxY: number }): CanvasNodeBounds[] {
    // TODO: Implement spatial query logic returning intersecting nodes
    return [];
  }
}
