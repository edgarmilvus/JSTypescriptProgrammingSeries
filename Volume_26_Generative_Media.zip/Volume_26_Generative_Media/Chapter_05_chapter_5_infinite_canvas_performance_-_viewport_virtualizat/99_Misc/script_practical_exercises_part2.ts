/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Skeleton code provided for Exercise 2
export interface Point2D {
  x: number;
  y: number;
  id: string;
}

export interface RectangleBoundary {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class QuadtreeNode<T extends Point2D> {
  private boundary: RectangleBoundary;
  private capacity: number;
  private items: T[] = [];
  private divided: boolean = false;

  private northwest!: QuadtreeNode<T>;
  private northeast!: QuadtreeNode<T>;
  private southwest!: QuadtreeNode<T>;
  private southeast!: QuadtreeNode<T>;

  constructor(boundary: RectangleBoundary, capacity: number) {
    this.boundary = boundary;
    this.capacity = capacity;
  }

  public insert(item: T): boolean {
    // TODO: Implement bounds check and recursive insertion
    return false;
  }

  private subdivide(): void {
    // TODO: Implement quadrant splitting logic
  }

  public query(range: RectangleBoundary, found: T[]): T[] {
    // TODO: Implement range intersection and collection
    return found;
  }
}
