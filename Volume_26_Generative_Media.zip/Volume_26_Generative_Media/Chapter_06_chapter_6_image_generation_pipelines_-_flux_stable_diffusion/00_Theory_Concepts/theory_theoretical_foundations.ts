/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="filled", fillcolor="#f0f4f8", fontname="Arial", fontsize=12];
edge [fontname="Arial", fontsize=10];

subgraph cluster_pixel {
    label = "Pixel Space (High Dimensional)";
    style = dashed;
    PixelInput [label="Input Image (512x512x3)"];
    PixelOutput [label="Reconstructed Image (512x512x3)"];
}

subgraph cluster_latent {
    label = "Latent Space (Low Dimensional)";
    style = dashed;
    LatentZ [label="Latent Representation z (64x64x4)"];
    DenoisedZ [label="Denoised Latent z_0"];
    UNet [label="U-Net / Transformer Denoiser"];
}

PixelInput -> Encoder [label="E(x)"];
Encoder -> LatentZ;
LatentZ -> UNet [label="Forward Diffusion / Noise"];
UNet -> DenoisedZ [label="Iterative Denoising (t)"];
DenoisedZ -> Decoder [label="D(z_0)"];
Decoder -> PixelOutput;
