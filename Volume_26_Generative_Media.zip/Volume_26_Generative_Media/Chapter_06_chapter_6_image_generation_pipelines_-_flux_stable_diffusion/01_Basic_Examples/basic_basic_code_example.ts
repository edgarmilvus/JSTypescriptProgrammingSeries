/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ImageGenerationPipeline.ts
 * @description A production-ready, self-contained TypeScript class managing an in-browser
 * Stable Diffusion / Flux image generation pipeline via Transformers.js and WebGPU.
 */

import { 
    AutoPipelineForImageGeneration, 
    Tensor 
} from '@huggingface/transformers';

/**
 * Interface representing the generation options supplied by the SaaS user interface.
 */
interface GenerationOptions {
    prompt: string;
    negativePrompt?: string;
    width?: number;
    height?: number;
    numInferenceSteps?: number;
    guidanceScale?: int;
    onProgress?: (step: number, totalSteps: number, progressTensor?: Tensor) => void;
}

/**
 * Interface representing the final output returned to the application canvas.
 */
interface GenerationResult {
    imageUrl: string;
    tensor: Tensor;
    executionTimeMs: number;
}

export class BrowserImageGenerationPipeline {
    private pipeline: any | null = null;
    private isInitialized: boolean = false;
    private modelId: string;

    /**
     * @constructor
     * @param {string} [modelId="Xenova/stable-diffusion-v1-5"] - The Hugging Face model repository ID.
     */
    constructor(modelId: string = "Xenova/stable-diffusion-v1-5") {
        this.modelId = modelId;
    }

    /**
     * Initializes the WebGPU backend and downloads/loads the ONNX model weights.
     * This method is asynchronous to handle network I/O and GPU context creation.
     * 
     * @returns {Promise<void>}
     */
    public async initialize(): Promise<void> {
        if (this.isInitialized) {
            console.warn("Pipeline is already initialized.");
            return;
        }

        try {
            console.info(`[Pipeline] Initializing WebGPU backend for model: ${this.modelId}...`);
            
            // Check for WebGPU availability in the browser environment
            if (!navigator.gpu) {
                throw new Error("WebGPU is not supported or enabled in this browser environment.");
            }

            // Load the pipeline using ONNX Runtime Web with WebGPU acceleration
            // We leveragefp16 precision to minimize memory overhead in the browser context
            this.pipeline = await AutoPipelineForImageGeneration.from_pretrained(this.modelId, {
                device: 'webgpu',
                dtype: 'fp16', // Fallback handling is managed internally by transformers.js if fp16 isn't supported
            });

            this.isInitialized = true;
            console.info("[Pipeline] Successfully initialized and loaded into GPU memory.");
        } catch (error: unknown) {
            console.error("[Pipeline] Failed to initialize WebGPU pipeline:", error);
            throw new Error(`Initialization failed: ${(error as Error).message}`);
        }
    }

    /**
     * Executes the text-to-image generation loop based on the user's prompt.
     * 
     * @param {GenerationOptions} options - Configuration parameters for generation.
     * @returns {Promise<GenerationResult>} The resulting image data URL, tensor, and metrics.
     */
    public async generate(options: GenerationOptions): Promise<GenerationResult> {
        if (!this.isInitialized || !this.pipeline) {
            throw new Error("Pipeline must be initialized via initialize() before generating images.");
        }

        const startTime = performance.now();
        const {
            prompt,
            negativePrompt = "",
            width = 512,
            height = 512,
            numInferenceSteps = 20,
            guidanceScale = 7.5,
            onProgress
        } = options;

        console.info(`[Pipeline] Starting generation for prompt: "${prompt}"`);

        try {
            // Execute the diffusion process on the WebGPU device
            // The callback function hooks into the inner loop of the scheduler for step-by-step UI updates
            const output = await this.pipeline(prompt, {
                negative_prompt: negativePrompt,
                width: width,
                height: height,
                num_inference_steps: numInferenceSteps,
                guidance_scale: guidanceScale,
                callback: (step: number, totalSteps: number, currentTensor: Tensor) => {
                    if (onProgress) {
                        onProgress(step, totalSteps, currentTensor);
                    }
                }
            });

            // Extract the generated image tensor (typically a batch of 1 image)
            const imageTensor = output.images[0];

            // Convert the raw tensor output into a browser-renderable Blob/URL via an HTML Canvas
            const imageUrl = await this.tensorToDataURL(imageTensor);

            const endTime = performance.now();
            const executionTimeMs = endTime - startTime;

            console.info(`[Pipeline] Generation completed successfully in ${executionTimeMs.toFixed(2)}ms`);

            return {
                imageUrl,
                tensor: imageTensor,
                executionTimeMs
            };

        } catch (error: unknown) {
            console.error("[Pipeline] Error during tensor inference execution:", error);
            throw new Error(`Inference execution failed: ${(error as Error).message}`);
        }
    }

    /**
     * Helper utility to convert a processed image Tensor into an object URL for DOM rendering.
     * 
     * @private
     * @param {Tensor} tensor - The output image tensor from the diffusion pipeline.
     * @returns {Promise<string>} A blob URL pointing to the rendered image.
     */
    private async tensorToDataURL(tensor: Tensor): Promise<string> {
        // Ensure the tensor is in the correct format [H, W, C] and normalized to [0, 255]
        // Transformers.js raw image outputs are typically RawImage instances or Tensor wrappers
        const rawImage = tensor.toCanvas ? tensor.toCanvas() : await tensor.toImage();
        
        // If rawImage is an HTMLCanvasElement
        if (rawImage instanceof HTMLCanvasElement) {
            return new Promise((resolve, reject) => {
                rawImage.toBlob((blob) => {
                    if (!blob) {
                        reject(new Error("Failed to convert canvas to Blob."));
                        return;
                    }
                    resolve(URL.createObjectURL(blob));
                }, 'image/png');
            });
        }

        throw new Error("Unsupported tensor-to-image conversion target.");
    }

    /**
     * Frees up WebGPU memory allocations and resets the pipeline state.
     * Essential for SaaS applications allowing users to hot-swap models without crashing the tab.
     */
    public async dispose(): void {
        if (this.pipeline && typeof this.pipeline.dispose === 'function') {
            await this.pipeline.dispose();
        }
        this.pipeline = null;
        this.isInitialized = false;
        console.info("[Pipeline] Resources successfully disposed from WebGPU memory.");
    }
}
