/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface GPUMemoryPressureEvent extends CustomEvent {
  detail: {
    allocatedBytes: number;
    maxBytes: number;
    usageRatio: number;
  };
}

export async function initializeWebGPUDevice(): Promise<{ device: GPUDevice; adapter: GPUAdapter }> {
  if (!navigator.gpu) {
    throw new Error('WebGPU is not supported in this browser environment.');
  }

  const adapter = await navigator.gpu.requestAdapter({
    powerPreference: 'high-performance',
  });

  if (!adapter) {
    throw new Error('Failed to secure a high-performance WebGPU adapter.');
  }

  // Request limits accommodating massive diffusion tensor storage buffers
  const requiredLimits: Record<string, number> = {
    maxStorageBufferBindingSize: Math.min(
      adapter.limits.maxStorageBufferBindingSize,
      2 * 1024 * 1024 * 1024 // Request up to 2GB if supported
    ),
    maxBufferSize: Math.min(
      adapter.limits.maxBufferSize,
      2 * 1024 * 1024 * 1024
    ),
  };

  const device = await adapter.requestDevice({
    requiredLimits,
  });

  return { device, adapter };
}

export class GPUBufferManager {
  private device: GPUDevice;
  private allocatedBuffers: Map<GPUBuffer, number> = new Map();
  private totalAllocatedBytes: number = 0;
  private maxStorageLimit: number;

  constructor(device: GPUDevice) {
    this.device = device;
    this.maxStorageLimit = device.limits.maxStorageBufferBindingSize;
  }

  public allocateTensorBuffer(sizeInBytes: number, usageFlags: GPUBufferUsageFlags): GPUBuffer {
    const buffer = this.device.createBuffer({
      size: sizeInBytes,
      usage: usageFlags,
      mappedAtCreation: false,
    });

    this.allocatedBuffers.set(buffer, sizeInBytes);
    this.totalAllocatedBytes += sizeInBytes;

    this.checkMemoryPressure();

    return buffer;
  }

  public writeTensorData(buffer: GPUBuffer, data: Float32Array): void {
    this.device.queue.writeBuffer(buffer, 0, data.buffer, data.byteOffset, data.byteLength);
  }

  public async readTensorData(buffer: GPUBuffer, sizeInBytes: number): Promise<Float32Array> {
    const stagingBuffer = this.device.createBuffer({
      size: sizeInBytes,
      usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
    });

    const commandEncoder = this.device.createCommandEncoder();
    commandEncoder.copyBufferToBuffer(buffer, 0, stagingBuffer, 0, sizeInBytes);
    this.device.queue.submit([commandEncoder.finish()]);

    await stagingBuffer.mapAsync(GPUMapMode.READ);
    const mappedRange = stagingBuffer.getMappedRange(0, sizeInBytes);
    const result = new Float32Array(mappedRange.slice(0));
    
    stagingBuffer.unmap();
    stagingBuffer.destroy();

    return result;
  }

  private checkMemoryPressure(): void {
    const usageRatio = this.totalAllocatedBytes / this.maxStorageLimit;
    if (usageRatio >= 0.8) {
      console.warn(`[GPUMemoryPressure] Active allocations are at ${(usageRatio * 100).toFixed(1)}% of maximum limits.`);
      
      const event: GPUMemoryPressureEvent = new CustomEvent('gpumemorypressure', {
        detail: {
          allocatedBytes: this.totalAllocatedBytes,
          maxBytes: this.maxStorageLimit,
          usageRatio,
        },
      }) as GPUMemoryPressureEvent;
      
      window.dispatchEvent(event);
    }
  }

  public dispose(): void {
    for (const [buffer] of this.allocatedBuffers) {
      buffer.destroy();
    }
    this.allocatedBuffers.clear();
    this.totalAllocatedBytes = 0;
  }
}
