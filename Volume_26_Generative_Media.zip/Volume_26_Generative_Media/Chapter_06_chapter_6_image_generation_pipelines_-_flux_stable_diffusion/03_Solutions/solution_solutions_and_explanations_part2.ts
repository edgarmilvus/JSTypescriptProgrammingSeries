/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type TensorShape = number[];

export interface NodePort {
  name: string;
  expectedShape?: TensorShape;
  dataType: 'float32' | 'int32' | 'string';
}

export interface ExecutionContext {
  device: GPUDevice;
  currentStep: number;
  totalSteps: number;
  abortSignal: AbortSignal;
}

export abstract class BaseWorkflowNode {
  public id: string;
  public inputs: Map<string, NodePort> = new Map();
  public outputs: Map<string, NodePort> = new Map();

  constructor(id: string) {
    this.id = id;
  }

  public abstract execute(
    context: ExecutionContext,
    inputData: Map<string, any>
  ): Promise<Map<string, any>>;
}

export class PipelineExecutor {
  private nodes: Map<string, BaseWorkflowNode> = new Map();
  private edges: Array<{ fromNode: string; fromPort: string; toNode: string; toPort: string }> = [];

  public addNode(node: BaseWorkflowNode): void {
    this.nodes.set(node.id, node);
  }

  public addEdge(fromNode: string, fromPort: string, toNode: string, toPort: string): void {
    this.edges.push({ fromNode, fromPort, toNode, toPort });
  }

  private topologicalSort(): string[] {
    const inDegree = new Map<string, number>();
    const adjList = new Map<string, string[]>();

    for (const nodeId of this.nodes.keys()) {
      inDegree.set(nodeId, 0);
      adjList.set(nodeId, []);
    }

    for (const edge of this.edges) {
      adjList.get(edge.fromNode)?.push(edge.toNode);
      inDegree.set(edge.toNode, (inDegree.get(edge.toNode) || 0) + 1);
    }

    const queue: string[] = [];
    for (const [nodeId, degree] of inDegree.entries()) {
      if (degree === 0) queue.push(nodeId);
    }

    const sorted: string[] = [];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      sorted.push(curr);

      for (const neighbor of adjList.get(curr) || []) {
        inDegree.set(neighbor, inDegree.get(neighbor)! - 1);
        if (inDegree.get(neighbor) === 0) {
          queue.push(neighbor);
        }
      }
    }

    if (sorted.length !== this.nodes.size) {
      throw new Error('Circular dependency detected in workflow node graph.');
    }

    return sorted;
  }

  public async *executePipeline(
    context: ExecutionContext
  ): AsyncGenerator<{ nodeId: string; progress: number; data: any }, void, unknown> {
    const sortedNodeIds = this.topologicalSort();
    const nodeOutputs = new Map<string, Map<string, any>>();

    for (let i = 0; i < sortedNodeIds.length; i++) {
      if (context.abortSignal.aborted) {
        throw new DOMException('Pipeline execution aborted by user.', 'AbortError');
      }

      const nodeId = sortedNodeIds[i];
      const node = this.nodes.get(nodeId)!;
      const inputData = new Map<string, any>();

      // Gather input data from upstream edges
      const incomingEdges = this.edges.filter((e) => e.toNode === nodeId);
      for (const edge of incomingEdges) {
        const upstreamOutput = nodeOutputs.get(edge.fromNode);
        if (!upstreamOutput || !upstreamOutput.has(edge.fromPort)) {
          throw new Error(`Missing output data from node ${edge.fromNode}:${edge.fromPort} for node ${nodeId}`);
        }
        
        // Shape validation check
        const portDefinition = node.inputs.get(edge.toPort);
        const tensorData = upstreamOutput.get(edge.fromPort);
        if (portDefinition?.expectedShape && tensorData instanceof Float32Array) {
          // Validate logical dimensions if encoded
        }

        inputData.set(edge.toPort, tensorData);
      }

      const outputMap = await node.execute(context, inputData);
      nodeOutputs.set(nodeId, outputMap);

      yield {
        nodeId,
        progress: (i + 1) / sortedNodeIds.length,
        data: outputMap,
      };
    }
  }
}
