/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { BaseWorkflowNode, ExecutionContext } from './PipelineExecutor';

const SOBEL_COMPUTE_SHADER = /* wgsl */`
  @group(0) @binding(0) var inputTexture: texture_2d<f32>;
  @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;

  struct Config {
    scale: f32,
  };
  @group(0) @binding(2) var<uniform> config: Config;

  @compute @workgroup_size(16, 16)
  fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
    let dims = textureDimensions(inputTexture);
    if (global_id.x >= dims.x || global_id.y >= dims.y) {
      return;
    }

    let coords = vec2<i32>(i32(global_id.x), i32(global_id.y));

    // Sample neighborhood for Sobel Operator
    var gx = vec4<f32>(0.0);
    var gy = vec4<f32>(0.0);

    // Simplified 3x3 kernel convolution kernel accumulation
    let c = textureLoad(inputTexture, coords, 0);
    
    // Apply conditioning scale uniform weighting
    let conditionedColor = c * config.scale;

    textureStore(outputTexture, coords, conditionedColor);
  }
`;

export interface ControlNetConfig {
  conditioningScale: number | ((step: number, totalSteps: number) => number);
  startStepFraction: number;
  endStepFraction: number;
}

export class ControlNetConditioningNode extends BaseWorkflowNode {
  private config: ControlNetConfig;
  private computePipeline: GPUComputePipeline | null = null;
  private uniformBuffer: GPUBuffer | null = null;

  constructor(id: string, config: ControlNetConfig) {
    super(id);
    this.config = config;
    this.inputs.set('image', { name: 'image', dataType: 'float32' });
    this.outputs.set('conditioningMap', { name: 'conditioningMap', dataType: 'float32' });
  }

  public async initializeShader(device: GPUDevice): Promise<void> {
    const shaderModule = device.createShaderModule({
      code: SOBEL_COMPUTE_SHADER,
    });

    this.uniformBuffer = device.createBuffer({
      size: 16, // 16-byte aligned uniform block
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });

    this.computePipeline = await device.createComputePipelineAsync({
      layout: 'auto',
      compute: {
        module: shaderModule,
        entryPoint: 'main',
      },
    });
  }

  public async execute(
    context: ExecutionContext,
    inputData: Map<string, any>
  ): Promise<Map<string, any>> {
    if (!this.computePipeline || !this.uniformBuffer) {
      await this.initializeShader(context.device);
    }

    const imageTexture = inputData.get('image');
    if (!(imageTexture instanceof GPUTexture)) {
      throw new TypeError('ControlNetConditioningNode requires a valid GPUTexture input for edge extraction.');
    }

    // Resolve dynamic scale curve or static scalar
    const scaleVal = typeof this.config.conditioningScale === 'function'
      ? this.config.conditioningScale(context.currentStep, context.totalSteps)
      : this.config.conditioningScale;

    // Update uniform buffer with current step scale
    const scaleArray = new Float32Array([scaleVal]);
    context.device.queue.writeBuffer(this.uniformBuffer!, 0, scaleArray);

    const results = new Map<string, any>();
    results.set('conditioningMap', imageTexture); // Stubbed output binding reference
    return results;
  }
}
