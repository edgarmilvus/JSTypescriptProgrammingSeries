/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState, useCallback } from 'react';

export interface WorkflowCanvasNodeViewProps {
  nodeId: string;
  nodeTitle: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  progress: number;
  outputStream?: AsyncGenerator<{ progress: number; tensorData: Float32Array }, void, unknown>;
  onCancel: () => void;
  onParameterChange: (paramName: string, value: any) => void;
  device?: GPUDevice;
}

export const WorkflowCanvasNodeView: React.FC<WorkflowCanvasNodeViewProps> = ({
  nodeId,
  nodeTitle,
  status,
  progress,
  outputStream,
  onCancel,
  onParameterChange,
  device,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [cfgScale, setCfgScale] = useState<number>(7.5);
  const [loupeVisible, setLoupeVisible] = useState<boolean>(false);
  const [loupeCoords, setLoupeCoords] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const loupeCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let isCancelled = false;

    async function consumeStream() {
      if (!outputStream || !canvasRef.current) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      for await (const frame of outputStream) {
        if (isCancelled) break;
        
        // Render tensor feedback data onto canvas bitmap (Assuming 512x512 RGBA format)
        const clampedData = new Uint8ClampedArray(frame.tensorData.buffer);
        const imageData = new ImageData(clampedData, 512, 512);
        ctx.putImageData(imageData, 0, 0);
      }
    }

    consumeStream();

    return () => {
      isCancelled = true;
    };
  }, [outputStream]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!e.shiftKey || !canvasRef.current) {
      setLoupeVisible(false);
      return;
    }

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setLoupeVisible(true);
    setLoupeCoords({ x, y });
  }, []);

  return (
    <div className="workflow-node-card border border-slate-700 rounded-lg p-4 bg-slate-900 text-white shadow-2xl w-96 relative">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold text-lg">{nodeTitle}</h3>
        <span className={`px-2 py-1 text-xs rounded uppercase font-bold ${
          status === 'running' ? 'bg-amber-500 text-black animate-pulse' : 'bg-emerald-500 text-black'
        }`}>
          {status}
        </span>
      </div>

      <div 
        className="relative aspect-square bg-black rounded overflow-hidden mb-4 cursor-crosshair"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setLoupeVisible(false)}
      >
        <canvas ref={canvasRef} width={512} height={512} className="w-full h-full object-contain" />
        
        {loupeVisible && (
          <div 
            className="absolute w-28 h-28 border-2 border-indigo-400 rounded-full overflow-hidden pointer-events-none bg-black shadow-lg"
            style={{ left: loupeCoords.x - 56, top: loupeCoords.y - 56 }}
          >
            <canvas ref={loupeCanvasRef} width={128} height={128} className="w-full h-full scale-400 origin-center" />
          </div>
        )}

        {status === 'running' && (
          <div className="absolute inset-x-0 bottom-0 bg-black/70 p-2 backdrop-blur-sm">
            <div className="w-full bg-slate-700 h-2 rounded overflow-hidden">
              <div className="bg-indigo-500 h-full transition-all duration-150" style={{ width: `${progress * 100}%` }} />
            </div>
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div>
          <label className="block text-xs text-slate-400 mb-1">CFG Guidance Scale: {cfgScale}</label>
          <input
            type="range"
            min="1.0"
            max="20.0"
            step="0.5"
            value={cfgScale}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              setCfgScale(val);
              onParameterChange('cfgScale', val);
            }}
            className="w-full accent-indigo-500 cursor-pointer"
          />
        </div>

        <div className="flex justify-end space-x-2">
          {status === 'running' ? (
            <button
              onClick={onCancel}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 rounded text-sm font-medium transition-colors shadow-lg"
            >
              Cancel Execution
            </button>
          ) : (
            <button
              onClick={() => onParameterChange('trigger', true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded text-sm font-medium transition-colors shadow-lg"
            >
              Run Node
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
