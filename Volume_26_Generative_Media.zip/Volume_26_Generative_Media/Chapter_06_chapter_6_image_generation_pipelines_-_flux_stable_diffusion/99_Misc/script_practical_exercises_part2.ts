/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Skeleton structure to guide your implementation
export type TensorShape = number[];

export interface NodePort {
  name: string;
  expectedShape?: TensorShape;
  dataType: 'float32' | 'int32' | 'string';
}

export interface ExecutionContext {
  device: GPUDevice;
  currentStep: number;
  totalSteps: number;
  abortSignal: AbortSignal;
}

export abstract class BaseWorkflowNode {
  public id: string;
  public inputs: Map<string, NodePort> = new Map();
  public outputs: Map<string, NodePort> = new Map();

  constructor(id: string) {
    this.id = id;
  }

  public abstract execute(
    context: ExecutionContext,
    inputData: Map<string, any>
  ): Promise<Map<string, any>>;
}

export class PipelineExecutor {
  private nodes: Map<string, BaseWorkflowNode> = new Map();
  private edges: Array<{ fromNode: string; fromPort: string; toNode: string; toPort: string }> = [];

  public addNode(node: BaseWorkflowNode): void {
    // TODO: Register node
  }

  public addEdge(fromNode: string, fromPort: string, toNode: string, toPort: string): void {
    // TODO: Register edge and validate ports
  }

  public async *executePipeline(context: ExecutionContext): AsyncGenerator<{ nodeId: string; progress: number; data: any }, void, unknown> {
    // TODO: Implement topological sort, validation, and step-by-step yield execution
    throw new Error('Not implemented');
  }
}
