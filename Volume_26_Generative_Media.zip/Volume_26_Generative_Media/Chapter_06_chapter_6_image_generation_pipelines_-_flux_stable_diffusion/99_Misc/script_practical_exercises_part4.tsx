/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Skeleton structure to guide your implementation
import React, { useEffect, useRef, useState } from 'react';

export interface WorkflowCanvasNodeViewProps {
  nodeId: string;
  nodeTitle: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  progress: number;
  outputStream?: AsyncGenerator<{ progress: number; tensorData: Float32Array }, void, unknown>;
  onCancel: () => void;
  onParameterChange: (paramName: string, value: any) => void;
}

export const WorkflowCanvasNodeView: React.FC<WorkflowCanvasNodeViewProps> = ({
  nodeId,
  nodeTitle,
  status,
  progress,
  outputStream,
  onCancel,
  onParameterChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [cfgScale, setCfgScale] = useState<number>(7.5);

  useEffect(() => {
    // TODO: Consume outputStream asynchronously, render incoming tensor data to canvas context
    let isCancelled = false;

    async function consumeStream() {
      if (!outputStream) return;
      for await (const frame of outputStream) {
        if (isCancelled) break;
        // TODO: Blit frame.tensorData to canvas
      }
    }

    consumeStream();

    return () => {
      isCancelled = true;
    };
  }, [outputStream]);

  return (
    <div className="workflow-node-card border rounded-lg p-4 bg-slate-900 text-white shadow-xl w-96">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold text-lg">{nodeTitle}</h3>
        <span className={`px-2 py-1 text-xs rounded ${status === 'running' ? 'bg-amber-500' : 'bg-emerald-500'}`}>
          {status}
        </span>
      </div>

      <div className="relative aspect-square bg-black rounded overflow-hidden mb-4">
        <canvas ref={canvasRef} className="w-full h-full object-contain" />
        {status === 'running' && (
          <div className="absolute inset-x-0 bottom-0 bg-black/60 p-2">
            <div className="w-full bg-slate-700 h-2 rounded overflow-hidden">
              <div className="bg-indigo-500 h-full transition-all duration-150" style={{ width: `${progress * 100}%` }} />
            </div>
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div>
          <label className="block text-xs text-slate-400 mb-1">CFG Scale: {cfgScale}</label>
          <input
            type="range"
            min="1.0"
            max="20.0"
            step="0.5"
            value={cfgScale}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              setCfgScale(val);
              onParameterChange('cfgScale', val);
            }}
            className="w-full accent-indigo-500"
          />
        </div>

        <div className="flex justify-end space-x-2">
          {status === 'running' ? (
            <button
              onClick={onCancel}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 rounded text-sm font-medium transition-colors"
            >
              Cancel Execution
            </button>
          ) : (
            <button
              onClick={() => onParameterChange('trigger', true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded text-sm font-medium transition-colors"
            >
              Run Node
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
