/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file video-orchestrator.ts
 * @description Core orchestration engine for frame-by-frame video generation jobs 
 * in a TypeScript-based SaaS architecture.
 */

import { EventEmitter } from 'events';

/**
 * Defines the strict structural shape of a video generation request payload.
 * Adheres to the Interface definition pattern for public API boundaries.
 */
interface IVideoJobPayload {
    readonly jobId: string;
    readonly userId: string;
    readonly prompt: string;
    readonly totalFrames: number;
    readonly fps: number;
    readonly resolution: {
        readonly width: number;
        readonly height: number;
    };
}

/**
 * Represents the lifecycle states of an individual frame within a rendering job.
 */
type FrameState = 'PENDING' | 'RENDERING' | 'COMPLETED' | 'FAILED';

/**
 * Represents the comprehensive state of a video generation job.
 */
interface IVideoJobState {
    jobId: string;
    status: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
    currentFrame: number;
    totalFrames: number;
    frameStates: Map<number, FrameState>;
    outputUrl?: string;
    error?: string;
}

/**
 * Mock WebSocket server interface for broadcasting real-time progress updates.
 */
interface IRealtimeBroadcaster {
    broadcast(jobId: string, event: string, payload: unknown): void;
}

/**
 * Mock implementation of a WebSocket broadcaster for SaaS client observability.
 */
class WebSocketBroadcaster implements IRealtimeBroadcaster {
    public broadcast(jobId: string, event: string, payload: unknown): void {
        console.log(`[WebSocket Emit] Room: ${jobId} | Event: ${event} | Payload:`, JSON.stringify(payload));
    }
}

/**
 * Core Orchestrator engine responsible for managing asynchronous video generation jobs,
 * tracking frame-by-frame progression, and handling state transitions.
 */
class VideoGenerationOrchestrator extends EventEmitter {
    private jobs: Map<string, IVideoJobState> = new Map();
    private broadcaster: IRealtimeBroadcaster;

    constructor(broadcaster: IRealtimeBroadcaster) {
        super();
        this.broadcaster = broadcaster;
    }

    /**
     * Initializes and registers a new frame-by-frame video generation job.
     * @param payload The validated video generation configuration payload.
     */
    public async initializeJob(payload: IVideoJobPayload): Promise<string> {
        // Construct initial frame states map
        const initialFrameStates = new Map<number, FrameState>();
        for (let i = 1; i <= payload.totalFrames; i++) {
            initialFrameStates.set(i, 'PENDING');
        }

        const jobState: IVideoJobState = {
            jobId: payload.jobId,
            status: 'QUEUED',
            currentFrame: 0,
            totalFrames: payload.totalFrames,
            frameStates: initialFrameStates
        };

        this.jobs.set(payload.jobId, jobState);
        
        // Broadcast initial job creation
        this.broadcaster.broadcast(payload.jobId, 'JOB_QUEUED', {
            jobId: payload.jobId,
            totalFrames: payload.totalFrames
        });

        // Trigger asynchronous execution pipeline without blocking the HTTP request thread
        setImmediate(() => this.executePipeline(payload));

        return payload.jobId;
    }

    /**
     * Executes the frame-by-frame rendering loop asynchronously.
     * @param payload The original job configuration payload.
     */
    private async executePipeline(payload: IVideoJobPayload): Promise<void> {
        const job = this.jobs.get(payload.jobId);
        if (!job) return;

        job.status = 'PROCESSING';
        this.broadcaster.broadcast(payload.jobId, 'JOB_STARTED', { jobId: payload.jobId });

        try {
            for (let frameIndex = 1; frameIndex <= payload.totalFrames; frameIndex++) {
                // Update specific frame state to RENDERING
                job.frameStates.set(frameIndex, 'RENDERING');
                job.currentFrame = frameIndex;

                this.broadcaster.broadcast(payload.jobId, 'FRAME_PROGRESS', {
                    jobId: payload.jobId,
                    currentFrame: frameIndex,
                    totalFrames: payload.totalFrames,
                    progressPercentage: Math.round((frameIndex / payload.totalFrames) * 100)
                });

                // Simulate frame generation latency (e.g., calling an AI diffusion pipeline)
                await this.simulateAIInferenceLatency(100);

                // Mark frame as successfully completed
                job.frameStates.set(frameIndex, 'COMPLETED');
            }

            // Finalize job processing
            job.status = 'COMPLETED';
            job.outputUrl = `https://cdn.saas-platform.com/videos/${payload.jobId}.mp4`;

            this.broadcaster.broadcast(payload.jobId, 'JOB_COMPLETED', {
                jobId: payload.jobId,
                outputUrl: job.outputUrl
            });

        } catch (error: unknown) {
            job.status = 'FAILED';
            const errorMessage = error instanceof Error ? error.message : 'Unknown rendering error';
            job.error = errorMessage;

            this.broadcaster.broadcast(payload.jobId, 'JOB_FAILED', {
                jobId: payload.jobId,
                error: errorMessage
            });
        }
    }

    /**
     * Helper utility to simulate asynchronous compute delay for frame rendering.
     * @param ms Milliseconds to wait.
     */
    private simulateAIInferenceLatency(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * Public method for fetching current job status (used for client polling fallback).
     */
    public getJobStatus(jobId: string): IVideoJobState | undefined {
        return this.jobs.get(jobId);
    }
}

// ==========================================
// Execution Demonstration (SaaS Integration)
// ==========================================

async function runSaaSWorkflow() {
    const wsBroadcaster = new WebSocketBroadcaster();
    const orchestrator = new VideoGenerationOrchestrator(wsBroadcaster);

    const sampleJobPayload: IVideoJobPayload = {
        jobId: 'job-xyz-98765',
        userId: 'user-alpha-42',
        prompt: 'Cinematic drone shot of a futuristic neon city, 4k resolution',
        totalFrames: 12, // Small count for demonstration speed
        fps: 24,
        resolution: {
            width: 1920,
            height: 1080
        }
    };

    console.log('Initializing video generation job for SaaS client...');
    const activeJobId = await orchestrator.initializeJob(sampleJobPayload);
    console.log(`Job successfully initialized with ID: ${activeJobId}`);

    // Poll status check demonstration after a brief interval
    setTimeout(() => {
        const status = orchestrator.getJobStatus(activeJobId);
        console.log('\n--- Mid-Pipeline Status Check ---');
        console.log(`Current Status: ${status?.status}`);
        console.log(`Progress: ${status?.currentFrame} / ${status?.totalFrames} frames`);
    }, 400);
}

// Execute the workflow simulation
runSaaSWorkflow();
