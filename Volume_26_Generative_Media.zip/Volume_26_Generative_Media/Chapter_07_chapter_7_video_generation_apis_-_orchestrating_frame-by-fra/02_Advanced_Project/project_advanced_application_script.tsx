/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';

// Interfaces for job tracking and frame processing
interface GenerationJob {
  jobId: string;
  prompt: string;
  totalFrames: number;
  fps: number;
  status: 'IDLE' | 'QUEUED' | 'PROCESSING' | 'ASSEMBLING' | 'COMPLETED' | 'FAILED';
  completedFrames: number;
  currentFrameData?: string; // Base64 or ObjectURL of latest frame
  error?: string;
}

interface FramePayload {
  jobId: string;
  frameIndex: number;
  totalFrames: number;
  imageData: string; // Base64 encoded JPEG/PNG
}

/**
 * VideoGenWorkspace: A SaaS client component for orchestrating frame-by-frame 
 * AI video generation jobs, handling real-time WebSocket streams, and compiling 
 * raw frame buffers into an MP4/WebM video stream using the browser's WebCodecs API.
 */
export default function VideoGenWorkspace() {
  // Application State
  const [prompt, setPrompt] = useState<string>('Cinematic drone shot over a neon-lit cyberpunk metropolis at night');
  const [totalFrames, setTotalFrames] = useState<number>(60); // 2 seconds at 30fps
  const [fps, setFps] = useState<number>(30);
  const [job, setJob] = useState<GenerationJob>({
    jobId: '',
    prompt: '',
    totalFrames: 0,
    fps: 30,
    status: 'IDLE',
    completedFrames: 0,
  });
  
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  
  // References for WebSocket and WebCodecs pipeline
  const wsRef = useRef<WebSocket | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const encoderRef = useRef<VideoEncoder | null>(null);
  const muxerChunksRef = useRef<Uint8Array[]>([]);

  /**
   * Initialize the WebCodecs VideoEncoder configuration for real-time 
   * hardware-accelerated encoding of frames coming from the WebSocket stream.
   */
  const initializeEncoder = useCallback((width: number, height: number, targetFps: number) => {
    muxerChunksRef.current = [];

    const initConfig: VideoEncoderConfig = {
      codec: 'vp09.00.10.08', // VP9 codec for broad web compatibility
      width,
      height,
      framerate: targetFps,
      bitrate: 2_000_000, // 2 Mbps
      latencyMode: 'realtime',
    };

    const encoder = new VideoEncoder({
      output: (chunk, metadata) => {
        // Handle encoded chunks (muxing step)
        const chunkData = new Uint8Array(chunk.byteLength);
        chunk.copyTo(chunkData);
        muxerChunksRef.current.push(chunkData);

        // If metadata contains decoder configuration, handle initialization if needed
        if (metadata && metadata.decoderConfig) {
          console.debug('Encoder emitted decoder config:', metadata.decoderConfig);
        }
      },
      error: (e) => {
        console.error('WebCodecs VideoEncoder error:', e);
        setJob((prev) => ({ ...prev, status: 'FAILED', error: e.message }));
      },
    });

    encoder.configure(initConfig);
    encoderRef.current = encoder;
  }, []);

  /**
   * Establishes a WebSocket connection to the generation pipeline, 
   * dispatching a new frame-by-frame job and listening for streaming payloads.
   */
  const startGenerationJob = async () => {
    if (!prompt.trim()) return;

    // Reset states
    setVideoUrl(null);
    setJob({
      jobId: 'job_' + Math.random().toString(36.substring(2, 9)),
      prompt,
      totalFrames,
      fps,
      status: 'QUEUED',
      completedFrames: 0,
    });

    // Establish WebSocket connection (simulated endpoint)
    const ws = new WebSocket(process.env.NEXT_PUBLIC_WS_URL || 'wss://api.generator.engine/v1/stream');
    wsRef.current = ws;

    ws.onopen = () => {
      console.debug('WebSocket connected. Dispatching frame generation job...');
      setJob((prev) => ({ ...prev, status: 'PROCESSING' }));

      // Send job payload to orchestrator
      ws.send(
        JSON.stringify({
          action: 'START_JOB',
          payload: {
            prompt,
            totalFrames,
            fps,
          },
        })
      );
    };

    ws.onmessage = async (event) => {
      const data = JSON.parse(event.data);

      if (data.type === 'FRAME_READY') {
        const framePayload: FramePayload = data.payload;
        
        // Update progress state
        setJob((prev) => ({
          ...prev,
          completedFrames: framePayload.frameIndex + 1,
          currentFrameData: framePayload.imageData,
        }));

        // Render frame to hidden canvas to capture VideoFrame
        await renderAndEncodeFrame(framePayload.imageData, framePayload.frameIndex);
      } else if (data.type === 'JOB_COMPLETE') {
        console.debug('Job completed by server. Finalizing stream...');
        await finalizeVideoAssembly();
        ws.close();
      } else if (data.type === 'ERROR') {
        setJob((prev) => ({ ...prev, status: 'FAILED', error: data.message }));
        ws.close();
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket encountered error:', error);
      setJob((prev) => ({ ...prev, status: 'FAILED', error: 'WebSocket transport error.' }));
    };

    ws.onclose = () => {
      console.debug('WebSocket connection closed.');
    };
  };

  /**
   * Renders the base64 image data onto an offscreen canvas, extracts a 
   * WebCodecs VideoFrame, and feeds it to the active VideoEncoder instance.
   */
  const renderAndEncodeFrame = async (base64Image: string, frameIndex: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.src = base64Image;
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
    });

    // Set canvas dimensions on first frame
    if (frameIndex === 0) {
      canvas.width = img.width;
      canvas.height = img.height;
      initializeEncoder(img.width, img.height, fps);
    }

    ctx.drawImage(img, 0, 0);

    if (encoderRef.current && encoderRef.current.state === 'configured') {
      // Create a hardware-accelerated VideoFrame directly from the canvas element
      const timestamp = (frameIndex / fps) * 1_000_000; // Microseconds
      const videoFrame = new VideoFrame(canvas, { timestamp });

      // Encode frame with keyframe injection every 30 frames
      const isKeyFrame = frameIndex % 30 === 0;
      encoderRef.current.encode(videoFrame, { keyFrame: isKeyFrame });

      // Explicitly close VideoFrame to prevent memory leaks in browser heap
      videoFrame.close();
    }
  };

  /**
   * Flushes the VideoEncoder pipeline, compiles encoded chunks into a Blob, 
   * and produces a playable Object URL for the HTML5 video player.
   */
  const finalizeVideoAssembly = async () => {
    setJob((prev) => ({ ...prev, status: 'ASSEMBLING' }));

    if (encoderRef.current && encoderRef.current.state === 'configured') {
      await encoderRef.current.flush();
      encoderRef.current.close();
    }

    // Assemble raw WebM/VP9 chunks into a standard Blob container
    const videoBlob = new Blob(muxerChunksRef.current, { type: 'video/webm' });
    const url = URL.createObjectURL(videoBlob);
    setVideoUrl(url);

    setJob((prev) => ({ ...prev, status: 'COMPLETED' }));
  };

  // Cleanup WebSockets and Encoders on component unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) wsRef.current.close();
      if (encoderRef.current && encoderRef.current.state === 'configured') {
        encoderRef.current.close();
      }
    };
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6 bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800">
      <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">
        Frame-by-Frame AI Video Generation Engine
      </h2>
      
      {/* Control Panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-400 mb-1">Prompt Configuration</label>
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={job.status === 'PROCESSING' || job.status === 'ASSEMBLING'}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Total Frames ({totalFrames})</label>
          <input
            type="number"
            min={10}
            max={300}
            value={totalFrames}
            onChange={(e) => setTotalFrames(Number(e.target.value))}
            disabled={job.status === 'PROCESSING' || job.status === 'ASSEMBLING'}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      <button
        onClick={startGenerationJob}
        disabled={job.status === 'PROCESSING' || job.status === 'ASSEMBLING'}
        className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 font-semibold py-3 rounded-lg transition-colors shadow-lg"
      >
        {job.status === 'IDLE' && 'Start Generation Pipeline'}
        {job.status === 'QUEUED' && 'Initializing Queue...'}
        {job.status === 'PROCESSING' && `Generating Frame ${job.completedFrames} / ${job.totalFrames}...`}
        {job.status === 'ASSEMBLING' && 'Assembling Video Stream...'}
        {job.status === 'COMPLETED' && 'Regenerate Video'}
        {job.status === 'FAILED' && 'Pipeline Failed - Retry'}
      </button>

      {/* Hidden processing canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Real-time Preview Area */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col items-center justify-center min-h-[240px]">
          <h3 className="text-sm font-semibold text-slate-400 mb-2">Live Frame Stream</h3>
          {job.currentFrameData ? (
            <img
              src={job.currentFrameData}
              alt={`Live Frame ${job.completedFrames}`}
              className="max-h-56 rounded-md object-contain border border-slate-800"
            />
          ) : (
            <p className="text-slate-600 text-sm">Awaiting stream packets...</p>
          )}
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col items-center justify-center min-h-[240px]">
          <h3 className="text-sm font-semibold text-slate-400 mb-2">Finalized Video Output</h3>
          {videoUrl ? (
            <video
              src={videoUrl}
              controls
              autoPlay
              loop
              className="max-h-56 rounded-md border border-slate-800"
            />
          ) : (
            <p className="text-slate-600 text-sm">Video will appear upon assembly completion.</p>
          )}
        </div>
      </div>

      {/* Error Output */}
      {job.error && (
        <div className="mt-4 p-4 bg-red-950 border border-red-800 text-red-200 rounded-lg text-sm">
          <strong>Pipeline Exception:</strong> {job.error}
        </div>
      )}
    </div>
  );
}
