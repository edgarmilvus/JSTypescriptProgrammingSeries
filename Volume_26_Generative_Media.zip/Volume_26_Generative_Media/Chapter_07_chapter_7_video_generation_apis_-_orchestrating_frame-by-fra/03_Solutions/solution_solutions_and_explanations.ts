/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export enum JobPriority {
  LOW = 0,
  NORMAL = 1,
  HIGH = 2,
  CRITICAL = 3,
}

export class InferenceTimeoutError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InferenceTimeoutError';
  }
}

export class RateLimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RateLimitError';
  }
}

export class InvalidPromptError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidPromptError';
  }
}

export interface JobOptions {
  priority?: JobPriority;
  maxRetries?: number;
  timeoutMs?: number;
}

export interface QueueMetrics {
  activeCount: number;
  queuedCount: number;
  completedCount: number;
  failedCount: number;
  averageProcessingTimeMs: number;
}

interface InternalJob<TJob, TResult> {
  id: string;
  data: TJob;
  options: Required<JobOptions>;
  resolve: (value: TResult | PromiseLike<TResult>) => void;
  reject: (reason?: any) => void;
  attempts: number;
  createdAt: number;
}

export class VideoJobQueue<TJob, TResult> {
  private maxConcurrency: number;
  private maxQueueDepth: number;
  private activeCount: number = 0;
  private completedCount: number = 0;
  private failedCount: number = 0;
  private totalProcessingTimeMs: number = 0;
  
  private queue: InternalJob<TJob, TResult>[] = [];
  private backpressureResolvers: (() => void)[] = [];
  private isPaused: boolean = false;

  constructor(maxConcurrency: number, maxQueueDepth: number) {
    this.maxConcurrency = maxConcurrency;
    this.maxQueueDepth = maxQueueDepth;
  }

  public async enqueue(jobData: TJob, options?: JobOptions): Promise<TResult> {
    const resolvedOptions: Required<JobOptions> = {
      priority: options?.priority ?? JobPriority.NORMAL,
      maxRetries: options?.maxRetries ?? 3,
      timeoutMs: options?.timeoutMs ?? 30000,
    };

    // Backpressure control: wait if queue depth exceeds limit
    while (this.queue.length >= this.maxQueueDepth) {
      await new Promise<void>((resolve) => {
        this.backpressureResolvers.push(resolve);
      });
    }

    return new Promise<TResult>((resolve, reject) => {
      const job: InternalJob<TJob, TResult> = {
        id: Math.random().toString(36.substring(2, 9)),
        data: jobData,
        options: resolvedOptions,
        resolve,
        reject,
        attempts: 0,
        createdAt: Date.now(),
      };

      this.insertByPriority(job);
      this.processNext();
    });
  }

  private insertByPriority(job: InternalJob<TJob, TResult>): void {
    const index = this.queue.findIndex(j => j.options.priority < job.options.priority);
    if (index === -1) {
      this.queue.push(job);
    } else {
      this.queue.splice(index, 0, job);
    }
  }

  private async processNext(): void {
    if (this.isPaused || this.activeCount >= this.maxConcurrency || this.queue.length === 0) {
      return;
    }

    const job = this.queue.shift();
    if (!job) return;

    // Release backpressure waiters if space opened up
    if (this.queue.length < this.maxQueueDepth && this.backpressureResolvers.length > 0) {
      const resolveWaiter = this.backpressureResolvers.shift();
      if (resolveWaiter) resolveWaiter();
    }

    this.activeCount++;
    const startTime = Date.now();

    try {
      const result = await this.executeWithRetry(job);
      const duration = Date.now() - startTime;
      this.totalProcessingTimeMs += duration;
      this.completedCount++;
      job.resolve(result);
    } catch (error) {
      this.failedCount++;
      job.reject(error);
    } finally {
      this.activeCount--;
      this.processNext();
    }
  }

  private async executeWithRetry(job: InternalJob<TJob, TResult>): Promise<TResult> {
    // Placeholder execution function representing AI inference cluster invocation
    // In production, this invokes the actual frame generation API callback.
    while (true) {
      job.attempts++;
      try {
        // Simulating invocation timeout wrapper
        return await Promise.race([
          this.simulateInference(job.data),
          new Promise<never>((_, reject) => 
            setTimeout(() => reject(new InferenceTimeoutError('Inference timed out')), job.options.timeoutMs)
          )
        ]);
      } catch (error) {
        if (error instanceof InvalidPromptError || job.attempts >= job.options.maxRetries) {
          throw error;
        }

        // Exponential backoff with jitter
        const baseDelay = Math.pow(2, job.attempts) * 100;
        const jitter = Math.random() * 100;
        const delay = baseDelay + jitter;
        await new Promise(res => setTimeout(res, delay));
      }
    }
  }

  private async simulateInference(data: TJob): Promise<TResult> {
    // Simulated inference execution layer
    return data as unknown as TResult;
  }

  public getMetrics(): QueueMetrics {
    return {
      activeCount: this.activeCount,
      queuedCount: this.queue.length,
      completedCount: this.completedCount,
      failedCount: this.failedCount,
      averageProcessingTimeMs: this.completedCount > 0 ? this.totalProcessingTimeMs / this.completedCount : 0,
    };
  }

  public async pause(): Promise<void> {
    this.isPaused = true;
  }

  public resume(): void {
    this.isPaused = false;
    while (this.activeCount < this.maxConcurrency && this.queue.length > 0) {
      this.processNext();
    }
  }
}
