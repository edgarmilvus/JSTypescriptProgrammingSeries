/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type MessageType = 
  | 'JOB_PROGRESS' 
  | 'FRAME_READY' 
  | 'ERROR_NOTIFICATION' 
  | 'CLIENT_COMMAND' 
  | 'PING' 
  | 'PONG';

export interface BaseMessage {
  id: string;
  timestamp: number;
  type: MessageType;
}

export interface JobProgressMessage extends BaseMessage {
  type: 'JOB_PROGRESS';
  payload: {
    jobId: string;
    currentFrame: number;
    totalFrames: number;
    estimatedTimeRemainingMs: number;
    fps: number;
  };
}

export interface FrameReadyMessage extends BaseMessage {
  type: 'FRAME_READY';
  payload: {
    jobId: string;
    frameIndex: number;
    width: number;
    height: number;
    format: 'jpeg' | 'png' | 'webp';
    byteLength: number;
  };
}

export interface ClientCommandMessage extends BaseMessage {
  type: 'CLIENT_COMMAND';
  payload: {
    jobId: string;
    command: 'PAUSE' | 'RESUME' | 'ABORT';
    parameters?: Record<string, unknown>;
  };
}

export type PipelineMessage = JobProgressMessage | FrameReadyMessage | ClientCommandMessage;

export class WebSocketTelemetryServer {
  private clients: Set<any> = new Set();

  constructor(port: number) {
    // Server initialization implementation (e.g., using ws library in Node.js)
  }

  public broadcast(message: PipelineMessage, binaryData?: ArrayBuffer): void {
    const jsonString = JSON.stringify(message);
    const jsonBuffer = Buffer.from(jsonString, 'utf-8');

    for (const client of this.clients) {
      if (binaryData) {
        // Multiplexing binary payload: [4-byte header length][JSON Payload][Binary Data]
        const headerLengthBuffer = Buffer.alloc(4);
        headerLengthBuffer.writeUInt32BE(jsonBuffer.length, 0);
        const packet = Buffer.concat([headerLengthBuffer, jsonBuffer, Buffer.from(binaryData)]);
        client.send(packet);
      } else {
        client.send(jsonString);
      }
    }
  }

  public async close(): Promise<void> {
    for (const client of this.clients) {
      client.terminate();
    }
    this.clients.clear();
  }
}

export class TelemetryClient {
  private ws: WebSocket | null = null;
  private url: string;
  private authToken: string;
  private offlineBuffer: ClientCommandMessage[] = [];
  private listeners: Map<string, Function[]> = new Map();
  private isConnected: boolean = false;

  constructor(url: string, authToken: string) {
    this.url = url;
    this.authToken = authToken;
    this.connect();
  }

  private connect(): void {
    const fullUrl = `${this.url}?token=${encodeURIComponent(this.authToken)}`;
    this.ws = new WebSocket(fullUrl);
    this.ws.binaryType = 'arraybuffer';

    this.ws.onopen = () => {
      this.isConnected = true;
      this.flushOfflineBuffer();
    };

    this.ws.onmessage = (event) => {
      if (event.data instanceof ArrayBuffer) {
        this.handleBinaryMessage(event.data);
      } else {
        const message: PipelineMessage = JSON.parse(event.data);
        this.emit(message.type, message);
      }
    };

    this.ws.onclose = () => {
      this.isConnected = false;
      setTimeout(() => this.connect(), 3000); // Reconnection backoff
    };
  }

  private handleBinaryMessage(data: ArrayBuffer): void {
    const dataView = new DataView(data);
    const jsonLength = dataView.getUint32(0, false); // Big-endian 4-byte header
    
    const decoder = new TextDecoder('utf-8');
    const jsonString = decoder.decode(new Uint8Array(data, 4, jsonLength));
    const message: PipelineMessage = JSON.parse(jsonString);

    const binaryPayload = data.slice(4 + jsonLength);
    this.emit(message.type, message, binaryPayload);
  }

  public on<K extends PipelineMessage['type']>(
    type: K, 
    listener: (msg: Extract<PipelineMessage, { type: K }>, binary?: ArrayBuffer) => void
  ): void {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, []);
    }
    this.listeners.get(type)!.push(listener);
  }

  private emit(type: string, message: PipelineMessage, binary?: ArrayBuffer): void {
    const typeListeners = this.listeners.get(type);
    if (typeListeners) {
      for (const listener of typeListeners) {
        listener(message, binary);
      }
    }
  }

  public send(message: ClientCommandMessage): void {
    if (this.isConnected && this.ws) {
      this.ws.send(JSON.stringify(message));
    } else {
      this.offlineBuffer.push(message);
    }
  }

  private flushOfflineBuffer(): void {
    while (this.offlineBuffer.length > 0 && this.isConnected && this.ws) {
      const msg = this.offlineBuffer.shift();
      if (msg) {
        this.ws.send(JSON.stringify(msg));
      }
    }
  }

  public disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
