/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface AssemblerConfig {
  width: number;
  height: number;
  bitrate: number;
  framerate: number;
  codec: string;
}

export class BrowserVideoAssembler {
  private encoder: VideoEncoder | null = null;
  private encodedChunks: EncodedVideoChunk[] = [];
  private encoderConfig: VideoEncoderConfig;

  constructor(config: AssemblerConfig) {
    this.encoderConfig = {
      codec: config.codec,
      width: config.width,
      height: config.height,
      bitrate: config.bitrate,
      framerate: config.framerate,
      latencyMode: 'quality',
    };
  }

  public async initialize(): Promise<void> {
    const support = await VideoEncoder.isConfigSupported(this.encoderConfig);
    if (!support.supported) {
      throw new Error(`VideoEncoder configuration is not supported: ${this.encoderConfig.codec}`);
    }

    this.encoder = new VideoEncoder({
      output: (chunk, metadata) => {
        this.encodedChunks.push(chunk);
      },
      error: (error) => {
        console.error('VideoEncoder error:', error);
      },
    });

    this.encoder.configure(this.encoderConfig);
  }

  public async addFrame(frame: VideoFrame, isKeyFrame: boolean = false): Promise<void> {
    if (!this.encoder) {
      throw new Error('VideoEncoder not initialized');
    }

    // Backpressure enforcement: block if encode queue exceeds threshold
    while (this.encoder.encodeQueueSize > 30) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }

    this.encoder.encode(frame, { keyFrame: isKeyFrame });
    frame.close(); // Immediately release graphics memory
  }

  public async finalize(): Promise<Blob> {
    if (!this.encoder) {
      throw new Error('VideoEncoder not initialized');
    }

    await this.encoder.flush();
    await this.encoder.close();
    this.encoder = null;

    // Package encoded chunks into a downloadable Blob container
    const totalLength = this.encodedChunks.reduce((acc, chunk) => acc + chunk.byteLength, 0);
    const combinedBuffer = new Uint8Array(totalLength);
    let offset = 0;

    for (const chunk of this.encodedChunks) {
      const chunkData = new Uint8Array(chunk.byteLength);
      chunk.copyTo(chunkData);
      combinedBuffer.set(chunkData, offset);
      offset += chunk.byteLength;
    }

    return new Blob([combinedBuffer], { type: 'video/mp4' });
  }

  public abort(): void {
    if (this.encoder) {
      this.encoder.reset();
      this.encoder.close();
      this.encoder = null;
    }
    this.encodedChunks = [];
  }
}
