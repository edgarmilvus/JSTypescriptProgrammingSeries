/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';

export interface AIdeoCanvasProps {
  jobId: string;
  wsEndpoint: string;
  width: number;
  height: number;
  totalFrames: number;
}

export type ToolMode = 'SELECT' | 'CROP' | 'PAINT_PROMPT';

export const AIdeoCanvas: React.FC<AIdeoCanvasProps> = ({
  jobId,
  wsEndpoint,
  width,
  height,
  totalFrames,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  
  const [currentFrameIndex, setCurrentFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [activeTool, setActiveTool] = useState<ToolMode>('SELECT');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const renderFrame = useCallback((frameIndex: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high-DPI (Retina) scaling
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Clear and draw background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Render placeholder frame indicator
    ctx.fillStyle = '#38bdf8';
    ctx.font = '24px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Frame ${frameIndex} / ${totalFrames}`, width / 2, height / 2);
    ctx.fillStyle = '#64748b';
    ctx.font = '14px Inter, sans-serif';
    ctx.fillText(`Tool: ${activeTool} | Job: ${jobId}`, width / 2, height / 2 + 30);
  }, [width, height, totalFrames, activeTool, jobId]);

  useEffect(() => {
    renderFrame(currentFrameIndex);
  }, [currentFrameIndex, renderFrame, zoomLevel]);

  useEffect(() => {
    // WebSocket telemetry subscription mock
    const ws = new WebSocket(`${wsEndpoint}?jobId=${jobId}`);
    ws.onmessage = (event) => {
      // Handle live telemetry frames
    };

    return () => {
      ws.close();
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [jobId, wsEndpoint]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newIndex = parseInt(e.target.value, 10);
    setCurrentFrameIndex(newIndex);
  };

  return (
    <div className="flex flex-col items-center p-4 bg-slate-900 rounded-xl shadow-2xl text-white">
      <div className="flex justify-between w-full mb-4 px-2">
        <div className="flex gap-2">
          {(['SELECT', 'CROP', 'PAINT_PROMPT'] as ToolMode[]).map((tool) => (
            <button 
              key={tool}
              onClick={() => setActiveTool(tool)}
              className={`px-3 py-1 rounded ${activeTool === tool ? 'bg-blue-600' : 'bg-slate-700'}`}
            >
              {tool.replace('_', ' ')}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span>Zoom: {zoomLevel}x</span>
          <button onClick={() => setZoomLevel(z => Math.max(0.5, z - 0.25))} className="px-2 bg-slate-700 rounded">-</button>
          <button onClick={() => setZoomLevel(z => Math.min(4, z + 0.25))} className="px-2 bg-slate-700 rounded">+</button>
        </div>
      </div>

      <div className="relative border border-slate-700 overflow-hidden rounded-lg bg-black">
        <canvas
          ref={canvasRef}
          style={{ width: `${width * zoomLevel}px`, height: `${height * zoomLevel}px` }}
          className="cursor-crosshair"
        />
      </div>

      <div className="w-full mt-4 flex flex-col gap-2">
        <div className="flex justify-between text-sm text-slate-400">
          <span>Frame: {currentFrameIndex} / {totalFrames}</span>
          <span>Speed: {playbackSpeed}x</span>
        </div>
        <input
          type="range"
          min={0}
          max={Math.max(1, totalFrames - 1)}
          value={currentFrameIndex}
          onChange={handleSeek}
          className="w-full accent-blue-500 cursor-pointer"
        />
      </div>
    </div>
  );
};
