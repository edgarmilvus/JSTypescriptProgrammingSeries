/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface EngineOptions {
  windowSize: number;
  blendWeights?: number[];
}

export class TemporalConsistencyEngine {
  private windowSize: number;
  private frameBufferHistory: Uint8Array[] = [];
  private weights: number[];

  constructor(options: EngineOptions) {
    this.windowSize = options.windowSize;
    
    if (options.blendWeights) {
      if (options.blendWeights.length !== options.windowSize) {
        throw new Error('blendWeights length must match windowSize');
      }
      this.weights = options.blendWeights;
    } else {
      // Default linear decay: current frame has highest weight
      const rawWeights = Array.from({ length: this.windowSize }, (_, i) => i + 1);
      const sum = rawWeights.reduce((a, b) => a + b, 0);
      this.weights = rawWeights.map(w => w / sum);
    }
  }

  public async blendFrame(
    currentFrameBuffer: Uint8Array, 
    width: number, 
    height: number
  ): Promise<Uint8Array> {
    // Push new frame to history window
    this.frameBufferHistory.unshift(new Uint8Array(currentFrameBuffer));

    // Maintain window size bound
    if (this.frameBufferHistory.length > this.windowSize) {
      this.frameBufferHistory.pop();
    }

    const currentHistoryLength = this.frameBufferHistory.length;
    const outputBuffer = new Uint8Array(currentFrameBuffer.length);

    // If only one frame exists (first frame), return as-is
    if (currentHistoryLength === 1) {
      outputBuffer.set(currentFrameBuffer);
      return outputBuffer;
    }

    // Adjust weights dynamically if history is smaller than windowSize during startup
    let activeWeights = this.weights.slice(0, currentHistoryLength);
    const weightSum = activeWeights.reduce((a, b) => a + b, 0);
    activeWeights = activeWeights.map(w => w / weightSum);

    // Pixel-by-pixel weighted blending across history buffer
    const pixelCount = currentFrameBuffer.length;
    for (let i = 0; i < pixelCount; i++) {
      let blendedValue = 0;
      for (let j = 0; j < currentHistoryLength; j++) {
        blendedValue += this.frameBufferHistory[j][i] * activeWeights[j];
      }
      outputBuffer[i] = Math.min(255, Math.max(0, Math.round(blendedValue)));
    }

    return outputBuffer;
  }

  public reset(): void {
    this.frameBufferHistory = [];
  }
}
