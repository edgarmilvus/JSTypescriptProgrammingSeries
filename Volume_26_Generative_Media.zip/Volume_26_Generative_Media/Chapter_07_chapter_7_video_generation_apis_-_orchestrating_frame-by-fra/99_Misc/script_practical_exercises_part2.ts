/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Implement your solution below

export type MessageType = 
  | 'JOB_PROGRESS' 
  | 'FRAME_READY' 
  | 'ERROR_NOTIFICATION' 
  | 'CLIENT_COMMAND' 
  | 'PING' 
  | 'PONG';

export interface BaseMessage {
  id: string;
  timestamp: number;
  type: MessageType;
}

export interface JobProgressMessage extends BaseMessage {
  type: 'JOB_PROGRESS';
  payload: {
    jobId: string;
    currentFrame: number;
    totalFrames: number;
    estimatedTimeRemainingMs: number;
    fps: number;
  };
}

export interface FrameReadyMessage extends BaseMessage {
  type: 'FRAME_READY';
  payload: {
    jobId: string;
    frameIndex: number;
    width: number;
    height: number;
    format: 'jpeg' | 'png' | 'webp';
    byteLength: number;
  };
}

export interface ClientCommandMessage extends BaseMessage {
  type: 'CLIENT_COMMAND';
  payload: {
    jobId: string;
    command: 'PAUSE' | 'RESUME' | 'ABORT';
    parameters?: Record<string, unknown>;
  };
}

export type PipelineMessage = JobProgressMessage | FrameReadyMessage | ClientCommandMessage;

export class WebSocketTelemetryServer {
  constructor(port: number) {
    // TODO: Initialize WebSocket server and event handlers
  }

  public broadcast(message: PipelineMessage, binaryData?: ArrayBuffer): void {
    // TODO: Send JSON and optional binary payload to all connected authenticated clients
  }

  public close(): Promise<void> {
    // TODO: Gracefully terminate all active socket connections
    throw new Error('Not implemented');
  }
}

export class TelemetryClient {
  constructor(url: string, authToken: string) {
    // TODO: Establish connection with heartbeat and offline buffer logic
  }

  public on<K extends PipelineMessage['type']>(
    type: K, 
    listener: (msg: Extract<PipelineMessage, { type: K }>, binary?: ArrayBuffer) => void
  ): void {
    // TODO: Register typed event listener
  }

  public send(message: ClientCommandMessage): void {
    // TODO: Send message or buffer if disconnected
  }

  public disconnect(): void {
    // TODO: Close socket and clean up timers
  }
}
