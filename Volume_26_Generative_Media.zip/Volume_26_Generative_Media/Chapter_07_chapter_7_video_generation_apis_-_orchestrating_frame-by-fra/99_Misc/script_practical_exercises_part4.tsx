/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Implement your solution below (TSX)

'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';

export interface AIdeoCanvasProps {
  jobId: string;
  wsEndpoint: string;
  width: number;
  height: number;
  totalFrames: number;
}

export type ToolMode = 'SELECT' | 'CROP' | 'PAINT_PROMPT';

export const AIdeoCanvas: React.FC<AIdeoCanvasProps> = ({
  jobId,
  wsEndpoint,
  width,
  height,
  totalFrames,
}) => {
  // TODO: Declare refs for canvas, animation frame ID, and WebSocket connection
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  const [currentFrameIndex, setCurrentFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [activeTool, setActiveTool] = useState<ToolMode>('SELECT');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // TODO: Implement frame rendering loop via requestAnimationFrame
  const renderFrame = useCallback((frameIndex: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // TODO: Draw background grid, active frame image, and tool overlays
  }, []);

  useEffect(() => {
    // TODO: Initialize WebSocket telemetry listener for live frame updates
    return () => {
      // TODO: Cleanup subscriptions and animation frames
    };
  }, [jobId, wsEndpoint, renderFrame]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newIndex = parseInt(e.target.value, 10);
    setCurrentFrameIndex(newIndex);
    renderFrame(newIndex);
  };

  return (
    <div className="flex flex-col items-center p-4 bg-slate-900 rounded-xl shadow-2xl text-white">
      <div className="flex justify-between w-full mb-4 px-2">
        <div className="flex gap-2">
          <button 
            onClick={() => setActiveTool('SELECT')}
            className={`px-3 py-1 rounded ${activeTool === 'SELECT' ? 'bg-blue-600' : 'bg-slate-700'}`}
          >
            Select
          </button>
          <button 
            onClick={() => setActiveTool('CROP')}
            className={`px-3 py-1 rounded ${activeTool === 'CROP' ? 'bg-blue-600' : 'bg-slate-700'}`}
          >
            Crop
          </button>
          <button 
            onClick={() => setActiveTool('PAINT_PROMPT')}
            className={`px-3 py-1 rounded ${activeTool === 'PAINT_PROMPT' ? 'bg-blue-600' : 'bg-slate-700'}`}
          >
            Paint Prompt
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span>Zoom: {zoomLevel}x</span>
          <button onClick={() => setZoomLevel(z => Math.max(0.5, z - 0.25))} className="px-2 bg-slate-700 rounded">-</button>
          <button onClick={() => setZoomLevel(z => Math.min(4, z + 0.25))} className="px-2 bg-slate-700 rounded">+</button>
        </div>
      </div>

      <div className="relative border border-slate-700 overflow-hidden rounded-lg bg-black">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          style={{ width: `${width * zoomLevel}px`, height: `${height * zoomLevel}px` }}
          className="cursor-crosshair"
        />
      </div>

      <div className="w-full mt-4 flex flex-col gap-2">
        <div className="flex justify-between text-sm text-slate-400">
          <span>Frame: {currentFrameIndex} / {totalFrames}</span>
          <span>Speed: {playbackSpeed}x</span>
        </div>
        <input
          type="range"
          min={0}
          max={totalFrames - 1}
          value={currentFrameIndex}
          onChange={handleSeek}
          className="w-full accent-blue-500 cursor-pointer"
        />
      </div>
    </div>
  );
};
