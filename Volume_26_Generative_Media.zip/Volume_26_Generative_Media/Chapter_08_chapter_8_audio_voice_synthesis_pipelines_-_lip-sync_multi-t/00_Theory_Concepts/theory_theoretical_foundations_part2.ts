/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual TypeScript implementation of a real-time PCM multi-track mixer 
// utilizing typed arrays and buffer pooling to avoid garbage collection overhead.

class PCMMixerEngine {
  private readonly sampleRate: number;
  private readonly numChannels: number;
  private masterHeadroomGain: number = 0.8;

  constructor(sampleRate: number = 44100, numChannels: number = 2) {
    this.sampleRate = sampleRate;
    this.numChannels = numChannels;
  }

  /**
   * Mixes multiple incoming PCM tracks into a single master buffer, 
   * applying gain stages and preventing digital clipping.
   */
  public mixTracks(tracks: readonly Float32Array[], trackGains: readonly number[]): Float32Array {
    if (tracks.length === 0 || tracks.length !== trackGains.length) {
      throw new Error("Invalid track inputs or mismatched gain parameters.");
    }

    const maxLength = Math.max(...tracks.map(t => t.length));
    const masterBuffer = new Float32Array(maxLength);

    // Sum all tracks sample by sample with individual track gain factors
    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];
      const gain = trackGains[i];

      for (let s = 0; s < track.length; s++) {
        masterBuffer[s] += track[s] * gain;
      }
    }

    // Apply master limiting and soft-clipping to prevent distortion
    for (let s = 0; s < masterBuffer.length; s++) {
      let sample = masterBuffer[s] * this.masterHeadroomGain;
      
      // Hard ceiling clamp or tanh soft-clipping curve
      if (sample > 1.0) {
        masterBuffer[s] = 1.0;
      } else if (sample < -1.0) {
        masterBuffer[s] = -1.0;
      } else {
        masterBuffer[s] = sample;
      }
    }

    return masterBuffer;
  }
}
