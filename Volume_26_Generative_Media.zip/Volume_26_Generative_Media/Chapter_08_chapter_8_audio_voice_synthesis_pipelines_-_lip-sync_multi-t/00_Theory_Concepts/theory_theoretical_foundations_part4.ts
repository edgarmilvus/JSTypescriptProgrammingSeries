/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual TypeScript representation of a node-based audio graph compiler 
// and topological execution planner.

type AudioNodeType = 'Source' | 'Effect' | 'Panner' | 'Destination';

interface IGraphAudioNode {
  readonly id: string;
  readonly type: AudioNodeType;
  readonly inputs: string[]; // IDs of upstream nodes
  readonly outputs: string[]; // IDs of downstream nodes
  process(inputBuffers: readonly Float32Array[]): Float32Array;
}

class AudioGraphCompiler {
  /**
   * Topologically sorts audio graph nodes to ensure upstream producers 
   * are evaluated before downstream consumers.
   */
  public compileExecutionPlan(nodes: Map<string, IGraphAudioNode>, destinationId: string): IGraphAudioNode[] {
    const visited = new Set<string>();
    const tempMark = new Set<string>();
    const sorted: IGraphAudioNode[] = { length: 0 } as unknown as IGraphAudioNode[]; // Array initialization
    const sortedArray: IGraphAudioNode[] = [];

    const visit = (nodeId: string) => {
      if (tempMark.has(nodeId)) {
        throw new Error(`Circular dependency detected in audio graph at node: ${nodeId}`);
      }
      if (!visited.has(nodeId)) {
        tempMark.add(nodeId);
        const node = nodes.get(nodeId);
        if (!node) {
          throw new Error(`Node not found in graph definition: ${nodeId}`);
        }

        for (const inputId of node.inputs) {
          visit(inputId);
        }

        tempMark.delete(nodeId);
        visited.add(nodeId);
        sortedArray.push(node);
      }
    };

    visit(destinationId);
    return sortedArray;
  }
}
