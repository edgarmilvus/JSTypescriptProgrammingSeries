/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Voice Synthesis and Multi-Track Mixing Pipeline
 * @description A self-contained TypeScript pipeline for TTS generation, phonetic 
 * viseme extraction for character lip-sync, and multi-track mixing in Node.js.
 * Target Context: SaaS Media Workflow Engine (Book 26, Chapter 8).
 */

import { EventEmitter } from 'node:events';
import { Readable, PassThrough } from 'node:stream';
import { promisify } from 'node:util';

// Define strict types for our audio chunks, visemes, and mixing tracks
export type VisemeType = 'sil' | 'p_b_m' | 'f_v' | 'th' | 't_d_n' | 'k_g' | 's_z' | 'ch_j_sh' | 'r' | 'l' | 'a' | 'e' | 'i' | 'o' | 'u';

export interface VisemeFrame {
  /** Timestamp in milliseconds from the start of the audio stream */
  timestampMs: number;
  /** The phonetically mapped viseme shape for animation rigging */
  viseme: VisemeType;
  /** Associated character or phoneme snippet */
  phoneme: string;
}

export interface AudioTrack {
  id: string;
  name: string;
  volume: number; // 0.0 to 1.0
  /** Stream representing raw PCM or encoded audio chunks */
  stream: Readable;
}

export interface RenderPipelineResult {
  executionId: string;
  totalDurationMs: number;
  visemeTimeline: VisemeFrame[];
  mixedAudioStream: Readable;
}

/**
 * Phoneme-to-Viseme mapping dictionary based on standard OCP/Microsoft standards.
 */
const PHONEME_TO_VISEME_MAP: Record<string, VisemeType> = {
  'p': 'p_b_m', 'b': 'p_b_m', 'm': 'p_b_m',
  'f': 'f_v', 'v': 'f_v',
  'th': 'th',
  't': 't_d_n', 'd': 't_d_n', 'n': 't_d_n',
  'k': 'k_g', 'g': 'k_g',
  's': 's_z', 'z': 's_z',
  'sh': 'ch_j_sh', 'ch': 'ch_j_sh', 'j': 'ch_j_sh',
  'r': 'r',
  'l': 'l',
  'a': 'a', 'ah': 'a',
  'e': 'e', 'eh': 'e',
  'i': 'i', 'ih': 'i',
  'o': 'o', 'oh': 'o',
  'u': 'u', 'uh': 'u'
};

/**
 * Simulates a Text-to-Speech engine yielding raw audio chunks and timing metadata.
 */
class MockTextToSpeechEngine extends EventEmitter {
  /**
   * Generates a synthetic audio stream and corresponding viseme timeline from input text.
   * @param text The input script to synthesize.
   * @param voiceId The identifier of the neural voice model.
   */
  public async synthesize(text: string, voiceId: string): Promise<{ audioStream: Readable; visemes: VisemeFrame[] }> {
    console.log(`[TTS Engine] Initializing voice model '${voiceId}' for text length: ${text.length} chars`);
    
    const visemes: VisemeFrame[] = [];
    const outputStream = new PassThrough();
    
    // Simulate async processing delay
    await new Promise((resolve) => setTimeout(resolve, 150));

    // Simple heuristic to split text into words/phonemes for demonstration
    const words = text.split(/\s+/);
    let currentTimeMs = 0;
    const msPerCharacter = 60; // Estimated speech rate

    // Generate mock PCM audio data chunks
    const sampleRate = 24000; // 24kHz mono PCM
    const bytesPerSample = 2; // 16-bit PCM
    
    // Process each word to build the viseme timeline
    for (const word of words) {
      const wordDurationMs = word.length * msPerCharacter;
      const firstChar = word.charAt(0).toLowerCase();
      
      // Determine viseme mapping
      const mappedViseme: VisemeType = PHONEME_TO_VISEME_MAP[firstChar] || 'a';
      
      visemes.push({
        timestampMs: currentTimeMs,
        viseme: mappedViseme,
        phoneme: firstChar
      });

      // Push simulated PCM chunk to the stream
      const chunkByteLength = Math.floor((wordDurationMs / 1000) * sampleRate * bytesPerSample);
      const pcmChunk = Buffer.alloc(chunkByteLength);
      // Fill with dummy sine wave data or silence for structural completeness
      pcmChunk.fill(128); 
      
      outputStream.write(pcmChunk);
      currentTimeMs += wordDurationMs;
    }

    // Signal end of synthesis
    outputStream.end();

    return {
      audioStream: outputStream,
      visemes
    };
  }
}

/**
 * Multi-Track Audio Mixer combining voice-over streams with background music/effects.
 */
class MultiTrackAudioMixer {
  /**
   * Mixes multiple audio streams into a single composite output stream with volume scaling.
   * @-param tracks Array of audio tracks containing streams and volume parameters.
   */
  public mixTracks(tracks: AudioTrack[]): Readable {
    console.log(`[AudioMixer] Initializing multi-track mix for ${tracks.length} active channels.`);
    
    const masterOutput = new PassThrough();
    let completedTracks = 0;

    if (tracks.length === 0) {
      masterOutput.end();
      return masterOutput;
    }

    // Handle streaming data integration across all tracks
    tracks.forEach((track) => {
      track.stream.on('data', (chunk: Buffer) => {
        // In a production Web Audio API or native binding pipeline, 
        // PCM mixing algorithms (e.g., clamping addition or linear mixing) 
        // are applied here based on track.volume.
        const scaledChunk = Buffer.alloc(chunk.length);
        for (let i = 0; i < chunk.length; i += 2) {
          if (i + 1 < chunk.length) {
            // Read 16-bit signed PCM sample
            let sample = chunk.readInt16LE(i);
            // Apply volume attenuation
            sample = Math.max(-32768, Math.min(32767, Math.floor(sample * track.volume)));
            scaledChunk.writeInt16LE(sample, i);
          }
        }
        masterOutput.write(scaledChunk);
      });

      track.stream.on('end', () => {
        completedTracks++;
        if (completedTracks === tracks.length) {
          console.log('[AudioMixer] All tracks fully consumed. Closing master stream.');
          masterOutput.end();
        }
      });

      track.stream.on('error', (err) => {
        console.error(`[AudioMixer] Error on track '${track.name}':`, err);
        masterOutput.destroy(err);
      });
    });

    return masterOutput;
  }
}

/**
 * Master Workflow Engine Orchestrator
 */
class VoiceSynthesisWorkflowEngine {
  private ttsEngine = new MockTextToSpeechEngine();
  private audioMixer = new MultiTrackAudioMixer();

  /**
   * Executes the end-to-end rendering pipeline for SaaS media generation.
   */
  public async executePipeline(executionId: string, scriptText: string, backgroundMusicStream: Readable): Promise<RenderPipelineResult> {
    console.log(`[WorkflowEngine] Starting pipeline execution: ${executionId}`);

    // Step 1: Generate Voice-Over TTS Stream and Visemes
    const { audioStream: voiceStream, visemes } = await this.ttsEngine.synthesize(scriptText, 'en-US-Neural-Standard-A');

    // Step 2: Prepare Background Track with ducking/volume scaling
    const backgroundTrack: AudioTrack = {
      id: 'bgm-01',
      name: 'Ambient Cinematic Synth',
      volume: 0.15, // Duck background music for voice clarity
      stream: backgroundMusicStream
    };

    const voiceTrack: AudioTrack = {
      id: 'vo-01',
      name: 'Character Voice-Over',
      volume: 1.0,
      stream: voiceStream
    };

    // Step 3: Mix Multi-Tracks
    const mixedStream = this.audioMixer.mixTracks([voiceTrack, backgroundTrack]);

    // Calculate total duration from last viseme frame
    const lastViseme = visemes[visemes.length - 1];
    const totalDurationMs = lastViseme ? lastViseme.timestampMs + 500 : 0;

    return {
      executionId,
      totalDurationMs,
      visemeTimeline: visemes,
      mixedAudioStream: mixedStream
    };
  }
}

// ==========================================
// Execution Demonstration (Self-Contained)
// ==========================================

async function runDemo() {
  const engine = new VoiceSynthesisWorkflowEngine();

  // Create a mock background music stream supplying silence/audio data
  const bgmStream = new PassThrough();
  const dummyBgmChunk = Buffer.alloc(19200, 100); // 19.2KB of mock PCM audio
  bgmStream.write(dummyBgmChunk);
  setTimeout(() => bgmStream.end(), 300); // End after 300ms

  const sampleScript = "Welcome to the generative media workflow engine. Node-based audio synthesis is now live.";

  try {
    const result = await engine.executePipeline('exec-99b-alpha', sampleScript, bgmStream);

    console.log('\n--- Pipeline Execution Complete ---');
    console.log(`Execution ID: ${result.executionId}`);
    console.log(`Estimated Duration: ${result.totalDurationMs} ms`);
    console.log(`Extracted Viseme Frames Count: ${result.visemeTimeline.length}`);
    console.log('Viseme Timeline Sample:', JSON.stringify(result.visemeTimeline.slice(0, 3), null, 2));

    // Consume mixed stream to demonstrate completion
    result.mixedAudioStream.on('data', (chunk) => {
      // In production, pipe this to WebRTC, WebSocket, or file disk storage (e.g., AWS S3)
    });

    result.mixedAudioStream.on('end', () => {
      console.log('[Demo] Mixed audio stream fully drained successfully.');
    });

  } catch (error) {
    console.error('[Demo] Pipeline execution failed:', error);
  }
}

runDemo();
