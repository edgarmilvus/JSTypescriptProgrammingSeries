/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Buffer } from 'buffer';

export interface VisemeKeyframe {
  timestampMs: number;
  durationMs: number;
  visemeCode: string;
  phoneme: string;
}

export interface VisemeTrack {
  trackId: string;
  totalDurationMs: number;
  keyframes: ReadonlyArray<VisemeKeyframe>;
}

export interface PipelineConfig {
  sampleRate: number;
  mapping: Record<string, string>;
  minThresholdMs: number;
}

export class VisemeExtractionPipeline {
  private config: Readonly<PipelineConfig>;

  constructor(config: PipelineConfig) {
    this.config = Object.freeze({
      ...config,
      mapping: { ...config.mapping },
    });
  }

  public async processAudioStream(audioBuffer: Buffer, transcript: string): Promise<VisemeTrack> {
    if (!audioBuffer || audioBuffer.length === 0) {
      throw new Error('Invalid or empty audio buffer provided.');
    }
    if (!transcript || transcript.trim().length === 0) {
      throw new Error('Transcript cannot be empty for phoneme extraction.');
    }

    const words = transcript.trim().split(/\s+/);
    const estimatedDurationPerWordMs = 250;
    const totalDurationMs = words.length * estimatedDurationPerWordMs;

    const keyframes: VisemeKeyframe[] = [];
    let currentTimeMs = 0;

    for (const word of words) {
      const phonemes = this.mockGraphemeToPhonemes(word);
      const phonemeDuration = Math.max(
        this.config.minThresholdMs,
        estimatedDurationPerWordMs / phonemes.length
      );

      for (const phoneme of phonemes) {
        const visemeCode = this.config.mapping[phoneme] || 'PP';
        keyframes.push({
          timestampMs: Math.round(currentTimeMs),
          durationMs: Math.round(phonemeDuration),
          visemeCode,
          phoneme,
        });
        currentTimeMs += phonemeDuration;
      }
    }

    return {
      trackId: `track_${Date.now()}`,
      totalDurationMs: Math.round(totalDurationMs),
      keyframes: Object.freeze(keyframes),
    };
  }

  private mockGraphemeToPhonemes(word: string): string[] {
    // Simple heuristic parser splitting characters into mock phonetic units
    const cleanWord = word.toLowerCase().replace(/[^a-z]/g, '');
    const phonemes: string[] = [];
    for (let i = 0; i < cleanWord.length; i++) {
      const char = cleanWord[i];
      if ('aeiou'.includes(char)) {
        phonemes.push('aa');
      } else if ('bp'.includes(char)) {
        phonemes.push('PP');
      } else if ('fv'.includes(char)) {
        phonemes.push('FF');
      } else {
        phonemes.push('nn');
      }
    }
    return phonemes.length > 0 ? phonemes : ['PP'];
  }
}
