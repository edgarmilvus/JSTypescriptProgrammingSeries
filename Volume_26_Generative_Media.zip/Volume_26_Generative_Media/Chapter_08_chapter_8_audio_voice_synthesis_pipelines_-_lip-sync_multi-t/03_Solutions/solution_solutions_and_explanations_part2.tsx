/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { FC, useEffect, useRef, useState, useCallback } from 'react';
import { VisemeTrack } from './VisemeExtractionPipeline';

export interface LipSyncVisualizerProps {
  audioSrc: string;
  visemeTrack: VisemeTrack;
  onVisemeChange?: (visemeCode: string, timestamp: number) => void;
}

export const LipSyncVisualizer: FC<LipSyncVisualizerProps> = ({
  audioSrc,
  visemeTrack,
  onVisemeChange,
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [activeViseme, setActiveViseme] = useState<string>('PP');
  const requestRef = useRef<number | null>(null);
  const previousVisemeRef = useRef<string>('PP');

  const getMouthPath = (code: string): string => {
    switch (code) {
      case 'aa':
        return 'M 30 50 Q 50 90 70 50 Z'; // Open wide
      case 'oh':
        return 'M 35 45 Q 50 75 65 45 Z'; // Round mouth
      case 'FF':
      case 'PP':
      default:
        return 'M 30 60 Q 50 65 70 60 Z'; // Closed / resting
    }
  };

  const updateVisemeFrame = useCallback(() => {
    if (audioRef.current) {
      const currentTimeMs = audioRef.current.currentTime * 1000;
      const currentKeyframe = visemeTrack.keyframes.find(
        (kf) =>
          currentTimeMs >= kf.timestampMs &&
          currentTimeMs <= kf.timestampMs + kf.durationMs
      );

      const visemeCode = currentKeyframe ? currentKeyframe.visemeCode : 'PP';

      if (visemeCode !== previousVisemeRef.current) {
        previousVisemeRef.current = visemeCode;
        setActiveViseme(visemeCode);
        if (onVisemeChange) {
          onVisemeChange(visemeCode, currentTimeMs);
        }
      }
    }
    requestRef.current = requestAnimationFrame(updateVisemeFrame);
  }, [visemeTrack, onVisemeChange]);

  useEffect(() => {
    const audioElement = audioRef.current;
    if (!audioElement) return;

    const handlePlay = () => {
      requestRef.current = requestAnimationFrame(updateVisemeFrame);
    };

    const handlePauseOrEnd = () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };

    audioElement.addEventListener('play', handlePlay);
    audioElement.addEventListener('pause', handlePauseOrEnd);
    audioElement.addEventListener('ended', handlePauseOrEnd);

    return () => {
      audioElement.removeEventListener('play', handlePlay);
      audioElement.removeEventListener('pause', handlePauseOrEnd);
      audioElement.removeEventListener('ended', handlePauseOrEnd);
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [updateVisemeFrame]);

  return (
    <div className="lip-sync-container" style={{ textAlign: 'center', fontFamily: 'sans-serif' }}>
      <audio ref={audioRef} src={audioSrc} controls />
      <div style={{ marginTop: '20px' }}>
        <svg width="200" height="200" viewBox="0 0 100 100" style={{ background: '#f0f0f0', borderRadius: '50%' }}>
          {/* Avatar Face Base */}
          <circle cx="50" cy="50" r="45" fill="#ffdbac" stroke="#333" strokeWidth="2" />
          {/* Eyes */}
          <circle cx="35" cy="40" r="5" fill="#333" />
          <circle cx="65" cy="40" r="5" fill="#333" />
          {/* Dynamic Mouth Path */}
          <path d={getMouthPath(activeViseme)} fill="#8b0000" stroke="#333" strokeWidth="2" />
        </svg>
      </div>
      <p>Active Viseme: <strong>{activeViseme}</strong></p>
    </div>
  );
};
