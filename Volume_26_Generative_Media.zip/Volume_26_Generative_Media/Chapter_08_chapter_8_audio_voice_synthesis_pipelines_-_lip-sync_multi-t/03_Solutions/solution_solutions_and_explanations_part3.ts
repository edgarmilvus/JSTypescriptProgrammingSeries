/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Buffer } from 'buffer';

export interface AudioTrack {
  readonly id: string;
  readonly pcmData: Buffer;
  readonly sampleRate: number;
  readonly channels: number;
  readonly offsetMs: number;
  readonly gain: number;
  readonly isMuted: boolean;
}

export class MultiTrackMixer {
  private tracks: ReadonlyArray<AudioTrack> = [];

  constructor(private masterSampleRate: number = 44100) {}

  public addTrack(track: AudioTrack): MultiTrackMixer {
    const updatedTracks = [...this.tracks, Object.freeze({ ...track })];
    const newMixer = new MultiTrackMixer(this.masterSampleRate);
    (newMixer as { tracks: ReadonlyArray<AudioTrack> }).tracks = Object.freeze(updatedTracks);
    return newMixer;
  }

  public removeTrack(trackId: string): MultiTrackMixer {
    const updatedTracks = this.tracks.filter((t) => t.id !== trackId);
    const newMixer = new MultiTrackMixer(this.masterSampleRate);
    (newMixer as { tracks: ReadonlyArray<AudioTrack> }).tracks = Object.freeze(updatedTracks);
    return newMixer;
  }

  public async renderMix(): Promise<Buffer> {
    const activeTracks = this.tracks.filter((t) => !t.isMuted && t.pcmData.length > 0);
    if (activeTracks.length === 0) {
      return Buffer.alloc(0);
    }

    let maxSampleLength = 0;
    for (const track of activeTracks) {
      const bytesPerSample = 2; // Assuming 16-bit PCM (Int16)
      const offsetSamples = Math.floor((track.offsetMs / 1000) * this.masterSampleRate);
      const trackSamples = track.pcmData.length / bytesPerSample;
      const totalTrackEndSample = offsetSamples + trackSamples;
      if (totalTrackEndSample > maxSampleLength) {
        maxSampleLength = totalTrackEndSample;
      }
    }

    const masterBuffer = Buffer.alloc(maxSampleLength * 2);

    for (const track of activeTracks) {
      const bytesPerSample = 2;
      const offsetSamples = Math.floor((track.offsetMs / 1000) * this.masterSampleRate);
      const numSamples = track.pcmData.length / bytesPerSample;

      for (let i = 0; i < numSamples; i++) {
        const masterIndex = (offsetSamples + i) * 2;
        if (masterIndex >= masterBuffer.length) break;

        const sampleVal = track.pcmData.readInt16LE(i * bytesPerSample);
        const adjustedSample = sampleVal * track.gain;

        const existingMasterSample = masterBuffer.readInt16LE(masterIndex);
        const mixedSample = existingMasterSample + adjustedSample;

        // Clamping protection against digital clipping
        const clampedSample = Math.max(-32768, Math.min(32767, Math.round(mixedSample)));
        masterBuffer.writeInt16LE(clampedSample, masterIndex);
      }
    }

    return masterBuffer;
  }
}
