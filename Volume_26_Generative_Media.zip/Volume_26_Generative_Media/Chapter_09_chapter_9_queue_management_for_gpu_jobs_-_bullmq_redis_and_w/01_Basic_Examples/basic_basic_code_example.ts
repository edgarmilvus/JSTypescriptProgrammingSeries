/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Queue, Worker, Job } from 'bullmq';
import Redis from 'ioredis';
import * as http from 'http';
import { URL } from 'url';

/**
 * Interface representing the payload for a generative media job.
 */
interface GenerationJobData {
  userId: string;
  prompt: string;
  model: string;
  webhookUrl: string;
}

/**
 * Interface representing progress updates sent via webhooks.
 */
interface WebhookPayload {
  jobId: string;
  status: 'active' | 'progress' | 'completed' | 'failed';
  progress: number;
  resultUrl?: string;
  error?: string;
}

// 1. Establish a shared Redis connection instance for BullMQ.
// BullMQ requires maxRetriesPerRequest set to null or undefined to handle blocking commands correctly.
const connection = new Redis({
  host: '127.0.0.1',
  port: 6379,
  maxRetriesPerRequest: null,
});

const QUEUE_NAME = 'gpu-generation-queue';

/**
 * 2. Initialize the BullMQ Queue.
 * This queue acts as the entry point from your SaaS API endpoints when users request media generation.
 */
const generationQueue = new Queue<GenerationJobData>(QUEUE_NAME, {
  connection,
  defaultJobOptions: {
    attempts: 3, // Automatically retry failed jobs up to 3 times
    backoff: {
      type: 'exponential',
      delay: 5000, // Wait 5s, then 10s, then 20s between attempts
    },
    removeOnComplete: { age: 3600 }, // Clean up completed jobs after 1 hour to save Redis memory
    removeOnFail: { age: 86400 }, // Retain failed jobs for 24 hours for debugging
  },
});

/**
 * Helper function to simulate dispatching an asynchronous webhook notification
 * back to the SaaS application backend or edge client.
 */
async function sendWebhook(webhookUrl: string, payload: WebhookPayload): Promise<void> {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(webhookUrl);
    const data = JSON.stringify(payload);

    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
      path: parsedUrl.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
      },
    };

    // In a real production system, use 'https' module if the target is secured.
    const req = http.request(options, (res) => {
      let responseBody = '';
      res.on('data', (chunk) => {
        responseBody += chunk;
      });
      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          resolve();
        } else {
          reject(new Error(`Webhook failed with status code ${res.statusCode}: ${responseBody}`));
        }
      });
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.write(data);
    req.end();
  });
}

/**
 * 3. Initialize the BullMQ Worker.
 * The worker pulls jobs from Redis and coordinates the local GPU processing pipeline.
 * Concurrency is strictly set to 1 to prevent VRAM exhaustion during heavy generation.
 */
const worker = new Worker<GenerationJobData>(
  QUEUE_NAME,
  async (job: Job<GenerationJobData>) => {
    const { userId, prompt, model, webhookUrl } = job.data;
    console.log(`[Worker] Starting job ${job.id} for user ${userId} using model ${model}`);

    // Notify client via webhook that processing has begun
    await sendWebhook(webhookUrl, {
      jobId: job.id as string,
      status: 'active',
      progress: 0,
    });

    // Simulate heavy WebGPU processing loops with incremental progress reporting
    const totalSteps = 10;
    for (let step = 1; step <= totalSteps; step++) {
      // Simulate hardware compute delay (e.g., waiting for WebGPU shader execution)
      await new Promise((resolve) => setTimeout(resolve, 600));

      const percent = Math.round((step / totalSteps) * 100);
      
      // Update BullMQ internal progress tracker (accessible via job.progress())
      await job.updateProgress(percent);

      // Stream progress update to the client webhook
      await sendWebhook(webhookUrl, {
        jobId: job.id as string,
        status: 'progress',
        progress: percent,
      });

      console.log(`[Worker] Job ${job.id} progress: ${percent}%`);
    }

    // Generate simulated final output artifact URL (e.g., S3 or CDN link)
    const resultUrl = `https://cdn.saas-platform.io/outputs/${job.id}.mp4`;

    // Notify client of successful completion
    await sendWebhook(webhookUrl, {
      jobId: job.id as string,
      status: 'completed',
      progress: 100,
      resultUrl,
    });

    return { resultUrl };
  },
  {
    connection,
    concurrency: 1, // CRITICAL: Restrict to 1 concurrent job per worker to protect local GPU VRAM
    limiter: {
      max: 5, // Maximum 5 jobs processed per time window
      duration: 10000, // Per 10 seconds (rate limiting safeguard)
    },
  }
);

// Worker event listeners for logging and lifecycle management
worker.on('completed', (job, returnValue) => {
  console.log(`[Queue Event] Job ${job.id} successfully completed. Result:`, returnValue);
});

worker.on('failed', async (job, err) => {
  console.error(`[Queue Event] Job ${job?.id} failed with error: ${err.message}`);
  if (job && job.data.webhookUrl) {
    try {
      await sendWebhook(job.data.webhookUrl, {
        jobId: job.id as string,
        status: 'failed',
        progress: job.progress as number || 0,
        error: err.message,
      });
    } catch (webhookErr) {
      console.error(`[Queue Event] Failed to dispatch failure webhook for job ${job.id}:`, webhookErr);
    }
  }
});

/**
 * 4. Demonstration Runner
 * Simulates a frontend API request submitting a job to the queue,
 * and a mock webhook receiver listening for status updates.
 */
async function runDemo() {
  // Start a local HTTP server to act as the webhook receiver
  const webhookServer = http.createServer((req, res) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const payload: WebhookPayload = JSON.parse(body);
      console.log(`\n[Webhook Receiver] Received event for Job [${payload.jobId}] -> Status: ${payload.status.toUpperCase()} (${payload.progress}%)`);
      if (payload.resultUrl) {
        console.log(`[Webhook Receiver] Artifact ready at: ${payload.resultUrl}`);
      }
      if (payload.error) {
        console.log(`[Webhook Receiver] Error message: ${payload.error}`);
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ received: true }));
    });
  });

  const WEBHOOK_PORT = 4000;
  webhookServer.listen(WEBHOOK_PORT, async () => {
    console.log(`[Webhook Server] Listening on http://localhost:${WEBHOOK_PORT}/webhook`);

    // Enqueue a test generation job
    console.log('[API] Enqueuing new generative media job...');
    const job = await generationQueue.add('generate-media', {
      userId: 'usr_992831',
      prompt: 'Cinematic drone shot of a futuristic neon cyber-city, 4k, raytracing',
      model: 'stable-diffusion-xl-v1.0',
      webhookUrl: `http://localhost:${WEBHOOK_PORT}/webhook`,
    });

    console.log(`[API] Job successfully added to queue with ID: ${job.id}`);
  });
}

// Execute the simulation
runDemo().catch(console.error);
