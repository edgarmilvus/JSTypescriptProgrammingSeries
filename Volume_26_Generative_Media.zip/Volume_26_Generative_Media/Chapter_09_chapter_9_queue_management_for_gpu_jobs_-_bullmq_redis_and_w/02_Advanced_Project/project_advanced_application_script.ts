/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Queue, Worker, Job, ConnectionOptions } from 'bullmq';
import Redis from 'ioredis';
import crypto from 'crypto';

/**
 * Configuration options for our Redis connection used by BullMQ.
 * Utilizing keep-alive parameters and reconnection strategies to guarantee
 * resilience under heavy network and database loads.
 */
const redisConnection: ConnectionOptions = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379', 10),
  password: process.env.REDIS_PASSWORD || undefined,
  maxRetriesPerRequest: null, // Required by BullMQ for blocking operations
  enableReadyCheck: false,
  retryStrategy: (times: number) => {
    // Exponential backoff with a maximum delay of 2000ms
    return Math.min(times * 50, 2000);
  },
};

/**
 * Interface representing the payload required for a generative media job.
 */
interface GenerativeJobPayload {
  userId: string;
  projectId: string;
  prompt: string;
  width: number;
  height: number;
  steps: number;
  webhookUrl: string;
}

/**
 * Interface representing the output returned by the GPU processing worker.
 */
interface GenerativeJobResult {
  assetUrl: string;
  vramUsedMB: number;
  processingTimeMs: number;
  checksum: string;
}

// ---------------------------------------------------------------------------
// 1. Queue Producer Architecture
// ---------------------------------------------------------------------------

/**
 * Global Queue instance for managing and dispatching GPU generation tasks.
 */
export const generativeQueue = new Queue<GenerativeJobPayload, GenerativeJobResult>('gpu-generation-queue', {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3, // Retry failed jobs up to 3 times
    backoff: {
      type: 'exponential',
      data: 5000, // 5 seconds initial delay before retry
    },
    removeOnComplete: {
      age: 86400, // Keep completed jobs in Redis for 24 hours
      count: 1000, // Keep maximum of 1000 completed jobs
    },
    removeOnFail: {
      age: 604800, // Keep failed jobs for 7 days for debugging
    },
  },
});

/**
 * Enqueues a new generative media job with priority handling.
 * 
 * @param payload - The data needed to execute the generation task.
 * @param priority - Integer representing job priority (lower number = higher priority).
 */
export async function dispatchGenerativeJob(payload: GenerativeJobPayload, priority: number = 10): Promise<string> {
  // Validate basic payload constraints to prevent malformed jobs entering the queue
  if (!payload.prompt || payload.width <= 0 || payload.height <= 0) {
    throw new Error('Invalid generative payload parameters provided.');
  }

  const jobId = `job_${crypto.randomUUID()}`;

  const job = await generativeQueue.add('render-generation', payload, {
    jobId,
    priority,
    // Add deduplication if necessary based on user and prompt hash
    deduplication: {
      id: crypto.createHash('sha256').update(`${payload.userId}:${payload.prompt}`).digest('hex'),
      ttl: 60000, // 1 minute deduplication window
    },
  });

  console.log(`[Queue Producer] Successfully enqueued job ID: ${job.id} with priority ${priority}`);
  return job.id as string;
}

// ---------------------------------------------------------------------------
// 2. GPU Worker Daemon Implementation
// ---------------------------------------------------------------------------

/**
 * Simulates an intensive WebGPU / Native C++ bridge invocation for media rendering.
 * This function enforces strict VRAM and time bounds.
 */
async function executeGpuRenderPipeline(job: Job<GenerativeJobPayload>): Promise<GenerativeJobResult> {
  const { prompt, width, height, steps } = job.data;
  
  console.log(`[Worker] Initializing GPU context for Job ${job.id}`);
  console.log(`[Worker] Parameters -> Dimensions: ${width}x${height}, Steps: ${steps}, Prompt: "${prompt}"`);

  // Report initial progress to BullMQ
  await job.updateProgress(10);

  // Simulate chunked execution steps with progress reporting
  for (let step = 1; step <= steps; step++) {
    // Check if job was cancelled or stalled externally
    if (await job.isTokenails()) {
      throw new Error(`Job ${job.id} was cancelled during execution.`);
    }

    // Simulate work increment
    await new Promise((resolve) => setTimeout(resolve, 100)); 
    
    const progress = Math.floor(10 + (step / steps) * 80);
    await job.updateProgress(progress);
  }

  // Simulate successful artifact generation
  const mockAssetUrl = `https://cdn. generative-engine.internal/assets/${job.id}.webp`;
  const checksum = crypto.createHash('md5').update(mockAssetUrl).digest('hex');

  await job.updateProgress(100);

  return {
    assetUrl: mockAssetUrl,
    vramUsedMB: 12450, // Simulated VRAM consumption
    processingTimeMs: steps * 100,
    checksum,
  };
}

/**
 * Worker instance managing concurrency and job lifecycle events.
 * concurrency: 1 ensures we do not saturate local WebGPU contexts or cause VRAM fragmentation.
 */
export const gpuWorker = new Worker<GenerativeJobPayload, GenerativeJobResult>(
  'gpu-generation-queue',
  async (job: Job<GenerativeJobPayload>) => {
    try {
      console.log(`[Worker] Processing started for Job: ${job.id} (Attempt ${job.attemptsMade + 1})`);
      
      const result = await executeGpuRenderPipeline(job);
      
      // Dispatch webhook notification to client application
      await sendWebhookNotification(job.data.webhookUrl, {
        status: 'COMPLETED',
        jobId: job.id,
        result,
      });

      return result;
    } catch (error: any) {
      console.error(`[Worker] Error processing Job ${job.id}:`, error.message);

      // Dispatch failure webhook notification
      await sendWebhookNotification(job.data.webhookUrl, {
        status: 'FAILED',
        jobId: job.id,
        error: error.message,
      });

      throw error; // Rethrow to let BullMQ handle retry attempts
    }
  },
  {
    connection: redisConnection,
    concurrency: 1, // Strict single-job concurrency per worker instance to safeguard VRAM
    limiter: {
      max: 10,      // Maximum 10 jobs processed
      duration: 1000, // Per 1 second (Rate limiting safeguard)
    },
  }
);

// Worker Event Listeners for telemetry and logging
gpuWorker.on('completed', (job, result) => {
  console.log(`[Worker Event] Job ${job.id} completed successfully. Asset URL: ${result.assetUrl}`);
});

gpuWorker.on('failed', (job, err) => {
  console.error(`[Worker Event] Job ${job?.id} failed permanently or exhausted retries: ${err.message}`);
});

// ---------------------------------------------------------------------------
// 3. Fault-Tolerant Webhook Handler
// ---------------------------------------------------------------------------

/**
 * Dispatches webhook notifications back to the consuming application with exponential backoff.
 */
async function sendWebhookNotification(url: string, payload: object, retries = 3): Promise<void> {
  let attempt = 0;
  while (attempt < retries) {
    try {
      // Utilizing standard fetch to push state changes to the target URL
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'GenerativeEngine-WebhookService/1.0',
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(5000), // 5-second timeout constraint
      });

      if (response.ok) {
        console.log(`[Webhook] Successfully notified endpoint: ${url}`);
        return;
      }

      console.warn(`[Webhook] Received non-200 status (${response.status}) from ${url}. Retrying...`);
    } catch (error: any) {
      console.error(`[Webhook] Attempt ${attempt + 1} failed for ${url}: ${error.message}`);
    }

    attempt++;
    // Wait before retrying (exponential backoff)
    await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000));
  }

  console.error(`[Webhook] CRITICAL: Failed to deliver webhook notification to ${url} after ${retries} attempts.`);
}
