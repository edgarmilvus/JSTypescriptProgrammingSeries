/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Queue, Worker, Job } from 'bullmq';
import Redis from 'ioredis';

// 2. Immutable GPUJobPayload interface
export interface GPUJobPayload {
  readonly jobId: string;
  readonly userId: string;
  readonly taskType: 'preview' | 'standard' | 'batch';
  readonly vramRequirementMB: number;
  readonly modelParameters: Readonly<Record<string, unknown>>;
}

// 1. Redis connection configuration
const connection = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379', 10),
  maxRetriesPerRequest: null, // Required by BullMQ
});

// 1. Initialize BullMQ Queue
export const gpuQueue = new Queue<GPUJobPayload>('gpu-render-queue', {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      // Custom exponential backoff with jitter calculation
      delay: 2000, 
    },
    removeOnComplete: true,
    removeOnFail: false,
  },
});

// 3. Job submission function with explicit priority mapping
export async function enqueueGPUJob(payload: GPUJobPayload): Promise<Job<GPUJobPayload>> {
  let priority = 5; // Default standard
  switch (payload.taskType) {
    case 'preview':
      priority = 1; // Highest priority
      break;
    case 'standard':
      priority = 5;
      break;
    case 'batch':
      priority = 10; // Lowest priority
      break;
  }

  return gpuQueue.add(payload.taskType, payload, {
    jobId: payload.jobId,
    priority,
  });
}

// Mock hardware utility for VRAM tracking
async function checkAvailableVRAM(requiredMB: number): Promise<boolean> {
  const simulatedTotalVRAM = 24576; // 24GB
  const simulatedUsedVRAM = 14336;  // 14GB in use
  const availableHeadroom = simulatedTotalVRAM - simulatedUsedVRAM;
  return availableHeadroom >= requiredMB;
}

// 4. Configure BullMQ Worker with concurrency limit of 2
export const gpuWorker = new Worker<GPUJobPayload>(
  'gpu-render-queue',
  async (job: Job<GPUJobPayload>) => {
    const { jobId, vramRequirementMB, taskType } = job.data;
    console.log(`[Worker] Processing job ${jobId} (${taskType}) requiring ${vramRequirementMB}MB VRAM`);

    // 5. Check available VRAM before execution
    const hasHeadroom = await checkAvailableVRAM(vramRequirementMB);
    if (!hasHeadroom) {
      console.warn(`[Worker] OOM Protection: Insufficient VRAM for job ${jobId}. Re-queuing with delay.`);
      
      // Calculate jitter to prevent thundering herd problem on Redis event loop
      const jitter = Math.floor(Math.random() * 1000);
      const calculatedDelay = Math.pow(2, job.attemptsMade) * 1000 + jitter;
      
      throw new Error(`INSUFFICIENT_VRAM: Requires ${vramRequirementMB}MB. Delaying for ${calculatedDelay}ms`);
    }

    // Simulate asynchronous WebGPU processing pipeline
    await new Promise((resolve) => setTimeout(resolve, 3000));
    console.log(`[Worker] Successfully completed GPU render for job ${jobId}`);
    return { success: true, timestamp: Date.now() };
  },
  {
    connection,
    concurrency: 2, // Strict VRAM OOM protection limit
  }
);

gpuWorker.on('failed', (job, err) => {
  console.error(`[Worker Error] Job ${job?.id} failed with error: ${err.message}`);
});
