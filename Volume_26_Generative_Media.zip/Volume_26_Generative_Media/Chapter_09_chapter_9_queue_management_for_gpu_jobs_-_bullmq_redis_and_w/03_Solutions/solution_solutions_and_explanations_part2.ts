/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';
import express, { Request, Response } from 'express';
import crypto from 'crypto';

// Immutable Webhook Event Interface
export interface WebhookEvent {
  readonly jobId: string;
  readonly status: 'STARTED' | 'PROGRESS_25' | 'PROGRESS_50' | 'COMPLETED' | 'FAILED';
  readonly timestamp: number;
  readonly metadata?: Readonly<Record<string, unknown>>;
}

const REDIS_CHANNEL_PREFIX = 'gpu:job:';
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || 'super-secret-gpu-key';

// 1. Redis Pub/Sub Publisher utility for BullMQ lifecycle integration
export class WebhookPublisher {
  constructor(private readonly redisClient: Redis) {}

  public async publishEvent(event: WebhookEvent): Promise<void> {
    const channel = `${REDIS_CHANNEL_PREFIX}${event.jobId}`;
    // Freeze object to enforce Immutable State Management principles
    const frozenEvent: Readonly<WebhookEvent> = Object.freeze({ ...event });
    await this.redisClient.publish(channel, JSON.stringify(frozenEvent));
  }
}

// 3. HMAC-SHA256 signature generator
function generateHMACSignature(payload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

// Helper with exponential backoff for downstream webhook deliveries
async function deliverWebhookWithRetry(url: string, payloadString: string, signature: string, retries = 3): Promise<void> {
  let attempt = 0;
  while (attempt < retries) {
    try {
      // Mocking fetch request to downstream client
      // const response = await fetch(url, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //     'X-Signature': signature,
      //   },
      //   body: payloadString,
      // });
      // if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
      return; // Success
    } catch (error) {
      attempt++;
      if (attempt >= retries) throw error;
      const delay = Math.pow(2, attempt) * 500;
      await new Promise((res) => setTimeout(res, delay));
    }
  }
}

// 2. Express Webhook Dispatcher Service with Redis Subscriber
export function createWebhookDispatcherApp(subscriberRedis: Redis, targetWebhookUrl: string) {
  const app = express();
  app.use(express.json());

  // Duplicate Redis connection required for subscription mode
  subscriberRedis.psubscribe(`${REDIS_CHANNEL_PREFIX}*`, (err, count) => {
    if (err) {
      console.error('Failed to subscribe to Redis channels:', err);
    } else {
      console.log(`Subscribed to ${count} Redis channel pattern(s).`);
    }
  });

  subscriberRedis.on('pmessage', async (pattern, channel, message) => {
    try {
      const rawData = JSON.parse(message);
      // Enforce immutable state object conversion on receipt
      const event: Readonly<WebhookEvent> = Object.freeze(rawData);

      console.log(`[Webhook Dispatcher] Event received for job ${event.jobId}: ${event.status}`);

      const payloadString = JSON.stringify(event);
      const signature = generateHMACSignature(payloadString, WEBHOOK_SECRET);

      // Dispatch HTTP webhook with retry middleware loop
      await deliverWebhookWithRetry(targetWebhookUrl, payloadString, signature);
    } catch (error) {
      console.error('[Webhook Dispatcher] Error processing message:', error);
    }
  });

  app.get('/health', (req: Request, res: Response) => {
    res.status(200).json({ status: 'healthy', timestamp: Date.now() });
  });

  return app;
}
