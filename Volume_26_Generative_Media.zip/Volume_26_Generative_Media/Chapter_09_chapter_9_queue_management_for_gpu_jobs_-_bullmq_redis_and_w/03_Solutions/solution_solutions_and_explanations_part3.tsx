/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback, useRef } from 'react';

export interface GPUJob {
  readonly jobId: string;
  readonly status: 'queued' | 'active' | 'completed' | 'failed';
  readonly progress: number; // 0 to 100
  readonly vramConsumptionMB: number;
  readonly taskType: string;
}

interface GPUJobMonitorProps {
  readonly wsEndpoint: string;
  readonly apiBaseUrl: string;
}

// 2. Custom React hook managing native WebSocket connection with exponential backoff
export function useGPUStream(endpoint: string) {
  const [jobs, setJobs] = useState<readonly GPUJob[]>([]);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const reconnectAttempts = useRef<number>(0);
  const wsRef = useRef<WebSocket | null>(null);

  const connect = useCallback(() => {
    const ws = new WebSocket(endpoint);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      reconnectAttempts.current = 0; // Reset backoff on success
    };

    ws.onmessage = (event) => {
      try {
        const incomingJob: GPUJob = JSON.parse(event.data);
        setJobs((prevJobs) => {
          const index = prevJobs.findIndex((j) => j.jobId === incomingJob.jobId);
          if (index !== -1) {
            // Immutable update for existing job
            const updated = [...prevJobs];
            updated[index] = Object.freeze(incomingJob);
            return Object.freeze(updated);
          } else {
            // Append new job immutably
            return Object.freeze([...prevJobs, Object.freeze(incomingJob)]);
          }
        });
      } catch (err) {
        console.error('Failed to parse incoming WebSocket message', err);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Exponential backoff reconnection calculation
      const timeout = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
      reconnectAttempts.current += 1;
      setTimeout(() => connect(), timeout);
    };
  }, [endpoint]);

  useEffect(() => {
    connect();
    return () => {
      wsRef.current?.close();
    };
  }, [connect]);

  return { jobs, isConnected, setJobs };
}

// 1 & 3 & 4. TSX Component for Job Monitoring and Cancellation
export const GPUJobMonitor: React.FC<GPUJobMonitorProps> = ({ wsEndpoint, apiBaseUrl }) => {
  const { jobs, isConnected, setJobs } = useGPUStream(wsEndpoint);

  const handleCancelJob = async (jobId: string) => {
    // Optimistic UI state update
    setJobs((prevJobs) =>
      Object.freeze(
        prevJobs.map((j) => (j.jobId === jobId ? Object.freeze({ ...j, status: 'failed' as const }) : j))
      )
    );

    try {
      await fetch(`${apiBaseUrl}/jobs/${jobId}`, { method: 'DELETE' });
    } catch (err) {
      console.error(`Failed to cancel job ${jobId} on server`, err);
    }
  };

  const categorizedJobs = {
    queued: jobs.filter((j) => j.status === 'queued'),
    active: jobs.filter((j) => j.status === 'active'),
    completed: jobs.filter((j) => j.status === 'completed'),
    failed: jobs.filter((j) => j.status === 'failed'),
  };

  return (
    <div className="gpu-job-monitor p-6 bg-slate-900 text-slate-100 min-h-screen">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Generative GPU Pipeline Monitor</h1>
        <div className="flex items-center space-x-2">
          <span className={`h-3 w-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-sm">{isConnected ? 'Live Stream Connected' : 'Reconnecting...'}</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {(['queued', 'active', 'completed', 'failed'] as const).map((statusKey) => (
          <div key={statusKey} className="bg-slate-800 p-4 rounded-lg shadow-md">
            <h2 className="text-lg font-semibold uppercase tracking-wider mb-3 text-slate-400">
              {statusKey} ({categorizedJobs[statusKey].length})
            </h2>
            <div className="space-y-3">
              {categorizedJobs[statusKey].map((job) => (
                <div key={job.jobId} className="bg-slate-700 p-3 rounded border border-slate-600">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-mono">{job.jobId.slice(0, 8)}</span>
                    <span>{job.vramConsumptionMB} MB VRAM</span>
                  </div>
                  <div className="text-sm font-medium mb-2 capitalize">{job.taskType}</div>
                  
                  {job.status === 'active' && (
                    <div className="w-full bg-slate-600 rounded-full h-2 mb-2 overflow-hidden">
                      <div className="bg-blue-500 h-2 transition-all duration-300" style={{ width: `${job.progress}%` }} />
                    </div>
                  )}

                  {job.status === 'active' || job.status === 'queued' ? (
                    <button
                      onClick={() => handleCancelJob(job.jobId)}
                      className="text-xs bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded w-full transition-colors"
                    >
                      Cancel Job
                    </button>
                  ) : null}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
