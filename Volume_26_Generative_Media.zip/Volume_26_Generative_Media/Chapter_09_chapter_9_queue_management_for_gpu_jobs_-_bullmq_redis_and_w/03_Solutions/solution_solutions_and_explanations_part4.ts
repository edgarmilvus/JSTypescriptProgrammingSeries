/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';

export interface GraphState {
  readonly currentNodeIndex: number;
  readonly pipelineId: string;
  readonly intermediateArtifacts: Readonly<Record<string, string>>;
  readonly accumulatedVRAMUsageMB: number;
}

// 1. RedisWorkflowCheckpointer Class implementing immutable state persistence
export class RedisWorkflowCheckpointer {
  constructor(private readonly redisClient: Redis) {}

  private getCheckpointerKey(jobId: string): string {
    return `workflow:checkpoint:${jobId}`;
  }

  // 2. Save state using Redis Hashes (HSET)
  public async saveState(jobId: string, state: Readonly<GraphState>): Promise<void> {
    const key = this.getCheckpointerKey(jobId);
    const serializedState = {
      currentNodeIndex: state.currentNodeIndex.toString(),
      pipelineId: state.pipelineId,
      intermediateArtifacts: JSON.stringify(state.intermediateArtifacts),
      accumulatedVRAMUsageMB: state.accumulatedVRAMUsageMB.toString(),
    };

    // Store as a Redis hash
    await this.redisClient.hset(key, serializedState);
    // Set a TTL of 24 hours to prevent stale Redis memory leaks
    await this.redisClient.expire(key, 86400);
  }

  // 2. Load state using Redis Hashes (HGETALL)
  public async loadState(jobId: string): Promise<Readonly<GraphState> | null> {
    const key = this.getCheckpointerKey(jobId);
    const rawData = await this.redisClient.hgetall(key);

    if (!rawData || Object.keys(rawData).length === 0) {
      return null;
    }

    // Enforce immutable state object construction upon hydration
    const hydratedState: Readonly<GraphState> = Object.freeze({
      currentNodeIndex: parseInt(rawData.currentNodeIndex, 10),
      pipelineId: rawData.pipelineId,
      intermediateArtifacts: Object.freeze(JSON.parse(rawData.intermediateArtifacts)),
      accumulatedVRAMUsageMB: parseInt(rawData.accumulatedVRAMUsageMB, 10),
    });

    return hydratedState;
  }

  public async clearState(jobId: string): Promise<void> {
    const key = this.getCheckpointerKey(jobId);
    await this.redisClient.del(key);
  }
}

// 3. Multi-step BullMQ Worker Processor integrated with Checkpointer
export interface PipelineJobData {
  readonly jobId: string;
  readonly pipelineSteps: readonly string[];
}

export async function processResumablePipeline(
  jobId: string,
  steps: readonly string[],
  checkpointer: RedisWorkflowCheckpointer
): Promise<void> {
  // Inspect checkpointer for existing execution state
  let currentState = await checkpointer.loadState(jobId);

  let startIndex = 0;
  let artifacts: Record<string, string> = {};
  let totalVRAM = 0;

  if (currentState) {
    console.log(`[Resumption Engine] Found valid checkpoint for job ${jobId} at node index ${currentState.currentNodeIndex}`);
    startIndex = currentState.currentNodeIndex + 1; // Resume from NEXT node
    artifacts = { ...currentState.intermediateArtifacts };
    totalVRAM = currentState.accumulatedVRAMUsageMB;
  } else {
    console.log(`[Resumption Engine] Initializing fresh execution graph for job ${jobId}`);
  }

  for (let i = startIndex; i < steps.length; i++) {
    const currentStepName = steps[i];
    console.log(`[Pipeline] Executing step ${i}: ${currentStepName}`);

    // Simulate WebGPU Kernel processing execution
    await new Promise((resolve) => setTimeout(resolve, 1500));
    artifacts[currentStepName] = `artifact_uri_${i}_${Date.now()}`;
    totalVRAM += 2048; // Mock VRAM accumulation

    // 4. Create immutable state transition snapshot and checkpoint to Redis
    const nextState: Readonly<GraphState> = Object.freeze({
      currentNodeIndex: i,
      pipelineId: jobId,
      intermediateArtifacts: Object.freeze({ ...artifacts }),
      accumulatedVRAMUsageMB: totalVRAM,
    });

    await checkpointer.saveState(jobId, nextState);
  }

  // Clear checkpoint upon successful workflow completion
  await checkpointer.clearState(jobId);
  console.log(`[Resumption Engine] Pipeline job ${jobId} completed successfully and checkpoint cleaned.`);
}
