/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// app/api/render-stream/route.ts
import { NextRequest } from 'next/server';

/**
 * Force the route to run on the Edge Runtime for optimal streaming support 
 * and zero cold-start overhead when handling persistent connections.
 */
export const runtime = 'edge';

/**
 * Handles incoming SSE connections from the node-based canvas UI.
 * Connects to the heavy backend generation worker and pipes progress updates.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const jobId = url.searchParams.get('jobId');

  if (!jobId) {
    return new Response(JSON.stringify({ error: 'Missing jobId parameter' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Create a TransformStream to handle piping and formatting SSE data chunks
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  // Establish a ReadableStream to stream data back to the client browser
  const customStream = new ReadableStream({
    async start(controller) {
      try {
        // Simulate or fetch from the actual AI media generation backend microservice
        // In a real SaaS setup, this would be an SSE or Webhook ingestion point
        const backendResponse = await fetch(`https://api.aicanvas-backend.internal/v1/jobs/${jobId}/stream`, {
          headers: {
            'Authorization': `Bearer ${process.env.INTERNAL_API_KEY}`,
            'Accept': 'text/event-stream',
          },
        });

        if (!backendResponse.ok || !backendResponse.body) {
          throw new Error(`Failed to connect to rendering backend: ${backendResponse.statusText}`);
        }

        const reader = backendResponse.body.getReader();

        // Read chunks from the AI backend and forward them to the client SSE connection
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunkText = decoder.decode(value, { stream: true });
          
          // Format as standard Server-Sent Events payload
          const sseFormattedData = `data: ${JSON.stringify({ raw: chunkText, timestamp: Date.now() })}\n\n`;
          controller.enqueue(encoder.encode(sseFormattedData));
        }
      } catch (error: any) {
        // Send error event down the SSE pipe before closing
        const errorPayload = `data: ${JSON.stringify({ error: error.message, status: 'FAILED' })}\n\n`;
        controller.enqueue(encoder.encode(errorPayload));
      } finally {
        controller.close();
      }
    },
  });

  // Return the stream with required headers for SSE compliance
  return new Response(customStream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
    },
  });
}

// ---------------------------------------------------------

// app/canvas/[jobId]/MediaNodeClient.tsx
'use client';

import React, { useEffect, useState } from 'react';

interface RenderProgress {
  status: string;
  progress: number;
  currentStep?: string;
  previewUrl?: string;
  error?: string;
}

/**
 * Client Component representing an interactive node on the AI canvas.
 * Subscribes to SSE streams to display real-time video/image generation progress.
 */
export default function MediaNodeClient({ jobId }: { jobId: string }) {
  const [renderState, setRenderState] = useState<RenderProgress>({
    status: 'INITIALIZING',
    progress: 0,
    currentStep: 'Allocating GPU workers...',
  });

  useEffect(() => {
    // Open a persistent SSE connection to our Next.js Edge route
    const eventSource = new EventSource(`/api/render-stream?jobId=${jobId}`);

    eventSource.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        
        // Handle custom error payloads pushed from the server stream
        if (parsed.status === 'FAILED') {
          setRenderState((prev) => ({ ...prev, status: 'FAILED', error: parsed.error }));
          eventSource.close();
          return;
        }

        // Attempt to parse the inner payload if it represents a structured JSON state from the backend
        let updateData;
        try {
          updateData = JSON.parse(parsed.raw);
        } catch {
          updateData = { currentStep: parsed.raw, progress: 50 };
        }

        setRenderState((prev) => ({
          ...prev,
          ...updateData,
          status: updateData.status || 'PROCESSING',
        }));
      } catch (err) {
        console.error('Failed to parse SSE message chunk:', err);
      }
    };

    eventSource.onerror = (err) => {
      console.error('SSE connection lost or errored:', err);
      setRenderState((prev) => ({ ...prev, status: 'DISCONNECTED', error: 'Stream connection lost.' }));
      eventSource.close();
    };

    // Cleanup connection when the component unmounts or jobId changes
    return () => {
      eventSource.close();
    };
  }, [jobId]);

  return (
    <div className="p-6 border rounded-xl shadow-lg bg-slate-900 text-white max-w-md">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">AI Generation Node</h3>
        <span className={`px-2 py-1 text-xs rounded font-semibold ${
          renderState.status === 'COMPLETED' ? 'bg-green-600' :
          renderState.status === 'FAILED' ? 'bg-red-600' : 'bg-amber-600 animate-pulse'
        }`}>
          {renderState.status}
        </span>
      </div>

      <div className="w-full bg-slate-700 rounded-full h-2.5 mb-4 overflow-hidden">
        <div 
          className="bg-blue-500 h-2.5 transition-all duration-300 ease-out" 
          style={{ width: `${renderState.progress}%` }}
        ></div>
      </div>

      <p className="text-sm text-slate-300 mb-2">
        <span className="font-semibold">Step:</span> {renderState.currentStep || 'Processing...'}
      </p>

      {renderState.previewUrl && (
        <div className="mt-4 rounded overflow-hidden border border-slate-700">
          <img src={renderState.previewUrl} alt="Live Generation Preview" className="w-full h-auto object-cover" />
        </div>
      )}

      {renderState.error && (
        <div className="mt-4 p-3 bg-red-950 border border-red-800 rounded text-red-200 text-xs">
          {renderState.error}
        </div>
      )}
    </div>
  );
}
