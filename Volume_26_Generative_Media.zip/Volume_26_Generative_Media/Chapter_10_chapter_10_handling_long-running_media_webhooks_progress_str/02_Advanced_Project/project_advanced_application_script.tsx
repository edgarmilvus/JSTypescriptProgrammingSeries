/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file media-workflow-engine.tsx
 * @description Enterprise-grade TypeScript implementation for handling long-running
 * media generation webhooks and real-time Server-Sent Events (SSE) streaming
 * inside a Next.js App Router environment.
 */

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { NextResponse, NextRequest } from 'next/server';

// ==========================================
// 1. TYPES & INTERFACES
// ==========================================

export type JobStatus = 'queued' | 'processing' | 'rendering' | 'completed' | 'failed';

export interface MediaJobPayload {
  jobId: string;
  nodeId: string;
  status: JobStatus;
  progress: number; // 0 to 100
  currentStage: string;
  mediaUrl?: string;
  error?: string;
}

// Global subscriber map for SSE connection management (Node.js runtime memory)
// In distributed environments, replace this with a Redis Pub/Sub adapter.
class EventBroker {
  private static subscribers = new Map<string, ReadableStreamDefaultController[]>();

  static subscribe(jobId: string, controller: ReadableStreamDefaultController) {
    if (!this.subscribers.has(jobId)) {
      this.subscribers.set(jobId, []);
    }
    this.subscribers.get(jobId)!.push(controller);
  }

  static unsubscribe(jobId: string, controller: ReadableStreamDefaultController) {
    const list = this.subscribers.get(jobId);
    if (!list) return;
    const index = list.indexOf(controller);
    if (index !== -1) {
      list.splice(index, 1);
    }
    if (list.length === 0) {
      this.subscribers.delete(jobId);
    }
  }

  static broadcast(jobId: string, data: MediaJobPayload) {
    const list = this.subscribers.get(jobId);
    if (!list) return;
    const encoder = new TextEncoder();
    const message = `data: ${JSON.stringify(data)}\n\n`;
    const encoded = encoder.encode(message);

    for (const controller of list) {
      try {
        controller.enqueue(encoded);
      } catch (err) {
        console.error(`Failed to push to controller for job ${jobId}:`, err);
      }
    }
  }
}

// ==========================================
// 2. BACKEND: WEBHOOK INGESTION ENDPOINT
// File: app/api/webhooks/media/route.ts
// ==========================================

export async function POST(req: NextRequest) {
  try {
    const body: MediaJobPayload = await req.json();
    
    // Validate mandatory payload properties
    if (!body.jobId || !body.status) {
      return NextResponse.json({ error: 'Missing required properties' }, { status: 400 });
    }

    // Cryptographic signature verification should be implemented here in production
    // e.g., verifyXHubSignature(req, process.env.WEBHOOK_SECRET);

    console.log(`[Webhook Ingest] Job ${body.jobId} -> Status: ${body.status} (${body.progress}%)`);

    // Broadcast the update immediately to all listening SSE connections for this job
    EventBroker.broadcast(body.jobId, body);

    return NextResponse.json({ success: true, receivedAt: new Date().toISOString() });
  } catch (error) {
    console.error('[Webhook Ingest Error]:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

// ==========================================
// 3. BACKEND: SSE STREAMING ENDPOINT
// File: app/api/jobs/[jobId]/stream/route.ts
// ==========================================

export async function GET(
  req: NextRequest,
  { params }: { params: { jobId: string } }
) {
  const { jobId } = params;

  const stream = new ReadableStream({
    start(controller) {
      // Register this client connection
      EventBroker.subscribe(jobId, controller);

      // Send initial heartbeat connection confirmation
      const encoder = new TextEncoder();
      controller.enqueue(encoder.encode(`data: ${JSON.stringify({ jobId, status: 'connected' })}\n\n`));

      // Keep connection alive with periodic pings handled outside or cleanup on close
      req.signal.addEventListener('abort', () => {
        EventBroker.unsubscribe(jobId, controller);
        try {
          controller.close();
        } catch {
          // Controller might already be closed
        }
      });
    },
    cancel() {
      // Stream canceled by client
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
    },
  });
}

// ==========================================
// 4. FRONTEND: REACT NODE CANVAS COMPONENT
// ==========================================

interface MediaNodeProps {
  nodeId: string;
  jobId: string;
  title: string;
}

export function MediaWorkflowCanvasNode({ nodeId, jobId, title }: MediaNodeProps) {
  const [jobState, setJobState] = useState<MediaJobPayload>({
    jobId,
    nodeId,
    status: 'queued',
    progress: 0,
    currentStage: 'Waiting in render queue...',
  });
  
  const eventSourceRef = useRef<EventSource | null>(null);

  // Establish and manage SSE connection
  useEffect(() => {
    const eventSource = new EventSource(`/api/jobs/${jobId}/stream`);
    eventSourceRef.current = eventSource;

    eventSource.onmessage = (event) => {
      try {
        const data: MediaJobPayload = JSON.parse(event.data);
        if (data.status && data.status !== ('connected' as any)) {
          setJobState(data);
          
          // Close stream automatically if terminal state is reached
          if (data.status === 'completed' || data.status === 'failed') {
            eventSource.close();
          }
        }
      } catch (err) {
        console.error('Failed to parse SSE event data:', err);
      }
    };

    eventSource.onerror = (err) => {
      console.error('SSE connection error:', err);
      eventSource.close();
    };

    // Cleanup connection on unmount
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [jobId]);

  return (
    <div className="border border-slate-700 bg-slate-900 rounded-lg p-4 w-80 shadow-xl text-slate-100">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold text-sm tracking-wide">{title}</h3>
        <span className={`text-xs px-2 py-0.5 rounded uppercase font-bold ${
          jobState.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' :
          jobState.status === 'failed' ? 'bg-rose-500/20 text-rose-400' :
          'bg-amber-500/20 text-amber-400 animate-pulse'
        }`}>
          {jobState.status}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800 rounded-full h-2 mb-3 overflow-hidden">
        <div 
          className="bg-indigo-500 h-full transition-all duration-300 ease-out" 
          style={{ width: `${jobState.progress}%` }}
        />
      </div>

      <div className="text-xs text-slate-400 mb-2 truncate">
        {jobState.currentStage}
      </div>

      {/* Media Preview Box */}
      {jobState.status === 'completed' && jobState.mediaUrl && (
        <div className="mt-2 rounded overflow-hidden border border-slate-700">
          <video src={jobState.mediaUrl} controls className="w-full h-32 object-cover" />
        </div>
      )}

      {jobState.status === 'failed' && (
        <div className="mt-2 text-xs text-rose-400 bg-rose-950/40 p-2 rounded border border-rose-900/50">
          Error: {jobState.error || 'Unknown processing failure'}
        </div>
      )}
    </div>
  );
}
