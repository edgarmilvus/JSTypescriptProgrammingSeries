/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response, NextRequest } from 'express';
import crypto from 'crypto';

interface WebhookPayload {
  eventId: string;
  generationId: string;
  status: 'queued' | 'progress' | 'completed' | 'failed';
  progress?: number;
  step?: string;
  assetUrl?: string;
  error?: string;
}

// In-memory cache for idempotency and replay prevention
const processedWebhookIds = new Set<string>();

/**
 * Performs a constant-time comparison of cryptographic signatures to prevent timing attacks.
 */
export function verifyWebhookSignature(payload: string, signatureHeader: string, secret: string): boolean {
  try {
    const computedSignature = `sha256=${crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex')}`;

    const signatureBuffer = Buffer.from(signatureHeader, 'utf8');
    const computedBuffer = Buffer.from(computedSignature, 'utf8');

    if (signatureBuffer.length !== computedBuffer.length) {
      return false;
    }

    return crypto.timingSafeEqual(signatureBuffer, computedBuffer);
  } catch (error) {
    return false;
  }
}

/**
 * Express middleware or handler for robust webhook ingestion
 */
export async function handleMediaWebhook(req: Request, res: Response): Promise<void> {
  const webhookSecret = process.env.WEBHOOK_SECRET || 'default_test_secret';
  const signature = req.headers['x-signature'] as string;
  const timestampHeader = req.headers['x-timestamp'] as string;
  const webhookId = req.headers['x-webhook-id'] as string;

  if (!signature || !timestampHeader || !webhookId) {
    res.status(400).json({ error: 'Missing required security headers (x-signature, x-timestamp, x-webhook-id).' });
    return;
  }

  // 1. Enforce timestamp validation (Reject payloads older than 5 minutes)
  const requestTimestamp = parseInt(timestampHeader, 10);
  const currentTimestamp = Date.now();
  const toleranceMs = 5 * 60 * 1000;

  if (isNaN(requestTimestamp) || Math.abs(currentTimestamp - requestTimestamp) > toleranceMs) {
    res.status(400).json({ error: 'Invalid or expired timestamp. Potential replay attack detected.' });
    return;
  }

  // 2. Verify signature using raw body representation
  const rawBody = (req as any).rawBody || JSON.stringify(req.body);
  const isValidSignature = verifyWebhookSignature(rawBody, signature, webhookSecret);

  if (!isValidSignature) {
    res.status(401).json({ error: 'Cryptographic signature mismatch.' });
    return;
  }

  // 3. Enforce Idempotency Layer
  if (processedWebhookIds.has(webhookId)) {
    res.status(200).json({ status: 'acknowledged', message: 'Event already processed (idempotent duplicate).' });
    return;
  }

  const payload: WebhookPayload = req.body;

  try {
    // 4. Process event types based on workflow state
    switch (payload.status) {
      case 'queued':
        console.log(`[Webhook] Generation ${payload.generationId} queued.`);
        break;
      case 'progress':
        console.log(`[Webhook] Generation ${payload.generationId} at ${payload.progress}% - Step: ${payload.step}`);
        break;
      case 'completed':
        console.log(`[Webhook] Generation ${payload.generationId} completed. Asset: ${payload.assetUrl}`);
        break;
      case 'failed':
        console.error(`[Webhook] Generation ${payload.generationId} failed: ${payload.error}`);
        break;
      default:
        res.status(400).json({ error: 'Unknown generation status type.' });
        return;
    }

    // Mark webhook ID as processed
    processedWebhookIds.add(webhookId);

    res.status(200).json({ status: 'success', eventId: payload.eventId });
  } catch (processingError) {
    console.error('[Webhook] Internal error processing event payload:', processingError);
    res.status(500).json({ error: 'Internal server error while processing webhook.' });
  }
}
