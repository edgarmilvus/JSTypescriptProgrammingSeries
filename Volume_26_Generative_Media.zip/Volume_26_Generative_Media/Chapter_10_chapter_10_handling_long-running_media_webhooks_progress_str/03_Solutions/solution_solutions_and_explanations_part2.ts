/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export class SSEConnectionManager {
  private url: string;
  private eventSource: EventSource | null = null;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private baseDelay = 1000; // 1 second
  private maxDelay = 30000; // 30 seconds
  private heartbeatTimeoutMs = 15000; // 15 seconds threshold
  private lastEventId: string | null = null;
  private eventCallbacks: Map<string, (data: any) => void> = new Map();
  private isManuallyClosed = false;

  constructor(url: string) {
    this.url = url;
  }

  public on(event: string, callback: (data: any) => void): void {
    this.eventCallbacks.set(event, callback);
  }

  public connect(): void {
    if (this.isManuallyClosed) return;

    const urlWithLastId = this.lastEventId 
      ? `${this.url}?lastEventId=${encodeURIComponent(this.lastEventId)}` 
      : this.url;

    this.eventSource = new EventSource(urlWithLastId);

    this.eventSource.onopen = () => {
      this.reconnectAttempts = 0;
      this.resetHeartbeatWatchdog();
    };

    this.eventSource.onmessage = (event) => {
      this.handleIncomingData('message', event);
    };

    // Register listeners for custom event channels
    const customEvents = ['progress', 'heartbeat', 'error', 'completed', 'queued'];
    customEvents.forEach((eventType) => {
      this.eventSource?.addEventListener(eventType, (event: MessageEvent) => {
        this.handleIncomingData(eventType, event);
      });
    });

    this.eventSource.onerror = () => {
      this.handleConnectionFailure();
    };
  }

  private handleIncomingData(eventType: string, event: MessageEvent): void {
    if (event.lastEventId) {
      this.lastEventId = event.lastEventId;
    }

    if (eventType === 'heartbeat') {
      this.resetHeartbeatWatchdog();
      return;
    }

    // Reset watchdog on any valid data payload
    this.resetHeartbeatWatchdog();

    const callback = this.eventCallbacks.get(eventType);
    if (callback) {
      try {
        const parsedData = JSON.parse(event.data);
        callback(parsedData);
      } catch (err) {
        callback(event.data);
      }
    }
  }

  private resetHeartbeatWatchdog(): void {
    if (this.heartbeatTimer) {
      clearTimeout(this.heartbeatTimer);
    }

    this.heartbeatTimer = setTimeout(() => {
      this.handleHeartbeatTimeout();
    }, this.heartbeatTimeoutMs);
  }

  private handleHeartbeatTimeout(): void {
    console.warn('[SSEManager] Heartbeat timeout expired. Connection is stale. Forcing reconnect...');
    this.closeSocket();
    this.attemptReconnect();
  }

  private handleConnectionFailure(): void {
    this.closeSocket();
    this.attemptReconnect();
  }

  private attemptReconnect(): void {
    if (this.isManuallyClosed) return;

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('[SSEManager] Max reconnection attempts reached. Giving up.');
      const errorCallback = this.eventCallbacks.get('error');
      if (errorCallback) errorCallback({ message: 'Max reconnection limits exceeded' });
      return;
    }

    // Exponential Backoff with Jitter formula: min(maxDelay, baseDelay * 2^attempt) + randomJitter
    const exponentialDelay = Math.min(
      this.maxDelay,
      this.baseDelay * Math.pow(2, this.reconnectAttempts)
    );
    const jitter = Math.random() * 1000;
    const totalDelay = exponentialDelay + jitter;

    this.reconnectAttempts++;
    console.log(`[SSEManager] Reconnecting in ${Math.round(totalDelay)}ms (Attempt ${this.reconnectAttempts})`);

    setTimeout(() => {
      this.connect();
    }, totalDelay);
  }

  private closeSocket(): void {
    if (this.heartbeatTimer) {
      clearTimeout(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
  }

  public disconnect(): void {
    this.isManuallyClosed = true;
    this.closeSocket();
    this.eventCallbacks.clear();
    console.log('[SSEManager] Disconnected cleanly and resources released.');
  }
}
