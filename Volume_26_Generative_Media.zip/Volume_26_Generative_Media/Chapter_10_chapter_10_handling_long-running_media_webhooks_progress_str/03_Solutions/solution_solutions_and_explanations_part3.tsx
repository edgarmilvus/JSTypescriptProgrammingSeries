/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

type NodeState = 
  | { status: 'idle' }
  | { status: 'queued'; queuePosition: number }
  | { status: 'processing'; progress: number; currentStep: string }
  | { status: 'completed'; assetUrl: string }
  | { status: 'error'; message: string };

interface MediaCanvasNodeProps {
  nodeId: string;
  initialState: NodeState;
  onCancel: (nodeId: string) => void;
  onRetry: (nodeId: string) => void;
}

export const MediaCanvasNode: React.FC<MediaCanvasNodeProps> = ({
  nodeId,
  initialState,
  onCancel,
  onRetry,
}) => {
  const [state, setState] = useState<NodeState>(initialState);
  const [displayedProgress, setDisplayedProgress] = useState<number>(0);
  
  // Refs for requestAnimationFrame interpolation tracking
  const targetProgressRef = useRef<number>(0);
  const currentProgressRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);

  // Synchronize target progress when state updates
  useEffect(() => {
    if (state.status === 'processing') {
      targetProgressRef.current = state.progress;
      startInterpolation();
    } else if (state.status === 'completed') {
      targetProgressRef.current = 100;
      setDisplayedProgress(100);
    } else {
      targetProgressRef.current = 0;
      setDisplayedProgress(0);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [state]);

  const startInterpolation = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    const animate = () => {
      const diff = targetProgressRef.current - currentProgressRef.current;
      if (Math.abs(diff) > 0.1) {
        // Ease towards target smoothly (lerp factor: 0.1)
        currentProgressRef.current += diff * 0.1;
        setDisplayedProgress(currentProgressRef.current);
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        currentProgressRef.current = targetProgressRef.current;
        setDisplayedProgress(targetProgressRef.current);
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);
  };

  return (
    <div className="canvas-node border rounded-lg p-4 shadow-md bg-white w-80 font-sans">
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Node: {nodeId}</span>
        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
          state.status === 'completed' ? 'bg-green-100 text-green-800' :
          state.status === 'processing' ? 'bg-blue-100 text-blue-800' :
          state.status === 'queued' ? 'bg-yellow-100 text-yellow-800' :
          state.status === 'error' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
        }`}>
          {state.status.toUpperCase()}
        </span>
      </div>

      {state.status === 'idle' && (
        <div className="text-gray-400 text-sm py-4 text-center">Idle. Awaiting workflow trigger.</div>
      )}

      {state.status === 'queued' && (
        <div className="py-4 text-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-yellow-500 mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Position in queue: #{state.queuePosition}</p>
        </div>
      )}

      {state.status === 'processing' && (
        <div className="py-2 space-y-3">
          <div className="flex justify-between text-xs text-gray-600">
            <span>{state.currentStep}</span>
            <span>{Math.round(displayedProgress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-blue-600 h-2 transition-all duration-75 ease-out" 
              style={{ width: `${displayedProgress}%` }}
            />
          </div>
          <button 
            onClick={() => onCancel(nodeId)}
            className="w-full mt-2 py-1.5 px-3 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-medium rounded transition-colors"
          >
            Cancel Generation
          </button>
        </div>
      )}

      {state.status === 'completed' && (
        <div className="space-y-3">
          <div className="relative aspect-video rounded overflow-hidden bg-gray-100 border">
            <img src={state.assetUrl} alt="Generated Asset" className="object-cover w-full h-full" />
          </div>
          <a 
            href={state.assetUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block text-center w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded"
          >
            Download Asset
          </a>
        </div>
      )}

      {state.status === 'error' && (
        <div className="space-y-3 py-2">
          <p className="text-xs text-red-600 bg-red-50 p-2 rounded border border-red-200">{state.message}</p>
          <button 
            onClick={() => onRetry(nodeId)}
            className="w-full py-1.5 bg-gray-900 hover:bg-black text-white text-xs font-medium rounded transition-colors"
          >
            Retry Generation
          </button>
        </div>
      )}
    </div>
  );
};
