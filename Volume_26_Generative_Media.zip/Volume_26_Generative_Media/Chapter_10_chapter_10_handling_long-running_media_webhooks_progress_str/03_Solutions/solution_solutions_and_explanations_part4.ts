/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface CanvasNodeData {
  id: string;
  status: 'optimistic_pending' | 'confirmed' | 'failed';
  assetUrl?: string;
  timestamp: number;
}

interface CanvasState {
  nodes: ReadonlyMap<string, CanvasNodeData>;
  history: ReadonlyArray<ReadonlyMap<string, CanvasNodeData>>;
}

export class CanvasReconciliationEngine {
  private state: CanvasState;
  private timeoutTimers: Map<string, NodeJS.Timeout> = new Map();
  private rollbackTimeoutMs = 30000; // 30 seconds

  constructor(initialNodes: Map<string, CanvasNodeData>) {
    this.state = {
      nodes: new Map(initialNodes),
      history: []
    };
  }

  public getState(): CanvasState {
    return this.state;
  }

  public applyOptimisticUpdate(nodeId: string, optimisticData: CanvasNodeData): void {
    // 1. Snapshot current state into history buffer for potential rollback
    const currentNodesSnapshot = new Map(this.state.nodes);
    
    // 2. Apply immutable update with 'optimistic_pending' status
    const updatedNodes = new Map(this.state.nodes);
    updatedNodes.set(nodeId, {
      ...optimisticData,
      status: 'optimistic_pending',
      timestamp: Date.now()
    });

    this.state = {
      nodes: updatedNodes,
      history: [...this.state.history, currentNodesSnapshot]
    };

    // 3. Schedule 30-second timeout rollback buffer
    if (this.timeoutTimers.has(nodeId)) {
      clearTimeout(this.timeoutTimers.get(nodeId)!);
    }

    const timer = setTimeout(() => {
      this.rollbackTransaction(nodeId);
    }, this.rollbackTimeoutMs);

    this.timeoutTimers.set(nodeId, timer);
  }

  public reconcileServerConfirmation(nodeId: string, confirmedData: Partial<CanvasNodeData>): void {
    // Clear timeout safeguard upon receiving server confirmation
    if (this.timeoutTimers.has(nodeId)) {
      clearTimeout(this.timeoutTimers.get(nodeId)!);
      this.timeoutTimers.delete(nodeId);
    }

    const node = this.state.nodes.get(nodeId);
    if (!node) return;

    const updatedNodes = new Map(this.state.nodes);
    updatedNodes.set(nodeId, {
      ...node,
      ...confirmedData,
      status: confirmedData.status || 'confirmed'
    });

    this.state = {
      ...this.state,
      nodes: updatedNodes
    };
  }

  public rollbackTransaction(nodeId: string): void {
    if (this.timeoutTimers.has(nodeId)) {
      clearTimeout(this.timeoutTimers.get(nodeId)!);
      this.timeoutTimers.delete(nodeId);
    }

    const previousSnapshot = this.state.history[this.state.history.length - 1];
    if (!previousSnapshot) {
      console.warn(`[ReconciliationEngine] No history snapshot available to rollback node ${nodeId}`);
      return;
    }

    console.warn(`[ReconciliationEngine] Timeout reached for node ${nodeId}. Rolling back state snapshot.`);

    const revertedNodes = new Map(previousSnapshot);
    
    this.state = {
      nodes: revertedNodes,
      history: this.state.history.slice(0, -1) // Pop history stack
    };
  }
}
