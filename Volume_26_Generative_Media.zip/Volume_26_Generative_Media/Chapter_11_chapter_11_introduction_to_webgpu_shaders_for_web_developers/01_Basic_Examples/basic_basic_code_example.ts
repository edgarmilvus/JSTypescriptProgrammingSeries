/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ImageInversionPipeline.ts
 * @description A self-contained TypeScript and WebGPU compute shader implementation
 * for real-time image color inversion within a browser-based media workflow engine.
 */

export class ImageInversionPipeline {
    private adapter: GPUAdapter | null = null;
    private device: GPUDevice | null = null;
    private computePipeline: GPUComputePipeline | null = null;
    private bindGroupLayout: GPUBindGroupLayout | null = null;

    /**
     * Initializes the WebGPU context, requesting high-performance adapters and logical devices.
     * @throws {Error} If WebGPU is not supported or device initialization fails.
     */
    public async initialize(): Promise<void> {
        // 1. Verify browser support for WebGPU
        if (!navigator.gpu) {
            throw new Error("WebGPU is not supported in this browser. Ensure chrome://flags or appropriate flags are enabled.");
        }

        // 2. Request a physical adapter (GPU) with high-performance preference
        this.adapter = await navigator.gpu.requestAdapter({
            powerPreference: "high-performance",
        });

        if (!this.adapter) {
            throw new Error("Failed to find an appropriate GPU adapter.");
        }

        // 3. Request logical device connection
        this.device = await this.adapter.requestDevice();

        // 4. Define the WGSL (WebGPU Shading Language) compute shader source code.
        // This shader processes a 2D grid of pixels, reading an RGBA color value,
        // inverting the RGB channels (1.0 - channel), and writing to an output buffer.
        const shaderCode = /* wgsl */ `
            @group(0) @binding(0) var<storage, read> inputBuffer: array<f32>;
            @group(0) @binding(1) var<storage, write> outputBuffer: array<f32>;

            @compute @workgroup_size(64)
            fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
                let index = global_id.x;
                
                // Ensure we don't read/write out of bounds
                if (index < arrayLength(&inputBuffer)) {
                    // Assuming RGBA layout where every 4 elements represent one pixel (R, G, B, A)
                    // We only invert R, G, and B; Alpha remains untouched.
                    let channelMod = index % 4u;
                    if (channelMod < 3u) {
                        outputBuffer[index] = 1.0 - inputBuffer[index];
                    } else {
                        outputBuffer[index] = inputBuffer[index];
                    }
                }
            }
        `;

        // 5. Create shader module from WGSL source
        const shaderModule = this.device.createShaderModule({
            code: shaderCode,
        });

        // 6. Create the compute pipeline layout and pipeline
        this.computePipeline = await this.device.createComputePipelineAsync({
            layout: "auto",
            compute: {
                module: shaderModule,
                entryPoint: "main",
            },
        });

        // Cache the automatically generated bind group layout
        this.bindGroupLayout = this.computePipeline.getBindGroupLayout(0);
    }

    /**
     * Processes a Float32Array of pixel data through the WebGPU compute pipeline.
     * @param inputPixels Raw pixel data represented as RGBA floats between 0.0 and 1.0.
     * @returns A Promise resolving to the processed Float32Array containing inverted colors.
     */
    public async processPixels(inputPixels: Float32Array): Promise<Float32Array> {
        if (!this.device || !this.computePipeline || !this.bindGroupLayout) {
            throw new Error("ImageInversionPipeline has not been initialized. Call initialize() first.");
        }

        const byteLength = inputPixels.byteLength;

        // 1. Create GPU-side input storage buffer (MAP_READ is not required here since it's only written by CPU and read by GPU)
        const gpuInputBuffer = this.device.createBuffer({
            size: byteLength,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });

        // 2. Write input pixel data from CPU to GPU input buffer
        this.device.queue.writeBuffer(gpuInputBuffer, 0, inputPixels);

        // 3. Create GPU-side output storage buffer
        const gpuOutputBuffer = this.device.createBuffer({
            size: byteLength,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
        });

        // 4. Create a staging buffer on the GPU for reading back data to CPU
        const cpuReadBuffer = this.device.createBuffer({
            size: byteLength,
            usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
        });

        // 5. Bind buffers to pipeline resource slots
        const bindGroup = this.device.createBindGroup({
            layout: this.bindGroupLayout,
            entries: [
                { binding: 0, resource: { buffer: gpuInputBuffer } },
                { binding: 1, resource: { buffer: gpuOutputBuffer } },
            ],
        });

        // 6. Record GPU command buffer
        const commandEncoder = this.device.createCommandEncoder();
        const passEncoder = commandEncoder.beginComputePass();
        passEncoder.setPipeline(this.computePipeline);
        passEncoder.setBindGroup(0, bindGroup);

        // Calculate workgroup dispatches (64 threads per workgroup based on shader definition)
        const totalElements = inputPixels.length;
        const workgroupCount = Math.ceil(totalElements / 64);
        passEncoder.dispatchWorkgroups(workgroupCount);
        passEncoder.end();

        // Copy GPU output buffer to staging CPU-readable buffer
        commandEncoder.copyBufferToBuffer(gpuOutputBuffer, 0, cpuReadBuffer, 0, byteLength);

        // Finish recording commands and submit to GPU queue
        const commandBuffer = commandEncoder.finish();
        this.device.queue.submit([commandBuffer]);

        // 7. Map the staging buffer to read results back into CPU memory
        await cpuReadBuffer.mapAsync(GPUMapMode.READ);
        const mappedRange = cpuReadBuffer.getMappedRange();
        const resultPixels = new Float32Array(mappedRange.slice(0));
        
        // Clean up buffer mappings
        cpuReadBuffer.unmap();

        // 8. Explicitly destroy temporary GPU buffers to prevent memory leaks
        gpuInputBuffer.destroy();
        gpuOutputBuffer.destroy();
        cpuReadBuffer.destroy();

        return resultPixels;
    }
}
