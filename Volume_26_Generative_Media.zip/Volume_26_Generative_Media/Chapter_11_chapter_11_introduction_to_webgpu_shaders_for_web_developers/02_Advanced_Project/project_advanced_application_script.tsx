/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'തായി';

/**
 * WGSL Compute Shader source code.
 * Performs parallel per-pixel color inversion and chromatic shift 
 * directly on a storage buffer representing a 2D image plane.
 */
const COMPUTE_SHADER_WGSL = /* wgsl */ `
@group(0) @binding(0) var<storage, read_write> pixelBuffer: array<u32>;
@group(0) @binding(1) var<uniform> uniforms: Uniforms;

struct Uniforms {
  width: u32,
  height: u32,
  time: f32,
  intensity: f32,
}

// Convert linear u32 RGBA to individual f32 channels
fn unpack_rgba(val: u32) -> vec4<f32> {
  let r = f32(val & 0xFFu);
  let g = f32((val >> 8u) & 0xFFu);
  let b = f32((val >> 16u) & 0xFFu);
  let a = f32((val >> 24u) & 0xFFu);
  return vec4<f32>(r, g, b, a) / 255.0;
}

// Pack individual f32 channels back into a single u32 RGBA value
fn pack_rgba(color: vec4<f32>) -> u32 {
  let clamped = clamp(color * 255.0, vec4<f32>(0.0), vec4<f32>(255.0));
  return u32(clamped.r) |
        (u32(clamped.g) << 8u) |
        (u32(clamped.b) << 16u) |
        (u32(clamped.a) << 24u);
}

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
  let x = global_id.x;
  let y = global_id.y;
  
  if (x >= uniforms.width || y >= uniforms.height) {
    return;
  }

  let index = y * uniforms.width + x;
  let current_color = unpack_rgba(pixelBuffer[index]);

  // Apply real-time procedural color transformation based on time uniform
  let wave = sin(uniforms.time + f32(y) * 0.05) * 0.5 + 0.5;
  
  var transformed = current_color;
  // Shift channels dynamically to simulate generative aberration
  transformed.r = mix(current_color.r, 1.0 - current_color.r, uniforms.intensity);
  transformed.g = mix(current_color.g, wave, uniforms.intensity * 0.5);

  pixelBuffer[index] = pack_rgba(transformed);
}
`;

interface WebGPUCanvasProps {
  width?: number;
  height?: number;
}

export default function AdvancedWebGPUCanvas({ width = 512, height = 512 }: WebGPUCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<string>('Initializing WebGPU Pipeline...');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  useEffect(() => {
    let animationFrameId: number;
    let gpuDevice: GPUDevice;
    let computePipeline: GPUComputePipeline;
    let bindGroup: GPUBindGroup;
    let storageBuffer: GPUBuffer;
    let uniformBuffer: GPUBuffer;
    let stagingBuffer: GPUBuffer;

    async function initWebGPU() {
      // 1. Verify WebGPU availability in the browser runtime
      if (!navigator.gpu) {
        setStatus('WebGPU is not supported on this browser/environment.');
        return;
      }

      // 2. Request high-performance adapter and logical device
      const adapter = await navigator.gpu.requestAdapter({
        powerPreference: 'high-performance',
      });
      if (!adapter) {
        setStatus('No appropriate GPUAdapter found.');
        return;
      }

      gpuDevice = await adapter.requestDevice();
      setStatus('GPU Device acquired successfully.');

      // 3. Initialize buffer sizes and data allocations
      const numPixels = width * height;
      const bufferSize = numPixels * Uint32Array.BYTES_PER_ELEMENT;

      // Create storage buffer for raw pixel manipulation
      storageBuffer = gpuDevice.createBuffer({
        size: bufferSize,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
      });

      // Create uniform buffer for pipeline parameters (width, height, time, intensity)
      const uniformSize = 16; // 2 u32s (8 bytes) + 2 f32s (8 bytes) = 16 bytes aligned
      uniformBuffer = gpuDevice.createBuffer({
        size: uniformSize,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
      });

      // Create staging buffer to read back processed data to CPU memory
      stagingBuffer = gpuDevice.createBuffer({
        size: bufferSize,
        usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
      });

      // 4. Create Shader Module and Compute Pipeline
      const shaderModule = gpuDevice.createShaderModule({
        code: COMPUTE_SHADER_WGSL,
      });

      computePipeline = await gpuDevice.createComputePipelineAsync({
        layout: 'auto',
        compute: {
          module: shaderModule,
          entryPoint: 'main',
        },
      });

      // 5. Establish Bind Group matching shader bindings
      bindGroup = gpuDevice.createBindGroup({
        layout: computePipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: storageBuffer } },
          { binding: 1, resource: { buffer: uniformBuffer } },
        ],
      });

      // Seed initial dummy pixel data (e.g., gradient grid)
      const initialPixels = new Uint32Array(numPixels);
      for (let i = 0; i < numPixels; i++) {
        const x = i % width;
        const y = Math.floor(i / width);
        const r = (x / width) * 255;
        const g = (y / height) * 255;
        const b = 128;
        const a = 255;
        initialPixels[i] = (a << 24) | (b << 16) | (g << 8) | r;
      }
      gpuDevice.queue.writeBuffer(storageBuffer, 0, initialPixels);

      setIsProcessing(true);
      setStatus('Pipeline active. Running compute passes...');

      let startTime = performance.now();

      // 6. Define the Render Loop
      const renderLoop = async () => {
        const currentTime = (performance.now() - startTime) * 0.001;

        // Update uniforms dynamically for each frame
        const uniformData = new ArrayBuffer(16);
        const viewU32 = new Uint32Array(uniformData);
        const viewF32 = new Float32Array(uniformData);
        viewU32[0] = width;
        viewU32[1] = height;
        viewF32[2] = currentTime;
        viewF32[3] = 0.75; // Intensity factor

        gpuDevice.queue.writeBuffer(uniformBuffer, 0, uniformData);

        // Encode GPU commands
        const commandEncoder = gpuDevice.createCommandEncoder();
        const passEncoder = commandEncoder.beginComputePass();
        passEncoder.setPipeline(computePipeline);
        passEncoder.setBindGroup(0, bindGroup);

        // Dispatch workgroups matching workgroup_size(16, 16)
        const workgroupCountX = Math.ceil(width / 16);
        const workgroupCountY = Math.ceil(height / 16);
        passEncoder.dispatchWorkgroups(workgroupCountX, workgroupCountY);
        passEncoder.end();

        // Copy storage buffer to staging buffer for CPU readback
        commandEncoder.copyBufferToBuffer(storageBuffer, 0, stagingBuffer, 0, bufferSize);
        gpuDevice.queue.submit([commandEncoder.finish()]);

        // Map staging buffer to read pixels back to HTML5 Canvas context
        await stagingBuffer.mapAsync(GPUMapMode.READ);
        const mappedRange = stagingBuffer.getMappedRange();
        const data = new Uint8ClampedArray(mappedRange);

        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const imgData = new ImageData(data, width, height);
            ctx.putImageData(imgData, 0, 0);
          }
        }

        stagingBuffer.unmap();

        animationFrameId = requestAnimationFrame(renderLoop);
      };

      animationFrameId = requestAnimationFrame(renderLoop);
    }

    initWebGPU();

    return () => {
      cancelAnimationFrame(animationFrameId);
      setIsProcessing(false);
    };
  }, [width, height]);

  return (
    <div className="flex flex-col items-center p-6 bg-slate-900 rounded-xl border border-slate-700 shadow-2xl">
      <div className="mb-4 text-sm font-mono text-cyan-400">
        Status: <span className="text-white">{status}</span>
      </div>
      <div className="relative border-2 border-slate-700 rounded-lg overflow-hidden bg-black">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="block w-full h-auto max-w-[512px] max-h-[512px]"
        />
        {isProcessing && (
          <div className="absolute top-2 right-2 px-2 py-1 bg-emerald-500/20 border border-emerald-500 text-emerald-300 text-xs rounded font-mono animate-pulse">
            GPU ACTIVE (WGSL)
          </div>
        )}
      </div>
    </div>
  );
}
