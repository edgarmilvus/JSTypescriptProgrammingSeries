/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export async function runPixelInversionPipeline(
  inputPixels: Uint32Array,
  width: number,
  height: number
): Promise<Uint32Array> {
  // 1. Initialize WebGPU device and adapter
  if (!navigator.gpu) {
    throw new Error("WebGPU is not supported in this browser.");
  }
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) {
    throw new Error("No appropriate GPUAdapter found.");
  }
  const device = await adapter.requestDevice();

  const bufferSize = inputPixels.byteLength;

  // 2. Create GPU buffers for storage and staging
  // Storage buffer for compute shader read/write
  const storageBuffer = device.createBuffer({
    size: bufferSize,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
  });

  // Staging buffer for CPU read-back
  const stagingBuffer = device.createBuffer({
    size: bufferSize,
    usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
  });

  // Write initial pixel data to the storage buffer
  device.queue.writeBuffer(storageBuffer, 0, inputPixels.buffer);

  // 3. Define the WGSL compute shader source
  const computeShaderCode = `
    @group(0) @binding(0) var<storage, read_write> pixels: array<u32>;

    @compute @workgroup_size(16, 16)
    fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
      let width = ${width}u;
      let height = ${height}u;

      if (global_id.x >= width || global_id.y >= height) {
        return;
      }

      let index = global_id.y * width + global_id.x;
      let pixel = pixels[index];

      // Extract RGBA components (assuming packed u32 RGBA format)
      let r = pixel & 0xFFu;
      let g = (pixel >> 8u) & 0xFFu;
      let b = (pixel >> 16u) & 0xFFu;
      let a = (pixel >> 24u) & 0xFFu;

      // Invert color channels, leave alpha untouched
      let inv_r = 255u - r;
      let inv_g = 255u - g;
      let inv_b = 255u - b;

      // Repack into u32
      pixels[index] = inv_r | (inv_g << 8u) | (inv_b << 16u) | (a << 24u);
    }
  `;

  const shaderModule = device.createShaderModule({
    code: computeShaderCode,
  });

  // 4. Set up pipeline layout, bind group, and compute pipeline
  const bindGroupLayout = device.createBindGroupLayout({
    entries: [
      {
        binding: 0,
        visibility: GPUShaderStage.COMPUTE,
        buffer: { type: 'storage' },
      },
    ],
  });

  const pipelineLayout = device.createPipelineLayout({
    bindGroupLayouts: [bindGroupLayout],
  });

  const computePipeline = device.createComputePipeline({
    layout: pipelineLayout,
    compute: {
      module: shaderModule,
      entryPoint: 'main',
    },
  });

  const bindGroup = device.createBindGroup({
    layout: bindGroupLayout,
    entries: [
      {
        binding: 0,
        resource: { buffer: storageBuffer },
      },
    ],
  });

  // 5. Encode compute commands, dispatch, copy to staging buffer, and submit
  const commandEncoder = device.createCommandEncoder();
  const passEncoder = commandEncoder.beginComputePass();
  passEncoder.setPipeline(computePipeline);
  passEncoder.setBindGroup(0, bindGroup);

  // Dispatch workgroups matching dimensions divided by workgroup size (16x16)
  const workgroupCountX = Math.ceil(width / 16);
  const workgroupCountY = Math.ceil(height / 16);
  passEncoder.dispatchWorkgroups(workgroupCountX, workgroupCountY, 1);
  passEncoder.end();

  // Copy modified storage buffer data to staging buffer for CPU read-back
  commandEncoder.copyBufferToBuffer(storageBuffer, 0, stagingBuffer, 0, bufferSize);

  device.queue.submit([commandEncoder.finish()]);

  // 6. Map staging buffer and return modified pixels
  await stagingBuffer.mapAsync(GPUMapMode.READ);
  const mappedRange = stagingBuffer.getMappedRange();
  const resultPixels = new Uint32Array(mappedRange.slice(0));
  stagingBuffer.unmap();

  return resultPixels;
}
