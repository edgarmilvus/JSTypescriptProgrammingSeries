/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useCallback } from 'react';

export interface ShaderParameters {
  brightness: number;
  contrast: number;
  hueShift: number;
  effectToggle: number; // 0 for off, 1 for on
}

export interface ShaderParameterPanelProps {
  device: GPUDevice;
  uniformBuffer: GPUBuffer;
  initialParams: ShaderParameters;
  onParamsUpdated?: (params: ShaderParameters) => void;
}

export const ShaderParameterPanel: React.FC<ShaderParameterPanelProps> = ({
  device,
  uniformBuffer,
  initialParams,
  onParamsUpdated
}) => {
  const [params, setParams] = useState<ShaderParameters>(initialParams);
  const rafIdRef = useRef<number | null>(null);
  const latestParamsRef = useRef<ShaderParameters>(initialParams);

  // Keep ref synchronized with state for immediate read access in rAF loop
  latestParamsRef.current = params;

  // WGSL 16-byte aligned ArrayBuffer packer
  // Struct layout alignment rule: 
  // - 3 floats (brightness, contrast, hueShift) = 12 bytes
  // - 1 u32/f32 (effectToggle) = 4 bytes
  // Total size = 16 bytes (perfect alignment)
  const updateGPUBuffer = useCallback((currentParams: ShaderParameters) => {
    const bufferData = new ArrayBuffer(16);
    const floatView = new Float32Array(bufferData);
    const uint32View = new Uint32Array(bufferData);

    floatView[0] = currentParams.brightness;
    floatView[1] = currentParams.contrast;
    floatView[2] = currentParams.hueShift;
    uint32View[3] = currentParams.effectToggle;

    device.queue.writeBuffer(uniformBuffer, 0, bufferData);
  }, [device, uniformBuffer]);

  // Throttled update loop using requestAnimationFrame
  const handleParamChange = (key: keyof ShaderParameters, value: number) => {
    setParams((prev) => {
      const updated = { ...prev, [key]: value };
      if (onParamsUpdated) {
        onParamsUpdated(updated);
      }
      return updated;
    });

    if (!rafIdRef.current) {
      rafIdRef.current = requestAnimationFrame(() => {
        updateGPUBuffer(latestParamsRef.current);
        rafIdRef.current = null;
      });
    }
  };

  useEffect(() => {
    // Initial write on mount
    updateGPUBuffer(initialParams);

    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, [initialParams, updateGPUBuffer]);

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-xl text-white w-80 space-y-4 border border-gray-800">
      <h3 className="text-lg font-semibold border-b border-gray-700 pb-2">WebGPU Shader Controls</h3>
      
      {/* Brightness Control */}
      <div className="space-y-1">
        <div className="flex justify-between text-sm">
          <span>Brightness</span>
          <span className="text-gray-400">{params.brightness.toFixed(2)}</span>
        </div>
        <input
          type="range"
          min="-1.0"
          max="1.0"
          step="0.01"
          value={params.brightness}
          onChange={(e) => handleParamChange('brightness', parseFloat(e.target.value))}
          className="w-full accent-indigo-500 cursor-pointer"
        />
      </div>

      {/* Contrast Control */}
      <div className="space-y-1">
        <div className="flex justify-between text-sm">
          <span>Contrast</span>
          <span className="text-gray-400">{params.contrast.toFixed(2)}</span>
        </div>
        <input
          type="range"
          min="0.0"
          max="3.0"
          step="0.01"
          value={params.contrast}
          onChange={(e) => handleParamChange('contrast', parseFloat(e.target.value))}
          className="w-full accent-indigo-500 cursor-pointer"
        />
      </div>

      {/* Hue Shift Control */}
      <div className="space-y-1">
        <div className="flex justify-between text-sm">
          <span>Hue Shift</span>
          <span className="text-gray-400">{params.hueShift.toFixed(0)}°</span>
        </div>
        <input
          type="range"
          min="0"
          max="360"
          step="1"
          value={params.hueShift}
          onChange={(e) => handleParamChange('hueShift', parseFloat(e.target.value))}
          className="w-full accent-indigo-500 cursor-pointer"
        />
      </div>

      {/* Effect Toggle */}
      <div className="flex items-center justify-between pt-2 border-t border-gray-800">
        <span className="text-sm font-medium">Enable Shader FX</span>
        <button
          onClick={() => handleParamChange('effectToggle', params.effectToggle === 1 ? 0 : 1)}
          className={`px-3 py-1 rounded text-xs font-bold transition-colors ${
            params.effectToggle === 1 ? 'bg-indigo-600 text-white' : 'bg-gray-700 text-gray-400'
          }`}
        >
          {params.effectToggle === 1 ? 'ON' : 'OFF'}
        </button>
      </div>
    </div>
  );
};
