/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export class VideoStreamProcessor {
  private device: GPUDevice;
  private context: GPUCanvasContext;
  private pipeline!: GPURenderPipeline;
  private sampler!: GPUSampler;
  private videoTexture!: GPUTexture;
  private bindGroup!: GPUBindGroup;
  private videoElement: HTMLVideoElement;
  private isRunning: boolean = false;
  private animationFrameId: number | null = null;

  constructor(
    device: GPUDevice,
    context: GPUCanvasContext,
    videoElement: HTMLVideoElement
  ) {
    this.device = device;
    this.context = context;
    this.videoElement = videoElement;
  }

  public async initialize(): Promise<void> {
    const canvasFormat = navigator.gpu.getPreferredCanvasFormat();

    // 1. Create sampler and video texture storage
    this.sampler = this.device.createSampler({
      magFilter: 'linear',
      minFilter: 'linear',
    });

    this.videoTexture = this.device.createTexture({
      size: { width: this.videoElement.videoWidth || 1280, height: this.videoElement.videoHeight || 720, depthOrArrayLayers: 1 },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT,
    });

    // 2. Compile WGSL shaders for video processing (Chromatic Aberration & Scanlines)
    const shaderModule = this.device.createShaderModule({
      code: `
        @group(0) @binding(0) var videoSampler: sampler;
        @group(0) @binding(1) var videoTexture: texture_2d<f32>;

        struct VertexOutput {
          @builtin(position) position: vec4<f32>,
          @location(0) uv: vec2<f32>,
        };

        @vertex
        fn vertexMain(@builtin(vertex_index) vertexIndex: u32) -> VertexOutput {
          var pos = array<vec2<f32>, 6>(
            vec2<f32>(-1.0, -1.0),
            vec2<f32>(1.0, -1.0),
            vec2<f32>(-1.0,  1.0),
            vec2<f32>(-1.0,  1.0),
            vec2<f32>(1.0, -1.0),
            vec2<f32>(1.0,  1.0)
          );

          var uv = array<vec2<f32>, 6>(
            vec2<f32>(0.0, 1.0),
            vec2<f32>(1.0, 1.0),
            vec2<f32>(0.0, 0.0),
            vec2<f32>(0.0, 0.0),
            vec2<f32>(1.0, 1.0),
            vec2<f32>(1.0, 0.0)
          );

          var output: VertexOutput;
          output.position = vec4<f32>(pos[vertexIndex], 0.0, 1.0);
          output.uv = uv[vertexIndex];
          return output;
        }

        @fragment
        fn fragmentMain(@location(0) uv: vec2<f32>) -> @location(0) vec4<f32> {
          // Simple chromatic aberration offset
          let offset = 0.005;
          let r = textureSample(videoTexture, videoSampler, uv + vec2<f32>(offset, 0.0)).r;
          let g = textureSample(videoTexture, videoSampler, uv).g;
          let b = textureSample(videoTexture, videoSampler, uv - vec2<f32>(offset, 0.0)).b;
          
          var color = vec4<f32>(r, g, b, 1.0);

          // Subtle scanline effect
          let scanline = sin(uv.y * 800.0) * 0.04;
          color = color - vec4<f32>(scanline, scanline, scanline, 0.0);

          return color;
        }
      `,
    });

    // 3. Create GPURenderPipeline with bind group layouts
    const bindGroupLayout = this.device.createBindGroupLayout({
      entries: [
        { binding: 0, visibility: GPUShaderStage.FRAGMENT, sampler: {} },
        { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: {} },
      ],
    });

    const pipelineLayout = this.device.createPipelineLayout({
      bindGroupLayouts: [bindGroupLayout],
    });

    this.pipeline = this.device.createRenderPipeline({
      layout: pipelineLayout,
      vertex: {
        module: shaderModule,
        entryPoint: 'vertexMain',
      },
      fragment: {
        module: shaderModule,
        entryPoint: 'fragmentMain',
        targets: [{ format: canvasFormat }],
      },
      primitive: {
        topology: 'triangle-list',
      },
    });

    this.bindGroup = this.device.createBindGroup({
      layout: bindGroupLayout,
      entries: [
        { binding: 0, resource: this.sampler },
        { binding: 1, resource: this.videoTexture.createView() },
      ],
    });
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;

    const renderLoop = () => {
      if (!this.isRunning) return;

      if (this.videoElement.readyState >= this.videoElement.HAVE_CURRENT_DATA) {
        // Update texture frame from video source using copyExternalImageToTexture
        this.device.queue.copyExternalImageToTexture(
          { source: this.videoElement, flipY: true },
          { texture: this.videoTexture },
          { width: this.videoElement.videoWidth, height: this.videoElement.videoHeight }
        );

        // Render pass execution
        const commandEncoder = this.device.createCommandEncoder();
        const textureView = this.context.getCurrentTexture().createView();

        const renderPassDescriptor: GPURenderPassDescriptor = {
          colorAttachments: [
            {
              view: textureView,
              clearValue: { r: 0, g: 0, b: 0, a: 1 },
              loadOp: 'clear',
              storeOp: 'store',
            },
          ],
        };

        const passEncoder = commandEncoder.beginRenderPass(renderPassDescriptor);
        passEncoder.setPipeline(this.pipeline);
        passEncoder.setBindGroup(0, this.bindGroup);
        passEncoder.draw(6, 1, 0, 0);
        passEncoder.end();

        this.device.queue.submit([commandEncoder.finish()]);
      }

      this.animationFrameId = requestAnimationFrame(renderLoop);
    };

    this.animationFrameId = requestAnimationFrame(renderLoop);
  }

  public stop(): void {
    this.isRunning = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }
}
