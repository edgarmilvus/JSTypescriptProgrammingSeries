/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export type DataType = 'texture' | 'buffer';

export interface WorkflowPin {
  id: string;
  name: string;
  type: DataType;
  format?: GPUTextureFormat;
}

export interface GPUWorkflowNode {
  id: string;
  name: string;
  inputs: WorkflowPin[];
  outputs: WorkflowPin[];
  execute: (encoder: GPUCommandEncoder, inputs: GPUTexture[], outputs: GPUTexture[]) => void;
}

export interface GPUWorkflowEdge {
  fromNodeId: string;
  fromPinId: string;
  toNodeId: string;
  toPinId: string;
}

export class WorkflowExecutionEngine {
  private nodes: Map<string, GPUWorkflowNode> = new Map();
  private edges: GPUWorkflowEdge[] = [];

  public registerNode(node: GPUWorkflowNode): void {
    this.nodes.set(node.id, node);
  }

  public addEdge(edge: GPUWorkflowEdge): void {
    this.edges.push(edge);
  }

  public compileExecutionPlan(): GPUWorkflowNode[] {
    const inDegree = new Map<string, number>();
    const adjacencyList = new Map<string, string[]>();

    // Initialize graph structures
    for (const nodeId of this.nodes.keys()) {
      inDegree.set(nodeId, 0);
      adjacencyList.set(nodeId, []);
    }

    // Populate adjacency list and compute in-degrees
    for (const edge of this.edges) {
      if (!this.nodes.has(edge.fromNodeId) || !this.nodes.has(edge.toNodeId)) {
        throw new Error(`Edge references non-existent node: ${edge.fromNodeId} -> ${edge.toNodeId}`);
      }

      const targets = adjacencyList.get(edge.fromNodeId)!;
      targets.push(edge.toNodeId);

      inDegree.set(edge.toNodeId, inDegree.get(edge.toNodeId)! + 1);
    }

    // Kahn's Algorithm for Topological Sort
    const queue: string[] = [];
    for (const [nodeId, degree] of inDegree.entries()) {
      if (degree === 0) {
        queue.push(nodeId);
      }
    }

    const sortedNodes: GPUWorkflowNode[] = [];

    while (queue.length > 0) {
      const currentNodeId = queue.shift()!;
      sortedNodes.push(this.nodes.get(currentNodeId)!);

      for (const neighborId of adjacencyList.get(currentNodeId)!) {
        const currentDegree = inDegree.get(neighborId)! - 1;
        inDegree.set(neighborId, currentDegree);

        if (currentDegree === 0) {
          queue.push(neighborId);
        }
      }
    }

    // Circular dependency detection
    if (sortedNodes.length !== this.nodes.size) {
      throw new Error("Circular dependency detected in the workflow node graph!");
    }

    return sortedNodes;
  }

  public executeFrame(device: GPUDevice): void {
    const sortedPlan = this.compileExecutionPlan();
    const commandEncoder = device.createCommandEncoder();

    // Map to hold persistent or frame-transient texture allocations
    const textureAllocations = new Map<string, GPUTexture>();

    // Dummy allocation mapper for illustration of data piping between nodes
    for (const node of sortedPlan) {
      const inputTextures: GPUTexture[] = node.inputs.map((pin) => {
        // Retrieve or create temporary texture matching pin constraints
        if (!textureAllocations.has(pin.id)) {
          const tex = device.createTexture({
            size: { width: 512, height: 512, depthOrArrayLayers: 1 },
            format: pin.format || 'rgba8unorm',
            usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING,
          });
          textureAllocations.set(pin.id, tex);
        }
        return textureAllocations.get(pin.id)!;
      });

      const outputTextures: GPUTexture[] = node.outputs.map((pin) => {
        if (!textureAllocations.has(pin.id)) {
          const tex = device.createTexture({
            size: { width: 512, height: 512, depthOrArrayLayers: 1 },
            format: pin.format || 'rgba8unorm',
            usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING,
          });
          textureAllocations.set(pin.id, tex);
        }
        return textureAllocations.get(pin.id)!;
      });

      // Execute node command recording
      node.execute(commandEncoder, inputTextures, outputTextures);
    }

    device.queue.submit([commandEncoder.finish()]);
  }
}
