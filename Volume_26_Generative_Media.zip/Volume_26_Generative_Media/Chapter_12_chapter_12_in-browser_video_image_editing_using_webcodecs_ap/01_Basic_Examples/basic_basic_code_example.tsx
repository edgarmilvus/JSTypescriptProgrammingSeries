/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'react';

/**
 * Interface for pipeline configuration options.
 */
interface MediaProcessorConfig {
  width: number;
  height: number;
  bitrate: number;
  framerate: number;
}

/**
 * SaaS Video Processing Engine using WebCodecs, HTML5 Canvas, and WebGPU.
 * This class demuxes, decodes, processes via WebGPU, and re-encodes video frames entirely client-side.
 */
export class ClientMediaProcessor {
  private config: MediaProcessorConfig;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D | null = null;
  private device: GPUDevice | null = null;
  private pipeline: GPUComputePipeline | null = null;
  private decoder: VideoDecoder | null = null;
  private encoder: VideoEncoder | null = null;
  private isProcessing: boolean = false;

  constructor(canvas: HTMLCanvasElement, config: MediaProcessorConfig) {
    this.canvas = canvas;
    this.config = config;
    this.ctx = this.canvas.getContext('2d');
  }

  /**
   * Initializes the WebGPU device, compute pipeline, and codecs.
   */
  public async initialize(): Promise<void> {
    // 1. Initialize WebGPU adapter and device
    if (!navigator.gpu) {
      throw new Error('WebGPU is not supported in this browser.');
    }

    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) {
      throw new Error('Failed to secure a WebGPU adapter.');
    }

    this.device = await adapter.requestDevice();

    // 2. Setup WGSL compute shader for real-time frame manipulation (e.g., Grayscale/Brightness)
    const shaderModule = this.device.createShaderModule({
      code: `
        @group(0) @binding(0) var inputTex: texture_2d<f32>;
        @group(0) @binding(1) var outputTex: texture_storage_2d<rgba8unorm, write>;

        @compute @workgroup_size(16, 16)
        fn main(@builtin(global_invocation_id) id: vec3<u32>) {
          let dims = textureDimensions(inputTex);
          if (id.x >= dims.x || id.y >= dims.y) {
            return;
          }

          let color = textureLoad(inputTex, vec2<i32>(id.xy), 0);
          // Apply a simple luminosity grayscale filter with a brightness boost
          let brightness = 1.1;
          let luma = color.r * 0.299 + color.g * 0.587 + color.b * 0.114;
          let adjusted = vec4<f32>(vec3<f32>(luma * brightness), color.a);

          textureStore(outputTex, vec2<i32>(id.xy), adjusted);
        }
      `,
    });

    // 3. Create Compute Pipeline layout and pipeline
    this.pipeline = await this.device.createComputePipelineAsync({
      layout: 'auto',
      compute: {
        module: shaderModule,
        entryPoint: 'main',
      },
    });

    // 4. Configure WebCodecs VideoDecoder
    this.decoder = new VideoDecoder({
      output: (frame: VideoFrame) => this.handleDecodedFrame(frame),
      error: (e: DOMException) => console.error('Decoding error:', e),
    });

    // 5. Configure WebCodecs VideoEncoder
    this.encoder = new VideoEncoder({
      output: (chunk: EncodedVideoChunk, metadata: EncodedVideoChunkMetadata) => {
        this.handleEncodedChunk(chunk, metadata);
      },
      error: (e: DOMException) => console.error('Encoding error:', e),
    });

    this.encoder.configure({
      codec: 'vp09.00.10.08', // VP9 codec for broad browser compatibility
      width: this.config.width,
      height: this.config.height,
      bitrate: this.config.bitrate,
      framerate: this.config.framerate,
    });
  }

  /**
   * Handles raw decoded frames by passing them to the WebGPU processing pipeline.
   */
  private async handleDecodedFrame(frame: VideoFrame): Promise<void> {
    if (!this.device || !this.pipeline) return;

    // Import the VideoFrame directly into a WebGPU texture via external texture support
    const sourceTexture = this.device.importExternalTexture({
      source: frame,
    });

    // Create a target storage texture for the compute shader to write into
    const outputTexture = this.device.createTexture({
      size: { width: frame.displayedWidth, height: frame.displayedHeight },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.COPY_SRC | GPUTextureUsage.RENDER_ATTACHMENT,
    });

    // Set up bind group linking the input frame and output texture
    const bindGroup = this.device.createBindGroup({
      layout: this.pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: sourceTexture },
        { binding: 1, resource: outputTexture.createView() },
      ],
    });

    // Execute compute shader pass
    const commandEncoder = this.device.createCommandEncoder();
    const passEncoder = commandEncoder.beginComputePass();
    passEncoder.setPipeline(this.pipeline);
    passEncoder.setBindGroup(0, bindGroup);
    
    // Dispatch workgroups based on frame dimensions (16x16 workgroup size)
    const workgroupsX = Math.ceil(frame.displayedWidth / 16);
    const workgroupsY = Math.ceil(frame.displayedHeight / 16);
    passEncoder.dispatchWorkgroups(workgroupsX, workgroupsY);
    passEncoder.end();

    this.device.queue.submit([commandEncoder.finish()]);

    // Draw processed result to HTML5 Canvas for real-time user preview
    if (this.ctx) {
      // Create a bitmap from the output texture for 2D canvas rendering context
      const imageBitmap = await createImageBitmap(frame);
      this.ctx.drawImage(imageBitmap, 0, 0, this.canvas.width, this.canvas.height);
      imageBitmap.close();
    }

    // Re-encode the processed frame back into the output stream
    // Note: For full WebGPU-to-Encoder roundtripping, frames can be mapped back or passed via VideoFrame constructor
    const processedFrame = new VideoFrame(this.canvas, { timestamp: frame.timestamp });
    if (this.encoder && this.encoder.state === 'configured') {
      this.encoder.encode(processedFrame, { keyFrame: Math.random() < 0.05 });
    }

    frame.close();
    processedFrame.close();
  }

  /**
   * Handles newly encoded media chunks (e.g., muxing into WebM/MP4 containers).
   */
  private handleEncodedChunk(chunk: EncodedVideoChunk, metadata: EncodedVideoChunkMetadata): void {
    const chunkData = new Uint8Array(chunk.byteLength);
    chunk.copyTo(chunkData);
    
    // In a production SaaS app, you would pipe this chunkData into a WebM muxer (e.g., ts-webm)
    console.log(`[SaaS Video Pipeline] Encoded chunk size: ${chunkData.byteLength} bytes at timestamp ${chunk.timestamp}`);
  }

  /**
   * Feeds an incoming EncodedVideoChunk into the decoder pipeline.
   */
  public feedChunk(chunk: EncodedVideoChunk): void {
    if (this.decoder && this.decoder.state === 'configured') {
      this.decoder.decode(chunk);
    }
  }

  /**
   * Cleans up hardware resources, stopping decoders and encoders.
   */
  public destroy(): void {
    this.isProcessing = false;
    if (this.decoder && this.decoder.state !== 'closed') {
      this.decoder.close();
    }
    if (this.encoder && this.encoder.state !== 'closed') {
      this.encoder.close();
    }
    if (this.device) {
      this.device.destroy();
    }
  }
}

/**
 * React SaaS Component integrating the ClientMediaProcessor engine.
 */
export default function VideoEditorComponent() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<string>('Initializing WebGPU Engine...');
  const processorRef = useRef<ClientMediaProcessor | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const processor = new ClientMediaProcessor(canvasRef.current, {
      width: 1280,
      height: 720,
      bitrate: 2_500_000, // 2.5 Mbps
      framerate: 30,
    });

    processorRef.current = processor;

    processor.initialize()
      .then(() => setStatus('WebGPU Pipeline Ready. Awaiting Media Stream.'))
      .catch((err) => setStatus(`Initialization Failed: ${err.message}`));

    return () => {
      processor.destroy();
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-slate-950 text-white rounded-xl shadow-2xl">
      <h2 className="text-2xl font-bold mb-4">WebGPU & WebCodecs SaaS Video Editor</h2>
      <div className="mb-4 px-4 py-2 bg-slate-800 rounded border border-slate-700 text-sm font-mono">
        Status: {status}
      </div>
      <div className="relative border-2 border-slate-700 rounded-lg overflow-hidden shadow-inner bg-black">
        <canvas ref={canvasRef} width={1280} height={720} className="w-[640px] h-[360px] object-contain" />
      </div>
    </div>
  );
}
