/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Configuration options for the WebCodecsVideoDemuxer.
 */
export interface DemuxerConfig {
  codec: string;
  description?: Uint8Array;
}

/**
 * A zero-copy video frame demuxing and decoding pipeline using the WebCodecs API.
 */
export class WebCodecsVideoDemuxer {
  private decoder: VideoDecoder;
  private frameQueue: VideoFrame[] = [];
  private resolveWait: (() => void) | null = null;
  private isFlushing: boolean = false;
  private maxQueueSize: number = 5;

  constructor(config: DemuxerConfig) {
    this.decoder = new VideoDecoder({
      output: (frame: VideoFrame) => {
        // Enforce backpressure limit on internal frame buffer
        if (this.frameQueue.length >= this.maxQueueSize) {
          // Drop oldest frame to maintain real-time responsiveness if needed,
          // or close it to prevent memory leaks.
          const droppedFrame = this.frameQueue.shift();
          droppedFrame?.close();
        }
        this.frameQueue.push(frame);
        if (this.resolveWait) {
          this.resolveWait();
          this.resolveWait = null;
        }
      },
      error: (e: DOMException) => {
        console.error("WebCodecs VideoDecoder error:", e);
      },
    });

    // Configure the hardware-accelerated decoder
    this.decoder.configure({
      codec: config.codec,
      description: config.description,
      hardwareAcceleration: "prefer-hardware",
    });
  }

  /**
   * Pushes an encoded video chunk into the decoder while respecting decodeQueueSize.
   */
  public async decodeChunk(chunk: EncodedVideoChunk): Promise<void> {
    // Respect backpressure threshold to prevent overwhelming the hardware decoder
    while (this.decoder.decodeQueueSize > this.maxQueueSize) {
      await new Promise((resolve) => setTimeout(resolve, 5));
    }

    if (this.isFlushing) return;
    this.decoder.decode(chunk);
  }

  /**
   * Async generator yielding decoded VideoFrame instances.
   */
  public async *decodeFrames(): AsyncGenerator<VideoFrame, void, unknown> {
    while (true) {
      while (this.frameQueue.length === 0) {
        if (this.isFlushing) return;
        await new Promise<void>((resolve) => {
          this.resolveWait = resolve;
        });
      }

      const frame = this.frameQueue.shift();
      if (frame) {
        yield frame;
        // Consumer is responsible for calling frame.close() after use, 
        // but we ensure safety guards exist.
      }
    }
  }

  /**
   * Flushes and resets the decoder state during seeking or stream termination.
   */
  public async reset(): Promise<void> {
    this.isFlushing = true;
    await this.decoder.flush();
    this.decoder.reset();
    
    // Clear remaining queued frames and close them to prevent memory leaks
    for (const frame of this.frameQueue) {
      frame.close();
    }
    this.frameQueue = [];
    this.isFlushing = false;
  }
}
