/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * WGSL Shader code implementing a dynamic color transformation and contrast filter.
 */
export const videoFilterShader = `
  struct Uniforms {
    intensity: f32,
    time: f32,
  };

  @group(0) @binding(0) var mySampler: sampler;
  @group(0) @binding(1) var myTexture: texture_external;
  @group(0) @binding(2) var<uniform> uniforms: Uniforms;

  @fragment
  fn main(@builtin(position) fragCoord: vec4f, @location(0) uv: vec2f) -> @location(0) vec4f {
    // Sample directly from the imported external video texture
    let color = textureSampleBaseClampToEdge(myTexture, mySampler, uv);
    
    // Apply dynamic contrast adjustment based on uniform intensity
    let factor = (1.015 * (uniforms.intensity + 1.0)) / (1.0 * (1.015 - uniforms.intensity));
    let adjustedColor = factor * (color.rgb - vec3f(0.5)) + vec3f(0.5);
    
    // Simple sepia/tint adjustment driven by time uniform
    let tint = vec3f(0.2, 0.1, 0.0) * sin(uniforms.time);
    
    return vec4f(clamp(adjustedColor + tint, vec3f(0.0), vec3f(1.0)), color.a);
  }
`;

/**
 * Sets up the WebGPU Render Pipeline and BindGroupLayout for external video textures.
 */
export async function createVideoPipeline(
  device: GPUDevice,
  presentationFormat: GPUTextureFormat
): Promise<{ pipeline: GPURenderPipeline; bindGroupLayout: GPUBindGroupLayout }> {
  const shaderModule = device.createShaderModule({
    code: videoFilterShader,
  });

  const bindGroupLayout = device.createBindGroupLayout({
    entries: [
      {
        binding: 0,
        visibility: GPUShaderStage.FRAGMENT,
        sampler: {},
      },
      {
        binding: 1,
        visibility: GPUShaderStage.FRAGMENT,
        externalTexture: {},
      },
      {
        binding: 2,
        visibility: GPUShaderStage.FRAGMENT,
        buffer: { type: "uniform" },
      },
    ],
  });

  const pipelineLayout = device.createPipelineLayout({
    bindGroupLayouts: [bindGroupLayout],
  });

  const pipeline = await device.createRenderPipelineAsync({
    layout: pipelineLayout,
    vertex: {
      module: shaderModule,
      entryPoint: "main_vertex", // Assumes a standard vertex shader exists in module
    },
    fragment: {
      module: shaderModule,
      entryPoint: "main",
      targets: [{ format: presentationFormat }],
    },
    primitive: {
      topology: "triangle-list",
    },
  });

  return { pipeline, bindGroupLayout };
}
