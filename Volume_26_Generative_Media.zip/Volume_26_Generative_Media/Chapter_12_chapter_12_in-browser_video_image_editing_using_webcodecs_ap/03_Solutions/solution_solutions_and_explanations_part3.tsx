/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// --- TypeScript Interfaces ---
export type PortType = 'video' | 'audio' | 'tensor' | 'control';

export interface PortData {
  id: string;
  name: string;
  type: PortType;
}

export interface NodeTelemetry {
  fps: number;
  decodeQueueSize: number;
  inferenceLatencyMs: number;
  gpuMemoryMb: number;
}

export interface NodeData {
  id: string;
  title: string;
  x: number;
  y: number;
  inputs: PortData[];
  outputs: PortData[];
  telemetry: NodeTelemetry;
  config: Record<string, any>;
}

export interface ConnectionData {
  id: string;
  fromNodeId: string;
  fromPortId: string;
  toNodeId: string;
  toPortId: string;
}

export interface AICanvasInspectorProps {
  initialNodes?: NodeData[];
  initialConnections?: ConnectionData[];
  onNodeSelect?: (node: NodeData | null) => void;
  onConnectionChange?: (connections: ConnectionData[]) => void;
}

/**
 * AICanvasInspector React Component
 */
export const AICanvasInspector: React.FC<AICanvasInspectorProps> = ({
  initialNodes = [],
  initialConnections = [],
  onNodeSelect,
  onConnectionChange,
}) => {
  const [nodes, setNodes] = useState<NodeData[]>(initialNodes);
  const [connections, setConnections] = useState<ConnectionData[]>(initialConnections);
  const [selectedNode, setSelectedNode] = useState<NodeData | null>(null);

  const handleNodeClick = (node: NodeData) => {
    setSelectedNode(node);
    if (onNodeSelect) onNodeSelect(node);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-gray-900 text-white font-sans">
      {/* Main Node Graph Canvas Area */}
      <div className="relative flex-1 bg-grid-pattern cursor-grab">
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {connections.map((conn) => {
            // Render connection Bezier curves between ports here
            return (
              <path
                key={conn.id}
                d="M 100 100 C 150 100, 200 200, 250 200"
                stroke="#3b82f6"
                strokeWidth="3"
                fill="none"
              />
            );
          })}
        </svg>

        {/* Node Cards */}
        {nodes.map((node) => (
          <div
            key={node.id}
            onClick={() => handleNodeClick(node)}
            style={{ transform: `translate(${node.x}px, ${node.y}px)` }}
            className={`absolute w-64 rounded-lg bg-gray-800 border ${
              selectedNode?.id === node.id ? 'border-blue-500 shadow-lg shadow-blue-500/20' : 'border-gray-700'
            } p-4 cursor-pointer select-none`}
          >
            <div className="flex justify-between items-center mb-2">
              <span className="font-bold text-sm">{node.title}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-gray-700 text-gray-300">
                {node.telemetry.fps} FPS
              </span>
            </div>
            
            {/* Telemetry Footer */}
            <div className="mt-3 pt-2 border-t border-gray-700 text-xs text-gray-400 grid grid-cols-2 gap-1">
              <div>Queue: {node.telemetry.decodeQueueSize}</div>
              <div>Latency: {node.telemetry.inferenceLatencyMs}ms</div>
            </div>
          </div>
        ))}
      </div>

      {/* Property Inspector Sidebar */}
      <div className="w-80 bg-gray-850 border-l border-gray-800 p-4 flex flex-col">
        <h2 className="text-lg font-semibold mb-4 text-gray-200">Property Inspector</h2>
        {selectedNode ? (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Node ID</label>
              <input
                type="text"
                disabled
                value={selectedNode.id}
                className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1 text-sm text-gray-400"
              />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">Label</label>
              <input
                type="text"
                value={selectedNode.title}
                onChange={(e) => {
                  const updated = { ...selectedNode, title: e.target.value };
                  setSelectedNode(updated);
                  setNodes(nodes.map(n => n.id === updated.id ? updated : n));
                }}
                className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-1 text-sm text-white"
              />
            </div>
          </div>
        ) : (
          <p className="text-sm text-gray-500 italic">Select a node to inspect and modify properties.</p>
        )}
      </div>
    </div>
  );
};
