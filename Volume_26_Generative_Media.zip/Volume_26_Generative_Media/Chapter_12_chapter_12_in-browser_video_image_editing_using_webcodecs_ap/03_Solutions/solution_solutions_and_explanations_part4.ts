/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Muxer, ArrayBufferTarget } from 'mp4-muxer';

/**
 * Configuration options for the WebCodecsVideoEncoder.
 */
export interface EncoderConfig {
  width: number;
  height: number;
  bitrate: number;
  framerate: number;
  codec: string;
}

/**
 * Handles client-side video encoding via WebCodecs and MP4 multiplexing.
 */
export class WebCodecsVideoEncoder {
  private encoder: VideoEncoder;
  private muxer: Muxer<ArrayBufferTarget>;
  private target: ArrayBufferTarget;

  constructor(config: EncoderConfig) {
    // Initialize the mp4-muxer target
    this.target = new ArrayBufferTarget();
    this.muxer = new Muxer({
      target: this.target,
      video: {
        codec: config.codec === 'avc1.4d002a' ? 'AVC' : 'Vp09',
        width: config.width,
        height: config.height,
        // Additional muxer configurations can be added here
      },
      fastStart: 'in-memory',
    });

    // Initialize the WebCodecs VideoEncoder
    this.encoder = new VideoEncoder({
      output: (chunk: EncodedVideoChunk, metadata: EncodedVideoChunkMetadata) => {
        // Pass encoded chunk and metadata straight into the MP4 muxer
        if (metadata.decoderConfig) {
          // Handle decoder configuration updates if required by muxer
        }
        this.muxer.addVideoChunk(chunk, metadata);
      },
      error: (e: DOMException) => {
        console.error("WebCodecs VideoEncoder runtime error:", e);
      },
    });

    // Configure encoder parameters
    this.encoder.configure({
      codec: config.codec,
      width: config.width,
      height: config.height,
      bitrate: config.bitrate,
      framerate: config.framerate,
      hardwareAcceleration: 'prefer-hardware',
    });
  }

  /**
   * Encodes a raw VideoFrame while respecting encoder backpressure limits.
   */
  public async encodeFrame(frame: VideoFrame, options?: { keyFrame?: boolean }): Promise<void> {
    while (this.encoder.encodeQueueSize > 4) {
      await new Promise((resolve) => setTimeout(resolve, 5));
    }

    this.encoder.encode(frame, { keyFrame: options?.keyFrame ?? false });
  }

  /**
   * Flushes the encoder, finalizes the MP4 container, and returns a downloadable Blob.
   */
  public async finalize(): Promise<Blob> {
    await this.encoder.flush();
    this.encoder.close();
    this.muxer.finalize();

    const buffer = this.target.buffer;
    return new Blob([buffer], { type: 'video/mp4' });
  }
}
