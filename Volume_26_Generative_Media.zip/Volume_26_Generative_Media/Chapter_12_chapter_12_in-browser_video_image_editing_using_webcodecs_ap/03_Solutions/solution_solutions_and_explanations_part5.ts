/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// --- Web Worker Script (worker.ts) ---
// Note: In practice, this runs inside a dedicated Web Worker context.
/*
import { pipeline, env } from '@xenova/transformers';

env.allowLocalModels = false;

class AIModelSingleton {
  static task = 'image-segmentation';
  static modelId = 'Xenova/deeplabv3_mnv2';
  static instance: any = null;

  static async getInstance(progress_callback?: Function) {
    if (this.instance === null) {
      this.instance = await pipeline(this.task, this.modelId, { progress_callback });
    }
    return this.instance;
  }
}

self.onmessage = async (event: MessageEvent) => {
  const { id, imageBitmap } = event.data;
  try {
    const segmenter = await AIModelSingleton.getInstance();
    const result = await segmenter(imageBitmap);
    
    // Clean up ImageBitmap memory inside worker
    imageBitmap.close();
    
    self.postMessage({ id, success: true, result });
  } catch (error: any) {
    self.postMessage({ id, success: false, error: error.message });
  }
};
*/

// --- Main Thread Client Wrapper ---
export class AIWorkerClient {
  private worker: Worker;
  private requestIdCounter = 0;
  private pendingRequests = new Map<number, (result: any) => void>();
  private isProcessing = false;

  constructor(workerScriptPath: string) {
    this.worker = new Worker(new URL(workerScriptPath, import.meta.url), { type: 'module' });
    this.worker.onmessage = this.handleMessage.bind(this);
  }

  private handleMessage(event: MessageEvent) {
    const { id, success, result, error } = event.data;
    const resolver = this.pendingRequests.get(id);
    if (resolver) {
      this.pendingRequests.delete(id);
      resolver(success ? result : Promise.reject(new Error(error)));
    }
    this.isProcessing = false;
  }

  /**
   * Dispatches an ImageBitmap to the worker for AI inference with frame-dropping safeguards.
   */
  public async runInference(imageBitmap: ImageBitmap): Promise<any> {
    // Drop frame if worker is currently busy to maintain real-time playback
    if (this.isProcessing) {
      imageBitmap.close();
      return null;
    }

    this.isProcessing = true;
    const id = ++this.requestIdCounter;

    return new Promise((resolve, reject) => {
      this.pendingRequests.set(id, resolve);
      // Transfer the ImageBitmap zero-copy to the Web Worker
      this.worker.postMessage({ id, imageBitmap }, [imageBitmap]);
    });
  }

  public terminate() {
    this.worker.terminate();
    this.pendingRequests.clear();
  }
}
