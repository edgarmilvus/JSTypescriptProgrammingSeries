/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @file FFmpegWasmTranscoder.ts
 * @description A self-contained SaaS module for client-side video transcoding 
 * using FFmpeg WebAssembly (WASM) running within an isolated Web Worker context.
 */

import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL, fetchFile } from '@ffmpeg/util';

/**
 * Configuration interface for the Transcoder service.
 */
interface TranscodeOptions {
  inputUrl: string;
  outputFileName: string;
  targetResolution: '640x360' | '1280x720' | '1920x1080';
  onProgress?: (progress: number) => void;
}

export class ClientVideoTranscoder {
  private ffmpeg: FFmpeg | null = null;
  private isLoaded: boolean = false;

  /**
   * Initializes the FFmpeg WASM instance. Downloads the core binaries from a CDN
   * and compiles them into the browser's WebAssembly memory space.
   */
  public async initialize(): Promise<void> {
    if (this.isLoaded && this.ffmpeg) return;

    // Instantiate the core FFmpeg class wrapper
    this.ffmpeg = new FFmpeg();

    // Setup logging hooks to monitor compilation and processing output
    this.ffmpeg.on('log', ({ message }) => {
      console.debug(`[FFmpeg WASM Log]: ${message}`);
    });

    try {
      // Define CDN sources for the multi-threaded or single-threaded WASM binaries
      const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
      
      console.log('Fetching FFmpeg WASM binaries from CDN...');
      
      // Load core, WASM binary, and worker scripts with proper blob conversions
      await this.ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      });

      this.isLoaded = true;
      console.log('FFmpeg WASM successfully initialized and loaded into memory.');
    } catch (error) {
      console.error('Failed to initialize FFmpeg WASM:', error);
      throw new Error(`Initialization failed: ${(error as Error).message}`);
    }
  }

  /**
   * Executes a transcoding operation on a target video file.
   * 
   * @param options TranscodeOptions containing source URL, target profile, and callbacks.
   * @returns Promise<string> A local Object URL representing the transcoded video blob.
   */
  public async transcodeVideo(options: TranscodeOptions): Promise<string> {
    if (!this.isLoaded || !this.ffmpeg) {
      throw new Error('Transcoder has not been initialized. Call initialize() first.');
    }

    const { inputUrl, outputFileName, targetResolution, onProgress } = options;

    // Attach progress listener to track transcoding percentage
    if (onProgress) {
      this.ffmpeg.on('progress', ({ progress }) => {
        // progress is typically a float between 0.0 and 1.0
        onProgress(Math.max(0, Math.min(1, progress)));
      });
    }

    try {
      console.log(`Fetching input file from: ${inputUrl}`);
      // Fetch the remote or local source file into an ArrayBuffer
      const inputData = await fetchFile(inputUrl);
      const inputVirtualName = 'input_source.mp4';

      console.log('Writing input file to FFmpeg MEMFS virtual file system...');
      // Write the binary data into FFmpeg's virtual MEMFS file system
      await this.ffmpeg.writeFile(inputVirtualName, inputData);

      // Map user-friendly resolution strings to FFmpeg video filter arguments
      let scaleFilter = 'scale=1280:720';
      if (targetResolution === '640x360') scaleFilter = 'scale=640:360';
      if (targetResolution === '1920x1080') scaleFilter = 'scale=1920:1080';

      console.log(`Executing FFmpeg CLI command with filter: ${scaleFilter}`);
      
      // Execute the core CLI command: transcode video codec to H.264, audio to AAC, scale resolution
      await this.ffmpeg.exec([
        '-i', inputVirtualName,
        '-vf', scaleFilter,
        '-c:v', 'libx264',
        '-preset', 'ultrafast', // Prioritize client CPU processing speed over compression density
        '-c:a', 'aac',
        outputFileName
      ]);

      console.log('Transcoding complete. Reading output from MEMFS...');
      
      // Read the output file data back from the virtual file system as a Uint8Array
      const outputData = await this.ffmpeg.readFile(outputFileName);

      // Create a Blob from the Uint8Array buffer with the correct MIME type
      const videoBlob = new Blob([outputData], { type: 'video/mp4' });

      // Generate a local object URL for immediate DOM consumption (e.g., HTML5 <video> tag)
      const outputObjectUrl = URL.createObjectURL(videoBlob);

      // Cleanup virtual files to free browser heap memory
      await this.ffmpeg.deleteFile(inputVirtualName);
      await this.ffmpeg.deleteFile(outputFileName);

      return outputObjectUrl;

    } catch (error) {
      console.error('Transcoding pipeline failed:', error);
      throw new Error(`Transcoding error: ${(error as Error).message}`);
    }
  }
}

/**
 * ==========================================
 * USAGE EXAMPLE (React Component Integration)
 * ==========================================
 */
import React, { useEffect, useState, useRef } from 'react';

export const VideoTranscoderWidget: React.FC = () => {
  const [transcoder, setTranscoder] = useState<ClientVideoTranscoder | null>(null);
  const [status, setStatus] = useState<string>('Initializing WASM Engine...');
  const [progress, setProgress] = useState<number>(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const isInitialized = useRef<boolean>(false);

  useEffect(() => {
    if (isInitialized.current) return;
    isInitialized.current = true;

    const initEngine = async () => {
      const clientTranscoder = new ClientVideoTranscoder();
      try {
        await clientTranscoder.initialize();
        setTranscoder(clientTranscoder);
        setStatus('Engine Ready. Drop or select a video to transcode.');
      } catch (err) {
        setStatus(`Initialization Error: ${(err as Error).message}`);
      }
    };

    initEngine();
  }, []);

  const handleFileSelection = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0 || !transcoder) return;

    const file = files[0];
    const localInputUrl = URL.createObjectURL(file);

    setStatus('Transcoding video locally in browser...');
    setProgress(0);

    try {
      const resultUrl = await transcoder.transcodeVideo({
        inputUrl: localInputUrl,
        outputFileName: 'output_transcoded.mp4',
        targetResolution: '640x360',
        onProgress: (p) => {
          setProgress(Math.round(p * 100));
        }
      });

      setOutputUrl(resultUrl);
      setStatus('Transcoding successfully completed!');
    } catch (err) {
      setStatus(`Transcoding failed: ${(err as Error).message}`);
    }
  };

  return (
    <div style={{ padding: '24px', fontFamily: 'sans-serif', maxWidth: '600px', margin: 'auto' }}>
      <h2>Client-Side SaaS Video Transcoder</h2>
      <p><strong>Status:</strong> {status}</p>
      
      {progress > 0 && progress < 100 && (
        <div style={{ width: '100%', backgroundColor: '#eee', borderRadius: '4px', margin: '12px 0' }}>
          <div style={{ width: `${progress}%`, backgroundColor: '#4f46e5', height: '16px', borderRadius: '4px', textAlign: 'center', color: 'white', fontSize: '10px' }}>
            {progress}%
          </div>
        </div>
      )}

      <input 
        type="file" 
        accept="video/*" 
        onChange={handleFileSelection} 
        disabled={!transcoder || (progress > 0 && progress < 100)} 
        style={{ margin: '16px 0' }}
      />

      {outputUrl && (
        <div>
          <h3>Transcoded Output Preview:</h3>
          <video src={outputUrl} controls width="100%" style={{ borderRadius: '8px', border: '1px solid #ccc' }} />
        </div>
      )}
    </div>
  );
};
