/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file FFmpegWasmService.ts
 * @description Enterprise-grade client-side video processing pipeline using FFmpeg WASM.
 * Handles virtual file system (MEMFS) staging, multi-file merging, and hardware-accelerated 
 * transcoding directly in the browser via Web Workers.
 */

import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

export interface VideoProcessJob {
  id: string;
  inputFiles: { name: string; data: File | Blob }[];
  outputName: string;
  targetResolution?: '720p' | '1080p';
  onProgress?: (progress: number, time: number) => void;
}

export class FFmpegWasmPipeline {
  private static instance: FFmpegWasmPipeline;
  private ffmpeg: FFmpeg;
  private isLoaded: boolean = false;
  private loadPromise: Promise<void> | null = null;

  private constructor() {
    this.ffmpeg = new FFmpeg();
  }

  /**
   * Singleton pattern to ensure the heavy WASM binary is only fetched and initialized once.
   */
  public static getInstance(): FFmpegWasmPipeline {
    if (!FFmpegWasmPipeline.instance) {
      FFmpegWasmPipeline.instance = new FFmpegWasmPipeline();
    }
    return FFmpegWasmPipeline.instance;
  }

  /**
   * Initializes the FFmpeg WebAssembly module, loading core scripts and multi-threaded workers
   * from a reliable CDN or local public asset directory.
   */
  public async load(): Promise<void> {
    if (this.isLoaded) return;
    if (this.loadPromise) return this.loadPromise;

    this.loadPromise = (async () => {
      try {
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
        
        // Attach progress listener for initial binary downloads
        this.ffmpeg.on('log', ({ message }) => {
          console.debug(`[FFmpeg Core]: ${message}`);
        });

        await this.ffmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
          // workerURL can be provided here if utilizing multi-threaded SharedArrayBuffer setups
        });

        this.isLoaded = true;
        console.info('FFmpeg WASM initialized successfully.');
      } catch (error) {
        console.error('Failed to initialize FFmpeg WASM:', error);
        this.loadPromise = null;
        throw error;
      }
    })();

    return this.loadPromise;
  }

  /**
   * Transcodes, scales, and merges multiple video inputs into a single cohesive output file.
   * 
   * @param job Configuration object containing files, output naming, and progress hooks.
   * @returns A URL pointing to the resulting Blob object ready for preview or download.
   */
  public async processAndMergeVideos(job: VideoProcessJob): Promise<string> {
    await this.load();

    const { inputFiles, outputName, targetResolution = '720p', onProgress } = job;

    // 1. Register progress tracking handler
    if (onProgress) {
      this.ffmpeg.on('progress', ({ progress, time }) => {
        // progress is a float between 0 and 1; time is processed micro/milliseconds
        onProgress(Math.min(Math.max(progress, 0), 1), time);
      });
    }

    const inputArgs: string[] = [];
    const filterComplexParts: string[] = [];

    try {
      // 2. Write input files into the virtual MEMFS file system
      for (let i = 0; i < inputFiles.length; i++) {
        const fileObj = inputFiles[i];
        const virtualName = `input_${i}.${fileObj.name.split('.').pop() || 'mp4'}`;
        
        // Convert File/Blob to Uint8Array and write to WASM memory space
        const fileData = await fetchFile(fileObj.data);
        await this.ffmpeg.writeFile(virtualName, fileData);

        inputArgs.push('-i', virtualName);
      }

      // 3. Construct filter complex graph for scaling and concat/merging
      const scaleFilter = targetResolution === '1080p' 
        ? 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2'
        : 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2';

      for (let i = 0; i < inputFiles.length; i++) {
        filterComplexParts.push(`[${i}:v]${scaleFilter},setsar=1[v${i}];`);
        filterComplexParts.push(`[${i}:a]aformat=sample_rates=44100:channel_layouts=stereo[a${i}];`);
      }

      let concatString = '';
      for (let i = 0; i < inputFiles.length; i++) {
        concatString += `[v${i}][a${i}]`;
      }
      concatString += `concat=n=${inputFiles.length}:v=1:1[outv][outa]`;

      const filterComplexArgument = filterComplexParts.join('') + concatString;

      // 4. Assemble complete FFmpeg CLI command arguments
      const args = [
        ...inputArgs,
        '-filter_complex', filterComplexArgument,
        '-map', '[outv]',
        '-map', '[outa]',
        '-c:v', 'libx264',
        '-preset', 'ultrafast', // Crucial for client-side performance to avoid UI locking
        '-crf', '28',           // Balanced quality vs file size for browser rendering
        '-c:a', 'aac',
        '-b:a', '128k',
        outputName
      ];

      console.info('Executing FFmpeg command:', args.join(' '));

      // 5. Execute binary execution inside the WASM container
      await this.ffmpeg.exec(args);

      // 6. Read output file from MEMFS and build a downloadable Blob URL
      const data = await this.ffmpeg.readFile(outputName);
      const outputBlob = new Blob([data], { type: 'video/mp4' });
      const videoUrl = URL.createObjectURL(outputBlob);

      // 7. Cleanup virtual file system to free up browser RAM
      for (let i = 0; i < inputFiles.length; i++) {
        const virtualName = `input_${i}.${inputFiles[i].name.split('.').pop() || 'mp4'}`;
        await this.ffmpeg.deleteFile(virtualName);
      }
      await this.ffmpeg.deleteFile(outputName);

      return videoUrl;

    } catch (error) {
      console.error('Error during video transcoding pipeline execution:', error);
      throw error;
    } finally {
      // Remove event listeners to prevent memory leaks
      this.ffmpeg.off('progress', () => {});
    }
  }
}
