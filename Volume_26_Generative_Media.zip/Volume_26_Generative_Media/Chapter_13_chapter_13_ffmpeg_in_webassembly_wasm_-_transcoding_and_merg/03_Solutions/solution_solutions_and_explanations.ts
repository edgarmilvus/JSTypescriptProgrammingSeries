/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export type WorkerRequestType = 'INIT' | 'EXECUTE' | 'TERMINATE';
export type WorkerResponseType = 'READY' | 'PROGRESS' | 'SUCCESS' | 'ERROR' | 'LOG';

export interface WorkerRequest {
  id: string;
  type: WorkerRequestType;
  args?: string[];
  files?: { name: string; data: Uint8Array }[];
}

export interface WorkerResponse {
  id: string;
  type: WorkerResponseType;
  payload?: any;
  message?: string;
}

export class FFmpegWorkerManager {
  private worker: Worker | null = null;
  private callbacks: Map<string, { resolve: (val: any) => void; reject: (err: any) => void }> = new Map();
  private onProgressCallback?: (progress: number, time: number) => void;

  constructor(workerScriptUrl: string, onProgress?: (progress: number, time: number) => void) {
    this.onProgressCallback = onProgress;
    
    // Requirement 2: Verify crossOriginIsolated for SharedArrayBuffer / multi-threading support
    if (typeof window !== 'undefined' && !window.crossOriginIsolated) {
      throw new Error(
        "Cross-Origin Isolation (COI) is required for multi-threaded FFmpeg WASM. " +
        "Ensure headers 'Cross-Origin-Opener-Policy: same-origin' and 'Cross-Origin-Embedder-Policy: require-corp' are set."
      );
    }

    // Requirement 4: Instantiate dedicated Web Worker securely
    this.worker = new Worker(workerScriptUrl, { type: 'module' });
    this.setupListeners();
  }

  private setupListeners(): void {
    if (!this.worker) return;

    this.worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
      const { id, type, payload, message } = event.data;

      if (type === 'PROGRESS') {
        if (this.onProgressCallback && payload) {
          this.onProgressCallback(payload.progress, payload.time);
        }
        return;
      }

      const pending = this.callbacks.get(id);
      if (pending) {
        if (type === 'SUCCESS') {
          pending.resolve(payload);
        } else if (type === 'ERROR') {
          pending.reject(new Error(message || 'Unknown worker error'));
        }
        this.callbacks.delete(id);
      }
    };
  }

  public async initialize(): Promise<void> {
    return this.sendRequest('INIT');
  }

  public async execute(args: string[], files?: { name: string; data: Uint8Array }[]): Promise<any> {
    return this.sendRequest('EXECUTE', args, files);
  }

  private sendRequest(type: WorkerRequestType, args?: string[], files?: { name: string; data: Uint8Array }[]): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!this.worker) {
        return reject(new Error('Worker is not initialized or has been terminated.'));
      }

      const id = Math.random().toString(36.substring(2, 9));
      this.callbacks.set(id, { resolve, reject });

      const request: WorkerRequest = { id, type, args, files };
      this.worker.postMessage(request);
    });
  }

  public terminate(): void {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
      this.callbacks.clear();
    }
  }
}
