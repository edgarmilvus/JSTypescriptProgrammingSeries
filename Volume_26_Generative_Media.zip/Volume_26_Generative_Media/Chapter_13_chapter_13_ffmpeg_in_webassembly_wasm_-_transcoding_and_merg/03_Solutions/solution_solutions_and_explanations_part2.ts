/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface PipelineConfig {
  resolution?: '720p' | '1080p' | '4k';
  videoBitrate?: string;
  audioBitrate?: string;
  watermark?: {
    filename: string;
    position?: 'bottom-right' | 'top-left';
    chromaKey?: { color: string; similarity: number; blend: number };
  };
  trimBounds?: { start: number; duration: number };
  outputContainer: 'mp4' | 'webm';
}

export class MediaPipelineBuilder {
  private config: PipelineConfig;

  constructor(config: PipelineConfig) {
    this.config = config;
  }

  public buildArguments(inputFileName: string, outputFileName: string): string[] {
    const args: string[] = [];

    // Trimming configuration (Seek optimization before input)
    if (this.config.trimBounds) {
      args.push('-ss', this.config.trimBounds.start.toString());
      args.push('-t', this.config.trimBounds.duration.toString());
    }

    args.push('-i', inputFileName);

    // If watermark exists, prepare input for second stream
    if (this.config.watermark) {
      args.push('-i', this.config.watermark.filename);
    }

    const filterComplexParts: string[] = [];
    let currentVideoLabel = '0:v';

    // 1. Resolution Scaling Filter
    if (this.config.resolution) {
      const scaleMap = { '720p': '1280:720', '1080p': '1920:1080', '4k': '3840:2160' };
      const dim = scaleMap[this.config.resolution];
      filterComplexParts.push(`[${currentVideoLabel}]scale=${dim}:flags=lanczos[scaled]`);
      currentVideoLabel = 'scaled';
    }

    // 2. Dynamic Watermark & Chroma Keying Filter (Challenge implementation)
    if (this.config.watermark) {
      let wmLabel = '1:v';
      if (this.config.watermark.chromaKey) {
        const { color, similarity, blend } = this.config.watermark.chromaKey;
        filterComplexParts.push(`[1:v]chromakey=${color}:${similarity}:${blend}[ckout]`);
        wmLabel = 'ckout';
      }

      const overlayPos = this.config.watermark.position === 'top-left' ? '10:10' : 'W-w-10:H-h-10';
      filterComplexParts.push(`[${currentVideoLabel}][${wmLabel}]overlay=${overlayPos}[vmapped]`);
      currentVideoLabel = 'vmapped';
    }

    // Append filter_complex if any filters were added
    if (filterComplexParts.length > 0) {
      args.push('-filter_complex', filterComplexParts.join(';'));
      args.push('-map', `[${currentVideoLabel}]`);
      args.push('-map', '0:a?'); // Map audio from input if present
    }

     // Codec configuration based on container format
     if (this.config.outputContainer === 'mp4') {
      args.push('-c:v', 'libx264', '-preset', 'fast');
      args.push('-c:a', 'aac');
    } else {
      args.push('-c:v', 'libvpx-vp9');
      args.push('-c:a', 'libopus');
    }

    if (this.config.videoBitrate) args.push('-b:v', this.config.videoBitrate);
    if (this.config.audioBitrate) args.push('-b:a', this.config.audioBitrate);

    args.push(outputFileName);
    return args;
  }
}
