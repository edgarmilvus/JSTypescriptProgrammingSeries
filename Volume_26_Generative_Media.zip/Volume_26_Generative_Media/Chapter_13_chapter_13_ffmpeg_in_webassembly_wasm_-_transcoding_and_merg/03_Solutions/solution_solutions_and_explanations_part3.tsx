/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { FFmpegWorkerManager } from './FFmpegWorkerManager'; // Assumed path from previous exercises
import { MediaPipelineBuilder, PipelineConfig } from './MediaPipelineBuilder';
import { MemfsRingBuffer } from './MemfsRingBuffer';

export interface WasmTranscodeStudioProps {
  maxFileSizeMB?: number;
  onTranscodeComplete?: (outputBlob: Blob) => void;
}

export const WasmTranscodeStudio: React.FC<WasmTranscodeStudioProps> = ({
  maxFileSizeMB = 500,
  onTranscodeComplete,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>('Idle');
  const [progress, setProgress] = useState<number>(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  
  const [resolution, setResolution] = useState<'720p' | '1080p' | '4k'>('1080p');
  const [container, setContainer] = useState<'mp4' | 'webm'>('mp4');

  const workerManagerRef = useRef<FFmpegWorkerManager | null>(null);
  const previewVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    try {
      workerManagerRef.current = new FFmpegWorkerManager('/ffmpeg-worker.js', (p) => {
        setProgress(Math.round(p * 100));
      });
      setStatus('Initializing WASM Environment...');
      workerManagerRef.current.initialize().then(() => {
        setStatus('Ready');
      }).catch((err) => {
        setStatus(`Initialization Error: ${err.message}`);
      });
    } catch (e: any) {
      setStatus(`Configuration Error: ${e.message}`);
    }

    return () => {
      workerManagerRef.current?.terminate();
    };
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.size > maxFileSizeMB * 1024 * 1024) {
        alert(`File exceeds maximum size limit of ${maxFileSizeMB}MB`);
        return;
      }
      setFile(droppedFile);
      setStatus('File loaded. Ready to transcode.');
    }
  }, [maxFileSizeMB]);

  const executeTranscode = async () => {
    if (!file || !workerManagerRef.current) return;

    try {
      setStatus('Writing file to Virtual File System (MEMFS)...');
      const ringBuffer = new MemfsRingBuffer(5);
      const inputName = 'input_source.' + file.name.split('.').pop();
      const outputName = `output_transcoded.${container}`;
      
      const arrayBuffer = await file.arrayBuffer();
      const fileData = new Uint8Array(arrayBuffer);

      // Execute Transcode pipeline args
      const pipelineConfig: PipelineConfig = {
        resolution,
        outputContainer: container,
      };

      const builder = new MediaPipelineBuilder(pipelineConfig);
      const args = builder.buildArguments(inputName, outputName);

      setStatus('Executing Transcode Pipeline...');
      const resultFiles = await workerManagerRef.current.execute(args, [{ name: inputName, data: fileData }]);

      // Retrieve final output blob from worker result payload
      const outputData = resultFiles[outputName];
      const outputBlob = new Blob([outputData], { type: `video/${container}` });
      const url = URL.createObjectURL(outputBlob);
      
      setOutputUrl(url);
      setStatus('Complete');
      if (onTranscodeComplete) onTranscodeComplete(outputBlob);

      // Challenge: Extract keyframe thumbnails
      // (Simplified invocation demonstrating auxiliary pass handling)
      generateThumbnails(inputName);

    } catch (err: any) {
      setStatus(`Error: ${err.message}`);
    }
  };

  const generateThumbnails = async (inputName: string) => {
    // Secondary fast pass for thumbnail extraction at regular intervals
    if (!workerManagerRef.current) return;
    const thumbArgs = ['-i', inputName, '-vf', 'fps=1/5,scale=160:90', 'thumb_%d.jpg'];
    try {
      const res = await workerManagerRef.current.execute(thumbArgs);
      const thumbUrls: string[] = [];
      Object.keys(res).forEach((key) => {
        if (key.startsWith('thumb_')) {
          const blob = new Blob([res[key]], { type: 'image/jpeg' });
          thumbUrls.push(URL.createObjectURL(blob));
        }
      });
      setThumbnails(thumbUrls);
    } catch (e) {
      console.error('Thumbnail generation failed', e);
    }
  };

  const seekToThumbnail = (seconds: number) => {
    if (previewVideoRef.current) {
      previewVideoRef.current.currentTime = seconds;
      previewVideoRef.current.play();
    }
  };

  return (
    <div className="wasm-transcode-studio" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Client-Side Video Transcoding Studio</h2>
      
      <div 
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        style={{ border: '2px dashed #ccc', padding: '30px', textAlign: 'center', marginBottom: '20px', borderRadius: '8px' }}
      >
        {file ? <p>Selected File: {file.name} ({(file.size / (1024*1024)).toFixed(2)} MB)</p> : <p>Drag & Drop a video file here</p>}
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label>Resolution: </label>
        <select value={resolution} onChange={(e: any) => setResolution(e.target.value)}>
          <option value="720p">720p</option>
          <option value="1080p">1080p</option>
          <option value="4k">4K</option>
        </select>

        <label style={{ marginLeft: '15px' }}>Container: </label>
        <select value={container} onChange={(e: any) => setContainer(e.target.value)}>
          <option value="mp4">MP4</option>
          <option value="webm">WebM</option>
        </select>

        <button 
          onClick={executeTranscode} 
          disabled={!file || status.includes('Executing')}
          style={{ marginLeft: '20px', padding: '8px 16px', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Start Transcode
        </button>
      </div>

      <div>
        <p><strong>Status:</strong> {status}</p>
        <div style={{ width: '100%', background: '#eee', height: '20px', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ width: `${progress}%`, background: '#28a745', height: '100%', transition: 'width 0.2s' }} />
        </div>
      </div>

      {thumbnails.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>Keyframe Thumbnails:</h4>
          <div style={{ display: 'flex', gap: '10px' }}>
            {thumbnails.map((url, idx) => (
              <img 
                key={idx} 
                src={url} 
                alt={`Thumbnail ${idx}`} 
                onClick={() => seekToThumbnail(idx * 5)} 
                style={{ cursor: 'pointer', border: '2px solid #ddd', borderRadius: '4px', width: '120px' }} 
              />
            ))}
          </div>
        </div>
      )}

      {outputUrl && (
        <div style={{ marginTop: '30px' }}>
          <h3>Preview Result</h3>
          <video ref={previewVideoRef} src={outputUrl} controls style={{ width: '100%', maxWidth: '640px', display: 'block', marginBottom: '10px' }} />
          <a 
            href={outputUrl} 
            download={`transcoded_video.${container}`}
            style={{ display: 'inline-block', padding: '10px 20px', background: '#28a745', color: '#fff', textDecoration: 'none', borderRadius: '4px' }}
          >
            Download Processed File
          </a>
        </div>
      )}
    </div>
  );
};
