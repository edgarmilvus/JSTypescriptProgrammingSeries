/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.tsx
// Description: Practical Exercises
// ==========================================

// Example skeleton structure to guide your implementation
import React, { useState, useEffect, useRef } from 'react';

export interface WasmTranscodeStudioProps {
  maxFileSizeMB?: number;
  onTranscodeComplete?: (outputBlob: Blob) => void;
}

export const WasmTranscodeStudio: React.FC<WasmTranscodeStudioProps> = ({
  maxFileSizeMB = 500,
  onTranscodeComplete,
}) => {
  // TODO: Implement state hooks for file, status, progress, and settings
  // TODO: Instantiate and manage FFmpegWorkerManager lifecycle via useEffect
  // TODO: Build UI markup for dropzone, configuration form, progress view, and result preview

  return (
    <div className="wasm-transcode-studio">
      <h2>Client-Side Video Transcoding Studio</h2>
      {/* Implement your component layout here */}
    </div>
  );
};
