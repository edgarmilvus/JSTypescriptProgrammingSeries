/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph PipelineOverview {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", fontsize=10];

    subgraph cluster_capture {
        label = "Input Stage";
        style=filled;
        color="#e2e8f0";
        Capture [label="Live Video Stream / Canvas Input"];
    }

    subgraph cluster_compute {
        label = "Inference & Masking";
        style=filled;
        color="#e2e8f0";
        Transformers [label="Transformers.js / ONNX Runtime\n(Semantic Segmentation)"];
        Matting [label="Alpha Matting & Edge Refinement"];
    }

    subgraph cluster_render {
        label = "Compositing Stage";
        style=filled;
        color="#e2e8f0";
        WebGPU [label="WebGPU / WebGL Shaders\n(Inpainting & Blending)"];
        DOM [label="Browser DOM / Output Canvas"];
    }

    Capture -> Transformers;
    Transformers -> Matting;
    Matting -> WebGPU;
    WebGPU -> DOM;
}
