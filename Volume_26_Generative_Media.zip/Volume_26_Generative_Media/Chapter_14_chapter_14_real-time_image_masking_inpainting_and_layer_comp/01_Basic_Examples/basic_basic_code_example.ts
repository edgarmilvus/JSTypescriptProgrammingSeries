/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * ============================================================================
 * DOMAIN MODELS & ZOD SCHEMAS (Runtime Validation Layer)
 * ============================================================================
 */

// 1. Define the Zod schema for an incoming layer mask payload from our AI worker.
const MaskPayloadSchema = z.object({
    jobId: z.string().uuid(),
    layerIndex: z.number().int().min(0).max(99),
    opacity: z.number().min(0).max(1),
    blendMode: z.enum(['normal', 'multiply', 'screen', 'overlay']),
    maskDataUri: z.string().url().startsWith('data:image/'),
});

// Infer the static TypeScript type from the runtime Zod schema.
type MaskPayload = z.infer<typeof MaskPayloadSchema>;

// 2. Define structural types for our hierarchical agentic workflow.
interface SupervisorDirective {
    readonly supervisorId: string;
    readonly targetLayer: number;
    actionType: 'INPAINT' | 'MATTE' | 'COMPOSITE';
    payload: unknown; // Untrusted input requiring guards
}

interface ValidatedAgentTask {
    readonly supervisorId: string;
    readonly targetLayer: number;
    actionType: 'INPAINT' | 'MATTE' | 'COMPOSITE';
    validatedPayload: MaskPayload;
}

/**
 * ============================================================================
 * TYPE GUARDS (Compile-Time Narrowing & Runtime Checking)
 * ============================================================================
 */

/**
 * User-defined type guard to check if an unknown payload is a valid MaskPayload.
 * This bridges the gap between external untrusted data and our strict WebGL pipeline.
 */
function isMaskPayload(data: unknown): data is MaskPayload {
    const result = MaskPayloadSchema.safeParse(data);
    return result.success;
}

/**
 * Type guard for checking if a supervisor directive contains a runnable payload.
 */
function isValidSupervisorDirective(directive: unknown): directive is SupervisorDirective {
    if (typeof directive !== 'object' || directive === null) {
        return false;
    }
    const candidate = directive as Record<string, unknown>;
    return (
        typeof candidate.supervisorId === 'string' &&
        typeof candidate.targetLayer === 'number' &&
        ['INPAINT', 'MATTE', 'COMPOSITE'].includes(candidate.actionType as string)
    );
}

/**
 * ============================================================================
 * HIERARCHICAL AGENTIC WORKFLOW & RENDERING PIPELINE
 * ============================================================================
 */

class WebGPULayerCompositorEngine {
    private activeLayers: Map<number, MaskPayload> = new Map();

    /**
     * Updates a specific compositing layer after ensuring complete type safety.
     */
    public applyLayerUpdate(task: ValidatedAgentTask): void {
        const { targetLayer, validatedPayload } = task;
        
        // Safe mutation of internal WebGPU layer state
        this.activeLayers.set(targetLayer, validatedPayload);
        
        console.log(`[Engine] Layer ${targetLayer} successfully updated by Supervisor ${task.supervisorId}.`);
        console.log(`[Engine] Rendering blend mode: ${validatedPayload.blendMode} at opacity ${validatedPayload.opacity}`);
    }

    public getLayer(index: number): MaskPayload | undefined {
        return this.activeLayers.get(index);
    }
}

/**
 * Central orchestrator managing the hierarchical agent dispatch loop.
 */
class HierarchicalAgentOrchestrator {
    private compositor = new WebGPULayerCompositorEngine();

    /**
     * Processes incoming raw messages from the AI backend cluster.
     */
    public handleIncomingWorkerMessage(rawMessage: unknown): void {
        // Step 1: Validate structural shape of the supervisor directive
        if (!isValidSupervisorDirective(rawMessage)) {
            console.error('[Orchestrator] Security Alert: Received malformed supervisor directive.');
            return;
        }

        // At this point, TypeScript knows rawMessage is a SupervisorDirective
        console.log(`[Orchestrator] Processing directive from supervisor: ${rawMessage.supervisorId}`);

        // Step 2: Validate the inner payload via Zod and user-defined type guards
        if (!isMaskPayload(rawMessage.payload)) {
            console.error('[Orchestrator] Validation Error: Payload failed Zod schema enforcement.');
            return;
        }

        // Step 3: Construct the safe, validated task for execution
        const safeTask: ValidatedAgentTask = {
            supervisorId: rawMessage.supervisorId,
            targetLayer: rawMessage.targetLayer,
            actionType: rawMessage.actionType,
            validatedPayload: rawMessage.payload, // Narrowed and guaranteed safe
        };

        // Step 4: Dispatch to the rendering engine pipeline
        this.compositor.applyLayerUpdate(safeTask);
    }
}

/**
 * ============================================================================
 * EXECUTION SIMULATION (Hello World Integration)
 * ============================================================================
 */

const orchestrator = new HierarchicalAgentOrchestrator();

// Simulating a malicious or malformed message from an untrusted WebSocket source
const malformedInput = {
    supervisorId: "sup-alpha-01",
    targetLayer: 2,
    actionType: "INPAINT",
    payload: {
        jobId: "not-a-uuid", // Fails UUID validation
        layerIndex: 999,      // Fails max range validation
        opacity: 1.5,         // Fails max opacity boundary (must be <= 1)
        blendMode: "invalid-blend", // Fails enum check
        maskDataUri: "not-a-url"    // Fails URL check
    }
};

console.log("--- Test 1: Processing Malformed Input ---");
orchestrator.handleIncomingWorkerMessage(malformedInput);

// Simulating a valid, well-formed message from the AI inpainting worker
const validWebsocketPayload = {
    supervisorId: "sup-alpha-01",
    targetLayer: 1,
    actionType: "MATTE",
    payload: {
        jobId: "a1b2c3d4-e5f6-7890-abcd-ef0123456789",
        layerIndex: 1,
        opacity: 0.85,
        blendMode: "multiply",
        maskDataUri: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
    }
};

console.log("\n--- Test 2: Processing Valid Input ---");
orchestrator.handleIncomingWorkerMessage(validWebsocketPayload);
