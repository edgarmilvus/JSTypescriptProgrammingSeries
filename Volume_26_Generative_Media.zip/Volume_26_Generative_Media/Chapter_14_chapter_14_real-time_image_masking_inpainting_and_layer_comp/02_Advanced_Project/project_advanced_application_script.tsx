/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';

/**
 * Interface representing a compositing layer within our node-based canvas engine.
 */
interface CompositingLayer {
  id: string;
  name: string;
  visible: boolean;
  opacity: number;
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay';
  texture: GPUTexture | null;
  sampler: GPUSampler | null;
}

/**
 * Configuration options for the WebGPU pipeline execution context.
 */
interface PipelineConfig {
  width: number;
  height: number;
  format: GPUTextureFormat;
}

/**
 * SaaS Image Compositor & Masking Engine Component
 */
export default function RealTimeCompositorApp() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [fps, setFps] = useState<number>(0);
  const [activeLayers, setActiveLayers] = useState<CompositingLayer[]>([]);

  // WebGPU Core References stored in refs to avoid React re-render cycles
  const deviceRef = useRef<GPUDevice | null>(null);
  const contextRef = useRef<GPUCanvasContext | null>(null);
  const pipelineRef = useRef<GPURenderPipeline | null>(null);
  const uniformBufferRef = useRef<GPUBuffer | null>(null);
  const bindGroupRef = useRef<GPUBindGroup | null>(null);

  /**
   * 1. Initialize WebGPU Adapter, Device, and Swapchain Context
   */
  const initializeWebGPU = useCallback(async () => {
    if (!canvasRef.current) return;

    if (!navigator.gpu) {
      alert('WebGPU is not supported in this browser. Please enable experimental flags.');
      return;
    }

    // Request high-performance adapter
    const adapter = await navigator.gpu.requestAdapter({
      powerPreference: 'high-performance',
    });

    if (!adapter) {
      throw new Error('Failed to secure an appropriate WebGPU adapter.');
    }

    // Request logical device with required limits
    const device = await adapter.requestDevice();
    deviceRef.current = device;

    const context = canvasRef.current.getContext('webgpu') as GPUCanvasContext;
    if (!context) {
      throw new Error('Failed to acquire WebGPU canvas rendering context.');
    }
    contextRef.current = context;

    const canvasFormat = navigator.gpu.getPreferredCanvasFormat();
    context.configure({
      device,
      format: canvasFormat,
      alphaMode: 'premultiplied',
    });

    // Load Shaders and Compile Pipelines
    await setupRenderPipeline(device, canvasFormat);
    
    // Allocate persistent uniform buffers for transformations and layer weights
    setupUniformBuffers(device);

    setIsInitialized(true);
  }, []);

  /**
   * 2. Compile WGSL Shaders and Configure the Render Pipeline
   */
  const setupRenderPipeline = async (device: GPUDevice, format: GPUTextureFormat) => {
    const shaderModule = device.createShaderModule({
      code: `
        struct Uniforms {
          resolution: vec2<f32>,
          time: f32,
          layerOpacity: f32,
        };

        @binding(0) @group(0) var<uniform> uniforms: Uniforms;
        @binding(1) @group(0) var baseTexture: texture_2d<f32>;
        @binding(2) @group(0) var maskTexture: texture_2d<f32>;
        @binding(3) @group(0) var imageSampler: sampler;

        struct VertexOutput {
          @builtin(position) position: vec4<f32>,
          @location(0) uv: vec2<f32>,
        };

        @vertex
        fn vs_main(@builtin(vertex_index) vertexIndex: u32) -> VertexOutput {
          var pos = array<vec2<f32>, 6>(
            vec2<f32>(-1.0, -1.0),
            vec2<f32>(1.0, -1.0),
            vec2<f32>(-1.0,  1.0),
            vec2<f32>(-1.0,  1.0),
            vec2<f32>(1.0, -1.0),
            vec2<f32>(1.0,  1.0)
          );

          var uv = array<vec2<f32>, 6>(
            vec2<f32>(0.0, 1.0),
            vec2<f32>(1.0, 1.0),
            vec2<f32>(0.0, 0.0),
            vec2<f32>(0.0, 0.0),
            vec2<f32>(1.0, 1.0),
            vec2<f32>(1.0, 0.0)
          );

          var output: VertexOutput;
          output.position = vec4<f32>(pos[vertexIndex], 0.0, 1.0);
          output.uv = uv[vertexIndex];
          return output;
        }

        @fragment
        fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
          let baseColor = textureSample(baseTexture, imageSampler, input.uv);
          let maskColor = textureSample(maskTexture, imageSampler, input.uv);
          
          // Apply real-time alpha matting composition
          let finalAlpha = baseColor.a * maskColor.r * uniforms.layerOpacity;
          return vec4<f32>(baseColor.rgb * finalAlpha, finalAlpha);
        }
      `,
    });

    const pipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex: {
        module: shaderModule,
        entryPoint: 'vs_main',
      },
      fragment: {
        module: shaderModule,
        entryPoint: 'fs_main',
        targets: [{ format }],
      },
      primitive: {
        topology: 'triangle-list',
      },
    });

    pipelineRef.current = pipeline;
  };

  /**
   * 3. Allocate Uniform Buffers for Frame-Level State updates
   */
  const setupUniformBuffers = (device: GPUDevice) => {
    // 16 bytes for resolution (vec2<f32>) + time (f32) + layerOpacity (f32) aligned to 16 bytes
    const uniformBufferSize = 16; 
    const uniformBuffer = device.createBuffer({
      size: uniformBufferSize,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });

    uniformBufferRef.current = uniformBuffer;
  };

  /**
   * 4. Core Render Loop for 60fps Real-Time Processing
   */
  useEffect(() => {
    initializeWebGPU();

    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;

    const render = (currentTime: number) => {
      frameCount++;
      if (currentTime - lastTime >= 1000) {
        setFps(Math.round((frameCount * 1000) / (currentTime - lastTime)));
        frameCount = 0;
        lastTime = currentTime;
      }

      if (
        deviceRef.current &&
        contextRef.current &&
        pipelineRef.current &&
        uniformBufferRef.current
      ) {
        const commandEncoder = deviceRef.current.createCommandEncoder();
        const textureView = contextRef.current.getCurrentTexture().createView();

        const renderPassDescriptor: GPURenderPassDescriptor = {
          colorAttachments: [
            {
              view: textureView,
              clearValue: { r: 0.05, g: 0.05, b: 0.05, a: 1.0 },
              loadOp: 'clear',
              storeOp: 'store',
            },
          ],
        };

        const passEncoder = commandEncoder.beginRenderPass(renderPassDescriptor);
        passEncoder.setPipeline(pipelineRef.current);
        
        // Draw primitives bound via pipeline layout
        passEncoder.draw(6, 1, 0, 0);
        passEncoder.end();

        deviceRef.current.queue.submit([commandEncoder.finish()]);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [initializeWebGPU]);

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 p-6">
      <header className="flex justify-between items-center mb-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Real-Time WebGPU Compositor</h1>
          <p className="text-sm text-slate-400">Chapter 14: Inpainting, Masking & Alpha Matting Pipeline</p>
        </div>
        <div className="flex items-center gap-4 bg-slate-900 px-4 py-2 rounded-lg border border-slate-800">
          <span className="text-xs uppercase tracking-wider text-slate-400">Status:</span>
          <span className={`h-2.5 w-2.5 rounded-full ${isInitialized ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          <span className="text-sm font-mono font-medium">{isInitialized ? `${fps} FPS` : 'Initializing...'}</span>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1 overflow-hidden">
        {/* Canvas Workspace */}
        <div className="lg:col-span-3 bg-slate-900/50 rounded-xl border border-slate-800/80 flex items-center justify-center p-4 relative overflow-hidden">
          <canvas
            ref={canvasRef}
            width={1024}
            height={768}
            className="max-w-full max-h-full object-contain rounded shadow-2xl border border-slate-800"
          />
        </div>

        {/* Layer Management & Properties Panel */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 overflow-y-auto">
          <h2 className="text-lg font-semibold tracking-wide border-b border-slate-800 pb-2">Compositing Layers</h2>
          <div className="flex flex-col gap-2 flex-1">
            {activeLayers.length === 0 ? (
              <p className="text-sm text-slate-500 italic text-center mt-8">No active layers loaded. Import a video stream or asset mask.</p>
            ) : (
              activeLayers.map((layer) => (
                <div key={layer.id} className="bg-slate-950/60 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{layer.name}</span>
                    <span className="text-xs text-slate-400 uppercase">{layer.blendMode}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
