/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define base and specific node interfaces
export interface BaseNode {
  id: string;
  name: string;
  x: number;
  y: number;
}

export interface ImageNode extends BaseNode {
  type: 'image';
  url: string;
  width?: number;
  height?: number;
}

export interface ShaderNode extends BaseNode {
  type: 'shader';
  shaderSource: string;
  uniforms: Record<string, number | number[]>;
}

export interface VideoNode extends BaseNode {
  type: 'video';
  streamId: string;
  fps: number;
  isMuted: boolean;
}

export interface MaskNode extends BaseNode {
  type: 'mask';
  featherRadius: number;
  invert: boolean;
}

// 2. Union type encompassing all specific nodes
export type CanvasNode = ImageNode | ShaderNode | VideoNode | MaskNode;

// 3. User-defined type guards
export function isImageNode(value: unknown): value is ImageNode {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as BaseNode).type === 'image' &&
    typeof (value as BaseNode).id === 'string' &&
    typeof (value as ImageNode).url === 'string'
  );
}

export function isShaderNode(value: unknown): value is ShaderNode {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as BaseNode).type === 'shader' &&
    typeof (value as BaseNode).id === 'string' &&
    typeof (value as ShaderNode).shaderSource === 'string' &&
    typeof (value as ShaderNode).uniforms === 'object'
  );
}

export function isVideoNode(value: unknown): value is VideoNode {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as BaseNode).type === 'video' &&
    typeof (value as BaseNode).id === 'string' &&
    typeof (value as VideoNode).streamId === 'string' &&
    typeof (value as VideoNode).fps === 'number' &&
    typeof (value as VideoNode).isMuted === 'boolean'
  );
}

export function isMaskNode(value: unknown): value is MaskNode {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as BaseNode).type === 'mask' &&
    typeof (value as BaseNode).id === 'string' &&
    typeof (value as MaskNode).featherRadius === 'number' &&
    typeof (value as MaskNode).invert === 'boolean'
  );
}

// 4. Composite type guard checking general structural integrity
export function isCanvasNode(value: unknown): value is CanvasNode {
  return (
    isImageNode(value) ||
    isShaderNode(value) ||
    isVideoNode(value) ||
    isMaskNode(value)
  );
}

// 5. Processing function leveraging type guards
export function processNode(node: unknown): void {
  if (!isCanvasNode(node)) {
    console.warn("Attempted to process invalid node structure:", node);
    return;
  }

  // TypeScript now narrows `node` based on the discriminant `type`
  switch (node.type) {
    case 'shader':
      console.log(`Updating uniforms for shader: ${node.name}`, node.uniforms);
      break;
    case 'image':
      console.log(`Loading image asset from URL: ${node.url}`);
      break;
    case 'video':
      console.log(`Binding video stream ${node.streamId} at ${node.fps} FPS`);
      break;
    case 'mask':
      console.log(`Configuring mask with feather radius: ${node.featherRadius}`);
      break;
  }
}

// Interactive Challenge: Filter and Cast Graph Function
export function filterAndCastGraph(rawNodes: unknown[]): CanvasNode[] {
  const validNodes: CanvasNode[] = [];

  rawNodes.forEach((rawNode, index) => {
    if (isCanvasNode(rawNode)) {
      validNodes.push(rawNode);
    } else {
      console.warn(`[Node Graph Validation] Malformed or unknown node discarded at index ${index}:`, rawNode);
    }
  });

  return validNodes;
}
