/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect, useState, useCallback } from 'react';

export interface InpaintingCanvasProps {
  imageUrl: string;
  brushSize: number;
  brushHardness: number;
  mode: 'paint' | 'erase';
  onMaskUpdate: (maskTexture: ImageBitmap | ImageData) => void;
}

interface Point {
  x: number;
  y: number;
}

export const InpaintingCanvas: React.FC<InpaintingCanvasProps> = ({
  imageUrl,
  brushSize,
  brushHardness,
  mode,
  onMaskUpdate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const maskCanvasRef = useRef<HTMLCanvasElement | null>(null);
  
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [hasError, setHasError] = useState<boolean>(false);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);

  const pointsRef = useRef<Point[]>([]);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const rafIdRef = useRef<number | null>(null);

  // Initialize backing canvases and load base image
  useEffect(() => {
    const canvas = canvasRef.getcurrent();
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      setHasError(true);
      return;
    }

    const maskCanvas = document.createElement('canvas');
    maskCanvasRef.current = maskCanvas;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageUrl;

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      maskCanvas.width = img.width;
      maskCanvas.height = img.height;

      const maskCtx = maskCanvas.getContext('2d');
      if (maskCtx) {
        maskCtx.fillStyle = 'black';
        maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
      }

      imageRef.current = img;
      ctx.drawImage(img, 0, 0);
      setIsLoading(false);
    };

    img.onerror = () => {
      setIsLoading(false);
      setHasError(true);
    };
  }, [imageUrl]);

  // Render loop using requestAnimationFrame for smooth drawing updates
  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    const maskCanvas = maskCanvasRef.current;
    const img = imageRef.current;
    if (!canvas || !maskCanvas || !img) return;

    const ctx = canvas.getContext('2d');
    const maskCtx = maskCanvas.getContext('2d');
    if (!ctx || !maskCtx) return;

    // Redraw base image
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);

    // Draw current mask stroke data with low opacity overlay
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = 'rgba(255, 0, 0, 1)';
    
    // Composite mask onto main canvas display
    ctx.drawImage(maskCanvas, 0, 0);
    ctx.restore();
  }, []);

  // Process stroke coordinate queue with quadratic interpolation
  const processStrokeQueue = useCallback(() => {
    const maskCanvas = maskCanvasRef.current;
    if (!maskCanvas) return;
    const maskCtx = maskCanvas.getContext('2d');
    if (!maskCtx) return;

    const pts = pointsRef.current;
    if (pts.length < 2) return;

    maskCtx.save();
    maskCtx.lineCap = 'round';
    maskCtx.lineJoin = 'round';
    maskCtx.lineWidth = brushSize * 2;
    maskCtx.strokeStyle = mode === 'paint' ? 'white' : 'black';
    maskCtx.fillStyle = mode === 'paint' ? 'white' : 'black';

    if (pts.length === 2) {
      maskCtx.beginPath();
      maskCtx.moveTo(pts[0].x, pts[0].y);
      maskCtx.lineTo(pts[1].x, pts[1].y);
      maskCtx.stroke();
    } else {
      maskCtx.beginPath();
      maskCtx.moveTo(pts[0].x, pts[0].y);
      
      let i = 1;
      for (i = 1; i < pts.length - 2; i++) {
        const xc = (pts[i].x + pts[i + 1].x) / 2;
        const yc = (pts[i].y + pts[i + 1].y) / 2;
        maskCtx.quadraticCurveTo(pts[i].x, pts[i].y, xc, yc);
      }
      // Curve through remaining points
      if (pts[i]) {
        maskCtx.quadraticCurveTo(pts[i].x, pts[i].y, pts[pts.length - 1].x, pts[pts.length - 1].y);
      }
      maskCtx.stroke();
    }
    maskCtx.restore();

    // Clear processed points except last for continuity
    pointsRef.current = [pts[pts.length - 1]];

    redraw();
    rafIdRef.current = null;
  }, [brushSize, mode, redraw]);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    setIsDrawing(true);
    pointsRef.current = [{ x, y }];

    // Draw single point click dot immediately
    const maskCanvas = maskCanvasRef.current;
    const maskCtx = maskCanvas?.getContext('2d');
    if (maskCtx) {
      maskCtx.fillStyle = mode === 'paint' ? 'white' : 'black';
      maskCtx.beginPath();
      maskCtx.arc(x, y, brushSize, 0, Math.PI * 2);
      maskCtx.fill();
      redraw();
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    pointsRef.current.push({ x, y });

    if (!rafIdRef.current) {
      rafIdRef.current = requestAnimationFrame(processStrokeQueue);
    }
  };

  const handlePointerUp = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    pointsRef.current = [];

    if (rafIdRef.current) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }

    const maskCanvas = maskCanvasRef.current;
    if (maskCanvas) {
      const maskCtx = maskCanvas.getContext('2d');
      if (maskCtx) {
        const imageData = maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
        onMaskUpdate(imageData);
      }
    }
  };

  if (hasError) return <div>Error loading base image for inpainting canvas.</div>;
  if (isLoading) return <div>Loading image canvas textures...</div>;

  return (
    <canvas
      ref={canvasRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      style={{ touchAction: 'none', cursor: 'crosshair', maxWidth: '100%', height: 'auto' }}
    />
  );
};
