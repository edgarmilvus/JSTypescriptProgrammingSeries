/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Mock typing for Transformers.js pipeline factory integration
type SegmentationPipeline = (input: HTMLVideoElement | ImageData) => Promise<Array<{ mask: { data: Float32Array; width: number; height: number } }>>;

export interface PipelineConfig {
  targetFps: number;
  inferenceWidth: number;
  inferenceHeight: number;
}

export class MediaStreamingPipeline {
  private videoElement: HTMLVideoElement;
  private glContext: WebGL2RenderingContext;
  private config: PipelineConfig;
  private segmenter: SegmentationPipeline | null = null;
  
  private isRunning: boolean = false;
  private isBusy: boolean = false;
  private frameCount: number = 0;
  private lastFrameTime: number = 0;
  private animFrameId: number | null = null;
  
  private skipInterval: number = 1;
  private currentWidth: number;
  private currentHeight: number;
  private latestMaskTexture: WebGLTexture | null = null;

  constructor(videoElement: HTMLVideoElement, glContext: WebGL2RenderingContext, config: PipelineConfig) {
    this.videoElement = videoElement;
    this.glContext = glContext;
    this.config = config;
    this.currentWidth = config.inferenceWidth;
    this.currentHeight = config.inferenceHeight;
  }

  public async initialize(pipelineFactory: (task: string, model: string) => Promise<SegmentationPipeline>): Promise<void> {
    try {
      // Initialize Transformers.js background segmentation model
      this.segmenter = await pipelineFactory('image-segmentation', 'Xenova/segformer-b0-finetuned-ade-20k-500');
      
      // Allocate backing WebGL texture for mask composition
      const gl = this.glContext;
      this.latestMaskTexture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.latestMaskTexture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    } catch (err) {
      console.error("Failed to initialize MediaStreamingPipeline segmentation model:", err);
      throw err;
    }
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastFrameTime = performance.now();
    this.loop();
  }

  public stop(): void {
    this.isRunning = false;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }

  private loop = (): void => {
    if (!this.isRunning) return;

    const now = performance.now();
    const delta = now - this.lastFrameTime;

    // Check if model is idle and frame-skipping interval condition is met
    if (!this.isBusy && this.frameCount % this.skipInterval === 0 && this.segmenter && this.videoElement.readyState >= 2) {
      this.isBusy = true;
      const inferenceStart = performance.now();

      this.segmenter(this.videoElement)
        .then((output) => {
          const inferenceDuration = performance.now() - inferenceStart;
          this.handleInferenceResult(output);
          this.adaptPerformance(inferenceDuration);
        })
        .catch((err) => {
          console.warn("Segmentation inference error:", err);
        })
        .finally(() => {
          this.isBusy = false;
        });
    }

    this.frameCount++;
    this.lastFrameTime = now;
    this.renderFrame();

    this.animFrameId = requestAnimationFrame(this.loop);
  };

  private handleInferenceResult(output: Array<{ mask: { data: Float32Array; width: number; height: number } }>):: void {
    if (!output || output.length === 0 || !this.latestMaskTexture) return;

    const maskData = output[0].mask;
    const gl = this.glContext;

    // Convert float mask tensor to Uint8Array alpha channel
    const uint8Mask = new Uint8Array(maskData.data.length);
    for (let i = 0; i < maskData.data.length; i++) {
      uint8Mask[i] = Math.floor(maskData.data[i] * 255);
    }

    gl.bindTexture(gl.TEXTURE_2D, this.latestMaskTexture);
    gl.texImage2D(
      gl.TEXTURE_2D,
      0,
      gl.LUMINANCE,
      maskData.width,
      maskData.height,
      0,
      gl.LUMINANCE,
      gl.UNSIGNED_BYTE,
      uint8Mask
    );
  }

  private adaptPerformance(durationMs: number): void {
    // Adaptive controller: If inference takes > 33ms (< 30fps), downscale and skip frames
    if (durationMs > 33) {
      this.skipInterval = Math.min(this.skipInterval + 1, 5);
      this.currentWidth = Math.max(128, Math.floor(this.currentWidth * 0.8));
      this.currentHeight = Math.max(128, Math.floor(this.currentHeight * 0.8));
    } else if (durationMs < 15 && this.skipInterval > 1) {
      this.skipInterval = Math.max(1, this.skipInterval - 1);
      this.currentWidth = Math.min(this.config.inferenceWidth, Math.floor(this.currentWidth * 1.1));
      this.currentHeight = Math.min(this.config.inferenceHeight, Math.floor(this.currentHeight * 1.1));
    }
  }

  private renderFrame(): void {
    const gl = this.glContext;
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Compositing step combining video background and latest segmentation mask texture
  }

  public dispose(): void {
    this.stop();
    if (this.latestMaskTexture) {
      this.glContext.deleteTexture(this.latestMaskTexture);
      this.latestMaskTexture = null;
    }
  }
}
