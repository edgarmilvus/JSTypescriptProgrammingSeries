/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export const COMPOSITE_COMPUTE_WGSL = /* wgsl */ `
struct LayerParams {
  opacity: f32,
  blendMode: u32,
  hasClippingMask: u32,
  _padding: f32,
};

struct PipelineSettings {
  layerCount: u32,
  width: u32,
  height: u32,
};

@group(0) @binding(0) var outputTexture: texture_storage_2d<rgba8unorm, write>;
@group(0) @binding(1) var inputSampler: sampler;
@group(0) @binding(2) var<uniform> settings: PipelineSettings;
@group(0) @binding(3) var<storage, read> layerParams: array<LayerParams>;

// Array of sampled textures bound dynamically or via texture_2d array
@group(1) @binding(0) var layerTex0: texture_2d<f32>;
@group(1) @binding(1) var layerTex1: texture_2d<f32>;

fn applyBlendMode(base: vec4<f32>, blend: vec4<f32>, mode: u32) -> vec4<f32> {
  var result = blend;
  if (mode == 1u) {
    // Multiply blend mode
    result = vec4<f32>(base.rgb * blend.rgb, blend.a);
  } else if (mode == 2u) {
    // Screen blend mode
    result = vec4<f32>(1.0 - (1.0 - base.rgb) * (1.0 - blend.rgb), blend.a);
  }
  return result;
}

@compute @workgroup_size(16, 16, 1)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
  let coords = global_id.xy;
  if (coords.x >= settings.width || coords.y >= settings.height) {
    return;
  }

  var accumulatedColor = vec4<f32>(0.0, 0.0, 0.0, 0.0);
  var previousAlpha = 1.0;

  for (var i: u32 = 0u; i < settings.layerCount; i++) {
    var layerColor: vec4<f32>;
    let params = layerParams[i];

    if (i == 0u) {
      layerColor = textureLoad(layerTex0, vec2<i32>(coords), 0);
    } else {
      layerColor = textureLoad(layerTex1, vec2<i32>(coords), 0);
    }

    layerColor.a *= params.opacity;

    // Interactive Challenge: Dynamic Clipping Mask Chain Logic
    if (params.hasClippingMask == 1u) {
      layerColor.a *= previousAlpha;
    }

    // Blend current layer over accumulated stack
    let blendedRgb = mix(accumulatedColor.rgb, applyBlendMode(accumulatedColor, layerColor, params.blendMode).rgb, layerColor.a);
    let blendedAlpha = accumulatedColor.a + layerColor.a * (1.0 - accumulatedColor.a);
    
    accumulatedColor = vec4<f32>(blendedRgb, blendedAlpha);
    previousAlpha = layerColor.a;
  }

  textureStore(outputTexture, vec2<i32>(coords), accumulatedColor);
}
`;

export async function initWebGPUCompositor(canvas: HTMLCanvasElement, width: number, height: number) {
  if (!navigator.gpu) throw new Error("WebGPU is not supported on this browser.");

  const adapter = await navigator.gpu.requestAdapter();
  const device = await adapter?.requestDevice()!;
  const context = canvas.getContext('webgpu') as GPUCanvasContext;

  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: 'premultiplied' });

  // Create compute pipeline
  const shaderModule = device.createShaderModule({ code: COMPOSITE_COMPUTE_WGSL });
  const computePipeline = device.createComputePipeline({
    layout: 'auto',
    compute: { module: shaderModule, entryPoint: 'main' },
  });

  // Create output storage texture
  const outputTexture = device.createTexture({
    size: { width, height, depthOrArrayLayers: 1 },
    format: 'rgba8unorm',
    usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_SRC,
  });

  return { device, context, computePipeline, outputTexture };
}
