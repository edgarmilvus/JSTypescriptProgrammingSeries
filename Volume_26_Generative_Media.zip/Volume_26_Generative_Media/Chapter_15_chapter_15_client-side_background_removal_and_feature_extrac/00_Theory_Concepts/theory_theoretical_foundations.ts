/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph ClientSideInference {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", fontsize=10];

    Canvas [label="HTML5 Canvas / Video Stream\n(Raw RGBA Pixels)"];
    Preprocessing [label="Tensor Preprocessing\n(Normalization & Resizing)"];
    ORT [label="ONNX Runtime Web\n(Wasm / WebGL Execution Provider)"];
    Postprocessing [label="Post-Processing\n(Mask Thresholding & Alpha Blending)"];
    Output [label="Visual Workflow Engine\n(Real-Time Compositing Canvas)"];

    Canvas -> Preprocessing [label=" getImageData()"];
    Preprocessing -> ORT [label=" Float32Array Tensor"];
    ORT -> Postprocessing [label=" Raw Logits / Probabilities"];
    Postprocessing -> Output [label=" Modified Frame / Alpha Mask"];
}
