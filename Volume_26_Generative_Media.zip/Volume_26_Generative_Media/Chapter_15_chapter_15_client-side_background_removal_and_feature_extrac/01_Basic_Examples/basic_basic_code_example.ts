/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as ort from 'onnxruntime-web';

/**
 * Interface representing the configuration options for the client-side
 * background removal processor.
 */
interface BackgroundRemovalConfig {
    modelPath: string;
    executionProvider: 'webgl' | 'wasm';
    inputWidth: number;
    inputHeight: number;
}

/**
 * SaaS Feature Processor: Handles client-side background removal using 
 * ONNX Runtime Web to offload heavy AI computation from the backend infrastructure.
 */
export class ClientSideBackgroundRemover {
    private session: ort.InferenceSession | null = null;
    private config: BackgroundRemovalConfig;
    private isInitialized: boolean = false;

    /**
     * Initializes the processor with specific runtime configurations.
     * @param {BackgroundRemovalConfig} config - Configuration parameters for the ONNX session.
     */
    constructor(config: BackgroundRemovalConfig) {
        this.config = config;
        
        // Configure ONNX Runtime Web global settings for WASM paths
        // In a production SaaS, these assets should be served from a CDN or public static folder.
        ort.env.wasm.wasmPaths = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@latest/dist/';
    }

    /**
     * Asynchronously initializes the ONNX Inference Session.
     * This loads the model weights into browser memory.
     */
    public async initialize(): Promise<void> {
        if (this.isInitialized && this.session) {
            return;
        }

        try {
            console.log(`[BackgroundRemover] Loading model from ${this.config.modelPath}...`);
            
            // Set execution provider based on configuration (WebGL preferred for GPU acceleration)
            const executionProviders = this.config.executionProvider === 'webgl' 
                ? ['webgl', 'wasm'] 
                : ['wasm'];

            // Create the inference session with optimized threading settings
            this.session = await ort.InferenceSession.create(this.config.modelPath, {
                executionProviders: executionProviders,
                graphOptimizationLevel: 'all',
            });

            this.isInitialized = true;
            console.log('[BackgroundRemover] Model loaded successfully into client browser.');
        } catch (error) {
            console.error('[BackgroundRemover] Failed to initialize ONNX session:', error);
            throw new Error(`Initialization failed: ${(error as Error).message}`);
        }
    }

    /**
     * Preprocesses an HTMLImageElement or ImageData into a normalized Float32Array tensor
     * matching the input shape requirements of the segmentation model (typically 1x3HxW or 1xHxWxC).
     * 
     * @param {HTMLImageElement} image - The source image element provided by the user.
     * @returns {Promise<ort.Tensor>} The formatted input tensor.
     */
    private async preprocess(image: HTMLImageElement): Promise<ort.Tensor> {
        const canvas = document.createElement('canvas');
        canvas.width = this.config.inputWidth;
        canvas.height = this.config.inputHeight;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
            throw new Error('Failed to acquire 2D rendering context for image preprocessing.');
        }

        // Draw and resize image to model input dimensions
        ctx.drawImage(image, 0, 0, this.config.inputWidth, this.config.inputHeight);
        const imageData = ctx.getImageData(0, 0, this.config.inputWidth, this.config.inputHeight);
        const { data } = imageData;

        const totalPixels = this.config.inputWidth * this.config.inputHeight;
        
        // Allocate Float32Array for Planar format (Channels-First: [1, 3, H, W]) 
        // which is standard for most vision models optimized in ONNX.
        const redArray = new Float32Array(totalPixels);
        const greenArray = new Float32Array(totalPixels);
        const blueArray = new Float32Array(totalPixels);

        for (let i = 0; i < totalPixels; i++) {
            const stride = i * 4;
            // Normalize pixel values from [0, 255] to [0.0, 1.0] (or apply mean/std normalization if required by model spec)
            redArray[i] = data[stride] / 255.0;
            greenArray[i] = data[stride + 1] / 255.0;
            blueArray[i] = data[stride + 2] / 255.0;
        }

        // Concatenate channels into a single contiguous Float32Array
        const inputData = new Float32Array(3 * totalPixels);
        inputData.set(redArray, 0);
        inputData.set(greenArray, totalPixels);
        inputData.set(blueArray, totalPixels * 2);

        // Create the ONNX Tensor with shape [1, 3, Height, Width]
        const tensor = new ort.Tensor(
            'float32', 
            inputData, 
            [1, 3, this.config.inputHeight, this.config.inputWidth]
        );

        return tensor;
    }

    /**
     * Executes client-side background removal inference on a target image element.
     * 
     * @param {HTMLImageElement} sourceImage - The image to process.
     * @returns {Promise<ImageData>} The resulting foreground image with a transparent background.
     */
    public async removeBackground(sourceImage: HTMLImageElement): Promise<ImageData> {
        if (!this.isInitialized || !this.session) {
            throw new Error('BackgroundRemover has not been initialized. Call initialize() first.');
        }

        // Step 1: Preprocess the input image into an ONNX tensor
        const inputTensor = await this.preprocess(sourceImage);
        
        // Extract the input name dynamically from the loaded model metadata
        const inputName = this.session.inputNames[0];
        const feeds: Record<string, ort.Tensor> = { [inputName]: inputTensor };

        try {
            // Step 2: Execute model inference via WebAssembly or WebGL
            const results = await this.session.run(feeds);
            
            // Extract the output tensor (typically a binary or alpha mask of shape [1, 1, H, W] or [1, H, W])
            const outputName = this.session.outputNames[0];
            const outputTensor = results[outputName];

            // Step 3: Post-process the mask and composite with the original image data
            return this.postprocess(sourceImage, outputTensor);
        } catch (error) {
            console.error('[BackgroundRemover] Inference execution failed:', error);
            throw error;
        }
    }

    /**
     * Post-processes the raw model output mask, applies alpha transparency,
     * and returns a renderable ImageData object for the SaaS UI canvas.
     * 
     * @param {HTMLImageElement} originalImage - The original user image.
     * @param {ort.Tensor} maskTensor - The alpha mask tensor generated by the model.
     * @returns {ImageData} Processed image data with background removed.
     */
    private postprocess(originalImage: HTMLImageElement, maskTensor: ort.Tensor): ImageData {
        const width = this.config.inputWidth;
        const height = this.config.inputHeight;

        // Create canvas to read original pixels at model resolution
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Failed to acquire canvas context during post-processing.');

        ctx.drawImage(originalImage, 0, 0, width, height);
        const imgData = ctx.getImageData(0, 0, width, height);
        const pixels = imgData.data;

        // Access the underlying Float32Array mask data
        const maskData = maskTensor.data as Float32Array;

        // Apply the mask alpha values to each pixel's alpha channel
        for (let i = 0; i < width * height; i++) {
            // Model outputs range typically from 0.0 (background) to 1.0 (foreground)
            const alphaValue = maskData[i];
            
            // Map float [0.0, 1.0] to integer byte [0, 255]
            const alphaByte = Math.max(0, Math.min(255, Math.floor(alphaValue * 255)));
            
            // Update the alpha channel (index 3 of every RGBA pixel tuple)
            pixels[i * 4 + 3] = alphaByte;
        }

        return imgData;
    }
}
