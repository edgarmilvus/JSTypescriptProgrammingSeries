/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'react';
import { z } from 'zod';

// ==========================================
// 1. ZOD SCHEMAS & TYPESCRIPT TYPE INFERENCE
// ==========================================

/**
 * Zod schema validating the configuration payload for initializing the ONNX inference worker.
 * Bridges runtime configuration validation with compile-time TypeScript safety.
 */
export const InferenceConfigSchema = z.object({
  modelPath: z.string().url().or(z.string().startsWith('/')),
  executionProvider: z.enum(['webassembly', 'webgl', 'webgpu']),
  threadCount: z.number().int().positive().max(8),
  inputWidth: z.number().int().positive().default(512),
  inputHeight: z.number().int().positive().default(512),
});

export type InferenceConfig = z.infer<typeof InferenceConfigSchema>;

/**
 * Schema validating incoming frame processing execution requests.
 */
const ProcessFramePayloadSchema = z.object({
  sharedBuffer: z.custom<SharedArrayBuffer>((val) => val instanceof SharedArrayBuffer, {
    message: 'Expected a valid SharedArrayBuffer instance',
  }),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
});

export type ProcessFramePayload = z.infer<typeof ProcessFramePayloadSchema>;

// ==========================================
// 2. WORKER THREAD CODE (BLOB / SEPARATE FILE)
// ==========================================

/**
 * Stringified Worker script containing ONNX Runtime Web execution logic.
 * Designed to execute in a headless worker environment, utilizing SharedArrayBuffer 
 * for zero-copy memory access to raw pixel arrays.
 */
const workerScript = `
  // Import ONNX Runtime Web via CDN in the worker scope
  importScripts('https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/ort.min.js');

  let session = null;

  self.onmessage = async function (e) {
    const { type, payload } = e.data;

    if (type === 'INIT') {
      try {
        // Configure threading for WASM backend execution
        ort.env.wasm.numThreads = payload.threadCount || 4;
        ort.env.wasm.simd = true;

        // Create inference session targeting specified hardware accelerator
        session = await ort.InferenceSession.create(payload.modelPath, {
          executionProviders: [payload.executionProvider],
        });

        self.postMessage({ type: 'INIT_SUCCESS' });
      } catch (err) {
        self.postMessage({ type: 'INIT_ERROR', error: err.message });
      }
    }

    if (type === 'PROCESS_FRAME') {
      try {
        if (!session) {
          throw new Error('Inference session not initialized.');
        }

        const { sharedBuffer, width, height } = payload;
        
        // Wrap the SharedArrayBuffer in a Float32Array view without copying data
        const inputTensorData = new Float32Array(sharedBuffer);

        // Construct the ORT tensor directly from the shared memory view
        const tensor = new ort.Tensor('float32', inputTensorData, [1, 3, height, width]);

        // Execute headless inference on the segmentation model
        const feeds = { [session.inputNames[0]]: tensor };
        const results = await session.run(feeds);
        const outputTensor = results[session.outputNames[0]];

        // Signal completion back to the main thread (output data is also written directly to SAB if configured)
        self.postMessage({ 
          type: 'PROCESS_SUCCESS', 
          outputShape: outputTensor.dims 
        });
      } catch (err) {
        self.postMessage({ type: 'PROCESS_ERROR', error: err.message });
      }
    }
  };
`;

// ==========================================
// 3. REACT COMPONENT & PIPELINE CONTROLLER
// ==========================================

export default function BackgroundRemovalStudio() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [statusMessage, setStatusMessage] = useState('Idle');
  const workerRef = useRef<Worker | null>(null);
  const sharedBufferRef = useRef<SharedArrayBuffer | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  /**
   * Initializes the Web Worker and validates configuration using Zod.
   */
  const handleInitializeEngine = async () => {
    try {
      setStatusMessage('Validating configuration...');
      
      const rawConfig: InferenceConfig = {
        modelPath: '/models/u2net_portrait.onnx',
        executionProvider: 'webgl',
        threadCount: 4,
        inputWidth: 512,
        inputHeight: 512,
      };

      // Runtime validation via Zod Schema
      const validatedConfig = InferenceConfigSchema.parse(rawConfig);

      setStatusMessage('Spawning Web Worker and loading ONNX model...');

      // Create a Blob URL to instantiate the worker without external file hosting dependencies
      const blob = new Blob([workerScript], { type: 'application/javascript' });
      const workerUrl = URL.createObjectURL(blob);
      workerRef.current = new Worker(workerUrl);

      // Setup worker message listener
      workerRef.current.onmessage = (event) => {
        const { type, error, outputShape } = event.data;
        if (type === 'INIT_SUCCESS') {
          setIsInitialized(true);
          setStatusMessage('Engine ready. Shared memory pool allocated.');
          
          // Allocate a SharedArrayBuffer for 512x512 RGB Float32 image data: 1 * 3 * 512 * 512 * 4 bytes
          const bufferSize = 1 * 3 * validatedConfig.inputWidth * validatedConfig.inputHeight * Float32Array.BYTES_PER_ELEMENT;
          sharedBufferRef.current = new SharedArrayBuffer(bufferSize);
        } else if (type === 'INIT_ERROR') {
          setStatusMessage(`Initialization failed: ${error}`);
        } else if (type === 'PROCESS_SUCCESS') {
          setStatusMessage(`Frame processed successfully. Output shape: ${outputShape.join('x')}`);
        } else if (type === 'PROCESS_ERROR') {
          setStatusMessage(`Processing error: ${error}`);
        }
      };

      // Dispatch initialization payload to worker
      workerRef.current.postMessage({ type: 'INIT', payload: validatedConfig });

    } catch (err) {
      if (err instanceof z.ZodError) {
        setStatusMessage(`Configuration validation error: ${err.errors.map(e => e.message).join(', ')}`);
      } else {
        setStatusMessage(`Unexpected error: ${(err as Error).message}`);
      }
    }
  };

  /**
   * Captures an image frame, normalizes pixel data into the SharedArrayBuffer, 
   * and triggers headless worker processing.
   */
  const handleProcessFrame = () => {
    if (!workerRef.current || !sharedBufferRef.current || !canvasRef.current) {
      setStatusMessage('Pipeline not initialized.');
      return;
    }

    setStatusMessage('Normalizing frame into SharedArrayBuffer...');
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const width = 512;
    const height = 512;
    const imageData = ctx.getImageData(0, 0, width, height);
    const pixels = imageData.data;

    // Create a Float32 view over the SharedArrayBuffer for NCHW normalization (RGB channels separated)
    const floatView = new Float32Array(sharedBufferRef.current);
    const channelSize = width * height;

    for (let i = 0; i < channelSize; i++) {
      const rIdx = i * 4;
      const gIdx = i * 4 + 1;
      const bIdx = i * 4 + 2;

      // Normalize pixel values from [0, 255] to [0.0, 1.0] and separate into NCHW format
      floatView[i] = pixels[rIdx] / 255.0;             // Red channel
      floatView[channelSize + i] = pixels[gIdx] / 255.0; // Green channel
      floatView[(channelSize * 2) + i] = pixels[bIdx] / 255.0; // Blue channel
    }

    setStatusMessage('Dispatching frame to worker thread...');

    // Validate payload shape before dispatching across thread boundaries
    const payload: ProcessFramePayload = {
      sharedBuffer: sharedBufferRef.current,
      width,
      height,
    };

    const validatedPayload = ProcessFramePayloadSchema.parse(payload);

    // Send the shared buffer reference to the worker (zero-copy transfer)
    workerRef.current.postMessage({
      type: 'PROCESS_FRAME',
      payload: validatedPayload,
    });
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Client-Side Vision Engine</h2>
        <p className="text-sm text-slate-400">ONNX Runtime Web + SharedArrayBuffer Pipeline</p>
      </div>

      <div className="p-4 bg-slate-800 rounded-lg border border-slate-700 space-y-2">
        <p className="text-sm font-mono">Status: <span className="text-emerald-400">{statusMessage}</span></p>
      </div>

      <div className="flex gap-4">
        {!isInitialized ? (
          <button
            onClick={handleInitializeEngine}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 font-semibold rounded-lg transition-colors"
          >
            Initialize Inference Engine
          </button>
        ) : (
          <button
            onClick={handleProcessFrame}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-semibold rounded-lg transition-colors"
          >
            Process Video Frame
          </button>
        )}
      </div>

      {/* Hidden canvas used for extracting raw pixel data from media elements */}
      <canvas ref={canvasRef} width={512} height={512} className="hidden" />
    </div>
  );
}
