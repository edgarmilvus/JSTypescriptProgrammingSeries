/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as ort from 'onnxruntime-web';

export interface SegmentationInput extends Record<string, ort.Tensor> {
  input_image: ort.Tensor;
}

export interface SegmentationOutput extends Record<string, ort.Tensor> {
  output_mask: ort.Tensor;
}

export class ModelSessionManager<
  TInput extends Record<string, ort.Tensor>,
  TOutput extends Record<string, ort.Tensor>
> {
  private session: ort.InferenceSession | null = null;

  constructor(private modelPath: string) {}

  /**
   * Initializes the ONNX inference session with specified execution providers.
   * @param executionProviders Array of execution providers (e.g., ['webgpu', 'wasm'])
   */
  public async initialize(executionProviders: string[] = ['webgpu', 'wasm']): Promise<void> {
    if (this.session) return;
    
    this.session = await ort.InferenceSession.create(this.modelPath, {
      executionProviders: executionProviders,
    });
  }

  /**
   * Executes the session with strictly typed inputs and returns strongly typed outputs.
   * @param inputs Record containing model input tensors matching TInput
   */
  public async run(inputs: TInput): Promise<TOutput> {
    if (!this.session) {
      throw new Error('ModelSessionManager is not initialized. Call initialize() first.');
    }

    // Validate that provided keys match session input names
    const expectedInputs = this.session.inputNames;
    const providedKeys = Object.keys(inputs);

    for (const expected of expectedInputs) {
      if (!providedKeys.includes(expected)) {
        throw new Error(`Missing required input tensor: "${expected}"`);
      }
    }

    // Execute inference
    const results = await this.session.run(inputs);

    // Cast results to the generic TOutput constraint
    return results as unknown as TOutput;
  }

  /**
   * Releases underlying ONNX session resources.
   */
  public async release(): Promise<void> {
    if (this.session) {
      await this.session.release();
      this.session = null;
    }
  }
}
