/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as ort from 'onnxruntime-web';

export type TelemetryCallback = (provider: string, status: 'success' | 'fallback', error?: unknown) => void;

export async function createRobustInferenceSession(
  modelPath: string,
  onTelemetry?: TelemetryCallback
): Promise<ort.InferenceSession> {
  const providers: string[] = [];

  // Probe WebGPU capability
  if (typeof navigator !== 'undefined' && 'gpu' in navigator && navigator.gpu) {
    providers.push('webgpu');
  }

  // Probe WebGL capability (WebGL2)
  if (typeof document !== 'undefined') {
    const canvas = document.createElement('canvas');
    const gl2 = canvas.getContext('webgl2');
    if (gl2) {
      providers.push('webgl');
    }
  }

  // Always fallback to WASM multithreaded CPU
  providers.push('wasm');

  let session: ort.InferenceSession | null = null;
  let lastError: unknown = null;

  for (const provider of providers) {
    try {
      session = await ort.InferenceSession.create(modelPath, {
        executionProviders: [provider],
      });
      onTelemetry?.(provider, 'success');
      return session;
    } catch (err) {
      lastError = err;
      onTelemetry?.(provider, 'fallback', err);
    }
  }

  throw new Error(`Failed to create ONNX inference session with any available execution provider. Last error: ${String(lastError)}`);
}
