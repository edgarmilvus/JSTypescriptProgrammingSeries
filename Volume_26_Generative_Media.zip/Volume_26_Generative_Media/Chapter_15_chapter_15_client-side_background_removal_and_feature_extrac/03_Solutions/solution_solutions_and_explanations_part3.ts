/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useCallback, useRef, useEffect } from 'react';
import * as ort from 'onnxruntime-web';

export interface BackgroundRemovalOptions {
  inputWidth?: number;
  inputHeight?: number;
  executionProviders?: string[];
}

export interface BackgroundRemovalHookResult {
  processFrame: (source: HTMLVideoElement | HTMLCanvasElement) => Promise<ImageData | null>;
  isLoading: boolean;
  loadingProgress: number;
  fps: number;
  activeProvider: string | null;
  error: Error | null;
}

export function useBackgroundRemoval(
  modelPath: string,
  options: BackgroundRemovalOptions = {}
): BackgroundRemovalHookResult {
  const { inputWidth = 512, inputHeight = 512, executionProviders = ['webgpu', 'wasm'] } = options;

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [fps, setFps] = useState<number>(0);
  const [activeProvider, setActiveProvider] = useState<string | null>(null);
  const [error, setError] = useState<Error | null>(null);

  const sessionRef = useRef<ort.InferenceSession | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  
  const frameCountRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(performance.now());

  // Initialize Offscreen Canvas for tensor preprocessing
  useEffect(() => {
    if (typeof document !== 'undefined') {
      const canvas = document.createElement('canvas');
      canvas.width = inputWidth;
      canvas.height = inputHeight;
      canvasRef.current = canvas;
      ctxRef.current = canvas.getContext('2d', { willReadFrequently: true });
    }
  }, [inputWidth, inputHeight]);

  // Load Model Session
  useEffect(() => {
    let isMounted = true;

    async function loadModel() {
      try {
        setIsLoading(true);
        setLoadingProgress(25);

        let activeSes: ort.InferenceSession | null = null;
        for (const ep of executionProviders) {
          try {
            activeSes = await ort.InferenceSession.create(modelPath, { executionProviders: [ep] });
            setActiveProvider(ep);
            break;
          } catch {
            continue;
          }
        }

        if (!activeSes) throw new Error('All execution providers failed during initialization.');

        if (isMounted) {
          sessionRef.current = activeSes;
          setLoadingProgress(100);
          setIsLoading(false);
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error(String(err)));
          setIsLoading(false);
        }
      }
    }

    loadModel();

    return () => {
      isMounted = true;
      sessionRef.current?.release();
    };
  }, [modelPath, executionProviders]);

  const processFrame = useCallback(
    async (source: HTMLVideoElement | HTMLCanvasElement): Promise<ImageData | null> => {
      if (!sessionRef.current || !ctxRef.current || !canvasRef.current) return null;

      const now = performance.now();
      frameCountRef.current++;
      if (now - lastTimeRef.current >= 1000) {
        setFps(Math.round((frameCountRef.current * 1000) / (now - lastTimeRef.current)));
        frameCountRef.current = 0;
        lastTimeRef.current = now;
      }

      const ctx = ctxRef.current;
      ctx.drawImage(source, 0, 0, inputWidth, inputHeight);
      const imgData = ctx.getImageData(0, 0, inputWidth, inputHeight);
      const { data } = imgData;

      // Convert RGBA to Float32Array and normalize channels (NCHW layout)
      const float32Data = new Float32Array(3 * inputWidth * inputHeight);
      const pixelCount = inputWidth * inputHeight;

      for (let i = 0; i < pixelCount; i++) {
        float32Data[i] = data[i * 4] / 255.0; // R
        float32Data[pixelCount + i] = data[i * 4 + 1] / 255.0; // G
        float32Data[pixelCount * 2 + i] = data[i * 4 + 2] / 255.0; // B
      }

      const inputTensor = new ort.Tensor('float32', float32Data, [1, 3, inputHeight, inputWidth]);

      try {
        const results = await sessionRef.current.run({ input_image: inputTensor });
        const outputTensor = results[sessionRef.current.outputNames[0]];

        // Create resulting ImageData containing alpha mask
        const outputData = outputTensor.data as Float32Array;
        const resultImageData = ctx.createImageData(inputWidth, inputHeight);

        for (let i = 0; i < pixelCount; i++) {
          const alpha = Math.floor(outputData[i] * 255);
          resultImageData.data[i * 4] = data[i * 4];
          resultImageData.data[i * 4 + 1] = data[i * 4 + 1];
          resultImageData.data[i * 4 + 2] = data[i * 4 + 2];
          resultImageData.data[i * 4 + 3] = alpha;
        }

        // Dispose tensor to prevent memory leaks
        inputTensor.dispose();
        outputTensor.dispose();

        return resultImageData;
      } catch (err) {
        inputTensor.dispose();
        console.error('Inference error during frame processing:', err);
        return null;
      }
    },
    [inputWidth, inputHeight]
  );

  return {
    processFrame,
    isLoading,
    loadingProgress,
    fps,
    activeProvider,
    error,
  };
}
