/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Client-side feature extractor stream utility
import * as ort from 'onnxruntime-web';

export interface EmbeddingPayload {
  frameIndex: number;
  timestamp: number;
  vector: number[];
}

export async function* streamFeatureEmbeddings(
  imageFrames: ImageData[],
  session: ort.InferenceSession
): AsyncGenerator<EmbeddingPayload, void, unknown> {
  for (let i = 0; i < imageFrames.length; i++) {
    const frame = imageFrames[i];
    const { width, height, data } = frame;
    const pixelCount = width * height;
    const float32Data = new Float32Array(3 * pixelCount);

    for (let p = 0; p < pixelCount; p++) {
      float32Data[p] = data[p * 4] / 255.0;
      float32Data[pixelCount + p] = data[p * 4 + 1] / 255.0;
      float32Data[pixelCount * 2 + p] = data[p * 4 + 2] / 255.0;
    }

    const inputTensor = new ort.Tensor('float32', float32Data, [1, 3, height, width]);

    try {
      const results = await session.run({ [session.inputNames[0]]: inputTensor });
      const outputTensor = results[session.outputNames[0]];
      const vectorArray = Array.from(outputTensor.data as Float32Array);

      inputTensor.dispose();
      outputTensor.dispose();

      yield {
        frameIndex: i,
        timestamp: Date.now(),
        vector: vectorArray,
      };
    } catch (err) {
      inputTensor.dispose();
      throw err;
    }
  }
}
