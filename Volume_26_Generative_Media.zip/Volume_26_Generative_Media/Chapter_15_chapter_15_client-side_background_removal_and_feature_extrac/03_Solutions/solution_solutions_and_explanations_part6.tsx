/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as ort from 'onnxruntime-web';

export interface RealtimeVisualCanvasProps {
  modelPath: string;
  backgroundImageUrl?: string;
}

export const RealtimeVisualCanvas: React.FC<RealtimeVisualCanvasProps> = ({
  modelPath,
  backgroundImageUrl,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  
  const [fps, setFps] = useState<number>(0);
  const [provider, setProvider] = useState<string>('Initializing...');
  
  const sessionRef = useRef<ort.InferenceSession | null>(null);
  const animationFrameId = useRef<number>(0);

  const runPipeline = useCallback(async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const session = sessionRef.current;

    if (!video || !canvas || !session || video.readyState < 2) {
      animationFrameId.current = requestAnimationFrame(runPipeline);
      return;
    }

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const width = 512;
    const height = 512;

    // Draw video frame to offscreen/processing resolution
    ctx.drawImage(video, 0, 0, width, height);
    const imgData = ctx.getImageData(0, 0, width, height);
    const { data } = imgData;

    const float32Data = new Float32Array(3 * width * height);
    const pixelCount = width * height;

    for (let i = 0; i < pixelCount; i++) {
      float32Data[i] = data[i * 4] / 255.0;
      float32Data[pixelCount + i] = data[i * 4 + 1] / 255.0;
      float32Data[pixelCount * 2 + i] = data[i * 4 + 2] / 255.0;
    }

    const inputTensor = new ort.Tensor('float32', float32Data, [1, 3, height, width]);

    try {
      const results = await session.run({ input_image: inputTensor });
      const maskTensor = results[session.outputNames[0]];
      const maskData = maskTensor.data as Float32Array;

      // Resize canvas to match video display aspect ratio
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      }

      // Draw background or apply effect
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Extract and composite foreground alpha matte mask
      const renderedImage = ctx.getImageData(0, 0, canvas.width, canvas.height);
      // (Compositing math mapping maskData coordinates to canvas pixels...)

      inputTensor.dispose();
      maskTensor.dispose();
    } catch (err) {
      inputTensor.dispose();
      console.error('Inference rendering error:', err);
    }

    animationFrameId.current = requestAnimationFrame(runPipeline);
  }, []);

  useEffect(() => {
    let isMounted = true;

    async function init() {
      try {
        // Setup Webcam stream
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });

        if (videoRef.current && isMounted) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        // Initialize ONNX Session with WebGPU fallback
        let activeSession: ort.InferenceSession | null = null;
        const EPs = ['webgpu', 'webgl', 'wasm'];

        for (const ep of EPs) {
          try {
            activeSession = await ort.InferenceSession.create(modelPath, { executionProviders: [ep] });
            setProvider(ep.toUpperCase());
            break;
          } catch {
            continue;
          }
        }

        if (!activeSession) throw new Error('Failed to load session with available EPs.');

        if (isMounted) {
          sessionRef.current = activeSession;
          animationFrameId.current = requestAnimationFrame(runPipeline);
        }
      } catch (err) {
        setProvider('Error loading session');
        console.error(err);
      }
    }

    init();

    return () => {
      isMounted = false;
      cancelAnimationFrame(animationFrameId.current);
      sessionRef.current?.release();
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [modelPath, runPipeline]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-slate-900">
      <div className="absolute top-4 left-4 z-10 bg-black/60 text-white p-3 rounded-lg backdrop-blur-md font-mono text-sm">
        <p>Provider: {provider}</p>
        <p>FPS: {fps}</p>
      </div>
      <video ref={videoRef} className="hidden" playsInline muted />
      <canvas ref={canvasRef} className="rounded-xl shadow-2xl max-w-full h-auto" />
    </div>
  );
};
