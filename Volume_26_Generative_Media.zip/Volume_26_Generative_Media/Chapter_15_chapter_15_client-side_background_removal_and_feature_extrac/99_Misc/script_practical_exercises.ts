/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import * as ort from 'onnxruntime-web';

// Define your generic interfaces for inputs and outputs here
export interface SegmentationInput extends Record<string, ort.Tensor> {
  input_image: ort.Tensor;
}

export interface SegmentationOutput extends Record<string, ort.Tensor> {
  output_mask: ort.Tensor;
}

export class ModelSessionManager<
  TInput extends Record<string, ort.Tensor>,
  TOutput extends Record<string, ort.Tensor>
> {
  private session: ort.InferenceSession | null = null;

  constructor(private modelPath: string) {}

  public async initialize(executionProviders: string[] = ['webgpu', 'wasm']): Promise<void> {
    // TODO: Initialize ort.InferenceSession with the specified modelPath and execution providers
    throw new Error('Not implemented');
  }

  public async run(inputs: TInput): Promise<TOutput> {
    // TODO: Validate inputs, execute the session, and return strongly-typed TOutput
    throw new Error('Not implemented');
  }

  public async release(): Promise<void> {
    // TODO: Release session resources
    throw new Error('Not implemented');
  }
}
