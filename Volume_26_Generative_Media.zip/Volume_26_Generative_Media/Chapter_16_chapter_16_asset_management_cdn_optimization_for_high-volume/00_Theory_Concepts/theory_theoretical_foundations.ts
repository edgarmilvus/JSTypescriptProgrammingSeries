/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
edge [fontname="Arial", fontsize=10];

Client [label="Client Canvas / Browser", fillcolor="#e0e7ff"];
Edge [label="Edge Runtime / CDN\n(Web Standards / V8 Isolates)", fillcolor="#dbeafe"];
ObjectStorage [label="Distributed Object Storage\n(S3 / R2)", fillcolor="#fae8ff"];
VectorDB [label="Vector Database\n(pgvector Indexing)", fillcolor="#fce7f3"];
Pipeline [label="Real-Time Media Pipeline\n(WebGPU Processing)", fillcolor="#dcfce7"];

Client -> Edge [label="1. Request Asset URL / Stream"];
Edge -> VectorDB [label="2. Semantic Similarity / Deduplication Query"];
Edge -> ObjectStorage [label="3. Cache Miss: Fetch Base Artifact", style="dashed"];
Edge -> Pipeline [label="4. On-the-Fly Transform / Stream", style="dashed"];
Edge -> Client [label="5. Deliver Optimized Media / Stream"];
