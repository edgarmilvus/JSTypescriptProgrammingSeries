/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
edge [fontname="Arial", fontsize=10];

UserQuery [label="User Semantic Query\n('Show me moody cyberpunk styles')", fillcolor="#e0e7ff"];
EmbeddingModel [label="Embedding Model\n(Converts text/image to vector)", fillcolor="#dbeafe"];
PgVector [label="PostgreSQL + pgvector\n(Approximate Nearest Neighbor Search)", fillcolor="#fce7f3"];
AssetRegistry [label="Asset Registry & Storage Pointers", fillcolor="#dcfce7"];

UserQuery -> EmbeddingModel [label="1. Input Prompt"];
EmbeddingModel -> PgVector [label="2. Query Vector [0.021, -0.43,...]"];
PgVector -> AssetRegistry [label="3. Index Match (Cosine Distance)"];
AssetRegistry -> UserQuery [label="4. Return Relevant Generative Assets"];
