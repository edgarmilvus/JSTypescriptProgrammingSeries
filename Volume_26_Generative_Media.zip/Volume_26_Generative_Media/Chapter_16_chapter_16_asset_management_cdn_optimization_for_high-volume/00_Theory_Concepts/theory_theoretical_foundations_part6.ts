/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
edge [fontname="Arial", fontsize=10];

ClientCanvas [label="Client Node Canvas", fillcolor="#e0e7ff"];
AuthService [label="Auth & Authorization Service\n(Issues Signed Tokens)", fillcolor="#dbeafe"];
EdgeCDN [label="Edge Runtime / CDN\n(Cryptographic Signature Verification)", fillcolor="#dbeafe"];
PrivateBucket [label="Private Object Storage", fillcolor="#fae8ff"];

ClientCanvas -> AuthService [label="1. Request Access to Node Asset"];
AuthService -> ClientCanvas [label="2. Return Cryptographically Signed URL\n(Includes HMAC, Expiry, Permissions)"];
ClientCanvas -> EdgeCDN [label="3. Request Asset with Signed URL Params"];
EdgeCDN -> EdgeCDN [label="4. Verify HMAC Signature & Expiry (Zero DB Lookup)"];
EdgeCDN -> PrivateBucket [label="5. Fetch Base Asset (Cache Hit/Miss)", style="dashed"];
EdgeCDN -> ClientCanvas [label="6. Stream / Deliver Media"];
