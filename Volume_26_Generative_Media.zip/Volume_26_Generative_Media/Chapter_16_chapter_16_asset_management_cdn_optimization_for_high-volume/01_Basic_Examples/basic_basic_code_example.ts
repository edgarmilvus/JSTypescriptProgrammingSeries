/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file asset-router.ts
 * @description Edge-optimized asset management and signed-URL generator for private AI media SaaS.
 * This module runs on V8-isolate-based Edge Runtimes, ensuring sub-millisecond cold starts and 
 * global proximity to end-users requesting generative media streams.
 */

import { crypto } from "https://deno.land/std@0.177.0/crypto/mod.ts";
import { encodeHex } from "https://deno.land/std@0.177.0/encoding/hex.ts";

/**
 * Configuration interface for the asset delivery pipeline.
 */
interface AssetConfig {
  cdnDomain: string;
  signingSecret: string;
  defaultExpirationSeconds: number;
}

/**
 * Payload interface representing an incoming media asset request.
 */
interface AssetRequestPayload {
  assetId: string;
  userId: string;
  transformation?: {
    width?: number;
    height?: number;
    format?: 'webp' | 'avif' | 'jpeg';
    quality?: number;
  };
}

/**
 * Generates an HMAC-SHA256 signature for secure, time-bound asset distribution.
 * 
 * @param {string} canonicalPath - The normalized asset path and transformation string.
 * @param {number} expiresAt - Unix timestamp (in seconds) when the URL expires.
 * @param {string} secret - The cryptographic secret key shared between storage and edge.
 * @returns {Promise<string>} The lowercase hex-encoded HMAC signature.
 */
async function generateHmacSignature(
  canonicalPath: string,
  expiresAt: number,
  secret: string
): Promise<string> {
  const message = `${canonicalPath}:${expiresAt}`;
  const encoder = new TextEncoder();
  
  // Import the secret key into the Web Crypto API
  const keyData = encoder.encode(secret);
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    keyData,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );

  // Sign the message payload
  const signatureBuffer = await crypto.subtle.sign(
    "HMAC",
    cryptoKey,
    encoder.encode(message)
  );

  // Convert the ArrayBuffer to a hex string
  return encodeHex(signatureBuffer);
}

/**
 * Constructs a fully qualified CDN URL embedded with transformation hints and cryptographic signature parameters.
 * 
 * @param {AssetRequestPayload} payload - The details of the requested asset and desired mutations.
 * @param {AssetConfig} config - Operational parameters including CDN domain and secret.
 * @returns {Promise<Response>} An HTTP Response object containing the redirect or signed asset route.
 */
export async function handleAssetRequest(
  payload: AssetRequestPayload,
  config: AssetConfig
): Promise<Response> {
  try {
    // 1. Validate the incoming payload invariants
    if (!payload.assetId || !payload.userId) {
      return new Response(
        JSON.stringify({ error: "Invalid payload: missing assetId or userId" }),
        { 
          status: 400, 
          headers: { "Content-Type": "application/json" } 
        }
      );
    }

    // 2. Build the base storage path for the private AI-generated media
    const basePath = `/secure-vault/${payload.userId}/${payload.assetId}`;

    // 3. Serialize transformation parameters into a deterministic query/path segment
    const tx = payload.transformation;
    const txParams = tx
      ? `_w=${tx.width || 'auto'}_h=${tx.height || 'auto'}_fmt=${tx.format || 'webp'}_q=${tx.quality || 85}`
      : '_default';

    const canonicalPath = `${basePath}/${txParams}`;

    // 4. Calculate expiration epoch timestamp
    const currentEpoch = Math.floor(Date.now() / 1000);
    const expiresAt = currentEpoch + config.defaultExpirationSeconds;

    // 5. Generate cryptographic proof of authorization
    const signature = await generateHmacSignature(canonicalPath, expiresAt, config.signingSecret);

    // 6. Assemble the final edge CDN URL with validation query string arguments
    const signedUrl = `https://${config.cdnDomain}${canonicalPath}?expires=${expiresAt}&sig=${signature}`;

    // 7. Return structural response with precise Edge-Caching headers
    return new Response(
      JSON.stringify({
        success: true,
        assetId: payload.assetId,
        url: signedUrl,
        expiresAt: new Date(expiresAt * 1000).toISOString(),
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          // Instruct downstream edge caches to store this mapping for short bursts 
          // while forcing validation on the cryptographic envelope periodically.
          "Cache-Control": "private, max-age=60, stale-while-revalidate=30",
          "X-Edge-Runtime": "V8-Isolate",
        },
      }
    );
  } catch (error: unknown) {
    // Graceful fallback for unexpected runtime failures
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    return new Response(
      JSON.stringify({ error: "Internal Edge Failure", details: errorMessage }),
      { 
        status: 500, 
        headers: { "Content-Type": "application/json" } 
      }
    );
  }
}
