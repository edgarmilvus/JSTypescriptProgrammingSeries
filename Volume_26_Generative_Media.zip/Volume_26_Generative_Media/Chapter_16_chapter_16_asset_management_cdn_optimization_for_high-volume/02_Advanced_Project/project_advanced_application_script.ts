/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createClient } from '@supabase/supabase-js';
import { createHmac, createHash } from 'crypto';

// Initialize Supabase client with environment configurations
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

/**
 * Interface representing metadata for an ingested generative media asset.
 */
interface GenerativeAssetMetadata {
    id: string;
    hash: string;
    fileSize: number;
    mimeType: string;
    storagePath: string;
    creatorId: string;
    tags: string[];
    createdAt: string;
}

/**
 * Interface representing generation parameters for deduplication calculations.
 */
interface GenerationParams {
    prompt: string;
    seed: number;
    modelId: string;
    dimensions: { width: number; height: number };
    steps: number;
}

/**
 * Generates a deterministic SHA-256 hash from generative asset parameters
 * to prevent duplicate storage of identical AI outputs.
 * 
 * @param params - The input parameters used for media generation.
 * @returns A hexadecimal hash string representing the unique signature.
 */
export function computeAssetFingerprint(params: GenerationParams): string {
    // Canonicalize the payload configuration to ensure deterministic hash generation
    const canonicalPayload = JSON.stringify({
        prompt: params.prompt.trim().toLowerCase(),
        seed: params.seed,
        modelId: params.modelId,
        dimensions: params.dimensions,
        steps: params.steps,
    });

    return createHash('sha256').update(canonicalPayload).digest('hex');
}

/**
 * Handles the secure ingestion, deduplication check, and persistence of a high-volume
 * AI media asset, mapping vector metadata for pgvector semantic search.
 * 
 * @param buffer - Binary buffer of the generated media.
 * @param params - Parameters used to generate the media.
 * @param mimeType - The MIME type of the generated artifact.
 * @param creatorId - UUID of the user or agent who triggered the generation.
 * @returns The structured asset metadata record.
 */
export async function ingestGenerativeAsset(
    buffer: Buffer,
    params: GenerationParams,
    mimeType: string,
    creatorId: string
): Promise<GenerativeAssetMetadata> {
    // Step 1: Compute fingerprint to check for existing records
    const assetHash = computeAssetFingerprint(params);
    const fileSize = buffer.length;

    // Step 2: Query database via pgvector / standard tables to check if identical media exists
    const { data: existingAsset, error: queryError } = await supabase
        .from('generative_assets')
        .select('*')
        .eq('hash', assetHash)
        .single();

    if (queryError && queryError.code !== 'PGRST116') {
        throw new Error(`Database query failed during deduplication check: ${queryError.message}`);
    }

    // If a duplicate asset exists, short-circuit the upload and return existing metadata (zero-redundancy storage)
    if (existingAsset) {
        console.log(`[Deduplication Hit] Asset with hash ${assetHash} already exists. Re-using path: ${existingAsset.storage_path}`);
        return {
            id: existingAsset.id,
            hash: existingAsset.hash,
            fileSize: existingAsset.file_size,
            mimeType: existingAsset.mime_type,
            storagePath: existingAsset.storage_path,
            creatorId: existingAsset.creator_id,
            tags: existingAsset.tags,
            createdAt: existingAsset.created_at,
        };
    }

    // Step 3: Define target object storage path with hierarchical tenant partitioning
    const fileExtension = mimeType.split('/')[1] || 'bin';
    const storagePath = `generated/${creatorId}/${assetHash}.${fileExtension}`;

    // Step 4: Upload raw binary buffer to cloud object storage (e.g., AWS S3 / Supabase Storage)
    const { error: uploadError } = await supabase.storage
        .from('ai-media-bucket')
        .upload(storagePath, buffer, {
            contentType: mimeType,
            upsert: false,
            cacheControl: '3600, public',
        });

    if (uploadError) {
        throw new Error(`Failed to upload media buffer to object storage: ${uploadError.message}`);
    }

    // Step 5: Register asset record within PostgreSQL relational database
    const newRecord = {
        hash: assetHash,
        file_size: fileSize,
        mime_type: mimeType,
        storage_path: storagePath,
        creator_id: creatorId,
        tags: [params.modelId, mimeType],
        generation_params: params,
        created_at: new Date().toISOString(),
    };

    const { data: insertedData, error: insertError } = await supabase
        .from('generative_assets')
        .insert([newRecord])
        .select()
        .single();

    if (insertError) {
        // Rollback storage object if database insertion fails
        await supabase.storage.from('ai-media-bucket').remove([storagePath]);
        throw new Error(`Failed to commit asset metadata to database: ${insertError.message}`);
    }

    return {
        id: insertedData.id,
        hash: insertedData.hash,
        fileSize: insertedData.file_size,
        mimeType: insertedData.mime_type,
        storagePath: insertedData.storage_path,
        creatorId: insertedData.creator_id,
        tags: insertedData.tags,
        createdAt: insertedData.created_at,
    };
}

/**
 * Generates an HMAC-signed, time-limited URL for secure distribution of private AI media assets.
 * 
 * @param storagePath - The internal object path of the asset.
 * @param expiresInSeconds - Validity duration of the signed URL in seconds.
 * @returns Fully qualified signed URL string.
 */
export async function generateSecureAssetSignedUrl(
    storagePath: string,
    expiresInSeconds: number = 300
): Promise<string> {
    const { data, error } = await supabase.storage
        .from('ai-media-bucket')
        .createSignedUrl(storagePath, expiresInSeconds);

    if (error || !data?.signedUrl) {
        throw new Error(`Failed to generate cryptographic signed URL: ${error?.message || 'Unknown error'}`);
    }

    return data.signedUrl;
}

/**
 * Client-side Service Worker registration script blueprint for caching large ONNX model weights
 * and generative pipelines locally to achieve instant offline execution.
 */
export function getServiceWorkerRegistrationScript(): string {
    return `
        const CACHE_NAME = 'ai-media-engine-v1';
        const MODEL_ASSETS = [
            '/models/flux-transformer.onnx',
            '/models/tokenizer-weights.bin',
            '/wasm/ort-wasm-simd-threaded.wasm'
        ];

        self.addEventListener('install', (event) => {
            event.waitUntil(
                caches.open(CACHE_NAME).then((cache) => {
                    console.log('[ServiceWorker] Pre-caching core generative model weights');
                    return cache.addAll(MODEL_ASSETS);
                })
            );
            self.skipWaiting();
        });

        self.addEventListener('activate', (event) => {
            event.waitUntil(
                caches.keys().then((cacheNames) => {
                    return Promise.all(
                        cacheNames.map((cacheName) => {
                            if (cacheName !== CACHE_NAME) {
                                console.log('[ServiceWorker] Purging outdated model cache:', cacheName);
                                return caches.delete(cacheName);
                            }
                        })
                    );
                })
            );
            self.clientClaim();
        });

        self.addEventListener('fetch', (event) => {
            const url = new URL(event.request.url);
            if (url.pathname.startsWith('/models/') || url.pathname.startsWith('/wasm/')) {
                event.respondWith(
                    caches.match(event.request).then((cachedResponse) => {
                        if (cachedResponse) {
                            return cachedResponse;
                        }
                        return fetch(event.request).then((networkResponse) => {
                            return caches.open(CACHE_NAME).then((cache) => {
                                cache.put(event.request, networkResponse.clone());
                                return networkResponse;
                            });
                        });
                    })
                );
            }
        });
    `;
}
