/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface AssetMetadata {
    readonly id: string;
    readonly uri: string;
    readonly mimeType: string;
    readonly sizeBytes: number;
    readonly checksum: string;
    readonly status: 'unloaded' | 'loading' | 'cached' | 'error';
    readonly lastAccessed: number;
}

export interface AssetRegistryState {
    readonly assets: ReadonlyMap<string, AssetMetadata>;
    readonly lruQueue: ReadonlyArray<string>;
    readonly maxCapacity: number;
}

export type AssetRegistryAction =
    | { type: 'REGISTER_ASSET'; payload: AssetMetadata }
    | { type: 'UPDATE_STATUS'; payload: { id: string; status: AssetMetadata['status'] } }
    | { type: 'EVICT_LRU' };

export function assetRegistryReducer(
    state: AssetRegistryState,
    action: AssetRegistryAction
): AssetRegistryState {
    switch (action.type) {
        case 'REGISTER_ASSET': {
            const asset = action.payload;
            const newAssets = new Map(state.assets);
            newAssets.set(asset.id, asset);

            // Filter out existing occurrence in LRU queue if updating, then push to back (most recent)
            let newQueue = state.lruQueue.filter((id) => id !== asset.id);
            newQueue = [...newQueue, asset.id];

            // Check capacity eviction
            if (newQueue.length > state.maxCapacity) {
                const evictedId = newQueue[0];
                newQueue = newQueue.slice(1);
                newAssets.delete(evictedId);
            }

            return {
                ...state,
                assets: newAssets,
                lruQueue: newQueue,
            };
        }

        case 'UPDATE_STATUS': {
            const { id, status } = action.payload;
            const existing = state.assets.get(id);
            if (!existing) return state;

            const updatedAsset: AssetMetadata = {
                ...existing,
                status,
                lastAccessed: Date.now(),
            };

            const newAssets = new Map(state.assets);
            newAssets.set(id, updatedAsset);

            // Move to back of LRU queue
            const newQueue = [...state.lruQueue.filter((item) => item !== id), id];

            return {
                ...state,
                assets: newAssets,
                lruQueue: newQueue,
            };
        }

        case 'EVICT_LRU': {
            if (state.lruQueue.length === 0) return state;

            const evictedId = state.lruQueue[0];
            const newQueue = state.lruQueue.slice(1);
            const newAssets = new Map(state.assets);
            newAssets.delete(evictedId);

            return {
                ...state,
                assets: newAssets,
                lruQueue: newQueue,
            };
        }

        default:
            return state;
    }
}
