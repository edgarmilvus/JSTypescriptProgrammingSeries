/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { AssetRegistryState, AssetMetadata } from './AssetRegistry';

export interface GenerativeMediaGalleryProps {
    readonly registryState: AssetRegistryState;
    readonly viewportWidth: number;
    readonly viewportHeight: number;
    readonly itemHeight: number;
    readonly onAssetSelect: (id: string) => void;
}

export const GenerativeMediaGallery: React.FC<GenerativeMediaGalleryProps> = ({
    registryState,
    viewportWidth,
    viewportHeight,
    itemHeight,
    onAssetSelect,
}) => {
    const [scrollTop, setScrollTop] = useState(0);

    const assetIds = useMemo(() => Array.from(registryState.assets.keys()), [registryState.assets]);
    const totalHeight = assetIds.length * itemHeight;

    const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - 2);
    const endIndex = Math.min(
        assetIds.length,
        Math.ceil((scrollTop + viewportHeight) / itemHeight) + 2
    );

    const visibleAssetIds = useMemo(
        () => assetIds.slice(startIndex, endIndex),
        [assetIds, startIndex, endIndex]
    );

    const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
        setScrollTop(e.currentTarget.scrollTop);
    }, []);

    return (
        <div
            className="generative-media-gallery-container"
            onScroll={handleScroll}
            style={{ width: viewportWidth, height: viewportHeight, overflowY: 'auto', position: 'relative' }}
        >
            <div style={{ height: totalHeight, width: '100%', position: 'relative' }}>
                {visibleAssetIds.map((id, index) => {
                    const actualIndex = startIndex + index;
                    const asset = registryState.assets.get(id);
                    if (!asset) return null;

                    return (
                        <div
                            key={asset.id}
                            onClick={() => onAssetSelect(asset.id)}
                            style={{
                                position: 'absolute',
                                top: actualIndex * itemHeight,
                                left: 0,
                                width: '100%',
                                height: itemHeight,
                                display: 'flex',
                                alignItems: 'center',
                                borderBottom: '1px solid #333',
                                padding: '0 16px',
                                boxSizing: 'border-box',
                                cursor: 'pointer',
                            }}
                        >
                            <span>{asset.id} - Status: {asset.status}</span>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
