/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface EdgeMiddlewareContext {
    readonly request: Request;
    readonly env: {
        readonly ASSET_SIGNING_SECRET: string;
        readonly KV_RATE_LIMIT_NAMESPACE: any;
    };
}

export async function handleEdgeAssetRequest(context: EdgeMiddlewareContext): Promise<Response> {
    const url = new URL(context.request.url);
    const signature = url.searchParams.get('sig');
    const expiresParam = url.searchParams.get('exp');

    if (!signature || !expiresParam) {
        return new Response('Missing signature or expiration', { status: 403 });
    }

    const expiresAt = parseInt(expiresParam, 10);
    if (isNaN(expiresAt) || Date.now() > expiresAt) {
        return new Response('URL expired', { status: 403 });
    }

    // Reconstruct canonical payload for verification
    const canonicalPath = url.pathname;
    const dataToVerify = `${canonicalPath}?exp=${expiresAt}`;

    const encoder = new TextEncoder();
    const keyData = encoder.encode(context.env.ASSET_SIGNING_SECRET);
    const msgData = encoder.encode(dataToVerify);

    const cryptoKey = await crypto.subtle.importKey(
        'raw',
        keyData,
        { name: 'HMAC', hash: 'SHA-256' },
        false,
        ['verify']
    );

    const sigBytes = Uint8Array.from(atob(signature), (c) => c.charCodeAt(0));
    const isValid = await crypto.subtle.verify('HMAC', cryptoKey, sigBytes, msgData);

    if (!isValid) {
        return new Response('Invalid cryptographic signature', { status: 403 });
    }

    // Rate limiting check simulation via KV
    const clientIp = context.request.headers.get('cf-connecting-ip') || '127.0.0.1';
    const rateLimitKey = `rl:${clientIp}`;
    const currentCount = await context.env.KV_RATE_LIMIT_NAMESPACE.get(rateLimitKey);

    if (currentCount && parseInt(currentCount, 10) > 100) {
        return new Response('Too Many Requests', { status: 429 });
    }
    await context.env.KV_RATE_LIMIT_NAMESPACE.put(rateLimitKey, ((parseInt(currentCount || '0', 10)) + 1).toString(), { expirationTtl: 60 });

    const response = new Response('Asset content stream placeholder', { status: 200 });
    response.headers.set('Cache-Control', 'public, max-age=31536000, immutable');
    return response;
}
