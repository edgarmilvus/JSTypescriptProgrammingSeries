/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface StorageRecord {
    readonly checksum: string;
    readonly storageUri: string;
    readonly referenceCount: number;
    readonly createdAt: number;
    readonly lastAccessedAt: number;
    readonly storageTier: 'hot' | 'warm' | 'cold';
}

export class AssetDeduplicationService {
    private readonly registry: Map<string, StorageRecord> = new Map();

    private async calculateChecksum(buffer: ArrayBuffer): Promise<string> {
        const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    public async registerOrDedupAsset(
        assetBuffer: ArrayBuffer,
        targetStorageUri: string
    ): Promise<{ uri: string; isDuplicate: boolean }> {
        const checksum = await this.calculateChecksum(assetBuffer);
        const existing = this.registry.get(checksum);

        if (existing) {
            const updatedRecord: StorageRecord = {
                ...existing,
                referenceCount: existing.referenceCount + 1,
                lastAccessedAt: Date.now(),
            };
            this.registry.set(checksum, updatedRecord);
            return { uri: existing.storageUri, isDuplicate: true };
        }

        const newRecord: StorageRecord = {
            checksum,
            storageUri: targetStorageUri,
            referenceCount: 1,
            createdAt: Date.now(),
            lastAccessedAt: Date.now(),
            storageTier: 'hot',
        };

        this.registry.set(checksum, newRecord);
        return { uri: targetStorageUri, isDuplicate: false };
    }

    public async releaseAssetReference(checksum: string): Promise<boolean> {
        const existing = this.registry.get(checksum);
        if (!existing) return false;

        const newCount = existing.referenceCount - 1;
        if (newCount <= 0) {
            this.registry.delete(checksum);
            return true; // Marked for permanent garbage collection & CDN purge
        }

        this.registry.set(checksum, {
            ...existing,
            referenceCount: newCount,
        });
        return false;
    }
}
