/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

export interface AssetMetadata {
    readonly id: string;
    readonly uri: string;
    readonly mimeType: string;
    readonly sizeBytes: number;
    readonly checksum: string;
    readonly status: 'unloaded' | 'loading' | 'cached' | 'error';
    readonly lastAccessed: number;
}

export interface AssetRegistryState {
    readonly assets: ReadonlyMap<string, AssetMetadata>;
    readonly lruQueue: ReadonlyArray<string>;
    readonly maxCapacity: number;
}

export type AssetRegistryAction =
    | { type: 'REGISTER_ASSET'; payload: AssetMetadata }
    | { type: 'UPDATE_STATUS'; payload: { id: string; status: AssetMetadata['status'] } }
    | { type: 'EVICT_LRU' };

export function assetRegistryReducer(
    state: AssetRegistryState,
    action: AssetRegistryAction
): AssetRegistryState {
    // TODO: Implement immutable state transitions adhering to LRU and capacity constraints.
    // Ensure that state.assets and state.lruQueue are never mutated in place.
    throw new Error('Not implemented');
}
