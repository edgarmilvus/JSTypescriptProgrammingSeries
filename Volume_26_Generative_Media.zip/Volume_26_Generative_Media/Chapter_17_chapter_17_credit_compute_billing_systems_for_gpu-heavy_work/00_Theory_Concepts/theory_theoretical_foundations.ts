/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#102a43"];
edge [color="#334e68", arrowhead=vee];

subgraph cluster_canvas {
    label = "Node-Based AI Canvas (Client/Worker)";
    style = dashed;
    color = "#627d98";
    
    InputNode [label="Input Image Node\n(Data Ingestion)"];
    ShaderNode [label="WebGPU Processing Node\n(Shader Pipeline)"];
    AIAgentNode [label="Transformers.js Inference Node\n(Browser / Edge Agent)"];
    ConsensusNode [label="Reviewer / Consensus Node\n(Multi-Agent Output Synthesis)"];
    
    InputNode -> ShaderNode;
    ShaderNode -> AIAgentNode;
    AIAgentNode -> ConsensusNode;
}

subgraph cluster_ledger {
    label = "Cryptographic Credit & Compute Ledger";
    style = filled;
    fillcolor = "#e1effe";
    color = "#3182ce";
    
    StateStore [label="Immutable State Management Store\n(Append-Only Feature Vectors & Hashed Transitions)"];
    CircuitBreaker [label="Real-Time Rate-Limiter &\nAuto-Pause Circuit Breaker"];
    
    ShaderNode -> StateStore [style=dotted, label="Emit Compute Units"];
    AIAgentNode -> StateStore [style=dotted, label="Emit Token Consumption"];
    StateStore -> CircuitBreaker [label="Evaluate Cumulative Load"];
}
