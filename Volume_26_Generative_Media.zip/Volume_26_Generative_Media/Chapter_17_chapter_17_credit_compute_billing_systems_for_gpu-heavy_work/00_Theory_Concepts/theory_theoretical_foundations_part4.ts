/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#102a43"];
edge [color="#334e68", arrowhead=vee];

Closed [label="CLOSED STATE\nNormal Pipeline Execution\n(Monitoring Burn Rate)"];
TripCondition [label="Threshold Exceeded?\n(Burn Rate > Max GCU/s OR Balance <= 0)", shape=diamond, fillcolor="#fed7d7", color="#e53e3e"];
Open [label="OPEN STATE\nAuto-Pause Circuit Breaker Tripped\n(WebGPU & Agents Terminated)"];
UserAction [label="User Intervention\n(Top-Up Credits / Fix Graph Loop)"];
HalfOpen [label="HALF-OPEN STATE\nProbationary Test Execution\n(Validating Resource Stability)"];

Closed -> TripCondition;
TripCondition -> Closed [label="No"];
TripCondition -> Open [label="Yes"];
Open -> UserAction;
UserAction -> HalfOpen;
HalfOpen -> Closed [label="Stable"];
HalfOpen -> Open [label="Unstable"];
ZeroBalance [label="Balance <= 0", shape=diamond, fillcolor="#fed7d7", color="#e53e3e"];
Closed -> ZeroBalance;
ZeroBalance -> Open [label="Yes"];
