/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file CreditLedgerEngine.ts
 * @description A cryptographic, immutable credit ledger and WebGPU compute billing interceptor 
 * designed for real-time generative media pipelines in TypeScript.
 * 
 * SaaS Context: Prevents runaway resource utilization by cryptographically hashing transactions, 
 * verifying pre-computed cost deltas against an append-only ledger, and halting execution via 
 * an automatic circuit breaker if compute-unit balances drop below safety thresholds.
 */

import * as crypto from 'crypto';

/**
 * Represents a single immutable transaction node within the cryptographic ledger.
 */
interface LedgerEntry {
    readonly id: string;
    readonly previousHash: string;
    readonly userId: string;
    readonly computeUnitsDelta: number;
    readonly costUsd: number;
    readonly timestamp: number;
    readonly signature: string;
}

/**
 * Configuration parameters for the GPU compute pipeline cost model.
 */
interface GpuCostConfig {
    readonly baseCostPerDispatch: number;
    readonly costPerWorkgroup: number;
    readonly costPerMillisecond: number;
}

/**
 * Tracks and enforces compute quotas and immutable transaction histories for a SaaS user base.
 */
export class CreditLedgerEngine {
    private ledger: LedgerEntry[] = [];
    private userBalances: Map<string, number> = new Map();
    private secretKey: string;
    private costConfig: GpuCostConfig;

    /**
     * Initializes the credit ledger engine with cryptographic secrets and GPU pricing models.
     * @param secretKey HMAC secret used to sign and verify ledger immutability.
     * @param costConfig Pricing model mapping GPU workloads to exact monetary/credit costs.
     */
    constructor(secretKey: string, costConfig: GpuCostConfig) {
        this.secretKey = secretKey;
        this.costConfig = costConfig;
        
        // Seed the ledger with a cryptographic genesis block
        this.appendGenesisBlock();
    }

    /**
     * Creates the immutable genesis block for the ledger chain.
     */
    private appendGenesisBlock(): void {
        const genesisEntry: Omit<LedgerEntry, 'signature'> = {
            id: 'gen-0000-0000-0000',
            previousHash: '0'.repeat(64),
            userId: 'SYSTEM',
            computeUnitsDelta: 0,
            costUsd: 0,
            timestamp: Date.now()
        };

        const signature = this.signEntry(genesisEntry);
        this.ledger.push({ ...genesisEntry, signature });
    }

    /**
     * Computes an HMAC-SHA256 signature for a ledger entry to guarantee tamper-resistance.
     */
    private signEntry(entry: Omit<LedgerEntry, 'signature'>): string {
        const payload = `${entry.id}|${entry.previousHash}|${entry.userId}|${entry.computeUnitsDelta}|${entry.costUsd}|${entry.timestamp}`;
        return crypto.createHmac('sha256', this.secretKey).update(payload).digest('hex');
    }

    /**
     * Adds funds (credits) to a user account, appending an immutable credit transaction to the chain.
     * @param userId Unique identifier of the SaaS subscriber.
     * @param amount Number of compute units or credits added.
     * @param dollarValue Real-world fiat value associated with the purchase.
     */
    public creditAccount(userId: string, amount: number, dollarValue: number): LedgerEntry {
        const currentBalance = this.userBalances.get(userId) || 0;
        this.userBalances.set(userId, currentBalance + amount);

        const previousBlock = this.ledger[this.ledger.length - 1];
        const newEntryData: Omit<LedgerEntry, 'signature'> = {
            id: crypto.randomUUID(),
            previousHash: previousBlock.signature,
            userId,
            computeUnitsDelta: amount,
            costUsd: -dollarValue, // Negative cost for the user means positive balance acquisition
            timestamp: Date.now()
        };

        const signature = this.signEntry(newEntryData);
        const entry: LedgerEntry = { ...newEntryData, signature };
        
        this.ledger.push(entry);
        return entry;
    }

    /**
     * Calculates the projected compute cost for a WebGPU dispatch payload based on thread counts and duration.
     * @param workgroupCountX Number of workgroups dispatched along the X dimension.
     * @param workgroupCountY Number of workgroups dispatched along the Y dimension.
     * @param estimatedExecutionMs Estimated hardware execution time in milliseconds.
     */
    public calculateWorkloadCost(workgroupCountX: number, workgroupCountY: number, estimatedExecutionMs: number): { units: number; usd: number } {
        const totalWorkgroups = workgroupCountX * workgroupCountY;
        const computedUnits = Math.ceil(
            this.costConfig.baseCostPerDispatch +
            (totalWorkgroups * this.costConfig.costPerWorkgroup) +
            (estimatedExecutionMs * this.costConfig.costPerMillisecond)
        );

        // Assume conversion rate of 100 compute units per $1.00 USD for this SaaS tier
        const computedUsd = computedUnits / 100;
        return { units: computedUnits, usd: computedUsd };
    }

    /**
     * Intercepts a WebGPU processing request, verifying sufficient credit balances and deducting atomically.
     * Acts as an auto-pause circuit breaker for high-throughput visual streaming pipelines.
     * 
     * @param userId The tenant executing the GPU job.
     * @param workgroupCountX WebGPU dispatch parameter X.
     * @param workgroupCountY WebGPU dispatch parameter Y.
     * @param estimatedExecutionMs Estimated runtime.
     * @returns boolean True if execution is authorized, false if throttled/paused due to insolvency.
     */
    public authorizeAndDeductGpuCompute(
        userId: string,
        workgroupCountX: number,
        workgroupCountY: number,
        estimatedExecutionMs: number
    ): boolean {
        const currentBalance = this.userBalances.get(userId) || 0;
        const cost = this.calculateWorkloadCost(workgroupCountX, workgroupCountY, estimatedExecutionMs);

        // Circuit Breaker Check: Halt execution if balance is insufficient
        if (currentBalance < cost.units) {
            console.warn(`[CircuitBreaker] User ${userId} halted. Insufficient compute units. Balance: ${currentBalance}, Required: ${cost.units}`);
            return false;
        }

        // Deduct balance
        this.userBalances.set(userId, currentBalance - cost.units);

        // Append debit entry to immutable ledger
        const previousBlock = this.ledger[this.ledger.length - 1];
        const debitEntryData: Omit<LedgerEntry, 'signature'> = {
            id: crypto.randomUUID(),
            previousHash: previousBlock.signature,
            userId,
            computeUnitsDelta: -cost.units,
            costUsd: cost.usd,
            timestamp: Date.now()
        };

        const signature = this.signEntry(debitEntryData);
        this.ledger.push({ ...debitEntryData, signature });

        return true;
    }

    /**
     * Validates the cryptographic integrity of the entire ledger chain.
     * Traverses every node, checking HMAC signatures and hash chain continuity.
     */
    public verifyLedgerIntegrity(): boolean {
        for (let i = 1; i < this.ledger.length; i++) {
            const current = this.ledger[i];
            const previous = this.ledger[i - 1];

            // Verify hash linkage
            if (current.previousHash !== previous.signature) {
                console.error(`[LedgerTamperDetected] Broken chain link at index ${i}.`);
                return false;
            }

            // Verify cryptographic signature
            const entryData: Omit<LedgerEntry, 'signature'> = {
                id: current.id,
                previousHash: current.previousHash,
                userId: current.userId,
                computeUnitsDelta: current.computeUnitsDelta,
                costUsd: current.costUsd,
                timestamp: current.timestamp
            };

            const expectedSignature = this.signEntry(entryData);
            if (expectedSignature !== current.signature) {
                console.error(`[LedgerTamperDetected] Invalid signature at index ${i}. Payload modified.`);
                return false;
            }
        }
        return true;
    }

    /**
     * Returns the current verified compute balance for a user.
     */
    public getBalance(userId: string): number {
        return this.userBalances.get(userId) || 0;
    }
}

// ==========================================
// Execution Demonstration (SaaS Integration)
// ==========================================

const pricingModel: GpuCostConfig = {
    baseCostPerDispatch: 10,
    costPerWorkgroup: 0.05,
    costPerMillisecond: 0.2
};

// Instantiate ledger with a secure environment secret
const ledgerEngine = new CreditLedgerEngine('super-secure-hmac-salt-key-xyz987', pricingModel);

// 1. User purchases credits
const tenantId = 'tenant_enterprise_99';
ledgerEngine.creditAccount(tenantId, 5000, 50.00); // Purchased 5000 units for $50
console.log(`Initial Balance for ${tenantId}: ${ledgerEngine.getBalance(tenantId)} units`);

// 2. WebGPU Pipeline Interceptor execution simulation (e.g., real-time style transfer or neural upscale)
const dispatchX = 256;
const dispatchY = 256;
const estimatedDurationMs = 45;

const isAuthorized = ledgerEngine.authorizeAndDeductGpuCompute(
    tenantId,
    dispatchX,
    dispatchY,
    estimatedDurationMs
);

console.log(`GPU Pipeline Execution Authorized: ${isAuthorized}`);
console.log(`Remaining Balance for ${tenantId}: ${ledgerEngine.getBalance(tenantId)} units`);

// 3. Verify ledger integrity
const isLedgerValid = ledgerEngine.verifyLedgerIntegrity();
console.log(`Cryptographic Ledger Chain Integrity Verified: ${isLedgerValid}`);
