/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createHash, randomUUID } from 'crypto';

/**
 * Represents a single immutable transaction within the compute credit ledger.
 */
export interface CreditTransaction {
  readonly id: string;
  readonly userId: string;
  readonly delta: number; // Negative for consumption, positive for top-up
  readonly timestamp: number;
  readonly pipelineId: string;
  readonly previousHash: string;
  readonly currentHash: string;
}

/**
 * Configuration for compute token estimation per node execution type.
 */
export interface ComputeProfile {
  readonly baseTokenCost: number;
  readonly costPerMegapixel: number;
  readonly costPerWebGPUTick: number;
}

/**
 * Telemetry metrics captured during active WebGPU streaming.
 */
export interface StreamTelemetry {
  readonly framesProcessed: number;
  readonly averageGPUTimeMs: number;
  readonly vramUsageBytes: number;
}

/**
 * Immutable Ledger for tracking and auditing compute credit consumption
 * across distributed node-based AI pipelines.
 */
export class ImmutableCreditLedger {
  private chain: CreditTransaction[] = [];

  constructor() {
    // Initialize genesis block
    const genesis: CreditTransaction = {
      id: 'genesis',
      userId: 'system',
      delta: 0,
      timestamp: Date.now(),
      pipelineId: 'root',
      previousHash: '0'.repeat(64),
      currentHash: this.calculateHash('genesis', 'system', 0, 0, 'root', '0'.repeat(64)),
    };
    this.chain.push(genesis);
  }

  private calculateHash(
    id: string,
    userId: string,
    delta: number,
    timestamp: number,
    pipelineId: string,
    previousHash: string
  ): string {
    const payload = `${id}:${userId}:${delta}:${timestamp}:${pipelineId}:${previousHash}`;
    return createHash('sha256').update(payload).digest('hex');
  }

  /**
   * Retrieves the current credit balance for a specified user by reducing the ledger.
   */
  public getBalance(userId: string): number {
    return this.chain
      .filter((tx) => tx.userId === userId || tx.userId === 'system')
      .reduce((acc, tx) => acc + tx.delta, 0);
  }

  /**
   * Appends a new immutable credit transaction to the chain.
   */
  public recordTransaction(userId: string, delta: number, pipelineId: string): CreditTransaction {
    const lastBlock = this.chain[this.chain.length - 1];
    const id = randomUUID();
    const timestamp = Date.now();
    const previousHash = lastBlock.currentHash;
    const currentHash = this.calculateHash(id, userId, delta, timestamp, pipelineId, previousHash);

    const newTx: CreditTransaction = {
      id,
      userId,
      delta,
      timestamp,
      pipelineId,
      previousHash,
      currentHash,
    };

    this.chain.push(newTx);
    return newTx;
  }

  /**
   * Verifies the cryptographic integrity of the entire audit chain.
   */
  public verifyIntegrity(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const current = this.chain[i];
      const previous = this.chain[i - 1];

      if (current.previousHash !== previous.currentHash) {
        return false;
      }

      const recomputedHash = this.calculateHash(
        current.id,
        current.userId,
        current.delta,
        current.timestamp,
        current.pipelineId,
        current.previousHash
      );

      if (recomputedHash !== current.currentHash) {
        return false;
      }
    }
    return true;
  }
}

/**
 * Real-time Circuit Breaker and Token Meter for WebGPU Streaming Pipelines.
 */
export class ComputeStreamCircuitBreaker {
  private ledger: ImmutableCreditLedger;
  private userId: string;
  private pipelineId: string;
  private profile: ComputeProfile;
  private activeSession: boolean = false;
  private accumulatedCost: number = 0;
  private maxAllowedCost: number;
  private frameTimer: NodeJS.Timeout | null = null;

  constructor(
    ledger: ImmutableCreditLedger,
    userId: string,
    pipelineId: string,
    profile: ComputeProfile,
    maxAllowedCost: number
  ) {
    this.ledger = ledger;
    this.userId = userId;
    this.pipelineId = pipelineId;
    this.profile = profile;
    this.maxAllowedCost = maxAllowedCost;
  }

  /**
   * Evaluates prerequisites, debits starting tokens, and initializes the stream.
   */
  public async initializeStream(initialMegapixels: number): Promise<boolean> {
    const estimatedCost =
      this.profile.baseTokenCost + initialMegapixels * this.profile.costPerMegapixel;

    const currentBalance = this.ledger.getBalance(this.userId);
    if (currentBalance < estimatedCost) {
      throw new Error(`Insufficient credits. Required: ${estimatedCost}, Available: ${currentBalance}`);
    }

    // Commit upfront reservation
    this.ledger.recordTransaction(this.userId, -estimatedCost, this.pipelineId);
    this.accumulatedCost += estimatedCost;
    this.activeSession = true;
    return true;
  }

  /**
   * Processes a real-time WebGPU streaming tick, evaluating telemetry against safety thresholds.
   */
  public processTick(telemetry: StreamTelemetry): void {
    if (!this.activeSession) return;

    // Calculate incremental cost based on WebGPU execution duration and memory footprint
    const tickCost =
      (telemetry.averageGPUTimeMs / 1000) * this.profile.costPerWebGPUTick +
      (telemetry.vramUsageBytes / (1024 * 1024 * 1024)) * 0.05;

    this.accumulatedCost += tickCost;

    // Check circuit breaker trip conditions
    if (this.accumulatedCost > this.maxAllowedCost || telemetry.averageGPUTimeMs > 33.3) {
      this.tripBreaker('Threshold exceeded: High GPU latency or maximum cost cap reached.');
    }
  }

  /**
   * Forcefully halts the streaming pipeline and reconciles token balances.
   */
  public tripBreaker(reason: string): void {
    if (!this.activeSession) return;
    this.activeSession = false;
    if (this.frameTimer) clearInterval(this.frameTimer);
    console.warn(`[CircuitBreaker Tripped] Pipeline ${this.pipelineId} halted. Reason: ${reason}`);
  }

  /**
   * Gracefully concludes the streaming session and refunds any unspent fractional tokens.
   */
  public settleStream(finalUsageCost: number): void {
    if (!this.activeSession) return;
    this.activeSession = false;
    if (this.frameTimer) clearInterval(this.frameTimer);

    if (finalUsageCost < this.accumulatedCost) {
      const refund = this.accumulatedCost - finalUsageCost;
      this.ledger.recordTransaction(this.userId, refund, this.pipelineId);
    }
  }
}
