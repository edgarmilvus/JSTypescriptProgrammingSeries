/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface LedgerTransaction {
  id: string;
  timestamp: number;
  userId: string;
  delta: number;
  operationType: string;
  metadata: Record<string, unknown>;
  previousHash: string;
  hash: string;
}

class CryptographicCreditLedger {
  private chain: LedgerTransaction[] = [];
  private static readonly GENESIS_HASH = '0x0000000000000000000000000000000000000000000000000000000000000000';

  constructor() {
    // Initialization of genesis block handled implicitly or via explicit bootstrap if desired
  }

  private async computeHash(data: string): Promise<string> {
    const encoder = new TextEncoder();
    const buffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  public async appendTransaction(
    tx: Omit<LedgerTransaction, 'id' | 'timestamp' | 'previousHash' | 'hash'>
  ): Promise<LedgerTransaction> {
    const id = crypto.randomUUID();
    const timestamp = Date.now();
    const previousHash = this.chain.length > 0 
      ? this.chain[this.chain.length - 1].hash 
      : CryptographicCreditLedger.GENESIS_HASH;

    const rawData = `${id}|${timestamp}|${tx.userId}|${tx.delta}|${tx.operationType}|${JSON.stringify(tx.metadata)}|${previousHash}`;
    const hash = await this.computeHash(rawData);

    const newBlock: LedgerTransaction = {
      id,
      timestamp,
      userId: tx.userId,
      delta: tx.delta,
      operationType: tx.operationType,
      metadata: tx.metadata,
      previousHash,
      hash,
    };

    this.chain.push(newBlock);
    return newBlock;
  }

  public async verifyChainIntegrity(): Promise<boolean> {
    for (let i = 0; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      
      // Verify previousHash link
      const expectedPreviousHash = i === 0 
        ? CryptographicCreditLedger.GENESIS_HASH 
        : this.chain[i - 1].hash;

      if (currentBlock.previousHash !== expectedPreviousHash) {
        return false;
      }

      // Recompute hash to verify block immutability
      const rawData = `${currentBlock.id}|${currentBlock.timestamp}|${currentBlock.userId}|${currentBlock.delta}|${currentBlock.operationType}|${JSON.stringify(currentBlock.metadata)}|${currentBlock.previousHash}`;
      const recomputedHash = await this.computeHash(rawData);

      if (currentBlock.hash !== recomputedHash) {
        return false;
      }
    }
    return true;
  }

  public getBalance(userId: string): number {
    return this.chain
      .filter(tx => tx.userId === userId)
      .reduce((acc, tx) => acc + tx.delta, 0);
  }
}

async function simulateLedgerForkResolution(
  ledger: CryptographicCreditLedger, 
  maliciousBlocks: LedgerTransaction[]
): Promise<boolean> {
  // Simulate injecting a malicious block into the private chain array for testing
  // Accessing private array via reflection/any casting for testing simulation context
  const chainRef = (ledger as any).chain as LedgerTransaction[];
  if (chainRef.length > 0) {
    chainRef[0].delta += 1000; // Tamper with genesis or an intermediate block
  }
  return await ledger.verifyChainIntegrity();
}
