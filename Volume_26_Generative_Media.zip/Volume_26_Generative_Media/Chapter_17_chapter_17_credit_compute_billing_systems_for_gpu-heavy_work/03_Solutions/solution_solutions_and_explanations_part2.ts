/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

class InsufficientCreditsError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InsufficientCreditsError';
  }
}

class WebGPUComputeBillingPipeline {
  private device: GPUDevice;
  private ledger: CryptographicCreditLedger;

  constructor(device: GPUDevice, ledger: CryptographicCreditLedger) {
    this.device = device;
    this.ledger = ledger;
  }

  public async executeComputeJob(params: {
    userId: string;
    workgroupCount: [number, number, number];
    pipeline: GPUComputePipeline;
    bindGroup: GPUBindGroup;
    estimatedTokens?: number;
  }): Promise<void> {
    const estimatedTokens = params.estimatedTokens ?? 0;
    const estimatedCost = 1.0; // Baseline check cost approximation

    // 1. Check user balance before execution
    const currentBalance = this.ledger.getBalance(params.userId);
    if (currentBalance < estimatedCost) {
      throw new InsufficientCreditsError(`User ${params.userId} has insufficient credits (${currentBalance}) for execution.`);
    }

    // 2. Allocate GPU Query Set for precise timestamp measurement
    const querySet = this.device.createQuerySet({
      type: 'timestamp',
      count: 2,
    });

    const resolveBuffer = this.device.createBuffer({
      size: 16, // 2 x 64-bit integers (u64 timestamps)
      usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC,
    });

    const destinationBuffer = this.device.createBuffer({
      size: 16,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    });

    // 3. Encode Commands and Write Timestamps
    const commandEncoder = this.device.createCommandEncoder();
    
    // Pass 1: Record start timestamp
    const passEncoder = commandEncoder.beginComputePass({
      timestampWrites: {
        querySetOfWriting: querySet,
        beginningOfPassWriteIndex: 0,
        endOfPassWriteIndex: 1,
      },
    });

    passEncoder.setPipeline(params.pipeline);
    passEncoder.setBindGroup(0, params.bindGroup);
    passEncoder.dispatchWorkgroups(...params.workgroupCount);
    passEncoder.end();

    // Resolve queries to staging buffer
    commandEncoder.resolveQuerySet(querySet, 0, 2, resolveBuffer, 0);
    commandEncoder.copyBufferToBuffer(resolveBuffer, 0, destinationBuffer, 0, 16);

    this.device.queue.submit([commandEncoder.finish()]);

    // 4. Map destination buffer and extract nanoseconds
    await destinationBuffer.mapAsync(GPUMapMode.READ);
    const timings = new BigInt64Array(destinationBuffer.getMappedRange());
    const startNs = timings[0];
    const endNs = timings[1];
    const gpuNanoseconds = Number(endNs - startNs);
    
    destinationBuffer.unmap();

    // 5. Calculate unified credit debit (1 Credit = 10^6 ns + 0.0001 * tokens)
    const computeUnits = gpuNanoseconds / 1_000_000;
    const tokenCost = estimatedTokens * 0.0001;
    const totalCreditDelta = -(computeUnits + tokenCost);

    // 6. Commit transaction to ledger
    await this.ledger.appendTransaction({
      userId: params.userId,
      delta: totalCreditDelta,
      operationType: 'WEBGPU_COMPUTE_CYCLE',
      metadata: {
        gpuNanoseconds,
        workgroupCount: params.workgroupCount,
        estimatedTokens,
      },
    });
  }
}

async function benchmarkAndBill(
  pipeline: WebGPUComputeBillingPipeline, 
  userId: string, 
  iterations: number
): Promise<{ averageNanoseconds: number; totalCreditsDeducted: number }> {
  // Benchmark execution stub
  return { averageNanoseconds: 1250000, totalCreditsDeducted: 2.5 };
}
