/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

interface CircuitBreakerConfig {
  maxBurnRatePerSecond: number;
  absoluteMinimumBalance: number;
  cooldownPeriodMs: number;
  onTrip: () => Promise<void>;
}

class StreamingCircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private config: CircuitBreakerConfig;
  private rollingWindow: { timestamp: number; credits: number }[] = [];
  private tripTimestamp: number = 0;

  constructor(config: CircuitBreakerConfig) {
    this.config = config;
  }

  public recordConsumption(credits: number, balance: number): CircuitState {
    const now = Date.now();

    // 1. Immediate absolute balance threshold trip check
    if (balance <= this.config.absoluteMinimumBalance) {
      this.trip(now);
      return this.state;
    }

    // 2. Append new consumption event and prune window older than 1 second
    this.rollingWindow.push({ timestamp: now, credits });
    this.rollingWindow = this.rollingWindow.filter(item => now - item.timestamp <= 1000);

    // 3. Calculate rolling burn rate (credits consumed in last 1000ms)
    const totalBurnInWindow = this.rollingWindow.reduce((sum, item) => sum + item.credits, 0);

    if (totalBurnInWindow > this.config.maxBurnRatePerSecond && this.state === 'CLOSED') {
      this.trip(now);
    }

    // Handle Half-Open automatic timeout recovery check
    if (this.state === 'OPEN' && now - this.tripTimestamp >= this.config.cooldownPeriodMs) {
      this.state = 'HALF_OPEN';
    }

    return this.state;
  }

  private trip(timestamp: number): void {
    if (this.state !== 'OPEN') {
      this.state = 'OPEN';
      this.tripTimestamp = timestamp;
      this.config.onTrip().catch(err => console.error('Error during circuit breaker trip callback:', err));
    }
  }

  public attemptRecovery(currentBalance: number): boolean {
    if (this.state === 'HALF_OPEN') {
      if (currentBalance > this.config.absoluteMinimumBalance) {
        this.state = 'CLOSED';
        this.rollingWindow = [];
        return true;
      } else {
        this.trip(Date.now());
        return false;
      }
    }
    return false;
  }
}
