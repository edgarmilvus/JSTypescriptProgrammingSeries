/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

interface TelemetryMessage {
  type: 'METRIC_UPDATE';
  creditsDeducted: number;
  burnRate: number;
  circuitState: CircuitState;
  timestamp: number;
}

interface LiveBillingTelemetryDashboardProps {
  websocketEndpoint: string;
  initialBalance: number;
  onEmergencyPause: () => void;
}

export const LiveBillingTelemetryDashboard: React.FC<LiveBillingTelemetryDashboardProps> = ({
  websocketEndpoint,
  initialBalance,
  onEmergencyPause,
}) => {
  const [balance, setBalance] = useState<number>(initialBalance);
  const [burnRate, setBurnRate] = useState<number>(0);
  const [circuitState, setCircuitState] = useState<CircuitState>('CLOSED');
  const [events, setEvents] = useState<TelemetryMessage[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    let reconnectTimeout: NodeJS.Timeout;

    const connectWebSocket = () => {
      const ws = new WebSocket(websocketEndpoint);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        try {
          const data: TelemetryMessage = JSON.parse(event.data);
          if (data.type === 'METRIC_UPDATE') {
            setBalance(prev => Math.max(0, prev - data.creditsDeducted));
            setBurnRate(data.burnRate);
            setCircuitState(data.circuitState);
            setEvents(prev => [data, ...prev.slice(0, 49)]); // Keep last 50 events
          }
        } catch (err) {
          console.error('Failed to parse telemetry message:', err);
        }
      };

      ws.onclose = () => {
        reconnectTimeout = setTimeout(connectWebSocket, 3000); // Exponential backoff retry stub
      };
    };

    connectWebSocket();

    return () => {
      if (wsRef.current) wsRef.current.close();
      clearTimeout(reconnectTimeout);
    };
  }, [websocketEndpoint]);

  const handleKillSwitch = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'EMERGENCY_HALT' }));
    }
    setCircuitState('OPEN');
    onEmergencyPause();
  };

  const getBadgeStyles = (state: CircuitState) => {
    switch (state) {
      case 'CLOSED':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 animate-pulse';
      case 'HALF_OPEN':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/50 animate-pulse';
      case 'OPEN':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/50 animate-ping';
    }
  };

  return (
    <div className="p-6 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-800">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold tracking-wide">GPU Compute & Credit Telemetry</h2>
        <div className={`px-3 py-1 rounded-full text-xs font-semibold border ${getBadgeStyles(circuitState)}`}>
          {circuitState}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700/50">
          <span className="text-slate-400 text-sm">Remaining Credits</span>
          <div className="text-3xl font-mono font-bold mt-1 text-emerald-400">
            {balance.toFixed(4)}
          </div>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700/50">
          <span className="text-slate-400 text-sm">Burn Velocity</span>
          <div className="text-3xl font-mono font-bold mt-1 text-amber-400">
            {burnRate.toFixed(2)} <span className="text-sm font-normal text-slate-400">cr/s</span>
          </div>
        </div>
      </div>

      <button
        onClick={handleKillSwitch}
        className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg shadow-lg transition-colors flex items-center justify-center space-x-2"
      >
        <span>🚨 Emergency Kill Switch</span>
      </button>
    </div>
  );
};
