/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file WebGPUtoMP4Exporter.ts
 * @description Production-grade TypeScript implementation for capturing real-time WebGPU 
 * node graph canvases and encoding them into an MP4 file using the WebCodecs API.
 * Context: SaaS Web Video Rendering Pipeline.
 */

export interface ExportConfig {
    width: number;
    height: number;
    fps: number;
    bitrate: number;
    durationSeconds: number;
}

export class WebGPUtoMP4Exporter {
    private device: GPUDevice;
    private canvas: OffscreenCanvas;
    private context: GPUCanvasContext;
    private config: ExportConfig;
    private encoder: VideoEncoder | null = null;
    private chunks: EncodedVideoChunk[] = [];
    private isEncoding: boolean = false;

    /**
     * Initializes the WebGPU context and configuration parameters.
     * @param device Active WebGPU device instance from the browser.
     * @param config Export parameters including dimensions, framerate, and bitrate.
     */
    constructor(device: GPUDevice, config: ExportConfig) {
        this.device = device;
        this.config = config;

        // Initialize an offscreen canvas to prevent UI locking during heavy rendering tasks
        this.canvas = new OffscreenCanvas(config.width, config.height);
        const ctx = this.canvas.getContext('webgpu');
        
        if (!ctx) {
            throw new Error('Failed to acquire WebGPU context from OffscreenCanvas.');
        }
        this.context = ctx;

        // Configure the canvas context with the appropriate swap chain format
        const presentationFormat = navigator.gpu.getPreferredCanvasFormat();
        this.context.configure({
            device: this.device,
            format: presentationFormat,
            alphaMode: 'premultiplied',
        });
    }

    /**
     * Initializes the WebCodecs VideoEncoder instance with H.264 configuration.
     */
    public async initializeEncoder(): Promise<void> {
        return new Promise((resolve, reject) => {
            this.encoder = new VideoEncoder({
                output: (chunk: EncodedVideoChunk, metadata: EncodedVideoChunkMetadata) => {
                    // Store encoded chunks as they become available from the hardware encoder
                    this.chunks.push(chunk);
                    
                    // Handle potential decoder configuration updates (e.g., keyframes)
                    if (metadata.decoderConfig) {
                        // In a complete muxer, you would write this config to the MP4 track header
                    }
                },
                error: (err: DOMException) => {
                    console.error('WebCodecs VideoEncoder Error:', err);
                    reject(err);
                },
            });

            // Configure encoder for hardware-accelerated H.264 baseline/main profile
            const encoderConfig: VideoEncoderConfig = {
                codec: 'avc1.42001f', // H.264 Baseline Profile Level 3.1
                width: this.config.width,
                height: this.config.height,
                bitrate: this.config.bitrate,
                framerate: this.config.fps,
                hardwareAcceleration: 'prefer-hardware',
                latencyMode: 'quality',
            };

            // Check if the configuration is supported by the user's hardware
            VideoEncoder.isConfigSupported(encoderConfig).then((support) => {
                if (!support.supported) {
                    reject(new Error('Requested WebCodecs configuration is not supported on this hardware.'));
                    return;
                }

                this.encoder?.configure(encoderConfig);
                resolve();
            });
        });
    }

    /**
     * Renders a single frame from the WebGPU node graph and queues it for encoding.
     * @param frameIndex Current chronological frame index.
     * @param renderCallback Function containing the WebGPU render pass logic for the node graph.
     */
    public async captureAndEncodeFrame(
        frameIndex: number, 
        renderCallback: (passEncoder: GPURenderPassEncoder, textureView: GPUTextureView) => void
    ): Promise<void> {
        if (!this.encoder || this.encoder.state === 'closed') {
            throw new Error('VideoEncoder is not initialized or has been closed.');
        }

        const timestampMicroseconds = Math.round((frameIndex / this.config.fps) * 1_000_000);

        // 1. Create a command encoder for the current frame
        const commandEncoder = this.device.createCommandEncoder();
        const textureView = this.context.getCurrentTexture().createView();

        // 2. Set up render pass descriptor
        const renderPassDescriptor: GPURenderPassDescriptor = {
            colorAttachments: [{
                view: textureView,
                clearValue: { r: 0.0, g: 0.0, b: 0.0, a: 1.0 },
                loadOp: 'clear',
                storeOp: 'store',
            }],
        };

        const passEncoder = commandEncoder.beginRenderPass(renderPassDescriptor);
        
        // Execute the external node-graph rendering commands
        renderCallback(passEncoder, textureView);
        
        passEncoder.end();

        // 3. Submit commands to the GPU queue
        this.device.queue.submit([commandEncoder.finish()]);

        // 4. Create a VideoFrame directly from the canvas source for optimal zero-copy handling where available
        const videoFrame = new VideoFrame(this.canvas, {
            timestamp: timestampMicroseconds,
            duration: Math.round(1_000_000 / this.config.fps),
        });

        // 5. Determine if this frame should be a keyframe (e.g., every 2 seconds)
        const isKeyframe = frameIndex % (this.config.fps * 2) === 0;

        // 6. Push frame into the hardware encoder
        this.encoder.encode(videoFrame, { keyFrame: isKeyframe });

        // 7. Crucial: Close the VideoFrame reference to free underlying system memory
        videoFrame.close();
    }

    /**
     * Finalizes the encoding process and returns a downloadable MP4 Blob.
     * Note: In a complete application, this method passes chunks to an MP4 muxer library (e.g., mp4box.js).
     */
    public async finalizeExport(): Promise<Blob> {
        if (!this.encoder) {
            throw new Error('Encoder not initialized.');
        }

        // Flush remaining frames from the encoder pipeline
        await this.encoder.flush();
        this.encoder.close();

        // Muxing raw encoded chunks into an MP4 container container format.
        // For demonstration, we package the raw elementary stream chunks into a generic blob.
        // Production implementations utilize mp4box.js or similar WebAssembly muxers here.
        const totalLength = this.chunks.reduce((acc, chunk) => acc + chunk.byteLength, 0);
        const concatenatedBuffer = new Uint8Array(totalLength);
        let offset = 0;

        for (const chunk of this.chunks) {
            const chunkData = new Uint8Array(chunk.byteLength);
            chunk.copyTo(chunkData);
            concatenatedBuffer.set(chunkData, offset);
            offset += chunk.byteLength;
        }

        return new Blob([concatenatedBuffer], { type: 'video/mp4' });
    }
}
