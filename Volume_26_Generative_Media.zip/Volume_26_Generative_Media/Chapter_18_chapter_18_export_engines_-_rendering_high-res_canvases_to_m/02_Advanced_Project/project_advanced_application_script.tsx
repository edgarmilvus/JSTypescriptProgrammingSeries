/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { FFmpeg } from '@ffmpeg/ffmpeg'; // Conceptual integration wrapper for WASM muxing

/**
 * Configuration interface for the high-resolution video export engine.
 */
interface ExportConfig {
  width: number;
  height: number;
  fps: number;
  durationSeconds: number;
  bitrate: number;
  onProgress?: (progress: number) => void;
}

/**
 * Node-based render frame callback type.
 * Advances simulation time and draws to the WebGPU canvas context.
 */
type RenderFrameCallback = (time: number, canvas: OffscreenCanvas, context: GPUCanvasContext) => Promise<void> | void;

/**
 * Enterprise-grade SaaS Export Engine for WebGPU Node Graphs.
 * Orchestrates off-screen rendering, WebCodecs compression, and WASM packaging.
 */
export class WebGPUVideoExportEngine {
  private config: ExportConfig;
  private offscreenCanvas: OffscreenCanvas;
  private gpuContext: GPUCanvasContext | null = null;
  private device: GPUDevice | null = null;

  constructor(config: ExportConfig) {
    this.config = config;
    // Initialize an OffscreenCanvas to decouple rendering from the DOM DOM-tree
    this.offscreenCanvas = new OffscreenCanvas(config.width, config.height);
  }

  /**
   * Initializes the WebGPU device and context configuration.
   */
  public async initialize(): Promise<void> {
    const adapter = await navigator.gpu?.requestAdapter();
    if (!adapter) {
      throw new Error("WebGPU is not supported on this browser/environment.");
    }

    this.device = await adapter.requestDevice();
    
    const context = this.offscreenCanvas.getContext('webgpu');
    if (!context) {
      throw new Error("Failed to acquire WebGPU context from OffscreenCanvas.");
    }
    this.gpuContext = context;

    this.gpuContext.configure({
      device: this.device,
      format: navigator.gpu.getPreferredCanvasFormat(),
      alphaMode: 'premultiplied',
    });
  }

  /**
   * Executes the non-real-time rendering loop, piping frames directly into the WebCodecs encoder.
   * @param renderCallback The node graph evaluation function for a specific timestamp.
   */
  public async exportToMP4(renderCallback: RenderFrameCallback): Promise<Blob> {
    if (!this.gpuContext || !this.device) {
      throw new Error("Export engine not initialized. Call initialize() first.");
    }

    const { width, height, fps, durationSeconds, bitrate, onProgress } = this.config;
    const totalFrames = Math.floor(fps * durationSeconds);
    const frameInterval = 1 / fps;

    // 1. Configure the WebCodecs H.264 VideoEncoder
    let encodedChunks: EncodedVideoChunk[] = [];
    
    const encoder = new VideoEncoder({
      output: (chunk, metadata) => {
        // Collect encoded bitstream chunks (NAL units)
        encodedChunks.push(chunk);
      },
      error: (e) => {
        console.error("WebCodecs Encoder Error:", e);
        throw e;
      },
    });

    encoder.configure({
      codec: 'avc1.640034', // H.264 High Profile Level 5.2
      width,
      height,
      bitrate,
      framerate: fps,
      latencyMode: 'quality',
    });

    // 2. Main Deterministic Offscreen Render Loop
    for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
      const currentTime = frameIndex * frameInterval;

      // Execute the generative node graph for the target deterministic timestamp
      await renderCallback(currentTime, this.offscreenCanvas, this.gpuContext);

      // Create a snapshot frame bitmap directly from the OffscreenCanvas
      const frameBitmap = await createImageBitmap(this.offscreenCanvas);

      // Calculate presentation timestamp (PTS) in microseconds
      const timestampMicroseconds = Math.round(currentTime * 1_000_000);
      const durationMicroseconds = Math.round(frameInterval * 1_000_000);

      // Pass the frame into the hardware-accelerated encoder
      const videoFrame = new VideoFrame(frameBitmap, {
        timestamp: timestampMicroseconds,
        duration: durationMicroseconds,
      });

      // Keyframe insertion strategy: Every 2 seconds (e.g., frameIndex % (fps * 2) === 0)
      const isKeyFrame = frameIndex % (fps * 2) === 0;
      encoder.encode(videoFrame, { keyFrame: isKeyFrame });

      // Close frame handles to free memory immediately
      videoFrame.close();
      frameBitmap.close();

      // Report progress back to the SaaS UI thread
      if (onProgress) {
        onProgress((frameIndex + 1) / totalFrames);
      }
    }

    // Flush remaining frames from the hardware encoder queue
    await encoder.flush();
    encoder.close();

    // 3. Package encoded bitstreams into an MP4 container (Using WASM/ArrayBuffer serialization)
    const mp4Blob = await this.muxChunksToMP4Container(encodedChunks);
    return mp4Blob;
  }

  /**
   * Helper function to multiplex raw NAL chunks into an MP4 container.
   * In production, this proxies data to an enterprise WASM implementation of MP4Box.
   */
  private async muxChunksToMP4Container(chunks: EncodedVideoChunk[]): Promise<Blob> {
    // Conceptual serialization: combining raw chunks into a unified ArrayBuffer container
    const totalLength = chunks.reduce((acc, chunk) => acc + chunk.byteLength, 0);
    const combinedBuffer = new Uint8Array(totalLength);
    let offset = 0;

    for (const chunk of chunks) {
      const buffer = new Uint8Array(chunk.byteLength);
      chunk.copyTo(buffer);
      combinedBuffer.set(buffer, offset);
      offset += chunk.byteLength;
    }

    // Return final file stream blob ready for cloud upload or local SaaS download
    return new Blob([combinedBuffer], { type: 'video/mp4' });
  }
}
