/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export class GPUVideoExportPipeline {
  private device: GPUDevice;
  private context: GPUCanvasContext;
  private encoder: VideoEncoder;
  private isEncoding: boolean = false;
  private queueSizeThreshold: number;

  constructor(
    device: GPUDevice,
    context: GPUCanvasContext,
    width: number,
    height: number,
    bitrate: number = 5_000_000,
    framerate: number = 60,
    queueSizeThreshold: number = 5
  ) {
    this.device = device;
    this.context = context;
    this.queueSizeThreshold = queueSizeThreshold;

    this.encoder = new VideoEncoder({
      output: (chunk, metadata) => {
        // Handle encoded chunks (e.g., push to an MP4 muxer)
      },
      error: (e) => {
        console.error('VideoEncoder error:', e);
      }
    });

    this.encoder.configure({
      codec: 'avc1.42001e',
      width,
      height,
      bitrate,
      framerate,
      hardwareAcceleration: 'prefer-hardware'
    });
  }

  public async captureFrame(timestamp: number): Promise<void> {
    if (this.encoder.encodeQueueSize > this.queueSizeThreshold) {
      console.warn(`Dropping frame due to backpressure. Queue size: ${this.encoder.encodeQueueSize}`);
      return;
    }

    const texture = this.context.getCurrentTexture();
    const frame = new VideoFrame(texture, {
      timestamp,
      alpha: 'discard'
    });

    this.encoder.encode(frame, { keyFrame: timestamp % 2000000 === 0 });
    frame.close();
  }

  public async finalize(): Promise<void> {
    await this.encoder.flush();
    this.encoder.close();
  }
}

import { VideoEncoderConfig } from './types';

export function evaluateEncoderBackpressure(
  encoder: VideoEncoder,
  currentConfig: VideoEncoderConfig,
  queueSizeThreshold: number = 5
): VideoEncoderConfig {
  if (encoder.encodeQueueSize > queueSizeThreshold) {
    // Dynamically reduce bitrate by 15% to alleviate backpressure
    const adjustedBitrate = Math.max(
      Math.floor(currentConfig.bitrate * 0.85),
      500_000
    );
    return {
      ...currentConfig,
      bitrate: adjustedBitrate
    };
  }
  return currentConfig;
}
