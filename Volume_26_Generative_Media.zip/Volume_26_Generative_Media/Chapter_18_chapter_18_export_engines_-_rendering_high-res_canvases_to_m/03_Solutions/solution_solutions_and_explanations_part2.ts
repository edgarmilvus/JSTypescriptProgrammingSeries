/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type NodeType = 'path' | 'circle' | 'rect' | 'text';

export interface BaseNode {
  id: string;
  type: NodeType;
  x: number;
  y: number;
  rotation?: number;
  scale?: number;
  strokeColor?: string;
  fillColor?: string;
}

export interface PathNode extends BaseNode {
  type: 'path';
  pathData: string;
}

export interface CircleNode extends BaseNode {
  type: 'circle';
  radius: number;
}

export type VectorNode = PathNode | CircleNode;

export function serializeNodeGraphToSVG(rootNode: VectorNode, precision: number = 3): string {
  const round = (val: number) => Number(val.toFixed(precision));

  function processNode(node: VectorNode): string {
    const x = round(node.x);
    const y = round(node.y);
    const rot = node.rotation ? round(node.rotation) : 0;
    const scale = node.scale ? round(node.scale) : 1;

    const transform = `translate(${x}, ${y}) rotate(${rot}) scale(${scale})`;
    const stroke = node.strokeColor ? `stroke="${node.strokeColor}"` : '';
    const fill = node.fillColor ? `fill="${node.fillColor}"` : 'fill="none"';

    let innerContent = '';
    if (node.type === 'path') {
      innerContent = `<path d="${(node as PathNode).pathData}" ${stroke} ${fill} />`;
    } else if (node.type === 'circle') {
      const r = round((node as CircleNode).radius);
      innerContent = `<circle cx="0" cy="0" r="${r}" ${stroke} ${fill} />`;
    }

    return `<g transform="${transform}">${innerContent}</g>`;
  }

  const svgBody = processNode(rootNode);
  return `<svg xmlns="http://www.w3.org/2000/svg" version="1.1">${svgBody}</svg>`;
}

export function optimizeSVGPathData(pathData: string): string {
  // Regex to match consecutive horizontal or vertical line commands and simplify paths
  return pathData.replace(/([vVhH])\s*([-\d.]+)\s+\1\s*([-\d.]+)/g, (match, cmd, val1, val2) => {
    const combined = parseFloat(val1) + parseFloat(val2);
    return `${cmd} ${combined}`;
  });
}
