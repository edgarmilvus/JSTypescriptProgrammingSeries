/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { createClient, RedisClientType } from 'redis';

/**
 * Interface representing an incoming media generation request.
 */
interface MediaGenerationRequest {
    userId: string;
    prompt: string;
    resolution: '1024x1024' | '2048x2048';
}

/**
 * Interface representing the result of a media generation pipeline execution.
 */
interface MediaGenerationResult {
    success: boolean;
    assetUrl?: string;
    error?: string;
    processingTimeMs: number;
}

/**
 * Token Bucket Rate Limiter for SaaS API Endpoints.
 * Implements an atomic Redis Lua script to track and replenish user tokens.
 */
class RedisTokenBucketRateLimiter {
    private client: RedisClientType;
    private maxTokens: number;
    private refillRatePerSecond: number;

    /**
     * @gIVEN Redis client connection, maximum token capacity, and refill rate.
     */
    constructor(client: RedisClientType, maxTokens: number = 5, refillRatePerSecond: number = 0.5) {
        this.client = client;
        this.maxTokens = maxTokens;
        this.refillRatePerSecond = refillRatePerSecond;
    }

    /**
     * Checks if a user has sufficient tokens to execute a request.
     * Deducts a token atomically if available.
     * 
     * @param userId - The unique identifier of the SaaS tenant/user.
     * @returns Promise<boolean> - True if request is allowed, false if rate-limited.
     */
    public async consumeToken(userId: string): Promise<boolean> {
        const key = `ratelimit:${userId}`;
        const now = Date.now();

        // Lua script to ensure atomicity of read, update, and write operations in Redis.
        const luaScript = `
            local key = KEYS[1]
            local maxTokens = tonumber(ARGV[1])
            local refillRate = tonumber(ARGV[2])
            local now = tonumber(ARGV[3])

            local bucket = redis.call('HMGET', key, 'tokens', 'lastRefill')
            local tokens = tonumber(bucket[1])
            local lastRefill = tonumber(bucket[2])

            if tokens == nil then
                tokens = maxTokens
                lastRefill = now
            else
                local delta = math.max(0, (now - lastRefill) / 1000)
                tokens = math.min(maxTokens, tokens + (delta * refillRate))
                lastRefill = now
            end

            if tokens < 1 then
                redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', lastRefill)
                return 0
            else
                tokens = tokens - 1
                redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', lastRefill)
                return 1
            end
        `;

        try {
            const result = await this.client.eval(luaScript, {
                keys: [key],
                arguments: [
                    this.maxTokens.toString(),
                    this.refillRatePerSecond.toString(),
                    now.toString()
                ]
            });
            return result === 1;
        } catch (error) {
            // Fail-open or fail-closed policy: In production, decide whether to block 
            // traffic if Redis goes down. Here we fail-open for availability.
            console.error('Redis Rate Limiter Error:', error);
            return true;
        }
    }
}

/**
 * Concurrency Queue Manager for Heavy WebGPU/AI Tasks.
 * Limits the number of concurrent executions to protect server resources.
 */
class MediaConcurrencyQueue {
    private maxConcurrency: number;
    private currentRunning: number = 0;
    private queue: Array<{
        task: () => Promise<MediaGenerationResult>;
        resolve: (value: MediaGenerationResult) => void;
        reject: (reason?: any) => void;
    }> = [];

    /**
     * @param maxConcurrency - Maximum number of simultaneous heavy media jobs allowed.
     */
    constructor(maxConcurrency: number = 2) {
        this.maxConcurrency = maxConcurrency;
    }

    /**
     * Enqueues a heavy generation task.
     * 
     * @param task - Async function executing the media generation pipeline.
     * @returns Promise<MediaGenerationResult>
     */
    public enqueue(task: () => Promise<MediaGenerationResult>): Promise<MediaGenerationResult> {
        return new Promise((resolve, reject) => {
            this.queue.push({ task, resolve, reject });
            this.processNext();
        });
    }

    /**
     * Internal processor that dequeues and executes tasks up to the concurrency limit.
     */
    private async processNext(): Promise<void> {
        if (this.currentRunning >= this.maxConcurrency || this.queue.length === 0) {
            return;
        }

        this.currentRunning++;
        const item = this.queue.shift();

        if (!item) {
            this.currentRunning--;
            return;
        }

        try {
            const result = await item.task();
            item.resolve(result);
        } catch (error) {
            item.reject(error);
        } finally {
            this.currentRunning--;
            this.processNext();
        }
    }
}

/**
 * SaaS Generative Media Controller Orchestrator.
 * Ties together authentication, rate limiting, and concurrency control.
 */
class GenerativeMediaService {
    private rateLimiter: RedisTokenBucketRateLimiter;
    private concurrencyQueue: MediaConcurrencyQueue;

    constructor(redisClient: RedisClientType) {
        this.rateLimiter = new RedisTokenBucketRateLimiter(redisClient, 5, 0.2); // 5 max tokens, refills 1 token every 5s
        this.concurrencyQueue = new MediaConcurrencyQueue(2); // Max 2 simultaneous GPU tasks
    }

    /**
     * Main entry point for processing a client media generation request.
     * 
     * @param req - The incoming media generation request payload.
     * @returns Promise<MediaGenerationResult>
     */
    public async handleRequest(req: MediaGenerationRequest): Promise<MediaGenerationResult> {
        const startTime = Date.now();

        // Step 1: Check Token Bucket Rate Limit
        const allowed = await this.rateLimiter.consumeToken(req.userId);
        if (!allowed) {
            return {
                success: false,
                error: 'Rate limit exceeded. Please wait for your token bucket to refill.',
                processingTimeMs: Date.now() - startTime
            };
        }

        // Step 2: Enqueue into Concurrency Controller
        try {
            const result = await this.concurrencyQueue.enqueue(async () => {
                return await this.executeHeavyMediaPipeline(req);
            });
            return result;
        } catch (err: any) {
            return {
                success: false,
                error: `Pipeline execution failed: ${err.message}`,
                processingTimeMs: Date.now() - startTime
            };
        }
    }

    /**
     * Simulated heavy WebGPU / AI model execution pipeline.
     * 
     * @param req - The request payload.
     * @returns Promise<MediaGenerationResult>
     */
    private async executeHeavyMediaPipeline(req: MediaGenerationRequest): Promise<MediaGenerationResult> {
        const startTime = Date.now();
        console.log(`[GPU Worker] Starting generation for user ${req.userId} with prompt: "${req.prompt}"`);

        // Simulate heavy GPU computation (e.g., Stable Diffusion inference taking 3 seconds)
        await new Promise((resolve) => setTimeout(resolve, 3000));

        console.log(`[GPU Worker] Completed generation for user ${req.userId}`);
        return {
            success: true,
            assetUrl: `https://cdn.saasplatform.com/assets/${req.userId}/${Date.now()}.png`,
            processingTimeMs: Date.now() - startTime
        };
    }
}

// ==========================================
// Execution Simulation Example
// ==========================================
async function runSimulation() {
    // Initialize Redis Client (mocked for standalone script illustration; requires running redis server)
    const redisClient = createClient({ url: 'redis://localhost:6379' });
    
    // Handle error events to prevent unhandled promise rejections during simulation setup
    redisClient.on('error', (err) => console.error('Redis Client Error', err));

    try {
        await redisClient.connect();
        const mediaService = new GenerativeMediaService(redisClient);

        // Simulate 3 concurrent requests from the same user
        const requests: MediaGenerationRequest[] = [
            { userId: 'user_alpha_123', prompt: 'Cyberpunk Tokyo street at night, neon lights', resolution: '1024x1024' },
            { userId: 'user_alpha_123', prompt: 'Renaissance oil painting of a cat astronaut', resolution: '1024x1024' },
            { userId: 'user_alpha_123', prompt: 'Minimalist architectural villa by the ocean', resolution: '2048x2048' },
        ];

        console.log('Dispatching 3 requests simultaneously...');
        const promises = requests.map((req) => mediaService.handleRequest(req));
        const results = await Promise.all(promises);

        results.forEach((res, index) => {
            console.log(`Request ${index + 1} Result:`, res);
        });

    } catch (e) {
        console.error('Simulation encountered an error (ensure Redis is running):', e);
    } finally {
        await redisClient.quit();
    }
}

// Uncomment below to execute simulation if Redis is available locally
// runSimulation();
