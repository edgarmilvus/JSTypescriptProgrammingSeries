/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { Redis } from '@upstash/redis';
import { headers } from 'next/headers';
import { z } from 'zod';

// Initialize Redis client for distributed rate limiting and concurrency tracking
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

// Zod schema for validating incoming generative media requests
const GenerationRequestSchema = z.object({
  prompt: z.string().min(3).max(1000),
  width: z.number().int().min(256).max(2048),
  height: z.number().int().min(256).max(2048),
  steps: z.number().int().min(10).max(150),
  modelTier: z.enum(['standard', 'hd', 'ultra']),
});

type GenerationRequest = z.infer<typeof GenerationRequestSchema>;

interface GenerationResult {
  success: boolean;
  mediaUrl?: string;
  error?: string;
  retryAfterSeconds?: number;
}

/**
 * Calculates the compute cost (tokens) based on resolution, steps, and model tier.
 * Used for dynamic rate-limiting deduction.
 */
function calculateComputeCost(params: GenerationRequest): number {
  const pixelFactor = (params.width * params.height) / (512 * 512);
  const stepFactor = params.steps / 30;
  const tierMultiplier = params.modelTier === 'ultra' ? 3.0 : params.modelTier === 'hd' ? 1.5 : 1.0;
  
  return Math.ceil(10 * pixelFactor * stepFactor * tierMultiplier);
}

/**
 * Server Action: Secure Generative Media Pipeline Endpoint
 * Implements:
 * 1. Distributed Token-Bucket Rate Limiting
 * 2. Concurrency Queue Slot Management
 * 3. Abuse Prevention & Cost-Based Quotas
 */
export async function generateMediaAction(rawInput: unknown): Promise<GenerationResult> {
  const startTime = performance.now();
  
  // 1. Extract client identifiers for rate limiting (fallback to IP)
  const headersList = headers();
  const clientId = headersList.get('x-forwarded-for') || headersList.get('x-real-ip') || 'anonymous-client';
  const userTier = headersList.get('x-user-tier') || 'free'; // 'free', 'pro', 'enterprise'

  // 2. Validate input payload against structural schema
  const parseResult = GenerationRequestSchema.safeParse(rawInput);
  if (!parseResult.success) {
    return {
      success: false,
      error: `Invalid payload structure: ${parseResult.error.message}`,
    };
  }

  const data = parseResult.data;
  const computeCost = calculateComputeCost(data);

  // 3. Define Quota Limits per Tier
  const limits = {
    free: { maxTokens: 100, refillRatePerSec: 2 },
    pro: { maxTokens: 500, refillRatePerSec: 10 },
    enterprise: { maxTokens: 2000, refillRatePerSec: 50 },
  }[userTier] || { maxTokens: 100, refillRatePerSec: 2 };

  const bucketKey = `rate-limit:tokens:${clientId}`;
  const timestampKey = `rate-limit:ts:${clientId}`;
  const now = Date.now();

  try {
    // 4. Atomic Distributed Token-Bucket Algorithm via Redis Transaction (Pipeline)
    const pipeline = redis.pipeline();
    pipeline.get(bucketKey);
    pipeline.get(timestampKey);
    const [currentTokensStr, lastRefillStr] = await pipeline.exec() as [string | null, string | null];

    let currentTokens = currentTokensStr !== null ? parseFloat(currentTokensStr) : limits.maxTokens;
    let lastRefill = lastRefillStr !== null ? parseInt(lastRefillStr, 10) : now;

    // Calculate token replenishment based on elapsed time
    const elapsedSeconds = (now - lastRefill) / 1000;
    currentTokens = Math.min(limits.maxTokens, currentTokens + elapsedSeconds * limits.refillRatePerSec);

    // Check if client has sufficient tokens for this generative operation
    if (currentTokens < computeCost) {
      const deficit = computeCost - currentTokens;
      const retryAfterSeconds = Math.ceil(deficit / limits.refillRatePerSec);
      return {
        success: false,
        error: `Rate limit exceeded. Required compute tokens: ${computeCost}, available: ${Math.floor(currentTokens)}.`,
        retryAfterSeconds,
      };
    }

    // Deduct tokens and update timestamp
    currentTokens -= computeCost;
    await redis.set(bucketKey, currentTokens, { ex: 3600 });
    await redis.set(timestampKey, now, { ex: 3600 });

    // 5. Concurrency Control: Prevent GPU Overload and OOM crashes
    const concurrencyKey = 'gpu:active-jobs';
    const maxGlobalConcurrency = 4; // Max concurrent WebGPU / Inference tasks cluster-wide
    
    // Acquire concurrency lock slot
    const activeJobs = await redis.incr(concurrencyKey);
    if (activeJobs > maxGlobalConcurrency) {
      // Rollback concurrency counter immediately
      await redis.decr(concurrencyKey);
      return {
        success: false,
        error: 'GPU cluster saturation limit reached. Please retry shortly.',
        retryAfterSeconds: 5,
      };
    }

    // Set TTL on concurrency key in case of abrupt serverless termination
    await redis.expire(concurrencyKey, 120);

    try {
      // 6. Execute Generative Media Pipeline (Simulated WebGPU / AI Model Inference)
      console.log(`[Pipeline] Processing job for ${clientId}. Cost: ${computeCost}. Active jobs: ${activeJobs}`);
      
      // Simulate heavy async WebGPU tensor processing
      await new Promise((resolve) => setTimeout(resolve, 3500));

      const mediaUrl = `https://cdn.generative-media.io/output_${crypto.randomUUID()}.webp`;

      const executionTime = performance.now() - startTime;
      console.log(`[Pipeline] Completed successfully in ${executionTime.toFixed(2)}ms`);

      return {
        success: true,
        mediaUrl,
      };

    } finally {
      // 7. Ensure Concurrency Slot is Released Even on Errors
      await redis.decr(concurrencyKey);
    }

  } catch (err: unknown) {
    // Safely handle Redis or unexpected pipeline failures without leaking internals
    const errorMessage = err instanceof Error ? err.message : 'Unknown pipeline error';
    console.error(`[Security Error] Failed to process generation request for ${clientId}:`, errorMessage);
    
    return {
      success: false,
      error: 'An internal error occurred while processing your media request.',
    };
  }
}
