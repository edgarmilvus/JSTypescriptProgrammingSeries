/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';

export interface RateLimitResult {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
}

export class RedisTokenBucketLimiter {
  private client: Redis;
  private capacity: number;
  private refillRate: number;

  constructor(client: Redis, capacity: number, refillRate: number) {
    this.client = client;
    this.capacity = capacity;
    this.refillRate = refillRate;
  }

  /**
   * Lua script to atomically calculate refilled tokens and consume request cost.
   * KEYS[1]: Redis key for the user bucket (Hash storing 'tokens' and 'lastRefill')
   * ARGV[1]: Current system timestamp (seconds)
   * ARGV[2]: Token capacity limit
   * ARGV[3]: Refill rate per second
   * ARGV[4]: Cost of the current request
   */
  private static readonly LUA_SCRIPT = `
    local key = KEYS[1]
    local now = tonumber(ARGV[1])
    local capacity = tonumber(ARGV[2])
    local refillRate = tonumber(ARGV[3])
    local cost = tonumber(ARGV[4])

    local bucket = redis.call('HMGET', key, 'tokens', 'lastRefill')
    local tokens = tonumber(bucket[1])
    local lastRefill = tonumber(bucket[2])

    if tokens == nil then
        tokens = capacity
        lastRefill = now
    else
        local delta = math.max(0, now - lastRefill)
        tokens = math.min(capacity, tokens + (delta * refillRate))
        lastRefill = now
    end

    local allowed = 0
    if tokens >= cost then
        tokens = tokens - cost
        allowed = 1
    end

    redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', lastRefill)
    -- Set TTL on key to expire after full bucket recharge time
    local ttl = math.ceil((capacity / refillRate))
    redis.call('EXPIRE', key, ttl)

    return { allowed, tokens, lastRefill }
  `;

  public async consume(userId: string, cost: number): Promise<RateLimitResult> {
    const key = `ratelimit:user:${userId}`;
    const now = Date.now() / 1000;

    try {
      const result = (await this.client.eval(
        RedisTokenBucketLimiter.LUA_SCRIPT,
        1,
        key,
        now,
        this.capacity,
        this.refillRate,
        cost
      )) as [number, number, number];

      const allowed = result[0] === 1;
      const remaining = Math.floor(result[1]);
      
      // Calculate reset time based on missing tokens to full capacity
      const deficit = Math.max(0, this.capacity - remaining);
      const resetTime = Math.ceil(Date.now() + (deficit / this.refillRate) * 1000);

      return {
        allowed,
        limit: this.capacity,
        remaining,
        resetTime,
      };
    } catch (error) {
      // Fail-open policy depending on security configuration, or throw based on policy
      console.error('Redis rate limiter failure, failing open:', error);
      return {
        allowed: true,
        limit: this.capacity,
        remaining: this.capacity,
        resetTime: Date.now(),
      };
    }
  }
}
