/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type TaskPriority = 'low' | 'normal' | 'high' | 'critical';

export interface QueueItem<T> {
  id: string;
  priority: TaskPriority;
  weight: number;
  execute: (signal: AbortSignal) => Promise<T>;
  resolve: (value: T) => void;
  reject: (reason: any) => void;
  signal: AbortSignal;
}

const PRIORITY_WEIGHTS: Record<TaskPriority, number> = {
  critical: 4,
  high: 3,
  normal: 2,
  low: 1,
};

export class PriorityMediaQueue {
  private activeCount: number = 0;
  private queue: QueueItem<any>[] = [];
  
  constructor(private concurrency: number, private maxQueueSize: number) {}

  public async enqueue<T>(
    id: string,
    priority: TaskPriority,
    execute: (signal: AbortSignal) => Promise<T>,
    signal: AbortSignal
  ): Promise<T> {
    if (this.queue.length >= this.maxQueueSize) {
      throw new Error('503 Service Unavailable: Media generation queue is full.');
    }

    if (signal.aborted) {
      throw new Error('Task aborted before execution.');
    }

    return new Promise<T>((resolve, reject) => {
      const item: QueueItem<T> = {
        id,
        priority,
        weight: PRIORITY_WEIGHTS[priority],
        execute,
        resolve,
        reject,
        signal,
      };

      // Handle external cancellation while waiting in queue
      signal.addEventListener('abort', () => {
        const index = this.queue.findIndex((q) => q.id === id);
        if (index !== -1) {
          this.queue.splice(index, 1);
          reject(new Error('Task cancelled by client disconnection.'));
        }
      });

      this.insertSorted(item);
      this.dispatch();
    });
  }

  private insertSorted(item: QueueItem<any>): void {
    // Insert descending based on priority weight
    let inserted = false;
    for (let i = 0; i < this.queue.length; i++) {
      if (item.weight > this.queue[i].weight) {
        this.queue.splice(i, 0, item);
        inserted = true;
        break;
      }
    }
    if (!inserted) {
      this.queue.push(item);
    }
  }

  private dispatch(): void {
    while (this.activeCount < this.concurrency && this.queue.length > 0) {
      const nextTask = this.queue.shift();
      if (!nextTask) return;

      if (nextTask.signal.aborted) {
        continue;
      }

      this.activeCount++;
      
      nextTask.execute(nextTask.signal)
        .then((result) => {
          nextTask.resolve(result);
        })
        .catch((error) => {
          nextTask.reject(error);
        })
        .finally(() => {
          this.activeCount--;
          this.dispatch();
        });
    }
  }
}
