/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { createHmac } from 'crypto';

export interface StreamSecurityConfig {
  secretKey: string;
  maxDurationMs: number;
  maxBytesPerSecond: number;
}

export class SecureStreamValidator {
  constructor(private config: StreamSecurityConfig) {}

  /**
   * Threat Model Notes (Markdown Block):
   * 1. Slowloris Attacks: Attackers open connections and read data extremely slowly to keep threads busy. Mitigated by `maxBytesPerSecond` minimum thresholds and `maxDurationMs` hard caps.
   * 2. Scraper Botnets: Automated scripts trying to harvest generated AI media. Mitigated by short-lived HMAC signatures bound to userId and timestamp windows.
   * 3. Token-Stuffing: Replaying captured streaming authorization URLs. Mitigated by strict expiration checks (e.g., 60-second validity window).
   */
  public verifyStreamToken(token: string, userId: string, timestamp: number): boolean {
    const now = Date.now();
    // Token validity window: 60 seconds
    if (now - timestamp > 60000 || timestamp > now) {
      return false;
    }

    const payload = `${userId}:${timestamp}`;
    const expectedSignature = createHmac('sha256', this.config.secretKey)
      .update(payload)
      .digest('hex');

    return expectedSignature === token;
  }

  public monitorStreamThroughput(
    stream: ReadableStream,
    signal: AbortSignal
  ): ReadableStream {
    let bytesTransferred = 0;
    const startTime = Date.now();
    const maxDuration = this.config.maxDurationMs;
    const maxBps = this.config.maxBytesPerSecond;

    const transformStream = new TransformStream({
      transform(chunk: Uint8Array, controller) {
        if (signal.aborted) {
          controller.terminate();
          return;
        }

        const elapsedMs = Date.now() - startTime;
        if (elapsedMs > maxDuration) {
          controller.error(new Error('Stream exceeded maximum allowed duration limit.'));
          return;
        }

        bytesTransferred += chunk.length;
        const currentBps = bytesTransferred / (elapsedMs / 1000);

        if (currentBps > maxBps) {
          controller.error(new Error('Stream terminated: Byte-rate throughput limit exceeded.'));
          return;
        }

        controller.enqueue(chunk);
      },
    });

    return stream.pipeThrough(transformStream);
  }
}
