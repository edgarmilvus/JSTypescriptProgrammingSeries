/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface DashboardProps {
  endpointUrl: string;
  userToken: string;
  onGenerationComplete: (mediaUrl: string) => void;
}

export type GenerationState = 'idle' | 'queued' | 'streaming' | 'completed' | 'rate_limited';

export interface RateLimitState {
  limit: number;
  remaining: number;
  reset: number;
}

export interface QueueState {
  position: number;
  estimatedWaitSeconds: number;
}

export const MediaGenerationDashboard: React.FC<DashboardProps> = ({
  endpointUrl,
  userToken,
  onGenerationComplete,
}) => {
  const [generationState, setGenerationState] = useState<GenerationState>('idle');
  const [rateLimit, setRateLimit] = useState<RateLimitState>({ limit: 10, remaining: 10, reset: 0 });
  const [queueStatus, setQueueStatus] = useState<QueueState | null>(null);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    let eventSource: EventSource | null = null;

    if (generationState === 'queued' || generationState === 'streaming') {
      eventSource = new EventSource(`${endpointUrl}?token=${userToken}`);

      eventSource.addEventListener('queue_update', (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        setQueueStatus({
          position: data.position,
          estimatedWaitSeconds: data.estimatedWaitSeconds,
        });
      });

      eventSource.addEventListener('generation_start', () => {
        setGenerationState('streaming');
        setQueueStatus(null);
      });

      eventSource.addEventListener('media_chunk', (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        if (data.url) {
          setMediaUrl(data.url);
          setGenerationState('completed');
          onGenerationComplete(data.url);
        }
      });

      eventSource.onerror = () => {
        setErrorMessage('Connection error with media generation stream.');
        setGenerationState('idle');
        eventSource?.close();
      };
    }

    return () => {
      eventSource?.close();
    };
  }, [generationState, endpointUrl, userToken, onGenerationComplete]);

  return (
    <div className="p-6 max-w-2xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800">
      <h2 className="text-xl font-semibold mb-4">Generative Media Pipeline Console</h2>
      
      <div className="mb-6 p-4 bg-slate-800 rounded-lg flex justify-between items-center text-sm">
        <div>
          <span className="text-slate-400">Tokens Remaining:</span>{' '}
          <strong className="text-emerald-400">{rateLimit.remaining} / {rateLimit.limit}</strong>
        </div>
        <div>
          <span className="text-slate-400">Status:</span>{' '}
          <span className="uppercase text-xs font-bold px-2 py-1 bg-blue-900 text-blue-200 rounded">
            {generationState}
          </span>
        </div>
      </div>

      {errorMessage && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-700 text-red-200 rounded-lg text-sm">
          {errorMessage}
        </div>
      )}

      {generationState === 'idle' && (
        <button
          onClick={() => {
            setErrorMessage(null);
            setGenerationState('queued');
          }}
          className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 font-medium rounded-lg transition-colors"
        >
          Generate High-Resolution Asset
        </button>
      )}

      {generationState === 'queued' && queueStatus && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-500 mx-auto mb-4"></div>
          <p className="text-lg font-medium">Your request is queued...</p>
          <p className="text-sm text-slate-400 mt-1">Queue Position: #{queueStatus.position}</p>
          <p className="text-xs text-slate-500 mt-1">Estimated Wait: ~{queueStatus.estimatedWaitSeconds}s</p>
        </div>
      )}

      {generationState === 'streaming' && (
        <div className="text-center py-8">
          <div className="animate-pulse h-2 bg-indigo-600 rounded-full mb-4"></div>
          <p className="text-lg font-medium">Synthesizing Media Pipeline Output...</p>
        </div>
      )}

      {generationState === 'completed' && mediaUrl && (
        <div className="text-center py-4">
          <p className="text-emerald-400 font-medium mb-3">Generation Successful!</p>
          <img src={mediaUrl} alt="Generated Media" className="rounded-lg max-h-64 mx-auto mb-4 border border-slate-700" />
          <button
            onClick={() => setGenerationState('idle')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-sm rounded-lg"
          >
            Generate Another
          </button>
        </div>
      )}
    </div>
  );
};
