/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Full-Stack AI Creative Studio - Capstone Implementation
 * Integrates WebGPU client-side processing with a Node.js orchestrated 
 * cyclical graph pipeline using TypeScript.
 */

import React, { useEffect, useRef, useState, FC } from 'react';
import { z } from 'zod';

/**
 * ============================================================================
 * 1. SHARED TYPES & ZOD SCHEMAS (JSON Schema Output enforcement)
 * ============================================================================
 */

/**
 * Zod schema defining the strict output structure required from our LLM orchestration 
 * node when generating creative instructions for the WebGPU canvas pipeline.
 */
const CreativeInstructionSchema = z.object({
  action: z.enum(['INVERT', 'THRESHOLD', 'BLUR', 'PASSTHROUGH']),
  parameters: z.object({
    intensity: z.number().min(0).max(1),
    thresholdValue: z.number().min(0).max(255).optional(),
  }),
  reasoning: z.string().describe("Explanation for why this transformation was chosen in the loop"),
});

type CreativeInstruction = z.infer<typeof CreativeInstructionSchema>;

/**
 * Structure representing a node within our cyclical graph execution engine.
 */
interface PipelineNode {
  id: string;
  type: 'AI_PROMPT' | 'WEBGPU_FILTER' | 'EVALUATION';
  nextNodes: string[]; // Enables cyclical graph structures
  data: Record<string, any>;
}

/**
 * ============================================================================
 * 2. CLIENT-SIDE WEBGPU PROCESSOR
 * ============================================================================
 */

/**
 * Manages the WebGPU device context, pipelines, and buffer allocations 
 * for real-time pixel processing inside the browser.
 */
class WebGPUImageProcessor {
  private device!: GPUDevice;
  private pipeline!: GPUComputePipeline;
  private isInitialized: boolean = false;

  /**
   * Initializes the WebGPU adapter and logical device, compiling the compute shader.
   */
  public async initialize(): Promise<boolean> {
    if (typeof window === 'undefined' || !navigator.gpu) {
      console.warn("WebGPU not supported on this browser/environment.");
      return false;
    }

    try {
      const adapter = await navigator.gpu.requestAdapter();
      if (!adapter) throw new Error("No appropriate GPUAdapter found.");

      this.device = await adapter.requestDevice();

      // WGSL (WebGPU Shading Language) compute shader for image inversion/filtering
      const shaderModule = this.device.createShaderModule({
        code: `
          @group(0) @binding(0) var inputTex: texture_storage_2d<rgba8unorm, read>;
          @group(0) @binding(1) var outputTex: texture_storage_2d<rgba8unorm, write>;

          @compute @workgroup_size(16, 16)
          fn main(@builtin(global_invocation_id) id: vec3<u32>) {
            let dims = textureDimensions(inputTex);
            if (id.x >= dims.x || id.y >= dims.y) {
              return;
            }
            
            let coords = vec2<i32>(i32(id.x), i32(id.y));
            let color = textureLoad(inputTex, coords);
            
            // Simple inversion filter based on the creative pipeline instruction
            let invertedColor = vec4<f32>(1.0 - color.r, 1.0 - color.g, 1.0 - color.b, color.a);
            
            textureStore(outputTex, coords, invertedColor);
          }
        `,
      });

      this.pipeline = await this.device.createComputePipelineAsync({
        layout: 'auto',
        compute: {
          module: shaderModule,
          entryPoint: 'main',
        },
      });

      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error("Failed to initialize WebGPU processor:", error);
      return false;
    }
  }

  /**
   * Executes the compute shader pass over provided texture assets.
   */
  public async processFrame(inputTextureView: GPUTextureView, outputTextureView: GPUTextureView): Promise<void> {
    if (!this.isInitialized) throw new Error("WebGPU Processor not initialized.");

    const commandEncoder = this.device.createCommandEncoder();
    const passEncoder = commandEncoder.beginComputePass();

    const bindGroup = this.device.createBindGroup({
      layout: this.pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: inputTextureView },
        { binding: 1, resource: outputTextureView },
      ],
    });

    passEncoder.setPipeline(this.pipeline);
    passEncoder.setBindGroup(0, bindGroup);
    
    // Dispatch workgroups matching a 16x16 layout
    passEncoder.dispatchWorkgroups(Math.ceil(512 / 16), Math.ceil(512 / 16));
    passEncoder.end();

    this.device.queue.submit([commandEncoder.finish()]);
    await this.device.queue.onSubmittedWorkDone();
  }
}

/**
 * ============================================================================
 * 3. REACT CANVAS COMPONENT (Next.js Integration)
 * ============================================================================
 */

/**
 * A Next.js client component rendering the node-based canvas interface 
 * and orchestrating local WebGPU execution alongside WebSocket synchronization.
 */
export const AICreativeStudioCanvas: FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gpuStatus, setGpuStatus] = useState<string>('Initializing WebGPU...');
  const [loopActive, setLoopActive] = useState<boolean>(false);
  const [currentInstruction, setCurrentInstruction] = useState<CreativeInstruction | null>(null);
  
  const processorRef = useRef<WebGPUImageProcessor>(new WebGPUImageProcessor());
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function setup() {
      const success = await processorRef.current.initialize();
      if (!isMounted) return;
      
      if (success) {
        setGpuStatus('WebGPU Initialized Successfully (Warm Start Ready)');
      } else {
        setGpuStatus('WebGPU Fallback to CPU/WebGL Mode Active');
      }

      // Establish WebSocket connection to Node.js orchestration backend
      socketRef.current = new WebSocket('ws://localhost:8080/api/studio-stream');

      socketRef.current.onmessage = (event) => {
        try {
          const rawData = JSON.parse(event.data);
          // Validate incoming message matches our expected JSON Schema Output from LLM
          const parsedResult = CreativeInstructionSchema.safeParse(rawData);
          
          if (parsedResult.success) {
            setCurrentInstruction(parsedResult.data);
            console.log("Cyclic Graph Step Executed:", parsedResult.data.reasoning);
          } else {
            console.error("Schema validation failed for orchestration payload:", parsedResult.error);
          }
        } catch (err) {
          console.error("Failed to parse incoming WebSocket message:", err);
        }
      };
    }

    setup();

    return () => {
      isMounted = false;
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, []);

  /**
   * Triggers a cyclical refinement loop iteration.
   */
  const handleTriggerIteration = () => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      alert("WebSocket backend not connected.");
      return;
    }

    setLoopActive(true);
    // Send message to Node.js backend to evaluate current canvas state and run local AI model
    socketRef.current.send(JSON.stringify({
      event: 'TRIGGER_GRAPH_STEP',
      nodeId: 'node_eval_1',
      payload: { timestamp: Date.now() }
    }));
  };

  return (
    <div style={{ padding: '24px', fontFamily: 'sans-serif', background: '#111', color: '#fff', minHeight: '100vh' }}>
      <h1>AI Creative Studio: Node-Based Canvas</h1>
      <div style={{ marginBottom: '16px', padding: '12px', background: '#222', borderRadius: '8px' }}>
        <strong>GPU Pipeline Status:</strong> <span style={{ color: '#4ade80' }}>{gpuStatus}</span>
      </div>

      <div style={{ display: 'flex', gap: '24px' }}>
        <div>
          <canvas 
            ref={canvasRef} 
            width={512} 
            height={512} 
            style={{ border: '2px solid #444', borderRadius: '8px', background: '#000' }} 
          />
        </div>

        <div style={{ flex: 1, background: '#1e1e1e', padding: '16px', borderRadius: '8px' }}>
          <h3>Cyclical Graph Orchestrator</h3>
          <p>Current Iteration Loop Status: <strong>{loopActive ? 'Running' : 'Idle'}</strong></p>
          
          <button 
            onClick={handleTriggerIteration}
            style={{ padding: '10px 20px', background: '#6366f1', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
          >
            Trigger Graph Step (ReAct Loop)
          </button>

          {currentInstruction && (
            <div style={{ marginTop: '16px', padding: '12px', background: '#2a2a2a', borderRadius: '6px' }}>
              <h4>Latest JSON Schema Output:</h4>
              <pre style={{ fontSize: '12px', color: '#38bdf8' }}>
                {JSON.stringify(currentInstruction, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AICreativeStudioCanvas;
