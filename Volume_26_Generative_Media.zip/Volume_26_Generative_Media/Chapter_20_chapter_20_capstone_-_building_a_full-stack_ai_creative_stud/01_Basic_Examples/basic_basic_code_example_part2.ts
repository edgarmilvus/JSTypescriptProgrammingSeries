/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * 4. NODE.JS ORCHESTRATION BACKEND (Companion Service Stub)
 * ============================================================================
 */

import { WebSocketServer, WebSocket } from 'ws';

/**
 * Initializes a Node.js WebSocket server managing the cyclical graph execution 
 * and maintaining local AI model warm-start states.
 */
export function startOrchestrationServer(port: number = 8080) {
  const wss = new WebSocketServer({ port });

  // Simulate a warm-start local AI engine instance (weights loaded in memory)
  const warmStartModelInstance = {
    isLoaded: true,
    runInference: async (promptContext: string) => {
      // Return structured output that complies with our Zod schema
      return {
        action: 'INVERT',
        parameters: {
          intensity: 0.85,
          thresholdValue: 128
        },
        reasoning: 'Iterative refinement loop detected low contrast. Applying inversion filter.'
      };
    }
  };

  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to Node.js orchestration stream.');

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);

        if (data.event === 'TRIGGER_GRAPH_STEP') {
          // Leverage the warm-start model instance without reloading weights
          const result = await warmStartModelInstance.runInference(data.nodeId);
          
          // Send back the structured JSON response to the client
          ws.send(JSON.stringify(result));
        }
      } catch (err) {
        console.error('Error handling WebSocket message in orchestration loop:', err);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from orchestration stream.');
    });
  });

  console.log(`Node.js AI Orchestration Server running on ws://localhost:${port}`);
}
