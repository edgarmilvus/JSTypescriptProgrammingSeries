/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export async function initializeWebGPUComputePipeline(
  inputTexture: GPUTexture,
  outputTexture: GPUTexture,
  filterIntensity: number
): Promise<{ device: GPUDevice; execute: () => void }> {
  // 1. Request Adapter and Device
  const adapter = await navigator.gpu?.requestAdapter();
  if (!adapter) throw new Error("No appropriate GPUAdapter found.");
  
  const device = await adapter.requestDevice();

  // 2. Define WGSL Compute Shader Module
  const computeShaderCode = `
    @group(0) @binding(0) var inputTex: texture_2d<f32>;
    @group(0) @binding(1) var outputTex: image_storage_2d<rgba8unorm, write>;
    
    struct Uniforms {
      intensity: f32,
    };
    @group(0) @binding(2) var<uniform> uniforms: Uniforms;

    @compute @workgroup_size(16, 16)
    fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
      let dims = textureDimensions(inputTex);
      let coord = vec2<i32>(i32(global_id.x), i32(global_id.y));

      if (coord.x >= dims.x || coord.y >= dims.y) {
        return;
      }

      let color = textureLoad(inputTex, coord, 0);
      // Simple custom filter adjustment (e.g., exposure / contrast scaling)
      let adjustedColor = vec4<f32>(color.rgb * uniforms.intensity, color.a);
      
      textureStore(outputTex, coord, adjustedColor);
    }
  `;

  const shaderModule = device.createShaderModule({
    code: computeShaderCode,
  });

  // 3. Create Uniform Buffer for dynamic parameters
  const uniformBuffer = device.createBuffer({
    size: 4, // 1 float32
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
  });

  // Update uniform buffer data
  device.queue.writeBuffer(uniformBuffer, 0, new Float32Array([filterIntensity]));

  // 4. Create Pipeline Layout and Bind Group Layout
  const bindGroupLayout = device.createBindGroupLayout({
    entries: [
      { binding: 0, visibility: GPUShaderStage.COMPUTE, texture: { sampleType: "float" } },
      { binding: 1, visibility: GPUShaderStage.COMPUTE, storageTexture: { access: "write-only", format: "rgba8unorm" } },
      { binding: 2, visibility: GPUShaderStage.COMPUTE, buffer: { type: "uniform" } },
    ],
  });

  const pipelineLayout = device.createPipelineLayout({
    bindGroupLayouts: [bindGroupLayout],
  });

  const computePipeline = device.createComputePipeline({
    layout: pipelineLayout,
    compute: {
      module: shaderModule,
      entryPoint: "main",
    },
  });

  // 5. Create Bind Group binding resources
  const bindGroup = device.createBindGroup({
    layout: bindGroupLayout,
    entries: [
      { binding: 0, resource: inputTexture.createView() },
      { binding: 1, resource: outputTexture.createView() },
      { binding: 2, resource: { buffer: uniformBuffer } },
    ],
  });

  // 6. Execution Command Encoder function
  const execute = () => {
    const commandEncoder = device.createCommandEncoder();
    const passEncoder = commandEncoder.beginComputePass();
    
    passEncoder.setPipeline(computePipeline);
    passEncoder.setBindGroup(0, bindGroup);

    // Calculate workgroup dispatches based on a 16x16 local workgroup block size
    const workgroupCountX = Math.ceil(inputTexture.width / 16);
    const workgroupCountY = Math.ceil(inputTexture.height / 16);
    
    passEncoder.dispatchWorkgroups(workgroupCountX, workgroupCountY);
    passEncoder.end();

    device.queue.submit([commandEncoder.finish()]);
  };

  return { device, execute };
}
