/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useCallback } from "react";

export interface NodeItem {
  id: string;
  x: number;
  y: number;
  title: string;
}

export interface Connection {
  fromNodeId: string;
  toNodeId: string;
}

interface AIWorkflowCanvasProps {
  initialNodes: NodeItem[];
  initialConnections: Connection[];
}

export const AIWorkflowCanvas: React.FC<AIWorkflowCanvasProps> = ({
  initialNodes,
  initialConnections,
}) => {
  const [nodes, setNodes] = useState<NodeItem[]>(initialNodes);
  const [connections] = useState<Connection[]>(initialConnections);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const dragOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const handlePointerDown = useCallback((node: NodeItem, e: React.PointerEvent) => {
    e.stopPropagation();
    setDraggingNodeId(node.id);
    dragOffsetRef.current = {
      x: e.clientX - node.x,
      y: e.clientY - node.y,
    };
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!draggingNodeId) return;

    const newX = e.clientX - dragOffsetRef.current.x;
    const newY = e.clientY - dragOffsetRef.current.y;

    setNodes((prevNodes) =>
      prevNodes.map((n) => (n.id === draggingNodeId ? { ...n, x: newX, y: newY } : n))
    );
  }, [draggingNodeId]);

  const handlePointerUp = useCallback(() => {
    setDraggingNodeId(null);
  }, []);

  return (
    <div
      className="relative w-full h-screen bg-slate-950 overflow-hidden select-none"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Connection Layer (SVG Curves) */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        {connections.map((conn, idx) => {
          const fromNode = nodes.find((n) => n.id === conn.fromNodeId);
          const toNode = nodes.find((n) => n.id === conn.toNodeId);
          if (!fromNode || !toNode) return null;

          const startX = fromNode.x + 150; // assuming node width 150
          const startY = fromNode.y + 40;
          const endX = toNode.x;
          const endY = toNode.y + 40;
          const pathString = `M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`;

          return (
            <path
              key={idx}
              d={pathString}
              stroke="#3b82f6"
              strokeWidth="2"
              fill="none"
            />
          );
        })}
      </svg>

      {/* Node Render Layer */}
      {nodes.map((node) => (
        <div
          key={node.id}
          onPointerDown={(e) => handlePointerDown(node, e)}
          style={{ transform: `translate(${node.x}px, ${node.y}px)` }}
          className="absolute w-40 h-24 bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-xl cursor-grab active:cursor-grabbing text-white flex flex-col justify-between"
        >
          <div className="font-semibold text-sm border-b border-slate-800 pb-1">
            {node.title}
          </div>
          <div className="text-xs text-slate-400">ID: {node.id}</div>
        </div>
      ))}
    </div>
  );
};
