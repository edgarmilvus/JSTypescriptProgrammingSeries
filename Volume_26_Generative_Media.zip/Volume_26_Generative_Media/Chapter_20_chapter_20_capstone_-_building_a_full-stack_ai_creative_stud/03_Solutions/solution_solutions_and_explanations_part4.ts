/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export class EmbeddingPipelineManager {
  private apiKey: string;
  private vectorStore: { id: string; vector: number[]; metadata: any }[] = [];

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  // 1. Text Chunking Utility
  public chunkText(text: string, maxChunkLength: number = 500): string[] {
    const words = text.split(/\s+/);
    const chunks: string[] = [];
    let currentChunk: string[] = [];

    for (const word of words) {
      currentChunk.push(word);
      if (currentChunk.join(" ").length >= maxChunkLength) {
        chunks.push(currentChunk.join(" "));
        currentChunk = [];
      }
    }

    if (currentChunk.length > 0) {
      chunks.push(currentChunk.join(" "));
    }

    return chunks;
  }

  // 2. Asynchronous Embedding Generator
  public async generateEmbedding(text: string): Promise<number[]> {
    // Simulated remote embedding API call
    return new Promise((resolve) => {
      setTimeout(() => {
        // Return a mock 128-dimensional embedding vector
        const mockVector = Array.from({ length: 128 }, () => Math.random());
        resolve(mockVector);
      }, 50);
    });
  }

  // 3. Vector Index Insertion
  public async addDocument(id: string, text: string, metadata: any): Promise<void> {
    const vector = await this.generateEmbedding(text);
    this.vectorStore.push({ id, vector, metadata });
  }

  // 4. Cosine Similarity Search
  public async search(queryText: string, topK: number = 3): Promise<any[]> {
    const queryVector = await this.generateEmbedding(queryText);

    const scoredResults = this.vectorStore.map((item) => {
      const score = this.cosineSimilarity(queryVector, item.vector);
      return { id: item.id, metadata: item.metadata, score };
    });

    scoredResults.sort((a, b) => b.score - a.score);
    return scoredResults.slice(0, topK);
  }

  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }
}
