/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { WebSocket } from "ws";

export type OperationType = "NODE_ADDED" | "NODE_MOVED" | "NODE_DELETED" | "CONNECTION_CREATED";

export interface SyncMessage {
  type: OperationType;
  timestamp: number;
  clientId: string;
  payload: any;
}

export class WebSocketSyncClient {
  private ws: WebSocket | null = null;
  private clientId: string;
  private url: string;
  private listeners: Map<OperationType, ((payload: any) => void)[]> = new Map();

  constructor(url: string) {
    this.url = url;
    this.clientId = Math.random().toString(36.substring(2, 9));
  }

  public connect(): void {
    this.ws = new WebSocket(this.url);

    this.ws.on("open", () => {
      console.log(`[SyncClient] Connected with ID: ${this.clientId}`);
    });

    this.ws.on("message", (data: string) => {
      const message: SyncMessage = JSON.parse(data);
      // Ignore messages sent by self
      if (message.clientId === this.clientId) return;

      const callbacks = this.listeners.get(message.type);
      if (callbacks) {
        callbacks.forEach((cb) => cb(message.payload));
      }
    });

    this.ws.on("close", () => {
      console.log("[SyncClient] Connection closed. Attempting reconnect...");
      setTimeout(() => this.connect(), 3000);
    });
  }

  public dispatch(type: OperationType, payload: any): void {
    const message: SyncMessage = {
      type,
      timestamp: Date.now(),
      clientId: this.clientId,
      payload,
    };

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      console.warn("[SyncClient] Cannot dispatch; socket is closed.");
    }
  }

  public on(type: OperationType, callback: (payload: any) => void): void {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, []);
    }
    this.listeners.get(type)!.push(callbacks => callbacks); // simplified registration
  }
}
