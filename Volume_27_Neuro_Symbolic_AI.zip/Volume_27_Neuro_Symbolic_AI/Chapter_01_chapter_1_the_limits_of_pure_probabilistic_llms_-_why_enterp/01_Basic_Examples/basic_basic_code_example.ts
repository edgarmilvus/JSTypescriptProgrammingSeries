/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from "zod";

/**
 * @file user-validator.ts
 * @description A self-contained SaaS micro-utility demonstrating how to constrain 
 * a probabilistic LLM JSON response using a deterministic Zod schema to prevent hallucinations.
 */

// 1. Define the deterministic symbolic schema using Zod
// This acts as our enterprise contract. Any violation will fail hard.
const EnterpriseUserProfileSchema = z.object({
  id: z.string().uuid({ message: "Must be a valid UUIDv4" }),
  email: z.string().email({ message: "Must be a valid corporate email address" }),
  clearanceLevel: z.enum(["RESTRICTED", "CONFIDENTIAL", "PUBLIC"], {
    errorMap: () => ({ message: "Clearance level must strictly match enterprise taxonomy" }),
  }),
  activeSubscriptionsCount: z.number().int().nonnegative(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

// Infer the TypeScript type directly from the runtime schema
type EnterpriseUserProfile = z.infer<typeof EnterpriseUserProfileSchema>;

/**
 * Simulates an unstructured or malformed response coming from a probabilistic LLM.
 * In a real SaaS application, this payload would be returned from an OpenAI or Anthropic completion call.
 */
const mockRawLLMResponse = JSON.stringify({
  id: "123e4567-e89b-12d3-a456-426614174000",
  email: "sarah.connor@cyberdyne-enterprise.io",
  clearanceLevel: "CONFIDENTIAL",
  activeSubscriptionsCount: 3,
  metadata: {
    department: "Neural Net Research",
  },
});

/**
 * Parses and validates raw LLM JSON strings against the deterministic schema.
 * 
 * @param rawJsonString - The raw string output from the LLM completion API.
 * @returns The strongly-typed, validated enterprise user profile.
 * @throws Error if the LLM output violates the structural or semantic rules.
 */
function parseAndValidateLLMOutput(rawJsonString: string): EnterpriseUserProfile {
  let parsedJson: unknown;

  // Step A: Safely parse the raw string into an unknown JavaScript object
  try {
    parsedJson = JSON.parse(rawJsonString);
  } catch (error) {
    throw new Error(`[Deterministic Bridge] Critical: LLM output was not valid JSON. Error: ${(error as Error).message}`);
  }

  // Step B: Apply deterministic symbolic validation via Zod
  const validationResult = EnterpriseUserProfileSchema.safeParse(parsedJson);

  if (!validationResult.success) {
    // Format the Zod errors into a readable string for logging or agentic feedback loops
    const errorMessages = validationResult.error.errors
      .map((err) => `Path: [${err.path.join(".")}] -> ${err.message}`)
      .join("; ");
    
    throw new Error(`[Deterministic Bridge] Hallucination/Schema Violation detected: ${errorMessages}`);
  }

  // Step C: Return the strictly typed, safe data payload
  return validationResult.data;
}

// --- Execution Example ---
try {
  console.log("Initializing Neuro-Symbolic validation pipeline...");
  const validatedProfile = parseAndValidateLLMOutput(mockRawLLMResponse);
  
  console.log("Validation Successful! Safe for downstream symbolic processing:");
  console.dir(validatedProfile, { depth: null, colors: true });

  // Downstream enterprise code can now safely interact with properties
  console.log(`Processing clearance for user: ${validatedProfile.email} with level ${validatedProfile.clearanceLevel}`);

} catch (error) {
  console.error((error as Error).message);
  // In an agentic ReAct loop, this error string would be fed back to the LLM as an observation 
  // instructing it to correct its JSON generation.
}
