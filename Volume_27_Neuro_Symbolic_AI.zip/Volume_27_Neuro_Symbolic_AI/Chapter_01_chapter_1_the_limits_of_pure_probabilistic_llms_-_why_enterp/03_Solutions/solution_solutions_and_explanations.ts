/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Define the deterministic schema for enterprise audit records
export const AuditRecordSchema = z.object({
  auditId: z.string().uuid({ message: "auditId must be a valid UUID" }),
  timestamp: z.string().datetime({ message: "timestamp must be a valid ISO 8601 date string" }),
  riskScore: z.number().min(0.0).max(1.0, { message: "riskScore must be bounded between 0.0 and 1.0" }),
  flaggedEntities: z.array(z.string()).nonempty({ message: "flaggedEntities cannot be empty" })
});

export type AuditRecord = z.infer<typeof AuditRecordSchema>;

export class SymbolicValidationError extends Error {
  constructor(message: string, public readonly validationErrors: z.ZodIssue[]) {
    super(message);
    this.name = 'SymbolicValidationError';
  }
}

/**
 * Executes a deterministic LLM query constrained by a JSON Schema Output.
 * @param prompt The input User Prompt representing the enterprise compliance query.
 * @returns A validated, type-safe AuditRecord object.
 */
export async function executeDeterministicAudit(prompt: string): Promise<AuditRecord> {
  // Simulated LLM client call configured for JSON schema enforcement
  // In production, this passes a JSON schema derived from AuditRecordSchema to the provider API
  const rawLLMResponse = await mockLLMClientCallWithSchema(prompt, AuditRecordSchema);

  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(rawLLMResponse);
  } catch (error) {
    throw new SymbolicValidationError("Failed to parse LLM output as valid JSON.", [
      {
        code: "custom",
        path: [],
        message: (error as Error).message,
      } as z.ZodIssue
    ]);
  }

  const validationResult = AuditRecordSchema.safeParse(parsedJson);

  if (!validationResult.success) {
    throw new SymbolicValidationError(
      "LLM output violated the deterministic enterprise audit schema.",
      validationResult.error.issues
    );
  }

  return validationResult.data;
}

// Mock helper representing an enterprise LLM client supporting structured decoding
async function mockLLMClientCallWithSchema(prompt: string, schema: z.ZodTypeAny): Promise<string> {
  // Real implementation interacts with OpenAI/Anthropic/Vertex structured outputs API
  return JSON.stringify({
    auditId: "123e4567-e89b-12d3-a456-426614174000",
    timestamp: "2023-10-25T14:30:00Z",
    riskScore: 0.85,
    flaggedEntities: ["Account-992", "Transaction-1042"]
  });
}
