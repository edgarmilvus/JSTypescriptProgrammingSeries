/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { BaseMessage, AIMessage, HumanMessage } from "@langchain/core/messages";

export interface AgentState {
  messages: BaseMessage[];
  currentThought?: string;
  toolCall?: {
    name: string;
    args: Record<string, any>;
  };
  observation?: string | null;
  isComplete: boolean;
}

// Stub for the Reasoning Node
export async function reasonNode(state: AgentState): Promise<Partial<AgentState>> {
  const history = state.messages;
  const latestPrompt = history[history.length - 1]?.content || "";

  // Simulated LLM reasoning call adhering to ReAct instructions
  // In production, invoke an LLM bound with tool definitions
  const mockDecision = {
    thought: "I need to look up the security clearance for the target entity in the Knowledge Graph.",
    toolCall: {
      name: "KnowledgeGraphLookup",
      args: { entityId: "Account-992" }
    },
    isComplete: false
  };

  return {
    currentThought: mockDecision.thought,
    toolCall: mockDecision.toolCall,
    isComplete: mockDecision.isComplete
  };
}

// Stub for the Action Node
export async function actionNode(state: AgentState): Promise<Partial<AgentState>> {
  if (!state.toolCall) {
    return { observation: "Error: No tool call specified by reasoning node." };
  }

  const { name, args } = state.toolCall;
  let observationResult = "";

  // Execute deterministic local tools based on tool name
  if (name === "KnowledgeGraphLookup") {
    observationResult = JSON.stringify({
      entityId: args.entityId,
      clearanceLevel: "TOP_SECRET",
      status: "VERIFIED"
    });
  } else {
    observationResult = `Error: Unknown tool '${name}'`;
  }

  return {
    observation: observationResult,
    messages: [
      ...state.messages,
      new AIMessage(`Thought: ${state.currentThought}\nAction: ${name}(${JSON.stringify(args)})`),
      new HumanMessage(`Observation: ${observationResult}`)
    ]
  };
}

// Conditional routing function to direct flow between nodes
export function routeAfterReasoning(state: AgentState): string {
  if (state.isComplete || !state.toolCall) {
    return "__end__";
  }
  return "actionNode";
}
