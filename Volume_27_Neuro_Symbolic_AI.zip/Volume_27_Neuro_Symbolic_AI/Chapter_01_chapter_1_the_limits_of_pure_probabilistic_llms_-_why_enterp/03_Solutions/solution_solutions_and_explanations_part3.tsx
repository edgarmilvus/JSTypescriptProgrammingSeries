/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface GraphNode {
  id: string;
  label: string;
  verified: boolean;
  metadata?: Record<string, unknown>;
}

export interface SymbolicGraphInspectorProps {
  userPrompt: string;
  llmResponse: string;
  knowledgeGraphNodes: GraphNode[];
}

export const SymbolicGraphInspector: React.FC<SymbolicGraphInspectorProps> = ({
  userPrompt,
  llmResponse,
  knowledgeGraphNodes,
}) => {
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(true);

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans">
      {/* Main Content Area: Prompt and LLM Response */}
      <div className="flex-1 p-6 flex flex-col gap-4 overflow-y-auto">
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">User Prompt</h3>
          <p className="mt-1 text-gray-100">{userPrompt}</p>
        </div>

        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex-1 shadow-sm flex flex-col">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">LLM Generated Response (Symbolically Anchored)</h3>
          <p className="mt-2 text-gray-100 whitespace-pre-wrap leading-relaxed">{llmResponse}</p>
        </div>
      </div>

      {/* Side Panel: Knowledge Graph Inspector Drawer */}
      <div className={`w-96 bg-gray-800 border-l border-gray-700 flex flex-col transition-all duration-300 ${isDrawerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
          <h2 className="font-bold text-lg text-gray-200">Symbolic Anchors</h2>
          <button 
            onClick={() => setIsDrawerOpen(!isDrawerOpen)}
            className="text-sm text-gray-400 hover:text-white px-2 py-1 rounded bg-gray-700/50 transition-colors"
            aria-expanded={isDrawerOpen}
            aria-label="Toggle Symbolic Anchors Drawer"
          >
            {isDrawerOpen ? 'Close' : 'Open'}
          </button>
        </div>

        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {knowledgeGraphNodes.map((node) => (
            <div
              key={node.id}
              onClick={() => setSelectedNode(node)}
              className={`p-3 rounded-md cursor-pointer border ${
                node.verified ? 'border-green-600/60 bg-green-950/20' : 'border-red-600/60 bg-red-950/20'
              } hover:border-gray-400 transition-all`}
            >
              <div className="flex justify-between items-center">
                <span className="font-medium text-sm text-gray-200">{node.label}</span>
                <span className={`text-xs px-2 py-0.5 rounded font-semibold ${node.verified ? 'bg-green-900/80 text-green-200' : 'bg-red-900/80 text-red-200'}`}>
                  {node.verified ? 'Verified' : 'Unverified'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Node Metadata Card */}
        {selectedNode && (
          <div className="p-4 border-t border-gray-700 bg-gray-900/90">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-semibold text-gray-400 uppercase">Node Details: {selectedNode.id}</h4>
              <button 
                onClick={() => setSelectedNode(null)} 
                className="text-xs text-gray-500 hover:text-gray-300"
              >
                Clear
              </button>
            </div>
            <pre className="mt-2 text-xs text-gray-300 overflow-x-auto bg-gray-950 p-2 rounded border border-gray-800">
              {JSON.stringify(selectedNode.metadata || {}, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
