/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface OntologyTriplet {
  subject: string;
  predicate: string;
  object: string;
}

// Enterprise Ontology Whitelist to prevent semantic injection or hallucinations
const ALLOWED_PREDICATES = new Set([
  'hasAccessLevel',
  'reportsTo',
  'managesProject',
  'belongsToDepartment',
  'hasSecurityClearance'
]);

export class OntologyViolationError extends Error {
  constructor(predicate: string) {
    super(`Semantic violation: Predicate '${predicate}' is not part of the certified enterprise ontology.`);
    this.name = 'OntologyViolationError';
  }
}

/**
 * Programmatically constructs a deterministic SPARQL query from validated ontology triplets.
 * @param triplets Array of subject-predicate-object semantic anchors extracted from the User Prompt.
 * @returns A fully formed, syntax-guaranteed SPARQL query string.
 */
export function generateSparqlQuery(triplets: OntologyTriplet[]): string {
  const PREFIXES = `
PREFIX ent: <http://enterprise.ontology/core#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
  `.trim();

  if (triplets.length === 0) {
    throw new Error("Cannot generate SPARQL query from an empty set of triplets.");
  }

  const whereClauses: string[] = [];

  for (const triplet of triplets) {
    if (!ALLOWED_PREDICATES.has(triplet.predicate)) {
      throw new OntologyViolationError(triplet.predicate);
    }

    // Sanitize and format variables or URIs safely
    const subj = triplet.subject.startsWith('?') ? triplet.subject : `<http://enterprise.ontology/instance/${triplet.subject}>`;
    const obj = triplet.object.startsWith('?') ? triplet.object : `<http://enterprise.ontology/instance/${triplet.object}>`;

    whereClauses.push(`  ${subj} ent:${triplet.predicate} ${obj} .`);
  }

  const query = `
${PREFIXES}

SELECT ?s ?o
WHERE {
${whereClauses.join('\n')}
}
  `.trim();

  return query;
}
