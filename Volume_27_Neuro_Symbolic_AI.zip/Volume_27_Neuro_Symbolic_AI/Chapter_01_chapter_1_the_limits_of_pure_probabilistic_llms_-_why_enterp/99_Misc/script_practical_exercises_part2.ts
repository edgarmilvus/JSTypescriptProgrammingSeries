/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { BaseMessage } from "@langchain/core/messages";

export interface AgentState {
  messages: BaseMessage[];
  currentThought?: string;
  toolCall?: {
    name: string;
    args: Record<string, any>;
  };
  observation?: string | null;
  isComplete: boolean;
}

// Stub for the Reasoning Node
export async function reasonNode(state: AgentState): Promise<Partial<AgentState>> {
  // TODO: Extract the latest User Prompt and message history.
  // TODO: Invoke the LLM with system instructions enforcing the ReAct format (Thought -> Action -> Observation).
  // TODO: Parse the model output to update currentThought and determine if a toolCall is required.
  throw new Error("reasonNode implementation missing");
}

// Stub for the Action Node
export async function actionNode(state: AgentState): Promise<Partial<AgentState>> {
  // TODO: Extract state.toolCall and execute the corresponding deterministic local tool (e.g., Knowledge Graph lookup).
  // TODO: Wrap the output in an observation string and return updated state.
  throw new Error("actionNode implementation missing");
}

// TODO: Write the conditional routing function to direct flow between reasonNode, actionNode, and END.
