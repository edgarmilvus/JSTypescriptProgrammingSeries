/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';

export interface GraphNode {
  id: string;
  label: string;
  verified: boolean;
  metadata?: Record<string, unknown>;
}

export interface SymbolicGraphInspectorProps {
  userPrompt: string;
  llmResponse: string;
  knowledgeGraphNodes: GraphNode[];
}

export const SymbolicGraphInspector: React.FC<SymbolicGraphInspectorProps> = ({
  userPrompt,
  llmResponse,
  knowledgeGraphNodes,
}) => {
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(true);

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans">
      {/* Main Content Area: Prompt and LLM Response */}
      <div className="flex-1 p-6 flex flex-col gap-4 overflow-y-auto">
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
          <h3 className="text-sm font-semibold text-gray-400">User Prompt</h3>
          <p className="mt-1 text-gray-100">{userPrompt}</p>
        </div>

        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex-1">
          <h3 className="text-sm font-semibold text-gray-400">LLM Generated Response (Symbolically Anchored)</h3>
          <p className="mt-1 text-gray-100 whitespace-pre-wrap">{llmResponse}</p>
        </div>
      </div>

      {/* Side Panel: Knowledge Graph Inspector Drawer */}
      <div className={`w-96 bg-gray-800 border-l border-gray-700 flex flex-col transition-all duration-300 ${isDrawerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
          <h2 className="font-bold text-lg">Symbolic Anchors</h2>
          <button 
            onClick={() => setIsDrawerOpen(!isDrawerOpen)}
            className="text-gray-400 hover:text-white"
            aria-expanded={isDrawerOpen}
          >
            {isDrawerOpen ? 'Close' : 'Open'}
          </button>
        </div>

        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {knowledgeGraphNodes.map((node) => (
            <div
              key={node.id}
              onClick={() => setSelectedNode(node)}
              className={`p-3 rounded-md cursor-pointer border ${
                node.verified ? 'border-green-600 bg-green-950/30' : 'border-red-600 bg-red-950/30'
              } hover:opacity-80 transition-opacity`}
            >
              <div className="flex justify-between items-center">
                <span className="font-medium">{node.label}</span>
                <span className={`text-xs px-2 py-0.5 rounded ${node.verified ? 'bg-green-800 text-green-200' : 'bg-red-800 text-red-200'}`}>
                  {node.verified ? 'Verified' : 'Unverified'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Node Metadata Card */}
        {selectedNode && (
          <div className="p-4 border-t border-gray-700 bg-gray-900">
            <h4 className="text-xs font-semibold text-gray-400 uppercase">Node Details: {selectedNode.id}</h4>
            <pre className="mt-2 text-xs text-gray-300 overflow-x-auto">
              {JSON.stringify(selectedNode.metadata || {}, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
