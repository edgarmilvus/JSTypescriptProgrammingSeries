/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Enterprise SaaS Workspace Knowledge Graph Engine
 * @description A fully self-contained, zero-dependency TypeScript implementation 
 * of a semantic triple store for modeling organizational entities, attributes, and relations.
 */

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents a unique node (entity) within the knowledge graph.
 */
export interface GraphEntity {
  id: string;
  type: 'User' | 'Workspace' | 'Project' | 'Role';
  properties: Record<string, string | number | boolean>;
}

/**
 * Represents a directed, typed relationship between two entities.
 * Structure: [Subject] --[Predicate]--> [Object]
 */
export interface SemanticTriple {
  subjectId: string;
  predicate: string;
  objectId: string;
  metadata?: Record<string, unknown>;
}

/**
 * Result structure for graph traversal queries.
 */
export interface TraversalResult {
  entity: GraphEntity;
  relationship: string;
  depth: number;
}

// ==========================================
// 2. KNOWLEDGE GRAPH ENGINE CLASS
// ==========================================

/**
 * An in-memory deterministic knowledge graph solver and triple store.
 */
export class WorkspaceKnowledgeGraph {
  // Primary storage indices for O(1) lookups
  private entities: Map<string, GraphEntity> = new Map();
  private triples: Set<string> = new Set(); // Serialized as "subject|predicate|object" for O(1) deduplication
  
  // Adjacency lists for fast graph traversal
  private outgoingEdges: Map<string, Set<string>> = new Map(); // subjectId -> Set of triple keys
  private incomingEdges: Map<string, Set<string>> = new Map(); // objectId -> Set of triple keys

  /**
   * Adds or updates an entity (node) in the graph.
   * @param entity The graph entity to upsert.
   */
  public addEntity(entity: GraphEntity): void {
    this.entities.set(entity.id, entity);
    if (!this.outgoingEdges.has(entity.id)) {
      this.outgoingEdges.set(entity.id, new Set());
    }
    if (!this.incomingEdges.has(entity.id)) {
      this.incomingEdges.set(entity.id, new Set());
    }
  }

  /**
   * Asserts a semantic triple (edge) into the graph.
   * Validates that both subject and object entities exist before linking.
   */
  public addTriple(triple: SemanticTriple): void {
    if (!this.entities.has(triple.subjectId)) {
      throw new Error(`Subject entity '${triple.subjectId}' does not exist in the graph.`);
    }
    if (!this.entities.has(triple.objectId)) {
      throw new Error(`Object entity '${triple.objectId}' does not exist in the graph.`);
    }

    const tripleKey = this.serializeTriple(triple.subjectId, triple.predicate, triple.objectId);
    
    if (!this.triples.has(tripleKey)) {
      this.triples.add(tripleKey);
      this.outgoingEdges.get(triple.subjectId)!.add(tripleKey);
      this.incomingEdges.get(triple.objectId)!.add(tripleKey);
    }
  }

  /**
   * Queries the graph for all outgoing relations from a given entity.
   * @param subjectId The ID of the source entity.
   */
  public getOutgoingTriples(subjectId: string): SemanticTriple[] {
    const tripleKeys = this.outgoingEdges.get(subjectId);
    if (!tripleKeys) return [];
    
    return Array.from(tripleKeys).map(key => this.deserializeTriple(key));
  }

  /**
   * Performs a deterministic 1-hop traversal to find all connected entities.
   * @param subjectId The starting entity ID.
   * @param predicate Optional filter for the relationship type.
   */
  public traverseOut(subjectId: string, predicate?: string): TraversalResult[] {
    const results: TraversalResult[] = [];
    const outgoing = this.getOutgoingTriples(subjectId);

    for (const t of outgoing) {
      if (predicate && t.predicate !== predicate) continue;
      
      const targetEntity = this.entities.get(t.objectId);
      if (targetEntity) {
        results.push({
          entity: targetEntity,
          relationship: t.predicate,
          depth: 1
        });
      }
    }

    return results;
  }

  /**
   * Serializes a triple components into a composite string key.
   */
  private serializeTriple(subject: string, predicate: string, object: string): string {
    return `${subject}___${predicate}___${object}`;
  }

  /**
   * Deserializes a composite string key back into a SemanticTriple object.
   */
  private deserializeTriple(key: string): SemanticTriple {
    const [subjectId, predicate, objectId] = key.split('___');
    return { subjectId, predicate, objectId };
  }
}

// ==========================================
// 3. EXECUTION DEMONSTRATION (SaaS Context)
// ==========================================

// Initialize our SaaS Knowledge Graph
const saasGraph = new WorkspaceKnowledgeGraph();

// 1. Populate Entities (Nodes)
saasGraph.addEntity({
  id: 'user_alice_123',
  type: 'User',
  properties: { email: 'alice@enterprise.io', status: 'ACTIVE' }
});

saasGraph.addEntity({
  id: 'workspace_acme_corp',
  type: 'Workspace',
  properties: { name: 'Acme Corp Enterprise', plan: 'ENTERPRISE' }
});

saasGraph.addEntity({
  id: 'project_core_engine',
  type: 'Project',
  properties: { name: 'Core Engine Redesign', securityLevel: 'HIGH' }
});

saasGraph.addEntity({
  id: 'role_admin',
  type: 'Role',
  properties: { permissions: 'READ,WRITE,DELETE,ADMIN' }
});

// 2. Assert Semantic Triples (Directed Edges)
// Alice BELONGS_TO Acme Corp Workspace
saasGraph.addTriple({
  subjectId: 'user_alice_123',
  predicate: 'BELONGS_TO',
  objectId: 'workspace_acme_corp'
});

// Alice HAS_ROLE Admin
saasGraph.addTriple({
  subjectId: 'user_alice_123',
  predicate: 'HAS_ROLE',
  objectId: 'role_admin'
});

// Acme Corp Workspace OWNS Project Core Engine
saasGraph.addTriple({
  subjectId: 'workspace_acme_corp',
  predicate: 'OWNS',
  objectId: 'project_core_engine'
});

// Alice CONTRIBUTES_TO Project Core Engine
saasGraph.addTriple({
  subjectId: 'user_alice_123',
  predicate: 'CONTRIBUTES_TO',
  objectId: 'project_core_engine'
});

// 3. Query the Graph Deterministically
console.log('=== TRAVERSAL: What is Alice connected to? ===');
const aliceConnections = saasGraph.traverseOut('user_alice_123');
aliceConnections.forEach(conn => {
  console.log(`[Alice] --(${conn.relationship})--> [${conn.entity.type}: ${conn.entity.properties.name || conn.entity.id}]`);
});

console.log('\n=== TRAVERSAL: Projects owned by Acme Corp ===');
const acmeProjects = saasGraph.traverseOut('workspace_acme_corp', 'OWNS');
acmeProjects.forEach(conn => {
  console.log(`[Acme Corp] --(${conn.relationship})--> [${conn.entity.type}: ${conn.entity.properties.name}]`);
});
