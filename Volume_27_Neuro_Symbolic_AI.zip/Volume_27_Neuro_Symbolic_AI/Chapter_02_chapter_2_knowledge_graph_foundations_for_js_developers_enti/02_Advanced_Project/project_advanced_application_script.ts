/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Enterprise Knowledge Graph Engine for Next.js SaaS Platforms
 * Language: TypeScript
 * Description: Implements a deterministic, in-memory Knowledge Graph using 
 * semantic triples (Subject-Predicate-Object) with robust traversal and filtering.
 */

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

export type EntityId = string;
export type Predicate = string;

/**
 * Represents a node within the Knowledge Graph.
 * Can map to users, resources, organizations, or permissions.
 */
export interface Entity {
  readonly id: EntityId;
  readonly type: 'User' | 'Organization' | 'Resource' | 'Role';
  readonly attributes: Record<string, string | number | boolean>;
}

/**
 * Represents a directed, labeled edge between a Subject and an Object.
 * Formulates the fundamental Semantic Triple: (Subject) -> [Predicate] -> (Object)
 */
export interface Triple {
  readonly subjectId: EntityId;
  readonly predicate: Predicate;
  readonly objectId: EntityId;
}

/**
 * Traversal path result for graph queries.
 */
export interface PathSegment {
  from: Entity;
  relation: Predicate;
  to: Entity;
}

// ==========================================
// 2. KNOWLEDGE GRAPH STORE IMPLEMENTATION
// ==========================================

export class KnowledgeGraph {
  private entities: Map<EntityId, Entity> = new Map();
  private triples: Set<string> = new Set(); // Serialized as "subject|predicate|object" for O(1) deduplication
  
  // Indexing for high-performance traversals
  private outgoingIndex: Map<EntityId, Set<string>> = new Map(); // subjectId -> set of triple keys
  private incomingIndex: Map<EntityId, Set<string>> = new Map(); // objectId -> set of triple keys

  /**
   * Adds or updates an entity within the graph.
   */
  public upsertEntity(entity: Entity): void {
    this.entities.set(entity.id, entity);
  }

  /**
   * Asserts a semantic triple into the graph, establishing a directed relationship.
   */
  public addTriple(triple: Triple): void {
    // Ensure both entities exist before binding relation
    if (!this.entities.has(triple.subjectId) || !this.entities.has(triple.objectId)) {
      throw new Error(`Orphaned Triple Error: Both Subject (${triple.subjectId}) and Object (${triple.objectId}) must exist.`);
    }

    const key = `${triple.subjectId}|${triple.predicate}|${triple.objectId}`;
    if (this.triples.has(key)) return; // Idempotent insertion

    this.triples.add(key);

    // Update outgoing index
    if (!this.outgoingIndex.has(triple.subjectId)) {
      this.outgoingIndex.set(triple.subjectId, new Set());
    }
    this.outgoingIndex.get(triple.subjectId)!.add(key);

    // Update incoming index
    if (!this.incomingIndex.has(triple.objectId)) {
      this.incomingIndex.set(triple.objectId, new Set());
    }
    this.incomingIndex.get(triple.objectId)!.add(key);
  }

  /**
   * Deserializes a triple string key back into a structured Triple object.
   */
  private parseKey(key: string): Triple {
    const [subjectId, predicate, objectId] = key.split('|');
    return { subjectId, predicate, objectId };
  }

  /**
   * Performs a 1-hop traversal from a starting entity following a specific predicate.
   */
  public traverse(startEntityId: EntityId, predicate: Predicate): Entity[] {
    const outgoingKeys = this.outgoingIndex.get(startEntityId);
    if (!outgoingKeys) return [];

    const results: Entity[] = [];
    for (const key of outgoingKeys) {
      const triple = this.parseKey(key);
      if (triple.predicate === predicate) {
        const targetEntity = this.entities.get(triple.objectId);
        if (targetEntity) {
          results.push(targetEntity);
        }
      }
    }
    return results;
  }

  /**
   * Evaluates transitive permissions or hierarchies (e.g., Is User X allowed to access Resource Y?).
   */
  public hasPath(startId: EntityId, targetId: EntityId, targetPredicate: Predicate, visited: Set<EntityId> = new Set()): boolean {
    if (startId === targetId) return true;
    if (visited.has(startId)) return false;
    
    visited.add(startId);

    const outgoingKeys = this.outgoingIndex.get(startId);
    if (!outgoingKeys) return false;

    for (const key of outgoingKeys) {
      const triple = this.parseKey(key);
      if (triple.predicate === targetPredicate) {
        if (triple.objectId === targetId) return true;
        if (this.hasPath(triple.objectId, targetId, targetPredicate, visited)) {
          return true;
        }
      }
    }

    return false;
  }
}

// ==========================================
// 3. APPLICATION INITIALIZATION & EXECUTION
// ==========================================

// Instantiate the enterprise graph engine
const enterpriseGraph = new KnowledgeGraph();

// Populate Entities (Nodes)
enterpriseGraph.upsertEntity({ id: 'org_acme', type: 'Organization', attributes: { name: 'Acme Corp', tier: 'Enterprise' } });
enterpriseGraph.upsertEntity({ id: 'usr_alice', type: 'User', attributes: { email: 'alice@acme.com', status: 'active' } });
enterpriseGraph.upsertEntity({ id: 'role_admin', type: 'Role', attributes: { level: 99 } });
enterpriseGraph.upsertEntity({ id: 'res_billing', type: 'Resource', attributes: { path: '/api/billing', sensitive: true } });

// Populate Relations (Semantic Triples)
enterpriseGraph.addTriple({ subjectId: 'usr_alice', predicate: 'BELONGS_TO', objectId: 'org_acme' });
enterpriseGraph.addTriple({ subjectId: 'usr_alice', predicate: 'ASSIGNED_ROLE', objectId: 'role_admin' });
enterpriseGraph.addTriple({ subjectId: 'role_admin', predicate: 'GRANTS_ACCESS', objectId: 'res_billing' });
enterpriseGraph.addTriple({ subjectId: 'org_acme', predicate: 'OWNS_RESOURCE', objectId: 'res_billing' });

// Execute Deterministic SaaS Queries
console.log('--- SaaS Knowledge Graph Execution ---');

// Query 1: Find all organizations Alice belongs to
const aliceOrgs = enterpriseGraph.traverse('usr_alice', 'BELONGS_TO');
console.log(`Alice's Organizations:`, aliceOrgs.map(o => o.attributes['name']));

// Query 2: Deterministic Access Control Verification (Zero-Hallucination)
const canAliceAccessBilling = enterpriseGraph.hasPath('usr_alice', 'res_billing', 'ASSIGNED_ROLE') || 
                              enterpriseGraph.hasPath('role_admin', 'res_billing', 'GRANTS_ACCESS');

console.log(`Does Alice have verified access to Billing API? ${canAliceAccessBilling}`);
