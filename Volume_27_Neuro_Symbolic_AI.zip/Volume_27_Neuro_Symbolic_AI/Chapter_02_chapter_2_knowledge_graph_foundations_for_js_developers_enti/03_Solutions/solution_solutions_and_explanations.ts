/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface RelationalUser {
  id: string;
  email: string;
  organizationId: string;
  managedOrganizationId?: string;
  isActive: boolean;
  createdAt: string;
}

interface RelationalOrganization {
  id: string;
  name: string;
}

type LiteralValue = string | boolean | number;

interface Triple {
  subject: string;
  predicate: string;
  object: LiteralValue;
}

class RelationalGraphMapper {
  private visited: Set<string> = new Set();

  public transformUserToTriples(user: RelationalUser, organization: RelationalOrganization): Triple[] {
    const userUri = `ex:user/${user.id}`;
    const orgUri = `ex:organization/${organization.id}`;

    // Prevent infinite loops using a composite visited tracking key
    const visitKey = `user:${user.id}-org:${organization.id}`;
    if (this.visited.has(visitKey)) {
      return [];
    }
    this.visited.add(visitKey);

    const triples: Triple[] = [
      // Scalar attribute triples
      { subject: userUri, predicate: 'rdf:type', object: 'ex:User' },
      { subject: userUri, predicate: 'ex:hasEmail', object: user.email },
      { subject: userUri, predicate: 'ex:isActive', object: user.isActive },
      { subject: userUri, predicate: 'ex:hasCreationDate', object: user.createdAt },

      // Foreign key transformed into a directed relationship edge
      { subject: userUri, predicate: 'ex:belongsTo', object: orgUri },
      { subject: orgUri, predicate: 'rdf:type', object: 'ex:Organization' },
      { subject: orgUri, predicate: 'ex:hasName', object: organization.name }
    ];

    // Handle circular reference: User managing an organization
    if (user.managedOrganizationId) {
      const managedOrgUri = `ex:organization/${user.managedOrganizationId}`;
      triples.push({
        subject: userUri,
        predicate: 'ex:managesOrganization',
        object: managedOrgUri
      });
    }

    return triples;
  }
}
