/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface Entity {
  id: string;
  type: string;
  properties: Record<string, unknown>;
}

interface Relation {
  sourceId: string;
  targetId: string;
  predicate: string;
}

class InMemoryGraphStore {
  private entities: Map<string, Entity> = new Map();
  private outgoingEdges: Map<string, Relation[]> = new Map();
  private incomingEdges: Map<string, Relation[]> = new Map();

  public addEntity(entity: Entity): void {
    this.entities.set(entity.id, entity);
  }

  public addRelation(relation: Relation): void {
    // Index outgoing edges
    const outgoing = this.outgoingEdges.get(relation.sourceId) || [];
    outgoing.push(relation);
    this.outgoingEdges.set(relation.sourceId, outgoing);

    // Index incoming edges
    const incoming = this.incomingEdges.get(relation.targetId) || [];
    incoming.push(relation);
    this.incomingEdges.set(relation.targetId, incoming);
  }

  public findConstrainedPath(startId: string, targetId: string, allowedPredicates: string[]): string[][] {
    const validPaths: string[][] = [];
    const allowedSet = new Set(allowedPredicates);
    
    // Queue stores paths (arrays of entity IDs)
    const queue: { currentId: string; path: string[] }[] = [
      { currentId: startId, path: [startId] }
    ];

    while (queue.length > 0) {
      const { currentId, path } = queue.shift()!;

      if (currentId === targetId) {
        validPaths.push(path);
        continue;
      }

      const outEdges = this.outgoingEdges.get(currentId) || [];
      for (const edge of outEdges) {
        // Enforce predicate constraint and prevent node re-visitation (cycle avoidance)
        if (allowedSet.has(edge.predicate) && !path.includes(edge.targetId)) {
          queue.push({
            currentId: edge.targetId,
            path: [...path, edge.targetId]
          });
        }
      }
    }

    return validPaths;
  }
}
