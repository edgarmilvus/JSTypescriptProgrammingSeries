/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

interface Triple {
  subject: string;
  predicate: string;
  object: string | boolean | number;
}

interface GraphExplorerPaneProps {
  triples: Triple[];
  onEntitySelect: (entityId: string) => void;
}

interface EntityNode {
  id: string;
  attributes: Record<string, string | boolean | number>;
  relations: { predicate: string; target: string }[];
}

export const GraphExplorerPane: React.FC<GraphExplorerPaneProps> = ({ triples, onEntitySelect }) => {
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState<string>('');
  const [expandedRelations, setExpandedRelations] = useState<Record<string, string[]>>({});

  // Parse flat triples into structured entities via useMemo
  const entityMap = useMemo(() => {
    const map = new Map<string, EntityNode>();

    triples.forEach(({ subject, predicate, object }) => {
      if (!map.has(subject)) {
        map.set(subject, { id: subject, attributes: {}, relations: [] });
      }
      const entity = map.get(subject)!;

      if (typeof object === 'string' && object.startsWith('ex:')) {
        entity.relations.push({ predicate, target: object });
      } else {
        entity.attributes[predicate] = object;
      }
    });

    return map;
  }, [triples]);

  const filteredEntities = useMemo(() => {
    const query = filterQuery.toLowerCase();
    return Array.from(entityMap.values()).filter(entity => {
      if (entity.id.toLowerCase().includes(query)) return true;
      return Object.values(entity.attributes).some(val => 
        String(val).toLowerCase().includes(query)
      );
    });
  }, [entityMap, filterQuery]);

  const handleSelect = (id: string) => {
    setSelectedEntityId(id);
    onEntitySelect(id);
  };

  const toggleLazyExpand = (relationKey: string, targetEntityId: string) => {
    if (expandedRelations[relationKey]) {
      setExpandedRelations(prev => {
        const copy = { ...prev };
        delete copy[relationKey];
        return copy;
      });
    } else {
      // Simulate lazy 2-hop fetch/expansion lookup from entityMap
      const targetEntity = entityMap.get(targetEntityId);
      const subRelations = targetEntity ? targetEntity.relations.map(r => `${r.predicate} -> ${r.target}`) : ['No outbound 2-hop links'];
      setExpandedRelations(prev => ({ ...prev, [relationKey]: subRelations }));
    }
  };

  const selectedEntity = selectedEntityId ? entityMap.get(selectedEntityId) : null;

  return (
    <div className="graph-explorer-pane" style={{ display: 'flex', gap: '20px', fontFamily: 'sans-serif' }}>
      <div style={{ flex: 1 }}>
        <input 
          type="text" 
          placeholder="Filter entities or attributes..." 
          value={filterQuery}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilterQuery(e.target.value)}
          style={{ width: '100%', padding: '8px', marginBottom: '12px' }}
        />
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {filteredEntities.map(entity => (
            <li 
              key={entity.id} 
              onClick={() => handleSelect(entity.id)}
              style={{ padding: '8px', cursor: 'pointer', background: selectedEntityId === entity.id ? '#e0f7fa' : '#f9f9f9', marginBottom: '4px' }}
            >
              <strong>{entity.id}</strong>
            </li>
          ))}
        </ul>
      </div>

      <div style={{ flex: 1, borderLeft: '1px solid #ccc', paddingLeft: '20px' }}>
        <h3>Metadata & Relations Panel</h3>
        {selectedEntity ? (
          <div>
            <h4>Entity: {selectedEntity.id}</h4>
            <h5>Literal Attributes</h5>
            <ul>
              {Object.entries(selectedEntity.attributes).map(([pred, val]) => (
                <li key={pred}><code>{pred}</code>: {String(val)}</li>
              ))}
            </ul>
            <h5>Semantic Relations</h5>
            <ul>
              {selectedEntity.relations.map((rel, idx) => {
                const relKey = `${selectedEntity.id}-${rel.predicate}-${rel.target}-${idx}`;
                const isExpanded = !!expandedRelations[relKey];
                return (
                  <li key={idx} style={{ marginBottom: '8px' }}>
                    <code>{rel.predicate}</code> ➔ <strong>{rel.target}</strong>
                    <button 
                      onClick={() => toggleLazyExpand(relKey, rel.target)}
                      style={{ marginLeft: '10px', fontSize: '10px' }}
                    >
                      {isExpanded ? 'Collapse 2-Hop' : 'Expand 2-Hop'}
                    </button>
                    {isExpanded && (
                      <ul style={{ background: '#eee', padding: '4px 15px', marginTop: '4px', fontSize: '12px' }}>
                        {expandedRelations[relKey].map((hop, i) => (
                          <li key={i}>{hop}</li>
                        ))}
                      </ul>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          <p>Select an entity to inspect properties.</p>
        )}
      </div>
    </div>
  );
};
