/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface OntologySchema {
  domainRestrictions: Map<string, string>; // predicate -> required subject type
  rangeRestrictions: Map<string, string>;  // predicate -> required object type / literal type
  cardinalityRules?: Map<string, number>;  // predicate -> max allowed instances per subject
}

interface ValidationError {
  triple: { subject: string; predicate: string; object: string };
  ruleViolated: string;
  severity: 'WARNING' | 'CRITICAL';
}

class GraphValidator {
  constructor(private store: InMemoryGraphStore, private schema: OntologySchema) {}

  public validateSchema(): ValidationError[] {
    const errors: ValidationError[] = [];
    const entityTypes = new Map<string, string>();

    // Pass 1: Extract entity types from the store
    // Accessing internal entities map via structural assumptions or store exposure method
    // Assuming store exposes an entity iterator or internal lookup helper
    // For demonstration, we iterate through all known nodes:
    const entities = (this.store as any).entities as Map<string, Entity>;
    entities.forEach((entity, id) => {
      entityTypes.set(id, entity.type);
    });

    const subjectPredicateCounts = new Map<string, number>();

    // Pass 2: Evaluate domain, range, and cardinality rules across all relations
    const outgoingEdges = (this.store as any).outgoingEdges as Map<string, Relation[]>;
    outgoingEdges.forEach((relations, sourceId) => {
      const subjectType = entityTypes.get(sourceId);

      relations.forEach(relation => {
        const { predicate, targetId } = relation;
        const targetEntity = entities.get(targetId);
        const targetType = targetEntity ? targetEntity.type : 'Literal';

        const tripleContext = { subject: sourceId, predicate, object: targetId };

        // 1. Domain Validation
        const requiredDomain = this.schema.domainRestrictions.get(predicate);
        if (requiredDomain && subjectType !== requiredDomain) {
          errors.push({
            triple: tripleContext,
            ruleViolated: `Domain violation: Predicate '${predicate}' requires subject type '${requiredDomain}', but found '${subjectType || 'Unknown'}'.`,
            severity: 'CRITICAL'
          });
        }

        // 2. Range Validation
        const requiredRange = this.schema.rangeRestrictions.get(predicate);
        if (requiredRange && targetType !== requiredRange) {
          errors.push({
            triple: tripleContext,
            ruleViolated: `Range violation: Predicate '${predicate}' requires object type '${requiredRange}', but found '${targetType}'.`,
            severity: 'CRITICAL'
          });
        }

        // 3. Cardinality Validation
        if (this.schema.cardinalityRules && this.schema.cardinalityRules.has(predicate)) {
          const maxAllowed = this.schema.cardinalityRules.get(predicate)!;
          const countKey = `${sourceId}:${predicate}`;
          const currentCount = (subjectPredicateCounts.get(countKey) || 0) + 1;
          subjectPredicateCounts.set(countKey, currentCount);

          if (currentCount > maxAllowed) {
            errors.push({
              triple: tripleContext,
              ruleViolated: `Cardinality violation: Predicate '${predicate}' exceeds maximum allowed instances of ${maxAllowed} for subject '${sourceId}'.`,
              severity: 'WARNING'
            });
          }
        }
      });
    });

    return errors;
  }
}
