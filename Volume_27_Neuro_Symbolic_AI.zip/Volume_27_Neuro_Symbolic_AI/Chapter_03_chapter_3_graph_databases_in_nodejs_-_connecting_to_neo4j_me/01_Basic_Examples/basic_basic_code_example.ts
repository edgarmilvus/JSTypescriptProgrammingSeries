/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import neo4j, { Driver, Session, ManagedTransaction, Node as Neo4jNode } from 'neo4j-driver';
import * as dotenv from 'dotenv';

// Load environmental variables for secure credential management
dotenv.config();

/**
 * Configuration interface for the Graph Database client.
 */
interface GraphDatabaseConfig {
    uri: string;
    user: string;
    pass: string;
}

/**
 * Domain model representing a SaaS User entity mapped from the graph database.
 */
interface UserNode {
    id: string;
    email: string;
    name: string;
    createdAt: number;
}

/**
 * Domain model representing an Organization entity mapped from the graph database.
 */
interface OrganizationNode {
    id: string;
    name: string;
    plan: 'FREE' | 'PRO' | 'ENTERPRISE';
}

/**
 * Unified relationship model representing workspace membership.
 */
interface MembershipRelationship {
    role: 'ADMIN' | 'MEMBER' | 'BILLING';
    joinedAt: number;
}

/**
 * Enterprise Graph Database Service class encapsulating connection pooling,
 * session lifecycles, and strongly-typed Cypher query execution.
 */
class SaaSGraphService {
    private driver: Driver;

    /**
     * Initializes the Neo4j driver with connection pooling parameters.
     * @param config Database connection configuration.
     */
    constructor(config: GraphDatabaseConfig) {
        try {
            // Instantiate the driver. Under the hood, this establishes a connection pool.
            this.driver = neo4j.driver(
                config.uri,
                neo4j.auth.basic(config.user, config.pass),
                {
                    maxConnectionPoolSize: 50,
                    connectionTimeout: 30000, // 30 seconds
                    logging: {
                        level: 'info',
                        logger: (level, message) => console.log(`[Neo4j Driver] ${level}: ${message}`)
                    }
                }
            );
            console.log('Successfully initialized Neo4j driver connection pool.');
        } catch (error) {
            console.error('Failed to initialize Neo4j driver:', error);
            throw error;
        }
    }

    /**
     * Verifies connectivity to the graph database cluster.
     */
    public async verifyConnectivity(): Promise<boolean> {
        try {
            await this.driver.verifyConnectivity();
            console.log('Graph database connection verified successfully.');
            return true;
        } catch (error) {
            console.error('Graph database connectivity check failed:', error);
            return false;
        }
    }

    /**
     * Creates a User node and links them to an Organization node with a membership relationship.
     * Uses explicit read/write transaction management to guarantee ACID compliance.
     * 
     * @param user The user properties to create.
     * @param orgId The unique identifier of the target organization.
     * @param role The access control role within the organization.
     */
    public async createUserAndLinkOrganization(
        user: UserNode, 
        orgId: string, 
        role: MembershipRelationship['role']
    ): Promise<void> {
        // Obtain a session from the driver's internal connection pool
        const session: Session = this.driver.session({ defaultAccessMode: neo4j.session.WRITE });

        try {
            // Execute a write transaction with automatic retry capabilities
            await session.executeWrite(async (tx: ManagedTransaction) => {
                const query = `
                    MATCH (org:Organization {id: $orgId})
                    CREATE (u:User {
                        id: $userId,
                        email: $email,
                        name: $name,
                        createdAt: $createdAt
                    })
                    CREATE (u)-[r:BELONGS_TO {role: $role, joinedAt: $joinedAt}]->(org)
                    RETURN u, r, org
                `;

                const parameters = {
                    orgId: orgId,
                    userId: user.id,
                    email: user.email,
                    name: user.name,
                    // Convert JavaScript numbers to Neo4j integers if precision is critical, 
                    // or pass standard JS numbers for safe serialization.
                    createdAt: user.createdAt,
                    role: role,
                    joinedAt: Date.now()
                };

                const result = await tx.run(query, parameters);
                
                if (result.records.length === 0) {
                    throw new Error(`Organization with ID ${orgId} not found. Aborting user creation.`);
                }

                console.log(`Successfully created user ${user.email} and linked to organization ${orgId}`);
            });
        } catch (error) {
            console.error('Transaction execution failed during user creation:', error);
            throw error;
        } finally {
            // CRITICAL: Always close sessions to return connections to the pool and prevent memory leaks.
            await session.close();
        }
    }

    /**
     * Retrieves an organization's user roster by querying the graph topology.
     * Demonstrates read-only transaction execution and robust result mapping.
     * 
     * @param orgId The organization identifier.
     */
    public async getOrganizationUsers(orgId: string): Promise<Array<{ user: UserNode; membership: MembershipRelationship }>> {
        const session: Session = this.driver.session({ defaultAccessMode: neo4j.session.READ });

        try {
            // Execute read transaction
            const result = await session.executeRead(async (tx: ManagedTransaction) => {
                const query = `
                    MATCH (u:User)-[r:BELONGS_TO]->(org:Organization {id: $orgId})
                    RETURN u, r
                    ORDER BY r.joinedAt DESC
                `;

                const parameters = { orgId };
                return await tx.run(query, parameters);
            });

            // Map raw Neo4j records into strongly-typed TypeScript domain objects
            return result.records.map(record => {
                const userNode = record.get('u') as Neo4jNode;
                const relationship = record.get('r');

                // Extract properties safely using Neo4j driver's internal structures
                const userProps = userNode.properties;
                const relProps = relationship.properties;

                return {
                    user: {
                        id: String(userProps.id),
                        email: String(userProps.email),
                        name: String(userProps.name),
                        createdAt: Number(userProps.createdAt)
                    },
                    membership: {
                        role: relProps.role as MembershipRelationship['role'],
                        joinedAt: Number(relProps.joinedAt)
                    }
                };
            });

        } catch (error) {
            console.error(`Failed to retrieve users for organization ${orgId}:`, error);
            throw error;
        } finally {
            await session.close();
        }
    }

    /**
     * Gracefully shuts down the driver and closes all active connection pools.
     */
    public async close(): Promise<void> {
        await this.driver.close();
        console.log('Neo4j driver connections terminated.');
    }
}

// ==========================================
// Execution Context & Demonstration Harness
// ==========================================

async function runSaaSGraphDemo() {
    // Environment validation guard
    const uri = process.env.NEO4J_URI || 'neo4j://localhost:7687';
    const user = process.env.NEO4J_USER || 'neo4j';
    const pass = process.env.NEO4J_PASSWORD || 'password123';

    const graphService = new SaaSGraphService({ uri, user, pass });

    const isConnected = await graphService.verifyConnectivity();
    if (!isConnected) {
        console.error('Aborting demo due to connection failure.');
        process.exit(1);
    }

    try {
        const mockUser: UserNode = {
            id: 'usr_998877',
            email: 'ada.lovelace@analytical-engines.io',
            name: 'Ada Lovelace',
            createdAt: Date.now()
        };

        const targetOrgId = 'org_enterprise_01';

        // Execute write operation
        await graphService.createUserAndLinkOrganization(mockUser, targetOrgId, 'ADMIN');

        // Execute read operation
        const members = await graphService.getOrganizationUsers(targetOrgId);
        console.log('Fetched Organization Members:', JSON.stringify(members, null, 2));

    } catch (error) {
        console.error('Demo execution encountered an unhandled error:', error);
    } finally {
        await graphService.close();
    }
}

// Uncomment to execute script directly in a Node.js runtime
// runSaaSGraphDemo();
