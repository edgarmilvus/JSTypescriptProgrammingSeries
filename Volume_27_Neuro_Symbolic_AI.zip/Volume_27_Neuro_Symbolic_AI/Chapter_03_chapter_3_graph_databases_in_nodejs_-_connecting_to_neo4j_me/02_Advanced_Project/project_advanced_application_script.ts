/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file enterprise-graph-service.ts
 * @description Enterprise-grade TypeScript service for connecting to Neo4j, managing 
 * connection pooling, executing strongly-typed Cypher queries, and mapping results 
 * to domain models for downstream neuro-symbolic reasoning.
 */

import neo4j, { Driver, Session, ManagedTransaction, Record as Neo4jRecord } from 'neo4j-driver';

// ==========================================
// 1. Domain Models & Interfaces
// ==========================================

export interface UserNode {
  id: string;
  email: string;
  department: string;
  createdAt: Date;
}

export interface ResourceNode {
  id: string;
  name: string;
  classification: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
}

export interface AccessEvaluationResult {
  user: UserNode;
  resource: ResourceNode;
  permissions: string[];
  isAuthorized: boolean;
}

export interface GraphConfig {
  uri: string;
  username: string;
  secret: string;
  maxConnectionPoolSize?: number;
}

// ==========================================
// 2. Enterprise Graph Service Implementation
// ==========================================

export class EnterpriseGraphService {
  private driver: Driver;

  /**
   * Initializes the Neo4j driver with enterprise pooling configurations.
   * Ensures that connection parameters align with high-throughput production requirements.
   */
  constructor(config: GraphConfig) {
    this.driver = neo4j.driver(
      config.uri,
      neo4j.auth.basic(config.username, config.secret),
      {
        maxConnectionPoolSize: config.maxConnectionPoolSize || 50,
        connectionTimeout: 10000, // 10 seconds
        encrypted: 'ENCRYPTION_ON',
      }
    );
  }

  /**
   * Verifies connectivity to the graph database instance.
   */
  public async verifyConnectivity(): Promise<void> {
    try {
      await this.driver.verifyConnectivity();
      console.info('[GraphService] Successfully established connection pool with Neo4j.');
    } catch (error) {
      console.error('[GraphService] Failed to connect to Neo4j cluster:', error);
      throw new Error('Database connectivity initialization failed.');
    }
  }

  /**
   * Evaluates user access rights to a specific resource by traversing the enterprise graph.
   * Utilizes managed transactions to guarantee ACID compliance and safe execution.
   * 
   * @param userId - The unique identifier of the user requesting access.
   * @param resourceId - The unique identifier of the target resource.
   */
  public async evaluateUserAccess(userId: string, resourceId: string): Promise<AccessEvaluationResult | null> {
    const session: Session = this.driver.session({ defaultAccessMode: neo4j.session.READ });

    try {
      // Execute read transaction with explicit typing and parameterization to prevent Cypher injection
      const result = await session.executeRead(async (tx: ManagedTransaction) => {
        const query = `
          MATCH (u:User {id: $userId})
          MATCH (r:Resource {id: $resourceId})
          OPTIONAL MATCH (u)-[:BELONGS_TO]->(:Role)-[:HAS_PERMISSION]->(p:Permission)
          RETURN u, r, collect(DISTINCT p.name) as permissions,
                 EXISTS((u)-[:BELONGS_TO]->(:Role)-[:HAS_PERMISSION]->(:Permission)-[:GRANTS]->(r)) as isDirectlyAuthorized
        `;

        const queryResult = await tx.run(query, { userId, resourceId });
        
        if (queryResult.records.length === 0) {
          return null;
        }

        return queryResult.records[0];
      });

      if (!result) {
        return null;
      }

      return this.mapRecordToAccessEvaluation(result);
    } catch (error) {
      console.error(`[GraphService] Error evaluating access for User ${userId} on Resource ${resourceId}:`, error);
      throw error;
    } finally {
      // Ensure session is always closed to prevent connection leaks
      await session.close();
    }
  }

  /**
   * Maps a raw Neo4j record into a strongly typed AccessEvaluationResult domain model.
   */
  private mapRecordToAccessEvaluation(record: Neo4jRecord): AccessEvaluationResult {
    const rawUser = record.get('u').properties;
    const rawResource = record.get('r').properties;
    const permissions: string[] = record.get('permissions');
    const isAuthorized: boolean = record.get('isDirectlyAuthorized');

    const user: UserNode = {
      id: rawUser.id,
      email: rawUser.email,
      department: rawUser.department,
      createdAt: new Date(rawUser.createdAt.toNumber ? rawUser.createdAt.toNumber() : rawUser.createdAt),
    };

    const resource: ResourceNode = {
      id: rawResource.id,
      name: rawResource.name,
      classification: rawResource.classification,
    };

    return {
      user,
      resource,
      permissions,
      isAuthorized,
    };
  }

  /**
   * Gracefully shuts down the driver and releases all pooled connections.
   */
  public async close(): Promise<void> {
    await this.driver.close();
    console.info('[GraphService] Neo4j driver connection pool closed.');
  }
}

// ==========================================
// 3. Execution Example (SaaS Integration Layer)
// ==========================================

async function runApplication() {
  const graphService = new EnterpriseGraphService({
    uri: process.env.NEO4J_URI || 'neo4j+s://hostname:7687',
    username: process.env.NEO4J_USER || 'neo4j',
    secret: process.env.NEO4J_PASSWORD || 'secure-password',
    maxConnectionPoolSize: 20,
  });

  try {
    await graphService.verifyConnectivity();

    // Simulate an incoming API request checking authorization policy via the knowledge graph
    const evaluation = await graphService.evaluateUserAccess('usr_99823', 'res_44102');

    if (evaluation) {
      console.log('Access Evaluation Complete:');
      console.dir(evaluation, { depth: null, colors: true });
    } else {
      console.warn('User or Resource not found in the graph topology.');
    }
  } catch (error) {
    console.error('Application runtime error:', error);
  } finally {
    await graphService.close();
  }
}

// Uncomment to execute in a standalone Node.js environment
// runApplication();
