/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import neo4j, { Driver, Session, Record as Neo4jRecord } from 'neo4j-driver';

// 2. Define TypeScript interfaces for domain models
export interface ConceptNode {
  id: string;
  name: string;
  confidenceScore: number;
}

export interface RelatesToEdge {
  weight: number;
  predicate: string;
}

export interface ComprehensiveConcept {
  concept: ConceptNode;
  relations: Array<{
    edge: RelatesToEdge;
    target: ConceptNode;
  }>;
}

// 1. Initialize Driver with custom connection pool & graceful shutdown
export function createNeo4jDriver(uri: string, user: string, pass: string): Driver {
  const driver = neo4j.driver(uri, neo4j.auth.basic(user, pass), {
    maxConnectionPoolSize: 50,
    connectionAcquisitionTimeout: 5000,
    encrypted: 'ENCRYPTION_ON',
  });

  const gracefulShutdown = async () => {
    console.log('Closing Neo4j driver connection pool...');
    await driver.close();
    process.exit(0);
  };

  process.on('SIGINT', gracefulShutdown);
  process.on('SIGTERM', gracefulShutdown);

  return driver;
}

// Interactive Challenge: Generic Read Execution Wrapper with Transaction Lifecycle Management
export async function executeRead<T>(
  driver: Driver,
  query: string,
  params: Record<string, any>,
  mapper: (record: Neo4jRecord) => T
): Promise<T[]> {
  const session: Session = driver.session();
  try {
    const result = await session.executeRead(async (tx) => {
      const queryResult = await tx.run(query, params);
      return queryResult.records.map((record) => mapper(record));
    });
    return result;
  } finally {
    await session.close();
  }
}

// 3 & 4. Fetch Concept with Relations using parameterized inputs and Record mapping
export async function fetchConceptWithRelations(
  driver: Driver,
  conceptId: string
): Promise<ComprehensiveConcept | null> {
  const query = `
    MATCH (c:Concept {id: $conceptId})
    OPTIONAL MATCH (c)-[r:RELATES_TO]->(target:Concept)
    RETURN c, collect({edge: r, target: target}) as rels
  `;

  const results = await executeRead(
    driver,
    query,
    { conceptId },
    (record: Neo4jRecord): ComprehensiveConcept | null => {
      const cNode = record.get('c');
      if (!cNode) return null;

      const concept: ConceptNode = {
        id: cNode.properties.id,
        name: cNode.properties.name,
        confidenceScore: cNode.properties.confidenceScore,
      };

      const rawRels = record.get('rels') as Array<{ edge: any; target: any }>;
      const relations = rawRels
        .filter((item) => item.target !== null && item.edge !== null)
        .map((item) => ({
          edge: {
            weight: item.edge.properties.weight,
            predicate: item.edge.properties.predicate,
          } as RelatesToEdge,
          target: {
            id: item.target.properties.id,
            name: item.target.properties.name,
            confidenceScore: item.target.properties.confidenceScore,
          } as ConceptNode,
        }));

      return { concept, relations };
    }
  );

  return results.length > 0 ? results[0] : null;
}
