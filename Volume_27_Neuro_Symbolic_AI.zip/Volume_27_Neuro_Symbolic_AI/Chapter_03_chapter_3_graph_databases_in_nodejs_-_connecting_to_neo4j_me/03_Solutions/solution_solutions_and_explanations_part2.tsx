/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useTransition } from 'react';

export interface GraphNode {
  id: string;
  name: string;
  confidenceScore: number;
  isDeterministic: boolean;
  properties: Record<string, any>;
  relationships: Array<{ type: string; targetId: string }>;
}

interface OntologyInspectorProps {
  initialQuery?: string;
  apiBaseUrl: string;
}

export const OntologyInspector: React.FC<OntologyInspectorProps> = ({
  initialQuery = '',
  apiBaseUrl,
}) => {
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [nodes, setNodes] = useState<GraphNode[]>([]);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  // 3. Debounced Search Input with AbortController
  useEffect(() => {
    const controller = new AbortController();
    const timeoutId = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `${apiBaseUrl}/api/ontology/search?q=${encodeURIComponent(searchTerm)}`,
          { signal: controller.signal }
        );
        if (!response.ok) throw new Error('Failed to fetch ontology nodes.');
        const data: GraphNode[] = await response.json();
        startTransition(() => {
          setNodes(data);
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setError(err.message);
        }
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => {
      clearTimeout(timeoutId);
      controller.abort();
    };
  }, [searchTerm, apiBaseUrl]);

  // Interactive Challenge: Optimistic mutation handler for "Verify Determinism"
  const handleToggleDeterminism = async () => {
    if (!selectedNode) return;

    const previousState = selectedNode.isDeterministic;
    const updatedState = !previousState;

    // Optimistically update local UI state immediately
    setSelectedNode({ ...selectedNode, isDeterministic: updatedState });
    setNodes((prevNodes) =>
      prevNodes.map((n) => (n.id === selectedNode.id ? { ...n, isDeterministic: updatedState } : n))
    );

    try {
      const response = await fetch(`${apiBaseUrl}/api/ontology/nodes/${selectedNode.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isDeterministic: updatedState }),
      });
      if (!response.ok) throw new Error('Network mutation failed.');
    } catch (err) {
      // Rollback on failure
      setSelectedNode({ ...selectedNode, isDeterministic: previousState });
      setNodes((prevNodes) =>
        prevNodes.map((n) => (n.id === selectedNode.id ? { ...n, isDeterministic: previousState } : n))
      );
      setError('Failed to update determinism status. State rolled back.');
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'sans-serif' }}>
      {/* Left Pane: Master List & Search */}
      <div style={{ width: '40%', borderRight: '1px solid #ccc', padding: '1rem', overflowY: 'auto' }}>
        <h2>Ontology Inspector</h2>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search concepts..."
          style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', boxSizing: 'border-box' }}
        />
        {loading && <p>Loading graph entities...</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {nodes.map((node) => (
            <li
              key={node.id}
              onClick={() => setSelectedNode(node)}
              style={{
                padding: '0.75rem',
                margin: '0.5rem 0',
                background: selectedNode?.id === node.id ? '#e2e8f0' : '#f8fafc',
                cursor: 'pointer',
                borderRadius: '4px',
              }}
            >
              <strong>{node.name}</strong> ({node.id})
              <div>Confidence: {node.confidenceScore}</div>
            </li>
          ))}
        </ul>
      </div>

      {/* Right Pane: Detail Panel */}
      <div style={{ width: '60%', padding: '2rem', overflowY: 'auto' }}>
        {selectedNode ? (
          <div>
            <h3>Node Details: {selectedNode.name}</h3>
            <p><strong>ID:</strong> {selectedNode.id}</p>
            <p><strong>Confidence Score:</strong> {selectedNode.confidenceScore}</p>
            <p>
              <strong>Status: </strong>
              <span style={{
                padding: '0.2rem 0.5rem',
                borderRadius: '4px',
                background: selectedNode.isDeterministic ? '#d1fae5' : '#fee2e2',
                color: selectedNode.isDeterministic ? '#065f46' : '#991b1b'
              }}>
                {selectedNode.isDeterministic ? 'Deterministic' : 'Probabilistic'}
              </span>
            </p>

            <button
              onClick={handleToggleDeterminism}
              style={{ padding: '0.5rem 1rem', background: '#2563eb', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', marginBottom: '1rem' }}
            >
              Verify Determinism
            </button>

            <h4>Properties</h4>
            <pre style={{ background: '#f1f5f9', padding: '1rem', borderRadius: '4px' }}>
              {JSON.stringify(selectedNode.properties, null, 2)}
            </pre>

            <h4>Relationships</h4>
            <ul>
              {selectedNode.relationships.map((rel, idx) => (
                <li key={idx}>[{rel.type}] &rarr; {rel.targetId}</li>
              ))}
            </ul>
          </div>
        ) : (
          <p style={{ color: '#64748b' }}>Select a node from the master list to inspect details.</p>
        )}
      </div>
    </div>
  );
};
