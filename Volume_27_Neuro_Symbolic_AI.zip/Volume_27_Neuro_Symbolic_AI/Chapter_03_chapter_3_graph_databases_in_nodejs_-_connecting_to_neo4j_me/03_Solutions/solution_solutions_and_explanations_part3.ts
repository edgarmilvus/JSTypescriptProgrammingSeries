/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Driver, Session, ManagedTransaction } from 'neo4j-driver';

export interface AxiomPayload {
  entityId: string;
  entityName: string;
  confidence: number;
  relationPredicate: string;
  targetEntityId: string;
  targetEntityName: string;
}

export class TransactionRollbackError extends Error {
  constructor(message: string, public readonly cause?: any) {
    super(message);
    this.name = 'TransactionRollbackError';
  }
}

// 1, 2 & 3. Ingest Axiom Bundle with explicit transaction management & idempotent MERGE
export async function ingestAxiomBundle(driver: Driver, axioms: AxiomPayload[]): Promise<number> {
  const session: Session = driver.session();
  let processedCount = 0;

  const transaction = await session.beginTransaction();

  try {
    for (const axiom of axioms) {
      const query = `
        MERGE (source:Concept {id: $entityId})
        ON CREATE SET source.name = $entityName, source.confidenceScore = $confidence
        ON MATCH SET source.confidenceScore = $confidence

        MERGE (target:Concept {id: $targetEntityId})
        ON CREATE SET target.name = $targetEntityName, target.confidenceScore = 1.0

        MERGE (source)-[r:RELATES_TO {predicate: $relationPredicate}]->(target)
        ON CREATE SET r.weight = $confidence
        ON MATCH SET r.weight = $confidence
      `;

      await transaction.run(query, {
        entityId: axiom.entityId,
        entityName: axiom.entityName,
        confidence: axiom.confidence,
        targetEntityId: axiom.targetEntityId,
        targetEntityName: axiom.targetEntityName,
        relationPredicate: axiom.relationPredicate,
      });

      processedCount += 2; // Count nodes/edges processed per iteration
    }

    await transaction.commit();
    return processedCount;
  } catch (error) {
    await transaction.rollback();
    throw new TransactionRollbackError(`Transaction aborted and rolled back due to error:`, error);
  } finally {
    await session.close();
  }
}

// Interactive Challenge: Retry middleware wrapper with exponential backoff and jitter
export async function ingestAxiomBundleWithRetry(
  driver: Driver,
  axioms: AxiomPayload[],
  maxRetries: number = 3
): Promise<number> {
  let attempt = 0;

  while (true) {
    try {
      return await ingestAxiomBundle(driver, axioms);
    } catch (error: any) {
      attempt++;
      const isTransient =
        error.code === 'Neo.TransientError.Transaction.LockAcquisitionTimeout' ||
        error.code === 'Neo.TransientError.Transaction.DeadlockDetected';

      if (!isTransient || attempt >= maxRetries) {
        throw error;
      }

      // Calculate exponential backoff with jitter
      const baseDelay = Math.pow(2, attempt) * 100;
      const jitter = Math.random() * 100;
      const delay = baseDelay + jitter;

      console.warn(`Transient database lock detected. Retrying attempt ${attempt}/${maxRetries} in ${Math.round(delay)}ms...`);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
}
