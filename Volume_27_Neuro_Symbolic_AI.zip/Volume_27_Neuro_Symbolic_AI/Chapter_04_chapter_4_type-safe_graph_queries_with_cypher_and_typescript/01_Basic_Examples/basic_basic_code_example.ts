/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Neo4jTypeSafeQueryBuilder.ts
 * @description A zero-hallucination, type-safe Cypher query builder for SaaS IAM architectures.
 * Adheres to strict type discipline (strict: true, strictNullChecks).
 */

// ============================================================================
// 1. DOMAIN MODELS & SCHEMA DEFINITIONS
// ============================================================================

/**
 * Represents the core properties of a Tenant node within the SaaS graph.
 */
interface TenantNode {
  id: string;
  name: string;
  tier: 'FREE' | 'PRO' | 'ENTERPRISE';
}

/**
 * Represents the core properties of a User node within the SaaS graph.
 */
interface UserNode {
  id: string;
  email: string;
  isActive: boolean;
}

/**
 * A mapped type representing all available node labels in the graph schema
 * and their corresponding TypeScript structural interfaces.
 */
interface GraphSchema {
  Tenant: TenantNode;
  User: UserNode;
}

/**
 * Extracts valid node label keys from the GraphSchema definition.
 */
type NodeLabel = keyof GraphSchema;

/**
 * Strongly typed relationship directions supported by the query builder.
 */
type Direction = 'IN' | 'OUT' | 'BOTH';

// ============================================================================
// 2. QUERY BUILDER ABSTRACT SYNTAX TREE (AST) & BUILDER CLASS
// ============================================================================

/**
 * Encapsulates the internal state of the Cypher query under construction.
 */
interface QueryState {
  matchClauses: string[];
  returnClauses: string[];
  parameters: Record<string, unknown>;
}

/**
 * Type-Safe Cypher Query Builder.
 * 
 * Enforces schema correctness at compile time by restricting node labels and property keys
 * to those defined within the GraphSchema interface.
 * 
 * @template TCurrentLabel - The label of the currently focused node in the fluent chain.
 */
class CypherBuilder<TCurrentLabel extends NodeLabel = NodeLabel> {
  private state: QueryState;

  constructor(initialState?: QueryState) {
    this.state = initialState || {
      matchClauses: [],
      returnClauses: [],
      parameters: {},
    };
  }

  /**
   * Appends a MATCH clause to the Cypher execution plan for a given node label.
   * 
   * @template L - Must be a valid key of GraphSchema.
   * @param label - The graph database node label.
   * @param alias - The variable name assigned to the node in Cypher.
   * @returns A new instance of CypherBuilder typed with the newly matched label.
   */
  public match<L extends NodeLabel>(
    label: L,
    alias: string
  ): CypherBuilder<L> {
    const clause = `(${alias}:${label})`;
    return new CypherBuilder<L>({
      ...this.state,
      matchClauses: [...this.state.matchClauses, clause],
    });
  }

  /**
   * Appends a WHERE conditional clause tied to specific properties of the current node schema.
   * Prevents runtime property typos by enforcing keys present on GraphSchema[TCurrentLabel].
   * 
   * @param property - A valid property key for the current node's TypeScript interface.
   * @param operator - The comparison operator (e.g., '=', 'CONTAINS', 'IN').
   * @param value - The expected value, strictly typed to match the property's type.
   */
  public where<K extends keyof GraphSchema[TCurrentLabel]>(
    alias: string,
    property: K,
    operator: '=' | 'CONTAINS' | '<>' | '>',
    value: GraphSchema[TCurrentLabel][K]
  ): this {
    const paramKey = `${alias}_${String(property)}`;
    const clause = `${alias}.${String(property)} ${operator} $${paramKey}`;
    
    this.state.matchClauses.push(`WHERE ${clause}`);
    this.state.parameters[paramKey] = value;
    
    return this;
  }

  /**
   * Specifies which variables or properties to return from the graph traversal.
   * 
   * @param expressions - Array of property or alias selectors.
   */
  public return(...expressions: string[]): this {
    this.state.returnClauses.push(...expressions);
    return this;
  }

  /**
   * Compiles the internal AST state into a fully parameterized, deterministic Cypher query string
   * alongside its runtime parameters, ready for direct execution via the Neo4j driver.
   */
  public build(): { query: string; parameters: Record<string, unknown> } {
    const matchPart = this.state.matchClauses.length > 0 
      ? `MATCH ${this.state.matchClauses.join(', ')}` 
      : '';
      
    const returnPart = this.state.returnClauses.length > 0 
      ? `RETURN ${this.state.returnClauses.join(', ')}` 
      : 'RETURN *';

    const query = [matchPart, returnPart].filter(Boolean).join(' ');

    return {
      query,
      parameters: this.state.parameters,
    };
  }
}

// ============================================================================
// 3. EXECUTION AND USAGE DEMONSTRATION (SAAS IAM CONTEXT)
// ============================================================================

/**
 * Factory function to instantiate the root of the query builder.
 */
function createQuery(): CypherBuilder<NodeLabel> {
  return new CypherBuilder();
}

// Execute builder construction for an Enterprise SaaS Tenant lookup
const compiledQueryObject = createQuery()
  .match('Tenant', 't')
  .where('t', 'tier', '=', 'ENTERPRISE')
  .return('t.id', 't.name')
  .build();

// Output the compiled deterministic query and safe parameters
console.log('--- DETERMINISTIC CYPHER QUERY ---');
console.log(compiledQueryObject.query);
// Output: MATCH (t:Tenant) WHERE t.tier = $t_tier RETURN t.id, t.name

console.log('--- SAFE PARAMETERS ---');
console.log(compiledQueryObject.parameters);
// Output: { t_tier: 'ENTERPRIse' } (or 'ENTERPRISE')
