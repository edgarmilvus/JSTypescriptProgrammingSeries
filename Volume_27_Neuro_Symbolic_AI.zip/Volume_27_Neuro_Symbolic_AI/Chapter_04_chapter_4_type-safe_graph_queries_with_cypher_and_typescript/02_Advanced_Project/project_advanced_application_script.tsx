/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import 'server-only';
import { z } from 'zod';
import { useState, useTransition } from 'react';

/**
 * 1. DOMAIN MODEL & ZOD SCHEMAS
 * Define the graph nodes and relationships using Zod. This guarantees runtime
 * safety while simultaneously inferring precise TypeScript types for the AST.
 */
export const UserNodeSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  reputationScore: z.number().min(0).max(100),
});

export const ConceptNodeSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  domain: z.enum(['NeuroSymbolicAI', 'GraphDB', 'TypeScript']),
});

export const MasteredRelationshipSchema = z.object({
  confidence: z.number().min(0).max(1),
  acquiredAt: z.string().datetime(),
});

// Infer static TypeScript types directly from the runtime Zod definitions
export type UserNode = z.infer<typeof UserNodeSchema>;
export type ConceptNode = z.infer<typeof ConceptNodeSchema>;
export type MasteredRelationship = z.infer<typeof MasteredRelationshipSchema>;

/**
 * 2. ABSTRACT SYNTAX TREE (AST) & QUERY BUILDER INTERFACES
 * Define structures to represent Cypher clauses programmatically to eliminate
 * string concatenation bugs and prevent Cypher injection vulnerabilities.
 */
type MatchClause = {
  type: 'MATCH';
  pattern: {
    nodeAlias: string;
    nodeLabel: string;
    properties?: Record<string, unknown>;
  };
};

type ReturnClause = {
  type: 'RETURN';
  expressions: string[];
};

type CypherAST = {
  matches: MatchClause[];
  returns: ReturnClause;
};

/**
 * A zero-hallucination, deterministic query builder that transforms 
 * strongly-typed AST structures into valid, parameterized Cypher strings.
 */
class DeterministicCypherBuilder {
  private ast: CypherAST = { matches: [], returns: { type: 'RETURN', expressions: [] } };

  /**
   * Appends a MATCH clause to the AST based on explicit graph schemas.
   */
  public match(nodeAlias: string, nodeLabel: string, properties?: Record<string, unknown>): this {
    this.ast.matches.push({
      type: 'MATCH',
      pattern: { nodeAlias, nodeLabel, properties },
    });
    return this;
  }

  /**
   * Specifies the return projections for the execution plan.
   */
  public return(expressions: string[]): this {
    this.ast.returns = { type: 'RETURN', expressions };
    return this;
  }

  /**
   * Compiles the AST into an immutable, parameterized Cypher query string.
   */
  public build(): { query: string; params: Record<string, unknown> } {
    let queryString = '';
    const params: Record<string, unknown> = {};

    for (const match of this.ast.matches) {
      const propString = match.pattern.properties
        ? ` { ${Object.keys(match.pattern.properties)
            .map((key, i) => `${key}: $param_${match.nodeAlias}_${i}`)
            .join(', ')} }`
        : '';
      
      queryString += `MATCH (${match.pattern.nodeAlias}:${match.pattern.nodeLabel}${propString}) `;

      if (match.pattern.properties) {
        Object.values(match.pattern.properties).forEach((val, i) => {
          params[`param_${match.nodeAlias}_${i}`] = val;
        });
      }
    }

    queryString += `RETURN ${this.ast.returns.expressions.join(', ')}`;

    return { query: queryString.trim(), params };
  }
}

/**
 * 3. MOCK GRAPH DATABASE DRIVER (Simulating Neo4j Driver Client)
 */
class Neo4jDriverMock {
  public async executeQuery<T>(query: string, params: Record<string, unknown>, schema: z.ZodSchema<T>): Promise<T[]> {
    console.log('[Neo4j Driver] Executing Deterministic Query:', query);
    console.log('[Neo4j Driver] With Parameters:', params);

    // Mock returning structured data matching our domain models
    const rawDatabaseRecords = [
      {
        id: '9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d',
        email: 'architect@neurosymbolic.ai',
        reputationScore: 95,
      },
    ];

    // Validate raw records against the Zod schema at runtime (Zero-Hallucination barrier)
    return rawDatabaseRecords.map((record) => schema.parse(record));
  }
}

/**
 * 4. SERVER COMPONENT DATA FETCHING
 * Fetches user context securely on the server using strongly-typed graph queries.
 */
export async function fetchUserContextByDomain(domainName: string): Promise<UserNode[]> {
  const driver = new Neo4jDriverMock();

  // Construct query deterministically using the AST builder
  const { query, params } = new DeterministicCypherBuilder()
    .match('u', 'User')
    .match('c', 'Concept', { domain: domainName })
    .return(['u'])
    .build();

  // Execute query and validate results against the UserNodeSchema
  const validatedUsers = await driver.executeQuery(query, params, z.array(UserNodeSchema));
  return validatedUsers;
}

/**
 * 5. REACT CLIENT COMPONENT WITH TRANSITION HOOKS
 * Demonstrates non-blocking UI state transitions when invoking graph mutations or refetches.
 */
export function GraphQueryController() {
  const [isPending, startTransition] = useTransition();
  const [users, setUsers] = useState<UserNode[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>('NeuroSymbolicAI');

  const handleDomainChange = (newDomain: string) => {
    setSelectedDomain(newDomain);
    
    // Wrap state update in useTransition to prevent UI blocking during async server operations
    startTransition(async () => {
      const fetchedUsers = await fetchUserContextByDomain(newDomain);
      setUsers(fetchedUsers);
    });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Neuro-Symbolic Graph Explorer</h2>
      <p>Current Domain: {selectedDomain}</p>
      
      <button 
        onClick={() => handleDomainChange('NeuroSymbolicAI')}
        disabled={isPending}
      >
        {isPending ? 'Querying GraphDB...' : 'Load Neuro-Symbolic Experts'}
      </button>

      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.email} (Reputation: {user.reputationScore})
          </li>
        ))}
      </ul>
    </div>
  );
}
