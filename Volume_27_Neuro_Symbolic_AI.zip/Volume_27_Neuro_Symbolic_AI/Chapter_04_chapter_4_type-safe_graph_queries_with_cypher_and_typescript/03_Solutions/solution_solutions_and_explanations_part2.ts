/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface GraphNode<TProperties = Record<string, any>> {
  id: string;
  labels: string[];
  properties: TProperties;
}

export type ExtractProperties<T> = T extends GraphNode<infer P> ? P : never;

export class CypherQueryBuilder<TContext extends Record<string, any> = {}> {
  private ast: {
    matches: string[];
    wheres: string[];
    returns: string[];
  } = { matches: [], wheres: [], returns: [] };

  public match<TVar extends string, TNode>(
    variable: TVar,
    label: string
  ): CypherQueryBuilder<TContext & Record<TVar, TNode>> {
    this.ast.matches.push(`(${variable}:${label})`);
    return this as any;
  }

  public where<TVar extends keyof TContext>(
    variable: TVar,
    property: keyof ExtractProperties<TContext[TVar]>,
    value: any
  ): CypherQueryBuilder<TContext> {
    const clause = `${String(variable)}.${String(property)} = $${String(variable)}_${String(property)}`;
    this.ast.wheres.push(clause);
    return this;
  }

  public return<TKeys extends keyof TContext>(...keys: TKeys[]): string {
    const matchClause = `MATCH ${this.ast.matches.join(', ')}`;
    const whereClause = this.ast.wheres.length > 0 ? `WHERE ${this.ast.wheres.join(' AND ')}` : '';
    const returnClause = `RETURN ${keys.join(', ')}`;
    return [matchClause, whereClause, returnClause].filter(Boolean).join(' ');
  }
}
