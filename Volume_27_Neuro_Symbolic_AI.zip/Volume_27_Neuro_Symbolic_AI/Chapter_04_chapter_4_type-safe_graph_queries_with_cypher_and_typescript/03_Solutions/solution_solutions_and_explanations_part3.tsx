/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export interface GraphNode<TProperties = Record<string, any>> {
  id: string;
  labels: string[];
  properties: TProperties;
}

export type ExtractProperties<T> = T extends GraphNode<infer P> ? P : never;

export interface KnowledgeGraphExplorerProps<TNode extends GraphNode> {
  nodes: TNode[];
  onNodeSelect: (node: TNode) => void;
  filterCriteria?: (properties: ExtractProperties<TNode>) => boolean;
}

export function KnowledgeGraphExplorer<TNode extends GraphNode>({
  nodes,
  onNodeSelect,
  filterCriteria,
}: KnowledgeGraphExplorerProps<TNode>) {
  const processedNodes = filterCriteria
    ? nodes.filter((node) => filterCriteria(node.properties))
    : nodes;

  return (
    <div className="knowledge-graph-explorer">
      <h2>Knowledge Graph Explorer</h2>
      <ul>
        {processedNodes.map((node) => (
          <li key={node.id} onClick={() => onNodeSelect(node)}>
            <span>ID: {node.id}</span>
            <div>
              {/* Type-safe property rendering */}
              {Object.entries(node.properties).map(([key, value]) => (
                <span key={key}> {key}: {String(value)} </span>
              ))}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
