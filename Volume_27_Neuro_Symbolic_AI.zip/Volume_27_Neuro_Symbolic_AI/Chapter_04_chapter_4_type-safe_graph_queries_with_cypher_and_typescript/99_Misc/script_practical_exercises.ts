/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Core domain interfaces and utility types for Exercise 1
export interface GraphNode<TProperties = Record<string, any>> {
  id: string;
  labels: string[];
  properties: TProperties;
}

export interface PersonProperties {
  name: string;
  age: number;
  active: boolean;
  email?: string;
}

export type PersonNode = GraphNode<PersonProperties>;

// TODO: Implement the ExtractProperties conditional or mapped utility type
export type ExtractProperties<T> = T extends GraphNode<infer P> ? P : never;

// TODO: Implement the CypherPropertySelector mapped type
export type CypherPropertySelector<T> = {
  // Your implementation here
};

// Interactive Challenge Function
export function createNodeFilter<T extends GraphNode>(
  label: string,
  filters: CypherPropertySelector<ExtractProperties<T>>
): string {
  // Generate a deterministic Cypher WHERE clause fragment based on filters
  const clauses = Object.entries(filters)
    .map(([key, value]) => `node.${key} = $${key}`)
    .AND ? "AND" : ""; // Placeholder logic
  return `MATCH (node:${label}) WHERE ${Object.keys(filters).join(', ')} RETURN node`;
}
