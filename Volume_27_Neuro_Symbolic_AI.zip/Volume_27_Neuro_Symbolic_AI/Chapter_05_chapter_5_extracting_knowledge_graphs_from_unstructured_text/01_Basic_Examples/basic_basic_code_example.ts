/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from "zod";
import OpenAI from "openai";
import { zodToJsonSchema } from "zod-to-json-schema";

/**
 * Initialize the OpenAI client for our SaaS backend infrastructure.
 * This assumes process.env.OPENAI_API_KEY is configured correctly.
 */
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "dummy-key-for-compilation",
});

/**
 * 1. Define the Zod Schema for Knowledge Graph Extraction
 * 
 * We enforce a strict structure consisting of Nodes and Edges. 
 * This ensures the LLM cannot return arbitrary free-form text or 
 * unstructured JSON objects that would break our graph database ingest pipeline.
 */
const KnowledgeGraphSchema = z.object({
  nodes: z.array(
    z.object({
      id: z.string().describe("Unique identifier or slug for the entity (e.g., 'user_123', 'feature_auth')"),
      label: z.string().describe("The semantic category of the node (e.g., 'User', 'Feature', 'Bug', 'Product')"),
      properties: z.record(z.string(), z.any()).describe("Key-value attributes associated with this entity"),
    })
  ).describe("The collection of discrete entities extracted from the text."),
  
  edges: z.array(
    z.object({
      source: z.string().describe("The ID of the source node where the relationship originates"),
      target: z.string().describe("The ID of the target node where the relationship points"),
      relation: z.string().describe("The uppercase verb phrase defining the edge type (e.g., 'EXPERIENCES', 'AFFECTS', 'OWNS')"),
      properties: z.record(z.string(), z.any()).optional().describe("Optional metadata about the relationship"),
    })
  ).describe("The directed connections representing relationships between the extracted nodes."),
});

// TypeScript type inference derived directly from our runtime schema
type KnowledgeGraphExtraction = z.infer<typeof KnowledgeGraphSchema>;

/**
 * 2. Define the SaaS Ingestion Pipeline Function
 * 
 * Takes raw, unstructured customer feedback and returns a guaranteed 
 * typesafe Knowledge Graph payload ready for GraphDB insertion.
 * 
 * @param unstructuredText - The raw string input from user feedback forms.
 */
async function extractKnowledgeGraph(unstructuredText: string): Promise<KnowledgeGraphExtraction> {
  // Convert our Zod schema into a JSON Schema format supported by OpenAI function calling or response formatting
  const jsonSchema = zodToJsonSchema(KnowledgeGraphSchema, { name: "KnowledgeGraph" });

  try {
    // Call the OpenAI chat completion endpoint with structured JSON outputs enforced
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert enterprise knowledge engineer. Extract entities and relationships from the provided text to form a deterministic Knowledge Graph. You must strictly adhere to the provided JSON schema."
        },
        {
          role: "user",
          content: unstructuredText
        }
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "KnowledgeGraph",
          strict: true,
          schema: jsonSchema.definitions?.KnowledgeGraph || jsonSchema,
        }
      },
      temperature: 0.0 // Zero temperature ensures deterministic, non-creative extractions
    });

    const rawContent = response.choices[0]?.message?.content;
    
    if (!rawContent) {
      throw new Error("Failed to extract knowledge graph: Received empty response from LLM.");
    }

    // Parse the raw JSON string returned by the model
    const parsedJson = JSON.parse(rawContent);

    /**
     * 3. Runtime Validation via Zod
     * 
     * Even though OpenAI's strict JSON mode guarantees schema compliance, 
     * running the data through Zod's .parse() guarantees complete type safety 
     * and triggers automatic TypeScript type narrowing.
     */
    const validatedGraph = KnowledgeGraphSchema.parse(parsedJson);

    return validatedGraph;

  } catch (error) {
    console.error("Error during Knowledge Graph extraction pipeline:", error);
    throw error;
  }
}

/**
 * 4. Execution Example for Our SaaS Workflow
 */
async function runDemo() {
  const sampleCustomerFeedback = `
    Customer alice_99 reported that the OAuth login module crashed 
    frequently when attempting single sign-on with Google Workspace. 
    Developer bob_dev investigated and noted that the OAuth token 
    service needs an immediate patch in version 2.1.4.
  `;

  console.log("Analyzing unstructured feedback and generating Knowledge Graph...");
  
  const graphResult = await extractKnowledgeGraph(sampleCustomerFeedback);

  console.log("\n--- Successfully Extracted Knowledge Graph ---");
  console.log(JSON.stringify(graphResult, null, 2));
}

// Execute the demo if run directly
if (require.main === module) {
  runDemo();
}
