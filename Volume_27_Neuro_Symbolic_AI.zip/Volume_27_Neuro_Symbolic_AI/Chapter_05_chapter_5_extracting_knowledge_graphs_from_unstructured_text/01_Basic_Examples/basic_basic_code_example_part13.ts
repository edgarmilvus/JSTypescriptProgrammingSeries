/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part13.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// COMMON PITFALL 1: HALLUCINATED JSON TYPES
// ==========================================
// BAD: Relying solely on JSON.parse() without runtime validation
async function unsafeExtraction(text: string) {
  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: text }],
    // Missing response_format json_schema! The model might return markdown or invalid structures.
  });
  
  // Type assertion lies to TypeScript compiler:
  return JSON.parse(response.choices[0].message.content!) as KnowledgeGraphExtraction;
  // Runtime crash waiting to happen if fields are missing or mistyped!
}

// GOOD: Enforce strict schema validation at both API and runtime boundaries
async function safeExtraction(text: string) {
  // Use response_format json_schema AND Zod .parse() as shown in the main example.
}


// =====================================================
// COMMON PITFALL 2: VERCEL / SERVERLESS TIMEOUTS (LONG TEXTS)
// =====================================================
// BAD: Passing multi-page documents directly into a single synchronous API call
async function processMassiveDocument(documentText: string) {
  // If the document is 50,000 words, GPT-4o output token generation 
  // can take 30+ seconds, exceeding standard serverless function timeouts (10s - 15s).
  return await extractKnowledgeGraph(documentText);
}

// GOOD: Implement chunking and asynchronous background job queues (e.g., BullMQ / Inngest)
async function processMassiveDocumentResiliently(documentText: string) {
  const chunks = splitTextIntoSemanticParagraphs(documentText, 4000);
  
  // Push jobs to background workers instead of blocking the HTTP request thread
  for (const chunk of chunks) {
    await backgroundQueue.add("extract-kg-chunk", { text: chunk });
  }
}


// ==========================================================
// COMMON PITFALL 3: UNBOUNDED ASYNC/AWAIT LOOPS (RATE LIMITS)
// ==========================================================
// BAD: Unthrottled Promise.all over large arrays of texts
async function processBatchUnsafe(feedbackItems: string[]) {
  // Will instantly trigger OpenAI 429 Too Many Requests errors!
  return await Promise.all(feedbackItems.map(item => extractKnowledgeGraph(item)));
}

// GOOD: Use concurrency control or batching libraries (e.g., p-limit)
import pLimit from "p-limit";
const limit = pLimit(5); // Maximum 5 concurrent LLM requests

async function processBatchSafe(feedbackItems: string[]) {
  const tasks = feedbackItems.map(item => 
    limit(() => extractKnowledgeGraph(item))
  );
  return await Promise.all(tasks);
}


// =========================================================
// COMMON PITFALL 4: GRAPH SCHEMA FRAGMENTATION (ID MISMATCHES)
// =========================================================
// BAD: Allowing the LLM to invent arbitrary node IDs without normalization
// e.g., Node 1 ID: "Alice Smith", Node 2 ID: "alice.smith@company.com"
// This creates duplicate nodes in the GraphDB instead of merging them.

// GOOD: Pre-process or normalize entity IDs via deterministic slugification functions
function normalizeEntityId(rawName: string): string {
  return rawName.toLowerCase().trim().replace(/[^a-z0-9_]/g, "_");
}
