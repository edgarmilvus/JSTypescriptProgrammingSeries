/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';

/**
 * ---------------------------------------------------------------------------
 * DOMAIN MODELS & ZOD SCHEMAS (Strict Zero-Hallucination Boundaries)
 * ---------------------------------------------------------------------------
 * We define exact structural contracts for the LLM output. By utilizing Zod,
 * we guarantee that downstream graph databases never receive malformed nodes 
 * or unconstrained edge types.
*/

export const EntityTypeSchema = z.enum([
  'PERSON',
  'ORGANIZATION',
  'SYSTEM',
  'CONCEPT',
  'METRIC'
]);

export const RelationshipTypeSchema = z.enum([
  'DEPENDS_ON',
  'MANAGES',
  'MONITORS',
  'COMMUNICATES_WITH',
  'OWNS'
]);

export const NodeSchema = z.object({
  id: z.string().describe("A unique, snake_case identifier for the entity (e.g., 'auth_service')."),
  name: z.string().describe("The human-readable name of the entity."),
  type: EntityTypeSchema,
  properties: z.record(z.string(), z.string()).optional().describe("Key-value attributes extracted from the text.")
});

export const EdgeSchema = z.object({
  sourceId: z.string().describe("The 'id' of the source Node."),
  targetId: z.string().describe("The 'id' of the target Node."),
  type: RelationshipTypeSchema,
  weight: z.number().min(0).max(1).describe("Confidence score of this relationship between 0.0 and 1.0.")
});

export const KnowledgeGraphExtractionSchema = z.object({
  nodes: z.array(NodeSchema).describe("List of distinct entities discovered in the text."),
  edges: z.array(EdgeSchema).describe("List of directed relationships connecting the nodes.")
});

export type ExtractedKnowledgeGraph = z.infer<typeof KnowledgeGraphExtractionSchema>;
export type ExtractedNode = z.infer<typeof NodeSchema>;
export type ExtractedEdge = z.infer<typeof EdgeSchema>;


/**
 * ---------------------------------------------------------------------------
 * INTERFACES & CONFIGURATION (SRP Compliance)
 * ---------------------------------------------------------------------------
*/

export interface ILLMProvider {
  extractStructuredData<T>(prompt: string, schema: z.ZodSchema<T>): Promise<T>;
}

export interface IGraphPersistenceService {
  persistGraph(graph: ExtractedKnowledgeGraph): Promise<void>;
}


/**
 * ---------------------------------------------------------------------------
 * KNOWLEDGE EXTRACTION SERVICE (Inference & Validation Layer)
 * ---------------------------------------------------------------------------
*/

class LLMKnowledgeExtractionService {
  constructor(private readonly llmProvider: ILLMProvider) {}

  /**
   * Parses raw unstructured enterprise text into a validated knowledge graph structure.
   */
  public async extractFromText(rawText: string): Promise<ExtractedKnowledgeGraph> {
    const systemPrompt = `
      You are an advanced enterprise knowledge extraction engine. 
      Analyze the provided text and extract all relevant entities and relationships.
      Adhere strictly to the provided structural schema. Do not invent entity types or relationships outside the allowed enums.
    `;

    const userPrompt = `Text to analyze:\n"""\n${rawText}\n"""`;
    const combinedPrompt = `${systemPrompt}\n\n${userPrompt}`;

    // Execute extraction via LLM with Zod schema validation
    const rawExtraction = await this.llmProvider.extractStructuredData(
      combinedPrompt,
      KnowledgeGraphExtractionSchema
    );

    // Post-processing sanity check: Ensure all edge references map to existing nodes
    this.validateGraphIntegrity(rawExtraction);

    return rawExtraction;
  }

  /**
   * Deterministic graph validation ensuring referential integrity.
   */
  private validateGraphIntegrity(graph: ExtractedKnowledgeGraph): void {
    const nodeIds = new Set(graph.nodes.map(n => n.id));

    for (const edge of graph.edges) {
      if (!nodeIds.has(edge.sourceId)) {
        throw new Error(`Graph Integrity Error: Edge references missing source node ID '${edge.sourceId}'`);
      }
      if (!nodeIds.has(edge.targetId)) {
        throw new Error(`Graph Integrity Error: Edge references missing target node ID '${edge.targetId}'`);
      }
    }
  }
}


/**
 * ---------------------------------------------------------------------------
 * MOCK LLM PROVIDER (Simulating Structured Generation & Zod Validation)
 * ---------------------------------------------------------------------------
*/

class MockOpenAIZodProvider implements ILLMProvider {
  public async extractStructuredData<T>(prompt: string, schema: z.ZodSchema<T>): Promise<T> {
    // In a live production environment, this invokes OpenAI Function Calling,
    // Anthropic Tool Use, or Outlines-backed structured decoding.
    
    const mockUnvalidatedPayload = {
      nodes: [
        { id: "api_gateway", name: "API Gateway", type: "SYSTEM", properties: { version: "2.1" } },
        { id: "auth_service", name: "Authentication Service", type: "SYSTEM", properties: { lang: "TypeScript" } },
        { id: "alice_dev", name: "Alice Smith", type: "PERSON", properties: { role: "Lead Architect" } }
      ],
      edges: [
        { sourceId: "api_gateway", targetId: "auth_service", type: "DEPENDS_ON", weight: 0.95 },
        { sourceId: "alice_dev", targetId: "auth_service", type: "MANAGES", weight: 1.0 }
      ]
    };

    // Parse through Zod schema to enforce runtime safety and zero hallucinations
    const validationResult = schema.safeParse(mockUnvalidatedPayload);

    if (!validationResult.success) {
      throw new Error(`LLM Output failed schema validation: ${JSON.stringify(validationResult.error.format())}`);
    }

    return validationResult.data;
  }
}


/**
 * ---------------------------------------------------------------------------
 * GRAPH DATABASE PERSISTENCE ADAPTER (GraphDB Integration)
 * ---------------------------------------------------------------------------
*/

class Neo4jPersistenceAdapter implements IGraphPersistenceService {
  public async persistGraph(graph: ExtractedKnowledgeGraph): Promise<void> {
    console.log(`[GraphDB] Beginning transaction for ${graph.nodes.length} nodes and ${graph.edges.length} edges...`);

    // Translate nodes to Cypher statements
    for (const node of graph.nodes) {
      const cypherNode = `MERGE (n:${node.type} {id: $id}) SET n.name = $name, n += $properties`;
      console.log(`Executing Cypher: ${cypherNode} with params:`, { id: node.id, name: node.name, properties: node.properties ?? {} });
    }

    // Translate edges to Cypher statements
    for (const edge of graph.edges) {
      const cypherEdge = `
        MATCH (s {id: $sourceId}), (t {id: $targetId})
        MERGE (s)-[r:${edge.type}]->(t)
        SET r.weight = $weight
      `;
      console.log(`Executing Cypher: ${cypherEdge.trim()} with params:`, { sourceId: edge.sourceId, targetId: edge.targetId, weight: edge.weight });
    }

    console.log(`[GraphDB] Transaction committed successfully.`);
  }
}


/**
 * ---------------------------------------------------------------------------
 * NEXT.JS API ROUTE HANDLER (Composition Root)
 * ---------------------------------------------------------------------------
*/

export async function POST(request: Request): Promise<Response> {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text || typeof text !== 'string') {
      return new Response(JSON.stringify({ error: "Invalid request payload: 'text' field is required." }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Initialize decoupled architectural services following SRP
    const llmProvider = new MockOpenAIZodProvider();
    const extractionService = new LLMKnowledgeExtractionService(llmProvider);
    const persistenceService = new Neo4jPersistenceAdapter();

    // 1. Extract validated structured Knowledge Graph from unstructured text
    const extractedGraph = await extractionService.extractFromText(text);

    // 2. Persist deterministic graph structures into GraphDB
    await persistenceService.persistGraph(extractedGraph);

    return new Response(JSON.stringify({ 
      success: true, 
      message: "Knowledge graph successfully extracted, validated, and persisted.",
      data: extractedGraph 
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error("Knowledge Extraction Pipeline Error:", error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message || "Internal server error during knowledge extraction." 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
