/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Define schemas adhering strictly to the requirements
export const EntitySchema = z.object({
  id: z.string().describe("A unique identifier for the entity, typically lowercase kebab-case."),
  name: z.string().describe("The canonical name of the entity."),
  type: z.enum(['PERSON', 'ORGANIZATION', 'TECHNOLOGY', 'CONCEPT']).describe("The categorical classification of the entity."),
  attributes: z.record(z.string()).optional().describe("Key-value metadata attributes associated with the entity."),
});

export const RelationshipSchema = z.object({
  sourceId: z.string().describe("The unique id of the source entity."),
  targetId: z.string().describe("The unique id of the target entity."),
  predicate: z.string().describe("The relationship verb or predicate connecting source and target (e.g., ACQUIRES)."),
  confidence: z.number().min(0).max(1).describe("Confidence score of the relationship between 0 and 1."),
});

export const KnowledgeGraphPayloadSchema = z.object({
  entities: z.array(EntitySchema),
  relationships: z.array(RelationshipSchema),
});

export type Entity = z.infer<typeof EntitySchema>;
export type Relationship = z.infer<typeof RelationshipSchema>;
export type KnowledgeGraphPayload = z.infer<typeof KnowledgeGraphPayloadSchema>;

/**
 * Normalizes entity names by stripping capitalization discrepancies, punctuation, 
 * and common corporate suffixes, then merges duplicate definitions.
 */
export function normalizeAndMergeGraph(payload: KnowledgeGraphPayload): KnowledgeGraphPayload {
  const entityMap = new Map<string, Entity>();
  const idMapping = new Map<string, string>(); // Maps old IDs to canonical merged IDs

  for (const entity of payload.entities) {
    // Clean name: lowercasings, strip punctuation, remove corporate suffixes
    const cleanedName = entity.name
      .toLowerCase()
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "")
      .replace(/\b(inc|llc|corp|ltd|co)\b/g, "")
      .trim()
      .replace(/\s+/g, " ");

    const canonicalId = cleanedName.replace(/\s+/g, "-");
    
    if (entityMap.has(canonicalId)) {
      // Merge attributes if duplicate exists
      const existing = entityMap.get(canonicalId)!;
      existing.attributes = { ...existing.attributes, ...entity.attributes };
      idMapping.set(entity.id, existing.id);
    } else {
      const normalizedEntity: Entity = {
        ...entity,
        id: canonicalId,
        name: entity.name.trim(), // Keep original clean capitalization for presentation
      };
      entityMap.set(canonicalId, normalizedEntity);
      idMapping.set(entity.id, canonicalId);
    }
  }

  // Remap relationships to point to the new canonical entity IDs and deduplicate
  const relationshipMap = new Map<string, Relationship>();
  for (const rel of payload.relationships) {
    const newSourceId = idMapping.get(rel.sourceId) || rel.sourceId;
    const newTargetId = idMapping.get(rel.targetId) || rel.targetId;

    // Avoid self-referential loops created by normalization collapse
    if (newSourceId === newTargetId) continue;

    const key = `${newSourceId}-${rel.predicate}-${newTargetId}`;
    if (!relationshipMap.has(key) || relationshipMap.get(key)!.confidence < rel.confidence) {
      relationshipMap.set(key, {
        ...rel,
        sourceId: newSourceId,
        targetId: newTargetId,
      });
    }
  }

  return {
    entities: Array.from(entityMap.values()),
    relationships: Array.from(relationshipMap.values()),
  };
}

export async function extractKnowledgeGraph(text: string): Promise<KnowledgeGraphPayload> {
  // Mock LLM Client invocation or structured generation call
  // In production, integrate OpenAI SDK with .beta.chat.completions.parse()
  const rawLLMOutput = {
    entities: [
      { id: "acme-inc", name: "Acme Inc.", type: "ORGANIZATION", attributes: { sector: "Manufacturing" } },
      { id: "globex", name: "Globex Corp", type: "ORGANIZATION", attributes: { sector: "Technology" } }
    ],
    relationships: [
      { sourceId: "acme-inc", targetId: "globex", predicate: "ACQUIRES", confidence: 0.95 }
    ]
  };

  try {
    // Validate output against Zod schema
    const parsedPayload = KnowledgeGraphPayloadSchema.parse(rawLLMOutput);
    
    // Apply the preprocessing and entity-resolution challenge requirement
    return normalizeAndMergeGraph(parsedPayload);
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error("Schema validation failed during graph extraction:", JSON.stringify(error.errors, null, 2));
      // Implement fallback or retry logic here
    }
    throw error;
  }
}
