/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { KnowledgeGraphPayload, Entity, Relationship } from './extractor';

export interface CypherStatement {
  query: string;
  params: Record<string, any>;
}

/**
 * Generates idempotent, parameterized Cypher statements for entities and relationships.
 */
export function generateCypherStatements(payload: KnowledgeGraphPayload): CypherStatement[] {
  const statements: CypherStatement[] = [];

  // 1. Generate statements for Entities using MERGE
  for (const entity of payload.entities) {
    const query = `
      MERGE (n:Entity {id: $id})
      SET n.name = $name,
          n.type = $type,
          n += $attributes
    `;
    statements.push({
      query: query.trim(),
      params: {
        id: entity.id,
        name: entity.name,
        type: entity.type,
        attributes: entity.attributes || {},
      },
    });
  }

  // 2. Generate statements for Relationships
  for (const rel of payload.relationships) {
    // Dynamically handling relationship types safely requires query construction with validated enums/strings
    const safePredicate = rel.predicate.replace(/[^a-zA-Z0-9_]/g, "_").toUpperCase();
    const query = `
      MATCH (source:Entity {id: $sourceId})
      MATCH (target:Entity {id: $targetId})
      MERGE (source)-[r:${safePredicate}]->(target)
      SET r.confidence = $confidence
    `;
    statements.push({
      query: query.trim(),
      params: {
        sourceId: rel.sourceId,
        targetId: rel.targetId,
        confidence: rel.confidence,
      },
    });
  }

  return statements;
}

/**
 * Interactive Challenge: Detects cyclical dependencies (DFS-based cycle check).
 * Strips the lowest-confidence edge if a cycle is detected.
 */
export function detectAndMitigateCycles(relationships: Relationship[]): Relationship[] {
  const adjList = new Map<string, Set<string>>();
  for (const rel of relationships) {
    if (!adjList.has(rel.sourceId)) adjList.set(rel.sourceId, new Set());
    adjList.get(rel.sourceId)!.add(rel.targetId);
  }

  const visited = new Set<string>();
  const recStack = new Set<string>();
  let hasCycle = false;

  function dfs(node: string): boolean {
    visited.add(node);
    recStack.add(node);

    const neighbors = adjList.get(node);
    if (neighbors) {
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          if (dfs(neighbor)) return true;
        } else if (recStack.has(neighbor)) {
          hasCycle = true;
          return true;
        }
      }
    }
    recStack.delete(node);
    return false;
  }

  for (const node of adjList.keys()) {
    if (!visited.has(node)) {
      if (dfs(node)) break;
    }
  }

  if (hasCycle) {
    console.warn("Structured Warning: Cyclical path detected in Knowledge Graph payload!");
    // Sort relationships ascending by confidence and remove the lowest-confidence edge
    const sorted = [...relationships].sort((a, b) => a.confidence - b.confidence);
    const removedEdge = sorted.shift();
    console.warn(`Stripped lowest-confidence edge to break cycle:`, removedEdge);
    return sorted;
  }

  return relationships;
}

/**
 * Executes generated statements within a managed database transaction.
 */
export async function persistGraph(payload: KnowledgeGraphPayload, driver: any): Promise<void> {
  // Apply cycle detection mitigation before persistence
  const sanitizedRelationships = detectAndMitigateCycles(payload.relationships);
  const sanitizedPayload: KnowledgeGraphPayload = {
    ...payload,
    relationships: sanitizedRelationships,
  };

  const statements = generateCypherStatements(sanitizedPayload);
  const session = driver.session();
  const tx = session.beginTransaction();

  try {
    for (const stmt of statements) {
      await tx.run(stmt.query, stmt.params);
    }
    await tx.commit();
  } catch (error) {
    console.error("Transaction failed, rolling back graph batch persistence:", error);
    await tx.rollback();
    throw error;
  } finally {
    await session.close();
  }
}
