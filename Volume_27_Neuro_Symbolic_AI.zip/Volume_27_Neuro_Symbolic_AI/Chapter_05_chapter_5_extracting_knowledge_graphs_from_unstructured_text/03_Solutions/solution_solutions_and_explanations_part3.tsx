/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { KnowledgeGraphPayload, Entity, Relationship } from './extractor';

export interface KnowledgeGraphExplorerProps {
  payload: KnowledgeGraphPayload;
  onNodeSelect?: (entity: Entity) => void;
  onRelationshipSelect?: (relationship: Relationship) => void;
}

export const KnowledgeGraphExplorer: React.FC<KnowledgeGraphExplorerProps> = ({
  payload,
  onNodeSelect,
  onRelationshipSelect,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [minConfidence, setMinConfidence] = useState<number>(0.0);
  const [selectedNode, setSelectedNode] = useState<Entity | null>(null);
  const [selectedRelationship, setSelectedRelationship] = useState<Relationship | null>(null);

  // Filter entities and relationships dynamically using useMemo hooks
  const filteredData = useMemo(() => {
    const filteredRelationships = payload.relationships.filter(
      (rel) => rel.confidence >= minConfidence
    );

    // Find entity IDs that remain connected or exist matching search query
    const filteredEntities = payload.entities.filter((entity) => {
      const matchesSearch =
        entity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entity.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'ALL' || entity.type === selectedCategory;
      return matchesSearch && matchesCategory;
    });

    return { entities: filteredEntities, relationships: filteredRelationships };
  }, [payload, searchTerm, selectedCategory, minConfidence]);

  const handleNodeClick = (entity: Entity) => {
    setSelectedNode(entity);
    setSelectedRelationship(null);
    if (onNodeSelect) onNodeSelect(entity);
  };

  const handleRelationshipClick = (rel: Relationship) => {
    setSelectedRelationship(rel);
    setSelectedNode(null);
    if (onRelationshipSelect) onRelationshipSelect(rel);
  };

  return (
    <div className="knowledge-graph-explorer-container" style={{ display: 'flex', height: '100vh', fontFamily: 'sans-serif' }}>
      
      {/* Primary Canvas & Controls Panel */}
      <div className="graph-canvas-panel" style={{ flex: 3, display: 'flex', flexDirection: 'column', position: 'relative', background: '#f9f9f9' }}>
        
        {/* Controls Toolbar */}
        <div style={{ padding: '1rem', borderBottom: '1px solid #ddd', display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <input
            type="text"
            placeholder="Search entities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          />
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          >
            <option value="ALL">All Categories</option>
            <option value="PERSON">Person</option>
            <option value="ORGANIZATION">Organization</option>
            <option value="TECHNOLOGY">Technology</option>
            <option value="CONCEPT">Concept</option>
          </select>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <label htmlFor="confidenceSlider" style={{ fontSize: '0.85rem' }}>Min Confidence: {minConfidence}</label>
            <input
              id="confidenceSlider"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={minConfidence}
              onChange={(e) => setMinConfidence(parseFloat(e.target.value))}
            />
          </div>
        </div>

        {/* Canvas Area Mockup */}
        <div style={{ flex: 1, padding: '2rem', overflowY: 'auto' }}>
          <h4>Entities Canvas ({filteredData.entities.length})</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
            {filteredData.entities.map((entity) => (
              <div
                key={entity.id}
                onClick={() => handleNodeClick(entity)}
                style={{
                  padding: '1rem',
                  background: selectedNode?.id === entity.id ? '#e0f2fe' : '#fff',
                  border: '1px solid #cbd5e1',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                }}
              >
                <strong>{entity.name}</strong>
                <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>{entity.type}</div>
              </div>
            ))}
          </div>

          <h4 style={{ marginTop: '2rem' }}>Relationships ({filteredData.relationships.length})</h4>
          <ul>
            {filteredData.relationships.map((rel, idx) => (
              <li
                key={idx}
                onClick={() => handleRelationshipClick(rel)}
                style={{ cursor: 'pointer', marginBottom: '0.5rem', color: selectedRelationship === rel ? '#0284c7' : '#33415') }
              }
            >
              <code>{rel.sourceId}</code> ➔ <strong>{rel.predicate}</strong> ➔ <code>{rel.targetId}</code> (Conf: {rel.confidence})
            </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Secondary Inspector Drawer */}
      <div className="inspector-panel" style={{ flex: 1, padding: '1.5rem', borderLeft: '1px solid #ccc', background: '#fff', overflowY: 'auto' }}>
        <h3>Inspector Drawer</h3>
        {selectedNode ? (
          <div>
            <h4>Entity Details</h4>
            <p><strong>ID:</strong> {selectedNode.id}</p>
            <p><strong>Name:</strong> {selectedNode.name}</p>
            <p><strong>Type:</strong> {selectedNode.type}</p>
            <h5>Attributes:</h5>
            <pre style={{ background: '#f1f5f9', padding: '0.5rem', borderRadius: '4px', fontSize: '0.8rem' }}>
              {JSON.stringify(selectedNode.attributes || {}, null, 2)}
            </pre>
          </div>
        ) : selectedRelationship ? (
          <div>
            <h4>Relationship Details</h4>
            <p><strong>Source:</strong> {selectedRelationship.sourceId}</p>
            <p><strong>Target:</strong> {selectedRelationship.targetId}</p>
            <p><strong>Predicate:</strong> {selectedRelationship.predicate}</p>
            <p><strong>Confidence:</strong> {selectedRelationship.confidence}</p>
          </div>
        ) : (
          <p style={{ color: '#94a3b8' }}>Select a node or relationship on the canvas to inspect its metadata.</p>
        )}
      </div>

    </div>
  );
};
