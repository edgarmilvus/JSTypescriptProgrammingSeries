/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// extractionService.ts
import { KnowledgeGraphPayload, KnowledgeGraphPayloadSchema } from './extractor';

export async function extractGraphFromChunk(textChunk: string): Promise<KnowledgeGraphPayload> {
  // Simulated LLM structural extraction call
  const rawOutput = {
    entities: [{ id: "entity-1", name: "Sample Entity", type: "CONCEPT" }],
    relationships: []
  };
  return KnowledgeGraphPayloadSchema.parse(rawOutput);
}

// embeddingService.ts
export async function generateChunkEmbedding(textChunk: string): Promise<number[]> {
  // Simulated API call to text-embedding-3-small
  // Returns a vector array of floats (e.g., dimensionality 1536)
  return new Array(1536).fill(0.123);
}

// orchestrator.ts
import { extractGraphFromChunk } from './extractionService';
import { generateChunkEmbedding } from './embeddingService';
import { persistGraph } from './graphMapper';
import { KnowledgeGraphPayload } from './extractor';
import * as crypto from 'crypto';

interface CachedChunkData {
  payload: KnowledgeGraphPayload;
  embedding: number[];
}

// In-memory cache store mapped by SHA-256 chunk hash
const processingCache = new Map<string, CachedChunkData>();

/**
 * Utility function to split documents into context-safe token windows/paragraphs.
 */
function chunkDocument(text: string, maxChunkLength: number = 500): string[] {
  const paragraphs = text.split(/\n\s*\n/);
  const chunks: string[] = [];
  
  for (const para of paragraphs) {
    if (para.length > maxChunkLength) {
      // Simple character-window sub-chunking fallback
      for (let i = 0; i < para.length; i += maxChunkLength) {
        chunks.push(para.substring(i, i + maxChunkLength));
      }
    } else {
      chunks.push(para);
    }
  }
  return chunks;
}

/**
 * Executes an asynchronous task with exponential backoff and retry strategy.
 */
async function retryWithBackoff<T>(fn: () => Promise<T>, retries: number = 3, delay: number = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (retries <= 0) throw error;
    console.warn(`Operation failed. Retrying in ${delay}ms... Error:`, error);
    await new Promise((resolve) => setTimeout(resolve, delay));
    return retryWithBackoff(fn, retries - 1, delay * 2);
  }
}

/**
 * Coordinates end-to-end document processing: chunking, concurrency, caching, and persistence.
 */
export async function processDocumentPipeline(documentText: string, driver: any): Promise<void> {
  const chunks = chunkDocument(documentText);
  console.log(`Starting pipeline processing for ${chunks.length} document chunks.`);

  for (const [index, chunk] of chunks.entries()) {
    // 1. Compute SHA-256 hash of the chunk text for caching
    const chunkHash = crypto.createHash('sha256').update(chunk).digest('hex');

    let payload: KnowledgeGraphPayload;
    let embedding: number[];

    // 2. Check cache for hit
    if (processingCache.has(chunkHash)) {
      console.log(`Cache hit for chunk [${index + 1}/${chunks.length}]. Bypassing LLM & embedding generation.`);
      const cached = processingCache.get(chunkHash)!;
      payload = cached.payload;
      embedding = cached.embedding;
    } else {
      console.log(`Cache miss for chunk [${index + 1}/${chunks.length}]. Invoking services concurrently.`);
      
      try {
        // 3. Concurrently invoke extraction and embedding services with retry resiliency
        [payload, embedding] = await retryWithBackoff(async () => {
          return await Promise.all([
            extractGraphFromChunk(chunk),
            generateChunkEmbedding(chunk)
          ]);
        });

        // Store result in cache
        processingCache.set(chunkHash, { payload, embedding });
      } catch (error) {
        console.error(`Pipeline failure at chunk [${index + 1}]. Aborting transaction batch.`, error);
        throw error;
      }
    }

    // 4. Persist validated graph payload into GraphDB
    await persistGraph(payload, driver);
    console.log(`Successfully persisted graph and vector metadata for chunk [${index + 1}].`);
  }
}
