/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file compliance-kb.ts
 * @description A self-contained TypeScript module demonstrating RDF triple creation, 
 * JSON-LD parsing, and deterministic graph querying for a SaaS compliance platform.
 */

import { Store, DataFactory, Parser, Writer } from 'n3';
const { namedNode, literal, quad } = DataFactory;

// Define namespaces for our regulatory ontology
const EX = 'http://example.org/compliance#';
const RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#';
const RDFS = 'http://www.w3.org/2000/01/rdf-schema#';

/**
 * Interface representing a verified compliance check result.
 */
interface ComplianceCheckResult {
  regulation: string;
  policy: string;
  status: string;
}

/**
 * Initializes an in-memory RDF Store and loads foundational compliance triples.
 */
async function initializeComplianceKnowledgeBase(): Promise<Store> {
  // 1. Create an in-memory N3 store to act as our deterministic graph database
  const store = new Store();

  // 2. Define raw RDF triples using Turtle syntax representing regulations and internal policies
  const ttlData = `
    @prefix ex: <http://example.org/compliance#> .
    @prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
    @prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

    ex:GDPR_Art32 a ex:Regulation ;
        rdfs:label "GDPR Article 32 - Security of Processing" ;
        ex:requiresControl ex:EncryptionAtRest .

    ex:InternalDataPolicy_V2 a ex:CorporatePolicy ;
        rdfs:label "Internal Data Security Policy v2" ;
        ex:satisfiesControl ex:EncryptionAtRest .

    ex:EncryptionAtRest a ex:SecurityControl ;
        rdfs:label "AES-256 Encryption for Database Storage" .
  `;

  // 3. Parse the Turtle data into the N3 Store asynchronously
  await new Promise<void>((resolve, reject) => {
    const parser = new Parser();
    parser.parse(ttlData, (error, quadItem) => {
      if (error) {
        reject(error);
      } else if (quadItem) {
        store.addQuad(quadItem);
      } else {
        resolve();
      }
    });
  });

  return store;
}

/**
 * Serializes the current graph store into a JSON-LD document suitable for API transmission.
 */
async function exportToJsonLd(store: Store): Promise<string> {
  const quads = store.getQuads(null, null, null, null);
  
  // Define a JSON-LD framing/context mapping
  const context = {
    ex: "http://example.org/compliance#",
    label: "http://www.w3.org/2000/01/rdf-schema#label",
    requiresControl: { "@id": "http://example.org/compliance#requiresControl", "@type": "@id" },
    satisfiesControl: { "@id": "http://example.org/compliance#satisfiesControl", "@type": "@id" }
  };

  return new Promise((resolve, reject) => {
    const writer = new Writer({ format: 'application/ld+json', prefixes: { ex: EX, rdfs: RDFS } });
    writer.addQuads(quads);
    writer.end((error, result) => {
      if (error) reject(error);
      else resolve(result || '');
    });
  });
}

/**
 * Deterministically queries the knowledge base to find if an internal policy satisfies a regulation.
 */
function verifyCompliance(store: Store, regulationLocalName: string): ComplianceCheckResult[] {
  const results: ComplianceCheckResult[] = [];
  
  const regNode = namedNode(`${EX}${regulationLocalName}`);
  
  // Find all controls required by the regulation
  const requiredControlQuads = store.getQuads(regNode, namedNode(`${EX}requiresControl`), null, null);

  for (const reqQuad of requiredControlQuads) {
    const controlNode = reqQuad.object;
    
    // Find all policies that satisfy this control
    const satisfyingPolicyQuads = store.getQuads(null, namedNode(`${EX}satisfiesControl`), controlNode, null);

    for (const polQuad of satisfyingPolicyQuads) {
      const policyNode = polQuad.subject;

      results.push({
        regulation: regNode.value,
        policy: policyNode.value,
        status: "COMPLIANT"
      });
    }
  }

  return results;
}

/**
 * Main execution loop demonstrating the SaaS workflow.
 */
async function runComplianceDemo() {
  console.log("Initializing Semantic Compliance Knowledge Base...");
  const kbStore = await initializeComplianceKnowledgeBase();

  console.log(`Knowledge Base loaded with ${kbStore.size} triples.`);

  console.log("\nExecuting Deterministic Compliance Verification for GDPR_Art32...");
  const complianceAudit = verifyCompliance(kbStore, "GDPR_Art32");

  console.log("Audit Results (Zero Hallucination):");
  console.log(JSON.stringify(complianceAudit, null, 2));

  console.log("\nExporting Graph to JSON-LD for Downstream Microservices...");
  const jsonLdOutput = await exportToJsonLd(kbStore);
  console.log(jsonLdOutput.substring(0, 450) + "...\n[Truncated for Display]");
}

// Execute the demonstration
runComplianceDemo().catch(console.err);
