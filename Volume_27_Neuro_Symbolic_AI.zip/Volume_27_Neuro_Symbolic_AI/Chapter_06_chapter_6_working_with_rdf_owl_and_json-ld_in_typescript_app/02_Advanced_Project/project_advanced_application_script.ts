/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file compliance-engine.ts
 * @description Enterprise Semantic Compliance Engine using TypeScript, RDF/JSON-LD,
 * and the Vercel AI SDK for deterministic zero-hallucination querying.
 */

import { NextResponse } from 'next/server';
import { streamText, tool } from 'ai';
import { openai } from '@ai-sdk/openai';
import { Parser, Store, Quad } from 'n3';
import { z } from 'zod';

// ============================================================================
// 1. DOMAIN MODELS & TYPES
// ============================================================================

/**
 * Represents a parsed JSON-LD semantic document mapped to RDF quads.
 */
interface SemanticDocument {
  contextUrl: string;
  graphId: string;
  rawJsonLd: Record<string, unknown>;
  quads: Quad[];
}

/**
 * Structured schema for compliance validation results.
 */
const ComplianceSchema = z.object({
  entityUri: z.string().url(),
  isCompliant: z.boolean(),
  violationReason: z.string().optional(),
  referencedStandard: z.string(),
});

type ComplianceResult = z.infer<typeof ComplianceSchema>;

// ============================================================================
// 2. ONTOLOGY REPOSITORY & PARSER
// ============================================================================

/**
 * Enterprise Knowledge Graph repository managing in-memory RDF stores
 * loaded from OWL/JSON-LD enterprise blueprints.
 */
class EnterpriseOntologyStore {
  private store: Store;

  constructor() {
    this.store = new Store();
  }

  /**
   * Ingests a JSON-LD compliance document, transforms it into RDF quads,
   * and loads it into the deterministic triple store.
   */
  public async ingestJsonLd(jsonLdInput: Record<string, unknown>): Promise<SemanticDocument> {
    const compactString = JSON.stringify(jsonLdInput);
    const parser = new Parser({ format: 'application/ld+json' });
    
    return new Promise((resolve, reject) => {
      const quads: Quad[] = [];
      parser.parse(compactString, (error, quad) => {
        if (error) {
          return reject(new Error(`Failed to parse JSON-LD: ${error.message}`));
        }
        if (quad) {
          this.store.addQuad(quad);
          quads.push(quad);
        } else {
          resolve({
            contextUrl: (jsonLdInput['@context'] as string) || '',
            graphId: (jsonLdInput['@id'] as string) || 'urn:graph:default',
            rawJsonLd: jsonLdInput,
            quads,
          });
        }
      });
    });
  }

  /**
   * Executes a deterministic graph lookup matching subject, predicate, and object patterns.
   */
  public queryTriples(subject?: string, predicate?: string, object?: string): Quad[] {
    return this.store.getQuads(
      subject ? (subject as any) : null,
      predicate ? (predicate as any) : null,
      object ? (object as any) : null,
      null
    );
  }
}

// Global singleton instance for the application runtime
const globalOntologyStore = new EnterpriseOntologyStore();

// ============================================================================
// 3. NEXT.JS API ROUTE & VERCEL AI SDK INTEGRATION
// ============================================================================

/**
 * Handles incoming POST requests from the Next.js frontend, bridging natural language
 * prompts with deterministic SPARQL-like graph evaluations via the Vercel AI SDK.
 */
export async function POST(req: Request) {
  try {
    const { prompt, jsonLdPayload } = await req.json();

    // Step 1: If a dynamic JSON-LD payload is provided in the request, ingest it.
    if (jsonLdPayload) {
      await globalOntologyStore.ingestJsonLd(jsonLdPayload);
    }

    // Step 2: Initialize the Vercel AI SDK stream with deterministic tool bindings.
    const result = await streamText({
      model: openai('gpt-4o-mini'),
      system: `You are a zero-hallucination enterprise compliance assistant. 
      You must base all compliance verifications strictly on the provided deterministic 
      ontology store. Never guess or extrapolate data outside the RDF graph.`,
      prompt,
      tools: {
        verifyComplianceRule: tool({
          description: 'Queries the semantic graph to verify if an entity complies with OWL ontology rules.',
          parameters: z.object({
            entityUri: z.string().describe('The URI of the entity being audited.'),
            targetClassUri: z.string().describe('The OWL class URI the entity must conform to.'),
          }),
          execute: async ({ entityUri, targetClassUri }) => {
            // Perform deterministic triple matching against the RDF store
            const typeQuads = globalOntologyStore.queryTriples(
              entityUri,
              'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
              targetClassUri
            );

            const isCompliant = typeQuads.length > 0;

            const result: ComplianceResult = {
              entityUri,
              isCompliant,
              violationReason: isCompliant 
                ? undefined 
                : `Entity ${entityUri} lacks rdf:type assertion for target class ${targetClassUri}.`,
              referencedStandard: targetClassUri,
            };

            return result;
          },
        }),
      },
      maxSteps: 3,
    });

    // Step 3: Return Server-Sent Events (SSE) stream back to the client.
    return result.toDataStreamResponse();

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown internal server error';
    return NextResponse.json(
      { error: 'Semantic Pipeline Failure', details: errorMessage },
      { status: 500 }
    );
  }
}
