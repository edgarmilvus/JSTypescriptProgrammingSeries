/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define foundational RDF Term types
export type NamedNode<T extends string = string> = {
  type: 'NamedNode';
  value: T;
};

export type BlankNode<T extends string = string> = {
  type: 'BlankNode';
  value: T;
};

export type Literal<T extends string = string, D extends string = string> = {
  type: 'Literal';
  value: T;
  datatype: D;
  language?: string;
};

export type Term = NamedNode | BlankNode | Literal;

// Type helper to check datatype constraints
export type XSDDatatype = 
  | 'http://www.w3.org/2001/XMLSchema#string'
  | 'http://www.w3.org/2001/XMLSchema#integer'
  | 'http://www.w3.org/2001/XMLSchema#boolean';

// Vocabulary Mapping Interface Definition
export interface OntologyVocabulary {
  [predicate: string]: {
    expectedType: 'NamedNode' | 'Literal';
    datatype?: XSDDatatype;
  };
}

// Strongly typed Triple structure
export interface TypedTriple<
  S extends NamedNode | BlankNode,
  P extends NamedNode,
  O extends Term
> {
  subject: S;
  predicate: P;
  object: O;
  toNTriples(): string;
}

// Factory class implementing strict generic constraints
export class TripleFactory<V extends OntologyVocabulary> {
  constructor(private vocabulary: V) {}

  public createTriple<
    SId extends string,
    PId extends Extract<keyof V, string>,
    OVal extends string
  >(
    subject: SId,
    predicate: PId,
    objectValue: OVal,
    objectType: V[PId]['expectedType']
  ): TypedTriple<NamedNode<SId>, NamedNode<PId>, Term> {
    const constraint = this.vocabulary[predicate];

    if (constraint.expectedType !== objectType) {
      throw new Error(`Semantic mismatch for predicate ${predicate}: expected ${constraint.expectedType}`);
    }

    const sub: NamedNode<SId> = { type: 'NamedNode', value: subject };
    const pred: NamedNode<PId> = { type: 'NamedNode', value: predicate };
    
    let obj: Term;
    if (objectType === 'NamedNode') {
      obj = { type: 'NamedNode', value: objectValue };
    } else {
      obj = { 
        type: 'Literal', 
        value: objectValue, 
        datatype: constraint.datatype || 'http://www.w3.org/2001/XMLSchema#string' 
      };
    }

    return {
      subject: sub,
      predicate: pred,
      object: obj,
      toNTriples() {
        const objStr = obj.type === 'Literal' 
          ? `"${obj.value}"^^<${obj.datatype}>` 
          : `<${obj.value}>`;
        return `<${sub.value}> <${pred.value}> ${objStr} .`;
      }
    };
  }
}

// Example Vocabulary Schema
const myVocabulary = {
  'http://schema.org/name': { expectedType: 'Literal' as const, datatype: 'http://www.w3.org/2001/XMLSchema#string' as const },
  'http://schema.org/knows': { expectedType: 'NamedNode' as const }
} satisfies OntologyVocabulary;

const factory = new TripleFactory(myVocabulary);
const validTriple = factory.createTriple(
  'http://example.org/alice',
  'http://schema.org/name',
  'Alice',
  'Literal'
);
