/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface OwlClassDefinition {
  uri: string;
  subClassOf?: string[];
  properties?: {
    [propertyUri: string]: {
      range: string;
      required?: boolean;
    };
  };
}

export class OntologyManager {
  private classes: Map<string, OwlClassDefinition> = new Map();

  public registerClass(def: OwlClassDefinition): void {
    this.classes.set(def.uri, def);
  }

  public isSubClassOf(childUri: string, parentUri: string, visited: Set<string> = new Set()): boolean {
    if (childUri === parentUri) return true;
    if (visited.has(childUri)) return false; // Cycle detection
    visited.add(childUri);

    const classDef = this.classes.get(childUri);
    if (!classDef || !classDef.subClassOf) return false;

    for (const parent of classDef.subClassOf) {
      if (this.isSubClassOf(parent, parentUri, visited)) {
        return true;
      }
    }
    return false;
  }

  public validateInstance(instance: Record<string, any>, classUri: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    const classDef = this.classes.get(classUri);

    if (!classDef) {
      return { valid: false, errors: [`Class definition for ${classUri} not found in ontology.`] };
    }

    if (classDef.properties) {
      for (const [propUri, constraint] of Object.entries(classDef.properties)) {
        const val = instance[propUri];
        if (constraint.required && (val === undefined || val === null)) {
          errors.push(`Missing required property: ${propUri}`);
        } else if (val !== undefined && typeof val !== 'string' && constraint.range.includes('string')) {
          errors.push(`Property ${propUri} violates range constraint: expected string.`);
        }
      }
    }

    return { valid: errors.length === 0, errors };
  }
}

// Usage Example
const manager = new OntologyManager();
manager.registerClass({
  uri: 'http://example.org/Engineer',
  subClassOf: ['http://example.org/Person']
});
manager.registerClass({
  uri: 'http://example.org/SoftwareEngineer',
  subClassOf: ['http://example.org/Engineer'],
  properties: {
    'http://example.org/programmingLanguage': { range: 'http://www.w3.org/2001/XMLSchema#string', required: true }
  }
});

const isSub = manager.isSubClassOf('http://example.org/SoftwareEngineer', 'http://example.org/Person');
