/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export class JsonLdProcessor<T> {
  constructor(private defaultContext: Record<string, string>) {}

  public async normalize(rawInput: unknown, context?: Record<string, string>): Promise<T> {
    if (!rawInput || typeof rawInput !== 'object') {
      throw new Error('Invalid JSON-LD payload: must be a non-null object.');
    }

    const activeContext = context || this.defaultContext;
    const normalizedRecord: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(rawInput as Record<string, unknown>)) {
      if (key.startsWith('@')) {
        normalizedRecord[key] = value;
        continue;
      }

      let expandedKey = key;
      for (const [prefix, uri] of Object.entries(activeContext)) {
        if (key.startsWith(`${prefix}:`)) {
          expandedKey = key.replace(`${prefix}:`, uri);
          break;
        }
      }
      normalizedRecord[expandedKey] = value;
    }

    return normalizedRecord as T;
  }

  public frame(compactedDoc: Record<string, unknown>, frameTemplate: Record<string, unknown>): T {
    const framedResult: Record<string, unknown> = {};
    for (const key of Object.keys(frameTemplate)) {
      if (compactedDoc[key] !== undefined) {
        framedResult[key] = compactedDoc[key];
      }
    }
    return framedResult as T;
  }
}

// Usage Example
interface UserProfile {
  '@id': string;
  'http://schema.org/name': string;
}

const processor = new JsonLdProcessor<UserProfile>({
  'schema': 'http://schema.org/'
});

// Async normalization execution
(async () => {
  const result = await processor.normalize({
    '@id': 'http://example.org/users/1',
    'schema:name': 'Bob Smith'
  });
})();
