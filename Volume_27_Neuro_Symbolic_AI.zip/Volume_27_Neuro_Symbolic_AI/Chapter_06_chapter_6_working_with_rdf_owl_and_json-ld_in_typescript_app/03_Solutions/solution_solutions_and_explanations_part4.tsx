/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export interface GraphNode {
  id: string;
  label: string;
  properties: Record<string, string>;
}

export interface GraphEdge {
  predicate: string;
  targetId: string;
}

export interface SemanticGraphPayload {
  focusNode: GraphNode;
  incomingEdges: GraphEdge[];
  outgoingEdges: GraphEdge[];
}

interface ExplorerServerProps {
  entityUri: string;
}

// Client Component for Interactive Exploration
export const SemanticExplorerClient: React.FC<{ initialData: SemanticGraphPayload }> = ({ initialData }) => {
  const [currentNode, setCurrentNode] = React.useState<GraphNode>(initialData.focusNode);

  return (
    <div className="p-4 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold">Focus Node: {currentNode.label}</h2>
      <p className="text-sm text-gray-500">IRI: {currentNode.id}</p>
      
      <div className="mt-4">
        <h3 className="font-semibold">Outgoing Relationships:</h3>
        <ul className="list-disc pl-5">
          {initialData.outgoingEdges.map((edge, idx) => (
            <li key={idx} className="text-blue-600">
              {edge.predicate} &rarr; {edge.targetId}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Server Component handling data fetching boundary
export async function SemanticExplorerServer({ entityUri }: ExplorerServerProps) {
  let payload: SemanticGraphPayload;
  let errorString: string | null = null;

  try {
    // Simulating strongly-typed SPARQL fetch execution on the server
    if (!entityUri.startsWith('http')) {
      throw new Error(`Invalid IRI supplied for SPARQL execution: ${entityUri}`);
    }

    payload = {
      focusNode: {
        id: entityUri,
        label: 'Resolved Enterprise Entity',
        properties: { 'http://schema.org/name': 'Knowledge Asset' }
      },
      outgoingEdges: [{ predicate: 'http://schema.org/isPartOf', targetId: 'http://example.org/catalog' }],
      incomingEdges: []
    };
  } catch (err: unknown) {
    errorString = err instanceof Error ? err.message : 'Unknown query execution error';
    return (
      <div className="p-4 border border-red-300 bg-red-50 text-red-700 rounded-lg">
        <h3 className="font-bold">Semantic Query Error</h3>
        <p>{errorString}</p>
        <code className="block mt-2 text-xs bg-red-100 p-2 rounded">Target IRI: {entityUri}</code>
      </div>
    );
  }

  return <SemanticExplorerClient initialData={payload} />;
}
