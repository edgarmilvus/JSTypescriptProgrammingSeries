/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface SparqlBindingValue {
  type: 'uri' | 'literal' | 'bnode';
  value: string;
  datatype?: string;
}

export interface SparqlJsonResponse {
  head: { vars: string[] };
  results: {
    bindings: Array<Record<string, SparqlBindingValue>>;
  };
}

export class SparqlQueryBuilder {
  private selectedVars: string[] = [];
  private wherePatterns: string[] = [];
  private limitCount?: number;

  public select(vars: string[]): this {
    this.selectedVars = vars;
    return this;
  }

  public where(pattern: string): this {
    this.wherePatterns.push(pattern);
    return this;
  }

  public limit(count: number): this {
    this.limitCount = count;
    return this;
  }

  public build(): string {
    const selectClause = `SELECT ${this.selectedVars.join(' ')}`;
    const whereClause = `WHERE {\n  ${this.wherePatterns.join(' .\n  ')} \n}`;
    const limitClause = this.limitCount !== undefined ? `LIMIT ${this.limitCount}` : '';
    return [selectClause, whereClause, limitClause].filter(Boolean).join('\n');
  }
}

export function mapSparqlResults<T>(
  rawResponse: SparqlJsonResponse,
  mappingConfig: Record<keyof T, string>
): T[] {
  return rawResponse.results.bindings.map((binding) => {
    const mappedInstance: Record<string, unknown> = {};

    for (const [targetKey, variableName] of Object.entries(mappingConfig) as Array<[keyof T, string]>) {
      const boundTerm = binding[variableName];
      if (boundTerm) {
        mappedInstance[targetKey as string] = boundTerm.value;
      } else {
        mappedInstance[targetKey as string] = null;
      }
    }

    return mappedInstance as T;
  });
}

// Usage Example
interface PersonEntity {
  name: string;
  email: string;
}

const query = new SparqlQueryBuilder()
  .select(['?name', '?email'])
  .where('?s <http://schema.org/name> ?name')
  .where('?s <http://schema.org/email> ?email')
  .limit(10)
  .build();

const mockResponse: SparqlJsonResponse = {
  head: { vars: ['name', 'email'] },
  results: {
    bindings: [
      {
        name: { type: 'literal', value: 'Alice' },
        email: { type: 'literal', value: 'alice@example.com' }
      }
    ]
  }
};

const results = mapSparqlResults<PersonEntity>(mockResponse, {
  name: 'name',
  email: 'email'
});
