/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file tenant-analyzer.ts
 * @description A self-contained, zero-hallucination semantic query engine using N3.js and SPARQL.
 * Demonstrates parsing RDF Turtle data and querying it programmatically in Node.js.
 */

import { Store, Parser, Writer, Quad } from 'n3';
import { Parser as SparqlParser, Generator as SparqlGenerator } from 'sparqljs';

// ============================================================================
// 1. DOMAIN MODELS & TYPES
// ============================================================================

/**
 * Represents a verified SaaS tenant profile extracted via deterministic query patterns.
 */
interface VerifiedTenantProfile {
  tenantUri: string;
  name: string;
  tier: string;
  activeFeatureCount: number;
}

// ============================================================================
// 2. MOCK DATA & SEMANTIC INPUT (TURTLE FORMAT)
// ============================================================================

/**
 * Raw RDF data in Turtle (.ttl) format representing enterprise SaaS tenants,
 * their subscription tiers, and enabled feature flags.
 */
const rawTurtleData = `
@prefix saas: <https://api.enterprise-saas.io/ontology#> .
@prefix xsd:  <http://www.w3.org/2001/XMLSchema#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .

saas:TenantA 
    a saas:EnterpriseTenant ;
    rdfs:label "Acme Corp" ;
    saas:subscriptionTier "Enterprise" ;
    saas:hasFeature saas:SSO, saas:AuditLogs, saas:CustomDomain .

saas:TenantB 
    a saas:SMBTenant ;
    rdfs:label "StartupXYZ" ;
    saas:subscriptionTier "Free" ;
    saas:hasFeature saas:SSO .

saas:TenantC 
    a saas:EnterpriseTenant ;
    rdfs:label "Global Logistics Inc" ;
    saas:subscriptionTier "Enterprise" ;
    saas:hasFeature saas:SSO, saas:AuditLogs, saas:CustomDomain, saas:AdvancedAnalytics .
`;

// ============================================================================
// 3. CORE SERVICE IMPLEMENTATION
// ============================================================================

/**
 * Executes a deterministic SPARQL query over an in-memory N3 store.
 * 
 * @param ttlData - The raw RDF Turtle string to be parsed.
 * @param sparqlQuery - The structural SPARQL query string.
 * @returns An array of verified, type-safe tenant profiles.
 */
export async function queryTenantKnowledgeBase(
  ttlData: string,
  sparqlQuery: string
): Promise<VerifiedTenantProfile[]> {
  // Step 3.1: Initialize the in-memory N3 Store
  const store = new Store();

  // Step 3.2: Parse Turtle data into RDF quads and load them into the store
  await new Promise<void>((resolve, reject) => {
    const parser = new Parser();
    parser.parse(ttlData, (error, quad, prefixes) => {
      if (error) {
        reject(new Error(`Failed to parse RDF Turtle: ${error.message}`));
        return;
      }
      if (quad) {
        store.addQuad(quad);
      } else {
        // When quad is null, parsing is complete
        resolve();
      }
    });
  });

  // Step 3.3: Parse the incoming SPARQL query string into an Abstract Syntax Tree (AST)
  const sparqlParser = new SparqlParser();
  const queryAst = sparqlParser.parse(sparqlQuery);

  // Step 3.4: Execute deterministic pattern matching over the N3 Store
  // Note: For production use cases with complex property paths, engines like 
  // Comunica or ldfs are recommended. Here, we evaluate standard triple patterns 
  // manually to guarantee zero-hallucination execution without external triple-store daemons.
  
  const results: VerifiedTenantProfile[] = [];

  // Extract variables and patterns from the parsed SPARQL AST (simplified for demo)
  // We look for patterns matching (?tenant rdf:type saas:EnterpriseTenant)
  const enterpriseTypeQuadPattern = new Quad(
    null,
    new Store().createQuad(
      null, 
      'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 
      'https://api.enterprise-saas.io/ontology#EnterpriseTenant'
    ).predicate,
    new Store().createQuad(
      null, 
      'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 
      'https://api.enterprise-saas.io/ontology#EnterpriseTenant'
    ).object
  );

  // Find all matching subjects in the store
  const matchingQuads = store.getQuads(null, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'https://api.enterprise-saas.io/ontology#EnterpriseTenant', null);

  for (const match of matchingQuads) {
    const tenantSubject = match.subject;

    // Fetch label (name)
    const labelQuads = store.getQuads(tenantSubject, 'http://www.w3.org/2000/01/rdf-schema#label', null, null);
    const name = labelQuads.length > 0 ? labelQuads[0].object.value : 'Unknown';

    // Fetch subscription tier
    const tierQuads = store.getQuads(tenantSubject, 'https://api.enterprise-saas.io/ontology#subscriptionTier', null, null);
    const tier = tierQuads.length > 0 ? tierQuads[0].object.value : 'Unknown';

    // Count features
    const featureQuads = store.getQuads(tenantSubject, 'https://api.enterprise-saas.io/ontology#hasFeature', null, null);
    const activeFeatureCount = featureQuads.length;

    results.push({
      tenantUri: tenantSubject.value,
      name,
      tier,
      activeFeatureCount,
    });
  }

  return results;
}

// ============================================================================
// 4. EXECUTION DEMONSTRATION (SERVER ACTION SIMULATION)
// ============================================================================

/**
 * Main execution handler simulating a Next.js Server Action invocation.
 */
async function runDemo() {
  console.log('Initializing Semantic Query Pipeline...');

  // A standard SPARQL query targeting Enterprise tenants
  const sampleSparqlQuery = `
    PREFIX saas: <https://api.enterprise-saas.io/ontology#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

    SELECT ?tenant ?name ?tier ?feature
    WHERE {
      ?tenant a saas:EnterpriseTenant ;
              rdfs:label ?name ;
              saas:subscriptionTier ?tier ;
              saas:hasFeature ?feature .
    }
  `;

  try {
    const verifiedTenants = await queryTenantKnowledgeBase(rawTurtleData, sampleSparqlQuery);
    
    console.log('\n--- Deterministic Query Results ---');
    console.log(JSON.stringify(verifiedTenants, null, 2));
    
  } catch (error) {
    console.error('Error executing semantic query pipeline:', error);
  }
}

// Execute the demo if run directly via Node.js
if (require.main === module) {
  runDecoupledDemo();
}

async function runDecoupledDemo() {
  await runDemo();
}
