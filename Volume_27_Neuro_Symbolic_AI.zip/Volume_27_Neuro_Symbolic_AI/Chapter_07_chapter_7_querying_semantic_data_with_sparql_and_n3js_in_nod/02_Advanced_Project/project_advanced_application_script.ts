/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file Enterprise Semantic Compliance Engine
 * @description Implements a zero-hallucination validation pipeline using N3.js,
 *              SPARQL querying, and strict TypeScript compilation settings.
 */

import { Store, Parser, Writer, Quad, NamedNode, Literal } from 'n3';
import { QueryEngine } from '@comunica/query-sparql';

// ==========================================
// 1. Strict Type Definitions & Interfaces
// ==========================================

/**
 * Represents the validation result returned by the deterministic solver.
 */
interface ComplianceValidationResult {
    readonly isCompliant: boolean;
    readonly violationCode?: string;
    readonly message: string;
    readonly evaluatedAt: string;
    readonly evidenceQuads: readonly string[];
}

/**
 * Strict data contract for incoming audit payloads.
 */
interface AuditPayload {
    readonly transactionId: string;
    readonly actorId: string;
    readonly resourceId: string;
    readonly actionType: 'READ' | 'WRITE' | 'DELETE' | 'ADMIN_OVERRIDE';
    readonly dataClassification: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
}

// Namespaces for our enterprise ontology
const NS = {
    ex: 'http://example.org/ns#',
    rdf: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
    xsd: 'http://www.w3.org/2001/XMLSchema#',
    sec: 'http://example.org/security#'
};

// ==========================================
// 2. Core Semantic Validation Engine
// ==========================================

export class SemanticComplianceEngine {
    private store: Store;
    private engine: QueryEngine;

    constructor() {
        // Initialize an in-memory N3 store and the Comunica SPARQL engine
        this.store = new Store();
        this.engine = new QueryEngine();
        this.initializeOntology();
    }

    /**
     * Seeds the N3 store with baseline corporate security policies (Ontology).
     */
    private initializeOntology(): void {
        const basePolicyTurtle = `
            @prefix sec: <${NS.sec}> .
            @prefix xsd: <${NS.xsd}> .

            sec:RestrictedDataRule a sec:SecurityPolicy ;
                sec:prohibitsAction sec:ADMIN_OVERRIDE ;
                sec:targetClassification sec:RESTRICTED ;
                sec:maxClearanceLevel 3 .
        `;

        const parser = new Parser();
        parser.parse(basePolicyTurtle, (error, quad) => {
            if (error) {
                throw new Error(`Failed to parse baseline ontology: ${error.message}`);
            }
            if (quad) {
                this.store.addQuad(quad);
            }
        });
    }

    /**
     * Transforms an incoming typed audit payload into RDF quads and loads them.
     */
    public ingestTransaction(payload: AuditPayload): void {
        const txNode = new NamedNode(`${NS.ex}transaction_${payload.transactionId}`);
        
        const quads = [
            new Quad(txNode, new NamedNode(`${NS.rdf}type`), new NamedNode(`${NS.sec}Transaction`)),
            new Quad(txNode, new NamedNode(`${NS.sec}hasActor`), new NamedNode(`${NS.ex}actor_${payload.actorId}`)),
            new Quad(txNode, new NamedNode(`${NS.sec}hasResource`), new NamedNode(`${NS.ex}resource_${payload.resourceId}`)),
            new Quad(txNode, new NamedNode(`${NS.sec}hasAction`), new NamedNode(`${NS.sec}${payload.actionType}`)),
            new Quad(txNode, new NamedNode(`${NS.sec}hasClassification`), new NamedNode(`${NS.sec}${payload.dataClassification}`))
        ];

        this.store.addQuads(quads);
    }

    /**
     * Evaluates the in-memory graph against deterministic SPARQL compliance rules.
     * Guarantees zero-hallucination through strict logical pattern matching.
     */
    public async validateTransaction(transactionId: string): Promise<ComplianceValidationResult> {
        const txUri = `${NS.ex}transaction_${transactionId}`;

        // SPARQL query designed to detect policy violations
        const sparqlQuery = `
            PREFIX sec: <${NS.sec}>
            PREFIX rdf: <${NS.rdf}>

            SELECT ?classification ?action WHERE {
                <${txUri}> sec:hasClassification ?classNode ;
                            sec:hasAction ?actionNode .
                
                ?classNode rdf:type ?classType .
                # Extract local names for comparison
                BIND(STRAFTER(STR(?classNode), "#") AS ?classification)
                BIND(STRAFTER(STR(?actionNode), "#") AS ?action)

                # Rule: RESTRICTED data cannot be accessed via ADMIN_OVERRIDE without secondary approval
                FILTER(?classification = "RESTRICTED" && ?action = "ADMIN_OVERRIDE")
            }
        `;

        try {
            const bindingsStream = await this.engine.queryBindings(sparqlQuery, {
                sources: [this.store],
            });

            const bindings = await bindingsStream.toArray();
            const isViolationFound = bindings.length > 0;

            const evidence: string[] = [];
            this.store.getQuads(new NamedNode(txUri), null, null, null).forEach(q => {
                evidence.push(`${q.subject.value} ${q.predicate.value} ${q.object.value}`);
            });

            if (isViolationFound) {
                return {
                    isCompliant: false,
                    violationCode: 'SEC_ERR_001_RESTRICTED_ADMIN_OVERRIDE',
                    message: 'Deterministic Policy Violation: ADMIN_OVERRIDE on RESTRICTED data is strictly prohibited.',
                    evaluatedAt: new Date().toISOString(),
                    evidenceQuads: evidence
                };
            }

            return {
                isCompliant: true,
                message: 'Transaction passed all semantic security checks.',
                evaluatedAt: new Date().toISOString(),
                evidenceQuads: evidence
            };

        } catch (err: unknown) {
            const errorMessage = err instanceof Error ? err.message : String(err);
            throw new Error(`SPARQL Evaluation Failure: ${errorMessage}`);
        }
    }
}

// ==========================================
// 3. Execution Example (SaaS Integration Simulator)
// ==========================================

async function runCompliancePipeline(): Promise<void> {
    const engine = new SemanticComplianceEngine();

    // Simulate an incoming high-risk enterprise audit payload
    const incomingAudit: AuditPayload = {
        transactionId: 'TX-90210',
        actorId: 'user_dev_404',
        resourceId: 'financial_ledger_2026',
        actionType: 'ADMIN_OVERRIDE',
        dataClassification: 'RESTRICTED'
    };

    console.log(`[Pipeline] Ingesting transaction ${incomingAudit.transactionId}...`);
    engine.ingestTransaction(incomingAudit);

    console.log(`[Pipeline] Executing deterministic SPARQL solver...`);
    const result = await engine.validateTransaction(incomingAudit.transactionId);

    console.log('\n--- Compliance Validation Report ---');
    console.log(JSON.stringify(result, null, 2));
}

// Execute if run directly
if (require.main === module) {
    runCompliancePipeline().catch(console.error);
}
