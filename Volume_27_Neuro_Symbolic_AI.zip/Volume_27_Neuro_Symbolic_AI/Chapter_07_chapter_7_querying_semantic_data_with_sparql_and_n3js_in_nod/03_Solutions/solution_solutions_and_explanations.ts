/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import { Store, StreamParser, Quad, Prefixes } from 'n3';

export class SemanticIngestionError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = 'SemanticIngestionError';
  }
}

export interface IngestionReport {
  tripleCount: number;
  prefixes: Prefixes;
  durationMs: number;
}

/**
 * Ingests a Turtle file asynchronously into an N3 Store with exhaustive error handling.
 * 
 * @param filePath Absolute path to the .ttl file.
 * @param store N3.Store instance to populate.
 * @returns A promise resolving to an IngestionReport.
 */
export async function ingestRdfStream(filePath: string, store: Store): Promise<IngestionReport> {
  const startTime = performance.now();
  const fileStream = fs.createReadStream(filePath);
  const parser = new StreamParser();
  
  const prefixes: Prefixes = {};
  let tripleCount = 0;

  return new Promise<IngestionReport>((resolve, reject) => {
    fileStream.on('error', (err) => {
      fileStream.destroy();
      reject(new SemanticIngestionError(`Failed to read file stream at ${filePath}`, err));
    });

    parser.on('prefix', (prefix, uri) => {
      prefixes[prefix] = uri;
    });

    parser.on('data', (quad: Quad) => {
      try {
        store.addQuad(quad);
        tripleCount++;
      } catch (err) {
        reject(new SemanticIngestionError('Failed to add quad to N3 store', err));
      }
    });

    parser.on('error', (err) => {
      fileStream.destroy();
      reject(new SemanticIngestionError('RDF parser encountered a syntax error', err));
    });

    parser.on('end', () => {
      const durationMs = performance.now() - startTime;
      resolve({
        tripleCount,
        prefixes,
        durationMs,
      });
    });

    try {
      fileStream.pipe(parser);
    } catch (err) {
      fileStream.destroy();
      reject(new SemanticIngestionError('Unexpected exception while piping stream to parser', err));
    } finally {
      // Ensure file descriptor safety via resource tracking/cleanup triggers
    }
  }).finally(() => {
    if (!fileStream.destroyed) {
      fileStream.destroy();
    }
  });
}
