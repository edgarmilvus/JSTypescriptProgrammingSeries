/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Store, Quad } from 'n3';
// Note: In a production environment, import QueryEngine from '@comunica/query-sparql-rdfjs';
// or use sparqlalgebrajs paired with store.getQuads for programmatic evaluation.

export class SparqlSyntaxError extends Error {
  constructor(message: string, public readonly query: string) {
    super(message);
    this.name = 'SparqlSyntaxError';
  }
}

export class InMemorySparqlEngine {
  private store: Store;

  constructor(initialQuads?: Quad[]) {
    this.store = new Store(initialQuads);
  }

  /**
   * Executes a SPARQL SELECT query against the in-memory store.
   * 
   * @param queryString Valid SPARQL SELECT query string.
   * @param timeoutMs Execution timeout limit in milliseconds.
   * @returns Array of variable bindings.
   */
  public async executeQuery(
    queryString: string,
    timeoutMs: number = 5000
  ): Promise<Record<string, string>[]> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    try {
      // Basic syntax check precondition
      if (!queryString || !queryString.trim().toUpperCase().startsWith('SELECT')) {
        throw new SparqlSyntaxError('Query must be a valid SPARQL SELECT statement', queryString);
      }

      if (controller.signal.aborted) {
        throw new Error('SPARQL query execution timed out prior to evaluation.');
      }

      // Simulated SPARQL evaluation engine hook processing over this.store patterns.
      // In a real integration, Comunica's QueryEngine would be invoked here with an AbortSignal.
      const results: Record<string, string>[] = [];
      
      // Fallback example matching store quads if basic triple pattern exists
      const quads = this.store.getQuads(null, null, null, null);
      if (quads.length > 0 && queryString.includes('?s ?p ?o')) {
        for (const quad of quads) {
          results.push({
            s: quad.subject.value,
            p: quad.predicate.value,
            o: quad.object.value
          });
        }
      }

      return results;
    } catch (err: unknown) {
      if (err instanceof SparqlSyntaxError) {
        throw err;
      }
      if (controller.signal.aborted) {
        throw new SparqlSyntaxError('SPARQL query execution timed out', queryString);
      }
      throw new SparqlSyntaxError(`Failed to evaluate SPARQL query: ${(err as Error).message}`, queryString);
    } finally {
      clearTimeout(timeoutId);
    }
  }
}
