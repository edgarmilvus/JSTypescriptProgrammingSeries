/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Store, DataFactory } from 'n3';
const { namedNode } = DataFactory;

export interface ExtractedEntity {
  id: string;
  type: string;
  relatedTo: string;
}

export interface ValidationError {
  entityId: string;
  reason: string;
}

export interface ValidationResult {
  validEntities: ExtractedEntity[];
  hallucinatedEntities: ValidationError[];
}

/**
 * Validates LLM-extracted entities against an RDF knowledge graph ontology.
 * 
 * @param entities Array of entities extracted by the LLM.
 * @param store N3.Store containing the deterministic ontology and graph data.
 * @returns Validation result containing valid and flagged entities.
 */
export async function validateEntitiesAgainstGraph(
  entities: ExtractedEntity[],
  store: Store
): Promise<ValidationResult> {
  const validEntities: ExtractedEntity[] = [];
  const hallucinatedEntities: ValidationError[] = [];

  const validationPromises = entities.map(async (entity) => {
    try {
      // Zero-hallucination check: Verify entity type exists in store ontology
      const typeExists = store.getQuads(
        namedNode(entity.id),
        namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type'),
        namedNode(entity.type),
        null
      ).length > 0;

      // Fallback check: If explicit instance doesn't exist, check class definition or domain definitions
      const classExists = store.getQuads(
        namedNode(entity.type),
        null,
        null,
        null
      ).length > 0;

      if (!typeExists && !classExists) {
        throw new Error(`Entity type <${entity.type}> or instance <${entity.id}> is missing from the ontology graph.`);
      }

      // Verify relationship target if specified
      if (entity.relatedTo) {
        const relationExists = store.getQuads(
          null,
          null,
          namedNode(entity.relatedTo),
          null
        ).length > 0 || store.getQuads(
          namedNode(entity.relatedTo),
          null,
          null,
          null
        ).length > 0;

        if (!relationExists) {
          throw new Error(`Referential integrity violation: Related entity <${entity.relatedTo}> not found in graph.`);
        }
      }

      return { entity, error: null };
    } catch (err) {
      return { entity, error: (err as Error).message };
    }
  });

  const outcomes = await Promise.allSettled(validationPromises);

  for (const outcome of outcomes) {
    if (outcome.status === 'fulfilled') {
      const { entity, error } = outcome.value;
      if (error) {
        hallucinatedEntities.push({ entityId: entity.id, reason: error });
      } else {
        validEntities.push(entity);
      }
    } else {
      // Handle rejected promises from unhandled batch exceptions
      hallucinatedEntities.push({
        entityId: 'unknown',
        reason: outcome.reason?.message || 'Unknown validation failure'
      });
    }
  }

  return { validEntities, hallucinatedEntities };
}
