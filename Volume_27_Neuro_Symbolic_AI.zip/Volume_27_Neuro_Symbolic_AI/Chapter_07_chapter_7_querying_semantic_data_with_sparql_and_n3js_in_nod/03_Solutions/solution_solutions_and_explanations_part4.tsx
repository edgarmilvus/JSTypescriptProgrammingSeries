/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface SparqlConsoleProps {
  initialQuery?: string;
  onExecuteQuery: (query: string) => Promise<Record<string, string>[]>;
  onValidateGraph?: () => Promise<boolean>;
}

export const SparqlConsoleComponent: React.FC<SparqlConsoleProps> = ({
  initialQuery = 'SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 10',
  onExecuteQuery,
  onValidateGraph
}) => {
  const [query, setQuery] = useState<string>(initialQuery);
  const [results, setResults] = useState<Record<string, string>[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleRunQuery = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await onExecuteQuery(query);
      setResults(data);
    } catch (err: unknown) {
      setError((err as Error).message || 'An error occurred during query execution.');
    } finally {
      setLoading(false);
    }
  };

  // Derive column headers dynamically from projection variable keys
  const columns = results.length > 0 ? Object.keys(results[0]) : [];

  return (
    <div className="sparql-console-container" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Semantic Knowledge Graph Console</h2>
      <div style={{ marginBottom: '10px' }}>
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          rows={6}
          style={{ width: '100%', fontFamily: 'monospace', padding: '8px' }}
        />
      </div>
      <button 
        onClick={handleRunQuery} 
        disabled={loading}
        style={{ padding: '10px 20px', cursor: 'pointer' }}
      >
        {loading ? 'Executing SPARQL...' : 'Execute Query'}
      </button>

      {error && (
        <div style={{ color: 'red', marginTop: '10px', padding: '10px', background: '#ffe6e6' }}>
          <strong>Error:</strong> {error}
        </div>
      )}

      <div style={{ marginTop: '20px' }}>
        <h3>Results ({results.length} rows)</h3>
        {results.length > 0 ? (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
              <thead>
                <tr style={{ background: '#f4f4f4', borderBottom: '2px solid #ddd' }}>
                  {columns.map((col) => (
                    <th key={col} style={{ padding: '8px', textAlign: 'left', border: '1px solid #ddd' }}>
                      ?{col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {results.map((row, index) => (
                  <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
                    {columns.map((col) => (
                      <td key={col} style={{ padding: '8px', border: '1px solid #ddd', fontFamily: 'monospace', fontSize: '13px' }}>
                        {row[col]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ color: '#666', fontStyle: 'italic' }}>No projection bindings available. Execute a query to view tabular data.</p>
        )}
      </div>
    </div>
  );
};
