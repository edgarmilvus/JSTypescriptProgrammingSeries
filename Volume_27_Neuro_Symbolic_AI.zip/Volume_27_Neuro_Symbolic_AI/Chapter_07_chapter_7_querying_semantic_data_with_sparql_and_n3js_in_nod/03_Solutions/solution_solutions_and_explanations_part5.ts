/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Store, DataFactory } from 'n3';
const { namedNode, literal } = DataFactory;

export interface AgentIntent {
  agentId: string;
  targetResource: string;
  requiredAction: string;
  contextZone: string;
}

export class SemanticPolicyEnforcer {
  private store: Store;

  constructor(policyStore: Store) {
    this.store = policyStore;
  }

  /**
   * Evaluates whether an agent's intent is authorized by the semantic access control graph.
   * Follows a strict fail-closed security posture.
   * 
   * @param intent The structured agent action intent.
   * @returns A promise resolving to true if authorized, false otherwise.
   */
  public async isAuthorized(intent: AgentIntent): Promise<boolean> {
    try {
      // Validate inputs against injection risks
      if (!intent.agentId || !intent.targetResource || !intent.requiredAction) {
        console.warn('Policy evaluation failed: Incomplete intent parameters.');
        return false;
      }

      // Construct safe parameter bindings or pattern matching queries
      const agentNode = namedNode(intent.agentId);
      const resourceNode = namedNode(intent.targetResource);
      const actionNode = namedNode(intent.requiredAction);
      const zoneNode = namedNode(intent.contextZone);

      // Programmatic pattern check against the access control ontology store:
      // Equivalent to SPARQL ASK WHERE { ?agent hasRole ?role . ?role grants ?action . ?action appliesTo ?resource . }
      
      // Step 1: Check direct or indirect role assignments
      const roleQuads = this.store.getQuads(agentNode, namedNode('http://example.org/ns/hasRole'), null, null);
      if (roleQuads.length === 0) {
        return false; // Fail-closed: Agent has no assigned roles
      }

      let authorized = false;

      for (const roleQuad of roleQuads) {
        const role = roleQuad.object;
        
        // Step 2: Verify role permission for the required action
        const permissionQuads = this.store.getQuads(role, namedNode('http://example.org/ns/permitsAction'), actionNode, null);
        
        if (permissionQuads.length > 0) {
          // Step 3: Verify resource scope and context zone clearance
          for (const permQuad of permissionQuads) {
            const scopeQuads = this.store.getQuads(permQuad.subject, namedNode('http://example.org/ns/targetResource'), resourceNode, null);
            const zoneQuads = this.store.getQuads(permQuad.subject, namedNode('http://example.org/ns/validZone'), zoneNode, null);

            if (scopeQuads.length > 0 || zoneQuads.length > 0) {
              authorized = true;
              break;
            }
          }
        }
        if (authorized) break;
      }

      return authorized;
    } catch (err) {
      // Exhaustive Asynchronous Resilience: Fail closed on any security exception
      console.error('Critical security policy evaluation exception:', err);
      return false;
    }
  }
}
