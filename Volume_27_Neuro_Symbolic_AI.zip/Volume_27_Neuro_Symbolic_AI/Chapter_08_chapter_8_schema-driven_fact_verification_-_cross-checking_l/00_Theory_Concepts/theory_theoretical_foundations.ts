/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph TheoreticalFoundations {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#333333"];
    edge [fontname="Arial", fontsize=10];

    LLM [label="LLM Generates\nProbabilistic Text", fillcolor="#ffe6e6"];
    Parser [label="Atomic Claim Extraction\n& Structuring", fillcolor="#fff2cc"];
    ZodVal [label="Runtime Schema Validation\n(Zod Schema Guardrail)", fillcolor="#e1d5e7"];
    GraphQuery [label="Knowledge Graph Query\n(Deterministic Traversal)", fillcolor="#d5e8d4"];
    Decision [label="Zero-Hallucination Guardrail\n(Accept / Correct / Reject)", fillcolor="#dae8fc"];

    LLM -> Parser [label=" Unstructured Output"];
    Parser -> ZodVal [label=" Raw JSON Payload"];
    ZodVal -> GraphQuery [label=" Validated Typed Claims"];
    GraphQuery -> Decision [label=" Graph Truth State"];
}
