/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file FactVerificationPipeline.ts
 * @description Implements a schema-driven fact verification guardrail in TypeScript.
 * Intercepts LLM extraction outputs, validates via Zod, and queries a deterministic
 * Knowledge Graph to eradicate hallucinations in a SaaS analytics context.
 */

// ==========================================
// 1. ONTOLOGY & KNOWLEDGE GRAPH DEFINITION
// ==========================================

/**
 * Represents a node in our enterprise Knowledge Graph.
 */
interface KGNode {
    id: string;
    label: string;
    properties: Record<string, string | number | boolean>;
}

/**
 * Represents a directed edge (relationship) in our Knowledge Graph.
 */
interface KGEdge {
    source: string;
    target: string;
    relation: string;
}

/**
 * A deterministic Knowledge Graph representing our SaaS product ecosystem.
 */
class KnowledgeGraphDB {
    private nodes: Map<string, KGNode> = new Map();
    private edges: KGEdge[] = [];

    /**
     * Inserts a node into the graph.
     */
    public addNode(node: KGNode): void {
        this.nodes.set(node.id, node);
    }

    /**
     * Inserts a directed edge into the graph.
     */
    public addEdge(edge: KGEdge): void {
        this.edges.push(edge);
    }

    /**
     * Deterministically checks if a specific relation exists between two entities.
     * @param sourceId The origin entity ID.
     * @param relation The predicate/relation string.
     * @param targetId The destination entity ID.
     */
    public verifyFact(sourceId: string, relation: string, targetId: string): boolean {
        // Ensure both nodes exist in the graph first
        if (!this.nodes.has(sourceId) || !this.nodes.has(targetId)) {
            return false;
        }

        // Scan edges for exact match
        return this.edges.some(
            (edge) =>
                edge.source === sourceId &&
                edge.relation === relation &&
                edge.target === targetId
        );
    }
}

// Initialize and seed our GraphDB with known product truths
const productKG = new KnowledgeGraphDB();

productKG.addNode({ id: 'feature_sso', label: 'Feature', properties: { name: 'Single Sign-On', tier: 'Enterprise' } });
productKG.addNode({ id: 'tier_enterprise', label: 'PricingTier', properties: { name: 'Enterprise' } });
productKG.addNode({ id: 'feature_csv_export', label: 'Feature', properties: { name: 'CSV Export', tier: 'Pro' } });
productKG.addNode({ id: 'tier_pro', label: 'PricingTier', properties: { name: 'Pro' } });

// Establish ground-truth relationships
productKG.addEdge({ source: 'feature_sso', relation: 'BELONGS_TO_TIER', target: 'tier_enterprise' });
productKG.addEdge({ source: 'feature_csv_export', relation: 'BELONGS_TO_TIER', target: 'tier_pro' });

// ==========================================
// 2. RUNTIME SCHEMA VALIDATION (ZOD)
// ==========================================

/**
 * Zod schema enforcing JSON Schema Output constraints from the LLM.
 * Guarantees runtime safety and compile-time TypeScript type inference.
 */
const ClaimExtractionSchema = z.object({
    subjectId: z.string().min(1, { message: "Subject ID cannot be empty" }),
    relation: z.string().min(1, { message: "Relation predicate cannot be empty" }),
    targetId: z.string().min(1, { message: "Target ID cannot be empty" }),
    rawStatement: z.string(),
    confidenceScore: z.number().min(0).max(1),
});

// Infer TypeScript type directly from the Zod schema
type ExtractedClaim = z.infer<typeof ClaimExtractionSchema>;

// ==========================================
// 3. ZERO-HALLUCINATION GUARDRAIL PIPELINE
// ==========================================

/**
 * Simulates an LLM parsing unstructured user feedback into a structured claim.
 * @param feedback Unstructured customer support ticket text.
 */
function simulateLLMExtraction(feedback: string): unknown {
    if (feedback.includes('SSO')) {
        // Valid claim matching our Knowledge Graph
        return {
            subjectId: 'feature_sso',
            relation: 'BELONGS_TO_TIER',
            targetId: 'tier_enterprise',
            rawStatement: 'SSO is included in the Enterprise plan.',
            confidenceScore: 0.98,
        };
    } else {
        // Hallucinated claim: LLM invents a non-existent relationship or entity
        return {
            subjectId: 'feature_sso',
            relation: 'BELONGS_TO_TIER',
            targetId: 'tier_pro', // Hallucination: SSO does not belong to Pro!
            rawStatement: 'SSO is included in the Pro tier.',
            confidenceScore: 0.85,
        };
    }
}

/**
 * Executes the complete schema-driven fact verification workflow.
 * @param customerFeedback The raw input text from the SaaS user.
 */
function processCustomerFeedbackPipeline(customerFeedback: string): void {
    console.log(`\n----------------------------------------`);
    console.log(`Processing Feedback: "${customerFeedback}"`);
    console.log(`----------------------------------------`);

    // Step 1: Obtain raw generation from LLM
    const rawLLMOutput = simulateLLMExtraction(customerFeedback);

    // Step 2: Validate structural integrity using Zod (JSON Schema Output enforcement)
    const validationResult = ClaimExtractionSchema.safeParse(rawLLMOutput);

    if (!validationResult.success) {
        console.error(`[Guardrail REJECTED] Structural schema validation failed:`, validationResult.error.format());
        return;
    }

    const claim: ExtractedClaim = validationResult.data;
    console.log(`[Validation PASSED] Structural schema verified for claim:`, claim.rawStatement);

    // Step 3: Cross-check claims against the deterministic Knowledge Graph
    const isFactuallyCorrect = productKG.verifyFact(
        claim.subjectId,
        claim.relation,
        claim.targetId
    );

    // Step 4: Enforce Zero-Hallucination Guardrail Decision
    if (isFactuallyCorrect) {
        console.log(`[Guardrail ACCEPTED] Fact successfully verified against Knowledge Graph.`);
        // Proceed to downstream business logic (e.g., updating analytics dashboard)
    } else {
        console.error(`[Guardrail HALTED] Hallucination detected! Claim contradicts Knowledge Graph:`);
        console.error(`   Failed Triple: (${claim.subjectId}) -[:${claim.relation}]-> (${claim.targetId})`);
        // Trigger automated correction, fallback response, or human-in-the-loop review
    }
}

// ==========================================
// 4. EXECUTION DEMONSTRATION
// ==========================================

// Test Case 1: Valid claim that matches the Knowledge Graph
processCustomerFeedbackPipeline("Can you confirm if SSO is available?");

// Test Case 2: Hallucinated claim generated by the LLM
processCustomerFeedbackPipeline("I heard we can get SSO on the Pro plan right?");
