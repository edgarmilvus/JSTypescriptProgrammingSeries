/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Define the LogicalClaimSchema using Zod with strict data validation rules
export const LogicalClaimSchema = z.object({
  subject: z.string().min(1, { message: "Subject cannot be empty." }),
  predicate: z.string().min(1, { message: "Predicate cannot be empty." }),
  object: z.string().min(1, { message: "Object cannot be empty." }),
  confidence: z.number().min(0.0).max(1.0, { message: "Confidence must be between 0.0 and 1.0." }),
});

export type LogicalClaim = z.infer<typeof LogicalClaimSchema>;

/**
 * Parses unstructured text into validated logical claims.
 * @param rawText The raw text output from an LLM.
 */
export async function extractClaims(rawText: string): Promise<LogicalClaim[]> {
  try {
    // Simulate an LLM extraction pipeline returning JSON string or structured payload
    // In a real-world scenario, you would prompt an LLM to return JSON matching this schema.
    const mockExtractedData = JSON.parse(rawText);

    // Ensure the payload is treated as an array of claims
    const claimsArray = Array.isArray(mockExtractedData) ? mockExtractedData : [mockExtractedData];

    // Validate and parse array elements against the LogicalClaimSchema
    const validatedClaims = z.array(LogicalClaimSchema).parse(claimsArray);

    return validatedClaims;
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error("Zod Validation Error during claim extraction:", JSON.stringify(error.issues, null, 2));
    } else {
      console.error("Unexpected parsing error:", error);
    }
    // Return empty fallback array or rethrow depending on downstream recovery policies
    return [];
  }
}
