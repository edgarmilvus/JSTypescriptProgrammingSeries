/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export class UnmappedPredicateError extends Error {
  constructor(predicate: string) {
    super(`Predicate '${predicate}' could not be resolved in the ontology.`);
    this.name = 'UnmappedPredicateError';
  }
}

/**
 * Normalizes entity strings for uniform Knowledge Graph URI matching.
 */
function normalizeEntity(entity: string): string {
  return entity
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '_');
}

/**
 * Maps a logical claim to a SPARQL ASK query against an RDF triplestore.
 * @param claim The validated logical claim.
 * @param ontologyMap A dictionary mapping natural predicates to RDF URIs.
 */
export function mapClaimToQuery(
  claim: { subject: string; predicate: string; object: string },
  ontologyMap: Map<string, string>
): string {
  const rdfPropertyUri = ontologyMap.get(claim.predicate.toLowerCase());

  if (!rdfPropertyUri) {
    throw new UnmappedPredicateError(claim.predicate);
  }

  // Normalize entities to match graph resource naming conventions
  const normalizedSubject = normalizeEntity(claim.subject);
  const normalizedObject = normalizeEntity(claim.object);

  // Construct a deterministic SPARQL ASK query string
  const sparqlAskQuery = `
    ASK {
      ex:${normalizedSubject} <${rdfPropertyUri}> ex:${normalizedObject} .
    }
  `.trim();

  return sparqlAskQuery;
}
