/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export type GuardrailStatus = 'PASSED' | 'MODIFIED' | 'REJECTED';

export interface GuardrailResult {
  status: GuardrailStatus;
  originalOutput: string;
  verifiedOutput: string;
  verificationReport: Array<{
    claim: string;
    verified: boolean;
    reason?: string;
  }>;
}

// Mock extraction helper matching Exercise 1 signature
async function extractClaimsInternal(text: string) {
  // Mock implementation for demonstration within middleware context
  return [{ subject: 'Acme Corp', predicate: 'acquired', object: 'StartupXYZ', confidence: 0.95 }];
}

/**
 * Intercepts LLM generation, runs graph verification, and applies guardrails.
 */
export async function enforceGuardrail(
  llmPrompt: string,
  generateFn: (prompt: string) => Promise<string>,
  dbClient: { query: (sparql: string) => Promise<boolean> }
): Promise<GuardrailResult> {
  const originalOutput = await generateFn(llmPrompt);
  const claims = await extractClaimsInternal(originalOutput);

  const verificationReport: Array<{ claim: string; verified: boolean; reason?: string }> = [];
  let hasCriticalFailure = false;
  let allVerified = true;

  for (const claim of claims) {
    const claimString = `${claim.subject} ${claim.predicate} ${claim.object}`;
    try {
      // Generate mock query or integrate mapClaimToQuery
      const mockSparql = `ASK { ex:${claim.subject} ex:${claim.predicate} ex:${claim.object} }`;
      const exists = await dbClient.query(mockSparql);

      if (exists) {
        verificationReport.push({ claim: claimString, verified: true });
      } else {
        allVerified = false;
        verificationReport.push({ 
          claim: claimString, 
          verified: false, 
          reason: 'Relation not found in Knowledge Graph.' 
        });

        if (claim.confidence > 0.8) {
          hasCriticalFailure = true;
        }
      }
    } catch (err: any) {
      allVerified = false;
      verificationReport.push({ 
        claim: claimString, 
        verified: false, 
        reason: `Verification execution error: ${err.message}` 
      });
      if (claim.confidence > 0.8) {
        hasCriticalFailure = true;
      }
    }
  }

  let status: GuardrailStatus = 'PASSED';
  let verifiedOutput = originalOutput;

  if (!allVerified) {
    if (hasCriticalFailure) {
      status = 'REJECTED';
      verifiedOutput = '[Guardrail: Generation rejected due to high-confidence unverified claims/hallucinations.]';
    } else {
      status = 'MODIFIED';
      verifiedOutput = originalOutput + '\n[Note: Some unverified peripheral claims were detected.]';
    }
  }

  return {
    status,
    originalOutput,
    verifiedOutput,
    verificationReport,
  };
}
