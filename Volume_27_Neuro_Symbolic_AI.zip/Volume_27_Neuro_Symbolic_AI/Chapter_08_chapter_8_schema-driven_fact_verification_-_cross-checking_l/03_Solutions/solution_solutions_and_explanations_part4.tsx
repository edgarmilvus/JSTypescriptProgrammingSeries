/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface GuardrailResultViewProps {
  result: {
    status: 'PASSED' | 'MODIFIED' | 'REJECTED';
    originalOutput: string;
    verifiedOutput: string;
    verificationReport: Array<{
      claim: string;
      verified: boolean;
      reason?: string;
    }>;
  };
}

/**
 * React Component for visualizing Zero-Hallucination Guardrail verification reports.
 */
export const FactVerificationDashboard: React.FC<GuardrailResultViewProps> = ({ result }) => {
  const [showRawText, setShowRawText] = useState(false);

  // Determine banner styling based on guardrail status
  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'PASSED':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'MODIFIED':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'REJECTED':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="p-6 border rounded-xl shadow-md bg-white max-w-2xl mx-auto font-sans">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Fact Verification Dashboard</h2>
        <span className={`px-3 py-1 text-sm font-semibold rounded-full border ${getStatusBadgeStyle(result.status)}`}>
          {result.status}
        </span>
      </div>

      {/* Verification Report List */}
      <div className="mb-6">
        <h3 className="text-md font-semibold text-gray-700 mb-3">Extracted Claims Audit</h3>
        {result.verificationReport.length === 0 ? (
          <p className="text-sm text-gray-500 italic">No claims extracted for this generation.</p>
        ) : (
          <ul className="space-y-2">
            {result.verificationReport.map((item, index) => (
              <li key={index} className="p-3 border rounded-lg flex justify-between items-center bg-gray-50">
                <span className="text-sm text-gray-800 font-medium">{item.claim}</span>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-0.5 text-xs rounded-md font-medium ${item.verified ? 'bg-green-200 text-green-900' : 'bg-red-200 text-red-900'}`}>
                    {item.verified ? 'Verified' : 'Hallucination'}
                  </span>
                  {item.reason && <span className="text-xs text-gray-500" title={item.reason}>ℹ️</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Toggle View for Raw vs Verified Output */}
      <div className="border-t pt-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-md font-semibold text-gray-700">Output Comparison</h3>
          <button
            onClick={() => setShowRawText(!showRawText)}
            className="text-xs text-blue-600 hover:underline font-medium"
          >
            {showRawText ? 'Show Verified Output' : 'Show Original Raw Output'}
          </button>
        </div>
        <div className="p-3 bg-gray-100 rounded-lg text-sm text-gray-700 whitespace-pre-wrap font-mono">
          {showRawText ? result.originalOutput : result.verifiedOutput}
        </div>
      </div>
    </div>
  );
};
