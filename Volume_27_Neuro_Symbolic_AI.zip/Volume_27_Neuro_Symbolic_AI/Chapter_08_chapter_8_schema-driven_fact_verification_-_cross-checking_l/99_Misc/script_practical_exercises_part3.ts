/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export type GuardrailStatus = 'PASSED' | 'MODIFIED' | 'REJECTED';

export interface GuardrailResult {
  status: GuardrailStatus;
  originalOutput: string;
  verifiedOutput: string;
  verificationReport: Array<{
    claim: string;
    verified: boolean;
    reason?: string;
  }>;
}

/**
 * Intercepts LLM generation, runs graph verification, and applies guardrails.
 */
export async function enforceGuardrail(
  llmPrompt: string,
  generateFn: (prompt: string) => Promise<string>,
  dbClient: { query: (sparql: string) => Promise<boolean> }
): Promise<GuardrailResult> {
  // TODO: 1. Generate text using generateFn
  // TODO: 2. Extract claims using extractClaims
  // TODO: 3. Verify each claim against dbClient
  // TODO: 4. Compile GuardrailResult and return
  throw new Error('Not implemented');
}
