/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Enterprise Knowledge Graph Deduplication & Entity Resolution Engine
 * 
 * This module provides deterministic record linkage and entity resolution 
 * for a SaaS customer profile graph, utilizing Jaro-Winkler string metrics
 * and deterministic property matching.
 */

// Define the shape of a raw incoming customer record from disparate sources
interface RawCustomerRecord {
  sourceId: string;
  sourceSystem: 'crm' | 'billing' | 'support';
  fullName: string;
  email: string;
  phone: string;
  company: string;
}

// Define the resolved, canonical entity node structure in the Knowledge Graph
interface CanonicalEntity {
  canonicalId: string;
  mergedSourceIds: string[];
  fullName: string;
  email: string;
  phone: string;
  company: string;
  confidenceScore: number;
}

/**
 * Computes the Jaro-Winkler similarity score between two strings.
 * Optimized for short strings like names and identifiers.
 * 
 * @param s1 - First string
 * @param s2 - Second string
 * @returns A similarity score between 0.0 (no match) and 1.0 (exact match)
 */
function jaroWinklerSimilarity(s1: string, s2: string): number {
  if (s1 === s2) return 1.0;
  if (!s1 || !s2) return 0.0;

  const str1 = s1.toLowerCase();
  const str2 = s2.toLowerCase();

  const len1 = str1.length;
  const len2 = str2.length;

  const maxDist = Math.floor(Math.max(len1, len2) / 2) - 1;
  if (maxDist < 0) return 0.0;

  const match1 = new Array(len1).fill(false);
  const match2 = new Array(len2).fill(false);

  let matches = 0;

  // Find matching characters within the dynamic window distance
  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - maxDist);
    const end = Math.min(i + maxDist + 1, len2);

    for (let j = start; j < end; j++) {
      if (!match2[j] && str1[i] === str2[j]) {
        match1[i] = true;
        match2[j] = true;
        matches++;
        break;
      }
    }
  }

  if (matches === 0) return 0.0;

  // Count transpositions
  let transpositions = 0;
  let k = 0;

  for (let i = 0; i < len1; i++) {
    if (match1[i]) {
      while (!match2[k]) k++;
      if (str1[i] !== str2[k]) transpositions++;
      k++;
    }
  }

  const m = matches;
  const t = transpositions / 2;

  // Jaro similarity formula
  const jaro = (m / len1 + m / len2 + (m - t) / m) / 3.0;

  // Jaro-Winkler modification: boost score for matching prefixes (up to 4 chars)
  let prefix = 0;
  for (let i = 0; i < Math.min(4, Math.min(len1, len2)); i++) {
    if (str1[i] === str2[i]) {
      prefix++;
    } else {
      break;
    }
  }

  const p = 0.1; // Standard scaling factor
  return jaro + prefix * p * (1.0 - jaro);
}

/**
 * Normalizes email addresses by trimming whitespace and lowercasing.
 */
function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Normalizes phone numbers by stripping all non-digit characters.
 */
function normalizePhone(phone: string): string {
  return phone.replace(/\D/g, '');
}

/**
 * Evaluates two customer records to determine if they represent the same real-world entity.
 * Uses deterministic rules for exact matches (normalized email/phone) and probabilistic 
 * Jaro-Winkler thresholds for name/company variations.
 * 
 * @param recordA - First customer record
 * @param recordB - Second customer record
 * @returns boolean indicating whether records should be merged
 */
function areRecordsMatching(recordA: RawCustomerRecord, recordB: RawCustomerRecord): boolean {
  // Rule 1: Deterministic match on normalized email
  const emailA = normalizeEmail(recordA.email);
  const emailB = normalizeEmail(recordB.email);
  if (emailA && emailB && emailA === emailB) {
    return true;
  }

  // Rule 2: Deterministic match on normalized phone number (if present and valid)
  const phoneA = normalizePhone(recordA.phone);
  const phoneB = normalizePhone(recordB.phone);
  if (phoneA.length >= 10 && phoneB.length >= 10 && phoneA === phoneB) {
    return true;
  }

  // Rule 3: Composite heuristic (High name similarity + matching company domain/name)
  const nameSimilarity = jaroWinklerSimilarity(recordA.fullName, recordB.fullName);
  const companySimilarity = jaroWinklerSimilarity(recordA.company, recordB.company);

  // If names match with high confidence (>= 0.92) and companies are similar (>= 0.85)
  if (nameSimilarity >= 0.92 && companySimilarity >= 0.85) {
    return true;
  }

  return false;
}

/**
 * Executes a deterministic entity resolution and deduplication pass over an array of raw records.
 * Constructs consolidated canonical entities for the knowledge graph.
 * 
 * @param rawRecords - Uncleaned raw records from multiple ingest pipelines
 * @returns Array of deduplicated CanonicalEntity objects
 */
function resolveEntities(rawRecords: RawCustomerRecord[]): CanonicalEntity[] {
  const canonicalMap: Map<string, CanonicalEntity> = new Map();
  const assignedSourceIds: Set<string> = new Set();

  for (let i = 0; i < rawRecords.length; i++) {
    const currentRecord = rawRecords[i];

    if (assignedSourceIds.has(currentRecord.sourceId)) {
      continue;
    }

    // Initialize a new canonical entity using the current record as the seed
    let baseEntity: CanonicalEntity = {
      canonicalId: `canon_${currentRecord.sourceId}`,
      mergedSourceIds: [currentRecord.sourceId],
      fullName: currentRecord.fullName,
      email: currentRecord.email,
      phone: currentRecord.phone,
      company: currentRecord.company,
      confidenceScore: 1.0,
    };

    assignedSourceIds.add(currentRecord.sourceId);

    // Compare against all remaining unassigned records
    for (let j = i + 1; j < rawRecords.length; j++) {
      const targetRecord = rawRecords[j];

      if (assignedSourceIds.has(targetRecord.sourceId)) {
        continue;
      }

      if (areRecordsMatching(baseEntity, {
        sourceId: targetRecord.sourceId,
        sourceSystem: targetRecord.sourceSystem,
        fullName: baseEntity.fullName,
        email: baseEntity.email,
        phone: baseEntity.phone,
        company: baseEntity.company
      }) || areRecordsMatching(currentRecord, targetRecord)) {
        
        // Merge record into the canonical entity
        baseEntity.mergedSourceIds.push(targetRecord.sourceId);
        assignedSourceIds.add(targetRecord.sourceId);

        // Update fields if target has higher fidelity data (e.g., more complete name)
        if (targetRecord.fullName.length > baseEntity.fullName.length) {
          baseEntity.fullName = targetRecord.fullName;
        }
      }
    }

    canonicalMap.set(baseEntity.canonicalId, baseEntity);
  }

  return Array.from(canonicalMap.values());
}

// ==========================================
// Execution Example (SaaS Customer Graph)
// ==========================================

const incomingStream: RawCustomerRecord[] = [
  {
    sourceId: "crm_101",
    sourceSystem: "crm",
    fullName: "Jonathan Smith-Wesson",
    email: "jon.smith@enterprise-saas.io",
    phone: "+1-555-019-2834",
    company: "Enterprise SaaS Corp"
  },
  {
    sourceId: "billing_202",
    sourceSystem: "billing",
    fullName: "Jon Smith-Wesson",
    email: "jon.smith@enterprise-saas.io",
    phone: "5550192834",
    company: "Enterprise SaaS Inc."
  },
  {
    sourceId: "support_303",
    sourceSystem: "support",
    fullName: "Jonathan Smith",
    email: "jsmith@otherdomain.com",
    phone: "+1-555-999-1111",
    company: "Acme Widgets"
  }
];

const resolvedGraphEntities = resolveEntities(incomingStream);
console.log(JSON.stringify(resolvedGraphEntities, null, 2));
