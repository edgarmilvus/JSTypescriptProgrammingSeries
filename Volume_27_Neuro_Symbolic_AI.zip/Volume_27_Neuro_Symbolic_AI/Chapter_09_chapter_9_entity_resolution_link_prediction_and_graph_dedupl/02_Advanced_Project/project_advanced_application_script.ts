/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file Enterprise Knowledge Graph Resolution and Link Prediction Pipeline
 * @author Neuro-Symbolic AI Architectures
 * @description Implements deterministic entity resolution, Jaro-Winkler distance metrication,
 * structural link prediction, and automated graph deduplication in TypeScript.
 */

import { performance } from 'perf_hooks';

// ============================================================================
// DOMAIN INTERTYPES & GRAPH STATE DEFINITIONS
// ============================================================================

/**
 * Represents a raw enterprise record ingested from disparate data silos.
 */
export interface RawRecord {
  readonly id: string;
  readonly name: string;
  readonly email: string;
  readonly organization: string;
  readonly taxId?: string;
}

/**
 * Represents a resolved, canonical entity node within the Knowledge Graph.
 */
export interface CanonicalEntity {
  readonly canonicalId: string;
  readonly mergedSourceIds: string[];
  readonly attributes: {
    readonly name: string;
    readonly normalizedEmail: string;
    readonly organization: string;
    readonly taxId?: string;
  };
  readonly confidenceScore: number;
}

/**
 * Represents a directed or undirected edge within the Knowledge Graph ontology.
 */
export interface GraphEdge {
  readonly sourceId: string;
  readonly targetId: string;
  readonly relationType: 'SAME_AS' | 'COLLABORATES_WITH' | 'SUBSIDIARY_OF';
  readonly weight: number;
  readonly inferred: boolean;
}

/**
 * The singular, canonical data structure passed across the resolution workflow.
 */
export interface GraphResolutionState {
  readonly rawRecords: Map<string, RawRecord>;
  readonly canonicalEntities: Map<string, CanonicalEntity>;
  readonly edges: GraphEdge[];
  readonly metrics: {
    readonly startTime: number;
    readonly endTime?: number;
    readonly duplicatePairsFound: number;
    readonly edgesPredicted: number;
  };
}

// ============================================================================
// STEP 1: DETERMINISTIC BLOCKING AND STRING METRICS (JARO-WINKLER)
// ============================================================================

/**
 * Computes the Jaro distance between two strings.
 * @param s1 First string
 * @param s2 Second string
 * @returns Jaro similarity score between 0.0 and 1.0
 */
function computeJaroDistance(s1: string, s2: string): number {
  if (s1 === s2) return 1.0;
  const len1 = s1.length;
  const len2 = s2.length;
  if (len1 === 0 || len2 === 0) return 0.0;

  const matchDistance = Math.floor(Math.max(len1, len2) / 2) - 1;
  const s1Matches = new Array(len1).fill(false);
  const s2Matches = new Array(len2).fill(false);

  let matches = 0;
  let transpositions = 0;

  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - matchDistance);
    const end = Math.min(i + matchDistance + 1, len2);
    for (let j = start; j < end; j++) {
      if (s2Matches[j]) continue;
      if (s1[i] !== s2[j]) continue;
      s1Matches[i] = true;
      s2Matches[j] = true;
      matches++;
      break;
    }
  }

  if (matches === 0) return 0.0;

  let k = 0;
  for (let i = 0; i < len1; i++) {
    if (!s1Matches[i]) continue;
    while (!s2Matches[k]) k++;
    if (s1[i] !== s2[k]) transpositions++;
    k++;
  }

  return (
    (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) /
}

/**
 * Computes the Jaro-Winkler string similarity metric with a standard scaling factor of 0.1.
 * @param s1 First string
 * @param s2 Second string
 * @returns Similarity score optimized for prefix matching
 */
export function computeJaroWinkler(s1: string, s2: string): number {
  const jaro = computeJaroDistance(s1, s2);
  let p = 0.1; // Scaling factor for prefix weight
  let l = 0;   // Length of common prefix up to 4 characters

  const maxPrefix = Math.min(4, Math.min(s1.length, s2.length));
  for (let i = 0; i < maxPrefix; i++) {
    if (s1[i] === s2[i]) {
      l++;
    } else {
      break;
    }
  }

  return jaro + l * p * (1.0 - jaro);
}

/**
 * Generates deterministic blocking keys to restrict the Cartesian product of record comparisons.
 * @param record Target raw enterprise record
 * @returns Array of deterministic blocking tokens (e.g., first 3 chars of name + domain)
 */
function generateBlockingKeys(record: RawRecord): string[] {
  const keys: string[] = [];
  const normalizedName = record.name.toLowerCase().replace(/[^a-z]/g, '');
  const domain = record.email.split('@')[1] || '';

  if (normalizedName.length >= 3) {
    keys.push(`name_${normalizedName.substring(0, 3)}`);
  }
  if (domain) {
    keys.push(`domain_${domain}`);
  }
  if (record.taxId) {
    keys.push(`tax_${record.taxId}`);
  }

  return keys;
}

// ============================================================================
// STEP 2: ENTITY RESOLUTION AND GRAPH DEDUPLICATION ENGINE
// ============================================================================

/**
 * Executes deterministic and probabilistic record linkage to cluster duplicate records.
 * @param state Current graph resolution state
 * @returns Updated state with consolidated canonical entities
 */
export function executeEntityResolution(state: GraphResolutionState): GraphResolutionState {
  const blockMap = new Map<string, string[]>();

  // Phase 1: Inverted Index Generation (Blocking)
  state.rawRecords.forEach((record, id) => {
    const keys = generateBlockingKeys(record);
    keys.forEach((key) => {
      const bucket = blockMap.get(key) || [];
      bucket.push(id);
      blockMap.set(key, bucket);
    });
  });

  const unionFindParent = new Map<string, string>();
  const find = (i: string): string => {
    let root = i;
    while (root !== unionFindParent.get(root)) {
      root = unionFindParent.get(root) || root;
    }
    let curr = i;
    while (curr !== root) {
      const next = unionFindParent.get(curr) || root;
      unionFindParent.set(curr, root);
      curr = next;
    }
    return root;
  };

  const union = (i: string, j: string) => {
    const rootI = find(i);
    const rootJ = find(j);
    if (rootI !== rootJ) {
      unionFindParent.set(rootI, rootJ);
    }
  };

  // Initialize Union-Find disjoint sets
  state.rawRecords.forEach((_, id) => {
    unionFindParent.set(id, id);
  });

  let duplicatePairsCount = 0;

  // Phase 2: Pairwise Comparison within Blocking Buckets
  blockMap.forEach((recordIds) => {
    const uniqueIds = Array.from(new Set(recordIds));
    for (let i = 0; i < uniqueIds.length; i++) {
      for (let j = i + 1; j < uniqueIds.length; j++) {
        const idA = uniqueIds[i];
        const idB = uniqueIds[j];
        const recA = state.rawRecords.get(idA)!;
        const recB = state.rawRecords.get(idB)!;

        // Hard deterministic match: Tax ID collision
        if (recA.taxId && recB.taxId && recA.taxId === recB.taxId) {
          union(idA, idB);
          duplicatePairsCount++;
          continue;
        }

        // Soft probabilistic match: Jaro-Winkler name similarity + email alignment
        const nameSim = computeJaroWinkler(recA.name.toLowerCase(), recB.name.toLowerCase());
        const emailMatch = recA.email.toLowerCase() === recB.email.toLowerCase() ? 1.0 : 0.0;

        // Composite scoring function
        const compositeScore = nameSim * 0.7 + emailMatch * 0.3;

        if (compositeScore >= 0.88) {
          union(idA, idB);
          duplicatePairsCount++;
        }
      }
    }
  });

  // Phase 3: Cluster Re-indexing into Canonical Entities
  const clusters = new Map<string, string[]>();
  state.rawRecords.forEach((_, id) => {
    const root = find(id);
    const members = clusters.get(root) || [];
    members.push(id);
    clusters.set(root, members);
  });

  const newCanonicalEntities = new Map<string, CanonicalEntity>();
  const initialEdges: GraphEdge[] = [...state.edges];

  clusters.forEach((memberIds, rootId) => {
    const primaryRecord = state.rawRecords.get(memberIds[0])!;
    const canonicalId = `canon_${rootId}`;

    newCanonicalEntities.set(canonicalId, {
      canonicalId,
      mergedSourceIds: memberIds,
      attributes: {
        name: primaryRecord.name,
        normalizedEmail: primaryRecord.email.toLowerCase().trim(),
        organization: primaryRecord.organization,
        taxId: primaryRecord.taxId,
      },
      confidenceScore: memberIds.length > 1 ? 0.95 : 1.0,
    });

    // Generate internal SAME_AS edges for traceability
    memberIds.forEach((sourceId) => {
      if (sourceId !== primaryRecord.id) {
        initialEdges.push({
          sourceId,
          targetId: canonicalId,
          relationType: 'SAME_AS',
          weight: 1.0,
          inferred: false,
        });
      }
    });
  });

  return {
    ...state,
    canonicalEntities: newCanonicalEntities,
    edges: initialEdges,
    metrics: {
      ...state.metrics,
      duplicatePairsFound: duplicatePairsCount,
    },
  };
}

// ============================================================================
// STEP 3: TRANSDUCTIVE LINK PREDICTION VIA STRUCTURAL OVERLAP
// ============================================================================

/**
 * Computes Jaccard structural overlap between two nodes to predict missing collaboration edges.
 * @param nodeA First canonical entity ID
 * @param nodeB Second canonical entity ID
 * @param adjacencyList Graph adjacency map
 * @returns Jaccard similarity coefficient
 */
function computeJaccardCoefficient(
  nodeA: string,
  nodeB: string,
  adjacencyList: Map<string, Set<string>>
): number {
  const neighborsA = adjacencyList.get(nodeA) || new Set();
  const neighborsB = adjacencyList.get(nodeB) || new Set();

  if (neighborsA.size === 0 && neighborsB.size === 0) return 0.0;

  let intersectionSize = 0;
  neighborsA.forEach((n) => {
    if (neighborsB.has(n)) intersectionSize++;
  });

  const unionSize = neighborsA.size + neighborsB.size - intersectionSize;
  if (unionSize === 0) return 0.0;

  return intersectionSize / unionSize;
}

/**
 * Executes transductive link prediction to discover and assert missing ontological edges.
 * @param state Current graph resolution state
 * @returns Updated state with newly inferred ontological edges
 */
export function executeLinkPrediction(state: GraphResolutionState): GraphResolutionState {
  const adjacencyList = new Map<string, Set<string>>();

  // Build structural adjacency index
  state.edges.forEach((edge) => {
    if (!adjacencyList.has(edge.sourceId)) adjacencyList.set(edge.sourceId, new Set());
    if (!adjacencyList.has(edge.targetId)) adjacencyList.set(edge.targetId, new Set());
    adjacencyList.get(edge.sourceId)!.add(edge.targetId);
    adjacencyList.get(edge.targetId)!.add(edge.sourceId);
  });

  const canonicalIds = Array.from(state.canonicalEntities.keys());
  const inferredEdges: GraphEdge[] = [...state.edges];
  let predictedCount = 0;

  // Evaluate structural overlap across unlinked node pairs
  for (let i = 0; i < canonicalIds.length; i++) {
    for (let j = i + 1; j < canonicalIds.length; j++) {
      const idA = canonicalIds[i];
      const idB = canonicalIds[j];

      const neighborsA = adjacencyList.get(idA);
      const alreadyConnected = neighborsA ? neighborsA.has(idB) : false;

      if (!alreadyConnected) {
        const score = computeJaccardCoefficient(idA, idB, adjacencyList);
        // Deterministic threshold for structural link inference
        if (score >= 0.45) {
          inferredEdges.push({
            sourceId: idA,
            targetId: idB,
            relationType: 'COLLABORATES_WITH',
            weight: Number(score.toFixed(4)),
            inferred: true,
          });
          predictedCount++;
        }
      }
    }
  }

  return {
    ...state,
    edges: inferredEdges,
    metrics: {
      ...state.metrics,
      edgesPredicted: predictedCount,
      endTime: performance.now(),
    },
  };
}

// ============================================================================
// STEP 4: NEXT.JS / SAAS PIPELINE ORCHESTRATION ENTRY POINT
// ============================================================================

/**
 * Orchestrates the full zero-hallucination graph reconciliation and deduction pipeline.
 * @param rawInputRecords Array of dirty enterprise ingest records
 * @returns Complete resolution state report for enterprise audit trails
 */
export function runEnterprisePipeline(rawInputRecords: RawRecord[]): {
  canonicalNodes: CanonicalEntity[];
  edges: GraphEdge[];
  executionTimeMs: number;
  duplicatePairsFound: number;
  edgesPredicted: number;
} {
  const startTime = performance.now();

  const rawMap = new Map<string, RawRecord>();
  rawInputRecords.forEach((rec) => rawMap.set(rec.id, rec));

  let currentState: GraphResolutionState = {
    rawRecords: rawMap,
    canonicalEntities: new Map(),
    edges: [],
    metrics: {
      startTime,
      duplicatePairsFound: 0,
      edgesPredicted: 0,
    },
  };

  // Stage 1: Deterministic & Probabilistic Entity Resolution
  currentState = executeEntityResolution(currentState);

  // Stage 2: Structural Link Prediction
  currentState = executeLinkPrediction(currentState);

  const endTime = currentState.metrics.endTime || performance.now();

  return {
    canonicalNodes: Array.from(currentState.canonicalEntities.values()),
    edges: currentState.edges,
    executionTimeMs: Number((endTime - startTime).toFixed(2)),
    duplicatePairsFound: currentState.metrics.duplicatePairsFound,
    edgesPredicted: currentState.metrics.edgesPredicted,
  };
}
