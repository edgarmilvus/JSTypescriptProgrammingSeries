/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface RawEntity {
  id: string;
  name: string;
  category: string;
  metadata: Record<string, string>;
}

export class DisjointSet {
  private parent: Map<string, string> = new Map();
  private rank: Map<string, number> = new Map();

  constructor(elements: string[]) {
    for (const el of elements) {
      this.parent.set(el, el);
      this.rank.set(el, 0);
    }
  }

  public find(i: string): string {
    if (!this.parent.has(i)) {
      this.parent.set(i, i);
      this.rank.set(i, 0);
      return i;
    }
    if (this.parent.get(i) !== i) {
      this.parent.set(i, this.find(this.parent.get(i)!));
    }
    return this.parent.get(i)!;
  }

  public union(i: string, j: string): void {
    const rootI = this.find(i);
    const rootJ = this.find(j);

    if (rootI !== rootJ) {
      const rankI = this.rank.get(rootI)!;
      const rankJ = this.rank.get(rootJ)!;

      if (rankI < rankJ) {
        this.parent.set(rootI, rootJ);
      } else if (rankI > rankJ) {
        this.parent.set(rootJ, rootI);
      } else {
        this.parent.set(rootJ, rootI);
        this.rank.set(rootI, rankI + 1);
      }
    }
  }
}

export function blockEntities(entities: RawEntity[]): Map<string, RawEntity[]> {
  const blocks = new Map<string, RawEntity[]>();
  for (const entity of entities) {
    const normalized = entity.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const blockKey = normalized.slice(0, 3) || 'unk';
    if (!blocks.has(blockKey)) {
      blocks.set(blockKey, []);
    }
    blocks.get(blockKey)!.push(entity);
  }
  return blocks;
}

function jaroDistance(s1: string, s2: string): number {
  if (s1 === s2) return 1.0;
  const len1 = s1.length;
  const len2 = s2.length;
  if (len1 === 0 || len2 === 0) return 0.0;

  const matchDistance = Math.floor(Math.max(len1, len2) / 2) - 1;
  const s1Matches = new Array(len1).fill(false);
  const s2Matches = new Array(len2).fill(false);

  let matches = 0;
  let transpositions = 0;

  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - matchDistance);
    const end = Math.min(i + matchDistance + 1, len2);
    for (let j = start; j < end; j++) {
      if (!s2Matches[j] && s1[i] === s2[j]) {
        s1Matches[i] = true;
        s2Matches[j] = true;
        matches++;
        break;
      }
    }
  }

  if (matches === 0) return 0.0;

  let k = 0;
  for (let i = 0; i < len1; i++) {
    if (s1Matches[i]) {
      while (!s2Matches[k]) k++;
      if (s1[i] !== s2[k]) transpositions++;
      k++;
    }
  }

  const m = matches;
  return (m / len1 + m / len2 + (m - transpositions / 2) / m) / 3.0;
}

export function jaroWinklerDistance(s1: string, s2: string): number {
  const jaro = jaroDistance(s1, s2);
  let p = 0.1;
  let l = 0;
  const maxL = Math.min(4, Math.min(s1.length, s2.length));
  while (l < maxL && s1[l] === s2[l]) {
    l++;
  }
  return jaro + l * p * (1 - jaro);
}

function tokenize(str: string): string[] {
  return str.toLowerCase().split(/\W+/).filter(Boolean);
}

function cosineSimilarity(tokens1: string[], tokens2: string[]): number {
  const freq1 = new Map<string, number>();
  const freq2 = new Map<string, number>();
  const vocab = new Set<string>();

  for (const t of tokens1) {
    freq1.set(t, (freq1.get(t) || 0) + 1);
    vocab.add(t);
  }
  for (const t of tokens2) {
    freq2.set(t, (freq2.get(t) || 0) + 1);
    vocab.add(t);
  }

  let dotProduct = 0;
  let norm1 = 0;
  let norm2 = 0;

  for (const word of vocab) {
    const v1 = freq1.get(word) || 0;
    const v2 = freq2.get(word) || 0;
    dotProduct += v1 * v2;
    norm1 += v1 * v1;
    norm2 += v2 * v2;
  }

  if (norm1 === 0 || norm2 === 0) return 0.0;
  return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
}

export function calculateSimilarity(e1: RawEntity, e2: RawEntity): number {
  const jw = jaroWinklerDistance(e1.name, e2.name);
  const tfidf = cosineSimilarity(tokenize(e1.name), tokenize(e2.name));
  return 0.7 * jw + 0.3 * tfidf;
}

export function resolveEntities(entities: RawEntity[], threshold = 0.88): Map<string, string> {
  const ds = new DisjointSet(entities.map(e => e.id));
  const blocks = blockEntities(entities);

  for (const [, blockEntitiesList] of blocks) {
    for (let i = 0; i < blockEntitiesList.length; i++) {
      for (let j = i + 1; j < blockEntitiesList.length; j++) {
        const e1 = blockEntitiesList[i];
        const e2 = blockEntitiesList[j];
        if (calculateSimilarity(e1, e2) >= threshold) {
          ds.union(e1.id, e2.id);
        }
      }
    }
  }

  const mapping = new Map<string, string>();
  for (const entity of entities) {
    mapping.set(entity.id, ds.find(entity.id));
  }
  return mapping;
}

export function resolveIncomingEntity(
  incoming: RawEntity,
  existingCanonicalNodes: Map<string, RawEntity>,
  threshold = 0.88
): { canonicalId: string; isMerged: boolean } {
  const normalized = incoming.name.toLowerCase().replace(/[^a-z0-9]/g, '');
  const blockKey = normalized.slice(0, 3) || 'unk';

  let bestMatchId: string | null = null;
  let highestScore = 0;

  for (const [canonicalId, existingNode] of existingCanonicalNodes.entries()) {
    const existingNorm = existingNode.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const existingBlock = existingNorm.slice(0, 3) || 'unk';

    if (existingBlock === blockKey) {
      const score = calculateSimilarity(incoming, existingNode);
      if (score > highestScore) {
        highestScore = score;
        bestMatchId = canonicalId;
      }
    }
  }

  if (highestScore >= threshold && bestMatchId) {
    return { canonicalId: bestMatchId, isMerged: true };
  } else {
    return { canonicalId: incoming.id, isMerged: false };
  }
}
