/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export class GraphTopology {
  private outgoing: Map<string, Set<string>> = new Map();
  private incoming: Map<string, Set<string>> = new Map();

  public addEdge(u: string, v: string): void {
    if (!this.outgoing.has(u)) this.outgoing.set(u, new Set());
    this.outgoing.get(u)!.add(v);

    if (!this.incoming.has(v)) this.incoming.set(v, new Set());
    this.incoming.get(v)!.add(u);

    if (!this.outgoing.has(v)) this.outgoing.set(v, new Set());
    if (!this.incoming.has(u)) this.incoming.set(u, new Set());
  }

  public getNeighbors(node: string): string[] {
    const out = this.outgoing.get(node) || new Set();
    const inc = this.incoming.get(node) || new Set();
    return Array.from(new Set([...out, ...inc]));
  }

  public commonNeighbors(u: string, v: string): string[] {
    const neighborsU = new Set(this.getNeighbors(u));
    const neighborsV = new Set(this.getNeighbors(v));
    const common: string[] = [];
    for (const n of neighborsU) {
      if (neighborsV.has(n)) {
        common.push(n);
      }
    }
    return common;
  }

  public adamicAdar(u: string, v: string): number {
    const common = this.commonNeighbors(u, v);
    let score = 0;
    for (const z of common) {
      const degree = this.getNeighbors(z).length;
      if (degree > 1) {
        score += 1 / Math.log(degree);
      }
    }
    return score;
  }

  public resourceAllocation(u: string, v: string): number {
    const common = this.commonNeighbors(u, v);
    let score = 0;
    for (const z of common) {
      const degree = this.getNeighbors(z).length;
      if (degree > 0) {
        score += 1 / degree;
      }
    }
    return score;
  }

  public preferentialAttachment(u: string, v: string): number {
    const degU = this.getNeighbors(u).length;
    const degV = this.getNeighbors(v).length;
    return degU * degV;
  }

  public scorePotentialEdge(
    u: string,
    v: string,
    weights = { cn: 0.25, aa: 0.25, ra: 0.25, pa: 0.25 }
  ): number {
    const cn = this.commonNeighbors(u, v).length;
    const aa = this.adamicAdar(u, v);
    const ra = this.resourceAllocation(u, v);
    const pa = this.preferentialAttachment(u, v);

    // Min-max normalization proxies or direct weight combination
    return weights.cn * cn + weights.aa * aa + weights.ra * ra + weights.pa * (pa > 0 ? Math.log(pa) : 0);
  }

  public predictMissingEdges(
    threshold: number,
    weights = { cn: 0.25, aa: 0.25, ra: 0.25, pa: 0.25 }
  ): Array<{ source: string; target: string; score: number }> {
    const nodes = Array.from(this.outgoing.keys());
    const predictions: Array<{ source: string; target: string; score: number }> = [];
    const existingEdges = new Set<string>();

    for (const [src, targets] of this.outgoing.entries()) {
      for (const tgt of targets) {
        existingEdges.add(`${src}->${tgt}`);
        existingEdges.add(`${tgt}->${src}`);
      }
    }

    // Scan localized 2-hop neighborhoods
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const u = nodes[i];
        const v = nodes[j];

        if (existingEdges.has(`${u}->${v}`)) continue;

        const common = this.commonNeighbors(u, v);
        if (common.length > 0) {
          const score = this.scorePotentialEdge(u, v, weights);
          if (score >= threshold) {
            predictions.push({ source: u, target: v, score });
          }
        }
      }
    }

    return predictions.sort((a, b) => b.score - a.score);
  }
}
