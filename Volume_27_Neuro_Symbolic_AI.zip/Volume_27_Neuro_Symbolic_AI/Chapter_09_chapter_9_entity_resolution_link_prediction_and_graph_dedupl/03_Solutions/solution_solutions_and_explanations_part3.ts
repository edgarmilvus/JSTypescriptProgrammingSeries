/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface GraphNode {
  id: string;
  properties: Record<string, any>;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: string;
  properties: Record<string, any>;
}

export interface GraphTransaction {
  steps: Array<{
    type: 'MERGE_PROPERTIES' | 'REPOINT_EDGES' | 'PRUNE_NODES';
    payload: any;
  }>;
}

export class MutableGraphStore {
  public nodes: Map<string, GraphNode> = new Map();
  public edges: Map<string, GraphEdge> = new Map();

  public clone(): MutableGraphStore {
    const cloned = new MutableGraphStore();
    for (const [k, v] of this.nodes.entries()) {
      cloned.nodes.set(k, { id: v.id, properties: { ...v.properties } });
    }
    for (const [k, v] of this.edges.entries()) {
      cloned.edges.set(k, {
        id: v.id,
        source: v.source,
        target: v.target,
        type: v.type,
        properties: { ...v.properties }
      });
    }
    return cloned;
  }
}

export class DeduplicationPlanner {
  constructor(private graph: MutableGraphStore) {}

  public planMerge(canonicalId: string, duplicateIds: string[]): GraphTransaction {
    const steps: GraphTransaction['steps'] = [];

    // Step 1: Property consolidation
    steps.push({
      type: 'MERGE_PROPERTIES',
      payload: { canonicalId, duplicateIds }
    });

    // Step 2: Edge re-pointing
    steps.push({
      type: 'REPOINT_EDGES',
      payload: { canonicalId, duplicateIds }
    });

    // Step 3: Node pruning
    steps.push({
      type: 'PRUNE_NODES',
      payload: { duplicateIds }
    });

    return { steps };
  }

  public validateTransaction(tx: GraphTransaction): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    for (const step of tx.steps) {
      if (step.type === 'MERGE_PROPERTIES') {
        if (!this.graph.nodes.has(step.payload.canonicalId)) {
          errors.id = `Canonical node ${step.payload.canonicalId} missing from graph.`;
        }
      }
      if (step.type === 'PRUNE_NODES') {
        for (const dupId of step.payload.duplicateIds) {
          if (!this.graph.nodes.has(dupId)) {
            errors.push(`Duplicate node ${dupId} missing from graph.`);
          }
        }
      }
    }
    return { valid: errors.length === 0, errors };
  }

  public executeWithRollback(tx: GraphTransaction): boolean {
    const validation = this.validateTransaction(tx);
    if (!validation.valid) return false;

    const snapshot = this.graph.clone();

    try {
      for (const step of tx.steps) {
        if (step.type === 'MERGE_PROPERTIES') {
          const canonical = this.graph.nodes.get(step.payload.canonicalId)!;
          for (const dupId of step.payload.duplicateIds) {
            const dup = this.graph.nodes.get(dupId);
            if (dup) {
              canonical.properties = { ...dup.properties, ...canonical.properties };
            }
          }
        } else if (step.type === 'REPOINT_EDGES') {
          const { canonicalId, duplicateIds } = step.payload;
          const dupSet = new Set(duplicateIds);

          for (const edge of this.graph.edges.values()) {
            if (dupSet.has(edge.source)) edge.source = canonicalId;
            if (dupSet.has(edge.target)) edge.target = canonicalId;
          }

          // Deduplicate edges
          const uniqueEdges = new Map<string, GraphEdge>();
          for (const edge of this.graph.edges.values()) {
            const key = `${edge.source}-${edge.target}-${edge.type}`;
            uniqueEdges.set(key, edge);
          }
          this.graph.edges = uniqueEdges;
        } else if (step.type === 'PRUNE_NODES') {
          for (const dupId of step.payload.duplicateIds) {
            this.graph.nodes.delete(dupId);
          }
        }
      }
      return true;
    } catch (e) {
      // Revert state on failure
      this.graph = snapshot;
      return false;
    }
  }
}
