/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface RawEntity {
  id: string;
  name: string;
  category: string;
  metadata: Record<string, string>;
}

interface ReviewPanelProps {
  candidatePair: {
    entityA: RawEntity;
    entityB: RawEntity;
    similarityScore: number;
    sharedNeighbors: string[];
  };
  onApproveMerge: (canonicalId: string, duplicateId: string) => Promise<void>;
  onRejectMatch: (idA: string, idB: string) => void;
}

export const EntityResolutionReviewPanel: React.FC<ReviewPanelProps> = ({
  candidatePair,
  onApproveMerge,
  onRejectMatch,
}) => {
  const [loading, setLoading] = useState(false);
  const [resolved, setResolved] = useState(false);

  const { entityA, entityB, similarityScore, sharedNeighbors } = candidatePair;

  const handleMerge = async () => {
    setLoading(true);
    try {
      await onApproveMerge(entityA.id, entityB.id);
      setResolved(true);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = () => {
    onRejectMatch(entityA.id, entityB.id);
    setResolved(true);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px', maxWidth: '600px', fontFamily: 'sans-serif' }}>
      <h3>Entity Resolution Review</h3>
      <p>Composite Similarity Score: <strong>{(similarityScore * 100).toFixed(1)}%</strong></p>
      
      <div style={{ display: 'flex', gap: '16px', marginBottom: '16px' }}>
        <div style={{ flex: 1, background: '#f9f9f9', padding: '12px', borderRadius: '4px' }}>
          <h4>Entity A (Canonical Candidate)</h4>
          <p><strong>Name:</strong> {entityA.name}</p>
          <p><strong>Category:</strong> {entityA.category}</p>
        </div>
        <div style={{ flex: 1, background: '#f9f9f9', padding: '12px', borderRadius: '4px' }}>
          <h4>Entity B (Duplicate Candidate)</h4>
          <p><strong>Name:</strong> {entityB.name}</p>
          <p><strong>Category:</strong> {entityB.category}</p>
        </div>
      </div>

      <div style={{ marginBottom: '16px' }}>
        <strong>Shared Structural Neighbors:</strong>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '8px' }}>
          {sharedNeighbors.length > 0 ? (
            sharedNeighbors.map((n, idx) => (
              <span key={idx} style={{ background: '#e0f2fe', color: '#0369a1', padding: '4px 8px', borderRadius: '12px', fontSize: '12px' }}>
                {n}
              </span>
            ))
          ) : (
            <span style={{ color: '#666', fontStyle: 'italic' }}>No shared neighbors</span>
          )}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '12px' }}>
        <button
          onClick={handleMerge}
          disabled={loading || resolved}
          style={{ background: '#10b981', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '4px', cursor: 'pointer' }}
        >
          {loading ? 'Merging...' : 'Approve Merge'}
        </button>
        <button
          onClick={handleReject}
          disabled={loading || resolved}
          style={{ background: '#ef4444', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '4px', cursor: 'pointer' }}
        >
          Reject Match
        </button>
      </div>
      {resolved && <p style={{ color: '#10b981', marginTop: '8px' }}>Decision recorded.</p>}
    </div>
  );
};

interface BatchQueueProps {
  initialPairs: Array<{
    entityA: RawEntity;
    entityB: RawEntity;
    similarityScore: number;
    sharedNeighbors: string[];
  }>;
  onApproveMerge: (canonicalId: string, duplicateId: string) => Promise<void>;
  onRejectMatch: (idA: string, idB: string) => void;
}

export const BatchResolutionQueue: React.FC<BatchQueueProps> = ({
  initialPairs,
  onApproveMerge,
  onRejectMatch,
}) => {
  const [pairs, setPairs] = useState(initialPairs);
  const [currentIndex, setCurrentIndex] = useState(0);

  const total = initialPairs.length;
  const progress = total === 0 ? 100 : ((total - pairs.length) / total) * 100;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (pairs.length === 0) return;
      if (e.key === 'ArrowRight') {
        handleCurrentMerge();
      } else if (e.key === 'ArrowLeft') {
        handleCurrentReject();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pairs]);

  const handleCurrentMerge = async () => {
    if (pairs.length === 0) return;
    const current = pairs[0];
    await onApproveMerge(current.entityA.id, current.entityB.id);
    setPairs(pairs.slice(1));
  };

  const handleCurrentReject = () => {
    if (pairs.length === 0) return;
    const current = pairs[0];
    onRejectMatch(current.entityA.id, current.entityB.id);
    setPairs(pairs.slice(1));
  };

  if (pairs.length === 0) {
    return <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>All entity resolution pairs reviewed!</div>;
  }

  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: '650px' }}>
      <div style={{ marginBottom: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
          <span>Resolution Progress</span>
          <span>{progress.toFixed(0)}%</span>
        </div>
        <div style={{ background: '#e5e7eb', height: '8px', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ width: `${progress}%`, background: '#3b82f6', height: '100%', transition: 'width 0.3s' }} />
        </div>
      </div>
      <EntityResolutionReviewPanel
        candidatePair={pairs[0]}
        onApproveMerge={async (cId, dId) => {
          await onApproveMerge(cId, dId);
          setPairs(pairs.slice(1));
        }}
        onRejectMatch={(idA, idB) => {
          onRejectMatch(idA, idB);
          setPairs(pairs.slice(1));
        }}
      />
    </div>
  );
};
