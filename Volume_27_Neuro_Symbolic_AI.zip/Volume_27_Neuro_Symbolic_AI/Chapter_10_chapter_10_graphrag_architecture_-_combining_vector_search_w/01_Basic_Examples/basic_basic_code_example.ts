/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { GoogleGenerativeAI } from '@google/genai';

/**
 * @file GraphRAG Basic Code Example
 * @description Demonstrates combining vector embeddings with knowledge graph traversal 
 * for deterministic, zero-hallucination SaaS support answers.
 */

// Initialize the Google Gen AI SDK.
// Ensure GEMINI_API_KEY is set in your environment variables.
const ai = new GoogleGenerativeAI();

/**
 * Represents a node in our SaaS Knowledge Graph.
 */
interface GraphNode {
    id: string;
    label: string;
    properties: Record<string, any>;
}

/**
 * Represents a directed edge in our SaaS Knowledge Graph.
 */
interface GraphEdge {
    source: string;
    target: string;
    relation: string;
}

/**
 * Represents the combined hybrid search output.
 */
interface GraphRAGContext {
    entryNode: GraphNode;
    neighbors: {
        edge: GraphEdge;
        node: GraphNode;
    }[];
}

/**
 * Mock Vector Database client simulating semantic similarity search over enterprise documentation.
 */
class MockVectorDB {
    /**
     * Performs a vector similarity search to find the most relevant graph entity ID.
     * @param query The user's natural language input.
     * @returns The string ID of the matched knowledge graph node.
     */
    async searchNearestNode(query: string): Promise<string> {
        console.log(`[VectorDB] Embedding query & searching index: "${query}"`);
        // In a real application, you would generate an embedding using ai.models.embedContent
        // and query Pinecone, Qdrant, or pgvector.
        if (query.toLowerCase().includes('auth') || query.toLowerCase().includes('token')) {
            return 'node_endpoint_auth';
        }
        return 'node_default_fallback';
    }
}

/**
 * Mock Knowledge Graph Database client simulating property graph navigation.
 */
class MockGraphDB {
    private nodes: Map<string, GraphNode> = new Map([
        ['node_endpoint_auth', {
            id: 'node_endpoint_auth',
            label: 'API_Endpoint',
            properties: { path: '/v1/auth/token', method: 'POST', status: 'Deprecated' }
        }],
        ['node_policy_oauth', {
            id: 'node_policy_oauth',
            label: 'Security_Policy',
            properties: { name: 'OAuth2 Mandatory', enforcementDate: '2025-01-01' }
        }],
        ['node_doc_migration', {
            id: 'node_doc_migration',
            label: 'Documentation',
            properties: { title: 'Migrating to OAuth2 Tokens', url: 'https://docs.saas.com/mig-oauth2' }
        }]
    ]);

    private edges: GraphEdge[] = [
        { source: 'node_endpoint_auth', target: 'node_policy_oauth', relation: 'GOVERNED_BY' },
        { source: 'node_endpoint_auth', target: 'node_doc_migration', relation: 'HAS_MIGRATION_GUIDE' }
    ];

    /**
     * Traverses the graph to fetch a node and its direct 1-hop neighbors.
     * @param nodeId The starting node ID identified by vector search.
     */
    async getSubgraph(nodeId: string): Promise<GraphRAGContext> {
        console.log(`[GraphDB] Traversing ontological edges for node ID: ${nodeId}`);
        const entryNode = this.nodes.get(nodeId);
        if (!entryNode) {
            throw new Error(`Graph entity not found for ID: ${nodeId}`);
        }

        const relatedEdges = this.edges.filter(e => e.source === nodeId);
        const neighbors = relatedEdges.map(edge => {
            const targetNode = this.nodes.get(edge.target)!;
            return { edge, node: targetNode };
        });

        return { entryNode, neighbors };
    }
}

/**
 * Main execution function running the GraphRAG pipeline.
 */
async function runGraphRAGPipeline(userQuery: string): Promise<string> {
    console.log(`\n--- Starting GraphRAG Pipeline ---`);
    console.log(`User Query: "${userQuery}"`);

    const vectorDb = new MockVectorDB();
    const graphDb = new MockGraphDB();

    // Step 1: Vector Search to locate entry point
    const entryNodeId = await vectorDb.searchNearestNode(userQuery);

    // Step 2: Knowledge Graph Traversal to extract deterministic context
    const subgraphContext = await graphDb.getSubgraph(entryNodeId);

    // Step 3: Serialize context into a strictly structured format for the LLM
    const serializedContext = JSON.stringify(subgraphContext, null, 2);

    // Step 4: Construct a deterministic prompt enforcing zero hallucinations
    const systemInstruction = `
You are a deterministic SaaS technical support assistant. 
You must answer the user's query EXCLUSIVELY using the provided JSON Knowledge Graph context. 
If the answer cannot be derived directly from the provided JSON nodes and relationships, state: "I cannot find this information in the verified system records."
Do NOT extrapolate, guess, or use external knowledge.
`;

    const prompt = `
[KNOWLEDGE GRAPH CONTEXT]
${serializedContext}

[USER QUERY]
${userQuery}

[INSTRUCTIONS]
Provide a concise, accurate support response based ONLY on the graph context above.
`;

    console.log(`[LLM] Dispatching prompt to Gemini...`);

    // Step 5: Generate response using Google Gen AI SDK
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.0 // Zero temperature ensures deterministic output
        }
    });

    return response.text ?? 'No response generated.';
}

// Execute the pipeline locally
(async () => {
    try {
        const query = "Why is my API authentication request failing on the token endpoint?";
        const answer = await runGraphRAGPipeline(query);
        console.log(`\n--- Final Generated Answer ---`);
        console.log(answer);
    } catch (error) {
        console.error("Pipeline execution failed:", error);
    }
})();
