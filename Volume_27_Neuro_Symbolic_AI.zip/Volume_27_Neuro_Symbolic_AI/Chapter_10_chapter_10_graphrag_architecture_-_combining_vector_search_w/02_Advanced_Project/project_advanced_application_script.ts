/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Neo4j, Session } from 'neo4j-driver';
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';

/**
 * Interface representing a hybrid search result combining semantic vector distance 
 * and explicit graph traversal paths.
 */
interface HybridContextNode {
    entityId: string;
    name: string;
    type: string;
    summary: string;
    vectorScore: number;
    graphNeighborhood: string[];
}

/**
 * Enterprise GraphRAG Orchestration Service.
 * Combines vector search isolation (Pinecone Namespaces) with deterministic 
 * ontological graph traversals (Neo4j) to prevent LLM hallucinations.
 */
export class GraphRAGOrchestrator {
    private neo4jSession: Session;
    private pineconeIndex: any;
    private openai: OpenAI;
    private tenantNamespace: string;

    /**
     * Initializes the GraphRAG pipeline components.
     * @param neo4jDriver Initialized Neo4j driver instance.
     * @param pineconeClient Initialized Pinecone client instance.
     * @param openaiApiKey API key for generating vector embeddings and completions.
     * @param tenantId The unique tenant identifier used as a logical Pinecone namespace.
     */
    constructor(
        neo4jDriver: Neo4j,
        pineconeClient: Pinecone,
        openaiApiKey: string,
        tenantId: string
    ) {
        this.neo4jSession = neo4jDriver.session();
        // Isolate vector indexes per tenant using Pinecone namespaces
        this.pineconeIndex = pineconeClient.index('enterprise-knowledge');
        this.tenantNamespace = `tenant-${tenantId}`;
        this.openai = new OpenAI({ apiKey: openaiApiKey });
    }

    /**
     * Generates a 1536-dimensional vector embedding for the input query string.
     * @param text The natural language query.
     */
    private async generateEmbedding(text: string): Promise<number[]> {
        const response = await this.openai.embeddings.create({
            model: 'text-embedding-3-small',
            input: text,
        });
        return response.data[0].embedding;
    }

    /**
     * Executes a hybrid retrieval query combining approximate nearest neighbor vector search
     * within a specific namespace and deterministic multi-hop graph exploration.
     * 
     * @param naturalLanguageQuery The user's prompt.
     * @param maxHops Maximum graph traversal depth for ontological relationships.
     */
    public async query(naturalLanguageQuery: string, maxHops: number = 2): Promise<string> {
        // Step 1: Generate semantic embedding for the user prompt
        const queryVector = await this.generateEmbedding(naturalLanguageQuery);

        // Step 2: Query Pinecone vector database inside the tenant's logical namespace
        const namespaceIndex = this.pinecone.namespace(this.tenantNamespace);
        const vectorResults = await namespaceIndex.query({
            vector: queryVector,
            topK: 5,
            includeMetadata: true,
        });

        // Extract top matching entity identifiers from vector similarity scores
        const seedEntityIds = vectorResults.matches.map((match: { metadata: { entityId: any; }; }) => match.metadata.entityId);

        if (seedEntityIds.length === 0) {
            return "No relevant context found within the organizational knowledge base.";
        }

        // Step 3: Execute deterministic Graph traversal using Neo4j Cypher
        // We anchor our traversal to the seed entities discovered via vector search
        // and traverse outward up to `maxHops` steps to gather strict factual relationships.
        const cypherQuery = `
            MATCH (start:Entity)
            WHERE start.id IN $seedEntityIds
            CALL apoc.path.subgraphNodes(start, {
                maxLevel: $maxHops,
                relationshipFilter: 'DEPENDS_ON|IMPLEMENTS|REFERENCES|OWNS'
            }) YIELD node
            RETURN DISTINCT node.id AS entityId, 
                            node.name AS name, 
                            node.type AS type, 
                            node.summary AS summary,
                            [(node)-[r]-(neighbor) | type(r) + ' -> ' + neighbor.name] as neighborhood
        `;

        const graphResult = await this.neo4jSession.run(cypherQuery, {
            seedEntityIds,
            maxHops: neo4j.int(maxHops)
        });

        // Step 4: Aggregate and format the retrieved context nodes
        const assembledContext: HybridContextNode[] = graphResult.records.map(record => ({
            entityId: record.get('entityId'),
            name: record.get('name'),
            type: record.get('type'),
            summary: record.get('summary'),
            vectorScore: 0.95, // Normalized representation of vector match relevance
            graphNeighborhood: record.get('neighborhood')
        }));

        // Step 5: Construct a deterministic, strictly bound prompt for the LLM
        const contextPayload = JSON.stringify(assembledContext, null, 2);
        
        const systemPrompt = `
            You are a deterministic, zero-hallucination enterprise assistant. 
            Answer the user's query EXCLUSIVELY using the provided JSON context graph. 
            If the answer cannot be directly deduced from the nodes and relationships below, 
            state clearly: "Information not available in the verified knowledge graph."
            Do not extrapolate, assume, or inject external knowledge.
        `;

        const completion = await this.openai.chat.completions.create({
            model: 'gpt-4-turbo',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: `Context Graph:\n${contextPayload}\n\nQuery: ${naturalLanguageQuery}` }
            ],
            temperature: 0.0 // Zero temperature guarantees deterministic output generation
        });

        return completion.choices[0].message.content || "Failed to generate completion.";
    }

    /**
     * Gracefully closes the Neo4j database session connection.
     */
    public async close(): Promise<void> {
        await this.neo4jSession.close();
    }
}
