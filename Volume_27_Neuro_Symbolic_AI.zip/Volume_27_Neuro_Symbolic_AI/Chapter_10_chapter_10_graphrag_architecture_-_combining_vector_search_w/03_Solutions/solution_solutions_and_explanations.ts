/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface DocumentNode {
  id: string;
  content: string;
  metadata: Record<string, unknown>;
}

export interface GraphRelationship {
  sourceId: string;
  targetId: string;
  relationshipType: string;
  properties?: Record<string, unknown>;
}

export interface VectorPayload {
  id: string;
  vector: number[];
  metadata: Record<string, unknown>;
}

export interface SyncTransactionResult {
  transactionId: string;
  success: boolean;
  vectorId?: string;
  graphNodeId?: string;
  error?: string;
}

export interface IVectorStoreClient {
  upsert(payload: VectorPayload): Promise<void>;
  delete(id: string): Promise<void>;
}

export interface IGraphDatabaseClient {
  mergeNode(node: DocumentNode): Promise<void>;
  mergeRelationship(relationship: GraphRelationship): Promise<void>;
  deleteNode(id: string): Promise<void>;
}

export interface IEmbeddingGenerator {
  generateEmbedding(text: string): Promise<number[]>;
}

export class DualIndexSyncCoordinator {
  private vectorClient: IVectorStoreClient;
  private graphClient: IGraphDatabaseClient;
  private embeddingGenerator: IEmbeddingGenerator;
  private transactionHistory: Map<string, { nodeId: string; vectorWritten: boolean; graphWritten: boolean }> = new Map();

  constructor(
    vectorClient: IVectorStoreClient,
    graphClient: IGraphDatabaseClient,
    embeddingGenerator: IEmbeddingGenerator
  ) {
    this.vectorClient = vectorClient;
    this.graphClient = graphClient;
    this.embeddingGenerator = embeddingGenerator;
  }

  public async syncDocument(
    node: DocumentNode,
    edges: GraphRelationship[]
  ): Promise<SyncTransactionResult> {
    const transactionId = `tx_${Date.now()}_${Math.random().toString(36.substring(2, 9))}`;
    this.transactionHistory.set(transactionId, { nodeId: node.id, vectorWritten: false, graphWritten: false });

    try {
      // Step 1: Generate embedding via headless inference client (non-blocking async)
      const vector = await this.embeddingGenerator.generateEmbedding(node.content);

      // Step 2: Upsert into Vector Store
      await this.vectorClient.upsert({
        id: node.id,
        vector,
        metadata: node.metadata,
      });
      
      const txState = this.transactionHistory.get(transactionId);
      if (txState) txState.vectorWritten = true;

      // Step 3: Upsert Node and Relationships into Graph Database sequentially for structural integrity
      await this.graphClient.mergeNode(node);
      for (const edge of edges) {
        await this.graphClient.mergeRelationship(edge);
      }

      if (txState) txState.graphWritten = true;

      return {
        transactionId,
        success: true,
        vectorId: node.id,
        graphNodeId: node.id,
      };
    } catch (error: any) {
      // Trigger automated compensation / rollback
      await this.rollbackTransaction(transactionId);
      return {
        transactionId,
        success: false,
        error: error.message || "Unknown error during synchronization pipeline execution.",
      };
    }
  }

  public async rollbackTransaction(transactionId: string): Promise<void> {
    const state = this.transactionHistory.get(transactionId);
    if (!state) return;

    // Compensating action: If the vector was written but the graph write failed, purge the orphaned vector.
    if (state.vectorWritten && !state.graphWritten) {
      try {
        await this.vectorClient.delete(state.nodeId);
      } catch (rollbackError) {
        console.error(`Failed to purge orphaned vector for node ${state.nodeId}:`, rollbackError);
      }
    }

    // If graph node was partially written, attempt cleanup
    if (state.graphWritten) {
      try {
        await this.graphClient.deleteNode(state.nodeId);
      } catch (graphRollbackError) {
        console.error(`Failed to cleanup graph node ${state.nodeId} during rollback:`, graphRollbackError);
      }
    }

    this.transactionHistory.delete(transactionId);
  }
}
