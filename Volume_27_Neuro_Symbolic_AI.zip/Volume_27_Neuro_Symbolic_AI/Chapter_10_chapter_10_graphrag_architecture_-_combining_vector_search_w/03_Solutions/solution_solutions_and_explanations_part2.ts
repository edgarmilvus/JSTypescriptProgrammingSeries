/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface SearchQuery {
  rawText: string;
  embedding: number[];
  topKAnchors: number;
  maxTraversalDepth: number;
}

export interface AnchorNode {
  id: string;
  vectorScore: number;
  labels: string[];
  properties: Record<string, unknown>;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string;
  weight: number;
}

export interface SubgraphContext {
  anchorNodes: AnchorNode[];
  traversedNodes: Map<string, Record<string, unknown>>;
  edges: GraphEdge[];
  combinedScore: number;
}

export interface IVectorIndex {
  query(embedding: number[], topK: number): Promise<AnchorNode[]>;
}

export interface IGraphNavigator {
  traverseFromNodes(nodeIds: string[], depth: number): Promise<{ nodes: Map<string, Record<string, unknown>>; edges: GraphEdge[] }>;
}

export class GraphRAGSearchEngine {
  private vectorIndex: IVectorIndex;
  private graphNavigator: IGraphNavigator;
  private alpha: number;

  constructor(vectorIndex: IVectorIndex, graphNavigator: IGraphNavigator, alpha: number = 0.7) {
    this.vectorIndex = vectorIndex;
    this.graphNavigator = graphNavigator;
    this.alpha = alpha;
  }

  public async executeHybridSearch(query: SearchQuery): Promise<SubgraphContext> {
    // Step 1: Perform vector similarity search to locate anchor nodes
    const anchorNodes = await this.vectorIndex.query(query.embedding, query.topK);
    const anchorIds = anchorNodes.map((anchor) => anchor.id);

    // Step 2: Execute multi-hop graph traversal starting outward from anchor nodes
    const traversalResult = await this.graphNavigator.traverseFromNodes(anchorIds, query.maxTraversalDepth);

    // Step 3: Compute aggregated metrics for hybrid ranking
    const avgVectorScore = anchorNodes.reduce((acc, curr) => acc + curr.vectorScore, 0) / (anchorNodes.length || 1);
    
    // Calculate average edge weight as a proxy for graph topology centrality
    const avgGraphTopologyScore = traversalResult.edges.reduce((acc, curr) => acc + curr.weight, 0) / (traversalResult.edges.length || 1);

    const combinedScore = this.calculateHybridScore(avgVectorScore, isNaN(avgGraphTopologyScore) ? 0 : avgGraphTopologyScore);

    return {
      anchorNodes,
      traversedNodes: traversalResult.nodes,
      edges: traversalResult.edges,
      combinedScore,
    };
  }

  private calculateHybridScore(vectorScore: number, graphTopologyScore: number): number {
    return (this.alpha * vectorScore) + ((1 - this.alpha) * graphTopologyScore);
  }
}
