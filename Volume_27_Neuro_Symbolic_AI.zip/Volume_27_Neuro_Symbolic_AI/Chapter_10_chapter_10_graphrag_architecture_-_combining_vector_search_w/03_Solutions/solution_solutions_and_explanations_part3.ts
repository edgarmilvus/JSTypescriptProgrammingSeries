/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { SubgraphContext } from "./exercise-2";

export interface SynthesizedPrompt {
  systemPrompt: string;
  userPrompt: string;
  allowedCitations: string[];
}

export interface VerificationResult {
  isVerified: boolean;
  unsupportedClaims: string[];
  validCitationsCount: number;
  invalidCitations: string[];
}

export class DeterministicPromptSynthesizer {
  private baseSystemDirective: string;

  constructor() {
    this.baseSystemDirective = 
      "You are a deterministic knowledge-retrieval assistant. You must answer the user's question " +
      "using ONLY the provided Knowledge Graph context. Every factual claim must include a citation " +
      "referencing the exact Node ID or Edge ID in the format [ID]. If the answer cannot be derived " +
      "entirely from the context, you must state: 'I am unable to answer this question based on the verified knowledge graph.'";
  }

  public synthesize(query: string, context: SubgraphContext): SynthesizedPrompt {
    const allowedCitations: string[] = [];
    let contextMarkdown = "### Knowledge Graph Context Subgraph\n\n**Anchor Nodes:**\n";

    for (const anchor of context.anchorNodes) {
      allowedCitations.push(anchor.id);
      contextMarkdown += `- ID: [${anchor.id}] | Labels: ${anchor.labels.join(", ")} | VectorScore: ${anchor.vectorScore.toFixed(4)}\n`;
    }

    contextMarkdown += "\n**Traversed Context Nodes:**\n";
    for (const [nodeId, properties] of context.traversedNodes.entries()) {
      if (!allowedCitations.includes(nodeId)) {
        allowedCitations.push(nodeId);
      }
      contextMarkdown += `- ID: [${nodeId}] | Properties: ${JSON.stringify(properties)}\n`;
    }

    contextMarkdown += "\n**Ontological Relationships (Edges):**\n";
    for (const edge of context.edges) {
      const edgeId = `edge_${edge.source}_${edge.target}`;
      allowedCitations.push(edgeId);
      contextMarkdown += `- ID: [${edgeId}] | (${edge.source}) -[:${edge.type} (weight: ${edge.weight})]-> (${edge.target})\n`;
    }

    const userPrompt = `${contextMarkdown}\n\nUser Question: ${query}\n\nAnswer:`;

    return {
      systemPrompt: this.baseSystemDirective,
      userPrompt,
      allowedCitations,
    };
  }

  public verifyGrounding(llmOutput: string, context: SubgraphContext): VerificationResult {
    // Regex to match all bracketed citation identifiers (e.g., [node_123], [edge_a_b])
    const citationRegex = /\[([^\]]+)\]/g;
    const matches = [...llmOutput.matchAll(citationRegex)];
    
    // Build allowed whitelist set from context
    const allowedSet = new Set<string>();
    context.anchorNodes.forEach(a => allowedSet.add(a.id));
    context.traversedNodes.forEach((_, id) => allowedSet.add(id));
    context.edges.forEach(e => allowedSet.add(`edge_${e.source}_${e.target}`));

    const invalidCitations: string[] = [];
    const unsupportedClaims: string[] = [];
    let validCount = 0;

    for (const match of matches) {
      const citationId = match[1];
      if (allowedSet.has(citationId)) {
        validCount++;
      } else {
        invalidCitations.push(citationId);
        unsupportedClaims.push(`Reference to unverified identifier [${citationId}] detected in LLM output.`);
      }
    }

    return {
      isVerified: invalidCitations.length === 0,
      unsupportedClaims,
      validCitationsCount: validCount,
      invalidCitations: Array.from(new Set(invalidCitations)),
    };
  }
}
