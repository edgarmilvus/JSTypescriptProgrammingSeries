/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { SubgraphContext } from './exercise-2';
import { VerificationResult, SynthesizedPrompt } from './exercise-3';

export interface GraphRAGExecutionTrace {
  queryId: string;
  rawQuery: string;
  timestamp: number;
  subgraphContext: SubgraphContext;
  synthesizedPrompt: SynthesizedPrompt;
  llmOutput: string;
  verificationResult: VerificationResult;
}

export interface GraphRAGInspectorProps {
  executionTrace: GraphRAGExecutionTrace | null;
  isLoading: boolean;
  errorMessage?: string;
  onReRunQuery: (queryText: string) => void;
}

export const GraphRAGInspector: React.FC<GraphRAGInspectorProps> = ({
  executionTrace,
  isLoading,
  errorMessage,
  onReRunQuery
}) => {
  const [activeTab, setActiveTab] = useState<'anchors' | 'graph' | 'prompt' | 'audit'>('anchors');
  const [inputQuery, setInputQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputQuery.trim()) {
      onReRunQuery(inputQuery);
    }
  };

  return (
    <div className="graph-rag-inspector-container" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>GraphRAG Pipeline Inspector</h2>
      
      <form onSubmit={handleSearchSubmit} style={{ marginBottom: '20px' }}>
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          placeholder="Enter natural language query..."
          style={{ padding: '8px', width: '300px', marginRight: '10px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '8px 16px' }}>
          {isLoading ? 'Executing...' : 'Run Query'}
        </button>
      </form>

      {errorMessage && <div style={{ color: 'red', marginBottom: '15px' }}>Error: {errorMessage}</div>}

      {executionTrace && (
        <div>
          <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid #ccc', paddingBottom: '10px' }}>
            <button onClick={() => setActiveTab('anchors')} style={{ fontWeight: activeTab === 'anchors' ? 'bold' : 'normal' }}>Vector Anchors</button>
            <button onClick={() => setActiveTab('graph')} style={{ fontWeight: activeTab === 'graph' ? 'bold' : 'normal' }}>Graph Topology</button>
            <button onClick={() => setActiveTab('prompt')} style={{ fontWeight: activeTab === 'prompt' ? 'bold' : 'normal' }}>Prompt & Output</button>
            <button onClick={() => setActiveTab('audit')} style={{ fontWeight: activeTab === 'audit' ? 'bold' : 'normal' }}>Grounding Audit</button>
          </div>

          <div className="tab-content">
            {activeTab === 'anchors' && (
              <div>
                <h3>Vector Similarity Anchors</h3>
                <ul>
                  {executionTrace.subgraphContext.anchorNodes.map((anchor) => (
                    <li key={anchor.id}>
                      <strong>ID:</strong> {anchor.id} | <strong>Score:</strong> {anchor.vectorScore.toFixed(4)} | <strong>Labels:</strong> {anchor.labels.join(', ')}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === 'graph' && (
              <div>
                <h3>Knowledge Graph Subgraph</h3>
                <h4>Nodes ({executionTrace.subgraphContext.traversedNodes.size})</h4>
                <ul>
                  {Array.from(executionTrace.subgraphContext.traversedNodes.entries()).map(([id, props]) => (
                    <li key={id}><strong>{id}</strong>: {JSON.stringify(props)}</li>
                  ))}
                </ul>
                <h4>Edges ({executionTrace.subgraphContext.edges.length})</h4>
                <ul>
                  {executionTrace.subgraphContext.edges.map((edge, idx) => (
                    <li key={idx}>({edge.source}) -[{edge.type}]-> ({edge.target}) [weight: {edge.weight}]</li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === 'prompt' && (
              <div>
                <h3>Synthesized Prompt & LLM Output</h3>
                <h4>System Directive:</h4>
                <pre style={{ background: '#f4f4f4', padding: '10px' }}>{executionTrace.synthesizedPrompt.systemPrompt}</pre>
                <h4>User Prompt Payload:</h4>
                <pre style={{ background: '#f4f4f4', padding: '10px' }}>{executionTrace.synthesizedPrompt.userPrompt}</pre>
                <h4>Generated LLM Response:</h4>
                <div style={{ background: '#eef', padding: '10px', borderLeft: '4px solid #00f' }}>{executionTrace.llmOutput}</div>
              </div>
            )}

            {activeTab === 'audit' && (
              <div>
                <h3>Grounding Verification Audit</h3>
                <p><strong>Verified Status:</strong> {executionTrace.verificationResult.isVerified ? '✅ PASSED' : '❌ FAILED'}</p>
                <p><strong>Valid Citations Count:</strong> {executionTrace.verificationResult.validCitationsCount}</p>
                <h4>Invalid / Unsupported Citations:</h4>
                <ul>
                  {executionTrace.verificationResult.invalidCitations.map((inv, idx) => (
                    <li key={idx} style={{ color: 'red' }}>[{inv}]</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
