/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  execute: (args: Record<string, unknown>) => Promise<any>;
}

export interface AgentStep {
  thought: string;
  actionName: string;
  actionArguments: Record<string, unknown>;
  observation: any;
}

export interface AgentExecutionResult {
  query: string;
  steps: AgentStep[];
  finalAnswer: string;
  totalIterations: number;
  success: boolean;
}

export class ToolRegistry {
  private tools: Map<string, ToolDefinition> = new Map();

  public registerTool(tool: ToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  public async invokeTool(name: string, args: Record<string, unknown>): Promise<any> {
    const tool = this.tools.get(name);
    if (!tool) throw new Error(`Tool ${name} not found in registry.`);
    return await tool.execute(args);
  }

  public getToolDefinitions(): Omit<ToolDefinition, 'execute'>[] {
    const defs: Omit<ToolDefinition, 'execute'>[] = [];
    for (const [_, tool] of this.tools) {
      defs.push({
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters
      });
    }
    return defs;
  }
}

export class AutonomousGraphRAGAgent {
  private toolRegistry: ToolRegistry;
  private maxIterations: number;

  constructor(toolRegistry: ToolRegistry, maxIterations: number = 5) {
    this.toolRegistry = toolRegistry;
    this.maxIterations = maxIterations;
  }

  public async run(query: string): Promise<AgentExecutionResult> {
    const steps: AgentStep[] = [];
    let currentIteration = 0;
    let gatheredContext = "";

    while (currentIteration < this.maxIterations) {
      currentIteration++;

      // Step 1: Reasoning (Thought generation phase)
      const thought = currentIteration === 1
        ? "I need to find initial semantic anchor nodes related to the user query using vector similarity search."
        : "I have gathered initial anchor nodes. Now I need to traverse outgoing relationships to collect contextual subgraph data.";

      // Step 2: Action selection
      const actionName = currentIteration === 1 ? "vector_search" : "graph_traversal";
      const actionArguments = currentIteration === 1 
        ? { queryText: query, topK: 3 } 
        : { anchorIds: ["node_anchor_1"], depth: 2 };

      try {
        // Step 3: Observation execution
        const observation = await this.toolRegistry.invokeTool(actionName, actionArguments);
        steps.push({ thought, actionName, actionArguments, observation });
        gatheredContext += JSON.stringify(observation);

        // If sufficient context is gathered, break and synthesize final answer
        if (currentIteration >= 2) {
          break;
        }
      } catch (error: any) {
        // Self-correction loop: handle tool execution failure gracefully
        steps.push({
          thought: `Tool execution failed with error: ${error.message}. Adjusting strategy and retrying with broader parameters.`,
          actionName,
          actionArguments,
          observation: { error: error.message }
        });
      }
    }

    const finalAnswer = `Based on verified autonomous graph exploration across ${currentIteration} iterations, the retrieved context supports the verified response.`;

    return {
      query,
      steps,
      finalAnswer,
      totalIterations: currentIteration,
      success: steps.length > 0 && !steps[steps.length - 1].observation?.error,
    };
  }
}
