/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Exercise 1 Starter Code: Dual-Index Synchronization Pipeline

export interface DocumentNode {
  id: string;
  content: string;
  metadata: Record<string, unknown>;
}

export interface GraphRelationship {
  sourceId: string;
  targetId: string;
  relationshipType: string;
  properties?: Record<string, unknown>;
}

export interface VectorPayload {
  id: string;
  vector: number[];
  metadata: Record<string, unknown>;
}

export interface SyncTransactionResult {
  transactionId: string;
  success: boolean;
  vectorId?: string;
  graphNodeId?: string;
  error?: string;
}

export interface IVectorStoreClient {
  upsert(payload: VectorPayload): Promise<void>;
  delete(id: string): Promise<void>;
}

export interface IGraphDatabaseClient {
  mergeNode(node: DocumentNode): Promise<void>;
  mergeRelationship(relationship: GraphRelationship): Promise<void>;
  deleteNode(id: string): Promise<void>;
}

export interface IEmbeddingGenerator {
  generateEmbedding(text: string): Promise<number[]>;
}

export class DualIndexSyncCoordinator {
  private vectorClient: IVectorStoreClient;
  private graphClient: IGraphDatabaseClient;
  private embeddingGenerator: IEmbeddingGenerator;

  constructor(
    vectorClient: IVectorStoreClient,
    graphClient: IGraphDatabaseClient,
    embeddingGenerator: IEmbeddingGenerator
  ) {
    this.vectorClient = vectorClient;
    this.graphClient = graphClient;
    this.embeddingGenerator = embeddingGenerator;
  }

  public async syncDocument(
    node: DocumentNode,
    edges: GraphRelationship[]
  ): Promise<SyncTransactionResult> {
    // TODO: Implement atomic dual-index synchronization logic
    throw new Error("Method not implemented.");
  }

  public async rollbackTransaction(transactionId: string): Promise<void> {
    // TODO: Implement compensation and rollback logic
    throw new Error("Method not implemented.");
  }
}
