/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Exercise 3 Starter Code: Deterministic Zero-Hallucination Prompt Synthesizer

import { SubgraphContext } from "./exercise-2";

export interface SynthesizedPrompt {
  systemPrompt: string;
  userPrompt: string;
  allowedCitations: string[];
}

export interface VerificationResult {
  isVerified: boolean;
  unsupportedClaims: string[];
  validCitationsCount: number;
  invalidCitations: string[];
}

export class DeterministicPromptSynthesizer {
  private baseSystemDirective: string;

  constructor() {
    this.baseSystemDirective = 
      "You are a deterministic knowledge-retrieval assistant. You must answer the user's question " +
      "using ONLY the provided Knowledge Graph context. Every factual claim must include a citation " +
      "referencing the exact Node ID or Edge ID in the format [ID]. If the answer cannot be derived " +
      "entirely from the context, you must state: 'I am unable to answer this question based on the verified knowledge graph.'";
  }

  public synthesize(query: string, context: SubgraphContext): SynthesizedPrompt {
    // TODO: Convert SubgraphContext into structured prompt text and extract allowed citation IDs
    throw new Error("Method not implemented.");
  }

  public verifyGrounding(llmOutput: string, context: SubgraphContext): VerificationResult {
    // TODO: Implement post-processing verification of citations against graph IDs
    throw new Error("Method not implemented.");
  }
}
