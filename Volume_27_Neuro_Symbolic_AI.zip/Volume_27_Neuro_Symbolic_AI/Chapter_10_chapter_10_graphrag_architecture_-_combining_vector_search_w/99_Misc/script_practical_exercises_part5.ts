/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// Exercise 5 Starter Code: Autonomous ReAct Agent with Knowledge Graph Tools

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  execute: (args: Record<string, unknown>) => Promise<any>;
}

export interface AgentStep {
  thought: string;
  actionName: string;
  actionArguments: Record<string, unknown>;
  observation: any;
}

export interface AgentExecutionResult {
  query: string;
  steps: AgentStep[];
  finalAnswer: string;
  totalIterations: number;
  success: boolean;
}

export class ToolRegistry {
  private tools: Map<string, ToolDefinition> = new Map();

  public registerTool(tool: ToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  public async invokeTool(name: string, args: Record<string, unknown>): Promise<any> {
    const tool = this.tools.get(name);
    if (!tool) throw new Error(`Tool ${name} not found in registry.`);
    return await tool.execute(args);
  }

  public getToolDefinitions(): Omit<ToolDefinition, 'execute'>[] {
    const defs: Omit<ToolDefinition, 'execute'>[] = [];
    for (const [_, tool] of this.tools) {
      defs.push({
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters
      });
    }
    return defs;
  }
}

export class AutonomousGraphRAGAgent {
  private toolRegistry: ToolRegistry;
  private maxIterations: number;

  constructor(toolRegistry: ToolRegistry, maxIterations: number = 5) {
    this.toolRegistry = toolRegistry;
    this.maxIterations = maxIterations;
  }

  public async run(query: string): Promise<AgentExecutionResult> {
    // TODO: Implement the Thought-Action-Observation ReAct loop
    throw new Error("Method not implemented.");
  }
}
