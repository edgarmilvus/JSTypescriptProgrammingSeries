/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file policy-engine.ts
 * @description Production-grade TypeScript module executing the Z3 SMT solver via WebAssembly 
 *              to verify the logical consistency of SaaS multi-tenant security policies.
 */

import { init } from 'z3-solver';
import type { Z3HighLevel } from 'z3-solver';

export interface PolicyRule {
  id: string;
  role: string;
  resource: string;
  action: 'READ' | 'WRITE' | 'DELETE';
  allowed: boolean;
}

export interface VerificationResult {
  isConsistent: boolean;
  counterexample?: Record<string, string | boolean>;
  error?: string;
}

export class PolicyVerificationEngine {
  private z3Instance: Z3HighLevel | null = null;

  /**
   * Initializes the Z3 WebAssembly module. Must be called prior to validation.
   */
  public async initialize(): Promise<void> {
    if (this.z3Instance) return;
    try {
      // Initialize the official z3-solver Wasm package
      const { Context } = await init();
      this.z3Instance = Context('main');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      throw new Error(`Failed to load Z3 Wasm module: ${message}`);
    }
  }

  /**
   * Evaluates a set of user-defined access policies for logical contradictions 
   * (e.g., a role being both allowed and denied the exact same action on a resource).
   */
  public async verifyPolicyConsistency(rules: PolicyRule[]): Promise<VerificationResult> {
    if (!this.z3Instance) {
      await this.initialize();
    }
    
    const { Solver, Bool } = this.z3Instance!;
    const solver = new Solver();

    // Map to keep track of logical assertions created for rules
    const ruleAssertions: Map<string, ReturnType<typeof Bool.const>> = new Map();

    try {
      // 1. Declare symbolic variables and constraints for each policy rule
      for (const rule of rules) {
        const varName = `rule_${rule.id}_${rule.role}_${rule.resource}_${rule.action}`;
        const constraint = Bool.const(varName);
        ruleAssertions.set(rule.id, constraint);

        // If rule mandates allowed=true, it asserts the positive condition; else negated
        if (rule.allowed) {
          solver.add(constraint);
        } else {
          solver.add(constraint.not());
        }
      }

      // 2. Add domain-specific business logic axioms (e.g., Mutual Exclusion)
      // Example Axiom: A user cannot simultaneously have READ allowed and denied for the same resource
      for (let i = 0; i < rules.length; i++) {
        for (let j = i + 1; j < rules.length; j++) {
          const r1 = rules[i];
          const r2 = rules[j];
          
          if (r1.role === r2.role && r1.resource === r2.resource && r1.action === r2.action) {
            if (r1.allowed !== r2.allowed) {
              // Direct contradiction detected in static definitions
              const c1 = ruleAssertions.get(r1.id)!;
              const c2 = ruleAssertions.get(r2.id)!;
              solver.add(c1.eq(c2.not())); // Forces a logical clash
            }
          }
        }
      }

      // 3. Execute the SMT solver check
      const checkResult = await solver.check();

      if (checkResult === 'sat') {
        // Satisfiable means no logical contradictions were found in the constraints
        return { isConsistent: true };
      } else if (checkResult === 'unsat') {
        // Unsatisfiable means a logical contradiction exists (Zero-Hallucination proof of failure)
        const model = solver.model();
        const counterexample: Record<string, string | boolean> = {};
        
        ruleAssertions.forEach((constExpr, id) => {
          const evalResult = model.eval(constExpr);
          counterexample[id] = evalResult.toString() === 'true';
        });

        return {
          isConsistent: false,
          counterexample,
          error: 'Logical contradiction detected among security policies.',
        };
      } else {
        return { isConsistent: false, error: 'Z3 solver returned unknown status.' };
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      return { isConsistent: false, error: `Execution error in Z3 solver: ${message}` };
    }
  }
}
