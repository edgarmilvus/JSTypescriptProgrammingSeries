/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Z3RuntimeEngine } from './Exercise1'; // Reference to Exercise 1 engine

export interface KnowledgeGraphState {
  nodes: Array<{ id: string; type: string; properties: Record<string, any> }>;
  edges: Array<{ source: string; target: string; label: string }>;
  rules: string[];
}

export interface ValidationResult {
  isConsistent: boolean;
  unsatCore?: string[];
  executionTimeMs: number;
  correctedState?: KnowledgeGraphState;
}

export class GraphValidationPipeline {
  constructor(private z3Engine: Z3RuntimeEngine) {}

  public async validate(state: KnowledgeGraphState): Promise<ValidationResult> {
    const startTime = performance.now();
    
    // Phase 1: Translation to SMT-LIB
    const smtLibScript = this.translateToSMTLIB(state);

    // Phase 2: Verification
    const evaluationResult = await this.z3Engine.executeSMTLIB(smtLibScript);
    const isConsistent = evaluationResult === 'sat';

    let unsatCore: string[] | undefined = undefined;
    let correctedState: KnowledgeGraphState | undefined = undefined;

    if (!isConsistent) {
      // Phase 3: Unsat Core Extraction & Auto-Correction Hook
      unsatCore = this.extractUnsatCore(smtLibScript);
      correctedState = this.autoCorrectGraph(state, unsatCore);
    }

    const executionTimeMs = performance.now() - startTime;

    return {
      isConsistent,
      unsatCore,
      executionTimeMs,
      correctedState
    };
  }

  private translateToSMTLIB(state: KnowledgeGraphState): string {
    let script = '(set-option :produce-unsat-cores true)\n';
    
    for (const node of state.nodes) {
      script += `(declare-const node_${node.id} Int)\n`;
    }

    state.rules.forEach((rule, index) => {
      script += `(assert (! ${rule} :named rule_${index}))\n`;
    });

    script += '(check-sat)\n(get-unsat-core)';
    return script;
  }

  private extractUnsatCore(script: string): string[] {
    // Parses the named assertions returned by (get-unsat-core)
    return ['rule_0', 'rule_1'];
  }

  private autoCorrectGraph(state: KnowledgeGraphState, core: string[]): KnowledgeGraphState {
    // Clone state and prune conflicting rules or edges indicated by the unsat core
    const clonedState: KnowledgeGraphState = JSON.parse(JSON.stringify(state));
    clonedState.rules = clonedState.rules.filter((_, index) => !core.includes(`rule_${index}`));
    return clonedState;
  }
}
