/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { Z3RuntimeEngine } from './Exercise1';

interface SchemaVerifierDashboardProps {
  engine: Z3RuntimeEngine;
  initialScript?: string;
}

export const SchemaVerifierDashboard: React.FC<SchemaVerifierDashboardProps> = ({
  engine,
  initialScript = '(assert true)\n(check-sat)'
}) => {
  const [script, setScript] = useState<string>(initialScript);
  const [status, setStatus] = useState<'IDLE' | 'RUNNING' | 'SAT' | 'UNSAT' | 'ERROR'>('IDLE');
  const [output, setOutput] = useState<string>('');
  const [isReady, setIsReady] = useState<boolean>(false);
  const [duration, setDuration] = useState<number>(0);

  useEffect(() => {
    let isMounted = true;
    engine.initialize().then(() => {
      if (isMounted) setIsReady(true);
    }).catch(err => {
      if (isMounted) {
        setStatus('ERROR');
        setOutput(err.message);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [engine]);

  // Live-typing debounce mechanism (300ms delay)
  useEffect(() => {
    if (!isReady) return;
    
    const handler = setTimeout(async () => {
      if (!script.trim()) return;
      setStatus('RUNNING');
      const start = performance.now();
      try {
        const result = await engine.executeSMTLIB(script);
        setDuration(Math.round(performance.now() - start));
        if (result === 'sat') {
          setStatus('SAT');
          setOutput('Schema is consistent (SAT).');
        } else {
          setStatus('UNSAT');
          setOutput('Schema contains logical contradictions (UNSAT).');
        }
      } catch (err: any) {
        setStatus('ERROR');
        setOutput(err.message);
      }
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [script, isReady, engine]);

  const handleVerifyManually = async () => {
    if (!isReady) return;
    setStatus('RUNNING');
    const start = performance.now();
    try {
      const result = await engine.executeSMTLIB(script);
      setDuration(Math.round(performance.now() - start));
      setStatus(result === 'sat' ? 'SAT' : 'UNSAT');
      setOutput(`Result: ${result}`);
    } catch (err: any) {
      setStatus('ERROR');
      setOutput(err.message);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl font-sans">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">WebAssembly Z3 Schema Verifier</h2>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          !isReady ? 'bg-yellow-600 text-yellow-100' : 'bg-green-600 text-green-100'
        }`}>
          {!isReady ? 'Loading Wasm...' : 'Engine Ready'}
        </span>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-400 mb-2">SMT-LIB / Schema Editor</label>
        <textarea
          value={script}
          onChange={(e) => setScript(e.target.value)}
          rows={8}
          className="w-full p-3 bg-slate-950 font-mono text-sm text-slate-200 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500"
          placeholder="Enter SMT-LIB code here..."
        />
      </div>

      <div className="flex justify-between items-center mb-6">
        <button
          onClick={handleVerifyManually}
          disabled={!isReady || status === 'RUNNING'}
          className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white font-medium rounded-lg transition-colors shadow-md"
        >
          {status === 'RUNNING' ? 'Verifying...' : 'Verify Consistency'}
        </button>
        {duration > 0 && <span className="text-xs text-slate-400">Execution time: {duration}ms</span>}
      </div>

      <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
        <div className="flex items-center space-x-3 mb-2">
          <span className="text-sm font-semibold text-slate-400">Status:</span>
          <span className={`px-2.5 py-0.5 rounded text-xs font-bold ${
            status === 'SAT' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
            status === 'UNSAT' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
            status === 'ERROR' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
            'bg-slate-800 text-slate-400'
          }`}>
            {status}
          </span>
        </div>
        <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap">{output}</pre>
      </div>
    </div>
  );
};
