/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Engine, TopLevelCondition } from 'json-rules-engine';
import { Store, Parser, Writer, DataFactory } from 'n3';
import { z } from 'zod';

// Extract required factories for RDF manipulation
const { namedNode, literal, quad } = DataFactory;

/**
 * ============================================================================
 * 1. RUNTIME VALIDATION SCHEMAS (Zod)
 * ============================================================================
 * Runtime validation ensures that data entering the inference boundary 
 * strictly conforms to expected business shapes. This mitigates injection 
 * attacks and malformed states before evaluation.
 */
const TenantContextSchema = z.object({
  tenantId: z.string().uuid(),
  tier: z.enum(['FREE', 'PRO', 'ENTERPRISE']),
  monthlyActiveUsers: z.number().int().nonnegative(),
  apiCallsMade: z.number().int().nonnegative(),
  featureFlags: z.array(z.string()),
  securityComplianceAttested: z.boolean(),
});

type TenantContext = z.infer<typeof TenantContextSchema>;

/**
 * ============================================================================
 * 2. DETERMINISTIC ENGINE SETUP (json-rules-engine)
 * ============================================================================
 * We construct a procedural rule engine instance. Rules are declared as plain JSON 
 * objects, making them serializable, database-storable, and immune to ambiguity.
 */
const proceduralEngine = new Engine();

// Define a rule: Enterprise tenants exceeding baseline API calls require an audit log flag
proceduralEngine.addRule({
  name: 'enterprise-audit-requirement',
  conditions: {
    all: [
      {
        fact: 'tier',
        operator: 'equal',
        value: 'ENTERPRISE',
      },
      {
        fact: 'apiCallsMade',
        operator: 'greaterThan',
        value: 100000,
      },
    ],
  },
  event: {
    type: 'trigger-security-audit',
    params: {
      severity: 'HIGH',
      message: 'Enterprise usage threshold exceeded; mandatory compliance audit triggered.',
    },
  },
});

// Define a rule: Non-enterprise accounts exceeding MAU limits must be rate-limited
proceduralEngine.addRule({
  name: 'enforce-mau-rate-limit',
  conditions: {
    all: [
      {
        fact: 'tier',
        operator: 'notEqual',
        value: 'ENTERPRISE',
      },
      {
        fact: 'monthlyActiveUsers',
        operator: 'greaterThan',
        value: 5000,
      },
    ],
  },
  event: {
    type: 'apply-rate-limiting',
    params: {
      action: 'THROTTLE',
      retryAfterSeconds: 3600,
    },
  },
});

/**
 * ============================================================================
 * 3. SEMANTIC RDF REASONER SETUP (N3.js)
 * ============================================================================
 * We instantiate an N3 quad store to process deterministic semantic triples. 
 * This allows us to infer hierarchical relationships (e.g., Enterprise inherits 
 * HIPAA compliance rights) using logical implication rules.
 */
const n3Store = new Store();

// Define namespace URIs for our SaaS Ontology
const saasNS = 'http://api.saas-platform.io/ontology#';
const tenantNS = 'http://api.saas-platform.io/tenant/';

/**
 * Populates the semantic store with ontological axioms and assertions.
 */
function initializeOntology(tenantId: string, tier: string, securityAttested: boolean) {
  // Axiom: An ENTERPRISE tier implies a regulated industry status
  n3Store.addQuad(
    namedNode(`${saasNS}EnterpriseTier`),
    namedNode(`${saasNS}impliesRegulation`),
    namedNode(`${saasNS}HIPAACompliant`)
  );

  // Assertion: The specific tenant is an instance of their respective tier
  n3Store.addQuad(
    namedNode(`${tenantNS}${tenantId}`),
    namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type'),
    namedNode(`${saasNS}${tier}Tier`)
  );

  // Assertion: Tenant security compliance attribute
  n3Store.addQuad(
    namedNode(`${tenantNS}${tenantId}`),
    namedNode(`${saasNS}securityAttested`),
    literal(securityAttested.toString(), namedNode('http://www.w3.org/2001/XMLSchema#boolean'))
  );
}

/**
 * Executes a custom semantic forward-chaining rule over the RDF store.
 * If a tenant is of type EnterpriseTier, we infer and insert an explicit 
 * entitlement triple.
 */
function executeSemanticInference(tenantId: string) {
  const tenantNode = namedNode(`${tenantNS}${tenantId}`);
  const enterpriseTypeNode = namedNode(`${saasNS}ENTERPRISETier`);
  const typeProperty = namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type');
  
  const hasEnterpriseType = n3Store.getQuads(tenantNode, typeProperty, enterpriseTypeNode, null).length > 0;

  if (hasEnterpriseType) {
    // Forward-chaining inference step: Grant dynamic master key access
    n3Store.addQuad(
      tenantNode,
      namedNode(`${saasNS}grantsEntitlement`),
      namedNode(`${saasNS}MasterEncryptionKeyAccess`)
    );
  }
}

/**
 * ============================================================================
 * 4. UNIFIED NEURO-SYMBOLIC PIPELINE EXECUTION
 * ============================================================================
 */
async function evaluateTenantPolicies(rawInput: unknown): Promise<{
  proceduralEvents: Array<{ type: string; params: Record<string, any> }>;
  semanticTriples: string[];
}> {
  // Step 1: Runtime validation using Zod to enforce system boundary integrity
  const validationResult = TenantContextSchema.safeParse(rawInput);
  
  if (!validationResult.success) {
    throw new Error(`Tenant context validation failed: ${JSON.stringify(validationResult.error.format())}`);
  }

  const tenant = validationResult.data;

  // Step 2: Run procedural rules via json-rules-engine
  // We map the validated object properties into fact keys expected by the engine
  const facts = {
    tier: tenant.tier,
    monthlyActiveUsers: tenant.monthlyActiveUsers,
    apiCallsMade: tenant.apiCallsMade,
  };

  const proceduralResults = await proceduralEngine.run(facts);
  const triggeredEvents = proceduralResults.events.map(event => ({
    type: event.type,
    params: event.params || {},
  }));

  // Step 3: Run semantic reasoning via N3
  initializeOntology(tenant.tenantId, tenant.tier, tenant.securityComplianceAttested);
  executeSemanticInference(tenant.tenantId);

  // Extract all serialized quads from the N3 store for auditing
  const quads = n3Store.getQuads(null, null, null, null);
  const writer = new Writer();
  const serializedTriples: string[] = [];

  // Convert quads into N-Triples string representations for zero-hallucination logging
  writer.addQuads(quads);
  writer.end((error, result) => {
    if (!error && result) {
      serializedTriples.push(...result.trim().split('\n'));
    }
  });

  return {
    proceduralEvents: triggeredEvents,
    semanticTriples: serializedTriples,
  };
}

// ============================================================================
// 5. EXAMPLE USAGE / INVOCATION
// ============================================================================
async function runDemo() {
  const samplePayload = {
    tenantId: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    tier: 'ENTERPRISE',
    monthlyActiveUsers: 12500,
    apiCallsMade: 150000,
    featureFlags: ['beta-ai-agents', 'custom-domains'],
    securityComplianceAttested: true,
  };

  try {
    console.log('Evaluating Zero-Hallucination Pipeline...');
    const result = await evaluateTenantPolicies(samplePayload);
    
    console.log('\n--- Procedural Rule Engine Events ---');
    console.dir(result.proceduralEvents, { depth: null });

    console.log('\n--- Semantic RDF Reasoner Triples (Inferred World State) ---');
    result.semanticTriples.forEach(triple => console.log(triple));

  } catch (error) {
    console.error('Pipeline Evaluation Error:', error);
  }
}

runDemo();
