/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file compliance-engine.ts
 * @description Advanced Neuro-Symbolic Inference Engine for SaaS Financial Compliance.
 * Integrates json-rules-engine, N3 Semantic Reasoning, and Strict TypeScript Type Narrowing.
 */

import { Engine, TopLevelCondition } from 'json-rules-engine';
import { Store, Parser, Writer, DataFactory } from 'n3';
import { Reasoner } from 'n3-reasoner';

const { namedNode, literal, quad } = DataFactory;

// ============================================================================
// 1. TYPE DEFINITIONS & TYPE NARROWING GUARDS
// ============================================================================

export type RiskTier = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface TransactionPayload {
  transactionId: string;
  userId: string;
  amountUSD: number;
  destinationCountry: string;
  isSanctionedCountry: boolean;
  userAccountAgeDays: number;
  kycVerified: boolean;
}

export interface InferenceResult {
  isCompliant: boolean;
  riskTier: RiskTier;
  triggeredRules: string[];
  semanticViolations: string[];
  auditTrail: string;
}

/**
 * Type Guard to ensure runtime safety on unknown input payloads before processing.
 * Demonstrates strict TypeScript Type Narrowing for zero-hallucination boundary checks.
 */
export function isTransactionPayload(input: unknown): input is TransactionPayload {
  if (typeof input !== 'object' || input === null) return false;
  const candidate = input as Record<string, unknown>;
  
  return (
    typeof candidate.transactionId === 'string' &&
    typeof candidate.userId === 'string' &&
    typeof candidate.amountUSD === 'number' &&
    typeof candidate.destinationCountry === 'string' &&
    typeof candidate.isSanctionedCountry === 'boolean' &&
    typeof candidate.userAccountAgeDays === 'number' &&
    typeof candidate.kycVerified === 'boolean'
  );
}

// ============================================================================
// 2. N3 SEMANTIC REASONER CONFIGURATION & ONTOLOGY SETUP
// ============================================================================

const COMPLIANCE_ONTOLOGY = `
  @prefix ex: <http://example.org/compliance#> .
  @prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
  @prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

  # Rules expressed in Semantic Web N3 notation for automated deductive closure
  {
    ?tx ex:amountUSD ?amt .
    ?amt math:greaterThan 10000 .
    ?tx ex:kycVerified false .
  } => {
    ?tx ex violatesRegulation "AML-Threshold-Unverified" .
  } .

  {
    ?tx ex:isSanctionedCountry true .
  } => {
    ?tx ex violatesRegulation "OFAC-Sanctions-Breach" .
  } .
`;

/**
 * Executes N3 Semantic Reasoner over RDF triples derived from the transaction payload.
 */
async function executeSemanticReasoning(payload: TransactionPayload): Promise<string[]> {
  const store = new Store();
  const parser = new Parser();

  // Parse static ontology rules into the N3 store
  parser.parse(COMPLIANCE_ONTOLOGY, (error, quadObj) => {
    if (quadObj) store.addQuad(quadObj);
  });

  // Dynamically instantiate runtime facts as RDF Triples
  const txNode = namedNode(`http://example.org/compliance#tx_${payload.transactionId}`);
  store.addQuad(quad(txNode, namedNode('http://example.org/compliance#amountUSD'), literal(payload.amountUSD)));
  store.addQuad(quad(txNode, namedNode('http://example.org/compliance#kycVerified'), literal(payload.kycVerified)));
  store.addQuad(quad(txNode, namedNode('http://example.org/compliance#isSanctionedCountry'), literal(payload.isSanctionedCountry)));

  // Execute reasoning engine to extract implied semantic violations
  // Note: n3-reasoner evaluates implications based on loaded rules and data stores
  const violations: string[] = [];
  const queryParser = new Parser();
  
  queryParser.parse(`
    @prefix ex: <http://example.org/compliance#> .
    { ?tx ex:violatesRegulation ?violation . }
  `, (_, q) => {
    if (q) {
      const results = store.getQuads(null, namedNode('http://example.org/compliance#violatesRegulation'), null, null);
      results.forEach(res => {
        violations.push(res.object.value);
      });
    }
  });

  // Deduplicate violations
  return Array.from(new Set(violations));
}

// ============================================================================
// 3. PROCEDURAL json-rules-engine PIPELINE
// ============================================================================

/**
 * Configures and executes procedural rules using json-rules-engine.
 */
async function executeProceduralRules(payload: TransactionPayload): Promise<{ triggered: string[]; risk: RiskTier }> {
  const engine = new Engine();

  // Rule 1: Critical Sanctions Check
  engine.addRule({
    name: 'Sanctioned Country Block',
    conditions: {
      all: [{
        fact: 'isSanctionedCountry',
        operator: 'equal',
        value: true
      }]
    },
    event: {
      type: 'CRITICAL_SANCTION_VIOLATION',
      params: { riskTier: 'CRITICAL' }
    }
  });

  // Rule 2: High Value Unverified AML Check
  engine.addRule({
    name: 'High Value Unverified AML Flag',
    conditions: {
      all: [
        { fact: 'amountUSD', operator: 'greaterThanInclusive', value: 10000 },
        { fact: 'kycVerified', operator: 'equal', value: false }
      ]
    },
    event: {
      type: 'HIGH_VALUE_AML_RISK',
      params: { riskTier: 'HIGH' }
    }
  });

  // Rule 3: Suspicious New Account Velocity Check
  engine.addRule({
    name: 'New Account High Velocity Check',
    conditions: {
      all: [
        { fact: 'userAccountAgeDays', operator: 'lessThan', value: 7 },
        { fact: 'amountUSD', operator: 'greaterThan', value: 5000 }
      ]
    },
    event: {
      type: 'NEW_ACCOUNT_VELOCITY',
      params: { riskTier: 'MEDIUM' }
    }
  });

  const { events } = await engine.run(payload);
  
  const triggeredRules = events.map(e => e.type);
  let highestRisk: RiskTier = 'LOW';

  if (events.some(e => e.params?.riskTier === 'CRITICAL')) {
    highestRisk = 'CRITICAL';
  } else if (events.some(e => e.params?.riskTier === 'HIGH')) {
    highestRisk = 'HIGH';
  } else if (events.some(e => e.params?.riskTier === 'MEDIUM')) {
    highestRisk = 'MEDIUM';
  }

  return { triggered: triggeredRules, risk: highestRisk };
}

// ============================================================================
// 4. NEURO-SYMBOLIC ORCHESTRATION LAYER (ZERO-HALLUCINATION PIPELINE)
// ============================================================================

/**
 * Main orchestration entrypoint for Next.js API Routes or Server Actions.
 * Guarantees deterministic evaluation prior to any generative AI model ingestion.
 */
export async function processTransactionCompliance(rawInput: unknown): Promise<InferenceResult> {
  // Step 1: Enforce Strict Type Narrowing
  if (!isTransactionPayload(rawInput)) {
    throw new Error('Invalid Transaction Payload structure. Failed Type Narrowing guard.');
  }

  const payload: TransactionPayload = rawInput;

  // Step 2: Run Procedural Rules Engine (json-rules-engine)
  const proceduralResult = await executeProceduralRules(payload);

  // Step 3: Run Semantic Web Reasoner (N3 Triples & Ontologies)
  const semanticViolations = await executeSemanticReasoning(payload);

  // Step 4: Synthesize Neuro-Symbolic Deterministic Decision Matrix
  const isCompliant = proceduralResult.triggered.length === 0 && semanticViolations.length === 0;
  
  let finalRiskTier = proceduralResult.risk;
  if (semanticViolations.length > 0 && finalRiskTier !== 'CRITICAL') {
    finalRiskTier = 'HIGH';
  }

  const auditTrail = `Evaluated TX ${payload.transactionId}: Compliant=${isCompliant}, Risk=${finalRiskTier}, ProceduralTriggers=[${proceduralResult.triggered.join(', ')}], SemanticViolations=[${semanticViolations.join(', ')}]`;

  return {
    isCompliant,
    riskTier: finalRiskTier,
    triggeredRules: proceduralResult.triggered,
    semanticViolations,
    auditTrail
  };
}
