/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Engine, RuleProperties } from 'json-rules-engine';

export interface PatientRecord {
  age: number;
  systolicBP: number;
  diastolicBP: number;
  heartRate: number;
  oxygenSaturation: number;
  comorbidities: string[];
}

const hypertensiveCrisisRule: RuleProperties = {
  name: 'HypertensiveCrisis',
  conditions: {
    any: [
      { fact: 'systolicBP', operator: 'greaterThanInclusive', value: 180 },
      { fact: 'diastolicBP', operator: 'greaterThanInclusive', value: 120 }
    ]
  },
  event: {
    type: 'HYPERTENSIVE_CRISIS_ALERT',
    params: { message: 'Immediate medical intervention required: Severe blood pressure elevation.' }
  }
};

const severeHypoxiaRule: RuleProperties = {
  name: 'SevereHypoxia',
  conditions: {
    all: [
      { fact: 'oxygenSaturation', operator: 'lessThan', value: 90 },
      { fact: 'comorbidities', operator: 'contains', value: 'COPD' }
    ]
  },
  event: {
    type: 'SEVERE_HYPOXIA_ALERT',
    params: { message: 'Critical oxygen saturation drop in COPD patient.' }
  }
};

const sepsisRiskRule: RuleProperties = {
  name: 'TachycardiaSepsisRisk',
  conditions: {
    all: [
      { fact: 'heartRate', operator: 'greaterThan', value: 100 },
      { fact: 'systolicBP', operator: 'lessThan', value: 90 },
      { fact: 'age', operator: 'greaterThan', value: 65 }
    ]
  },
  event: {
    type: 'SEPSIS_RISK_ALERT',
    params: { message: 'High risk of tachycardia-associated sepsis in elderly patient.' }
  }
};

export async function evaluatePatientRecord(record: PatientRecord): Promise<string[]> {
  const engine = new Engine();

  engine.addRule(hypertensiveCrisisRule);
  engine.addRule(severeHypoxiaRule);
  engine.addRule(sepsisRiskRule);

  const { events } = await engine.run(record);
  return events.map((event) => event.type);
}
