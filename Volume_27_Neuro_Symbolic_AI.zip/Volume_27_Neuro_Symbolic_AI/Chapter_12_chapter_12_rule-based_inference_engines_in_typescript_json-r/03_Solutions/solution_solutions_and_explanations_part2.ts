/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Store, Parser, DataFactory, Quad } from 'n3';

const { namedNode, quad } = DataFactory;

export async function inferArchitecturalRisks(turtleData: string): Promise<string[]> {
  const store = new Store();
  const parser = new Parser();

  const parseAsync = (data: string): Promise<Quad[]> =>
    new Promise((resolve, reject) => {
      const quads: Quad[] = [];
      parser.parse(data, (error, quadItem) => {
        if (error) reject(error);
        else if (quadItem) quads.push(quadItem);
        else resolve(quads);
      });
    });

  const initialQuads = await parseAsync(turtleData);
  store.addQuads(initialQuads);

  const criticalInfraType = namedNode('http://example.org/CriticalInfrastructure');
  const dependsOnPred = namedNode('http://example.org/dependsOn');
  const rdfType = namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type');
  const requiresAudit = namedNode('http://example.org/requiresSecurityAudit');

  // Forward-chaining rule inference
  const inferredQuads: Quad[] = [];
  store.forEach((q) => {
    if (q.predicate.equals(rdfType) && q.object.equals(criticalInfraType)) {
      const criticalComponent = q.subject;
      store.getQuads(null, dependsOnPred, criticalComponent, null).forEach((depQuad) => {
        const dependentComponent = depQuad.subject;
        inferredQuads.push(quad(dependentComponent, requiresAudit, DataFactory.literal('true')));
      });
    }
  }, null, null, null);

  store.addQuads(inferredQuads);

  const auditQuads = store.getQuads(null, requiresAudit, null, null);
  return Array.from(new Set(auditQuads.map((q) => q.subject.value)));
}
