/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export interface EvaluatedRuleEntry {
  ruleId: string;
  triggered: boolean;
  timestamp: number;
}

export interface SemanticTripleEntry {
  subject: string;
  predicate: string;
  object: string;
}

export interface AuditDashboardProps {
  patientId: string;
  evaluatedRules: EvaluatedRuleEntry[];
  inferredTriples: SemanticTripleEntry[];
  systemStatus: 'IDLE' | 'PROCESSING' | 'COMPLIANT' | 'VIOLATION';
}

export const NeuroSymbolicAuditDashboard: React.FC<AuditDashboardProps> = ({
  patientId,
  evaluatedRules,
  inferredTriples,
  systemStatus,
}) => {
  const getStatusBadgeClass = (status: AuditDashboardProps['systemStatus']) => {
    switch (status) {
      case 'COMPLIANT': return 'bg-green-500 text-white';
      case 'VIOLATION': return 'bg-red-500 text-white';
      case 'PROCESSING': return 'bg-yellow-500 text-black';
      default: return 'bg-gray-400 text-white';
    }
  };

  return (
    <div className="neuro-symbolic-dashboard p-6 font-sans">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Audit Dashboard for Patient: {patientId}</h2>
        <span className={`px-4 py-2 rounded-full font-semibold ${getStatusBadgeClass(systemStatus)}`}>
          {systemStatus}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="border p-4 rounded shadow-sm">
          <h3 className="text-lg font-semibold mb-3">Evaluated Rules</h3>
          <ul className="divide-y">
            {evaluatedRules.map((rule, idx) => (
              <li key={idx} className="py-2 flex justify-between">
                <span>{rule.ruleId}</span>
                <span className={rule.triggered ? 'text-red-600 font-bold' : 'text-green-600'}>
                  {rule.triggered ? 'TRIGGERED' : 'PASSED'}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="border p-4 rounded shadow-sm">
          <h3 className="text-lg font-semibold mb-3">Inferred Semantic Triples</h3>
          <ul className="divide-y text-sm font-mono">
            {inferredTriples.map((triple, idx) => (
              <li key={idx} className="py-2">
                <span className="text-blue-600">{triple.subject}</span> →{' '}
                <span className="text-purple-600">{triple.predicate}</span> →{' '}
                <span className="text-green-600">{triple.object}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default NeuroSymbolicAuditDashboard;
