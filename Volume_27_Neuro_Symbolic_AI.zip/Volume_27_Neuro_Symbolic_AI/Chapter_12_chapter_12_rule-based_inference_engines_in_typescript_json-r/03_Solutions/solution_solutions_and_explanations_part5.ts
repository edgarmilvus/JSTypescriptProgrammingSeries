/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Engine } from 'json-rules-engine';
import { Store } from 'n3';

export enum WorkflowState {
  CREATED = 'CREATED',
  VALIDATING = 'VALIDATING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  SETTLED = 'SETTLED',
}

export class TransitionViolationError extends Error {
  constructor(public readonly currentState: WorkflowState, public readonly violationReason: string) {
    super(`Transition failed from ${currentState}: ${violationReason}`);
    this.name = 'TransitionViolationError';
  }
}

export async function validateAndTransition(
  currentState: WorkflowState,
  action: string,
  contextData: Record<string, unknown>,
  rdfStore: Store
): Promise<WorkflowState> {
  const engine = new Engine();

  engine.addRule({
    name: 'TransactionLimitGuard',
    conditions: {
      all: [{ fact: 'amount', operator: 'lessThanInclusive', value: 10000 }]
    },
    event: { type: 'VALID_AMOUNT' }
  });

  const { events } = await engine.run(contextData);
  if (events.length === 0) {
    throw new TransitionViolationError(currentState, 'Quantitative check failed: Amount exceeds threshold.');
  }

  const entityNode = contextData.entityId ? rdfStore.dataFactory.namedNode(contextData.entityId as string) : null;
  if (entityNode) {
    const sanctionedType = rdfStore.dataFactory.namedNode('http://example.org/SanctionedEntity');
    const rdfType = rdfStore.dataFactory.namedNode('http://www.w3.org/1999/02/22-rdf-syntax-ns#type');
    
    const isSanctioned = rdfStore.getQuads(entityNode, rdfType, sanctionedType, null).length > 0;
    if (isSanctioned) {
      throw new TransitionViolationError(currentState, 'Ontological check failed: Entity is listed as sanctioned.');
    }
  }

  switch (currentState) {
    case WorkflowState.CREATED:
      if (action === 'SUBMIT') return WorkflowState.VALIDATING;
      break;
    case WorkflowState.VALIDATING:
      if (action === 'APPROVE') return WorkflowState.APPROVED;
      if (action === 'REJECT') return WorkflowState.REJECTED;
      break;
    case WorkflowState.APPROVED:
      if (action === 'SETTLE') return WorkflowState.SETTLED;
      break;
    default:
      break;
  }

  throw new TransitionViolationError(currentState, `Invalid action '${action}' for current state.`);
}
