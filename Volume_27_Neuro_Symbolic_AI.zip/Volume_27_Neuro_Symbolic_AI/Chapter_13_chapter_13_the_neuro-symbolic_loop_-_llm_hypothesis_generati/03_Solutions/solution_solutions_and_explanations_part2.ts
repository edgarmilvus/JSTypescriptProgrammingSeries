/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Driver, Session } from 'neo4j-driver';
import { LogicalNode } from './exercise-1';

export interface OntologicalContext {
  nodes: Array<{ id: string; labels: string[]; properties: Record<string, any> }>;
  edges: Array<{ source: string; target: string; type: string; properties: Record<string, any> }>;
}

export function CacheSubgraphQuery(ttlMs: number) {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value;
    const cache = new Map<string, { timestamp: number; data: OntologicalContext }>();

    descriptor.value = async function (ast: LogicalNode): Promise<OntologicalContext> {
      const cacheKey = JSON.stringify(ast);
      const now = Date.now();
      const cached = cache.get(cacheKey);

      if (cached && now - cached.timestamp < ttlMs) {
        return cached.data;
      }

      const result = await originalMethod.call(this, ast);
      cache.set(cacheKey, { timestamp: now, data: result });
      return result;
    };

    return descriptor;
  };
}

export class GraphContextExtractor {
  private driver: Driver;
  private queryTimeoutMs: number;

  constructor(driver: Driver, queryTimeoutMs: number = 5000) {
    this.driver = driver;
    this.queryTimeoutMs = queryTimeoutMs;
  }

  public extractEntities(ast: LogicalNode): string[] {
    const entities = new Set<string>();

    function traverse(n: LogicalNode) {
      if (!n) return;
      if (n.type === 'Variable') {
        entities.add(n.name);
      } else if (n.type === 'BinaryOp') {
        traverse(n.left);
        traverse(n.right);
      } else if (n.type === 'UnaryOp') {
        traverse(n.operand);
      } else if (n.type === 'Quantifier') {
        traverse(n.body);
      }
    }

    traverse(ast);
    return Array.from(entities);
  }

  public buildSubGraphQuery(entities: string[]): { query: string; params: Record<string, any> } {
    const query = `
      MATCH (e) WHERE e.name IN $entities
      MATCH path = (e)-[r*1..2]-(neighborhood)
      RETURN nodes(path) as nodes, relationships(path) as rels
    `;
    return { query, params: { entities } };
  }

  @CacheSubgraphQuery(60000)
  public async fetchContext(ast: LogicalNode): Promise<OntologicalContext> {
    const entities = this.extractEntities(ast);
    if (entities.length === 0) {
      return { nodes: [], edges: [] };
    }

    const { query, params } = this.buildSubGraphQuery(entities);
    const session: Session = this.driver.session();

    try {
      const result = await session.executeRead(async (tx) => {
        const res = await tx.run(query, params);
        return res;
      });

      const nodesMap = new Map<string, any>();
      const edgesMap = new Map<string, any>();

      for (const record of result.records) {
        const rawNodes = record.get('nodes');
        const rawRels = record.get('rels');

        for (const node of rawNodes) {
          nodesMap.set(node.elementId, {
            id: node.elementId,
            labels: node.labels,
            properties: node.properties,
          });
        }

        for (const rel of rawRels) {
          edgesMap.set(rel.elementId, {
            source: rel.startNodeElementId,
            target: rel.endNodeElementId,
            type: rel.type,
            properties: rel.properties,
          });
        }
      }

      return {
        nodes: Array.from(nodesMap.values()),
        edges: Array.from(edgesMap.values()),
      };
    } finally {
      await session.close();
    }
  }
}
