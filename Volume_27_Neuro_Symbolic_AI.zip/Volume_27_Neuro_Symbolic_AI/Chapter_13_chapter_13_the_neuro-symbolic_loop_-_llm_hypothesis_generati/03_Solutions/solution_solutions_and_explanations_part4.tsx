/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useReducer } from 'react';

export type DashboardState = 'IDLE' | 'GENERATING' | 'VERIFYING' | 'REFINING' | 'ACCEPTED' | 'TERMINATED_MAX_ITERATIONS';

export interface LoopEvent {
  type: 'STATE_CHANGE' | 'TOKEN_USAGE';
  state?: DashboardState;
  tokens?: { input: number; output: number };
}

export function useTokenTracker(events$: AsyncIterable<LoopEvent> | null, budgetLimit: number) {
  const [inputTokens, setInputTokens] = useState<number>(0);
  const [outputTokens, setOutputTokens] = useState<number>(0);

  useEffect(() => {
    if (!events$) return;
    let isMounted = true;

    async function consume() {
      for await (const event of events$) {
        if (!isMounted) break;
        if (event.type === 'TOKEN_USAGE' && event.tokens) {
          setInputTokens(prev => prev + event.tokens!.input);
          setOutputTokens(prev => prev + event.tokens!.output);
        }
      }
    }

    consume();
    return () => { isMounted = false; };
  }, [events$]);

  const totalTokens = inputTokens + outputTokens;
  const percentage = Math.min(100, (totalTokens / budgetLimit) * 100);
  const isWarning = percentage >= 80;

  return { inputTokens, outputTokens, totalTokens, percentage, isWarning };
}

interface DashboardProps {
  sessionId: string;
  initialHypothesis: string;
  eventsStream: AsyncIterable<LoopEvent> | null;
  budgetLimit: number;
}

export const NeuroSymbolicDashboard: React.FC<DashboardProps> = ({ sessionId, initialHypothesis, eventsStream, budgetLimit }) => {
  const [currentState, setCurrentState] = useState<DashboardState>('IDLE');
  const [maxIterations, setMaxIterations] = useState<number>(5);
  
  const tokenTracker = useTokenTracker(eventsStream, budgetLimit);

  return (
    <div className="p-6 grid grid-cols-2 gap-4 bg-gray-900 text-white min-h-screen">
      <div className="p-4 bg-gray-800 rounded-lg border border-gray-700">
        <h2 className="text-xl font-bold mb-2">Session: {sessionId}</h2>
        <div className="mb-4">
          <span className="px-3 py-1 bg-blue-600 rounded text-sm">State: {currentState}</span>
        </div>
        <div className="mb-4">
          <label className="block text-sm mb-1">Max Iteration Policy: {maxIterations}</label>
          <input 
            type="number" 
            value={maxIterations} 
            onChange={(e) => setMaxIterations(Number(e.target.value))}
            className="bg-gray-700 p-2 rounded w-full"
          />
        </div>
        <div className="mt-4">
          <h3 className="font-semibold mb-1">Token Budget Meter</h3>
          <div className="w-full bg-gray-700 h-4 rounded overflow-hidden">
            <div 
              className={`h-full ${tokenTracker.isWarning ? 'bg-red-500' : 'bg-green-500'}`} 
              style={{ width: `${tokenTracker.percentage}%` }}
            />
          </div>
          <p className="text-xs mt-1 text-gray-400">
            Used: {tokenTracker.totalTokens} / {budgetLimit} tokens ({tokenTracker.percentage.toFixed(1)}%)
          </p>
        </div>
      </div>
      
      <div className="p-4 bg-gray-800 rounded-lg border border-gray-700">
        <h2 className="text-xl font-bold mb-2">Hypothesis Viewer</h2>
        <pre className="bg-gray-900 p-3 rounded text-sm overflow-x-auto text-green-400">
          {initialHypothesis}
        </pre>
      </div>
    </div>
  );
};
