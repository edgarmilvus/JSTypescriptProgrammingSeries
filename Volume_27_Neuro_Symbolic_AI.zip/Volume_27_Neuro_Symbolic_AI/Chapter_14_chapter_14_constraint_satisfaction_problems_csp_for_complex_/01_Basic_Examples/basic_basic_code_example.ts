/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file CloudNodeScheduler.ts
 * @description A deterministic Constraint Satisfaction Problem (CSP) solver for 
 * allocating tenant workloads to physical compute nodes without resource collisions.
 * Implements strict type discipline (strictNullChecks, noImplicitAny).
 */

/** Represents the resource capacity and current load of a physical compute node. */
interface ComputeNode {
    readonly id: string;
    readonly maxCpuCores: number;
    readonly maxMemoryGb: number;
}

/** Represents an asynchronous tenant job demanding specific resources and time blocks. */
interface TenantWorkload {
    readonly id: string;
    readonly requiredCpuCores: number;
    readonly requiredMemoryGb: number;
    readonly requiredTimeSlot: number; // e.g., hour of day [0-23]
}

/** Represents a successfully verified allocation mapping. */
interface AllocationAssignment {
    readonly workloadId: string;
    readonly nodeId: string;
    readonly timeSlot: number;
}

/** 
 * Encapsulates the CSP state and execution context for deterministic scheduling.
 */
class DeterministicSchedulerEngine {
    private readonly nodes: ReadonlyArray<ComputeNode>;
    private readonly workloads: ReadonlyArray<TenantWorkload>;

    /**
     * Initializes the scheduler with immutable domain entities.
     * @param nodes Available physical infrastructure nodes.
     * @param workloads Pending tenant execution requests.
     */
    constructor(nodes: ComputeNode[], workloads: TenantWorkload[]) {
        this.nodes = Object.freeze([...nodes]);
        this.workloads = Object.freeze([...workloads]);
    }

    /**
     * Determines whether a specific workload can be assigned to a node at a given 
     * time slot without violating capacity or temporal overlap constraints.
     */
    private isConstraintSatisfied(
        workload: TenantWorkload,
        node: ComputeNode,
        timeSlot: number,
        currentAssignments: ReadonlyArray<AllocationAssignment>
    ): boolean {
        // Constraint 1: Check capacity boundaries of the target node
        if (workload.requiredCpuCores > node.maxCpuCores) {
            return false;
        }
        if (workload.requiredMemoryGb > node.maxMemoryGb) {
            return false;
        }

        // Filter current assignments that target this specific physical node
        const nodeAssignments = currentAssignments.filter(
            (assignment) => assignment.nodeId === node.id
        );

        // Calculate cumulative resource utilization at the requested time slot
        let utilizedCpu = 0;
        let utilizedMemory = 0;

        for (const assignment of nodeAssignments) {
            if (assignment.timeSlot === timeSlot) {
                // Find the corresponding workload details to sum resources
                const assignedWorkload = this.workloads.find(
                    (w) => w.id === assignment.workloadId
                );
                
                if (assignedWorkload !== undefined) {
                    utilizedCpu += assignedWorkload.requiredCpuCores;
                    utilizedMemory += assignedWorkload.requiredMemoryGb;
                }
            }
        }

        // Constraint 2: Verify cumulative resource limits do not exceed node maximums
        const projectedCpu = utilizedCpu + workload.requiredCpuCores;
        const projectedMemory = utilizedMemory + workload.requiredMemoryGb;

        if (projectedCpu > node.maxCpuCores || projectedMemory > node.maxMemoryGb) {
            return false;
        }

        return true;
    }

    /**
     * Executes a recursive backtracking search algorithm to find a complete,
     * conflict-free allocation mapping for all pending workloads.
     * 
     * @param workloadIndex The current index in the workloads array to process.
     * @param currentAssignments Accumulator for valid assignments discovered so far.
     * @returns An array of assignments if successful, or null if no valid state exists.
     */
    private backtrackSearch(
        workloadIndex: number,
        currentAssignments: AllocationAssignment[]
    ): AllocationAssignment[] | null {
        // Base Case: If all workloads have been assigned, return the valid solution path
        if (workloadIndex >= this.workloads.length) {
            return currentAssignments;
        }

        const currentWorkload = this.workloads[workloadIndex];
        if (currentWorkload === undefined) {
            throw new Error(`Critical: Workload at index ${workloadIndex} is undefined.`);
        }

        // Iterate through all available physical nodes to find a valid binding
        for (const node of this.nodes) {
            const timeSlot = currentWorkload.requiredTimeSlot;

            // Test constraints against the current candidate assignment
            if (this.isConstraintSatisfied(currentWorkload, node, timeSlot, currentAssignments)) {
                
                // Construct new assignment state immutably
                const newAssignment: AllocationAssignment = {
                    workloadId: currentWorkload.id,
                    nodeId: node.id,
                    timeSlot: timeSlot,
                };

                const nextAssignments = [...currentAssignments, newAssignment];

                // Recursively attempt to solve for the next workload in the queue
                const solution = this.backtrackSearch(workloadIndex + 1, nextAssignments);

                // If a complete downstream solution was found, propagate it upward
                if (solution !== null) {
                    return solution;
                }
                
                // Otherwise, backtracking occurs implicitly here: the loop continues
                // to the next node, discarding the invalid branch.
            }
        }

        // Exhausted all node options for this workload without finding a valid slot
        return null;
    }

    /**
     * Public entry point to execute the CSP solver engine.
     * @returns A frozen array of allocation assignments or an error if impossible.
     */
    public solve(): ReadonlyArray<AllocationAssignment> {
        const initialAssignments: AllocationAssignment[] = [];
        const result = this.backtrackSearch(0, initialAssignments);

        if (result === null) {
            throw new Error("CSP Solver Failure: No valid schedule exists for the given resource constraints.");
        }

        return Object.freeze(result);
    }
}

// ==========================================
// Execution Example (SaaS Context)
// ==========================================

// 1. Define physical infrastructure nodes available in our Kubernetes cluster
const clusterNodes: ComputeNode[] = [
    { id: "node-us-east-1", maxCpuCores: 8, maxMemoryGb: 32 },
    { id: "node-us-east-2", maxCpuCores: 4, maxMemoryGb: 16 },
];

// 2. Define incoming tenant workloads requesting execution slots
const tenantWorkloads: TenantWorkload[] = [
    { id: "tenant-job-alpha", requiredCpuCores: 4, requiredMemoryGb: 16, requiredTimeSlot: 10 },
    { id: "tenant-job-beta", requiredCpuCores: 4, requiredMemoryGb: 16, requiredTimeSlot: 10 },
    { id: "tenant-job-gamma", requiredCpuCores: 2, requiredMemoryGb: 8, requiredTimeSlot: 10 },
];

// 3. Instantiate and run the deterministic solver
try {
    const scheduler = new DeterministicSchedulerEngine(clusterNodes, tenantWorkloads);
    const schedule = scheduler.solve();
    
    console.log("Successfully generated deterministic schedule:", JSON.stringify(schedule, null, 2));
} catch (error: unknown) {
    if (error instanceof Error) {
        console.error("Scheduling failure caught:", error.message);
    } else {
        console.error("An unknown error occurred during scheduling.");
    }
}
