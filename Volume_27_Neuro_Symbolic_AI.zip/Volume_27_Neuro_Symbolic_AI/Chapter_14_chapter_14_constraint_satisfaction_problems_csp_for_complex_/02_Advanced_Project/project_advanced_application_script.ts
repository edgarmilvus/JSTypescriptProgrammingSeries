/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file Enterprise CSP Scheduling Engine for TypeScript / Next.js
 * @description Implements a deterministic CSP solver backed by a Knowledge Graph ontology
 * for zero-hallucination resource allocation and shift scheduling.
 */

import { performance } from 'perf_hooks';

// ============================================================================
// 1. Ontological & Domain Data Structures
// ============================================================================

export type SkillLevel = 'JUNIOR' | 'SENIOR' | 'EXPERT';

export interface ResourceNode {
  id: string;
  type: 'PERSONNEL' | 'EQUIPMENT' | 'FACILITY';
  skills: SkillLevel[];
  availability: [number, number][]; // Array of valid [startHour, endHour] windows
}

export interface TaskNode {
  id: string;
  requiredSkill: SkillLevel;
  durationHours: number;
  preferredRoomId: string;
}

export interface CSPDomain {
  variableId: string; // taskId
  possibleStartTimes: number[]; // Discrete hourly slots [8, 9, 10, ...]
  possibleResources: string[]; // Resource IDs capable of executing the task
}

export interface Assignment {
  taskId: string;
  startTime: number;
  endTime: number;
  resourceId: string;
}

// ============================================================================
// 2. GraphDB & Ontology Interface Mock
// ============================================================================

export class EnterpriseKnowledgeGraph {
  private resources: Map<string, ResourceNode> = new Map();
  private tasks: Map<string, TaskNode> = new Map();

  /**
   * Ingests ontological nodes representing enterprise assets and workflow dependencies.
   */
  public addResource(resource: ResourceNode): void {
    this.resources.set(resource.id, resource);
  }

  public addTask(task: TaskNode): void {
    this.tasks.set(task.id, task);
  }

  public getResources(): ResourceNode[] {
    return Array.from(this.resources.values());
  }

  public getTasks(): TaskNode[] {
    return Array.from(this.tasks.values());
  }

  /**
   * Generates initial CSP domains by querying the Knowledge Graph for capability matching.
   */
  public generateInitialDomains(timeHorizon: number[]): Map<string, CSPDomain> {
    const domains = new Map<string, CSPDomain>();

    for (const task of this.tasks.values()) {
      // Find resources matching the required skill level
      const validResources = Array.from(this.resources.values())
        .filter(res => res.skills.includes(task.requiredSkill))
        .map(res => res.id);

      domains.set(task.id, {
        variableId: task.id,
        possibleStartTimes: timeHorizon.filter(t => t + task.durationHours <= Math.max(...timeHorizon)),
        possibleResources: validResources,
      });
    }

    return domains;
  }
}

// ============================================================================
// 3. Deterministic CSP Engine & AC-3 Arc Consistency
// ============================================================================

export class CSPSchedulerEngine {
  private graph: EnterpriseKnowledgeGraph;
  private timeHorizon: number[];

  constructor(graph: EnterpriseKnowledgeGraph, timeHorizon: number[]) {
    this.graph = graph;
    this.timeHorizon = timeHorizon;
  }

  /**
   * Enforces Arc Consistency (AC-3) to prune impossible assignments before search.
   */
  public enforceArcConsistency(domains: Map<string, CSPDomain>): boolean {
    const tasks = this.graph.getTasks();
    const queue: [string, string][] = [];

    // Populate queue with all binary task pairs
    for (let i = 0; i < tasks.length; i++) {
      for (let j = 0; j < tasks.length; j++) {
        if (i !== j) {
          queue.push([tasks[i].id, tasks[j].id]);
        }
      }
    }

    while (queue.length > 0) {
      const [xi, xj] = queue.shift()!;
      if (this.removeInconsistentValues(domains, xi, xj)) {
        const domainXi = domains.get(xi);
        if (!domainXi || domainXi.possibleStartTimes.length === 0) {
            return false; // Domain wiped out, no solution exists
        }
      }
    }

    return true;
  }

  /**
   * Removes start times from Xi that conflict with any potential value in Xj (e.g., resource double-booking).
   */
  private removeInconsistentValues(domains: Map<string, CSPDomain>, xi: string, xj: string): boolean {
    let pruned = false;
    const domainXi = domains.get(xi)!;
    const domainXj = domains.get(xj)!;
    const taskI = this.graph.getTasks().find(t => t.id === xi)!;
    const taskJ = this.graph.getTasks().find(t => t.id === xj)!;

    const remainingTimes: number[] = [];

    for (const tI of domainXi.possibleStartTimes) {
      let hasValidSupport = false;

      for (const tJ of domainXj.possibleStartTimes) {
        // Check temporal overlap if same resource could be assigned
        const overlaps = !(tI + taskI.durationHours <= tJ || tJ + taskJ.durationHours <= tI);
        
        // If they overlap in time, they must not share the exact same resource pool completely,
        // or we need at least one non-conflicting resource assignment vector.
        const sharedResources = domainXi.possibleResources.filter(r => domainXj.possibleResources.includes(r));

        if (!overlaps || sharedResources.length === 0) {
          hasValidSupport = true;
          break;
        }
      }

      if (hasValidSupport) {
        remainingTimes.push(tI);
      } else {
        pruned = true;
      }
    }

    domainXi.possibleStartTimes = remainingTimes;
    return pruned;
  }

  /**
   * Backtracking search with Minimum Remaining Values (MRV) heuristic.
   */
  public solve(): Assignment[] | null {
    const domains = this.graph.generateInitialDomains(this.timeHorizon);
    
    if (!this.enforceArcConsistency(domains)) {
      return null; // Unsatisfiable graph constraints
    }

    const assignments: Map<string, { startTime: number; resourceId: string }> = new Map();
    const success = this.backtrack(assignments, domains);

    if (!success) return null;

    // Format final deterministic output
    const results: Assignment[] = [];
    for (const [taskId, data] of assignments.entries()) {
      const task = this.graph.getTasks().find(t => t.id === taskId)!;
      results.push({
        taskId,
        startTime: data.startTime,
        endTime: data.startTime + task.durationHours,
        resourceId: data.resourceId,
      });
    }

    return results;
  }

  private backtrack(
    assignments: Map<string, { startTime: number; resourceId: string }>,
    domains: Map<string, CSPDomain>
  ): boolean {
    if (assignments.size === this.graph.getTasks().length) {
      return true; // All variables assigned successfully
    }

    // Select unassigned variable using MRV heuristic (smallest domain first)
    const unassignedTasks = this.graph.getTasks().filter(t => !assignments.has(t.id));
    unassignedTasks.sort((a, b) => {
      const domA = domains.get(a.id)?.possibleStartTimes.length || 0;
      const domB = domains.get(b.id)?.possibleStartTimes.length || 0;
      return domA - domB;
    });

    const task = unassignedTasks[0];
    const domain = domains.get(task.id)!;

    for (const startTime of domain.possibleStartTimes) {
      for (const resourceId of domain.possibleResources) {
        if (this.isConsistent(task.id, startTime, resourceId, assignments)) {
          // Assign
          assignments.set(task.id, { startTime, resourceId });

          // Recurse
          if (this.backtrack(assignments, domains)) {
            return true;
          }

          // Unassign (Backtrack)
          assignments.delete(task.id);
        }
      }
    }

    return false;
  }

  private isConsistent(
    taskId: string,
    startTime: number,
    resourceId: string,
    assignments: Map<string, { startTime: number; resourceId: string }>
  ): boolean {
    const task = this.graph.getTasks().find(t => t.id === taskId)!;
    const endTime = startTime + task.durationHours;

    for (const [assignedId, data] of assignments.entries()) {
      const assignedTask = this.graph.getTasks().find(t => t.id === assignedId)!;
      const assignedEndTime = data.startTime + assignedTask.durationHours;

      // Check resource collision
      if (data.resourceId === resourceId) {
        const overlaps = !(endTime <= data.startTime || startTime >= assignedEndTime);
        if (overlaps) return false;
      }
    }

    return true;
  }
}

// ============================================================================
// 4. Execution & SaaS Pipeline Integration Example
// ============================================================================

export function runEnterpriseSchedulingDemo(): void {
  const kg = new EnterpriseKnowledgeGraph();

  // Seed Knowledge Graph with Personnel Assets
  kg.addResource({ id: 'Eng_Alice', type: 'PERSONNEL', skills: ['SENIOR', 'EXPERT'], availability: [[8, 18]] });
  kg.addResource({ id: 'Eng_Bob', type: 'PERSONNEL', skills: ['JUNIOR', 'SENIOR'], availability: [[8, 18]] });

  // Seed Knowledge Graph with Tasks
  kg.addTask({ id: 'Task_ArchReview', requiredSkill: 'EXPERT', durationHours: 2, preferredRoomId: 'Room_A' });
  kg.addTask({ id: 'Task_CodeMigration', requiredSkill: 'SENIOR', durationHours: 4, preferredRoomId: 'Room_B' });
  kg.addTask({ id: 'Task_UnitTesting', requiredSkill: 'JUNIOR', durationHours: 3, preferredRoomId: 'Room_C' });

  // Define operational time horizon (e.g., 08:00 to 18:00)
  const timeHorizon = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17];

  const engine = new CSPSchedulerEngine(kg, timeHorizon);
  
  const startTime = performance.now();
  const schedule = engine.solve();
  const endTime = performance.now();

  console.log(`[CSP Solver] Execution Time: ${(endTime - startTime).toFixed(4)}ms`);
  
  if (schedule) {
    console.log('[CSP Solver] Zero-Hallucination Schedule Successfully Generated:');
    console.table(schedule);
  } else {
    console.error('[CSP Solver] No valid schedule found satisfying ontological constraints.');
  }
}
