/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { MockGraphDBClient } from './mockGraphDB';

export interface OntologyNode {
  id: string;
  type: string;
  properties: Record<string, any>;
}

export interface CSPVariable {
  name: string;
  domain: any[];
}

export interface CSPConstraint {
  variables: string[];
  predicate: (assignment: Record<string, any>) => boolean;
}

export interface CSPProblem {
  variables: CSPVariable[];
  constraints: CSPConstraint[];
}

export async function extractCSPProblem(sparqlClient: MockGraphDBClient): Promise<CSPProblem> {
  try {
    // 1. Fetch raw ontology nodes representing Tasks and Resources
    const rawNodes: OntologyNode[] = await sparqlClient.query(
      "SELECT ?node ?type ?props WHERE { ?node rdf:type ?type . ?node hasProperties ?props }"
    );

    if (!rawNodes || rawNodes.length === 0) {
      throw new Error("Graph query returned zero nodes or disconnected graph.");
    }

    const tasks = rawNodes.filter(n => n.type === 'Task');
    const resources = rawNodes.filter(n => n.type === 'Resource' || n.type === 'SupervisedEquipment');
    const subclassEdges = await sparqlClient.query(
      "SELECT ?sub ?super WHERE { ?sub rdfs:subClassOf ?super }"
    );

    // Build subclass inheritance map for transitive domain resolution
    const subclassMap = new Map<string, string[]>();
    subclassEdges.forEach((edge: { sub: string; super: string }) => {
      const list = subclassMap.get(edge.super) || [];
      list.push(edge.sub);
      subclassMap.set(edge.super, list);
    });

    // Helper to resolve transitive subclass resource domains
    const resolveSubclasses = (resourceType: string): any[] => {
      let matching = resources.filter(r => r.properties.category === resourceType || r.type === resourceType);
      const subs = subclassMap.get(resourceType) || [];
      for (const sub of subs) {
        matching = matching.concat(resolveSubclasses(sub));
      }
      return matching;
    };

    const variables: CSPVariable[] = [];
    const constraints: CSPConstraint[] = [];

    // 2. Map tasks to CSP variables
    for (const task of tasks) {
      if (!task.properties || !task.properties.duration) {
        throw new Error(`Task ${task.id} is missing required 'duration' property in graph.`);
      }

      const requiredSkill = task.properties.requiredSkill;
      const requiredEquipmentType = task.properties.requiredEquipmentType;

      // Filter domain based on ontological properties (skills & equipment classes)
      let domain = resources.filter(res => {
        const matchesSkill = !requiredSkill || (res.properties.skills && res.properties.skills.includes(requiredSkill));
        const matchesType = !requiredEquipmentType || res.properties.category === requiredEquipmentType || res.type === requiredEquipmentType;
        return matchesSkill && matchesType;
      });

      // If equipment type uses hierarchical inheritance, expand domain transitively
      if (requiredEquipmentType && domain.length === 0) {
        const transitiveResources = resolveSubclasses(requiredEquipmentType);
        domain = transitiveResources.filter(res => !requiredSkill || (res.properties.skills && res.properties.skills.includes(requiredSkill)));
      }

      if (domain.length === 0) {
        throw new Error(`Domain wipe-out detected during extraction: No resources satisfy constraints for task ${task.id}`);
      }

      variables.push({
        name: task.id,
        domain: domain.map(d => ({ resourceId: d.id, duration: task.properties.duration }))
      });
    }

    // 3. Extract temporal and binary constraints from graph edges
    const rawConstraints = await sparqlClient.query(
      "SELECT ?t1 ?t2 ?relation WHERE { ?t1 ?relation ?t2 }"
    );

    rawConstraints.forEach((rel: { t1: string; t2: string; relation: string }) => {
      if (rel.relation === 'precedes' && tasks.some(t => t.id === rel.t1) && tasks.some(t => t.id === rel.t2)) {
        constraints.push({
          variables: [rel.t1, rel.t2],
          predicate: (assignment: Record<string, any>) => {
            const assign1 = assignment[rel.t1];
            const assign2 = assignment[rel.t2];
            if (!assign1 || !assign2) return true; // Unassigned variables pass temporarily
            // Task 1 must finish before Task 2 starts
            return (assign1.startTime + assign1.duration) <= assign2.startTime;
          }
        });
      }
    });

    // Resource exclusion constraint: No two tasks can use the exact same resource simultaneously
    for (let i = 0; i < tasks.length; i++) {
      for (let j = i + 1; j < tasks.length; j++) {
        const t1Id = tasks[i].id;
        const t2Id = tasks[j].id;
        constraints.push({
          variables: [t1Id, t2Id],
          predicate: (assignment: Record<string, any>) => {
            const a1 = assignment[t1Id];
            const a2 = assignment[t2Id];
            if (!a1 || !a2) return true;
            if (a1.resourceId !== a2.resourceId) return true; // Different resources, no conflict
            
            // Check for time overlap on the same resource
            const end1 = a1.startTime + a1.duration;
            const end2 = a2.startTime + a2.duration;
            return end1 <= a2.startTime || end2 <= a1.startTime;
          }
        });
      }
    }

    return { variables, constraints };
  } catch (error: any) {
    throw new Error(`Failed to extract CSP problem from Knowledge Graph: ${error.message}`);
  }
}
