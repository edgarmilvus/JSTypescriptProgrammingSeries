/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type Assignment<TVar extends string, TVal> = Map<TVar, TVal>;

export interface SolverResult<TVar extends string, TVal> {
  success: boolean;
  assignment?: Assignment<TVar, TVal>;
  nodesExplored: number;
  failureReason?: string;
}

export class DeterministicCSPSolver<TVar extends string, TVal> {
  private variables: Map<TVar, TVal[]>;
  private constraints: Array<{ vars: TVar[]; check: (assignment: Map<TVar, TVal>) => boolean }>;
  private nodesExplored: number = 0;

  constructor(variables: Map<TVar, TVal[]>, constraints: any[]) {
    this.variables = variables;
    this.constraints = constraints;
  }

  public solve(): SolverResult<TVar, TVal> {
    this.nodesExplored = 0;
    const initialAssignment = new Map<TVar, TVal>();
    const domainsCopy = new Map<TVar, TVal[]>();
    
    for (const [v, dom] of this.variables.entries()) {
      domainsCopy.set(v, [...dom]);
    }

    const result = this.backtrack(initialAssignment, domainsCopy);
    return {
      success: result !== null,
      assignment: result || undefined,
      nodesExplored: this.nodesExplored,
      failureReason: result ? undefined : "Unsatisfiable: Dead-end reached where all variable domains were exhausted or pruned via forward checking."
    };
  }

  private selectUnassignedVariable(assignment: Assignment<TVar, TVal>, domains: Map<TVar, TVal[]>): TVar | null {
    let unassigned = Array.from(this.variables.keys()).filter(v => !assignment.has(v));
    if (unassigned.length === 0) return null;

    // MRV heuristic: find variable with smallest remaining domain
    let bestVar = unassigned[0];
    let minDomainSize = domains.get(bestVar)!.length;
    let candidates = [bestVar];

    for (let i = 1; i < unassigned.length; i++) {
      const v = unassigned[i];
      const size = domains.get(v)!.length;
      if (size < minDomainSize) {
        minDomainSize = size;
        candidates = [v];
      } else if (size === minDomainSize) {
        candidates.push(v);
      }
    }

    // Degree heuristic tie-breaker: select variable involved in most constraints with unassigned vars
    if (candidates.length > 1) {
      let maxDegree = -1;
      let selectedByDegree = candidates[0];

      for (const cVar of candidates) {
        let degree = 0;
        for (const constraint of this.constraints) {
          if (constraint.vars.includes(cVar)) {
            for (const otherVar of constraint.vars) {
              if (otherVar !== cVar && !assignment.has(otherVar)) {
                degree++;
              }
            }
          }
        }
        if (degree > maxDegree) {
          maxDegree = degree;
          selectedByDegree = cVar;
        }
      }
      return selectedByDegree;
    }

    return bestVar;
  }

  private backtrack(assignment: Assignment<TVar, TVal>, domains: Map<TVar, TVal[]>): Assignment<TVar, TVal> | null {
    this.nodesExplored++;
    if (assignment.size === this.variables.size) {
      return assignment;
    }

    const varName = this.selectUnassignedVariable(assignment, domains);
    if (!varName) return null;

    const domainValues = domains.get(varName)!;

    for (const value of domainValues) {
      assignment.set(varName, value);

      // Validate current assignment against all constraints touching this variable
      if (this.isConsistent(varName, assignment)) {
        // Forward Checking: prune domains of neighboring unassigned variables
        const savedDomains = this.cloneDomains(domains);
        const forwardCheckFailed = !this.forwardCheck(varName, assignment, domains);

        if (!forwardCheckFailed) {
          const result = this.backtrack(assignment, domains);
          if (result !== null) return result;
        }

        // Restore domains if path failed
        domains.clear();
        for (const [k, v] of savedDomains.entries()) {
          domains.set(k, v);
        }
      }

      assignment.delete(varName);
    }

    return null;
  }

  private isConsistent(varName: TVar, assignment: Assignment<TVar, TVal>): boolean {
    for (const constraint of this.constraints) {
      if (constraint.vars.includes(varName)) {
        // Only evaluate if all variables in the constraint are currently assigned
        const allAssigned = constraint.vars.every(v => assignment.has(v));
        if (allAssigned) {
          if (!constraint.check(assignment)) {
            return false;
          }
        }
      }
    }
    return true;
  }

  private forwardCheck(varName: TVar, assignment: Assignment<TVar, TVal>, domains: Map<TVar, TVal[]>): boolean {
    for (const constraint of this.constraints) {
      if (constraint.vars.includes(varName)) {
        const unassignedNeighbors = constraint.vars.filter(v => !assignment.has(v));
        for (const neighbor of unassignedNeighbors) {
          const neighborDomain = domains.get(neighbor)!;
          const validDomainValues: TVal[] = [];

          for (const val of neighborDomain) {
            assignment.set(neighbor, val);
            if (constraint.check(assignment)) {
              validDomainValues.push(val);
            }
            assignment.delete(neighbor);
          }

          domains.set(neighbor, validDomainValues);
          if (validDomainValues.length === 0) {
            return false; // Domain wipe-out detected
          }
        }
      }
    }
    return true;
  }

  private cloneDomains(domains: Map<TVar, TVal[]>): Map<TVar, TVal[]> {
    const copy = new Map<TVar, TVal[]>();
    for (const [k, v] of domains.entries()) {
      copy.set(k, [...v]);
    }
    return copy;
  }
}
