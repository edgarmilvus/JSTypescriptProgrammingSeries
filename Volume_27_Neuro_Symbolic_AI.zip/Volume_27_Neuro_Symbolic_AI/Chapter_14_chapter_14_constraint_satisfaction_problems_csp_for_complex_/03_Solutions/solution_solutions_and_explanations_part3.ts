/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { EventEmitter } from 'events';

export class LiveSchedulingEngine extends EventEmitter {
  private graphState: Map<string, any>;
  private cspDomains: Map<string, any[]>;
  private arcs: Array<[string, string]>;
  private constraints: Map<string, Array<(val1: any, val2: any) => boolean>>;
  private executionLock: boolean = false;

  constructor(initialGraphState: Map<string, any>, initialDomains: Map<string, any[]>, arcs: Array<[string, string]>) {
    super();
    this.graphState = initialGraphState;
    this.cspDomains = initialDomains;
    this.arcs = arcs;
    this.constraints = new Map();
  }

  public registerConstraint(var1: string, var2: string, predicate: (val1: any, val2: any) => boolean): void {
    const key1 = `${var1}->${var2}`;
    const key2 = `${var2}->${var1}`;
    
    const list1 = this.constraints.get(key1) || [];
    list1.push(predicate);
    this.constraints.set(key1, list1);

    const list2 = this.constraints.get(key2) || [];
    list2.push((v1, v2) => predicate(v2, v1));
    this.constraints.set(key2, list2);
  }

  public async handleGraphMutation(mutationEvent: { type: string; entityId: string; delta: any }): Promise<void> {
    if (this.executionLock) {
      throw new Error("Execution lock active: Concurrent graph mutation blocked during ongoing AC-3 propagation.");
    }

    this.executionLock = true;
    const previousGraphStateSnapshot = new Map(this.graphState);
    const previousDomainsSnapshot = new Map<string, any[]>();
    for (const [k, v] of this.cspDomains.entries()) {
      previousDomainsSnapshot.set(k, [...v]);
    }

    try {
      // 1. Apply mutation to graph state
      this.graphState.set(mutationEvent.entityId, mutationEvent.delta);

      // 2. Adjust CSP domains based on mutation
      if (mutationEvent.type === 'RESOURCE_UNAVAILABLE') {
        for (const [varName, domain] of this.cspDomains.entries()) {
          const filtered = domain.filter(d => d.resourceId !== mutationEvent.entityId);
          this.cspDomains.set(varName, filtered);
        }
      } else if (mutationEvent.type === 'TASK_DURATION_UPDATE') {
        const domain = this.cspDomains.get(mutationEvent.entityId);
        if (domain) {
          this.cspDomains.set(mutationEvent.entityId, domain.map(d => ({ ...d, duration: mutationEvent.delta.newDuration })));
        }
      }

      // 3. Run AC-3 to enforce arc consistency
      const consistent = this.runAC3();

      if (!consistent) {
        // Rollback state on deadlock
        this.graphState = previousGraphStateSnapshot;
        this.cspDomains = previousDomainsSnapshot;
        this.emit('ConflictRejection', {
          entityId: mutationEvent.entityId,
          reason: 'Graph mutation introduced unresolvable arc inconsistency (deadlock).'
        });
        return;
      }

      this.emit('onScheduleUpdate', { domains: Object.fromEntries(this.cspDomains) });
    } catch (error: any) {
      // Rollback on unexpected failure
      this.graphState = previousGraphStateSnapshot;
      this.cspDomains = previousDomainsSnapshot;
      this.emit('ConflictRejection', { entityId: mutationEvent.entityId, error: error.message });
    } finally {
      this.executionLock = false;
    }
  }

  private runAC3(): boolean {
    const queue: Array<[string, string]> = [...this.arcs];

    while (queue.length > 0) {
      const [Xi, Xj] = queue.shift()!;

      if (this.revise(Xi, Xj)) {
        const domainXi = this.cspDomains.get(Xi) || [];
        if (domainXi.length === 0) {
          return false; // Domain wipe-out: arc inconsistency detected
        }
        // Add neighboring arcs back to queue
        for (const [xk, xl] of this.arcs) {
          if (xl === Xi && xk !== Xj) {
            queue.push([xk, Xi]);
          }
        }
      }
    }
    return true;
  }

  private revise(Xi: string, Xj: string): boolean {
    let revised = false;
    const domainXi = this.cspDomains.get(Xi) || [];
    const domainXj = this.cspDomains.get(Xj) || [];
    const predicates = this.constraints.get(`${Xi}->${Xj}`) || [];

    const newDomainXi: any[] = [];

    for (const x of domainXi) {
      let hasSupport = false;
      for (const y of domainXj) {
        let satisfiesAll = true;
        for (const pred of predicates) {
          if (!pred(x, y)) {
            satisfiesAll = false;
            break;
          }
        }
        if (satisfiesAll) {
          hasSupport = true;
          break;
        }
      }

      if (hasSupport) {
        newDomainXi.push(x);
      } else {
        revised = true;
      }
    }

    this.cspDomains.set(Xi, newDomainXi);
    return revised;
  }
}
