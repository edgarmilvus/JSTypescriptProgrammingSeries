/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

export interface ScheduleItem {
  resourceId: string;
  resourceName: string;
  startTime: number;
  endTime: number;
  taskId: string;
  status: 'locked' | 'solved' | 'conflicted';
  ontologicalJustification: string;
  resourceClass: string;
}

export interface ScheduleMatrixViewProps {
  scheduleData: ScheduleItem[];
  onLockAssignment: (resourceId: string, startTime: number, locked: boolean) => void;
  onInspectOntology: (justification: string) => void;
}

export const ScheduleMatrixView: React.FC<ScheduleMatrixViewProps> = ({
  scheduleData,
  onLockAssignment,
  onInspectOntology,
}) => {
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectedJustification, setInspectedJustification] = useState<string | null>(null);

  // Memoized filter calculation for 60fps performance during scale operations
  const filteredSchedule = useMemo(() => {
    return scheduleData.filter(item => {
      const matchesClass = selectedClassFilter === 'ALL' || item.resourceClass === selectedClassFilter;
      const matchesSearch = item.resourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            item.taskId.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesClass && matchesSearch;
    });
  }, [scheduleData, selectedClassFilter, searchQuery]);

  // Extract unique resource classes for toolbar filter
  const resourceClasses = useMemo(() => {
    const classes = new Set(scheduleData.map(i => i.resourceClass));
    return ['ALL', ...Array.from(classes)];
  }, [scheduleData]);

  const handleCellClick = (item: ScheduleItem) => {
    const newLockState = item.status !== 'locked';
    onLockAssignment(item.resourceId, item.startTime, newLockState);
  };

  const handleInspectClick = (item: ScheduleItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setInspectedJustification(item.ontologicalJustification);
    onInspectOntology(item.ontologicalJustification);
  };

  return (
    <div className="csp-schedule-matrix" style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Deterministic Resource Allocation Matrix</h2>
      
      {/* Search and Filter Toolbar */}
      <div style={{ marginBottom: '15px', display: 'flex', gap: '15px' }}>
        <input
          type="text"
          placeholder="Filter by Task or Resource..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ padding: '8px', width: '250px' }}
        />
        <select
          value={selectedClassFilter}
          onChange={(e) => setSelectedClassFilter(e.target.value)}
          style={{ padding: '8px' }}
        >
          {resourceClasses.map(cls => (
            <option key={cls} value={cls}>{cls}</option>
          ))}
        </select>
      </div>

      <div style={{ display: 'flex', gap: '20px' }}>
        {/* Timeline Grid */}
        <div style={{ flex: 2, overflowX: 'auto', border: '1px solid #ccc', padding: '10px' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f4f4f4', borderBottom: '2px solid #ddd' }}>
                <th style={{ padding: '8px', textAlign: 'left' }}>Resource</th>
                <th style={{ padding: '8px', textAlign: 'left' }}>Task ID</th>
                <th style={{ padding: '8px', textAlign: 'left' }}>Time Window</th>
                <th style={{ padding: '8px', textAlign: 'left' }}>Status</th>
                <th style={{ padding: '8px', textAlign: 'left' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredSchedule.map((item, index) => {
                const statusColor = 
                  item.status === 'locked' ? '#2196F3' :
                  item.status === 'solved' ? '#4CAF50' : '#F44336';

                return (
                  <tr 
                    key={index} 
                    onClick={() => handleCellClick(item)}
                    style={{ borderBottom: '1px solid #eee', cursor: 'pointer', background: item.status === 'conflicted' ? '#ffebee' : 'transparent' }}
                  >
                    <td style={{ padding: '8px' }}>{item.resourceName} ({item.resourceClass})</td>
                    <td style={{ padding: '8px' }}>{item.taskId}</td>
                    <td style={{ padding: '8px' }}>{item.startTime} - {item.endTime}</td>
                    <td style={{ padding: '8px' }}>
                      <span style={{ background: statusColor, color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '12px' }}>
                        {item.status.toUpperCase()}
                      </span>
                    </td>
                    <td style={{ padding: '8px' }}>
                      <button 
                        onClick={(e) => handleInspectClick(item, e)}
                        style={{ padding: '4px 8px', background: '#333', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                      >
                        Inspect Ontology
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Ontological Justification Side Panel */}
        <div style={{ flex: 1, border: '1px solid #ccc', padding: '15px', background: '#fafafa', borderRadius: '4px' }}>
          <h3>Ontological Justification</h3>
          {inspectedJustification ? (
            <p style={{ whiteSpace: 'pre-wrap', fontSize: '14px', color: '#333' }}>
              {inspectedJustification}
            </p>
          ) : (
            <p style={{ color: '#777', fontStyle: 'italic' }}>
              Select "Inspect Ontology" on any schedule row to view deterministic CSP constraint derivations and graph triples.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
