/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file compliance-proof-engine.ts
 * @description A self-contained TypeScript implementation of a deterministic 
 * neuro-symbolic proof trail generator for compliance auditing in SaaS applications.
 */

// 1. Define the core data structures for our symbolic facts and rules.
export interface TransactionContext {
    id: string;
    amountUSD: number;
    jurisdiction: string;
    isSanctionedCountry: boolean;
    hasValidKYC: boolean;
}

// Represents a single logical step in the automated proof trail.
export interface ProofStep {
    stepId: string;
    ruleName: string;
    premise: string;
    evaluatedValue: boolean;
    reasoning: string;
    timestamp: string;
}

// The complete serialized audit log ready for GraphDB ingestion or UI rendering.
export interface AuditProofTrail {
    transactionId: string;
    isApproved: boolean;
    totalSteps: number;
    steps: ProofStep[];
    generatedAt: string;
}

/**
 * Evaluates a transaction context against a deterministic rule base,
 * capturing an immutable proof trail for zero-hallucination explainability.
 * 
 * @param tx The transaction context to evaluate.
 * @returns An AuditProofTrail containing all executed reasoning steps.
 */
export function evaluateTransactionCompliance(tx: TransactionContext): AuditProofTrail {
    const steps: ProofStep[] = [];
    const timestamp = new Date().toISOString();

    // Step 1: Evaluate Sanction Status (Hard Stop)
    const sanctionCheckPassed = !tx.isSanctionedCountry;
    steps.push({
        stepId: "STEP-01",
        ruleName: "SanctionedJurisdictionRule",
        premise: `Jurisdiction '${tx.jurisdiction}' must not be on the active OFAC sanction list.`,
        evaluatedValue: sanctionCheckPassed,
        reasoning: sanctionCheckPassed 
            ? `Jurisdiction ${tx.jurisdiction} passed sanction screening.` 
            : `REJECTED: Jurisdiction ${tx.jurisdiction} is flagged as a sanctioned territory.`,
        timestamp: new Date().toISOString(),
    });

    // Short-circuit if hard stop fails
    if (!sanctionCheckPassed) {
        return {
            transactionId: tx.id,
            isApproved: false,
            totalSteps: steps.length,
            steps,
            generatedAt: timestamp,
        };
    }

    // Step 2: Evaluate KYC Verification
    const kycCheckPassed = tx.hasValidKYC === true;
    steps.push({
        stepId: "STEP-02",
        ruleName: "KYCComplianceRule",
        premise: "User executing transaction must possess a verified, unexpired KYC record.",
        evaluatedValue: kycCheckPassed,
        reasoning: kycCheckPassed
            ? "Valid KYC record found and cryptographically verified."
            : "REJECTED: Missing or expired KYC documentation for user entity.",
        timestamp: new Date().toISOString(),
    });

    if (!kycCheckPassed) {
        return {
            transactionId: tx.id,
            isApproved: false,
            totalSteps: steps.length,
            steps,
            generatedAt: timestamp,
        };
    }

    // Step 3: Evaluate High-Value Threshold Rule
    const HIGH_VALUE_THRESHOLD = 10000;
    const isHighValue = tx.amountUSD > HIGH_VALUE_THRESHOLD;
    let thresholdCheckPassed = true;
    let thresholdReasoning = `Transaction amount $${tx.amountUSD} is below the $${HIGH_VALUE_THRESHOLD} manual review threshold.`;

    if (isHighValue) {
        // In a real neuro-symbolic engine, this might invoke an LLM sub-symbolic check 
        // which is then constrained and verified by a deterministic fallback.
        thresholdCheckPassed = true; // Assume high-value cleared secondary review for this example
        thresholdReasoning = `Transaction amount $${tx.amountUSD} exceeded $${HIGH_VALUE_THRESHOLD}; secondary automated heuristic verified source of funds.`;
    }

    steps.push({
        stepId: "STEP-03",
        ruleName: "HighValueThresholdRule",
        premise: `Transactions exceeding $${HIGH_VALUE_THRESHOLD} require explicit heuristic validation.`,
        evaluatedValue: thresholdCheckPassed,
        reasoning: thresholdReasoning,
        timestamp: new Date().toISOString(),
    });

    const overallApproval = sanctionCheckPassed && kycCheckPassed && thresholdCheckPassed;

    return {
        transactionId: tx.id,
        isApproved: overallApproval,
        totalSteps: steps.length,
        steps,
        generatedAt: timestamp,
    };
}

// --- Execution Example ---
const sampleTransaction: TransactionContext = {
    id: "TX-998234",
    amountUSD: 15400,
    jurisdiction: "DE", // Germany
    isSanctionedCountry: false,
    hasValidKYC: true,
};

const auditTrail = evaluateTransactionCompliance(sampleTransaction);
console.log(JSON.stringify(auditTrail, null, 2));
