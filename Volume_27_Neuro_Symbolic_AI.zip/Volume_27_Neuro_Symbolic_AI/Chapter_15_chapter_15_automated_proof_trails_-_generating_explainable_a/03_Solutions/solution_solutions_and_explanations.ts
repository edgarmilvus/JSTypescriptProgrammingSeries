/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export type SolverOutcome = 'PROPAGATED' | 'BRANCHED' | 'SATISFIED' | 'CONTRADICTION';

export interface SolverStateNode {
  stepId: string;
  domains: Map<string, Set<number | string | boolean>>;
  activeConstraintId: string;
  outcome: SolverOutcome;
  parentId: string | null;
}

export class AuditedConstraintSolver {
  private trail: SolverStateNode[] = [];
  private onStateTransitionCallback?: (node: SolverStateNode) => void;

  constructor(onStateTransition?: (node: SolverStateNode) => void) {
    this.onStateTransitionCallback = onStateTransition;
  }

  public recordStep(
    stepId: string,
    domains: Map<string, Set<number | string | boolean>>,
    activeConstraintId: string,
    outcome: SolverOutcome,
    parentId: string | null
  ): SolverStateNode {
    // Deep clone domains to guarantee immutability of historical states
    const clonedDomains = new Map<string, Set<number | string | boolean>>();
    for (const [key, set] of domains.entries()) {
      clonedDomains.set(key, new Set(set));
    }

    const node: SolverStateNode = {
      stepId,
      domains: clonedDomains,
      activeConstraintId,
      outcome,
      parentId,
    };

    this.trail.push(node);
    if (this.onStateTransitionCallback) {
      this.onStateTransitionCallback(node);
    }
    return node;
  }

  public getTrail(): SolverStateNode[] {
    return this.trail;
  }
}

export function serializeProofTrail(nodes: SolverStateNode[]): string {
  const serializable = nodes.map(node => {
    // Convert Maps to sorted arrays of [key, sortedValues] for determinism
    const sortedDomainsRecord: Record<string, any[]> = {};
    const sortedKeys = Array.from(node.domains.keys()).sort();
    
    for (const key of sortedKeys) {
      const values = Array.from(node.domains.get(key)!).sort((a, b) => {
        if (typeof a === 'boolean' || typeof b === 'boolean') {
          return String(a).localeCompare(String(b));
        }
        return a > b ? 1 : a < b ? -1 : 0;
      });
      sortedDomainsRecord[key] = values;
    }

    return {
      stepId: node.stepId,
      domains: sortedDomainsRecord,
      activeConstraintId: node.activeConstraintId,
      outcome: node.outcome,
      parentId: node.parentId,
    };
  });

  return JSON.stringify(serializable, null, 2);
}

export function verifyProofTrailIntegrity(serializedTrail: string): boolean {
  try {
    const parsed: Array<{ stepId: string; parentId: string | null }> = JSON.parse(serializedTrail);
    const stepIds = new Set<string>();

    // First pass: collect all valid IDs
    for (const node of parsed) {
      if (stepIds.has(node.stepId)) return false; // Duplicate step IDs violate DAG integrity
      stepIds.add(node.stepId);
    }

    // Second pass: verify parent references
    for (const node of parsed) {
      if (node.parentId !== null && !stepIds.has(node.parentId)) {
        return false; // Broken link to non-existent parent
      }
    }

    return true;
  } catch {
    return false;
  }
}
