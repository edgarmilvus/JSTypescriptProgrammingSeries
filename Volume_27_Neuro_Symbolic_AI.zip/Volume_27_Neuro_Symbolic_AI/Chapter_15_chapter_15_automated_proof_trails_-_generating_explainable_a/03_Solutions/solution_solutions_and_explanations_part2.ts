/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { SolverStateNode, serializeProofTrail } from './exercise-1';

export interface GraphTriple {
  subject: string;
  predicate: string;
  object: string;
  graphUri: string;
}

export interface OntologicalSchema {
  classes: string[];
  properties: string[];
}

export class OntologicalProofMapper {
  private schema: OntologicalSchema;
  private baseUri: string;

  constructor(schema: OntologicalSchema, baseUri: string = 'http://example.org/audit/') {
    this.schema = schema;
    this.baseUri = baseUri;
  }

  public mapTrailToTriples(nodes: SolverStateNode[]): GraphTriple[] {
    const triples: GraphTriple[] = [];
    const graphUri = `${this.baseUri}graph/proof-trail`;

    for (const node of nodes) {
      const stepSubject = `${this.baseUri}step/${node.stepId}`;

      // 1. Map step outcome type
      triples.push({
        subject: stepSubject,
        predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
        object: `${this.baseUri}class/SolverStep`,
        graphUri,
      });

      triples.push({
        subject: stepSubject,
        predicate: `${this.baseUri}prop/hasOutcome`,
        object: `${this.baseUri}outcome/${node.outcome}`,
        graphUri,
      });

      triples.push({
        subject: stepSubject,
        predicate: `${this.baseUri}prop/evaluatesConstraint`,
        object: `${this.baseUri}constraint/${node.activeConstraintId}`,
        graphUri,
      });

      // 2. Map causal lineage (parentId -> derivedFromStep)
      if (node.parentId) {
        triples.push({
          subject: stepSubject,
          predicate: `${this.baseUri}prop/derivedFromStep`,
          object: `${this.baseUri}step/${node.parentId}`,
          graphUri,
        });
      }

      // 3. Map variable domain states
      for (const [variable, domainValues] of node.domains.entries()) {
        const varSubject = `${this.baseUri}variable/${variable}`;
        triples.push({
          subject: stepSubject,
          predicate: `${this.baseUri}prop/modifiesVariable`,
          object: varSubject,
          graphUri,
        });

        for (const val of domainValues) {
          triples.push({
            subject: varSubject,
            predicate: `${this.baseUri}prop.hasDomainValue`,
            object: String(val),
            graphUri,
          });
        }
      }
    }

    return triples;
  }
}

export class MemoryGraphStore {
  private triples: GraphTriple[] = [];

  public insertTriples(newTriples: GraphTriple[]): void {
    this.triples.push(...newTriples);
  }

  public queryProofPath(targetStepId: string, baseUri: string = 'http://example.org/audit/'): GraphTriple[] {
    const matchedTriples: GraphTriple[] = [];
    const visitedSteps = new Set<string>();
    const queue: string[] = [targetStepId];

    while (queue.length > 0) {
      const currentStepId = queue.shift()!;
      if (visitedSteps.has(currentStepId)) continue;
      visitedSteps.add(currentStepId);

      const stepSubject = `${baseUri}step/${currentStepId}`;

      // Find all triples associated with this specific step
      const stepTriples = this.triples.filter(t => t.subject === stepSubject);
      matchedTriples.push(...stepTriples);

      // Find parent links to traverse backward
      const parentLinks = this.triples.filter(
        t => t.subject === stepSubject && t.predicate === `${baseUri}prop/derivedFromStep`
      );

      for (const link of parentLinks) {
        // Extract parent stepId from URI (e.g., ".../step/step-1" -> "step-1")
        const parentStepId = link.object.split('/').pop();
        if (parentStepId && !visitedSteps.has(parentStepId)) {
          queue.push(parentStepId);
        }
      }
    }

    return matchedTriples;
  }
}
