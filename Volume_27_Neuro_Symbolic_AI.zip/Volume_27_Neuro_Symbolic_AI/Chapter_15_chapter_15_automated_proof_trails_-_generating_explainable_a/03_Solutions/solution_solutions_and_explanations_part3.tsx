/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { SolverStateNode } from './exercise-1';
import { GraphTriple } from './exercise-2';

export interface ProofTrailExplorerProps {
  rootStepId: string;
  fetchChildSteps: (stepId: string) => Promise<SolverStateNode[]>;
  fetchTriplesForStep: (stepId: string) => Promise<GraphTriple[]>;
}

export const ProofTrailExplorer: React.FC<ProofTrailExplorerProps> = ({
  rootStepId,
  fetchChildSteps,
  fetchTriplesForStep,
}) => {
  const [nodes, setNodes] = useState<Map<string, SolverStateNode>>(new Map());
  const [childrenMap, setChildrenMap] = useState<Map<string, string[]>>(new Map());
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set([rootStepId]));
  const [selectedId, setSelectedId] = useState<string | null>(rootStepId);
  const [stepTriples, setStepTriples] = useState<GraphTriple[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);

  // Load root node on mount
  useEffect(() => {
    loadChildren(rootStepId);
  }, [rootStepId]);

  // Load triples when selectedId changes
  useEffect(() => {
    if (selectedId) {
      fetchTriplesForStep(selectedId).then(setStepTriples);
    } else {
      setStepTriples([]);
    }
  }, [selectedId, fetchTriplesForStep]);

  const loadChildren = async (stepId: string) => {
    setLoading(true);
    try {
      const children = await fetchChildSteps(stepId);
      setNodes(prev => {
        const next = new Map(prev);
        for (const child of children) {
          next.set(child.stepId, child);
        }
        return next;
      });
      setChildrenMap(prev => {
        const next = new Map(prev);
        next.set(
          stepId,
          children.map(c => c.stepId)
        );
        return next;
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleExpand = async (stepId: string) => {
    const nextExpanded = new Set(expandedIds);
    if (nextExpanded.has(stepId)) {
      nextExpanded.delete(stepId);
    } else {
      nextExpanded.add(stepId);
      if (!childrenMap.has(stepId)) {
        await loadChildren(stepId);
      }
    }
    setExpandedIds(nextExpanded);
  };

  const handleKeyDown = (e: React.KeyboardEvent, stepId: string) => {
    if (e.key === 'ArrowRight') {
      if (!expandedIds.has(stepId)) {
        toggleExpand(stepId);
      }
    } else if (e.key === 'ArrowLeft') {
      if (expandedIds.has(stepId)) {
        toggleExpand(stepId);
      }
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedId(stepId);
    }
  };

  const renderNodeTree = (currentId: string, depth: number = 0) => {
    const node = nodes.get(currentId);
    if (!node) return null;

    const isExpanded = expandedIds.has(currentId);
    const isSelected = selectedId === currentId;
    const childIds = childrenMap.get(currentId) || [];
    const hasChildren = childIds.length > 0 || node.outcome !== 'SATISFIED';

    const badgeColor =
      node.outcome === 'SATISFIED'
        ? '#28a745'
        : node.outcome === 'CONTRADICTION'
        ? '#dc3545'
        : node.outcome === 'BRANCHED'
        ? '#ffc107'
        : '#17a2b8';

    return (
      <div key={currentId} style={{ marginLeft: `${depth * 20}px`, margin: '4px 0' }}>
        <div
          tabIndex={0}
          role="treeitem"
          aria-expanded={isExpanded}
          aria-selected={isSelected}
          onClick={() => setSelectedId(currentId)}
          onKeyDown={e => handleKeyDown(e, currentId)}
          style={{
            display: 'flex',
            alignItem: 'center',
            padding: '6px 10px',
            background: isSelected ? '#e2e8f0' : '#f8fafc',
            border: '1px solid #cbd5e1',
            borderRadius: '4px',
            cursor: 'pointer',
            outline: 'none',
          }}
        >
          {hasChildren && (
            <button
              onClick={e => {
                e.stopPropagation();
                toggleExpand(currentId);
              }}
              style={{ marginRight: '8px', background: 'none', border: 'none', cursor: 'pointer' }}
            >
              {isExpanded ? '▼' : '▶'}
            </button>
          )}
          <span style={{ fontWeight: 'bold', marginRight: '10px' }}>{node.stepId}</span>
          <span
            style={{
              padding: '2px 6px',
              borderRadius: '12px',
              fontSize: '11px',
              color: '#fff',
              backgroundColor: badgeColor,
            }}
          >
            {node.outcome}
          </span>
          <span style={{ marginLeft: '12px', fontSize: '12px', color: '#64748b' }}>
            Constraint: {node.activeConstraintId}
          </span>
        </div>

        {isExpanded && childIds.map(childId => renderNodeTree(childId, depth + 1))}
      </div>
    );
  };

  return (
    <div ref={containerRef} style={{ display: 'flex', gap: '20px', fontFamily: 'sans-serif' }}>
      <div style={{ flex: 1, borderRight: '1px solid #cbd5e1', paddingRight: '15px' }}>
        <h3>Proof Trail Decision Tree</h3>
        {renderNodeTree(rootStepId)}
        {loading && <div style={{ fontSize: '12px', color: '#64748b' }}>Loading child steps...</div>}
      </div>

      <div style={{ flex: 1, paddingLeft: '15px' }}>
        <h3>Semantic Triples Inspection</h3>
        {selectedId ? (
          <div>
            <h4>Step: {selectedId}</h4>
            <ul style={{ listStyleType: 'none', padding: 0 }}>
              {stepTriples.map((t, idx) => (
                <li key={idx} style={{ fontSize: '12px', marginBottom: '6px', background: '#f1f5f9', padding: '6px', borderRadius: '4px' }}>
                  <strong>S:</strong> {t.subject} <br />
                  <strong>P:</strong> {t.predicate} <br />
                  <strong>O:</strong> {t.object}
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <p style={{ color: '#64748b' }}>Select a node to inspect ontological triples.</p>
        )}
      </div>
    </div>
  );
};
