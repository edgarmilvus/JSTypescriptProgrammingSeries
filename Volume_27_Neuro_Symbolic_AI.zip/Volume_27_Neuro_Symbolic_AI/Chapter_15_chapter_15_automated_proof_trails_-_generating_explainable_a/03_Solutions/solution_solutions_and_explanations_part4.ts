/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { AuditedConstraintSolver, SolverStateNode } from './exercise-1';

export type ReActPhase = 'THOUGHT' | 'ACTION' | 'OBSERVATION' | 'VALIDATION';

export interface ReActStep {
  phase: ReActPhase;
  content: string;
  toolName?: string;
  toolInput?: Record<string, unknown>;
  isValidated: boolean;
  solverStepId?: string;
}

export class DeterministicReActAgent {
  private solver: AuditedConstraintSolver;
  private stepCounter: number = 0;

  constructor(solver: AuditedConstraintSolver) {
    this.solver = solver;
  }

  private mockLlmReason(goal: string, context: string): Promise<{ thought: string; toolName?: string; toolInput?: Record<string, unknown> }> {
    return new Promise(resolve => {
      setTimeout(() => {
        if (context.includes('UNAUTHORIZED')) {
          resolve({
            thought: 'Attempting to invoke unauthorized administrative tool to bypass resource limits.',
            toolName: 'admin_override_tool',
            toolInput: { level: 9 },
          });
        } else {
          resolve({
            thought: `Analyzing goal '${goal}'. Allocating standard compute resource safely.`,
            toolName: 'allocate_resource',
            toolInput: { resourceId: 'res-A', capacity: 50 },
          });
        }
      }, 50);
    });
  }

  public async *run(goal: string, forceUnauthorized: boolean = false): AsyncGenerator<ReActStep, void, unknown> {
    let currentContext = forceUnauthorized ? 'UNAUTHORIZED' : 'STANDARD';
    let parentStepId: string | null = null;

    for (let iteration = 0; iteration < 2; iteration++) {
      // 1. THOUGHT PHASE
      const llmOutput = await this.mockLlmReason(goal, currentContext);
      yield {
        phase: 'THOUGHT',
        content: llmOutput.thought,
        toolName: llmOutput.toolName,
        toolInput: llmOutput.toolInput,
        isValidated: true,
      };

      if (!llmOutput.toolName) break;

      // 2. VALIDATION PHASE (Deterministic Constraint Solver Check)
      const solverStepId = `step-${++this.stepCounter}`;
      const domains = new Map<string, Set<number | string | boolean>>();
      domains.set('toolName', new Set([llmOutput.toolName]));
      
      const isUnauthorized = llmOutput.toolName === 'admin_override_tool';
      const outcome = isUnauthorized ? 'CONTRADICTION' : 'PROPAGATED';

      const solverNode = this.solver.recordStep(
        solverStepId,
        domains,
        'Constraint_SecurityPolicy_v1',
        outcome,
        parentStepId
      );
      parentStepId = solverStepId;

      yield {
        phase: 'VALIDATION',
        content: isUnauthorized 
          ? 'Solver rejected action: Security policy violation detected.' 
          : 'Solver validated action successfully.',
        toolName: llmOutput.toolName,
        toolInput: llmOutput.toolInput,
        isValidated: !isUnauthorized,
        solverStepId,
      };

      if (isUnauthorized) {
        // Backtracking corrective thought phase
        currentContext = 'STANDARD';
        parentStepId = solverStepId;
        
        yield {
          phase: 'THOUGHT',
          content: 'Backtracking due to constraint contradiction. Selecting fallback compliant action.',
          toolName: 'safe_allocate_resource',
          toolInput: { resourceId: 'res-B', capacity: 10 },
          isValidated: true,
        };
        
        const fallbackSolverId = `step-${++this.stepCounter}`;
        const fallbackDomains = new Map<string, Set<number | string | boolean>>();
        fallbackDomains.set('toolName', new Set(['safe_allocate_resource']));
        
        const fallbackNode = this.solver.recordStep(
          fallbackSolverId,
          fallbackDomains,
          'Constraint_SecurityPolicy_v1',
          'SATISFIED',
          parentStepId
        );

        yield {
          phase: 'VALIDATION',
          content: 'Fallback action validated and satisfied.',
          toolName: 'safe_allocate_resource',
          toolInput: { resourceId: 'res-B', capacity: 10 },
          isValidated: true,
          solverStepId: fallbackSolverId,
        };
        break;
      }

      // 3. ACTION & OBSERVATION PHASE
      yield {
        phase: 'ACTION',
        content: `Executing tool ${llmOutput.toolName}`,
        toolName: llmOutput.toolName,
        toolInput: llmOutput.toolInput,
        isValidated: true,
      };

      yield {
        phase: 'OBSERVATION',
        content: `Tool ${llmOutput.toolName} executed successfully with output OK.`,
        isValidated: true,
      };
    }
  }
}
