/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Enterprise SaaS Zero-Hallucination Graph-Guided RAG Pipeline
 * @description Demonstrates deterministic Knowledge Graph querying, immutable state management,
 * and schema-constrained generation to eliminate LLM hallucinations in TypeScript.
 */

import { EventEmitter } from 'events';

// ============================================================================
// 1. DOMAIN ONTOLOGY & UTILITY TYPES
// ============================================================================

/** Represents an authenticated enterprise tenant context. */
export interface TenantContext {
  readonly tenantId: string;
  readonly securityClearanceLevel: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
}

/** Represents a node inside the deterministic enterprise Knowledge Graph. */
export interface GraphNode {
  readonly id: string;
  readonly label: string;
  readonly properties: Record<string, unknown>;
}

/** Represents a directed edge within the Knowledge Graph. */
export interface GraphEdge {
  readonly sourceId: string;
  readonly targetId: string;
  readonly relationType: 'ALLOWS_ACCESS_TO' | 'DEPENDS_ON' | 'OWNS_DATA';
}

/** 
 * Utility Type: Immutable Snapshot 
 * Ensures that retrieved context graphs cannot be mutated mid-pipeline,
 * protecting state integrity across asynchronous execution boundaries.
 */
type ImmutableGraphContext = Readonly<{
  nodes: ReadonlyArray<GraphNode>;
  edges: ReadonlyArray<GraphEdge>;
}>;

/** 
 * Utility Type: Partial Configuration 
 * Allows callers to override default solver parameters safely.
 */
type SolverConfigOverrides = Partial<{
  maxDepth: number;
  temperature: number;
  strictMode: boolean;
}>;

// ============================================================================
// 2. DETERMINISTIC GRAPH DB SOLVER
// ============================================================================

/**
 * Mock Graph Database simulating deterministic ontology traversals.
 */
class EnterpriseGraphDatabase {
  private nodes: Map<string, GraphNode> = new Map();
  private edges: GraphEdge[] = [];

  constructor() {
    // Seed initial deterministic enterprise data
    this.nodes.set("node_user_1", { id: "node_user_1", label: "User", properties: { role: "Engineering Lead" } });
    this.nodes.set("node_resource_a", { id: "node_resource_a", label: "Service", properties: { name: "Billing-API", clearance: "CONFIDENTIAL" } });
    
    this.edges.push({
      sourceId: "node_user_1",
      targetId: "node_resource_a",
      relationType: "ALLOWS_ACCESS_TO"
    });
  }

  /**
   * Executes a deterministic graph traversal based on a starting entity and relation.
   */
  public async traverse(startId: string, relation: string): Promise<ImmutableGraphContext> {
    const matchedNodes: GraphNode[] = [];
    const matchedEdges: GraphEdge[] = [];

    const startNode = this.nodes.get(startId);
    if (!startNode) {
      return { nodes: [], edges: [] };
    }

    matchedNodes.push(startNode);

    for (const edge of this.edges) {
      if (edge.sourceId === startId && edge.relationType === relation) {
        const targetNode = this.nodes.get(edge.targetId);
        if (targetNode) {
          matchedEdges.push(edge);
          matchedNodes.push(targetNode);
        }
      }
    }

    // Return frozen, immutable snapshot
    return Object.freeze({
      nodes: Object.freeze(matchedNodes),
      edges: Object.freeze(matchedEdges)
    });
  }
}

// ============================================================================
// 3. GRAPH-GUIDED RAG PIPELINE & SOLVER
// ============================================================================

/**
 * Orchestrates zero-hallucination generation by fusing deterministic graph traversals
 * with downstream text generation constraints.
 */
export class GraphGuidedRAGPipeline extends EventEmitter {
  private graphDb: EnterpriseGraphDatabase;

  constructor() {
    super();
    this.graphDb = new EnterpriseGraphDatabase();
  }

  /**
   * Resolves a user query against the deterministic Knowledge Graph, creating an immutable
   * context payload that prevents external hallucination injections.
   */
  public async executePipeline(
    tenant: TenantContext,
    startEntityId: string,
    query: string,
    configOverrides?: SolverConfigOverrides
  ): Promise<string> {
    // 1. Establish default solver configuration using utility type manipulation
    const config = {
      maxDepth: 2,
      temperature: 0.0, // Zero temperature for deterministic outputs
      strictMode: true,
      ...configOverrides
    };

    this.emit('log', `[RAG] Starting deterministic traversal for tenant: ${tenant.tenantId}`);

    // 2. Perform Graph traversal instead of vector embedding similarity search
    const graphContext: ImmutableGraphContext = await this.graphDb.traverse(
      startEntityId, 
      "ALLOWS_ACCESS_TO"
    );

    // 3. Validate security boundaries against the graph context
    this.validateGraphSecurity(tenant, graphContext);

    // 4. Synthesize deterministic response based strictly on verified graph nodes
    const response = this.generateDeterministicResponse(query, graphContext, config.strictMode);

    this.emit('log', `[RAG] Pipeline execution complete with zero hallucinations.`);
    return response;
  }

  /**
   * Validates that every node retrieved complies with the tenant's security clearance.
   */
  private validateGraphSecurity(tenant: TenantContext, context: ImmutableGraphContext): void {
    for (const node of context.nodes) {
      const nodeClearance = node.properties["clearance"];
      if (nodeClearance === "RESTRICTED" && tenant.securityClearanceLevel !== "RESTRICTED") {
        throw new Error(`Security Violation: Tenant ${tenant.tenantId} attempted to access restricted node ${node.id}`);
      }
    }
  }

  /**
   * Generates a deterministic output string by formatting graph properties directly,
   * bypassing unconstrained generative LLM calls.
   */
  private generateDeterministicResponse(query: string, context: ImmutableGraphContext, strictMode: boolean): string {
    if (context.nodes.length <= 1 && strictMode) {
      return "No verified deterministic path found in the Knowledge Graph to answer this query.";
    }

    const primaryNode = context.nodes[0];
    const targetNode = context.nodes[1];

    return `Verified Enterprise Audit: Based on deterministic graph path traversal, entity '${primaryNode.label}' (${primaryNode.id}) has a verified relationship '${context.edges[0]?.relationType}' pointing to target service '${targetNode.properties["name"]}' with clearance '${targetNode.properties["clearance']}'.`;
  }
}

// ============================================================================
// 4. EXECUTION DEMONSTRATION
// ============================================================================

async function runDemo() {
  const pipeline = new GraphGuidedRAGPipeline();
  
  pipeline.on('log', (msg) => console.log(msg));

  const tenant: TenantContext = {
    tenantId: "tenant_alpha_99",
    securityClearanceLevel: "CONFIDENTIAL"
  };

  try {
    const result = await pipeline.executePipeline(
      tenant,
      "node_user_1",
      "What billing services does user_1 have access to?",
      { strictMode: true }
    );

    console.log("\n--- FINAL PIPELINE OUTPUT ---");
    console.log(result);
  } catch (error: unknown) {
    if (error instanceof Error) {
      console.error("Pipeline Failed:", error.message);
    }
  }
}

// Execute if run directly
runDemo();
