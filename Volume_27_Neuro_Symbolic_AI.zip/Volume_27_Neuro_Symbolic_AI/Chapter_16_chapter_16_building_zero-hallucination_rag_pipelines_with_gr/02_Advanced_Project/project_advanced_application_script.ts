/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file compliance-rag-pipeline.ts
 * @description Enterprise zero-hallucination RAG pipeline using TypeScript, 
 * Graph-guided retrieval, and deterministic validation solvers.
 */

import { Neo4j, Driver, Session } from 'neo4j-driver'; // Simulated GraphDB Driver
import { OpenAI } from 'openai'; // Simulated LLM Client

// ============================================================================
// 1. TYPE DEFINITIONS & ONTOLOGY SCHEMAS
// ============================================================================

/** Represents an entity node within the compliance Knowledge Graph */
export type GraphNodeId = string;

export interface RegulatoryEntity {
  id: GraphNodeId;
  label: 'Standard' | 'Clause' | 'Device' | 'Risk';
  properties: {
    name: string;
    description: string;
    version?: string;
    criticality?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  };
}

/** Represents a directed relationship edge constrained by the ontology */
export interface RegulatoryRelationship {
  source: GraphNodeId;
  target: GraphNodeId;
  type: 'GOVERNS' | 'MITIGATES' | 'REQUIRES_TESTING' | 'VIOLATES';
}

/** The validated subgraph extracted via graph traversal */
export interface ValidatedSubgraph {
  nodes: Map<GraphNodeId, RegulatoryEntity>;
  relationships: RegulatoryRelationship[];
  traversalTrace: string[];
}

/** The immutable state object for our LangGraph-style workflow */
export interface PipelineState {
  rawQuery: string;
  extractedEntities: string[];
  subgraph: ValidatedSubgraph | null;
  generatedDraft: string | null;
  validationResult: {
    isDeterministic: boolean;
    hallucinationDetected: boolean;
    violations: string[];
  } | null;
  finalOutput: string | null;
}

// ============================================================================
// 2. TYPE GUARDS & RUNTIME TYPE NARROWING
// ============================================================================

/**
 * Runtime Type Guard to ensure an unknown object conforms to the RegulatoryEntity interface.
 * Implements Type Narrowing to safely access property fields down the pipeline.
 */
export function isRegulatoryEntity(node: unknown): node is RegulatoryEntity {
  if (typeof node !== 'object' || node === null) return false;
  const candidate = node as Record<string, unknown>;
  
  return (
    typeof candidate.id === 'string' &&
    (candidate.label === 'Standard' || candidate.label === 'Clause' || candidate.label === 'Device' || candidate.label === 'Risk') &&
    typeof candidate.properties === 'object' &&
    candidate.properties !== null &&
    typeof (candidate.properties as Record<string, unknown>).name === 'string'
  );
}

// ============================================================================
// 3. GRAPH-GUIDED RETRIEVAL ENGINE
// ============================================================================

export class GraphGuidedRetrievalEngine {
  private driver: Driver;

  constructor(uri: string, credentials: { user: string; pass: string }) {
    // In a real application, initialize the Neo4j or TypeDB driver here
    this.driver = {} as Driver; 
  }

  /**
   * Executes an asynchronous graph traversal to fetch an ontology-compliant subgraph.
   * Utilizes Node.js asynchronous processing patterns to remain non-blocking.
   */
  public async fetchConstrainedSubgraph(targetDevice: string, standardName: string): Promise<ValidatedSubgraph> {
    const session: Session = {} as Session; // Mock session allocation
    
    // Simulated Cypher query enforcing strict ontological traversal paths
    const cypherQuery = `
      MATCH (d:Device {name: $targetDevice})-[:REQUIRES_TESTING]->(r:Risk)
      MATCH (s:Standard {name: $standardName})-[:GOVERNS]->(c:Clause)
      MATCH (r)-[:MITIGATES]->(c)
      RETURN d, r, s, c
    `;

    // Asynchronous network I/O boundary simulation
    const queryResults = await this.executeCypherQuery(cypherQuery, { targetDevice, standardName });

    const nodes = new Map<GraphNodeId, RegulatoryEntity>();
    const relationships: RegulatoryRelationship[] = [];
    const traversalTrace: string[] = [];

    // Parse and validate nodes using type guards
    for (const record of queryResults) {
      if (isRegulatoryEntity(record.node)) {
        nodes.set(record.node.id, record.node);
        traversalTrace.push(`Visited node: ${record.node.id} [${record.node.label}]`);
      }
      if (record.rel) {
        relationships.push(record.rel);
      }
    }

    return { nodes, relationships, traversalTrace };
  }

  private async executeCypherQuery(query: string, params: Record<string, any>): Promise<any[]> {
    // Simulated asynchronous DB resolution delay
    await new Promise((resolve) => setTimeout(resolve, 50));
    return [
      {
        node: {
          id: 'dev-001',
          label: 'Device',
          properties: { name: 'InfusionPumpX', description: 'Class II Medical Device' }
        },
        rel: { source: 'dev-001', target: 'risk-001', type: 'REQUIRES_TESTING' }
      },
      {
        node: {
          id: 'risk-001',
          label: 'Risk',
          properties: { name: 'BatteryOverheat', description: 'Thermal runaway risk', criticality: 'HIGH' }
        }
      }
    ];
  }
}

// ============================================================================
// 4. DETERMINISTIC SOLVER & ZERO-HALLUCINATION GUARD
// ============================================================================

export class ZeroHallucinationSolver {
  /**
   * Compares the LLM's generated draft against the absolute ground-truth subgraph.
   * Strips out any entities or relationships not explicitly present in the Knowledge Graph.
   */
  public validateAndEnforce(draft: string, subgraph: ValidatedSubgraph): { isDeterministic: boolean; cleanedOutput: string; violations: string[] } {
    const violations: string[] = [];
    let isDeterministic = true;

    // Extract all valid entity names from the subgraph nodes
    const validEntityNames = Array.from(subgraph.nodes.values()).map(
      (node) => node.properties.name.toLowerCase()
    );

    // Naive heuristic text check for unauthorized entities/claims in the draft
    // In production, this utilizes token-level AST matching or strict embedding distance thresholds
    const sentences = draft.split('.');
    const validatedSentences = sentences.filter((sentence) => {
      const lowerSentence = sentence.toLowerCase();
      // Check if the sentence mentions at least one verified graph entity
      const referencesGraphEntity = validEntityNames.some((name) => lowerSentence.includes(name));
      
      if (!referencesGraphEntity && sentence.trim().length > 0) {
        violations.push(`Unverified claim detected: "${sentence.trim()}" lacks graph path backing.`);
        isDeterministic = false;
        return false; // Drop unverified hallucinated sentences
      }
      return true;
    });

    return {
      isDeterministic,
      cleanedOutput: validatedSentences.join('.') + (validatedSentences.length > 0 ? '.' : ''),
      violations,
    };
  }
}

// ============================================================================
// 5. ORCHESTRATION PIPELINE ENTRY POINT
// ============================================================================

/**
 * Main execution handler simulating a LangGraph state workflow entry point.
 */
export async function runCompliancePipeline(userQuery: string, targetDevice: string, standardName: string): Promise<PipelineState> {
  // Initialize initial state
  const state: PipelineState = {
    rawQuery: userQuery,
    extractedEntities: [targetDevice, standardName],
    subgraph: null,
    generatedDraft: null,
    validationResult: null,
    finalOutput: null,
  };

  // Step 1: Instantiate Retrieval Engine & Fetch Graph Context
  const retrievalEngine = new GraphGuidedRetrievalEngine('bolt://localhost:7687', { user: 'neo4j', pass: 'secret' });
  state.subgraph = await retrievalEngine.fetchConstrainedSubgraph(targetDevice, standardName);

  // Step 2: Format Subgraph into Strict Context Prompt for LLM
  const contextString = Array.from(state.subgraph.nodes.values())
    .map(n => `- [${n.label}] ${n.properties.name}: ${n.properties.description}`)
    .join('\n');

  // Step 3: Simulate LLM Generation (Bound by context prompt)
  // In reality, an OpenAI or local LLM call happens here using the constructed contextString
  state.generatedDraft = `The device ${targetDevice} is governed by rigorous risk frameworks. Specifically, it involves the risk of BatteryOverheat, which is classified as thermal runaway risk with HIGH criticality. All testing procedures must reference this graph-backed profile.`;

  // Step 4: Run Deterministic Solver Validation
  const solver = new ZeroHallucinationSolver();
  const validation = solver.validateAndEnforce(state.generatedDraft, state.subgraph);

  state.validationResult = {
    isDeterministic: validation.isDeterministic,
    hallucinationDetected: !validation.isDeterministic,
    violations: validation.violations,
  };

  state.finalOutput = validation.cleanedOutput;

  return state;
}
