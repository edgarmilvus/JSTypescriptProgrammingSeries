/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Logger } from 'winston'; // Assumed logger

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  properties: Record<string, any>;
}

export interface GraphEdge {
  source: string;
  target: string;
  relation: string;
  weight: number;
}

export interface SerializedGraphContext {
  markdown: string;
  nodeCount: number;
  edgeCount: number;
}

export interface ComplianceOntology {
  allowedNodeTypes: Set<string>;
  allowedRelations: Set<string>;
}

export interface GraphDBClient {
  getNeighbors(nodeId: string): Promise<{ nodes: GraphNode[]; edges: GraphEdge[] }>;
  getNode(nodeId: string): Promise<GraphNode | null>;
}

export class OntologyContextExpander {
  private client: GraphDBClient;
  private ontology: ComplianceOntology;
  private confidenceThreshold: number;

  constructor(client: GraphDBClient, ontology: ComplianceOntology, confidenceThreshold: number = 0.65) {
    this.client = client;
    this.ontology = ontology;
    this.confidenceThreshold = confidenceThreshold;
  }

  public async expandContext(seedEntities: string[], maxDepth: number): Promise<SerializedGraphContext> {
    const visitedNodes = new Map<string, { node: GraphNode; confidence: number }>();
    const collectedEdges: GraphEdge[] = [];
    const queue: { id: string; depth: number; currentConfidence: number }[] = seedEntities.map(id => ({
      id,
      depth: 0,
      currentConfidence: 1.0,
    }));

    while (queue.length > 0) {
      const { id, depth, currentConfidence } = queue.shift()!;

      if (visitedNodes.has(id)) {
        continue;
      }

      const node = await this.client.getNode(id);
      if (!node || !this.ontology.allowedNodeTypes.has(node.type)) {
        continue;
      }

      if (currentConfidence < this.confidenceThreshold) {
        continue;
      }

      visitedNodes.set(id, { node, confidence: currentConfidence });

      if (depth >= maxDepth) {
        continue;
      }

      const { nodes: neighborNodes, edges: neighborEdges } = await this.client.getNeighbors(id);

      for (const edge of neighborEdges) {
        if (!this.ontology.allowedRelations.has(edge.relation)) {
          continue;
        }

        const nextId = edge.source === id ? edge.target : edge.source;
        if (!visitedNodes.has(nextId)) {
          const edgeDecay = edge.weight ?? 0.9;
          const nextConfidence = currentConfidence * edgeDecay;

          if (nextConfidence >= this.confidenceThreshold) {
            collectedEdges.push(edge);
            queue.push({
              id: nextId,
              depth: depth + 1,
              currentConfidence: nextConfidence,
            });
          }
        }
      }
    }

    return this.serializeSubgraph(Array.from(visitedNodes.values()).map(v => v.node), collectedEdges);
  }

  private serializeSubgraph(nodes: GraphNode[], edges: GraphEdge[]): SerializedGraphContext {
    const groupedByType = new Map<string, GraphNode[]>();
    for (const node of nodes) {
      const group = groupedByType.get(node.type) || [];
      group.push(node);
      groupedByType.set(node.type, group);
    }

    let markdown = "### Expanded Ontology Context\n\n";

    for (const [type, typeNodes] of groupedByType.entries()) {
      markdown += `#### Entity Type: ${type}\n`;
      for (const node of typeNodes) {
        markdown += `- **ID:** ${node.id} | **Label:** ${node.label}\n`;
        markdown += `  - Properties: ${JSON.stringify(node.properties)}\n`;
      }
      markdown += "\n";
    }

    markdown += "#### Verified Relationships\n";
    for (const edge of edges) {
      markdown += `- ${edge.source} --(${edge.relation})--> ${edge.target}\n`;
    }

    return {
      markdown,
      nodeCount: nodes.length,
      edgeCount: edges.length,
    };
  }
}
