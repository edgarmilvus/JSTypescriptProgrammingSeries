/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { Levenshtein } from 'fast-levenshtein';

export type SolverResult<T> = 
  | { success: true; data: T; corrections: string[] }
  | { success: false; errors: { path: string; message: string }[] };

export interface KnowledgeGraphValidator {
  entityExists(entityId: string): Promise<boolean>;
  getValidEntities(): Promise<string[]>;
}

export class DeterministicSolver {
  private kgValidator: KnowledgeGraphValidator;
  private maxRetries: number;

  constructor(kgValidator: KnowledgeGraphValidator, maxRetries: number = 3) {
    this.kgValidator = kgValidator;
    this.maxRetries = maxRetries;
  }

  public async resolve<T>(
    rawModelOutput: string, 
    expectedSchema: z.ZodType<T>, 
    llmCallExecutor?: (prompt: string) => Promise<string>
  ): Promise<SolverResult<T>> {
    let attempts = 0;
    let currentOutput = rawModelOutput;
    const corrections: string[] = [];

    while (attempts <= this.maxRetries) {
      try {
        let parsedJson: any;
        try {
          parsedJson = JSON.parse(currentOutput);
        } catch (e) {
          throw new Error(`Invalid JSON format: ${(e as Error).message}`);
        }

        const validationResult = expectedSchema.safeParse(parsedJson);
        if (!validationResult.success) {
          const errors = validationResult.error.errors.map(err => ({
            path: err.path.join('.'),
            message: err.message
          }));
          
          if (attempts >= this.maxRetries || !llmCallExecutor) {
            return { success: false, errors };
          }

          currentOutput = await this.requestSelfCorrection(currentOutput, errors, llmCallExecutor);
          attempts++;
          continue;
        }

        const data = validationResult.data;
        const entityValidationErrors = await this.validateAndCorrectEntities(data, corrections);

        if (entityValidationErrors.length > 0) {
          if (attempts >= this.maxRetries || !llmCallExecutor) {
            return { success: false, errors: entityValidationErrors };
          }
          currentOutput = await this.requestSelfCorrection(currentOutput, entityValidationErrors, llmCallExecutor);
          attempts++;
          continue;
        }

        return { success: true, data, corrections };
      } catch (err) {
        if (attempts >= this.maxRetries || !llmCallExecutor) {
          return { success: false, errors: [{ path: 'root', message: (err as Error).message }] };
        }
        currentOutput = await this.requestSelfCorrection(currentOutput, [{ path: 'root', message: (err as Error).message }], llmCallExecutor);
        attempts++;
      }
    }

    return { success: false, errors: [{ path: 'root', message: 'Exceeded maximum correction attempts.' }] };
  }

  private async validateAndCorrectEntities(data: any, corrections: string[]): Promise<{ path: string; message: string }[]> {
    const errors: { path: string; message: string }[] = [];
    const validEntities = await this.kgValidator.getValidEntities();

    // Deep object traversal to locate entity identifiers matching target patterns
    const inspectAndFix = async (obj: any, path: string) => {
      if (!obj || typeof obj !== 'object') return;

      for (const key of Object.keys(obj)) {
        const currentPath = `${path}.${key}`;
        if (key === 'entityId' || key.endsWith('Id')) {
          const val = obj[key];
          if (typeof val === 'string') {
            const exists = await this.kgValidator.entityExists(val);
            if (!exists) {
              const match = this.findClosestEntity(val, validEntities);
              if (match && match.distance <= 2) {
                corrections.push(`Auto-corrected entity ID '${val}' to '${match.entity}' at path ${currentPath}`);
                obj[key] = match.entity;
              } else {
                errors.push({ path: currentPath, message: `Entity ID '${val}' does not exist in Knowledge Graph and no fuzzy match $\le 2$ was found.` });
              }
            }
          }
        } else {
          await inspectAndFix(obj[key], currentPath);
        }
      }
    };

    await inspectAndFix(data, 'root');
    return errors;
  }

  private findClosestEntity(target: string, candidates: string[]): { entity: string; distance: number } | null {
    let closest: string | null = null;
    let minDistance = Infinity;

    for (const candidate of candidates) {
      const dist = Levenshtein.get(target, candidate);
      if (dist < minDistance) {
        minDistance = dist;
        closest = candidate;
      }
    }

    return closest ? { entity: closest, distance: minDistance } : null;
  }

  private async requestSelfCorrection(failedOutput: string, errors: { path: string; message: string }[], executor: (p: string) => Promise<string>): Promise<string> {
    const prompt = `Your previous output failed validation. Please fix the following errors:\n${JSON.stringify(errors, null, 2)}\n\nPrevious Output:\n${failedOutput}`;
    return await executor(prompt);
  }
}
