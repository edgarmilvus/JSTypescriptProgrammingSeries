/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

export interface SerializedGraphContext {
  markdown: string;
  nodeCount: number;
  edgeCount: number;
}

export interface GraphNodeDetail {
  id: string;
  label: string;
  type: string;
  distanceFromSeed: number;
  properties: Record<string, any>;
}

export interface GraphRAGInspectorProps {
  query: string;
  seedEntities: string[];
  subgraph: SerializedGraphContext;
  nodeDetails: GraphNodeDetail[];
  validationErrors: string[];
  corrections: string[];
  finalPrompt: string;
  isLoading: boolean;
}

export const GraphRAGInspector: React.FC<GraphRAGInspectorProps> = ({
  query,
  seedEntities,
  subgraph,
  nodeDetails,
  validationErrors,
  corrections,
  finalPrompt,
  isLoading
}) => {
  const [activeTab, setActiveTab] = useState<'query' | 'traversal' | 'validation' | 'prompt'>('query');
  const [selectedNode, setSelectedNode] = useState<GraphNodeDetail | null>(null);

  const memoizedNodes = useMemo(() => nodeDetails, [nodeDetails]);

  return (
    <div className="w-full max-w-5xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wide flex items-center gap-2">
          <span>🛡️ Graph-Guided RAG Pipeline Inspector</span>
        </h2>
        {isLoading && <span className="text-xs bg-amber-500/20 text-amber-300 px-3 py-1 rounded-full animate-pulse">Running Traversal...</span>}
      </div>

      {/* Warning Banners */}
      {corrections.length > 0 && (
        <div className="bg-amber-950/40 border-l-4 border-amber-500 p-4 mx-6 mt-4 text-amber-200 text-sm rounded-r">
          <p className="font-semibold">Deterministic Solver Auto-Corrections Applied:</p>
          <ul className="list-disc ml-5 mt-1">
            {corrections.map((c, idx) => <li key={idx}>{c}</li>)}
          </ul>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-950 px-6 pt-2">
        {(['query', 'traversal', 'validation', 'prompt'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-3 font-medium text-sm transition-colors border-b-2 capitalize ${
              activeTab === tab ? 'border-indigo-500 text-indigo-400 bg-slate-900/50' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.replace('-', ' ')}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="p-6 min-h-[400px]">
        {activeTab === 'query' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-400 uppercase">User Query</h3>
              <p className="mt-1 p-3 bg-slate-800/60 rounded border border-slate-700 text-slate-200">{query}</p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-400 uppercase">Extracted Seed Entities</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                {seedEntities.map(entity => (
                  <span key={entity} className="px-3 py-1 bg-indigo-900/50 border border-indigo-700/50 rounded-full text-indigo-300 text-xs font-medium">
                    {entity}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'traversal' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
              <span>Total Nodes: {subgraph.nodeCount} | Total Edges: {subgraph.edgeCount}</span>
              <span>Click node to inspect properties</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[350px] overflow-y-auto pr-2">
              {memoizedNodes.map(node => (
                <div 
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className="p-3 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded cursor-pointer transition-all hover:border-indigo-500"
                >
                  <div className="flex justify-between items-start">
                    <span className="font-semibold text-indigo-300">{node.label}</span>
                    <span className="text-[10px] bg-slate-700 px-2 py-0.5 rounded text-slate-300">{node.type}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">ID: {node.id} | Distance: {node.distanceFromSeed}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'validation' && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-400 uppercase">Solver Status</h3>
            {validationErrors.length === 0 ? (
              <div className="p-4 bg-emerald-950/30 border border-emerald-800/50 rounded text-emerald-400 text-sm">
                ✅ All structural constraints and ontological boundaries verified successfully. Zero hallucinations detected.
              </div>
            ) : (
              <div className="space-y-2">
                {validationErrors.map((err, idx) => (
                  <div key={idx} className="p-3 bg-rose-950/40 border border-rose-800/50 rounded text-rose-300 text-sm">
                    ❌ {err}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'prompt' && (
          <div>
            <h3 className="text-sm font-semibold text-slate-400 uppercase mb-2">Final LLM Prompt</h3>
            <pre className="p-4 bg-slate-950 rounded border border-slate-800 text-xs text-emerald-300 font-mono overflow-x-auto whitespace-pre-wrap max-h-[350px]">
              {finalPrompt}
            </pre>
          </div>
        )}
      </div>

      {/* Node Inspection Modal */}
      {selectedNode && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full p-6 shadow-2xl relative">
            <h3 className="text-lg font-bold text-indigo-400 mb-2">Node Inspection: {selectedNode.label}</h3>
            <div className="space-y-2 text-sm text-slate-300 mb-6">
              <p><strong className="text-slate-400">ID:</strong> {selectedNode.id}</p>
              <p><strong className="text-slate-400">Type:</strong> {selectedNode.type}</p>
              <p><strong className="text-slate-400">Distance from Seed:</strong> {selectedNode.distanceFromSeed}</p>
              <div>
                <strong className="text-slate-400 block mb-1">Properties Map:</strong>
                <pre className="p-3 bg-slate-950 rounded text-xs text-slate-200 overflow-x-auto border border-slate-800">
                  {JSON.stringify(selectedNode.properties, null, 2)}
                </pre>
              </div>
            </div>
            <button 
              onClick={() => setSelectedNode(null)}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 rounded font-semibold text-white transition-colors"
            >
              Close Inspector
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
