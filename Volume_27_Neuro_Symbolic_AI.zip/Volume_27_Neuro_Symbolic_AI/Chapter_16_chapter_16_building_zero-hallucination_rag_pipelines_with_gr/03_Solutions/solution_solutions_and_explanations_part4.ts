/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { LRUCache } from 'lru-cache';

export interface GraphDBClient {
  verifyClaim(entity: string, relation: string, target: string): Promise<boolean>;
}

export interface Ontology {
  strictnessLevel: 'low' | 'medium' | 'high';
}

export interface MiddlewareConfig {
  graphClient: GraphDBClient;
  ontology: Ontology;
  redactionMarker?: string;
}

export function createGraphGuardrailMiddleware(config: MiddlewareConfig) {
  const cache = new LRUCache<string, boolean>({ max: 1000 });
  const marker = config.redactionMarker || '[Redacted: Unverified Graph Claim]';

  return {
    wrapStream: async function* (stream: AsyncIterable<string>): AsyncIterable<string> {
      let buffer = '';

      for await (const chunk of stream) {
        buffer += chunk;

        // Check for sentence/statement boundary punctuation
        const sentenceMatch = buffer.match(/^(.*?[.!?])(\s+.*)?$/);
        if (sentenceMatch) {
          const sentence = sentenceMatch[1];
          buffer = sentenceMatch[2] || '';

          const isVerified = await validateSentence(sentence, config.graphClient, cache, config.ontology.strictnessLevel);
          if (isVerified) {
            yield sentence;
          } else {
            yield ` ${marker} `;
          }
        }
      }

      // Flush remainder buffer
      if (buffer.trim().length > 0) {
        const isVerified = await validateSentence(buffer, config.graphClient, cache, config.ontology.strictnessLevel);
        if (isVerified) {
          yield buffer;
        } else {
          yield ` ${marker} `;
        }
      }
    }
  };
}

async function validateSentence(
  sentence: string, 
  client: GraphDBClient, 
  cache: LRUCache<string, boolean>, 
  strictness: 'low' | 'medium' | 'high'
): Promise<boolean> {
  // Lightweight entity/relation extraction heuristic (mock implementation)
  const extractionRegex = /([A-Z][a-zA-Z0-9_-]+)\s+(is|has|regulates|governs|contains)\s+([A-Z][a-zA-Z0-9_-]+)/g;
  let match;
  let hasClaims = false;

  while ((match = extractionRegex.exec(sentence)) !== null) {
    hasClaims = true;
    const [, entity, relation, target] = match;
    const cacheKey = `${entity}:${relation}:${target}`;

    if (cache.has(cacheKey)) {
      if (!cache.get(cacheKey)) return false;
      continue;
    }

    const verified = await client.verifyClaim(entity, relation, target);
    cache.set(cacheKey, verified);

    if (!verified) {
      if (strictness === 'high') return false;
      if (strictness === 'medium' && Math.random() > 0.3) return false; // Simulated quantization fallback degradation check
    }
  }

  // If strictness is high and ungrounded prose is detected without formal relations, enforce stricter validation
  if (strictness === 'high' && !hasClaims && sentence.length > 50) {
    return false; 
  }

  return true;
}
