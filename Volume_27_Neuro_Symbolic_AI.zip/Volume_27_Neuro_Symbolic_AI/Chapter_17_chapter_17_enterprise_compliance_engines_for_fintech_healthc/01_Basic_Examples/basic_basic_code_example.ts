/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file compliance-engine.ts
 * @description A zero-hallucination, deterministic compliance verification engine 
 * utilizing a TypeScript-based symbolic rule evaluator and ontological graph model.
 */

// Define the ontological types for our enterprise domain model
export type Jurisdiction = 'US' | 'EU' | 'UK' | 'SG';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'PROHIBITED';

export interface EntityNode {
  id: string;
  name: string;
  jurisdiction: Jurisdiction;
  isSanctioned: boolean;
  pepStatus: boolean; // Politically Exposed Person
  accreditedInvestor: boolean;
}

export interface TransactionPayload {
  transactionId: string;
  sourceEntityId: string;
  targetEntityId: string;
  amountUSD: number;
  currency: string;
  timestamp: number;
}

export interface ComplianceRule {
  ruleId: string;
  description: string;
  evaluate: (source: EntityNode, target: EntityNode, tx: TransactionPayload) => RuleResult;
}

export interface RuleResult {
  ruleId: string;
  passed: boolean;
  message: string;
  metadata?: Record<string, unknown>;
}

export interface AuditReport {
  transactionId: string;
  isCompliant: boolean;
  timestamp: number;
  evaluations: RuleResult[];
  failedRules: string[];
}

/**
 * Knowledge Graph Repository simulator storing ontological relationships and node states.
 * In a production enterprise system, this interfaces with a GraphDB via SPARQL or Cypher.
 */
export class OntologicalKnowledgeGraph {
  private entities: Map<string, EntityNode> = new Map();

  constructor(initialEntities: EntityNode[] = []) {
    initialEntities.forEach(entity => this.entities.set(entity.id, entity));
  }

  public addEntity(entity: EntityNode): void {
    this.entities.set(entity.id, entity);
  }

  public getEntity(id: string): EntityNode {
    const entity = this.entities.get(id);
    if (!entity) {
      throw new Error(`Ontological Violation: Entity with ID ${id} not found in Knowledge Graph.`);
    }
    return entity;
  }
}

/**
 * Deterministic Solver Engine executing hard-coded logical constraints.
 */
export class DeterministicComplianceEngine {
  private rules: ComplianceRule[] = [];
  private graph: OntologicalKnowledgeGraph;

  constructor(graph: OntologicalKnowledgeGraph) {
    this.graph = graph;
    this.registerDefaultRules();
  }

  /**
   * Registers mandatory enterprise compliance rules.
   */
  private registerDefaultRules(): void {
    // Rule 1: Anti-Money Laundering (AML) Sanctions Check
    this.rules.push({
      ruleId: 'AML-001',
      description: 'Source or target entities must not be on active sanction lists.',
      evaluate: (source, target, tx) => {
        if (source.isSanctioned || target.isSanctioned) {
          return {
            ruleId: 'AML-001',
            passed: false,
            message: `Sanction violation detected. Source (${source.id}) or Target (${target.id}) is flagged.`,
            metadata: { sourceSanctioned: source.isSanctioned, targetSanctioned: target.isSanctioned }
          };
        }
        return { ruleId: 'AML-001', passed: true, message: 'Entities clear of active sanctions.' };
      }
    });

    // Rule 2: High-Value Threshold Reporting (FinCEN / EU AMLD)
    this.rules.push({
      ruleId: 'FIN-002',
      description: 'Transactions exceeding $10,000 USD require verified institutional or accredited status.',
      evaluate: (source, target, tx) => {
        const THRESHOLD = 10000;
        if (tx.amountUSD > THRESHOLD) {
          if (!source.accreditedInvestor) {
            return {
              ruleId: 'FIN-002',
              passed: false,
              message: `Transaction amount ($${tx.amountUSD}) exceeds threshold without accredited source status.`,
              metadata: { amount: tx.amountUSD, threshold: THRESHOLD }
            };
          }
        }
        return { ruleId: 'FIN-002', passed: true, message: 'Transaction within allowable threshold or source is accredited.' };
      }
    });

    // Rule 3: Politically Exposed Person (PEP) Enhanced Due Diligence
    this.rules.push({
      ruleId: 'REG-003',
      description: 'Transactions involving PEPs require dual-jurisdiction validation.',
      evaluate: (source, target, tx) => {
        if ((source.pepStatus || target.pepStatus) && tx.amountUSD > 5000) {
          if (source.jurisdiction !== target.jurisdiction) {
            return {
              ruleId: 'REG-003',
              passed: false,
              message: 'Cross-border PEP transaction exceeding $5,000 requires manual compliance officer override.',
              metadata: { sourcePep: source.pepStatus, targetPep: target.pepStatus, amount: tx.amountUSD }
            };
          }
        }
        return { ruleId: 'REG-003', passed: true, message: 'PEP validation passed.' };
      }
    });
  }

  /**
   * Executes all rules deterministically against a transaction payload.
   */
  public evaluateTransaction(tx: TransactionPayload): AuditReport {
    const sourceEntity = this.graph.getEntity(tx.sourceEntityId);
    const targetEntity = this.graph.getEntity(tx.targetEntityId);

    const evaluations: RuleResult[] = this.rules.map(rule => rule.evaluate(sourceEntity, targetEntity, tx));
    const failedRules = evaluations.filter(e => !e.passed).map(e => e.ruleId);

    return {
      transactionId: tx.transactionId,
      isCompliant: failedRules.length === 0,
      timestamp: Date.now(),
      evaluations,
      failedRules
    };
  }
}

// ==========================================
// EXAMPLE EXECUTION CONTEXT (SaaS / API Simulation)
// ==========================================

// 1. Initialize Knowledge Graph with ontological entities
const kb = new OntologicalKnowledgeGraph([
  { id: 'ENT-001', name: 'Acme Corp US', jurisdiction: 'US', isSanctioned: false, pepStatus: false, accreditedInvestor: true },
  { id: 'ENT-002', name: 'Global Offshore LLC', jurisdiction: 'UK', isSanctioned: true, pepStatus: false, accreditedInvestor: false },
  { id: 'ENT-003', name: 'State Official Holding', jurisdiction: 'EU', isSanctioned: false, pepStatus: true, accreditedInvestor: false }
]);

// 2. Instantiate the Deterministic Compliance Engine
const complianceEngine = new DeterministicComplianceEngine(kb);

// 3. Execute a high-risk test transaction triggering sanctions
const sampleTransaction: TransactionPayload = {
  transactionId: 'TXN-998877',
  sourceEntityId: 'ENT-001',
  targetEntityId: 'ENT-002',
  amountUSD: 25000,
  currency: 'USD',
  timestamp: Date.now()
};

const auditReport: AuditReport = complianceEngine.evaluateTransaction(sampleTransaction);
console.log(JSON.stringify(auditReport, null, 2));
