/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';

/**
 * Represents a node within the Enterprise Knowledge Graph.
 */
interface KnowledgeGraphNode {
  id: string;
  label: 'Entity' | 'Transaction' | 'Regulation' | 'Jurisdiction';
  properties: Record<string, any>;
}

/**
 * Represents a directed edge within the Enterprise Knowledge Graph.
 */
interface KnowledgeGraphEdge {
  source: string;
  target: string;
  relation: 'GOVERNED_BY' | 'PARTICIPATES_IN' | 'RESTRICTS' | 'EXCEEDS_THRESHOLD';
}

/**
 * The unified Knowledge Graph container.
 */
interface KnowledgeGraph {
  nodes: Map<string, KnowledgeGraphNode>;
  edges: KnowledgeGraphEdge[];
}

/**
 * Input payload for the enterprise compliance verification engine.
 */
interface CompliancePayload {
  tenantId: string;
  domain: 'FINTECH' | 'HEALTHCARE' | 'LEGAL';
  transactionId: string;
  subjectId: string;
  amount?: number;
  dataClassification?: 'PII' | 'PHI' | 'PCI' | 'PUBLIC';
  jurisdiction: string;
  timestamp: string;
}

/**
 * Deterministic audit evaluation result.
 */
interface ComplianceEvaluationResult {
  isCompliant: boolean;
  violatedRules: Array<{
    ruleId: string;
    description: string;
    severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  }>;
  auditTrail: string[];
  executedAt: string;
}

/**
 * Mock ontological rule definition.
 */
interface OntologicalRule {
  ruleId: string;
  domain: 'FINTECH' | 'HEALTHCARE' | 'LEGAL';
  evaluate: (payload: CompliancePayload, graph: KnowledgeGraph) => boolean;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
}

/**
 * Global Deterministic Rule Registry.
 * Contains absolute, programmatic compliance constraints.
 */
const REGULATORY_RULE_REGISTRY: OntologicalRule[] = [
  {
    ruleId: 'FIN-AML-001',
    domain: 'FINTECH',
    description: 'Transactions exceeding $10,000 in high-risk jurisdictions require mandatory AML verification flags.',
    severity: 'CRITICAL',
    evaluate: (payload, graph) => {
      if (payload.domain !== 'FINTECH') return true;
      if (!payload.amount || payload.amount <= 10000) return true;
      
      // Check Knowledge Graph for jurisdiction risk rating
      const jurisdictionNode = graph.nodes.get(`jurisdiction:${payload.jurisdiction}`);
      const isHighRisk = jurisdictionNode?.properties?.riskLevel === 'HIGH';
      
      // If high risk and > $10k, must have explicit KYC verification edge
      if (isHighRisk) {
        const hasKycEdge = graph.edges.some(
          e => e.source === payload.subjectId && e.relation === 'GOVERNED_BY' && e.target === 'KYC_VERIFIED'
        );
        return hasKycEdge;
      }
      return true;
    },
  },
  {
    ruleId: 'MED-HIPAA-004',
    domain: 'HEALTHCARE',
    description: 'Protected Health Information (PHI) must never cross international borders without encrypted proxy mapping.',
    severity: 'CRITICAL',
    evaluate: (payload, graph) => {
      if (payload.domain !== 'HEALTHCARE') return true;
      if (payload.dataClassification !== 'PHI') return true;

      const entityNode = graph.nodes.get(`entity:${payload.subjectId}`);
      const isDomestic = entityNode?.properties?.jurisdiction === payload.jurisdiction;
      const hasProxyMapping = graph.edges.some(
        e => e.source === payload.subjectId && e.relation === 'RESTRICTS' && e.target === 'ENCRYPTED_PROXY'
      );

      return isDomestic || hasProxyMapping;
    },
  },
  {
    ruleId: 'LEG-GDPR-012',
    domain: 'LEGAL',
    description: 'Data subjects in EU jurisdictions must have active explicit consent records for processing telemetry.',
    severity: 'HIGH',
    evaluate: (payload, graph) => {
      if (payload.domain !== 'LEGAL') return true;
      if (payload.jurisdiction !== 'EU') return true;

      const hasConsentEdge = graph.edges.some(
        e => e.source === payload.subjectId && e.relation === 'GOVERNED_BY' && e.target === 'EXPLICIT_CONSENT_ACTIVE'
      );

      return hasConsentEdge;
    },
  },
];

/**
 * Constructs an enterprise knowledge graph from persistent storage or cache.
 */
async function loadDomainKnowledgeGraph(tenantId: string): Promise<KnowledgeGraph> {
  const nodes = new Map<string, KnowledgeGraphNode>();
  
  // Seeding mock institutional graph state
  nodes.set('jurisdiction:EU', { id: 'jurisdiction:EU', label: 'Jurisdiction', properties: { riskLevel: 'MEDIUM' } });
  nodes.set('jurisdiction:OFFSHORE_X', { id: 'jurisdiction:OFFSHORE_X', label: 'Jurisdiction', properties: { riskLevel: 'HIGH' } });
  nodes.set('entity:user_123', { id: 'entity:user_123', label: 'Entity', properties: { jurisdiction: 'EU' } });

  const edges: KnowledgeGraphEdge[] = [
    { source: 'entity:user_123', target: 'EXPLICIT_CONSENT_ACTIVE', relation: 'GOVERNED_BY' },
    { source: 'entity:user_999', target: 'KYC_VERIFIED', relation: 'GOVERNED_BY' }
  ];

  return { nodes, edges };
}

/**
 * Next.js API Route Handler for Deterministic Compliance Engine
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const auditTrail: string[] = [];
  const startTime = performance.now();

  try {
    auditTrail.push(`[${new Date().toISOString()}] Initializing Zero-Hallucination Compliance Pipeline.`);
    
    const body: CompliancePayload = await req.json();
    auditTrail.push(`[${new Date().toISOString()}] Parsed payload for Tenant: ${body.tenantId}, Domain: ${body.domain}`);

    // Step 1: Load Domain Knowledge Graph deterministically
    auditTrail.push(`[${new Date().toISOString()}] Loading ontological Knowledge Graph state...`);
    const knowledgeGraph = await loadDomainKnowledgeGraph(body.tenantId);
    auditTrail.push(`[${new Date().toISOString()}] Loaded ${knowledgeGraph.nodes.size} nodes and ${knowledgeGraph.edges.length} edges.`);

    // Step 2: Filter applicable deterministic rules based on domain
    const applicableRules = REGULATORY_RULE_REGISTRY.filter(rule => rule.domain === body.domain);
    auditTrail.push(`[${new Date().toISOString()}] Isolated ${applicableRules.length} deterministic rules for domain ${body.domain}.`);

    // Step 3: Execute strict ontological rule validations
    const violatedRules: ComplianceEvaluationResult['violatedRules'] = [];

    for (const rule of applicableRules) {
      auditTrail.push(`[${new Date().toISOString()}] Evaluating rule: ${rule.ruleId} - ${rule.description}`);
      const passed = rule.evaluate(body, knowledgeGraph);
      
      if (!passed) {
        auditTrail.push(`[${new Date().toISOString()}] RULE VIOLATION DETECTED: ${rule.ruleId}`);
        violatedRules.push({
          ruleId: rule.ruleId,
          description: rule.description,
          severity: rule.severity,
        });
      } else {
        auditTrail.push(`[${new Date().toISOString()}] Rule PASSED: ${rule.ruleId}`);
      }
    }

    const isCompliant = violatedRules.length === 0;
    const endTime = performance.now();
    auditTrail.push(`[${new Date().toISOString()}] Compliance evaluation finished in ${(endTime - startTime).toFixed(2)}ms. Status: ${isCompliant ? 'COMPLIANT' : 'NON_COMPLIANT'}`);

    const result: ComplianceEvaluationResult = {
      isCompliant,
      violatedRules,
      auditTrail,
      executedAt: new Date().toISOString(),
    };

    return NextResponse.json(result, { status: 200 });

  } catch (error: any) {
    return NextResponse.json(
      {
        error: 'Internal Compliance Engine Execution Failure',
        details: error.message,
        auditTrail,
      },
      { status: 500 }
    );
  }
}
