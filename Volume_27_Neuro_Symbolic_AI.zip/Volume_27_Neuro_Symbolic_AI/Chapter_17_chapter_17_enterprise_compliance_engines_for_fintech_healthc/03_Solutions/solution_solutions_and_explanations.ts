/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import 'server-only';
import { z } from 'zod';
import crypto from 'crypto';

// 1. Context and Domain Interfaces
export interface TransactionEvaluationContext {
  userId: string;
  userRiskScore: number;
  destinationCountry: string;
  originCountry: string;
  amountUsd: number;
  isPepOrSanctioned: boolean;
  graphTriples: [string, string, string][]; // [subject, predicate, object]
}

export interface ComplianceResult {
  approved: boolean;
  triggeredRules: string[];
  auditHash: string;
  evaluationTimestamp: string;
}

// 2. Deterministic Solver Module with Interactive Challenge (Embargo Check)
export function evaluateAMLCompliance(context: TransactionEvaluationContext): ComplianceResult {
  const triggeredRules: string[] = [];

  // Challenge Requirement: Dynamic RDF/OWL-inspired triple store check for active trade embargo
  const hasEmbargo = context.graphTriples.some(
    ([subject, predicate, object]) =>
      (subject === context.destinationCountry && predicate === 'HAS_EMBARGO_WITH' && object === context.originCountry) ||
      (subject === context.originCountry && predicate === 'HAS_EMBARGO_WITH' && object === context.destinationCountry)
  );

  if (hasEmbargo) {
    triggeredRules.push('ERR_EMBARGO_VIOLATION');
    return finalizeResult(false, triggeredRules);
  }

  // Requirement Rule 1: PEP or Sanctions list check
  if (context.isPepOrSanctioned) {
    triggeredRules.push('ERR_SANCTIONS_OR_PEP_MATCH');
  }

  // Requirement Rule 2: High risk score threshold check
  if (context.userRiskScore > 80) {
    triggeredRules.push('ERR_HIGH_USER_RISK_SCORE');
  }

  // Requirement Rule 3: Large transaction reporting threshold
  if (context.amountUsd >= 10000) {
    triggeredRules.push('INFO_CTR_THRESHOLD_EXCEEDED');
  }

  // Strict approval logic: Approved only if no structural error rules triggered
  const hasErrorRule = triggeredRules.some(rule => rule.startsWith('ERR_'));
  const approved = !hasErrorRule;

  return finalizeResult(approved, triggeredRules);
}

function finalizeResult(approved: boolean, triggeredRules: string[]): ComplianceResult {
  const evaluationTimestamp = new Date().toISOString();
  const rawPayload = JSON.stringify({ approved, triggeredRules, evaluationTimestamp });
  const auditHash = crypto.createHash('sha256').update(rawPayload).digest('hex');

  return {
    approved,
    triggeredRules,
    auditHash,
    evaluationTimestamp,
  };
}

// 3. Next.js Server Action with Runtime Zod Validation
const TransactionSchema = z.object({
  userId: z.string(),
  userRiskScore: z.number().min(0).max(100),
  destinationCountry: z.string(),
  originCountry: z.string(),
  amountUsd: z.number().positive(),
  isPepOrSanctioned: z.boolean(),
  graphTriples: z.array(z.tuple([z.string(), z.string(), z.string()])),
});

export async function verifyTransactionAction(input: unknown): Promise<ComplianceResult> {
  const parsedData = TransactionSchema.parse(input);
  
  // Execute pure deterministic solver
  const result = evaluateAMLCompliance(parsedData);

  // Persist immutable audit log entry (simulated database persistence)
  await persistAuditLog(parsedData.userId, result);

  return result;
}

async function persistAuditLog(userId: string, result: ComplianceResult) {
  // In production, write strictly to a secure immutable database audit table
  console.log(`[AUDIT_LOG] User ${userId} evaluated. Approved: ${result.approved}. Hash: ${result.auditHash}`);
}
