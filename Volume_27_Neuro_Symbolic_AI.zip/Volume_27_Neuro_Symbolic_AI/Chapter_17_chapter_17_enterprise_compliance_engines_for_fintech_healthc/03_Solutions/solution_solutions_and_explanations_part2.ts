/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { NextResponse } from 'next/server';

// 1. Ontological Graph Schema and Types
export type NodeType = 'Clinician' | 'Patient' | 'Department' | 'ConsentDirective';

export interface GraphNode {
  id: string;
  type: NodeType;
  departmentId?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  relationship: 'TREATS' | 'HAS_ACTIVE_CONSENT' | 'REVOKE_CONSENT' | 'DELEGATES_TO';
}

export interface OntologicalGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface AccessRequest {
  clinicianId: string;
  patientId: string;
  requestedCategories: string[];
  emergencyOverride: boolean;
  graph: OntologicalGraph;
}

export interface AccessEvaluationResult {
  authorized: boolean;
  evaluatedRules: string[];
  trace: string[];
}

// Challenge Requirement: Cyclic Graph Detection Utility for Access Delegation
function detectDelegationCycles(edges: GraphEdge[]): boolean {
  const adjList = new Map<string, string[]>();
  
  edges
    .filter(e => e.relationship === 'DELEGATES_TO')
    .forEach(e => {
      const list = adjList.get(e.source) || [];
      list.push(e.target);
      adjList.set(e.source, list);
    });

  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function dfs(node: string): boolean {
    visited.add(node);
    recursionStack.add(node);

    const neighbors = adjList.get(node) || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        if (dfs(neighbor)) return true;
      } else if (recursionStack.has(neighbor)) {
        return true; // Cycle detected
      }
    }

    recursionStack.delete(node);
    return false;
  }

  for (const node of adjList.keys()) {
    if (!visited.has(node)) {
      if (dfs(node)) return true;
    }
  }

  return false;
}

// 2. Deterministic HIPAA Evaluation Function
export function evaluateHIPAAAccess(request: AccessRequest): AccessEvaluationResult {
  const evaluatedRules: string[] = [];
  const trace: string[] = [];

  // Check for circular delegation security anomaly
  const hasCycle = detectDelegationCycles(request.graph.edges);
  if (hasCycle) {
    evaluatedRules.push('ERR_SECURITY_CYCLIC_DELEGATION');
    return { authorized: false, evaluatedRules, trace: ['Circular delegation detected in authorization edge set.'] };
  }

  const clinicianNode = request.graph.nodes.find(n => n.id === request.clinicianId && n.type === 'Clinician');
  const patientNode = request.graph.nodes.find(n => n.id === request.patientId && n.type === 'Patient');

  if (!clinicianNode || !patientNode) {
    evaluatedRules.push('ERR_ENTITY_NOT_FOUND');
    return { authorized: false, evaluatedRules, trace: ['Clinician or Patient entity missing from ontology graph.'] };
  }

  // Rule H1: Direct TREATS edge OR Emergency Override
  const hasTreatsEdge = request.graph.edges.some(
    e => e.source === request.clinicianId && e.target === request.patientId && e.relationship === 'TREATS'
  );

  if (!hasTreatsEdge && !request.emergencyOverride) {
    evaluatedRules.push('RULE_H1_FAILED');
    return { authorized: false, evaluatedRules, trace: ['Neither TREATS relationship nor emergency override present.'] };
  }
  evaluatedRules.push('RULE_H1_PASSED');

  // Rule H2: Patient must not have active REVOKE_CONSENT targeting clinician's department
  const clinicianDept = clinicianNode.departmentId;
  const hasRevokedConsent = request.graph.edges.some(
    e => e.source === request.patientId && e.target === clinicianDept && e.relationship === 'REVOKE_CONSENT'
  );

  if (hasRevokedConsent && !request.emergencyOverride) {
    evaluatedRules.push('RULE_H2_FAILED');
    return { authorized: false, evaluatedRules, trace: ['Active consent revocation found for department.'] };
  }
  evaluatedRules.push('RULE_H2_PASSED');

  // Rule H3: Minimum necessary data category enforcement (simulated restriction check)
  evaluatedRules.push('RULE_H3_PASSED');

  return {
    authorized: true,
    evaluatedRules,
    trace: ['All HIPAA Minimum Necessary and RBAC/ABAC rules successfully satisfied.'],
  };
}

// 3. Next.js API Route Integration
export async function POST(req: Request) {
  try {
    const body: AccessRequest = await req.json();
    const result = evaluateHIPAAAccess(body);
    return NextResponse.json(result, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: 'Invalid access evaluation payload.' }, { status: 400 });
  }
}
