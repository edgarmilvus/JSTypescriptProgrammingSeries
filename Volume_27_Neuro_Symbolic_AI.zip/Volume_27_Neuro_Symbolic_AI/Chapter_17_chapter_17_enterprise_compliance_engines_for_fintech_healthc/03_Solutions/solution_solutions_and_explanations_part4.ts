/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import 'server-only';

// 1. Legal Graph Node Types
export type ClauseType = 'OBLIGATION' | 'PERMISSION' | 'PROHIBITION';

export interface Clause {
  id: string;
  type: ClauseType;
  subject: string;
  action: string;
  condition: string;
  temporalScope: { start: string; end: string };
  dateIssued: string; // ISO Date for temporal precedence
}

export interface LegalEdge {
  source: string; // Clause ID A
  target: string; // Clause ID B
  relationship: 'SUPERSEDES' | 'REFERENCES';
}

export interface LegalGraph {
  clauses: Clause[];
  edges: LegalEdge[];
}

export interface ContradictionReport {
  clauseIdA: string;
  clauseIdB: string;
  conflictReason: string;
  resolved: boolean;
  winningClauseId?: string;
}

// 2. Contradiction Detection Algorithm with Temporal Precedence Rule
export function detectContradictions(graph: LegalGraph): ContradictionReport[] {
  const reports: ContradictionReport[] = [];
  const { clauses, edges } = graph;

  for (let i = 0; i < clauses.length; i++) {
    for (let j = i + 1; j < clauses.length; j++) {
      const cA = clauses[i];
      const cB = clauses[j];

      // Check core conflict parameters
      const sameSubject = cA.subject === cB.subject;
      const sameAction = cA.action === cB.action;
      const sameCondition = cA.condition === cB.condition;
      const overlappingTemporal = 
        cA.temporalScope.start <= cB.temporalScope.end && 
        cB.temporalScope.start <= cA.temporalScope.end;

      if (sameSubject && sameAction && sameCondition && overlappingTemporal) {
        // Direct conflict if types are mutually exclusive (e.g. OBLIGATION vs PROHIBITION)
        const isConflict = 
          (cA.type === 'OBLIGATION' && cB.type === 'PROHIBITION') ||
          (cA.type === 'PROHIBITION' && cB.type === 'OBLIGATION') ||
          (cA.type === 'PERMISSION' && cB.type === 'PROHIBITION');

        if (isConflict) {
          // Challenge Requirement: Temporal Precedence Resolution via 'SUPERSEDES' edge
          const aSupersedesB = edges.some(e => e.source === cA.id && e.target === cB.id && e.relationship === 'SUPERSEDES');
          const bSupersedesA = edges.some(e => e.source === cB.id && e.target === cA.id && e.relationship === 'SUPERSEDES');

          if (aSupersedesB) {
            reports.push({
              clauseIdA: cA.id,
              clauseIdB: cB.id,
              conflictReason: 'Direct logical contradiction resolved by explicit SUPERSEDES edge.',
              resolved: true,
              winningClauseId: cA.id,
            });
          } else if (bSupersedesA) {
            reports.push({
              clauseIdA: cA.id,
              clauseIdB: cB.id,
              conflictReason: 'Direct logical contradiction resolved by explicit SUPERSEDES edge.',
              resolved: true,
              winningClauseId: cB.id,
            });
          } else {
            // Unresolved contradiction
            reports.push({
              clauseIdA: cA.id,
              clauseIdB: cB.id,
              conflictReason: 'Unresolved contradiction: Mutually exclusive clause types under identical conditions without precedence edge.',
              resolved: false,
            });
          }
        }
      }
    }
  }

  return reports;
}

// 3. Next.js Server Component Rendering Compliance Audit Report
export async function LegalComplianceReportServerComponent({ contractId }: { contractId: string }) {
  // Fetch parsed clause graph from semantic store securely on server
  const graph: LegalGraph = await fetchContractGraphFromDatabase(contractId);
  const contradictions = detectContradictions(graph);

  return (
    <div className="p-6 bg-slate-900 text-white rounded-lg">
      <h2 className="text-xl font-bold mb-4">Legal Contract Compliance & Contradiction Report</h2>
      <p className="text-sm text-slate-400 mb-6">Contract ID: {contractId} | Zero Client-Side JS Calculation</p>
      
      {contradictions.length === 0 ? (
        <div className="p-4 bg-emerald-900/50 border border-emerald-500 rounded text-emerald-200">
          No logical contradictions detected across contract clauses.
        </div>
      ) : (
        <div className="space-y-4">
          {contradictions.map((report, idx) => (
            <div key={idx} className={`p-4 border rounded ${report.resolved ? 'bg-amber-950/40 border-amber-600' : 'bg-rose-950/40 border-rose-600'}`}>
              <div className="flex justify-between items-center mb-2">
                <span className="font-mono text-xs">Conflict between [{report.clauseIdA}] & [{report.clauseIdB}]</span>
                <span className={`px-2 py-0.5 text-xs rounded ${report.resolved ? 'bg-amber-500 text-black' : 'bg-rose-500 text-white'}`}>
                  {report.resolved ? 'Resolved (Precedence)' : 'Unresolved Contradiction'}
                </span>
              </div>
              <p className="text-sm text-slate-300">{report.conflictReason}</p>
              {report.winningClauseId && (
                <p className="text-xs text-amber-400 mt-2">Winning Clause: {report.winningClauseId}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

async function fetchContractGraphFromDatabase(contractId: string): Promise<LegalGraph> {
  // Mock DB fetch returning a LegalGraph
  return { clauses: [], edges: [] };
}
