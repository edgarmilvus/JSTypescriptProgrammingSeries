/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState, useTransition } from 'react';

export interface ComplianceResultProp {
  approved: boolean;
  triggeredRules: string[];
  auditHash: string;
  evaluationTimestamp: string;
  evaluationTrace?: string[];
}

interface ComplianceInspectorViewProps {
  initialResult: ComplianceResultProp;
  simulationAction: (formData: FormData) => Promise<ComplianceResultProp>;
}

export function ComplianceInspectorView({ initialResult, simulationAction }: ComplianceInspectorViewProps) {
  const [result, setResult] = useState<ComplianceResultProp>(initialResult);
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PASSED' | 'FAILED'>('ALL');
  const [copied, setCopied] = useState(false);
  const [isPending, startTransition] = useTransition();

  // Challenge State: Interactive What-If Simulation Parameters
  const [userRiskScore, setUserRiskScore] = useState<number>(45);
  const [emergencyOverride, setEmergencyOverride] = useState<boolean>(false);

  const handleCopyHash = () => {
    navigator.clipboard.writeText(result.auditHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('userRiskScore', userRiskScore.toString());
    formData.append('emergencyOverride', emergencyOverride.toString());

    startTransition(async () => {
      const updatedResult = await simulationAction(formData);
      setResult(updatedResult);
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 shadow-2xl">
      <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Compliance Graph Inspector</h1>
          <p className="text-xs text-slate-400">Timestamp: {result.evaluationTimestamp}</p>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-sm font-semibold flex items-center gap-2 ${result.approved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'bg-rose-500/20 text-rose-400 border border-rose-500/50'}`}>
          <span className={`w-2.5 h-2.5 rounded-full ${result.approved ? 'bg-emerald-400' : 'bg-rose-400'}`} />
          {result.approved ? 'Strictly Verified & Approved' : 'Compliance Failure Flagged'}
        </div>
      </div>

      {/* Cryptographic Audit Hash Section */}
      <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 mb-6 flex items-center justify-between">
        <div>
          <span className="text-xs font-mono uppercase text-slate-400">Cryptographic Audit Hash (SHA-256)</span>
          <p className="font-mono text-sm text-amber-400 break-all">{result.auditHash}</p>
        </div>
        <button
          onClick={handleCopyHash}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded font-medium transition"
        >
          {copied ? 'Copied!' : 'Copy Hash'}
        </button>
      </div>

      {/* Interactive What-If Simulation Panel (Challenge Requirement) */}
      <form onSubmit={handleRunSimulation} className="bg-slate-900/60 p-4 rounded-lg border border-slate-800 mb-6">
        <h3 className="text-sm font-semibold text-slate-300 mb-3">Interactive What-If Simulation Mode</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-slate-400 mb-1">User Risk Score: {userRiskScore}</label>
            <input
              type="range"
              min="0"
              max="100"
              value={userRiskScore}
              onChange={(e) => setUserRiskScore(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
          </div>
          <div className="flex items-center gap-2 pt-5">
            <input
              type="checkbox"
              id="emergency"
              checked={emergencyOverride}
              onChange={(e) => setEmergencyOverride(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-emerald-500"
            />
            <label htmlFor="emergency" className="text-xs text-slate-300">Enable Emergency Access Override</label>
          </div>
        </div>
        <button
          type="submit"
          disabled={isPending}
          className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded font-medium text-sm transition"
        >
          {isPending ? 'Re-running Deterministic Engine...' : 'Run Simulation'}
        </button>
      </form>

      {/* Rule Filter Controls */}
      <div className="flex gap-2 mb-4">
        {(['ALL', 'PASSED', 'FAILED'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilterStatus(status)}
            className={`px-3 py-1 rounded text-xs font-medium transition ${filterStatus === status ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-400 hover:text-slate-200'}`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Triggered Rules List */}
      <div className="space-y-2">
        <h3 className="text-sm font-semibold text-slate-300 mb-2">Rule Evaluation Trace</h3>
        {result.triggeredRules.length === 0 ? (
          <p className="text-xs text-slate-500 italic">No rules triggered or evaluation path is empty.</p>
        ) : (
          result.triggeredRules
            .filter((rule) => {
              if (filterStatus === 'PASSED') return !rule.startsWith('ERR_');
              if (filterStatus === 'FAILED') return rule.startsWith('ERR_');
              return true;
            })
            .map((rule, idx) => (
              <div key={idx} className="p-3 bg-slate-900 border border-slate-800 rounded flex justify-between items-center text-xs font-mono">
                <span>{rule}</span>
                <span className={`px-2 py-0.5 rounded ${rule.startsWith('ERR_') ? 'bg-rose-950 text-rose-400' : 'bg-emerald-950 text-emerald-400'}`}>
                  {rule.startsWith('ERR_') ? 'FAILED / TRIGGERED' : 'PASSED'}
                </span>
              </div>
            ))
        )}
      </div>
    </div>
  );
}
