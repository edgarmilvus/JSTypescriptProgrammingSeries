/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file InMemoryComplianceGraph.ts
 * @description A high-performance, cache-friendly in-memory graph processing engine 
 * implemented in TypeScript for deterministic Neuro-Symbolic AI reasoning.
 */

/**
 * Represents the fundamental unit of the knowledge graph (Entity or Concept).
 */
interface GraphNode {
    id: number;          // Packed integer ID for dense array mapping
    label: string;       // Human-readable identifier (e.g., "Regulation_SOC2")
    properties: Record<string, string | number>; // Metadata attributes
}

/**
 * Represents a directed, typed relationship between two nodes.
 */
interface GraphEdge {
    source: number;      // Source node integer ID
    target: number;      // Target node integer ID
    relationType: string;// Semantic predicate (e.g., "REQUIRES", "VIOLATES")
}

/**
 * A high-performance, cache-friendly in-memory graph engine optimized for V8's memory model.
 */
class InMemoryGraphEngine {
    // Dense node storage array indexed by integer node ID for O(1) direct lookup.
    private nodes: GraphNode[] = [];

    // Compressed adjacency list: Maps source node ID to an array of target node IDs.
    // Storing primitive numbers directly avoids object allocation overhead inside tight loops.
    private adjacencyList: Map<number, number[]> = new Map();

    // Edge metadata lookup table keyed by a composite string "source->target".
    private edgeMetadata: Map<string, GraphEdge> = new Map();

    /**
     * Adds a node to the in-memory graph.
     * @param node The graph node to insert.
     */
    public addNode(node: GraphNode): void {
        this.nodes[node.id] = node;
        if (!this.adjacencyList.has(node.id)) {
            this.adjacencyList.set(node.id, []);
        }
    }

    /**
     * Adds a directed edge between two nodes, updating the compressed adjacency list.
     * @param edge The graph edge to insert.
     */
    public addEdge(edge: GraphEdge): void {
        // Ensure source exists in adjacency list
        if (!this.adjacencyList.has(edge.source)) {
            this.adjacencyList.set(edge.source, []);
        }
        
        // Push target to adjacency list
        const targets = this.adjacencyList.get(edge.source)!;
        if (!targets.includes(edge.target)) {
            targets.push(edge.target);
        }

        // Store edge metadata
        const key = `${edge.source}->${edge.target}`;
        this.edgeMetadata.set(key, edge);
    }

    /**
     * Performs a deterministic Breadth-First Search (BFS) to find the shortest path 
     * between a compliance standard and an operational asset.
     * 
     * @param startId The starting node integer ID.
     * @param targetId The target node integer ID.
     * @returns An array of node IDs representing the deterministic path, or empty if none.
     */
    public findDeterministicPath(startId: number, targetId: number): number[] {
        if (!this.adjacencyList.has(startId) || !this.adjacencyList.has(targetId)) {
            return [];
        }

        if (startId === targetId) {
            return [startId];
        }

        const visited: Uint8Array = new Uint8Array(this.nodes.length);
        const parentMap: Int32Array = new Int32Array(this.nodes.length).fill(-1);
        
        // Manual queue implementation using a flat array to avoid V8 garbage collection 
        // pressure caused by shifting dynamic JavaScript arrays.
        const queue: number[] = new number[this.nodes.length];
        let head = 0;
        let tail = 0;

        queue[tail++] = startId;
        visited[startId] = 1;

        let found = false;

        while (head < tail) {
            const current = queue[head++];

            if (current === targetId) {
                found = true;
                break;
            }

            const neighbors = this.adjacencyList.get(current);
            if (!neighbors) continue;

            for (let i = 0; i < neighbors.length; i++) {
                const neighbor = neighbors[i];
                if (visited[neighbor] === 0) {
                    visited[neighbor] = 1;
                    parentMap[neighbor] = current;
                    queue[tail++] = neighbor;
                }
            }
        }

        if (!found) {
            return [];
        }

        // Reconstruct path from target back to start
        const path: number[] = [];
        let curr = targetId;
        while (curr !== -1) {
            path.unshift(curr);
            curr = parentMap[curr];
        }

        return path;
    }

    /**
     * Retrieves node details by ID.
     */
    public getNode(id: number): GraphNode | undefined {
        return this.nodes[id];
    }
}

// ==========================================
// SAAS USAGE & EXECUTION CONTEXT
// ==========================================

// 1. Initialize the high-performance in-memory engine
const complianceEngine = new InMemoryGraphEngine();

// 2. Populate nodes representing Regulatory Standards, Controls, and Cloud Assets
complianceEngine.addNode({ id: 0, label: "Standard_SOC2", properties: { category: "Security" } });
complianceEngine.addNode({ id: 1, label: "Control_AccessControl", properties: { type: "Preventative" } });
complianceEngine.addNode({ id: 2, label: "Asset_DatabaseCluster", properties: { tier: "Production" } });
complianceEngine.addNode({ id: 3, label: "Vulnerability_UnencryptedStorage", properties: { severity: "High" } });

// 3. Populate edges defining ontological relationships
complianceEngine.addEdge({ source: 0, target: 1, relationType: "REQUIRES" });
complianceEngine.addEdge({ source: 1, target: 2, relationType: "GOVERNS" });
complianceEngine.addEdge({ source: 2, target: 3, relationType: "EXHIBITS" });

// 4. Execute a deterministic compliance verification query
const auditPath = complianceEngine.findDeterministicPath(0, 3);

console.log("Deterministic Audit Path (Node IDs):", auditPath);
// Output: [0, 1, 2, 3]

// 5. Translate integer path back to human-readable ontological trace for the SaaS UI
const symbolicTrace = auditPath.map(id => complianceEngine.getNode(id)?.label);
console.log("Symbolic Resolution Trace:", symbolicTrace);
// Output: [ 'Standard_SOC2', 'Control_AccessControl', 'Asset_DatabaseCluster', 'Vulnerability_UnencryptedStorage' ]
