/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { performance } from 'perf_hooks';

/**
 * Represents the primitive data types supported in our deterministic ontological graph.
 */
type NodeType = 'Entity' | 'Concept' | 'Constraint' | 'Rule';

/**
 * Packed structural representation of a Graph Node designed to minimize V8 hidden class 
 * transitions and maintain memory locality using parallel typed arrays or flat structures.
 */
interface GraphNode {
    readonly id: number;          // Unique integer ID for fast array/map indexing
    readonly name: string;        // Human-readable identifier
    readonly type: NodeType;      // Ontological classification
    readonly payloadPtr: number;  // Memory pointer or external reference index
}

/**
 * Represents a directed, weighted edge in the adjacency list.
 */
interface GraphEdge {
    readonly source: number;
    readonly target: number;
    readonly weight: number;
    readonly relationType: string;
}

/**
 * High-performance, in-memory graph execution engine optimized for zero-hallucination 
 * neuro-symbolic inference. Avoids garbage collection pressure by pre-allocating buffers
 * and maintaining flat index structures.
 */
export class InMemoryGraphEngine {
    private nodes: Map<number, GraphNode> = new Map();
    private adjacencyList: Map<number, GraphEdge[]> = new Map();
    private reverseAdjacencyList: Map<number, GraphEdge[]> = new Map();
    private isDirty: boolean = false;

    /**
     * Adds a node to the in-memory graph with O(1) complexity.
     * 
     * @param node The graph node structure to insert.
     */
    public addNode(node: GraphNode): void {
        if (this.nodes.has(node.id)) {
            throw new Error(`Deterministic Collision: Node with ID ${node.id} already exists.`);
        }
        this.nodes.set(node.id, node);
        this.adjacencyList.set(node.id, []);
        this.reverseAdjacencyList.set(node.id, []);
        this.isDirty = true;
    }

    /**
     * Establishes a directed edge between two nodes.
     * 
     * @param edge The graph edge to establish.
     */
    public addEdge(edge: GraphEdge): void {
        if (!this.nodes.has(edge.source) || !this.nodes.has(edge.target)) {
            symbolicAssert(false, "Referential Integrity Failure: Edge references non-existent nodes.");
        }

        const forwardEdges = this.adjacencyList.get(edge.source);
        if (forwardEdges) {
            forwardEdges.push(edge);
        }

        const reverseEdges = this.reverseAdjacencyList.get(edge.target);
        if (reverseEdges) {
            reverseEdges.push(edge);
        }

        this.isDirty = true;
    }

    /**
     * Executes a deterministic Breadth-First Search (BFS) to validate ontological reachability 
     * without invoking probabilistic LLM completion layers.
     * 
     * @param startId The starting node ID for traversal.
     * @param targetId The target node ID to reach.
     * @returns An array of node IDs representing the deterministic path.
     */
    public deterministicPathSearch(startId: number, targetId: number): number[] {
        if (!this.nodes.has(startId) || !this.nodes.has(targetId)) {
            return [];
        }

        const queue: number[] = [startId];
        const visited: Set<number> = new Set([startId]);
        const parentMap: Map<number, number> = new Map();

        let head = 0;
        while (head < queue.length) {
            const current = queue[head++];
            
            if (current === targetId) {
                return this.reconstructPath(parentMap, startId, targetId);
            }

            const neighbors = this.adjacencyList.get(current) || [];
            for (const edge of neighbors) {
                if (!visited.has(edge.target)) {
                    visited.add(edge.target);
                    parentMap.set(edge.target, current);
                    queue.push(edge.target);
                }
            }
        }

        return []; // No deterministic path found; guarantees zero-hallucination fallback.
    }

    /**
     * Reconstructs the exact path from the parent map generated during BFS.
     */
    private reconstructPath(parentMap: Map<number, number>, start: number, target: number): number[] {
        const path: number[] = [target];
        let current = target;
        while (current !== start) {
            const parent = parentMap.get(current);
            if (parent === undefined) break;
            path.unshift(parent);
            current = parent;
        }
        return path;
    }

    /**
     * Exports current engine snapshot for synchronization with a persistent GraphDB
     * or a Checkpointer instance.
     */
    public createSnapshot(): { nodeCount: number; edgeCount: number; timestamp: number } {
        let edgeCount = 0;
        for (const edges of this.adjacencyList.values()) {
            edgeCount += edges.length;
        }
        return {
            nodeCount: this.nodes.size,
            edgeCount,
            timestamp: performance.now()
        };
    }
}

/**
 * Strict symbolic assertion function to enforce absolute zero-hallucination invariants.
 */
function symbolicAssert(condition: boolean, message: string): asserts condition {
    if (!condition) {
        throw new Error(`[CRITICAL SYMBOLIC VIOLATION]: ${message}`);
    }
}

// --- Application Initialization & Execution ---
const engine = new InMemoryGraphEngine();

// Populate ontological nodes for a SaaS Workspace authorization schema
engine.addNode({ id: 1, name: "Tenant_Alpha", type: "Entity", payloadPtr: 1001 });
engine.addNode({ id: 2, name: "Workspace_Engineering", type: "Concept", payloadPtr: 1002 });
engine.addNode({ id: 3, name: "Role_Admin", type: "Constraint", payloadPtr: 1003 });
engine.addNode({ id: 4, name: "Policy_FullAccess", type: "Rule", payloadPtr: 1004 });

// Establish deterministic hierarchical edges
engine.addEdge({ source: 1, target: 2, weight: 1.0, relationType: "CONTAINS" });
engine.addEdge({ source: 2, target: 3, weight: 1.0, relationType: "ASSIGNED_ROLE" });
engine.addEdge({ source: 3, target: 4, weight: 1.0, relationType: "ENFORCES" });

// Execute deterministic query
const startTime = performance.now();
const path = engine.deterministicPathSearch(1, 4);
const endTime = performance.now();

console.log(`Deterministic Traversal Path: ${path.join(" -> ")}`);
console.log(`Execution Time: ${(endTime - startTime).toFixed(4)}ms`);
console.log(`Graph Engine Snapshot:`, engine.createSnapshot());
