/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export class ContiguousGraphStore {
  private nodeCapacity: number;
  private edgeCapacity: number;
  private nodeCount: number = 0;
  private edgeCount: number = 0;

  // Memory layout buffers
  private nodeBuffer: ArrayBuffer;
  private edgeBuffer: ArrayBuffer;

  // TypedArray views for nodes (Metadata ID, Adjacency Head Offset, Adjacency Length)
  private nodeMetadata: Uint32Array;
  private nodeOffsets: Uint32Array;
  private nodeDegrees: Uint32Array;

  // TypedArray views for edges (Target Node Index, Edge Weight)
  private edgeTargets: Uint32Array;
  private edgeWeights: Float64Array;

  constructor(nodeCapacity: number, edgeCapacity: number) {
    this.nodeCapacity = nodeCapacity;
    this.edgeCapacity = edgeCapacity;

    // Allocate raw memory buffers
    this.nodeBuffer = new ArrayBuffer(nodeCapacity * 12); // 3 * 4 bytes per node
    this.nodeMetadata = new Uint32Array(this.nodeBuffer, 0, nodeCapacity);
    this.nodeOffsets = new Uint32Array(this.nodeBuffer, nodeCapacity * 4, nodeCapacity);
    this.nodeDegrees = new Uint32Array(this.nodeBuffer, nodeCapacity * 8, nodeCapacity);

    this.edgeBuffer = new ArrayBuffer(edgeCapacity * 12); // 4 bytes (target) + 8 bytes (weight)
    this.edgeTargets = new Uint32Array(this.edgeBuffer, 0, edgeCapacity);
    this.edgeWeights = new Float64Array(this.edgeBuffer, edgeCapacity * 4, edgeCapacity);
  }

  public ensureCapacity(additionalNodes: number, additionalEdges: number): void {
    const requiredNodes = this.nodeCount + additionalNodes;
    const requiredEdges = this.edgeCount + additionalEdges;

    if (requiredNodes > this.nodeCapacity) {
      this.nodeCapacity = Math.max(this.nodeCapacity * 2, requiredNodes);
      const newNodeBuffer = new ArrayBuffer(this.nodeCapacity * 12);
      
      const newMetadata = new Uint32Array(newNodeBuffer, 0, this.nodeCapacity);
      const newOffsets = new Uint32Array(newNodeBuffer, this.nodeCapacity * 4, this.nodeCapacity);
      const newDegrees = new Uint32Array(newNodeBuffer, this.nodeCapacity * 8, this.nodeCapacity);

      newMetadata.set(this.nodeMetadata);
      newOffsets.set(this.nodeOffsets);
      newDegrees.set(this.nodeDegrees);

      this.nodeBuffer = newNodeBuffer;
      this.nodeMetadata = newMetadata;
      this.nodeOffsets = newOffsets;
      this.nodeDegrees = newDegrees;
    }

    if (requiredEdges > this.edgeCapacity) {
      this.edgeCapacity = Math.max(this.edgeCapacity * 2, requiredEdges);
      const newEdgeBuffer = new ArrayBuffer(this.edgeCapacity * 12);

      const newTargets = new Uint32Array(newEdgeBuffer, 0, this.edgeCapacity);
      const newWeights = new Float64Array(newEdgeBuffer, this.edgeCapacity * 4, this.edgeCapacity);

      newTargets.set(this.edgeTargets);
      newWeights.set(this.edgeWeights);

      this.edgeBuffer = newEdgeBuffer;
      this.edgeTargets = newTargets;
      this.edgeWeights = newWeights;
    }
  }

  public addNode(nodeId: number, metadataId: number): number {
    this.ensureCapacity(1, 0);
    const index = this.nodeCount++;
    this.nodeMetadata[index] = metadataId;
    this.nodeOffsets[index] = this.edgeCount;
    this.nodeDegrees[index] = 0;
    return index;
  }

  public addEdge(sourceIndex: number, targetIndex: number, weight: number): void {
    if (sourceIndex >= this.nodeCount || targetIndex >= this.nodeCount) {
      throw new Error("Out-of-bounds node index reference during edge insertion.");
    }
    this.ensureCapacity(0, 1);

    const edgeIndex = this.edgeCount++;
    this.edgeTargets[edgeIndex] = targetIndex;
    this.edgeWeights[edgeIndex] = weight;
    this.nodeDegrees[sourceIndex]++;
  }

  public getNeighbors(nodeIndex: number): { indices: Uint32Array; weights: Float64Array } {
    if (nodeIndex >= this.nodeCount) {
      throw new Error("Node index out of bounds.");
    }
    const offset = this.nodeOffsets[nodeIndex];
    const degree = this.nodeDegrees[nodeIndex];

    return {
      indices: new Uint32Array(this.edgeBuffer, offset * 4, degree),
      weights: new Float64Array(this.edgeBuffer, offset * 8 + this.edgeCapacity * 4, degree)
    };
  }
}
