/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { performance } from 'perf_hooks';
import * as v8 from 'v8';
import { ContiguousGraphStore } from './ContiguousGraphStore';

export interface BenchmarkResult {
  executionTimeMs: number;
  heapUsedDiffBytes: number;
  p50: number;
  p95: number;
  p99: number;
}

export class ArrayBufferPool {
  private queueBuffer: Uint32Array;
  private visitedBuffer: Uint8Array;

  constructor(maxNodes: number) {
    this.queueBuffer = new Uint32Array(maxNodes);
    this.visitedBuffer = new Uint8Array(Math.ceil(maxNodes / 8));
  }

  public getQueue(): Uint32Array {
    return this.queueBuffer;
  }

  public getVisited(): Uint8Array {
    this.visitedBuffer.fill(0);
    return this.visitedBuffer;
  }
}

export function benchmarkTraversal(graph: ContiguousGraphStore, startNode: number, maxNodes: number): BenchmarkResult {
  const pool = new ArrayBufferPool(maxNodes);
  const durations: number[] = [];
  const initialHeap = v8.getHeapStatistics().used_heap_size;

  if (global.gc) {
    global.gc();
  }

  for (let i = 0; i < 1000; i++) {
    const start = performance.now();
    
    const queue = pool.getQueue();
    const visited = pool.getVisited();
    let head = 0;
    let tail = 0;

    queue[tail++] = startNode;
    visited[startNode >> 3] |= (1 << (startNode & 7));

    while (head < tail) {
      const curr = queue[head++];
      const neighbors = graph.getNeighbors(curr);
      const indices = neighbors.indices;

      for (let j = 0; j < indices.length; j++) {
        const neighbor = indices[j];
        const byteIndex = neighbor >> 3;
        const bitMask = 1 << (neighbor & 7);

        if (!(visited[byteIndex] & bitMask)) {
          visited[byteIndex] |= bitMask;
          queue[tail++] = neighbor;
        }
      }
    }

    durations.push(performance.now() - start);
  }

  const finalHeap = v8.getHeapStatistics().used_heap_size;
  durations.sort((a, b) => a - b);

  return {
    executionTimeMs: durations.reduce((a, b) => a + b, 0),
    heapUsedDiffBytes: finalHeap - initialHeap,
    p50: durations[Math.floor(durations.length * 0.50)],
    p95: durations[Math.floor(durations.length * 0.95)],
    p99: durations[Math.floor(durations.length * 0.99)],
  };
}
