/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';

export interface TelemetryPayload {
  heapUsed: number;
  heapTotal: number;
  bufferUtilization: number;
  p50: number;
  p95: number;
  p99: number;
}

export const GraphEngineDashboard: React.FC<{ telemetryStream: WebSocket }> = ({ telemetryStream }) => {
  const [telemetry, setTelemetry] = useState<TelemetryPayload>({
    heapUsed: 0,
    heapTotal: 100,
    bufferUtilization: 0,
    p50: 0,
    p95: 0,
    p99: 0,
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    telemetryStream.onmessage = (event) => {
      const data: TelemetryPayload = JSON.parse(event.data);
      setTelemetry(data);
    };
  }, [telemetryStream]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#1e1e1e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Simulated node rendering loop for 5000+ nodes
      ctx.fillStyle = '#00ffcc';
      for (let i = 0; i < 5000; i++) {
        const x = (i * 37) % canvas.width;
        const y = (i * 59) % canvas.height;
        ctx.fillRect(x, y, 2, 2);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div style={{ padding: '20px', background: '#121212', color: '#fff', fontFamily: 'sans-serif' }}>
      <h2>Neuro-Symbolic Graph Engine Telemetry</h2>
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div>
          <h4>V8 Heap Usage</h4>
          <progress value={telemetry.heapUsed} max={telemetry.heapTotal} style={{ width: '200px' }} />
          <span>{((telemetry.heapUsed / telemetry.heapTotal) * 100).toFixed(1)}%</span>
        </div>
        <div>
          <h4>Buffer Utilization</h4>
          <progress value={telemetry.bufferUtilization} max={100} style={{ width: '200px' }} />
          <span>{telemetry.bufferUtilization}%</span>
        </div>
        <div>
          <h4>Latencies (p50 / p95 / p99)</h4>
          <p>{telemetry.p50.toFixed(2)}ms / {telemetry.p95.toFixed(2)}ms / {telemetry.p99.toFixed(2)}ms</p>
        </div>
      </div>
      <div>
        <canvas ref={canvasRef} width={800} height={500} style={{ border: '1px solid #333' }} />
      </div>
    </div>
  );
};
