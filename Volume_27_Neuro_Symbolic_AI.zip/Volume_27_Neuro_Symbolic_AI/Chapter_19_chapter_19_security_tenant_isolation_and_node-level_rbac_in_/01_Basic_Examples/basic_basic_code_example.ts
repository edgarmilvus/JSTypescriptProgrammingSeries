/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Secure Graph Traversal Engine with Node-Level RBAC and Tenant Isolation
 * @description Implements a zero-trust graph query engine in TypeScript for multi-tenant SaaS.
 */

import { EventEmitter } from 'events';

// ============================================================================
// Types and Interfaces
// ============================================================================

/**
 * Represents the security classification levels available in the system.
 */
type SecurityClassification = 'PUBLIC' |- 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';

/**
 * Defines the user's security profile within a specific tenant context.
 */
interface UserContext {
  userId: string;
  tenantId: string;
  roles: string[];
  clearanceLevel: SecurityClassification;
}

/**
 * Represents a single node (entity) within the knowledge graph.
 */
interface GraphNode {
  id: string;
  tenantId: string;
  label: string;
  classification: SecurityClassification;
  requiredRoles: string[];
  properties: Record<string, unknown>;
}

/**
 * Represents a directed edge (relationship) between two nodes in the knowledge graph.
 */
interface GraphEdge {
  id: string;
  tenantId: string;
  sourceId: string;
  targetId: string;
  relationshipType: string;
  classification: SecurityClassification;
}

/**
 * Audit log entry structure for tracking security decisions.
 */
interface AuditLogEntry {
  timestamp: string;
  userId: string;
  tenantId: string;
  action: string;
  nodeId: string;
  allowed: boolean;
  reason: string;
}

// ============================================================================
// In-Memory Graph Storage (Mock Database Layer)
// ============================================================================

/**
 * Mock database simulating a multi-tenant graph storage layer.
 */
class SecureGraphDatabase {
  private nodes: Map<string, GraphNode> = new Map();
  private edges: Map<string, GraphEdge> = new Map();

  /**
   * Inserts a node into the secure store.
   */
  public async saveNode(node: GraphNode): Promise<void> {
    this.nodes.set(node.id, node);
  }

  /**
   * Inserts an edge into the secure store.
   */
  public async saveEdge(edge: GraphEdge): Promise<void> {
    this.edges.set(edge.id, edge);
  }

  /**
   * Retrieves a node by ID using non-blocking asynchronous operations.
   */
  public async getNode(id: string): Promise<GraphNode | undefined> {
    return Promise.resolve(this.nodes.get(id));
  }

  /**
   * Retrieves all outgoing edges for a given source node ID.
   */
  public async getOutgoingEdges(sourceId: string): Promise<GraphEdge[]> {
    const results: GraphEdge[] = [];
    for (const edge of this.edges.values()) {
      if (edge.sourceId === sourceId) {
        results.push(edge);
      }
    }
    return Promise.resolve(results);
  }
}

// ============================================================================
// Security Policy Engine
// ============================================================================

/**
 * Evaluates security policies for graph nodes and edges.
 */
class SecurityPolicyEngine {
  private classificationHierarchy: Record<SecurityClassification, number> = {
    'PUBLIC': 0,
    'INTERNAL': 1,
    'CONFIDENTIAL': 2,
    'RESTRICTED': 3,
  };

  /**
   * Determines if a user has access to a specific graph node.
   * Enforces Tenant Isolation, Classification Hierarchy, and RBAC intersection.
   */
  public evaluateNodeAccess(user: UserContext, node: GraphNode): { allowed: boolean; reason: string } {
    // 1. Tenant Isolation Check (Hard Boundary)
    if (user.tenantId !== node.tenantId) {
      return {
        allowed: false,
        reason: `Tenant Isolation Violation: User tenant '${user.tenantId}' cannot access node belonging to tenant '${node.tenantId}'.`,
      };
    }

    // 2. Security Clearance Level Check (Hierarchical)
    const userClearanceRank = this.classificationHierarchy[user.clearanceLevel];
    const nodeClassificationRank = this.classificationHierarchy[node.classification];

    if (userClearanceRank < nodeClassificationRank) {
      return {
        allowed: false,
        reason: `Insufficient Clearance: User clearance '${user.clearanceLevel}' is below node classification '${node.classification}'.`,
      };
    }

    // 3. Role-Based Access Control (RBAC) Intersection Check
    if (node.requiredRoles.length > 0) {
      const hasRequiredRole = node.requiredRoles.some(role => user.roles.includes(role));
      if (!hasRequiredRole) {
        return {
          allowed: false,
          reason: `RBAC Violation: User lacks one of the required roles: [${node.requiredRoles.join(', ')}].`,
        };
      }
    }

    return { allowed: true, reason: 'Access granted by security policy engine.' };
  }
}

// ============================================================================
// Zero-Trust Graph Traversal Engine
// ============================================================================

/**
 * Executes traversals across the knowledge graph while enforcing deterministic security policies.
 */
class ZeroTrustTraversalEngine extends EventEmitter {
  private db: SecureGraphDatabase;
  private policyEngine: SecurityPolicyEngine;

  constructor(db: SecureGraphDatabase, policyEngine: SecurityPolicyEngine) {
    super();
    this.db = db;
    this.policyEngine = policyEngine;
  }

  /**
   * Traverses the graph starting from a root node, evaluating security policies at every hop.
   * Non-blocking I/O is utilized via async/await to keep the event loop responsive.
   */
  public async traverse(user: UserContext, startNodeId: string, maxDepth: number = 3): Promise<GraphNode[]> {
    const visited: Set<string> = new Set();
    const authorizedNodes: GraphNode[] = [];
    const queue: { nodeId: string; depth: number }[] = [{ nodeId: startNodeId, depth: 0 }];

    while (queue.length > 0) {
      const current = queue.shift();
      if (!current) break;

      const { nodeId, depth } = current;

      if (visited.has(nodeId) || depth > maxDepth) {
        continue;
      }

      visited.add(nodeId);

      // Non-blocking database fetch
      const node = await this.db.getNode(nodeId);
      if (!node) {
        this.emit('audit', {
          timestamp: new Date().toISOString(),
          userId: user.userId,
          tenantId: user.tenantId,
          action: 'TRAVERSE_NODE',
          nodeId,
          allowed: false,
          reason: 'Node not found in storage.',
        } as AuditLogEntry);
        continue;
      }

      // Evaluate security policy
      const accessResult = this.policyEngine.evaluateNodeAccess(user, node);

      // Emit immutable audit trail event
      this.emit('audit', {
        timestamp: new Date().toISOString(),
        userId: user.userId,
        tenantId: user.tenantId,
        action: 'TRAVERSE_NODE',
        nodeId: node.id,
        allowed: accessResult.allowed,
        reason: accessResult.reason,
      } as AuditLogEntry);

      if (!accessResult.allowed) {
        // Zero-trust fail-secure: Skip unauthorized nodes entirely (do not traverse further)
        continue;
      }

      // Add authorized node to result set
      authorizedNodes.push(node);

      // Fetch outgoing edges for the next traversal step
      const outgoingEdges = await this.db.getOutgoingEdges(node.id);
      for (const edge of outgoingEdges) {
        // Verify edge tenant isolation as well
        if (edge.tenantId === user.tenantId && !visited.has(edge.targetId)) {
          queue.push({ nodeId: edge.targetId, depth: depth + 1 });
        }
      }
    }

    return authorizedNodes;
  }
}

// ============================================================================
// Execution Demonstration (SaaS Application Context)
// ============================================================================

async function runSaaSDemo() {
  const db = new SecureGraphDatabase();
  const policyEngine = new SecurityPolicyEngine();
  const engine = new ZeroTrustTraversalEngine(db, policyEngine);

  // Setup Audit Logger listener
  engine.on('audit', (entry: AuditLogEntry) => {
    const status = entry.allowed ? '✅ ALLOWED' : '❌ DENIED';
    console.log(`[AUDIT] ${entry.timestamp} | User: ${entry.userId} | Node: ${entry.nodeId} | ${status} | ${entry.reason}`);
  });

  // Populate Database with Multi-Tenant Data
  // Tenant A Nodes
  await db.saveNode({
    id: 'node_alpha_1',
    tenantId: 'tenant_acme_corp',
    label: 'CustomerRecord',
    classification: 'CONFIDENTIAL',
    requiredRoles: ['support_agent'],
    properties: { name: 'Acme Global Account' },
  });

  await db.saveNode({
    id: 'node_alpha_2',
    tenantId: 'tenant_acme_corp',
    label: 'FinancialAudit',
    classification: 'RESTRICTED',
    requiredRoles: ['finance_admin'],
    properties: { q3Revenue: '$4.2M' },
  });

  // Tenant B Node (Attempted Cross-Tenant Contamination)
  await db.saveNode({
    id: 'node_beta_1',
    tenantId: 'tenant_globex',
    label: 'SecretProject',
    classification: 'PUBLIC',
    requiredRoles: [],
    properties: { codeName: 'Project Homer' },
  });

  // Establish edges for traversal
  await db.saveEdge({
    id: 'edge_1',
    tenantId: 'tenant_acme_corp',
    sourceId: 'node_alpha_1',
    targetId: 'node_alpha_2',
    relationshipType: 'HAS_FINANCIAL',
    classification: 'CONFIDENTIAL',
  });

  await db.saveEdge({
    id: 'edge_2',
    tenantId: 'tenant_acme_corp',
    sourceId: 'node_alpha_1',
    targetId: 'node_beta_1', // Malicious cross-tenant link attempt
    relationshipType: 'LINKED_TO',
    classification: 'PUBLIC',
  });

  // Define User: Support Agent at Acme Corp (Lacks finance_admin role)
  const supportAgentUser: UserContext = {
    userId: 'usr_alice_123',
    tenantId: 'tenant_acme_corp',
    roles: ['support_agent'],
    clearanceLevel: 'CONFIDENTIAL',
  };

  console.log('--- Starting Traversal for Support Agent (Alice) ---');
  const results = await engine.traverse(supportAgentUser, 'node_alpha_1', 2);
  
  console.log('\n--- Authorized Nodes Returned to Application ---');
  results.forEach(n => console.log(`- [${n.id}] ${n.label}:`, n.properties));
}

// Run the demonstration
runSaaSDemo();
