/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createHash, randomBytes, createHmac } from 'crypto';

/**
 * Enumeration of system-wide security roles mapped to granular access permissions.
 */
export enum SecurityRole {
  GLOBAL_ADMIN = 'GLOBAL_ADMIN',
  TENANT_ADMIN = 'TENANT_ADMIN',
  ANALYST = 'ANALYST',
  AUDITOR = 'AUDITOR',
  GUEST = 'GUEST'
}

/**
 * Sensitivity classification levels for nodes within the knowledge graph.
 */
export enum ClassificationLevel {
  PUBLIC = 0,
  INTERNAL = 1,
  CONFIDENTIAL = 2,
  RESTRICTED = 3,
  TOP_SECRET = 4
}

/**
 * Represents the contextual identity of the user executing a graph query.
 */
export interface SecurityContext {
  userId: string;
  tenantId: string;
  roles: SecurityRole[];
  clearanceLevel: ClassificationLevel;
  sessionTokenHash: string;
}

/**
 * Represents a single node inside the deterministic graph database.
 */
export interface GraphNode {
  id: string;
  tenantId: string;
  label: string;
  classification: ClassificationLevel;
  properties: Record<string, unknown>;
  integrityHash: string;
}

/**
 * Represents a directed, weighted edge connecting two graph nodes.
 */
export interface GraphEdge {
  id: string;
  tenantId: string;
  sourceId: string;
  targetId: string;
  relationshipType: string;
  classification: ClassificationLevel;
  integrityHash: string;
}

/**
 * Audit log entry recording every authorization check and graph traversal action.
 */
export interface AuditLogEntry {
  timestamp: number;
  tenantId: string;
  userId: string;
  action: string;
  targetNodeId: string;
  accessGranted: boolean;
  reason: string;
  hmacSignature: string;
}

/**
 * Zero-Trust Node-Level RBAC and Traversal Engine for Multi-Tenant Knowledge Graphs.
 */
export class SecureGraphEngine {
  private nodes: Map<string, GraphNode> = new Map();
  private edges: Map<string, GraphEdge> = new Map();
  private auditTrail: AuditLogEntry[] = [];
  private hmacSecret: string;

  /**
   * Initializes the secure graph engine with a cryptographic key for audit signing.
   * @param hmacSecret - Secret key used for generating immutable audit log entry signatures.
   */
  constructor(hmacSecret?: string) {
    this.hmacSecret = hmacSecret || randomBytes(32).toString('hex');
  }

  /**
   * Cryptographically signs an audit log entry to ensure tamper-evidence.
   */
  private generateAuditSignature(entry: Omit<AuditLogEntry, 'hmacSignature'>): string {
    const payload = `${entry.timestamp}:${entry.tenantId}:${entry.userId}:${entry.action}:${entry.targetNodeId}:${entry.accessGranted}`;
    return createHmac('sha256', this.hmacSecret).update(payload).digest('hex');
  }

  /**
   * Records an immutable audit log entry.
   */
  private recordAudit(
    context: SecurityContext,
    action: string,
    targetNodeId: string,
    accessGranted: boolean,
    reason: string
  ): void {
    const rawEntry = {
      timestamp: Date.now(),
      tenantId: context.tenantId,
      userId: context.userId,
      action,
      targetNodeId,
      accessGranted,
      reason
    };

    const hmacSignature = this.generateAuditSignature(rawEntry);
    this.auditTrail.push({ ...rawEntry, hmacSignature });
  }

  /**
   * Ingests a node into the graph, computing its cryptographic integrity hash.
   */
  public ingestNode(nodeData: Omit<GraphNode, 'integrityHash'>): GraphNode {
    const payload = `${nodeData.id}:${nodeData.tenantId}:${nodeData.classification}:${JSON.stringify(nodeData.properties)}`;
    const integrityHash = createHash('sha256').update(payload).digest('hex');
    
    const node: GraphNode = { ...nodeData, integrityHash };
    this.nodes.set(node.id, node);
    return node;
  }

  /**
   * Evaluates node-level access control based on multi-tenant boundaries and RBAC policies.
   */
  public evaluateAccess(context: SecurityContext, node: GraphNode): boolean {
    // Rule 1: Strict Tenant Isolation Check
    if (context.tenantId !== node.tenantId && !context.roles.includes(SecurityRole.GLOBAL_ADMIN)) {
      this.recordAudit(context, 'TRAVERSE_NODE', node.id, false, 'Tenant boundary violation detected.');
      return false;
    }

    // Rule 2: Global Admins bypass clearance checks
    if (context.roles.includes(SecurityRole.GLOBAL_ADMIN)) {
      this.recordAudit(context, 'TRAVERSE_NODE', node.id, true, 'Global Admin override authorized.');
      return true;
    }

    // Rule 3: Classification Clearance Check
    if (node.classification > context.clearanceLevel) {
      this.recordAudit(context, 'TRAVERSE_NODE', node.id, false, `Insufficient clearance. Required: ${node.classification}, User: ${context.clearanceLevel}`);
      return false;
    }

    // Rule 4: Tenant Admin role verification for confidential or higher items
    if (node.classification >= ClassificationLevel.CONFIDENTIAL) {
      const hasPrivilegedRole = context.roles.includes(SecurityRole.TENANT_ADMIN) || context.roles.includes(SecurityRole.ANALYST);
      if (!hasPrivilegedRole) {
        this.recordAudit(context, 'TRAVERSE_NODE', node.id, false, 'Role lacks permission for classified node.');
        return false;
      }
    }

    this.recordAudit(context, 'TRAVERSE_NODE', node.id, true, 'Access granted successfully.');
    return true;
  }

  /**
   * Performs a zero-trust, breadth-first graph traversal starting from a given root node,
   * filtering out nodes and edges that violate tenant isolation or RBAC rules.
   * 
   * @param context - The security context of the user executing the traversal.
   * @param startNodeId - The unique identifier of the traversal starting point.
   * @param maxDepth - The maximum depth allowed for the graph traversal.
   */
  public secureTraversal(context: SecurityContext, startNodeId: string, maxDepth: number = 3): { nodes: GraphNode[], edges: GraphEdge[] } {
    const startNode = this.nodes.get(startNodeId);
    if (!startNode || !this.evaluateAccess(context, startNode)) {
      throw new Error(`Access denied or node not found for traversal root: ${startNodeId}`);
    }

    const visitedNodes = new Map<string, GraphNode>();
    const collectedEdges = new Map<string, GraphEdge>();
    let queue: Array<{ nodeId: string; currentDepth: number }> = [{ nodeId: startNodeId, currentDepth: 0 }];
    
    visitedNodes.set(startNode.id, startNode);

    while (queue.length > 0) {
      const { nodeId, currentDepth } = queue.shift()!;

      if (currentDepth >= maxDepth) continue;

      // Find all outgoing and incoming edges connected to the current node
      for (const edge of this.edges.values()) {
        if (edge.sourceId === nodeId || edge.targetId === nodeId) {
          const neighborId = edge.sourceId === nodeId ? edge.targetId : edge.sourceId;
          const neighborNode = this.nodes.get(neighborId);

          if (neighborNode && !visitedNodes.has(neighborNode.id)) {
            // Evaluate access to the adjacent node
            if (this.evaluateAccess(context, neighborNode)) {
              visitedNodes.set(neighborNode.id, neighborNode);
              collectedEdges.set(edge.id, edge);
              queue.push({ nodeId: neighborNode.id, currentDepth: currentDepth + 1 });
            }
          }
        }
      }
    }

    return {
      nodes: Array.from(visitedNodes.values()),
      edges: Array.from(collectedEdges.values())
    };
  }
}
