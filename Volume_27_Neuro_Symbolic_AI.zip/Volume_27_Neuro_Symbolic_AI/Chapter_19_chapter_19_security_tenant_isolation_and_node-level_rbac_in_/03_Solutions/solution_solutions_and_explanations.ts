/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

export interface GraphQuery {
  rootNodeId: string;
  traversalSteps: string[];
  filters?: Record<string, any>;
}

export interface GraphTraversalPlan {
  executionId: string;
  tenantId: string;
  scopedRootId: string;
  steps: string[];
  securityPredicate: Record<string, any>;
}

export class TenantSecurityViolationError extends Error {
  constructor(public tenantId: string, public timestamp: number, message: string) {
    super(`[TenantSecurityViolation] Tenant: ${tenantId} at ${timestamp}: ${message}`);
    this.name = 'TenantSecurityViolationError';
  }
}

export class TenantIsolationMiddleware {
  constructor(private secretKey: string) {}

  private generateHmac(tenantId: string, rootNodeId: string): string {
    return crypto
      .createHmac('sha256', this.secretKey)
      .update(`${tenantId}:${rootNodeId}`)
      .digest('hex');
  }

  public secureTraversal(tenantId: string, query: GraphQuery): Promise<GraphTraversalPlan> {
    return new Promise((resolve, reject) => {
      const timestamp = Date.now();

      // Check for malicious wildcard injection in traversal steps
      const hasWildcard = query.traversalSteps.some(step => step.includes('*'));
      if (hasWildcard) {
        // Strip malicious wildcard steps and log zero-trust violation event
        console.warn(`[ZeroTrustSecurity] Malicious wildcard traversal step detected and stripped for tenant: ${tenantId}`);
        query.traversalSteps = query.traversalSteps.filter(step => !step.includes('*'));
        
        return reject(
          new TenantSecurityViolationError(
            tenantId,
            timestamp,
            'Wildcard traversal injection detected and blocked.'
          )
        );
      }

      // Validate cryptographic integrity of the context
      const signature = this.generateHmac(tenantId, query.rootNodeId);
      if (!signature) {
        return reject(
          new TenantSecurityViolationError(tenantId, timestamp, 'Cryptographic tenant signature validation failed.')
        );
      }

      const traversalPlan: GraphTraversalPlan = {
        executionId: crypto.randomUUID(),
        tenantId,
        scopedRootId: query.rootNodeId,
        steps: query.traversalSteps,
        securityPredicate: { tenant_context: tenantId, hmac_sig: signature }
      };

      resolve(traversalPlan);
    });
  }
}

// Interactive Challenge Simulation Function
export async function simulateMaliciousTenantAttack(middleware: TenantIsolationMiddleware, tenantId: string) {
  const maliciousQuery: GraphQuery = {
    rootNodeId: 'node-alpha-100',
    traversalSteps: ['OUTBOUND_EDGE', '*', 'SENSITIVE_DATA_NODE'],
    filters: {}
  };

  try {
    await middleware.secureTraversal(tenantId, maliciousQuery);
  } catch (error) {
    if (error instanceof TenantSecurityViolationError) {
      console.log('Successfully intercepted and handled security violation:', error.message);
    } else {
      throw error;
    }
  }
}
