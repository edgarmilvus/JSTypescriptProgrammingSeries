/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface SecurityContext {
  userId: string;
  roles: string[];
  clearanceLevel: number; // 1-5 scale
}

export interface GraphNode {
  id: string;
  labels: string[];
  minClearanceRequired: number; // 1-5 scale
}

export class NodeRbacGate {
  public evaluateAccess(context: SecurityContext, node: GraphNode): boolean {
    // Rule 1: Clearance level check
    if (context.clearanceLevel < node.minClearanceRequired) {
      return false;
    }

    // Rule 2: Restricted label enforcement
    const isRestricted = node.labels.includes('restricted');
    if (isRestricted) {
      const hasPrivilegedRole = context.roles.includes('SecurityAdmin') || context.roles.includes('Auditor');
      if (!hasPrivilegedRole) {
        return false;
      }
    }

    return true;
  }
}

export async function* traverseGraph(
  startNode: GraphNode,
  adjacencyList: Map<GraphNode, GraphNode[]>,
  context: SecurityContext,
  rbacGate: NodeRbacGate,
  visited: Set<string> = new Set()
): AsyncIterableIterator<GraphNode> {
  if (visited.has(startNode.id)) {
    return;
  }
  visited.add(startNode.id);

  // Pre-flight evaluation: silence branch if unauthorized
  if (!rbacGate.evaluateAccess(context, startNode)) {
    return; // Prune branch silently without leaking existence
  }

  yield startNode;

  const neighbors = adjacencyList.get(startNode) || [];
  for (const neighbor of neighbors) {
    yield* traverseGraph(neighbor, adjacencyList, context, rbacGate, visited);
  }
}
