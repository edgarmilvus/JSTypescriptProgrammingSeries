/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

interface CacheEntry {
  allowed: boolean;
  expiresAt: number;
}

export class OntologyRuleEngine {
  private permissionCache = new Map<string, CacheEntry>();
  constructor(private ttlMs: number = 60000) {}

  private getCacheKey(userId: string, targetNodeId: string, action: string): string {
    return `${userId}:${targetNodeId}:${action}`;
  }

  public async evaluateDynamicPermission(
    userId: string,
    targetNodeId: string,
    action: 'READ' | 'WRITE',
    mockPathFinder: (uId: string, targetId: string) => Promise<{ pathValid: boolean; edgeTimestamp: number }>
  ): Promise<boolean> {
    const cacheKey = this.getCacheKey(userId, targetNodeId, action);
    const cached = this.permissionCache.get(cacheKey);
    const now = Date.now();

    if (cached && cached.expiresAt > now) {
      return cached.allowed;
    }

    // Execute dynamic ontology sub-graph path query with temporal edge validation
    const pathEvaluation = await mockPathFinder(userId, targetNodeId);
    
    // Check if membership/relationship has expired (e.g., edge timestamp older than 30 days)
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
    const isTemporallyValid = (now - pathEvaluation.edgeTimestamp) <= thirtyDaysInMs;

    const allowed = pathEvaluation.pathValid && isTemporallyValid;

    // Cache evaluation result with TTL
    this.permissionCache.set(cacheKey, {
      allowed,
      expiresAt: now + this.ttlMs
    });

    return allowed;
  }

  public invalidateCache(): void {
    this.permissionCache.clear();
  }
}
