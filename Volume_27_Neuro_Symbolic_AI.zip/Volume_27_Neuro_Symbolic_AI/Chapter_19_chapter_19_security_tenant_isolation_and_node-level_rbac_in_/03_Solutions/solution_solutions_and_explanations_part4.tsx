/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export type EventType = 'ACCESS_GRANTED' | 'RBAC_REJECTED' | 'TENANT_BREACH_ATTEMPT';

export interface SecurityAuditEvent {
  eventId: string;
  timestamp: number;
  tenantId: string;
  userId: string;
  eventType: EventType;
  nodeId: string;
}

interface SecurityAuditDashboardProps {
  eventStream: AsyncIterable<SecurityAuditEvent> | React.Observable<SecurityAuditEvent>;
}

export const SecurityAuditDashboard: React.FC<SecurityAuditDashboardProps> = ({ eventStream }) => {
  const [events, setEvents] = useState<SecurityAuditEvent[]>([]);
  const [filterViolationsOnly, setFilterViolationsOnly] = useState<boolean>(false);

  // Simulated subscription handling for demonstration purposes
  useEffect(() => {
    let isMounted = true;
    // Real implementation would subscribe to RxJS observable or AsyncIterator stream
    return () => {
      isMounted = false;
    };
  }, [eventStream]);

  const displayedEvents = filterViolationsOnly
    ? events.filter(e => e.eventType === 'RBAC_REJECTED' || e.eventType === 'TENANT_BREACH_ATTEMPT')
    : events;

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Security Audit Trail Dashboard</h2>
        <button
          onClick={() => setFilterViolationsOnly(!filterViolationsOnly)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded text-sm font-semibold transition"
        >
          {filterViolationsOnly ? 'Show All Events' : 'Isolate Security Violations'}
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-700 text-slate-400">
              <th className="p-3">Timestamp</th>
              <th className="p-3">Tenant ID</th>
              <th className="p-3">User ID</th>
              <th className="p-3">Event Type</th>
              <th className="p-3">Target Node</th>
            </tr>
          </thead>
          <tbody>
            {displayedEvents.map(evt => {
              const isViolation = evt.eventType !== 'ACCESS_GRANTED';
              return (
                <tr
                  key={evt.eventId}
                  className={`border-b border-slate-800 transition-colors ${
                    isViolation ? 'bg-red-950/40 animate-pulse' : 'hover:bg-slate-800/50'
                  }`}
                >
                  <td className="p-3 text-sm">{new Date(evt.timestamp).toLocaleTimeString()}</td>
                  <td className="p-3 text-sm font-mono">{evt.tenantId}</td>
                  <td className="p-3 text-sm font-mono">{evt.userId}</td>
                  <td className={`p-3 text-sm font-bold ${isViolation ? 'text-red-400' : 'text-emerald-400'}`}>
                    {evt.eventType}
                  </td>
                  <td className="p-3 text-sm font-mono">{evt.nodeId}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
