/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

export interface LogEntry {
  index: number;
  timestamp: number;
  previousHash: string;
  actorId: string;
  action: string;
  targetNodeId: string;
  nonce: number;
  hash: string;
}

export class ImmutableAuditLog {
  private chain: LogEntry[] = [];

  constructor() {
    // Create Genesis Block
    this.createGenesisBlock();
  }

  private createGenesisBlock(): void {
    const genesisEntry: Omit<LogEntry, 'hash'> = {
      index: 0,
      timestamp: Date.now(),
      previousHash: '0'.repeat(64),
      actorId: 'SYSTEM',
      action: 'GENESIS',
      targetNodeId: 'ROOT',
      nonce: 0
    };
    const hash = this.calculateHash(genesisEntry);
    this.chain.push({ ...genesisEntry, hash });
  }

  private calculateHash(entry: Omit<LogEntry, 'hash'>): string {
    const dataString = `${entry.index}:${entry.timestamp}:${entry.previousHash}:${entry.actorId}:${entry.action}:${entry.targetNodeId}:${entry.nonce}`;
    return crypto.createHash('sha256').update(dataString).digest('hex');
  }

  public async appendEntry(actorId: string, action: string, targetNodeId: string): Promise<LogEntry> {
    const previousBlock = this.chain[this.chain.length - 1];
    const index = previousBlock.index + 1;
    const timestamp = Date.now();
    const previousHash = previousBlock.hash;
    const nonce = Math.floor(Math.random() * 1000000);

    const newEntryData = { index, timestamp, previousHash, actorId, action, targetNodeId, nonce };
    const hash = this.calculateHash(newEntryData);

    const fullEntry: LogEntry = { ...newEntryData, hash };
    this.chain.push(fullEntry);
    return fullEntry;
  }

  public verifyChainIntegrity(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      // Validate cryptographic linkage
      if (currentBlock.previousHash !== previousBlock.hash) {
        return false;
      }

      // Recalculate hash to verify contents haven't been tampered with
      const { hash, ...blockData } = currentBlock;
      const recalculatedHash = this.calculateHash(blockData);
      if (recalculatedHash !== hash) {
        return false;
      }
    }
    return true;
  }
}
