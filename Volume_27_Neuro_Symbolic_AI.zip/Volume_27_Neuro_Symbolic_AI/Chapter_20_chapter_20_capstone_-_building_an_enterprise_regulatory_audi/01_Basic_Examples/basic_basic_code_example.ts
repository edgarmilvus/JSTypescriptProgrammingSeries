/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { EventEmitter } from 'events';

/**
 * Represents the severity level of a compliance or audit violation.
 */
enum ViolationSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

/**
 * Represents a raw financial transaction entering the SaaS auditing pipeline.
 */
interface TransactionPayload {
  transactionId: string;
  sourceAccount: string;
  destinationAccount: string;
  amountUSD: number;
  jurisdiction: string;
  timestamp: number;
  metadata?: Record<string, unknown>;
}

/**
 * Represents a node within the Enterprise Knowledge Graph (GraphDB abstraction).
 */
interface EntityNode {
  id: string;
  name: string;
  type: 'Individual' | 'CorporateEntity' | 'ShellCompany' | 'BankBranch';
  riskScore: number;
  sanctioned: boolean;
  jurisdiction: string;
}

/**
 * Represents a directed relationship edge in the Knowledge Graph.
 */
interface EntityEdge {
  sourceId: string;
  targetId: string;
  relationshipType: 'OWNS' | 'DIRECTS' | 'TRANSACTS_WITH' | 'SUBSIDIARY_OF';
  ownershipPercentage?: number;
}

/**
 * The deterministic audit result structure ensuring zero-hallucination tracking.
 */
interface AuditVerdict {
  transactionId: string;
  isCompliant: boolean;
  deterministicRulesChecked: string[];
  violations: Array<{
    ruleId: string;
    description: string;
    severity: ViolationSeverity;
  }>;
  executionTimeMs: number;
  timestamp: number;
}

/**
 * Mock Enterprise Graph Database for resolving entity relationships and ultimate beneficial ownership (UBO).
 */
class EnterpriseGraphDatabase {
  private nodes: Map<string, EntityNode> = new Map();
  private edges: EntityEdge[] = [];

  constructor() {
    // Seed initial graph data representing corporate structures and sanctioned entities
    this.nodes.set('ACC-001', {
      id: 'ACC-001',
      name: 'Alpha Global Corp',
      type: 'CorporateEntity',
      riskScore: 0.1,
      sanctioned: false,
      jurisdiction: 'US'
    });

    this.nodes.set('ACC-002', {
      id: 'ACC-002',
      name: 'Shadow Holdings LLC',
      type: 'ShellCompany',
      riskScore: 0.85,
      sanctioned: true,
      jurisdiction: 'KY' // Cayman Islands
    });

    this.nodes.set('ACC-003', {
      id: 'ACC-003',
      name: 'Beta Industrial Ltd',
      type: 'CorporateEntity',
      riskScore: 0.2,
      sanctioned: false,
      jurisdiction: 'DE'
    });

    this.edges.push({
      sourceId: 'ACC-001',
      targetId: 'ACC-002',
      relationshipType: 'SUBSIDIARY_OF',
      ownershipPercentage: 51.0
    });
  }

  /**
   * Retrieves an entity node by its identifier.
   */
  public async getNode(id: string): Promise<EntityNode | null> {
    // Simulating non-blocking I/O latency to a remote graph database cluster
    return new Promise((resolve) => {
      setImmediate(() => {
        resolve(this.nodes.get(id) || null);
      });
    });
  }

  /**
   * Evaluates if a path exists between two entities via graph traversal (e.g., UBO checks).
   */
  public async hasSanctionedPath(startId: string, maxDepth: number = 3): Promise<boolean> {
    return new Promise((resolve) => {
      setImmediate(() => {
        const visited = new Set<string>();
        const queue: Array<{ id: string; depth: number }> = [{ id: startId, depth: 0 }];

        while (queue.length > 0) {
          const current = queue.shift()!;
          if (visited.has(current.id)) continue;
          visited.add(current.id);

          const node = this.nodes.get(current.id);
          if (node && node.sanctioned) {
            resolve(true);
            return;
          }

          if (current.depth < maxDepth) {
            const outgoing = this.edges.filter(e => e.sourceId === current.id);
            for (const edge of outgoing) {
              if (!visited.has(edge.targetId)) {
                queue.push({ id: edge.targetId, depth: current.depth + 1 });
              }
            }
          }
        }
        resolve(false);
      });
    });
  }
}

/**
 * Deterministic Compliance Solver implementing hard regulatory invariants.
 */
class ComplianceSolver {
  private graphDb: EnterpriseGraphDatabase;

  constructor(graphDb: EnterpriseGraphDatabase) {
    this.graphDb = graphDb;
  }

  /**
   * Evaluates a transaction against strict deterministic regulatory rules.
   * This layer operates without probabilistic generation (zero hallucination).
   */
  public async evaluateTransaction(tx: TransactionPayload): Promise<AuditVerdict> {
    const startTime = performance.now();
    const rulesChecked: string[] = [];
    const violations: Array<{ ruleId: string; description: string; severity: ViolationSeverity }> = [];

    // Rule 1: Threshold reporting limit (Bank Secrecy Act / AML invariant)
    rulesChecked.push('RULE-AML-01-THRESHOLD');
    if (tx.amountUSD > 10000) {
      // Check if metadata contains mandatory reporting flags
      if (!tx.metadata || !tx.metadata['amlReportFiled']) {
        violations.push({
          ruleId: 'RULE-AML-01-THRESHOLD',
          description: `Transaction amount $${tx.amountUSD} exceeds $10,000 threshold without prior AML filing tag.`,
          severity: ViolationSeverity.MEDIUM
        });
      }
    }

    // Rule 2: Direct or Indirect Sanctioned Entity Check via Knowledge Graph
    rulesChecked.push('RULE-OFAC-02-UBO-SANCTION');
    const sourceNode = await this.graphDb.getNode(tx.sourceAccount);
    const destNode = await this.graphDb.getNode(tx.destinationAccount);

    if (sourceNode?.sanctioned || destNode?.sanctioned) {
      violations.push({
        ruleId: 'RULE-OFAC-02-UBO-SANCTION',
        description: `Direct transaction involvement with a sanctioned entity (Source: ${tx.sourceAccount}, Dest: ${tx.destinationAccount}).`,
        severity: ViolationSeverity.CRITICAL
      });
    } else {
      // Perform deeper graph traversal for Ultimate Beneficial Ownership (UBO) taint
      const sourceTainted = await this.graphDb.hasSanctionedPath(tx.sourceAccount);
      const destTainted = await this.graphDb.hasSanctionedPath(tx.destinationAccount);

      if (sourceTainted || destTainted) {
        violations.push({
          ruleId: 'RULE-OFAC-02-UBO-SANCTION',
          description: `Indirect ownership link detected to a sanctioned entity through corporate graph traversal.`,
          severity: ViolationSeverity.HIGH
        });
      }
    }

    // Rule 3: High-Risk Jurisdiction Cross-Border check
    rulesChecked.push('RULE-GEO-03-JURISDICTION');
    const highRiskJurisdictions = ['KY', 'PA', 'IR', 'NK']; // Cayman Islands, Panama, Iran, North Korea
    if (highRiskJurisdictions.includes(tx.jurisdiction)) {
      violations.push({
        ruleId: 'RULE-GEO-03-JURISDICTION',
        description: `Transaction originates from or terminates in high-risk monitored jurisdiction: ${tx.jurisdiction}.`,
        severity: ViolationSeverity.HIGH
      });
    }

    const endTime = performance.now();

    return {
      transactionId: tx.transactionId,
      isCompliant: violations.length === 0,
      deterministicRulesChecked: rulesChecked,
      violations,
      executionTimeMs: Number((endTime - startTime).toFixed(3)),
      timestamp: Date.now()
    };
  }
}

/**
 * Enterprise Audit Pipeline Orchestrator demonstrating non-blocking execution and event dispatching.
 */
class AuditPipelineOrchestrator extends EventEmitter {
  private solver: ComplianceSolver;

  constructor(solver: ComplianceSolver) {
    super();
    this.solver = solver;
  }

  /**
   * Ingests and processes incoming financial transactions asynchronously.
   */
  public async processStream(transactions: TransactionPayload[]): Promise<AuditVerdict[]> {
    const verdicts: AuditVerdict[] = [];

    // Utilizing non-blocking asynchronous mapping across the transaction batch
    const auditPromises = transactions.map(async (tx) => {
      this.emit('transaction:received', tx);
      const verdict = await this.solver.evaluateTransaction(tx);
      this.emit('transaction:audited', verdict);
      return verdict;
    });

    for (const promise of auditPromises) {
      verdicts.push(await promise);
    }

    return verdicts;
  }
}

// ==========================================
// Execution Demonstration (SaaS Pipeline)
// ==========================================
async function runDemo() {
  const graphDb = new EnterpriseGraphDatabase();
  const solver = new ComplianceSolver(graphDb);
  const orchestrator = new AuditPipelineOrchestrator(solver);

  orchestrator.on('transaction:received', (tx) => {
    console.log(`[Ingest] Processing transaction ${tx.transactionId} for $${tx.amountUSD}`);
  });

  orchestrator.on('transaction:audited', (verdict) => {
    console.log(`[Audit] Verdict for ${verdict.transactionId}: Compliant = ${verdict.isCompliant} (${verdict.executionTimeMs}ms)`);
  });

  const sampleTransactions: TransactionPayload[] = [
    {
      transactionId: 'TXN-9981',
      sourceAccount: 'ACC-001', // Alpha Global Corp (subsidiary of Shadow Holdings LLC)
      destinationAccount: 'ACC-003', // Beta Industrial Ltd
      amountUSD: 15000,
      jurisdiction: 'US',
      timestamp: Date.now(),
      metadata: { amlReportFiled: false }
    },
    {
      transactionId: 'TXN-9982',
      sourceAccount: 'ACC-003',
      destinationAccount: 'ACC-002', // Shadow Holdings LLC (Sanctioned)
      amountUSD: 5000,
      jurisdiction: 'KY',
      timestamp: Date.now()
    }
  ];

  console.log('--- Starting Enterprise Regulatory Audit Pipeline ---');
  const results = await orchestrator.processStream(sampleTransactions);
  console.log('--- Final Audit Summary ---');
  console.log(JSON.stringify(results, null, 2));
}

// Execute the simulation
runDemo().catch(console.error);
