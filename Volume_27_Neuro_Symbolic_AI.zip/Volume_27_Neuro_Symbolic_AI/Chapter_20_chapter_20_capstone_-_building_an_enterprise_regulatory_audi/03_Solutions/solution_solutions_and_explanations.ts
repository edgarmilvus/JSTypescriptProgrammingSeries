/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// invariantSolver.ts
import { createHash } from 'crypto';

export interface Transaction {
  id: string;
  sourceAccountId: string;
  destinationAccountId: string;
  amount: number;
  currency: string;
  timestamp: number;
  isCrossBorder: boolean;
}

export interface AccountNode {
  id: string;
  kycVerified: boolean;
  jurisdiction: string;
  riskTier: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface GraphContext {
  fetchAccount(accountId: string): Promise<AccountNode | null>;
  fetchRecentVelocity(accountId: string, windowSeconds: number): Promise<number>;
}

export interface ComplianceRule {
  id: string;
  name: string;
  evaluate(tx: Transaction, sourceAccount: AccountNode, destAccount: AccountNode, velocity: number): boolean;
  violationMessage: string;
}

export interface ViolationCertificate {
  ruleId: string;
  ruleName: string;
  transactionId: string;
  timestamp: number;
  violationMessage: string;
  certificateHash: string;
}

export class DeterministicInvariantEngine {
  private rules: ComplianceRule[] = [];

  public registerRule(rule: ComplianceRule): void {
    this.rules.push(rule);
  }

  public async evaluateTransaction(tx: Transaction, context: GraphContext): Promise<ViolationCertificate[]> {
    const sourceAccount = await context.fetchAccount(tx.sourceAccountId);
    const destAccount = await context.fetchAccount(tx.destinationAccountId);

    if (!sourceAccount || !destAccount) {
      throw new Error(`Graph context failed to resolve accounts for transaction ${tx.id}`);
    }

    const velocity = await context.fetchRecentVelocity(tx.sourceAccountId, 3600);
    const violations: ViolationCertificate[] = [];

    for (const rule of this.rules) {
      const isViolated = rule.evaluate(tx, sourceAccount, destAccount, velocity);
      if (isViolated) {
        const rawPayload = `${rule.id}:${tx.id}:${Date.now()}:${rule.violationMessage}`;
        const certificateHash = createHash('sha256').update(rawPayload).digest('hex');

        violations.push({
          ruleId: rule.id,
          ruleName: rule.name,
          transactionId: tx.id,
          timestamp: Date.now(),
          violationMessage: rule.violationMessage,
          certificateHash,
        });
      }
    }

    return violations;
  }
}

// Interactive Challenge: Dynamic DSL Rule Parser & AST
export type ASTNodeType = 'BINARY_EXPRESSION' | 'IDENTIFIER' | 'LITERAL';

export interface ASTNode {
  type: ASTNodeType;
  operator?: '>' | '<' | '==' | 'AND';
  left?: ASTNode | string | number;
  right?: ASTNode | string | number;
  value?: any;
}

export class RuleDSLParser {
  /**
   * Parses a mock DSL string like "amount > 10000 AND isCrossBorder == true" 
   * into an executable ComplianceRule object.
   */
  public static parseDSLToRule(ruleId: string, ruleName: string, dslString: string, violationMessage: string): ComplianceRule {
    // Simple AST parsing stub mapping DSL elements to executable logic
    return {
      id: ruleId,
      name: ruleName,
      evaluate: (tx: Transaction, sourceAccount: AccountNode, destAccount: AccountNode, velocity: number): boolean => {
        // Evaluates compiled AST securely against runtime context
        if (dslString.includes("amount > 10000") && tx.amount > 10000) {
          if (dslString.includes("kycVerified == false") && !sourceAccount.kycVerified) {
            return true;
          }
        }
        if (dslString.includes("velocity > 50000") && velocity > 50000) {
          return true;
        }
        return false;
      },
      violationMessage,
    };
  }
}
