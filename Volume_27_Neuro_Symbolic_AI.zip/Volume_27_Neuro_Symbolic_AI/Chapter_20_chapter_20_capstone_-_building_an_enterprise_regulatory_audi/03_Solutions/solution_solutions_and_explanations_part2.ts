/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// fraudQueryBuilder.ts
export interface QueryDefinition {
  queryString: string;
  parameters: Record<string, any>;
  expectedReturnType: string;
}

export interface AccountNode {
  id: string;
  taxIdHash: string;
  riskScore?: number;
}

export class GraphQueryBuilder {
  private ontologySchema: Record<string, any>;

  constructor(ontologySchema: Record<string, any>) {
    this.ontologySchema = ontologySchema;
  }

  public matchCircularTransactions(accountNodeId: string, maxDepth: number): QueryDefinition {
    const safeDepth = Math.max(1, Math.min(maxDepth, 5));
    const queryString = `
      MATCH path = (a:Account {id: $accountNodeId})-[:TRANSACT*1..${safeDepth}]->(a)
      RETURN path, length(path) as depth
      ORDER BY depth ASC
      LIMIT 50;
    `;

    return {
      queryString,
      parameters: { accountNodeId },
      expectedReturnType: 'GraphPathList',
    };
  }

  public matchSyntheticIdentityCluster(taxIdHash: string): QueryDefinition {
    const queryString = `
      MATCH (s:SyntheticaIdentity {taxIdHash: $taxIdHash})<-[:SHARED_ATTRIBUTE]-(acc:Account)
      RETURN acc.id as accountId, acc.riskTier as riskTier
    `;

    return {
      queryString,
      parameters: { taxIdHash },
      expectedReturnType: 'AccountClusterList',
    };
  }

  // Interactive Challenge: Weighted Risk Scoring Heuristic Extension
  public addRiskHeuristicWeight(
    query: QueryDefinition, 
    weightFunction: (node: AccountNode) => number
  ): QueryDefinition & { compiledAST: Record<string, any> } {
    const mockNode: AccountNode = { id: 'AST_EVAL_NODE', taxIdHash: '0x000' };
    const calculatedWeight = weightFunction(mockNode);

    const enhancedQueryString = `${query.queryString}
      // HEURISTIC_WEIGHT_APPLIED: ${calculatedWeight}
    `;

    return {
      ...query,
      queryString: enhancedQueryString,
      parameters: {
        ...query.parameters,
        _appliedHeuristicWeight: calculatedWeight,
      },
      expectedReturnType: `${query.expectedReturnType}WithWeightedHeuristics`,
      compiledAST: {
        type: 'QueryPlanAST',
        baseQuery: query.queryString,
        weightFunctionSource: weightFunction.toString(),
        evalWeight: calculatedWeight,
      },
    };
  }
}
