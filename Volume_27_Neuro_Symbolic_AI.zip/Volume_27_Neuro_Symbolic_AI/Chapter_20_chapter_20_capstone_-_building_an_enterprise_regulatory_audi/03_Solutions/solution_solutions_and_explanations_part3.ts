/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// auditPipeline.ts
import { StateGraph, END } from "@langchain/langgraph";
import { Transaction, GraphContext, ViolationCertificate, DeterministicInvariantEngine } from "./invariantSolver.js";
import { createHmac } from "crypto";

export interface PipelineState {
  transaction: Transaction;
  context: GraphContext;
  violations: ViolationCertificate[];
  signedCertificates: Array<ViolationCertificate & { hmacSignature: string }>;
  auditNarrative: string;
  requiresEscalation: boolean;
}

export class ZeroHallucinationAuditPipeline {
  private graph: StateGraph<any>;
  private engine: DeterministicInvariantEngine;
  private hmacSecret: string;

  constructor(engine: DeterministicInvariantEngine, hmacSecret: string) {
    this.engine = engine;
    this.hmacSecret = hmacSecret;
    this.graph = new StateGraph<PipelineState>({
      channels: {
        transaction: { value: (x: any, y: any) => y ?? x, default: () => ({} as Transaction) },
        context: { value: (x: any, y: any) => y ?? x, default: () => ({} as GraphContext) },
        violations: { value: (x: any, y: any) => y ?? x, default: () => [] },
        signedCertificates: { value: (x: any, y: any) => y ?? x, default: () => [] },
        auditNarrative: { value: (x: any, y: any) => y ?? x, default: () => "" },
        requiresEscalation: { value: (x: any, y: any) => y ?? x, default: () => false },
      }
    });

    this.buildPipeline();
  }

  private buildPipeline(): void {
    // Node 1: Deterministic Solver
    this.graph.addNode("DeterministicSolverNode", async (state: PipelineState) => {
      const violations = await this.engine.evaluateTransaction(state.transaction, state.context);
      return {
        violations,
        requiresEscalation: violations.length > 0,
      };
    });

    // Interactive Challenge Node: Cryptographic Signing Interceptor
    this.graph.addNode("VerificationInterceptorNode", async (state: PipelineState) => {
      const signedCertificates = state.violations.map(cert => {
        const hmacSignature = createHmac('sha256', this.hmacSecret)
          .update(cert.certificateHash)
          .digest('hex');
        return { ...cert, hmacSignature };
      });
      return { signedCertificates };
    });

    // Node 2: Audit Narrator (Strict Zero-Hallucination LLM Boundary)
    this.graph.addNode("AuditNarratorNode", async (state: PipelineState) => {
      const summaryLines = state.signedCertificates.map(
        c => `Rule Violation [${c.ruleName}]: ${c.violationMessage} (Sig: ${c.hmacSignature.substring(0, 8)}...)`
      );
      const auditNarrative = `AUTOMATED AUDIT SUMMARY:\n${summaryLines.join('\n')}`;
      return { auditNarrative };
    });

    // Edges & Conditional Routing
    this.graph.addEdge("DeterministicSolverNode", "VerificationInterceptorNode");
    
    this.graph.addConditionalEdges(
      "VerificationInterceptorNode",
      (state: PipelineState) => (state.requiresEscalation ? "narrate" : "terminate"),
      {
        narrate: "AuditNarratorNode",
        terminate: END,
      }
    );

    this.graph.addEdge("AuditNarratorNode", END);
    this.graph.setEntryPoint("DeterministicSolverNode");
  }

  public compile() {
    return this.graph.compile();
  }
}
