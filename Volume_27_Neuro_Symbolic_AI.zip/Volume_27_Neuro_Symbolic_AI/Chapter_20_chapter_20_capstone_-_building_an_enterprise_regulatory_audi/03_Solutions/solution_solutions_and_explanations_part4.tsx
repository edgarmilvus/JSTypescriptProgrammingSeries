/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// RegulatoryAuditWorkbench.tsx
import React, { useState, useEffect } from 'react';

export interface ViolationCertificate {
  ruleId: string;
  ruleName: string;
  transactionId: string;
  timestamp: number;
  violationMessage: string;
  certificateHash: string;
  hmacSignature?: string;
}

export interface TransactionAlert {
  id: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'VERIFIED_VIOLATION' | 'OVERRIDDEN';
  certificate: ViolationCertificate;
  narrative?: string;
}

export interface AuditWorkbenchProps {
  initialAlerts: TransactionAlert[];
  websocketEndpoint: string;
  onOverrideAction: (alertId: string, justification: string) => Promise<void>;
}

export const RegulatoryAuditWorkbench: React.FC<AuditWorkbenchProps> = ({
  initialAlerts,
  websocketEndpoint,
  onOverrideAction,
}) => {
  const [alerts, setAlerts] = useState<TransactionAlert[]>(initialAlerts);
  const [selectedAlert, setSelectedAlert] = useState<TransactionAlert | null>(null);
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [justificationInput, setJustificationInput] = useState<string>('');
  const [recentPulseId, setRecentPulseId] = useState<string | null>(null);

  // Interactive Challenge: Real-time WebSocket Subscription Hook
  useEffect(() => {
    const ws = new WebSocket(websocketEndpoint);
    ws.onmessage = (event) => {
      try {
        const newAlert: TransactionAlert = JSON.parse(event.data);
        setAlerts((prev) => [newAlert, ...prev]);
        if (newAlert.severity === 'CRITICAL') {
          setRecentPulseId(newAlert.id);
          setTimeout(() => setRecentPulseId(null), 3000); // Remove pulse after 3s
        }
      } catch (err) {
        console.error("Failed to parse incoming WS violation event:", err);
      }
    };
    return () => ws.close();
  }, [websocketEndpoint]);

  const filteredAlerts = alerts.filter(
    (alert) => severityFilter === 'ALL' || alert.severity === severityFilter
  );

  const handleOverrideSubmit = async () => {
    if (!selectedAlert || !justificationInput.trim()) return;
    await onOverrideAction(selectedAlert.id, justificationInput);
    setAlerts((prev) =>
      prev.map((a) => (a.id === selectedAlert.id ? { ...a, status: 'OVERRIDDEN' } : a))
    );
    setSelectedAlert(null);
    setJustificationInput('');
  };

  return (
    <div className="p-6 bg-slate-900 text-slate-100 min-h-screen font-mono">
      <header className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold tracking-wider text-cyan-400">ENTERPRISE REGULATORY AUDIT WORKBENCH</h1>
        <div>
          <label className="text-sm mr-2 text-slate-400">Filter Severity:</label>
          <select 
            className="bg-slate-800 border border-slate-700 p-1 text-slate-200 rounded"
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
          >
            <option value="ALL">ALL</option>
            <option value="LOW">LOW</option>
            <option value="MEDIUM">MEDIUM</option>
            <option value="HIGH">HIGH</option>
            <option value="CRITICAL">CRITICAL</option>
          </select>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-6">
        {/* Data Grid */}
        <div className="col-span-2 bg-slate-800 rounded-lg p-4 border border-slate-700 overflow-y-auto max-h-[700px]">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-700 text-slate-400 text-sm">
                <th className="p-2">ID</th>
                <th className="p-2">Severity</th>
                <th className="p-2">Status</th>
                <th className="p-2">Rule</th>
              </tr>
            </thead>
            <tbody>
              {filteredAlerts.map((alert) => {
                const isPulse = recentPulseId === alert.id;
                return (
                  <tr 
                    key={alert.id}
                    onClick={() => setSelectedAlert(alert)}
                    className={`cursor-pointer border-b border-slate-700/50 transition-colors hover:bg-slate-700/50 ${
                      isPulse ? 'animate-pulse bg-cyan-900/50' : ''
                    }`}
                  >
                    <td className="p-2 text-xs">{alert.id}</td>
                    <td className="p-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        alert.severity === 'CRITICAL' ? 'bg-red-900 text-red-200' :
                        alert.severity === 'HIGH' ? 'bg-orange-900 text-orange-200' : 'bg-blue-900 text-blue-200'
                      }`}>
                        {alert.severity}
                      </span>
                    </td>
                    <td className="p-2 text-xs text-slate-300">{alert.status}</td>
                    <td className="p-2 text-xs text-cyan-300">{alert.certificate.ruleName}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Detailed Inspection Drawer */}
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700 flex flex-col justify-between">
          {selectedAlert ? (
            <div>
              <h2 className="text-lg font-bold text-cyan-300 mb-2">Inspection Drawer</h2>
              <div className="text-xs space-y-2 text-slate-300 mb-4">
                <p><strong>Tx ID:</strong> {selectedAlert.certificate.transactionId}</p>
                <p><strong>Rule:</strong> {selectedAlert.certificate.ruleName}</p>
                <p><strong>Message:</strong> {selectedAlert.certificate.violationMessage}</p>
                <p className="break-all"><strong>Cert Hash:</strong> {selectedAlert.certificate.certificateHash}</p>
                {selectedAlert.certificate.hmacSignature && (
                  <p className="break-all text-emerald-400"><strong>HMAC:</strong> {selectedAlert.certificate.hmacSignature}</p>
                )}
              </div>
              <div className="bg-slate-900 p-3 rounded border border-slate-700 mb-4 text-xs text-slate-200">
                <p className="font-semibold text-slate-400 mb-1">Audit Narrative:</p>
                {selectedAlert.narrative || "No narrative generated."}
              </div>
              <div className="space-y-2">
                <label className="text-xs text-slate-400">Mandatory Justification for Override:</label>
                <textarea 
                  className="w-full bg-slate-900 border border-slate-700 p-2 text-xs text-slate-100 rounded"
                  rows={3}
                  value={justificationInput}
                  onChange={(e) => setJustificationInput(e.target.value)}
                  placeholder="Enter explicit regulatory justification..."
                />
                <button 
                  onClick={handleOverrideSubmit}
                  className="w-full bg-red-700 hover:bg-red-600 text-white font-bold py-2 rounded text-xs tracking-wider"
                >
                  DISPATCH HUMAN OVERRIDE
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500 text-sm">
              Select an alert to inspect violation certificate & audit narrative.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
