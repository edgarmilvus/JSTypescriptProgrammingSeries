/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// PATTERN: Branded Types enforcing Ubiquitous Language boundaries
// This code ensures that domain concepts are structurally distinct at compile time.

declare const __brand: unique symbol;

type Brand<T, TBrand> = T & { [__brand]: TBrand };

// Domain Primitives explicitly defined in the Ubiquitous Language
type CustomerEmail = Brand<string, "CustomerEmail">;
type OrderId = Brand<string, "OrderId">;

// Factory function acting as a Type Guard / Constructor for CustomerEmail
function createCustomerEmail(input: string): CustomerEmail {
    if (!input.includes("@") || input.length < 5) {
        throw new Error(`Invalid domain concept: '${input}' is not a valid CustomerEmail.`);
    }
    return input as CustomerEmail;
}

function createOrderId(input: string): OrderId {
    if (!input.startsWith("ORD-")) {
        throw new Error(`Invalid domain concept: '${input}' is not a valid OrderId.`);
    }
    return input as OrderId;
}

function sendShippingConfirmation(email: CustomerEmail, orderId: OrderId): void {
    // Business logic guaranteed to receive valid domain concepts
}

const validEmail = createCustomerEmail("user@example.com");
const validOrderId = createOrderId("ORD-12345");

// SUCCESS: Compiles correctly because types match the Ubiquitous Language contract
sendShippingConfirmation(validEmail, validOrderId);

// COMPILE ERROR: Prevents primitive obsession bugs instantly!
// sendShippingConfirmation(validOrderId, validEmail);
