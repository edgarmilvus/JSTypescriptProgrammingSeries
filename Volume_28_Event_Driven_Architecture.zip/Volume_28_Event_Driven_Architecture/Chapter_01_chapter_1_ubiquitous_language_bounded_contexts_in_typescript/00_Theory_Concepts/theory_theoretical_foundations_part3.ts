/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// PATTERN: Rich Domain Model with Encapsulated Invariants
// The entity protects its own state, preventing invalid business transitions.

type OrderStatus = "Pending" | "Paid" | "Shipped" | "Cancelled";

interface LineItem {
    readonly sku: string;
    readonly quantity: number;
    readonly unitPrice: number;
}

export class Order {
    private constructor(
        public readonly id: OrderId,
        private status: OrderStatus,
        private readonly lineItems: ReadonlyArray<LineItem>
    ) {}

    public static createNew(id: OrderId, initialItems: LineItem[]): Order {
        if (initialItems.length === 0) {
            throw new Error("An order must contain at least one line item.");
        }
        return new Order(id, "Pending", [...initialItems]);
    }

    public markAsPaid(): void {
        if (this.status !== "Pending") {
            throw new Error(`Cannot pay for an order that is currently in status: ${this.status}`);
        }
        this.status = "Paid";
    }

    public ship(): void {
        if (this.status !== "Paid") {
            throw new Error("Violation of domain invariant: Cannot ship an order that has not been paid.");
        }
        this.status = "Shipped";
    }

    public getStatus(): OrderStatus {
        return this.status;
    }

    public getTotalAmount(): number {
        return this.lineItems.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0);
    }
}
