/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Billing Context Basic Code Example
 * Demonstrates a self-contained domain model implementing explicit type branding 
 * to enforce Ubiquitous Language boundaries in TypeScript.
 */

namespace BillingContext {
    /**
     * A branded string type representing a unique identifier for a billing customer.
     * Using an intersection type prevents structural compatibility with arbitrary strings 
     * or IDs from other bounded contexts (e.g., IdentityContext).
     */
    export type CustomerId = string & { readonly __brand: unique symbol };

    /**
     * Factory function to safely parse and cast a raw string into a branded CustomerId.
     * Enforces domain validation rules at the boundary of our system.
     * 
     * @param id - The raw string representation of the customer ID.
     * @returns A validated, branded CustomerId.
     */
    export function createCustomerId(id: string): CustomerId {
        if (!id || id.trim().length === 0 || !id.startsWith('cust_')) {
            throw new Error('Invalid Ubiquitous Language violation: CustomerId must start with "cust_".');
        }
        return id as CustomerId;
    }

    /**
     * Represents the monetary value associated with an invoice or subscription plan.
     * Encapsulates the currency and amount to prevent floating-point arithmetic errors.
     */
    export interface Money {
        readonly amountInCents: number;
        readonly currency: 'USD' | 'EUR' | 'GBP';
    }

    /**
     * The core aggregate root for the Billing Bounded Context.
     * Represents a customer who is actively subscribed to a SaaS tier.
     */
    export interface SubscribedCustomer {
        readonly id: CustomerId;
        readonly email: string;
        readonly monthlyRate: Money;
        isActive: boolean;
    }

    /**
     * Domain service responsible for executing a monthly billing cycle check.
     * Implements business logic strictly using the Billing Context's Ubiquitous Language.
     * 
     * @param customer - The target subscriber.
     * @returns A boolean indicating if the charge was successfully queued.
     */
    export function processMonthlyRenewal(customer: SubscribedCustomer): boolean {
        if (!customer.isActive) {
            console.warn(`[Billing] Renewal skipped: Customer ${customer.id} is inactive.`);
            return false;
        }

        // Simulating charge dispatch logic
        console.log(`[Billing] Charging ${customer.email} the amount of ${customer.monthlyRate.amountInCents / 100} ${customer.monthlyRate.currency}.`);
        return true;
    }
}

// ==========================================
// Execution Simulation
// ==========================================

try {
    // 1. Create a valid branded customer ID using domain factory methods
    const validId = BillingContext.createCustomerId('cust_9823471');

    // 2. Instantiate our aggregate root matching the domain interface
    const subscriber: BillingContext.SubscribedCustomer = {
        id: validId,
        email: 'enterprise-client@saasprovider.com',
        monthlyRate: {
            amountInCents: 49900, // $499.00 USD
            currency: 'USD'
        },
        isActive: true
    };

    // 3. Execute domain behavior
    BillingContext.processMonthlyRenewal(subscriber);

    // 4. Attempting to pass an unbranded raw string will throw a compile-time type error:
    // const brokenSubscriber: BillingContext.SubscribedCustomer = {
    //     id: 'cust_123', // Type 'string' is not assignable to type 'CustomerId'
    //     ...
    // };

} catch (error: unknown) {
    if (error instanceof Error) {
        console.error(`Domain Error Caught: ${error.message}`);
    }
}
