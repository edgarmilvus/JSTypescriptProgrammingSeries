/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * ============================================================================
 * 1. BRANDED TYPES & VALUE OBJECTS (Ubiquitous Language Enforcement)
 * ============================================================================
 * We use TypeScript branded types to prevent primitive obsession. 
 * A TenantId is fundamentally different from a SubscriptionId, even though both 
 * are represented at runtime as strings. Passing one where the other is expected 
 * will result in a compile-time error.
 */

declare const __brand: unique symbol;
type Branded<T, TBrand> = T & { readonly [__brand]: TBrand };

export type TenantId = Branded<string, 'TenantId'>;
export type SubscriptionId = Branded<string, 'SubscriptionId'>;
export type EmailAddress = Branded<string, 'EmailAddress'>;

export function createTenantId(id: string): TenantId {
    if (!id || id.trim().length === 0) {
        throw new Error('Invalid TenantId: Must not be empty.');
    }
    return id as TenantId;
}

export function createSubscriptionId(id: string): SubscriptionId {
    if (!id || id.trim().length === 0) {
        throw new Error('Invalid SubscriptionId: Must not be empty.');
    }
    return id as SubscriptionId;
}

export function createEmailAddress(email: string): EmailAddress {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        throw new Error(`Invalid EmailAddress format: ${email}`);
    }
    return email as EmailAddress;
}

/**
 * ============================================================================
 * 2. DOMAIN ENUMS & TYPES (Bounded Context Vocabulary)
 * ============================================================================
 */
export enum SubscriptionTier {
    STARTER = 'STARTER',
    PROFESSIONAL = 'PROFESSIONAL',
    ENTERPRISE = 'ENTERPRISE'
}

export enum SubscriptionStatus {
    TRIAL = 'TRIAL',
    ACTIVE = 'ACTIVE',
    PAST_DUE = 'PAST_DUE',
    SUSPENDED = 'SUSPENDED',
    TERMINATED = 'TERMINATED'
}

/**
 * Interface representing the structural capabilities granted by a tier.
 */
export interface TierCapabilities {
    readonly maxWebhooks: number;
    readonly customCryptoEnabled: boolean;
    readonly dataResidencyRegion: 'US' | 'EU' | 'APAC';
}

export const TIER_CONFIGURATIONS: Record<SubscriptionTier, TierCapabilities> = {
    [SubscriptionTier.STARTER]: {
        maxWebhooks: 5,
        customCryptoEnabled: false,
        dataResidencyRegion: 'US'
    },
    [SubscriptionTier.PROFESSIONAL]: {
        maxWebhooks: 50,
        customCryptoEnabled: true,
        dataResidencyRegion: 'US'
    },
    [SubscriptionTier.ENTERPRISE]: {
        maxWebhooks: 1000,
        customCryptoEnabled: true,
        dataResidencyRegion: 'EU'
    }
};

/**
 * ============================================================================
 * 3. DOMAIN EVENTS (Event-Driven Architecture Foundation)
 * ============================================================================
 */
export interface DomainEvent<TType extends string, TPayload> {
    readonly eventId: string;
    readonly occurredAt: Date;
    readonly type: TType;
    readonly payload: TPayload;
}

export type TenantSubscribedEvent = DomainEvent<
    'TenantSubscribed',
    { tenantId: TenantId; subscriptionId: SubscriptionId; tier: SubscriptionTier }
>;

export type SubscriptionSuspendedEvent = DomainEvent<
    'SubscriptionSuspended',
    { tenantId: TenantId; reason: string }
>;

export type AnyDomainEvent = TenantSubscribedEvent | SubscriptionSuspendedEvent;

/**
 * ============================================================================
 * 4. THE SUBSCRIPTION AGGREGATE (Encapsulating State & Invariants)
 * ============================================================================
 */
export interface SubscriptionState {
    readonly id: SubscriptionId;
    readonly tenantId: TenantId;
    readonly tier: SubscriptionTier;
    readonly status: SubscriptionStatus;
    readonly billingEmail: EmailAddress;
    readonly version: number;
}

export class SubscriptionAggregate {
    private state: SubscriptionState;
    private uncommittedEvents: AnyDomainEvent[] = [];

    private constructor(state: SubscriptionState) {
        this.state = state;
    }

    /**
     * Factory method to create a brand new Subscription in a Trial state.
     */
    public static createNew(
        id: SubscriptionId,
        tenantId: TenantId,
        tier: SubscriptionTier,
        billingEmail: EmailAddress
    ): SubscriptionAggregate {
        const initialState: SubscriptionState = {
            id,
            tenantId,
            tier,
            status: SubscriptionStatus.TRIAL,
            billingEmail,
            version: 1
        };

        const aggregate = new SubscriptionAggregate(initialState);
        
        // Record the domain event
        aggregate.addEvent({
            eventId: randomUUID(),
            occurredAt: new Date(),
            type: 'TenantSubscribed',
            payload: { tenantId, subscriptionId: id, tier }
        });

        return aggregate;
    }

    public get currentState(): Readonly<SubscriptionState> {
        return this.state;
    }

    public pullUncommittedEvents(): AnyDomainEvent[] {
        const events = [...this.uncommittedEvents];
        this.uncommittedEvents = [];
        return events;
    }

    private addEvent(event: AnyDomainEvent): void {
        this.uncommittedEvents.push(event);
    }

    /**
     * Business logic method enforcing state transition rules.
     * A subscription cannot be suspended if it is already terminated.
     */
    public suspend(reason: string): void {
        if (this.state.status === SubscriptionStatus.TERMINATED) {
            throw new Error(`Cannot suspend subscription ${this.state.id} because it is already terminated.`);
        }
        if (this.state.status === SubscriptionStatus.SUSPENDED) {
            return; // Idempotent no-op
        }

        this.state = {
            ...this.state,
            status: SubscriptionStatus.SUSPENDED,
            version: this.state.version + 1
        };

        this.addEvent({
            eventId: randomUUID(),
            occurredAt: new Date(),
            type: 'SubscriptionSuspended',
            payload: { tenantId: this.state.tenantId, reason }
        });
    }
}

/**
 * ============================================================================
 * 5. ADVANCED APPLICATION SCRIPT / GRAPH STATE ORCHESTRATOR
 * ============================================================================
 * This script coordinates multiple bounded services, acting as the transactional 
 * boundary for an incoming workflow request.
 */
export interface SaaSWorkflowGraphState {
    readonly executionId: string;
    readonly inputPayload: {
        rawTenantId: string;
        rawSubscriptionId: string;
        rawTier: string;
        rawEmail: string;
    };
    tenantId?: TenantId;
    subscriptionId?: SubscriptionId;
    tier?: SubscriptionTier;
    billingEmail?: EmailAddress;
    aggregate?: SubscriptionAggregate;
    capabilities?: TierCapabilities;
    emittedEvents: AnyDomainEvent[];
    errors: string[];
}

export class ProvisioningWorkflowOrchestrator {
    /**
     * Executes the workflow script step-by-step, maintaining an immutable graph state.
     */
    public async execute(initialState: SaaSWorkflowGraphState): Promise<SaaSWorkflowGraphState> {
        let currentState = { ...initialState };

        try {
            // Step 1: Anti-Corruption Layer (ACL) Validation & Parsing
            currentState = this.stepParseAndSanitizeInputs(currentState);
            if (currentState.errors.length > 0) return currentState;

            // Step 2: Instantiate Domain Aggregate
            currentState = this.stepInitializeAggregate(currentState);
            if (currentState.errors.length > 0) return currentState;

            // Step 3: Resolve Topological Capabilities
            currentState = this.stepResolveCapabilities(currentState);
            if (currentState.errors.length > 0) return currentState;

            // Step 4: Dispatch / Collect Domain Events
            currentState = this.stepCollectEvents(currentState);

        } catch (err: unknown) {
            const errorMessage = err instanceof Error ? err.message : 'Unknown execution failure';
            currentState = {
                ...currentState,
                errors: [...currentState.errors, errorMessage]
            };
        }

        return currentState;
    }

    private stepParseAndSanitizeInputs(state: SaaSWorkflowGraphState): SaaSWorkflowGraphState {
        try {
            const tenantId = createTenantId(state.inputPayload.rawTenantId);
            const subscriptionId = createSubscriptionId(state.inputPayload.rawSubscriptionId);
            const billingEmail = createEmailAddress(state.inputPayload.rawEmail);
            
            let tier: SubscriptionTier;
            if (Object.values(SubscriptionTier).includes(state.inputPayload.rawTier as SubscriptionTier)) {
                tier = state.inputPayload.rawTier as SubscriptionTier;
            } else {
                throw new Error(`Invalid SubscriptionTier provided: ${state.inputPayload.rawTier}`);
            }

            return { ...state, tenantId, subscriptionId, billingEmail, tier };
        } catch (e: unknown) {
            const msg = e instanceof Error ? e.message : 'Input validation failure';
            return { ...state, errors: [...state.errors, msg] };
        }
    }

    private stepInitializeAggregate(state: SaaSWorkflowGraphState): SaaSWorkflowGraphState {
        if (!state.tenantId || !state.subscriptionId || !state.tier || !state.billingEmail) {
            return { ...state, errors: [...state.errors, 'Missing parsed primitives for aggregate initialization.'] };
        }

        const aggregate = SubscriptionAggregate.createNew(
            state.subscriptionId,
            state.tenantId,
            state.tier,
            state.billingEmail
        );

        return { ...state, aggregate };
    }

    private stepResolveCapabilities(state: SaaSWorkflowGraphState): SaaSWorkflowGraphState {
        if (!state.tier) {
            return { ...state, errors: [...state.errors, 'Tier is required for capability resolution.'] };
        }

        const capabilities = TIER_CONFIGURATIONS[state.tier];
        return { ...state, capabilities };
    }

    private stepCollectEvents(state: SaaSWorkflowGraphState): SaaSWorkflowGraphState {
        if (!state.aggregate) {
            return { ...state, errors: [...state.errors, 'No aggregate present to pull events from.'] };
        }

        const events = state.aggregate.pullUncommittedEvents();
        return { ...state, emittedEvents: [...state.emittedEvents, ...events] };
    }
}
