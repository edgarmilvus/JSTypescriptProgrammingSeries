/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. StockId branded string schema and inferred type
export const StockIdSchema = z
  .string()
  .regex(/^STOCK-[0-9]{6}$/, "Invalid StockId format. Must match ^STOCK-[0-9]{6}$");
export type StockId = z.infer<typeof StockIdSchema>;

// 2. StockItemStatus enum schema and inferred type
export const StockItemStatusSchema = z.enum([
  'Quarantine',
  'Available',
  'Allocated',
  'Dispatched',
]);
export type StockItemStatus = z.infer<typeof StockItemStatusSchema>;

// 3. StockItem object schema and inferred type
export const StockItemSchema = z.object({
  id: StockIdSchema,
  sku: z.string().min(1, "SKU cannot be empty"),
  status: StockItemStatusSchema,
  quantity: z.number().int().positive("Quantity must be a positive integer"),
  binLocation: z.string().regex(/^[A-Z]-[0-9]{2}-[0-9]{2}$/, "Invalid bin location format"),
});
export type StockItem = z.infer<typeof StockItemSchema>;

// 4. Derived TypeScript Utility Types
export type UnassignedStockItem = Omit<StockItem, 'binLocation'>;

export type StockItemStatusUpdate = Readonly<
  Pick<StockItem, 'id' | 'status'>
>;

// 5. Infrastructure boundary parsing utility
export function parseStockItem(rawInput: unknown): StockItem {
  const result = StockItemSchema.safeParse(rawInput);
  
  if (!result.success) {
    throw new Error(
      `Domain Validation Error: Failed to parse StockItem. Details: ${JSON.stringify(
        result.error.format()
      )}`
    );
  }
  
  return result.data;
}

// --- Interactive Challenge Unit Test Demonstration ---
try {
  const invalidPayload = {
    id: "STOCK-123456",
    sku: "SKU-999",
    status: "LostInTransit", // Invalid status violating the Ubiquitous Language
    quantity: 10,
    binLocation: "A-12-04"
  };

  parseStockItem(invalidPayload);
} catch (error: any) {
  console.error(error.message); 
  // Output demonstrates a caught Zod error protecting the domain boundary
}
