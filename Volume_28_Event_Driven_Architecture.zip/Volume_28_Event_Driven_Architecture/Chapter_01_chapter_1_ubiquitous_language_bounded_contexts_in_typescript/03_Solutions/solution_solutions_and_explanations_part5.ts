/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Custom Domain Error
export class DomainInvariantViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DomainInvariantViolationError';
  }
}

// 1. Base Value Object with Structural Equality
export abstract class ValueObject<T> {
  public equals(other: T): boolean {
    if (other === null || other === undefined) {
      return false;
    }
    return JSON.stringify(this) === JSON.stringify(other);
  }
}

// 2. Email Value Object
export class Email extends ValueObject<Email> {
  public readonly value: string;

  constructor(value: string) {
    super();
    if (!value.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
      throw new DomainInvariantViolationError(`Invalid email format: ${value}`);
    }
    this.value = value;
  }
}

// 3. Address Value Object
export class Address extends ValueObject<Address> {
  constructor(
    public readonly street: string,
    public readonly city: string,
    public readonly postalCode: string,
    public readonly country: string
  ) {
    super();
  }
}

// Branded CustomerId Type
export type CustomerId = string & { readonly __brand: unique symbol };

// 4 & 5. Customer Aggregate Root
export class Customer {
  private readonly _id: CustomerId;
  private readonly _name: string;
  private _emails: Email[];
  private _domainEvents: unknown[] = []; // Placeholder for DomainEvent[]

  constructor(id: CustomerId, name: string, initialEmail: Email) {
    this._id = id;
    this._name = name;
    this._emails = [initialEmail];
  }

  public get id(): CustomerId {
    return this._id;
  }

  public get name(): string {
    return this._name;
  }

  public get emails(): ReadonlyArray<Email> {
    return [...this._emails]; // Returns a shallow clone wrapped as ReadonlyArray
  }

  public addEmail(newEmail: Email): void {
    // Enforce business invariant: Max 3 emails
    if (this._emails.length >= 3) {
      throw new DomainInvariantViolationError('A customer cannot have more than 3 active email addresses.');
    }

    if (this._emails.some(existing => existing.equals(newEmail))) {
      throw new DomainInvariantViolationError('Duplicate email addresses are not allowed.');
    }

    this._emails.push(newEmail);
  }
}

// --- Interactive Challenge Compilation Test ---
// const customer = new Customer("CUST-1" as CustomerId, "Acme Corp", new Email("test@acme.com"));
// ❌ COMPILE ERROR: Property 'push' does not exist on type 'ReadonlyArray<Email>'
// customer.emails.push(new Email("hack@acme.com")); 
