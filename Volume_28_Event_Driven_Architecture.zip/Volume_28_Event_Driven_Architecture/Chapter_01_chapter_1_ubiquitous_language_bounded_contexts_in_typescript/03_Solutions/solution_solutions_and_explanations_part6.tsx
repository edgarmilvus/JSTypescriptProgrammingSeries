/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

// 1. Domain Schemas and Inferred Types
export const ShippingOrderIdSchema = z.string().regex(/^SHIP-[0-9]{6}$/);
export type ShippingOrderId = z.infer<typeof ShippingOrderIdSchema>;

export const ShippingAddressSchema = z.object({
  street: z.string(),
  city: z.string(),
  postalCode: z.string(),
  country: z.string(),
});
export type ShippingAddress = z.infer<typeof ShippingAddressSchema>;

export const FulfilledItemSchema = z.object({
  sku: z.string(),
  quantity: z.number().int().positive(),
});
export type FulfilledItem = z.infer<typeof FulfilledItemSchema>;

export const ShippingStatusSchema = z.enum(['ReadyToPack', 'Packed', 'Dispatched', 'Flagged']);
export type ShippingStatus = z.infer<typeof ShippingStatusSchema>;

export const ShippingOrderSchema = z.object({
  orderId: ShippingOrderIdSchema,
  destination: ShippingAddressSchema,
  lineItems: z.array(FulfilledItemSchema),
  status: ShippingStatusSchema,
});
export type ShippingOrder = z.infer<typeof ShippingOrderSchema>;

// 2. Strict Event Handler Prop Type
export interface OrderFulfillmentPanelProps {
  readonly order: ShippingOrder;
  readonly onDispatchOrder: (payload: Pick<ShippingOrder, 'orderId' | 'status'>) => Promise<void>;
}

// 3. React Functional Component Implementation
export const OrderFulfillmentPanel: React.FC<OrderFulfillmentPanelProps> = ({
  order,
  onDispatchOrder,
}) => {
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleDispatchClick = async () => {
    try {
      setIsSubmitting(true);
      await onDispatchOrder({
        orderId: order.orderId,
        status: 'Dispatched',
      });
    } catch (error) {
      console.error('Failed to dispatch order', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-4 border rounded shadow">
      <h2>Order Fulfillment: {order.orderId}</h2>
      <p>
        Destination: {order.destination.street}, {order.destination.city} ({order.destination.postalCode})
      </p>
      <p>Current Status: <strong>{order.status}</strong></p>

      {/* 3. Conditional UI rule: Enabled strictly when 'Packed' */}
      <button
        onClick={handleDispatchClick}
        disabled={order.status !== 'Packed' || isSubmitting}
        className="px-4 py-2 bg-blue-600 text-white disabled:bg-gray-400"
      >
        {isSubmitting ? 'Dispatching...' : 'Dispatch Order'}
      </button>
    </div>
  );
};
