/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file user-registration.ts
 * @description Demonstrates a self-contained DDD Value Object and Entity pattern 
 * combined with Zod for runtime boundary validation and deep immutability in TypeScript.
 */

// ==========================================
// 1. ZOD SCHEMAS & BOUNDARY VALIDATION
// ==========================================

/**
 * Defines the runtime validation schema for an Email Address Value Object.
 * Enforces string formatting, lowercasing, and domain constraints.
 */
const EmailSchema = z.string()
    .email({ message: "Invalid email format supplied." })
    .transform((val) => val.toLowerCase());

/**
 * Defines the runtime validation schema for a Username Value Object.
 * Enforces alphanumeric constraints and strict length boundaries.
 */
const UsernameSchema = z.string()
    .min(3, { message: "Username must be at least 3 characters long." })
    .max(20, { message: "Username cannot exceed 20 characters." })
    .regex(/^[a-zA-Z0-9_]+$/, { message: "Username can only contain alphanumeric characters and underscores." });

/**
 * Master schema for incoming raw network payloads at the SaaS API boundary.
 */
const RegisterUserPayloadSchema = z.object({
    email: EmailSchema,
    username: UsernameSchema,
});

// Infer static TypeScript types directly from our Zod schemas
type RegisterUserPayload = z.infer<typeof RegisterUserPayloadSchema>;


// ==========================================
// 2. DOMAIN VALUE OBJECTS (Deep Immutability)
// ==========================================

/**
 * Represents an immutable Email Value Object within the domain model.
 */
export class Email {
    // Readonly modifier prevents accidental reassignment outside initialization
    public readonly value: string;

    constructor(email: string) {
        // Double-check validation at the domain boundary even if parsed by Zod
        const result = EmailSchema.safeParse(email);
        if (!result.success) {
            throw new Error(`Domain invariant violated: ${result.error.errors[0].message}`);
        }
        this.value = result.data;
        
        // Deeply freeze the object instance to prevent runtime mutations
        Object.freeze(this);
    }

    /**
     * Value Objects are structurally equal if their internal primitive values match.
     */
    public equals(other: Email): boolean {
        if (other === null || other === undefined) return false;
        return this.value === other.value;
    }
}

/**
 * Represents an immutable Username Value Object within the domain model.
 */
export class Username {
    public readonly value: string;

    constructor(username: string) {
        const result = UsernameSchema.safeParse(username);
        if (!result.success) {
            throw new Error(`Domain invariant violated: ${result.error.errors[0].message}`);
        }
        this.value = result.data;
        Object.freeze(this);
    }

    public equals(other: Username): boolean {
        if (other === null || other === undefined) return false;
        return this.value === other.value;
    }
}


// ==========================================
// 3. DOMAIN ENTITY
// ==========================================

/**
 * Represents a User Entity in the SaaS application.
 * Entities have a unique identifier and maintain state through immutable Value Objects.
 */
export class UserEntity {
    // The Entity's unique identifier is immutable
    public readonly id: string;
    
    // Internal domain state consists of immutable Value Objects
    private _email: Email;
    private _username: Username;
    public readonly createdAt: Date;

    constructor(id: string, email: Email, username: Username) {
        if (!id || id.trim().length === 0) {
            throw new Error("User Entity must be initialized with a valid identifier.");
        }
        this.id = id;
        this._email = email;
        this._username = username;
        this.createdAt = new Date(); // Date is captured at birth

        Object.freeze(this);
    }

    /**
     * Getter for email adhering to encapsulation principles.
     */
    public get email(): Email {
        return this._email;
    }

    /**
     * Getter for username.
     */
    public get username(): Username {
        return this._username;
    }

    /**
     * Immutability pattern for state transitions:
     * Instead of mutating `this._email` directly, we return a BRAND NEW UserEntity instance.
     */
    public updateEmail(newEmail: Email): UserEntity {
        return new UserEntity(
            this.id,
            newEmail,
            this._username
        );
    }
}


// ==========================================
// 4. APPLICATION BOUNDARY EXECUTION SIMULATION
// ==========================================

/**
 * Simulates an incoming SaaS API request payload from an untrusted client.
 */
const rawClientPayload = {
    email: "   Developer.One@SaaS-Platform.COM   ",
    username: "dev_guru_99"
};

try {
    console.log("Step 1: Parsing and validating raw payload at the API boundary using Zod...");
    const validatedData = RegisterUserPayloadSchema.parse(rawClientPayload);
    
    console.log("Step 2: Instantiating strongly-typed Domain Value Objects...");
    const userEmail = new Email(validatedData.email);
    const userUsername = new Username(validatedData.username);

    console.log("Step 3: Constructing the User Entity...");
    const user = new UserEntity("usr_9812739182", userEmail, userUsername);

    console.log("Successfully created user entity:", {
        id: user.id,
        email: user.email.value,
        username: user.username.value,
        createdAt: user.createdAt.toISOString()
    });

    console.log("Step 4: Demonstrating immutable state update...");
    const updatedUser = user.updateEmail(new Email("new.address@saas-platform.com"));
    
    console.log("Original User Email (Unchanged due to immutability):", user.email.value);
    console.log("Updated User Email (New Instance):", updatedUser.email.value);

    // Attempting to mutate a readonly property directly will trigger a TypeScript compilation error:
    // user.id = "hacked_id"; // Error: Cannot assign to 'id' because it is a read-only property.

} catch (error: any) {
    console.error("Validation or Domain Invariant Failed:", error.message);
}
