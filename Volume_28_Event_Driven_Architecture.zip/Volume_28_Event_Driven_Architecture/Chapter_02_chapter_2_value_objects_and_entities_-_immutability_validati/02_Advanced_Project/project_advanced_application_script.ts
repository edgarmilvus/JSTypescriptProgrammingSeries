/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';

// ============================================================================
// 1. DOMAIN PRIMITIVES & VALUE OBJECTS (Immutability & Branded Types)
// ============================================================================

/**
 * Branded type to prevent primitive obsession for Tenant Identifiers.
 */
type TenantId = string & { readonly __brand: unique symbol };

/**
 * Branded type to prevent primitive obsession for Plan Codes.
 */
type PlanCode = string & { readonly __brand: unique symbol };

/**
 * Zod schema for Money to guarantee runtime invariants (non-negative amounts).
 */
const MoneySchema = z.object({
  amount: z.number().nonnegative('Monetary amount cannot be negative.'),
  currency: z.string().length(3, 'Currency must be a valid ISO-4217 3-letter code.'),
});

type Money = z.infer<typeof MoneySchema>;

/**
 * Zod schema for Feature Flags configuration map.
 */
const FeatureFlagsSchema = z.record(z.string(), z.boolean());

type FeatureFlags = z.infer<typeof FeatureFlagsSchema>;

// ============================================================================
// 2. RUNTIME VALIDATION & INCOMING PAYLOAD SCHEMAS
// ============================================================================

/**
 * Comprehensive schema for updating a SaaS Subscription Plan.
 * This acts as our anti-corruption layer boundary validating untrusted JSON input.
 */
const UpdateSubscriptionPayloadSchema = z.object({
  tenantId: z.string().uuid('Invalid Tenant UUID format.'),
  planCode: z.string().min(2, 'Plan code must be at least 2 characters.'),
  basePrice: MoneySchema,
  features: FeatureFlagsSchema,
  maxSeats: z.number().int().positive('Max seats must be a positive integer.'),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

type UpdateSubscriptionPayload = z.infer<typeof UpdateSubscriptionPayloadSchema>;

// ============================================================================
// 3. DOMAIN ENTITY WITH DEEP IMMUTABILITY
// ============================================================================

/**
 * Represents the immutable Subscription Configuration Entity within the Domain.
 * All properties are marked readonly, and internal collections are frozen.
 */
export class SubscriptionConfig {
  public readonly tenantId: TenantId;
  public readonly planCode: PlanCode;
  public readonly basePrice: Readonly<Money>;
  public readonly features: Readonly<FeatureFlags>;
  public readonly maxSeats: number;
  public readonly updatedAt: Date;

  private constructor(
    tenantId: string,
    planCode: string,
    basePrice: Money,
    features: FeatureFlags,
    maxSeats: number
  ) {
    this.tenantId = tenantId as TenantId;
    this.planCode = planCode as PlanCode;
    
    // Deep freeze the basePrice and features objects to enforce runtime immutability
    this.basePrice = Object.freeze({ ...basePrice });
    this.features = Object.freeze({ ...features });
    
    this.maxSeats = maxSeats;
    this.updatedAt = new Date();

    // Freeze the entity instance itself to prevent property reassignment
    Object.freeze(this);
  }

  /**
   * Factory method to create an immutable SubscriptionConfig from validated raw input.
   * Enforces domain invariants prior to instantiation.
   */
  public static create(rawInput: unknown): SubscriptionConfig {
    // Step 1: Perform runtime validation using Zod
    const validationResult = UpdateSubscriptionPayloadSchema.safeParse(rawInput);

    if (!validationResult.success) {
      // In a real application, throw a custom DomainValidationException
      throw new Error(`Domain Validation Failed: ${validationResult.error.message}`);
    }

    const data = validationResult.data;

    // Step 2: Enforce additional business rule invariants
    if (data.maxSeats > 10000 && data.planCode === 'FREE') {
      throw new Error('Invariant Violation: FREE tier cannot exceed 10,000 seats.');
    }

    // Step 3: Instantiate the immutable entity
    return new SubscriptionConfig(
      data.tenantId,
      data.planCode,
      data.basePrice,
      data.features,
      data.maxSeats
    );
  }

  /**
   * Implements the "Copy-on-Write" pattern: returns a new immutable instance 
   * with updated properties rather than mutating the current state.
   */
  public updateSeats(newMaxSeats: number): SubscriptionConfig {
    if (newMaxSeats <= 0) {
      throw new Error('Seats must be greater than zero.');
    }

    return new SubscriptionConfig(
      this.tenantId,
      this.planCode,
      this.basePrice,
      { ...this.features },
      newMaxSeats
    );
  }
}

// ============================================================================
// 4. TYPE GUARDS & APPLICATION EXECUTION SERVICE
// ============================================================================

/**
 * User-defined type guard to safely check if an unknown error is an instance of Error.
 */
function isStandardError(error: unknown): error is Error {
  return error instanceof Error;
}

/**
 * SaaS Application Service simulating webhook or API request processing.
 */
export function handleSubscriptionUpdateWebhook(incomingJsonPayload: unknown): void {
  try {
    console.log('[Webhook] Received raw payload. Initiating domain boundary validation...');

    // Transform and validate untrusted input into a trusted immutable domain entity
    const subscriptionConfig = SubscriptionConfig.create(incomingJsonPayload);

    console.log(`[Domain] Subscription successfully parsed and locked for tenant: ${subscriptionConfig.tenantId}`);
    console.log(`[Domain] Current Plan: ${subscriptionConfig.planCode}, Max Seats: ${subscriptionConfig.maxSeats}`);

    // Demonstrate copy-on-write immutability behavior
    const upgradedConfig = subscriptionConfig.updateSeats(500);
    console.log(`[Domain] Upgraded seats via copy-on-write. New count: ${upgradedConfig.maxSeats}`);

    // Attempting to mutate directly will fail at compile time (readonly) and runtime (Object.freeze)
    // subscriptionConfig.maxSeats = 250; // Error: Cannot assign to 'maxSeats' because it is a read-only property.

  } catch (error: unknown) {
    if (isStandardError(error)) {
      console.error(`[Application Error] Failed to process subscription: ${error.message}`);
    } else {
      console.error('[Application Error] An unexpected non-error object was thrown:', error);
    }
  }
}

// ============================================================================
// 5. EXECUTION EXAMPLE
// ============================================================================

// Simulated incoming HTTP request body from a SaaS billing dashboard webhook
const validMockPayload = {
  tenantId: "123e4567-e89b-12d3-a456-426614174000",
  planCode: "ENTERPRISE",
  basePrice: {
    amount: 499.99,
    currency: "USD"
  },
  features: {
    sso: true,
    auditLogs: true,
    advancedAnalytics: false
  },
  maxSeats: 250,
  metadata: {
    campaign: "Q4_PROMO"
  }
};

handleSubscriptionUpdateWebhook(validMockPayload);
