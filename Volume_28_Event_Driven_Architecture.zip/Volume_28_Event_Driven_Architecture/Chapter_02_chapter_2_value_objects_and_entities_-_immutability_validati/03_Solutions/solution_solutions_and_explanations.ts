/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. UserId Value Object
export class UserId {
  private readonly value: string;

  constructor(value: string) {
    if (!UserId.isValidUuid(value)) {
      throw new Error(`Invalid UUID format for UserId: ${value}`);
    }
    this.value = value;
    Object.freeze(this);
  }

  private static isValidUuid(id: string): boolean {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(id);
  }

  public toString(): string {
    return this.value;
  }

  public equals(other: UserId): boolean {
    if (!other) return false;
    return this.value === other.value;
  }
}

// 2. Email Value Object
export class Email {
  private readonly value: string;

  constructor(value: string) {
    if (!value || !value.includes('@')) {
      throw new Error('Invalid email format');
    }
    this.value = value;
    Object.freeze(this);
  }

  public toString(): string {
    return this.value;
  }

  public equals(other: Email): boolean {
    return this.value === other.value;
  }
}

// 3. User Entity Properties Interface
export interface UserProps {
  readonly email: Email;
  readonly isActive: boolean;
  readonly roles: ReadonlyArray<string>;
  readonly createdAt: Date;
}

// 4. Secure User Entity
export class User {
  private readonly _id: UserId;
  private _email: Email;
  private _isActive: boolean;
  private _roles: string[];
  private readonly _createdAt: Date;

  constructor(id: UserId, props: UserProps) {
    this._id = id;
    this._email = props.email;
    this._isActive = props.isActive;
    this._roles = [...props.roles]; // Defensive copy
    this._createdAt = new Date(props.createdAt.getTime()); // Defensive copy
    Object.freeze(this);
  }

  public get id(): UserId {
    return this._id;
  }

  public get email(): Email {
    return this._email;
  }

  public get isActive(): boolean {
    return this._isActive;
  }

  public get roles(): ReadonlyArray<string> {
    return [...this._roles]; // Return defensive copy to prevent external mutation
  }

  public get createdAt(): Date {
    return new Date(this._createdAt.getTime()); // Return defensive copy
  }

  public updateEmail(newEmail: Email): User {
    if (this._email.equals(newEmail)) {
      return this; // No change needed
    }
    
    // Return a new instance or mutate safely under strict invariants
    this._email = newEmail;
    return this;
  }

  public addRole(role: string): void {
    if (this._roles.includes(role)) {
      return;
    }
    this._roles.push(role);
  }

  public equals(other: User): boolean {
    if (!other) return false;
    return this._id.equals(other.id);
  }
}
