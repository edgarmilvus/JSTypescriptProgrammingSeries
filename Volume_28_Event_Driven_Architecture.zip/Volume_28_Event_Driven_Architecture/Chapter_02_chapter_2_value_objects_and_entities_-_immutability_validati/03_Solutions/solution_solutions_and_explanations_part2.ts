/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod Schema for Money Payload
export const MoneySchema = z.object({
  amount: z.number().int().positive("Amount must be a positive integer representing cents"),
  currency: z.string().length(3, "Currency must be a 3-letter ISO code").toUpperCase(),
});

// Infer the TypeScript type from the schema
export type MoneyDTO = z.infer<typeof MoneySchema>;

// 2. Custom Domain Validation Error
export class DomainValidationError extends Error {
  constructor(message: string, public readonly details: z.ZodIssue[]) {
    super(message);
    this.name = 'DomainValidationError';
  }
}

// 3. Money Value Object
export class Money {
  private readonly _amount: number;
  private readonly _currency: string;

  constructor(dto: MoneyDTO) {
    this._amount = dto.amount;
    this._currency = dto.currency;
    Object.freeze(this);
  }

  public get amount(): number {
    return this._amount;
  }

  public get currency(): string {
    return this._currency;
  }

  // Factory method using parser
  public static fromUnknown(raw: unknown): Money {
    const result = MoneySchema.safeParse(raw);
    
    if (!result.success) {
      throw new DomainValidationError(
        'Failed to parse Money payload due to validation errors.',
        result.error.issues
      );
    }

    return new Money(result.data);
  }

  public equals(other: Money): boolean {
    return this._amount === other.amount && this._currency === other.currency;
  }
}
