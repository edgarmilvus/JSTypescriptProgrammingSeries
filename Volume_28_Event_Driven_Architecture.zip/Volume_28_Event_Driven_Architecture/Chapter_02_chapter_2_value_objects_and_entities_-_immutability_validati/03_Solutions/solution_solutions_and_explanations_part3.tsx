/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// PostalCode Value Object Implementation
export class PostalCode {
  private readonly value: string;
  private static readonly POSTAL_REGEX = /^[A-Z0-9]{3,10}$/;

  constructor(value: string) {
    const trimmed = value.trim().toUpperCase();
    if (!PostalCode.POSTAL_REGEX.test(trimmed)) {
      throw new Error('Invalid postal code format. Must be 3-10 alphanumeric characters.');
    }
    this.value = trimmed;
    Object.freeze(this);
  }

  public toString(): string {
    return this.value;
  }
}

export const ShippingAddressForm: React.FC = () => {
  const [postalInput, setPostalInput] = useState('');
  const [postalError, setPostalError] = useState<string | null>(null);

  const handlePostalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPostalInput(value);
    
    try {
      // Attempting to instantiate the Value Object on every keystroke
      new PostalCode(value);
      setPostalError(null); // Clear error if valid
    } catch (error) {
      if (error instanceof Error) {
        setPostalError(error.message);
      } else {
        setPostalError('An unknown validation error occurred.');
      }
    }
  };

  return (
    <form onSubmit={(e) => e.preventDefault()}>
      <div>
        <label>Postal Code: </label>
        <input 
          type="text" 
          value={postalInput} 
          onChange={handlePostalChange} 
          aria-invalid={Boolean(postalError)}
        />
        {postalError && <span style={{ color: 'red', display: 'block' }}>{postalError}</span>}
      </div>
      <button type="submit" disabled={Boolean(postalError) || postalInput.trim() === ''}>
        Save Address
      </button>
    </form>
  );
};
