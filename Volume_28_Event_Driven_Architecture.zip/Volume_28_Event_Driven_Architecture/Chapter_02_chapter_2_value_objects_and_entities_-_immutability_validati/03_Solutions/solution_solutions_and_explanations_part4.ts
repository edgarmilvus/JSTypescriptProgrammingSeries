/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export class Waypoint {
  private readonly _latitude: number;
  private readonly _longitude: number;

  constructor(latitude: number, longitude: number) {
    if (latitude < -90 || latitude > 90) {
      throw new Error(`Invalid latitude: ${latitude}. Must be between -90 and 90.`);
    }
    if (longitude < -180 || longitude > 180) {
      throw new Error(`Invalid longitude: ${longitude}. Must be between -180 and 180.`);
    }
    this._latitude = latitude;
    this._longitude = longitude;
    Object.freeze(this);
  }

  public get latitude(): number {
    return this._latitude;
  }

  public get longitude(): number {
    return this._longitude;
  }

  public equals(other: Waypoint): boolean {
    if (!other) return false;
    return this._latitude === other._latitude && this._longitude === other._longitude;
  }
}

export class Route {
  private readonly _waypoints: ReadonlyArray<Waypoint>;

  constructor(waypoints: Waypoint[]) {
    // Invariant 1: Must contain at least two waypoints
    if (!waypoints || waypoints.length < 2) {
      throw new Error('A route must contain at least two waypoints (origin and destination).');
    }

    // Invariant 2: No consecutive duplicate waypoints
    for (let i = 0; i < waypoints.length - 1; i++) {
      if (waypoints[i].equals(waypoints[i + 1])) {
        throw new Error('A route cannot contain consecutive duplicate waypoints.');
      }
    }

    // Deep immutability via defensive copying and freezing
    this._waypoints = Object.freeze(waypoints.map(wp => new Waypoint(wp.latitude, wp.longitude)));
    Object.freeze(this);
  }

  public get waypoints(): ReadonlyArray<Waypoint> {
    // Return a new array containing cloned instances to guarantee encapsulation
    return this._waypoints.map(wp => new Waypoint(wp.latitude, wp.longitude));
  }

  public equals(other: Route): boolean {
    if (!other) return false;
    if (this._waypoints.length !== other._waypoints.length) return false;

    return this._waypoints.every((wp, index) => wp.equals(other._waypoints[index]));
  }
}
