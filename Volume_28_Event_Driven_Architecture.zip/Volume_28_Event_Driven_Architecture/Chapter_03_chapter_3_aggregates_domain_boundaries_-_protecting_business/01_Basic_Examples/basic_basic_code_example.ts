/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file workspace-aggregate.ts
 * @description A self-contained TypeScript implementation of an Aggregate Root 
 * enforcing transactional business invariants in a SaaS domain model.
 */

// ==========================================
// VALUE OBJECTS & PRIMITIVES
// ==========================================

/**
 * Represents a unique identifier for a Workspace.
 */
class WorkspaceId {
  constructor(public readonly value: string) {
    if (!value || value.trim() === '') {
      throw new Error('WorkspaceId cannot be empty.');
    }
  }
}

/**
 * Represents a unique identifier for a Project.
 */
class ProjectId {
  constructor(public readonly value: string) {
    if (!value || value.trim() === '') {
      throw new Error('ProjectId cannot be empty.');
    }
  }
}

/**
 * Subscription tier types determining capacity constraints.
 */
type SubscriptionTier = 'FREE' | 'PRO' | 'ENTERPRISE';

/**
 * Value Object holding subscription details.
 */
class Subscription {
  constructor(
    public readonly tier: SubscriptionTier,
    public readonly maxProjects: number
  ) {
    if (maxProjects < 0) {
      throw new Error('Max projects cannot be negative.');
    }
  }
}

// ==========================================
// DOMAIN EVENTS
// ==========================================

/**
 * Base interface for all domain events emitted by aggregates.
 */
interface DomainEvent {
  occurredOn: Date;
  eventName: string;
}

/**
 * Event published when a project is added to a workspace.
 */
class ProjectAddedEvent implements DomainEvent {
  public readonly occurredOn = new Date();
  public readonly eventName = 'ProjectAdded';

  constructor(
    public readonly workspaceId: string,
    public readonly projectId: string
  ) {}
}

// ==========================================
// ENTITY & AGGREGATE ROOT
// ==========================================

/**
 * Internal entity representing a Project inside the Workspace aggregate.
 * Cannot be accessed or mutated directly from outside the Aggregate Root.
 */
class ProjectEntity {
  constructor(
    public readonly id: ProjectId,
    public readonly name: string,
    public readonly isActive: boolean
  ) {}
}

/**
 * The Workspace Aggregate Root.
 * Responsible for maintaining consistency boundaries and enforcing invariants.
 */
class WorkspaceAggregate {
  private readonly _projects: ProjectEntity[] = [];
  private readonly _domainEvents: DomainEvent[] = [];

  constructor(
    public readonly id: WorkspaceId,
    public readonly name: string,
    private _subscription: Subscription
  ) {}

  /**
   * Exposes a read-only view of projects to prevent external mutation.
   */
  public get projects(): ReadonlyArray<ProjectEntity> {
    return [...this._projects];
  }

  /**
   * Exposes subscription configuration read-only.
   */
  public get subscription(): Subscription {
    return this._subscription;
  }

  /**
   * Collects uncommitted domain events for downstream dispatching.
   */
  public getDomainEvents(): DomainEvent[] {
    return [...this._domainEvents];
  }

  /**
   * Clears domain events after successful persistence and dispatch.
   */
  public clearDomainEvents(): void {
    this._domainEvents.length = 0;
  }

  /**
   * BUSINESS INVARIANT ENFORCEMENT:
   * Adds a project to the workspace only if the active project count 
   * does not violate the subscription limit.
   */
  public addProject(projectId: ProjectId, projectName: string): void {
    // 1. Check if project already exists within this aggregate
    const exists = this._projects.some((p) => p.id.value === projectId.value);
    if (exists) {
      throw new Error(`Project with ID ${projectId.value} already exists in this workspace.`);
    }

    // 2. Enforce Business Invariant: Subscription Project Limit
    const activeProjectsCount = this._projects.filter((p) => p.isActive).length;
    if (activeProjectsCount >= this._subscription.maxProjects) {
      throw new Error(
        `Invariant Violation: Cannot add project. Workspace has reached the limit of ${this._subscription.maxProjects} projects for the ${this._subscription.tier} tier.`
      );
    }

    // 3. Mutate internal state safely
    const newProject = new ProjectEntity(projectId, projectName, true);
    this._projects.push(newProject);

    // 4. Record Domain Event for eventual consistency or auditing
    this._domainEvents.push(new ProjectAddedEvent(this.id.value, projectId.value));
  }

  /**
   * Upgrades the workspace subscription, altering the invariant boundary.
   */
    public upgradeSubscription(newTier: SubscriptionTier, newMaxProjects: number): void {
    this._subscription = new Subscription(newTier, newMaxProjects);
  }
}

// ==========================================
// APPLICATION USAGE EXAMPLE
// ==========================================

// Initialize a workspace on the FREE tier (limit: 2 projects)
const workspaceId = new WorkspaceId('ws_998877');
const freeSubscription = new Subscription('FREE', 2);
const workspace = new WorkspaceAggregate(workspaceId, 'Acme Corp Engineering', freeSubscription);

try {
  // Add first project (Allowed)
  workspace.addProject(new ProjectId('proj_1'), 'Auth Microservice');
  console.log('Project 1 added successfully.');

  // Add second project (Allowed)
  workspace.addProject(new ProjectId('proj_2'), 'Billing API');
  console.log('Project 2 added successfully.');

  // Attempt to add third project (Will throw an error due to invariant violation)
  workspace.addProject(new ProjectId('proj_3'), 'Analytics Dashboard');
  console.log('Project 3 added successfully.');
} catch (error: any) {
  console.error(`Operation Failed: ${error.message}`);
}

// Output uncommitted events for outbox pattern / event bus processing
console.log('Uncommitted Domain Events:', workspace.getDomainEvents());
