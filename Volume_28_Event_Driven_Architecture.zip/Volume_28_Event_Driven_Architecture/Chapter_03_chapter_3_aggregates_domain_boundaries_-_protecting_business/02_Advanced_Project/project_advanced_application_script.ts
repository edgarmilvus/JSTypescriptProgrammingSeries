/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file OrganizationAggregate.ts
 * @description Production-grade TypeScript implementation of an Aggregate Root
 * handling subscription limits and domain events for a SaaS Multi-Tenant Workspace.
 */

// ==========================================
// 1. DOMAIN PRIMITIVES & VALUE OBJECTS
// ==========================================

/**
 * Unique Identifier value object for Organizations.
 */
export class OrganizationId {
  constructor(public readonly value: string) {
    if (!value || value.trim().length === 0) {
      throw new Error("OrganizationId cannot be empty.");
    }
  }

  public equals(other: OrganizationId): boolean {
    return other instanceof OrganizationId && other.value === this.value;
  }
}

/**
 * Unique Identifier value object for Users/Members.
 */
export class UserId {
  constructor(public readonly value: string) {
    if (!value || value.trim().length === 0) {
      throw new Error("UserId cannot be empty.");
    }
  }

  public equals(other: UserId): boolean {
    return other instanceof UserId && other.value === this.value;
  }
}

/**
 * Subscription Tier enumeration defining feature and seat boundaries.
 */
export enum SubscriptionTier {
  FREE = "FREE",
  PRO = "PRO",
  ENTERPRISE = "ENTERPRISE",
}

/**
 * Value Object encapsulating subscription details and seat limits.
 */
export class Subscription {
  constructor(
    public readonly tier: SubscriptionTier,
    public readonly maxSeats: number,
    public readonly expiresAt: Date
  ) {
    if (maxSeats < 1) {
      throw new Error("A subscription must allow at least one seat.");
    }
  }

  public isExpired(): boolean {
    return new Date() > this.expiresAt;
  }
}

// ==========================================
// 2. DOMAIN EVENTS
// ==========================================

export interface DomainEvent {
  readonly occurredOn: Date;
  readonly eventName: string;
}

export class SeatLimitExceededEvent implements DomainEvent {
  public readonly occurredOn = new Date();
  public readonly eventName = "Organization.SeatLimitExceeded";

  constructor(
    public readonly organizationId: string,
    public readonly attemptedSeats: number,
    public readonly maxSeats: number
  ) {}
}

export class MemberAddedEvent implements DomainEvent {
  public readonly occurredOn = new Date();
  public readonly eventName = "Organization.MemberAdded";

  constructor(
    public readonly organizationId: string,
    public readonly userId: string
  ) {}
}

export class SubscriptionUpgradedEvent implements DomainEvent {
  public readonly occurredOn = new Date();
  public readonly eventName = "Organization.SubscriptionUpgraded";

  constructor(
    public readonly organizationId: string,
    public readonly newTier: SubscriptionTier,
    public readonly newMaxSeats: number
  ) {}
}

// ==========================================
// 3. ENTITY & AGGREGATE ROOT
// ==========================================

/**
 * Internal entity representing a member inside the Organization aggregate boundary.
 */
class Member {
  constructor(
    public readonly id: UserId,
    public role: "ADMIN" | "MEMBER",
    public readonly joinedAt: Date = new Date()
  ) {}
}

/**
 * Organization Aggregate Root.
 * Protects invariants regarding membership counts, active subscription states, and role assignments.
 */
export class Organization {
  private _members: Map<string, Member> = new Map();
  private _domainEvents: DomainEvent[] = [];

  constructor(
    public readonly id: OrganizationId,
    public name: string,
    private _subscription: Subscription
  ) {}

  /**
   * Returns an immutable snapshot of domain events accumulated during the aggregate's lifecycle.
   */
  public getDomainEvents(): DomainEvent[] {
    return [...this._domainEvents];
  }

  /**
   * Clears published events after persistence/dispatching.
   */
  public clearEvents(): void {
    this._domainEvents = [];
  }

  public get subscription(): Subscription {
    return this._subscription;
  }

  public get memberCount(): number {
    return this._members.size;
  }

  /**
   * INVARIANT 1: Cannot add a member if the subscription is expired or max seats are reached.
   */
  public addMember(userId: UserId, role: "ADMIN" | "MEMBER" = "MEMBER"): void {
    // Check expiration invariant
    if (this._subscription.isExpired()) {
      throw new Error("Cannot add members to an organization with an expired subscription.");
    }

    // Check capacity invariant
    if (this._members.size >= this._subscription.maxSeats) {
      this._domainEvents.push(
        new SeatLimitExceededEvent(
          this.id.value,
          this._members.size + 1,
          this._subscription.maxSeats
        )
      );
      throw new Error(
        `Seat limit exceeded. Max allowed: ${this._subscription.maxSeats}`
      );
    }

    // Check uniqueness invariant within aggregate
    if (this._members.has(userId.value)) {
      throw new Error(`User ${userId.value} is already a member of this organization.`);
    }

    // Mutate state safely
    const newMember = new Member(userId, role);
    this._members.set(userId.value, newMember);

    // Record domain event for eventual consistency / cross-aggregate reactions
    this._domainEvents.push(new MemberAddedEvent(this.id.value, userId.value));
  }

  /**
   * INVARIANT 2: Upgrading or changing subscriptions must validate capacity constraints against current membership.
   */
  public updateSubscription(newSubscription: Subscription): void {
    if (newSubscription.maxSeats < this._members.size) {
      throw new Error(
        `Cannot downgrade subscription. Current active members (${this._members.size}) exceed new maximum seats (${newSubscription.maxSeats}).`
      );
    }

    this._subscription = newSubscription;

    this._domainEvents.push(
      new SubscriptionUpgradedEvent(
        this.id.value,
        newSubscription.tier,
        newSubscription.maxSeats
      )
    );
  }

  /**
   * Removes a member while keeping at least one admin if required.
   */
  public removeMember(userId: UserId): void {
    const member = this._members.get(userId.value);
    if (!member) {
      throw new Error(`User ${userId.value} is not a member of this organization.`);
    }

    if (member.role === "ADMIN") {
      const adminCount = Array.from(this._members.values()).filter(
        (m) => m.role === "ADMIN"
      ).length;
      if (adminCount <= 1) {
        throw new Error("Cannot remove the last remaining administrator from the organization.");
      }
    }

    this._members.delete(userId.value);
  }
}

// ==========================================
// 4. APPLICATION SERVICE (ORCHESTRATION)
// ==========================================

/**
 * Mock Event Publisher interface for dispatching domain events to a message bus (e.g., RabbitMQ, Kafka).
 */
export interface EventPublisher {
  publishAll(events: DomainEvent[]): Promise<void>;
}

/**
 * Mock Repository interface for loading and saving the Organization aggregate.
 */
export interface OrganizationRepository {
  findById(id: OrganizationId): Promise<Organization | null>;
  save(organization: Organization): Promise<void>;
}

/**
 * Application Service executing use cases while preserving transactional and domain boundaries.
 */
export class RegisterUserToOrganizationService {
  constructor(
    private readonly orgRepo: OrganizationRepository,
    private readonly eventPublisher: EventPublisher
  ) {}

  public async execute(orgIdStr: string, userIdStr: string): Promise<void> {
    const orgId = new OrganizationId(orgIdStr);
    const userId = new UserId(userIdStr);

    // 1. Load Aggregate Root within a transactional boundary
    const organization = await this.orgRepo.findById(orgId);
    if (!organization) {
      throw new Error(`Organization with ID ${orgIdStr} not found.`);
    }

    try {
      // 2. Invoke domain logic (Invariants checked inside aggregate)
      organization.addMember(userId);

      // 3. Persist aggregate state changes atomically
      await this.orgRepo.save(organization);

      // 4. Dispatch domain events to external subscribers
      const events = organization.getDomainEvents();
      await this.eventPublisher.publishAll(events);

      // 5. Clear dispatched events from aggregate memory
      organization.clearEvents();
    } catch (error) {
      // Invariant violated or persistence failed; rollback transactional boundary
      throw error;
    }
  }
}
