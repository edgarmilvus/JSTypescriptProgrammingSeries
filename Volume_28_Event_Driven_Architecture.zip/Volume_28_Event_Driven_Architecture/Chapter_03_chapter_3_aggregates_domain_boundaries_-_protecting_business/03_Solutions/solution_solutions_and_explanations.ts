/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export class WorkspaceInvariantViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WorkspaceInvariantViolationError';
  }
}

export class StorageQuota {
  private constructor(public readonly bytes: number) {}

  public static fromMegabytes(mb: number): StorageQuota {
    return new StorageQuota(mb * 1024 * 1024);
  }

  public static fromGigabytes(gb: number): StorageQuota {
    return new StorageQuota(gb * 1024 * 1024 * 1024);
  }

  public static fromTerabytes(tb: number): StorageQuota {
    return new StorageQuota(tb * 1024 * 1024 * 1024 * 1024);
  }

  public add(other: StorageQuota): StorageQuota {
    return new StorageQuota(this.bytes + other.bytes);
  }

  public isGreaterThan(other: StorageQuota): boolean {
    return this.bytes > other.bytes;
  }
}

export type WorkspaceTier = 'free' | 'pro' | 'enterprise';

interface WorkspaceTierLimits {
  maxDocuments: number;
  maxStorage: StorageQuota;
}

const TIER_LIMITS: Record<WorkspaceTier, WorkspaceTierLimits> = {
  free: {
    maxDocuments: 10,
    maxStorage: StorageQuota.fromMegabytes(100),
  },
  pro: {
    maxDocuments: 500,
    maxStorage: StorageQuota.fromGigabytes(10),
  },
  enterprise: {
    maxDocuments: Infinity,
    maxStorage: StorageQuota.fromTerabytes(1),
  },
};

export class Document {
  constructor(
    public readonly id: string,
    public readonly sizeInBytes: number
  ) {}
}

export interface DomainEvent {
  occurredOn: Date;
}

export class DocumentAddedToWorkspace implements DomainEvent {
  public readonly occurredOn = new Date();
  constructor(public readonly workspaceId: string, public readonly documentId: string) {}
}

export class Workspace {
  private documents: Document[] = [];
  private domainEvents: DomainEvent[] = [];

  constructor(
    private readonly id: string,
    private readonly tier: WorkspaceTier
  ) {}

  // Solution to Interactive Challenge: Return a readonly shallow copy
  public getDocuments(): ReadonlyArray<Document> {
    return [...this.documents];
  }

  public getDomainEvents(): ReadonlyArray<DomainEvent> {
    return [...this.domainEvents];
  }

  public clearDomainEvents(): void {
    this.domainEvents = [];
  }

  public addDocument(doc: Document): void {
    const limits = TIER_LIMITS[this.tier];

    // 1. Check document count invariant
    if (this.documents.length >= limits.maxDocuments) {
      throw new WorkspaceInvariantViolationError(
        `Workspace '${this.id}' has reached the maximum document limit of ${limits.maxDocuments} for tier '${this.tier}'.`
      );
    }

    // 2. Check storage size invariant
    const currentStorage = this.documents.reduce(
      (total, d) => total.add(StorageQuota.fromMegabytes(d.sizeInBytes / (1024 * 1024))),
      StorageQuota.fromMegabytes(0)
    );
    const docStorage = StorageQuota.fromMegabytes(doc.sizeInBytes / (1024 * 1024));
    const projectedStorage = currentStorage.add(docStorage);

    if (projectedStorage.isGreaterThan(limits.maxStorage)) {
      throw new WorkspaceInvariantViolationError(
        `Workspace '${this.id}' exceeds storage quota limit for tier '${this.tier}'.`
      );
    }

    // 3. Mutate internal state
    this.documents.push(doc);

    // 4. Record domain event
    this.domainEvents.push(new DocumentAddedToWorkspace(this.id, doc.id));
  }
}
