/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export class InvalidOrderStateTransitionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidOrderStateTransitionError';
  }
}

export interface DomainEvent {
  readonly version: number;
  readonly occurredOn: Date;
}

export class OrderCreated implements DomainEvent {
  readonly occurredOn = new Date();
  constructor(readonly orderId: string, readonly version: number = 1) {}
}

export class ItemAddedToOrder implements DomainEvent {
  readonly occurredOn = new Date();
  constructor(readonly orderId: string, readonly itemId: string, readonly version: number) {}
}

export class OrderCancelled implements DomainEvent {
  readonly occurredOn = new Date();
  constructor(readonly orderId: string, readonly version: number) {}
}

export abstract class AggregateRoot {
  private uncommittedEvents: DomainEvent[] = [];
  private currentVersion: number = 0;

  protected getVersion(): number {
    return this.currentVersion;
  }

  protected setVersion(version: number): void {
    this.currentVersion = version;
  }

  protected addEvent(event: DomainEvent): void {
    this.uncommittedEvents.push(event);
    this.currentVersion = event.version;
  }

  public getUncommittedEvents(): DomainEvent[] {
    return [...this.uncommittedEvents];
  }

  public markEventsAsCommitted(): void {
    this.uncommittedEvents = [];
  }

  protected abstract applyEvent(event: DomainEvent): void;

  protected raise(event: DomainEvent): void {
    this.applyEvent(event);
    this.addEvent(event);
  }
}

type OrderStatus = 'Draft' | 'Active' | 'Cancelled' | 'Completed';

export class Order extends AggregateRoot {
  private id!: string;
  private status: OrderStatus = 'Draft';
  private items: string[] = [];

  private constructor() {
    super();
  }

  public static rehydrate(events: DomainEvent[]): Order {
    const order = new Order();
    for (const event of events) {
      order.applyEvent(event);
      order.setVersion(event.version);
    }
    return order;
  }

  protected applyEvent(event: DomainEvent): void {
    if (event instanceof OrderCreated) {
      this.applyOrderCreated(event);
    } else if (event instanceof ItemAddedToOrder) {
      this.applyItemAddedToOrder(event);
    } else if (event instanceof OrderCancelled) {
      this.applyOrderCancelled(event);
    }
  }

  private applyOrderCreated(event: OrderCreated): void {
    this.id = event.orderId;
    this.status = 'Active';
  }

  private applyItemAddedToOrder(event: ItemAddedToOrder): void {
    this.items.push(event.itemId);
  }

  private applyOrderCancelled(event: OrderCancelled): void {
    this.status = 'Cancelled';
  }

  public static create(orderId: string): Order {
    const order = new Order();
    const event = new OrderCreated(orderId, 1);
    order.raise(event);
    return order;
  }

  public addItem(itemId: string): void {
    if (this.status === 'Cancelled' || this.status === 'Completed') {
      throw new InvalidOrderStateTransitionError(`Cannot modify order '${this.id}' in status '${this.status}'.`);
    }
    const nextVersion = this.getVersion() + 1;
    this.raise(new ItemAddedToOrder(this.id, itemId, nextVersion));
  }

  public cancel(): void {
    if (this.status === 'Cancelled' || this.status === 'Completed') {
      throw new InvalidOrderStateTransitionError(`Order '${this.id}' is already finalized.`);
    }
    const nextVersion = this.getVersion() + 1;
    this.raise(new OrderCancelled(this.id, nextVersion));
  }
}

export class OrderCommandHandler {
  public async handleCompleteOrder(orderId: string, expectedVersion: number, eventStore: any): Promise<void> {
    const history = await eventStore.getEventsForStream(orderId);
    const order = Order.rehydrate(history);

    if (order['getVersion']() !== expectedVersion) {
      throw new Error(`Concurrency Conflict: Expected version ${expectedVersion}, but actual version is ${order['getVersion']()}.`);
    }
    
    // Proceed with completion business logic...
  }
}
