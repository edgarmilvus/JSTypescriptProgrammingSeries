/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface OutboxMessage {
  id: string;
  aggregateId: string;
  eventType: string;
  payload: string;
  occurredOn: Date;
  processed: boolean;
}

export interface DatabaseTransactionClient {
  query(sql: string, params: any[]): Promise<any>;
}

export class OutboxRepository {
  constructor(private readonly db: DatabaseTransactionClient) {}

  public async saveWithAggregate(
    aggregateId: string,
    eventType: string,
    payload: any,
    tx: DatabaseTransactionClient
  ): Promise<void> {
    const messageId = crypto.randomUUID();
    const query = `
      INSERT INTO outbox_messages (id, aggregate_id, event_type, payload, occurred_on, processed)
      VALUES ($1, $2, $3, $4, NOW(), FALSE)
    `;
    await tx.query(query, [messageId, aggregateId, eventType, JSON.stringify(payload)]);
  }
}

export function TransactionalOutbox(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
  const originalMethod = descriptor.value;
  descriptor.value = async function (...args: any[]) {
    const dbClient = this.dbClient; // Assumes dbClient is a property on the repository/service
    await dbClient.query('BEGIN', []);
    try {
      const result = await originalMethod.apply(this, args);
      await dbClient.query('COMMIT', []);
      return result;
    } catch (error) {
      await dbClient.query('ROLLBACK', []);
      throw error;
    }
  };
  return descriptor;
}

export class OutboxProcessor {
  constructor(private readonly db: DatabaseTransactionClient, private readonly messageBroker: any) {}

  public async pollAndDispatch(): Promise<void> {
    const { rows } = await this.db.query(
      'SELECT * FROM outbox_messages WHERE processed = FALSE ORDER BY occurred_on ASC LIMIT 50',
      []
    );

    for (const msg of rows) {
      try {
        await this.messageBroker.publish(msg.event_type, JSON.parse(msg.payload));
        await this.db.query('UPDATE outbox_messages SET processed = TRUE WHERE id = $1', [msg.id]);
      } catch (error) {
        console.error(`Failed to dispatch message ${msg.id}:`, error);
        break; // Stop batch processing on failure to preserve ordered delivery
      }
    }
  }
}

export class InventoryEventConsumer {
  constructor(private readonly db: DatabaseTransactionClient) {}

  public async handleInvoicePaid(event: { eventId: string; invoiceId: string; items: string[] }): Promise<void> {
    await this.db.query('BEGIN', []);
    try {
      // Check deduplication table for idempotency
      const { rows } = await this.db.query(
        'SELECT event_id FROM processed_events WHERE event_id = $1',
        [event.eventId]
      );

      if (rows.length > 0) {
        // Event already processed; acknowledge silently (idempotent behavior)
        await this.db.query('COMMIT', []);
        return;
      }

      // Reserve inventory items
      for (const itemId of event.items) {
        await this.db.query(
          'UPDATE inventory_stock SET reserved = reserved + 1 WHERE item_id = $1',
          [itemId]
        );
      }

      // Record event ID in deduplication log
      await this.db.query(
        'INSERT INTO processed_events (event_id, processed_at) VALUES ($1, NOW())',
        [event.eventId]
      );

      await this.db.query('COMMIT', []);
    } catch (error) {
      await this.db.query('ROLLBACK', []);
      throw error;
    }
  }
}
