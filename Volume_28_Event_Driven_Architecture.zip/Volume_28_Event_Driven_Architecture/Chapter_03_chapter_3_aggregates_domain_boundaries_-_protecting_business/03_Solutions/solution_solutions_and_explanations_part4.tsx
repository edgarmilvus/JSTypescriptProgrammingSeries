/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { Suspense, useState } from 'react';
import { useChat } from 'ai/react';

interface AggregateDiagnosticsPanelProps {
  workspaceId: string;
}

interface AggregateMetrics {
  workspaceId: string;
  version: number;
  documentCount: number;
  storageUsedBytes: number;
  outboxPendingCount: number;
}

function isAggregateMetricsParams(params: any): params is { workspaceId: string; includeHistory: boolean } {
  return typeof params === 'object' && params !== null && typeof params.workspaceId === 'string';
}

async function fetchAggregateMetrics(params: { workspaceId: string; includeHistory: boolean }): Promise<AggregateMetrics> {
  // Mock domain service data fetch
  return {
    workspaceId: params.workspaceId,
    version: 42,
    documentCount: 8,
    storageUsedBytes: 52428800,
    outboxPendingCount: 0,
  };
}

export function AggregateDiagnosticsPanel({ workspaceId }: AggregateDiagnosticsPanelProps) {
  const [metrics, setMetrics] = useState<AggregateMetrics | null>(null);

  const { messages, input, handleInputChange, handleSubmit, toolInvocations } = useChat({
    api: '/api/chat',
    initialMessages: [
      { id: '1', role: 'system', content: `Monitoring active workspace ${workspaceId}. Ready for telemetry queries.` }
    ],
    async experimental_onToolCall(toolCall) {
      if (toolCall.toolName === 'fetchAggregateMetrics') {
        if (isAggregateMetricsParams(toolCall.args)) {
          const result = await fetchAggregateMetrics(toolCall.args);
          setMetrics(result);
          return result;
        }
        throw new Error('Invalid arguments passed to fetchAggregateMetrics tool.');
      }
    }
  });

  return (
    <Suspense fallback={<div className="animate-pulse p-6 bg-slate-900 text-white rounded-lg">Loading Aggregate Telemetry...</div>}>
      <div className="flex flex-col h-[600px] max-w-2xl mx-auto p-4 bg-slate-950 text-slate-100 rounded-xl border border-slate-800">
        <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4">
          <h2 className="text-lg font-semibold tracking-wide">Workspace Diagnostics: {workspaceId}</h2>
          {metrics && (
            <span className="text-xs px-2 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded">
              v{metrics.version} | Docs: {metrics.documentCount}
            </span>
          )}
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2">
          {messages.map((m) => (
            <div key={m.id} className={`p-3 rounded-lg text-sm ${m.role === 'user' ? 'bg-indigo-950 text-indigo-200 ml-8' : 'bg-slate-900 text-slate-300 mr-8'}`}>
              <span className="font-bold block text-xs opacity-50 mb-1">{m.role.toUpperCase()}</span>
              {m.content}
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Ask AI Copilot about aggregate invariants..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-600"
          />
          <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm px-4 py-2 rounded-lg font-medium transition-colors">
            Analyze
          </button>
        </form>
      </div>
    </Suspense>
  );
}
