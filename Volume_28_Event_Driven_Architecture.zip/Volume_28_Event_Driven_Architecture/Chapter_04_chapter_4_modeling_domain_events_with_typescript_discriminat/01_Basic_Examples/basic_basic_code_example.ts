/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Billing Domain Events Example
 * @description A self-contained TypeScript implementation demonstrating 
 * Domain Events using Discriminated Unions for a SaaS Subscription Service.
 */

// ==========================================
// 1. DOMAIN EVENT DEFINITIONS (DISCRIMINATED UNIONS)
// ==========================================

/**
 * Base interface for all domain events in the billing context.
 * Guarantees that every event has a unique ID, a timestamp, 
 * and an associated aggregate (tenant/user) identifier.
 */
interface DomainEventBase {
    readonly eventId: string;
    readonly occurredOn: Date;
    readonly aggregateId: string; // e.g., TenantId or UserId
}

/**
 * Event fired when a new user registers and initializes a free trial account.
 */
export interface UserRegisteredEvent extends DomainEventBase {
    readonly type: 'USER_REGISTERED';
    readonly payload: {
        readonly email: string;
        readonly plan: 'FREE_TRIAL';
    };
}

/**
 * Event fired when a user upgrades their subscription to a paid tier.
 */
export interface SubscriptionUpgradedEvent extends DomainEventBase {
    readonly type: 'SUBSCRIPTION_UPGRADED';
    readonly payload: {
        readonly previousPlan: 'FREE_TRIAL' | 'STARTER';
        readonly newPlan: 'PRO' | 'ENTERPRISE';
        readonly monthlyValueInCents: number;
    };
}

/**
 * Event fired when an account is suspended due to a payment processing failure.
 */
export interface AccountSuspendedEvent extends DomainEventBase {
    readonly type: 'ACCOUNT_SUSPENDED';
    readonly payload: {
        readonly reason: 'INSUFFICIENT_FUNDS' | 'CARD_EXPIRED' | 'MANUAL_REVOCATION';
        readonly failedInvoiceId: string;
    };
}

/**
 * The master Discriminated Union representing all possible billing domain events.
 * The 'type' property acts as the literal discriminator.
 */
export type BillingDomainEvent = 
    | UserRegisteredEvent 
    | SubscriptionUpgradedEvent 
    | AccountSuspendedEvent;


// ==========================================
// 2. EVENT DISPATCHER & HANDLER INFRASTRUCTURE
// ==========================================

/**
 * An in-memory event bus that processes incoming billing domain events.
 */
export class BillingEventDispatcher {
    /**
     * Dispatches an event to the appropriate domain handlers using 
     * TypeScript's exhaustive type-checking capabilities.
     * 
     * @param event The incoming billing domain event.
     */
    public async dispatch(event: BillingDomainEvent): Promise<void> {
        // Pattern matching via switch statement on the discriminant 'type'
        switch (event.type) {
            case 'USER_REGISTERED':
                await this.handleUserRegistered(event);
                break;
            case 'SUBSCRIPTION_UPGRADED':
                await this.handleSubscriptionUpgraded(event);
                break;
            case 'ACCOUNT_SUSPENDED':
                await this.handleAccountSuspended(event);
                break;
            default:
                // Exhaustiveness check (Never type guard)
                // If a new event is added to BillingDomainEvent without a case, 
                // TypeScript will throw a compile-time error here.
                const _exhaustiveCheck: never = event;
                throw new Error(`Unhandled domain event type: ${(_exhaustiveCheck as any).type}`);
        }
    }

    private async handleUserRegistered(event: UserRegisteredEvent): Promise<void> {
        console.log(`[Event: USER_REGISTERED] Tenant ${event.aggregateId} registered with email ${event.payload.email}.`);
        // Side effect: Provision database schemas, send welcome email via SendGrid, etc.
    }

    private async handleSubscriptionUpgraded(event: SubscriptionUpgradedEvent): Promise<void> {
        console.log(`[Event: SUBSCRIPTION_UPGRADED] Tenant ${event.aggregateId} upgraded from ${event.payload.previousPlan} to ${event.payload.newPlan}. Value: $${event.payload.monthlyValueInCents / 100}`);
        // Side effect: Update Stripe subscription metadata, unlock premium features in Redis cache.
    }

    private async handleAccountSuspended(event: AccountSuspendedEvent): Promise<void> {
        console.warn(`[Event: ACCOUNT_SUSPENDED] Tenant ${event.aggregateId} suspended. Reason: ${event.payload.reason}. Invoice: ${event.payload.failedInvoiceId}`);
        // Side effect: Revoke JWT tokens, downgrade feature flags to read-only mode.
    }
}


// ==========================================
// 3. EXECUTION / SIMULATION (SAAS CONTEXT)
// ==========================================

async function simulateBillingPipeline() {
    const dispatcher = new BillingEventDispatcher();

    // Constructing an immutable event instance representing a user upgrade
    const upgradeEvent: BillingDomainEvent = {
        eventId: 'evt_998877665544',
        occurredOn: new Date(),
        aggregateId: 'tenant_abc_123',
        type: 'SUBSCRIPTION_UPGRADED',
        payload: {
            previousPlan: 'FREE_TRIAL',
            newPlan: 'PRO',
            monthlyValueInCents: 4900 // $49.00/month
        }
    };

    console.log('Initiating event processing pipeline...');
    await dispatcher.dispatch(upgradeEvent);
}

// Execute simulation
simulateBillingPipeline().catch(console.error);
