/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';

// ============================================================================
// 1. BASE DOMAIN EVENT DEFINITIONS & SCHEMAS
// ============================================================================

/**
 * Base schema for all domain events across the SaaS platform.
 * Enforces metadata tracking for distributed tracing and event sourcing.
 */
const BaseDomainEventSchema = z.object({
  eventId: z.string().uuid(),
  correlationId: z.string().uuid(),
  timestamp: z.string().datetime(),
  version: z.number().int().positive(),
  actorId: z.string(),
});

/**
 * Schema for Tenant Subscription Upgraded Event Payload.
 */
const SubscriptionUpgradedPayloadSchema = z.object({
  tenantId: z.string(),
  previousTier: z.enum(['FREE', 'PRO', 'ENTERPRISE']),
  newTier: z.enum(['FREE', 'PRO', 'ENTERPRISE']),
  seatsAllocated: z.number().int().positive(),
  vectorStorageLimitMb: z.number().int().positive(),
});

/**
 * Schema for Vector Embedding Indexing Triggered Event Payload.
 * Simulates integration with the Pinecone Client (Node.js) workflow.
 */
const VectorIndexingTriggeredPayloadSchema = z.object({
  tenantId: z.string(),
  indexName: z.string(),
  vectorDimensions: z.number().int().positive(),
  documentBatchSize: z.number().int().positive(),
});

// ============================================================================
// 2. DISCRIMINATED UNIONS VIA RUNTIME SCHEMAS
// ============================================================================

/**
 * Complete runtime schema for the Subscription Upgraded Event.
 */
const SubscriptionUpgradedEventSchema = BaseDomainEventSchema.extend({
  eventType: z.literal('TENANT_SUBSCRIPTION_UPGRADED'),
  payload: SubscriptionUpgradedPayloadSchema,
});

/**
 * Complete runtime schema for the Vector Indexing Event.
 */
const VectorIndexingTriggeredEventSchema = BaseDomainEventSchema.extend({
  eventType: z.literal('VECTOR_INDEXING_TRIGGERED'),
  payload: VectorIndexingTriggeredPayloadSchema,
});

/**
 * Master Discriminated Union Schema representing all domain events in the system.
 */
const DomainEventSchema = z.discriminatedUnion('eventType', [
  SubscriptionUpgradedEventSchema,
  VectorIndexingTriggeredEventSchema,
]);

// Infer TypeScript types directly from the Zod schemas to ensure single source of truth.
export type DomainEvent = z.infer<typeof DomainEventSchema>;
export type SubscriptionUpgradedEvent = z.infer<typeof SubscriptionUpgradedEventSchema>;
export type VectorIndexingTriggeredEvent = z.infer<typeof VectorIndexingTriggeredEventSchema>;

// ============================================================================
// 3. IMMUTABLE STATE MANAGEMENT & EVENT CREATORS
// ============================================================================

/**
 * Factory functions to safely construct immutable domain events.
 * Guarantees that internal structures cannot be mutated after creation.
 */
export const EventFactory = {
  createSubscriptionUpgraded(
    actorId: string,
    correlationId: string,
    payload: z.infer<typeof SubscriptionUpgradedPayloadSchema>,
    version: number = 1
  ): SubscriptionUpgradedEvent {
    const rawEvent = {
      eventId: crypto.randomUUID(),
      correlationId,
      timestamp: new Date().toISOString(),
      version,
      actorId,
      eventType: 'TENANT_SUBSCRIPTION_UPGRADED' as const,
      payload: Object.freeze({ ...payload }), // Enforce shallow immutability
    };

    // Runtime validation guarantees structural integrity before dispatch
    return SubscriptionUpgradedEventSchema.parse(rawEvent);
  },

  createVectorIndexingTriggered(
    actorId: string,
    correlationId: string,
    payload: z.infer<typeof VectorIndexingTriggeredPayloadSchema>,
    version: number = 1
  ): VectorIndexingTriggeredEvent {
    const rawEvent = {
      eventId: crypto.randomUUID(),
      correlationId,
      timestamp: new Date().toISOString(),
      version,
      actorId,
      eventType: 'VECTOR_INDEXING_TRIGGERED' as const,
      payload: Object.freeze({ ...payload }),
    };

    return VectorIndexingTriggeredEventSchema.parse(rawEvent);
  },
};

// ============================================================================
// 4. EXHAUSTIVE PATTERN MATCHING & EVENT DISPATCHER
// ============================================================================

/**
 * Compile-time assertion helper to ensure exhaustive switch-case handling.
 * If a new event type is added to the discriminated union without a corresponding case,
 * TypeScript will throw a compilation error.
 */
function assertNever(x: never): never {
  throw new Error(`Unexpected object: ${JSON.stringify(x)}`);
}

/**
 * Core Domain Event Dispatcher simulating routing to downstream microservices,
 * such as updating billing records or invoking the Pinecone Vector Database SDK.
 */
export async function handleDomainEvent(incomingData: unknown): Promise<void> {
  // 1. Perform runtime validation on untrusted network payload
  const parseResult = DomainEventSchema.safeParse(incomingData);

  if (!parseResult.success) {
    console.error('Validation failed for incoming domain event:', parseResult.error.format());
    throw new Error('Invalid domain event schema payload.');
  }

  const event: DomainEvent = parseResult.data;

  // 2. Execute exhaustive pattern matching based on the discriminator `eventType`
  switch (event.eventType) {
    case 'TENANT_SUBSCRIPTION_UPGRADED': {
      // TypeScript automatically narrows `event` to SubscriptionUpgradedEvent here
      console.log(`[Billing Service] Processing upgrade for tenant: ${event.payload.tenantId}`);
      console.log(`Transition: ${event.payload.previousTier} -> ${event.payload.newTier}`);
      
      // Simulate provisioning vector storage limits
      await provisionTenantResources(event.payload.tenantId, event.payload.vectorStorageLimitMb);
      break;
    }

    case 'VECTOR_INDEXING_TRIGGERED': {
      // TypeScript automatically narrows `event` to VectorIndexingTriggeredEvent here
      console.log(`[Vector Search Engine] Initializing Pinecone index: ${event.payload.indexName}`);
      console.log(`Dimensions: ${event.payload.vectorDimensions}, Batch Size: ${event.payload.documentBatchSize}`);
      
      // Simulate Pinecone Client upsert operation call
      await triggerPineconeUpsert(event.payload.indexName, event.payload.documentBatchSize);
      break;
    }

    default: {
      // Exhaustiveness check
      return assertNever(event);
    }
  }
}

// ============================================================================
// 5. SIMULATED MICROSERVICE INFRASTRUCTURE INTEGRATIONS
// ============================================================================

async function provisionTenantResources(tenantId: string, storageLimitMb: number): Promise<void> {
  // Mock async database or cloud provider operation
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Successfully provisioned ${storageLimitMb}MB storage for tenant ${tenantId}.`);
      resolve();
    }, 100);
  });
}

async function triggerPineconeUpsert(indexName: string, batchSize: number): Promise<void> {
  // Mock Pinecone Client invocation
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Pinecone index '${indexName}' received batch of ${batchSize} vectors for indexing.`);
      resolve();
    }, 150);
  });
}

// ============================================================================
// 6. EXECUTION DEMONSTRATION
// ============================================================================

async function runDemo() {
  const correlationId = crypto.randomUUID();

  // Create an immutable subscription event
  const subEvent = EventFactory.createSubscriptionUpgraded(
    'usr_admin_992',
    correlationId,
    {
      tenantId: 'tenant_acme_corp',
      previousTier: 'FREE',
      newTier: 'ENTERPRISE',
      seatsAllocated: 50,
      vectorStorageLimitMb: 10240,
    }
  );

  // Create an immutable vector indexing event
  const vectorEvent = EventFactory.createVectorIndexingTriggered(
    'usr_admin_992',
    correlationId,
    {
      tenantId: 'tenant_acme_corp',
      indexName: 'enterprise-knowledge-base',
      vectorDimensions: 1536,
      documentBatchSize: 500,
    }
  );

  console.log('--- Dispatching Subscription Upgraded Event ---');
  await handleDomainEvent(subEvent);

  console.log('\n--- Dispatching Vector Indexing Event ---');
  await handleDomainEvent(vectorEvent);
}

// Uncomment to execute in a Node.js environment:
// runDemo().catch(console.error);
