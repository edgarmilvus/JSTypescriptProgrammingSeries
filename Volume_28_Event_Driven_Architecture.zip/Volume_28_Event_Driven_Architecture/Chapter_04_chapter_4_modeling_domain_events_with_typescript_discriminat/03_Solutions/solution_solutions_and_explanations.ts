/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Base Event Interface
export interface DomainEvent<
  TType extends string,
  TData extends object,
  TVersion extends number
> {
  readonly eventId: string;
  readonly aggregateId: string; // Order ID
  readonly timestamp: number;
  readonly version: TVersion;
  readonly type: TType;
  readonly correlationId: string;
  readonly data: Readonly<TData>;
}

// 2. Specific Event Payloads & Variants
export type LineItem = {
  readonly productId: string;
  readonly quantity: number;
  readonly unitPrice: number;
};

export type OrderInitializedEvent = DomainEvent<
  'OrderInitialized',
  { readonly items: ReadonlyArray<LineItem> },
  1
>;

export type WarehouseAllocation = {
  readonly warehouseId: string;
  readonly allocatedItems: ReadonlyArray<LineItem>;
};

export type InventoryAllocatedEvent = DomainEvent<
  'InventoryAllocated',
  { readonly allocations: ReadonlyArray<WarehouseAllocation> },
  1
>;

export type InventoryAllocationFailedEvent = DomainEvent<
  'InventoryAllocationFailed',
  { 
    readonly missingItems: ReadonlyArray<LineItem>;
    readonly reason: string;
  },
  1
>;

export type PaymentCapturedEvent = DomainEvent<
  'PaymentCaptured',
  { 
    readonly transactionId: string;
    readonly currency: string;
    readonly amount: number;
  },
  1
>;

export type FulfillmentCompletedEvent = DomainEvent<
  'FulfillmentCompleted',
  { 
    readonly trackingNumber: string;
    readonly courierService: string;
    readonly estimatedDeliveryDate: string;
  },
  1
>;

// 3. Combined Discriminated Union
export type OrderFulfillmentEvent =
  | OrderInitializedEvent
  | InventoryAllocatedEvent
  | InventoryAllocationFailedEvent
  | PaymentCapturedEvent
  | FulfillmentCompletedEvent;

// 4. Dispatcher Function Implementation Sketch
export function processFulfillmentEvent(event: OrderFulfillmentEvent): void {
  switch (event.type) {
    case 'OrderInitialized':
      // TypeScript automatically narrows `event` to `OrderInitializedEvent`
      console.log(`Order ${event.aggregateId} initialized with ${event.data.items.length} items.`);
      break;
      
    case 'InventoryAllocated':
      console.log(`Inventory reserved for order ${event.aggregateId}.`);
      break;

    case 'InventoryAllocationFailed':
      console.warn(`Allocation failed for order ${event.aggregateId}: ${event.data.reason}`);
      break;

    case 'PaymentCaptured':
      console.log(`Payment captured: ${event.data.amount} ${event.data.currency} (TxID: ${event.data.transactionId})`);
      break;

    case 'FulfillmentCompleted':
      console.log(`Order ${event.aggregateId} shipped via ${event.data.courierService}. Tracking: ${event.data.trackingNumber}`);
      break;

    default:
      // Exhaustiveness check
      const _exhaustiveCheck: never = event;
      throw new Error(`Unhandled event type: ${_exhaustiveCheck}`);
  }
}
