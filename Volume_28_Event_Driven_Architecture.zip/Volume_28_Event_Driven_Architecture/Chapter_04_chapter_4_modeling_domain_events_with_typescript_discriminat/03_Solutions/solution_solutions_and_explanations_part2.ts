/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { OrderFulfillmentEvent } from './exercise-1';

// 1. Generic Pattern Matching Engine
export type EventHandlers<T extends { type: string }, TResult> = {
  [K in T['type']]: (event: Extract<T, { type: K }>) => TResult;
};

export function matchEvent<T extends { type: string }, TResult>(
  event: T,
  handlers: EventHandlers<T, TResult>
): TResult {
  const handler = handlers[event.type as T['type']];
  if (!handler) {
    throw new Error(`No handler registered for event type: ${event.type}`);
  }
  return handler(event as any);
}

// 2. Shipping Microservice Consumer Module
export function handleShippingEvent(event: OrderFulfillmentEvent): string {
  return matchEvent(event, {
    OrderInitialized: (e) => {
      // e is strictly typed as OrderInitializedEvent
      return `Queuing order initialization check for ID: ${e.aggregateId}`;
    },
    InventoryAllocated: (e) => {
      // e is strictly typed as InventoryAllocatedEvent
      const warehouses = e.data.allocations.map(a => a.warehouseId).join(', ');
      return `Preparing shipment dispatch from warehouses: ${warehouses}`;
    },
    InventoryAllocationFailed: (e) => {
      return `Holding shipping manifest due to stock shortages: ${e.data.reason}`;
    },
    PaymentCaptured: (e) => {
      return `Clearing payment of ${e.data.amount} ${e.data.currency} for dispatch validation.`;
    },
    FulfillmentCompleted: (e) => {
      return `Archiving fulfillment workflow. Tracking assigned: ${e.data.trackingNumber}`;
    }
  });
}
