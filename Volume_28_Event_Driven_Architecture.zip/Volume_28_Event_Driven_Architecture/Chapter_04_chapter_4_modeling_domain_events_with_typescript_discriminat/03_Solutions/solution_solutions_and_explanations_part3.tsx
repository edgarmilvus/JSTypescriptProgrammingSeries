/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { OrderFulfillmentEvent } from './exercise-1';

// 1. UIState Discriminated Union
export type UIState =
  | { readonly status: 'INITIALIZING'; readonly orderId: string; readonly itemCount: number }
  | { readonly status: 'ALLOCATION_ERROR'; readonly orderId: string; readonly reason: string }
  | { readonly status: 'ACTIVE_FULFILLMENT'; readonly orderId: string; readonly warehouses: ReadonlyArray<string> }
  | { readonly status: 'COMPLETED'; readonly orderId: string; readonly trackingNumber: string; readonly courier: string };

// 2. Pure Reducer Function
export function reduceOrderUIState(currentState: UIState, event: OrderFulfillmentEvent): UIState {
  switch (event.type) {
    case 'OrderInitialized':
      return {
        status: 'INITIALIZING',
        orderId: event.aggregateId,
        itemCount: event.data.items.length
      };
    case 'InventoryAllocationFailed':
      return {
        status: 'ALLOCATION_ERROR',
        orderId: event.aggregateId,
        reason: event.data.reason
      };
    case 'InventoryAllocated':
    case 'PaymentCaptured':
      // Transitions/keeps active fulfillment state if allocation succeeds
      return {
        status: 'ACTIVE_FULFILLMENT',
        orderId: event.aggregateId,
        warehouses: event.type === 'InventoryAllocated' 
          ? event.data.allocations.map(a => a.warehouseId) 
          : (currentState.status === 'ACTIVE_FULFILLMENT' ? currentState.warehouses : [])
      };
    case 'FulfillmentCompleted':
      return {
        status: 'COMPLETED',
        orderId: event.aggregateId,
        trackingNumber: event.data.trackingNumber,
        courier: event.data.courierService
      };
    default:
      const _exhaustiveCheck: never = event;
      return currentState;
  }
}

// 3. Specific View Component (ActiveFulfillmentView)
interface ActiveFulfillmentViewProps {
  readonly state: Extract<UIState, { status: 'ACTIVE_FULFILLMENT' }>;
}

export const ActiveFulfillmentView: React.FC<ActiveFulfillmentViewProps> = ({ state }) => {
  return (
    <div className="p-4 border rounded bg-blue-50">
      <h2 className="font-bold">Fulfillment In Progress</h2>
      <p>Order ID: {state.orderId}</p>
      <p>Active Warehouses: {state.warehouses.join(', ')}</p>
    </div>
  );
};

// 4. React Dashboard Stream Component
interface OrderDashboardStreamProps {
  readonly uiState: UIState;
}

export const OrderDashboardStream: React.FC<OrderDashboardStreamProps> = ({ uiState }) => {
  switch (uiState.status) {
    case 'INITIALIZING':
      return <div className="p-4">Initializing order {uiState.orderId} ({uiState.itemCount} items)...</div>;
    case 'ALLOCATION_ERROR':
      return <div className="p-4 text-red-600">Error on Order {uiState.orderId}: {uiState.reason}</div>;
    case 'ACTIVE_FULFILLMENT':
      return <ActiveFulfillmentView state={uiState} />;
    case 'COMPLETED':
      return <div className="p-4 text-green-600">Completed! Tracking: {uiState.trackingNumber} via {uiState.courier}</div>;
    default:
      const _exhaustiveCheck: never = uiState;
      return null;
  }
};
