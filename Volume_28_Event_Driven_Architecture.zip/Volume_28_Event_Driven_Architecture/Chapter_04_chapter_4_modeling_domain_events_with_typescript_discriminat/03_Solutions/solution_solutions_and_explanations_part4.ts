/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define V1 and V2 Event Interfaces
export interface PaymentCapturedEventV1 {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly timestamp: number;
  readonly version: 1;
  readonly type: 'PaymentCaptured';
  readonly correlationId: string;
  readonly data: {
    readonly transactionId: string;
    readonly currency: string;
    readonly amount: number; // Legacy primitive
  };
}

export interface PaymentCapturedEventV2 {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly timestamp: number;
  readonly version: 2;
  readonly type: 'PaymentCaptured';
  readonly correlationId: string;
  readonly data: {
    readonly transactionId: string;
    readonly money: {
      readonly amountInCents: number; // Modern structured representation
      readonly currencyCode: string;
    };
  };
}

export type EvolvingPaymentEvent = PaymentCapturedEventV1 | PaymentCapturedEventV2;

// 2. Upcaster Function
export function upcastPaymentCaptured(event: PaymentCapturedEventV1): PaymentCapturedEventV2 {
  return {
    ...event,
    version: 2,
    data: {
      transactionId: event.data.transactionId,
      money: {
        amountInCents: Math.round(event.data.amount * 100),
        currencyCode: event.data.currency
      }
    }
  };
}

// 3. Runtime Type Guard for V1
export function isPaymentCapturedV1(event: unknown): event is PaymentCapturedEventV1 {
  return (
    typeof event === 'object' &&
    event !== null &&
    (event as any).type === 'PaymentCaptured' &&
    (event as any).version === 1 &&
    typeof (event as any).data === 'object' &&
    typeof (event as any).amount !== 'object' // distinguishing feature
  );
}

// 4. Generic Event Stream Middleware Pipeline
export function processIncomingEvent(rawEvent: unknown): PaymentCapturedEventV2 {
  if (isPaymentCapturedV1(rawEvent)) {
    // Intercept and upcast legacy schema at runtime
    return upcastPaymentCaptured(rawEvent);
  }

  // If it's already V2 (or validated through other guards), safely cast/return
  const candidate = rawEvent as PaymentCapturedEventV2;
  if (candidate.version === 2) {
    return candidate;
  }

  throw new Error(`Unsupported event version or malformed payload structure.`);
}
