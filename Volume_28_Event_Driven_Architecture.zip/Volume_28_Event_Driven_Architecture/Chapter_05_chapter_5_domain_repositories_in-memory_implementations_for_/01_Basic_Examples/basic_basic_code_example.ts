/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file InMemoryProjectRepository.ts
 * @description A self-contained TypeScript example demonstrating the Repository pattern 
 * and an In-Memory implementation for testing Domain-Driven Design aggregates in a SaaS context.
 */

// ============================================================================
// 1. DOMAIN EVENTS & BASE ENTITY DEFINITIONS
// ============================================================================

/**
 * Interface representing a domain event emitted by an aggregate root.
 */
export interface IDomainEvent {
    occurredOn: Date;
    eventName: string;
}

/**
 * Concrete domain event emitted when a Project's status changes.
 */
export class ProjectStatusChangedEvent implements IDomainEvent {
    public readonly occurredOn: Date = new Date();
    public readonly eventName = 'ProjectStatusChanged';

    constructor(
        public readonly projectId: string,
        public readonly newStatus: 'ACTIVE' | 'ARCHIVED'
    ) {}
}

/**
 * Base Aggregate Root class encapsulating domain invariants and uncommitted events.
 */
export abstract class AggregateRoot {
    private _domainEvents: IDomainEvent[] = [];

    /**
     * Collects a domain event to be dispatched after persistence.
     */
    protected addDomainEvent(event: IDomainEvent): void {
        this._domainEvents.push(event);
    }

    /**
     * Returns and clears uncommitted events (useful for event-driven architectures).
     */
    public pullDomainEvents(): IDomainEvent[] {
        const events = [...this._domainEvents];
        this._domainEvents = [];
        return events;
    }
}

// ============================================================================
// 2. PROJECT AGGREGATE IMPLEMENTATION
// ============================================================================

export type ProjectStatus = 'ACTIVE' | 'ARCHIVED';

/**
 * Project Aggregate Root containing business logic and state.
 */
export class Project extends AggregateRoot {
    private _status: ProjectStatus;

    constructor(
        public readonly id: string,
        public readonly tenantId: string,
        private _name: string,
        initialStatus: ProjectStatus = 'ACTIVE'
    ) {
        super();
        this._status = initialStatus;
    }

    public get name(): string {
        return this._name;
    }

    public get status(): ProjectStatus {
        return this._status;
    }

    /**
     * Business method to archive the project, enforcing domain rules.
     */
    public archive(): void {
        if (this._status === 'ARCHIVED') {
            throw new Error(`Project ${this.id} is already archived.`);
        }

        this._status = 'ARCHIVED';
        
        // Record the state transition event
        this.addDomainEvent(new ProjectStatusChangedEvent(this.id, 'ARCHIVED'));
    }
}

// ============================================================================
// 3. REPOSITORY INTERFACE
// ============================================================================

/**
 * Domain Repository Interface. 
 * Infrastructure agnostic: allows swapping Postgres for Memory effortlessly.
 */
export interface IProjectRepository {
    save(project: Project): Promise<void>;
    findById(id: string): Promise<Project | null>;
    findByTenantId(tenantId: string): Promise<Project[]>;
}

// ============================================================================
// 4. IN-MEMORY REPOSITORY IMPLEMENTATION FOR TESTING
// ============================================================================

/**
 * In-Memory implementation of IProjectRepository for fast, zero-I/O unit tests.
 */
export class InMemoryProjectRepository implements IProjectRepository {
    // Underlying storage mechanism: a Map keyed by Project ID
    private items: Map<string, Project> = new Map();

    /**
     * Persists or updates a project in memory.
     * Crucially, we perform a deep copy or store a reference safely depending on isolation needs.
     */
    public async save(project: Project): Promise<void> {
        // Simulating async network/disk jitter realistically if desired, 
        // but keeping it synchronous-like for test speed.
        this.items.set(project.id, project);
    }

    /**
     * Retrieves a project by its unique identifier.
     */
    public async findById(id: string): Promise<Project | null> {
        const project = this.items.get(id);
        if (!project) {
            return null;
        }
        return project;
    }

    /**
     * Queries projects belonging to a specific SaaS tenant.
     */
    public async findByTenantId(tenantId: string): Promise<Project[]> {
        const results: Project[] = [];
        for (const project of this.items.values()) {
            if (project.tenantId === tenantId) {
                results.push(project);
            }
        }
        return results;
    }

    /**
     * Helper method exclusively for tests to inspect state cleanly.
     */
    public clear(): void {
        this.items.clear();
    }
}

// ============================================================================
// 5. USAGE EXAMPLE (TEST SCENARIO)
// ============================================================================

async function runTestScenario() {
    const repository = new InMemoryProjectRepository();
    const tenantId = 'tenant-xyz-99';
    
    // 1. Create and save a new aggregate
    const project = new Project('proj-1', tenantId, 'SaaS Migration Dashboard');
    await repository.save(project);

    // 2. Fetch aggregate from repository
    const foundProject = await repository.findById('proj-1');
    if (!foundProject) {
        throw new Error('Project should exist');
    }

    // 3. Execute business logic method
    foundProject.archive();

    // 4. Verify domain events generated
    const events = foundProject.pullDomainEvents();
    console.log(`Generated Events:`, events);
    // Output should show ProjectStatusChangedEvent with newStatus: 'ARCHIVED'

    // 5. Persist updated state
    await repository.save(foundProject);

    // 6. Query by tenant
    const tenantProjects = await repository.findByTenantId(tenantId);
    console.log(`Tenant Project Count: ${tenantProjects.length}`);
    console.log(`Project Status: ${tenantProjects[0].status}`);
}

// Execute the simulation
runTestScenario().catch(console.error);
