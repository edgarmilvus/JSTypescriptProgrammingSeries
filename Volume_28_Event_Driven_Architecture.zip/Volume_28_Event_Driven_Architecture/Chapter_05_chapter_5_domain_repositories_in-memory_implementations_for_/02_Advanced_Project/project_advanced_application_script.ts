/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file advanced-edge-repository.ts
 * @description Advanced Application Script showcasing a DDD In-Memory Repository
 * supporting domain event tracking, optimistic concurrency control, and edge-ready state management.
 */

// ============================================================================
// 1. Domain Primitives & Interfaces
// ============================================================================

/**
 * Unique Identifier value object for aggregates.
 */
export class UniqueId {
  constructor(private readonly value: string) {}
  toString(): string { return this.value; }
  equals(other: UniqueId): boolean {
    return other instanceof UniqueId && other.value === this.value;
  }
}

/**
 * Base Domain Event interface tracking occurrence metadata.
 */
export interface DomainEvent {
  readonly eventId: string;
  readonly occurredOn: Date;
  readonly aggregateId: string;
}

/**
 * Base Aggregate Root enforcing invariant encapsulation and event recording.
 */
export abstract class AggregateRoot<TId extends UniqueId> {
  protected _id: TId;
  protected _version: number = 0;
  private _domainEvents: DomainEvent[] = [];

  constructor(id: TId) {
    this._id = id;
  }

  get id(): TId { return this._id; }
  get version(): number { return this._version; }

  getUncommittedEvents(): DomainEvent[] {
    return [...this._domainEvents];
  }

  clearEvents(): void {
    this._domainEvents = [];
  }

  protected addDomainEvent(event: DomainEvent): void {
    this._domainEvents.push(event);
  }

  // Increment version during state transitions to support OCC (Optimistic Concurrency Control)
  protected incrementVersion(): void {
    this._version++;
  }
}

// ============================================================================
// 2. Concrete Domain Model: AI Model Compression Task
// ============================================================================

export interface CompressionTaskCreatedEvent extends DomainEvent {
  readonly modelName: string;
  readonly targetReductionRatio: number;
}

export class ModelCompressionTask extends AggregateRoot<UniqueId> {
  private modelName: string;
  private targetReductionRatio: number;
  private status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';

  constructor(id: UniqueId, modelName: string, targetReductionRatio: number) {
    super(id);
    this.modelName = modelName;
    this.targetReductionRatio = targetReductionRatio;
    this.status = 'PENDING';

    // Record domain event for downstream microservices / edge workers
    this.addDomainEvent({
      eventId: crypto.randomUUID(),
      occurredOn: new Date(),
      aggregateId: id.toString(),
      modelName,
      targetReductionRatio,
    } as CompressionTaskCreatedEvent);
  }

  public startProcessing(): void {
    if (this.status !== 'PENDING') {
      throw new Error('Task can only be started from PENDING state.');
    }
    this.status = 'PROCESSING';
    this.incrementVersion();
  }

  public complete(): void {
    if (this.status !== 'PROCESSING') {
      throw new Error('Task must be processing before completion.');
    }
    this.status = 'COMPLETED';
    this.incrementVersion();
  }

  public getStatus() { return this.status; }
}

// ============================================================================
// 3. Repository Contract & In-Memory Implementation
// ============================================================================

export interface IRepository<T extends AggregateRoot<UniqueId>> {
  save(aggregate: T): Promise<void>;
  findById(id: UniqueId): Promise<T | null>;
}

/**
 * High-performance In-Memory Repository utilizing deep-cloning to simulate 
 * network serialization boundaries and prevent memory mutation leaks.
 */
export class InMemoryModelTaskRepository implements IRepository<ModelCompressionTask> {
  private items: Map<string, string> = new Map(); // Store serialized snapshots to simulate persistence isolation
  private versions: Map<string, number> = new Map();

  async save(aggregate: ModelCompressionTask): Promise<void> {
    const idStr = aggregate.id.toString();
    const currentVersion = this.versions.get(idStr) || 0;

    // Optimistic Concurrency Control Check
    if (aggregate.version !== currentVersion && currentVersion !== 0) {
      setItemConcurrencyError(idStr, aggregate.version, currentVersion);
    }

    // Simulate database write serialization
    this.items.set(idStr, JSON.stringify(aggregate));
    this.versions.set(idStr, aggregate.version + 1);
  }

  async findById(id: UniqueId): Promise<ModelCompressionTask | null> {
    const rawData = this.items.get(id.toString());
    if (!rawData) return null;

    const plainObject = JSON.parse(rawData);
    // Reconstitute domain object from serialized state
    const task = Object.setPrototypeOf(plainObject, ModelCompressionTask.prototype);
    return task;
  }
}

function setItemConcurrencyError(id: string, attempted: number, actual: number): void {
  throw new Error(`Concurrency conflict on Aggregate [${id}]. Attempted version ${attempted}, but current store version is ${actual}.`);
}

// ============================================================================
// 4. Execution Sandbox Example for Edge Runtime Testing
// ============================================================================

export async function runEdgeSimulation(): Promise<void> {
  const repo = new InMemoryModelTaskRepository();
  const taskId = new UniqueId('task-9988-alpha');

  // Initialize Aggregate
  const task = new ModelCompressionTask(taskId, 'Llama-3-8B-Instruct', 0.45);
  await repo.save(task);

  // Retrieve and mutate state
  const fetchedTask = await repo.findById(taskId);
  if (fetchedTask) {
    fetchedTask.startProcessing();
    fetchedTask.complete();
    await repo.save(fetchedTask);
    console.log(`Successfully completed task. Final state version: ${fetchedTask.version}`);
  }
}
