/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export class ConcurrencyError extends Error {
  constructor(aggregateId: string, expectedVersion: number, actualVersion: number) {
    super(`Concurrency conflict for aggregate ${aggregateId}. Expected version ${expectedVersion}, but found ${actualVersion}.`);
    this.name = 'ConcurrencyError';
  }
}

export interface DomainEvent {
  eventId: string;
  occurredOn: Date;
}

export abstract class AggregateRoot {
  private _version: number = 0;
  private _domainEvents: DomainEvent[] = [];

  get version(): number {
    return this._version;
  }

  protected setVersion(version: number): void {
    this._version = version;
  }

  getDomainEvents(): DomainEvent[] {
    return this._domainEvents;
  }

  clearDomainEvents(): void {
    this._domainEvents = [];
  }

  protected addDomainEvent(event: DomainEvent): void {
    this._domainEvents.push(event);
  }
}

export class UserAggregate extends AggregateRoot {
  constructor(public readonly id: string, public username: string, initialVersion: number = 0) {
    super();
    this.setVersion(initialVersion);
  }

  public changeUsername(newUsername: string): void {
    if (!newUsername || newUsername.trim() === '') {
      throw new Error('Username cannot be empty');
    }
    this.username = newUsername;
  }
}

export interface IRepository<T extends AggregateRoot> {
  findById(id: string): Promise<T | null>;
  save(aggregate: T): Promise<void>;
}

export class InMemoryUserRepository implements IRepository<UserAggregate> {
  // Storage mapping ID to the aggregate instance and its recorded version
  private storage: Map<string, { aggregate: UserAggregate; version: number }> = new Map();

  async findById(id: string): Promise<UserAggregate | null> {
    const record = this.storage.get(id);
    if (!record) {
      return null;
    }

    // Return a deep clone or reconstructed instance to prevent reference mutation bugs
    const cloned = new UserAggregate(record.aggregate.id, record.aggregate.username, record.version);
    return cloned;
  }

  async save(aggregate: UserAggregate): Promise<void> {
    const record = this.storage.get(aggregate.id);
    const currentStoredVersion = record ? record.version : 0;

    // Enforce Optimistic Concurrency Control: incoming version must be current + 1
    if (aggregate.version !== currentStoredVersion + 1) {
      throw new ConcurrencyError(aggregate.id, currentStoredVersion + 1, aggregate.version);
    }

    // Update internal version state tracking on the aggregate root via protected mechanism simulation
    // In practice, saving persists changes and bumps the internal version reference
    this.storage.set(aggregate.id, {
      aggregate: new UserAggregate(aggregate.id, aggregate.username, aggregate.version),
      version: aggregate.version,
    });

    // Clear domain events after successful write simulation
    aggregate.clearDomainEvents();
  }
}
