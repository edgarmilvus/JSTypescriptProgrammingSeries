/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface StorableEvent {
  aggregateId: string;
  version: number;
  eventName: string;
  payload: Record<string, unknown>;
  occurredOn: Date;
}

export interface AggregateSnapshot {
  aggregateId: string;
  version: number;
  state: Record<string, unknown>;
}

export interface IEventStore {
  saveEvents(aggregateId: string, events: StorableEvent[], expectedVersion: number): Promise<void>;
  getEventsForAggregate(aggregateId: string): Promise<StorableEvent[]>;
}

export interface ISnapshotStore {
  saveSnapshot(snapshot: AggregateSnapshot): Promise<void>;
  getSnapshot(aggregateId: string): Promise<AggregateSnapshot | null>;
}

export abstract class EventSourcedAggregate {
  protected version: number = -1;
  private uncommittedEvents: StorableEvent[] = [];

  get Version(): number {
    return this.version;
  }

  public abstract apply(event: StorableEvent): void;

  protected raise(eventName: string, payload: Record<string, unknown>): void {
    this.version++;
    const event: StorableEvent = {
      aggregateId: this.getAggregateId(),
      version: this.version,
      eventName,
      payload,
      occurredOn: new Date(),
    };
    this.apply(event);
    this.uncommittedEvents.push(event);
  }

  public getUncommittedEvents(): StorableEvent[] {
    return [...this.uncommittedEvents];
  }

  public markChangesAsCommitted(): void {
    this.uncommittedEvents = [];
  }

  public abstract getAggregateId(): string;
  public abstract toSnapshot(): Record<string, unknown>;
  public abstract restoreFromSnapshot(state: Record<string, unknown>): void;
}

export class EventSourcedOrderRepository {
  constructor(
    private eventStore: IEventStore,
    private snapshotStore: ISnapshotStore,
    private snapshotThreshold: number = 50
  ) {}

  async findById(aggregateId: string): Promise<EventSourcedAggregate | null> {
    // 1. Check snapshot store for an existing snapshot
    const snapshot = await this.snapshotStore.getSnapshot(aggregateId);
    
    // 2. Retrieve event stream from eventStore
    const events = await this.eventStore.getEventsForAggregate(aggregateId);

    if (!snapshot && events.length === 0) {
      return null;
    }

    // 3. Filter events if a snapshot exists (replay only events after snapshot version)
    const filteredEvents = snapshot
      ? events.filter((e) => e.version > snapshot.version)
      : events;

    // Dynamic instantiation requires a factory or constructor hook; here we assume instantiation via a subclass or stub
    // For demonstration, we use a mock factory pattern based on the first event or snapshot
    const aggregate = this.instantiateAggregate(aggregateId, snapshot, filteredEvents[0]);

    if (snapshot) {
      aggregate.restoreFromSnapshot(snapshot.state);
    }

    // Apply remaining events sequentially
    for (const event of filteredEvents) {
      aggregate.apply(event);
    }

    return aggregate;
  }

  async save(aggregate: EventSourcedAggregate): Promise<void> {
    // 1. Extract uncommitted events
    const uncommittedEvents = aggregate.getUncommittedEvents();
    if (uncommittedEvents.length === 0) return;

    const expectedVersion = aggregate.Version - uncommittedEvents.length;

    // 2. Persist events to event store with OCC check
    await this.eventStore.saveEvents(aggregate.getAggregateId(), uncommittedEvents, expectedVersion);

    // 3. Check if aggregate version crosses snapshot threshold
    if (aggregate.Version > 0 && aggregate.Version % this.snapshotThreshold === 0) {
      const snapshot: AggregateSnapshot = {
        aggregateId: aggregate.getAggregateId(),
        version: aggregate.Version,
        state: aggregate.toSnapshot(),
      };
      await this.snapshotStore.saveSnapshot(snapshot);
    }

    // 4. Clear uncommitted events
    aggregate.markChangesAsCommitted();
  }

  private instantiateAggregate(aggregateId: string, snapshot: AggregateSnapshot | null, firstEvent: StorableEvent): EventSourcedAggregate {
    // Helper factory stub to create concrete aggregate instance
    class ConcreteOrderAggregate extends EventSourcedAggregate {
      constructor(private id: string) { super(); }
      public getAggregateId(): string { return this.id; }
      public apply(event: StorableEvent): void { this.version = event.version; }
      public toSnapshot(): Record<string, unknown> { return {}; }
      public restoreFromSnapshot(state: Record<string, unknown>): void {}
    }
    return new ConcreteOrderAggregate(aggregateId);
  }
}
