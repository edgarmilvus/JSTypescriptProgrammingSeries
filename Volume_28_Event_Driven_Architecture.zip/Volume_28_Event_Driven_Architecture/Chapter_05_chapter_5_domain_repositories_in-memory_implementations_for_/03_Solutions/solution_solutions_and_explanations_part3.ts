/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface IDomainEvent {
  eventName: string;
  aggregateId: string;
  occurredOn: Date;
}

export class OrderPlacedEvent implements IDomainEvent {
  eventName = 'OrderPlaced';
  occurredOn = new Date();
  constructor(public aggregateId: string, public customerId: string, public totalAmount: number) {}
}

export class OrderShippedEvent implements IDomainEvent {
  eventName = 'OrderShipped';
  occurredOn = new Date();
  constructor(public aggregateId: string, public trackingNumber: string) {}
}

type EventHandler<T extends IDomainEvent = IDomainEvent> = (event: T) => Promise<void> | void;

export class InMemoryEventBus {
  private handlers: Map<string, EventHandler[]> = new Map();

  public subscribe<T extends IDomainEvent>(eventName: string, handler: EventHandler<T>): void {
    if (!this.handlers.has(eventName)) {
      this.handlers.set(eventName, []);
    }
    this.handlers.get(eventName)!.push(handler as EventHandler);
  }

  public async publish(event: IDomainEvent): Promise<void> {
    const eventHandlers = this.handlers.get(event.eventName);
    if (!eventHandlers) return;

    // Execute handlers sequentially or concurrently
    for (const handler of eventHandlers) {
      await handler(event);
    }
  }
}

export interface OrderReadModel {
  orderId: string;
  customerId: string;
  totalAmount: number;
  status: 'Pending' | 'Shipped';
  trackingNumber?: string;
}

export class OrderDashboardProjector {
  private readModelStore: Map<string, OrderReadModel> = new Map();

  constructor(private eventBus: InMemoryEventBus) {
    this.eventBus.subscribe('OrderPlaced', (event) => this.handleOrderPlaced(event as OrderPlacedEvent));
    this.eventBus.subscribe('OrderShipped', (event) => this.handleOrderShipped(event as OrderShippedEvent));
  }

  private async handleOrderPlaced(event: OrderPlacedEvent): Promise<void> {
    const readModel: OrderReadModel = {
      orderId: event.aggregateId,
      customerId: event.customerId,
      totalAmount: event.totalAmount,
      status: 'Pending',
    };
    this.readModelStore.set(event.aggregateId, readModel);
  }

  private async handleOrderShipped(event: OrderShippedEvent): Promise<void> {
    const existing = this.readModelStore.get(event.aggregateId);
    if (existing) {
      existing.status = 'Shipped';
      existing.trackingNumber = event.trackingNumber;
      this.readModelStore.set(event.aggregateId, existing);
    }
  }

  public async getOrderById(orderId: string): Promise<OrderReadModel | null> {
    return this.readModelStore.get(orderId) || null;
  }
}
