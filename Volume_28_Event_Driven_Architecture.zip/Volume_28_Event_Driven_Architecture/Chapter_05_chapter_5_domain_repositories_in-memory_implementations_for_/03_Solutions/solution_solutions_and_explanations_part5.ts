/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface AggregateRoot {
  readonly id: string;
  version: number;
}

export interface IRepository<T extends AggregateRoot> {
  findById(id: string): Promise<T | null>;
  save(aggregate: T): Promise<void>;
}

export interface DiagnosticMetrics {
  activeListeners: number;
  storedAggregates: number;
  estimatedMemoryUsageBytes: number;
}

export class LeakDetectorRepositoryDecorator<T extends AggregateRoot> implements IRepository<T> {
  private accessCount: number = 0;

  constructor(private innerRepository: IRepository<T>, private storeReference: Map<string, T>) {}

  async findById(id: string): Promise<T | null> {
    this.accessCount++;
    return this.innerRepository.findById(id);
  }

  async save(aggregate: T): Promise<void> {
    return this.innerRepository.save(aggregate);
  }

  public getDiagnostics(): DiagnosticMetrics {
    const storedAggregates = this.storeReference.size;
    // Estimate memory footprint via rough JSON serialization sizing approximation
    let serializedSize = 0;
    for (const [, agg] of this.storeReference.entries()) {
      serializedSize += JSON.stringify(agg).length * 2; // UTF-16 estimation
    }

    return {
      activeListeners: 0, // Managed separately if wrapping event buses
      storedAggregates,
      estimatedMemoryUsageBytes: serializedSize,
    };
  }

  public resetDiagnosticMetrics(): void {
    this.storeReference.clear();
    this.accessCount = 0;
  }
}

// Unit Test Template Example:
describe('LeakDetectorRepositoryDecorator', () => {
  it('should report zero stored aggregates after repository reset', async () => {
    const backingStore = new Map<string, AggregateRoot>();
    const mockRepo: IRepository<AggregateRoot> = {
      async findById(id) { return backingStore.get(id) || null; },
      async save(agg) { backingStore.set(agg.id, agg); }
    };

    const decorator = new LeakDetectorRepositoryDecorator(mockRepo, backingStore);
    
    await decorator.save({ id: '1', version: 1 });
    await decorator.save({ id: '2', version: 1 });

    expect(decorator.getDiagnostics().storedAggregates).toBe(2);

    decorator.resetDiagnosticMetrics();

    expect(decorator.getDiagnostics().storedAggregates).toBe(0);
  });
});
