/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

export interface StorableEvent {
  aggregateId: string;
  version: number;
  eventName: string;
  payload: Record<string, unknown>;
  occurredOn: Date;
}

export interface AggregateSnapshot {
  aggregateId: string;
  version: number;
  state: Record<string, unknown>;
}

export interface IEventStore {
  saveEvents(aggregateId: string, events: StorableEvent[], expectedVersion: number): Promise<void>;
  getEventsForAggregate(aggregateId: string): Promise<StorableEvent[]>;
}

export interface ISnapshotStore {
  saveSnapshot(snapshot: AggregateSnapshot): Promise<void>;
  getSnapshot(aggregateId: string): Promise<AggregateSnapshot | null>;
}

export abstract class EventSourcedAggregate {
  protected version: number = -1;
  private uncommittedEvents: StorableEvent[] = [];

  get Version(): number {
    return this.version;
  }

  public abstract apply(event: StorableEvent): void;

  protected raise(eventName: string, payload: Record<string, unknown>): void {
    this.version++;
    const event: StorableEvent = {
      aggregateId: this.getAggregateId(),
      version: this.version,
      eventName,
      payload,
      occurredOn: new Date(),
    };
    this.apply(event);
    this.uncommittedEvents.push(event);
  }

  public getUncommittedEvents(): StorableEvent[] {
    return [...this.uncommittedEvents];
  }

  public markChangesAsCommitted(): void {
    this.uncommittedEvents = [];
  }

  public abstract getAggregateId(): string;
  public abstract toSnapshot(): Record<string, unknown>;
  public abstract restoreFromSnapshot(state: Record<string, unknown>): void;
}

export class EventSourcedOrderRepository {
  constructor(
    private eventStore: IEventStore,
    private snapshotStore: ISnapshotStore,
    private snapshotThreshold: number = 50 // Take a snapshot every 50 events
  ) {}

  async findById(aggregateId: string): Promise<EventSourcedAggregate | null> {
    // TODO: 1. Check snapshot store for an existing snapshot of the aggregate.
    // TODO: 2. Retrieve event stream from eventStore, filtering for events > snapshot version (if snapshot exists).
    // TODO: 3. Instantiate aggregate, restore from snapshot if available, and apply remaining events.
    // TODO: 4. Return fully hydrated aggregate or null if neither snapshot nor events exist.
    throw new Error('Not implemented');
  }

  async save(aggregate: EventSourcedAggregate): Promise<void> {
    // TODO: 1. Extract uncommitted events from aggregate.
    // TODO: 2. Persist events to eventStore with optimistic concurrency checks.
    // TODO: 3. Check if aggregate version crosses snapshotThreshold boundary; if so, persist a snapshot.
    // TODO: 4. Clear uncommitted events on aggregate.
    throw new Error('Not implemented');
  }
}
