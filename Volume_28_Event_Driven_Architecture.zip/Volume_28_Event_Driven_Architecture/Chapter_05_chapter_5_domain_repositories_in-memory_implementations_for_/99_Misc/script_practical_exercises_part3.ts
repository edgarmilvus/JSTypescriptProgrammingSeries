/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export interface IDomainEvent {
  eventName: string;
  aggregateId: string;
  occurredOn: Date;
}

export class OrderPlacedEvent implements IDomainEvent {
  eventName = 'OrderPlaced';
  occurredOn = new Date();
  constructor(public aggregateId: string, public customerId: string, public totalAmount: number) {}
}

export class OrderShippedEvent implements IDomainEvent {
  eventName = 'OrderShipped';
  occurredOn = new Date();
  constructor(public aggregateId: string, public trackingNumber: string) {}
}

type EventHandler<T extends IDomainEvent = IDomainEvent> = (event: T) => Promise<void> | void;

export class InMemoryEventBus {
  private handlers: Map<string, EventHandler[]> = new Map();

  public subscribe<T extends IDomainEvent>(eventName: string, handler: EventHandler<T>): void {
    // TODO: Register handler for the specified eventName
    throw new Error('Not implemented');
  }

  public async publish(event: IDomainEvent): Promise<void> {
    // TODO: Execute all registered handlers for event.eventName asynchronously or sequentially
    throw new Error('Not implemented');
  }
}

export interface OrderReadModel {
  orderId: string;
  customerId: string;
  totalAmount: number;
  status: 'Pending' | 'Shipped';
  trackingNumber?: string;
}

export class OrderDashboardProjector {
  private readModelStore: Map<string, OrderReadModel> = new Map();

  constructor(private eventBus: InMemoryEventBus) {
    // TODO: Subscribe to 'OrderPlaced' and 'OrderShipped' events
    throw new Error('Not implemented');
  }

  private async handleOrderPlaced(event: OrderPlacedEvent): Promise<void> {
    // TODO: Insert new record into readModelStore
    throw new Error('Not implemented');
  }

  private async handleOrderShipped(event: OrderShippedEvent): Promise<void> {
    // TODO: Update existing record status and trackingNumber in readModelStore
    throw new Error('Not implemented');
  }

  public async getOrderById(orderId: string): Promise<OrderReadModel | null> {
    // TODO: Return read model from store or null
    throw new Error('Not implemented');
  }
}
