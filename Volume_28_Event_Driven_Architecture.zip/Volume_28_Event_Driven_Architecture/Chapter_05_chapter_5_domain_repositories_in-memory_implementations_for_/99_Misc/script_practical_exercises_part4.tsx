/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect } from 'react';

// Interfaces mirroring our domain classes from previous exercises
interface OrderReadModel {
  orderId: string;
  customerId: string;
  totalAmount: number;
  status: 'Pending' | 'Shipped';
  trackingNumber?: string;
}

interface LogEntry {
  id: string;
  timestamp: string;
  eventName: string;
  payload: string;
}

interface CqrsInspectorDashboardProps {
  // Mock or stub interface representations for the dashboard data sources
  fetchReadModels: () => Promise<OrderReadModel[]>;
  onPlaceOrder: (customerId: string, totalAmount: number) => Promise<void>;
  subscribeToEvents: (callback: (log: LogEntry) => void) => () => void; // returns unsubscribe function
}

export const CqrsInspectorDashboard: React.FC<CqrsInspectorDashboardProps> = ({
  fetchReadModels,
  onPlaceOrder,
  subscribeToEvents,
}) => {
  const [orders, setOrders] = useState<OrderReadModel[]>([]);
  const [eventLogs, setEventLogs] = useState<LogEntry[]>([]);
  const [customerIdInput, setCustomerIdInput] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [loading, setLoading] = useState<boolean>(false);

  // TODO: Implement useEffect to load initial read models and subscribe to real-time event logs.
  // Make sure to clean up event subscriptions on component unmount.

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Validate inputs, call onPlaceOrder, handle loading state, and refresh orders list.
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h2>CQRS System Inspector Dashboard</h2>
      
      {/* Command Submission Form Section */}
      <div style={{ background: '#f4f4f4', padding: '15px', borderRadius: '8px', marginBottom: '20px' }}>
        <h3>Dispatch Command: Place Order</h3>
        <form onSubmit={handleFormSubmit} style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <div>
            <label style={{ display: 'block', fontSize: '12px' }}>Customer ID:</label>
            <input 
              type="text" 
              value={customerIdInput} 
              onChange={(e) => setCustomerIdInput(e.target.value)}
              placeholder="cust_123" 
            />
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '12px' }}>Total Amount:</label>
            <input 
              type="number" 
              value={amountInput} 
              onChange={(e) => setAmountInput(e.target.value)}
              placeholder="99.99" 
            />
          </div>
          <button type="submit" disabled={loading} style={{ marginTop: '16px', padding: '6px 12px' }}>
            {loading ? 'Processing...' : 'Submit Command'}
          </button>
        </form>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Read Models Table Section */}
        <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
          <h3>Read Models (Query Side)</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #ddd', textAlign: 'left' }}>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {/* TODO: Map over orders state and render rows */}
              <tr>
                <td colSpan={4} style={{ textAlign: 'center', color: '#888' }}>No orders found.</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Real-Time Event Stream Log Section */}
        <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', background: '#1e1e1e', color: '#d4d4d4' }}>
          <h3 style={{ color: '#9cdcfe' }}>Live Event Stream</h3>
          <div style={{ height: '250px', overflowY: 'auto', fontFamily: 'monospace', fontSize: '12px' }}>
            {/* TODO: Map over eventLogs state and render timestamped logs */}
            <div style={{ color: '#858585' }}>Listening for domain events...</div>
          </div>
        </div>
      </div>
    </div>
  );
};
