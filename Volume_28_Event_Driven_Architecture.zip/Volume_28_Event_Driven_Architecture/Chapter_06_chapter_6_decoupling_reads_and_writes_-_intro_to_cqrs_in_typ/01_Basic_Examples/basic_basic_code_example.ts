/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

// ==========================================
// 1. COMMAND SIDE: Writing State
// ==========================================

/**
 * Zod schema defining the strict shape and constraints for updating a user's email.
 * This guarantees runtime validation before any state modification occurs.
 */
const UpdateUserEmailCommandSchema = z.object({
  userId: z.string().uuid({ message: "Invalid user ID format; must be a valid UUID." }),
  newEmail: z.string().email({ message: "Invalid email format provided." }),
  updatedAt: z.date(),
});

/**
 * TypeScript type inferred directly from the Zod schema, bridging runtime 
 * validation with compile-time type safety.
 */
type UpdateUserEmailCommand = z.infer<typeof UpdateUserEmailCommandSchema>;

/**
 * In-memory data store representing our write-optimized database 
 * (e.g., PostgreSQL primary instance).
 */
const writeDatabase = new Map<string, { id: string; email: string; updatedAt: Date }>();

// Seed initial data into the write store
writeDatabase.set("123e4567-e89b-12d3-a456-426614174000", {
  id: "123e4567-e89b-12d3-a456-426614174000",
  email: "alice@legacy-domain.com",
  updatedAt: new Date("2023-01-01T00:00:00.000Z"),
});

/**
 * The Command Handler responsible for executing the business logic 
 * associated with changing a user's email. It does NOT return data to 
 * the caller other than confirmation of success.
 */
class UpdateUserEmailHandler {
  /**
   * Executes the command after validating the input payload.
   * @param rawCommand - The unvalidated input payload from the API/Client.
   */
  public async handle(rawCommand: unknown): Promise<void> {
    // 1. Enforce runtime validation using our Zod schema
    const command: UpdateUserEmailCommand = UpdateUserEmailCommandSchema.parse(rawCommand);

    // 2. Fetch aggregate root from the write database
    const userRecord = writeDatabase.get(command.userId);
    if (!userRecord) {
      throw new Error(`User with ID ${command.userId} not found in write store.`);
    }

    // 3. Perform business validation / invariant checks
    if (userRecord.email === command.newEmail) {
      throw new Error("New email must be different from the current email.");
    }

    // 4. Mutate state in the write database
    userRecord.email = command.newEmail;
    userRecord.updatedAt = command.updatedAt;
    writeDatabase.set(command.userId, userRecord);

    console.log(`[Write Model] Successfully updated email for user ${command.userId} to ${command.newEmail}`);

    // 5. In a real CQRS system, we would publish an event here (e.g., UserEmailChangedEvent) 
    // to asynchronously project changes to the read database. For this basic example, 
    // we simulate that projection directly.
    UserProjector.project({
      id: userRecord.id,
      displayEmail: userRecord.email,
      lastModifiedTimestamp: userRecord.updatedAt.getTime(),
    });
  }
}

// ==========================================
// 2. READ SIDE: Fetching Projections
// ==========================================

/**
 * Zod schema for querying the read model. Optimized for UI consumption.
 */
const GetUserDashboardQuerySchema = z.object({
  userId: z.string().uuid(),
});

type GetUserDashboardQuery = z.infer<typeof GetUserDashboardQuerySchema>;

/**
 * A denormalized Read Model designed explicitly for fast UI dashboard rendering.
 * Notice how this shape differs from the normalized write database schema.
 */
interface UserDashboardReadModel {
  id: string;
  displayEmail: string;
  lastModifiedTimestamp: number;
  uiNotificationMessage: string;
}

/**
 * In-memory data store representing our read-optimized database 
 * (e.g., MongoDB, Elasticsearch, or a dedicated read replica).
 */
const readDatabase = new Map<string, UserDashboardReadModel>();

/**
 * The Projector component listens to write-side changes (or simulates them) 
 * and updates the read-optimized denormalized view.
 */
class UserProjector {
  public static project(eventData: { id: string; displayEmail: string; lastModifiedTimestamp: number }): void {
    const denormalizedView: UserDashboardReadModel = {
      id: eventData.id,
      displayEmail: eventData.displayEmail.toUpperCase(), // Transform data for UI presentation needs
      lastModifiedTimestamp: eventData.lastModifiedTimestamp,
      uiNotificationMessage: `Profile updated successfully at ${new Date(eventData.lastModifiedTimestamp).toISOString()}`,
    };

    // Save directly to the read store
    readDatabase.set(eventData.id, denormalizedView);
    console.log(`[Read Model] Projection updated for user dashboard:`, denormalizedView);
  }
}

/**
 * The Query Handler responsible for fetching data exclusively. 
 * It contains zero business logic, zero state mutations, and executes with maximum read performance.
 */
class GetUserDashboardHandler {
  /**
   * Executes the query and returns a denormalized read model for UI consumption.
   * @param rawQuery - The query parameters requested by the client.
   */
  public async handle(rawQuery: unknown): Promise<UserDashboardReadModel> {
    // 1. Validate query parameters
    const query: GetUserDashboardQuery = GetUserDashboardQuerySchema.parse(rawQuery);

    // 2. Directly fetch from the read database without complex joins or computations
    const dashboardData = readDatabase.get(query.userId);
    if (!dashboardData) {
      throw new Error(`Dashboard view for user ${query.userId} not found.`);
    }

    // 3. Return the exact shape required by the UI
    return dashboardData;
  }
}

// ==========================================
// 3. EXECUTION DEMONSTRATION
// ==========================================

async function runDemo() {
  const targetUserId = "123e4567-e89b-12d3-a456-426614174000";

  // Initially, let's populate the read model to mirror the initial seed data
  UserProjector.project({
    id: targetUserId,
    displayEmail: "alice@legacy-domain.com",
    lastModifiedTimestamp: new Date("2023-01-01T00:00:00.000Z").getTime(),
  });

  console.log("\n--- STEP 1: Executing a Write Command ---");
  const commandHandler = new UpdateUserEmailHandler();
  
  // Construct the command payload
  const commandPayload = {
    userId: targetUserId,
    newEmail: "alice.new@saas-platform.com",
    updatedAt: new Date(),
  };

  // Execute the command (State change)
  await commandHandler.handle(commandPayload);

  console.log("\n--- STEP 2: Executing a Read Query ---");
  const queryHandler = new GetUserDashboardHandler();
  
  // Construct the query payload
  const queryPayload = {
    userId: targetUserId,
  };

  // Execute the query (Data fetching for UI)
  const dashboardResult = await queryHandler.handle(queryPayload);
  
  console.log("\n--- STEP 3: Final UI Presentation Output ---");
  console.log(dashboardResult);
}

runEmpiricalDemo();
// (Executing the demo function)
runDemo();
