/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

// ==========================================
// 1. DOMAIN EVENTS & CORE TYPES
// ==========================================

/**
 * Base interface for all domain events emitted on the write side.
 */
interface DomainEvent {
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly aggregateId: string;
  readonly eventType: string;
}

/**
 * Emitted when a new SaaS workspace is successfully provisioned.
 */
interface WorkspaceCreatedEvent extends DomainEvent {
  readonly eventType: 'WorkspaceCreated';
  readonly name: string;
  readonly ownerEmail: string;
}

/**
 * Emitted when a workspace tier is upgraded.
 */
interface WorkspaceUpgradedEvent extends DomainEvent {
  readonly eventType: 'WorkspaceUpgraded';
  readonly newTier: 'ENTERPRISE' | 'SCALE';
}

type AnyWorkspaceEvent = WorkspaceCreatedEvent | WorkspaceUpgradedEvent;

// ==========================================
// 2. WRITE SIDE: COMMANDS, MODELS & HANDLERS
// ==========================================

/**
 * Command to instantiate a new workspace.
 */
interface CreateWorkspaceCommand {
  readonly commandType: 'CreateWorkspace';
  readonly workspaceId: string;
  readonly name: string;
  readonly ownerEmail: string;
}

/**
 * Command to upgrade an existing workspace.
 */
interface UpgradeWorkspaceCommand {
  readonly commandType: 'UpgradeWorkspace';
  readonly workspaceId: string;
  readonly newTier: 'ENTERPRISE' | 'SCALE';
}

type AnyCommand = CreateWorkspaceCommand | UpgradeWorkspaceCommand;

/**
 * Write Model: The Workspace Aggregate Root containing pure business logic.
 */
class WorkspaceAggregate {
  private uncommittedEvents: AnyWorkspaceEvent[] = [];
  private isCreated = false;
  private tier: 'FREE' | 'SCALE' | 'ENTERPRISE' = 'FREE';

  constructor(public readonly id: string) {}

  /**
   * Executes the creation command and records the corresponding domain event.
   */
  public create(name: string, ownerEmail: string): void {
    if (this.isCreated) {
      throw new Error(`Workspace ${this.id} already exists.`);
    }
    if (!name || name.trim().length === 0) {
      throw new Error('Workspace name cannot be empty.');
    }

    const event: WorkspaceCreatedEvent = {
      eventId: randomUUID(),
      occurredAt: new Date(),
      aggregateId: this.id,
      eventType: 'WorkspaceCreated',
      name,
      ownerEmail,
    };

    this.apply(event);
    this.uncommittedEvents.push(event);
  }

  /**
   * Executes the tier upgrade command and records the domain event.
   */
  public upgrade(newTier: 'ENTERPRISE' | 'SCALE'): void {
    if (!this.isCreated) {
      throw new Error(`Workspace ${this.id} does not exist yet.`);
    }
    if (this.tier === newTier) {
      throw new Error(`Workspace is already on tier ${newTier}.`);
    }

    const event: WorkspaceUpgradedEvent = {
      eventId: randomUUID(),
      occurredAt: new Date(),
      aggregateId: this.id,
      eventType: 'WorkspaceUpgraded',
      newTier,
    };

    this.apply(event);
    this.uncommittedEvents.push(event);
  }

  /**
   * Internal state mutator driven by events (Event Sourcing hydration baseline).
   */
  private apply(event: AnyWorkspaceEvent): void {
    switch (event.eventType) {
      case 'WorkspaceCreated':
        this.isCreated = true;
        break;
      case 'WorkspaceUpgraded':
        this.tier = event.newTier;
        break;
    }
  }

  public getUncommittedEvents(): AnyWorkspaceEvent[] {
    return [...this.uncommittedEvents];
  }

  public clearUncommittedEvents(): void {
    this.uncommittedEvents = [];
  }
}

/**
 * In-memory Write Store simulating an Event Store / Write Database.
 */
class EventStore {
  private store: Map<string, AnyWorkspaceEvent[]> = new Map();

  async saveEvents(aggregateId: string, events: AnyWorkspaceEvent[]): Promise<void> {
    const existing = this.store.get(aggregateId) || [];
    this.store.set(aggregateId, [...existing, ...events]);
    // In a real-world architecture, these events would also be published to a message broker (e.g., Kafka, RabbitMQ)
  }

  async getEventsForAggregate(aggregateId: string): Promise<AnyWorkspaceEvent[]> {
    return this.store.get(aggregateId) || [];
  }
}

/**
 * Command Bus Handler coordinating the write workflow.
 */
class WorkspaceCommandBus {
  constructor(private readonly eventStore: EventStore, private readonly eventProjector: ReadProjector) {}

  async handle(command: AnyCommand): Promise<void> {
    const aggregate = new WorkspaceAggregate(command.workspaceId);

    // Rehydrate aggregate state if it already exists (simplified load pattern)
    const pastEvents = await this.eventStore.getEventsForAggregate(command.workspaceId);
    for (const event of pastEvents) {
      // In a full implementation, apply past events to rebuild state
    }

    if (command.commandType === 'CreateWorkspace') {
      aggregate.create(command.name, command.ownerEmail);
    } else if (command.commandType === 'UpgradeWorkspace') {
      aggregate.upgrade(command.newTier);
    }

    const newEvents = aggregate.getUncommittedEvents();
    await this.eventStore.saveEvents(command.workspaceId, newEvents);
    aggregate.clearUncommittedEvents();

    // Project events asynchronously or synchronously to the read database
    for (const event of newEvents) {
      await this.eventProjector.project(event);
    }
  }
}

// ==========================================
// 3. READ SIDE: PROJECTIONS, QUERIES & UI MODELS
// ==========================================

/**
 * Optimized Read Model tailored specifically for Dashboard UI consumption.
 */
interface WorkspaceDashboardReadModel {
  readonly id: string;
  readonly name: string;
  readonly owner: string;
  readonly currentTier: string;
  readonly updatedAt: Date;
}

/**
 * In-memory Read Database (e.g., PostgreSQL read-replica or MongoDB collection).
 */
class ReadDatabase {
  private projections: Map<string, WorkspaceDashboardReadModel> = new Map();

  async upsert(id: string, model: WorkspaceDashboardReadModel): Promise<void> {
    this.projections.set(id, model);
  }

  async findById(id: string): Promise<WorkspaceDashboardReadModel | null> {
    return this.projections.get(id) || null;
  }
}

/**
 * Event Projector responsible for transforming write-side events into read-optimized models.
 */
class ReadProjector {
  constructor(private readonly readDb: ReadDatabase) {}

  async project(event: AnyWorkspaceEvent): Promise<void> {
    const existing = await this.readDb.findById(event.aggregateId);

    if (event.eventType === 'WorkspaceCreated') {
      const newModel: WorkspaceDashboardReadModel = {
        id: event.aggregateId,
        name: event.name,
        owner: event.ownerEmail,
        currentTier: 'FREE',
        updatedAt: event.occurredAt,
      };
      await this.readDb.upsert(event.aggregateId, newModel);
    } else if (event.eventType === 'WorkspaceUpgraded' && existing) {
      const updatedModel: WorkspaceDashboardReadModel = {
        ...existing,
        currentTier: event.newTier,
        updatedAt: event.occurredAt,
      };
      await this.readDb.upsert(event.aggregateId, updatedModel);
    }
  }
}

/**
 * Query Handler optimized for fast data retrieval bypassing all domain overhead.
 */
class GetWorkspaceDashboardQueryHandler {
  constructor(private readonly readDb: ReadDatabase) {}

  async execute(workspaceId: string): Promise<WorkspaceDashboardReadModel> {
    const record = await this.readDb.findById(workspaceId);
    if (!record) {
      throw new Error(`Workspace read model not found for ID: ${workspaceId}`);
    }
    return record;
  }
}

// ==========================================
// 4. EXECUTION DEMONSTRATION (Next.js API Context)
// ==========================================

async function runDemo() {
  const eventStore = new EventStore();
  const readDb = new ReadDatabase();
  const projector = new ReadProjector(readDb);
  const commandBus = new WorkspaceCommandBus(eventStore, projector);
  const queryHandler = new GetWorkspaceDashboardQueryHandler(readDb);

  const workspaceId = randomUUID();

  // 1. Execute Write Command
  console.log('--- Executing CreateWorkspace Command ---');
  await commandBus.handle({
    commandType: 'CreateWorkspace',
    workspaceId,
    name: 'Acme Corp Engineering',
    ownerEmail: 'admin@acme.com',
  });

  // 2. Execute Write Command: Upgrade
  console.log('--- Executing UpgradeWorkspace Command ---');
  await commandBus.handle({
    commandType: 'UpgradeWorkspace',
    workspaceId,
    newTier: 'ENTERPRISE',
  });

  // 3. Execute Read Query (Zero domain processing, direct read model fetch)
  console.log('--- Executing Read Query for UI Dashboard ---');
  const dashboardData = await queryHandler.execute(workspaceId);
  console.log('Dashboard Read Model Result:', dashboardData);
}

runDemo();
