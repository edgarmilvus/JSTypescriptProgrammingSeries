/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema for the RegisterUserCommand
export const RegisterUserCommandSchema = z.object({
  userId: z.string().uuid({ message: "Invalid UUID format for userId" }),
  email: z.string().email({ message: "Invalid email format" }),
  subscriptionTier: z.enum(['free', 'pro', 'enterprise'], {
    message: "Subscription tier must be 'free', 'pro', or 'enterprise'",
  }),
  metadata: z
    .object({
      organizationId: z.string().min(1, "Organization ID cannot be empty"),
      seatLimit: z.number().int().positive("Seat limit must be a positive integer"),
    })
    .optional(),
});

// 2. Infer the TypeScript type from the schema
export type RegisterUserCommand = z.infer<typeof RegisterUserCommandSchema>;

// 3. Define the CommandHandler interface
export interface CommandHandler<TCommand, TResult> {
  handle(command: TCommand): Promise<TResult>;
}

// 4. Implement the safe execution wrapper
export async function executeCommand<TCommand, TResult>(
  rawPayload: unknown,
  schema: z.ZodSchema<TCommand>,
  handler: CommandHandler<TCommand, TResult>
): Promise<TResult> {
  // Parse and validate the raw payload against the provided Zod schema
  const validationResult = schema.safeParse(rawPayload);

  if (!validationResult.success) {
    // Format and throw structured validation errors
    const errorMessage = validationResult.error.errors
      .map((err) => `${err.path.join('.')}: ${err.message}`)
      .join(', ');
    throw new Error(`Command Validation Failed: ${errorMessage}`);
  }

  // Invoke the command handler with the fully validated and type-safe payload
  return await handler.handle(validationResult.data);
}
