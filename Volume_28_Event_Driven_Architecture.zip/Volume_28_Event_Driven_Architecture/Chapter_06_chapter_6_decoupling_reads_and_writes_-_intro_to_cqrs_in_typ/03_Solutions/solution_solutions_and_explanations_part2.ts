/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface UserRegisteredEvent {
  eventId: string;
  timestamp: Date;
  version: number;
  payload: {
    userId: string;
    email: string;
    subscriptionTier: 'free' | 'pro' | 'enterprise';
  };
}

export interface UserDashboardView {
  userId: string;
  email: string;
  tier: string;
  theme: string;
  activeWidgetsCount: number;
  lastUpdatedAt: Date;
}

export class UserDashboardProjectionHandler {
  private readStore: Map<string, UserDashboardView> = new Map();
  private processedEvents: Set<string> = new Set();

  public async handleEvent(event: UserRegisteredEvent): Promise<void> {
    // 1. Idempotency Check: Prevent duplicate processing from at-least-once message delivery
    if (this.processedEvents.has(event.eventId)) {
      return; 
    }

    const { userId, email, subscriptionTier } = event.payload;

    // 2. Transform the event payload into a denormalized Read Model DTO
    const dashboardView: UserDashboardView = {
      userId,
      email,
      tier: subscriptionTier,
      theme: 'light', // Default dashboard setting optimized for UI read models
      activeWidgetsCount: 3,
      lastUpdatedAt: event.timestamp,
    };

    // 3. Save/upsert the projection view into the fast read-side data store
    this.readStore.set(userId, dashboardView);

    // 4. Mark the event as successfully processed
    this.processedEvents.add(event.eventId);
  }

  public async getDashboardView(userId: string): Promise<UserDashboardView | null> {
    // Retrieve the pre-computed read model directly without complex joins
    return this.readStore.get(userId) ?? null;
  }
}
