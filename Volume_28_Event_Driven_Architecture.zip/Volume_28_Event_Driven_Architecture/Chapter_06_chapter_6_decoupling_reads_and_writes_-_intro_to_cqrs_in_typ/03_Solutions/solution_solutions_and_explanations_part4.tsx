/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// Mock types and interfaces for the component
export interface UserSummaryDto {
  userId: string;
  email: string;
  tier: 'free' | 'pro' | 'enterprise';
  joinedAt: Date;
}

export interface PaginatedUserResponse {
  data: UserSummaryDto[];
  totalCount: number;
}

export class GetUsersByTierQuery {
  constructor(public readonly tier: 'free' | 'pro' | 'enterprise', public readonly page = 1) {}
}

export class UpgradeUserSubscriptionCommand {
  constructor(public readonly userId: string, public readonly newTier: 'pro' | 'enterprise') {}
}

export interface AdminUserDashboardProps {
  queryDispatcher: {
    dispatch<TResult>(query: any): Promise<TResult>;
  };
  commandDispatcher: {
    execute(command: any): Promise<void>;
  };
}

export const AdminUserDashboard: React.FC<AdminUserDashboardProps> = ({
  queryDispatcher,
  commandDispatcher,
}) => {
  const [selectedTier, setSelectedTier] = useState<'free' | 'pro' | 'enterprise'>('free');
  const [users, setUsers] = useState<UserSummaryDto[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Read Side: Fetch users by dispatching a query
  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const query = new GetUsersByTierQuery(selectedTier);
      const response = await queryDispatcher.dispatch<PaginatedUserResponse>(query);
      setUsers(response.data);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load users projection.');
    } finally {
      setLoading(false);
    }
  }, [queryDispatcher, selectedTier]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Write Side: Dispatch command to upgrade tier, then refresh read model query
  const handleUpgradeTier = async (userId: string, targetTier: 'pro' | 'enterprise') => {
    setErrorMessage(null);
    try {
      const command = new UpgradeUserSubscriptionCommand(userId, targetTier);
      await commandDispatcher.execute(command);
      
      // Refresh the read side projection view after write operation completes
      await fetchUsers();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to execute command on write side.');
    }
  };

  return (
    <div className="admin-dashboard" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Admin User Dashboard (CQRS Architecture)</h2>

      {/* Filter Dropdown (Drives Read Queries) */}
      <div style={{ marginBottom: '15px' }}>
        <label htmlFor="tier-filter">Filter by Tier: </label>
        <select
          id="tier-filter"
          value={selectedTier}
          onChange={(e) => setSelectedTier(e.target.value as any)}
        >
          <option value="free">Free</option>
          <option value="pro">Pro</option>
          <option value="enterprise">Enterprise</option>
        </select>
      </div>

      {/* Error Notification Banner */}
      {errorMessage && (
        <div style={{ background: '#ffe6e6', color: '#c00', padding: '10px', marginBottom: '15px', borderRadius: '4px' }}>
          <strong>Error: </strong> {errorMessage}
        </div>
      )}

      {/* Loading & Data Table */}
      {loading ? (
        <p>Loading user projections...</p>
      ) : (
        <table border={1} cellPadding={8} style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>User ID</th>
              <th>Email</th>
              <th>Tier</th>
              <th>Joined At</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ textAlign: 'center' }}>No users found in this tier.</td>
              </tr>
            ) : (
              users.map((user) => (
                <tr key={user.userId}>
                  <td>{user.userId}</td>
                  <td>{user.email}</td>
                  <td>{user.tier}</td>
                  <td>{new Date(user.joinedAt).toLocaleDateString()}</td>
                  <td>
                    {user.tier !== 'enterprise' && (
                      <button
                        onClick={() => handleUpgradeTier(user.userId, user.tier === 'free' ? 'pro' : 'enterprise')}
                      >
                        Upgrade Tier
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};
