/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export interface IQuery<TResult> {
  // Marker or metadata if needed
}

export interface IQueryHandler<TQuery extends IQuery<TResult>, TResult> {
  handle(query: TQuery): Promise<TResult>;
}

export interface UserSummaryDto {
  userId: string;
  email: string;
  tier: string;
  joinedAt: Date;
}

export interface PaginatedUserResponse {
  data: UserSummaryDto[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
}

export class GetUsersByTierQuery implements IQuery<PaginatedUserResponse> {
  constructor(
    public readonly tier: 'free' | 'pro' | 'enterprise',
    public readonly page: number = 1,
    public readonly pageSize: number = 10
  ) {}
}

export class QueryDispatcher {
  private handlers = new Map<string, IQueryHandler<any, any>>();

  public register<TQuery extends IQuery<TResult>, TResult>(
    queryName: string,
    handler: IQueryHandler<TQuery, TResult>
  ): void {
    // TODO: Register handler
  }

  public async dispatch<TResult>(query: IQuery<TResult>): Promise<TResult> {
    // TODO: Resolve handler based on query constructor name or identifier and execute
    throw new Error('Not implemented');
  }
}
