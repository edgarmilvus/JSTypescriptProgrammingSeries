/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Tenant Subscription Management - Write Model & Command Handler Example
 * Language: TypeScript (ESM)
 */

// ==========================================
// 1. DOMAIN EVENTS
// ==========================================

/**
 * Base contract for all domain events emitted by the write model.
 */
export interface DomainEvent {
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly eventType: string;
  readonly aggregateId: string;
}

/**
 * Event emitted when a tenant successfully upgrades their subscription tier.
 */
export class TenantSubscriptionUpgradedEvent implements DomainEvent {
  readonly eventId: string;
  readonly occurredAt: Date;
  readonly eventType = 'TenantSubscriptionUpgraded';

  constructor(
    public readonly aggregateId: string,
    public readonly previousTier: string,
    public readonly newTier: string,
    public readonly upgradedByUserId: string
  ) {
    this.eventId = crypto.randomUUID();
    this.occurredAt = new Date();
  }
}

// ==========================================
// 2. COMMANDS & COMMAND OBJECTS
// ==========================================

/**
 * Marker interface for all write-side commands.
 */
export interface Command {}

/**
 * Command payload to request a subscription upgrade for a SaaS tenant.
 */
export class UpgradeSubscriptionCommand implements Command {
  constructor(
    public readonly tenantId: string,
    public readonly targetTier: 'PRO' | 'ENTERPRISE',
    public readonly requestedByUserId: string
  ) {}
}

// ==========================================
// 3. DOMAIN AGGREGATE (STATE & INVARIANTS)
// ==========================================

/**
 * Allowed subscription tiers with an ordering hierarchy for business rule validation.
 */
type SubscriptionTier = 'FREE' | 'PRO' | 'ENTERPRISE';

const TIER_HIERARCHY: Record<SubscriptionTier, number> = {
  FREE: 1,
  PRO: 2,
  ENTERPRISE: 3,
};

/**
 * The Tenant Aggregate Root.
 * Encapsulates both state and behavior, ensuring business rules cannot be bypassed.
 */
export class TenantAggregate {
  private _id: string;
  private _tier: SubscriptionTier;
  private _isActive: boolean;
  private _uncommittedEvents: DomainEvent[] = [];

  constructor(id: string, initialTier: SubscriptionTier, isActive: boolean) {
    this._id = id;
    this._tier = initialTier;
    this._isActive = isActive;
  }

  // --- Getters for reading internal state safely ---
  public get id(): string { return this._id; }
  public get tier(): SubscriptionTier { return this._tier; }
  public get isActive(): boolean { return this._isActive; }

  /**
   * Pulls and clears uncommitted events (used by the repository layer before dispatching to event bus).
   */
  public pullDomainEvents(): DomainEvent[] {
    const events = [...this._uncommittedEvents];
    this._uncommittedEvents = [];
    return events;
  }

  /**
   * Business Logic Method: Handles the state transition for upgrading a subscription.
   * Enforces invariants: Tenant must be active, and target tier must be higher than current tier.
   */
  public upgradeSubscription(targetTier: 'PRO' | 'ENTERPRISE', userId: string): void {
    // Invariant 1: Inactive tenants cannot modify subscriptions
    if (!this._isActive) {
      throw new Error(`Cannot modify subscription for inactive tenant [TenantId: ${this._id}]`);
    }

    // Invariant 2: Cannot "upgrade" to the same or lower tier
    const currentWeight = TIER_HIERARCHY[this._tier];
    const targetWeight = TIER_HIERARCHY[targetTier];

    if (targetWeight <= currentWeight) {
      throw new Error(
        `Invalid subscription transition. Current tier (${this._tier}) is equal to or higher than target tier (${targetTier}).`
      );
    }

    // Capture previous state for event logging
    const previousTier = this._tier;

    // Execute state transition
    this._tier = targetTier;

    // Record the domain event representing the successful mutation
    const upgradeEvent = new TenantSubscriptionUpgradedEvent(
      this._id,
      previousTier,
      targetTier,
      userId
    );

    this._uncommittedEvents.push(upgradeEvent);
  }
}

// ==========================================
// 4. REPOSITORY INTERFACE (PERSISTENCE BOUNDARY)
// ==========================================

/**
 * Repository interface representing the data access boundary for the write model.
 */
export interface ITenantRepository {
  findById(tenantId: string): Promise<TenantAggregate | null>;
  save(aggregate: TenantAggregate): Promise<void>;
}

/**
 * In-memory stub implementation of ITenantRepository for demonstration purposes.
 */
export class InMemoryTenantRepository implements ITenantRepository {
  private store: Map<string, TenantAggregate> = new Map();

  constructor() {
    // Seed an initial active tenant on the FREE tier
    const sampleTenant = new TenantAggregate('tenant-uuid-999', 'FREE', true);
    this.store.set(sampleTenant.id, sampleTenant);
  }

  public async findById(tenantId: string): Promise<TenantAggregate | null> {
    return this.store.get(tenantId) || null;
  }

  public async save(aggregate: TenantAggregate): Promise<void> {
    this.store.set(aggregate.id, aggregate);
    // In a real-world Event Store or database, uncommitted events would be 
    // published to an outbox table or message broker here.
  }
}

// ==========================================
// 5. COMMAND HANDLER (ORCHESTRATION LAYER)
// ==========================================

/**
 * Command Handler responsible for orchestrating the lifecycle of the UpgradeSubscriptionCommand.
 * It loads the aggregate, invokes the domain behavior, and persists the resulting state.
 */
export class UpgradeSubscriptionCommandHandler {
  constructor(private readonly tenantRepository: ITenantRepository) {}

  /**
   * Executes the command workflow.
   * @param command The incoming UpgradeSubscriptionCommand payload.
   */
  public async handle(command: UpgradeSubscriptionCommand): Promise<void> {
    // 1. Fetch the aggregate root from the repository
    const tenant = await this.tenantRepository.findById(command.tenantId);

    if (!tenant) {
      throw new Error(`Tenant not found for ID: ${command.tenantId}`);
    }

    // 2. Invoke domain logic / state transition method on the aggregate
    // All business validation occurs inside this method call.
    tenant.upgradeSubscription(command.targetTier, command.requestedByUserId);

    // 3. Extract generated domain events for downstream messaging/reactivity
    const domainEvents = tenant.pullDomainEvents();

    // 4. Persist the updated aggregate state to the underlying store
    await this.tenantRepository.save(tenant);

    // 5. Dispatch domain events (Simulated integration outbox dispatch)
    this.dispatchEventsToBroker(domainEvents);
  }

  private dispatchEventsToBroker(events: DomainEvent[]): void {
    for (const event of events) {
      console.log(`[EventBus] Publishing Domain Event -> Type: ${event.eventType}, AggregateId: ${event.aggregateId}`, JSON.stringify(event));
    }
  }
}

// ==========================================
// 6. EXECUTION SIMULATION (CLIENT ENTRYPOINT)
// ==========================================

async function runSaaSApplicationSimulation() {
  console.log('--- Initializing Write Model Simulation ---');

  // Instantiate infrastructure dependencies
  const tenantRepo = new InMemoryTenantRepository();
  const upgradeHandler = new UpgradeSubscriptionCommandHandler(tenantRepo);

  // Construct a valid command
  const command = new UpgradeSubscriptionCommand(
    'tenant-uuid-999',
    'PRO',
    'user-admin-123'
  );

  console.log(`\n[Client] Sending command to upgrade tenant ${command.tenantId} to ${command.targetTier}...`);

  try {
    // Execute command via handler
    await upgradeHandler.handle(command);
    console.log('[Client] Command executed successfully.');
  } catch (error: any) {
    console.error('[Client Error]:', error.message);
  }

  // Attempt an invalid command (downgrading back to FREE)
  console.log('\n[Client] Sending invalid command to downgrade tenant back to FREE...');
  const invalidCommand = new UpgradeSubscriptionCommand(
    'tenant-uuid-999',
    'FREE',
    'user-admin-123'
  );

  try {
    await upgradeHandler.handle(invalidCommand);
  } catch (error: any) {
    console.error('[Client Error Caught Successfully]:', error.message);
  }
}

// Run the simulation
runSaaSApplicationSimulation();
