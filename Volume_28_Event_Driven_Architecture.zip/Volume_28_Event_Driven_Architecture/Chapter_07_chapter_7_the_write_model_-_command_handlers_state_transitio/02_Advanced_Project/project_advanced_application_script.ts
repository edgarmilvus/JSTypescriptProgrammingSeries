/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * ============================================================================
 * DOMAIN PRIMITIVES & BASE CLASSES
 * ============================================================================
 */

/**
 * Base interface for all domain events emitted by aggregates.
 */
export interface IDomainEvent {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly eventType: string;
  readonly version: number;
  readonly occurredOn: Date;
}

/**
 * Base abstract class for Domain Aggregates, managing event sourcing and state.
 */
export abstract class AggregateRoot {
  private _id: string;
  private _version: number = 0;
  private _uncommittedEvents: IDomainEvent[] = [];

  constructor(id: string) {
    this._id = id;
  }

  public get id(): string {
    return this._id;
  }

  public get version(): number {
    return this._version;
  }

  public getUncommittedEvents(): IDomainEvent[] {
    return [...this._uncommittedEvents];
  }

  public clearUncommittedEvents(): void {
    this._uncommittedEvents = [];
  }

  protected applyEvent(event: IDomainEvent): void {
    this.mutate(event);
    this._version++;
    this._uncommittedEvents.push(event);
  }

  public loadFromHistory(history: IDomainEvent[]): void {
    for (const event of history) {
      this.mutate(event);
      this._version = event.version;
    }
  }

  protected abstract mutate(event: IDomainEvent): void;
}

/**
 * Base interface for Commands.
 */
export interface ICommand {
  readonly aggregateId: string;
}

/**
 * Command Handler contract.
 */
export interface ICommandHandler<TCommand extends ICommand> {
  handle(command: TCommand): Promise<void>;
}

/**
 * Event Store Port for persisting and fetching domain events.
 */
export interface IEventStore {
  saveEvents(aggregateId: string, events: IDomainEvent[], expectedVersion: number): Promise<void>;
  getEvents(aggregateId: string): Promise<IDomainEvent[]>;
}

/**
 * ============================================================================
 * CONTEXT: PROJECT DOMAIN AGGREGATE & EVENTS
 * ============================================================================
 */

export class ProjectInitializedEvent implements IDomainEvent {
  readonly eventId = randomUUID();
  readonly eventType = 'ProjectInitialized';
  readonly occurredOn = new Date();
  constructor(
    public readonly aggregateId: string,
    public readonly version: number,
    public readonly projectName: string,
    public readonly ownerId: string
  ) {}
}

export class TaskAddedEvent implements IDomainEvent {
  readonly eventId = randomUUID();
  readonly eventType = 'TaskAdded';
  readonly occurredOn = new Date();
  constructor(
    public readonly aggregateId: string,
    public readonly version: number,
    public readonly taskId: string,
    public readonly title: string
  ) {}
}

/**
 * The Project Aggregate enforces business invariants regarding project setup and task delegation.
 */
export class ProjectAggregate extends AggregateRoot {
  private name!: string;
  private ownerId!: string;
  private tasks: Map<string, { title: string; completed: boolean }> = new Map();
  private isArchived: boolean = false;

  constructor(id: string) {
    super(id);
  }

  public static initialize(id: string, projectName: string, ownerId: string): ProjectAggregate {
    const project = new ProjectAggregate(id);
    project.applyEvent(new ProjectInitializedEvent(id, project.version + 1, projectName, ownerId));
    return project;
  }

  public addTask(taskId: string, title: string): void {
    if (this.isArchived) {
      throw new Error('Cannot add tasks to an archived project.');
    }
    if (this.tasks.has(taskId)) {
      throw new Error(`Task with ID ${taskId} already exists in this project.`);
    }
    this.applyEvent(new TaskAddedEvent(this.id, this.version + 1, taskId, title));
  }

  protected mutate(event: IDomainEvent): void {
    switch (event.eventType) {
      case 'ProjectInitialized': {
        const e = event as ProjectInitializedEvent;
        this.name = e.projectName;
        this.ownerId = e.ownerId;
        break;
      }
      case 'TaskAdded': {
        const e = event as TaskAddedEvent;
        this.tasks.set(e.taskId, { title: e.title, completed: false });
        break;
      }
      default:
        throw new Error(`Unhandled event type: ${event.eventType}`);
    }
  }
}

/**
 * ============================================================================
 * COMMANDS & COMMAND HANDLER IMPLEMENTATION
 * ============================================================================
 */

export interface IInitializeProjectCommand extends ICommand {
  projectName: string;
  ownerId: string;
}

export interface IAddTaskCommand extends ICommand {
  taskId: string;
  title: string;
}

/**
 * InMemory Event Store Stub for execution illustration.
 */
export class InMemoryEventStore implements IEventStore {
  private store: Map<string, IDomainEvent[]> = new Map();

  async saveEvents(aggregateId: string, events: IDomainEvent[], expectedVersion: number): Promise<void> {
    const existing = this.store.get(aggregateId) || [];
    if (existing.length !== expectedVersion) {
      throwConcurrencyException(aggregateId, expectedVersion, existing.length);
    }
    this.store.set(aggregateId, [...existing, ...events]);
  }

  async getEvents(aggregateId: string): Promise<IDomainEvent[]> {
    const events = this.store.get(aggregateId);
    if (!events) {
      throw new Error(`Aggregate with ID ${aggregateId} not found.`);
    }
    return events;
  }
}

function throwConcurrencyException(id: string, expected: number, actual: number): never {
  throw new Error(`Concurrency Conflict on Aggregate ${id}: Expected version ${expected}, but found ${actual}.`);
}

/**
 * Command Handler orchestrating loading, mutating, and persisting aggregates.
 */
export class ProjectCommandHandlers {
  constructor(private eventStore: IEventStore) {}

  async handleInitializeProject(command: IInitializeProjectCommand): Promise<void> {
    // 1. Instantiate Aggregate via factory method
    const project = ProjectAggregate.initialize(command.aggregateId, command.projectName, command.ownerId);

    // 2. Persist uncommitted events to the event store
    const uncommitted = project.getUncommittedEvents();
    await this.eventStore.saveEvents(project.id, uncommitted, project.version - uncommitted.length);
    project.clearUncommittedEvents();
  }

  async handleAddTask(command: IAddTaskCommand): Promise<void> {
    // 1. Rehydrate aggregate state from the event store history
    const history = await this.eventStore.getEvents(command.aggregateId);
    const project = new ProjectAggregate(command.aggregateId);
    project.loadFromHistory(history);

    // 2. Execute business logic method (enforces invariants)
    project.addTask(command.taskId, command.title);

    // 3. Persist new events with optimistic concurrency locking check
    const uncommitted = project.getUncommittedEvents();
    const previousVersion = project.version - uncommitted.length;
    await this.eventStore.saveEvents(project.id, uncommitted, previousVersion);
    project.clearUncommittedEvents();
  }
}
