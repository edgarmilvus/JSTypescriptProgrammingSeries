/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { randomUUID } from 'crypto';

export type Currency = 'USD' | 'EUR' | 'GBP';

export class Money {
  constructor(public readonly amount: number, public readonly currency: Currency) {
    if (amount < 0) throw new Error("Money amount cannot be negative.");
  }

  public add(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error(`Currency mismatch: Cannot add ${other.currency} to ${this.currency}`);
    }
    return new Money(this.amount + other.amount, this.currency);
  }

  public subtract(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error(`Currency mismatch: Cannot subtract ${other.currency} from ${this.currency}`);
    }
    return new Money(this.amount - other.amount, this.currency);
  }

  public isLessThan(other: Money): boolean {
    if (this.currency !== other.currency) {
      throw new Error("Cannot compare currencies directly.");
    }
    return this.amount < other.amount;
  }
}

export class AccountId {
  private constructor(public readonly value: string) {}
  public static create(value: string = randomUUID()): AccountId {
    return new AccountId(value);
  }
}

export interface DomainEvent {
  readonly eventId: string;
  readonly occurredOn: Date;
  readonly aggregateId: string;
}

export class AccountOpenedEvent implements DomainEvent {
  readonly eventId = randomUUID();
  readonly occurredOn = new Date();
  constructor(public readonly aggregateId: string, public readonly initialDeposit: Money, public readonly overdraftLimit: Money) {}
}

export class FundsDepositedEvent implements DomainEvent {
  readonly eventId = randomUUID();
  readonly occurredOn = new Date();
  constructor(public readonly aggregateId: string, public readonly amount: Money) {}
}

export class FundsWithdrawnEvent implements DomainEvent {
  readonly eventId = randomUUID();
  readonly occurredOn = new Date();
  constructor(public readonly aggregateId: string, public readonly amount: Money) {}
}

export abstract class AggregateRoot<TState> {
  private _domainEvents: DomainEvent[] = [];
  protected state!: TState;

  public getUncommittedEvents(): DomainEvent[] {
    return [...this._domainEvents];
  }

  public clearEvents(): void {
    this._domainEvents = [];
  }

  protected addEvent(event: DomainEvent): void {
    this._domainEvents.push(event);
  }
}

export interface BankAccountState {
  id: AccountId;
  balance: Money;
  overdraftLimit: Money;
  isClosed: boolean;
}

export class BankAccount extends AggregateRoot<BankAccountState> {
  private constructor(state: BankAccountState) {
    super();
    this.state = state;
  }

  public static create(id: AccountId, initialDeposit: Money, overdraftLimit: Money): BankAccount {
    if (initialDeposit.currency !== overdraftLimit.currency) {
      throw new Error("Currency mismatch between initial deposit and overdraft limit.");
    }
    const account = new BankAccount({
      id,
      balance: initialDeposit,
      overdraftLimit,
      isClosed: false
    });
    account.addEvent(new AccountOpenedEvent(id.value, initialDeposit, overdraftLimit));
    return account;
  }

  public deposit(amount: Money): void {
    if (this.state.isClosed) {
      throw new Error("Cannot deposit into a closed account.");
    }
    if (amount.currency !== this.state.balance.currency) {
      throw new Error(`Currency mismatch: Cannot deposit ${amount.currency} into ${this.state.balance.currency} account.`);
    }
    this.state = {
      ...this.state,
      balance: this.state.balance.add(amount)
    };
    this.addEvent(new FundsDepositedEvent(this.state.id.value, amount));
  }

  public withdraw(amount: Money): void {
    if (this.state.isClosed) {
      throw new Error("Cannot withdraw from a closed account.");
    }
    if (amount.currency !== this.state.balance.currency) {
      throw new Error(`Currency mismatch: Cannot withdraw ${amount.currency} from ${this.state.balance.currency} account.`);
    }
    
    // Check invariant: balance - amount >= -overdraftLimit
    const newBalanceAmount = this.state.balance.amount - amount.amount;
    if (newBalanceAmount < -this.state.overdraftLimit.amount) {
      throw new Error("Insufficient funds exceeding overdraft limit.");
    }

    this.state = {
      ...this.state,
      balance: this.state.balance.subtract(amount)
    };
    this.addEvent(new FundsWithdrawnEvent(this.state.id.value, amount));
  }
}
