/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export class ConcurrencyException extends Error {
  constructor(aggregateId: string, expectedVersion: number, actualVersion: number) {
    super(`Concurrency conflict for aggregate ${aggregateId}: Expected version ${expectedVersion}, but found ${actualVersion}.`);
    this.name = 'ConcurrencyException';
  }
}

export interface VersionedEntity {
  id: string;
  version: number;
}

export interface StoredAggregateRecord {
  id: string;
  version: number;
  payload: any;
}

export class InMemoryEventStore {
  private store = new Map<string, StoredAggregateRecord>();

  public async load(id: string): Promise<StoredAggregateRecord | null> {
    const record = this.store.get(id);
    return record ? JSON.parse(JSON.stringify(record)) : null;
  }

  public async save(id: string, newVersion: number, expectedVersion: number, payload: any): Promise<void> {
    const existing = this.store.get(id);
    
    if (existing && existing.version !== expectedVersion) {
      throw new ConcurrencyException(id, expectedVersion, existing.version);
    }

    this.store.set(id, {
      id,
      version: newVersion,
      payload
    });
  }
}

export class EventSourcedRepository<T> {
  constructor(private eventStore: InMemoryEventStore) {}

  public async getById(id: string): Promise<{ aggregate: T; version: number }> {
    const record = await this.eventStore.load(id);
    if (!record) {
      throw new Error(`Aggregate with ID ${id} not found.`);
    }
    return {
      aggregate: record.payload as T,
      version: record.version
    };
  }

  public async save(id: string, aggregate: T, currentVersion: number): Promise<void> {
    const newVersion = currentVersion + 1;
    await this.eventStore.save(id, newVersion, currentVersion, aggregate);
  }
}
