/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface DomainEvent {
  readonly eventId: string;
  readonly occurredOn: Date;
  readonly aggregateId: string;
}

export class FundsDepositedEvent implements DomainEvent {
  constructor(
    public readonly eventId: string,
    public readonly aggregateId: string,
    public readonly amount: number,
    public readonly currency: string,
    public readonly occurredOn: Date = new Date()
  ) {}
}

export interface IntegrationMessage {
  readonly messageId: string;
  readonly specVersion: string;
  readonly type: string;
  readonly source: string;
  readonly time: string;
  readonly data: Record<string, any>;
}

export interface OutboxRecord {
  id: string;
  aggregateId: string;
  eventType: string;
  payload: string; 
  status: 'PENDING' | 'PUBLISHED';
  createdAt: Date;
}

export class DomainToIntegrationMapper {
  public static map(domainEvent: DomainEvent): IntegrationMessage {
    if (domainEvent instanceof FundsDepositedEvent) {
      return {
        messageId: domainEvent.eventId,
        specVersion: '1.0',
        type: 'CustomerAccountCreditedV1',
        source: `/fintech/accounts/${domainEvent.aggregateId}`,
        time: domainEvent.occurredOn.toISOString(),
        data: {
          accountId: domainEvent.aggregateId,
          amount: domainEvent.amount,
          currency: domainEvent.currency
        }
      };
    }
    throw new Error(`Mapping not implemented for event type: ${domainEvent.constructor.name}`);
  }
}

export class OutboxDispatcher {
  constructor(
    private outboxTable: OutboxRecord[],
    private messageBroker: { publish: (msg: IntegrationMessage) => Promise<void> }
  ) {}

  public async dispatchPendingMessages(): Promise<void> {
    const pendingRecords = this.outboxTable.filter(record => record.status === 'PENDING');

    for (const record of pendingRecords) {
      try {
        const integrationMessage: IntegrationMessage = JSON.parse(record.payload);
        await this.messageBroker.publish(integrationMessage);
        record.status = 'PUBLISHED';
      } catch (error) {
        console.error(`Failed to publish outbox record ${record.id}:`, error);
      }
    }
  }
}
