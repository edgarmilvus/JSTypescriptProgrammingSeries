/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Exercise 1: Financial Ledger Aggregate
import { randomUUID } from 'crypto';

export type Currency = 'USD' | 'EUR' | 'GBP';

export class Money {
  constructor(public readonly amount: number, public readonly currency: Currency) {
    if (amount < 0) throw new Error("Money amount cannot be negative.");
  }

  public add(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error(`Currency mismatch: Cannot add ${other.currency} to ${this.currency}`);
    }
    return new Money(this.amount + other.amount, this.currency);
  }

  public subtract(other: Money): Money {
    if (this.currency !== other.currency) {
      throw new Error(`Currency mismatch: Cannot subtract ${other.currency} from ${this.currency}`);
    }
    return new Money(this.amount - other.amount, this.currency);
  }

  public isLessThan(other: Money): boolean {
    if (this.currency !== other.currency) {
      throw new Error("Cannot compare currencies directly.");
    }
    return this.amount < other.amount;
  }
}

export class AccountId {
  private constructor(public readonly value: string) {}
  public static create(value: string = randomUUID()): AccountId {
    return new AccountId(value);
  }
}

export interface DomainEvent {
  readonly eventId: string;
  readonly occurredOn: Date;
  readonly aggregateId: string;
}

export abstract class AggregateRoot<TState> {
  private _domainEvents: DomainEvent[] = [];
  protected state!: TState;

  public getUncommittedEvents(): DomainEvent[] {
    return [...this._domainEvents];
  }

  public clearEvents(): void {
    this._domainEvents = [];
  }

  protected addEvent(event: DomainEvent): void {
    this._domainEvents.push(event);
  }
}

export interface BankAccountState {
  id: AccountId;
  balance: Money;
  overdraftLimit: Money;
  isClosed: boolean;
}

export class BankAccount extends AggregateRoot<BankAccountState> {
  // TODO: Implement private constructor and static factory method 'create'

  public deposit(amount: Money): void {
    // TODO: Implement invariant checking, state mutation, and event recording
  }

  public withdraw(amount: Money): void {
    // TODO: Implement overdraft checking, balance updates, and event recording
  }
}
