/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Exercise 2: CQRS Command Dispatcher & Middleware
export interface ICommand {
  readonly __commandBrand?: any;
}

export interface ICommandHandler<TCommand extends ICommand, TResult = void> {
  handle(command: TCommand): Promise<TResult>;
}

export type CommandHandlerConstructor<TCommand extends ICommand, TResult = void> = 
  new (...args: any[]) => ICommandHandler<TCommand, TResult>;

export interface CommandContext {
  commandName: string;
  timestamp: Date;
  correlationId: string;
}

export interface CommandMiddleware {
  execute<TCommand extends ICommand, TResult>(
    command: TCommand,
    context: CommandContext,
    next: () => Promise<TResult>
  ): Promise<TResult>;
}

export class CommandDispatcher {
  private handlers = new Map<string, ICommandHandler<any, any>>();
  private middleware: CommandMiddleware[] = [];

  public register<TCommand extends ICommand, TResult>(
    commandName: string,
    handler: ICommandHandler<TCommand, TResult>
  ): void {
    this.handlers.set(commandName, handler);
  }

  public use(middleware: CommandMiddleware): void {
    this.middleware.push(middleware);
  }

  public async dispatch<TCommand extends ICommand, TResult>(
    command: TCommand
  ): Promise<TResult> {
    // TODO: Implement the onion-style middleware execution pipeline
    // wrapping the final handler invocation.
    throw new Error("Not implemented");
  }
}
