/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// Exercise 4: Event Mapper & Transactional Outbox
export interface DomainEvent {
  readonly eventId: string;
  readonly occurredOn: Date;
  readonly aggregateId: string;
}

export class FundsDepositedEvent implements DomainEvent {
  constructor(
    public readonly eventId: string,
    public readonly aggregateId: string,
    public readonly amount: number,
    public readonly currency: string,
    public readonly occurredOn: Date = new Date()
  ) {}
}

// External Integration Event Schema for Downstream Consumers
export interface IntegrationMessage {
  readonly messageId: string;
  readonly specVersion: string;
  readonly type: string;
  readonly source: string;
  readonly time: string;
  readonly data: Record<string, any>;
}

export interface OutboxRecord {
  id: string;
  aggregateId: string;
  eventType: string;
  payload: string; // JSON stringified IntegrationMessage
  status: 'PENDING' | 'PUBLISHED';
  createdAt: Date;
}

export class DomainToIntegrationMapper {
  public static map(domainEvent: DomainEvent): IntegrationMessage {
    // TODO: Switch on event type and map to corresponding IntegrationMessage schema
    throw new Error("Mapping not implemented for event type");
  }
}

export class OutboxDispatcher {
  constructor(
    private outboxTable: OutboxRecord[],
    private messageBroker: { publish: (msg: IntegrationMessage) => Promise<void> }
  ) {}

  public async dispatchPendingMessages(): Promise<void> {
    // TODO: Query PENDING records, map/parse, publish via broker, and update status to PUBLISHED
    throw new Error("Not implemented");
  }
}
