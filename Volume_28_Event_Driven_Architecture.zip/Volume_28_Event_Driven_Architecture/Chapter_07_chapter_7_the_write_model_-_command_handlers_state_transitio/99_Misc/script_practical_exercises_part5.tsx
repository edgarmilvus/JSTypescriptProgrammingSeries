/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// Exercise 5: React Component - Command & Outbox Dashboard (TSX)
import React, { useState, useEffect } from 'react';

export interface OutboxItemView {
  id: string;
  aggregateId: string;
  eventType: string;
  status: 'PENDING' | 'PUBLISHED' | 'FAILED';
  createdAt: string;
}

export interface CommandLogEntry {
  id: string;
  commandName: string;
  timestamp: string;
  status: 'SUCCESS' | 'ERROR';
  message: string;
}

export interface DashboardProps {
  onDispatchCommand: (commandName: string, payload: any) => Promise<void>;
  fetchOutboxQueue: () => Promise<OutboxItemView[]>;
}

export const CommandAndOutboxDashboard: React.FC<DashboardProps> = ({
  onDispatchCommand,
  fetchOutboxQueue
}) => {
  const [accountId, setAccountId] = useState<string>('');
  const [commandType, setCommandType] = useState<string>('ADJUST_OVERDRAFT');
  const [parameterValue, setParameterValue] = useState<number>(0);
  
  const [outboxItems, setOutboxItems] = useState<OutboxItemView[]>([]);
  const [logs, setLogs] = useState<CommandLogEntry[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // TODO: Implement useEffect to poll fetchOutboxQueue periodically

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Validate inputs, invoke onDispatchCommand, update logs, and catch errors
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h2>Write-Model Command & Outbox Dashboard</h2>
      
      {errorMessage && (
        <div style={{ background: '#ffe6e6', color: '#cc0000', padding: '1rem', marginBottom: '1rem', borderRadius: '4px' }}>
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '1rem', maxWidth: '500px', marginBottom: '2rem' }}>
        <div>
          <label style={{ display: 'block', fontWeight: 'bold' }}>Account ID:</label>
          <input 
            type="text" 
            value={accountId} 
            onChange={(e) => setAccountId(e.target.value)} 
            placeholder="Enter Account UUID..."
            style={{ width: '100%', padding: '0.5rem' }}
            required
          />
        </div>

        <div>
          <label style={{ display: 'block', fontWeight: 'bold' }}>Command Type:</label>
          <select 
            value={commandType} 
            onChange={(e) => setCommandType(e.target.value)}
            style={{ width: '100%', padding: '0.5rem' }}
          >
            <option value="ADJUST_OVERDRAFT">Adjust Overdraft Limit</option>
            <option value="FORCE_AUDIT">Force Account Audit</option>
            <option value="FREEZE_ACCOUNT">Freeze Account</option>
          </select>
        </div>

        <div>
          <label style={{ display: 'block', fontWeight: 'bold' }}>Parameter Value:</label>
          <input 
            type="number" 
            value={parameterValue} 
            onChange={(e) => setParameterValue(Number(e.target.value))} 
            style={{ width: '100%', padding: '0.5rem' }}
          />
        </div>

        <button 
          type="submit" 
          disabled={isSubmitting}
          style={{ padding: '0.75rem', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          {isSubmitting ? 'Dispatching Command...' : 'Dispatch Command'}
        </button>
      </form>

      <h3>Transactional Outbox Queue</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '2rem' }}>
        <thead>
          <tr style={{ background: '#f8f9fa', textAlign: 'left' }}>
            <th style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>ID</th>
            <th style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>Aggregate ID</th>
            <th style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>Event Type</th>
            <th style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>Status</th>
            <th style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>Created At</th>
          </tr>
        </thead>
        <tbody>
          {outboxItems.map((item) => (
            <tr key={item.id}>
              <td style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>{item.id}</td>
              <td style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>{item.aggregateId}</td>
              <td style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>{item.eventType}</td>
              <td style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>
                <span style={{ 
                  padding: '0.25rem 0.5rem', 
                  borderRadius: '4px', 
                  color: 'white',
                  backgroundColor: item.status === 'PUBLISHED' ? '#28a745' : item.status === 'PENDING' ? '#ffc107' : '#dc3545' 
                }}>
                  {item.status}
                </span>
              </td>
              <td style={{ padding: '0.5rem', border: '1px solid #dee2e6' }}>{item.createdAt}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Command Execution Logs</h3>
      <div style={{ background: '#212529', color: '#f8f9fa', padding: '1rem', borderRadius: '4px', maxHeight: '200px', overflowY: 'auto', fontFamily: 'monospace' }}>
        {logs.length === 0 ? (
          <div>No command logs recorded yet.</div>
        ) : (
          logs.map((log) => (
            <div key={log.id} style={{ marginBottom: '0.5rem' }}>
              [{log.timestamp}] <span style={{ color: log.status === 'SUCCESS' ? '#28a745' : '#dc3545' }}>{log.status}</span>: {log.commandName} - {log.message}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
