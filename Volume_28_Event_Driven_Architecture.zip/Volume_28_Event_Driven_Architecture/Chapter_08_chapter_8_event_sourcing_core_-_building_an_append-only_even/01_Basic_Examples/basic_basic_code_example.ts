/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Represents the fundamental structure of any domain event in the SaaS platform.
 * Every state change is captured as a historical fact with metadata.
 */
interface DomainEvent {
  readonly aggregateId: string;
  readonly eventType: string;
  readonly version: number;
  readonly payload: Record<string, unknown>;
  readonly timestamp: Date;
}

/**
 * Defines the contract for an Event Store, ensuring that streams can be 
 * appended to with concurrency checks and loaded for state reconstruction.
 */
interface IEventStore {
  append(aggregateId: string, expectedVersion: number, events: Omit<DomainEvent, 'version' | 'timestamp'>[]): Promise<void>;
  getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]>;
}

/**
 * Custom error thrown when a concurrent write collision occurs.
 * Prevents race conditions by rejecting out-of-order event appends.
 */
class ConcurrencyException extends Error {
  constructor(aggregateId: string, expected: number, actual: number) {
    super(`Concurrency conflict on aggregate '${aggregateId}'. Expected version ${expected}, but actual version is ${actual}.`);
    this.name = 'ConcurrencyException';
  }
}

/**
 * An in-memory implementation of an Append-Only Event Store for a SaaS tenant system.
 */
class InMemoryEventStore implements IEventStore {
  // Storage mapping aggregate IDs to their chronological arrays of events
  private readonly store: Map<string, DomainEvent[]> = new Map();

  /**
   * Appends new events to an aggregate stream with Optimistic Concurrency Control (OCC).
   */
  public async append(
    aggregateId: string, 
    expectedVersion: number, 
    newEvents: Omit<DomainEvent, 'version' | 'timestamp'>[]
  ): Promise<void> {
    // Retrieve existing events for this aggregate, or initialize an empty array if none exist
    const existingEvents = this.store.get(aggregateId) || [];
    
    // Determine the current version of the aggregate based on the last recorded event's version, or 0 if empty
    const currentVersion = existingEvents.length > 0 
      ? existingEvents[existingEvents.length - 1].version 
      : 0;

    // Validate optimistic concurrency control
    if (currentVersion !== expectedVersion) {
      throw new ConcurrencyException(aggregateId, expectedVersion, currentVersion);
    }

    // Map the incoming raw event definitions into fully-formed immutable DomainEvents
    let runningVersion = currentVersion;
    const timestamp = new Date();

    const eventsToAppend: DomainEvent[] = newEvents.map((rawEvent) => {
      runningVersion++;
      return {
        ...rawEvent,
        version: runningVersion,
        timestamp,
      };
    });

    // Commit the events to the store immutably by concatenating them with existing history
    this.store.set(aggregateId, [...existingEvents, ...eventsToAppend]);
  }

  /**
   * Replays the complete historical event stream for a specific aggregate.
   */
  public async getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]> {
    const events = this.store.get(aggregateId);
    if (!events) {
      return [];
    }
    // Return a shallow copy to prevent external mutation of the internal event stream
    return [...events];
  }
}

// ==========================================
// Execution Example (SaaS Tenant Context)
// ==========================================
async function runDemo() {
  const eventStore = new InMemoryEventStore();
  const tenantAggregateId = 'tenant_xyz_9988';

  console.log('--- Step 1: Initializing Subscription ---');
  // At version 0 (brand new aggregate), we append the creation event
  await eventStore.append(tenantAggregateId, 0, [
    {
      aggregateId: tenantAggregateId,
      eventType: 'SubscriptionCreated',
      payload: { plan: 'Enterprise', seatCount: 25 },
    },
  ]);

  let history = await eventStore.getEventsForAggregate(tenantAggregateId);
  console.log(`Loaded ${history.length} events. Current Version: ${history[history.length - 1].version}`);

  console.log('\n--- Step 2: Upgrading Subscription Plan ---');
  // Current version is now 1. We expect version 1 to perform an upgrade.
  await eventStore.append(tenantAggregateId, 1, [
    {
      aggregateId: tenantAggregateId,
      eventType: 'PlanUpgraded',
      payload: { newPlan: 'Global-Enterprise', seatCount: 50 },
    },
  ]);

  history = await eventStore.getEventsForAggregate(tenantAggregateId);
  console.log(`Loaded ${history.length} events. Current Version: ${history[history.length - 1].version}`);

  console.log('\n--- Step 3: Demonstrating Concurrency Conflict ---');
  try {
    // Simulating a race condition: Two admin requests read version 2, 
    // but the first one already incremented it to 2. The second request passes stale expectedVersion: 2.
    // Wait, let's look at the math: current version after Step 2 is 2.
    // If an agent tries to write with expectedVersion: 1 (stale state), it will fail.
    await eventStore.append(tenantAggregateId, 1, [
      {
        aggregateId: tenantAggregateId,
        eventType: 'PaymentMethodUpdated',
        payload: { last4: '4242' },
      },
    ]);
  } catch (error) {
    if (error instanceof ConcurrencyException) {
      console.error(`Caught Expected Concurrency Error: ${error.message}`);
    } else {
      throw error;
    }
  }
}

runDemo();
