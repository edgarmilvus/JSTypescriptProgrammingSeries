/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * Represents the fundamental structure of an immutable domain event.
 */
export interface DomainEvent {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly aggregateType: string;
  readonly eventType: string;
  readonly eventVersion: number;
  readonly timestamp: Date;
  readonly payload: Record<string, unknown>;
}

/**
 * Concurrency exception thrown when version mismatch occurs during append operations.
 */
export class ConcurrencyException extends Error {
  constructor(aggregateId: string, expectedVersion: number, actualVersion: number) {
    super(
      `Concurrency conflict for aggregate ${aggregateId}. Expected version: ${expectedVersion}, Actual version: ${actualVersion}`
    );
    this.name = 'ConcurrencyException';
  }
}

/**
 * Interface defining the persistence contract for our append-only event store.
 */
export interface IEventStore {
  saveEvents(aggregateId: string, expectedVersion: number, events: Omit<DomainEvent, 'eventId' | 'timestamp'>[]): Promise<void>;
  getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]>;
}

/**
 * In-memory implementation of an Append-Only Event Store suitable for testing and scaling out
 * with an underlying ACID-compliant database (e.g., PostgreSQL).
 */
export class InMemoryEventStore implements IEventStore {
  private readonly store: Map<string, DomainEvent[]> = new Map();

  /**
   * Appends new events to the aggregate stream after validating optimistic concurrency.
   */
  public async saveEvents(
    aggregateId: string,
    expectedVersion: number,
    newEvents: Omit<DomainEvent, 'eventId' | 'timestamp'>[]
  ): Promise<void> {
    // Retrieve existing event stream or initialize a new one
    const existingEvents = this.store.get(aggregateId) || [];
    const currentVersion = existingEvents.length > 0 
      ? existingEvents[existingEvents.length - 1].eventVersion 
      : 0;

    // Enforce Optimistic Concurrency Control (OCC)
    if (currentVersion !== expectedVersion) {
      throw new ConcurrencyException(aggregateId, expectedVersion, currentVersion);
    }

    let versionCounter = currentVersion;
    const timestamp = new Date();

    // Map raw event inputs to fully hydrated domain events
    const hydratedEvents: DomainEvent[] = newEvents.map((eventData) => {
      versionCounter++;
      return {
        ...eventData,
        eventId: randomUUID(),
        eventVersion: versionCounter,
        timestamp,
      };
    });

    // Append to our immutable ledger
    this.store.set(aggregateId, [...existingEvents, ...hydratedEvents]);
  }

  /**
   * Replays the complete event stream for a given aggregate.
   */
  public async getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]> {
    const events = this.store.get(aggregateId);
    if (!events) {
      throw new Error(`Aggregate with ID ${aggregateId} not found.`);
    }
    // Return a frozen copy to preserve immutability
    return Object.freeze([...events]);
  }
}

/**
 * Subscription Model for Read-Model Projections (CQRS pattern).
 */
export type EventSubscriber = (event: DomainEvent) => Promise<void>;

export class EventBus {
  private subscribers: EventSubscriber[] = [];

  public subscribe(subscriber: EventSubscriber): void {
    this.subscribers.push(subscriber);
  }

  public async publish(event: DomainEvent): Promise<void> {
    for (const subscriber of this.subscribers) {
      await subscriber(event);
    }
  }
}

// --- Execution Example ---
async function runDemo() {
  const eventStore = new InMemoryEventStore();
  const eventBus = new EventBus();

  // Register a simple projector that logs state mutations
  eventBus.subscribe(async (event) => {
    console.log(`[Projector] Processing Event: ${event.eventType} for Aggregate: ${event.aggregateId} (v${event.eventVersion})`);
  });

  const subscriptionId = 'sub_12345';

  // 1. First transaction: Initialize Subscription
  const initialEvents = [
    {
      aggregateId: subscriptionId,
      aggregateType: 'Subscription',
      eventType: 'SubscriptionInitialized',
      payload: { planId: 'enterprise-tier', customerId: 'cust_999' },
    },
  ];

  await eventStore.saveEvents(subscriptionId, 0, initialEvents);
  
  // Publish events to the bus for read-models
  const savedStream = await eventStore.getEventsForAggregate(subscriptionId);
  await eventBus.publish(savedStream[0]);

  // 2. Second transaction: Upgrade Subscription (Optimistic Concurrency check matching version 1)
  const upgradeEvents = [
    {
      aggregateId: subscriptionId,
      aggregateType: 'Subscription',
      eventType: 'SubscriptionUpgraded',
      payload: { newPlanId: 'global-scale-tier' },
    },
  ];

  await eventStore.saveEvents(subscriptionId, 1, upgradeEvents);
  const updatedStream = await eventStore.getEventsForAggregate(subscriptionId);
  await eventBus.publish(updatedStream[1]);

  console.log(`Total events in stream: ${updatedStream.length}`);
}

runDemo().catch(console.error);
