/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface CheckpointStore {
  getCheckpoint(projectionName: string): Promise<number>;
  saveCheckpoint(projectionName: string, position: number): Promise<void>;
}

export interface StoredEvent {
  eventId: string;
  eventType: string;
  version: number;
  timestamp: Date;
  data: Record<string, unknown>;
}

export interface EventStoreTailer {
  readAllEventsFromPosition(position: number, limit: number): Promise<StoredEvent[]>;
}

export interface Projector {
  readonly projectionName: string;
  handle(event: StoredEvent): Promise<void>;
}

export class ProjectionEngine {
  constructor(
    private checkpointStore: CheckpointStore,
    private eventStore: EventStoreTailer,
    private projector: Projector
  ) {}

  public async catchUp(): Promise<void> {
    const projectionName = this.projector.projectionName;
    const batchSize = 100;
    let isCatchingUp = true;

    while (isCatchingUp) {
      // 1. Retrieve current checkpoint position for this projector from checkpointStore.
      const currentPosition = await this.checkpointStore.getCheckpoint(projectionName);

      // 2. Loop and fetch batches of events from eventStore starting from the checkpoint position.
      const events = await this.eventStore.readAllEventsFromPosition(currentPosition, batchSize);

      if (events.length === 0) {
        isCatchingUp = false;
        break;
      }

      // 3. Process each event sequentially
      for (const event of events) {
        try {
          // a. Pass event to projector.handle(event).
          await this.projector.handle(event);

          // b. Upon successful handling, update the checkpoint position in checkpointStore.
          currentPosition = event.version; // Assuming version serves as global position tracker
          await this.checkpointStore.saveCheckpoint(projectionName, currentPosition);
        } catch (error) {
          // 4. Handle errors gracefully: stop processing on failure without advancing checkpoint.
          console.error(`Projection failed for '${projectionName}' at event version ${event.version}:`, error);
          throw error; // Halts the catch-up loop to preserve at-least-once safety and prevent checkpoint skipping
        }
      }
    }
  }
}
