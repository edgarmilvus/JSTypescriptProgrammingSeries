/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface StoredEventDto {
  eventId: string;
  eventType: string;
  version: number;
  timestamp: string;
  data: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

interface EventStreamInspectorProps {
  aggregateId: string;
  apiEndpoint: string;
}

export const EventStreamInspector: React.FC<EventStreamInspectorProps> = ({
  aggregateId,
  apiEndpoint,
}) => {
  const [events, setEvents] = useState<StoredEventDto[]>([]);
  const [filterType, setFilterType] = useState<string>('');
  const [isPolling, setIsPolling] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch events effect with polling support
  useEffect(() => {
    let isMounted = true;

    const fetchEvents = async () => {
      try {
        const response = await fetch(`${apiEndpoint}/streams/${aggregateId}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch event stream: ${response.statusText}`);
        }
        const data: StoredEventDto[] = await response.json();
        if (isMounted) {
          setEvents(data);
          setError(null);
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err.message || 'An unexpected error occurred');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchEvents();

    let intervalId: NodeJS.Timeout | null = null;
    if (isPolling) {
      intervalId = setInterval(fetchEvents, 3000);
    }

    return () => {
      isMounted = false;
      if (intervalId) clearInterval(intervalId);
    };
  }, [aggregateId, apiEndpoint, isPolling]);

  // Filter events based on eventType input
  const filteredEvents = events.filter((event) =>
    event.eventType.toLowerCase().includes(filterType.toLowerCase())
  );

  return (
    <div className="event-stream-inspector p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl font-sans">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Event Stream: {aggregateId}</h2>
        <div className="flex gap-4 items-center">
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input 
              type="checkbox" 
              checked={isPolling} 
              onChange={(e) => setIsPolling(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-blue-600 focus:ring-blue-500"
            />
            Live Poll (3s)
          </label>
          <input
            type="text"
            placeholder="Filter by event type..."
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1 bg-slate-800 border border-slate-700 rounded text-sm text-slate-200 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {loading && <div className="text-slate-400 py-4">Loading event stream...</div>}
      {error && <div className="text-red-400 py-4 bg-red-950/50 px-4 rounded border border-red-800">{error}</div>}

      {!loading && !error && (
        <div className="space-y-4">
          {filteredEvents.length === 0 ? (
            <div className="text-slate-500 text-center py-6">No matching events found.</div>
          ) : (
            filteredEvents.map((event) => (
              <div 
                key={event.eventId} 
                className="bg-slate-800/60 border border-slate-700/60 rounded-lg p-4 transition hover:border-slate-600"
              >
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-0.5 bg-blue-900/60 text-blue-300 border border-blue-700/50 rounded-full text-xs font-semibold">
                      {event.eventType}
                    </span>
                    <span className="text-xs text-slate-400">v{event.version}</span>
                  </div>
                  <span className="text-xs text-slate-500">
                    {new Date(event.timestamp).toLocaleString()}
                  </span>
                </div>
                
                <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <span className="text-xs font-semibold text-slate-400 block mb-1">Payload Data:</span>
                    <pre className="bg-slate-950 p-3 rounded text-xs text-emerald-400 overflow-x-auto font-mono">
                      {JSON.stringify(event.data, null, 2)}
                    </pre>
                  </div>
                  {event.metadata && (
                    <div>
                      <span className="text-xs font-semibold text-slate-400 block mb-1">Metadata:</span>
                      <pre className="bg-slate-950 p-3 rounded text-xs text-amber-400 overflow-x-auto font-mono">
                        {JSON.stringify(event.metadata, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
