/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Define custom concurrency error
export class ConcurrencyError extends Error {
  constructor(public readonly streamId: string, public readonly expectedVersion: number, public readonly actualVersion: number) {
    super(`Concurrency conflict on stream '${streamId}'. Expected version ${expectedVersion}, but found actual version ${actualVersion}.`);
    this.name = 'ConcurrencyError';
  }
}

export interface DomainEvent {
  readonly eventId: string;
  readonly eventType: string;
  readonly data: Record<string, unknown>;
  readonly metadata?: Record<string, unknown>;
}

export interface StoredEvent extends DomainEvent {
  readonly version: number;
  readonly timestamp: Date;
}

export class InMemoryEventStore {
  private streams: Map<string, StoredEvent[]> = new Map();

  public async appendToStream(
    streamId: string, 
    events: DomainEvent[], 
    expectedVersion: number
  ): Promise<void> {
    // TODO: Implement the Optimistic Concurrency Control check here.
    // 1. Retrieve existing events for the streamId, or initialize an empty array if it doesn't exist.
    // 2. Determine the current actual version of the stream.
    // 3. Compare actual version with expectedVersion. Throw ConcurrencyError if they don't match.
    // 4. Map the incoming DomainEvents to StoredEvents with incremented versions and timestamps.
    // 5. Persist the new events back into the streams map.
  }

  public async readStream(streamId: string): Promise<StoredEvent[]> {
    return this.streams.get(streamId) || [];
  }
}
