/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

export interface SerializableEvent {
  eventId: string;
  eventType: string;
  data: string; // JSON stringified data
  metadata?: string; // JSON stringified metadata
}

export type EventConstructor<T = any> = new (...args: any[]) => T;

export class EventRegistry {
  private registry: Map<string, EventConstructor> = new Map();

  public register(eventType: string, constructor: EventConstructor): void {
    // TODO: Register the event type mapping
  }

  public getConstructor(eventType: string): EventConstructor | undefined {
    // TODO: Retrieve the constructor for a given event type string
    return undefined;
  }
}

export class EventDeserializer {
  constructor(private registry: EventRegistry) {}

  public deserialize(storedEvent: SerializableEvent): any {
    // TODO: 
    // 1. Look up the constructor using storedEvent.eventType.
    // 2. If not found, throw an error.
    // 3. Parse JSON data and metadata.
    // 4. Instantiate and return the domain event object using Object.create or constructor invocation.
  }
}
