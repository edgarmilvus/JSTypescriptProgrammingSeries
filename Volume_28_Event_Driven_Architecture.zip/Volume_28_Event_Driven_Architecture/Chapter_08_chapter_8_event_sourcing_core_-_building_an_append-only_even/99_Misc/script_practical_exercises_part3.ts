/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export interface Snapshot {
  aggregateId: string;
  aggregateType: string;
  version: number;
  state: Record<string, unknown>;
  timestamp: Date;
}

export interface ISnapshotStore {
  saveSnapshot(snapshot: Snapshot): Promise<void>;
  getLatestSnapshot(aggregateId: string): Promise<Snapshot | null>;
}

export interface IEventStoreForSnapshotting {
  readStreamFromVersion(streamId: string, fromVersion: number): Promise<StoredEvent[]>;
}

export class AggregateLoader {
  constructor(
    private snapshotStore: ISnapshotStore,
    private eventStore: IEventStoreForSnapshotting
  ) {}

  public async loadAggregate<T>(
    aggregateId: string,
    factory: (state?: Record<string, unknown>) => T,
    applyEvent: (aggregate: T, event: StoredEvent) => void
  ): Promise<{ aggregate: T; version: number }> {
    // TODO: 
    // 1. Fetch the latest snapshot for aggregateId using snapshotStore.
    // 2. Determine starting version (if snapshot exists, version + 1; otherwise, 0).
    // 3. Initialize aggregate state from snapshot or via factory() if no snapshot exists.
    // 4. Read remaining events from eventStore using readStreamFromVersion.
    // 5. Iterate through events, calling applyEvent() on the aggregate.
    // 6. Return the fully hydrated aggregate instance and its latest version number.
  }
}
