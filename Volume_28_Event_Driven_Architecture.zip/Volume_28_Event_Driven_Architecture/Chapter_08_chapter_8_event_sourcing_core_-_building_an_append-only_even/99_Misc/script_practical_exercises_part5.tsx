/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect } from 'react';

export interface StoredEventDto {
  eventId: string;
  eventType: string;
  version: number;
  timestamp: string;
  data: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

interface EventStreamInspectorProps {
  aggregateId: string;
  apiEndpoint: string;
}

export const EventStreamInspector: React.FC<EventStreamInspectorProps> = ({
  aggregateId,
  apiEndpoint,
}) => {
  const [events, setEvents] = useState<StoredEventDto[]>([]);
  const [filterType, setFilterType] = useState<string>('');
  const [isPolling, setIsPolling] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // TODO: Implement useEffect to fetch events from `${apiEndpoint}/streams/${aggregateId}`.
  // TODO: Implement polling interval logic when `isPolling` is true.
  // TODO: Implement filteredEvents logic based on `filterType`.

  return (
    <div className="event-stream-inspector p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Event Stream: {aggregateId}</h2>
        <div className="flex gap-4 items-center">
          <label className="flex items-center gap-2 text-sm">
            <input 
              type="checkbox" 
              checked={isPolling} 
              onChange={(e) => setIsPolling(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700"
            />
            Live Poll
          </label>
          <input
            type="text"
            placeholder="Filter by event type..."
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1 bg-slate-800 border border-slate-700 rounded text-sm text-slate-200 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* TODO: Render loading state, error state, or the chronological list of events */}
      <div className="space-y-4">
        {/* Render event items here */}
      </div>
    </div>
  );
};
