/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

-- Example of a denormalized read-model schema in PostgreSQL
CREATE TABLE project_dashboards (
    project_id UUID PRIMARY KEY,
    organization_id UUID NOT NULL,
    project_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    team_members JSONB NOT NULL DEFAULT '[]', -- Array of {id, name, avatarUrl}
    task_counts JSONB NOT NULL DEFAULT '{}',   -- {open: 12, in_progress: 4, completed: 35}
    recent_activities JSONB NOT NULL DEFAULT '[]', -- Last 3 activity logs
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);

-- Creating a B-Tree index for tenant isolation and fast filtering
CREATE INDEX idx_project_dashboards_org ON project_dashboards(organization_id);

-- Creating a GIN index for high-performance querying inside JSONB columns
CREATE INDEX idx_project_dashboards_team_gin ON project_dashboards USING GIN (team_members);
