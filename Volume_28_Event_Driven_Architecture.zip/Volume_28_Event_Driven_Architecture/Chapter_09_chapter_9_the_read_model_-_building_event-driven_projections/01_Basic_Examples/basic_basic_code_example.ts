/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Pool, PoolClient } from 'pg';

/**
 * Configuration interface for the PostgreSQL connection pool.
 */
interface DatabaseConfig {
  connectionString: string;
}

/**
 * Represents a domain event envelope emitted by the write-side aggregate.
 */
interface DomainEvent<T = any> {
  eventId: string;
  eventType: string;
  aggregateId: string;
  version: number;
  payload: T;
  occurredAt: Date;
}

/**
 * Payload for the WorkspaceCreated event.
 */
interface WorkspaceCreatedPayload {
  name: string;
  ownerId: string;
}

/**
 * Payload for the MemberAdded event.
 */
interface MemberAddedPayload {
  userId: string;
  role: 'admin' | 'member';
}

/**
 * The Read Model structure optimized for UI dashboard queries.
 */
interface WorkspaceSummaryReadModel {
  workspaceId: string;
  name: string;
  ownerId: string;
  memberCount: number;
  updatedAt: Date;
}

/**
 * Projector service responsible for listening to domain events
 * and updating the PostgreSQL read model idempotently.
 */
class WorkspaceProjector {
  private pool: Pool;

  constructor(config: DatabaseConfig) {
    // Initialize the PostgreSQL connection pool
    this.pool = new Pool(config);
  }

  /**
   * Ensures the read-model tables and the idempotent event-tracker table exist.
   */
  public async initializeSchema(): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      // Create the denormalized read model table optimized for queries
      await client.query(`
        CREATE TABLE IF NOT EXISTS workspace_summaries (
          workspace_id UUID PRIMARY KEY,
          name TEXT NOT NULL,
          owner_id TEXT NOT NULL,
          member_count INTEGER NOT NULL DEFAULT 1,
          updated_at TIMESTAMPTZ NOT NULL
        );
      `);

      // Create an idempotency tracking table to prevent duplicate event processing
      await client.query(`
        CREATE TABLE IF NOT EXISTS processed_events (
          event_id UUID PRIMARY KEY,
          event_type TEXT NOT NULL,
          processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
      `);

      await client.query('COMMIT');
      console.log('Read model schema initialized successfully.');
    } catch (error) {
      await client.query('ROLLBACK');
      console.error('Failed to initialize schema:', error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Main entry point for dispatching domain events to their respective projection handlers.
   * Executes inside a database transaction to guarantee atomicity and idempotency.
   */
  public async handleEvent(event: DomainEvent): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      // 1. Check idempotency: Have we processed this event ID before?
      const idempotencyCheck = await client.query(
        'SELECT 1 FROM processed_events WHERE event_id = $1',
        [event.eventId]
      );

      if ((idempotencyCheck.rowCount ?? 0) > 0) {
        console.warn(`Event ${event.eventId} (${event.eventType}) already processed. Skipping.`);
        await client.query('ROLLBACK');
        return;
      }

      // 2. Route the event to the appropriate handler based on its event type
      switch (event.eventType) {
        case 'WorkspaceCreated':
          await this.projectWorkspaceCreated(client, event as DomainEvent<WorkspaceCreatedPayload>);
          break;
        case 'MemberAdded':
          await this.projectMemberAdded(client, event as DomainEvent<MemberAddedPayload>);
          break;
        default:
          console.log(`Unhandled event type: ${event.eventType}`);
      }

      // 3. Record the event as processed within the same transaction
      await client.query(
        'INSERT INTO processed_events (event_id, event_type) VALUES ($1, $2)',
        [event.eventId, event.eventType]
      );

      await client.query('COMMIT');
      console.log(`Successfully projected event: ${event.eventType} [${event.eventId}]`);
    } catch (error) {
      await client.query('ROLLBACK');
      console.error(`Error projecting event ${event.eventId}:`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Handles the 'WorkspaceCreated' projection logic.
   */
  private async projectWorkspaceCreated(
    client: PoolClient,
    event: DomainEvent<WorkspaceCreatedPayload>
  ): Promise<void> {
    const { aggregateId, payload, occurredAt } = event;
    
    // Insert the initial denormalized read model record
    await client.query(
      `INSERT INTO workspace_summaries (workspace_id, name, owner_id, member_count, updated_at)
       VALUES ($1, $2, $3, 1, $4)
       ON CONFLICT (workspace_id) DO NOTHING;`,
      [aggregateId, payload.name, payload.ownerId, occurredAt]
    );
  }

  /**
   * Handles the 'MemberAdded' projection logic.
   */
  private async projectMemberAdded(
    client: PoolClient,
    event: DomainEvent<MemberAddedPayload>
  ): Promise<void> {
    const { aggregateId, occurredAt } = event;

    // Increment the member count and update the timestamp
    await client.query(
      `UPDATE workspace_summaries
       SET member_count = member_count + 1,
           updated_at = $1
       WHERE workspace_id = $2;`,
      [occurredAt, aggregateId]
    );
  }

  /**
   * Query method utilized by SaaS API controllers or Server Actions to fetch read models.
   */
  public async getWorkspaceSummary(workspaceId: string): Promise<WorkspaceSummaryReadModel | null> {
    const result = await this.pool.query(
      `SELECT workspace_id AS "workspaceId", name, owner_id AS "ownerId", 
              member_count AS "memberCount", updated_at AS "updatedAt"
       FROM workspace_summaries
       WHERE workspace_id = $1`,
      [workspaceId]
    );

    if (result.rows.length === 0) {
      return null;
    }

    return result.rows[0] as WorkspaceSummaryReadModel;
  }

  /**
   * Gracefully close the database connection pool.
   */
  public async shutdown(): Promise<void> {
    await this.pool.end();
  }
}

// ==========================================
// Execution Example (Simulated App Runtime)
// ==========================================
async function runDemo() {
  const projector = new WorkspaceProjector({
    connectionString: process.env.DATABASE_URL || 'postgres://postgres:password@localhost:5432/saas_read_model'
  });

  try {
    // Step 1: Initialize database schema
    await projector.initializeSchema();

    // Step 2: Simulate an incoming 'WorkspaceCreated' domain event
    const workspaceCreatedEvent: DomainEvent<WorkspaceCreatedPayload> = {
      eventId: '11111111-1111-1111-1111-111111111111',
      eventType: 'WorkspaceCreated',
      aggregateId: 'wspace-999',
      version: 1,
      payload: {
        name: 'Engineering Team',
        ownerId: 'user-abc'
      },
      occurredAt: new Date()
    };

    await projector.handleEvent(workspaceCreatedEvent);

    // Attempting duplicate delivery to test idempotency
    console.log('\n--- Testing Idempotency (Sending duplicate event) ---');
    await projector.handleEvent(workspaceCreatedEvent);

    // Step 3: Simulate an incoming 'MemberAdded' domain event
    const memberAddedEvent: DomainEvent<MemberAddedPayload> = {
      eventId: '22222222-2222-2222-2222-222222222222',
      eventType: 'MemberAdded',
      aggregateId: 'wspace-999',
      version: 2,
      payload: {
        userId: 'user-xyz',
        role: 'member'
      },
      occurredAt: new Date()
    };

    await projector.handleEvent(memberAddedEvent);

    // Step 4: Query the read model to verify output
    console.log('\n--- Fetching Read Model for UI ---');
    const summary = await projector.getWorkspaceSummary('wspace-999');
    console.log('Workspace Summary Read Model:', summary);

  } catch (error) {
    console.error('Demo execution failed:', error);
  } finally {
    await projector.shutdown();
  }
}

// Uncomment to run directly if executing this file
// runDemo();
