/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pool, PoolClient } from 'pg';

/**
 * Configuration interface for the Event Projector Service.
 */
interface ProjectorConfig {
  connectionString: string;
  consumerGroup: string;
  batchSize: number;
}

/**
 * Base structure for a Domain Event originating from the Write Model.
 */
interface DomainEvent<T = Record<string, unknown>> {
  eventId: string;
  aggregateId: string;
  eventType: string;
  version: number;
  payload: T;
  occurredAt: Date;
}

/**
 * Specialized payload for LLM analysis completed events.
 */
interface LLMAnalysisCompletedPayload {
  repositoryId: string;
  pullRequestId: number;
  summary: string;
  vulnerabilityCount: number;
  tokensUsed: number;
}

/**
 * PostgreSQL Event-Driven Projector Service for CQRS Read Models.
 * Handles idempotent projection updates, consumer check-pointing, and batch processing.
 */
export class CodeReviewReadModelProjector {
  private pool: Pool;
  private consumerGroup: string;
  private batchSize: number;
  private isRunning: boolean = false;

  constructor(config: ProjectorConfig) {
    this.pool = new Pool({ connectionString: config.connectionString });
    this.consumerGroup = config.consumerGroup;
    this.batchSize = config.batchSize;
  }

  /**
   * Initializes required read-model tables and projector checkpoint tracking.
   */
  public async initializeSchema(): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      // Create the denormalized read model for dashboard queries
      await client.query(`
        CREATE TABLE IF NOT EXISTS pr_dashboard_read_model (
          repository_id VARCHAR(255) NOT NULL,
          pull_request_id INT NOT NULL,
          status VARCHAR(50) NOT NULL,
          summary TEXT,
          vulnerability_count INT DEFAULT 0,
          tokens_consumed INT DEFAULT 0,
          last_updated_version INT NOT NULL,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (repository_id, pull_request_id)
        );
      `);

      // Create the projector checkpoint table to guarantee idempotent processing
      await client.query(`
        CREATE TABLE IF NOT EXISTS projector_checkpoints (
          consumer_group VARCHAR(255) PRIMARY KEY,
          last_processed_position BIGINT NOT NULL,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);

      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Failed to initialize projector schema: ${(error as Error).message}`);
    } finally {
      client.release();
    }
  }

  /**
   * Starts the polling event loop for processing domain events asynchronously.
   */
  public async start(): Promise<void> {
    this.isRunning = true;
    while (this.isRunning) {
      try {
        const processedCount = await this.processBatch();
        if (processedCount === 0) {
          // Back off briefly if no new events are available
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }
      } catch (error) {
        console.error('Error in projector processing loop:', error);
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }
  }

  /**
   * Stops the projector gracefully.
   */
  public stop(): void {
    this.isRunning = false;
  }

  /**
   * Processes a single batch of events within a database transaction to ensure atomicity.
   */
  private async processBatch(): Promise<number> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      // Fetch the current projector position (checkpoint)
      const checkpointRes = await client.query(
        'SELECT last_processed_position FROM projector_checkpoints WHERE consumer_group = $1 FOR UPDATE',
        [this.consumerGroup]
      );

      let lastPosition = 0n;
      if (checkpointRes.rows.length > 0) {
        lastPosition = BigInt(checkpointRes.rows[0].last_processed_position);
      } else {
        await client.query(
          'INSERT INTO projector_checkpoints (consumer_group, last_processed_position) VALUES ($1, 0)',
          [this.consumerGroup]
        );
      }

      // Fetch next batch of events from the event store (simulated table)
      const eventsRes = await client.query(
        `SELECT global_position, event_id, aggregate_id, event_type, version, payload, occurred_str 
         FROM event_store 
         WHERE global_position > $1 
         ORDER BY global_position ASC 
         LIMIT $2`,
        [lastPosition.toString(), this.batchSize]
      );

      const events = eventsRes.rows;
      if (events.length === 0) {
        await client.query('COMMIT');
        return 0;
      }

      let maxPosition = lastPosition;

      // Project each event into the read model
      for (const rawEvent of events) {
        const event: DomainEvent = {
          eventId: rawEvent.event_id,
          aggregateId: rawEvent.aggregate_id,
          eventType: rawEvent.event_type,
          version: rawEvent.version,
          payload: rawEvent.payload,
          occurredAt: new Date(rawEvent.occurred_str),
        };

        await this.projectEvent(client, event);
        maxPosition = BigInt(rawEvent.global_position);
      }

      // Update checkpoint position atomically with the projection updates
      await client.query(
        'UPDATE projector_checkpoints SET last_processed_position = $1, updated_at = CURRENT_TIMESTAMP WHERE consumer_group = $2',
        [maxPosition.toString(), this.consumerGroup]
      );

      await client.query('COMMIT');
      return events.length;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Routes domain events to specific projection updaters with idempotency guards.
   */
  private async projectEvent(client: PoolClient, event: DomainEvent): Promise<void> {
    switch (event.eventType) {
      case 'CodeReviewRequested':
        await client.query(
          `INSERT INTO pr_dashboard_read_model 
           (repository_id, pull_request_id, status, last_updated_version) 
           VALUES ($1, $2, 'PENDING', $3)
           ON CONFLICT (repository_id, pull_request_id) 
           DO UPDATE SET status = 'PENDING', last_updated_version = $3 
           WHERE EXCLUDED.last_updated_version > pr_dashboard_read_model.last_updated_version`,
          [event.payload.repositoryId, event.payload.pullRequestId, event.version]
        );
        break;

      case 'LLMAnalysisCompleted': {
        const payload = event.payload as unknown as LLMAnalysisCompletedPayload;
        await client.query(
          `UPDATE pr_dashboard_read_model 
           SET status = 'ANALYZED', 
               summary = $1, 
               vulnerability_count = $2, 
               tokens_consumed = $3, 
               last_updated_version = $4,
               updated_at = CURRENT_TIMESTAMP
           WHERE repository_id = $5 AND pull_request_id = $6 
             AND $4 > last_updated_version`,
          [
            payload.summary,
            payload.vulnerabilityCount,
            payload.tokensUsed,
            event.version,
            payload.repositoryId,
            payload.pullRequestId,
          ]
        );
        break;
      }
      default:
        // Ignore unhandled event types gracefully
        break;
    }
  }
}
