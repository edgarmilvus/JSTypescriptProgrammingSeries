/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the base domain event interface
export interface BaseDomainEvent {
  eventId: string;
  streamId: string;
  sequenceNumber: number;
  occurredAt: Date;
  type: string;
}

// Define specific event interfaces
export interface OrderCreatedEvent extends BaseDomainEvent {
  type: 'OrderCreated';
  payload: {
    customerId: string;
    initialAmount: number;
  };
}

export interface ItemAddedToOrderEvent extends BaseDomainEvent {
  type: 'ItemAddedToOrder';
  payload: {
    itemId: string;
    price: number;
    quantity: number;
  };
}

export type DomainEvent = OrderCreatedEvent | ItemAddedToOrderEvent;

// User-defined Type Guard for OrderCreatedEvent
export function isOrderCreatedEvent(event: DomainEvent): event is OrderCreatedEvent {
  return event.type === 'OrderCreated';
}

// User-defined Type Guard for ItemAddedToOrderEvent
export function isItemAddedToOrderEvent(event: DomainEvent): event is ItemAddedToOrderEvent {
  return event.type === 'ItemAddedToOrder';
}

// OrderSummaryProjector implementation
export class OrderSummaryProjector {
  constructor(private dbPool: { query: (sql: string, params?: any[]) => Promise<any> }) {}

  public async handleEvent(event: DomainEvent): Promise<void> {
    const client = await this.dbPool.query('BEGIN'); // Simplified pool transaction handle
    try {
      // 1. Check if event has already been processed using the processed_events ledger (Idempotency check)
      const ledgerCheck = await this.dbPool.query(
        `SELECT 1 FROM processed_events WHERE event_id = $1`,
        [event.eventId]
      );

      if (ledgerCheck.rows && ledgerCheck.rows.length > 0) {
        await this.dbPool.query('COMMIT');
        return; // Event already processed; idempotent skip
      }

      // 2. Handle type narrowing and apply state mutations based on event type
      if (isOrderCreatedEvent(event)) {
        // Upsert or insert new order summary read model record
        await this.dbPool.query(
          `INSERT INTO order_summaries (order_id, customer_id, status, total_amount, item_count, last_processed_sequence)
           VALUES ($1, $2, 'CREATED', $3, 0, $4)
           ON CONFLICT (order_id) DO UPDATE 
           SET total_amount = order_summaries.total_amount + $3,
               last_processed_sequence = GREATEST(order_summaries.last_processed_sequence, $4)`,
          [event.streamId, event.payload.customerId, event.payload.initialAmount, event.sequenceNumber]
        );
      } else if (isItemAddedToOrderEvent(event)) {
        const itemTotal = event.payload.price * event.payload.quantity;
        await this.dbPool.query(
          `UPDATE order_summaries 
           SET total_amount = total_amount + $1, 
               item_count = item_count + $2,
               last_processed_sequence = GREATEST(last_processed_sequence, $3)
           WHERE order_id = $4 AND last_processed_sequence < $3`,
          [itemTotal, event.payload.quantity, event.sequenceNumber, event.streamId]
        );
      }

      // 3. Record eventId in processed_events ledger to lock in idempotency
      await this.dbPool.query(
        `INSERT INTO processed_events (event_id, processed_at) VALUES ($1, NOW())`,
        [event.eventId]
      );

      await this.dbPool.query('COMMIT');
    } catch (error) {
      await this.dbPool.query('ROLLBACK');
      throw error;
    }
  }
}
