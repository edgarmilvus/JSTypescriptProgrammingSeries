/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface OutboxEventRecord {
  id: string;
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  retryCount: number;
}

export interface EventBus {
  publish(eventType: string, payload: Record<string, unknown>): Promise<void>;
}

export class OutboxPoller {
  private isPolling = false;

  constructor(
    private dbClient: { query: (sql: string, params?: any[]) => Promise<any> }, 
    private eventBus: EventBus,
    private batchSize: number = 50
  ) {}

  public async startPolling(intervalMs: number): Promise<void> {
    setInterval(async () => {
      if (this.isPolling) return;
      this.isPolling = true;
      try {
        await this.pollAndDispatch();
      } catch (error) {
        console.error('Error during outbox polling execution:', error);
      } finally {
        this.isPolling = false;
      }
    }, intervalMs);
  }

  private async pollAndDispatch(): Promise<void> {
    // Begin explicit transaction for safe row locking and batch updates
    await this.dbClient.query('BEGIN');

    try {
      // Fetch pending events using SKIP LOCKED to prevent horizontal worker contention
      const result = await this.dbClient.query(
        `SELECT id, aggregate_type as "aggregateType", aggregate_id as "aggregateId", 
                event_type as "eventType", payload, retry_count as "retryCount"
         FROM outbox_events 
         WHERE status = 'PENDING' 
         ORDER BY created_at ASC 
         LIMIT $1 
         FOR UPDATE SKIP LOCKED`,
        [this.batchSize]
      );

      const events: OutboxEventRecord[] = result.rows;

      if (events.length === 0) {
        await this.dbClient.query('COMMIT');
        return;
      }

      for (const event of events) {
        try {
          // Attempt dispatching to external broker
          await this.eventBus.publish(event.eventType, {
            aggregateId: event.aggregateId,
            aggregateType: event.aggregateType,
            ...event.payload,
          });

          // Mark outbox entry as published on success
          await this.dbClient.query(
            `UPDATE outbox_events SET status = 'PUBLISHED', updated_at = NOW() WHERE id = $1`,
            [event.id]
          );
        } catch (dispatchError) {
          const newRetryCount = event.retryCount + 1;
          const newStatus = newRetryCount > 5 ? 'FAILED' : 'PENDING';

          if (newStatus === 'FAILED') {
            console.error(`Alarm: Outbox event ${event.id} exceeded max retries and marked as FAILED.`);
          }

          // Update retry counter and mark as failed if threshold is crossed
          await this.dbClient.query(
            `UPDATE outbox_events 
             SET retry_count = $1, status = $2, updated_at = NOW() 
             WHERE id = $3`,
            [newRetryCount, newStatus, event.id]
          );
        }
      }

      await this.dbClient.query('COMMIT');
    } catch (error) {
      await this.dbClient.query('ROLLBACK');
      throw error;
    }
  }
}
