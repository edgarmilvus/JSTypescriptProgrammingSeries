/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { DomainEvent, isOrderCreatedEvent, isItemAddedToOrderEvent } from './Exercise1';

export interface EventStoreCursor {
  nextChunk(size: number): Promise<DomainEvent[]>;
  close(): Promise<void>;
}

export class ProjectionRebuilder {
  constructor(
    private eventStoreConnection: { query: (sql: string, params?: any[]) => Promise<any> },
    private projectorRegistry: { project(event: DomainEvent): Promise<void> }
  ) {}

  public async rebuild(projectionName: string): Promise<void> {
    console.log(`Starting full projection rebuild for: ${projectionName}`);
    const startTime = Date.now();
    
    // 1. Reset read model table storage
    await this.resetReadModel(projectionName);

    // 2. Initialize event stream cursor
    const cursor = await this.openEventCursor();

    try {
      let batch: DomainEvent[];
      let totalProcessed = 0;
      const chunkSize = 1000;

      // 3. Iterate through chunks using cursor pagination
      while ((batch = await cursor.nextChunk(chunkSize)).length > 0) {
        for (const event of batch) {
          await this.projectorRegistry.project(event);
          totalProcessed++;

          // 4. Log progress metrics every 10,000 processed events
          if (totalProcessed % 10000 === 0) {
            const elapsedSeconds = (Date.now() - startTime) / 1000;
            const rate = totalProcessed / elapsedSeconds;
            console.log(`Rebuild Progress: Processed ${totalProcessed} events. Elapsed: ${elapsedSeconds.toFixed(2)}s (${rate.toFixed(2)} ev/s)`);
          }
        }
      }

      const totalElapsed = (Date.now() - startTime) / 1000;
      console.log(`Finished rebuilding projection: ${projectionName}. Total events processed: ${totalProcessed} in ${totalElapsed.toFixed(2)}s.`);

    } finally {
      await cursor.close();
    }
  }

  private async resetReadModel(projectionName: string): Promise<void> {
    if (projectionName === 'order_summaries') {
      await this.eventStoreConnection.query(`TRUNCATE TABLE order_summaries RESTART IDENTITY CASCADE`);
      await this.eventStoreConnection.query(`TRUNCATE TABLE processed_events RESTART IDENTITY CASCADE`);
    } else {
      throw new Error(`Unknown projection table mapping for: ${projectionName}`);
    }
  }

  private async openEventCursor(): Promise<EventStoreCursor> {
    // Implementation utilizing keyset pagination by global_sequence_number
    let lastSequence = 0;
    const db = this.eventStoreConnection;

    return {
      async nextChunk(size: number): Promise<DomainEvent[]> {
        const result = await db.query(
          `SELECT event_id as "eventId", stream_id as "streamId", sequence_number as "sequenceNumber", 
                  occurred_at as "occurredAt", event_type as "type", payload 
           FROM event_store 
           WHERE global_sequence_number > $1 
           ORDER BY global_sequence_number ASC 
           LIMIT $2`,
          [lastSequence, size]
        );

        const rows = result.rows;
        if (rows.length === 0) return [];

        // Update pagination marker to the highest sequence number in the current chunk
        lastSequence = rows[rows.length - 1].sequenceNumber;

        // Map raw database rows to domain event objects
        return rows.map((row: any) => ({
          eventId: row.eventId,
          streamId: row.streamId,
          sequenceNumber: row.sequenceNumber,
          occurredAt: new Date(row.occurredAt),
          type: row.type,
          payload: row.payload,
        })) as DomainEvent[];
      },
      async close(): Promise<void> {
        // Cleanup cursor resources if required
      }
    };
  }
}
