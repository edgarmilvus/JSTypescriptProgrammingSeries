/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define Read Model DTO
export interface OrderSummaryDto {
  orderId: string;
  customerId: string;
  status: 'PENDING' | 'PAID' | 'SHIPPED' | 'CANCELLED';
  totalAmount: number;
  itemCount: number;
  updatedAt: string;
}

export interface OrderSummaryUpdatedEvent {
  type: 'OrderSummaryUpdated';
  payload: OrderSummaryDto;
}

// 2. Custom Hook for Initial Fetch + Real-time WebSocket Sync
export function useOrderStream(customerId: string) {
  const [orders, setOrders] = useState<OrderSummaryDto[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${wsProtocol}//${window.location.host}/ws/orders?customerId=${customerId}`;
    const socket = new WebSocket(wsUrl);

    // Fetch initial REST snapshot
    async function fetchInitialData() {
      try {
        setLoading(true);
        const response = await fetch(`/api/customers/${customerId}/orders`);
        if (!response.ok) {
          throw new Error(`Failed to fetch orders: ${response.statusText}`);
        }
        const data: OrderSummaryDto[] = await response.json();
        if (isMounted) {
          setOrders(data);
          setError(null);
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err.message || 'Unknown network error');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    fetchInitialData();

    // Attach WebSocket listener for real-time delta synchronization
    socket.onmessage = (event) => {
      try {
        const message: OrderSummaryUpdatedEvent = JSON.parse(event.data);
        if (message.type === 'OrderSummaryUpdated' && isMounted) {
          setOrders((prevOrders) => {
            const index = prevOrders.findIndex((o) => o.orderId === message.payload.orderId);
            if (index >=ريخ > -1 || index !== -1) {
              // Immutable update of existing order summary
              const updated = [...prevOrders];
              updated[index] = message.payload;
              return updated;
            } else {
              // Prepend new order summary if newly created
              return [message.payload, ...prevOrders];
            }
          });
        }
      } catch (parseError) {
        console.error('Failed to parse incoming WebSocket message:', parseError);
      }
    };

    socket.onerror = () => {
      if (isMounted) {
        setError('WebSocket connection error occurred.');
      }
    };

    // Cleanup socket and flag unmounted state on component destroy
    return () => {
      isMounted = false;
      socket.close();
    };
  }, [customerId]);

  return { orders, loading, error };
}

// 3. React Component Implementation
export interface CustomerOrderDashboardProps {
  customerId: string;
}

export const CustomerOrderDashboard: React.FC<CustomerOrderDashboardProps> = ({ customerId }) => {
  const { orders, loading, error } = useOrderStream(customerId);

  if (loading) {
    return <div data-testid="loading-state" className="p-6 text-center text-gray-600">Loading order summaries from read model...</div>;
  }

  if (error) {
    return <div data-testid="error-state" className="p-6 text-center text-red-500 font-semibold">Error: {error}</div>;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto bg-white shadow-md rounded-lg">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">Customer Order Dashboard (CQRS Read View)</h1>
      {orders.length === 0 ? (
        <p className="text-gray-500">No active orders found for this customer.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Updated</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {orders.map((order) => (
                <tr key={order.orderId}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{order.orderId}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      order.status === 'PAID' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.itemCount}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.totalAmount.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(order.updatedAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
