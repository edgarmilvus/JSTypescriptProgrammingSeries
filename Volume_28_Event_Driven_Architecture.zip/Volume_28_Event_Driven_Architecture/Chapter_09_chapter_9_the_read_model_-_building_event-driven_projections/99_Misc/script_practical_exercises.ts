/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Define the base domain event interface
export interface BaseDomainEvent {
  eventId: string;
  streamId: string;
  sequenceNumber: number;
  occurredAt: Date;
  type: string;
}

// Define specific event interfaces
export interface OrderCreatedEvent extends BaseDomainEvent {
  type: 'OrderCreated';
  payload: {
    customerId: string;
    initialAmount: number;
  };
}

export interface ItemAddedToOrderEvent extends BaseDomainEvent {
  type: 'ItemAddedToOrder';
  payload: {
    itemId: string;
    price: number;
    quantity: number;
  };
}

export type DomainEvent = OrderCreatedEvent | ItemAddedToOrderEvent; // Add more as needed

// TODO: Implement the user-defined Type Guard for OrderCreatedEvent
export function isOrderCreatedEvent(event: DomainEvent): event is OrderCreatedEvent {
  // Your code here
  return false;
}

// TODO: Implement the OrderSummaryProjector class
export class OrderSummaryProjector {
  constructor(private dbPool: any /* PostgreSQL Pool mock */) {}

  public async handleEvent(event: DomainEvent): Promise<void> {
    // 1. Check if event has already been processed using the processed_events ledger
    // 2. Begin transaction
    // 3. Apply event logic based on type narrowing (using type guards)
    // 4. Update order_summaries read model
    // 5. Record eventId in processed_events ledger
    // 6. Commit transaction
    throw new Error('Not implemented');
  }
}
