/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

export interface OutboxEventRecord {
  id: string;
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  retryCount: number;
}

export interface EventBus {
  publish(eventType: string, payload: Record<string, unknown>): Promise<void>;
}

export class OutboxPoller {
  private isPolling = false;

  constructor(
    private dbClient: any, // PostgreSQL client connection
    private eventBus: EventBus,
    private batchSize: number = 50
  ) {}

  public async startPolling(intervalMs: number): Promise<void> {
    setInterval(async () => {
      if (this.isPolling) return;
      this.isPolling = true;
      try {
        await this.pollAndDispatch();
      } catch (error) {
        console.error('Error during outbox polling execution:', error);
      } finally {
        this.isPolling = false;
      }
    }, intervalMs);
  }

  private async pollAndDispatch(): Promise<void> {
    // TODO: Implement transaction opening, SELECT ... FOR UPDATE SKIP LOCKED query,
    // iteration over fetched events, calling this.eventBus.publish() with proper awaits,
    // and updating the outbox record status to 'PUBLISHED' or incrementing retryCount.
    throw new Error('Not implemented');
  }
}
