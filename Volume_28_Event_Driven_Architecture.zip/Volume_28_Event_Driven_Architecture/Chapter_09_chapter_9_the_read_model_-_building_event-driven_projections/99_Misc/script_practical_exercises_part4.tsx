/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// 1. Define Read Model DTO
export interface OrderSummaryDto {
  orderId: string;
  customerId: string;
  status: 'PENDING' | 'PAID' | 'SHIPPED' | 'CANCELLED';
  totalAmount: number;
  itemCount: number;
  updatedAt: string;
}

// 2. Custom Hook for Initial Fetch + Real-time WebSocket Sync
export function useOrderStream(customerId: string) {
  const [orders, setOrders] = useState<OrderSummaryDto[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // TODO: Implement asynchronous initial fetch from REST endpoint (/api/customers/:id/orders)
  // TODO: Implement WebSocket connection setup to listen for live projection updates
  // TODO: Ensure proper cleanup (socket.close(), cancel pending promises) on unmount

  return { orders, loading, error };
}

// 3. React Component Implementation
export interface CustomerOrderDashboardProps {
  customerId: string;
}

export const CustomerOrderDashboard: React.FC<CustomerOrderDashboardProps> = ({ customerId }) => {
  const { orders, loading, error } = useOrderStream(customerId);

  if (loading) {
    return <div data-testid="loading-state">Loading order summaries from read model...</div>;
  }

  if (error) {
    return <div data-testid="error-state" className="text-red-500">Error: {error}</div>;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Customer Order Dashboard (CQRS Read View)</h1>
      {/* TODO: Render table or cards mapping over `orders` array with strict type checking */}
    </div>
  );
};
