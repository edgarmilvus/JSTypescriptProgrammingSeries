/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Enterprise Event-Sourced Aggregate with Snapshotting & Hydration
 * @description Demonstrates the core pattern of reducing hydration overhead via snapshots
 * in an enterprise SaaS billing context.
 */

// ==========================================
// 1. DOMAIN EVENTS & BASE INTERFACES
// ==========================================

/**
 * Base interface for all domain events in the system.
 */
interface DomainEvent {
    readonly aggregateId: string;
    readonly eventType: string;
    readonly version: number;
    readonly occurredAt: Date;
}

/**
 * Event emitted when a subscription is initially created.
 */
class SubscriptionCreatedEvent implements DomainEvent {
    readonly eventType = 'SubscriptionCreated';
    readonly occurredAt: Date = new Date();

    constructor(
        public readonly aggregateId: string,
        public readonly version: number,
        public readonly planName: string,
        public readonly seatCount: number
    ) {}
}

/**
 * Event emitted when seats are added to an existing subscription.
 */
class SeatsAddedEvent implements DomainEvent {
    readonly eventType = 'SeatsAdded';
    readonly occurredAt: Date = new Date();

    constructor(
        public readonly aggregateId: string,
        public readonly version: number,
        public readonly additionalSeats: number
    ) {}
}

// ==========================================
// 2. SNAPSHOT DEFINITION
// ==========================================

/**
 * Represents a frozen state of an aggregate at a specific version.
 */
interface Snapshot<TState> {
    readonly aggregateId: string;
    readonly version: number;
    readonly state: TState;
    readonly timestamp: Date;
}

// ==========================================
// 3. AGGREGATE STATE & ROOT
// ==========================================

/**
 * The internal data structure representing the state of a SaaS Subscription.
 */
interface SubscriptionState {
    planName: string;
    seatCount: number;
    isActive: boolean;
}

/**
 * Event-sourced aggregate root managing subscription business logic.
 */
class SubscriptionAggregate {
    private id: string;
    private version: number = 0;
    private uncommittedEvents: DomainEvent[] = [];
    
    // Aggregate internal state
    private state: SubscriptionState = {
        planName: '',
        seatCount: 0,
        isActive: false
    };

    /**
     * Private constructor. Use factory methods or hydration to instantiate.
     */
    private constructor(id: string) {
        this.id = id;
    }

    /**
     * Factory method to create a brand new subscription.
     */
    public static create(id: string, planName: string, initialSeats: number): SubscriptionAggregate {
        const aggregate = new SubscriptionAggregate(id);
        const event = new SubscriptionCreatedEvent(id, 1, planName, initialSeats);
        aggregate.applyChange(event);
        return aggregate;
    }

    /**
     * Business method to add seats to the subscription.
     */
    public addSeats(count: number): void {
        if (count <= 0) {
            throw new Error('Must add a positive number of seats.');
        }
        if (!this.state.isActive) {
            throw new Error('Cannot modify an inactive subscription.');
        }
        
        const nextVersion = this.version + 1;
        const event = new SeatsAddedEvent(this.id, nextVersion, count);
        this.applyChange(event);
    }

    /**
     * Applies an event to the aggregate state and tracks it as uncommitted.
     */
    private applyChange(event: DomainEvent): void {
        this.mutateState(event);
        this.version = event.version;
        this.uncommittedEvents.push(event);
    }

    /**
     * Pure state transition function based on incoming events.
     */
    public mutateState(event: DomainEvent): void {
        switch (event.eventType) {
            case 'SubscriptionCreated': {
                const casted = event as SubscriptionCreatedEvent;
                this.state.planName = casted.planName;
                this.state.seatCount = casted.seatCount;
                this.state.isActive = true;
                break;
            }
            case 'SeatsAdded': {
                const casted = event as SeatsAddedEvent;
                this.state.seatCount += casted.additionalSeats;
                break;
            }
            default:
                throw new Error(`Unhandled event type: ${(event as DomainEvent).eventType}`);
        }
        this.version = event.version;
    }

    /**
     * Reconstitutes an aggregate directly from a snapshot.
     */
    public static restoreFromSnapshot(snapshot: Snapshot<SubscriptionState>): SubscriptionAggregate {
        const aggregate = new SubscriptionAggregate(snapshot.aggregateId);
        aggregate.version = snapshot.version;
        // Deep copy state to prevent mutation leaks
        aggregate.state = { ...snapshot.state };
        return aggregate;
    }

    /**
     * Creates a snapshot of the current state.
     */
    public createSnapshot(): Snapshot<SubscriptionState> {
        return {
            aggregateId: this.id,
            version: this.version,
            state: { ...this.state },
            timestamp: new Date()
        };
    }

    // Accessors for verification
    public getVersion(): number { return this.version; }
    public getState(): SubscriptionState { return { ...this.state }; }
    public getUncommittedEvents(): DomainEvent[] { return [...this.uncommittedEvents]; }
    public clearUncommittedEvents(): void { this.uncommittedEvents = []; }
    public getId(): string { return this.id; }
}

// ==========================================
// 4. STORAGE & INFRASTRUCTURE SIMULATION
// ==========================================

/**
 * In-memory Event Store simulating a append-only database (e.g., EventStoreDB, PostgreSQL).
 */
class InMemoryEventStore {
    private storage: Map<string, DomainEvent[]> = new Map();

    public async saveEvents(aggregateId: string, events: DomainEvent[]): Promise<void> {
        const existing = this.storage.get(aggregateId) || [];
        this.storage.set(aggregateId, [...existing, ...events]);
    }

    public async getEventsForAggregate(aggregateId: string, fromVersion: number = 0): Promise<DomainEvent[]> {
        const events = this.storage.get(aggregateId) || [];
        return events.filter(e => e.version > fromVersion);
    }
}

/**
 * In-memory Snapshot Store simulating a document or key-value store (e.g., Redis, MongoDB).
 */
class InMemorySnapshotStore {
    private snapshots: Map<string, Snapshot<SubscriptionState>> = new Map();

    public async saveSnapshot(snapshot: Snapshot<SubscriptionState>): Promise<void> {
        // Store the latest snapshot per aggregate ID
        this.snapshots.set(snapshot.aggregateId, snapshot);
    }

    public async getLatestSnapshot(aggregateId: string): Promise<Snapshot<SubscriptionState> | null> {
        return this.snapshots.get(aggregateId) || null;
    }
}

// ==========================================
// 5. REPOSITORY WITH HYDRATION & SNAPSHOTTING
// ==========================================

/**
 * Repository orchestrating snapshot checks, event replaying, and persistence.
 */
class SubscriptionRepository {
    private snapshotFrequency: number = 3; // Snapshot every 3 events for demo purposes

    constructor(
        private eventStore: InMemoryEventStore,
        private snapshotStore: InMemorySnapshotStore
    ) {}

    /**
     * Loads an aggregate by combining snapshot retrieval and delta event replaying.
     */
    public async getById(aggregateId: string): Promise<SubscriptionAggregate> {
        // 1. Attempt to fetch the latest snapshot
        const latestSnapshot = await this.snapshotStore.getLatestSnapshot(aggregateId);
        
        let aggregate: SubscriptionAggregate;
        let fromVersion = 0;

        if (latestSnapshot) {
            // Hydrate directly from snapshot
            aggregate = SubscriptionAggregate.restoreFromSnapshot(latestSnapshot);
            fromVersion = latestSnapshot.version;
            console.log(`[Repository] Hydrated aggregate ${aggregateId} from snapshot at version ${fromVersion}`);
        } else {
            // Fallback: instantiate empty aggregate
            // In a complete implementation, we'd check if any events exist first
            aggregate = SubscriptionAggregate.restoreFromSnapshot({
                aggregateId,
                version: 0,
                state: { planName: '', seatCount: 0, isActive: false },
                timestamp: new Date()
            });
            console.log(`[Repository] No snapshot found for ${aggregateId}. Replaying from genesis.`);
        }

        // 2. Fetch delta events that occurred *after* the snapshot version
        const deltaEvents = await this.eventStore.getEventsForAggregate(aggregateId, fromVersion);

        // 3. Replay delta events
        for (const event of deltaEvents) {
            aggregate.mutateState(event);
        }

        if (deltaEvents.length > 0) {
            console.log(`[Repository] Replayed ${deltaEvents.length} delta events for aggregate ${aggregateId}`);
        }

        return aggregate;
    }

    /**
     * Saves an aggregate, committing uncommitted events and conditionally creating a snapshot.
     */
    public async save(aggregate: SubscriptionAggregate): Promise<void> {
        const events = aggregate.getUncommittedEvents();
        if (events.length === 0) return;

        // 1. Append new events to the event store
        await this.eventStore.saveEvents(aggregate.getId(), events);
        aggregate.clearUncommittedEvents();

        // 2. Check if a new snapshot should be created based on frequency threshold
        const currentVersion = aggregate.getVersion();
        if (currentVersion % this.snapshotFrequency === 0) {
            const snapshot = aggregate.createSnapshot();
            await this.snapshotStore.saveSnapshot(snapshot);
            console.log(`[Repository] Snapshot created & stored for aggregate ${aggregate.getId()} at version ${currentVersion}`);
        }
    }
}

// ==========================================
// 6. EXECUTION & VERIFICATION SCRIPT
// ==========================================

async function runDemo() {
    console.log('--- STARTING EVENT SOURCING SNAPSHOT DEMO ---\n');

    const eventStore = new InMemoryEventStore();
    const snapshotStore = new InMemorySnapshotStore();
    const repository = new SubscriptionRepository(eventStore, snapshotStore);

    const aggregateId = 'sub_enterprise_999';

    // Step 1: Create a new aggregate and save it (Version 1)
    console.log('--- Step 1: Creating Subscription ---');
    const sub = SubscriptionAggregate.create(aggregateId, 'Enterprise Tier', 10);
    await repository.save(sub); // Version 1 (Snapshot threshold not met yet if freq=3)

    // Step 2: Add seats multiple times to trigger snapshot creation
    console.log('\n--- Step 2: Modifying Subscription (Triggering Snapshot) ---');
    let loadedSub = await repository.getById(aggregateId);
    loadedSub.addSeats(5); // Version 2
    await repository.save(loadedSub);

    loadedSub = await repository.getById(aggregateId);
    loadedSub.addSeats(5); // Version 3 -> Hits threshold (3 % 3 === 0)
    await repository.save(loadedSub);

    // Step 3: Add more seats past the snapshot threshold
    console.log('\n--- Step 3: Adding Delta Events Past Snapshot ---');
    loadedSub = await repository.getById(aggregateId);
    loadedSub.addSeats(10); // Version 4
    await repository.save(loadedSub);

    loadedSub = await repository.getById(aggregateId);
    loadedSub.addSeats(10); // Version 5
    await repository.save(loadedSub);

    // Step 4: Final Hydration test
    console.log('\n--- Step 4: Final Hydration Test (Should load snapshot v3 + 2 delta events) ---');
    const finalSub = await repository.getById(aggregateId);
    console.log('Final Aggregate State:', finalSub.getState());
    console.log('Final Aggregate Version:', finalSub.getVersion());
}

// Execute the simulation
runDemo();
