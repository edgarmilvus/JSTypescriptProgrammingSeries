/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file Enterprise Production-Grade Event Sourced Repository with OCC & Upcasting
 */

interface Metadata {
    readonly correlationId: string;
    readonly causationId: string;
    readonly userId: string;
}

interface Envelope<T extends DomainEvent> {
    readonly eventId: string;
    readonly payload: T;
    readonly metadata: Metadata;
    readonly schemaVersion: number;
}

class OptimisticConcurrencyError extends Error {
    constructor(aggregateId: string, expectedVersion: number, actualVersion: number) {
        super(`Concurrency conflict on aggregate ${aggregateId}: Expected version ${expectedVersion}, but found ${actualVersion}.`);
        this.name = 'OptimisticConcurrencyError';
    }
}

/**
 * Enterprise Event Store supporting Optimistic Concurrency Control (OCC).
 */
class EnterpriseEventStore {
    private eventStream: Map<string, Envelope<DomainEvent>[]> = new Map();

    /**
     * Appends events atomically with optimistic concurrency verification.
     */
    public async appendEvents(
        aggregateId: string, 
        expectedVersion: number, 
        events: DomainEvent[], 
        metadata: Metadata
    ): Promise<void> {
        const existingEnvelopes = this.eventStream.get(aggregateId) || [];
        const currentVersion = existingEnvelopes.length > 0 
            ? existingEnvelopes[existingEnvelopes.length - 1].payload.version 
            : 0;

        if (currentVersion !== expectedVersion) {
            throw new OptimisticConcurrencyError(aggregateId, expectedVersion, currentVersion);
        }

        const newEnvelopes: Envelope<DomainEvent>[] = events.map((event, index) => ({
            eventId: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            payload: event,
            metadata,
            schemaVersion: 1
        }));

        this.eventStream.set(aggregateId, [...existingEnvelopes, ...newEnvelopes]);
    }

    public async getStream(aggregateId: string, fromVersion: number = 0): Promise<DomainEvent[]> {
        const envelopes = this.eventStream.get(aggregateId) || [];
        return envelopes
            .map(env => this.upcast(env))
            .filter(event => event.version > fromVersion);
    }

    /**
     * Upcasting engine to handle schema evolution of historical events.
     */
    private upcast(envelope: Envelope<DomainEvent>): DomainEvent {
        let event = envelope.payload;
        if (envelope.schemaVersion === 1) {
            // Example schema migration: v1 to v2 conversion
            if (event.eventType === 'SubscriptionCreated') {
                // Apply structural migrations if event schema evolved over time
            }
        }
        return event;
    }
}

/**
 * Asynchronous Snapshot Worker using an event-driven worker queue.
 */
class AsyncSnapshotWorker {
    constructor(
        private snapshotStore: InMemorySnapshotStore,
        private eventStore: EnterpriseEventStore
    ) {}

    /**
     * Background worker routine triggered via message broker (e.g., Kafka, RabbitMQ).
     */
    public async handleSnapshotTrigger(aggregateId: string, currentVersion: number): Promise<void> {
        // Fetch full stream or reconstruct aggregate in memory safely
        console.log(`[Background Worker] Building asynchronous snapshot for ${aggregateId} at version ${currentVersion}`);
        
        // In a real system, this worker instantiates the aggregate, replays events, 
        // and writes the snapshot to Redis without blocking the user-facing command handler.
    }
}
