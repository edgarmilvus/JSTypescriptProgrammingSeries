/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createClient, RedisClientType } from 'redis';
import { Pool } from 'pg';

// ============================================================================
// DOMAIN TYPES & INTERFACES
// ============================================================================

export interface DomainEvent {
    eventId: string;
    aggregateId: string;
    eventType: string;
    eventVersion: number;
    payload: Record<string, any>;
    occurredAt: Date;
}

export interface BillingAggregate {
    aggregateId: string;
    version: number;
    balance: number;
    status: 'ACTIVE' | 'SUSPENDED' | 'CLOSED';
    lastEventId: string;
}

// ============================================================================
// INFRASTRUCTURE SETUP (PostgreSQL & Redis)
// ============================================================================

const pgPool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/billing_db',
});

const redisClient: RedisClientType = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
});

// ============================================================================
// AGGREGATE RECONSTRUCTION ENGINE WITH SNAPSHOTS
// ============================================================================

/**
 * Rebuilds the BillingAggregate using a Cache-Aside Snapshot strategy.
 * 1. Checks Redis for a serialized snapshot.
 * 2. If found, loads events strictly *after* the snapshot version.
 * 3. If not found, loads the entire event stream from PostgreSQL.
 * 4. Applies state transitions and conditionally triggers an async snapshot.
 */
export async function getBillingAggregate(aggregateId: string): Promise<BillingAggregate> {
    await ensureRedisConnected();

    const snapshotKey = `snapshot:billing:${aggregateId}`;
    let aggregate: BillingAggregate | null = null;
    let fromVersion = 0;

    // Step 1: Attempt to load the latest snapshot from Redis cache
    const cachedSnapshot = await redisClient.get(snapshotKey);
    
    if (cachedSnapshot) {
        const parsed: BillingAggregate = JSON.parse(cachedSnapshot);
        aggregate = parsed;
        fromVersion = parsed.version;
        console.log(`[Cache Hit] Snapshot loaded for aggregate ${aggregateId} at version ${fromVersion}`);
    } else {
        // Step 1b: Fallback to base state if no snapshot exists in cache
        aggregate = {
            aggregateId,
            version: 0,
            balance: 0,
            status: 'ACTIVE',
            lastEventId: '',
        };
        console.log(`[Cache Miss] Full stream replay required for aggregate ${aggregateId}`);
    }

    // Step 2: Fetch incremental events from PostgreSQL
    const query = `
        SELECT event_id, aggregate_id, event_type, event_version, payload, occurred_at
        FROM event_store
        WHERE aggregate_id = $1 AND event_version > $2
        ORDER BY event_version ASC;
    `;
    const { rows } = await pgPool.query(query, [aggregateId, fromVersion]);

    if (rows.length === 0 && !cachedSnapshot) {
        throw new Error(`Aggregate ${aggregateId} not found.`);
    }

    // Step 3: Replay events to project current state
    for (const row of rows) {
        const event: DomainEvent = {
            eventId: row.event_id,
            aggregateId: row.aggregate_id,
            eventType: row.event_type,
            eventVersion: row.event_version,
            payload: row.payload,
            occurredAt: row.occurred_at,
        };

        aggregate = applyEvent(aggregate, event);
    }

    // Step 4: Evaluate asynchronous snapshot criteria (e.g., every 50 new events)
    if (rows.length >= 50 || !cachedSnapshot) {
        await scheduleAsyncSnapshot(aggregate);
    }

    return aggregate;
}

/**
 * Pure state transition reducer function for the Billing Aggregate.
 */
function applyEvent(aggregate: BillingAggregate, event: DomainEvent): BillingAggregate {
    switch (event.eventType) {
        case 'InvoiceIssued':
            return {
                ...aggregate,
                version: event.eventVersion,
                balance: aggregate.balance + event.payload.amount,
                lastEventId: event.eventId,
            };
        case 'PaymentReceived':
            return {
                ...aggregate,
                version: event.eventVersion,
                balance: aggregate.balance - event.payload.amount,
                lastEventId: event.eventId,
            };
        case 'AccountSuspended':
            return {
                ...aggregate,
                version: event.eventVersion,
                status: 'SUSPENDED',
                lastEventId: event.eventId,
            };
        default:
            return {
                ...aggregate,
                version: event.eventVersion,
                lastEventId: event.eventId,
            };
    }
}

/**
 * Asynchronously persists a snapshot to Redis and archives state to persistent storage.
 */
async function scheduleAsyncSnapshot(aggregate: BillingAggregate): Promise<void> {
    const snapshotKey = `snapshot:billing:${aggregate.aggregateId}`;
    
    // Non-blocking write to Redis with a 24-hour TTL
    await redisClient.set(snapshotKey, JSON.stringify(aggregate), {
        EX: 86400, 
    });

    // Optionally persist snapshot to PostgreSQL snapshot table for durable auditing
    const query = `
        INSERT INTO snapshots (aggregate_id, version, state, updated_at)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (aggregate_id) 
        DO UPDATE SET version = EXCLUDED.version, state = EXCLUDED.state, updated_at = EXCLUDED.updated_at;
    `;
    await pgPool.query(query, [aggregate.aggregateId, aggregate.version, JSON.stringify(aggregate)]);
    
    console.log(`[Snapshot Created] Aggregate ${aggregate.aggregateId} snapshotted at version ${aggregate.version}`);
}

async function ensureRedisConnected(): Promise<void> {
    if (!redisClient.isOpen) {
        await redisClient.connect();
    }
}
