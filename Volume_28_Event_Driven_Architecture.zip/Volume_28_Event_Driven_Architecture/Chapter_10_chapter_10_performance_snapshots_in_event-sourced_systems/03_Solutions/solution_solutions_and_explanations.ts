/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface DomainEvent {
  aggregateId: string;
  sequenceNumber: number;
  eventType: string;
  timestamp: Date;
  payload: Record<string, any>;
}

export interface Snapshot<T> {
  aggregateId: string;
  sequenceNumber: number;
  state: T;
  timestamp: Date;
}

export interface IEventStore {
  saveEvents(aggregateId: string, events: DomainEvent[], expectedVersion: number): Promise<void>;
  getEvents(aggregateId: string, fromSequenceNumber?: number): Promise<DomainEvent[]>;
}

export interface ISnapshotStore {
  saveSnapshot<T>(snapshot: Snapshot<T>): Promise<void>;
  getSnapshot<T>(aggregateId: string): Promise<Snapshot<T> | null>;
}

export abstract class AggregateRoot {
  public id: string = '';
  public version: number = 0;
  protected uncommittedEvents: DomainEvent[] = [];

  abstract apply(event: DomainEvent): void;
  
  public getUncommittedEvents(): DomainEvent[] {
    return this.uncommittedEvents;
  }

  public markEventsAsCommitted(): void {
    this.uncommittedEvents = [];
  }
}

export class OptimizedAggregateRepository<T extends AggregateRoot> {
  constructor(
    private eventStore: IEventStore,
    private snapshotStore: ISnapshotStore,
    private aggregateFactory: (id: string) => T,
    private snapshotThreshold: number = 50
  ) {}

  public async load(aggregateId: string): Promise<T> {
    // 1. Fetch latest snapshot from snapshotStore
    const snapshot = await this.snapshotStore.getSnapshot<any>(aggregateId);
    
    // 2. Instantiate aggregate via factory
    const aggregate = this.aggregateFactory(aggregateId);
    
    let fromSequenceNumber = 0;

    if (snapshot) {
      // If snapshot exists, restore its base state and version
      Object.assign(aggregate, snapshot.state);
      aggregate.version = snapshot.sequenceNumber;
      fromSequenceNumber = snapshot.sequenceNumber + 1;
    }

    // 3. Fetch events occurring strictly after the snapshot sequence number
    const events = await this.eventStore.getEvents(aggregateId, fromSequenceNumber);

    // 4. Apply historical events sequentially to reconstruct current state
    for (const event of events) {
      aggregate.apply(event);
      aggregate.version = event.sequenceNumber;
    }

    return aggregate;
  }

  public async save(aggregate: T): Promise<void> {
    const uncommittedEvents = aggregate.getUncommittedEvents();
    if (uncommittedEvents.length === 0) return;

    // Calculate expected version prior to these uncommitted changes
    const expectedVersion = aggregate.version - uncommittedEvents.length;

    // 1. Persist uncommitted events with optimistic concurrency locking
    await this.eventStore.saveEvents(aggregate.id, uncommittedEvents, expectedVersion);

    // 2. Check if total events since last snapshot exceeds snapshotThreshold
    // We determine the last snapshot version or track delta events
    const snapshot = await this.snapshotStore.getSnapshot(aggregate.id);
    const lastSnapshotVersion = snapshot ? snapshot.sequenceNumber : 0;
    const eventsSinceLastSnapshot = aggregate.version - lastSnapshotVersion;

    if (eventsSinceLastSnapshot >= this.snapshotThreshold) {
      const newSnapshot: Snapshot<any> = {
        aggregateId: aggregate.id,
        sequenceNumber: aggregate.version,
        state: JSON.parse(JSON.stringify(aggregate)), // Deep clone state
        timestamp: new Date()
      };
      await this.snapshotStore.saveSnapshot(newSnapshot);
    }

    // 3. Mark events as committed on the aggregate
    aggregate.markEventsAsCommitted();
  }
}
