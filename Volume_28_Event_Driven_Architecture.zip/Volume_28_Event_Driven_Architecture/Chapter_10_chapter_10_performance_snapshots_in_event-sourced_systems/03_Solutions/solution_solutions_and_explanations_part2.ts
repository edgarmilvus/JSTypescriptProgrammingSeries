/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { AggregateRoot } from './Exercise1';

export interface ICacheTier<T> {
  get(key: string): Promise<T | null>;
  set(key: string, value: T, ttlSeconds: number): Promise<void>;
  invalidate(key: string): Promise<void>;
}

export class TwoTierCachedRepository<T extends AggregateRoot> {
  constructor(
    private underlyingRepository: { load(id: string): Promise<T>; save(agg: T): Promise<void> },
    private l1Cache: ICacheTier<T>,
    private l2Cache: ICacheTier<T>,
    private ttlSeconds: number = 300
  ) {}

  async load(id: string): Promise<T> {
    const cacheKey = `aggregate:${id}`;

    // 1. Check L1 cache (In-Memory LRU)
    let aggregateData = await this.l1Cache.get(cacheKey);
    if (aggregateData) {
      return aggregateData;
    }

    // 2. Check L2 cache (Redis)
    aggregateData = await this.l2Cache.get(cacheKey);
    if (aggregateData) {
      // Populate L1 cache for subsequent fast reads
      await this.l1Cache.set(cacheKey, aggregateData, this.ttlSeconds);
      return aggregateData;
    }

    // 3. On L1/L2 miss, fall back to underlying repository
    const aggregate = await this.underlyingRepository.load(id);

    // 4. Populate both L1 and L2 caches
    await Promise.all([
      this.l1Cache.set(cacheKey, aggregate, this.ttlSeconds),
      this.l2Cache.set(cacheKey, aggregate, this.ttlSeconds)
    ]);

    return aggregate;
  }

  async save(aggregate: T): Promise<void> {
    const cacheKey = `aggregate:${aggregate.id}`;

    // 1. Persist changes via underlying repository
    await this.underlyingRepository.save(aggregate);

    // 2. Invalidate both L1 and L2 caches to prevent stale reads across instances
    await Promise.all([
      this.l1Cache.invalidate(cacheKey),
      this.l2Cache.invalidate(cacheKey)
    ]);
  }
}
