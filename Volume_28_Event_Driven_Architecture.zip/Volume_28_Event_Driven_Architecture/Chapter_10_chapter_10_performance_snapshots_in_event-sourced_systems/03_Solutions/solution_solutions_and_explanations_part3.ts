/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { DomainEvent } from './Exercise1';

export interface VersionedEvent extends DomainEvent {
  version: number;
}

export interface IEventUpcaster {
  targetEventType: string;
  fromVersion: number;
  toVersion: number;
  upcast(event: VersionedEvent): VersionedEvent;
}

export class AddressV1ToV2Upcaster implements IEventUpcaster {
  targetEventType = 'ShippingAddressUpdated';
  fromVersion = 1;
  toVersion = 2;

  upcast(event: VersionedEvent): VersionedEvent {
    // Transform flat address properties into nested value object structure
    const { street, city, zip, ...rest } = event.payload;
    return {
      ...event,
      version: 2,
      payload: {
        ...rest,
        address: { street, city, zip }
      }
    };
  }
}

export class UpcastingPipeline {
  private upcasters: Map<string, IEventUpcaster[]> = new Map();

  public register(upcaster: IEventUpcaster): void {
    const list = this.upcasters.get(upcaster.targetEventType) || [];
    list.push(upcaster);
    this.upcasters.set(upcaster.targetEventType, list);
  }

  public upcastEvent(event: VersionedEvent): VersionedEvent {
    const applicableUpcasters = this.upcasters.get(event.eventType) || [];
    let currentEvent = { ...event };

    // Iteratively apply upcasters in sequential version order
    let upgraded = true;
    while (upgraded) {
      upgraded = false;
      for (const upcaster of applicableUpcasters) {
        if (currentEvent.version === upcaster.fromVersion) {
          currentEvent = upcaster.upcast(currentEvent);
          upgraded = true;
          break;
        }
      }
    }

    return currentEvent;
  }
}

export class EventCompactor {
  /**
   * Compacts an event stream by merging successive quantity adjustments
   * or discarding obsolete intermediate state transitions.
   */
  public static compact(events: DomainEvent[]): DomainEvent[] {
    const compactionMap = new Map<string, DomainEvent>();
    const compactedList: DomainEvent[] = [];

    for (const event of events) {
      if (event.eventType === 'CartItemQuantityAdjusted') {
        const itemId = event.payload.itemId;
        const key = `CartItemQuantityAdjusted:${itemId}`;
        
        if (compactionMap.has(key)) {
          // Collapse multiple intermediate quantity changes into a cumulative final event
          const existing = compactionMap.get(key)!;
          existing.payload.quantity = event.payload.quantity; // Last-write-wins or net sum
          existing.timestamp = event.timestamp;
        } else {
          const cloned = { ...event, payload: { ...event.payload } };
          compactionMap.set(key, cloned);
          compactedList.push(cloned);
        }
      } else {
        compactedList.push(event);
      }
    }

    return compactedList;
  }
}
