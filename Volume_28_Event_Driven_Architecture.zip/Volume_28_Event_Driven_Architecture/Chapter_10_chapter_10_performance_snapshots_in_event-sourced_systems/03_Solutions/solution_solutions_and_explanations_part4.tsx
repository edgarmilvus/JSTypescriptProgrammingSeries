/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface AggregateTelemetry {
  aggregateId: string;
  aggregateType: string;
  eventCountSinceLastSnapshot: number;
  lastSnapshotVersion: number;
  estimatedHydrationTimeMs: number;
}

export interface SnapshotDashboardProps {
  systemMetrics: {
    totalAggregates: number;
    totalSnapshots: number;
    cacheHitRatePercentage: number;
    avgHydrationTimeWithSnapshotMs: number;
    avgHydrationTimeWithoutSnapshotMs: number;
  };
  delinquentAggregates: AggregateTelemetry[];
  onTriggerSnapshot: (aggregateId: string) => Promise<void>;
  onRefreshMetrics: () => Promise<void>;
}

export const SnapshotDashboard: React.FC<SnapshotDashboardProps> = ({
  systemMetrics,
  delinquentAggregates,
  onTriggerSnapshot,
  onRefreshMetrics
}) => {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSnapshotClick = async (aggregateId: string) => {
    setLoadingId(aggregateId);
    setError(null);
    try {
      await onTriggerSnapshot(aggregateId);
      await onRefreshMetrics();
    } catch (err: any) {
      setError(err.message || 'Failed to trigger snapshot compaction.');
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-extrabold tracking-tight">Event Store & Snapshot Performance Dashboard</h1>
        <button
          onClick={onRefreshMetrics}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-400"
          aria-label="Refresh telemetry metrics"
        >
          Refresh Telemetry
        </button>
      </header>

      {error && (
        <div className="mb-6 p-4 bg-red-950 border border-red-700 text-red-200 rounded-lg" role="alert">
          <span>Error: {error}</span>
        </div>
      )}

      {/* Metric Cards Grid */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10" aria-label="System telemetry overview">
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700">
          <p className="text-sm font-medium text-slate-400">Total Aggregates</p>
          <p className="text-3xl font-bold mt-2 text-indigo-400">{systemMetrics.totalAggregates.toLocaleString()}</p>
        </div>
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700">
          <p className="text-sm font-medium text-slate-400">Total Snapshots</p>
          <p className="text-3xl font-bold mt-2 text-emerald-400">{systemMetrics.totalSnapshots.toLocaleString()}</p>
        </div>
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700">
          <p className="text-sm font-medium text-slate-400">Cache Hit Rate</p>
          <p className="text-3xl font-bold mt-2 text-cyan-400">{systemMetrics.cacheHitRatePercentage}%</p>
        </div>
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700">
          <p className="text-sm font-medium text-slate-400">Hydration Speedup</p>
          <p className="text-xl font-semibold mt-2 text-amber-400">
            {systemMetrics.avgHydrationTimeWithSnapshotMs}ms <span className="text-xs text-slate-400">vs {systemMetrics.avgHydrationTimeWithoutSnapshotMs}ms</span>
          </p>
        </div>
      </section>

      {/* Delinquent Aggregates Table */}
      <section className="bg-slate-800 rounded-xl p-6 shadow-inner border border-slate-700">
        <h2 className="text-xl font-bold mb-4">Aggregates Requiring Snapshot Compaction</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-700 text-slate-400">
                <th className="py-3 px-4">Aggregate ID</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Unsnapshot Events</th>
                <th className="py-3 px-4">Est. Hydration Time</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {delinquentAggregates.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-slate-500">All aggregates are fully snapshotted. No action required.</td>
                </tr>
              ) : (
                delinquentAggregates.map((item) => (
                  <tr key={item.aggregateId} className="border-b border-slate-700/50 hover:bg-slate-750">
                    <td className="py-3 px-4 font-mono text-sm text-indigo-300">{item.aggregateId}</td>
                    <td className="py-3 px-4">{item.aggregateType}</td>
                    <td className="py-3 px-4 text-amber-400 font-semibold">{item.eventCountSinceLastSnapshot}</td>
                    <td className="py-3 px-4">{item.estimatedHydrationTimeMs} ms</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleSnapshotClick(item.aggregateId)}
                        disabled={loadingId === item.aggregateId}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-600 text-white text-sm font-medium rounded transition-colors focus:ring-2 focus:ring-emerald-400"
                        aria-label={`Trigger snapshot for aggregate ${item.aggregateId}`}
                      >
                        {loadingId === item.aggregateId ? 'Compacting...' : 'Trigger Snapshot'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
