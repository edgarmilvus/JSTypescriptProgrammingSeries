/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { PoolClient } from 'pg';
import { DomainEvent } from './Exercise1';

/**
 * SQL DDL Reference for Exercise 5:
 * 
 * CREATE TABLE event_store (
 *   aggregate_id VARCHAR(255) NOT NULL,
 *   sequence_number INT NOT NULL,
 *   event_type VARCHAR(255) NOT NULL,
 *   payload JSONB NOT NULL,
 *   timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
 *   PRIMARY KEY (aggregate_id, sequence_number)
 * );
 * 
 * CREATE TABLE snapshot_store (
 *   aggregate_id VARCHAR(255) PRIMARY KEY,
 *   sequence_number INT NOT NULL,
 *   state JSONB NOT NULL,
 *   timestamp TIMESTAMP WITH TIME ZONE NOT NULL
 * );
 * 
 * -- Specialized partial index to optimize querying un-snapshotted events or sorting by aggregate timeline
 * CREATE INDEX idx_event_store_hydration ON event_store (aggregate_id, sequence_number ASC);
 */

export async function appendEventsBatch(
  client: PoolClient,
  aggregateId: string,
  events: DomainEvent[],
  expectedVersion: number
): Promise<void> {
  if (events.length === 0) return;

  try {
    // 1. Begin transaction (caller may pass a client already in a transaction, or we run inside BEGIN/COMMIT)
    await client.query('BEGIN');

    // 2. Query current maximum sequence number with row-level locking (SELECT ... FOR UPDATE)
    const versionQuery = `
      SELECT MAX(sequence_number) as current_version 
      FROM event_store 
      WHERE aggregate_id = $1 
      FOR UPDATE
    `;
    const result = await client.query(versionQuery, [aggregateId]);
    const currentVersion = result.rows[0]?.current_version ?? 0;

    // 3. Verify optimistic concurrency control
    if (currentVersion !== expectedVersion) {
      throw new Error(`Concurrency Conflict: Expected version ${expectedVersion}, but found current version ${currentVersion} for aggregate ${aggregateId}`);
    }

    // 4. Perform bulk insert of all events in the batch using parameterized multi-row insertion
    const insertQuery = `
      INSERT INTO event_store (aggregate_id, sequence_number, event_type, payload, timestamp)
      VALUES 
    `;

    const values: any[] = [];
    const placeholders: string[] = [];
    let paramIndex = 1;

    for (const event of events) {
      placeholders.push(`($${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++})`);
      values.push(
        event.aggregateId,
        event.sequenceNumber,
        event.eventType,
        JSON.stringify(event.payload),
        event.timestamp
      );
    }

    const finalQuery = insertQuery + placeholders.join(', ');
    await client.query(finalQuery, values);

    // 5. Commit transaction on success
    await client.query('COMMIT');
  } catch (error) {
    // Rollback transaction on concurrency violation or database error
    await client.query('ROLLBACK');
    throw error;
  }
}
