/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Exercise 1: Starter Code

export interface DomainEvent {
  aggregateId: string;
  sequenceNumber: number;
  eventType: string;
  timestamp: Date;
  payload: Record<string, any>;
}

export interface Snapshot<T> {
  aggregateId: string;
  sequenceNumber: number;
  state: T;
  timestamp: Date;
}

export interface IEventStore {
  saveEvents(aggregateId: string, events: DomainEvent[], expectedVersion: number): Promise<void>;
  getEvents(aggregateId: string, fromSequenceNumber?: number): Promise<DomainEvent[]>;
}

export interface ISnapshotStore {
  saveSnapshot<T>(snapshot: Snapshot<T>): Promise<void>;
  getSnapshot<T>(aggregateId: string): Promise<Snapshot<T> | null>;
}

export abstract class AggregateRoot {
  public id: string = '';
  public version: number = 0;
  protected uncommittedEvents: DomainEvent[] = [];

  abstract apply(event: DomainEvent): void;
  
  public getUncommittedEvents(): DomainEvent[] {
    return this.uncommittedEvents;
  }

  public markEventsAsCommitted(): void {
    this.uncommittedEvents = [];
  }
}

export class OptimizedAggregateRepository<T extends AggregateRoot> {
  constructor(
    private eventStore: IEventStore,
    private snapshotStore: ISnapshotStore,
    private aggregateFactory: (id: string) => T,
    private snapshotThreshold: number = 50
  ) {}

  public async load(aggregateId: string): Promise<T> {
    // TODO: Implement snapshot-aware hydration
    // 1. Fetch latest snapshot from snapshotStore
    // 2. Determine starting sequence number (0 if no snapshot, snapshot.sequenceNumber + 1 otherwise)
    // 3. Fetch events from eventStore starting from the calculated sequence number
    // 4. Instantiate aggregate (via factory or restore from snapshot state)
    // 5. Apply historical events sequentially
    // 6. Return fully hydrated aggregate instance
    throw new Error('Not implemented');
  }

  public async save(aggregate: T): Promise<void> {
    // TODO: Implement optimized save workflow
    // 1. Extract uncommitted events from aggregate
    // 2. Persist events to eventStore with optimistic locking (expectedVersion = aggregate.version - uncommittedEvents.length)
    // 3. Check if total events since last snapshot exceeds snapshotThreshold
    // 4. If threshold is met, serialize aggregate state and save a new snapshot
    // 5. Mark events as committed on the aggregate
    throw new Error('Not implemented');
  }
}
