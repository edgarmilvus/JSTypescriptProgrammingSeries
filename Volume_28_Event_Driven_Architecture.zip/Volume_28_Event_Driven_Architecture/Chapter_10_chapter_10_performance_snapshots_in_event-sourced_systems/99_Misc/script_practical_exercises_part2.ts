/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Exercise 2: Starter Code

import { AggregateRoot } from './Exercise1';

export interface ICacheTier<T> {
  get(key: string): Promise<T | null>;
  set(key: string, value: T, ttlSeconds: number): Promise<void>;
  invalidate(key: string): Promise<void>;
}

export class InMemoryLRUCache<T> implements ICacheTier<T> {
  private cache = new Map<string, { value: T; expiresAt: number }>();
  constructor(private maxSize: number = 1000) {}

  async get(key: string): Promise<T | null> {
    const item = this.cache.get(key);
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    return item.value;
  }

  async set(key: string, value: T, ttlSeconds: number): Promise<void> {
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey !== undefined) {
        this.cache.delete(firstKey);
      }
    }
    this.cache.set(key, {
      value,
      expiresAt: Date.now() + ttlSeconds * 1000
    });
  }

  async invalidate(key: string): Promise<void> {
    this.cache.delete(key);
  }
}

export class RedisCacheTier<T> implements ICacheTier<T> {
  // Mock representation of a Redis client connection
  constructor(private redisClient: { get(k: string): Promise<string | null>; setex(k: string, ttl: number, v: string): Promise<void>; del(k: string): Promise<void> }) {}

  async get(key: string): Promise<T | null> {
    const raw = await this.redisClient.get(key);
    return raw ? JSON.parse(raw) : null;
  }

  async set(key: string, value: T, ttlSeconds: number): Promise<void> {
    await this.redisClient.setex(key, ttlSeconds, JSON.stringify(value));
  }

  async invalidate(key: string): Promise<void> {
    await this.redisClient.del(key);
  }
}

export class TwoTierCachedRepository<T extends AggregateRoot> {
  constructor(
    private underlyingRepository: { load(id: string): Promise<T>; save(agg: T): Promise<void> },
    private l1Cache: ICacheTier<T>,
    private l2Cache: ICacheTier<T>,
    private ttlSeconds: number = 300
  ) {}

  async load(id: string): Promise<T> {
    // TODO: Implement two-tier cache read logic
    // 1. Check L1 cache. If hit, return aggregate.
    // 2. Check L2 cache. If hit, populate L1 cache and return aggregate.
    // 3. On L1/L2 miss, call underlyingRepository.load(id).
    // 4. Populate both L1 and L2 caches with the loaded aggregate.
    // 5. Return aggregate.
    throw new Error('Not implemented');
  }

  async save(aggregate: T): Promise<void> {
    // TODO: Implement write-through / invalidation logic
    // 1. Call underlyingRepository.save(aggregate).
    // 2. Invalidate L1 and L2 caches for aggregate.id to prevent stale reads.
    throw new Error('Not implemented');
  }
}
