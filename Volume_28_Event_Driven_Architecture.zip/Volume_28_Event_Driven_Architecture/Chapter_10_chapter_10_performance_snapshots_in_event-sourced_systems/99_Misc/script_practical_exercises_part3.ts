/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Exercise 3: Starter Code

import { DomainEvent } from './Exercise1';

export interface VersionedEvent extends DomainEvent {
  version: number;
}

export interface IEventUpcaster {
  targetEventType: string;
  fromVersion: number;
  toVersion: number;
  upcast(event: VersionedEvent): VersionedEvent;
}

export class AddressV1ToV2Upcaster implements IEventUpcaster {
  targetEventType = 'ShippingAddressUpdated';
  fromVersion = 1;
  toVersion = 2;

  upcast(event: VersionedEvent): VersionedEvent {
    // TODO: Transform flat address fields (street, city, zip) into nested payload { address: { street, city, zip } }
    // Increment event.version to 2
    throw new Error('Not implemented');
  }
}

export class UpcastingPipeline {
  private upcasters: Map<string, IEventUpcaster[]> = new Map();

  public register(upcaster: IEventUpcaster): void {
    const list = this.upcasters.get(upcaster.targetEventType) || [];
    list.push(upcaster);
    this.upcasters.set(upcaster.targetEventType, list);
  }

  public upcastEvent(event: VersionedEvent): VersionedEvent {
    // TODO: Find all applicable upcasters for event.eventType
    // Sort/chain them sequentially from event.version up to the latest schema version
    // Return the fully upcasted event
    throw new Error('Not implemented');
  }
}

export class EventCompactor {
  /**
   * Compacts a stream of events by merging consecutive similar events 
   * or removing superseded intermediate state mutations.
   */
  public static compact(events: DomainEvent[]): DomainEvent[] {
    // TODO: Implement compaction algorithm
    // Example: If an aggregate has 10 'CartItemQuantityAdjusted' events for the same itemId,
    // consolidate them into a single event reflecting the final net quantity adjustment.
    throw new Error('Not implemented');
  }
}
