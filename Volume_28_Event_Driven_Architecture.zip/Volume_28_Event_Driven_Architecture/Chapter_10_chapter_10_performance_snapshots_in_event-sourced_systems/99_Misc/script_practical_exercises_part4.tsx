/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Exercise 4: Starter Code

import React, { useState } from 'react';

export interface AggregateTelemetry {
  aggregateId: string;
  aggregateType: string;
  eventCountSinceLastSnapshot: number;
  lastSnapshotVersion: number;
  estimatedHydrationTimeMs: number;
}

export interface SnapshotDashboardProps {
  systemMetrics: {
    totalAggregates: number;
    totalSnapshots: number;
    cacheHitRatePercentage: number;
    avgHydrationTimeWithSnapshotMs: number;
    avgHydrationTimeWithoutSnapshotMs: number;
  };
  delinquentAggregates: AggregateTelemetry[];
  onTriggerSnapshot: (aggregateId: string) => Promise<void>;
  onRefreshMetrics: () => Promise<void>;
}

export const SnapshotDashboard: React.FC<SnapshotDashboardProps> = ({
  systemMetrics,
  delinquentAggregates,
  onTriggerSnapshot,
  onRefreshMetrics
}) => {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSnapshotClick = async (aggregateId: string) => {
    // TODO: Implement snapshot trigger handler
    // Set loading state for specific aggregateId
    // Call onTriggerSnapshot(aggregateId) inside try/catch
    // Refresh metrics on success, catch errors and set error state
    throw new Error('Not implemented');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-extrabold tracking-tight">Event Store & Snapshot Performance Dashboard</h1>
        <button
          onClick={onRefreshMetrics}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg transition-colors"
        >
          Refresh Telemetry
        </button>
      </header>

      {error && (
        <div className="mb-6 p-4 bg-red-950 border border-red-700 text-red-200 rounded-lg" role="alert">
          <span>Error: {error}</span>
        </div>
      )}

      {/* TODO: Render Metric Cards Grid (Total Aggregates, Snapshots, Cache Hit Rate, Hydration Latency comparison) */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
        {/* Metric Card 1: Total Aggregates */}
        {/* Metric Card 2: Total Snapshots */}
        {/* Metric Card 3: Cache Hit Rate */}
        {/* Metric Card 4: Avg Hydration Latency */}
      </section>

      {/* TODO: Render Delinquent Aggregates Table exceeding snapshot thresholds */}
      <section className="bg-slate-800 rounded-xl p-6 shadow-inner">
        <h2 className="text-xl font-bold mb-4">Aggregates Requiring Snapshot Compaction</h2>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-700 text-slate-400">
              <th className="py-3 px-4">Aggregate ID</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Unsnapshot Events</th>
              <th className="py-3 px-4">Est. Hydration Time</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {/* Map delinquentAggregates here */}
          </tbody>
        </table>
      </section>
    </div>
  );
};
