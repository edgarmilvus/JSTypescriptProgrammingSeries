/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
digraph SPA_Broker_Analogy {
    node [shape=box, style="rounded,filled", fillcolor="#f0f4f8", fontname="Arial", fontsize=12];
    
    subgraph cluster_spa {
        label = "Web Development Analogy: SPA State Management";
        style=dashed;
        color=gray;
        
        UI [label="UI Component"];
        Action [label="Dispatcher / Action"];
        Store [label="Immutable State Store\n(Redux / Event Sourced)"];
        Subscriber [label="React Subscriptions"];
        
        UI -> Action [label="Dispatch Intent"];
        Action -> Store [label="State Mutation"];
        Store -> Subscriber [label="Render Updates"];
    }

    subgraph cluster_eda {
        label = "Event-Driven Architecture: Event Broker";
        style=dashed;
        color=gray;
        
        Producer [label="Microservice Producer"];
        Broker [label="Event Broker\n(Kafka / RabbitMQ / NATS)"];
        Consumer [label="Microservice Consumer"];
        
        Producer -> Broker [label="Publish Domain Event"];
        Broker -> Consumer [label="Deliver Message Stream"];
    }
}
