/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
digraph Broker_Comparison {
    node [shape=box, style="rounded,filled", fillcolor="#eef2f7", fontname="Arial", fontsize=11];

    Root [label="Event Broker Selection Matrix", fillcolor="#d0e1fd", style="rounded,filled"];
    
    Kafka [label="Apache Kafka\n(Log-Centric / High Throughput\n/ Replayability)"];
    RabbitMQ [label="RabbitMQ\n(Smart Broker / Complex Routing\n/ Task Queues)"];
    NATS [label="NATS / JetStream\n(Ultra-Low Latency / Edge / Lightweight)"];

    Root -> Kafka [label="Event Sourced / Analytics\n/ Massive Scale"];
    Root -> RabbitMQ [label="Complex AMQP Routing\n/ Work Queues / DLQ Needs"];
    Root -> NATS [label="Real-Time Signaling\n/ IoT / Edge / Minimal Ops"];

    subgraph cluster_kafka_props {
        label = "Kafka Characteristics";
        style=dotted;
        K1 [label="Dumb Broker / Smart Consumer"];
        K2 [label="Disk-backed Append Log"];
        K3 [label="High Operational Complexity"];
    }
    Kafka -> K1; Kafka -> K2; Kafka -> K3;

    subgraph cluster_rmq_props {
        label = "RabbitMQ Characteristics";
        style=dotted;
        R1 [label="Smart Broker / Dumb Consumer"];
        R2 [label="Exchange-to-Queue Routing"];
        R3 [label="Mature Enterprise Features"];
    }
    RabbitMQ -> R1; RabbitMQ -> R2; RabbitMQ -> R3;

    subgraph cluster_nats_props {
        label = "NATS Characteristics";
        style=dotted;
        N1 [label="Blazing Fast Go Runtime"];
        N2 [label="Hierarchical Subjects"];
        N3 [label="Optional JetStream Persistence"];
    }
    NATS -> N1; NATS -> N2; NATS -> N3;
}
