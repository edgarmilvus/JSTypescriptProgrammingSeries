/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
digraph Decision_Framework {
    node [shape=box, style="rounded,filled", fillcolor="#fff2cc", fontname="Arial", fontsize=11];

    Start [label="Start Architecture Evaluation", fillcolor="#f8cecc", style="rounded,filled"];
    
    Q1 [label="Is Event Sourcing / Replayability\na core architectural requirement?"];
    Q2 [label="Do you need complex content-based routing\n& robust Dead-Letter Queues?"];
    Q3 [label="Is ultra-low latency & minimal\noperational overhead paramount?"];

    AnsKafka [label="Select Apache Kafka\n(Immutable Log / CQRS Read Model Rebuilds)", fillcolor="#d5e8d4"];
    AnsRMQ [label="Select RabbitMQ\n(AMQP Exchanges / Work Queues / Enterprise Routing)", fillcolor="#d5e8d4"];
    AnsNATS [label="Select NATS JetStream\n(High-Speed Signaling / Edge / Lightweight)", fillcolor="#d5e8d4"];

    Start -> Q1;
    Q1 -> AnsKafka [label="Yes"];
    Q1 -> Q2 [label="No"];
    
    Q2 -> AnsRMQ [label="Yes"];
    Q2 -> Q3 [label="No"];
    
    Q3 -> AnsNATS [label="Yes"];
    Q3 -> AnsRMQ [label="Fallback / Default"];
}
