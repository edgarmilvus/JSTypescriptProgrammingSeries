/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Self-contained 'Hello World' Event Broker Interface and Implementation
 * Context: SaaS AI Platform streaming Headless Inference events via Server-Sent Events (SSE)
 */

import { EventEmitter } from 'node:events';

/**
 * Represents the immutable structure of an AI inference execution event.
 * Adheres to Domain-Driven Design (DDD) principles by treating events as facts.
 */
interface InferenceRequestedEvent {
  readonly eventId: string;
  readonly aggregateId: string; // Tenant or Session ID
  readonly eventType: 'INFERENCE_REQUESTED';
  readonly payload: {
    readonly modelName: string;
    readonly prompt: string;
    readonly temperature: number;
  };
  readonly metadata: {
    readonly timestamp: number;
    readonly version: string;
  };
}

/**
 * Abstract interface defining the contract for any underlying event broker
 * (whether backed by Kafka, RabbitMQ, or NATS).
 */
interface IEventBroker {
  connect(): Promise<void>;
  publish(topic: string, event: InferenceRequestedEvent): Promise<void>;
  subscribe(topic: string, handler: (event: InferenceRequestedEvent) => Promise<void>): Promise<void>;
  disconnect(): Promise<void>;
}

/**
 * A concrete in-memory mock broker simulating message broker behaviors
 * such as asynchronous delivery, network latency, and connection lifecycles.
 */
class InMemorySaaSBroker implements IEventBroker {
  private isConnected: boolean = false;
  private readonly dispatcher: EventEmitter;

  constructor() {
    this.dispatcher = new EventEmitter();
    // Prevent memory leak warnings for high-throughput multi-tenant systems
    this.dispatcher.setMaxListeners(100);
  }

  /**
   * Establishes a simulated connection to the cluster.
   */
  public async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        this.isConnected = true;
        console.log('[Broker] Successfully connected to distributed message bus.');
        resolve();
      }, 50);
    });
  }

  /**
   * Publishes an immutable event to a specified topic/channel.
   * @param topic The routing key or partition topic (e.g., 'ai.inference.requests')
   * @param event The immutable domain event object
   */
  public async publish(topic: string, event: InferenceRequestedEvent): Promise<void> {
    if (!this.isConnected) {
      throw new Error('[BrokerError] Cannot publish message; broker is disconnected.');
    }

    // Simulate network serialization overhead (JSON stringify/parse roundtrip)
    const serializedPayload = JSON.stringify(event);
    
    // Simulate asynchronous broker acknowledgement (ACK)
    setImmediate(() => {
      this.dispatcher.emit(topic, JSON.parse(serializedPayload));
    });
  }

  /**
   * Subscribes a worker handler to a specific topic.
   * @param topic The topic to listen on
   * @param handler Async function processing the incoming event
   */
  public async subscribe(
    topic: string,
    handler: (event: InferenceRequestedEvent) => Promise<void>
  ): Promise<void> {
    if (!this.isConnected) {
      throw new Error('[BrokerError] Cannot subscribe; broker is disconnected.');
    }

    this.dispatcher.on(topic, async (event: InferenceRequestedEvent) => {
      try {
        // Execute the consumer logic wrapped in error boundaries
        await handler(event);
      } catch (error) {
        console.error(`[BrokerError] Failed to process event [${event.eventId}] on topic [${topic}]:`, error);
        // In a real Kafka/RabbitMQ implementation, this would trigger a Dead Letter Queue (DLQ) routing
      }
    });

    console.log(`[Broker] Worker successfully subscribed to topic: ${topic}`);
  }

  /**
   * Gracefully terminates broker connections.
   */
  public async disconnect(): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(() => {
        this.isConnected = false;
        this.dispatcher.removeAllListeners();
        console.log('[Broker] Gracefully disconnected from distributed message bus.');
        resolve();
      }, 50);
    });
  }
}

/**
 * Application Entrypoint / Demonstration execution loop
 */
async function bootstrapSaaSInferencePipeline() {
  const broker: IEventBroker = new InMemorySaaSBroker();
  const INFERENCE_TOPIC = 'ai.inference.requests.v1';

  // 1. Establish connection to the broker
  await broker.connect();

  // 2. Register a downstream microservice consumer (e.g., Headless Inference Worker)
  await broker.subscribe(INFERENCE_TOPIC, async (event) => {
    console.log(`[InferenceWorker] Received event ID: ${event.eventId} for Tenant: ${event.aggregateId}`);
    console.log(`[InferenceWorker] Spawning headless model execution for: "${event.payload.prompt}"`);
    
    // Simulate heavy async LLM token computation
    await new Promise((resolve) => setTimeout(resolve, 100));
    
    console.log(`[InferenceWorker] Successfully processed model: ${event.payload.modelName}`);
  });

  // 3. Construct an immutable domain event representing a user prompt request
  const incomingInferenceEvent: InferenceRequestedEvent = {
    eventId: 'evt_' + Math.random().toString(36.substring(2, 9)),
    aggregateId: 'tenant_enterprise_991',
    eventType: 'INFERENCE_REQUESTED',
    payload: {
      modelName: 'llama-3-70b-instruct',
      prompt: 'Explain the mathematical implications of event-driven distributed state consistency.',
      temperature: 0.2,
    },
    metadata: {
      timestamp: Date.now(),
      version: '1.0.0',
    },
  };

  // 4. Publish the event as an upstream API gateway producer
  console.log('[APIGateway] Publishing inference request to broker...');
  await broker.publish(INFERENCE_TOPIC, incomingInferenceEvent);

  // 5. Allow time for asynchronous processing before shutting down
  setTimeout(async () => {
    await broker.disconnect();
  }, 300);
}

// Execute the bootstrap routine
bootstrapSaaSInferencePipeline().catch((err) => {
  console.error('Fatal bootstrapping error:', err);
});
