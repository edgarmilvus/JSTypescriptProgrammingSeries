/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { StateGraph, END } from "@langgraph/js";
import { Pinecone } from "@pinecone-database/pinecone";
import { Kafka, Producer, Consumer, EachMessagePayload } from "kafkajs";

/**
 * Interface representing the shared graph state for our enterprise document 
 * processing and vector indexing workflow in a SaaS context.
 */
interface DocumentProcessingState {
  documentId: string;
  tenantId: string;
  rawContent: string;
  chunks: string[];
  embeddings: number[][];
  vectorIds: string[];
  status: "RECEIVED" | "CHUNKED" | "EMBEDDED" | "INDEXED" | "FAILED";
  error?: string;
}

/**
 * Mock Checkpointer abstraction using a high-performance key-value/SQL store 
 * to serialize and persist the state graph after every node transition.
 */
class RedisGraphCheckpointer {
  private store: Map<string, string> = new Map();

  async save(threadId: string, state: DocumentProcessingState): Promise<void> {
    const serialized = JSON.stringify(state);
    this.store.set(threadId, serialized);
    // In production, execute an asynchronous Redis HSET or PostgreSQL upsert
  }

  async load(threadId: string): Promise<DocumentProcessingState | null> {
    const data = this.store.get(threadId);
    return data ? JSON.parse(data) : null;
  }
}

/**
 * Core Application Engine orchestrating Event Brokers (Kafka), State Graphs (LangGraph),
 * and Vector Databases (Pinecone) within a TypeScript microservices architecture.
 */
class EnterpriseDocumentWorkflowEngine {
  private pinecone: Pinecone;
  private kafka: Kafka;
  private producer: Producer;
  private consumer: Consumer;
  private checkpointer: RedisGraphCheckpointer;
  private workflow: StateGraph<DocumentProcessingState>;

  constructor() {
    // 1. Initialize Pinecone Client for Vector Indexing
    this.pinecone = new Pinecone({
      apiKey: process.env.PINECONE_API_KEY || "mock_pinecone_key",
    });

    // 2. Initialize Kafka Client for Event-Driven Communication
    this.kafka = new Kafka({
      clientId: "saas-document-service",
      brokers: [process.env.KAFKA_BROKER || "localhost:9092"],
    });

    this.producer = this.kafka.producer();
    this.consumer = this.kafka.consumer({ groupId: "document-processing-group" });
    this.checkpointer = new RedisGraphCheckpointer();

    // 3. Construct the StateGraph for Deterministic Workflow Execution
    this.workflow = new StateGraph<DocumentProcessingState>({
      channels: {
        documentId: { value: (x, y) => y ?? x, default: () => "" },
        tenantId: { value: (x, y) => y ?? x, default: () => "" },
        rawContent: { value: (x, y) => y ?? x, default: () => "" },
        chunks: { value: (x, y) => y ?? x, default: () => [] },
        embeddings: { value: (x, y) => y ?? x, default: () => [] },
        vectorIds: { value: (x, y) => y ?? x, default: () => [] },
        status: { value: (x, y) => y ?? x, default: () => "RECEIVED" },
        error: { value: (x, y) => y ?? x, default: () => undefined },
      },
    });

    this.initializeGraphNodes();
  }

  /**
   * Defines computational nodes and transitions within the LangGraph StateGraph.
   */
  private initializeGraphNodes(): void {
    // Node 1: Chunk raw text into semantic segments
    this.workflow.addNode("chunkDocument", async (state: DocumentProcessingState) => {
      try {
        // Splitting logic simulating semantic chunking
        const chunkSize = 500;
        const chunks: string[] = [];
        for (let i = 0; i < state.rawContent.length; i += chunkSize) {
          chunks.push(state.rawContent.slice(i, i + chunkSize));
        }
        return { ...state, chunks, status: "CHUNKED" };
      } catch (err: any) {
        return { ...state, status: "FAILED", error: err.message };
      }
    });

    // Node 2: Generate vector embeddings for text chunks
    this.workflow.addNode("generateEmbeddings", async (state: DocumentProcessingState) => {
      try {
        // Simulating embedding generation via an external AI microservice
        const embeddings = state.chunks.map(() => Array(1536).fill(0.123));
        return { ...state, embeddings, status: "EMBEDDED" };
      } catch (err: any) {
        return { ...state, status: "FAILED", error: err.message };
      }
    });

    // Node 3: Upsert vectors into Pinecone Index
    this.workflow.addNode("indexVectors", async (state: DocumentProcessingState) => {
      try {
        const index = this.pinecone.index("tenant-documents");
        const vectors = state.embeddings.map((embedding, indexNum) => ({
          id: `${state.documentId}-chunk-${indexNum}`,
          values: embedding,
          metadata: { tenantId: state.tenantId, documentId: state.documentId },
        }));

        await index.upsert(vectors);
        const vectorIds = vectors.map((v) => v.id);

        return { ...state, vectorIds, status: "INDEXED" };
      } catch (err: any) {
        return { ...state, status: "FAILED", error: err.message };
      }
    });

    // Define Graph Edges and Execution Flow
    this.workflow.addEdge("chunkDocument", "generateEmbeddings");
    this.workflow.addEdge("generateEmbeddings", "indexVectors");
    this.workflow.addEdge("indexVectors", END);
    this.workflow.setEntryPoint("chunkDocument");
  }

  /**
   * Connects to Kafka, subscribes to ingestion topics, and processes events.
   */
  public async startConsumer(): Promise<void> {
    await this.producer.connect();
    await this.consumer.connect();
    await this.consumer.subscribe({ topic: "document.ingestion.requested", fromBeginning: false });

    await this.consumer.run({
      eachMessage: async ({ topic, partition, message }: EachMessagePayload) => {
        if (!message.value) return;

        const payload = JSON.parse(message.value.toString()) as {
          documentId: string;
          tenantId: string;
          content: string;
        };

        console.log(`[Kafka Consumer] Processing document ingestion: ${payload.documentId}`);

        // Initialize state
        let currentState: DocumentProcessingState = {
          documentId: payload.documentId,
          tenantId: payload.tenantId,
          rawContent: payload.content,
          chunks: [],
          embeddings: [],
          vectorIds: [],
          status: "RECEIVED",
        };

        // Persist initial state via checkpointer
        await this.checkpointer.save(payload.documentId, currentState);

        try {
          // Compile and execute StateGraph workflow
          const compiledApp = this.workflow.compile();
          const result = await compiledApp.invoke(currentState);

          // Save final state checkpoint
          await this.checkpointer.save(payload.documentId, result);

          // Produce domain event downstream to Kafka signaling successful indexing
          await this.producer.send({
            topic: "document.indexed.completed",
            messages: [
              {
                key: payload.documentId,
                value: JSON.stringify({
                  documentId: result.documentId,
                  tenantId: result.tenantId,
                  vectorIds: result.vectorIds,
                  status: result.status,
                }),
              },
            ],
          });

          console.log(`[Workflow Success] Document ${payload.documentId} indexed successfully.`);
        } catch (error: any) {
          console.error(`[Workflow Error] Failed processing document ${payload.documentId}:`, error);
          
          currentState.status = "FAILED";
          currentState.error = error.message;
          await this.checkpointer.save(payload.documentId, currentState);
        }
      },
    });
  }
}

// Execution entry point for the Next.js API route or dedicated background worker process
if (require.main === module) {
  const engine = new EnterpriseDocumentWorkflowEngine();
  engine.start().catch((err) => {
    console.error("Critical error starting Enterprise Document Workflow Engine:", err);
    process.exit(1);
  });
}
