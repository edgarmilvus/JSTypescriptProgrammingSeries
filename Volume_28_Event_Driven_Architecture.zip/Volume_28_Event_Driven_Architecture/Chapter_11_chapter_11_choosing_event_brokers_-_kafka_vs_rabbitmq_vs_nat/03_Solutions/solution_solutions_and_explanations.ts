/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Kafka, Producer, Consumer, EachMessagePayload, logLevel } from 'kafkajs';

// 1. Strict Domain Event Types
export type EventType = 'TransactionInitiated' | 'TransactionCleared' | 'TransactionFailed';

export interface DomainEventEnvelope<T> {
  eventId: string;
  aggregateId: string;
  eventType: EventType;
  timestamp: number;
  version: number;
  payload: T;
}

export interface TransactionPayload {
  accountId: string;
  amount: number;
  currency: string;
}

// 2. Idempotent Producer
export class KafkaLedgerProducer {
  private producer: Producer;

  constructor(kafka: Kafka) {
    this.producer = kafka.producer({
      idempotent: true,
      maxInFlightRequests: 1,
      allowAutoTopicCreation: false,
    });
  }

  public async connect(): Promise<void> {
    await this.producer.connect();
  }

  public async publishEvent(topic: string, event: DomainEventEnvelope<TransactionPayload>): Promise<void> {
    await this.producer.send({
      topic,
      acks: -1, // equivalent to 'all'
      messages: [
        {
          key: event.aggregateId, // Ensures total ordering per ledger account
          value: JSON.stringify(event),
          headers: {
            eventType: event.eventType,
            version: event.version.toString(),
          },
        },
      ],
    });
  }

  public async disconnect(): Promise<void> {
    await this.producer.disconnect();
  }
}

// 3 & Interactive Challenge: Consumer Group Processing with Retry, Backoff, and DLQ
export class KafkaLedgerConsumer {
  private consumer: Consumer;
  private retryStateTracker: Map<string, number> = new Map();

  constructor(kafka: Kafka, groupId: string) {
    this.consumer = kafka.consumer({ groupId });
  }

  public async connect(topics: string[]): Promise<void> {
    await this.consumer.connect();
    for (const topic of topics) {
      await this.consumer.subscribe({ topic, fromBeginning: false });
    }
  }

  public async startProcessing(dlqTopic: string, producer: Producer): Promise<void> {
    await this.consumer.run({
      autoCommit: false,
      eachMessage: async (payload: EachMessagePayload) => {
        const { topic, partition, message } = payload;
        const messageKey = `${topic}-${partition}-${message.offset}`;

        if (!message.value) return;

        const event: DomainEventEnvelope<TransactionPayload> = JSON.parse(message.value.toString());

        try {
          // Simulate processing pipeline (e.g., handling transient network timeout on TransactionCleared)
          await this.processWithTransientSimulation(event);

          // Success: Reset retry tracker and manually commit offset
          this.retryStateTracker.delete(messageKey);
          await this.consumer.commitOffsets([
            { topic, partition, offset: (BigInt(message.offset) + 1n).toString() },
          ]);
        } catch (error) {
          const currentRetries = this.retryStateTracker.get(messageKey) || 0;

          if (currentRetries < 3) {
            // Exponential backoff simulation
            const backoffMs = Math.pow(2, currentRetries) * 100;
            this.retryStateTracker.set(messageKey, currentRetries + 1);
            
            await new Promise((resolve) => setTimeout(resolve, backoffMs));
            // Re-throw or recursively process depending on local execution loop design
            throw error; 
          } else {
            // Max retries exceeded -> Route to DLQ
            console.error(`Max retries reached for message ${messageKey}. Routing to DLQ.`);
            await producer.send({
              topic: dlqTopic,
              messages: [
                {
                  key: message.key,
                  value: message.value,
                  headers: { ...message.headers, error: (error as Error).message },
                },
              ],
            });

            // Commit offset to skip poisoned message in primary topic
            this.retryStateTracker.delete(messageKey);
            await this.consumer.commitOffsets([
              { topic, partition, offset: (BigInt(message.offset) + 1n).toString() },
            ]);
          }
        }
      },
    });
  }

  private async processWithTransientSimulation(event: DomainEventEnvelope<TransactionPayload>): Promise<void> {
    if (event.eventType === 'TransactionCleared' && event.payload.amount > 10000) {
      // Simulate random transient network error
      if (Math.random() < 0.8) {
        throw new Error('Transient Network Timeout');
      }
    }
    // Normal processing logic...
  }

  public async gracefulShutdown(): Promise<void> {
    await this.consumer.disconnect();
  }
}
