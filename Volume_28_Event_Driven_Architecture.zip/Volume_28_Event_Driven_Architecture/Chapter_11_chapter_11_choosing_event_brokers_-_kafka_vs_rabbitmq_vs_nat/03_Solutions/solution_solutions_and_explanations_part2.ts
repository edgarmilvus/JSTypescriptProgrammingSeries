/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { connect, NatsConnection, JetStreamManager, JetStreamClient, AckPolicy, nanos } from 'nats';

export class NatsBrokerManager {
  private nc!: NatsConnection;
  private jsm!: JetStreamManager;
  private js!: JetStreamClient;

  public async initialize(): Promise<void> {
    this.nc = await connect({ servers: ['nats://localhost:4222'] });
    this.jsm = await this.nc.jetstreamManager();
    this.js = this.nc.jetstream();

    // 1. Programmatically provision TELEMETRY_STREAM
    await this.jsm.streams.add({
      name: 'TELEMETRY_STREAM',
      subjects: ['telemetry.>'],
      max_bytes: 1024 * 1024 * 1024, // 1GB
      storage: 'file',
    });
  }

  // 2. Durable Worker Consumer
  public async startDurableWorker(queueGroup: string, durableName: string): Promise<void> {
    const consumerInfo = await this.js.consumers.get('TELEMETRY_STREAM', durableName).catch(async () => {
      // Create if missing
      return await this.jsm.consumers.add('TELEMETRY_STREAM', {
        durable_name: durableName,
        ack_policy: AckPolicy.Explicit,
        filter_subject: 'telemetry.device',
      });
    });

    const messages = await this.js.consumers.get('TELEMETRY_STREAM', durableName);
    const iter = await messages.messages();

    for await (const m of iter) {
      try {
        const payload = JSON.parse(m.string());
        
        // Process DB persistence
        await this.persistToDatabase(payload);

        // Explicit acknowledgment
        m.ack();
      } catch (err) {
        // Negative acknowledgment with delay or redelivery
        m.nak();
      }
    }
  }

  // 3. Request-Reply Service Handler
  public startAccountService(): void {
    this.nc.subscribe('account.balance.get', {
      callback: async (err, msg) => {
        if (err) return;
        try {
          const { accountId } = JSON.parse(msg.string());
          const balance = await this.fetchAccountBalanceFromDB(accountId);
          
          msg.respond(JSON.stringify({ accountId, balance, timestamp: Date.now() }));
        } catch (error) {
          msg.respond(JSON.stringify({ error: 'Internal Service Error' }));
        }
      }
    });
  }

  // 4. Request-Reply Caller with Timeout Handling
  public async getAccountBalance(accountId: string): Promise<number> {
    try {
      const response = await this.nc.request(
        'account.balance.get',
        JSON.stringify({ accountId }),
        { timeout: 500 } // 500ms strict timeout window
      );
      
      const data = JSON.parse(response.string());
      return data.balance;
    } catch (err) {
      throw new Error(`Account balance request failed or timed out: ${(err as Error).message}`);
    }
  }

  private async persistToDatabase(data: any): Promise<void> {
    // Mock DB write
  }

  private async fetchAccountBalanceFromDB(id: string): Promise<number> {
    return 1500.00;
  }

  public async close(): Promise<void> {
    await this.nc.drain();
  }
}
