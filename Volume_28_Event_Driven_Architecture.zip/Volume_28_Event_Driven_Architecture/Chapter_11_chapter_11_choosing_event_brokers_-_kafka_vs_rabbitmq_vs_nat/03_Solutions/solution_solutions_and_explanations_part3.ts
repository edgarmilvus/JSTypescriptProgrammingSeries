/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import amqp, { Connection, Channel, ConsumeMessage } from 'amqplib';

export interface OrderPayload {
  orderId: string;
  category: string;
  weightKg: number;
  destinationCountry: string;
}

export class RabbitMQOrderPipeline {
  private connection!: Connection;
  private channel!: Channel;

  public async initialize(): Promise<void> {
    this.connection = await amqp.connect('amqp://localhost');
    this.channel = await this.connection.createChannel();

    // 1 & 2. Topology Declaration with DLX parameters
    const exchange = 'orders.topic';
    const dlxExchange = 'orders.dlx.exchange';
    const dlxQueue = 'orders.dlx';

    await this.channel.assertExchange(exchange, 'topic', { durable: true });
    await this.channel.assertExchange(dlxExchange, 'direct', { durable: true });
    
    await this.channel.assertQueue(dlxQueue, { durable: true });
    await this.channel.bindQueue(dlxQueue, dlxExchange, 'dlx.routing');

    const queueArgs = {
      'x-dead-letter-exchange': dlxExchange,
      'x-dead-letter-routing-key': 'dlx.routing',
    };

    await this.channel.assertQueue('orders.express', { durable: true, arguments: queueArgs });
    await this.channel.assertQueue('orders.standard', { durable: true, arguments: queueArgs });

    await this.channel.bindQueue('orders.express', exchange, 'order.*.express');
    await this.channel.bindQueue('orders.standard', exchange, 'order.*.standard');
  }

  // 4. Typed Publisher with Dynamic Routing Key Computation
  public async publishOrder(order: OrderPayload): Promise<boolean> {
    const speedTier = order.weightKg < 5 ? 'express' : 'standard';
    const routingKey = `order.${order.destinationCountry.toLowerCase()}.${speedTier}`;

    const payloadBuffer = Buffer.from(JSON.stringify(order));

    return this.channel.publish('orders.topic', routingKey, payloadBuffer, {
      persistent: true,
      contentType: 'application/json',
    });
  }

  // 3. Competing Consumers with Prefetch and Manual Acknowledgment
  public async consumeExpressOrders(onMessageProcessed: (order: OrderPayload) => Promise<void>): Promise<void> {
    await this.channel.prefetch(10); // Fair work distribution

    await this.channel.consume('orders.express', async (msg: ConsumeMessage | null) => {
      if (!msg) return;

      try {
        const order: OrderPayload = JSON.parse(msg.content.toString());
        await onMessageProcessed(order);
        
        this.channel.ack(msg);
      } catch (error) {
        // Negative acknowledgment without requeue triggers DLX forwarding
        this.channel.nack(msg, false, false);
      }
    });
  }

  public async close(): Promise<void> {
    await this.channel.close();
    await this.connection.close();
  }
}
