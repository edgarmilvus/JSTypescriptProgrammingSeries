/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useCallback } from 'react';

// 1. TypeScript Interface Definitions
export interface SystemMetrics {
  eventsPerSecond: number;
  brokerHealth: 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
  brokerType: 'Kafka' | 'RabbitMQ' | 'NATS';
}

export interface LiveTransactionEvent {
  id: string;
  description: string;
  timestamp: string;
}

interface DashboardProps {
  streamEndpoint: string;
}

// 2. Custom Hook for Event Stream Consumption
export function useEventStream(endpoint: string) {
  const [metrics, setMetrics] = useState<SystemMetrics>({
    eventsPerSecond: 0,
    brokerHealth: 'DISCONNECTED',
    brokerType: 'Kafka',
  });
  const [events, setEvents] = useState<LiveTransactionEvent[]>([]);

  useEffect(() => {
    const eventSource = new EventSource(endpoint);

    eventSource.onopen = () => {
      setMetrics((prev) => ({ ...prev, brokerHealth: 'CONNECTED' }));
    };

    eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'METRICS') {
        setMetrics(data.payload);
      } else if (data.type === 'TRANSACTION') {
        setEvents((prev) => [data.payload, ...prev.slice(0, 99)]); // Keep rolling window of 100
      }
    };

    eventSource.onerror = () => {
      setMetrics((prev) => ({ ...prev, brokerHealth: 'DEGRADED' }));
    };

    return () => {
      eventSource.close();
    };
  }, [endpoint]);

  return { metrics, events };
}

// 3 & Interactive Challenge: Real-Time CQRS Dashboard Component with Pause/Resume Buffer
export const CQRSMetricsDashboard: React.FC<DashboardProps> = ({ streamEndpoint }) => {
  const { metrics, events: liveEvents } = useEventStream(streamEndpoint);
  
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [displayedEvents, setDisplayedEvents] = useState<LiveTransactionEvent[]>([]);
  const bufferRef = useRef<LiveTransactionEvent[]>([]);

  // Handle incoming live events vs paused buffering state
  useEffect(() => {
    if (liveEvents.length === 0) return;
    const latestEvent = liveEvents[0];

    if (isPaused) {
      // Buffer incoming items, cap at 100 items FIFO
      if (bufferRef.current.length >= 100) {
        bufferRef.current.pop();
      }
      bufferRef.current.unshift(latestEvent);
    } else {
      setDisplayedEvents((prev) => [latestEvent, ...prev.slice(0, 99)]);
    }
  }, [liveEvents, isPaused]);

  const togglePauseStream = () => {
    if (isPaused) {
      // Flush buffer into active state array when resuming
      setDisplayedEvents((prev) => [...bufferRef.current, ...prev].slice(0, 100));
      bufferRef.current = [];
    }
    setIsPaused(!isPaused);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-gray-900 text-white rounded-xl shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">CQRS Read Model Dashboard ({metrics.brokerType})</h1>
        <div className="flex items-center space-x-4">
          <span className={`px-3 py-1 rounded text-sm font-semibold ${
            metrics.brokerHealth === 'CONNECTED' ? 'bg-green-600' : 'bg-yellow-600'
          }`}>
            {metrics.brokerHealth}
          </span>
          <button
            onClick={togglePauseStream}
            className={`px-4 py-2 rounded font-medium transition ${
              isPaused ? 'bg-blue-600 hover:bg-blue-500' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            {isPaused ? 'Resume Stream' : 'Pause Stream'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-800 p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Events / Second</p>
          <p className="text-3xl font-extrabold">{metrics.eventsPerSecond}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Buffered Items (Paused)</p>
          <p className="text-3xl font-extrabold">{bufferRef.current.length}</p>
        </div>
      </div>

      <div className="bg-gray-800 p-4 rounded-lg h-96 overflow-y-auto">
        <h2 className="text-lg font-semibold mb-3">Live Transaction Stream</h2>
        {displayedEvents.map((evt) => (
          <div key={evt.id} className="p-3 mb-2 bg-gray-700 rounded transition-all duration-300">
            <p className="font-mono text-sm">{evt.description}</p>
            <span className="text-xs text-gray-400">{evt.timestamp}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
