/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { PrismaClient, Prisma } from '@prisma/client';
import { randomUUID } from 'crypto';

// Initialize the Prisma Client instance
const prisma = new PrismaClient();

/**
 * Represents a domain event payload for a SaaS subscription upgrade.
 */
interface SubscriptionUpgradedPayload {
  readonly subscriptionId: string;
  readonly tenantId: string;
  readonly newTier: 'ENTERPRISE' | 'PRO';
  readonly upgradedAt: string;
}

/**
 * Represents the structure of an Outbox record matching our database schema.
 */
interface OutboxRecordInput {
  readonly aggregateId: string;
  readonly aggregateType: string;
  readonly eventType: string;
  readonly payload: SubscriptionUpgradedPayload;
}

/**
 * Simulates a message broker publisher (e.g., Kafka, RabbitMQ, AWS SNS/SQS).
 * In production, this would use a robust client library with connection pooling and retries.
 */
class MessageBrokerMock {
  public async publish(topic: string, eventType: string, payload: unknown): Promise<void> {
    // Simulate network latency
    await new Promise((resolve) => setTimeout(resolve, 50));
    console.log(`[MessageBroker] Published to topic "${topic}" | Event: "${eventType}"`, payload);
  }
}

const messageBroker = new MessageBrokerMock();

/**
 * Executes a business operation (upgrading a subscription) and writes an event
 * to the outbox table within a single ACID database transaction.
 * 
 * @param tenantId The unique identifier of the tenant upgrading their subscription.
 * @param newTier The target subscription tier.
 */
async function upgradeSubscriptionWithOutbox(tenantId: string, newTier: 'ENTERPRISE' | 'PRO'): void {
  const subscriptionId = `sub_${randomUUID()}`;
  const timestamp = new Date().toISOString();

  // Define the event payload
  const eventPayload: SubscriptionUpgradedPayload = {
    subscriptionId,
    tenantId,
    newTier,
    upgradedAt: timestamp,
  };

  const outboxRecord: OutboxRecordInput = {
    aggregateId: subscriptionId,
    aggregateType: 'Subscription',
    eventType: 'SubscriptionUpgraded',
    payload: eventPayload,
  };

  try {
    // Execute a Prisma interactive transaction ($transaction)
    // This guarantees that either ALL operations succeed, or NONE are committed.
    await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // 1. Perform the core business state mutation
      // In a real application, this updates the Tenant or Subscription table.
      console.log(`[Database] Updating tenant ${tenantId} to tier ${newTier}...`);
      
      const updatedTenant = await tx.tenant.upsert({
        where: { id: tenantId },
        update: { subscriptionTier: newTier, updatedAt: new Date() },
        create: { id: tenantId, subscriptionTier: newTier, name: `Tenant ${tenantId}` },
      });

      // 2. Write the domain event to the Outbox table within the exact same transaction
      console.log(`[Database] Writing event to outbox for aggregate ${subscriptionId}...`);
      
      await tx.outbox.create({
        data: {
          id: randomUUID(),
          aggregateId: outboxRecord.aggregateId,
          aggregateType: outboxRecord.aggregateType,
          eventType: outboxRecord.eventType,
          // Store the payload as a JSON string or native JSON depending on DB dialect
          payload: outboxRecord.payload as unknown as Prisma.JsonObject,
          status: 'PENDING',
          createdAt: new Date(),
        },
      });

      console.log('[Database] Transaction successfully committed.');
    });

  } catch (error) {
    console.error('[Database] Transaction failed and was rolled back:', error);
    throw error;
  }
}

/**
 * Background worker polling mechanism that reads pending outbox messages,
 * publishes them to the message broker, and marks them as processed.
 */
async function processOutboxQueue(): Promise<void> {
  console.log('[Outbox Worker] Polling for pending events...');

  // Fetch a batch of pending events, ordered chronologically
  const pendingEvents = await prisma.outbox.findMany({
    where: { status: 'PENDING' },
    take: 10,
    orderBy: { createdAt: 'asc' },
  });

  if (pendingEvents.length === 0) {
    console.log('[Outbox Worker] No pending events found.');
    return;
  }

  for (const event of pendingEvents) {
    try {
      console.log(`[Outbox Worker] Processing event ID: ${event.id} (${event.eventType})`);

      // Attempt to publish to the external message broker
      await messageBroker.publish(
        `tenant-events-${event.aggregateType.toLowerCase()}`,
        event.eventType,
        event.payload
      );

      // Mark the outbox record as PROCESSED
      await prisma.outbox.update({
        where: { id: event.id },
        data: { 
          status: 'PROCESSED',
          processedAt: new Date(),
        },
      });

      console.log(`[Outbox Worker] Successfully processed and marked event ${event.id} as PROCESSED.`);

    } catch (publishError) {
      // Handle transient broker outages safely
      console.error(`[Outbox Worker] Failed to publish event ${event.id}. Leaving as PENDING for retry:`, publishError);
      
      // Optionally implement an attempt counter and move to a 'FAILED' (Dead Letter) state after N retries
      await prisma.outbox.update({
        where: { id: event.id },
        data: {
          retryCount: { increment: 1 },
        },
      });
    }
  }
}

// ==========================================
// Execution Simulation
// ==========================================
async function main() {
  // Setup database connection (Assumes a running PostgreSQL instance with Prisma schema configured)
  try {
    await prisma.$connect();
    console.log('Connected to database.');

    // Step 1: Simulate a user action triggering the outbox pattern
    await upgradeSubscriptionWithOutbox('tenant_uuid_9988', 'ENTERPRISE');

    // Step 2: Simulate the background worker picking up the event
    await processOutboxQueue();

  } catch (e) {
    console.error('Execution error:', e);
  } finally {
    await prisma.$disconnect();
  }
}

// Uncomment to run if executed directly
// main();
