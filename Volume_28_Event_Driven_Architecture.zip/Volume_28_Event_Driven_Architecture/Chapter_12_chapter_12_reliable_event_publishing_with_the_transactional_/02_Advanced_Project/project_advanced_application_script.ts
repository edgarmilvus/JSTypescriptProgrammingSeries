/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { PrismaClient, Prisma } from '@prisma/client';
import { randomUUID } from 'crypto';

/**
 * Initialize Prisma Client. 
 * In a real Next.js application, this would be imported from a shared lib file 
 * to prevent exhausting database connection pools during hot-reloads.
 */
const prisma = new PrismaClient();

/**
 * Interface representing a domain event structure conforming to CloudEvents / DDD standards.
 */
interface DomainEvent {
  eventId: string;
  eventType: string;
  aggregateId: string;
  aggregateType: string;
  payload: Record<string, any>;
  occurredAt: string;
}

/**
 * Service responsible for executing business transactions alongside 
 * writing events to the Transactional Outbox table.
 */
export class SubscriptionService {
  /**
   * Upgrades a user subscription atomically using Prisma interactive transactions.
   * 
   * @param userId - The unique identifier of the user.
   * @param newTier - The target subscription tier (e.g., 'ENTERPRISE').
   * @returns The updated subscription record.
   */
  public async upgradeSubscription(userId: string, newTier: string) {
    // We utilize Prisma's interactive transaction client ($transaction) to ensure
    // that both the business state change and the outbox insertion either both 
    // succeed or both roll back entirely.
    return await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // 1. Perform the core business operation (Updating the database state)
      const updatedSubscription = await tx.subscription.upsert({
        where: { userId },
        update: { tier: newTier, updatedAt: new Date() },
        create: { 
          id: randomUUID(), 
          userId, 
          tier: newTier, 
          status: 'ACTIVE' 
        },
      });

      // 2. Construct the domain event payload
      const domainEvent: DomainEvent = {
        eventId: randomUUID(),
        eventType: 'SubscriptionUpgraded',
        aggregateId: updatedSubscription.id,
        aggregateType: 'Subscription',
        payload: {
          userId: updatedSubscription.userId,
          tier: updatedSubscription.tier,
          status: updatedSubscription.status,
        },
        occurredAt: new Date().toISOString(),
      };

      // 3. Write the event to the Outbox table within the SAME transaction
      await tx.outboxEvent.create({
        data: {
          id: domainEvent.eventId,
          aggregateId: domainEvent.aggregateId,
          aggregateType: domainEvent.aggregateType,
          eventType: domainEvent.eventType,
          payload: JSON.parse(JSON.stringify(domainEvent.payload)),
          processed: false,
          createdAt: new Date(),
        },
      });

      console.log(`[Transaction] Successfully upgraded subscription for user ${userId} and queued outbox event ${domainEvent.eventId}`);

      return updatedSubscription;
    });
  }
}

/**
 * Mock Message Broker client representing an external system like Kafka or RabbitMQ.
 */
class MessageBrokerClient {
  public async publish(topic: string, event: DomainEvent): Promise<void> {
    // Simulate network latency and occasional broker unavailability
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Math.random() < 0.05) {
          reject(new Error('Broker connection timeout'));
        } else {
          console.log(`[Broker] Published event [${event.eventType}] to topic [${topic}]:`, event);
          resolve();
        }
      }, 100);
    });
  }
}

/**
 * Background worker responsible for polling the Outbox table and dispatching events.
 * This runs continuously in a Node.js background process or a scheduled cron job.
 */
export class OutboxPublisherWorker {
  private isRunning: boolean = false;
  private pollIntervalMs: number;
  private brokerClient: MessageBrokerClient;
  private batchSize: number;

  constructor(pollIntervalMs: number = 5000, batchSize: number = 50) {
    this.pollIntervalMs = pollIntervalMs;
    this.brokerClient = new MessageBrokerClient();
    this.batchSize = batchSize;
  }

  /**
   * Starts the polling loop.
   */
  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log('[OutboxWorker] Starting background polling publisher...');
    this.pollLoop();
  }

  /**
   * Stops the polling loop gracefully.
   */
  public stop(): void {
    this.isRunning = false;
    console.log('[OutboxWorker] Stopping background polling publisher...');
  }

  /**
   * Internal asynchronous loop that continuously fetches and publishes batches of events.
   */
  private async pollLoop(): void {
    while (this.isRunning) {
      try {
        await this.processBatch();
      } catch (error) {
        console.error('[OutboxWorkerError] Critical error during outbox processing cycle:', error);
      }

      // Wait for the specified interval before polling again
      await new Promise((resolve) => setTimeout(this.pollIntervalMs, resolve));
    }
  }

  /**
   * Fetches a batch of unprocessed outbox events and dispatches them to the broker.
   */
  private async processBatch(): Promise<void> {
    // Fetch unprocessed records ordered by creation date to preserve causal ordering
    const events = await prisma.outboxEvent.findMany({
      where: { processed: false },
      orderBy: { createdAt: 'asc' },
      take: this.batchSize,
    });

    if (events.length === 0) {
      return;
    }

    console.log(`[OutboxWorker] Found ${events.length} unprocessed outbox events. Dispatching...`);

    for (const record of events) {
      const domainEvent: DomainEvent = {
        eventId: record.id,
        eventType: record.eventType,
        aggregateId: record.aggregateId,
        aggregateType: record.aggregateType,
        payload: record.payload as Record<string, any>,
        occurredAt: record.createdAt.toISOString(),
      };

      try {
        // Attempt to publish to the message broker
        await this.brokerClient.publish(`domain-events.${record.aggregateType.toLowerCase()}`, domainEvent);

        // Mark the event as processed within a discrete database operation
        await prisma.outboxEvent.update({
          where: { id: record.id },
          data: { 
            processed: true,
            processedAt: new Date()
          },
        });

        console.log(`[OutboxWorker] Successfully processed and marked outbox event ${record.id} as complete.`);
      } catch (error) {
        // In a production setup, implement exponential backoff and a retry counter column 
        // on the outbox table to move poisoned messages to a Dead Letter Queue (DLQ).
        console.error(`[OutboxWorkerError] Failed to publish event ${record.id}:`, error);
        break; // Break the batch loop to prevent hammering a failing broker
      }
    }
  }
}

/**
 * Execution entry point for demonstration purposes.
 */
async function bootstrap() {
  const subscriptionService = new SubscriptionService();
  const worker = new OutboxPublisherWorker(3000, 10);

  // Start the background worker
  worker.start();

  // Simulate a user upgrading their subscription via a Next.js API route handler
  try {
    const userId = 'usr_99887766';
    await subscriptionService.upgradeSubscription(userId, 'ENTERPRISE');
  } catch (err) {
    console.error('Failed to execute subscription upgrade:', err);
  }

  // Allow the worker time to pick up and process the event before exiting simulation
  setTimeout(() => {
    worker.stop();
    prisma.$disconnect();
    console.log('[Simulation] Completed outbox cycle demo.');
  }, 10000);
}

// Uncomment below to run directly in a Node environment
// bootstrap();
