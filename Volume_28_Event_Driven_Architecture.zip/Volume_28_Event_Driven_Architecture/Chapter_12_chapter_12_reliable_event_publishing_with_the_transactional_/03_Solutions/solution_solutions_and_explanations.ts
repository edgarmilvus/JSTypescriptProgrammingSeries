/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { PrismaClient, Prisma } from '@prisma/client';
import { z } from 'zod';

// 1. Zod validation schema for runtime payload verification
export const DomainEventSchema = z.object({
  eventId: z.string().uuid(),
  aggregateId: z.string(),
  aggregateType: z.string(),
  eventType: z.string(),
  payload: z.record(z.any()),
  occurredAt: z.date(),
  version: z.number().int().positive(),
});

export type DomainEvent<T> = z.infer<typeof DomainEventSchema> & { payload: T };

export class OutboxRepository {
  constructor(private readonly prisma: PrismaClient) {}

  /**
   * Upgrades a user and writes the corresponding outbox event atomically.
   * Accepts an optional Prisma transaction client to support repository composition.
   */
  public async upgradeUserAndEnqueueEvent<T>(
    userId: string,
    newTier: string,
    event: DomainEvent<T>,
    txClient?: Prisma.TransactionClient
  ): Promise<void> {
    // Validate the event structure against our Zod schema before hitting the DB
    DomainEventSchema.parse(event);

    const executeTransaction = async (tx: Prisma.TransactionClient) => {
      // 1. Perform the aggregate state change
      await tx.user.update({
        where: { id: userId },
        data: { subscriptionTier: newTier },
      });

      // 2. Persist the domain event to the outbox table within the same transaction
      await tx.outboxEvent.create({
        data: {
          id: event.eventId,
          aggregateId: event.aggregateId,
          aggregateType: event.aggregateType,
          eventType: event.eventType,
          payload: JSON.stringify(event.payload),
          occurredAt: event.occurredAt,
          version: event.version,
          status: 'PENDING',
          retryCount: 0,
        },
      });
    };

    // If an external transaction client is provided, execute on it; otherwise, start a new one.
    if (txClient) {
      await executeTransaction(txClient);
    } else {
      await this.prisma.$transaction(async (tx) => {
        await executeTransaction(tx);
      });
    }
  }
}
