/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { PrismaClient } from '@prisma/client';

export interface MessageBroker {
  publish(topic: string, message: string): Promise<void>;
}

export class PollingOutboxPublisher {
  private isRunning: boolean = false;
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly broker: MessageBroker,
    private readonly batchSize: number = 50,
    private readonly pollIntervalMs: number = 500
  ) {}

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.pollLoop();
  }

  public stop(): void {
    this.isRunning = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  private async pollLoop(): Promise<void> {
    if (!this.isRunning) return;

    try {
      await this.processBatch();
    } catch (error) {
      console.error('Error processing outbox batch:', error);
    } finally {
      if (this.isRunning) {
        this.timer = setTimeout(() => this.pollLoop(), this.pollIntervalMs);
      }
    }
  }

  private async processBatch(): Promise<void> {
    await this.prisma.$transaction(async (tx) => {
      // 1. Claim a batch of pending events safely across concurrent pollers using SKIP LOCKED
      const events: Array<{
        id: string;
        eventType: string;
        payload: string;
        retryCount: number;
      }> = await tx.$queryRaw`
        SELECT id, event_type, payload, retry_count 
        FROM outbox_events 
        WHERE status = 'PENDING' 
        ORDER BY occurred_at ASC 
        LIMIT ${this.batchSize} 
        FOR UPDATE SKIP LOCKED;
      `;

      if (events.length === 0) return;

      const eventIds = events.map((e) => e.id);

      // 2. Mark claimed events as PROCESSING to prevent duplicate pickup
      await tx.outboxEvent.updateMany({
        where: { id: { in: eventIds } },
        data: { status: 'PROCESSING' },
      });

      // 3. Process each event and publish to broker
      for (const event of events) {
        try {
          await this.broker.publish(event.eventType, event.payload);

          // Mark as PROCESSED on success
          await tx.outboxEvent.update({
            where: { id: event.id },
            data: { status: 'PROCESSED', processedAt: new Date() },
          });
        } catch (error) {
          const newRetryCount = event.retryCount + 1;
          const maxRetries = 5;

          if (newRetryCount >= maxRetries) {
            // Move to FAILED (Dead-Letter Queue state)
            await tx.outboxEvent.update({
              where: { id: event.id },
              data: { status: 'FAILED', retryCount: newRetryCount, errorMetadata: String(error) },
            });
          } else {
            // Revert to PENDING with incremented retry count for exponential backoff handling
            await tx.outboxEvent.update({
              where: { id: event.id },
              data: { status: 'PENDING', retryCount: newRetryCount },
            });
          }
        }
      }
    });
  }
}
