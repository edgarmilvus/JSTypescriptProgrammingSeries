/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Readable, Transform } from 'stream';

export interface CDCEnvelope<T> {
  before: T | null;
  after: T | null;
  source: {
    version: string;
    connector: string;
    name: string;
    db: string;
    table: string;
  };
  op: 'c' | 'u' | 'd';
  ts_ms: number;
}

export interface CloudEvent<T> {
  specversion: string;
  id: string;
  source: string;
  type: string;
  datacontenttype: string;
  data: T;
  time: string;
}

export class OutboxCDCProcessor {
  constructor(private readonly downstreamPublisher: (event: CloudEvent<any>) => Promise<void>) {}

  public async processStream(cdcStream: Readable): Promise<void> {
    const jsonTransformer = new Transform({
      objectMode: true,
      transform: (chunk: Buffer | string, encoding, callback) => {
        try {
          const rawString = typeof chunk === 'string' ? chunk : chunk.toString('utf8');
          const envelope: CDCEnvelope<any> = JSON.parse(rawString);

          // Filter: only process inserts ('c') on the outbox_events table
          if (envelope.op === 'c' && envelope.after && envelope.source.table === 'outbox_events') {
            const record = envelope.after;

            // Transform into CloudEvent specification v1.0
            const cloudEvent: CloudEvent<any> = {
              specversion: '1.0',
              id: record.id,
              source: `/db/${envelope.source.db}/${envelope.source.table}`,
              type: record.event_type,
              datacontenttype: 'application/json',
              data: JSON.parse(record.payload),
              time: new Date(envelope.ts_ms).toISOString(),
            };

            callback(null, cloudEvent);
          } else {
            callback(null); // Filter out irrelevant records
          }
        } catch (err) {
          // Error handling middleware: log parsing errors without breaking stream
          console.error('Failed to parse CDC log entry:', err);
          callback(null);
        }
      },
    });

    const dispatchStream = new Transform({
      objectMode: true,
      transform: async (cloudEvent: CloudEvent<any>, encoding, callback) => {
        try {
          await this.downstreamPublisher(cloudEvent);
          callback(null);
        } catch (err) {
          console.error(`Failed to publish CloudEvent ${cloudEvent.id}:`, err);
          callback(null);
        }
      },
    });

    await new Promise<void>((resolve, reject) => {
      cdcStream
        .pipe(jsonTransformer)
        .pipe(dispatchStream)
        .on('error', reject)
        .on('end', resolve);
    });
  }
}
