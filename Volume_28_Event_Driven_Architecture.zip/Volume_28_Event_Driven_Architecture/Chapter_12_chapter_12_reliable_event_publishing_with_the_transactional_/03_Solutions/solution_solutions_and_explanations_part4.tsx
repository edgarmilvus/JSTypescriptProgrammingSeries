/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { Suspense } from 'react';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface OutboxMetrics {
  pendingCount: number;
  processedTodayCount: number;
  deadLetterCount: number;
  averageLagMs: number;
}

async function fetchOutboxMetrics(): Promise<OutboxMetrics> {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  const [pendingCount, processedTodayCount, deadLetterCount] = await Promise.all([
    prisma.outboxEvent.count({ where: { status: 'PENDING' } }),
    prisma.outboxEvent.count({
      where: {
        status: 'PROCESSED',
        processedAt: { gte: startOfToday },
      },
    }),
    prisma.outboxEvent.count({ where: { status: 'FAILED' } }),
  ]);

  return {
    pendingCount,
    processedTodayCount,
    deadLetterCount,
    averageLagMs: 142, // Computed latency metric placeholder
  };
}

async function MetricsGrid() {
  const metrics = await fetchOutboxMetrics();

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">
      <div className="p-4 bg-white shadow rounded">
        <h3 className="text-gray-500 text-sm">Pending Events</h3>
        <p className="text-2xl font-bold">{metrics.pendingCount}</p>
      </div>
      <div className="p-4 bg-white shadow rounded">
        <h3 className="text-gray-500 text-sm">Processed Today</h3>
        <p className="text-2xl font-bold text-green-600">{metrics.processedTodayCount}</p>
      </div>
      <div className="p-4 bg-white shadow rounded">
        <h3 className="text-gray-500 text-sm">Dead Letter (Failed)</h3>
        <p className="text-2xl font-bold text-red-600">{metrics.deadLetterCount}</p>
      </div>
      <div className="p-4 bg-white shadow rounded">
        <h3 className="text-gray-500 text-sm">Average Lag</h3>
        <p className="text-2xl font-bold text-blue-600">{metrics.averageLagMs} ms</p>
      </div>
    </div>
  );
}

export default async function OutboxDashboardView() {
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Transactional Outbox Operational Dashboard</h1>
      <Suspense fallback={<div className="p-4 text-gray-500">Loading system health metrics...</div>}>
        <MetricsGrid />
      </Suspense>
    </div>
  );
}
