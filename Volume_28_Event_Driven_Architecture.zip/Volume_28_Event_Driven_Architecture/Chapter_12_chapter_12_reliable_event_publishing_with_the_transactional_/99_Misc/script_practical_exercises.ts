/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

// TODO: Define the DomainEvent interface and Zod validation schema

export interface DomainEvent<T> {
  eventId: string;
  aggregateId: string;
  aggregateType: string;
  eventType: string;
  payload: T;
  occurredAt: Date;
  version: number;
}

export class OutboxRepository {
  constructor(private readonly prisma: PrismaClient) {}

  public async upgradeUserAndEnqueueEvent<T>(
    userId: string,
    newTier: string,
    event: DomainEvent<T>
  ): Promise<void> {
    // TODO: Implement the atomic transaction ensuring both the user update 
    // and outbox insertion succeed or fail together.
    throw new Error('Not implemented');
  }
}
