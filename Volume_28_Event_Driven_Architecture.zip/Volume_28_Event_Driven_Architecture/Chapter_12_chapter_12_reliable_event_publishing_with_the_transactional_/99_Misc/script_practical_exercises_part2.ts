/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { PrismaClient } from '@prisma/client';

export interface MessageBroker {
  publish(topic: string, message: string): Promise<void>;
}

export class PollingOutboxPublisher {
  private isRunning: boolean = false;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly broker: MessageBroker,
    private readonly batchSize: number = 50,
    private readonly pollIntervalMs: number = 500
  ) {}

  public start(): void {
    // TODO: Implement the non-blocking polling loop using setTimeout or setInterval
    throw new Error('Not implemented');
  }

  public stop(): void {
    // TODO: Implement graceful shutdown logic
    throw new Error('Not implemented');
  }

  private async processBatch(): Promise<void> {
    // TODO: Execute raw SQL query with FOR UPDATE SKIP LOCKED, publish events, 
    // and update statuses atomically or within controlled transaction boundaries.
    throw new Error('Not implemented');
  }
}
