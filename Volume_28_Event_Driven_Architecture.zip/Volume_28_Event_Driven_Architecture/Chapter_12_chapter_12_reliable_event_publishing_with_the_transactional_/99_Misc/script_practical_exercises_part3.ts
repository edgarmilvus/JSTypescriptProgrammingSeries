/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { Readable } from 'stream';

export interface CDCEnvelope<T> {
  before: T | null;
  after: T | null;
  source: {
    version: string;
    connector: string;
    name: string;
    db: string;
    table: string;
  };
  op: 'c' | 'u' | 'd';
  ts_ms: number;
}

export interface CloudEvent<T> {
  specversion: string;
  id: string;
  source: string;
  type: string;
  datacontenttype: string;
  data: T;
  time: string;
}

export class OutboxCDCProcessor {
  constructor(private readonly downstreamPublisher: (event: CloudEvent<any>) => Promise<void>) {}

  public async processStream(cdcStream: Readable): Promise<void> {
    // TODO: Pipe the readable stream through transformation and filtering steps,
    // decoding CDC payloads and dispatching them to the downstream publisher.
    throw new Error('Not implemented');
  }
}
