/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Pool, PoolClient } from 'pg';

/**
 * Represents a domain event entering the microservice.
 * In a real-world SaaS architecture, this would match the schema 
 * published by your upstream message broker or event bus.
 */
interface DomainEvent {
  eventId: string;          // Globally unique identifier for this specific message instance
  eventType: string;        // The classification of the event (e.g., 'SUBSCRIPTION_RENEWED')
  aggregateId: string;      // The ID of the entity being modified (e.g., user or tenant ID)
  timestamp: number;        // Epoch timestamp of when the event was emitted
  payload: {
    planId: string;
    amountCents: number;
    currency: string;
  };
}

/**
 * Interface representing the result of processing a domain event.
 */
interface ProcessingResult {
  success: boolean;
  message: string;
  duplicateDetected: boolean;
}

/**
 * PostgreSQL connection pool simulating our SaaS database.
 * In production, this would be injected via Dependency Injection.
 */
const dbPool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://user:password@localhost:5432/saas_db',
});

/**
 * Core Idempotent Event Handler class.
 * Ensures that messages with identical eventIds are processed exactly once,
 * safely handling race conditions under at-least-once delivery semantics.
 */
class IdempotentSubscriptionHandler {
  constructor(private readonly pool: Pool) {}

  /**
   * Main entry point for handling an incoming domain event.
   * Utilizes a PostgreSQL transaction, a unique constraint on the event_log table,
   * and row-level locking to guarantee atomicity and deduplication.
   * 
   * @param event The incoming DomainEvent from the message broker.
   */
  public async handleEvent(event: DomainEvent): Promise<ProcessingResult> {
    // Acquire a dedicated client from the pool to participate in a transaction
    const client: PoolClient = await this.pool.connect();

    try {
      // 1. Begin an isolated transaction
      await client.query('BEGIN');

      // 2. Attempt to register the incoming event ID in our processed event log.
      // We rely on a database unique constraint on `event_id`. 
      // If the eventId already exists, this INSERT statement will throw a unique violation error (Postgres error code: 23505).
      const insertLogQuery = `
        INSERT INTO processed_events (event_id, event_type, aggregate_id, processed_at)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (event_id) DO NOTHING
        RETURNING event_id;
      `;

      const insertResult = await client.query(insertLogQuery, [
        event.eventId,
        event.eventType,
        event.aggregateId,
      ]);

      // 3. Check if the insert actually happened or if it was ignored due to a conflict
      if (insertResult.rowCount === 0) {
        // The event_id already exists in the database. This is a duplicate delivery!
        await client.query('ROLLBACK');
        console.warn(`[IdempotentHandler] Duplicate event detected and ignored: ${event.eventId}`);
        
        return {
          success: true,
          message: `Event ${event.eventId} was already processed. Skipped safely.`,
          duplicateDetected: true,
        };
      }

      // 4. Execute the core business logic (At-Least-Once safety zone)
      // Because we successfully claimed the event_id inside this transaction, 
      // no other concurrent thread can process this event ID.
      await this.executeBusinessLogic(client, event);

      // 5. Commit the transaction, permanently saving both the business state change 
      // and the event processing log entry atomically.
      await client.query('COMMIT');

      console.log(`[IdempotentHandler] Successfully processed event: ${event.eventId}`);
      return {
        success: true,
        message: `Event ${event.eventId} processed successfully.`,
        duplicateDetected: false,
      };

    } catch (error: any) {
      // Rollback the entire transaction if any unexpected database or logic error occurs
      await client.query('ROLLBACK');
      console.error(`[IdempotentHandler] Failed to process event ${event.eventId}:`, error.message);
      
      throw new Error(`Event processing failed for ${event.eventId}: ${error.message}`);
    } finally {
      // Always release the client back to the pool to prevent connection leaks
      client.release();
    }
  }

  /**
   * Simulates the core domain logic update for a SaaS subscription renewal.
   * 
   * @param client Active PostgreSQL client within an open transaction.
   * @param event The domain event containing payload data.
   */
  private async executeBusinessLogic(client: PoolClient, event: DomainEvent): Promise<void> {
    const { aggregateId, payload } = event;

    // Update the tenant or user subscription record in the database
    const updateSubscriptionQuery = `
      UPDATE subscriptions 
      SET 
        plan_id = $1,
        balance_cents = balance_cents + $2,
        updated_at = NOW()
      WHERE user_id = $3;
    `;

    const updateResult = await client.query(updateSubscriptionQuery, [
      payload.planId,
      payload.amountCents,
      aggregateId,
    ]);

    // Safety check: Ensure the user's subscription record actually exists
    if (updateResult.rowCount === 0) {
      throw new Error(`Subscription aggregate not found for user_id: ${aggregateId}`);
    }

    // Simulate an external side effect (e.g., recording an audit log or sending a receipt email)
    // Note: External side effects should ideally use the Transactional Outbox Pattern 
    // to avoid phantom network calls during rollbacks.
    console.log(`[BusinessLogic] Renewed subscription for user ${aggregateId} with plan ${payload.planId}`);
  }
}

// ==========================================
// EXAMPLE USAGE SIMULATION
// ==========================================
async function runSimulation() {
  const handler = new IdempotentSubscriptionHandler(dbPool);

  const sampleEvent: DomainEvent = {
    eventId: 'evt_9988776654321',
    eventType: 'SUBSCRIPTION_RENEWED',
    aggregateId: 'user_12345',
    timestamp: Date.now(),
    payload: {
      planId: 'enterprise_tier_v2',
      amountCents: 4900,
      currency: 'USD',
    },
  };

  console.log('--- Simulating At-Least-Once Delivery (Sending 3 identical events concurrently) ---');

  // Simulate a message broker re-delivering the exact same message 3 times simultaneously
  const results = await Promise.all([
    handler.handleEvent(sampleEvent),
    handler.handleEvent(sampleEvent),
    handler.handleEvent(sampleEvent),
  ]);

  console.log('--- Results Summary ---');
  results.forEach((res, index) => {
    console.log(`Delivery Attempt ${index + 1}:`, res);
  });

  await dbPool.end();
}

// Uncomment to run if executed directly
// runSimulation();
