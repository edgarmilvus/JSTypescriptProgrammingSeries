/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pool, PoolClient } from 'pg';
import Redis from 'ioredis';
import { createHash } from 'crypto';

/**
 * Interface representing an incoming domain event from the message broker.
 */
interface DomainEvent {
  eventId: string;
  eventType: string;
  aggregateId: string;
  version: number;
  payload: {
    userId: string;
    subscriptionId: string;
    amountCents: number;
    renewedAt: string;
  };
  occurredAt: string;
}

/**
 * Result structure for the idempotent event handler.
 */
interface HandlingResult {
  success: boolean;
  status: 'PROCESSED' | 'DUPLICATE_DISCARDED' | 'CONFLICT_RETRYABLE' | 'FAILED';
  error?: string;
}

/**
 * IdempotentSubscriptionHandler manages subscription renewal events with 
 * strict at-least-once deduplication and state fingerprinting guarantees.
 */
export class IdempotentSubscriptionHandler {
  private redis: Redis;
  private pgPool: Pool;
  private readonly DEDUP_TTL_SECONDS = 86400; // 24 hours retention for processed IDs

  constructor(redisClient: Redis, pgPool: Pool) {
    this.redis = redisClient;
    this.pgPool = pgPool;
  }

  /**
   * Main entry point for processing incoming subscription renewal events.
   * Implements a multi-layered defense against duplicate processing:
   * 1. Redis atomic distributed lock & fast-path deduplication check.
   * 2. Database-level unique constraint and aggregate version tracking.
   * 3. State fingerprint verification to detect payload tampering or divergence.
   */
  public async handle(event: DomainEvent): Promise<HandlingResult> {
    const dedupKey = `dedup:event:${event.eventId}`;

    // Step 1: Fast-path atomic check in Redis using SET NX PX
    // This prevents concurrent processing of the exact same event ID across worker replicas.
    const acquired = await this.redis.set(
      dedupKey,
      'PROCESSING',
      'EX',
      this.DEDUP_TTL_SECONDS,
      'NX'
    );

    if (!acquired) {
      const statusValue = await this.redis.get(dedupKey);
      console.warn(`[Deduplication] Duplicate event ID detected via Redis cache: ${event.eventId}. Status: ${statusValue}`);
      return {
        success: true,
        status: 'DUPLICATE_DISCARDED',
      };
    }

    const client: PoolClient = await this.pgPool.connect();

    try {
      // Step 2: Begin transaction for atomic state transition and ledger recording
      await client.query('BEGIN');

      // Step 3: Compute state fingerprint of the payload to detect semantic divergence
      const stateFingerprint = this.generateFingerprint(event.payload);

      // Step 4: Check if this event or a higher version has already been processed for this aggregate
      const aggregateCheckQuery = `
        SELECT version, state_fingerprint 
        FROM subscription_aggregates 
        WHERE aggregate_id = $1 
        FOR UPDATE;
      `;
      const aggregateResult = await client.query(aggregateCheckQuery, [event.aggregateId]);

      if (aggregateResult.rows.length > 0) {
        const currentVersion = aggregateResult.rows[0].version;
        const existingFingerprint = aggregateResult.rows[0].state_fingerprint;

        // If the incoming event version is lower or equal, check if it's an exact retry
        if (event.version <= currentVersion) {
          if (existingFingerprint === stateFingerprint) {
            await client.query('COMMIT');
            await this.redis.set(dedupKey, 'PROCESSED_DUPLICATE', 'EX', this.DEDUP_TTL_SECONDS);
            return { success: true, status: 'DUPLICATE_DISCARDED' };
          } else {
            // Version collision with different payloads indicates event corruption or out-of-order anomalies
            throw new Error(`State fingerprint mismatch for aggregate ${event.aggregateId} at version ${event.version}`);
          }
        }

        // Enforce strict sequential versioning (e.g., expecting currentVersion + 1)
        if (event.version !== currentVersion + 1) {
          throw new Error(`Out-of-order event detected. Expected version ${currentVersion + 1}, received ${event.version}`);
        }
      } else {
        // First time seeing this aggregate; enforce starting version invariant
        if (event.version !== 1) {
          throw new Error(`Initial event for aggregate ${event.aggregateId} must start at version 1, received ${event.version}`);
        }
      }

      // Step 5: Execute domain side-effects (e.g., insert ledger entry, update subscription record)
      const updateSubscriptionQuery = `
        INSERT INTO subscriptions (aggregate_id, user_id, subscription_id, status, current_amount_cents, updated_at)
        VALUES ($1, $2, $3, 'ACTIVE', $4, $5)
        ON CONFLICT (aggregate_id) 
        DO UPDATE SET 
          current_amount_cents = EXCLUDED.current_amount_cents,
          updated_at = EXCLUDED.updated_at;
      `;
      await client.query(updateSubscriptionQuery, [
        event.aggregateId,
        event.payload.userId,
        event.payload.subscriptionId,
        event.payload.amountCents,
        event.payload.renewedAt,
      ]);

      // Step 6: Insert into processed events audit table to enforce database-level uniqueness
      const auditInsertQuery = `
        INSERT INTO processed_events (event_id, event_type, aggregate_id, version, processed_at)
        VALUES ($1, $2, $3, $4, NOW())
        ON CONFLICT (event_id) DO NOTHING;
      `;
      await client.query(auditInsertQuery, [
        event.eventId,
        event.eventType,
        event.aggregateId,
        event.version,
      ]);

      // Step 7: Update aggregate root version and state fingerprint
      const upsertAggregateQuery = `
        INSERT INTO subscription_aggregates (aggregate_id, version, state_fingerprint, updated_at)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (aggregate_id) 
        DO UPDATE SET 
          version = EXCLUDED.version,
          state_fingerprint = EXCLUDED.state_fingerprint,
          updated_at = EXCLUDED.updated_at;
      `;
      await client.query(upsertAggregateQuery, [
        event.aggregateId,
        event.version,
        stateFingerprint,
      ]);

      // Step 8: Commit transaction successfully
      await client.query('COMMIT');

      // Update Redis deduplication key status to processed
      await this.redis.set(dedupKey, 'PROCESSED_SUCCESS', 'EX', this.DEDUP_TTL_SECONDS);

      return {
        success: true,
        status: 'PROCESSED',
      };
    } catch (error: any) {
      await client.query('ROLLBACK');
      
      // If transaction failed due to serialization or concurrent updates, clear Redis lock to allow clean retry
      await this.redis.del(dedupKey);

      console.error(`[IdempotentHandler] Failed to process event ${event.eventId}:`, error.message);
      
      return {
        success: false,
        status: 'FAILED',
        error: error.message,
      };
    } finally {
      client.release();
    }
  }

  /**
   * Generates a cryptographic SHA-256 fingerprint of the event payload 
   * to guarantee deterministic state validation across retries.
   */
  private generateFingerprint(payload: Record<string, any>): string {
    const normalizedString = JSON.stringify(payload, Object.keys(payload).sort());
    return createHash('sha256').update(normalizedString).digest('hex');
  }
}
