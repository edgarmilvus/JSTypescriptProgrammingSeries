/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Pool, PoolClient } from 'pg';

export interface FundsDepositedEvent {
  eventId: string;
  aggregateId: string; // Account ID
  amount: number;
  currency: string;
  timestamp: string;
}

export class PostgresLedgerEventHandler {
  constructor(private readonly pool: Pool) {}

  public async handle(event: FundsDepositedEvent): Promise<void> {
    const client: PoolClient = await this.pool.connect();

    try {
      // 1. Begin transaction block
      await client.query('BEGIN');

      // 2. Enforce Idempotency: Attempt to record the eventId
      // If it already exists, ON CONFLICT DO NOTHING ensures no error is thrown.
      const insertResult = await client.query(
        `INSERT INTO processed_messages (event_id) 
         VALUES ($1) 
         ON CONFLICT (event_id) DO NOTHING`,
        [event.eventId]
      );

      // 3. If no rows were inserted, the event has already been processed. Safe exit.
      if (insertResult.rowCount === 0) {
        await client.query('COMMIT');
        return;
      }

      // 4. Prevent concurrent modification anomalies using SELECT ... FOR UPDATE
      const accountResult = await client.query(
        `SELECT id, balance FROM accounts WHERE id = $1 FOR UPDATE`,
        [event.aggregateId]
      );

      if (accountResult.rowCount === 0) {
        throw new Error(`Account with ID ${event.aggregateId} not found.`);
      }

      // 5. Execute core business logic: update account balance
      await client.query(
        `UPDATE accounts 
         SET balance = balance + $1, updated_at = NOW() 
         WHERE id = $2`,
        [event.amount, event.aggregateId]
      );

      // 6. Commit transaction
      await client.query('COMMIT');
    } catch (error) {
      // Rollback transaction on unexpected failures
      await client.query('ROLLBACK');
      throw error;
    } finally {
      // Guaranteed connection release back to the pool
      client.release();
    }
  }
}
