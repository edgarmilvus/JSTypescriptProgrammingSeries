/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';

export class RedisDeduplicationService {
  constructor(private readonly redisClient: Redis) {}

  public async isDuplicate(eventId: string, ttlSeconds: number): Promise<boolean> {
    const key = `dedup:event:${eventId}`;
    
    try {
      // Attempt conditional set: Set if Not Exists (NX) with an expiration time in seconds (EX)
      const result = await this.redisClient.set(key, '1', 'EX', ttlSeconds, 'NX');

      // If the command successfully sets the key, it is NOT a duplicate (returns false)
      if (result === 'OK') {
        return false;
      }

      // Interactive Challenge: Implement sliding window extension
      // If the event arrives again before expiration, extend its TTL by an additional delta (e.g., 300s)
      await this.redisClient.expire(key, ttlSeconds + 300);

      // If result is null/falsy, the key already existed (it IS a duplicate)
      return true;
    } catch (error) {
      // Robust Fallback Strategy: Log critical error and fail-safe (allow execution)
      console.error(`[CRITICAL] Redis deduplication failure for event ${eventId}. Falling back to allow processing:`, error);
      
      // Depending on business risk policy, returning false ensures system availability over strict deduplication during outages.
      return false; 
    }
  }
}
