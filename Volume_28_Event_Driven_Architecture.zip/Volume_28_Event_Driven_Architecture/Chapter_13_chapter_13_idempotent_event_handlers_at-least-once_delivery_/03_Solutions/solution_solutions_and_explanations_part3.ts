/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface IMessagePublisher {
  publish(topic: string, payload: string): Promise<void>;
}

export interface OutboxMessage {
  id: string;
  topic: string;
  payload: string;
  status: 'PENDING' | 'DISPATCHED' | 'FAILED';
  retryCount: number;
}

export class TransactionalOutboxDispatcher {
  constructor(
    private readonly dbPool: any, // PostgreSQL Pool
    private readonly publisher: IMessagePublisher
  ) {}

  public async pollAndDispatch(batchSize: number = 50): Promise<void> {
    const client = await this.dbPool.connect();

    try {
      await client.query('BEGIN');

      // 1. Fetch pending messages safely using SKIP LOCKED to prevent multi-worker contention
      const fetchResult = await client.query(
        `SELECT id, topic, payload, status, retry_count as "retryCount"
         FROM outbox_messages
         WHERE status = 'PENDING'
         ORDER BY created_at ASC
         LIMIT $1
         FOR UPDATE SKIP LOCKED`,
        [batchSize]
      );

      const messages: OutboxMessage[] = fetchResult.rows;

      if (messages.length === 0) {
        await client.query('COMMIT');
        return;
      }

      for (const msg of messages) {
        try {
          // 2. Attempt publishing to the broker
          await this.publisher.publish(msg.topic, msg.payload);

          // 3. Mark as DISPATCHED on successful publication
          await client.query(
            `UPDATE outbox_messages 
             SET status = 'DISPATCHED', dispatched_At = NOW() 
             WHERE id = $1`,
            [msg.id]
          );
        } catch (pubError) {
          // 4. Handle publishing failure and implement DLQ logic for the interactive challenge
          const newRetryCount = msg.retryCount + 1;
          const maxRetries = 5;

          if (newRetryCount >= maxRetries) {
            // Move to FAILED/DLQ status
            await client.query(
              `UPDATE outbox_messages 
               SET status = 'FAILED', retry_count = $1 
               WHERE id = $2`,
              [newRetryCount, msg.id]
            );
            console.error(`[DLQ] Message ${msg.id} permanently failed after ${maxRetries} attempts.`);
          } else {
            // Increment retry count, leave as PENDING for future cycles
            await client.query(
              `UPDATE outbox_messages 
               SET retry_count = $1 
               WHERE id = $2`,
              [newRetryCount, msg.id]
            );
          }
        }
      }

      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      console.error('Outbox dispatcher polling cycle failed:', error);
    } finally {
      client.release();
    }
  }
}
