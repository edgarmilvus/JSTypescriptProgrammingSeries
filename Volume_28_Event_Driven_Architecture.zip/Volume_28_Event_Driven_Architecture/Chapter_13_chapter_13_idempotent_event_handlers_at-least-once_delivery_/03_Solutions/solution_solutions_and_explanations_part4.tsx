/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface SystemEvent {
  id: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, any>;
  timestamp: string;
}

interface StreamedEventViewerProps {
  eventStream: ReadableStream<Uint8Array>;
}

export const StreamedEventViewer: React.FC<StreamedEventViewerProps> = ({ eventStream }) => {
  const [events, setEvents] = useState<SystemEvent[]>([]);

  // Deduplication utility checking state fingerprints
  const isDuplicateEvent = (existingEvents: SystemEvent[], incomingEvent: SystemEvent): boolean => {
    return existingEvents.some(
      (evt) =>
        evt.aggregateId === incomingEvent.aggregateId &&
        evt.timestamp === incomingEvent.timestamp &&
        evt.eventType === incomingEvent.eventType
    );
  };

  useEffect(() => {
    const reader = eventStream.getReader();
    const decoder = new TextDecoder();
    let isMounted = true;

    const readStream = async () => {
      try {
        while (isMounted) {
          const { value, done } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          // Assuming standard newline-delimited JSON streams from SSE
          const lines = chunk.split('\n').filter(Boolean);

          for (const line of lines) {
            try {
              const parsedEvent: SystemEvent = JSON.parse(line);
              
              setEvents((prevEvents) => {
                if (isDuplicateEvent(prevEvents, parsedEvent)) {
                  return prevEvents; // Drop duplicate
                }
                return [...prevEvents, parsedEvent]; // Append unique event
              });
            } catch (err) {
              console.error('Failed to parse incoming stream chunk line:', err);
            }
          }
        }
      } catch (error) {
        console.error('Error reading event stream:', error);
      }
    };

    readStream();

    return () => {
      isMounted = false;
      reader.cancel();
    };
  }, [eventStream]);

  return (
    <div className="stream-container">
      <h2>Real-Time System Events</h2>
      <ul>
        {events.map((evt) => (
          <li key={evt.id} className="event-card">
            <span className="badge">{evt.eventType}</span>
            <p>Aggregate ID: {evt.aggregateId}</p>
            <small>{evt.timestamp}</small>
          </li>
        ))}
      </ul>
    </div>
  );
};
