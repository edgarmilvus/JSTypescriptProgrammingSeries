/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

export function generateStateFingerprint(
  payload: Record<string, any>,
  ignoredKeys: string[] = ['timestamp', 'traceId']
): string {
  // Recursive helper function to normalize and sort JSON objects
  const normalize = (value: any): any => {
    if (value === null || typeof value !== 'object') {
      return value;
    }

    if (Array.isArray(value)) {
      return value.map(normalize);
    }

    const sortedObj: Record<string, any> = {};
    const keys = Object.keys(value).sort();

    for (const key of keys) {
      if (ignoredKeys.includes(key)) {
        continue; // Strip volatile transient fields
      }
      sortedObj[key] = normalize(value[key]);
    }

    return sortedObj;
  };

  const normalizedPayload = normalize(payload);
  const canonicalString = JSON.stringify(normalizedPayload);

  // Compute cryptographic SHA-256 hash digest
  return crypto.createHash('sha256').update(canonicalString).digest('hex');
}
