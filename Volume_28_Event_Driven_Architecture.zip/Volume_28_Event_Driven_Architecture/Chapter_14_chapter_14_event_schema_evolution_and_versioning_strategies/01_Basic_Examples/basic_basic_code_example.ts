/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file user-signup-upcaster.ts
 * @description Demonstrates the Upcaster Pattern for Event Schema Evolution in TypeScript.
 * Context: SaaS User Management Microservice.
 */

// ==========================================
// 1. SCHEMA DEFINITIONS (VERSIONS 1 & 2)
// ==========================================

/**
 * Version 1 of the UserSignedUp event schema.
 * Used historically when users only provided a single "name" string.
 */
export interface UserSignedUpV1 {
  readonly eventId: string;
  readonly specVersion: 1;
  readonly timestamp: string;
  readonly data: {
    readonly userId: string;
    readonly email: string;
    readonly name: string; // Legacy monolithic field
  };
}

/**
 * Version 2 of the UserSignedUp event schema.
 * Introduced to support fine-grained profile personalization (firstName/lastName).
 */
export interface UserSignedUpV2 {
  readonly eventId: string;
  readonly specVersion: 2;
  readonly timestamp: string;
  readonly data: {
    readonly userId: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly defaultWorkspaceId: string; // New required field in V2
  };
}

/**
 * A union type representing any valid historical or current version of the event.
 */
export type AnyUserSignedUpEvent = UserSignedUpV1 | UserSignedUpV2;

/**
 * The current canonical version of the event used by modern application services.
 */
export type CurrentUserSignedUpEvent = UserSignedUpV2;

// ==========================================
// 2. UPCASTER IMPLEMENTATION
// ==========================================

/**
 * Type definition for an upcaster function that takes an event of version N
 * and returns an event of version N + 1.
 */
type EventUpcaster<TInput, TOutput> = (event: TInput) => TOutput;

/**
 * Upcaster from Version 1 to Version 2.
 * 
 * Splits the legacy monolithic "name" string into "firstName" and "lastName",
 * and assigns a default fallback for the newly introduced "defaultWorkspaceId" field.
 * 
 * @param event - The historical V1 event retrieved from the Event Store.
 * @returns A fully compliant V2 event structure.
 */
export const upcastUserSignedUpV1ToV2: EventUpcaster<UserSignedUpV1, UserSignedUpV2> = (event) => {
  // Defensive splitting of the legacy name string
  const nameParts = event.data.name.trim().split(/\s+/);
  const firstName = nameParts[0] || 'Unknown';
  const lastName = nameParts.slice(1).join(' ') || 'User';

  return {
    eventId: event.eventId,
    specVersion: 2, // Bump the version identifier
    timestamp: event.timestamp,
    data: {
      userId: event.data.userId,
      email: event.data.email,
      firstName,
      lastName,
      defaultWorkspaceId: `ws_default_${event.data.userId}`, // Safe synthetic default
    },
  };
};

// ==========================================
// 3. EVENT STREAM PIPELINE RUNTIME
// ==========================================

/**
 * Orchestrates the reading of raw historical events from persistence 
 * and applies sequential upcasting until the event reaches the target version.
 * 
 * @param rawEvent - Untyped or legacy event fetched from storage.
 * @returns The modern, upcast event ready for domain projection.
 */
export function processAndUpcastEvent(rawEvent: { specVersion: number; [key: string]: any }): CurrentUserSignedUpEvent {
  let event: any = rawEvent;

  // Step-by-step upward migration loop
  while (event.specVersion < 2) {
    switch (event.specVersion) {
      case 1:
        event = upcastUserSignedUpV1ToV2(event as UserSignedUpV1);
        break;
      default:
        throw new Error(`No upcaster defined for specVersion: ${event.specVersion}`);
    }
  }

  return event as CurrentUserSignedUpEvent;
}

// ==========================================
// 4. EXECUTION DEMONSTRATION
// ==========================================

// Mock historical event stored 3 years ago in the database
const historicalV1Event: UserSignedUpV1 = {
  eventId: 'evt_9988776655',
  specVersion: 1,
  timestamp: '2021-06-15T08:30:00.000Z',
  data: {
    userId: 'usr_12345',
    email: 'jane.doe@enterprise-saas.io',
    name: 'Jane Marie Doe',
  },
};

// Execute the upcasting pipeline
console.log('--- BEFORE UPCASTING (V1) ---');
console.log(JSON.stringify(historicalV1Event, null, 2));

const modernEvent = processAndUpcastEvent(historicalV1Event);

console.log('--- AFTER UPCASTING (V2) ---');
console.log(JSON.stringify(modernEvent, null, 2));
