/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';

/**
 * @file BillingEventEvolutionService.ts
 * @description Demonstrates schema evolution, runtime validation, and upcasting 
 * for SaaS subscription domain events using TypeScript and Zod.
 */

// ==========================================
// 1. EVENT SCHEMA DEFINITIONS (VERSIONS 1 & 2)
// ==========================================

/**
 * Schema for V1 Subscription Created Event.
 * Represents the legacy structure where pricing was a flat integer amount
 * and currency was assumed to be USD implicitly.
 */
export const SubscriptionCreatedV1Schema = z.object({
  eventId: z.string().uuid(),
  eventType: z.literal('SubscriptionCreated'),
  version: z.literal(1),
  occurredAt: z.string().datetime(),
  data: z.object({
    subscriptionId: z.string(),
    customerId: z.string(),
    amountInCents: z.number().int().positive(),
  }),
});

export type SubscriptionCreatedV1 = z.infer<typeof SubscriptionCreatedV1Schema>;

/**
 * Schema for V2 Subscription Created Event.
 * Introduces explicit multi-currency support, tax calculations, 
 * and a structured metadata object.
 */
export const SubscriptionCreatedV2Schema = z.object({
  eventId: z.string().uuid(),
  eventType: z.literal('SubscriptionCreated'),
  version: z.literal(2),
  occurredAt: z.string().datetime(),
  data: z.object({
    subscriptionId: z.string(),
    customerId: z.string(),
    pricing: z.object({
      amount: z.number().int().positive(),
      currency: z.string().length(3), // ISO 4217 currency code
    }),
    taxInclusive: z.boolean(),
    metadata: z.record(z.string(), z.string()).optional(),
  }),
});

export type SubscriptionCreatedV2 = z.infer<typeof SubscriptionCreatedV2Schema>;

/**
 * Union type representing any version of the SubscriptionCreated event 
 * that might reside in the Event Store.
 */
export type AnySubscriptionCreatedEvent = SubscriptionCreatedV1 | SubscriptionCreatedV2;


// ==========================================
// 2. UPCASTER IMPLEMENTATION
// ==========================================

/**
 * Upcaster function to transform a V1 subscription event into a V2 event.
 * Ensures backward compatibility by supplying sensible defaults for new required fields.
 * 
 * @param event - The validated V1 event payload
 * @returns A fully compliant V2 event payload
 */
export function upcastV1ToV2(event: SubscriptionCreatedV1): SubscriptionCreatedV2 {
  console.info(`[Upcaster] Upcasting SubscriptionCreated event ${event.eventId} from v1 to v2...`);
  
  return {
    eventId: event.eventId,
    eventType: 'SubscriptionCreated',
    version: 2,
    occurredAt: event.occurredAt,
    data: {
      subscriptionId: event.data.subscriptionId,
      customerId: event.data.customerId,
      pricing: {
        amount: event.data.amountInCents,
        currency: 'USD', // Default assumption for legacy v1 payloads
      },
      taxInclusive: false, // Default historical baseline
      metadata: {
        migratedFromVersion: '1',
      },
    },
  };
}


// ==========================================
-- 3. EVENT PIPELINE & DISPATCHER
// ==========================================

/**
 * Processes an raw incoming event payload retrieved from the event store or message broker.
 * Dynamically validates the schema based on the version header and upcasts if necessary.
 * 
 * @param rawEvent - The unknown incoming message payload
 * @returns The normalized V2 domain event ready for projection or consumption
 */
export function processIncomingEvent(rawEvent: unknown): SubscriptionCreatedV2 {
  // Step A: Inspect version via a lightweight validator or structural check
  const baseCheck = z.object({ version: z.number() }).safeParse(rawEvent);
  
  if (!baseCheck.success) {
    throw new Error(`[EventProcessor] Invalid event structure: ${baseCheck.error.message}`);
  }

  const { version } = baseCheck.data;

  // Step B: Route to appropriate version handler and upcast iteratively
  switch (version) {
    case 1: {
      const parsedV1 = SubscriptionCreatedV1Schema.parse(rawEvent);
      return upcastV1ToV2(parsedV1);
    }
    case 2: {
      const parsedV2 = SubscriptionCreatedV2Schema.parse(rawEvent);
      console.info(`[EventProcessor] Processed native v2 event: ${parsedV2.eventId}`);
      return parsedV2;
    }
    default:
      throw new Error(`[EventProcessor] Unsupported event version: ${version}`);
  }
}


// ==========================================
// 4. SIMULATED EXECUTION BLOCK
// ==========================================

// Simulate fetching a legacy V1 event from historical event store storage
const historicalV1EventStreamItem = {
  eventId: "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d",
  eventType: "SubscriptionCreated",
  version: 1,
  occurredAt: new Date().toISOString(),
  data: {
    subscriptionId: "sub_998877",
    customerId: "cust_112233",
    amountInCents: 4900,
  },
};

// Execute processing pipeline
try {
  const normalizedEvent = processIncomingEvent(historicalV1EventStreamItem);
  console.log("Successfully normalized event to V2 format:", JSON.stringify(normalizedEvent, null, 2));
} catch (error) {
  console.error("Failed to process event stream item:", error);
}
