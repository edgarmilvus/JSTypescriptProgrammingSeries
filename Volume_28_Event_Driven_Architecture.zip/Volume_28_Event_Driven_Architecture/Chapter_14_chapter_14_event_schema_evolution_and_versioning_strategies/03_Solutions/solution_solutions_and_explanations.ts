/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define Schemas for V1, V2, and V3
export const OrderPlacedV1Schema = z.object({
  specVersion: z.literal(1),
  eventId: z.string().uuid(),
  aggregateId: z.string().uuid(),
  timestamp: z.string().datetime(),
  data: z.object({
    orderId: z.string(),
    totalAmount: z.number().int(), // Cents
  }),
});
export type OrderPlacedV1 = z.infer<typeof OrderPlacedV1Schema>;

export const OrderPlacedV2Schema = z.object({
  specVersion: z.literal(2),
  eventId: z.string().uuid(),
  aggregateId: z.string().uuid(),
  timestamp: z.string().datetime(),
  data: z.object({
    orderId: z.string(),
    totalAmount: z.string(), // Localized string representation
    shippingAddress: z.object({
      street: z.string(),
      city: z.string(),
      zipCode: z.string(),
    }),
  }),
});
export type OrderPlacedV2 = z.infer<typeof OrderPlacedV2Schema>;

export const OrderPlacedV3Schema = z.object({
  specVersion: z.literal(3),
  eventId: z.string().uuid(),
  aggregateId: z.string().uuid(),
  timestamp: z.string().datetime(),
  data: z.object({
    orderId: z.string(),
    totalAmount: z.string(),
    currency: z.string().default('USD'),
    shippingAddress: z.object({
      street: z.string(),
      city: z.string(),
      zipCode: z.string(),
      validationHash: z.string(),
    }),
    customerProfile: z.object({
      customerId: z.string(),
      tier: z.string(),
    }),
  }),
});
export type OrderPlacedV3 = z.infer<typeof OrderPlacedV3Schema>;

// 2. Discrete Upcasters
export function upcastV1ToV2(event: OrderPlacedV1): OrderPlacedV2 {
  const dollars = (event.data.totalAmount / 100).toFixed(2);
  return {
    specVersion: 2,
    eventId: event.eventId,
    aggregateId: event.aggregateId,
    timestamp: event.timestamp,
    data: {
      orderId: event.data.orderId,
      totalAmount: dollars,
      shippingAddress: {
        street: 'Unknown Street',
        city: 'Unknown City',
        zipCode: '00000',
      },
    },
  };
}

export function upcastV2ToV3(event: OrderPlacedV2): OrderPlacedV3 {
  return {
    specVersion: 3,
    eventId: event.eventId,
    aggregateId: event.aggregateId,
    timestamp: event.timestamp,
    data: {
      orderId: event.data.orderId,
      totalAmount: event.data.totalAmount,
      currency: 'USD',
      shippingAddress: {
        ...event.data.shippingAddress,
        validationHash: 'legacy-hash-placeholder',
      },
      customerProfile: {
        customerId: 'anonymous-legacy-customer',
        tier: 'STANDARD',
      },
    },
  };
}

// 3. Composition Pipeline
export function upcastEvent(rawEvent: unknown): OrderPlacedV3 {
  // Check specVersion via lightweight peek
  const peekSchema = z.object({ specVersion: z.number() });
  const peekResult = peekSchema.safeParse(rawEvent);

  if (!peekResult.success) {
    throw new Error(`Invalid event payload structure: ${peekResult.error.message}`);
  }

  const { specVersion } = peekResult.data;

  if (specVersion === 3) {
    return OrderPlacedV3Schema.parse(rawEvent);
  }

  if (specVersion === 2) {
    const v2Event = OrderPlacedV2Schema.parse(rawEvent);
    return upcastV2ToV3(v2Event);
  }

  if (specVersion === 1) {
    const v1Event = OrderPlacedV1Schema.parse(rawEvent);
    const v2Event = upcastV1ToV2(v1Event);
    return upcastV2ToV3(v2Event);
  }

  throw new Error(`Unsupported event specification version: ${specVersion}`);
}
