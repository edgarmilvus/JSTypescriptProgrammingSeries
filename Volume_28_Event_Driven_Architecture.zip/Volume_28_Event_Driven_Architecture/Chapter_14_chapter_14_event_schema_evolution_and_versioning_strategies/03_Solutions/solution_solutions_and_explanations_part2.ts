/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const UserRegisteredV1Schema = z.object({
  version: z.literal('1.0'),
  userId: z.string(),
  email: z.string().email(),
  registeredAt: z.string(),
});

export const UserRegisteredV2Schema = z.object({
  version: z.literal('2.0'),
  userId: z.string(),
  email: z.string().email(),
  registeredAt: z.string(),
  marketingPreferences: z.object({
    newsletter: z.boolean(),
    sms: z.boolean(),
  }).optional(),
  referralSource: z.string().optional(),
});

type NormalizedUserEvent = z.infer<typeof UserRegisteredV2Schema>;

export function handleUserRegisteredEvent(payload: unknown): NormalizedUserEvent {
  // 1. Attempt V2 parsing with strict stripping of unknown keys (Forward Compatibility)
  const v2Result = UserRegisteredV2Schema.passthrough().safeParse(payload);
  if (v2Result.success) {
    // If it's already v2 (or v3+ with extra fields stripped by Zod), return normalized
    return {
      version: '2.0',
      userId: v2Result.data.userId,
      email: v2Result.data.email,
      registeredAt: v2Result.data.registeredAt,
      marketingPreferences: v2Result.data.marketingPreferences,
      referralSource: v2Result.data.referralSource,
    };
  }

  // 2. Attempt V1 parsing (Backward Compatibility)
  const v1Result = UserRegisteredV1Schema.safeParse(payload);
  if (v1Result.success) {
    console.warn(
      `[Compatibility Warning]: Processed legacy v1 UserRegistered event for user ${v1Result.data.userId}. Producer migration or upcaster registration recommended.`
    );
    
    // Structurally augment v1 payload to conform to normalized v2 shape
    return {
      version: '2.0',
      userId: v1Result.data.userId,
      email: v1Result.data.email,
      registeredAt: v1Result.data.registeredAt,
      marketingPreferences: {
        newsletter: false,
        sms: false,
      },
      referralSource: 'direct_legacy',
    };
  }

  throw new Error('Validation failed: Payload matches neither UserRegistered v1 nor v2 contracts.');
}
