/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export interface PersistedEventRecord {
  eventId: string;
  aggregateId: string;
  eventType: string;
  specVersion: number;
  payload: string; // JSON stringified data
  createdAt: Date;
}

export class VersionedEventRepository {
  private store: PersistedEventRecord[] = [];
  private upcasterRegistry = new Map<string, Map<number, (data: any) => any>>();

  constructor() {
    // Register an upcaster for OrderPlaced v1 -> v2
    this.registerUpcaster('OrderPlaced', 1, (data) => ({
      ...data,
      specVersion: 2,
      totalAmount: (data.totalAmount / 100).toFixed(2),
      shippingAddress: { street: 'Default St', city: 'Default City', zipCode: '00000' }
    }));
  }

  public registerUpcaster(eventType: string, fromVersion: number, upcasterFn: (data: any) => any): void {
    if (!this.upcasterRegistry.has(eventType)) {
      this.upcasterRegistry.set(eventType, new Map());
    }
    this.upcasterRegistry.get(eventType)!.set(fromVersion, upcasterFn);
  }

  async appendEvent(aggregateId: string, eventType: string, version: number, data: unknown): Promise<void> {
    const record: PersistedEventRecord = {
      eventId: crypto.randomUUID(),
      aggregateId,
      eventType,
      specVersion: version,
      payload: JSON.stringify(data),
      createdAt: new Date(),
    };

    // Simulate dual-write persistence execution
    this.store.push(record);
  }

  async getStream(aggregateId: string, targetVersion?: number): Promise<unknown[]> {
    const streamRecords = this.store.filter((r) => r.aggregateId === aggregateId);
    const hydratedEvents: unknown[] = [];

    for (const record of streamRecords) {
      let currentData = JSON.parse(record.payload);
      let currentVersion = record.specVersion;

      // If a target version is requested and is higher than stored version, upcast sequentially
      if (targetVersion && targetVersion > currentVersion) {
        const eventUpcasters = this.upcasterRegistry.get(record.eventType);
        
        while (eventUpcasters && currentVersion < targetVersion) {
          const upcaster = eventUpcasters.get(currentVersion);
          if (!upcaster) {
            throw new Error(`Missing upcaster path for ${record.eventType} from version ${currentVersion}`);
          }
          currentData = upcaster(currentData);
          currentVersion++;
        }
      }

      hydratedEvents.push({
        eventId: record.eventId,
        aggregateId: record.aggregateId,
        eventType: record.eventType,
        specVersion: currentVersion,
        data: currentData,
        createdAt: record.createdAt,
      });
    }

    return hydratedEvents;
  }
}
