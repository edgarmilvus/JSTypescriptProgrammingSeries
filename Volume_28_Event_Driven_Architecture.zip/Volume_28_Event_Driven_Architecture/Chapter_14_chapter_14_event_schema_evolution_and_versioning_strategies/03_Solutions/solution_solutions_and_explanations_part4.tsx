/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';
import { z } from 'zod';

const TelemetryMessageSchema = z.object({
  eventId: z.string().uuid(),
  eventType: z.string(),
  detectedVersion: z.number().int().positive(),
  producerId: z.string(),
  timestamp: z.string(),
});

type TelemetryMessage = z.infer<typeof TelemetryMessageSchema>;

export const EventTelemetryStreamer: React.FC = () => {
  const [connectionStatus, setConnectionStatus] = useState<'Connecting' | 'Connected' | 'Disconnected'>('Connecting');
  const [versionCounts, setVersionCounts] = useState<Record<number, number>>({ 1: 0, 2: 0, 3: 0 });
  const [recentEvents, setRecentEvents] = useState<TelemetryMessage[]>([]);

  useEffect(() => {
    const eventSource = new EventSource('/api/telemetry/events');

    eventSource.onopen = () => {
      setConnectionStatus('Connected');
    };

    eventSource.onmessage = (event) => {
      try {
        const rawData = JSON.parse(event.data);
        const parsedMessage = TelemetryMessageSchema.parse(rawData);

        setVersionCounts((prev) => ({
          ...prev,
          [parsedMessage.detectedVersion]: (prev[parsedMessage.detectedVersion] || 0) + 1,
        }));

        setRecentEvents((prev) => [parsedMessage, ...prev.slice(0, 9)]);
      } catch (err) {
        console.error('Failed to parse incoming telemetry packet:', err);
      }
    };

    eventSource.onerror = () => {
      setConnectionStatus('Disconnected');
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-lg">
      <header className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold tracking-tight">Event Schema Telemetry Monitor</h2>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          connectionStatus === 'Connected' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
        }`}>
          {connectionStatus}
        </span>
      </header>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-sm text-slate-400">Version 1 (Legacy)</p>
          <p className="text-3xl font-extrabold text-amber-400">{versionCounts[1]}</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-sm text-slate-400">Version 2 (Transition)</p>
          <p className="text-3xl font-extrabold text-sky-400">{versionCounts[2]}</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
          <p className="text-sm text-slate-400">Version 3 (Current)</p>
          <p className="text-3xl font-extrabold text-emerald-400">{versionCounts[3]}</p>
        </div>
      </div>

      <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
        <div className="px-4 py-3 bg-slate-750 border-b border-slate-700 font-medium text-sm text-slate-300">
          Live Stream Feed
        </div>
        <div className="divide-y divide-slate-700 max-h-64 overflow-y-auto font-mono text-xs">
          {recentEvents.length === 0 ? (
            <div className="p-4 text-center text-slate-500">Waiting for incoming telemetry packets...</div>
          ) : (
            recentEvents.map((ev, index) => (
              <div key={index} className="p-3 flex justify-between items-center hover:bg-slate-750/50">
                <span>{ev.eventType} (v{ev.detectedVersion})</span>
                <span className="text-slate-400">{ev.producerId}</span>
                <span className="text-slate-500">{new Date(ev.timestamp).toLocaleTimeString()}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
