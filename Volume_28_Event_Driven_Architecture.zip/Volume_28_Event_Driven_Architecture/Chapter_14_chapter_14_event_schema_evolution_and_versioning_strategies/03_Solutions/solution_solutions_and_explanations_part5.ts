/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export interface SchemaDiffReport {
  isBackwardCompatible: boolean;
  breakingChanges: string[];
  nonBreakingChanges: string[];
}

export function compareEventSchemas(
  oldSchema: z.ZodObject<any>,
  newSchema: z.ZodObject<any>
): SchemaDiffReport {
  const breakingChanges: string[] = [];
  const nonBreakingChanges: string[] = [];

  const oldShape = oldSchema.shape;
  const newShape = newSchema.shape;

  const oldKeys = Object.keys(oldShape);
  const newKeys = Object.keys(newShape);

  // 1. Check for missing keys (Breaking Change)
  for (const key of oldKeys) {
    if (!newKeys.includes(key)) {
      breakingChanges.push(`Property '${key}' was removed from the schema.`);
    }
  }

  // 2. Check for added keys (Non-Breaking Change if optional, Breaking if required without default)
  for (const key of newKeys) {
    if (!oldKeys.includes(key)) {
      const newField = newShape[key];
      const isOptional = newField.isOptional() || newField.isNullable();
      
      if (isOptional) {
        nonBreakingChanges.push(`Optional property '${key}' was added.`);
      } else {
        breakingChanges.push(`Required property '${key}' was added without fallback defaults.`);
      }
    }
  }

  // 3. Check for type modifications on common keys
  for (const key of oldKeys) {
    if (newKeys.includes(key)) {
      const oldType = oldShape[key]._def.typeName;
      const newType = newShape[key]._def.typeName;

      if (oldType !== newType) {
        breakingChanges.push(`Property '${key}' changed type from ${oldType} to ${newType}.`);
      }
    }
  }

  return {
    isBackwardCompatible: breakingChanges.length === 0,
    breakingChanges,
    nonBreakingChanges,
  };
}
