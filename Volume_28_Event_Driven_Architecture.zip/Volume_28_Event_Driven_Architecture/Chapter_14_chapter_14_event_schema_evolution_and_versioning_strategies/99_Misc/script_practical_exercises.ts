/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { z } from 'zod';

// TODO: Define your Zod schemas for v1, v2, and v3 here.
// Remember to include metadata such as eventId, aggregateId, timestamp, and specVersion.

export const OrderPlacedV1Schema = z.object({
  specVersion: z.literal(1),
  eventId: z.string().uuid(),
  aggregateId: z.string().uuid(),
  timestamp: z.string().datetime(),
  data: z.object({
    orderId: z.string(),
    totalAmount: z.number().int(), // Cents
  }),
});

export type OrderPlacedV1 = z.infer<typeof OrderPlacedV1Schema>;

// Define V2 and V3 schemas below...

export function upcastV1ToV2(event: OrderPlacedV1): any {
  // TODO: Implement transformation logic from v1 to v2
}

export function upcastV2ToV3(event: any): any {
  // TODO: Implement transformation logic from v2 to v3
}

export function upcastEvent(rawEvent: unknown): any {
  // TODO: Inspect rawEvent, validate its initial shape, and execute the upcaster chain.
}
