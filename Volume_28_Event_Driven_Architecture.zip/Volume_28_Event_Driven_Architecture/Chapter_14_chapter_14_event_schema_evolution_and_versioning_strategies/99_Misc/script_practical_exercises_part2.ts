/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { z } from 'zod';

// TODO: Define your v1 and v2 schemas for UserRegistered.

export const UserRegisteredV1Schema = z.object({
  version: z.literal('1.0'),
  userId: z.string(),
  email: z.string().email(),
  registeredAt: z.string(),
});

export const UserRegisteredV2Schema = z.object({
  version: z.literal('2.0'),
  userId: z.string(),
  email: z.string().email(),
  registeredAt: z.string(),
  marketingPreferences: z.object({
    newsletter: z.boolean(),
    sms: z.boolean(),
  }).optional(),
  referralSource: z.string().optional(),
});

type NormalizedUserEvent = z.infer<typeof UserRegisteredV2Schema>;

export function handleUserRegisteredEvent(payload: unknown): NormalizedUserEvent {
  // TODO: Implement safe parsing, backward compatibility mapping (v1 -> normalized v2),
  // and forward compatibility handling (ignoring unknown keys).
  throw new Error('Not implemented');
}
