/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file dlq-resilience-pipeline.ts
 * @description A production-grade, self-contained TypeScript implementation of an 
 * event processing pipeline featuring Exponential Backoff Retries and a Dead-Letter Queue (DLQ).
 * 
 * Target Context: SaaS Web Application Webhook Dispatcher
 */

import { randomUUID } from 'crypto';

// ============================================================================
// DOMAIN TYPES & INTERFACES (Strict Type Discipline Enforcement)
// ============================================================================

/**
 * Represents the status lifecycle of an asynchronous event within the SaaS pipeline.
 */
type EventStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'DLQ';

/**
 * Represents the structure of a multi-tenant SaaS webhook event.
 */
interface WebhookEvent {
  readonly id: string;
  readonly tenantId: string;
  readonly eventType: string;
  readonly payload: Record<string, unknown>;
  retryCount: number;
  readonly createdAt: number;
}

/**
 * Represents the dead-letter payload stored when an event permanently fails.
 */
interface DeadLetterRecord {
  readonly dlqId: string;
  readonly originalEvent: WebhookEvent;
  readonly failureReason: string;
  readonly stackTrace: string;
  readonly failedAt: number;
}

/**
 * Configuration parameters for the retry and error recovery strategy.
 */
interface PipelineConfig {
  readonly maxRetries: number;
  readonly baseBackoffMs: number;
  readonly maxBackoffMs: number;
}

// ============================================================================
// IN-MEMORY INFRASTRUCTURE MOCKS (Simulating Event Bus & DLQ Storage)
// ============================================================================

/**
 * Mock database storage for Dead-Letter Queue persistence.
 */
class DeadLetterQueueStore {
  private readonly storage: Map<string, DeadLetterRecord> = new Map();

  /**
   * Persists a poisoned event to the DLQ.
   */
  public async save(record: DeadLetterRecord): Promise<void> {
    // Simulating asynchronous I/O overhead (e.g., PostgreSQL/DynamoDB write)
    await new Promise((resolve) => setTimeout(resolve, 15));
    this.storage.set(record.dlqId, record);
    console.log(`[DLQ Storage] CRITICAL: Event ${record.originalEvent.id} successfully isolated to DLQ under ID ${record.dlqId}`);
  }

  /**
   * Retrieves all records currently quarantined in the DLQ for administrative audit.
   */
  public async getAll(): Promise<ReadonlyArray<DeadLetterRecord>> {
    await new Promise((resolve) => setTimeout(resolve, 10));
    return Array.from(this.storage.values());
  }
}

// ============================================================================
// CORE PIPELINE PROCESSOR
// ============================================================================

/**
 * Handles the end-to-end execution, error interception, retry scheduling, 
 * and DLQ routing for SaaS webhooks.
 */
class WebhookPipelineProcessor {
  private readonly dlqStore: DeadLetterQueueStore;
  private readonly config: PipelineConfig;

  constructor(dlqStore: DeadLetterQueueStore, config: PipelineConfig) {
    this.dlqStore = dlqStore;
    this.config = config;
  }

  /**
   * Calculates exponential backoff delay with jitter to prevent thundering herd problems.
   * 
   * Formula: base * (2 ^ retryCount) + random_jitter
   */
  private calculateBackoff(retryCount: number): number {
    const exponentialFactor = Math.pow(2, retryCount);
    const calculatedDelay = this.config.baseBackoffMs * exponentialFactor;
    const boundedDelay = Math.min(calculatedDelay, this.config.maxBackoffMs);
    // Add 10-20ms of jitter
    const jitter = Math.random() * 20;
    return Math.floor(boundedDelay + jitter);
  }

  /**
   * Simulates a downstream API call that may fail intermittently.
   */
  private async dispatchToDownstreamService(event: WebhookEvent): Promise<void> {
    // Simulate unpredictable external API behavior (70% failure rate for demonstration)
    const isUnstableNetworkFailure = Math.random() < 0.70;
    
    if (isUnstableNetworkFailure) {
      throw new Error(`[Downstream Error] HTTP 503: Service Unavailable while dispatching event type '${event.eventType}' for tenant '${event.tenantId}'.`);
    }

    // Success path
    console.log(`[Downstream Service] SUCCESS: Event ${event.id} processed successfully.`);
  }

  /**
   * Processes an incoming event with exhaustive asynchronous resilience, handling 
   * retries, backoff delays, and terminal routing to the Dead-Letter Queue.
   * 
   * @param event The webhook event to process.
   */
  public async processEvent(event: WebhookEvent): Promise<EventStatus> {
    let currentStatus: EventStatus = 'PROCESSING';

    try {
      console.log(`[Pipeline] Processing event ID: ${event.id} (Attempt ${event.retryCount + 1}/${this.config.maxRetries + 1})`);
      
      // Execute primary asynchronous operation
      await this.dispatchToDownstreamService(event);
      
      currentStatus = 'COMPLETED';
      return currentStatus;

    } catch (error: unknown) {
      // Exhaustive Asynchronous Resilience: Type-guarding the caught error safely
      const err = error instanceof Error ? error : new Error(String(error));
      
      console.warn(`[Pipeline Warning] Execution failed for event ${event.id}: ${err.message}`);

      // Evaluate if the event can be retried or must be routed to the DLQ
      if (event.retryCount < this.config.maxRetries) {
        event.retryCount++;
        const backoffDelay = this.calculateBackoff(event.retryCount);
        
        console.log(`[Pipeline] Scheduling retry #${event.retryCount} for event ${event.id} in ${backoffDelay}ms...`);
        
        // Wait for the computed backoff period before recursively retrying
        await new Promise((resolve) => setTimeout(resolve, backoffDelay));
        
        // Recursive retry call
        return await this.processEvent(event);
      } else {
        // Max retries exceeded: Route to Dead-Letter Queue
        currentStatus = 'DLQ';
        console.error(`[Pipeline Error] MAX RETRIES EXCEEDED. Routing event ${event.id} to Dead-Letter Queue.`);
        
        const deadLetterRecord: DeadLetterRecord = {
          dlqId: randomUUID(),
          originalEvent: event,
          failureReason: err.message,
          stackTrace: err.stack ?? 'No stack trace available',
          failedAt: Date.now(),
        };

        // Persist to DLQ store
        await this.dlqStore.save(deadLetterRecord);
        return currentStatus;
      }
    } finally {
      // Guaranteed resource cleanup / metrics logging block
      console.log(`[Pipeline Finalizer] Execution context closed for event ${event.id}. Final Status Recorded: ${currentStatus}\n`);
    }
  }
}

// ============================================================================
// EXECUTION ENTRYPOINT (Simulation)
// ============================================================================

async function runSaaSApplicationDemo(): Promise<void> {
  console.log('=== STARTING SAAS WEBHOOK PIPELINE DEMO WITH DLQ ISOLATION ===\n');

  const dlqStore = new DeadLetterQueueStore();
  const pipelineConfig: PipelineConfig = {
    maxRetries: 3,
    baseBackoffMs: 50, // Shortened for rapid demonstration
    maxBackoffMs: 500,
  };

  const processor = new WebhookPipelineProcessor(dlqStore, pipelineConfig);

  // Construct a mock incoming SaaS webhook payload
  const incomingWebhook: WebhookEvent = {
    id: randomUUID(),
    tenantId: 'tenant_enterprise_99',
    eventType: 'invoice.payment_succeeded',
    payload: {
      invoiceId: 'inv_1029384756',
      amountDueUSD: 499.00,
      customerEmail: 'ceo@enterprise.com',
    },
    retryCount: 0,
    createdAt: Date.now(),
  };

  // Process the event through the resilient pipeline
  const finalOutcome = await processor.processEvent(incomingWebhook);
  console.log(`=== PIPELINE EXECUTION COMPLETED WITH STATUS: ${finalOutcome} ===\n`);

  // Inspect the Dead-Letter Queue state if failure occurred
  const allDlqRecords = await dlqStore.getAll();
  if (allDlqRecords.length > 0) {
    console.log('--- AUDITING DEAD-LETTER QUEUE (DLQ) CONTENTS ---');
    console.log(JSON.stringify(allDlqRecords, null, 2));
  } else {
    console.log('--- DEAD-LETTER QUEUE (DLQ) IS EMPTY (Event processed successfully during retries) ---');
  }
}

// Execute the simulation
runSaaSApplicationDemo().catch((fatalError: unknown) => {
  console.error('Fatal unhandled error in SaaS application demo:', fatalError);
});
