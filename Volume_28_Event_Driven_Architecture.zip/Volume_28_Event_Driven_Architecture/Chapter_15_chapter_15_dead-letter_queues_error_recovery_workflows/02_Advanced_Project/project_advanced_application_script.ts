/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * Represents the structure of any domain event flowing through the event-driven architecture.
 */
interface DomainEvent<T = Record<string, unknown>> {
  readonly id: string;
  readonly type: string;
  readonly timestamp: number;
  readonly payload: T;
  readonly metadata: {
    readonly correlationId: string;
    readonly retryCount: number;
    readonly originalQueue: string;
  };
}

/**
 * Result of a message processing attempt.
 */
type ProcessingResult = 
  | { readonly status: 'SUCCESS' }
  | { readonly status: 'RETRYABLE_ERROR'; readonly error: Error }
  | { readonly status: 'POISON_MESSAGE'; readonly error: Error };

/**
 * In-memory broker simulation for queues and DLQs.
 */
class EventBrokerStore {
  private static queues: Map<string, DomainEvent[]> = new Map();
  private static dlqs: Map<string, DomainEvent[]> = new Map();

  /**
   * Pushes an event onto a standard queue.
   */
  public static async publish(queueName: string, event: DomainEvent): Promise<void> {
    const queue = this.queues.get(queueName) ?? [];
    queue.push(event);
    this.queues.set(queueName, queue);
  }

  /**
   * Routes a terminally failed event to the Dead-Letter Queue.
   */
  public static async sendToDLQ(dlqName: string, event: DomainEvent, reason: string): Promise<void> {
    const dlq = this.dlqs.get(dlqName) ?? [];
    const poisonedEvent: DomainEvent = {
      ...event,
      metadata: {
        ...event.metadata,
        originalQueue: dlqName,
      }
    };
    dlq.push(poisonedEvent);
    this.dlqs.set(dlqName, dlq);
    console.warn(`[DLQ ROUTER]: Event ${event.id} routed to DLQ '${dlqName}'. Reason: ${reason}`);
  }

  public static async getDLQMessages(dlqName: string): readonly DomainEvent[] {
    return this.dlqs.get(dlqName) ?? [];
  }

  public static async clearDLQ(dlqName: string): Promise<void> {
    this.dlqs.delete(dlqName);
  }
}

/**
 * Resilient Event Processor with Exponential Backoff and DLQ Fallback.
 */
class ResilientEventProcessor {
  private readonly maxRetries: number = 3;
  private readonly baseBackoffMs: number = 100;

  /**
   * Simulates processing an event with potential failures.
   */
  private async processPayload(event: DomainEvent): Promise<void> {
    // Simulate intermittent failure for demonstration purposes
    if (event.payload.shouldFail === true) {
      throw new Error('Transient Database Connection Timeout');
    }
    if (event.payload.isPoison === true) {
      throw new TypeError('Malformed Schema: Missing mandatory billing profile');
    }
  }

  /**
   * Executes the event handling lifecycle with Exhaustive Asynchronous Resilience.
   */
  public async handleMessage(queueName: string, event: DomainEvent): Promise<ProcessingResult> {
    let attempt = event.metadata.retryCount;

    while (attempt <= this.maxRetries) {
      try {
        // Exhaustive Asynchronous Resilience: Mandatory try/catch wrapping
        await this.processPayload(event);
        return { status: 'SUCCESS' };
      } catch (error: unknown) {
        const err = error instanceof Error ? error : new Error(String(error));
        
        // Differentiate between schema poison pills and transient infrastructure errors
        if (err instanceof TypeError) {
          return { status: 'POISON_MESSAGE', error: err };
        }

        attempt++;
        if (attempt > this.maxRetries) {
          return { status: 'RETRYABLE_ERROR', error: err };
        }

        // Calculate Exponential Backoff: base * 2^attempt
        const backoffTime = this.baseBackoffMs * Math.pow(2, attempt);
        console.warn(`[RETRY]: Attempt ${attempt} failed for event ${event.id}. Retrying in ${backoffTime}ms...`);
        await new Promise((resolve) => setTimeout(resolve, backoffTime));
      } finally {
        // Guaranteed execution block for resource clean-up or telemetry emission
        console.debug(`[TELEMETRY]: Execution lifecycle finished for event ID: ${event.id}`);
      }
    }

    return { 
      status: 'RETRYABLE_ERROR', 
      error: new Error('Max retry attempts exhausted without explicit termination.') 
    };
  }

  /**
   * Orchestrates the consumer loop, routing failures to the DLQ automatically.
   */
  public async consumeAndProtect(queueName: string, dlqName: string, event: DomainEvent): Promise<void> {
    try {
      const result = await this.handleMessage(queueName, event);

      if (result.status === 'POISON_MESSAGE' || result.status === 'RETRYABLE_ERROR') {
        await EventBrokerStore.sendToDLQ(dlqName, event, result.error.message);
      }
    } catch (criticalError: unknown) {
      // Catch-all for unhandled exceptions inside the worker infrastructure
      const err = criticalError instanceof Error ? criticalError : new Error(String(criticalError));
      console.error(`[CRITICAL WORKER FAILURE]: ${err.message}`, { eventId: event.id });
      await EventBrokerStore.sendToDLQ(dlqName, event, `Critical Worker Crash: ${err.message}`);
    }
  }
}

/**
 * Administrative Replay Service for Dead-Letter Queues.
 */
class DLQReplayService {
  /**
   * Replays all messages from a DLQ back to the primary operational queue after a fix is deployed.
   */
  public static async replayDLQ(dlqName: string, targetQueueName: string): Promise<number> {
    const messages = await EventBrokerStore.getDLQMessages(dlqName);
    let replayedCount = 0;

    for (const message of messages) {
      try {
        const resurrectedEvent: DomainEvent = {
          ...message,
          metadata: {
            ...message.metadata,
            retryCount: 0, // Reset retry count for fresh execution pipeline
          }
        };

        await EventBrokerStore.publish(targetQueueName, resurrectedEvent);
        replayedCount++;
      } catch (error: unknown) {
        const err = error instanceof Error ? error : new Error(String(error));
        console.error(`[REPLAY ERROR]: Failed to re-enqueue message ${message.id}: ${err.message}`);
      }
    }

    // Flush the DLQ after successful re-queueing
    await EventBrokerStore.clearDLQ(dlqName);
    console.info(`[REPLAY SUCCESS]: Successfully replayed ${replayedCount} messages from ${dlqName} to ${targetQueueName}`);
    return replayedCount;
  }
}

// ==========================================
// EXECUTION DEMONSTRATION
// ==========================================
async function runDemo() {
  const processor = new ResilientEventProcessor();
  const queueName = 'billing-events';
  const dlqName = 'billing-events-dlq';

  // 1. Create a poison message (missing schema properties)
  const poisonEvent: DomainEvent = {
    id: randomUUID(),
    type: 'USER_BILLED',
    timestamp: Date.now(),
    payload: { isPoison: true },
    metadata: { correlationId: randomUUID(), retryCount: 0, originalQueue: queueName }
  };

  // 2. Consume and protect
  console.log('--- Processing Poison Message ---');
  await processor.consumeAndProtect(queueName, dlqName, poisonEvent);

  // 3. Inspect DLQ
  const dlqMessages = await EventBrokerStore.getDLQMessages(dlqName);
  console.log(`DLQ Current Depth: ${dlqMessages.length}`);

  // 4. Trigger Administrative Replay
  console.log('--- Triggering DLQ Replay ---');
  await DLQReplayService.replayDLQ(dlqName, queueName);
}

runDemo().catch(console.error);
