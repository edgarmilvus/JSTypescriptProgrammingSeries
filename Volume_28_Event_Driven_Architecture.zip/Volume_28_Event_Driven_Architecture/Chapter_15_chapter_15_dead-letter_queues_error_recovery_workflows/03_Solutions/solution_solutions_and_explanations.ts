/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 1: Poison Message Trap Implementation
export interface Envelope<T> {
  readonly id: string;
  readonly payload: T;
  readonly attemptCount: number;
  readonly firstFailureTimestamp?: number;
}

export interface RetryPolicy {
  readonly maxRetries: number;
  readonly baseDelayMs: number;
  readonly maxDelayMs: number;
}

export interface DLQRecord<T> {
  readonly originalEnvelope: Envelope<T>;
  readonly errorDetails: {
    readonly message: string;
    readonly stack?: string;
    readonly failedAt: number;
  };
}

export interface MessageBrokerClient {
  publishToDLQ<T>(record: DLQRecord<T>): Promise<void>;
}

export class ResilientConsumer<T> {
  private readonly policy: RetryPolicy;
  private readonly broker: MessageBrokerClient;

  constructor(policy: RetryPolicy, broker: MessageBrokerClient) {
    this.policy = policy;
    this.broker = broker;
  }

  private calculateBackoff(attemptCount: number): number {
    const exponentialDelay = this.policy.baseDelayMs * Math.pow(2, attemptCount - 1);
    const cappedDelay = Math.min(exponentialDelay, this.policy.maxDelayMs);
    // Apply full jitter: random value between 0 and cappedDelay
    const jitteredDelay = Math.random() * cappedDelay;
    return Math.floor(jitteredDelay);
  }

  public async processMessage(
    envelope: Envelope<T>,
    handler: (payload: T) => Promise<void>
  ): Promise<"SUCCESS" | "RETRY_SCHEDULED" | "ROUTED_TO_DLQ"> {
    const startTime = Date.now();
    try {
      await handler(envelope.payload);
      return "SUCCESS";
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      const nextAttemptCount = envelope.attemptCount + 1;

      if (nextAttemptCount > this.policy.maxRetries) {
        const dlqRecord: DLQRecord<T> = {
          originalEnvelope: {
            ...envelope,
            attemptCount: nextAttemptCount,
            firstFailureTimestamp: envelope.firstFailureTimestamp ?? startTime,
          },
          errorDetails: {
            message: err.message,
            stack: err.stack,
            failedAt: Date.now(),
          },
        };

        await this.broker.publishToDLQ(dlqRecord);
        return "ROUTED_TO_DLQ";
      } else {
        const delay = this.calculateBackoff(nextAttemptCount);
        // In a real broker integration, a retry delay mechanism (like delayed exchanges or re-queuing) would be triggered here.
        console.warn(`Retry scheduled for message ${envelope.id} in ${delay}ms (Attempt ${nextAttemptCount}/${this.policy.maxRetries})`);
        return "RETRY_SCHEDULED";
      }
    } finally {
      // Resource cleanup or metrics flushing hooks can be placed here safely
    }
  }
}
