/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 2: Stateful Circuit Breaker Implementation
export type CircuitState = "CLOSED" | "OPEN" | "HALF_OPEN";

export interface CircuitBreakerOptions {
  readonly failureThreshold: number;
  readonly successThreshold: number;
  readonly timeoutDurationMs: number;
}

export class CircuitOpenError extends Error {
  constructor(message: string = "Circuit breaker is OPEN. Execution blocked.") {
    super(message);
    this.name = "CircuitOpenError";
  }
}

export class CircuitBreaker {
  private state: CircuitState = "CLOSED";
  private failureCount: number = 0;
  private successCount: number = 0;
  private nextAttemptTimestamp: number = 0;
  private readonly options: CircuitBreakerOptions;

  constructor(options: CircuitBreakerOptions) {
    this.options = options;
  }

  public async execute<R>(action: () => Promise<R>): Promise<R> {
    const now = Date.now();

    if (this.state === "OPEN") {
      if (now >= this.nextAttemptTimestamp) {
        this.state = "HALF_OPEN";
        this.successCount = 0;
      } else {
        throw new CircuitOpenError(
          `Circuit breaker is OPEN. Fast failing execution until ${new Date(this.nextAttemptTimestamp).toISOString()}`
        );
      }
    }

    try {
      const result = await action();
      this.handleSuccess();
      return result;
    } catch (error) {
      this.handleFailure();
      throw error;
    }
  }

  private handleSuccess(): void {
    if (this.state === "HALF_OPEN") {
      this.successCount++;
      if (this.successCount >= this.options.successThreshold) {
        this.state = "CLOSED";
        this.failureCount = 0;
        this.successCount = 0;
      }
    } else if (this.state === "CLOSED") {
      // Reset failure counter on successful execution in closed state
      this.failureCount = 0;
    }
  }

  private handleFailure(): void {
    this.failureCount++;
    if (this.state === "HALF_OPEN") {
      // Any failure in HALF_OPEN immediately trips the breaker back to OPEN
      this.state = "OPEN";
      this.nextAttemptTimestamp = Date.now() + this.options.timeoutDurationMs;
    } else if (this.state === "CLOSED" && this.failureCount >= this.options.failureThreshold) {
      this.state = "OPEN";
      this.nextAttemptTimestamp = Date.now() + this.options.timeoutDurationMs;
    }
  }
}
