/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 3: Saga Orchestration and Compensation Engine
export interface SagaStep<TContext> {
  readonly name: string;
  execute(context: TContext): Promise<TContext>;
  compensate(context: TContext): Promise<void>;
}

export class SagaCompensationFailedError extends Error {
  constructor(public readonly errors: Array<{ stepName: string; error: unknown }>) {
    super("One or more compensation steps failed during saga rollback.");
    this.name = "SagaCompensationFailedError";
  }
}

export class SagaOrchestrator<TContext> {
  private readonly steps: Array<SagaStep<TContext>> = [];

  public addStep(step: SagaStep<TContext>): this {
    this.steps.push(step);
    return this;
  }

  public async execute(initialContext: TContext): Promise<TContext> {
    let currentContext = initialContext;
    const executedSteps: Array<SagaStep<TContext>> = [];

    try {
      for (const step of this.steps) {
        currentContext = await step.execute(currentContext);
        executedSteps.push(step);
      }
      return currentContext;
    } catch (executionError) {
      const compensationErrors: Array<{ stepName: string; error: unknown }> = [];

      // Iterate in reverse order through successfully executed steps
      for (let i = executedSteps.length - 1; i >= 0; i--) {
        const step = executedSteps[i];
        try {
          await step.compensate(currentContext);
        } catch (compensationError) {
          compensationErrors.push({
            stepName: step.name,
            error: compensationError,
          });
        }
      }

      if (compensationErrors.length > 0) {
        throw new SagaCompensationFailedError(compensationErrors);
      }

      throw executionError;
    }
  }
}
