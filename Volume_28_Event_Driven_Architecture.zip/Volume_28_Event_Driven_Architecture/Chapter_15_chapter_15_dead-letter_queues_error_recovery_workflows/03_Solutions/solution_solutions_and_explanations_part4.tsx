/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// Exercise 4: DLQ Dashboard React TSX Component
import React, { useState, useEffect, useCallback } from "react";

export interface DLQRecordView {
  readonly id: string;
  readonly originalTopic: string;
  readonly errorMessage: string;
  readonly failedAt: number;
  readonly payloadSnippet: string;
}

export interface DLQApiClient {
  fetchRecords(page: number, filter?: string): Promise<ReadonlyArray<DLQRecordView>>;
  replayRecord(recordId: string): Promise<boolean>;
}

export interface DLQDashboardProps {
  readonly apiClient: DLQApiClient;
  readonly pageSize?: number;
}

export const DLQDashboard: React.FC<DLQDashboardProps> = ({ apiClient, pageSize = 10 }) => {
  const [records, setRecords] = useState<ReadonlyArray<DLQRecordView>>([]);
  const [page, setPage] = useState<number>(1);
  const [filterQuery, setFilterQuery] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [replayingIds, setReplayingIds] = useState<ReadonlyArray<string>>([]);

  const loadRecords = useCallback(async () => {
    setIsLoading(true);
    setErrorBanner(null);
    try {
      const data = await apiClient.fetchRecords(page, filterQuery);
      setRecords(data);
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : "Failed to load DLQ records.");
    } finally {
      setIsLoading(false);
    }
  }, [apiClient, page, filterQuery]);

  useEffect(() => {
    loadRecords();
  }, [loadRecords]);

  const handleReplay = async (recordId: string): Promise<void> => {
    setReplayingIds((prev) => [...prev, recordId]);
    setErrorBanner(null);
    try {
      const success = await apiClient.replayRecord(recordId);
      if (success) {
        setRecords((prev) => prev.filter((r) => r.id !== recordId));
      } else {
        setErrorBanner(`Replay mutation rejected for record ${recordId}`);
      }
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : `Error replaying record ${recordId}`);
    } finally {
      setReplayingIds((prev) => prev.filter((id) => id !== recordId));
    }
  };

  return (
    <div className="dlq-dashboard-container" style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h2>Dead-Letter Queue Operations Center</h2>
      
      {errorBanner && (
        <div className="error-banner" style={{ background: "#ffebee", color: "#c62828", padding: "10px", marginBottom: "15px", borderRadius: "4px" }}>
          <strong>Error: </strong> {errorBanner}
        </div>
      )}

      <div className="controls" style={{ marginBottom: "15px" }}>
        <input
          type="text"
          placeholder="Filter by error message..."
          value={filterQuery}
          onChange={(e) => setFilterQuery(e.target.value)}
          style={{ padding: "8px", width: "300px", marginRight: "10px" }}
        />
        <button onClick={loadRecords} disabled={isLoading} style={{ padding: "8px 16px" }}>
          {isLoading ? "Refreshing..." : "Refresh Queue"}
        </button>
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#f5f5f5", textAlign: "left" }}>
            <th style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>ID</th>
            <th style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>Topic</th>
            <th style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>Error Message</th>
            <th style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>Failed At</th>
            <th style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {records.length === 0 && !isLoading ? (
            <tr>
              <td colSpan={5} style={{ textAlign: "center", padding: "20px", color: "#666" }}>
                No dead-letter records found.
              </td>
            </tr>
          ) : (
            records.map((record) => {
              const isReplaying = replayingIds.includes(record.id);
              return (
                <tr key={record.id} style={{ borderBottom: "1px solid #eee" }}>
                  <td style={{ padding: "10px" }}>{record.id}</td>
                  <td style={{ padding: "10px" }}>{record.originalTopic}</td>
                  <td style={{ padding: "10px", color: "#d32f2f" }}>{record.errorMessage}</td>
                  <td style={{ padding: "10px" }}>{new Date(record.failedAt).toLocaleString()}</td>
                  <td style={{ padding: "10px" }}>
                    <button
                      onClick={() => handleReplay(record.id)}
                      disabled={isReplaying}
                      style={{ padding: "6px 12px", background: "#1976d2", color: "#white", border: "none", borderRadius: "4px", cursor: "pointer" }}
                    >
                      {isReplaying ? "Replaying..." : "Replay Message"}
                    </button>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};
