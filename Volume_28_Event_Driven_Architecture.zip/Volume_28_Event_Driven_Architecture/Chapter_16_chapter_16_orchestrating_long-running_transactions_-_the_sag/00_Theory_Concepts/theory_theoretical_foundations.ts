/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph SagaFlow {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f0f4f8", color="#333333"];
    
    subgraph cluster_forward {
        label = "Forward Path (Business Process)";
        style=dashed;
        color="#2b6cb0";
        
        Step1 [label="1. Order Service\nCreate Order (Pending)"];
        Step2 [label="2. Inventory Service\nReserve Stock"];
        Step3 [label="3. Payment Service\nProcess Charge"];
        
        Step1 -> Step2 -> Step3;
    }

    Failure [label="4. Shipping Service\nFAILED: Out of Zone", fillcolor="#fed7d7", color="#c53030"];
    Step3 -> Failure;

    subgraph cluster_compensation {
        label = "Compensating Path (Rollback)";
        style=dashed;
        color="#c53030";
        
        Comp3 [label="Compensate 3:\nRefund Payment", fillcolor="#fed7d7"];
        Comp2 [label="Compensate 2:\nRelease Stock", fillcolor="#fed7d7"];
        Comp1 [label="Compensate 1:\nCancel Order", fillcolor="#fed7d7"];
        
        Comp3 -> Comp2 -> Comp1;
    }

    Failure -> Comp3 [color="#c53030", style=bold, label="Trigger Rollback"];
    Comp3 -> Comp2;
    Comp2 -> Comp1;
}
