/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// Define the possible states of a complex Order Processing Saga
export type OrderSagaState = 
  | 'STARTED'
  | 'INVENTORY_RESERVED'
  | 'PAYMENT_PROCESSED'
  | 'SHIPPING_SCHEDULED'
  | 'COMPLETED'
  | 'COMPENSATING_PAYMENT'
  | 'COMPENSATING_INVENTORY'
  | 'FAILED'
  | 'COMPENSATED';

// Define the domain event and command interfaces
export interface SagaContext {
  sagaId: string;
  orderId: string;
  customerId: string;
  items: Array<{ productId: string; quantity: number; price: number }>;
  totalAmount: number;
  paymentReference?: string;
  shippingTrackingNumber?: string;
  failureReason?: string;
  version: number;
}

export interface SagaStep<TContext> {
  name: string;
  execute(context: TContext): Promise<TContext>;
  compensate(context: TContext): Promise<TContext>;
}

/**
 * Abstract Orchestrator Engine implementing persistent state machine logic
 * with optimistic concurrency control and failure compensation.
 */
export class OrderSagaOrchestrator {
  private steps: Map<OrderSagaState, SagaStep<SagaContext>> = new Map();

  constructor(private readonly stateStore: ISagaStateRepository) {}

  public registerStep(state: OrderSagaState, step: SagaStep<SagaContext>): void {
    this.steps.set(state, step);
  }

  public async startSaga(initialContext: SagaContext): Promise<void> {
    let currentContext = { ...initialContext, version: 1 };
    let currentState: OrderSagaState = 'STARTED';

    await this.stateStore.saveState(currentContext.sagaId, currentState, currentContext);

    const executionPath: OrderSagaState[] = [
      'INVENTORY_RESERVED',
      'PAYMENT_PROCESSED',
      'SHIPPING_SCHEDULED'
    ];

    for (const targetState of executionPath) {
      const step = this.steps.get(targetState);
      if (!step) {
        throw new Error(`No execution step registered for state: ${targetState}`);
      }

      try {
        // Execute forward step
        currentContext = await step.execute(currentContext);
        currentState = targetState;
        await this.stateStore.saveState(currentContext.sagaId, currentState, currentContext);
      } catch (error: any) {
        currentContext.failureReason = error.message;
        await this.handleFailure(currentState, currentContext);
        return;
      }
    }

    // Finalize completion
    await this.stateStore.saveState(currentContext.sagaId, 'COMPLETED', currentContext);
  }

  private async handleFailure(failedState: OrderSagaState, context: SagaContext): Promise<void> {
    console.error(`Saga ${context.sagaId} failed at state ${failedState}. Initiating compensation...`);
    
    // Determine compensation sequence based on where failure occurred
    const compensationSequence = this.getCompensationPath(failedState);

    for (const compensationState of compensationSequence) {
      const step = this.steps.get(compensationState);
      if (step) {
        try {
          context = await step.compensate(context);
          await this.stateStore.saveState(context.sagaId, compensationState, context);
        } catch (compError: any) {
          // Critical operational alert: Compensation failed! Requires human intervention / dead-letter queue.
          console.error(`CRITICAL: Compensation step ${compensationState} failed for Saga ${context.sagaId}:`, compError);
          await this.stateStore.saveState(context.sagaId, 'FAILED', context);
          return;
        }
      }
    }

    await this.stateStore.saveState(context.sagaId, 'COMPENSATED', context);
  }

  private getCompensationPath(failedState: OrderSagaState): OrderSagaState[] {
    switch (failedState) {
      case 'SHIPPING_SCHEDULED':
        return ['COMPENSATING_PAYMENT', 'COMPENSATING_INVENTORY'];
      case 'PAYMENT_PROCESSED':
        return ['COMPENSATING_INVENTORY'];
      case 'INVENTORY_RESERVED':
      default:
        return [];
    }
  }
}

// Mock repository interface representing durable persistence
export interface ISagaStateRepository {
  saveState(sagaId: string, state: OrderSagaState, context: SagaContext): Promise<void>;
  getState(sagaId: string): Promise<{ state: OrderSagaState; context: SagaContext } | null>;
}
