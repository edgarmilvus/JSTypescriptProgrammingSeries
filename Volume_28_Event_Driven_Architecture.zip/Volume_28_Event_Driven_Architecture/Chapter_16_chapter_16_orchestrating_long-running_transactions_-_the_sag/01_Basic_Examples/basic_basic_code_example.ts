/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file SaaS User Onboarding Saga Orchestrator
 * @description Demonstrates a basic orchestration-based saga handling distributed transactions
 * with compensating actions in TypeScript.
 */

// Define the possible states of our SaaS Onboarding Saga workflow
type SagaState = 
  | 'STARTED'
  | 'USER_CREATED'
  | 'WORKSPACE_PROVISIONED'
  | 'PAYMENT_PROCESSED'
  | 'COMPLETED'
  | 'COMPENSATING_PAYMENT'
  | 'COMPENSATING_WORKSPACE'
  | 'COMPENSATING_USER'
  | 'FAILED'
  | 'ROLLED_BACK';

// Context interface holding data passed along the saga steps
interface OnboardingContext {
  userId: string;
  email: string;
  workspaceId?: string;
  paymentToken?: string;
  error?: string;
}

/**
 * Simulates the User Service: Creates a user account.
 */
async function createUser(context: OnboardingContext): Promise<void> {
  console.log(`[UserService] Creating user profile for ${context.email}...`);
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 500));
  context.userId = 'usr_99887766';
  console.log(`[UserService] Success: User ${context.userId} created.`);
}

/**
 * Compensating action for User Service: Deletes or deactivates the user account.
 */
async function rollbackUser(context: OnboardingContext): Promise<void> {
  console.log(`[Compensation:UserService] Deleting user profile ${context.userId}...`);
  await new Promise(resolve => setTimeout(resolve, 500));
  console.log(`[Compensation:UserService] User ${context.userId} removed.`);
}

/**
 * Simulates the Workspace Service: Provisions a dedicated tenant database/schema.
 */
async function provisionWorkspace(context: OnboardingContext): Promise<void> {
  console.log(`[WorkspaceService] Provisioning workspace for user ${context.userId}...`);
  await new Promise(resolve => setTimeout(resolve, 500));
  context.workspaceId = 'ws_11223344';
  console.log(`[WorkspaceService] Success: Workspace ${context.workspaceId} provisioned.`);
}

/**
 * Compensating action for Workspace Service: Deprovisions the tenant workspace.
 */
async function rollbackWorkspace(context: OnboardingContext): Promise<void> {
  console.log(`[Compensation:WorkspaceService] Deprovisioning workspace ${context.workspaceId}...`);
  await new Promise(resolve => setTimeout(resolve, 500));
  console.log(`[Compensation:WorkspaceService] Workspace ${context.workspaceId} destroyed.`);
}

/**
 * Simulates the Billing Service: Charges the user's credit card.
 * Throws an error to simulate a downstream failure (e.g., declined card or gateway timeout).
 */
async function processPayment(context: OnboardingContext): Promise<void> {
  console.log(`[BillingService] Processing payment token ${context.paymentToken}...`);
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Simulated failure condition
  throw new Error('Payment Gateway Timeout / Card Declined');
}

/**
 * Compensating action for Billing Service: Refunds the charged amount.
 */
async function rollbackPayment(context: OnboardingContext): Promise<void> {
  console.log(`[Compensation:BillingService] Issuing refund for token ${context.paymentToken}...`);
  await new Promise(resolve => setTimeout(resolve, 500));
  console.log(`[Compensation:BillingService] Refund completed.`);
}

/**
 * Saga Orchestrator class managing execution flow and compensation order.
 */
class OnboardingSagaOrchestrator {
  private state: SagaState = 'STARTED';
  private context: OnboardingContext;

  constructor(email: string, paymentToken: string) {
    this.context = { email, paymentToken };
  }

  /**
   * Executes the primary forward transaction path, catching errors to trigger rollback.
   */
  public async execute(): Promise<SagaState> {
    try {
      // Step 1: Create User
      this.state = 'STARTED';
      await createUser(this.context);
      this.state = 'USER_CREATED';

      // Step 2: Provision Workspace
      await provisionWorkspace(this.context);
      this.state = 'WORKSPACE_PROVISIONED';

      // Step 3: Process Payment (Will throw an error in this example)
      await processPayment(this.context);
      this.state = 'PAYMENT_PROCESSED';

      // Final Success State
      this.state = 'COMPLETED';
      console.log('[SagaOrchestrator] Onboarding workflow completed successfully.');
      return this.state;

    } catch (error: any) {
      this.context.error = error.message;
      console.error(`[SagaOrchestrator] Error encountered at state '${this.state}': ${this.context.error}`);
      await this.compensate();
      return this.state;
    }
  }

  /**
   * Executes reverse compensating transactions in exact LIFO (Last-In, First-Out) order.
   */
  private async compensate(): Promise<void> {
    console.log('[SagaOrchestrator] Initiating compensation workflow (Rollback)...');

    switch (this.state) {
      case 'PAYMENT_PROCESSED':
        this.state = 'COMPENSATING_PAYMENT';
        await rollbackPayment(this.context);
        // Fall through to previous steps

      case 'WORKSPACE_PROVISIONED':
        this.state = 'COMPENSATING_WORKSPACE';
        await rollbackWorkspace(this.context);
        // Fall through to previous steps

      case 'USER_CREATED':
      case 'STARTED':
        this.state = 'COMPENSATING_USER';
        await rollbackUser(this.context);
        this.state = 'ROLLED_BACK';
        break;

      default:
        this.state = 'FAILED';
        break;
    }

    console.log(`[SagaOrchestrator] Saga execution finished with state: ${this.state}`);
  }
}

// ==========================================
// Execution Entrypoint
// ==========================================
async function runDemo() {
  const orchestrator = new OnboardingSagaOrchestrator('enterprise-client@saasprovider.io', 'tok_visa_debit_fail');
  const finalState = await orchestrator.execute();
  console.log(`Final Saga Execution State: ${finalState}`);
}

runDemo();
