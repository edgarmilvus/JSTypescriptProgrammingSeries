/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * Represents the current lifecycle states of an Orchestrated Saga.
 */
type SagaStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'COMPENSATING' | 'COMPENSATED';

/**
 * Payload required to initiate the AI Model Deployment Saga.
 */
interface DeployModelCommand {
  tenantId: string;
  userId: string;
  modelName: string;
  creditCost: number;
  datasetUri: string;
}

/**
 * Base interface for all Saga execution steps.
 */
interface SagaStep<TContext> {
  name: string;
  execute(context: TContext): Promise<boolean>;
  compensate(context: TContext): Promise<boolean>;
}

/**
 * Shared runtime context passed between saga steps.
 */
interface DeploymentSagaContext {
  sagaId: string;
  tenantId: string;
  userId: string;
  modelName: string;
  creditCost: number;
  datasetUri: string;
  reservationId?: string;
  vectorIndexName?: string;
  jobId?: string;
  errors: string[];
}

/**
 * Step 1: Billing Context - Reserve user credits for the deployment.
 */
class ReserveCreditsStep implements SagaStep<DeploymentSagaContext> {
  name = 'ReserveCredits';

  async execute(context: DeploymentSagaContext): Promise<boolean> {
    console.log(`[Saga: ${context.sagaId}] Executing: Reserving ${context.creditCost} credits for tenant ${context.tenantId}`);
    
    // Simulate API call to Billing Bounded Context
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    // Simulate successful reservation and assign a rollback token
    context.reservationId = `res_${randomUUID().substring(0, 8)}`;
    console.log(`[Saga: ${context.sagaId}] Success: Credits reserved with ID ${context.reservationId}`);
    return true;
  }

  async compensate(context: DeploymentSagaContext): Promise<boolean> {
    if (!context.reservationId) return true;
    console.log(`[Saga: ${context.sagaId}] Compensating: Refunding ${context.creditCost} credits for reservation ${context.reservationId}`);
    
    // Simulate rollback call to Billing Bounded Context
    await new Promise((resolve) => setTimeout(resolve, 500));
    console.log(`[Saga: ${context.sagaId}] Compensation Complete: Credits refunded.`);
    return true;
  }
}

/**
 * Step 2: Vector Database Context - Provision vector index for the model.
 */
class ProvisionVectorIndexStep implements SagaStep<DeploymentSagaContext> {
  name = 'ProvisionVectorIndex';

  async execute(context: DeploymentSagaContext): Promise<boolean> {
    console.log(`[Saga: ${context.sagaId}] Executing: Provisioning vector index for model ${context.modelName}`);
    
    // Simulate API call to Vector DB Bounded Context
    await new Promise((resolve) => setTimeout(resolve, 600));
    
    // Introduce conditional failure injection for demonstration purposes
    if (context.modelName.includes('fail-vector')) {
      console.error(`[Saga: ${context.sagaId}] Failure: Vector database cluster exhausted.`);
      throw new Error('VectorDatabaseProvisioningException');
    }

    context.vectorIndexName = `idx_${context.tenantId}_${Date.now()}`;
    console.log(`[Saga: ${context.sagaId}] Success: Vector index created: ${context.vectorIndexName}`);
    return true;
  }

  async compensate(context: DeploymentSagaContext): Promise<boolean> {
    if (!context.vectorIndexName) return true;
    console.log(`[Saga: ${context.sagaId}] Compensating: Deleting vector index ${context.vectorIndexName}`);
    
    // Simulate teardown call to Vector DB Bounded Context
    await new Promise((resolve) => setTimeout(resolve, 400));
    console.log(`[Saga: ${context.sagaId}] Compensation Complete: Vector index deleted.`);
    return true;
  }
}

/**
 * Step 3: Training Pipeline Context - Initialize fine-tuning worker job.
 */
class InitializeFineTuningJobStep implements SagaStep<DeploymentSagaContext> {
  name = 'InitializeFineTuningJob';

  async execute(context: DeploymentSagaContext): Promise<boolean> {
    console.log(`[Saga: ${context.sagaId}] Executing: Starting fine-tuning job with dataset ${context.datasetUri}`);
    
    // Simulate API call to ML Training Pipeline
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    context.jobId = `job_${randomUUID().substring(0, 8)}`;
    console.log(`[Saga: ${context.sagaId}] Success: Fine-tuning job started with ID ${context.jobId}`);
    return true;
  }

  async compensate(context: DeploymentSagaContext): Promise<boolean> {
    if (!context.jobId) return true;
    console.log(`[Saga: ${context.sagaId}] Compensating: Cancelling fine-tuning job ${context.jobId}`);
    
    // Simulate cancellation call to ML Training Pipeline
    await new Promise((resolve) => setTimeout(resolve, 300));
    console.log(`[Saga: ${context.sagaId}] Compensation Complete: Fine-tuning job cancelled.`);
    return true;
  }
}

/**
 * The Model Deployment Saga Orchestrator Engine.
 */
class ModelDeploymentSagaOrchestrator {
  private steps: SagaStep<DeploymentSagaContext>[] = [
    new ReserveCreditsStep(),
    new ProvisionVectorIndexStep(),
    new InitializeFineTuningJobStep(),
  ];

  async execute(command: DeployModelCommand): Promise<{ status: SagaStatus; context: DeploymentSagaContext }> {
    const sagaId = `saga_${randomUUID().substring(0, 8)}`;
    const context: DeploymentSagaContext = {
      sagaId,
      tenantId: command.tenantId,
      userId: command.userId,
      modelName: command.modelName,
      creditCost: command.creditCost,
      datasetUri: command.datasetUri,
      errors: [],
    };

    console.log(`\n==================================================`);
    console.log(`[Saga Orchestrator] Starting Saga: ${sagaId} for Tenant: ${command.tenantId}`);
    console.log(`==================================================\n`);

    let executedStepsCount = 0;

    try {
      // Forward Execution Phase
      for (const step of this.steps) {
        executedStepsCount++;
        const success = await step.execute(context);
        if (!success) {
          throw new Error(`Step ${step.name} returned false without throwing an exception.`);
        }
      }

      console.log(`\n[Saga: ${sagaId}] Status: COMPLETED successfully.\n`);
      return { status: 'COMPLETED', context };

    } catch (error: any) {
      console.error(`\n[Saga: ${sagaId}] Error encountered: ${error.message}. Initiating Rollback...\n`);
      context.errors.push(error.message);

      // Backward Compensation Phase (Run in reverse order of successfully executed steps)
      const stepsToCompensate = this.steps.slice(0, executedStepsCount).reverse();

      for (const step of stepsToCompensate) {
        try {
          await step.compensate(context);
        } catch (compensationError: any) {
          // Critical logging point: Compensation failures require human intervention or DLQ routing
          console.error(`[CRITICAL] [Saga: ${sagaId}] Compensation failed for step ${step.name}: ${compensationError.message}`);
        }
      }

      console.log(`\n[Saga: ${sagaId}] Status: COMPENSATED (Rolled back successfully).\n`);
      return { status: 'COMPENSATED', context };
    }
  }
}

// ==========================================
// Execution Demonstration (Simulated Server Action)
// ==========================================
async function runDemo() {
  const orchestrator = new ModelDeploymentSagaOrchestrator();

  // Test Case 1: Successful Deployment Workflow
  await orchestrator.execute({
    tenantId: 'tenant_alpha_99',
    userId: 'usr_123',
    modelName: 'gpt-custom-v1',
    creditCost: 150,
    datasetUri: 's3://datasets/alpha-v1.jsonl',
  });

  // Test Case 2: Failing Deployment Workflow (Triggers Rollback)
  await orchestrator.execute({
    tenantId: 'tenant_beta_42',
    userId: 'usr_456',
    modelName: 'fail-vector-model',
    creditCost: 300,
    datasetUri: 's3://datasets/beta-v1.jsonl',
  });
}

runDemo();
