/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface DomainEvent {
  readonly eventId: string;
  readonly correlationId: string;
  readonly occurredAt: Date;
}

export interface OrderPlacedEvent extends DomainEvent {
  readonly type: 'ORDER_PLACED';
  readonly payload: {
    orderId: string;
    customerId: string;
    items: Array<{ productId: string; quantity: number }>;
    totalAmount: number;
  };
}

export interface InventoryReservedEvent extends DomainEvent {
  readonly type: 'INVENTORY_RESERVED';
  readonly payload: {
    orderId: string;
    reservationId: string;
    items: Array<{ productId: string; quantity: number }>;
  };
}

export interface InventoryReservationFailedEvent extends DomainEvent {
  readonly type: 'INVENTORY_RESERVATION_FAILED';
  readonly payload: {
    orderId: string;
    reason: string;
  };
}

export interface PaymentProcessedEvent extends DomainEvent {
  readonly type: 'PAYMENT_PROCESSED';
  readonly payload: {
    orderId: string;
    paymentId: string;
    amount: number;
  };
}

export interface PaymentFailedEvent extends DomainEvent {
  readonly type: 'PAYMENT_FAILED';
  readonly payload: {
    orderId: string;
    reason: string;
  };
}

export interface InventoryReleaseRequestedEvent extends DomainEvent {
  readonly type: 'INVENTORY_RELEASE_REQUESTED';
  readonly payload: {
    orderId: string;
    reservationId: string;
  };
}

export interface OrderCancelRequestedEvent extends DomainEvent {
  readonly type: 'ORDER_CANCEL_REQUESTED';
  readonly payload: {
    orderId: string;
    reason: string;
  };
}

type EventHandler = (event: DomainEvent) => Promise<void>;

export class EventBus {
  private subscribers: Map<string, EventHandler[]> = new Map();
  private processedEvents: Set<string> = new Set(); // Deduplication store for Idempotency

  public subscribe(eventType: string, handler: EventHandler): void {
    const handlers = this.subscribers.get(eventType) || [];
    handlers.push(handler);
    this.subscribers.set(eventType, handlers);
  }

  public async publish(event: DomainEvent): Promise<void> {
    // Idempotency check middleware wrapper
    if (this.processedEvents.has(event.eventId)) {
      console.warn(`[EventBus] Duplicate event intercepted and dropped: ${event.eventId} (${event.type})`);
      return;
    }

    this.processedEvents.add(event.eventId);
    console.log(`[EventBus] Publishing event: ${event.type} [ID: ${event.eventId}, Correlation: ${event.correlationId}]`);

    const handlers = this.subscribers.get(event.type) || [];
    await Promise.all(handlers.map(async (handler) => {
      try {
        await handler(event);
      } catch (error) {
        console.error(`[EventBus] Error handling event ${event.type}:`, error);
      }
    }));
  }
}

export class InventoryBoundedContext {
  constructor(private eventBus: EventBus) {
    this.eventBus.subscribe('ORDER_PLACED', this.handleOrderPlaced.bind(this));
    this.eventBus.subscribe('INVENTORY_RELEASE_REQUESTED', this.handleReleaseInventory.bind(this));
  }

  private async handleOrderPlaced(event: DomainEvent): Promise<void> {
    const orderEvent = event as OrderPlacedEvent;
    console.log(`[InventoryContext] Reserving inventory for Order ID: ${orderEvent.payload.orderId}`);
    
    // Simulate successful reservation
    const reservationId = `res-${Math.random().toString(36).substring(7)}`;
    const reservedEvent: InventoryReservedEvent = {
      eventId: `evt-${Math.random().toString(36).substring(7)}`,
      correlationId: orderEvent.correlationId,
      occurredAt: new Date(),
      type: 'INVENTORY_RESERVED',
      payload: {
        orderId: orderEvent.payload.orderId,
        reservationId,
        items: orderEvent.payload.items,
      },
    };

    await this.eventBus.publish(reservedEvent);
  }

  private async handleReleaseInventory(event: DomainEvent): Promise<void> {
    const releaseEvent = event as InventoryReleaseRequestedEvent;
    console.log(`[InventoryContext] COMPENSATING: Released inventory for Order ID: ${releaseEvent.payload.orderId}`);
  }
}

export class BillingBoundedContext {
  constructor(private eventBus: EventBus) {
    this.eventBus.subscribe('INVENTORY_RESERVED', this.handleInventoryReserved.bind(this));
  }

  private async handleInventoryReserved(event: DomainEvent): Promise<void> {
    const invEvent = event as InventoryReservedEvent;
    console.log(`[BillingContext] Processing payment for Order ID: ${invEvent.payload.orderId}`);

    // Simulate a payment failure condition
    const paymentFailed = true; 

    if (paymentFailed) {
      const failEvent: PaymentFailedEvent = {
        eventId: `evt-${Math.random().toString(36).substring(7)}`,
        correlationId: invEvent.correlationId,
        occurredAt: new Date(),
        type: 'PAYMENT_FAILED',
        payload: {
          orderId: invEvent.payload.orderId,
          reason: 'Insufficient funds on credit card',
        },
      };
      await this.eventBus.publish(failEvent);
    }
  }
}

export class OrderBoundedContext {
  constructor(private eventBus: EventBus) {
    this.eventBus.subscribe('PAYMENT_FAILED', this.handlePaymentFailed.bind(this));
  }

  private async handlePaymentFailed(event: DomainEvent): Promise<void> {
    const failEvent = event as PaymentFailedEvent;
    console.log(`[OrderContext] Payment failed for Order ID: ${failEvent.payload.reason}. Initiating compensation cascade.`);

    // Trigger Compensations
    const releaseEvent: InventoryReleaseRequestedEvent = {
      eventId: `evt-${Math.random().toString(36).substring(7)}`,
      correlationId: failEvent.correlationId,
      occurredAt: new Date(),
      type: 'INVENTORY_RELEASE_REQUESTED',
      payload: {
        orderId: failEvent.payload.orderId,
        reservationId: 'res-simulated',
      },
    };

    const cancelEvent: OrderCancelRequestedEvent = {
      eventId: `evt-${Math.random().toString(36).substring(7)}`,
      correlationId: failEvent.correlationId,
      occurredAt: new Date(),
      type: 'ORDER_CANCEL_REQUESTED',
      payload: {
        orderId: failEvent.payload.orderId,
        reason: failEvent.payload.reason,
      },
    };

    await this.eventBus.publish(releaseEvent);
    await this.eventBus.publish(cancelEvent);
  }
}
