/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type SagaState = 
  | { status: 'PENDING' }
  | { status: 'FLIGHT_RESERVED'; flightBookingId: string }
  | { status: 'HOTEL_RESERVED'; flightBookingId: string; hotelBookingId: string }
  | { status: 'COMPLETED'; flightBookingId: string; hotelBookingId: string; carBookingId: string }
  | { status: 'COMPENSATING'; reason: string }
  | { status: 'FAILED'; reason: string };

export interface SagaEvent {
  readonly eventId: string;
  readonly correlationId: string;
  readonly type: string;
  readonly payload: any;
  readonly timestamp: Date;
}

export class TravelSagaOrchestrator {
  private currentState: SagaState = { status: 'PENDING' };
  private history: SagaEvent[] = [];
  private hotelTimeoutHandle?: NodeJS.Timeout;

  constructor(public readonly sagaId: string) {}

  public getState(): SagaState {
    return this.currentState;
  }

  public getHistory(): ReadonlyArray<SagaEvent> {
    return this.history;
  }

  public applyEvent(event: SagaEvent): void {
    this.validateTransition(event);
    this.history.push(event);
    this.transitionState(event);
  }

  private validateTransition(event: SagaEvent): void {
    if (this.currentState.status === 'COMPLETED' || this.currentState.status === 'FAILED') {
      throw new Error(`Illegal state transition attempt from terminal state: ${this.currentState.status}`);
    }
  }

  private transitionState(event: SagaEvent): void {
    switch (event.type) {
      case 'FLIGHT_RESERVED':
        if (this.currentState.status === 'PENDING') {
          this.currentState = { 
            status: 'FLIGHT_RESERVED', 
            flightBookingId: event.payload.flightBookingId 
          };
          this.scheduleHotelTimeout(event.correlationId);
        }
        break;

      case 'HOTEL_RESERVED':
        if (this.currentState.status === 'FLIGHT_RESERVED') {
          if (this.hotelTimeoutHandle) clearTimeout(this.hotelTimeoutHandle);
          this.currentState = {
            status: 'HOTEL_RESERVED',
            flightBookingId: this.currentState.flightBookingId,
            hotelBookingId: event.payload.hotelBookingId,
          };
        }
        break;

      case 'HOTEL_TIMEOUT':
      case 'HOTEL_FAILED':
        if (this.currentState.status === 'FLIGHT_RESERVED' || this.currentState.status === 'PENDING') {
          if (this.hotelTimeoutHandle) clearTimeout(this.hotelTimeoutHandle);
          this.currentState = {
            status: 'COMPENSATING',
            reason: event.payload.reason || 'Hotel service failure or timeout',
          };
        }
        break;

      case 'COMPENSATION_COMPLETED':
        if (this.currentState.status === 'COMPENSATING') {
          this.currentState = {
            status: 'FAILED',
            reason: this.currentState.reason,
          };
        }
        break;

      default:
        throw new Error(`Unknown or invalid event type for current state: ${event.type}`);
    }
  }

  private scheduleHotelTimeout(correlationId: string): void {
    this.hotelTimeoutHandle = setTimeout(() => {
      this.applyEvent({
        eventId: `timeout-${Date.now()}`,
        correlationId,
        type: 'HOTEL_TIMEOUT',
        payload: { reason: 'Hotel reservation exceeded 5000ms threshold' },
        timestamp: new Date(),
      });
    }, 5000);
  }

  public static replay(sagaId: string, events: SagaEvent[]): TravelSagaOrchestrator {
    const orchestrator = new TravelSagaOrchestrator(sagaId);
    for (const event of events) {
      orchestrator.applyEvent(event);
    }
    return orchestrator;
  }
}
