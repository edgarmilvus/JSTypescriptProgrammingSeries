/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useReducer, useEffect, useState } from 'react';

export interface SagaInstanceViewModel {
  sagaId: string;
  workflowName: string;
  currentState: 'PENDING' | 'RUNNING' | 'COMPENSATING' | 'COMPLETED' | 'FAILED';
  startedAt: number;
  lastUpdated: number;
  steps: Array<{ stepName: string; durationMs?: number; status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'COMPENSATING' }>;
}

type SagaAction = 
  | { type: 'UPSERT_SAGA'; payload: SagaInstanceViewModel }
  | { type: 'REMOVE_SAGA'; payload: { sagaId: string } };

function sagaReducer(state: Map<string, SagaInstanceViewModel>, action: SagaAction): Map<string, SagaInstanceViewModel> {
  const nextState = new Map(state);
  switch (action.type) {
    case 'UPSERT_SAGA':
      nextState.set(action.payload.sagaId, action.payload);
      return nextState;
    case 'REMOVE_SAGA':
      nextState.delete(action.payload.sagaId);
      return nextState;
    default:
      return state;
  }
}

interface SagaDashboardProps {
  streamUrl: string;
}

export const SagaDashboard: React.FC<SagaDashboardProps> = ({ streamUrl }) => {
  const [sagas, dispatch] = useReducer(sagaReducer, new Map<string, SagaInstanceViewModel>());
  const [filterStuck, setFilterStuck] = useState<boolean>(false);

  useEffect(() => {
    const eventSource = new EventSource(streamUrl);

    eventSource.onmessage = (event) => {
      try {
        const sagaData: SagaInstanceViewModel = JSON.parse(event.data);
        dispatch({ type: 'UPSERT_SAGA', payload: sagaData });
      } catch (err) {
        console.error('Failed to parse incoming saga SSE message', err);
      }
    };

    return () => {
      eventSource.close();
    };
  }, [streamUrl]);

  // Headless inference heuristic for risk prediction
  const predictTimeoutRisk = (saga: SagaInstanceViewModel): boolean => {
    if (saga.currentState === 'COMPLETED' || saga.currentState === 'FAILED') return false;
    const elapsedTime = Date.now() - saga.startedAt;
    // Heuristic: If running longer than 15000ms with pending steps, flag high risk
    return elapsedTime > 15000 && saga.steps.some(s => s.status === 'PENDING');
  };

  const handleForceCompensation = (sagaId: string) => {
    fetch(`/api/sagas/${sagaId}/compensate`, { method: 'POST' })
      .catch(err => console.error('Failed to dispatch manual compensation command', err));
  };

  const filteredSagas = Array.from(sagas.values()).filter(saga => {
    if (!filterStuck) return true;
    return saga.currentState === 'COMPENSATING' || saga.currentState === 'FAILED';
  });

  return (
    <div className="saga-dashboard" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Saga Orchestration Dashboard</h2>
      
      <div style={{ marginBottom: '15px' }}>
        <label>
          <input 
            type="checkbox" 
            checked={filterStuck} 
            onChange={(e) => setFilterStuck(e.target.checked)} 
          />
          {' '}Filter Stuck / Compensating Sagas
        </label>
      </div>

      <div className="saga-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '15px' }}>
        {filteredSagas.map(saga => {
          const isHighRisk = predictTimeoutRisk(saga);
          return (
            <div key={saga.sagaId} style={{ border: '1px solid #ccc', borderRadius: '6px', padding: '15px', background: '#f9f9f9' }}>
              <h3>{saga.workflowName}</h3>
              <p><strong>ID:</strong> {saga.sagaId}</p>
              <p>
                <strong>State:</strong> <span style={{ color: saga.currentState === 'COMPENSATING' ? 'orange' : 'inherit' }}>{saga.currentState}</span>
              </p>

              {isHighRisk && (
                <div style={{ background: '#ffe6e6', color: '#cc0000', padding: '5px', fontSize: '12px', fontWeight: 'bold', marginBottom: '10px', borderRadius: '4px' }}>
                  ⚠️ High Risk of Timeout
                </div>
              )}

              <div className="steps-list" style={{ fontSize: '13px', marginBottom: '10px' }}>
                {saga.steps.map((step, idx) => (
                  <div key={idx}>- {step.stepName}: <strong>{step.status}</strong></div>
                ))}
              </div>

              {(saga.currentState === 'RUNNING' || saga.currentState === 'COMPENSATING') && (
                <button 
                  onClick={() => handleForceCompensation(saga.sagaId)}
                  style={{ background: '#d9534f', color: 'white', border: 'none', padding: '6px 12px', borderRadius: '4px', cursor: 'pointer' }}
                >
                  Force Compensation
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
