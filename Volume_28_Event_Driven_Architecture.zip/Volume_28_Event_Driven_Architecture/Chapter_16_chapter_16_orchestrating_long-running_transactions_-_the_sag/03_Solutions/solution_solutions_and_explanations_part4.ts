/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export class AccountId {
  constructor(public readonly value: string) {}
}

export class Money {
  constructor(public readonly amount: number, public readonly currency: string) {
    if (amount < 0) throw new Error('Money amount cannot be negative');
  }

  public add(other: Money): Money {
    if (this.currency !== other.currency) throw new Error('Currency mismatch');
    return new Money(this.amount + other.amount, this.currency);
  }

  public subtract(other: Money): Money {
    if (this.currency !== other.currency) throw new Error('Currency mismatch');
    return new Money(this.amount - other.amount, this.currency);
  }
}

export interface LedgerEntry {
  readonly entryId: string;
  readonly accountId: string;
  readonly amount: Money;
  readonly type: 'DEBIT' | 'CREDIT';
  readonly timestamp: Date;
}

export class AccountAggregate {
  private balance: Money;
  private auditTrail: LedgerEntry[] = [];

  constructor(public readonly id: AccountId, initialBalance: Money, private overdraftLimit: Money) {
    this.balance = initialBalance;
  }

  public getBalance(): Money {
    return this.balance;
  }

  public getAuditTrail(): ReadonlyArray<LedgerEntry> {
    return this.auditTrail;
  }

  public debit(amount: Money, entryId: string): void {
    const potentialBalance = this.balance.subtract(amount);
    // Enforce invariant: Balance cannot drop below zero minus overdraft limit
    if (potentialBalance.amount < -this.overdraftLimit.amount) {
      throw new Error(`Insufficient funds on account ${this.id.value} exceeding overdraft limit.`);
    }
    this.balance = potentialBalance;
    this.auditTrail.push({ entryId, accountId: this.id.value, amount, type: 'DEBIT', timestamp: new Date() });
  }

  public credit(amount: Money, entryId: string): void {
    this.balance = this.balance.add(amount);
    this.auditTrail.push({ entryId, accountId: this.id.value, amount, type: 'CREDIT', timestamp: new Date() });
  }
}

export class AccountTransferSaga {
  private state: 'INITIATED' | 'SOURCE_DEBITED' | 'DESTINATION_CONVERTED' | 'COMPLETED' | 'COMPENSATING' | 'ALTERNATIVE_REQUIRED' | 'FAILED' = 'INITIATED';

  constructor(
    public readonly sagaId: string,
    private sourceAccount: AccountAggregate,
    private destinationAccount: AccountAggregate,
    private transferAmount: Money
  ) {}

  public executeForward(conversionFee: Money): void {
    try {
      const debitId = `txn-debit-${Date.now()}`;
      this.sourceAccount.debit(this.transferAmount, debitId);
      this.state = 'SOURCE_DEBITED';

      // Simulate failure at destination currency conversion step
      const destinationConversionFailed = true;
      if (destinationConversionFailed) {
        throw new Error('Currency conversion service timeout or validation failure');
      }

      this.state = 'COMPLETED';
    } catch (error) {
      this.handleCompensation();
    }
  }

  private handleCompensation(): void {
    this.state = 'COMPENSATING';
    try {
      // Calculate exact mathematical inverse for compensating transaction
      const creditId = `txn-compensate-${Date.now()}`;
      this.sourceAccount.credit(this.transferAmount, creditId);
      this.state = 'FAILED';
    } catch (compError) {
      // Pivot to alternative compliance path if standard compensation fails
      this.state = 'ALTERNATIVE_REQUIRED';
      console.warn(`[Saga ${this.sagaId}] Standard financial compensation failed. Routing funds to suspense account.`);
    }
  }

  public getState(): string {
    return this.state;
  }
}
