/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Exercise 1 Starter Code: Type definitions and event bus skeleton
// Your task is to implement the handlers and choreography logic.

export interface DomainEvent {
  readonly eventId: string;
  readonly correlationId: string;
  readonly occurredAt: Date;
}

export interface OrderPlacedEvent extends DomainEvent {
  readonly type: 'ORDER_PLACED';
  readonly payload: {
    orderId: string;
    customerId: string;
    items: Array<{ productId: string; quantity: number }>;
    totalAmount: number;
  };
}

export interface InventoryReservedEvent extends DomainEvent {
  readonly type: 'INVENTORY_RESERVED';
  readonly payload: {
    orderId: string;
    reservationId: string;
  };
}

export interface PaymentFailedEvent extends DomainEvent {
  readonly type: 'PAYMENT_FAILED';
  readonly payload: {
    orderId: string;
    reason: string;
  };
}

// TODO: Implement your Choreography Saga Event Bus and Bounded Context Handlers below.
