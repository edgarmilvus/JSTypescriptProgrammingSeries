/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// Exercise 3 Starter Code: React Component Skeleton
// Your task is to complete the SagaDashboard TSX component.

import React, { useReducer, useEffect } from 'react';

export interface SagaInstanceViewModel {
  sagaId: string;
  workflowName: string;
  currentState: string;
  startedAt: string;
  lastUpdated: string;
  steps: Array<{ stepName: string; status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'COMPENSATING' }>;
}

interface SagaDashboardProps {
  streamUrl: string;
}

export const SagaDashboard: React.FC<SagaDashboardProps> = ({ streamUrl }) => {
  // TODO: Implement state management, SSE connection, and UI rendering logic.
  return (
    <div className="saga-dashboard">
      <h2>Saga Orchestration Dashboard</h2>
      {/* Render saga instances and controls here */}
    </div>
  );
};
