/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { NodeSDK } from '@opentelemetry/sdk-node';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { trace, context, propagation, SpanStatusCode, Tracer } from '@opentelemetry/api';
import * as opentelemetry from '@opentelemetry/api';

/**
 * 1. Initialize the OpenTelemetry NodeSDK.
 * This must be executed as early as possible in your application lifecycle
 * (ideally in a separate tracing.ts file imported at the very top of your entry point).
 */
const sdk = new NodeSDK({
  traceExporter: new OTLPTraceExporter({
    url: 'https://otlp.saas-observability.internal/v1/traces',
  }),
  instrumentations: [getNodeAutoInstrumentations()],
});

sdk.start();

// Obtain a tracer instance for our billing microservice domain
const tracer: Tracer = trace.getTracer('billing-service', '1.0.0');

/**
 * Represents the raw message envelope received from the message broker.
 * Contains both the business payload and the serialized W3C trace context headers.
 */
interface EventEnvelope<T> {
  eventId: string;
  eventType: string;
  timestamp: string;
  // Carriers can be headers, metadata objects, or dictionaries carrying traceparent/tracestate
  metadata: {
    traceparent?: string;
    tracestate?: string;
    tenantId: string;
  };
  payload: T;
}

/**
 * Represents the data payload for an InvoiceCreated domain event.
 */
interface InvoiceCreatedPayload {
  invoiceId: string;
  customerId: string;
  amountCents: number;
  currency: string;
}

/**
 * Simulates a vector database client (e.g., Pinecone Node.js SDK) 
 * performing an audit log embedding search within a child span.
 */
async function queryAuditVectorDatabase(tenantId: string, invoiceId: string): Promise<void> {
  const span = tracer.startSpan('Pinecone.queryAuditEmbeddings');
  try {
    span.setAttribute('tenant.id', tenantId);
    span.setAttribute('invoice.id', invoiceId);
    span.setAttribute('db.system', 'pinecone');
    
    // Simulate network latency for vector similarity search
    await new Promise((resolve) => setTimeout(resolve, 45));
    
    span.setStatus({ code: SpanStatusCode.OK });
  } catch (error: any) {
    span.recordException(error);
    span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
    throw error;
  } finally {
    span.end();
  }
}

/**
 * Core event consumer function that processes incoming event envelopes.
 * Extracts the W3C trace context, reactivates it, and executes domain logic.
 */
async function handleInvoiceCreatedEvent(rawMessage: string): Promise<void> {
  // Parse the incoming JSON message from the message broker queue
  const envelope: EventEnvelope<InvoiceCreatedPayload> = JSON.parse(rawMessage);

  /**
   * 2. Extract Trace Context.
   * We use the W3C propagation rules via the OpenTelemetry API.
   * The carrier is our metadata dictionary containing 'traceparent'.
   */
  const extractedContext = propagation.extract(
    context.active(),
    envelope.metadata,
    {
      get(carrier, key) {
        return carrier[key as keyof typeof carrier];
      },
      keys(carrier) {
        return Object.keys(carrier);
      },
    }
  );

  /**
   * 3. Start a new consumer span within the extracted context.
   * By wrapping the logic inside `context.with(extractedContext, ...)`, 
   * any child spans created here will automatically link back to the producer's trace.
   */
  await context.with(extractedContext, async () => {
    const consumerSpan = tracer.startSpan('EventConsumer.handleInvoiceCreated', {
      attributes: {
        'messaging.system': 'rabbitmq',
        'messaging.destination': 'invoices.created',
        'messaging.operation': 'process',
        'event.id': envelope.eventId,
        'event.type': envelope.eventType,
        'tenant.id': envelope.metadata.tenantId,
      },
    });

    // Bind the span to the active context execution flow
    await context.with(trace.setSpan(context.active(), consumerSpan), async () => {
      try {
        console.log(`[BillingService] Processing invoice ${envelope.payload.invoiceId} for tenant ${envelope.metadata.tenantId}`);

        // Step A: Perform domain business logic validation
        if (envelope.payload.amountCents <= 0) {
          throw new Error('Invalid invoice amount: must be greater than zero.');
        }

        // Step B: Query Pinecone vector database for audit anomaly detection
        await queryAuditVectorDatabase(envelope.metadata.tenantId, envelope.payload.invoiceId);

        // Step C: Simulate downstream database write (e.g., PostgreSQL / Prisma)
        const dbSpan = tracer.startSpan('PostgreSQL.insertLedgerEntry');
        dbSpan.setAttribute('db.statement', 'INSERT INTO ledger ...');
        await new Promise((resolve) => setTimeout(resolve, 25));
        dbSpan.end();

        consumerSpan.setStatus({ code: SpanStatusCode.OK });
      } catch (error: any) {
        console.error(`[BillingService] Failed to process event: ${error.message}`);
        consumerSpan.recordException(error);
        consumerSpan.setStatus({
          code: SpanStatusCode.ERROR,
          message: error.message,
        });
        throw error;
      } finally {
        consumerSpan.end();
      }
    });
  });
}

/**
 * Simulation runner demonstrating end-to-end execution.
 */
async function simulateIncomingMessage(): Promise<void> {
  // Construct a mock payload simulating a message published by an upstream API Gateway
  // containing an active W3C traceparent header (e.g., version 00, traceId, parentSpanId, flags).
  const mockIncomingEnvelope = JSON.stringify({
    eventId: 'evt_9981237192837',
    eventType: 'InvoiceCreated',
    timestamp: new Date().toISOString(),
    metadata: {
      traceparent: '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01',
      tenantId: 'tenant_enterprise_42',
    },
    payload: {
      invoiceId: 'inv_abc123',
      customerId: 'cust_xyz789',
      amountMents: 15000,
      currency: 'USD',
    },
  });

  await handleInvoiceCreatedEvent(mockIncomingEnvelope);
}

// Execute simulation
simulateIncomingMessage().catch(console.error);
