/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { trace, context, Span, Tracer, propagation, ROOT_CONTEXT } from '@opentelemetry/api';
import { NodeSDK } from '@opentelemetry/sdk-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { Resource } from '@opentelemetry/resources';
import { SemanticResourceAttributes } from '@opentelemetry/semantic-conventions';

/**
 * 1. Initialize OpenTelemetry SDK for a SaaS Microservice Node environment.
 */
const sdk = new NodeSDK({
  resource: new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: 'billing-service-event-processor',
    [SemanticResourceAttributes.SERVICE_VERSION]: '1.0.0',
  }),
  traceExporter: new OTLPTraceExporter({
    url: process.env.OTEL_EXPORTER_OTLP_ENDPOINT || 'http://localhost:4318/v1/traces',
  }),
});

// Start the OpenTelemetry SDK
sdk.start();

/**
 * Interface representing a domain event envelope matching CloudEvents specification
 * with embedded W3C Trace Context carriers.
 */
interface DomainEventEnvelope<T> {
  specversion: string;
  type: string;
  source: string;
  id: string;
  time: string;
  datacontenttype: string;
  traceparent?: string; // W3C Trace Context propagation header
  tracestate?: string;  // W3C Trace State propagation header
  data: T;
}

/**
 * Payload for a subscription charge domain event.
 */
interface SubscriptionChargedData {
  tenantId: string;
  subscriptionId: string;
  amountCents: number;
  currency: string;
}

/**
 * Tracer instance for the billing domain bounded context.
 */
const tracer: Tracer = trace.getTracer('billing-domain-tracer', '1.0.0');

/**
 * 2. Event Producer / Publisher Function
 * Simulates generating a domain event inside a Next.js API Route handler
 * and injecting the active OpenTelemetry span context into the message envelope.
 */
async function publishSubscriptionChargedEvent(
  data: SubscriptionChargedData
): Promise<DomainEventEnvelope<SubscriptionChargedData>> {
  return tracer.startActiveSpan('Publisher.publishSubscriptionChargedEvent', async (span: Span) => {
    try {
      span.setAttribute('tenant.id', data.tenantId);
      span.setAttribute('subscription.id', data.subscriptionId);
      span.setAttribute('event.type', 'billing.subscription.charged');

      // Create a carrier object to hold the distributed tracing context
      const carrier: Record<string, string> = {};
      
      // Inject current active context into the carrier map using W3C propagator
      propagation.inject(context.active(), carrier);

      const eventEnvelope: DomainEventEnvelope<SubscriptionChargedData> = {
        specversion: '1.0',
        type: 'billing.subscription.charged',
        source: 'urn:saas:billing-service',
        id: crypto.randomUUID(),
        time: new Date().toISOString(),
        datacontenttype: 'application/json',
        traceparent: carrier['traceparent'],
        tracestate: carrier['tracestate'],
        data,
      };

      // Simulate asynchronous publishing to message broker (e.g., RabbitMQ / Kafka)
      await simulatedMessageBrokerPublish(eventEnvelope);

      span.setStatus({ code: 1 }); // OK status
      return eventEnvelope;
    } catch (error: any) {
      span.recordException(error);
      span.setStatus({ code: 2, message: error.message }); // ERROR status
      throw error;
    } finally {
      span.end();
    }
  });
}

/**
 * 3. Event Consumer / Handler Function
 * Simulates an asynchronous worker consuming the event envelope,
 * extracting the W3C trace context, and continuing the distributed trace.
 */
async function handleSubscriptionChargedEvent(
  event: DomainEventEnvelope<SubscriptionChargedData>
): Promise<void> {
  // Extract carrier metadata from the incoming event envelope
  const carrier: Record<string, string> = {};
  if (event.traceparent) carrier['traceparent'] = event.traceparent;
  if (event.tracestate) carrier['tracestate'] = event.tracestate;

  // Extract the parent context from the carrier; fallback to ROOT_CONTEXT if missing
  const extractedContext = propagation.extract(ROOT_CONTEXT, carrier);

  // Start a new span as a child of the producer's span using the extracted context
  await tracer.startActiveSpan(
    'Consumer.handleSubscriptionChargedEvent',
    {},
    extractedContext,
    async (span: Span) => {
      try {
        span.setAttribute('tenant.id', event.data.tenantId);
        span.setAttribute('event.id', event.id);
        span.setAttribute('messaging.system', 'rabbitmq');

        console.log(`Processing subscription charge for tenant: ${event.data.tenantId}`);
        
        // Simulate business logic execution (e.g., updating read model, issuing invoice)
        await processDatabaseLedgerUpdate(event.data);

        span.setStatus({ code: 1 });
      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: 2, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    }
  );
}

/**
 * Helper simulation for message broker transport latency.
 */
async function simulatedMessageBrokerPublish(
  event: DomainEventEnvelope<SubscriptionChargedData>
): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 50));
}

/**
 * Helper simulation for database ledger persistence.
 */
async function processDatabaseLedgerUpdate(
  data: SubscriptionChargedData
): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 100));
}

/**
 * 4. Execution Driver
 * Demonstrates the end-to-end trace lifecycle from publishing to consumption.
 */
async function runDemo() {
  const sampleData: SubscriptionChargedData = {
    tenantId: 'tenant_xyz_9988',
    subscriptionId: 'sub_12345abcde',
    amountCents: 4999,
    currency: 'USD',
  };

  console.log('--- Starting Distributed Trace Simulation ---');
  const publishedEvent = await publishSubscriptionChargedEvent(sampleData);
  console.log('Event Published with Traceparent:', publishedEvent.traceparent);

  await handleSubscriptionChargedEvent(publishedEvent);
  console.log('--- Distributed Trace Simulation Complete ---');
}

// Run the demonstration script
runDemo().catch(console.error);
