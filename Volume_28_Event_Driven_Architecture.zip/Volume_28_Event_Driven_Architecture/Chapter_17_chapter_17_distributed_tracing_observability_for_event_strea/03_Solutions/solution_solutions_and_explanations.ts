/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { trace, propagation, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';

export interface DomainEvent<T = Record<string, unknown>> {
  eventId: string;
  eventType: string;
  timestamp: number;
  payload: T;
  metadata: {
    traceparent?: string;
    tracestate?: string;
    [key: string]: unknown;
  };
}

export class InstrumentedEventPublisher {
  private tracer = trace.getTracer('instrumented-event-publisher');

  constructor(private brokerClient: { publish: (exchange: string, routingKey: string, content: Buffer) => Promise<void> }) {}

  async publish<T>(exchange: string, routingKey: string, event: DomainEvent<T>): Promise<void> {
    const activeSpan = trace.getSpan(context.active());
    let spanContextToUse = context.active();

    // Interactive Challenge: If no active span exists, create a synthetic root span fallback
    if (!activeSpan) {
      const syntheticTracer = trace.getTracer('synthetic-fallback-tracer');
      const syntheticSpan = syntheticTracer.startSpan('Synthetic Root Publish', {
        kind: SpanKind.PRODUCER,
      });
      spanContextToUse = trace.setSpan(context.active(), syntheticSpan);
    }

    return this.tracer.startActiveSpan(
      `publish ${event.eventType}`,
      {
        kind: SpanKind.PRODUCER,
        attributes: {
          'messaging.system': 'rabbitmq',
          'messaging.destination': exchange,
          'messaging.operation': 'publish',
          'messaging.message_id': event.eventId,
        },
      },
      spanContextToUse,
      async (span) => {
        try {
          // Inject active W3C trace context into event metadata
          propagation.inject(context.active(), event.metadata);

          const payloadBuffer = Buffer.from(JSON.stringify(event));
          await this.brokerClient.publish(exchange, routingKey, payloadBuffer);

          span.setStatus({ code: SpanStatusCode.OK });
        } catch (error) {
          span.recordException(error as Error);
          span.setStatus({
            code: SpanStatusCode.ERROR,
            message: (error as Error).message,
          });
          throw error;
        } finally {
          span.end();
          // If we created a synthetic span, ensure we end it as well
          if (!activeSpan) {
            const currentSpan = trace.getSpan(context.active());
            if (currentSpan) {
              currentSpan.end();
            }
          }
        }
      }
    );
  }
}
