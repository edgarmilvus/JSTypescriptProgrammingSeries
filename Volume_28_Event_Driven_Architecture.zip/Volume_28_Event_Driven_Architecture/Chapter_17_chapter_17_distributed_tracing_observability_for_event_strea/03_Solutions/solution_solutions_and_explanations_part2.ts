/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { trace, propagation, context, SpanKind, SpanStatusCode, metrics } from '@opentelemetry/api';
import { DomainEvent } from './Exercise1'; // Re-using DomainEvent interface

export type MessageHandler<T> = (event: DomainEvent<T>) => Promise<void>;

// Initialize a corruption counter metric for the interactive challenge
const meter = metrics.getMeter('event-consumer-metrics');
const corruptionCounter = meter.createCounter('messaging.trace.corruption_total', {
  description: 'Counts occurrences of malformed or corrupted W3C traceparent headers',
});

function isValidTraceParent(traceparent?: string): boolean {
  if (!traceparent) return false;
  // W3C Trace Context spec: version (2 hex) - traceId (32 hex) - parentId (16 hex) - traceFlags (2 hex)
  const regex = /^00-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}$/i;
  return regex.test(traceparent);
}

export function withTracingConsumer<T>(
  eventType: string,
  handler: MessageHandler<T>
): MessageHandler<T> {
  const tracer = trace.getTracer('event-consumer-middleware');

  return async (event: DomainEvent<T>): Promise<void> => {
    let extractedContext = context.active();

    // Interactive Challenge: Defensive validation of traceparent
    if (event.metadata.traceparent) {
      if (isValidTraceParent(event.metadata.traceparent)) {
        extractedContext = propagation.extract(context.active(), event.metadata);
      } else {
        corruptionCounter.add(1, { event_type: event.eventType });
        console.warn(`[Tracing] Malformed traceparent received: "${event.metadata.traceparent}". Falling back to new root trace.`);
      }
    }

    const span = tracer.startSpan(
      `${eventType} process`,
      {
        kind: SpanKind.CONSUMER,
        attributes: {
          'messaging.system': 'rabbitmq',
          'messaging.operation': 'process',
          'messaging.message_id': event.eventId,
          'event.type': event.eventType,
        },
      },
      extractedContext
    );

    await context.with(trace.setSpan(extractedContext, span), async () => {
      try {
        await handler(event);
        span.setStatus({ code: SpanStatusCode.OK });
      } catch (error) {
        span.recordException(error as Error);
        span.setStatus({
          code: SpanStatusCode.ERROR,
          message: (error as Error).message,
        });
        throw error;
      } finally {
        span.end();
      }
    });
  };
}
