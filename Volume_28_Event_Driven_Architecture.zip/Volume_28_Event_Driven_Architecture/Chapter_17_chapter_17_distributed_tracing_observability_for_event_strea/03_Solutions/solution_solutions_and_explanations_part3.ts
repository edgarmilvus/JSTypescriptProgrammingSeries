/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { trace, context } from '@opentelemetry/api';

export class TraceLogger {
  private static enrichLogPayload(meta?: Record<string, unknown>) {
    const activeSpan = trace.getSpan(context.active());
    if (!activeSpan) {
      return { ...meta };
    }

    const spanContext = activeSpan.spanContext();
    return {
      ...meta,
      trace_id: spanContext.traceId,
      span_id: spanContext.spanId,
    };
  }

  static info(message: string, meta?: Record<string, unknown>): void {
    const enriched = TraceLogger.enrichLogPayload(meta);
    console.log(JSON.stringify({ level: 'INFO', message, ...enriched, timestamp: new Date().toISOString() }));
  }

  static warn(message: string, meta?: Record<string, unknown>): void {
    const enriched = TraceLogger.enrichLogPayload(meta);
    console.warn(JSON.stringify({ level: 'WARN', message, ...enriched, timestamp: new Date().toISOString() }));
  }

  static error(message: string, error: Error, meta?: Record<string, unknown>): void {
    const enriched = TraceLogger.enrichLogPayload(meta);
    console.error(JSON.stringify({
      level: 'ERROR',
      message,
      error: { name: error.name, message: error.message, stack: error.stack },
      ...enriched,
      timestamp: new Date().toISOString(),
    }));
  }
}
