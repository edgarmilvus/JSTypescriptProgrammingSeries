/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo } from 'react';

export interface SpanData {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  name: string;
  kind: 'INTERNAL' | 'SERVER' | 'CLIENT' | 'PRODUCER' | 'CONSUMER';
  startTime: number;
  endTime: number;
  attributes: Record<string, string | number | boolean>;
  status: { code: 'UNSET' | 'OK' | 'ERROR'; message?: string };
}

export interface TraceVisualizerProps {
  spans: SpanData[];
  onSelectSpan?: (span: SpanData) => void;
}

interface TreeNode extends SpanData {
  children: TreeNode[];
}

export const TraceVisualizer: React.FC<TraceVisualizerProps> = ({ spans, onSelectSpan }) => {
  // Build hierarchical tree and analyze trace bounds
  const { tree, minTime, maxTime, totalDuration, bottleneckSpanId } = useMemo(() => {
    if (spans.length === 0) return { tree: [], minTime: 0, maxTime: 0, totalDuration: 0, bottleneckSpanId: null };

    let min = Infinity;
    let max = -Infinity;
    const map = new Map<string, TreeNode>();
    const roots: TreeNode[] = [];

    spans.forEach((span) => {
      if (span.startTime < min) min = span.startTime;
      if (span.endTime > max) max = span.endTime;
      map.set(span.spanId, { ...span, children: [] });
    });

    const duration = max - min || 1;
    let maxDuration = 0;
    let bottleneckId: string | null = null;

    map.forEach((node) => {
      const nodeDuration = node.endTime - node.startTime;
      // Interactive Challenge: Detect latency bottleneck (> 50% of total trace duration)
      if (nodeDuration > duration * 0.5) {
        maxDuration = nodeDuration;
        bottleneckId = node.spanId;
      }

      if (node.parentSpanId && map.has(node.parentSpanId)) {
        map.get(node.parentSpanId)!.children.push(node);
      } else {
        roots.push(node);
      }
    });

    return { tree: roots, minTime: min, maxTime: max, totalDuration: duration, bottleneckSpanId: bottleneckId };
  }, [spans]);

  const renderSpanNode = (node: TreeNode, depth: number = 0) => {
    const startOffset = ((node.startTime - minTime) / totalDuration) * 100;
    const width = Math.max(((node.endTime - node.startTime) / totalDuration) * 100, 1);
    const isBottleneck = node.spanId === bottleneckSpanId;

    const statusColor = 
      node.status.code === 'ERROR' ? 'bg-red-500' :
      node.status.code === 'OK' ? 'bg-green-500' : 'bg-gray-400';

    return (
      <div key={node.spanId} className="flex flex-col mb-2">
        <div 
          onClick={() => onSelectSpan?.(node)}
          className={`flex items-center justify-between p-2 rounded cursor-pointer hover:bg-gray-100 border ${isBottleneck ? 'border-amber-500 bg-amber-50' : 'border-gray-200'}`}
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <div className="flex items-center space-x-2 w-1/3">
            <span className={`w-3 h-3 rounded-full ${statusColor}`} />
            <span className="font-medium text-sm truncate">{node.name}</span>
            {isBottleneck && <span title="Latency Bottleneck Detected">⚠️</span>}
          </div>

          <div className="relative w-2/3 h-6 bg-gray-100 rounded">
            <div
              className={`absolute h-full rounded opacity-80 ${statusColor}`}
              style={{ left: `${startOffset}%`, width: `${width}%` }}
            />
          </div>
        </div>

        {node.children.map((child) => renderSpanNode(child, depth + 1))}
      </div>
    );
  };

  return (
    <div className="p-4 bg-white shadow rounded-lg">
      {bottleneckSpanId && (
        <div className="mb-4 p-3 bg-amber-100 border border-amber-400 text-amber-800 rounded text-sm">
          ⚠️ Potential latency bottleneck detected in service [<strong>{spans.find(s => s.spanId === bottleneckSpanId)?.attributes['service.name'] || 'unknown'}</strong>]
        </div>
      )}
      <div className="font-bold text-lg mb-4">Trace Timeline Visualizer</div>
      {tree.map((rootNode) => renderSpanNode(rootNode))}
    </div>
  );
};
