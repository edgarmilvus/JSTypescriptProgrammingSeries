/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { metrics, Meter, Histogram, Counter } from '@opentelemetry/api';

// Interactive Challenge: Runtime Type Guard for metric attributes
function isValidMetricAttribute(value: unknown): value is string | number | boolean {
  const type = typeof value;
  return type === 'string' || type === 'number' || type === 'boolean';
}

export class EventMetricsCollector {
  private meter: Meter;
  private processingLatencyHistogram: Histogram;
  private eventCounter: Counter;

  constructor(serviceName: string) {
    this.meter = metrics.getMeter(serviceName);
    
    this.processingLatencyHistogram = this.meter.createHistogram('event.processing.latency', {
      description: 'Measures end-to-end event processing lag in milliseconds',
      unit: 'ms',
    });

    this.eventCounter = this.meter.createCounter('events.processed.total', {
      description: 'Total number of domain events processed',
    });
  }

  recordEventProcessed(
    eventType: string, 
    status: 'success' | 'failure', 
    latencyMs: number, 
    metadata?: Record<string, unknown>
  ): void {
    const sanitizedAttributes: Record<string, string | number | boolean> = {
      event_type: eventType,
      status: status,
    };

    // Sanitize dynamic metadata attributes using the type guard
    if (metadata) {
      for (const [key, val] of Object.entries(metadata)) {
        if (isValidMetricAttribute(val)) {
          sanitizedAttributes[`meta_${key}`] = val;
        } else {
          // Serialize objects/arrays to prevent cardinality leaks
          sanitizedAttributes[`meta_${key}`] = JSON.stringify(val);
        }
      }
    }

    this.processingLatencyHistogram.record(latencyMs, sanitizedAttributes);
    this.eventCounter.add(1, sanitizedAttributes);
  }
}
