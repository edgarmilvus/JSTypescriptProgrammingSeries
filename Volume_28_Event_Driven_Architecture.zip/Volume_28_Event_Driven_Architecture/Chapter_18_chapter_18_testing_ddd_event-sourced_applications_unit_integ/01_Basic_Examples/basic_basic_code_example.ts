/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file workspace.spec.ts
 * @description Unit tests for an Event-Sourced Workspace aggregate in a SaaS application.
 */

// ============================================================================
// 1. DOMAIN EVENTS
// ============================================================================

/**
 * Base interface for all domain events in the system.
 */
interface DomainEvent {
    readonly eventId: string;
    readonly aggregateId: string;
    readonly timestamp: Date;
    readonly version: number;
}

/**
 * Emitted when a new SaaS workspace is provisioned.
 */
class WorkspaceProvisionedEvent implements DomainEvent {
    constructor(
        public readonly aggregateId: string,
        public readonly ownerId: string,
        public readonly workspaceName: string,
        public readonly version: number = 1,
        public readonly eventId: string = Math.random().toString(),
        public readonly timestamp: Date = new Date()
    ) {}
}

/**
 * Emitted when a workspace subscription is upgraded to a higher tier.
 */
class WorkspaceUpgradedEvent implements DomainEvent {
    constructor(
        public readonly aggregateId: string,
        public readonly newTier: 'PRO' | 'ENTERPRISE',
        public readonly version: number,
        public readonly eventId: string = Math.random().toString(),
        public readonly timestamp: Date = new Date()
    ) {}
}

/**
 * Emitted when an attempt is made to upgrade a suspended workspace.
 */
class WorkspaceUpgradeFailedEvent implements DomainEvent {
    constructor(
        public readonly aggregateId: string,
        public readonly reason: string,
        public readonly version: number,
        public readonly eventId: string = Math.random().toString(),
        public readonly timestamp: Date = new Date()
    ) {}
}

// ============================================================================
// 2. AGGREGATE ROOT
// ============================================================================

/**
 * Represents the Workspace aggregate root. It maintains no ORM state,
 * relying strictly on applying domain events to reconstruct its internal state.
 */
class WorkspaceAggregate {
    private id: string = '';
    private ownerId: string = '';
    private name: string = '';
    private tier: 'FREE' | 'PRO' | 'ENTERPRISE' = 'FREE';
    private isSuspended: boolean = false;
    private version: number = 0;
    
    // Uncommitted changes accumulated during the current execution context
    private uncommittedEvents: DomainEvent[] = [];

    private constructor() {}

    /**
     * Factory method to load an aggregate from its complete event history.
     */
    public static reconstitute(history: DomainEvent[]): WorkspaceAggregate {
        const aggregate = new WorkspaceAggregate();
        for (const event of history) {
            aggregate.applyEvent(event, false);
        }
        return aggregate;
    }

    /**
     * Command: Provision a brand new workspace.
     */
    public static provision(workspaceId: string, ownerId: string, name: string): WorkspaceAggregate {
        const aggregate = new WorkspaceAggregate();
        const event = new WorkspaceProvisionedEvent(workspaceId, ownerId, name, 1);
        aggregate.applyEvent(event, true);
        return aggregate;
    }

    /**
     * Command: Upgrade the workspace tier.
     */
    public upgradeTier(newTier: 'PRO' | 'ENTERPRISE'): void {
        if (this.isSuspended) {
            throw new Error("Cannot upgrade a suspended workspace.");
        }
        if (this.tier === newTier) {
            throw new Error(`Workspace is already on the ${newTier} tier.`);
        }

        const nextVersion = this.version + 1;
        const event = new WorkspaceUpgradedEvent(this.id, newTier, nextVersion);
        this.applyEvent(event, true);
    }

    /**
     * Internal state router that applies an event to mutate the aggregate's private state.
     * @param event The domain event to apply.
     * @param isNew Whether this is a newly generated event or part of history reconstruction.
     */
    private applyEvent(event: DomainEvent, isNew: boolean): void {
        if (event instanceof WorkspaceProvisionedEvent) {
            this.id = event.aggregateId;
            this.ownerId = event.ownerId;
            this.name = event.workspaceName;
            this.tier = 'FREE';
            this.version = event.version;
        } else if (event instanceof WorkspaceUpgradedEvent) {
            this.tier = event.newTier;
            this.version = event.version;
        }

        if (isNew) {
            this.uncommittedEvents.push(event);
        }
    }

    /**
     * Flushes uncommitted events to be dispatched to the message bus or event store.
     */
    public getUncommittedEvents(): DomainEvent[] {
        return [...this.uncommittedEvents];
    }

    // Public getters for testing assertions
    public getTier(): string { return this.tier; }
    public getVersion(): number { return this.version; }
    public getId(): string { return this.id; }
}

// ============================================================================
// 3. UNIT TESTING FIXTURE / FRAMEWORK
// ============================================================================

/**
 * A lightweight Given-When-Then test harness for Event-Sourced aggregates.
 */
class AggregateTestFixture<T extends WorkspaceAggregate> {
    private history: DomainEvent[] = [];
    private aggregateInstance!: T;
    private caughtError: Error | null = null;

    /**
     * GIVEN stage: Setup past history of the aggregate.
     */
    public given(events: DomainEvent[]): this {
        this.history = events;
        return this;
    }

    /**
     * WHEN stage: Execute a command against the aggregate.
     */
    public when(action: (aggregate: WorkspaceAggregate) => void): this {
        try {
            // Reconstitute aggregate from history if history exists, 
            // otherwise assume a creation method was called inside action
            if (this.history.length > 0) {
                this.aggregateInstance = WorkspaceAggregate.reconstitute(this.history) as T;
            }
            action(this.aggregateInstance);
        } catch (error) {
            this.caughtError = error as Error;
        }
        return this;
    }

    /**
     * THEN stage: Assert expected emitted events.
     */
    public thenEvents(expectedEvents: DomainEvent[]): void {
        if (this.caughtError) {
            throw new Error(`Expected successful execution, but caught error: ${this.caughtError.message}`);
        }
        const uncommitted = this.aggregateInstance.getUncommittedEvents();
        
        if (uncommitted.length !== expectedEvents.length) {
            throw new Error(`Event count mismatch. Expected ${expectedEvents.length}, got ${uncommitted.length}`);
        }

        uncommitted.forEach((event, index) => {
            const expected = expectedEvents[index];
            if (event.constructor !== expected.constructor) {
                throw new Error(`Event type mismatch at index ${index}. Expected ${expected.constructor.name}, got ${event.constructor.name}`);
            }
            // Deep property check excluding metadata like timestamps and IDs for clean test assertions
            for (const key of Object.keys(expected)) {
                if (key !== 'eventId' && key !== 'timestamp') {
                    if ((event as any)[key] !== (expected as any)[key]) {
                        throw new Error(`Property '${key}' mismatch in event ${event.constructor.name}. Expected ${(expected as any)[key]}, got ${(event as any)[key]}`);
                    }
                }
            }
        });
        console.log("✅ Test Passed: Events matched successfully.");
    }

    /**
     * THEN stage: Assert that an expected error was thrown.
     */
    public thenError(expectedErrorMessage: string): void {
        if (!this.caughtError) {
            throw new Error("Expected an error to be thrown, but execution succeeded.");
        }
        if (this.caughtError.message !== expectedErrorMessage) {
            throw new Error(`Error message mismatch. Expected '${expectedErrorMessage}', got '${this.caughtError.message}'`);
        }
        console.log("✅ Test Passed: Correct error caught.");
    }
}

// ============================================================================
// 4. UNIT TEST SUITE EXECUTION
// ============================================================================

function runTests() {
    console.log("Running Workspace Aggregate Unit Tests...");

    // Test 1: Successfully upgrade a workspace tier
    new AggregateTestFixture<WorkspaceAggregate>()
        .given([
            new WorkspaceProvisionedEvent("ws-123", "usr-456", "Acme Corp", 1)
        ])
        .when((aggregate) => {
            aggregate.upgradeTier("PRO");
        })
        .thenEvents([
            new WorkspaceUpgradedEvent("ws-123", "PRO", 2)
        ]);

    // Test 2: Attempting to upgrade to the same tier should fail via invariant check
    // Note: Since Test 2 verifies an error, we structure the fixture to check exceptions.
    const errorTestFixture = new AggregateTestFixture<WorkspaceAggregate>();
    errorTestFixture
        .given([
            new WorkspaceProvisionedEvent("ws-123", "usr-456", "Acme Corp", 1),
            new WorkspaceUpgradedEvent("ws-123", "PRO", 2)
        ])
        .when((aggregate) => {
            aggregate.upgradeTier("PRO");
        })
        .thenError("Workspace is already on the PRO tier.");
}

runTests();
