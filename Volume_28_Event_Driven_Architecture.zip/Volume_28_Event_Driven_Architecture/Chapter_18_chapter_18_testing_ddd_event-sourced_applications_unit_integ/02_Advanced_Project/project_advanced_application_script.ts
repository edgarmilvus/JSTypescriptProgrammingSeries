/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file Enterprise Subscription Event-Sourced Aggregate & Test Suite
 * @description Demonstrates DDD aggregate testing, event-sourcing rehydration,
 * and asynchronous projection pipelines in TypeScript for a SaaS billing platform.
 */

// ============================================================================
// 1. DOMAIN EVENTS & BASE TYPES
// ============================================================================

export interface DomainEvent {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly version: number;
  readonly occurredOn: Date;
  readonly type: string;
}

export class SubscriptionInitiated implements DomainEvent {
  readonly type = 'SubscriptionInitiated';
  constructor(
    public readonly aggregateId: string,
    public readonly tenantId: string,
    public readonly planId: string,
    public readonly version: number = 1,
    public readonly occurredOn: Date = new Date(),
    public readonly eventId: string = crypto.randomUUID()
  ) {}
}

export class PaymentFailed implements DomainEvent {
  readonly type = 'PaymentFailed';
  constructor(
    public readonly aggregateId: string,
    public readonly reason: string,
    public readonly version: number,
    public readonly occurredOn: Date = new Date(),
    public readonly eventId: string = crypto.randomUUID()
  ) {}
}

export class SubscriptionCanceled implements DomainEvent {
  readonly type = 'SubscriptionCanceled';
  constructor(
    public readonly aggregateId: string,
    public readonly reason: string,
    public readonly version: number,
    public readonly occurredOn: Date = new Date(),
    public readonly eventId: string = crypto.randomUUID()
  ) {}
}

// ============================================================================
// 2. EVENT-SOURCED AGGREGATE ROOT
// ============================================================================

export type SubscriptionStatus = 'TRIALING' | 'ACTIVE' | 'PAST_DUE' | 'CANCELED';

export class SubscriptionAggregate {
  private id: string = '';
  private tenantId: string = '';
  private planId: string = '';
  private status: SubscriptionStatus = 'TRIALING';
  private version: number = 0;
  private uncommittedEvents: DomainEvent[] = [];

  private constructor() {}

  /**
   * Recreates an aggregate instance from a historical stream of domain events.
   */
  public static recreateFromHistory(events: DomainEvent[]): SubscriptionAggregate {
    const aggregate = new SubscriptionAggregate();
    for (const event of events) {
      aggregate.applyEvent(event, false);
    }
    return aggregate;
  }

  /**
   * Factory method to initialize a brand-new subscription.
   */
  public static initialize(aggregateId: string, tenantId: string, planId: string): SubscriptionAggregate {
    const aggregate = new SubscriptionAggregate();
    const event = new SubscriptionInitiated(aggregateId, tenantId, planId, 1);
    aggregate.applyEvent(event, true);
    return aggregate;
  }

  public cancel(reason: string): void {
    if (this.status === 'CANCELED') {
      throw new Error(`Domain Invariant Violation: Subscription ${this.id} is already canceled.`);
    }
    const event = new SubscriptionCanceled(this.id, reason, this.version + 1);
    this.applyEvent(event, true);
  }

  public failPayment(reason: string): void {
    if (this.status === 'CANCELED') {
      throw new Error(`Domain Invariant Violation: Cannot apply payment failure to a canceled subscription.`);
    }
    const event = new PaymentFailed(this.id, reason, this.version + 1);
    this.applyEvent(event, true);
  }

  private applyEvent(event: DomainEvent, isNew: boolean): void {
    switch (event.type) {
      case 'SubscriptionInitiated': {
        const e = event as SubscriptionInitiated;
        this.id = e.aggregateId;
        this.tenantId = e.tenantId;
        this.planId = e.planId;
        this.status = 'ACTIVE';
        break;
      }
      case 'PaymentFailed': {
        this.status = 'PAST_DUE';
        break;
      }
      case 'SubscriptionCanceled': {
        this.status = 'CANCELED';
        break;
      }
      default:
        throw new Error(`Unhandled event type: ${(event as any).type}`);
    }

    this.version = event.version;
    if (isNew) {
      this.uncommittedEvents.push(event);
    }
  }

  public getUncommittedEvents(): DomainEvent[] {
    return [...this.uncommittedEvents];
  }

  public markChangesAsCommitted(): void {
    this.uncommittedEvents = [];
  }

  public getStatus(): SubscriptionStatus {
    return this.status;
  }

  public getVersion(): number {
    return this.version;
  }
}

// ============================================================================
// 3. IN-MEMORY EVENT STORE & TEST FIXTURE HARNESS
// ============================================================================

export class InMemoryEventStore {
  private store: Map<string, DomainEvent[]> = new Map();

  async save(aggregateId: string, events: DomainEvent[]): Promise<void> {
    const existing = this.store.get(aggregateId) || [];
    this.store.set(aggregateId, [...existing, ...events]);
  }

  async getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]> {
    const events = this.store.get(aggregateId);
    if (!events) {
      throw new Error(`Aggregate with ID ${aggregateId} not found in event store.`);
    }
    return events;
  }
}

// ============================================================================
// 4. UNIT & INTEGRATION TEST SUITE
// ============================================================================

async function runSubscriptionTestSuite() {
  console.log('--- Starting Enterprise Subscription Domain Test Suite ---');
  const eventStore = new InMemoryEventStore();
  const aggregateId = 'sub-uuid-9988-77';

  // Test 1: Successful Aggregate Initialization
  console.log('Test 1: Initializing subscription aggregate...');
  const sub = SubscriptionAggregate.initialize(aggregateId, 'tenant-alpha', 'enterprise-tier-v2');
  
  if (sub.getStatus() !== 'ACTIVE') {
    throw new Error('Test 1 Failed: New subscription must be active.');
  }
  if (sub.getVersion() !== 1) {
    throw new Error('Test 1 Failed: Aggregate version should be 1.');
  }
  console.log('✔ Test 1 Passed: Aggregate initialized correctly.');

  // Test 2: Persisting and Rehydrating from Event Store
  console.log('Test 2: Persisting uncommitted events and rehydrating...');
  await eventStore.save(aggregateId, sub.getUncommittedEvents());
  sub.markChangesAsCommitted();

  // Simulate state mutations
  sub.failPayment('Credit Card Expired');
  await eventStore.save(aggregateId, sub.getUncommittedEvents());
  sub.markChangesAsCommitted();

  const historicalEvents = await eventStore.getEventsForAggregate(aggregateId);
  const rehydratedSub = SubscriptionAggregate.recreateFromHistory(historicalEvents);

  if (rehydratedSub.getStatus() !== 'PAST_DUE') {
    throw new Error('Test 2 Failed: Rehydrated aggregate status should be PAST_DUE.');
  }
  if (rehydratedSub.getVersion() !== 2) {
    throw new Error('Test 2 Failed: Rehydrated aggregate version should be 2.');
  }
  console.log('✔ Test 2 Passed: Event sourcing rehydration verified.');

  // Test 3: Domain Invariant Enforcement (Double Cancellation)
  console.log('Test 3: Testing domain invariants on canceled subscription...');
  rehydratedSub.cancel('Customer requested churn');
  
  try {
    rehydratedSub.cancel('Attempting duplicate cancellation');
    throw new Error('Test 3 Failed: Should have thrown an invariant violation error.');
  } catch (error: any) {
    if (!error.message.includes('already canceled')) {
      throw error;
    }
  }
  console.log('✔ Test 3 Passed: Domain invariants successfully protected against invalid transitions.');
  console.log('--- All Tests Completed Successfully ---');
}

// Execute the test suite
runSubscriptionTestSuite().catch((err) => {
  console.error('Test Suite Failed:', err);
  process.exit(1);
});
