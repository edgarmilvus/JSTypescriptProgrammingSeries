/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Domain Events
export interface ShoppingCartCreated {
  type: 'ShoppingCartCreated';
  cartId: string;
}

export interface ItemAddedToCart {
  type: 'ItemAddedToCart';
  cartId: string;
  itemId: string;
  quantity: number;
}

export interface ItemRemovedFromCart {
  type: 'ItemRemovedFromCart';
  cartId: string;
  itemId: string;
  quantity: number;
}

export interface ShoppingCartCheckedOut {
  type: 'ShoppingCartCheckedOut';
  cartId: string;
}

export type DomainEvent = 
  | ShoppingCartCreated 
  | ItemAddedToCart 
  | ItemRemovedFromCart 
  | ShoppingCartCheckedOut;

export class CheckedOutCartError extends Error {
  constructor() {
    super('Cannot modify a checked-out shopping cart.');
    this.name = 'CheckedOutCartError';
  }
}

export class InsufficientItemQuantityError extends Error {
  constructor() {
    super('Cannot remove more items than currently exist in the cart.');
    this.name = 'InsufficientItemQuantityError';
  }
}

export class ShoppingCart {
  private id: string = '';
  private isCheckedOut: boolean = false;
  private items: Map<string, number> = new Map();
  private uncommittedEvents: DomainEvent[] = [];

  constructor(history: DomainEvent[]) {
    this.replay(history);
  }

  private apply(event: DomainEvent): void {
    switch (event.type) {
      case 'ShoppingCartCreated':
        this.id = event.cartId;
        break;
      case 'ItemAddedToCart':
        const currentQty = this.items.get(event.itemId) || 0;
        this.items.set(event.itemId, currentQty + event.quantity);
        break;
      case 'ItemRemovedFromCart':
        const existingQty = this.items.get(event.itemId) || 0;
        this.items.set(event.itemId, existingQty - event.quantity);
        break;
      case 'ShoppingCartCheckedOut':
        this.isCheckedOut = true;
        break;
    }
  }

  private replay(history: DomainEvent[]): void {
    for (const event of history) {
      this.apply(event);
    }
  }

  private raise(event: DomainEvent): void {
    this.apply(event);
    this.uncommittedEvents.push(event);
  }

  public addItem(itemId: string, quantity: number): void {
    if (this.isCheckedOut) {
      throw new CheckedOutCartError();
    }
    this.raise({ type: 'ItemAddedToCart', cartId: this.id, itemId, quantity });
  }

  public removeItem(itemId: string, quantity: number): void {
    if (this.isCheckedOut) {
      throw new CheckedOutCartError();
    }
    const currentQty = this.items.get(itemId) || 0;
    if (quantity > currentQty) {
      throw new InsufficientItemQuantityError();
    }
    this.raise({ type: 'ItemRemovedFromCart', cartId: this.id, itemId, quantity });
  }

  public checkout(): void {
    if (this.isCheckedOut) {
      throw new CheckedOutCartError();
    }
    this.raise({ type: 'ShoppingCartCheckedOut', cartId: this.id });
  }

  public getUncommittedEvents(): DomainEvent[] {
    return this.uncommittedEvents;
  }
}

// Fluent Testing Helper Utility
export interface AggregateTestBuilder<T> {
  given(events: DomainEvent[]): this;
  when(commandFn: (aggregate: T) => void): this;
  thenExpectEvents(expectedEvents: DomainEvent[]): void;
  thenExpectError(errorClass: new (...args: any[]) => Error): void;
}

export class AggregateTestRunner<T> implements AggregateTestBuilder<T> {
  private history: DomainEvent[] = [];
  private commandFn?: (aggregate: T) => void;
  constructor(private aggregateFactory: (history: DomainEvent[]) => T) {}

  given(events: DomainEvent[]): this {
    this.history = events;
    return this;
  }

  when(commandFn: (aggregate: T) => void): this {
    this.commandFn = commandFn;
    return this;
  }

  thenExpectEvents(expectedEvents: DomainEvent[]): void {
    const aggregate = this.aggregateFactory(this.history);
    if (this.commandFn) this.commandFn(aggregate);
    const uncommitted = (aggregate as any).getUncommittedEvents();
    if (JSON.stringify(uncommitted) !== JSON.stringify(expectedEvents)) {
      throw new Error(`Expected events mismatch.\nExpected: ${JSON.stringify(expectedEvents)}\nReceived: ${JSON.stringify(uncommitted)}`);
    }
  }

  thenExpectError(errorClass: new (...args: any[]) => Error): void {
    const aggregate = this.aggregateFactory(this.history);
    try {
      if (this.commandFn) this.commandFn(aggregate);
      throw new Error(`Expected error of type ${errorClass.name}, but no error was thrown.`);
    } catch (error: any) {
      if (!(error instanceof errorClass)) {
        throw new Error(`Expected error of type ${errorClass.name}, but got ${error.constructor.name}: ${error.message}`);
      }
    }
  }
}

export function testAggregate<T>(
  aggregateFactory: (history: DomainEvent[]) => T
): AggregateTestBuilder<T> {
  return new AggregateTestRunner(aggregateFactory);
}
