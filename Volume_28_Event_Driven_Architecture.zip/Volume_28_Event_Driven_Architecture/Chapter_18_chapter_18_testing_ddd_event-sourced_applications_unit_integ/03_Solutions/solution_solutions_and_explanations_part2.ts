/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface OrderPlacedEvent {
  type: 'OrderPlaced';
  orderId: string;
  totalAmount: number;
}

export interface OrderSummaryReadModel {
  orderId: string;
  totalAmount: number;
}

export class InMemoryEventBus {
  private handlers: ((event: OrderPlacedEvent) => Promise<void>)[] = [];

  public subscribe(handler: (event: OrderPlacedEvent) => Promise<void>): void {
    this.handlers.push(handler);
  }

  public async publish(event: OrderPlacedEvent): Promise<void> {
    for (const handler of this.handlers) {
      // Simulate async task dispatching boundary
      setImmediate(() => handler(event));
    }
  }
}

export class OrderSummaryRepository {
  private store = new Map<string, OrderSummaryReadModel>();

  public async save(summary: OrderSummaryReadModel): Promise<void> {
    this.store.set(summary.orderId, summary);
  }

  public async findById(orderId: string): Promise<OrderSummaryReadModel | undefined> {
    return this.store.get(orderId);
  }
}

export async function waitForCondition(
  conditionFn: () => Promise<boolean>,
  timeoutMs: number = 2000,
  intervalMs: number = 50
): Promise<void> {
  const startTime = Date.now();
  while (Date.now() - startTime < timeoutMs) {
    if (await conditionFn()) {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  throw new Error(`Condition timed out after ${timeoutMs}ms`);
}

// Integration Test Example Block
export async function runIntegrationTest() {
  const eventBus = new InMemoryEventBus();
  const repository = new OrderSummaryRepository();

  // Register Projection Event Handler
  eventBus.subscribe(async (event) => {
    if (event.type === 'OrderPlaced') {
      await repository.save({
        orderId: event.orderId,
        totalAmount: event.totalAmount,
      });
    }
  });

  const testEvent: OrderPlacedEvent = {
    type: 'OrderPlaced',
    orderId: 'order-123',
    totalAmount: 150.00,
  };

  // Act: Publish event asynchronously
  await eventBus.publish(testEvent);

  // Assert: Wait for projection consistency
  await waitForCondition(async () => {
    const summary = await repository.findById('order-123');
    return summary !== undefined && summary.totalAmount === 150.00;
  });

  console.log('CQRS Integration test passed successfully.');
}
