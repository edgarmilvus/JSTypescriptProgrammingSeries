/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const InvoiceGenerationRequestedSchema = z.object({
  eventId: z.string().uuid(),
  occurredAt: z.string().datetime(),
  data: z.object({
    orderId: z.string(),
    customerId: z.string(),
    totalAmount: z.number().positive(),
    currency: z.string().length(3),
  }),
});

export type InvoiceGenerationRequestedEvent = z.infer<typeof InvoiceGenerationRequestedSchema>;

export class OrderServiceProducer {
  public emitInvoiceRequested(payload: unknown): string {
    const validated = InvoiceGenerationRequestedSchema.parse(payload);
    return JSON.stringify(validated);
  }
}

export class BillingServiceConsumer {
  public handleMessage(rawMessage: string): InvoiceGenerationRequestedEvent {
    const parsedJson = JSON.parse(rawMessage);
    const result = InvoiceGenerationRequestedSchema.safeParse(parsedJson);
    
    if (!result.success) {
      throw new Error(`Anti-Corruption Layer Validation Failed: ${result.error.message}`);
    }
    
    return result.data;
  }
}

// Test assertions showcase
export function runContractTests() {
  const producer = new OrderServiceProducer();
  const consumer = new BillingServiceConsumer();

  const validPayload = {
    eventId: '123e4567-e89b-12d3-a456-426614174000',
    occurredAt: new Date().toISOString(),
    data: {
      orderId: 'ORD-999',
      customerId: 'CUST-555',
      totalAmount: 250.75,
      currency: 'USD',
    },
  };

  // 1. Producer Contract Validation Test
  const serialized = producer.emitInvoiceRequested(validPayload);
  const deserialized = consumer.handleMessage(serialized);
  if (deserialized.data.orderId !== 'ORD-999') {
    throw new Error('Contract validation payload mismatch.');
  }

  // 2. Consumer Anti-Corruption Layer Error Test
  const malformedPayload = JSON.stringify({
    eventId: 'not-a-uuid',
    occurredAt: 'invalid-date',
    data: {
      orderId: 'ORD-999',
      customerId: 'CUST-555',
      totalAmount: -10, // Invalid: must be positive
      currency: 'USDT', // Invalid: length must be 3
    },
  });

  let caught = false;
  try {
    consumer.handleMessage(malformedPayload);
  } catch (err) {
    caught = true;
  }

  if (!caught) {
    throw new Error('Consumer failed to catch schema violation in contract test.');
  }

  console.log('Contract tests passed successfully.');
}
