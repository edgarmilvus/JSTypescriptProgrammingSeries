/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface DomainEventDTO {
  eventId: string;
  eventType: string;
  version: number;
  occurredAt: string;
  payload: Record<string, unknown>;
}

interface AggregateAuditTrailProps {
  aggregateId: string;
  fetchEventsUrl: string;
  streamEventsUrl: string;
}

export const AggregateAuditTrail: React.FC<AggregateAuditTrailProps> = ({
  aggregateId,
  fetchEventsUrl,
  streamEventsUrl,
}) => {
  const [events, setEvents] = useState<DomainEventDTO[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let isMounted = true;
    fetch(`${fetchEventsUrl}/${aggregateId}`)
      .then((res) => res.json())
      .then((data: DomainEventDTO[]) => {
        if (isMounted) {
          setEvents(data);
          setLoading(false);
        }
      })
      .catch(() => {
        if (isMounted) setLoading(false);
      });

    const eventSource = new EventSource(`${streamEventsUrl}/${aggregateId}`);
    eventSource.onmessage = (event) => {
      const newEvent: DomainEventDTO = JSON.parse(event.data);
      if (isMounted) {
        setEvents((prev) => [...prev, newEvent]);
      }
    };

    return () => {
      isMounted = false;
      eventSource.close();
    };
  }, [aggregateId, fetchEventsUrl, streamEventsUrl]);

  const toggleExpand = (eventId: string) => {
    setExpandedIds((prev) => ({ ...prev, [eventId]: !prev[eventId] }));
  };

  if (loading) return <div data-testid="loading-state">Loading audit history...</div>;

  return (
    <div data-testid="audit-trail-container">
      <h2>Audit Trail for {aggregateId}</h2>
      {events.length === 0 ? (
        <p data-testid="empty-state">No events recorded.</p>
      ) : (
        <ul>
          {events.map((evt) => (
            <li key={evt.eventId} data-testid={`event-item-${evt.eventId}`}>
              <span>{evt.occurredAt} - {evt.eventType} (v{evt.version})</span>
              <button onClick={() => toggleExpand(evt.eventId)}>
                {expandedIds[evt.eventId] ? 'Hide Payload' : 'Show Payload'}
              </button>
              {expandedIds[evt.eventId] && (
                <pre data-testid={`payload-${evt.eventId}`}>
                  {JSON.stringify(evt.payload, null, 2)}
                </pre>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
