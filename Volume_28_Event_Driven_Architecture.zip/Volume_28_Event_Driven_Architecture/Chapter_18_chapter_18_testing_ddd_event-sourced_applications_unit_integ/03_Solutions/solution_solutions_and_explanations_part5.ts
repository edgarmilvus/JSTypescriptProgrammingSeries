/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import fc from 'fast-check';

export type WalletEvent = 
  | { type: 'Deposited'; amount: number } 
  | { type: 'Withdrawn'; amount: number };

export class NegativeBalanceError extends Error {
  constructor() {
    super('Balance cannot drop below zero.');
    this.name = 'NegativeBalanceError';
  }
}

export class Wallet {
  private balance: number = 0;
  private history: WalletEvent[] = [];

  constructor(history: WalletEvent[] = []) {
    for (const event of history) {
      this.apply(event);
    }
  }

  private apply(event: WalletEvent): void {
    if (event.type === 'Deposited') {
      this.balance += event.amount;
    } else if (event.type === 'Withdrawn') {
      this.balance -= event.amount;
    }
  }

  public deposit(amount: number): void {
    if (amount <= 0) throw new Error('Deposit must be positive');
    this.history.push({ type: 'Deposited', amount });
    this.balance += amount;
  }

  public withdraw(amount: number): void {
    if (amount <= 0) throw new Error('Withdrawal must be positive');
    if (this.balance - amount < 0) {
      throw new NegativeBalanceError();
    }
    this.history.push({ type: 'Withdrawn', amount });
    this.balance -= amount;
  }

  public getBalance(): number {
    return this.balance;
  }
}

describe('Wallet Aggregate Property-Based Testing', () => {
  it('should never allow the balance to drop below zero under any valid transaction sequence', () => {
    fc.assert(
      fc.property(
        fc.array(
          fc.record({
            isDeposit: fc.boolean(),
            amount: fc.integer({ min: 1, max: 500 }),
          }),
          { minLength: 1, maxLength: 50 }
        ),
        (transactions) => {
          const wallet = new Wallet();
          let expectedBalance = 0;

          for (const tx of transactions) {
            try {
              if (tx.isDeposit) {
                wallet.deposit(tx.amount);
                expectedBalance += tx.amount;
              } else {
                if (wallet.getBalance() >= tx.amount) {
                  wallet.withdraw(tx.amount);
                  expectedBalance -= tx.amount;
                } else {
                  wallet.withdraw(tx.amount); // Should throw
                }
              }
            } catch (err) {
              if (err instanceof NegativeBalanceError) {
                if (wallet.getBalance() < 0) return false;
              } else {
                throw err;
              }
            }
          }

          return wallet.getBalance() >= 0 && wallet.getBalance() === expectedBalance;
        }
      )
    );
  });
});
