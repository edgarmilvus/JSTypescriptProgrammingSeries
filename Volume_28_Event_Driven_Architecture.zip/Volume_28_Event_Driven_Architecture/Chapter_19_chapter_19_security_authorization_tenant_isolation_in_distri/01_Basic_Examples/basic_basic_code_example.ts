/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as crypto from 'crypto';

/**
 * Represents the multi-tenant security context injected into every distributed event.
 */
interface TenantSecurityContext {
  readonly tenantId: string;
  readonly userId: string;
  readonly clearanceLevel: 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'RESTRICTED';
  readonly issuedAt: number;
  readonly expiresAt: number;
}

/**
 * Represents the immutable structure of a secure domain event.
 */
interface SecureDomainEvent<T = Record<string, unknown>> {
  readonly eventId: string;
  readonly eventType: string;
  readonly metadata: TenantSecurityContext;
  readonly payload: T;
  readonly signature: string;
}

/**
 * Configuration options for the Event Security Gateway.
 */
interface EventSecurityOptions {
  readonly signingSecret: string;
  readonly maxEventAgeMs: number;
}

/**
 * SaaS Context Payload: A customer upgrading their subscription plan.
 */
interface SubscriptionUpgradedPayload {
  readonly subscriptionId: string;
  readonly newPlan: 'PRO' | 'ENTERPRISE';
  readonly updatedByIp: string;
}

/**
 * Secure Event Gateway responsible for signing, sealing, and verifying 
 * multi-tenant events passing across microservice boundaries.
 */
class SecureEventGateway {
  private readonly signingSecret: Buffer;
  private readonly maxEventAgeMs: number;

  constructor(options: EventSecurityOptions) {
    this.signingSecret = Buffer.from(options.signingSecret, 'utf-8');
    this.maxEventAgeMs = options.maxEventAgeMs;
  }

  /**
   * Computes an HMAC-SHA256 signature for the event payload and metadata combination.
   * Ensures tamper-proof transit across distributed message brokers (e.g., Kafka, RabbitMQ).
   */
  private computeSignature(
    eventId: string,
    eventType: string,
    metadata: TenantSecurityContext,
    payload: unknown
  ): string {
    const canonicalString = JSON.stringify({
      eventId,
      eventType,
      metadata,
      payload,
    });

    return crypto
      .createHmac('sha256', this.signingSecret)
      .update(canonicalString)
      .digest('hex');
  }

  /**
   * Publishes/Creates a secure, cryptographically signed event for a specific tenant.
   */
  public createSecureEvent<T>(
    eventType: string,
    tenantContext: Omit<TenantSecurityContext, 'issuedAt' | 'expiresAt'>,
    payload: T
  ): SecureDomainEvent<T> {
    const now = Date.now();
    const metadata: TenantSecurityContext = {
      ...tenantContext,
      issuedAt: now,
      expiresAt: now + this.maxEventAgeMs,
    };

    const eventId = crypto.randomUUID();
    const signature = this.computeSignature(eventId, eventType, metadata, payload);

    return {
      eventId,
      eventType,
      metadata,
      payload,
      signature,
    };
  }

  /**
   * Verifies incoming events from external microservices. Enforces zero-trust 
   * validation by checking cryptographic signatures, time-to-live expiration, 
   * and tenant boundary conformity.
   */
  public verifyAndConsumeEvent<T>(
    event: SecureDomainEvent<T>,
    expectedTenantId?: string
  ): { isValid: boolean; error?: string; data?: SecureDomainEvent<T> } {
    // Step 1: Validate Tenant Boundary match if required
    if (expectedTenantId && event.metadata.tenantId !== expectedTenantId) {
      return {
        isValid: false,
        error: `Tenant Isolation Violation: Event belongs to tenant [${event.metadata.tenantId}], but context expected [${expectedTenantId}].`,
      };
    }

    // Step 2: Validate Event Expiration (Replay attack & TTL mitigation)
    const now = Date.now();
    if (now > event.metadata.expiresAt) {
      return {
        isValid: false,
        error: `Event Expired: Event TTL exceeded by [${now - event.metadata.expiresAt}ms].`,
      };
    }

    // Step 3: Re-calculate and verify cryptographic signature
    const calculatedSignature = this.computeSignature(
      event.eventId,
      event.eventType,
      event.metadata,
      event.payload
    );

    // Use timing-safe comparison to prevent timing attacks
    const signatureBuffer = Buffer.from(event.signature, 'hex');
    const calculatedBuffer = Buffer.from(calculatedSignature, 'hex');

    if (
      signatureBuffer.length !== calculatedBuffer.length ||
      !crypto.timingSafeEqual(signatureBuffer, calculatedBuffer)
    ) {
      return {
        isValid: false,
        error: 'Cryptographic Integrity Failure: Invalid signature or tampered payload.',
      };
    }

    return {
      isValid: true,
      data: event,
    };
  }
}

// ==========================================
// EXECUTION & DEMONSTRATION SIMULATION
// ==========================================

// 1. Initialize our gateway with a securely stored secret key
const eventGateway = new SecureEventGateway({
  signingSecret: 'super-secret-tenant-isolation-key-2026',
  maxEventAgeMs: 5000, // Events expire after 5 seconds
});

// 2. Tenant A attempts to publish an event
const tenantAEvent = eventGateway.createSecureEvent<SubscriptionUpgradedPayload>(
  'subscription.upgraded',
  {
    tenantId: 'tenant-alpha-99',
    userId: 'usr_12345',
    clearanceLevel: 'CONFIDENTIAL',
  },
  {
    subscriptionId: 'sub_98765',
    newPlan: 'ENTERPRISE',
    updatedByIp: '192.168.1.50',
  }
);

console.log('--- GENERATED SECURE EVENT ---');
console.log(JSON.stringify(tenantAEvent, null, 2));

// 3. Consumer Service validates the event under Tenant Alpha context
console.log('\n--- CONSUMING EVENT (VALID TENANT) ---');
const validationResult1 = eventGateway.verifyAndConsumeEvent(
  tenantAEvent,
  'tenant-alpha-99'
);
console.log('Validation Success:', validationResult1.isValid);

// 4. Malicious actor attempts cross-tenant injection attack
console.log('\n--- CONSUMING EVENT (CROSS-TENANT ATTACK SIMULATION) ---');
const maliciousConsumerAttempt = eventGateway.verifyAndConsumeEvent(
  tenantAEvent,
  'tenant-omega-66' // Trying to process Tenant Alpha's event inside Tenant Omega's space
);
console.log('Validation Success:', maliciousConsumerAttempt.isValid);
console.log('Error Message:', maliciousConsumerAttempt.error);

// 5. Malicious actor attempts payload tampering
console.log('\n--- CONSUMING EVENT (TAMPERED PAYLOAD SIMULATION) ---');
const tamperedEvent: SecureDomainEvent<SubscriptionUpgradedPayload> = {
  ...tenantAEvent,
  payload: {
    ...tenantAEvent.payload,
    newPlan: 'ENTERPRISE', // Attacker changes subscription level without re-signing
    subscriptionId: 'sub_HACKED',
  },
};
const tamperingAttempt = eventGateway.verifyAndConsumeEvent(
  tamperedEvent,
  'tenant-alpha-99'
);
console.log('Validation Success:', tamperingAttempt.isValid);
console.log('Error Message:', tamperingAttempt.error);
