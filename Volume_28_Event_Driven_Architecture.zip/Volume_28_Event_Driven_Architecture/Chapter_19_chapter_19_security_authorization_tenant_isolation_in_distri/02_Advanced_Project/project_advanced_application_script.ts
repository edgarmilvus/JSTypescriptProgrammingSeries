/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { createHmac, timingSafeEqual } from 'crypto';

// ============================================================================
// Types & Interfaces
// ============================================================================

/**
 * Represents the strict security context embedded within every distributed event.
 */
export interface TenantSecurityContext {
  tenantId: string;
  userId: string;
  clearanceLevel: 'STANDARD' | 'ELEVATED' | 'ADMIN';
  issuedAt: number;
}

/**
 * Represents an immutable distributed event envelope.
 */
export interface SecureDomainEvent<T = unknown> {
  eventId: string;
  eventType: string;
  timestamp: number;
  securityContext: TenantSecurityContext;
  payload: T;
  signature: string;
}

/**
 * Immutable state representation for the AI chatbot model session.
 */
export interface ChatSessionState {
  readonly sessionId: string;
  readonly tenantId: string;
  readonly messages: ReadonlyArray<{ readonly role: 'user' | 'assistant'; readonly content: string }>;
  readonly modelConfig: Readonly<{ model: string; temperature: number }>;
}

// ============================================================================
// Cryptographic Security Utilities
// ============================================================================

const EVENT_SIGNING_SECRET = process.env.EVENT_SIGNING_SECRET || 'fallback-dev-secret-key-change-in-prod';

/**
 * Cryptographically signs a domain event payload and security context using HMAC-SHA256.
 * Ensures zero-trust data integrity across distributed microservices.
 */
export function signDomainEvent<T>(
  event: Omit<SecureDomainEvent<T>, 'signature'>
): SecureDomainEvent<T> {
  const canonicalData = JSON.stringify({
    eventId: event.eventId,
    eventType: event.eventType,
    timestamp: event.timestamp,
    securityContext: event.securityContext,
    payload: event.payload,
  });

  const signature = createHmac('sha256', EVENT_SIGNING_SECRET)
    .update(canonicalData)
    .digest('hex');

  return {
    ...event,
    signature,
  };
}

/**
 * Verifies the cryptographic signature of an incoming distributed event.
 * Uses timing-safe comparisons to prevent timing attacks.
 */
export function verifyDomainEvent<T>(event: SecureDomainEvent<T>): boolean {
  const { signature, ...rest } = event;
  const canonicalData = JSON.stringify(rest);

  const expectedSignature = createHmac('sha256', EVENT_SIGNING_SECRET)
    .update(canonicalData)
    .digest('hex');

  try {
    const signatureBuffer = Buffer.from(signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');

    if (signatureBuffer.length !== expectedBuffer.length) {
      return false;
    }

    return timingSafeEqual(signatureBuffer, expectedBuffer);
  } catch {
    return false;
  }
}

// ============================================================================
// Immutable State & Projection Engine
// ============================================================================

/**
 * Applies an event to the current state, returning a brand new immutable state object.
 * Adheres to Immutable State Management principles.
 */
export function reduceChatSession(
  currentState: ChatSessionState | null,
  event: SecureDomainEvent<{ role: 'user' | 'assistant'; content: string }>
): ChatSessionState {
  // Enforce strict multi-tenant data isolation boundary
  if (currentState && currentState.tenantId !== event.securityContext.tenantId) {
    throw new Error('SECURITY VIOLATION: Cross-tenant state mutation attempt detected.');
  }

  const baseState: ChatSessionState = currentState || {
    sessionId: event.payload.content ? 'session-' + Date.now() : 'default',
    tenantId: event.securityContext.tenantId,
    messages: [],
    modelConfig: { model: 'gpt-4o', temperature: 0.7 },
  };

  // Return an entirely new object with frozen/immutable nested arrays
  return {
    ...baseState,
    messages: Object.freeze([...baseState.messages, event.payload]),
  };
}

// ============================================================================
// Next.js Server Action & SSE Route Handler
// ============================================================================

/**
 * Next.js Edge Route Handler implementing Server-Sent Events (SSE) for AI token streaming.
 * Integrates tenant validation, cryptographic verification, and immutable projections.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const tenantId = url.searchParams.get('tenantId');
  const token = url.searchParams.get('token');

  // 1. Validate basic authentication context
  if (!tenantId || !token) {
    return new NextResponse('Unauthorized: Missing tenant or token', { status: 401 });
  }

  // 2. Setup Server-Sent Events (SSE) readable stream
  const encoder = new TextEncoder();
  const customStream = new ReadableStream({
    async start(controller) {
      try {
        // Simulate event sourcing replay for the specific tenant
        const mockEvent: SecureDomainEvent<{ role: 'user' | 'assistant'; content: string }> = signDomainEvent({
          eventId: 'evt-' + Math.random().toString(36).substring(7),
          eventType: 'AI_TOKEN_STREAM_INITIALIZED',
          timestamp: Date.now(),
          securityContext: {
            tenantId,
            userId: 'usr-secure-99',
            clearanceLevel: 'ELEVATED',
            issuedAt: Date.now(),
          },
          payload: { role: 'assistant', content: 'Secure connection established. Processing AI stream...' },
        });

        // 3. Verify cryptographic integrity before processing the event projection
        if (!verifyDomainEvent(mockEvent)) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: 'Cryptographic validation failed' })}\n\n`));
          controller.close();
          return;
        }

        // 4. Update state immutably via event projection
        let sessionState: ChatSessionState | null = null;
        sessionState = reduceChatSession(sessionState, mockEvent);

        // 5. Stream real-time data chunks to the client via SSE
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ tenant: sessionState.tenantId, message: mockEvent.payload.content })}\n\n`));

        // Simulate streaming tokens
        const tokens = ['Hello', ' from', ' the', ' secure', ' event-driven', ' microservice!'];
        for (const tokenChunk of tokens) {
          const tokenEvent = signDomainEvent({
            eventId: 'evt-' + Math.random().toString(36).substring(7),
            eventType: 'AI_TOKEN_GENERATED',
            timestamp: Date.now(),
            securityContext: mockEvent.securityContext,
            payload: { role: 'assistant', content: tokenChunk },
          });

          sessionState = reduceChatSession(sessionState, tokenEvent);

          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ token: tokenChunk })}\n\n`));
          // Artificial delay for streaming effect
          await new Promise((resolve) => setTimeout(resolve, 100));
        }

        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: errorMessage })}\n\n`));
        controller.close();
      }
    },
  });

  return new NextResponse(customStream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Tenant-Id': tenantId,
    },
  });
}
