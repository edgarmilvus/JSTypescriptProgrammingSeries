/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

export class SecurityViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SecurityViolationError';
  }
}

export interface DomainEvent<T> {
  eventId: string;
  eventType: string;
  timestamp: number;
  tenantId: string;
  securityClearance: string[];
  payload: T;
}

export class SecureEventEnvelope {
  /**
   * Recursively sorts object keys to ensure deterministic stringification
   * regardless of property insertion order.
   */
  private static canonicalize(obj: unknown): unknown {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }

    if (Array.isArray(obj)) {
      return obj.map(SecureEventEnvelope.canonicalize);
    }

    const sortedObject: Record<string, unknown> = {};
    const keys = Object.keys(obj as Record<string, unknown>).sort();

    for (const key of keys) {
      sortedObject[key] = SecureEventEnvelope.canonicalize(
        (obj as Record<string, unknown>)[key]
      );
    }

    return sortedObject;
  }

  /**
   * Generates a canonicalized string representation of the event core properties.
   */
  private static serializeEvent<T>(event: DomainEvent<T>): string {
    const canonicalPayload = SecureEventEnvelope.canonicalize(event.payload);
    const coreData = {
      eventId: event.eventId,
      eventType: event.eventType,
      timestamp: event.timestamp,
      tenantId: event.tenantId,
      securityClearance: [...event.securityClearance].sort(),
      payload: canonicalPayload,
    };
    return JSON.stringify(coreData);
  }

  /**
   * Signs a domain event using HMAC-SHA256.
   */
  public static sign<T>(event: DomainEvent<T>, secretKey: string): string {
    const serialized = SecureEventEnvelope.serializeEvent(event);
    return crypto
      .createHmac('sha256', secretKey)
      .update(serialized)
      .digest('hex');
  }

  /**
   * Verifies the cryptographic signature and checks for replay attacks (5-minute window).
   */
  public static verify<T>(
    event: DomainEvent<T>,
    signature: string,
    secretKey: string,
    maxAgeMs: number = 5 * 60 * 1000
  ): boolean {
    const currentTime = Date.now();
    if (Math.abs(currentTime - event.timestamp) > maxAgeMs) {
      throw new SecurityViolationError(
        `Security violation: Event timestamp ${event.timestamp} is outside the acceptable window (Replay Attack Prevention).`
      );
    }

    const expectedSignature = SecureEventEnvelope.sign(event, secretKey);

    // Use timing-safe comparison to prevent timing attacks
    const signatureBuffer = Buffer.from(signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');

    if (
      signatureBuffer.length !== expectedBuffer.length ||
      !crypto.timingSafeEqual(signatureBuffer, expectedBuffer)
    ) {
      throw new SecurityViolationError(
        'Security violation: Cryptographic signature mismatch.'
      );
    }

    return true;
  }
}
