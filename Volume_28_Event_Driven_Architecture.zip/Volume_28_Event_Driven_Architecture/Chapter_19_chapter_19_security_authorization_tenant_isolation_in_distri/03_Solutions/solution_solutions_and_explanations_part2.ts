/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface TenantContext {
  tenantId: string;
  region: string;
}

export interface DomainEvent<T> {
  eventId: string;
  eventType: string;
  timestamp: number;
  tenantId: string;
  securityClearance: string[];
  payload: T;
}

export interface TenantAwareProjector<T> {
  handledEventTypes: string[];
  project(event: DomainEvent<T>, context: TenantContext): Promise<void>;
}

export class TenantIsolationPipeline {
  private projectors: Map<string, TenantAwareProjector<any>[]> = new Map();

  public registerProjector(projector: TenantAwareProjector<any>): void {
    for (const eventType of projector.handledEventTypes) {
      const existing = this.projectors.get(eventType) || [];
      existing.push(projector);
      this.projectors.set(eventType, existing);
    }
  }

  public async dispatch<T>(
    event: DomainEvent<T>,
    activeContext: TenantContext
  ): Promise<void> {
    // Enforce tenant boundary validation
    if (event.tenantId !== activeContext.tenantId) {
      this.emitSecurityAuditLog(event, activeContext, 'TENANT_MISMATCH_VIOLATION');
      throw new Error(
        `Tenant Isolation Violation: Execution context tenant [${activeContext.tenantId}] attempted to process event destined for tenant [${event.tenantId}].`
      );
    }

    const handlers = this.projectors.get(event.eventType);
    if (!handlers || handlers.length === 0) {
      return;
    }

    // Execute matching projectors sequentially or concurrently within the verified tenant context
    for (const projector of handlers) {
      await projector.project(event, activeContext);
    }
  }

  private emitSecurityAuditLog<T>(
    event: DomainEvent<T>,
    context: TenantContext,
    reason: string
  ): void {
    console.warn(
      JSON.stringify({
        severity: 'CRITICAL',
        auditEvent: 'SECURITY_VIOLATION',
        reason,
        eventTenantId: event.tenantId,
        contextTenantId: context.tenantId,
        eventId: event.eventId,
        timestamp: new Date().toISOString(),
      })
    );
  }
}
