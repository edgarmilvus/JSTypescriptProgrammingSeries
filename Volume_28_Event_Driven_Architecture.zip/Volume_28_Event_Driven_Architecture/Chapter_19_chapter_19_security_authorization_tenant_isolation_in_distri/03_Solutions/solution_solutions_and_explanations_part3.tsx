/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';

interface AuditLogEntry {
  id: string;
  timestamp: number;
  tenantId: string;
  action: string;
  severity: 'INFO' | 'WARN' | 'CRITICAL';
  signature: string;
}

interface SecureAuditLogStreamerProps {
  tenantId: string;
  authToken: string;
  sseEndpoint: string;
}

export const SecureAuditLogStreamer: React.FC<SecureAuditLogStreamerProps> = ({
  tenantId,
  authToken,
  sseEndpoint,
}) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [anomalyCount, setAnomalyCount] = useState<number>(0);
  const [connectionStatus, setConnectionStatus] = useState<string>('Connecting...');

  useEffect(() => {
    // Append auth token as query parameter or initialize secure stream connection
    const url = new URL(sseEndpoint);
    url.searchParams.append('token', authToken);

    const eventSource = new EventSource(url.toString());

    eventSource.onopen = () => {
      setConnectionStatus('Connected');
    };

    eventSource.onmessage = (event) => {
      try {
        const incomingLog: AuditLogEntry = JSON.parse(event.data);

        // Client-side tenant isolation verification check
        if (incomingLog.tenantId !== tenantId) {
          setAnomalyCount((prev) => prev + 1);
          console.warn(`Intercepted cross-tenant log packet for tenant: ${incomingLog.tenantId}`);
          return;
        }

        // Immutable state update pattern
        setLogs((prevLogs) => [...prevLogs, incomingLog]);
      } catch (err) {
        console.error('Failed to parse incoming audit stream packet:', err);
      }
    };

    eventSource.onerror = (error) => {
      console.error('SSE Connection Error:', error);
      setConnectionStatus('Error / Disconnected');
      eventSource.close();
    };

    // Clean teardown mechanism upon component unmount
    return () => {
      eventSource.close();
    };
  }, [tenantId, authToken, sseEndpoint]);

  return (
    <div className="audit-streamer" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Secure Audit Stream for Tenant: {tenantId}</h2>
      <div style={{ marginBottom: '10px' }}>
        <strong>Status:</strong> <span style={{ color: connectionStatus === 'Connected' ? 'green' : 'red' }}>{connectionStatus}</span> |{' '}
        <strong>Security Anomalies Filtered:</strong> {anomalyCount}
      </div>
      <div className="log-container" style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}>
        {logs.length === 0 ? (
          <p>No audit events recorded yet.</p>
        ) : (
          logs.map((log) => (
            <div key={log.id} style={{ borderBottom: '1px solid #eee', padding: '6px 0' }}>
              <span style={{ fontSize: '0.85em', color: '#666' }}>{new Date(log.timestamp).toISOString()}</span> [
              <strong style={{ color: log.severity === 'CRITICAL' ? 'red' : 'inherit' }}>{log.severity}</strong>] {log.action}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
