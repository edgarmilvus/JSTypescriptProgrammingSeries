/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface DomainEvent<T> {
  eventId: string;
  eventType: string;
  timestamp: number;
  tenantId: string;
  securityClearance: string[];
  payload: T;
}

export interface ServiceSecurityContext {
  serviceId: string;
  authorizedTenants: string[];
  clearanceLevels: string[];
}

export interface EventAccessPolicy {
  eventType: string;
  requiredClearance: string[];
  restrictToTenants?: string[];
}

export class EventACLEngine {
  public evaluateAccess(
    event: DomainEvent<unknown>,
    context: ServiceSecurityContext,
    policy: EventAccessPolicy
  ): boolean {
    // 1. Validate event type match
    if (event.eventType !== policy.eventType) {
      this.auditLog(event, context, policy, 'EVENT_TYPE_MISMATCH');
      return false;
    }

    // 2. Enforce tenant restriction ACLs if specified
    if (policy.restrictToTenants && policy.restrictToTenants.length > 0) {
      const isTenantAuthorized = policy.restrictToTenants.includes(event.tenantId);
      const isServiceAuthorizedForTenant = context.authorizedTenants.includes(event.tenantId);

      if (!isTenantAuthorized || !isServiceAuthorizedForTenant) {
        this.auditLog(event, context, policy, 'TENANT_AUTHORIZATION_FAILED');
        return false;
      }
    } else {
      // If no explicit restriction list, check generic service tenant membership
      if (!context.authorizedTenants.includes(event.tenantId)) {
        this.auditLog(event, context, policy, 'SERVICE_TENANT_NOT_AUTHORIZED');
        return false;
      }
    }

    // 3. Enforce security clearance tier validation (Service must possess ALL required clearances)
    const hasRequiredClearances = policy.requiredClearance.every((clearance) =>
      context.clearanceLevels.includes(clearance)
    );

    if (!hasRequiredClearances) {
      this.auditLog(event, context, policy, 'INSUFFICIENT_SECURITY_CLEARANCE');
      return false;
    }

    return true;
  }

  private auditLog(
    event: DomainEvent<unknown>,
    context: ServiceSecurityContext,
    policy: EventAccessPolicy,
    reason: string
  ): void {
    console.warn(
      JSON.stringify({
        timestamp: new Date().toISOString(),
        serviceId: context.serviceId,
        eventId: event.eventId,
        eventType: event.eventType,
        targetTenant: event.tenantId,
        rejectionReason: reason,
        action: 'ACL_ACCESS_DENIED',
      })
    );
  }
}
