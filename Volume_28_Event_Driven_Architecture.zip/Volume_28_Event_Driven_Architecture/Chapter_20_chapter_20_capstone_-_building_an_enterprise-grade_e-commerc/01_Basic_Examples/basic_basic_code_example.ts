/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file OrderAggregateDemo.ts
 * @description A self-contained TypeScript implementation of an Event-Sourced Order Aggregate,
 * Command Handler, and CQRS Read Model projection for an enterprise e-commerce system.
 */

// ==========================================
// 1. DOMAIN EVENTS (The Source of Truth)
// ==========================================

/**
 * Base interface for all domain events in the system.
 * Every event must carry a unique stream ID, a version for concurrency control, and a timestamp.
 */
export interface DomainEvent {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly version: number;
  readonly occurredAt: Date;
  readonly eventType: string;
}

/**
 * Emitted when a customer successfully places a new order.
 */
export interface OrderPlacedEvent extends DomainEvent {
  readonly eventType: 'OrderPlaced';
  readonly customerId: string;
  readonly items: Array<{ productId: string; quantity: number; unitPrice: number }>;
  readonly totalAmount: number;
}

/**
 * Emitted when payment is successfully captured for an order.
 */
export interface OrderPaidEvent extends DomainEvent {
  readonly eventType: 'OrderPaid';
  readonly paymentReference: string;
}

/**
 * Emitted when an order is cancelled by the customer or system.
 */
export interface OrderCancelledEvent extends DomainEvent {
  readonly eventType: 'OrderCancelled';
  readonly reason: string;
}

// Union type of all possible order events
export type OrderEvent = OrderPlacedEvent | OrderPaidEvent | OrderCancelledEvent;

// ==========================================
// 2. READ MODEL (CQRS Projections)
// ==========================================

/**
 * The denormalized read model optimized for UI queries and fast retrieval.
 */
export interface OrderReadModel {
  id: string;
  customerId: string;
  status: 'PENDING' | 'PAID' | 'CANCELLED';
  items: Array<{ productId: string; quantity: number; unitPrice: number }>;
  totalAmount: number;
  paymentReference?: string;
  cancellationReason?: string;
  version: number;
  updatedAt: Date;
}

// ==========================================
// 3. THE EVENT-SOURCED AGGREGATE
// ==========================================

/**
 * The Order Aggregate. It maintains no mutable state except through applying events.
 */
export class OrderAggregate {
  private _id: string = '';
  private _customerId: string = '';
  private _status: 'PENDING' | 'PAID' | 'CANCELLED' = 'PENDING';
  private _items: Array<{ productId: string; quantity: number; unitPrice: number }> = [];
  private _totalAmount: number = 0;
  private _paymentReference?: string;
  private _cancellationReason?: string;
  private _version: number = 0;
  
  // Uncommitted changes (events that have occurred in memory but not yet persisted to the Event Store)
  private uncommittedEvents: OrderEvent[] = [];

  private constructor() {}

  /**
   * Factory method to hydrate an aggregate from its historical events (Event Sourcing hydration).
   */
  public static reconstitute(history: OrderEvent[]): OrderAggregate {
    const aggregate = new OrderAggregate();
    for (const event of history) {
      aggregate.applyEvent(event, false); // false means do not record as uncommitted
    }
    return aggregate;
  }

  /**
   * Command: Place a new order.
   */
  public static placeOrder(
    orderId: string,
    customerId: string,
    items: Array<{ productId: string; quantity: number; unitPrice: number }>
  ): OrderAggregate {
    const aggregate = new OrderAggregate();
    const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);

    const event: OrderPlacedEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: orderId,
      version: 1,
      occurrencesAt: new Date(),
      occurredAt: new Date(),
      eventType: 'OrderPlaced',
      customerId,
      items,
      totalAmount,
    };

    aggregate.applyEvent(event, true);
    return aggregate;
  }

  /**
   * Command: Mark the order as paid.
   */
  public pay(paymentReference: string): void {
    if (this._status !== 'PENDING') {
      throw new Error(`Cannot pay for order ${this._id} because its current status is ${this._status}`);
    }

    const event: OrderPaidEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this._id,
      version: this._version + 1,
      occurredAt: new Date(),
      eventType: 'OrderPaid',
      paymentReference,
    };

    this.applyEvent(event, true);
  }

  /**
   * Command: Cancel the order.
   */
  public cancel(reason: string): void {
    if (this._status === 'PAID') {
      throw new Error(`Cannot cancel order ${this._id} because it has already been paid.`);
    }
    if (this._status === 'CANCELLED') {
      throw new Error(`Order ${this._id} is already cancelled.`);
    }

    const event: OrderCancelledEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this._id,
      version: this._version + 1,
      occurredAt: new Date(),
      eventType: 'OrderCancelled',
      reason,
    };

    this.applyEvent(event, true);
  }

  /**
   * Internal mutator dispatcher. Applies event changes to the aggregate's in-memory state.
   */
  private applyEvent(event: OrderEvent, isNew: boolean): void {
    switch (event.eventType) {
      case 'OrderPlaced':
        this._id = event.aggregateId;
        this._customerId = event.customerId;
        this._items = event.items;
        this._totalAmount = event.totalAmount;
        this._status = 'PENDING';
        break;

      case 'OrderPaid':
        this._paymentReference = event.paymentReference;
        this._status = 'PAID';
        break;

      case 'OrderCancelled':
        this._cancellationReason = event.reason;
        this._status = 'CANCELLED';
        break;

      default:
        // Exhaustive check for TypeScript type safety
        const _exhaustiveCheck: never = event;
        throw new Error(`Unhandled event type: ${_exhaustiveCheck}`);
    }

    this._version = event.version;

    if (isNew) {
      this.uncommittedEvents.push(event);
    }
  }

  /**
   * Retrieves and clears uncommitted events for persistence.
   */
  public getUncommittedEvents(): OrderEvent[] {
    const events = [...this.uncommittedEvents];
    this.uncommittedEvents = [];
    return events;
  }

  public getVersion(): number {
    return this._version;
  }
}

// ==========================================
// 4. IN-MEMORY EVENT STORE & PROJECTION REPOSITORY
// ==========================================

/**
 * Simulates an enterprise Event Store and a Read Model Database.
 */
export class InMemoryEventStoreAndProjectionManager {
  private eventStore: Map<string, OrderEvent[]> = new Map();
  private readModelDatabase: Map<string, OrderReadModel> = new Map();

  /**
   * Saves new events to the event store and updates the read model projection.
   */
  public async save(aggregateId: string, events: OrderEvent[], expectedVersion: number): Promise<void> {
    const existingEvents = this.eventStore.get(aggregateId) || [];
    
    // Optimistic Concurrency Control Check
    const currentVersion = existingEvents.length;
    if (currentVersion !== expectedVersion) {
      throw new Error(`Concurrency conflict! Expected version ${expectedVersion}, but found version ${currentVersion}`);
    }

    // Append events
    this.eventStore.set(aggregateId, [...existingEvents, ...events]);

    // Project events into the Read Model
    for (const event of events) {
      this.projectReadModel(event);
    }
  }

  /**
   * Loads the event stream for an aggregate.
   */
  public async getEventsForAggregate(aggregateId: string): Promise<OrderEvent[]> {
    return this.eventStore.get(aggregateId) || [];
  }

  /**
   * Queries the read model directly (CQRS Query side).
   */
  public async getOrderReadModel(aggregateId: string): Promise<OrderReadModel | undefined> {
    return this.readModelDatabase.get(aggregateId);
  }

  /**
   * Projects domain events into the denormalized read model database.
   */
  private projectReadModel(event: OrderEvent): void {
    let model = this.readModelDatabase.get(event.aggregateId);

    if (!model) {
      model = {
        id: event.aggregateId,
        customerId: '',
        status: 'PENDING',
        items: [],
        totalAmount: 0,
        version: 0,
        updatedAt: new Date(),
      };
    }

    switch (event.eventType) {
      case 'OrderPlaced':
        model.customerId = event.customerId;
        model.items = event.items;
        model.totalAmount = event.totalAmount;
        model.status = 'PENDING';
        break;
      case 'OrderPaid':
        model.paymentReference = event.paymentReference;
        model.status = 'PAID';
        break;
      case 'OrderCancelled':
        model.cancellationReason = event.reason;
        model.status = 'CANCELLED';
        break;
    }

    model.version = event.version;
    model.updatedAt = event.occurredAt;
    this.readModelDatabase.set(event.aggregateId, model);
  }
}

// ==========================================
// 5. EXECUTION DEMONSTRATION
// ==========================================

async function runDemo() {
  const storeManager = new InMemoryEventStoreAndProjectionManager();
  const orderId = 'order-999-xyz';

  console.log('--- 1. Placing Order ---');
  const order = OrderAggregate.placeOrder(orderId, 'cust-123', [
    { productId: 'prod-A', quantity: 2, unitPrice: 50.0 },
    { productId: 'prod-B', quantity: 1, unitPrice: 100.0 },
  ]);

  await storeManager.save(orderId, order.getUncommittedEvents(), 0);
  
  let readModel = await storeManager.getOrderReadModel(orderId);
  console.log('Read Model after Place:', JSON.stringify(readModel, null, 2));

  console.log('\n--- 2. Paying for Order ---');
  // Rehydrate aggregate from store to simulate a fresh command handling request
  const historicalEvents = await storeManager.getEventsForAggregate(orderId);
  const hydratedOrder = OrderAggregate.reconstitute(historicalEvents);

  hydratedOrder.pay('PAY-REF-88889');
  await storeManager.save(orderId, hydratedOrder.getUncommittedEvents(), hydratedOrder.getVersion() - 1);

  readModel = await storeManager.getOrderReadModel(orderId);
  console.log('Read Model after Payment:', JSON.stringify(readModel, null, 2));
}

runDemo().catch(console.error);
