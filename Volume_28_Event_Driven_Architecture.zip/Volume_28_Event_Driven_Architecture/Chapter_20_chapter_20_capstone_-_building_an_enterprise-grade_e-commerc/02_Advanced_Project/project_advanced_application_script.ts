/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

// ============================================================================
// CORE DOMAIN & EVENT SOURCING INFRASTRUCTURE
// ============================================================================

/**
 * Represents the base contract for all domain events in the system.
 * Immutable State Management: Events are records of facts that have occurred 
 * and can never be modified.
 */
export interface DomainEvent {
  readonly eventId: string;
  readonly aggregateId: string;
  readonly eventType: string;
  readonly version: number;
  readonly timestamp: Date;
  readonly payload: Record<string, unknown>;
}

/**
 * In-memory / Durable Event Store abstraction for Event Sourcing.
 */
export class EventStore {
  private events: DomainEvent[] = [];

  /**
   * Appends new uncommitted events to the store with optimistic concurrency checks.
   */
  async saveEvents(aggregateId: string, expectedVersion: number, newEvents: DomainEvent[]): Promise<void> {
    const currentStream = this.events.filter(e => e.aggregateId === aggregateId);
    const currentVersion = currentStream.length;

    if (currentVersion !== expectedVersion) {
      raiseConcurrencyError(aggregateId, expectedVersion, currentVersion);
    }

    for (const event of newEvents) {
      this.events.push(event);
    }
  }

  /**
   * Retrieves all events for a given aggregate root to hydrate its state.
   */
  async getEventsForAggregate(aggregateId: string): Promise<DomainEvent[]> {
    return this.events.filter(e => e.aggregateId === aggregateId);
  }
}

function raiseConcurrencyError(aggregateId: string, expected: number, actual: number): never {
  throw new Error(`Concurrency Conflict on Aggregate ${aggregateId}. Expected version ${expected}, but found ${actual}.`);
}

// ============================================================================
// AGGREGATE ROOT IMPLEMENTATION
// ============================================================================

export type OrderStatus = 'PENDING' | 'PAID' | 'SHIPPED' | 'CANCELLED';

/**
 * Order Aggregate Root implementing Event Sourcing and Immutable State Management.
 */
export class OrderAggregate {
  private id: string;
  private version: number = 0;
  private status: OrderStatus = 'PENDING';
  private uncommittedEvents: DomainEvent[] = [];

  private constructor(id: string) {
    this.id = id;
  }

  /**
   * Factory method to create a new Order via a domain command.
   */
  public static createNewOrder(orderId: string, customerId: string, totalAmount: number): OrderAggregate {
    const order = new OrderAggregate(orderId);
    order.applyChange({
      eventId: randomUUID(),
      aggregateId: orderId,
      eventType: 'OrderPlaced',
      version: 1,
      timestamp: new Date(),
      payload: { customerId, totalAmount }
    });
    return order;
  }

  /**
   * Hydrates the aggregate state from an array of historical events.
   */
  public static hydrate(events: DomainEvent[]): OrderAggregate {
    if (events.length === 0) {
      throw new Error("Cannot hydrate aggregate from empty event stream.");
    }
    const order = new OrderAggregate(events[0].aggregateId);
    for (const event of events) {
      order.applyEventToState(event);
      order.version = event.version;
    }
    return order;
  }

  private applyChange(event: DomainEvent): void {
    this.applyEventToState(event);
    this.uncommittedEvents.push(event);
    this.version++;
  }

  private applyEventToState(event: DomainEvent): void {
    switch (event.eventType) {
      case 'OrderPlaced':
        this.status = 'PENDING';
        break;
      case 'PaymentConfirmed':
        this.status = 'PAID';
        break;
      case 'OrderShipped':
        this.status = 'SHIPPED';
        break;
      case 'OrderCancelled':
        this.status = 'CANCELLED';
        break;
      default:
        throw new Error(`Unhandled event type: ${event.eventType}`);
    }
  }

  public confirmPayment(): void {
    if (this.status !== 'PENDING') {
      throw new Error(`Cannot confirm payment for order in status: ${this.status}`);
    }
    this.applyChange({
      eventId: randomUUID(),
      aggregateId: this.id,
      eventType: 'PaymentConfirmed',
      version: this.version + 1,
      timestamp: new Date(),
      payload: {}
    });
  }

  public shipOrder(): void {
    if (this.status !== 'PAID') {
      throw new Error(`Cannot ship order that is not paid. Current status: ${this.status}`);
    }
    this.applyChange({
      eventId: randomUUID(),
      aggregateId: this.id,
      eventType: 'OrderShipped',
      version: this.version + 1,
      timestamp: new Date(),
      payload: {}
    });
  }

  public getUncommittedEvents(): DomainEvent[] {
    return [...this.uncommittedEvents];
  }

  public markEventsAsCommitted(): void {
    this.uncommittedEvents = [];
  }

  public getVersion(): number {
    return this.version;
  }
}

// ============================================================================
// SAGAS & ORCHESTRATION LAYER
// ============================================================================

/**
 * Order Fulfillment Saga Coordinator.
 * Manages distributed transactions across Payment and Shipping bounded contexts.
 */
export class OrderFulfillmentSaga {
  constructor(private eventStore: EventStore) {}

  /**
   * Handles incoming domain events and orchestrates subsequent actions.
   */
  async handleEvent(event: DomainEvent): Promise<void> {
    switch (event.eventType) {
      case 'OrderPlaced':
        await this.processPaymentStep(event);
        break;
      case 'PaymentConfirmed':
        await this.processShippingStep(event);
        break;
      default:
        // Ignore unhandled events for this saga
        break;
    }
  }

  private async processPaymentStep(event: DomainEvent): Promise<void> {
    console.log(`[SAGA] Order ${event.aggregateId} placed. Initiating Payment Gateway Charge...`);
    
    // Simulate external payment service integration with idempotency key
    const paymentSuccessful = true; 

    const events = await this.eventStore.getEventsForAggregate(event.aggregateId);
    const order = OrderAggregate.hydrate(events);

    if (paymentSuccessful) {
      order.confirmPayment();
      await this.eventStore.saveEvents(event.aggregateId, order.getVersion() - 1, order.getUncommittedEvents());
      order.markEventsAsCommitted();
      console.log(`[SAGA] Payment confirmed for Order ${event.aggregateId}`);
    } else {
      // Trigger compensating transaction / cancellation logic
      console.error(`[SAGA] Payment failed for Order ${event.aggregateId}. Initiating compensation.`);
    }
  }

  private async processShippingStep(event: DomainEvent): Promise<void> {
    console.log(`[SAGA] Payment confirmed for ${event.aggregateId}. Requesting Warehouse Fulfillment...`);
    
    const events = await this.eventStore.getEventsForAggregate(event.aggregateId);
    const order = OrderAggregate.hydrate(events);

    order.shipOrder();
    await this.eventStore.saveEvents(event.aggregateId, order.getVersion() - 1, order.getUncommittedEvents());
    order.markEventsAsCommitted();
    console.log(`[SAGA] Order ${event.aggregateId} successfully shipped and fulfilled.`);
  }
}

// ============================================================================
// EXECUTION DEMONSTRATION
// ============================================================================

async function runEnterpriseOrderWorkflow() {
  const eventStore = new EventStore();
  const sagaCoordinator = new OrderFulfillmentSaga(eventStore);

  const orderId = randomUUID();
  const customerId = randomUUID();

  console.log('--- 1. CREATING NEW ORDER AGGREGATE ---');
  const order = OrderAggregate.createNewOrder(orderId, customerId, 250.00);
  const uncommitted = order.getUncommittedEvents();
  
  await eventStore.saveEvents(orderId, 0, uncommitted);
  order.markEventsAsCommitted();

  console.log('--- 2. TRIGGERING SAGA WORKFLOW VIA EVENT DISPATCH ---');
  for (const event of uncommitted) {
    await sagaCoordinator.handleEvent(event);
  }

  // Simulate subsequent event dispatch loop for the next saga step
  const updatedEvents = await eventStore.getEventsForAggregate(orderId);
  const latestEvent = updatedEvents[updatedEvents.length - 1];
  if (latestEvent.eventType === 'PaymentConfirmed') {
    await sagaCoordinator.handleEvent(latestEvent);
  }

  console.log('--- 3. FINAL AGGREGATE HYDRATION & VERIFICATION ---');
  const finalStream = await eventStore.getEventsForAggregate(orderId);
  const finalHydratedOrder = OrderAggregate.hydrate(finalStream);
  console.log(`Final Order Version: ${finalHydratedOrder.getVersion()}`);
}

runEnterpriseOrderWorkflow().catch(console.error);
