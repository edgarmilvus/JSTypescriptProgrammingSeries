/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface DomainEvent {
  eventId: string;
  aggregateId: string;
  version: number;
  timestamp: Date;
  type: string;
  data: Record<string, any>;
}

export interface OrderItem {
  productId: string;
  quantity: number;
  price: number;
}

export type OrderStatus = 'PENDING' | 'PAID' | 'FULFILLED' | 'CANCELLED';

export interface OrderCreatedEvent extends DomainEvent {
  type: 'OrderCreated';
  data: {
    orderId: string;
    customerId: string;
    currency: string;
    items: OrderItem[];
  };
}

export interface ItemAddedEvent extends DomainEvent {
  type: 'ItemAdded';
  data: {
    item: OrderItem;
  };
}

export interface PaymentProcessedEvent extends DomainEvent {
  type: 'PaymentProcessed';
  data: {
    paymentId: string;
    amount: number;
  };
}

export interface OrderFulfilledEvent extends DomainEvent {
  type: 'OrderFulfilled';
  data: {};
}

export interface OrderCancelledEvent extends DomainEvent {
  type: 'OrderCancelled';
  data: {
    reason: string;
  };
}

export abstract class AggregateRoot {
  private changes: DomainEvent[] = [];
  protected version: number = 0;

  public getUncommittedChanges(): DomainEvent[] {
    return [...this.changes];
  }

  public markChangesAsCommitted(): void {
    this.changes = [];
  }

  protected applyChange(event: DomainEvent, isNew: boolean = true): void {
    this.apply(event);
    if (isNew) {
      this.changes.push(event);
    }
    this.version = event.version;
  }

  protected abstract apply(event: DomainEvent): void;
}

export class Order extends AggregateRoot {
  private orderId!: string;
  private customerId!: string;
  private currency: string = 'USD';
  private items: OrderItem[] = [];
  private status: OrderStatus = 'PENDING';
  private totalAmount: number = 0;

  private constructor() {
    super();
  }

  public static create(orderId: string, customerId: string, currency: string = 'USD'): Order {
    const order = new Order();
    const event: OrderCreatedEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: orderId,
      version: 1,
      timestamp: new Date(),
      type: 'OrderCreated',
      data: { orderId, customerId, currency, items: [] }
    };
    order.applyChange(event);
    return order;
  }

  public addItem(item: OrderItem): void {
    if (this.status !== 'PENDING') {
      throw new Error(`Cannot add items to an order with status: ${this.status}`);
    }

    const event: ItemAddedEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this.orderId,
      version: this.version + 1,
      timestamp: new Date(),
      type: 'ItemAdded',
      data: { item }
    };
    this.applyChange(event);
  }

  public processPayment(paymentId: string, amount: number): void {
    if (this.status !== 'PENDING') {
      throw new Error(`Cannot process payment for an order with status: ${this.status}`);
    }
    if (amount < this.totalAmount) {
      throw new Error('Insufficient payment amount.');
    }

    const event: PaymentProcessedEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this.orderId,
      version: this.version + 1,
      timestamp: new Date(),
      type: 'PaymentProcessed',
      data: { paymentId, amount }
    };
    this.applyChange(event);
  }

  public fulfillOrder(): void {
    if (this.status !== 'PAID') {
      throw new Error(`Cannot fulfill an order that is not paid. Current status: ${this.status}`);
    }

    const event: OrderFulfilledEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this.orderId,
      version: this.version + 1,
      timestamp: new Date(),
      type: 'OrderFulfilled',
      data: {}
    };
    this.applyChange(event);
  }

  public cancelOrder(reason: string): void {
    if (this.status === 'FULFILLED' || this.status === 'CANCELLED') {
      throw new Error(`Cannot cancel an order with status: ${this.status}`);
    }

    const event: OrderCancelledEvent = {
      eventId: crypto.randomUUID(),
      aggregateId: this.orderId,
      version: this.version + 1,
      timestamp: new Date(),
      type: 'OrderCancelled',
      data: { reason }
    };
    this.applyChange(event);
  }

  protected apply(event: DomainEvent): void {
    switch (event.type) {
      case 'OrderCreated':
        this.orderId = event.data.orderId;
        this.customerId = event.data.customerId;
        this.currency = event.data.currency || 'USD';
        this.items = [...event.data.items];
        this.status = 'PENDING';
        this.calculateTotal();
        break;
      case 'ItemAdded':
        this.items = [...this.items, event.data.item];
        this.calculateTotal();
        break;
      case 'PaymentProcessed':
        this.status = 'PAID';
        break;
      case 'OrderFulfilled':
        this.status = 'FULFILLED';
        break;
      case 'OrderCancelled':
        this.status = 'CANCELLED';
        break;
      default:
        throw new Error(`Unknown event type: ${(event as any).type}`);
    }
  }

  private calculateTotal(): void {
    this.totalAmount = this.items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  }

  public static loadFromHistory(history: DomainEvent[]): Order {
    const order = new Order();
    for (const rawEvent of history) {
      const upcastedEvent = upcastOrderEvent(rawEvent);
      order.applyChange(upcastedEvent, false);
    }
    return order;
  }
}

export function upcastOrderEvent(event: DomainEvent): DomainEvent {
  if (event.type === 'OrderCreated' && event.version === 1) {
    return {
      ...event,
      version: 2,
      data: {
        ...event.data,
        currency: 'USD' // Upcast default currency for legacy version 1 events
      }
    };
  }
  return event;
}
