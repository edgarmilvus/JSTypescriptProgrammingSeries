/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { DomainEvent } from './domain-event.base';

export interface OrderSummaryReadModel {
  orderId: string;
  customerId: string;
  status: string;
  totalAmount: number;
  itemCount: number;
  lastEventId: string;
}

export interface IReadModelRepository {
  getById(orderId: string): Promise<OrderSummaryReadModel | null>;
  save(model: OrderSummaryReadModel): Promise<void>;
  hasProcessedEvent(eventId: string): Promise<boolean>;
  markEventProcessed(eventId: string): Promise<void>;
}

export interface IEventHandler<TEvent extends DomainEvent> {
  handle(event: TEvent): Promise<void>;
}

export interface StagedEvent {
  event: DomainEvent;
  receivedAt: Date;
  retryCount: number;
}

export class OrderSummaryProjector {
  private dlq: StagedEvent[] = [];

  constructor(private readonly repository: IReadModelRepository) {}

  public async project(event: DomainEvent): Promise<void> {
    const alreadyProcessed = await this.repository.hasProcessedEvent(event.eventId);
    if (alreadyProcessed) {
      return; // Idempotency check: skip duplicated events
    }

    try {
      await this.handleEvent(event);
      await this.repository.markEventProcessed(event.eventId);
    } catch (error: any) {
      await this.handleOrphanedEvent(event, error);
    }
  }

  private async handleEvent(event: DomainEvent): Promise<void> {
    switch (event.type) {
      case 'OrderCreated': {
        const { orderId, customerId, items } = event.data;
        const totalAmount = items.reduce((sum: number, i: any) => sum + i.price * i.quantity, 0);
        
        await this.repository.save({
          orderId,
          customerId,
          status: 'PENDING',
          totalAmount,
          itemCount: items.length,
          lastEventId: event.eventId
        });
        break;
      }
      case 'ItemAdded': {
        const { orderId, item } = event.data;
        const summary = await this.repository.getById(orderId);
        if (!summary) {
          throw new Error(`Orphaned event: OrderCreated missing for orderId ${orderId}`);
        }

        summary.itemCount += 1;
        summary.totalAmount += item.price * item.quantity;
        summary.lastEventId = event.eventId;
        await this.repository.save(summary);
        break;
      }
      case 'PaymentProcessed': {
        const { orderId } = event.data;
        const summary = await this.repository.getById(orderId);
        if (!summary) {
          throw new Error(`Orphaned event: OrderCreated missing for orderId ${orderId}`);
        }

        summary.status = 'PAID';
        summary.lastEventId = event.eventId;
        await this.repository.save(summary);
        break;
      }
      case 'OrderCancelled': {
        const { orderId } = event.data;
        const summary = await this.repository.getById(orderId);
        if (!summary) {
          throw new Error(`Orphaned event: OrderCreated missing for orderId ${orderId}`);
        }

        summary.status = 'CANCELLED';
        summary.lastEventId = event.eventId;
        await this.repository.save(summary);
        break;
      }
    }
  }

  public async handleOrphanedEvent(event: DomainEvent, error: Error): Promise<void> {
    this.dlq.push({
      event,
      receivedAt: new Date(),
      retryCount: 1
    });
  }

  public async processStagedEvents(): Promise<void> {
    const currentDlq = [...this.dlq];
    this.dlq = [];

    for (const staged of currentDlq) {
      try {
        await this.handleEvent(staged.event);
        await this.repository.markEventProcessed(staged.event.eventId);
      } catch (err) {
        staged.retryCount += 1;
        if (staged.retryCount <= 3) {
          this.dlq.push(staged); // Re-stage if under max retries
        }
      }
    }
  }
}
