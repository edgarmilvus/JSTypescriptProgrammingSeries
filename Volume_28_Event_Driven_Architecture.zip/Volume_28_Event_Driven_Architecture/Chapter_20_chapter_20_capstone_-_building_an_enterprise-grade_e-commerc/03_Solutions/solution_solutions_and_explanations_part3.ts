/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export type SagaState = 
  | 'Started' 
  | 'InventoryReserved' 
  | 'PaymentProcessed' 
  | 'ShippingScheduled' 
  | 'Completed' 
  | 'Compensating' 
  | 'Failed';

export interface RetryPolicy {
  maxRetries: number;
  initialDelayMs: number;
  backoffFactor: number;
}

export async function executeWithRetry<T>(
  operation: () => Promise<T>,
  policy: RetryPolicy
): Promise<T> {
  let attempt = 0;
  let delay = policy.initialDelayMs;

  while (true) {
    try {
      return await operation();
    } catch (error) {
      attempt++;
      if (attempt > policy.maxRetries) {
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, delay));
      delay *= policy.backoffFactor;
    }
  }
}

export class OrderCheckoutSagaOrchestrator {
  private state: SagaState = 'Started';

  constructor(
    private readonly orderId: string,
    private readonly inventoryClient: { reserve: () => Promise<void>; release: () => Promise<void> },
    private readonly paymentClient: { process: () => Promise<void>; refund: () => Promise<void> },
    private readonly shippingClient: { schedule: () => Promise<void>; cancel: () => Promise<void> },
    private readonly retryPolicy: RetryPolicy
  ) {}

  public async execute(): Promise<void> {
    try {
      // Step 1: Reserve Inventory
      await executeWithRetry(() => this.inventoryClient.reserve(), this.retryPolicy);
      this.state = 'InventoryReserved';

      // Step 2: Process Payment
      await executeWithRetry(() => this.paymentClient.process(), this.retryPolicy);
      this.state = 'PaymentProcessed';

      // Step 3: Schedule Shipping
      await executeWithRetry(() => this.shippingClient.schedule(), this.retryPolicy);
      this.state = 'ShippingScheduled';

      this.state = 'Completed';
    } catch (error) {
      await this.compensate();
    }
  }

  private async compensate(): Promise<void> {
    this.state = 'Compensating';
    const currentState = this.state;

    try {
      if (
        currentState === 'ShippingScheduled' ||
        this.hasReached('ShippingScheduled')
      ) {
        await this.shippingClient.cancel();
      }
      if (
        currentState === 'PaymentProcessed' ||
        this.hasReached('PaymentProcessed')
      ) {
        await this.paymentClient.refund();
      }
      if (
        currentState === 'InventoryReserved' ||
        this.hasReached('InventoryReserved')
      ) {
        await this.inventoryClient.release();
      }
      this.state = 'Failed';
    } catch (compError) {
      this.state = 'Failed';
      throw new Error(`Critical: Compensation workflow failed for order ${this.orderId}: ${compError}`);
    }
  }

  private hasReached(targetState: SagaState): boolean {
    const states: SagaState[] = ['Started', 'InventoryReserved', 'PaymentProcessed', 'ShippingScheduled', 'Completed'];
    return states.indexOf(this.state) >= states.indexOf(targetState);
  }
}
