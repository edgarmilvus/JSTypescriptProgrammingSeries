/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useReducer, useEffect } from 'react';

export interface DomainEvent {
  eventId: string;
  aggregateId: string;
  version: number;
  timestamp: Date;
  type: string;
  data: Record<string, any>;
}

interface TimeTravelState {
  events: DomainEvent[];
  currentIndex: number;
}

type TimeTravelAction =
  | { type: 'ADD_EVENT'; event: DomainEvent }
  | { type: 'SET_INDEX'; index: number };

function timeTravelReducer(state: TimeTravelState, action: TimeTravelAction): TimeTravelState {
  switch (action.type) {
    case 'ADD_EVENT':
      const updatedEvents = [...state.events, action.event];
      return {
        events: updatedEvents,
        currentIndex: updatedEvents.length - 1
      };
    case 'SET_INDEX':
      return {
        ...state,
        currentIndex: Math.max(0, Math.min(action.index, state.events.length - 1))
      };
    default:
      return state;
  }
}

export const OrderTimeTravelControls: React.FC<{
  events: DomainEvent[];
  currentIndex: number;
  onIndexChange: (index: number) => void;
}> = ({ events, currentIndex, onIndexChange }) => {
  if (events.length === 0) return null;

  return (
    <div style={{ padding: '1rem', background: '#f4f4f4', borderRadius: '4px', margin: '1rem 0' }}>
      <label htmlFor="time-travel-slider" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
        Event Time-Travel Debugger ({currentIndex + 1} of {events.length} events)
      </label>
      <input
        id="time-travel-slider"
        type="range"
        min={0}
        max={events.length - 1}
        value={currentIndex}
        onChange={(e) => onIndexChange(Number(e.target.value))}
        style={{ width: '100%' }}
      />
      <div style={{ fontSize: '0.85rem', color: '#666', marginTop: '0.25rem' }}>
        Active Event: {events[currentIndex]?.type} at {new Date(events[currentIndex]?.timestamp).toLocaleTimeString()}
      </div>
    </div>
  );
};

export const OrderTrackingDashboard: React.FC<{ wsEndpoint: string; orderId: string }> = ({ wsEndpoint, orderId }) => {
  const [state, dispatch] = useReducer(timeTravelReducer, { events: [], currentIndex: 0 });
  const [connectionStatus, setConnectionStatus] = useState<'Connected' | 'Reconnecting...' | 'Disconnected'>('Disconnected');

  useEffect(() => {
    let ws: WebSocket;
    let heartbeatInterval: any;

    const connect = () => {
      setConnectionStatus('Reconnecting...');
      ws = new WebSocket(wsEndpoint);

      ws.onopen = () => {
        setConnectionStatus('Connected');
        heartbeatInterval = setInterval(() => ws.send(JSON.stringify({ type: 'PING' })), 30000);
      };

      ws.onmessage = (event) => {
        const message: DomainEvent = JSON.parse(event.data);
        if (message.aggregateId === orderId) {
          dispatch({ type: 'ADD_EVENT', event: message });
        }
      };

      ws.onclose = () => {
        setConnectionStatus('Disconnected');
        clearInterval(heartbeatInterval);
        setTimeout(connect, 5000);
      };
    };

    connect();

    return () => {
      clearInterval(heartbeatInterval);
      if (ws) ws.close();
    };
  }, [wsEndpoint, orderId]);

  const visibleEvents = state.events.slice(0, state.currentIndex + 1);
  const currentStatus = visibleEvents.reduce((acc, ev) => {
    switch (ev.type) {
      case 'OrderCreated': return 'PENDING';
      case 'PaymentProcessed': return 'PAID';
      case 'OrderFulfilled': return 'FULFILLED';
      case 'OrderCancelled': return 'CANCELLED';
      default: return acc;
    }
  }, 'INITIAL');

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: '800px', margin: 'auto' }}>
      <h2>Order Tracking Dashboard: {orderId}</h2>
      <div style={{ padding: '0.5rem 1rem', background: connectionStatus === 'Connected' ? '#d4edda' : '#f8d7da', color: connectionStatus === 'Connected' ? '#155724' : '#721c24', marginBottom: '1rem', borderRadius: '4px' }}>
        Status: <strong>{connectionStatus}</strong>
      </div>

      <div>
        <h3>Current Order State: <span style={{ color: '#007bff' }}>{currentStatus}</span></h3>
      </div>

      <OrderTimeTravelControls
        events={state.events}
        currentIndex={state.currentIndex}
        onIndexChange={(index) => dispatch({ type: 'SET_INDEX', index })}
      />

      <div style={{ marginTop: '2rem' }}>
        <h4>Event Stream Log</h4>
        <ul>
          {visibleEvents.map((ev, idx) => (
            <li key={ev.eventId || idx} style={{ marginBottom: '0.5rem' }}>
              <code>{ev.type}</code> (v{ev.version}) - {new Date(ev.timestamp).toLocaleTimeString()}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
