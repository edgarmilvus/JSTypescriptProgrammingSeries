/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// SaaS Telemetry Monitor Frontend - Tauri 2.0 IPC Integration Example
// ============================================================================

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing the system telemetry payload returned by the Rust backend.
 * Ensures type safety across the IPC boundary.
 */
interface SystemTelemetry {
    cpuUsage: number;
    memoryAllocatedBytes: number;
    activeWorkerThreads: number;
    status: 'OPTIMAL' | 'WARNING' | 'CRITICAL';
}

/**
 * Interface representing incoming background events pushed from the Rust core.
 */
interface HeartbeatEvent {
    timestamp: number;
    nodeId: string;
}

/**
 * Main application controller class managing the lifecycle of Tauri IPC interactions.
 */
class TelemetryDashboardController {
    private unlistenHeartbeat: UnlistenFn | null = null;
    private isMonitoring: boolean = false;

    constructor(private readonly tenantId: string) {
        console.log(`[Dashboard] Initializing telemetry monitor for tenant: ${this.tenantId}`);
    }

    /**
     * Asynchronously requests an immediate system health check from the Rust backend.
     * Uses Tauri 2.0's type-safe `invoke` function.
     * 
     * @returns {Promise<SystemTelemetry>} The current system metrics.
     */
    public async fetchSystemTelemetry(): Promise<SystemTelemetry> {
        try {
            // The string 'get_system_telemetry' maps directly to a #[tauri::command] in Rust.
            // We pass a typed payload object to demonstrate argument passing over IPC.
            const telemetry = await invoke<SystemTelemetry>('get_system_telemetry', {
                tenantContext: this.tenantId,
                requestTimestamp: Date.now(),
            });

            return telemetry;
        } catch (error) {
            // Tauri IPC errors can originate from serialization failures, Rust panics,
            // or security permission rejections.
            console.error('[Dashboard] Failed to fetch system telemetry over IPC:', error);
            throw new Error(`IPC Communication Failure: ${JSON.stringify(error)}`);
        }
    }

    /**
     * Subscribes to an asynchronous event stream emitted by the Rust background threads.
     * Demonstrates bidirectional communication (Server-Sent Events equivalent inside desktop apps).
     */
    public async subscribeToHeartbeats(onPulse: (event: HeartbeatEvent) => void): Promise<void> {
        if (this.isMonitoring) {
            console.warn('[Dashboard] Heartbeat subscription already active.');
            return;
        }

        try {
            // Listen to the 'rust-node-heartbeat' event emitted via app_handle.emit() in Rust
            this.unlistenHeartbeat = await listen<HeartbeatEvent>('rust-node-heartbeat', (event) => {
                // event.payload contains the typed data structure pushed from backend
                onPulse(event.payload);
            });

            this.isMonitoring = true;
            console.log('[Dashboard] Successfully subscribed to backend heartbeats.');
        } catch (error) {
            console.error('[Dashboard] Failed to establish event listener:', error);
        }
    }

    /**
     * Cleans up event listeners when the dashboard component unmounts or terminates.
     * Prevents memory leaks in the web-view context.
     */
    public async teardown(): Promise<void> {
        if (this.unlistenHeartbeat) {
            this.unlistenHeartbeat();
            this.unlistenHeartbeat = null;
            this.isMonitoring = false;
            console.log('[Dashboard] Teardown complete. Event listeners unlinked.');
        }
    }
}

// ============================================================================
// Execution Example (Simulating a React/Vue Component Mount lifecycle)
// ============================================================================

(async () => {
    const dashboard = new TelemetryDashboardController('tenant_alpha_992');

    try {
        // 1. Fetch initial state via Command Invoke
        const initialMetrics = await dashboard.fetchSystemTelemetry();
        console.log('[App] Initial Telemetry Received:', initialMetrics);

        // 2. Setup real-time event subscription
        await dashboard.subscribeToHeartbeats((heartbeat) => {
            console.log(`[App] Heartbeat received from Node ${heartbeat.nodeId} at ${new Date(heartbeat.timestamp).toISOString()}`);
        });

        // Simulate running for 10 seconds before tearing down
        setTimeout(async () => {
            await dashboard.teardown();
        }, 10000);

    } catch (err) {
        console.error('[App] Critical failure during dashboard initialization:', err);
    }
})();
