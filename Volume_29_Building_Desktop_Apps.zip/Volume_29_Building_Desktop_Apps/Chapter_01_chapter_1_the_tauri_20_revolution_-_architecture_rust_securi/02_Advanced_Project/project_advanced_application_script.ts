/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file vector-indexer-manager.ts
 * @description Advanced Tauri 2.0 frontend orchestration script for an offline 
 * vector embedding developer tool. Manages IPC bridge communications, payload 
 * serialization, capability validation, and real-time indexing progress tracking.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing the configuration payload required by the Rust core
 * to initialize the text embedding pipeline.
 */
interface IndexingConfig {
  targetDirectory: string;
  chunkSize: number;
  overlap: number;
  embeddingModel: 'text-embedding-3-small' | 'local-mini-lm';
  batchSize: number;
}

/**
 * Interface representing a real-time progress update emitted from the 
 * Rust backend via Tauri's event system.
 */
interface IndexingProgressEvent {
  jobId: string;
  filesProcessed: number;
  totalFiles: number;
  currentFile: string;
  status: 'scanning' | 'chunking' | 'embedding' | 'completed' | 'failed';
  errorMessage?: string;
}

/**
 * Interface representing the final structured output returned by the 
 * Rust vector generation engine.
 */
interface IndexingResult {
  jobId: string;
  totalEmbeddingsGenerated: number;
  durationMs: number;
  vectorDatabasePath: string;
}

/**
 * Core manager class handling all interactions between the TypeScript frontend
 * and the secure Tauri 2.0 Rust backend.
 */
export class VectorIndexerManager {
  private activeJobId: string | null = null;
  private progressListeners: Array<(progress: IndexingProgressEvent) => void> = [];
  private unlistenProgress: UnlistenFn | null = null;

  constructor() {
    this.initializeEventListener();
  }

  /**
   * Sets up the global event listener to capture asynchronous progress updates
   * streamed from the Rust core over Tauri's IPC event bus.
   */
  private async initializeEventListener(): Promise<void> {
    try {
      // Listen to the 'vector-indexer://progress' event channel registered in Rust
      this.unlistenProgress = await listen<IndexingProgressEvent>(
        'vector-indexer://progress',
        (event) => {
          // Verify event payload belongs to the currently active job context
          if (this.activeJobId && event.payload.jobId === this.activeJobId) {
            this.notifyListeners(event.payload);
          }
        }
      );
    } catch (error) {
      console.error('Failed to initialize Tauri event listener:', error);
      throw new Error('IPC Event Listener Initialization Failed');
    }
  }

  /**
   * Registers a callback function to receive real-time updates during indexing.
   * 
   * @param callback Function executed on every progress event emission.
   */
  public subscribeToProgress(callback: (progress: IndexingProgressEvent) => void): () => void {
    this.progressListeners.push(callback);
    // Return an unsubscription cleanup function
    return () => {
      this.progressListeners = this.progressListeners.filter(cb => cb !== callback);
    };
  }

  /**
   * Dispatches updates to all active UI subscribers.
   */
  private notifyListeners(progress: IndexingProgressEvent): void {
    for (const listener of this.progressListeners) {
      try {
        listener(progress);
      } catch (err) {
        console.error('Error in progress listener callback:', err);
      }
    }
  }

  /**
   * Triggers the secure Rust backend command to start scanning and embedding a directory.
   * Leverages Tauri 2.0's type-safe `invoke` mechanism backed by capability permissions.
   * 
   * @param config The structural parameters defining how the codebase is indexed.
   * @returns A promise resolving to the final indexing execution metrics.
   */
  public async startIndexingJob(config: IndexingConfig): Promise<IndexingResult> {
    // Basic structural validation on the frontend before hitting the IPC boundary
    if (!config.targetDirectory || config.targetDirectory.trim() === '') {
      throw new Error('Target directory path cannot be empty.');
    }

    if (config.chunkSize <= 0 || config.overlap < 0) {
      throw new Error('Invalid chunk size or overlap parameters.');
    }

    // Generate a secure pseudo-random job identifier for tracking
    this.activeJobId = `job_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

    try {
      console.info(`[Tauri IPC] Invoking 'start_vector_indexing' with Job ID: ${this.activeJobId}`);

      // Invoke the Rust command registered in Tauri's builder context
      const result = await invoke<IndexingResult>('start_vector_indexing', {
        jobId: this.activeJobId,
        config: {
          ...config,
          target_directory: config.targetDirectory, // Mapping to Rust snake_case expectations if needed
          chunk_size: config.chunkSize,
          embedding_model: config.embeddingModel,
          batch_size: config.batchSize,
        },
      });

      console.info(`[Tauri IPC] Indexing completed successfully for Job ID: ${this.activeJobId}`);
      return result;

    } catch (error) {
      // Catch serialization or Rust panic errors safely across the IPC boundary
      console.error(`[Tauri IPC Error] Failed to execute indexing job:`, error);
      throw new Error(`Indexing execution failed: ${String(error)}`);
    } finally {
      this.activeJobId = null;
    }
  }

  /**
   * Gracefully cleans up event listeners when the manager instance is destroyed.
   */
  public async destroy(): Promise<void> {
    if (this.unlistenProgress) {
      this.unlistenProgress();
      this.unlistenProgress = null;
    }
    this.progressListeners = [];
  }
}

/**
 * Singleton export for application-wide usage inside React/Next.js state management layers.
 */
export const vectorIndexer = new VectorIndexerManager();
