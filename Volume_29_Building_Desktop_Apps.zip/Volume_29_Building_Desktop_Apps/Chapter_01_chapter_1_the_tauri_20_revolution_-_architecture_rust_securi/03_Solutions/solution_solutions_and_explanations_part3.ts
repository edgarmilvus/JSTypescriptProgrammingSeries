/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect } from 'react';
import { listen } from '@tauri-apps/api/event';
import { invoke } from '@tauri-apps/api/core';

export type ModelStatus = 'cold' | 'initializing' | 'warm_ready' | 'error';

export interface WarmStartPayload {
  modelId: string;
  status: ModelStatus;
  memoryUsageBytes: number;
  averageInferenceLatencyMs: number;
  timestamp: number;
}

/**
   * Custom hook adhering to SRP: handles event subscriptions and sliding-window calculations.
   */
export function useWarmStartListener() {
  const [payload, setPayload] = useState<WarmStartPayload | null>(null);
  const [movingAvgLatency, setMovingAvgLatency] = useState<number>(0);
  const [latencyHistory, setLatencyHistory] = useState<number[]>([]);

  useEffect(() => {
    let isMounted = true;

    const unlistenPromise = listen<WarmStartPayload>('ai://warm-start-update', (event) => {
      if (!isMounted) return;
      const data = event.payload;
      setPayload(data);

      setLatencyHistory((prev) => {
        const updated = [...prev, data.averageInferenceLatencyMs].slice(-10);
        const sum = updated.reduce((acc, val) => acc + val, 0);
        setMovingAvgLatency(sum / updated.length);
        return updated;
      });
    });

    return () => {
      isMounted = false;
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, []);

  const triggerProbe = async () => {
    try {
      await invoke('ping_ai_sidecar');
    } catch (err) {
      console.error('Failed to probe AI sidecar:', err);
    }
  };

  return { payload, movingAvgLatency, triggerProbe };
}
