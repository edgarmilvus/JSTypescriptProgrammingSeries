/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { listen, UnlistenFn } from '@tauri-apps/api/event';
import { invoke } from '@tauri-apps/api/core';

export interface ComputeProgress {
  jobId: string;
  percentComplete: number;
}

export class ComputeWorkerManager {
  /**
   * Submits a compute job asynchronously, returning its unique job ID.
   */
  public static async submitJob(payloadData: string): Promise<string> {
    const jobId = await invoke<string>('submit_compute_job', { payloadData });
    return jobId;
  }

  /**
   * Cancels an active compute job using its identifier.
   */
  public static async cancelJob(jobId: string): Promise<void> {
    await invoke('cancel_compute_job', { jobId });
  }

  /**
   * Listens for progress updates specific to a given job ID.
   */
  public static async trackProgress(
    jobId: string,
    onProgress: (percent: number) => void,
    onComplete: (result: any) => void
  ): Promise<() => void> {
    const unlistenProgress: UnlistenFn = await listen<ComputeProgress>('compute://progress', (event) => {
      if (event.payload.jobId === jobId) {
        onProgress(event.payload.percentComplete);
      }
    });

    const unlistenComplete: UnlistenFn = await listen<{ jobId: string; result: any }>('compute://complete', (event) => {
      if (event.payload.jobId === jobId) {
        onComplete(event.payload.result);
        unlistenProgress();
        unlistenComplete();
      }
    });

    return () => {
      unlistenProgress();
      unlistenComplete();
    };
  }
}
