/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f8f9fa", color="#dee2e6"];
edge [fontname="Arial", color="#6c757d"];

subgraph cluster_frontend {
    label = "Web View Layer (Vite & TypeScript)";
    style = dashed;
    color = "#adb5bd";
    
    TS [label="TypeScript UI / Components"];
    ESM [label="ECMAScript Modules (ESM)"];
    Vite [label="Vite Bundler & HMR Engine"];
    
    TS -> ESM;
    ESM -> Vite;
}

subgraph cluster_ipc {
    label = "IPC Bridge (Serialization / Deserialization)";
    style = solid;
    color = "#495057";
    
    Command [label="Invoke Commands / Emit Events"];
}

subgraph cluster_backend {
    label = "Native Rust Backend Process";
    style = dashed;
    color = "#adb5bd";
    
    TauriCore [label="Tauri Core / Event Loop"];
    Plugins [label="Native Plugins & System APIs"];
    AsyncRuntime [label="Tokio Async Runtime"];
    
    TauriCore -> AsyncRuntime;
    AsyncRuntime -> Plugins;
}

TS -> Command [label="JSON / Serde"];
Command -> TauriCore [label="IPC Message Passing"];
