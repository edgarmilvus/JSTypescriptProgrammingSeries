/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

rankdir=TB;
node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f8f9fa", color="#dee2e6"];
edge [fontname="Arial", color="#6c757d"];

subgraph cluster_webview {
    label = "Web View (JavaScript / TypeScript Context)";
    style = filled;
    color = "#e9ecef";
    
    Invoker [label="window.__TAURI__.core.invoke('command_name', payload)"];
    Listener [label="listen('event-name', callback)"];
}

subgraph cluster_bridge {
    label = "Secure IPC Bridge";
    style = solid;
    color = "#ced4da";
    
    Serialization [label="JSON Serialization & Sanitization"];
}

subgraph cluster_rust {
    label = "Rust Core Process";
    style = filled;
    color = "#e9ecef";
    
    CommandHandler [label="#[tauri::command]\nfn command_name(payload: Payload)"];
    Emitter [label="app.emit('event-name', data)"];
}

Invoker -> Serialization [label="1. Async Request"];
Serialization -> CommandHandler [label="2. Deserialization"];
CommandHandler -> Emitter [label="3. Background Processing"];
Emitter -> Serialization [label="4. Response / Stream"];
Serialization -> Listener [label="5. Event Delivery"];
