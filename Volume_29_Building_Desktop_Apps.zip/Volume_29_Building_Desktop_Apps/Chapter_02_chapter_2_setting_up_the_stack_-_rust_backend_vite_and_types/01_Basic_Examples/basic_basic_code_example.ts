/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file SaaS Telemetry Dashboard Type-Guard Pipeline
 * @description Demonstrates generics, type inference, and custom type guards for 
 * processing asynchronous IPC payloads coming from a high-performance Tauri 2.0 Rust backend.
 */

// ============================================================================
// 1. DOMAIN MODELS & GENERIC INTERFACES
// ============================================================================

/**
 * Represents the raw, untrusted payload envelope received over the Tauri IPC bridge.
 * @template T The expected underlying data structure of the telemetry event.
 */
interface IpcEnvelope<T> {
  readonly traceId: string;
  readonly timestamp: number;
  readonly payload: T;
}

/**
 * Represents a metric data point emitted by the Rust core engine.
 */
interface SystemMetricPayload {
  readonly cpuUsagePercent: number;
  readonly memoryAllocatedBytes: number;
  readonly activeWorkerThreads: number;
}

/**
 * Represents an audit log entry emitted by the Rust security subsystem.
 */
interface AuditLogPayload {
  readonly actor: string;
  readonly action: string;
  readonly severity: 'LOW' | 'MEDIUM' | 'CRITICAL';
}

// ============================================================================
// 2. CUSTOM TYPE GUARDS (RUNTIME-TO-COMPILE-TIME BRIDGE)
// ============================================================================

/**
 * Custom type guard to verify if an unknown runtime object conforms to the 
 * SystemMetricPayload structure.
 * 
 * @param value The unknown data received from the IPC bridge.
 * @returns True if the value matches SystemMetricPayload, narrowing the type scope.
 */
function isSystemMetricPayload(value: unknown): value is SystemMetricPayload {
  // Ensure the value is a non-null object and not an array
  if (value === null || typeof value !== 'object') {
    return false;
  }

  // Cast to Record to safely inspect runtime keys without triggering TS errors
  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.cpuUsagePercent === 'number' &&
    typeof candidate.memoryAllocatedBytes === 'number' &&
    typeof candidate.activeWorkerThreads === 'number'
  );
}

/**
 * Custom type guard to verify if an unknown runtime object conforms to the 
 * AuditLogPayload structure.
 * 
 * @param value The unknown data received from the IPC bridge.
 * @returns True if the value matches AuditLogPayload, narrowing the type scope.
 */
function isAuditLogPayload(value: unknown): value is AuditLogPayload {
  if (value === null || typeof value !== 'object') {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  const isValidSeverity = 
    candidate.severity === 'LOW' || 
    candidate.severity === 'MEDIUM' || 
    candidate.severity === 'CRITICAL';

  return (
    typeof candidate.actor === 'string' &&
    typeof candidate.action === 'string' &&
    isValidSeverity
  );
}

// ============================================================================
// 3. GENERIC PROCESSOR PIPELINE
// ============================================================================

/**
 * A generic processor class designed to ingest, validate, and transform 
 * asynchronous IPC payloads safely in a SaaS developer tool frontend.
 * 
 * @template T The target payload type this processor instance handles.
 */
class TelemetryProcessor<T> {
  private processingQueue: IpcEnvelope<T>[] = [];

  /**
   * Ingests a raw data stream, validating its structure using a provided type guard.
   * Leverages TypeScript type inference to manage the envelope structure.
   * 
   * @param rawData The raw input from the Tauri backend (typed as unknown for safety).
   * @param validator A type guard function that confirms whether the payload matches type T.
   * @returns The validated payload, or null if validation fails.
   */
  public ingest(
    rawData: unknown, 
    validator: (val: unknown) => val is T
  ): T | null {
    // Type guard step: Ensure the envelope structure itself is valid
    if (rawData === null || typeof rawData !== 'object') {
      console.warn('IPC Error: Malformed envelope received.');
      return null;
    }

    const envelope = rawData as Record<string, unknown>;

    // Validate envelope metadata
    if (typeof envelope.traceId !== 'string' || typeof envelope.timestamp !== 'number') {
      console.warn('IPC Error: Missing or invalid envelope metadata.');
      return null;
    }

    // Delegate deep payload validation to the injected type guard
    if (!validator(envelope.payload)) {
      console.error(`Security Warning: Payload failed type validation for trace ID: ${envelope.traceId}`);
      return null;
    }

    // Construct the fully typed envelope utilizing TypeScript's type inference
    const validEnvelope: IpcEnvelope<T> = {
      traceId: envelope.traceId,
      timestamp: envelope.timestamp,
      payload: envelope.payload, // Safely narrowed to type T here
    };

    this.processingQueue.push(validEnvelope);
    this.dispatchToAnalytics(validEnvelope);

    return validEnvelope.payload;
  }

  /**
   * Internal telemetry dispatcher simulating a SaaS state update.
   */
  private dispatchToAnalytics(envelope: IpcEnvelope<T>): void {
    console.log(`[SaaS Telemetry Engine] Processing Trace: ${envelope.traceId}`);
    // In a real Tauri app, this would update a React/Vue reactive store
  }
}

// ============================================================================
// 4. EXECUTION SIMULATION (DEMONSTRATING RUNTIME SAFETY)
// ============================================================================

// Initialize processors for our distinct SaaS data streams
const metricsProcessor = new TelemetryProcessor<SystemMetricPayload>();
const auditProcessor = new TelemetryProcessor<AuditLogPayload>();

// Simulate incoming JSON payload from the Rust backend (e.g., via Tauri event listener)
const rawSystemEvent = {
  traceId: 'tr-9921-alpha',
  timestamp: Date.now(),
  payload: {
    cpuUsagePercent: 14.8,
    memoryAllocatedBytes: 104857600,
    activeWorkerThreads: 4
  }
};

// Simulate a corrupted or malicious payload injection attempt
const rawMalformedEvent = {
  traceId: 'tr-6666-malicious',
  timestamp: Date.now(),
  payload: {
    cpuUsagePercent: "OVERLOAD", // Maliciously injected string instead of number
    memoryAllocatedBytes: 512,
    activeWorkerThreads: 2
  }
};

console.log('--- STARTING IPC TELEMETRY PIPELINE SIMULATION ---');

// Process valid system metrics
const processedMetrics = metricsProcessor.ingest(rawSystemEvent, isSystemMetricPayload);
if (processedMetrics) {
  // TypeScript knows with 100% certainty that processedMetrics is of type SystemMetricPayload
  console.log(`SUCCESS: CPU usage is at ${processedMetrics.cpuUsagePercent}%`);
}

// Attempt to process malformed metrics using the system metric processor
const failedMetrics = metricsProcessor.ingest(rawMalformedEvent, isSystemMetricPayload);
if (failedMetrics === null) {
  console.log('REJECTED: Malformed event was safely caught and discarded by the type guard.');
}

console.log('--- PIPELINE SIMULATION COMPLETE ---');
