/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file EnterpriseTelemetryBridge.ts
 * @description Advanced application script for a Tauri 2.0 SaaS developer tool.
 * Manages secure IPC communication, plugin states, and runtime payload validation 
 * between the Vite/TypeScript frontend and the high-performance Rust backend.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface defining the strict shape of a telemetry event received from the Rust backend.
 * Using an Interface allows for declaration merging and clear contract enforcement.
 */
export interface TelemetryPayload {
    readonly id: string;
    readonly timestamp: number;
    source: 'rust_core' | 'plugin_sandbox' | 'ipc_bridge';
    metricName: string;
    value: number | string | boolean;
    metadata?: Record<string, unknown>;
}

/**
 * Interface defining the configuration state for active workspace plugins.
 */
export interface PluginConfig {
    pluginId: string;
    enabled: boolean;
    executionTimeoutMs: number;
    allowedScopes: string[];
}

/**
 * A discriminated union type representing the potential states of an IPC command response.
 */
type IpcResult<T> = 
    | { status: 'success'; data: T; latencyMs: number }
    | { status: 'error'; code: string; message: string; fatal: boolean };

/**
 * Type Guard function for Type Narrowing.
 * Refines a generic unknown or broad payload down to a strict TelemetryPayload.
 * 
 * @param payload - The unknown runtime data coming across the IPC bridge.
 * @returns boolean indicating if the payload matches the TelemetryPayload interface.
 */
function isTelemetryPayload(payload: unknown): payload is TelemetryPayload {
    if (typeof payload !== 'object' || payload === null) {
        return false;
    }

    const candidate = payload as Record<string, unknown>;

    return (
        typeof candidate.id === 'string' &&
        typeof candidate.timestamp === 'number' &&
        (candidate.source === 'rust_core' || candidate.source === 'plugin_sandbox' || candidate.source === 'ipc_bridge') &&
        typeof candidate.metricName === 'string' &&
        (typeof candidate.value === 'number' || typeof candidate.value === 'string' || typeof candidate.value === 'boolean')
    );
}

/**
 * Core class managing the SaaS application's background communication bridge with Rust.
 */
export class EnterpriseTelemetryBridge {
    private static instance: EnterpriseTelemetryBridge;
    private activeListeners: UnlistenFn[] = [];
    private isInitialized: boolean = false;

    private constructor() {
        // Private constructor for Singleton pattern
    }

    /**
     * Retrieves the singleton instance of the EnterpriseTelemetryBridge.
     */
    public static getInstance(): EnterpriseTelemetryBridge {
        if (!EnterpriseTelemetryBridge.instance) {
            EnterpriseTelemetryBridge.instance = new EnterpriseTelemetryBridge();
        }
        return EnterpriseTelemetryBridge.instance;
    }

    /**
     * Initializes the bridge, setting up event listeners for Rust-emitted telemetry streams.
     */
    public async initializeBridge(): Promise<void> {
        if (this.isInitialized) {
            console.warn('[TelemetryBridge] Bridge is already initialized.');
            return;
        }

        try {
            // Registering an asynchronous event listener for Rust backend broadcasts
            const unlisten = await listen<unknown>('rust-telemetry-stream', (event) => {
                const rawPayload = event.payload;

                // Applying Type Narrowing via the custom type guard
                if (isTelemetryPayload(rawPayload)) {
                    this.processValidTelemetry(rawPayload);
                } else {
                    console.error('[TelemetryBridge] Malformed telemetry payload received from Rust:', rawPayload);
                }
            });

            this.activeListeners.push(unlisten);
            this.isInitialized = true;
            console.log('[TelemetryBridge] Successfully established IPC bridge with Rust backend.');
        } catch (error) {
            console.error('[TelemetryBridge] Failed to initialize IPC event listeners:', error);
            throw new Error('Initialization of EnterpriseTelemetryBridge failed.');
        }
    }

    /**
     * Executes a secure command on the Rust backend via Tauri's invoke API.
     * 
     * @param command - The registered Rust function name.
     * @param args - The payload arguments passed to the backend.
     */
    public async executeBackendCommand<T>(
        command: string, 
        args?: Record<string, unknown>
    ): Promise<IpcResult<T>> {
        const startTime = performance.now();

        try {
            // Invoking the Tauri 2.0 command mapped in src-tauri/src/lib.rs
            const response = await invoke<T>(command, args);
            const endTime = performance.now();

            return {
                status: 'success',
                data: response,
                latencyMs: parseFloat((endTime - startTime).toFixed(2))
            };
        } catch (err: unknown) {
            const endTime = performance.now();
            const errorMessage = err instanceof Error ? err.message : String(err);

            return {
                status: 'error',
                code: 'IPC_INVOKE_FAILURE',
                message: errorMessage,
                fatal: false
            };
        }
    }

    /**
     * Internal method to process validated telemetry data.
     * Demonstrates safe property access post-type narrowing.
     */
    private processValidTelemetry(telemetry: TelemetryPayload): void {
        // Safe access due to prior Type Narrowing
        console.info(
            `[Telemetry] [${telemetry.source}] Metric: ${telemetry.metricName} = ${telemetry.value} (ID: ${telemetry.id})`
        );

        if (telemetry.metadata && typeof telemetry.metadata.severity === 'string') {
            if (telemetry.metadata.severity === 'CRITICAL') {
                this.handleCriticalAlert(telemetry);
            }
        }
    }

    /**
     * Handles critical anomalies flagged by the Rust core runtime.
     */
    private handleCriticalAlert(telemetry: TelemetryPayload): void {
        console.warn(`[CRITICAL ALERT] Immediate intervention required for metric: ${telemetry.metricName}`);
        // Additional SaaS error-reporting hooks can be integrated here
    }

    /**
     * Cleans up event listeners upon application termination or workspace unmounting.
     */
    public async teardown(): Promise<void> {
        for (const unlisten of this.activeListeners) {
            unlisten();
        }
        this.activeListeners = [];
        this.isInitialized = false;
        console.log('[TelemetryBridge] Telemetry bridge torn down cleanly.');
    }
}
