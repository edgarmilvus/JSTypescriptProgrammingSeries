/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src-ts/core/configValidator.ts

export interface TauriRuntimeConfig {
  productName: string;
  version: string;
  identifier: string;
  build: {
    devUrl: string;
    frontendDist: string;
  };
  security: {
    csp: string;
  };
}

/**
 * Validates the runtime Tauri configuration injected via window.__TAURI_INTERNALS__.
 * Throws a detailed error if any security or routing parameters are malformed.
 */
export function validateTauriConfig(rawConfig: unknown): asserts rawConfig is TauriRuntimeConfig {
  if (!rawConfig || typeof rawConfig !== 'object') {
    throw new Error('Tauri initialization failed: Configuration payload must be a valid object.');
  }

  const config = rawConfig as Record<string, unknown>;

  if (typeof config.productName !== 'string' || config.productName.trim() === '') {
    throw new Error('Tauri initialization failed: Missing or invalid "productName".');
  }

  if (typeof config.version !== 'string' || !/^\d+\.\d+\.\d+/.test(config.version)) {
    throw new Error('Tauri initialization failed: Invalid semantic versioning format in "version".');
  }

  if (typeof config.identifier !== 'string' || !config.identifier.includes('.')) {
    throw new Error('Tauri initialization failed: "identifier" must follow reverse-DNS convention (e.g., com.domain.app).');
  }

  const build = config.build as Record<string, unknown> | undefined;
  if (!build || typeof build.devUrl !== 'string' || typeof build.frontendDist !== 'string') {
    throw new Error('Tauri initialization failed: Malformed "build" configuration block.');
  }

  // Ensure devUrl strictly matches expected local development expectations
  if (!build.devUrl.startsWith('http://localhost:1420') && !build.devUrl.startsWith('https://localhost:1420')) {
    throw new Error(`Tauri initialization failed: Insecure or mismatched devUrl port. Expected localhost:1420, got "${build.devUrl}".`);
  }

  const security = config.security as Record<string, unknown> | undefined;
  if (!security || typeof security.csp !== 'string') {
    throw new Error('Tauri initialization failed: Missing security Content Security Policy (CSP).');
  }

  // Check CSP for unsafe remote evaluation vectors
  if (security.csp.includes('unsafe-eval') || security.csp.includes('https://*')) {
    throw new Error('Security Violation: Content Security Policy contains unsafe directives ("unsafe-eval" or wildcards).');
  }
}
