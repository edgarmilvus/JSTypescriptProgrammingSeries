/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src-ts/hooks/useTauriQuery.ts

import { useState, useEffect, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';

export interface QueryState<T> {
  data: T | null;
  isLoading: boolean;
  error: Error | null;
}

export interface TelemetryQuery {
  target: string;
  sampleRate: number;
  filters: string[];
}

export interface TelemetryResult {
  timestamp: number;
  statusCode: number;
  payload: string;
}

/**
 * Custom React hook for executing Tauri IPC commands with unmount cancellation support.
 */
export function useTauriQuery<TArgs, TResult>(
  command: string,
  args: TArgs
): QueryState<TResult> & { refetch: () => void } {
  const [data, setData] = useState<TResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const isMountedRef = useRef<boolean>(true);
  const argsRef = useRef<TArgs>(args);
  argsRef.current = args;

  const executeQuery = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Invoke Tauri core command with strongly-typed arguments
      const result = await invoke<TResult>(command, { query: argsRef.current });
      
      if (isMountedRef.current) {
        setData(result);
        setIsLoading(false);
      }
    } catch (err) {
      if (isMountedRef.current) {
        const normalizedError = err instanceof Error ? err : new Error(String(err));
        setError(normalizedError);
        setIsLoading(false);
      }
    }
  }, [command]);

  useEffect(() => {
    isMountedRef.current = true;
    executeQuery();

    return () => {
      isMountedRef.current = false;
    };
  }, [executeQuery]);

  return {
    data,
    isLoading,
    error,
    refetch: executeQuery,
  };
}
