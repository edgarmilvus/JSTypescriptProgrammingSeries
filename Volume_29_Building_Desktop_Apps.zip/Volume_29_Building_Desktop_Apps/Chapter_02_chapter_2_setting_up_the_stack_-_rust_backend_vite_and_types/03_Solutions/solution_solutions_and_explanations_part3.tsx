/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// src-ts/components/DiagnosticStreamViewer.tsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

export type LogSeverity = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

export interface LogEntry {
  id: string;
  timestamp: number;
  severity: LogSeverity;
  message: string;
  source: string;
}

interface DiagnosticStreamViewerProps {
  maxBufferSize?: number;
  autoScrollDefault?: boolean;
}

/**
 * A high-performance log stream viewer component optimized for Tauri desktop tools.
 */
export const DiagnosticStreamViewer: React.FC<DiagnosticStreamViewerProps> = ({
  maxBufferSize = 5000,
  autoScrollDefault = true,
}) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [filterSeverity, setFilterSeverity] = useState<LogSeverity | 'ALL'>('ALL');
  const [autoScroll, setAutoScroll] = useState<boolean>(autoScrollDefault);

  const logsBufferRef = useRef<LogEntry[]>([]);
  const requestRef = useRef<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Throttled UI state synchronization loop using requestAnimationFrame (60 FPS cap)
  const flushLogsToState = useCallback(() => {
    if (!isPaused && logsBufferRef.current.length > 0) {
      const incoming = [...logsBufferRef.current];
      logsBufferRef.current = [];

      setLogs((prevLogs) => {
        const combined = [...prevLogs, ...incoming];
        if (combined.length > maxBufferSize) {
          return combined.slice(combined.length - maxBufferSize);
        }
        return combined;
      });
    }
    requestRef.current = requestAnimationFrame(flushLogsToState);
  }, [isPaused, maxBufferSize]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(flushLogsToState);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [flushLogsToState]);

  // Subscribe to Tauri event channel
  useEffect(() => {
    let unlisten: UnlistenFn | undefined;

    async function setupEventListener() {
      unlisten = await listen<LogEntry>('plugin:telemetry://log-stream', (event) => {
        if (!isPaused) {
          logsBufferRef.current.push(event.payload);
        }
      });
    }

    setupEventListener();

    return () => {
      if (unlisten) {
        unlisten();
      }
    };
  }, [isPaused]);

  // Handle auto-scrolling behavior
  useEffect(() => {
    if (autoScroll && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const filteredLogs = logs.filter(
    (log) => filterSeverity === 'ALL' || log.severity === filterSeverity
  );

  return (
    <div className="diagnostic-stream-container flex flex-col h-full bg-slate-900 text-slate-100 p-4 rounded-lg">
      <div className="flex justify-between items-center mb-4 border-b border-slate-700 pb-2">
        <div className="flex gap-2">
          <button 
            onClick={() => setIsPaused(!isPaused)}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 rounded text-sm font-semibold transition"
          >
            {isPaused ? 'Resume Stream' : 'Pause Stream'}
          </button>
          <button 
            onClick={() => setLogs([])}
            className="px-3 py-1 bg-red-600 hover:bg-red-500 rounded text-sm font-semibold transition"
          >
            Clear Buffer
          </button>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400">Severity:</label>
          <select 
            value={filterSeverity} 
            onChange={(e) => setFilterSeverity(e.target.value as any)}
            className="bg-slate-800 text-slate-200 text-xs px-2 py-1 rounded border border-slate-700"
          >
            <option value="ALL">ALL</option>
            <option value="DEBUG">DEBUG</option>
            <option value="INFO">INFO</option>
            <option value="WARN">WARN</option>
            <option value="ERROR">ERROR</option>
          </select>
        </div>
      </div>

      <div 
        ref={containerRef}
        onScroll={(e) => {
          const target = e.currentTarget;
          const isAtBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 40;
          setAutoScroll(isAtBottom);
        }}
        className="flex-1 overflow-y-auto font-mono text-xs space-y-1 pr-2 max-h-[600px]"
      >
        {filteredLogs.map((log) => (
          <div key={log.id} className="flex gap-2 items-start py-0.5 border-b border-slate-800/50">
            <span className="text-slate-500">[{new Date(log.timestamp).toISOString()}]</span>
            <span className={`font-bold px-1 rounded text-[10px] ${
              log.severity === 'ERROR' ? 'bg-red-900 text-red-200' :
              log.severity === 'WARN' ? 'bg-amber-900 text-amber-200' :
              log.severity === 'INFO' ? 'bg-blue-900 text-blue-200' : 'bg-slate-800 text-slate-400'
            }`}>
              {log.severity}
            </span>
            <span className="text-slate-400">[{log.source}]</span>
            <span className="flex-1 break-all text-slate-200">{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
