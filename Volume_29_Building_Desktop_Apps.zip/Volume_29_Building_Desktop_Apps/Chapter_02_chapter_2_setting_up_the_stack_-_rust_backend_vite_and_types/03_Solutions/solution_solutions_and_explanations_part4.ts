/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// vite.config.ts / custom plugin implementation

import { Plugin } from 'vite';

/**
 * A custom Vite plugin to enforce Tauri webview runtime detection during local development.
 */
export function tauriEnvironmentGuardPlugin(): Plugin {
  return {
    name: 'vite-plugin-tauri-environment-guard',
    transformIndexHtml(html) {
      const guardScript = `
        <script>
          window.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
              const isTauriEnv = window.__TAURI_INTERNALS__ !== undefined || window.__TAURI__ !== undefined;
              if (!isTauriEnv && window.location.hostname === 'localhost') {
                const banner = document.createElement('div');
                banner.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#dc2626;color:white;padding:12px;text-align:center;font-family:sans-serif;font-weight:bold;z-index:99999;box-shadow:0 -4px 12px rgba(0,0,0,0.3);';
                banner.innerHTML = '⚠️ Warning: PulseDesk frontend running in external browser. Tauri IPC commands and native bindings will fail. Please launch via "tauri dev".';
                document.body.appendChild(banner);
              }
            }, 500);
          });
        </script>
      `;
      return html.replace('</body>', `${guardScript}</body>`);
    },
  };
}
