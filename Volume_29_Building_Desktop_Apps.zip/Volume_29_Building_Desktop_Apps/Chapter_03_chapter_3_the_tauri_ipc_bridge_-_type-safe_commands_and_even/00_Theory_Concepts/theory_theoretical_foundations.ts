/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", fontsize=10];

    subgraph cluster_frontend {
        label = "Frontend Execution Context (Sandboxed WebView)";
        style=filled;
        color="#e2e8f0";
        fillcolor="#f8fafc";
        
        TS [label="TypeScript Application\n(UI & Business Logic)", fillcolor="#dbeafe", color="#93c5fd"];
        Zod [label="Zod Schema Validation\n(Runtime Type Boundary)", fillcolor="#e0e7ff", color="#a5b4fc"];
        Invoke [label="Tauri Core Invoke\n(Serialization Layer)", fillcolor="#ede9fe", color="#c4b5fd"];
    }

    IPC [label="Tauri IPC Bridge\n(JSON Serialization & Serialization Protocol)", shape=oval, fillcolor="#fef3c7", color="#fcd34d"];

    subgraph cluster_backend {
        label = "Backend Execution Context (Native Rust Process)";
        style=filled;
        color="#e2e8f0";
        fillcolor="#f8fafc";

        Handler [label="Rust Command Handler\n(Async Execution)", fillcolor="#ffedd5", color="#fdba74"];
        Serde [label="Serde Deserialization\n(Payload Parsing)", fillcolor="#fed7aa", color="#fb923c"];
        System [label="OS / Hardware\n(Filesystem, DB, etc.)", fillcolor="#fee2e2", color="#fca5a5"];
    }

    TS -> Zod [label=" 1. User Intent"];
    Zod -> Invoke [label=" 2. Validated Payload"];
    Invoke -> IPC [label=" 3. Async Message"];
    IPC -> Serde [label=" 4. Raw Bytes"];
    Serde -> Handler [label=" 5. Strong Types"];
    Handler -> System [label=" 6. Native Action"];
}
