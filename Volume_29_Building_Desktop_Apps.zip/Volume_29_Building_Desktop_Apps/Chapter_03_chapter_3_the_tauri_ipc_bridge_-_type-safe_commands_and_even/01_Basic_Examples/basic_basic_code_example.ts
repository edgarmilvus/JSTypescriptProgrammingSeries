/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * @file deploymentManager.ts
 * @description Core IPC bridge module for managing SaaS deployment configurations in Tauri 2.0.
 */

/**
 * Represents the target deployment environment for the SaaS application.
 */
export type DeploymentEnvironment = 'development' | 'staging' | 'production';

/**
 * Represents the raw configuration payload received from or sent to the Rust backend.
 */
export interface DeploymentConfig {
    /** Unique identifier for the deployment target */
    id: string;
    /** Human-readable name of the service */
    serviceName: string;
    /** Target environment */
    environment: DeploymentEnvironment;
    /** Maximum memory allocation in megabytes */
    memoryLimitMb: number;
    /** Optional environment variables */
    envVars?: Record<string, string>;
}

/**
 * Immutable update payload for modifying an existing configuration.
 * Leverages the Utility Type `Partial` to make all properties of `DeploymentConfig` optional,
 * excluding the immutable `id` which is handled separately.
 */
export type DeploymentUpdatePayload = Partial<Omit<DeploymentConfig, 'id'>>;

/**
 * Standardized API response wrapper returned by the Rust backend.
 */
export type ApiResponse<T> = 
    | { status: 'success'; data: T }
    | { status: 'error'; errorCode: string; message: string };

/**
 * Real-time event payload emitted by the Rust backend during long-running deployment pipelines.
 */
export interface DeploymentProgressEvent {
    deploymentId: string;
    step: 'building' | 'bundling' | 'uploading' | 'verifying';
    progressPercentage: number;
    timestamp: number;
}

/**
 * Safely invokes the Tauri Rust command to fetch a deployment configuration by its unique identifier.
 * 
 * @param id - The unique identifier of the deployment configuration.
 * @returns A promise resolving to an immutable, strongly-typed configuration object.
 */
export async function fetchDeploymentConfig(id: string): Promise<Readonly<DeploymentConfig>> {
    try {
        // Invoke the Rust command 'get_deployment_config' with strongly-typed arguments
        const response = await invoke<ApiResponse<DeploymentConfig>>('get_deployment_config', { id });

        // Runtime type-narrowing using a custom type guard or discriminated union check
        if (response.status === 'error') {
            throw new Error(`Rust IPC Error [${response.errorCode}]: ${response.message}`);
        }

        // Return the data wrapped in Object.freeze to enforce Immutable State Management at runtime
        return Object.freeze(response.data);
    } catch (error) {
        console.error('Failed to fetch deployment configuration via Tauri IPC:', error);
        throw error;
    }
}

/**
 * Updates an existing deployment configuration utilizing immutable patterns.
 * 
 * @param id - The identifier of the configuration to update.
 * @param updates - The partial updates to apply, constrained by Utility Types.
 * @returns The newly updated, immutable configuration object.
 */
export async function updateDeploymentConfig(
    id: string, 
    updates: DeploymentUpdatePayload
): Promise<Readonly<DeploymentConfig>> {
    // Construct an immutable payload copy ensuring zero-mutation of the original input
    const payload = Object.freeze({
        id,
        ...updates,
        // Ensure timestamp tracking or audit logs are injected immutably
        lastModified: Date.now()
    });

    const response = await invoke<ApiResponse<DeploymentConfig>>('update_deployment_config', { payload });

    if (response.status === 'error') {
        throw new Error(`Failed to update deployment: ${response.message}`);
    }

    return Object.freeze(response.data);
}

/**
 * Subscribes to real-time event streams emitted from the Rust backend for deployment tracking.
 * 
 * @param callback - Function executed whenever a progress event is received.
 * @returns A promise resolving to the unlisten function for cleanup.
 */
export async function subscribeToDeploymentProgress(
    callback: (event: DeploymentProgressEvent) => void
): Promise<UnlistenFn> {
    // Listen to the Tauri event channel 'deployment-progress'
    const unlisten = await listen<DeploymentProgressEvent>('deployment-progress', (event) => {
        // The event payload is strongly typed via the generic parameter of listen<T>
        const progressData = event.payload;
        
        // Execute the user-provided callback with the validated payload
        callback(progressData);
    });

    return unlisten;
}
