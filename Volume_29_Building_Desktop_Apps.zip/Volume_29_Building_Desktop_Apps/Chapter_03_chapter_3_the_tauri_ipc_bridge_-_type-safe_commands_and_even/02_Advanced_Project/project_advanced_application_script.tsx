/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file tauri-ipc-manager.ts
 * @description Enterprise-grade Tauri 2.0 IPC Manager implementing type-safe commands, 
 * event-driven data streaming, and immutable state management for a SaaS desktop developer tool.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Represents a connected workspace project inside our SaaS desktop environment.
 */
export interface ProjectWorkspace {
    readonly id: string;
    readonly name: string;
    readonly rootPath: string;
    readonly environment: 'development' | 'staging' | 'production';
    readonly telemetryEnabled: boolean;
    readonly lastSyncedAt: number;
}

/**
 * Payload structure required when initializing a new workspace project.
 * Utilizes Utility Types conceptually by omitting auto-generated fields like id and lastSyncedAt.
 */
export type ProjectInitializationPayload = Omit<ProjectWorkspace, 'id' | 'lastSyncedAt'>;

/**
 * Payload utilized for updating an existing workspace configuration.
 * Utilizes TypeScript's built-in Partial utility type to make all fields optional except what is explicitly managed.
 */
export type ProjectUpdatePayload = Partial<Omit<ProjectWorkspace, 'id'>>;

/**
 * Standardized response wrapper for all Tauri IPC command invocations.
 */
export interface IPCResponse<T> {
    readonly success: boolean;
    readonly data?: T;
    readonly error?: string;
    readonly timestamp: number;
}

/**
 * Telemetry data stream event emitted from the Rust backend via Tauri event system.
 */
export interface BackendTelemetryEvent {
    readonly metricName: string;
    readonly value: number;
    readonly severity: 'info' | 'warn' | 'critical';
}

/**
 * Centralized IPC Manager class implementing Immutable State Management.
 * Ensures all state mutations return fresh object references.
 */
export class TauriIpcManager {
    private static instance: TauriIpcManager;
    private currentWorkspace: ProjectWorkspace | null = null;
    private telemetryListeners: Set<(event: BackendTelemetryEvent) => void> = new Set();
    private unlistenTelemetry: UnlistenFn | null = null;

    private constructor() {
        this.initializeEventListener();
    }

    /**
     * Retrieves the singleton instance of the TauriIpcManager.
     */
    public static getInstance(): TauriIpcManager {
        if (!TauriIpcManager.instance) {
            TauriIpcManager.instance = new TauriIpcManager();
        }
        return TauriIpcManager.instance;
    }

    /**
     * Sets up the asynchronous event listener for real-time data streaming from the Rust backend.
     */
    private async initializeEventListener(): Promise<void> {
        try {
            this.unlistenTelemetry = await listen<BackendTelemetryEvent>('rust-telemetry-stream', (event) => {
                const payload = event.payload;
                // Notify all registered subscribers immutably
                this.telemetryListeners.forEach(listener => listener(payload));
            });
        } catch (error) {
            console.error('Failed to initialize Tauri event listener:', error);
        }
    }

    /**
     * Subscribes to real-time telemetry events streamed from the Rust backend.
     * 
     * @param listener Callback function executed upon receiving telemetry data.
     * @returns A cleanup function to unregister the listener.
     */
    public subscribeToTelemetry(listener: (event: BackendTelemetryEvent) => void): () => void {
        this.telemetryListeners.add(listener);
        return () => {
            this.telemetryListeners.delete(listener);
        };
    }

    /**
     * Invokes a type-safe Tauri command to initialize a new project workspace on the local filesystem.
     * 
     * @param payload Configuration payload required to set up the project.
     * @returns Promise resolving to the standardized IPC response containing the created workspace.
     */
    public async initializeProject(payload: ProjectInitializationPayload): Promise<IPCResponse<ProjectWorkspace>> {
        try {
            // Invoke the Rust command 'initialize_workspace' with strict type checking
            const result = await invoke<ProjectWorkspace>('initialize_workspace', { payload });

            // Apply Immutable State Management: Replace state with a completely new reference
            this.currentWorkspace = {
                ...result,
                lastSyncedAt: Date.now()
            };

            return {
                success: true,
                data: this.currentWorkspace,
                timestamp: Date.now()
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : String(error),
                timestamp: Date.now()
            };
        }
    }

    /**
     * Updates the current project workspace using partial payloads.
     * Demonstrates immutable state merging.
     * 
     * @param updates Partial properties to update within the active workspace.
     */
    public async updateWorkspace(updates: ProjectUpdatePayload): Promise<IPCResponse<ProjectWorkspace>> {
        if (!this.currentWorkspace) {
            return {
                success: false,
                error: 'No active workspace found in state.',
                timestamp: Date.now()
            };
        }

        try {
            const updatedWorkspace = await invoke<ProjectWorkspace>('update_workspace_config', {
                id: this.currentWorkspace.id,
                updates
            });

            // Immutable State Update: Create a fresh object combining previous state and backend response
            this.currentWorkspace = {
                ...this.currentWorkspace,
                ...updatedWorkspace,
                lastSyncedAt: Date.now()
            };

            return {
                success: true,
                data: this.currentWorkspace,
                timestamp: Date.now()
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : String(error),
                timestamp: Date.now()
            };
        }
    }

    /**
     * Returns a frozen copy of the current workspace to enforce read-only access externally.
     */
    public getWorkspace(): ProjectWorkspace | null {
        return this.currentWorkspace ? Object.freeze({ ...this.currentWorkspace }) : null;
    }

    /**
     * Gracefully tears down event listeners when the manager is disposed.
     */
    public async dispose(): Promise<void> {
        if (this.unlistenTelemetry) {
            this.unlistenTelemetry();
            this.unlistenTelemetry = null;
        }
        this.telemetryListeners.clear();
        this.currentWorkspace = null;
    }
}
