/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';

// 1. Define TypeScript interfaces mirroring the Rust backend structs
export interface WorkspaceFileStats {
  path: string;
  size_bytes: number;
  is_directory: boolean;
  last_modified: number; // epoch timestamp
}

export interface ConfigOverrides {
  settings: Record<string, unknown>;
}

// 2. Strongly typed frontend wrapper function invoking the Tauri command
export async function fetchWorkspaceStats(targetPath: string): Promise<WorkspaceFileStats[]> {
  try {
    // The generic type parameter ensures type-safety of the resolved promise data
    return await invoke<WorkspaceFileStats[]>('fetch_workspace_stats', { targetPath });
  } catch (error) {
    console.error('Failed to fetch workspace stats:', error);
    throw new Error(typeof error === 'string' ? error : 'Unknown IPC error occurred');
  }
}

export async function batchUpdateConfig(config: ConfigOverrides): Promise<void> {
  await invoke('batch_update_config', { config });
}
