/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useState } from 'react';
import { listen, UnlistenFn } from '@tauri-apps/api/event';
import { invoke } from '@tauri-apps/api/core';

// 1. Define TypeScript interface matching the Rust LogPayload struct
export type LogLevel = 'Info' | 'Warn' | 'Error';

export interface LogPayload {
  level: LogLevel;
  message: string;
  timestamp: number;
}

// 2. React component hook managing the log stream listener and state buffer
export function useLogStream() {
  const [logs, setLogs] = useState<LogPayload[]>([]);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);

  useEffect(() => {
    let unlisten: UnlistenFn | undefined;

    async function setupListener() {
      // Strongly type the event payload inside the listener callback
      unlisten = await listen<LogPayload>('plugin:logger:new-log', (event) => {
        setLogs((prevLogs) => [...prevLogs, event.payload]);
      });
      setIsStreaming(true);
    }

    setupListener();

    // Trigger the backend command to start the background worker thread
    invoke('start_log_stream').catch((err) => {
      console.error('Failed to start log stream:', err);
    });

    // Cleanup mechanism: unlisten from the event stream and clear state on unmount
    return () => {
      if (unlisten) {
        unlisten();
      }
      setIsStreaming(false);
    };
  }, []);

  return { logs, isStreaming };
}

/* 
// --- Corresponding Rust Backend Context (Mental Model) ---
// #[derive(serde::Serialize, Clone)]
// pub struct LogPayload { level: String, message: String, timestamp: u64 }
// 
// #[tauri::command]
// async fn start_log_stream(app: tauri::AppHandle) -> Result<(), String> {
//     std::thread::spawn(move || {
//         loop {
//             let payload = LogPayload { level: "Info".into(), message: "Heartbeat".into(), timestamp: 123456789 };
//             let _ = app.emit("plugin:logger:new-log", &payload);
//             std::thread::sleep(std::time::Duration::from_millis(500));
//         }
//     });
//     Ok(())
// }
*/
