/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';

// 1. Define interface for search matches returned from Rust
export interface SearchMatch {
  file_path: string;
  matched_line_number: number;
  snippet_preview: string;
}

export function WorkspaceSearch() {
  const [query, setQuery] = useState<string>('');
  const [results, setResults] = useState<SearchMatch[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // 2. Implement debounced execution pattern using useEffect timeout
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    const timerId = setTimeout(async () => {
      try {
        const matches = await invoke<SearchMatch[]>('search_workspace_index', { query });
        setResults(matches);
      } catch (err) {
        setError(typeof err === 'string' ? err : 'An error occurred during search execution.');
        setResults([]);
      } finally {
        setIsLoading(false);
      }
    }, 300); // 300ms debounce delay

    // Clear timeout if query changes before 300ms expires
    return () => clearTimeout(timerId);
  }, [query]);

  return (
    <div className="workspace-search-container">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search workspace index..."
        className="search-input"
      />

      {isLoading && <div className="spinner">Searching workspace...</div>}
      {error && <div className="error-toast">{error}</div>}

      <ul className="search-results-list">
        {!isLoading && !error && results.map((match, index) => (
          <li key={`${match.file_path}-${match.matched_line_number}-${index}`} className="search-result-item">
            <span className="file-path">{match.file_path}:{match.matched_line_number}</span>
            <code className="snippet">{match.snippet_preview}</code>
          </li>
        ))}
      </ul>
    </div>
  );
}
