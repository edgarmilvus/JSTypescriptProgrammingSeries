/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';

// 1. Define TypeScript types mirroring the Rust AppError enum envelope
export type AppErrorType = 'IoError' | 'SerializationError' | 'NotFound' | 'Unauthorized';

export interface AppError {
  type: AppErrorType;
  message: string;
}

// 2. Type-safe wrapper utility returning a discriminated result tuple [data, error]
export async function safeInvoke<T>(
  cmd: string,
  args?: Record<string, unknown>
): Promise<[T | null, AppError | null]> {
  try {
    const data = await invoke<T>(cmd, args);
    return [data, null];
  } catch (error) {
    // Normalize string errors or structured error payloads into the AppError format
    if (typeof error === 'object' && error !== null && 'type' in error && 'message' in error) {
      return [null, error as AppError];
    }
    
    const errorMessage = typeof error === 'string' ? error : (error as Error)?.message || 'Unknown IPC failure';
    
    return [
      null,
      {
        type: 'IoError',
        message: errorMessage,
      },
    ];
  }
}

/* 
// --- Rust Backend Error Architecture Context (Mental Model) ---
// #[derive(serde::Serialize, Debug)]
// #[serde(tag = "type", content = "message")]
// pub enum AppError {
//     IoError(String),
//     SerializationError(String),
//     NotFound(String),
//     Unauthorized,
// }
// 
// type AppResult<T> = Result<T, AppError>;
// 
// #[tauri::command]
// async fn perform_critical_operation(condition: bool) -> AppResult<String> {
//     if condition {
//         Ok("Success".into())
//     } else {
//         Err(AppError::NotFound("Target resource missing".into()))
//     }
// }
*/
