/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual TypeScript representation of managing a multi-window architecture
// inside a Tauri frontend application. 

import { Window } from '@tauri-apps/api/window';
import { emit, listen } from '@tauri-apps/api/event';

// Interface representing configuration payloads for secondary utility windows
interface UtilityWindowConfig {
    label: string;
    url: string;
    width: number;
    height: number;
    title: string;
}

/**
 * Spawns a secondary utility window via the Tauri API.
 * In the background, this instructs the Rust core to invoke the OS window manager.
 */
async function createUtilityWindow(config: UtilityWindowConfig): void {
    try {
        // Check if the window already exists to prevent duplicate instantiations
        const existingWindow = await Window.getByLabel(config.label);
        if (existingWindow) {
            await existingWindow.setFocus();
            return;
        }

        // Instantiate a new window object. This maps directly to a native OS window handle.
        const appWindow = new Window(config.label, {
            url: config.url,
            width: config.width,
            height: config.height,
            title: config.title,
            decorations: true,
            transparent: false,
            alwaysOnTop: false,
        });

        // Register lifecycle event listeners for the new window
        appWindow.once('tauri://created', () => {
            console.log(`Window '${config.label}' was successfully created.`);
        });

        appWindow.once('tauri://error', (error) => {
            console.error(`Failed to create window '${config.label}':`, error);
        });

    } catch (error) {
        console.error("Critical error while attempting to spawn utility window:", error);
    }
}

/**
 * Broadcasts a state synchronization event from a primary window 
 * to all listening secondary windows via the Rust event bus.
 */
async function syncStateAcrossWindows(stateKey: string, payload: unknown): Promise<void> {
    await emit('app-state-sync', {
        key: stateKey,
        data: payload,
        timestamp: Date.now()
    });
}
