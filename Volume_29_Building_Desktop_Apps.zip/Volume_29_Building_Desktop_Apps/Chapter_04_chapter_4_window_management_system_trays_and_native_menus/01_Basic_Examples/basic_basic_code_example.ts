/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// SaaS Desktop Client: Window Management, System Tray, and Native Menus
// ============================================================================

import { Window, getCurrentWindow } from '@tauri-apps/api/window';
import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing the application telemetry state.
 * Adheres to Immutable State Management principles.
 */
interface AppTelemetryState {
    readonly activeConnections: number;
    readonly syncStatus: 'idle' | 'syncing' | 'error';
    readonly lastHeartbeat: string;
}

/**
 * Manages the lifecycle of secondary tool windows and tray interactions.
 */
class SaaSDesktopManager {
    private secondaryWindow: Window | null = null;
    private state: AppTelemetryState;
    private unlistenSync: UnlistenFn | null = null;

    constructor() {
        // Initialize with a frozen, immutable default state
        this.state = Object.freeze({
            activeConnections: 0,
            syncStatus: 'idle',
            lastHeartbeat: new Date().toISOString(),
        });
    }

    /**
     * Asynchronously initializes event listeners and window hooks.
     * Enforces Exhaustive Asynchronous Resilience via try/catch/finally blocks.
     */
    public async initialize(): Promise<void> {
        try {
            console.info('[SaaSDesktopManager] Initializing desktop subsystems...');
            
            // Register backend event listeners for tray-to-frontend synchronization
            this.unlistenSync = await listen<number>('tray-action-sync', (event) => {
                this.handleTrayAction(event.payload);
            });

            // Perform initial state fetch from Rust backend
            await this.refreshTelemetryState();
            
        } catch (error: unknown) {
            console.error('[SaaSDesktopManager] Initialization failed critically:', error);
            this.updateState({ syncStatus: 'error' });
            throw new Error(`Failed to initialize SaaS desktop client: ${error instanceof Error ? error.message : String(error)}`);
        } finally {
            console.debug('[SaaSDesktopManager] Initialization routine completed execution lifecycle.');
        }
    }

    /**
     * Spawns a secondary utility window (e.g., live analytics inspector).
     * Validates if the window already exists before invocation.
     */
    public async openAnalyticsInspector(): Promise<void> {
        try {
            // Check if the window is already instantiated to prevent resource leaks
            const existingWindow = await Window.getByLabel('analytics-inspector');
            if (existingWindow) {
                console.warn('[SaaSDesktopManager] Inspector window already open. Focusing...');
                await existingWindow.setFocus();
                return;
            }

            // Instantiate a new Tauri Window instance programmatically
            this.secondaryWindow = new Window('analytics-inspector', {
                url: '/inspector.html',
                title: 'SaaS Enterprise Inspector',
                width: 800,
                height: 600,
                resizable: true,
                decorations: true,
                transparent: false,
            });

            // Await webview window creation confirmation
            this.secondaryWindow.once('tauri://created', () => {
                console.info('[SaaSDesktopManager] Secondary inspector window successfully created.');
            });

            this.secondaryWindow.once('tauri://error', (err) => {
                console.error('[SaaSDesktopManager] Failed to create secondary window:', err);
            });

        } catch (error: unknown) {
            console.error('[SaaSDesktopManager] Error during secondary window creation:', error);
            // Graceful degradation: alert user or handle via fallback UI
        } finally {
            console.debug('[SaaSDesktopManager] openAnalyticsInspector execution terminated.');
        }
    }

    /**
     * Communicates with the Rust backend to fetch updated state metrics.
     * Demonstrates strict adherence to Immutable State Management.
     */
    private async refreshTelemetryState(): Promise<void> {
        try {
            // Invoke Rust command exposing system metrics
            const metrics = await invoke<{ connections: number }>('get_telemetry_metrics');
            
            // Create a brand new state object rather than mutating the existing one
            this.updateState({
                activeConnections: metrics.connections,
                syncStatus: 'idle',
                lastHeartbeat: new Date().toISOString()
            });

        } catch (error: unknown) {
            console.error('[SaaSDesktopManager] Failed to fetch telemetry from Rust core:', error);
            this.updateState({ syncStatus: 'error' });
            throw error; // Propagate up if critical
        }
    }

    /**
     * Pure function to update state immutably.
     * @param partialState The subset of state properties to update.
     */
    private updateState(partialState: Partial<AppTelemetryState>): void {
        this.state = Object.freeze({
            ...this.state,
            ...partialState
        });
        console.debug('[SaaSDesktopManager] State updated immutably:', this.state);
        // Trigger UI rendering refresh hooks here in a real framework context
    }

    /**
     * Handles incoming commands from the system tray menu dispatched via backend events.
     */
    private handleTrayAction(actionCode: number): void {
        try {
            switch (actionCode) {
                case 1:
                    console.info('[SaaSDesktopManager] Tray command: Open Dashboard requested.');
                    getCurrentWindow().show();
                    getCurrentWindow().setFocus();
                    break;
                case 2:
                    console.info('[SaaSDesktopManager] Tray command: Spawn Inspector requested.');
                    this.openAnalyticsInspector();
                    break;
                case 3:
                    console.info('[SaaSDesktopManager] Tray command: Graceful shutdown initiated.');
                    invoke('shutdown_app');
                    break;
                default:
                    console.warn(`[SaaSDesktopManager] Unknown tray action code received: ${actionCode}`);
            }
        } catch (error: unknown) {
            console.error('[SaaSDesktopManager] Error processing tray action payload:', error);
        }
    }

    /**
     * Cleans up all event listeners and active resource handles.
     */
    public destroy(): void {
        try {
            if (this.unlistenSync) {
                this.unlistenSync();
                this.unlistenSync = null;
            }
            console.info('[SaaSDesktopManager] Successfully cleaned up application resources.');
        } catch (error: unknown) {
            console.error('[SaaSDesktopManager] Error during cleanup phase:', error);
        }
    }
}

// Export singleton instance for enterprise usage
export const desktopManager = new SaaSDesktopManager();
