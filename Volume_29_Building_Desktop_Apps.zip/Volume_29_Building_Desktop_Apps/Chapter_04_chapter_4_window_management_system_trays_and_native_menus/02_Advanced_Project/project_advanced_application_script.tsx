/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file desktop-manager.ts
 * @module DesktopManager
 * @description Advanced application script for managing multi-window lifecycles,
 * native system trays, and dynamic context menus in a Tauri 2.0 TypeScript frontend.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';
import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
import { TrayIcon } from '@tauri-apps/api/tray';
import { Menu } from '@tauri-apps/api/menu';

/**
 * Represents the configuration state of an auxiliary application window.
 */
interface WindowConfig {
  label: string;
  url: string;
  title: string;
  width: number;
  height: number;
  resizable?: boolean;
}

/**
 * Enterprise SaaS Desktop Manager Class.
 * Centralizes all native interactions, event listeners, and window orchestration.
 */
export class DesktopManager {
  private static instance: DesktopManager;
  private activeWindows: Map<string, WebviewWindow> = new Map();
  private unlisteners: UnlistenFn[] = [];

  private constructor() {}

  /**
   * Enforces a Singleton pattern to prevent multiple conflicting IPC bridges.
   */
  public static getInstance(): DesktopManager {
    if (!DesktopManager.instance) {
      DesktopManager.instance = new DesktopManager();
    }
    return DesktopManager.instance;
  }

  /**
   * Initializes global event listeners for native window synchronization and tray actions.
   */
  public async initialize(): Promise<void> {
    try {
      // Listen for backend-triggered window open commands via IPC
      const unlistenOpen = await listen<{ config: WindowConfig }>('tauri://open-sub-window', (event) => {
        this.createAuxiliaryWindow(event.payload.config);
      });
      this.unlisteners.push(unlistenOpen);

      // Listen for system tray state synchronization events
      const unlistenTray = await listen<{ status: string }>('tray-status-update', (event) => {
        console.info(`[Tauri Tray Sync] Status changed to: ${event.payload.status}`);
      });
      this.unlisteners.push(unlistenTray);

      console.info('[DesktopManager] Successfully initialized event orchestration bridge.');
    } catch (error) {
      console.error('[DesktopManager] Failed to initialize listeners:', error);
      throw error;
    }
  }

  /**
   * Programmatically spawns or focuses an auxiliary Tauri webview window.
   * 
   * @param config - Window configuration parameters (label, dimensions, url).
   */
  public async createAuxiliaryWindow(config: WindowConfig): Promise<WebviewWindow | null> {
    try {
      // Check if window already exists to prevent duplication
      let targetWindow = await WebviewWindow.getByLabel(config.label);

      if (targetWindow) {
        await targetWindow.setFocus();
        return targetWindow;
      }

      // Instantiate a new WebviewWindow instance using Tauri 2.0 APIs
      targetWindow = new WebviewWindow(config.label, {
        url: config.url,
        title: config.title,
        width: config.width,
        height: config.height,
        resizable: config.resizable ?? true,
        center: true,
        visible: false, // Hide initially to prevent layout flash during load
      });

      // Register lifecycle hooks once the window is created
      targetWindow.once('tauri://created', async () => {
        console.info(`[DesktopManager] Window '${config.label}' successfully created.`);
        await targetWindow?.show();
        await targetWindow?.setFocus();
      });

      targetWindow.once('tauri://error', (err) => {
        console.error(`[DesktopManager] Error creating window '${config.label}':`, err);
      });

      this.activeWindows.set(config.label, targetWindow);
      return targetWindow;
    } catch (error) {
      console.error(`[DesktopManager] Exception during window creation for '${config.label}':`, error);
      return null;
    }
  }

  /**
   * Dispatches a command to the Rust backend to rebuild the system tray native menu.
   * 
   * @param items - Array of dynamic menu strings or identifiers.
   */
  public async updateTrayMenu(items: string[]): Promise<void> {
    try {
      await invoke('update_native_tray_menu', { menuItems: items });
      console.info('[DesktopManager] Native tray menu synchronized with backend.');
    } catch (error) {
      console.error('[DesktopManager] Failed to update native tray menu:', error);
    }
  }

  /**
   * Gracefully tears down all active event listeners and clears window references.
   */
  public destroy(): void {
    this.unlisteners.forEach((unlisten) => unlisten());
    this.unlisteners = [];
    this.activeWindows.clear();
    console.info('[DesktopManager] Destroyed all listeners and cleared window cache.');
  }
}

/**
 * React Hook for consuming the DesktopManager inside Next.js client components.
 */
export function useDesktopManager() {
  return DesktopManager.getInstance();
}
