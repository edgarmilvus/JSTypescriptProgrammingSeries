/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen, emit } from '@tauri-apps/api/event';

interface ConfigPayload {
  theme: 'dark' | 'light';
  refreshRate: number;
  syncId: number;
}

export function InspectorPanel() {
  const [syncId, setSyncId] = useState<number>(0);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [refreshRate, setRefreshRate] = useState<number>(1000);

  useEffect(() => {
    // Listen for incoming config updates from the Rust backend or other windows
    const unlistenPromise = listen<ConfigPayload>('config-updated', (event) => {
      // Ensure we resolve states safely using latest payload data
      setTheme(event.payload.theme);
      setRefreshRate(event.payload.refreshRate);
      setSyncId(event.payload.syncId);
    });

    return () => {
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, []);

  // Rapid-fire simulation handler to prevent race conditions via explicit payload tracking
  const handleRapidSync = async () => {
    for (let i = 1; i <= 50; i++) {
      const payload: ConfigPayload = {
        theme: i % 2 === 0 ? 'dark' : 'light',
        refreshRate: 1000 + i,
        syncId: i,
      };

      // Invoke backend to persist and broadcast globally
      try {
        await invoke('update_configuration', { payload });
      } catch (error) {
        console.error(`Failed to sync packet ${i}:`, error);
      }
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Inspector Panel</h2>
      <p>Current Sync ID: {syncId}</p>
      <p>Theme: {theme} | Refresh Rate: {refreshRate}ms</p>
      <button onClick={handleRapidSync}>
        Rapid Sync (50x)
      </button>
    </div>
  );
}
