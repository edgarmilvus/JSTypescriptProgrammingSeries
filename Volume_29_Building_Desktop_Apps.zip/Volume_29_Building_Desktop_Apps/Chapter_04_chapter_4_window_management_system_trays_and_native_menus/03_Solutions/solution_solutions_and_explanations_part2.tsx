/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

interface MenuEventPayload {
  id: string;
}

export function DynamicMenuController() {
  const [menuLabel, setMenuLabel] = useState('');
  const [shortcut, setShortcut] = useState('');
  const [lastActivated, setLastActivated] = useState<string | null>(null);

  useEffect(() => {
    // Listen for custom menu events dispatched from the backend on menu item clicks
    const unlistenPromise = listen<MenuEventPayload>('menu-item-clicked', (event) => {
      setLastActivated(event.payload.id);
    });

    return () => {
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, []);

  const handleRegisterMenu = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Invoke Rust backend command to dynamically inject a menu item
      await invoke('add_dynamic_menu_item', {
        label: menuLabel,
        accelerator: shortcut,
      });
      alert(`Successfully registered menu: ${menuLabel}`);
      setMenuLabel('');
      setShortcut('');
    } catch (error) {
      console.error('Failed to register dynamic menu item:', error);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h3>Dynamic Menu Registrar</h3>
      <form onSubmit={handleRegisterMenu}>
        <div>
          <label>Label: </label>
          <input
            type="text"
            value={menuLabel}
            onChange={(e) => setMenuLabel(e.target.value)}
            placeholder="e.g., Export PDF"
            required
          />
        </div>
        <div style={{ marginTop: '10px' }}>
          <label>Shortcut: </label>
          <input
            type="text"
            value={shortcut}
            onChange={(e) => setShortcut(e.target.value)}
            placeholder="e.g., CmdOrCtrl+Shift+E"
          />
        </div>
        <button type="submit" style={{ marginTop: '10px' }}>
          Register Menu Item
        </button>
      </form>

      {lastActivated && (
        <div style={{ marginTop: '20px', color: 'green' }}>
          Action Triggered from Native Menu ID: <strong>{lastActivated}</strong>
        </div>
      )}
    </div>
  );
}
