/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';

export function TrayStatusWidget() {
  const [isSilent, setIsSilent] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Fetch initial silent mode status from backend upon mounting
  useEffect(() => {
    async function fetchStatus() {
      try {
        const status = await invoke<boolean>('get_silent_mode_status');
        setIsSilent(status);
      } catch (error) {
        console.error('Failed to fetch silent mode status:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchStatus();
    
    // Optional polling interval to synchronize state with background background daemons
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleSilent = async () => {
    try {
      const newStatus = await invoke<boolean>('toggle_silent_mode');
      setIsSilent(newStatus);
    } catch (error) {
      console.error('Failed to toggle silent mode:', error);
    }
  };

  if (loading) {
    return <div>Loading Tray Status...</div>;
  }

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h3>System Tray Background Service</h3>
      <p>
        Status: <strong style={{ color: isSilent ? 'orange' : 'green' }}>
          {isSilent ? 'Silent Mode Active' : 'Normal Operations'}
        </strong>
      </p>
      <button onClick={handleToggleSilent}>
        {isSilent ? 'Disable Silent Mode' : 'Enable Silent Mode'}
      </button>
    </div>
  );
}
