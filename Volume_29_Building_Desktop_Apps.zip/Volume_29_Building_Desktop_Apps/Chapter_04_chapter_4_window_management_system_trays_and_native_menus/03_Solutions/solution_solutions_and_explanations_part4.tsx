/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { ReactNode, MouseEvent } from 'react';
import { invoke } from '@tauri-apps/api/core';

interface DataGridContextProps {
  rowId: string;
  children: ReactNode;
}

export function DataGridContextMenu({ rowId, children }: DataGridContextProps) {
  const handleContextMenu = async (e: MouseEvent<HTMLDivElement>) => {
    // Prevent the default browser context menu from appearing
    e.preventDefault();
    e.stopPropagation();

    // Extract exact client and screen coordinates
    const { clientX, clientY } = e;

    try {
      // Invoke the Rust backend command to build and display the native popup menu
      await invoke('show_data_grid_context_menu', {
        rowId,
        x: Math.round(clientX),
        y: Math.round(clientY),
      });
    } catch (error) {
      console.error('Failed to display native context menu:', error);
    }
  };

  return (
    <div
      onContextMenu={handleContextMenu}
      style={{ width: '100%', minHeight: '50px', cursor: 'context-menu' }}
    >
      {children}
    </div>
  );
}
