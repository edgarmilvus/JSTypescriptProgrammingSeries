/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

interface Task {
  id: string;
  name: string;
  progress: number;
  status: 'Pending' | 'Processing' | 'Completed' | 'Failed';
}

export function TaskQueueDashboard() {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    // Listen for background task state broadcasts from the Rust Tokio worker
    const unlistenPromise = listen<Task>('task-update', (event) => {
      setTasks((prevTasks) => {
        const index = prevTasks.findIndex((t) => t.id === event.payload.id);
        if (index >= 0) {
          const updated = [...prevTasks];
          updated[index] = event.payload;
          return updated;
        } else {
          return [...prevTasks, event.payload];
        }
      });
    });

    return () => {
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, []);

  const handleCancelTask = async (taskId: string) => {
    try {
      await invoke('cancel_background_task', { taskId });
    } catch (error) {
      console.error(`Failed to cancel task ${taskId}:`, error);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h3>Background Task Queue Dashboard</h3>
      {tasks.length === 0 ? (
        <p>No active background tasks.</p>
      ) : (
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {tasks.map((task) => (
            <li key={task.id} style={{ marginBottom: '15px', border: '1px solid #ddd', padding: '10px' }}>
              <div>
                <strong>{task.name}</strong> [{task.status}]
              </div>
              <div style={{ background: '#eee', width: '100%', height: '10px', marginTop: '5px' }}>
                <div
                  style={{
                    background: task.status === 'Failed' ? 'red' : 'blue',
                    width: `${task.progress}%`,
                    height: '100%',
                  }}
                />
              </div>
              {task.status === 'Processing' && (
                <button
                  onClick={() => handleCancelTask(task.id)}
                  style={{ marginTop: '5px' }}
                >
                  Cancel Task
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
