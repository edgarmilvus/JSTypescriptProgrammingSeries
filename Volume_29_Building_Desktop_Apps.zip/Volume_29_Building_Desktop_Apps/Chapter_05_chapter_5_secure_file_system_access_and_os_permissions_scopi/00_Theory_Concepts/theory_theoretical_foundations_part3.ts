/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// TypeScript Frontend invocation of a secure, custom BFF command
// rather than directly calling a generic filesystem plugin.
import { invoke } from '@tauri-apps/api/core';

interface IndexingResult {
  filesProcessed: number;
  vectorsGenerated: number;
}

async function indexWorkspaceDocuments(workspacePath: string): Promise<IndexingResult> {
  try {
    // We invoke a custom Rust command that handles internal path validation,
    // safe directory traversal, and vector embedding generation.
    const result = await invoke<IndexingResult>('index_local_workspace', {
      path: workspacePath,
    });
    
    console.log(`Successfully indexed ${result.filesProcessed} files.`);
    return result;
  } catch (error) {
    console.error('Failed to index workspace due to security or I/O error:', error);
    throw error;
  }
}
