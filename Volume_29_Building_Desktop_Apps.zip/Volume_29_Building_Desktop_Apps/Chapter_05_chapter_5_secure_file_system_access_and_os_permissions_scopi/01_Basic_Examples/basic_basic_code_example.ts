/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { appDataDir, join } from '@tauri-apps/api/path';

/**
 * Interface representing the user's workspace settings configuration payload.
 */
interface WorkspaceSettings {
  theme: 'light' | 'dark' | 'system';
  autoSaveInterval: number;
  lastOpenedProject: string;
}

/**
 * Centralized Service Manager for handling secure file system operations 
 * within the Tauri 2.0 capability-scoped security boundary.
 */
class SecureWorkspaceManager {
  private static instance: SecureWorkspaceManager;

  private constructor() {}

  /**
   * Retrieves the singleton instance of the SecureWorkspaceManager.
   * @returns {SecureWorkspaceManager} The active manager instance.
   */
  public static getInstance(): SecureWorkspaceManager {
    if (!SecureWorkspaceManager.instance) {
      SecureWorkspaceManager.instance = new SecureWorkspaceManager();
    }
    return SecureWorkspaceManager.instance;
  }

  /**
   * Safely reads the workspace configuration file from the OS-specific app data directory.
   * 
   * @async
   * @throws {Error} If path resolution fails or the backend invocation is rejected.
   * @returns {Promise<WorkspaceSettings>} The parsed workspace settings object.
   */
  public async loadSettings(): Promise<WorkspaceSettings> {
    try {
      // Step 1: Resolve the base application data directory dynamically using Tauri's path API.
      // This ensures we reference the correct OS sandbox path (e.g., ~/Library/Application Support/... on macOS).
      const baseDir = await appDataDir();

      // Step 2: Securely join the base directory with the target configuration filename.
      // The join utility normalizes path separators safely across Windows, macOS, and Linux.
      const configPath = await join(baseDir, 'settings.json');

      // Step 3: Invoke the Rust backend command 'read_secure_file', passing the absolute path.
      // The TypeScript compiler enforces type safety by mapping the generic parameter <string> to the return type.
      const rawFileContent = await invoke<string>('read_secure_file', {
        targetPath: configPath,
      });

      // Step 4: Parse the JSON string retrieved from the backend into our strongly-typed interface.
      const parsedSettings: WorkspaceSettings = JSON.parse(rawFileContent);

      return parsedSettings;
    } catch (error) {
      console.error('[SecureWorkspaceManager] Failed to load workspace settings:', error);
      
      // Fallback to secure default settings if file reading or parsing fails
      return {
        theme: 'system',
        autoSaveInterval: 300,
        lastOpenedProject: 'default-workspace',
      };
    }
  }

  /**
   * Persists updated workspace settings to the secure app data directory via the Rust backend.
   * 
   * @async
   * @param {WorkspaceSettings} newSettings - The updated settings payload to save.
   * @returns {Promise<boolean>} True if the operation succeeded, false otherwise.
   */
  public async saveSettings(newSettings: WorkspaceSettings): Promise<boolean> {
    try {
      // Step 1: Resolve the base application data directory.
      const baseDir = await appDataDir();

      // Step 2: Construct the absolute file path for the settings file.
      const configPath = await join(baseDir, 'settings.json');

      // Step 3: Serialize the TypeScript object payload into a strict JSON string.
      const serializedData = JSON.stringify(newSettings, null, 2);

      // Step 4: Transmit the file path and serialized content across the IPC bridge to Rust.
      // The command 'write_secure_file' handles the actual file system write under capability scrutiny.
      await invoke<void>('write_secure_file', {
        targetPath: configPath,
        content: serializedData,
      });

      return true;
    } catch (error) {
      console.error('[SecureWorkspaceManager] Failed to persist workspace settings:', error);
      return false;
    }
  }
}

// Export a singleton instance for consumption across UI components in the SaaS application
export const workspaceManager = SecureWorkspaceManager.getInstance();
