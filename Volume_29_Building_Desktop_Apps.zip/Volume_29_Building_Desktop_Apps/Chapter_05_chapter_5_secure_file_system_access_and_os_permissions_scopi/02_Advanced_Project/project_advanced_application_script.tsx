/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file EnterpriseWorkspaceManager.tsx
 * @description Advanced Tauri 2.0 frontend client script for secure local file system
 * operations within a SaaS desktop wrapper. Enforces capability scoping and path validation.
 */

import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

/**
 * Interface representing a managed workspace file metadata structure.
 */
interface WorkspaceFile {
  name: string;
  path: string;
  size: number;
  lastModified: number;
}

/**
 * Interface representing the application configuration payload.
 */
interface AppConfig {
  workspaceRoot: string;
  autoSaveInterval: number;
  maxCacheSizeMb: number;
}

/**
 * EnterpriseWorkspaceManager Component
 * 
 * Provides a secure interface for interacting with local workspace files 
 * constrained by Tauri 2.0 capability-based permission rules.
 */
export default function EnterpriseWorkspaceManager() {
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [activeFileContent, setActiveFileContent] = useState<string>('');
  const [activeFilePath, setActiveFilePath] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Ready');
  const [isWorkspaceScoped, setIsWorkspaceScoped] = useState<boolean>(false);

  // 1. Initialize listeners for OS-level file system watcher events pushed from Rust backend
  useEffect(() => {
    let unlistenWatcher: (() => void) | undefined;

    async function setupWatcher() {
      try {
        // Listen to custom backend events emitted when scoped directories change
        unlistenWatcher = await listen<string>('fs-watcher-event', (event) => {
          setStatusMessage(`File system change detected: ${event.payload}`);
          refreshWorkspaceFiles();
        });
        setIsWorkspaceScoped(true);
      } catch (error) {
        console.error('Failed to initialize Tauri event listener:', error);
        setStatusMessage('Error: Running outside Tauri environment or capabilities missing.');
      }
    }

    setupWatcher();
    refreshWorkspaceFiles();

    return () => {
      if (unlistenWatcher) {
        unlistenWatcher();
      }
    };
  }, []);

  /**
   * 2. Safely fetch files from the permitted app-data directory via Rust invoke bridge.
   * Enforces that paths stay within the Tauri capability scope ($APPDATA/workspace).
   */
  const refreshWorkspaceFiles = async () => {
    try {
      setStatusMessage('Scanning permitted workspace directories...');
      const result = await invoke<WorkspaceFile[]>('list_scoped_workspace_files');
      setFiles(result);
      setStatusMessage('Workspace synchronized successfully.');
    } catch (error) {
      console.error('Access denied or execution error:', error);
      setStatusMessage(`Access Error: ${error}`);
    }
  };

  /**
   * 3. Read a specific file's content after validating path restrictions.
   * @param {string} filePath - Absolute or relative path authorized by capability scopes.
   */
  const handleOpenFile = async (filePath: string) => {
    try {
      setStatusMessage(`Reading file: ${filePath}`);
      // Invoke the Rust command 'read_secure_file' mapped in tauri.conf.json permissions
      const content = await invoke<string>('read_secure_file', { path: filePath });
      setActiveFileContent(content);
      setActiveFilePath(filePath);
      setStatusMessage(`Loaded: ${filePath}`);
    } catch (error) {
      console.error('Failed to read file:', error);
      setStatusMessage(`Read failed: ${error}`);
    }
  };

  /**
   * 4. Save active file updates back to the local disk through strict backend validation.
   */
  const handleSaveFile = async () => {
    if (!activeFilePath) {
      setStatusMessage('No active file selected for saving.');
      return;
    }

    try {
      setStatusMessage(`Saving changes to ${activeFilePath}...`);
      await invoke('write_secure_file', {
        path: activeFilePath,
        contents: activeFileContent,
      });
      setStatusMessage(`Successfully saved: ${activeFilePath}`);
    } catch (error) {
      console.error('Failed to write file:', error);
      setStatusMessage(`Write failed: ${error}`);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto font-sans bg-gray-900 text-gray-100 rounded-lg shadow-xl">
      <header className="flex justify-between items-center mb-6 border-b border-gray-700 pb-4">
        <h1 className="text-2xl font-bold tracking-wide">Enterprise Workspace Manager</h1>
        <div className="flex items-center space-x-2">
          <span className={`h-3 w-3 rounded-full ${isWorkspaceScoped ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-sm text-gray-400">
            {isWorkspaceScoped ? 'Capabilities Scoped & Secured' : 'Unscoped / Web Fallback'}
          </span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* File Explorer Sidebar */}
        <div className="bg-gray-800 p-4 rounded-md border border-gray-700 flex flex-col h-96">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold text-gray-300">Workspace Files</h2>
            <button
              onClick={refreshWorkspaceFiles}
              className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-xs rounded text-white transition-colors"
            >
              Refresh
            </button>
          </div>
          <div className="flex-1 overflow-y-auto space-y-1">
            {files.length === 0 ? (
              <p className="text-sm text-gray-500 italic">No files found or access restricted.</p>
            ) : (
              files.map((file) => (
                <button
                  key={file.path}
                  onClick={() => handleOpenFile(file.path)}
                  className={`w-full text-left px-3 py-2 rounded text-sm transition-colors truncate ${
                    activeFilePath === file.path
                      ? 'bg-blue-600 text-white'
                      : 'hover:bg-gray-700 text-gray-300'
                  }`}
                >
                  {file.name}
                </button>
              ))
            )}
          </div>
        </div>

        {/* Editor Main Canvas */}
        <div className="md:col-span-2 bg-gray-800 p-4 rounded-md border border-gray-700 flex flex-col h-96">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-medium text-gray-400 truncate">
              {activeFilePath ? activeFilePath : 'No file open'}
            </span>
            <button
              onClick={handleSaveFile}
              disabled={!activeFilePath}
              className={`px-4 py-1.5 text-sm rounded font-medium text-white transition-colors ${
                activeFilePath ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 cursor-not-allowed'
              }`}
            >
              Save Changes
            </button>
          </div>
          <textarea
            value={activeFileContent}
            onChange={(e) => setActiveFileContent(e.target.value)}
            disabled={!activeFilePath}
            placeholder="Select a file from the workspace to begin editing..."
            className="flex-1 bg-gray-900 border border-gray-700 rounded p-3 text-sm text-gray-200 font-mono resize-none focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Status Bar */}
      <footer className="mt-6 pt-3 border-t border-gray-700 flex justify-between items-center text-xs text-gray-400">
        <span>Status: {statusMessage}</span>
        <span>Tauri 2.0 Security Model: Active</span>
      </footer>
    </div>
  );
}
