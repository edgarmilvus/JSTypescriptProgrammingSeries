/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

use std::path::{Path, Component};
use std::fs;
use serde::Serialize;
use tokio::fs as tokio_fs;

#[derive(Debug, Serialize)]
pub enum CustomFileError {
    PathTraversalDetected,
    InvalidPath(String),
    FileTooLarge(u64),
    IoError(String),
}

impl std::fmt::Display for CustomFileError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CustomFileError::PathTraversalDetected => write!(f, "Security violation: Path traversal attempt detected."),
            CustomFileError::InvalidPath(msg) => write!(f, "Invalid path: {}", msg),
            CustomFileError::FileTooLarge(size) => write!(f, "File size exceeds limit: {} bytes", size),
            CustomFileError::IoError(msg) => write!(f, "I/O error: {}", msg),
        }
    }
}

impl std::error::Error for CustomFileError {}

/// Validates against null-bytes and parent directory escapes
fn validate_path(input_path: &str) -> Result<std::path::PathBuf, CustomFileError> {
    // Guard against null-byte injection attacks
    if input_path.contains('\0') {
        return Err(CustomFileError::PathTraversalDetected);
    }

    let path = Path::new(input_path);
    
    // Ensure components do not contain ParentDir (..) traversals
    for component in path.components() {
        if let Component::ParentDir = component {
            return Err(CustomFileError::PathTraversalDetected);
        }
    }

    let base_dir = dirs::home_dir()
        .ok_or_else(|| CustomFileError::InvalidPath("Could not resolve home directory".into()))?
        .join("Projects/TauriNotes");

    let canonical_base = fs::canonicalize(&base_dir)
        .map_err(|_| CustomFileError::InvalidPath("Base directory does not exist".into()))?;

    let target_path = if path.is_absolute() {
        path.to_path_buf()
    } else {
        canonical_base.join(path)
    };

    // Check metadata and ensure containment within base directory
    let canonical_target = fs::canonicalize(&target_path)
        .map_err(|_| CustomFileError::InvalidPath("Target file does not exist".into()))?;

    if !canonical_target.starts_with(&canonical_base) {
        return Err(CustomFileError::PathTraversalDetected);
    }

    Ok(canonical_target)
}

#[tauri::command]
pub async fn secure_read_notes_file(path: String) -> Result<String, CustomFileError> {
    let safe_path = validate_path(&path)?;

    let metadata = fs::metadata(&safe_path)
        .map_err(|e| CustomFileError::IoError(e.to_string()))?;

    if !metadata.is_file() {
        return Err(CustomFileError::InvalidPath("Target is not a regular file".into()));
    }

    const MAX_SIZE: u64 = 5_000_000; // 5MB limit
    if metadata.len() > MAX_SIZE {
        return Err(CustomFileError::FileTooLarge(metadata.len()));
    }

    let contents = tokio_fs::read_to_string(&safe_path)
        .await
        .map_err(|e| CustomFileError::IoError(e.to_string()))?;

    Ok(contents)
}
