/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

interface AuditLog {
  timestamp: string;
  action: string;
  targetPath: string;
  status: 'SUCCESS' | 'DENIED' | 'ERROR';
  message: string;
}

export function SecurityAuditDashboard() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [filePathInput, setFilePathInput] = useState<string>('');

  const handleFileAccessAttempt = async (path: string) => {
    setLoading(true);
    const timestamp = new Date().toLocaleTimeString();
    
    try {
      const result = await invoke<string>('secure_read_notes_file', { path });
      
      const newLog: AuditLog = {
        timestamp,
        action: 'READ_FILE',
        targetPath: path,
        status: 'SUCCESS',
        message: `Successfully read ${result.length} characters.`
      };
      
      setLogs((prevLogs) => [newLog, ...prevLogs]);
    } catch (err) {
      const errorMessage = typeof err === 'string' ? err : (err as Error).message || 'Unknown security violation';
      
      const isDenied = errorMessage.toLowerCase().includes('security') || 
                       errorMessage.toLowerCase().includes('traversal') ||
                       errorMessage.toLowerCase().includes('denied');

      const newLog: AuditLog = {
        timestamp,
        action: 'READ_FILE',
        targetPath: path,
        status: isDenied ? 'DENIED' : 'ERROR',
        message: errorMessage
      };

      setLogs((prevLogs) => [newLog, ...prevLogs]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-slate-900 text-white rounded-xl shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Security Audit Dashboard</h2>
      
      <div className="flex gap-2 mb-6">
        <input 
          type="text"
          value={filePathInput}
          onChange={(e) => setFilePathInput(e.target.value)}
          placeholder="Enter relative or absolute file path..."
          className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg focus:outline-none focus:border-indigo-500"
        />
        <button
          onClick={() => handleFileAccessAttempt(filePathInput)}
          disabled={loading || !filePathInput.trim()}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-lg font-medium transition"
        >
          {loading ? 'Checking...' : 'Audit Read'}
        </button>
      </div>

      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-slate-400">Activity Log</h3>
        {logs.length === 0 ? (
          <p className="text-slate-500 italic">No audit events recorded yet.</p>
        ) : (
          logs.map((log, idx) => (
            <div key={idx} className="p-3 bg-slate-800 rounded-lg border border-slate-700 flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400">{log.timestamp}</span>
                <span className={`px-2 py-0.5 text-xs font-bold rounded ${
                  log.status === 'SUCCESS' ? 'bg-green-900 text-green-300' :
                  log.status === 'DENIED' ? 'bg-amber-900 text-amber-300' : 'bg-red-900 text-red-300'
                }`}>
                  {log.status}
                </span>
              </div>
              <p className="text-sm font-mono text-slate-300">Target: {log.targetPath}</p>
              <p className="text-sm text-slate-200">{log.message}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
