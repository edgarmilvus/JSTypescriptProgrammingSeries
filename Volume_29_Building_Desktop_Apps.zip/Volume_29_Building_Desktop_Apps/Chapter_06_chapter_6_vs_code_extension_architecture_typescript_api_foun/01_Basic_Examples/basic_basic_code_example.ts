/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as vscode from 'vscode';

/**
 * Interface representing the response payload from a SaaS cloud-sync backend.
 */
interface SyncStatusResponse {
    status: 'synced' | 'pending' | 'error';
    activeWorkspaces: number;
    lastSyncedAt: string;
}

/**
 * Mock function simulating an asynchronous fetch request to a SaaS API.
 * Uses TypeScript Generics to ensure type-safe payload parsing.
 * 
 * @template T The expected structure of the response data.
 * @param endpoint The API URL endpoint.
 * @returns A promise resolving to the typed response.
 */
async function fetchSaaSWorkspaceStatus<T>(endpoint: string): Promise<T> {
    // Under the hood, this simulates an asynchronous network boundary crossing.
    // In a real Tauri or VS Code extension, this would utilize fetch or native IPC.
    return new Promise((resolve) => {
        setTimeout(() => {
            const mockData = {
                status: 'synced',
                activeWorkspaces: 4,
                lastSyncedAt: new Date().toISOString()
            } as unknown as T;
            resolve(mockData);
        }, 1000);
    });
}

/**
 * This method is called when your extension is activated.
 * Activation is triggered by events defined in the package.json manifest.
 * 
 * @param context Encapsulates utilities for managing extension state and subscriptions.
 */
export function activate(context: vscode.ExtensionContext): void {
    // Log initialization to the Extension Host output channel
    console.log('SaaS Cloud-Sync extension "saas-devtools" is now active.');

    // 1. Create a status bar item aligned to the right side of the status bar
    const statusBarItem = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Right,
        100
    );
    statusBarItem.text = "$(cloud) SaaS: Connecting...";
    statusBarItem.tooltip = "Click to force synchronization with SaaS workspace.";
    statusBarItem.command = 'saas-devtools.syncNow';
    
    // Ensure the status bar item is disposed of when the extension deactivates
    context.subscriptions.push(statusBarItem);
    statusBarItem.show();

    // 2. Register a command that users can trigger via the Command Palette or Status Bar
    const disposableCommand = vscode.commands.registerCommand(
        'saas-devtools.syncNow',
        async () => {
            try {
                // Provide immediate visual feedback to the user
                statusBarItem.text = "$(sync~spin) SaaS: Syncing...";
                vscode.window.showInformationMessage('Initiating synchronization with SaaS backend...');

                // Fetch remote status using our generic helper
                const data = await fetchSaaSWorkspaceStatus<SyncStatusResponse>(
                    'https://api.saas-devtools.internal/v1/status'
                );

                // Update UI based on fetched state
                if (data.status === 'synced') {
                    statusBarItem.text = `$(cloud-upload) SaaS: Synced (${data.activeWorkspaces})`;
                    vscode.window.showInformationMessage(
                        `Sync successful! Last updated at: ${data.lastSyncedAt}`
                    );
                } else {
                    statusBarItem.text = `$(alert) SaaS: Sync Error`;
                    vscode.window.showWarningMessage('SaaS sync completed with warnings.');
                }
            } catch (error) {
                // Handle unexpected runtime exceptions gracefully
                statusBarItem.text = `$(error) SaaS: Offline`;
                const errorMessage = error instanceof Error ? error.message : 'Unknown error';
                vscode.window.showErrorMessage(`Failed to sync with SaaS platform: ${errorMessage}`);
            }
        }
    );

    // Register the command disposal to prevent memory leaks
    context.subscriptions.push(disposableCommand);

    // 3. Perform an initial background synchronization check upon activation
    vscode.commands.executeCommand('saas-devtools.syncNow');
}

/**
 * This method is called when your extension is deactivated.
 * Used for cleanup tasks, closing database connections, or flushing telemetry.
 */
export function deactivate(): void {
    console.log('SaaS Cloud-Sync extension "saas-devtools" has been deactivated.');
}
