/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import * as vscode from 'vscode';

/**
 * Represents the base interface for all tasks dispatched to our Worker Agent Pool.
 * @template TPayload The structural type of the payload required by the worker.
 */
interface WorkerTask<TPayload> {
    readonly taskId: string;
    readonly agentType: 'CodeGenerator' | 'DatabaseQuery' | 'SearchAgent';
    readonly payload: TPayload;
    readonly timeoutMs?: number;
}

/**
 * Payload definitions for individual worker agent types.
 */
interface CodeGeneratorPayload {
    readonly schemaName: string;
    readonly targetLanguage: 'typescript' | 'rust';
    readonly outputUri: vscode.Uri;
}

interface DatabaseQueryPayload {
    readonly connectionString: string;
    readonly sqlQuery: string;
    readonly maxRows: number;
}

interface SearchAgentPayload {
    readonly searchQuery: string;
    readonly includeGlob: string;
}

/**
 * Discriminated union representing the possible result states returned by worker agents.
 */
type WorkerResult<TData = unknown> = 
    | { readonly status: 'success'; readonly taskId: string; readonly data: TData; readonly executionTimeMs: number }
    | { readonly status: 'error'; readonly taskId: string; readonly errorCode: string; readonly message: string }
    | { readonly status: 'timeout'; readonly taskId: string; readonly limitExceededMs: number };

/**
 * Type Guard to check if a generic WorkerResult is a successful execution.
 * Demonstrates TypeScript Type Narrowing for heterogeneous response streams.
 */
function isSuccessfulResult<TData>(result: WorkerResult<TData>): result is Extract<WorkerResult<TData>, { status: 'success' }> {
    return result.status === 'success';
}

/**
 * SaaS Worker Supervisor Node managing parallel execution pools within the VS Code Extension Host.
 */
export class SaaSWorkerSupervisor implements vscode.Disposable {
    private readonly activeWorkers: Map<string, AbortController> = new Map();
    private readonly outputChannel: vscode.OutputChannel;
    private isDisposed: boolean = false;

    constructor() {
        this.outputChannel = vscode.window.createOutputChannel('SaaS Developer Tools: Supervisor');
        this.outputChannel.appendLine('[Supervisor] Initialized worker pool architecture.');
    }

    /**
     * Dispatches a generic worker task to the remote or local execution runtime.
     * Enforces Generics to maintain absolute type safety between payload and anticipated result data.
     */
    public async dispatchTask<TPayload, TResult>(
        task: WorkerTask<TPayload>
    ): Promise<TResult | null> {
        if (this.isDisposed) {
            throw new Error('Cannot dispatch tasks: Supervisor node has been disposed.');
        }

        const abortController = new AbortController();
        this.activeWorkers.set(task.taskId, abortController);

        this.outputChannel.appendLine(`[Dispatcher] Spawning agent [${task.agentType}] for Task ID: ${task.taskId}`);

        try {
            // Simulate execution across the isolated extension worker boundary
            const rawResult = await this.executeUnderWorkspaceConstraint<TPayload, TResult>(
                task, 
                abortController.signal
            );

            // Apply Type Narrowing via Custom Type Guard
            if (isSuccessfulResult(rawResult)) {
                this.outputChannel.appendLine(`[Success] Task ${task.taskId} completed in ${rawResult.executionTimeMs}ms.`);
                return rawResult.data;
            } else if (rawResult.status === 'error') {
                vscode.window.showErrorMessage(`Agent Error [${rawResult.errorCode}]: ${rawResult.message}`);
                return null;
            } else {
                vscode.window.showWarningMessage(`Agent Warning: Task ${task.taskId} timed out.`);
                return null;
            }
        } catch (error: unknown) {
            if (error instanceof Error) {
                this.outputChannel.appendLine(`[Fatal Error] Task ${task.taskId} failed: ${error.message}`);
                vscode.window.showErrorMessage(`Task Execution Failed: ${error.message}`);
            }
            return null;
        } finally {
            this.activeWorkers.delete(task.taskId);
        }
    }

    /**
     * Internal simulation of asynchronous processing with cancellation support.
     */
    private async executeUnderWorkspaceConstraint<TPayload, TResult>(
        task: WorkerTask<TPayload>,
        signal: AbortSignal
    ): Promise<WorkerResult<TResult>> {
        return new Promise((resolve, reject) => {
            const timeout = task.timeoutMs ?? 5000;
            const timer = setTimeout(() => {
                if (!signal.aborted) {
                    resolve({ status: 'timeout', taskId: task.taskId, limitExceededMs: timeout });
                }
            }, timeout);

            signal.addEventListener('abort', () => {
                clearTimeout(timer);
                reject(new Error('Operation aborted by supervisor lifecycle manager.'));
            });

            // Mocking processing delay
            setTimeout(() => {
                clearTimeout(timer);
                if (signal.aborted) return;

                // Mock successful response payload routing based on agent type
                const mockSuccessResponse: WorkerResult<TResult> = {
                    status: 'success',
                    taskId: task.taskId,
                    data: { processedUri: (task.payload as any)?.outputUri?.toString() ?? 'mock-result' } as unknown as TResult,
                    executionTimeMs: Math.floor(Math.random() * 300) + 50
                };
                resolve(mockSuccessResponse);
            }, 1000);
        });
    }

    /**
     * Implements the vscode.Disposable interface to guarantee zero leaks upon deactivation.
     */
    public dispose(): void {
        if (this.isDisposed) return;
        this.isDisposed = true;

        this.outputChannel.appendLine('[Supervisor] Shutting down all active worker agents...');
        for (const [taskId, controller] of this.activeWorkers.entries()) {
            controller.abort();
            this.outputChannel.appendLine(`[Abort] Terminated runaway worker process for Task ID: ${taskId}`);
        }
        this.activeWorkers.clear();
        this.outputChannel.dispose();
    }
}

/**
 * Extension activation entry point demonstrating integration with VS Code's lifecycle.
 */
export function activate(context: vscode.ExtensionContext): void {
    const supervisor = new SaaSWorkerSupervisor();
    context.subscriptions.push(supervisor);

    let disposableCommand = vscode.commandRegistry.registerCommand(
        'saasTools.runCodeGenerationAgent',
        async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) {
                vscode.window.showInformationMessage('Open a document to execute the generation agent.');
                return;
            }

            const task: WorkerTask<CodeGeneratorPayload> = {
                taskId: `gen-${Date.now()}`,
                agentType: 'CodeGenerator',
                payload: {
                    schemaName: 'UserAccountSchema',
                    targetLanguage: 'typescript',
                    outputUri: editor.document.uri
                },
                timeoutMs: 8000
            };

            await supervisor.dispatchTask<CodeGeneratorPayload, { processedUri: string }>(task);
        }
    );

    context.subscriptions.push(disposableCommand);
}

export function deactivate(): void {
    // Cleanup handled automatically via context.subscriptions and dispose()
}
