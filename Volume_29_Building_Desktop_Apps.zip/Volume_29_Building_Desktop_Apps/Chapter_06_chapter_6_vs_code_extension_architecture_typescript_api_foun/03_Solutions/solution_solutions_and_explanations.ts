/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as vscode from 'vscode';

export interface IExtensionServiceConfig {
    enableVectorSearch: boolean;
    maxResults: number;
    supabaseUrl?: string;
}

export class ExtensionInitializationError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'ExtensionInitializationError';
    }
}

// Simulated heavy client dependency
class SupabaseClientMock {
    constructor(url: string) {
        console.log(`[SupabaseClientMock] Initialized connection to ${url}`);
    }
    public async queryVector(text: string): Promise<string[]> {
        return [`Result for: ${text}`];
    }
}

export function activate(context: vscode.ExtensionContext): void {
    const startTime = Date.now();
    
    // Interactive Challenge: Handle onStartupFinished performance validation
    const elapsedTime = Date.now() - startTime;
    if (elapsedTime > 500) {
        throw new ExtensionInitializationError(`Extension bootstrap exceeded threshold: ${elapsedTime}ms`);
    }

    let supabaseClient: SupabaseClientMock | undefined;

    // Register initialization command
    const initCommand = vscode.commands.registerCommand('devtools.initializeWorkspace', async () => {
        vscode.window.showInformationMessage('Initializing workspace tools...');
    });

    // Register vector query command with lazy loading
    const vectorQueryCommand = vscode.commands.registerCommand('devtools.vectorQuery', async () => {
        // Lazy-load the heavy client instance on first query execution
        if (!supabaseClient) {
            const config = vscode.workspace.getConfiguration('devtools');
            const url = config.get<string>('supabaseUrl') || 'https://default.supabase.co';
            supabaseClient = new SupabaseClientMock(url);
        }

        const input = await vscode.window.showInputBox({ prompt: 'Enter query text for vector search' });
        if (input) {
            const results = await supabaseClient.queryVector(input);
            vscode.window.showInformationMessage(`Found ${results.length} vector matches.`);
        }
    });

    // Push disposables to subscriptions array to prevent memory leaks
    context.subscriptions.push(initCommand, vectorQueryCommand);
}

export function deactivate(): void {
    console.log('Extension host is shutting down. Cleaning up resources.');
}
