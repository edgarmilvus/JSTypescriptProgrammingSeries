/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as vscode from 'vscode';

export interface IVectorToolConfiguration {
    apiKey: string;
    modelName: string;
    batchSize: number;
    vectorDimension: number;
}

export class ConfigurationManager implements vscode.Disposable {
    private static readonly SECTION = 'devtools';
    private cachedConfig: IVectorToolConfiguration;
    private _onDidChangeConfiguration = new vscode.EventEmitter<IVectorToolConfiguration>();
    public readonly onDidChangeConfiguration: vscode.Event<IVectorToolConfiguration> = this._onDidChangeConfiguration.event;
    private disposable: vscode.Disposable;

    constructor() {
        this.cachedConfig = this.readAndValidateConfig();
        
        this.disposable = vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration(ConfigurationManager.SECTION)) {
                this.cachedConfig = this.readAndValidateConfig();
                this._onDidChangeConfiguration.fire(this.cachedConfig);
            }
        });
    }

    private readAndValidateConfig(): IVectorToolConfiguration {
        const raw = vscode.workspace.getConfiguration(ConfigurationManager.SECTION);
        
        const config: IVectorToolConfiguration = {
            apiKey: raw.get<string>('apiKey', ''),
            modelName: raw.get<string>('modelName', 'text-embedding-3-small'),
            batchSize: raw.get<number>('batchSize', 100),
            vectorDimension: raw.get<number>('vectorDimension', 1536)
        };

        this.assertValidConfiguration(config);
        return config;
    }

    private assertValidConfiguration(config: IVectorToolConfiguration): asserts config is IVectorToolConfiguration {
        if (config.vectorDimension <= 0 || !Number.isInteger(config.vectorDimension)) {
            throw new Error(`Invalid configuration: vectorDimension must be a positive integer. Got: ${config.vectorDimension}`);
        }
        if (config.batchSize <= 0 || !Number.isInteger(config.batchSize)) {
            throw new Error(`Invalid configuration: batchSize must be a positive integer. Got: ${config.batchSize}`);
        }
    }

    public getConfig(): IVectorToolConfiguration {
        return this.cachedConfig;
    }

    // Interactive Challenge: Transactional update method
    public async updateSettingAsync<K extends keyof IVectorToolConfiguration>(
        key: K, 
        value: IVectorToolConfiguration[K]
    ): Promise<void> {
        const raw = vscode.workspace.getConfiguration(ConfigurationManager.SECTION);
        await raw.update(key, value, vscode.ConfigurationTarget.Workspace);
        
        // Update local cache and fire event immediately
        this.cachedConfig = {
            ...this.cachedConfig,
            [key]: value
        };
        this.assertValidConfiguration(this.cachedConfig);
        this._onDidChangeConfiguration.fire(this.cachedConfig);
    }

    public dispose(): void {
        this.disposable.dispose();
        this._onDidChangeConfiguration.dispose();
    }
}
