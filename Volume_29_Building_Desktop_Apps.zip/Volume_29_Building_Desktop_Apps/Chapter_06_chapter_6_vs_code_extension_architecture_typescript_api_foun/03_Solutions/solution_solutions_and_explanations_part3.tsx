/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

export interface VectorQueryPanelProps {
    initialThreshold?: number;
    onQuerySubmit?: (query: string, threshold: number) => void;
}

declare function acquireVsCodeApi(): {
    postMessage: (message: any) => void;
    getState: () => any;
    setState: (state: any) => void;
};

// Singleton initialization of the VS Code API handle
const vscodeApi = typeof acquireVsCodeApi !== 'undefined' ? acquireVsCodeApi() : null;

export const VectorQueryPanel: React.FC<VectorQueryPanelProps> = ({ initialThreshold = 0.75 }) => {
    const [queryText, setQueryText] = useState('');
    const [threshold, setThreshold] = useState(initialThreshold);
    const [results, setResults] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);

    // Interactive Challenge: Debounce reference for handling high-frequency search input
    const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setQueryText(value);

        if (debounceTimerRef.current) {
            clearTimeout(debounceTimerRef.current);
        }

        // Debounce extension messaging to prevent flooding the Extension Host
        debounceTimerRef.current = setTimeout(() => {
            if (vscodeApi) {
                vscodeApi.postMessage({ command: 'previewQuery', text: value, threshold });
            }
        }, 300);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        
        if (vscodeApi) {
            vscodeApi.postMessage({
                command: 'executeVectorSearch',
                payload: { queryText, threshold }
            });
        }
    };

    return (
        <div className="vector-query-container" style={{ padding: '16px', fontFamily: 'sans-serif' }}>
            <h2>Vector Query Management</h2>
            <form onSubmit={handleSubmit}>
                <div style={{ marginBottom: '12px' }}>
                    <label>Search Query: </label>
                    <input 
                        type="text" 
                        value={queryText} 
                        onChange={handleInputChange} 
                        placeholder="Type semantic query..."
                        style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                    />
                </div>
                <div style={{ marginBottom: '12px' }}>
                    <label>Similarity Threshold ({threshold}): </label>
                    <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.01" 
                        value={threshold} 
                        onChange={(e) => setThreshold(parseFloat(e.target.value))}
                        style={{ width: '100%' }}
                    />
                </div>
                <button type="submit" disabled={loading} style={{ padding: '8px 16px' }}>
                    {loading ? 'Executing...' : 'Run Query'}
                </button>
            </form>
            <div className="results-container" style={{ marginTop: '20px', maxHeight: '300px', overflowY: 'auto' }}>
                {results.map((res, index) => (
                    <div key={index} className="result-item" style={{ padding: '6px', borderBottom: '1px solid #ccc' }}>
                        {res}
                    </div>
                ))}
            </div>
        </div>
    );
};
