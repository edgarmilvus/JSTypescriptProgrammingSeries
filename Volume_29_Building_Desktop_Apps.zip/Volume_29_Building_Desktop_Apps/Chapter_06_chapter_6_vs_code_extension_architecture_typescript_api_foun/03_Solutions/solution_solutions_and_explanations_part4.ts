/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as vscode from 'vscode';

export type VectorExplorerNode = ConnectionNode | TableNode | IndexNode;

export interface ConnectionNode {
    type: 'connection';
    label: string;
    id: string;
    isConnected: boolean;
}

export interface TableNode {
    type: 'table';
    label: string;
    schemaName: string;
    rowCount: number;
}

export interface IndexNode {
    type: 'index';
    label: string;
    dimension: number;
    metric: 'cosine' | 'euclidean' | 'inner_product';
}

export class VectorExplorerProvider implements vscode.TreeDataProvider<VectorExplorerNode> {
    private _onDidChangeTreeData: vscode.EventEmitter<VectorExplorerNode | undefined | null | void> = new vscode.EventEmitter<VectorExplorerNode | undefined | null | void>();
    public readonly onDidChangeTreeData: vscode.Event<VectorExplorerNode | undefined | null | void> = this._onDidChangeTreeData.event;

    constructor() {
        // Registering context-menu drop command for Interactive Challenge
        vscode.commands.registerCommand('devtools.dropIndex', async (node: IndexNode) => {
            const confirmation = await vscode.window.showInformationMessage(
                `Are you sure you want to drop vector index '${node.label}'?`,
                { modal: true },
                'Yes'
            );

            if (confirmation === 'Yes') {
                // Execute deletion logic against backend service layer here
                vscode.window.showInformationMessage(`Index '${node.label}' successfully dropped.`);
                this.refresh();
            }
        });
    }

    public refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    public getTreeItem(element: VectorExplorerNode): vscode.TreeItem {
        const item = new vscode.TreeItem(element.label);

        switch (element.type) {
            case 'connection':
                item.collapsibleState = vscode.TreeItemCollapsibleState.Collapsed;
                item.iconPath = new vscode.ThemeIcon(element.isConnected ? 'database' : 'error');
                item.description = element.isConnected ? 'Connected' : 'Disconnected';
                break;
            case 'table':
                item.collapsibleState = vscode.TreeItemCollapsibleState.Collapsed;
                item.iconPath = new vscode.ThemeIcon('table');
                item.description = `${element.rowCount} rows`;
                break;
            case 'index':
                item.collapsibleState = vscode.TreeItemCollapsibleState.None;
                item.iconPath = new vscode.ThemeIcon('symbol-property');
                item.description = `Dim: ${element.dimension} (${element.metric})`;
                // Bind context value for declarative menu contributions in package.json
                item.contextValue = 'vectorIndex';
                break;
        }

        return item;
    }

    public async getChildren(element?: VectorExplorerNode): Promise<VectorExplorerNode[]> {
        if (!element) {
            // Root level: Return mock connections
            return [
                { type: 'connection', id: 'conn-1', label: 'Production DB (Supabase)', isConnected: true }
            ];
        }

        if (element.type === 'connection') {
            // Fetch tables for the selected connection asynchronously
            return [
                { type: 'table', label: 'embeddings_store', schemaName: 'public', rowCount: 12500 }
            ];
        }

        if (element.type === 'table') {
            // Fetch vector indexes associated with the table
            return [
                { type: 'index', label: 'idx_text_embedding_cosine', dimension: 1536, metric: 'cosine' }
            ];
        }

        return [];
    }
}
