/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual representation of a strongly typed frontend invocation wrapper
// bridging TypeScript and the Rust backend via Tauri's invoke API.

import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';

// Define the expected shape of the configuration payload using a Zod Schema.
// This ensures runtime safety before data crosses the IPC bridge.
const WorkspaceConfigSchema = z.object({
  workspacePath: z.string().min(1, { message: "Workspace path cannot be empty" }),
  maxThreads: z.number().int().positive().max(64),
  enableTelemetry: z.boolean(),
});

type WorkspaceConfig = z.infer<typeof WorkspaceConfigSchema>;

/**
 * Invokes the Rust backend command to update the application workspace configuration.
 * Demonstrates type safety, error boundaries, and IPC serialization.
 */
export async function updateWorkspaceConfig(rawConfig: unknown): Promise<WorkspaceConfig> {
  // Step 1: Runtime validation using the Zod schema.
  // This catches malformed data on the TypeScript side before wasting IPC bandwidth.
  const validationResult = WorkspaceConfigSchema.safeParse(rawConfig);
  
  if (!validationResult.success) {
    throw new Error(`Invalid configuration payload: ${validationResult.error.message}`);
  }

  const validConfig = validationResult.data;

  try {
    // Step 2: Cross the IPC boundary using Tauri's invoke function.
    // The payload is serialized to JSON automatically by the Tauri runtime.
    const response = await invoke<WorkspaceConfig>('save_workspace_config', {
      config: validConfig,
    });

    return response;
  } catch (error) {
    // Step 3: Robust error handling across the IPC boundary.
    // Errors thrown in Rust (e.g., std::io::Error) are serialized and caught here.
    console.error("Failed to persist workspace configuration in Rust backend:", error);
    throw error;
  }
}
