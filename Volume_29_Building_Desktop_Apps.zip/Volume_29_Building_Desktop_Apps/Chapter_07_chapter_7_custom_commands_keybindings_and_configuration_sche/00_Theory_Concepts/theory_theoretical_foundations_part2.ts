/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Comprehensive TypeScript module demonstrating immutable state management
// and Zod schema validation for developer tool configurations.

import { z } from 'zod';

// Define the comprehensive schema for a developer tool's configuration
export const DeveloperToolConfigSchema = z.object({
  version: z.literal(1),
  theme: z.enum(['dark', 'light', 'hc-dark', 'solarized']),
  editor: z.object({
    fontSize: z.number().int().min(8).max(72),
    tabSize: z.number().int().min(1).max(8),
    wordWrap: z.boolean(),
  }),
  aiAssistant: z.object({
    enabled: z.boolean(),
    modelName: z.string(),
    maxContextTokens: z.number().int().positive(),
    temperature: z.number().min(0.0).max(2.0),
  }),
  keybindings: z.record(z.string(), z.string()),
});

export type DeveloperToolConfig = z.infer<typeof DeveloperToolConfigSchema>;

/**
 * An immutable state store for managing developer tool configurations.
 * Demonstrates functional state updates without in-place mutation.
 */
export class ConfigurationStore {
  private currentState: DeveloperToolConfig;

  constructor(initialState: DeveloperToolConfig) {
    // Validate initial state against schema
    this.currentState = DeveloperToolConfigSchema.parse(initialState);
  }

  /**
   * Retrieves an immutable snapshot of the current configuration.
   */
  public getState(): Readonly<DeveloperToolConfig> {
    return this.currentState;
  }

  /**
   * Produces a new immutable state instance with partial updates applied.
   * Utilizes deep freezing and cloning to guarantee immutability.
   */
  public updateState(updater: (draft: DeveloperToolConfig) => Partial<DeveloperToolConfig>): DeveloperToolConfig {
    // Deep clone the current state to ensure pure functional immutability
    const clonedState: DeveloperToolConfig = JSON.parse(JSON.stringify(this.currentState));
    
    // Apply user modifications to the clone
    const partialUpdate = updater(clonedState);

    // Construct the candidate new state
    const candidateState: DeveloperToolConfig = {
      ...clonedState,
      ...partialUpdate,
      // Ensure nested objects are correctly merged immutably if provided partially
      editor: partialUpdate.editor ? { ...clonedState.editor, ...partialUpdate.editor } : clonedState.editor,
      aiAssistant: partialUpdate.aiAssistant ? { ...clonedState.aiAssistant, ...partialUpdate.aiAssistant } : clonedState.aiAssistant,
      keybindings: partialUpdate.keybindings ? { ...clonedState.keybindings, ...partialUpdate.keybindings } : clonedState.keybindings,
    };

    // Validate the candidate state against the Zod schema before committing
    const validationResult = DeveloperToolConfigSchema.safeParse(candidateState);

    if (!validationResult.success) {
      throw new Error(`State mutation rejected by schema validation: ${validationResult.error.message}`);
    }

    // Atomically swap the pointer to the new immutable state
    this.currentState = validationResult.data;

    return this.currentState;
  }
}
