/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// Comprehensive TypeScript utility demonstrating robust error handling
// and type-safe result unwrapping across the Tauri IPC boundary.

import { invoke } from '@tauri-apps/api/core';
import { DeveloperToolConfig, DeveloperToolConfigSchema } from './configStore';

// Define a discriminated union type for command execution results,
// mirroring Rust's Result<T, E> pattern on the frontend.
export type CommandResult<T> = 
  | { success: true; data: T }
  | { success: false; error: { code: string; message: string } };

/**
 * Safely executes a Tauri command with exhaustive error handling
 * and runtime schema verification of the returned data.
 */
export async function loadConfigFromBackend(): Promise<CommandResult<DeveloperToolConfig>> {
  try {
    // Invoke the Rust backend command
    const rawResponse = await invoke<unknown>('get_developer_config');

    // Validate the response data against the Zod schema at runtime.
    // Even if Rust sends valid JSON, schema validation guarantees shape integrity.
    const validationResult = DeveloperToolConfigSchema.safeParse(rawResponse);

    if (!validationResult.success) {
      return {
        success: false,
        error: {
          code: 'SCHEMA_VALIDATION_ERROR',
          message: `Backend response violated configuration schema: ${validationResult.error.message}`,
        },
      };
    }

    return {
      success: true,
      data: validationResult.data,
    };
  } catch (error: unknown) {
    // Handle network, IPC serialization, or unhandled Rust panics
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    return {
      success: false,
      error: {
        code: 'IPC_TRANSMISSION_ERROR',
        message: `Failed to communicate with Rust backend: ${errorMessage}`,
      },
    };
  }
}
