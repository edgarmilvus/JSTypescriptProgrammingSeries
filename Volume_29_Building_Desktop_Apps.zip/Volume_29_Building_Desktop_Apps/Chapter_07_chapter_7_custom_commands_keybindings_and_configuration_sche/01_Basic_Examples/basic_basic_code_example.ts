/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file app-config.ts
 * @description A self-contained module demonstrating runtime validation using Zod,
 * immutable state management, and asynchronous operations for a SaaS desktop application.
 */

// ==========================================
// 1. ZOD SCHEMA DEFINITION
// ==========================================

/**
 * Defines the strict structural shape and constraints of the application configuration.
 * Used for runtime validation of incoming data and automatic static type inference.
 */
export const AppConfigSchema = z.object({
  /** Unique identifier for the workspace */
  workspaceId: z.string().uuid({ message: "Workspace ID must be a valid UUID" }),
  
  /** Application theme preference */
  theme: z.enum(['light', 'dark', 'system']).default('system'),
  
  /** Feature flags toggled by the user */
  features: z.object({
    telemetry: z.boolean().default(true),
    advancedLogging: z.boolean().default(false),
  }),
  
  /** API rate limits or timeout configurations in milliseconds */
  timeoutMs: z.number().int().positive().max(60000).default(5000),
});

/**
 * Automatically infers the TypeScript type directly from the Zod schema.
 * Ensures the compile-time type always matches the runtime validation logic.
 */
export type AppConfig = z.infer<typeof AppConfigSchema>;


// ==========================================
// 2. IMMUTABLE STATE & ASYNCHRONOUS TOOL HANDLING
// ==========================================

/**
 * Represents the current application state container.
 */
let currentConfig: AppConfig = {
  workspaceId: "00000000-0000-0000-0000-000000000000",
  theme: 'system',
  features: {
    telemetry: true,
    advancedLogging: false,
  },
  timeoutMs: 5000,
};

/**
 * Retrieves an immutable copy of the current application configuration.
 * Adheres to the Immutable State Management principle by preventing direct reference mutation.
 * 
 * @returns {Readonly<AppConfig>} A frozen/read-only snapshot of the configuration.
 */
export function getAppConfig(): Readonly<AppConfig> {
  // Return a deep clone/copy to guarantee immutability of the internal state
  return JSON.parse(JSON.stringify(currentConfig));
}

/**
 * Asynchronously validates raw input data, updates the application state immutably,
 * and simulates persisting the configuration to disk (e.g., via a Tauri backend command).
 * 
 * @async
 * @param {unknown} rawInput - Untrusted input data from an external source or frontend form.
 * @returns {Promise<Readonly<AppConfig>>} The newly updated and validated configuration.
 * @throws {z.ZodError} If the validation fails.
 */
export async function updateAndPersistConfig(rawInput: unknown): Promise<Readonly<AppConfig>> {
  // Step A: Runtime validation using the Zod schema
  const validationResult = AppConfigSchema.safeParse(rawInput);

  if (!validationResult.success) {
    // Format and throw detailed validation errors for debugging and UI feedback
    const errorMessages = validationResult.error.errors
      .map(err => `${err.path.join('.')}: ${err.message}`)
      .join(', ');
    throw new Error(`Configuration validation failed: ${errorMessages}`);
  }

  const validatedData = validationResult.data;

  // Step B: Immutable state transition (creating a new object rather than mutating in place)
  const nextConfig: AppConfig = {
    ...validatedData,
    features: {
      ...validatedData.features,
    },
  };

  // Step C: Asynchronous tool handling (simulating a non-blocking IPC call or disk write)
  await simulateDiskPersistence(nextConfig);

  // Step D: Commit the new state reference safely
  currentConfig = nextConfig;

  // Return an immutable snapshot of the newly committed state
  return getAppConfig();
}

/**
 * Simulates an asynchronous disk write or Tauri IPC command execution.
 * Wraps the operation in a Promise to ensure non-blocking execution.
 * 
 * @async
 * @param {AppConfig} config - The configuration object to persist.
 * @returns {Promise<void>}
 */
async function simulateDiskPersistence(config: AppConfig): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!config.workspaceId) {
        reject(new Error("Persistence failed: Missing workspace identifier."));
      } else {
        // Simulated successful write to disk / Tauri store
        resolve();
      }
    }, 150);
  });
}
