/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { z } from 'zod';

/**
 * @file app-config-manager.ts
 * @description Manages configuration schemas, Tauri custom command invocation,
 *              and immutable state updates for a developer tooling desktop application.
 */

/**
 * 1. Define the Zod Schema for the application configuration.
 * This guarantees runtime validation and infers the compile-time TypeScript type.
 */
export const AppConfigSchema = z.object({
  theme: z.enum(['dark', 'light', 'system']).default('dark'),
  telemetryEnabled: z.boolean().default(false),
  maxConcurrentWorkers: z.number().int().min(1).max(16).default(4),
  hotkeyBinding: z.string().min(3).default('CmdOrCtrl+Shift+D'),
  workspaceRoot: z.string().min(1).default('/path/to/default/workspace'),
});

// Infer the TypeScript type directly from the Zod schema to maintain end-to-end type safety
export type AppConfig = z.infer<typeof AppConfigSchema>;

/**
 * 2. Immutable State Manager for Application Configurations.
 * Ensures data structures are never mutated in place, preventing race conditions
 * during asynchronous Tauri IPC operations.
 */
export class ConfigManager {
  private state: AppConfig;

  constructor(initialConfig: AppConfig) {
    // Validate initial config against the Zod schema at runtime
    this.state = AppConfigSchema.parse(initialConfig);
  }

  /**
   * Retrieves an immutable snapshot of the current configuration state.
   */
  public getState(): Readonly<AppConfig> {
    return Object.freeze({ ...this.state });
  }

  /**
   * Updates the configuration immutably by merging partial updates
   * and validating the resulting shape.
   */
  public updateState(updates: Partial<AppConfig>): Readonly<AppConfig> {
    const candidate = { ...this.state, ...updates };
    
    // Validate the candidate object; throws ZodError if validation fails
    const validated = AppConfigSchema.parse(candidate);
    
    // Immutably replace the state reference
    this.state = validated;
    return this.getState();
  }
}

/**
 * 3. Tauri IPC Bridge & Command Wrappers
 */
export async function loadConfigFromBackend(): Promise<AppConfig> {
  try {
    // Invoke the custom Rust command 'get_user_config'
    const rawConfig = await invoke<unknown>('get_user_config');
    
    // Validate untrusted data coming across the Rust-TS boundary
    const parsedConfig = AppConfigSchema.parse(rawConfig);
    return parsedConfig;
  } catch (error) {
    console.error('Failed to load or validate configuration from backend:', error);
    throw new Error('Configuration initialization failed due to schema mismatch.');
  }
}

export async function saveConfigToBackend(config: AppConfig): Promise<void> {
  // Ensure the payload strictly matches the Zod schema before sending to Rust
  const validatedPayload = AppConfigSchema.parse(config);

  try {
    await invoke('save_user_config', { newConfig: validatedPayload });
    console.log('Configuration successfully persisted by backend.');
  } catch (error) {
    console.error('IPC Error while saving configuration:', error);
    throw error;
  }
}

/**
 * 4. Global Keybinding and Event Listener Initialization
 */
export async function initializeEventListeners(
  configManager: ConfigManager,
  onConfigChange: (newConfig: Readonly<AppConfig>) => void
): Promise<() => void> {
  // Listen for backend-emitted keybinding trigger events
  const unlistenKeybinding = await listen<string>('global-shortcut-triggered', (event) => {
    console.log(`Global shortcut fired: ${event.payload}`);
    const currentState = configManager.getState();
    
    // Perform an immutable toggle or action based on current state
    const updated = configManager.updateState({
      maxConcurrentWorkers: currentState.maxConcurrentWorkers === 4 ? 8 : 4
    });
    
    onConfigChange(updated);
  });

  // Return a cleanup function to unregister listeners when components unmount
  return () => {
    unlistenKeybinding();
  };
}
