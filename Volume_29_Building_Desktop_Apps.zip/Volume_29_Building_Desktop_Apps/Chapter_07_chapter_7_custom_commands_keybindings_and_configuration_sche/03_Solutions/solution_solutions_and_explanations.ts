/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';

// Define the Zod schema matching the exact shape and types returned by the Rust backend
export const WorkspaceStatusSchema = z.object({
  status: z.string(),
  // FIXED: Parse active_timestamp as a number (u64 in Rust maps to number in JS/TS)
  active_timestamp: z.number(), 
});

export type WorkspaceStatus = z.infer<typeof WorkspaceStatusSchema>;

export interface WorkspaceConfigInput {
  workspaceId: string;
  maxTokens: number;
  allowedExtensions: string[];
  autoSave: boolean;
}

/**
 * Invokes the Rust 'configure_workspace' command and validates the output.
 */
export async function invokeConfigureWorkspace(config: WorkspaceConfigInput): Promise<WorkspaceStatus> {
  try {
    // Invoke the Tauri command safely across the IPC bridge
    const rawResponse = await invoke('configure_workspace', { config });
    
    // Parse and validate the response against our Zod schema
    const validatedData = WorkspaceStatusSchema.parse(rawResponse);
    return validatedData;
  } catch (error) {
    // FIXED: Properly differentiate between Tauri IPC execution errors and Zod validation errors
    if (error instanceof z.ZodError) {
      console.error("Zod Validation Error - Backend payload mismatch:", error.issues);
      throw new Error(`Data corruption detected from backend: ${error.message}`);
    }
    
    console.error("Tauri IPC Execution Failed:", error);
    throw error;
  }
}
