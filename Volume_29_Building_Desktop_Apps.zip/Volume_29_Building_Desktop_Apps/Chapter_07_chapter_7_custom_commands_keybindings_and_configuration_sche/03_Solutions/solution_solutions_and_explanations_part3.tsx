/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface KeybindingItem {
  id: string;
  label: string;
  currentKey: string;
  category: string;
}

interface KeybindingManagerProps {
  initialBindings: KeybindingItem[];
  onBindingChange: (id: string, newKey: string) => Promise<void>;
}

export const KeybindingManager: React.FC<KeybindingManagerProps> = ({
  initialBindings,
  onBindingChange,
}) => {
  const [bindings, setBindings] = useState<KeybindingItem[]>(initialBindings);
  const [recordingId, setRecordingId] = useState<string | null>(null);
  const [tempKey, setTempKey] = useState<string>('');

  useEffect(() => {
    if (!recordingId) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      event.preventDefault();
      event.stopPropagation();

      const modifiers: string[] = [];
      if (event.ctrlKey) modifiers.push('Ctrl');
      if (event.metaKey) modifiers.push('Cmd');
      if (event.shiftKey) modifiers.push('Shift');
      if (event.altKey) modifiers.push('Alt');

      const mainKey = event.key.toUpperCase();
      
      // Prevent capturing lone modifier presses
      if (['CONTROL', 'META', 'SHIFT', 'ALT'].includes(mainKey)) {
        return;
      }

      const formattedCombo = [...modifiers, mainKey].join('+');
      setTempKey(formattedCombo);
      
      // Automatically commit the captured shortcut and dispatch action
      if (recordingId) {
        onBindingChange(recordingId, formattedCombo).then(() => {
          setBindings((prev) =>
            prev.map((b) => (b.id === recordingId ? { ...b, currentKey: formattedCombo } : b))
          );
          setRecordingId(null);
          setTempKey('');
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [recordingId, onBindingChange]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <h2 className="text-xl font-bold mb-4">Global Keybindings Manager</h2>
      <div className="space-y-3">
        {bindings.map((binding) => (
          <div key={binding.id} className="flex justify-between items-center p-3 bg-slate-800 rounded">
            <div>
              <span className="font-medium">{binding.label}</span>
              <span className="text-xs text-slate-400 block">{binding.category}</span>
            </div>
            <button
              onClick={() => setRecordingId(binding.id)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 rounded text-sm font-mono transition-colors"
            >
              {recordingId === binding.id ? (tempKey || 'Press keys...') : binding.currentKey}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
