/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const ModelParamsSchema = z.object({
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().int().min(100).max(128000),
  topP: z.number().min(0).max(1).default(1.0),
});

export const EndpointSchema = z.object({
  name: z.string().min(1, "Endpoint name cannot be empty"),
  // Instructor Note: z.string().url() natively handles standard HTTP/HTTPS URLs (including localhost sockets like http://localhost:8080/v1). 
  // However, custom non-HTTP IPC sockets (e.g., unix:// or custom pipe strings) would fail a strict .url() check.
  url: z.string().url("Must be a valid HTTP or HTTPS URL"),
  enabled: z.boolean().default(true),
});

export const AppConfigSchema = z.object({
  version: z.literal("2.0"),
  modelParams: ModelParamsSchema,
  endpoints: z.array(EndpointSchema).min(1, "At least one endpoint must be configured"),
  experimentalFeatures: z.record(z.string(), z.boolean()).default({}),
});

export type AppConfig = z.infer<typeof AppConfigSchema>;

export type ValidationErrorDetails = {
  path: string;
  message: string;
};

export type Result<T, E> = 
  | { success: true; data: T }
  | { success: false; errors: E[] };

/**
 * Parses and validates raw configuration JSON strings with granular error diagnostics.
 */
export function parseAndValidateConfig(rawJsonString: string): Result<AppConfig, ValidationErrorDetails> {
  try {
    const parsedJson = JSON.parse(rawJsonString);
    const result = AppConfigSchema.safeParse(parsedJson);

    if (!result.success) {
      const errors: ValidationErrorDetails[] = result.error.issues.map((issue) => ({
        path: issue.path.join('.'),
        message: issue.message,
      }));
      return { success: false, errors };
    }

    return { success: true, data: result.data };
  } catch (syntaxError) {
    return {
      success: false,
      errors: [{ path: 'root', message: `Invalid JSON syntax: ${(syntaxError as Error).message}` }],
    };
  }
}
