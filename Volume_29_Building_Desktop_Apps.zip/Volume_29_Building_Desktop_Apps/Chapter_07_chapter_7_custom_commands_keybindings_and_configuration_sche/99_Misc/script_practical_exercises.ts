/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';

// Define the Zod schema for the workspace configuration response
export const WorkspaceStatusSchema = z.object({
  status: z.string(),
  // BUGGY AREA: Analyze the type constraint below against the Rust u64 backend type
  active_timestamp: z.string(), 
});

export type WorkspaceStatus = z.infer<typeof WorkspaceStatusSchema>;

export interface WorkspaceConfigInput {
  workspaceId: string;
  maxTokens: number;
  allowedExtensions: string[];
  autoSave: boolean;
}

/**
 * Invokes the Rust 'configure_workspace' command and validates the output.
 */
export async function invokeConfigureWorkspace(config: WorkspaceConfigInput): Promise<WorkspaceStatus> {
  try {
    // Invoke the Tauri command
    const rawResponse = await invoke('configure_workspace', { config });
    
    // Parse and validate the response against our Zod schema
    const validatedData = WorkspaceStatusSchema.parse(rawResponse);
    return validatedData;
  } catch (error) {
    // BUGGY AREA: How should we handle raw errors thrown by Tauri vs Zod validation errors?
    console.error("Failed to configure workspace:", error);
    throw error;
  }
}
