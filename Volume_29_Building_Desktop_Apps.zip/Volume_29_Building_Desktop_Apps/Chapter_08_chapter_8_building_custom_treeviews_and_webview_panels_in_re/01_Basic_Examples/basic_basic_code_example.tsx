/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @file TreeViewNode.tsx
 * @description A self-contained, high-performance React component demonstrating 
 * a recursive TreeView node for a Tauri 2.0 desktop project explorer.
 */

import React, { useState, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';

/**
 * Represents a single node within the project hierarchy TreeView.
 */
export interface TreeNode {
  id: string;
  name: string;
  kind: 'file' | 'directory';
  children?: TreeNode[];
}

/**
 * Properties for the TreeViewNode component.
 */
interface TreeViewNodeProps {
  node: TreeNode;
  level: number;
  onSelect: (nodeId: string) => void;
  selectedId: string | null;
}

/**
 * TreeViewNode Component
 * Renders a recursive tree node, handling expansion toggles and IPC calls to Rust.
 */
export const TreeViewNode: React.FC<TreeViewNodeProps> = ({
  node,
  level,
  onSelect,
  selectedId,
}) => {
  // Local state to track whether a directory node is expanded
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  
  // Local state for dynamically loaded children if fetched lazily from Rust
  const [children, setChildren] = useState<TreeNode[]>(node.children || []);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  /**
   * Handles node expansion and triggers a Tauri IPC command if lazy loading is required.
   */
  const handleToggleExpand = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();

    if (node.kind === 'directory') {
      // If we are expanding and children are not populated, fetch them from Rust backend
      if (!isExpanded && (!children || children.length === 0)) {
        try {
          setIsLoading(true);
          // Invoke Rust command 'get_directory_children' via Tauri 2.0 IPC core API
          const fetchedChildren = await invoke<TreeNode[]>('get_directory_children', {
            dirId: node.id,
          });
          setChildren(fetchedChildren);
        } catch (error) {
          console.error(`Failed to fetch children for node ${node.id}:`, error);
        } finally {
          setIsLoading(false);
        }
      }
      setIsExpanded((prev) => !prev);
    }
  }, [isExpanded, node.id, node.kind, children]);

  /**
   * Handles the selection event for the node.
   */
  const handleSelect = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect(node.id);
  }, [node.id, onSelect]);

  // Determine styling based on selection and tree depth
  const isSelected = selectedId === node.id;
  const paddingLeftStyle = { paddingLeft: `${level * 16}px` };

  return (
    <div className="tree-node-container">
      <div
        className={`tree-node-row ${isSelected ? 'selected' : ''}`}
        style={paddingLeftStyle}
        onClick={handleSelect}
      >
        {node.kind === 'directory' ? (
          <button 
            className="expand-btn" 
            onClick={handleToggleExpand}
            aria-label={`Toggle ${node.name}`}
          >
            {isLoading ? '⏳' : isExpanded ? '▼' : '▶'}
          </button>
        ) : (
          <span className="file-spacer" />
        )}
        <span className="node-icon">
          {node.kind === 'directory' ? '📁' : '📄'}
        </span>
        <span className="node-name">{node.name}</span>
      </div>

      {/* Recursively render child nodes if expanded */}
      {node.kind === 'directory' && isExpanded && (
        <div className="tree-node-children">
          {children.map((childNode) => (
            <TreeViewNode
              key={childNode.id}
              node={childNode}
              level={level + 1}
              onSelect={onSelect}
              selectedId={selectedId}
            />
          ))}
        </div>
      )}
    </div>
  );
};
