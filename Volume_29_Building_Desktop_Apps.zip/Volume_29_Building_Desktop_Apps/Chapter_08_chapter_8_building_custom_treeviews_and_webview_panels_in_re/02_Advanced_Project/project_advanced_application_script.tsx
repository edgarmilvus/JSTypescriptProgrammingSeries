/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file AppController.tsx
 * @description Advanced application orchestration script for Tauri 2.0 desktop tools.
 * Manages webview panel lifecycle, virtualized tree node state, and Rust IPC synchronization.
 */

import React, { useState, useEffect, useCallback, useRef } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";

/**
 * Represents a node within the virtualized project hierarchy tree view.
 */
export interface TreeNode {
  id: string;
  name: string;
  kind: "file" | "directory";
  children?: TreeNode[];
  expanded?: boolean;
}

/**
 * Represents an active webview panel layout configuration.
 */
export interface WebviewPanel {
  id: string;
  title: string;
  activeNodeId: string | null;
  scrollOffset: number;
  isDirty: boolean;
}

/**
 * Payload interface for file system change events emitted from the Rust backend.
 */
interface FsChangeEvent {
  path: string;
  kind: "created" | "modified" | "deleted";
}

export const AdvancedWorkspaceManager: React.FC = () => {
  // Application-wide tree state for the project navigator
  const [treeData, setTreeData] = useState<TreeNode[]>([]);
  
  // Active panels collection managed by the dynamic layout engine
  const [panels, setPanels] = useState<WebviewPanel[]>([
    { id: "panel-1", title: "Welcome", activeNodeId: null, scrollOffset: 0, isDirty: false }
  ]);
  
  const [activePanelId, setActivePanelId] = useState<string>("panel-1");
  const isSyncingRef = useRef<boolean>(false);

  /**
   * Initializes the workspace by fetching the root directory structure from the Rust backend.
   */
  const initializeWorkspace = async () => {
    try {
      const initialRoot = await invoke<TreeNode[]>("get_project_tree", { path: "." });
      setTreeData(initialRoot);
    } catch (error) {
      console.error("Failed to load project tree from Rust backend:", error);
    }
  };

  /**
   * Synchronizes panel state changes back to the Rust backend for local disk persistence.
   */
  const persistPanelState = useCallback(async (panel: WebviewPanel) => {
    if (isSyncingRef.current) return;
    isSyncingRef.current = true;
    try {
      await invoke("save_panel_state", { panelId: panel.id, state: panel });
    } catch (error) {
      console.error(`Failed to persist state for panel ${panel.id}:`, error);
    } finally {
      isSyncingRef.current = false;
    }
  }, []);

  // Setup Tauri event listeners for real-time filesystem synchronization
  useEffect(() => {
    initializeWorkspace();

    let unlistenFs: (() => void) | undefined;

    const setupListeners = async () => {
      unlistenFs = await listen<FsChangeEvent>("fs-change", (event) => {
        const { path, kind } = event.payload;
        console.log(`Filesystem mutation detected [${kind}]: ${path}`);
        // Trigger incremental tree node refresh via IPC
        initializeWorkspace();
      });
    };

    setupListeners();

    return () => {
      if (unlistenFs) unlistenFs();
    };
  }, []);

  /**
   * Handles user interaction within the virtualized tree view, expanding nodes 
   * or opening corresponding files in active webview panels.
   */
  const handleNodeSelect = useCallback((node: TreeNode) => {
    setPanels((prevPanels) =>
      prevPanels.map((panel) => {
        if (panel.id === activePanelId) {
          const updatedPanel = {
            ...panel,
            title: node.name,
            activeNodeId: node.id,
            isDirty: true,
          };
          persistPanelState(updatedPanel);
          return updatedPanel;
        }
        return panel;
      })
    );
  }, [activePanelId, persistPanelState]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-gray-950 text-gray-100 font-sans">
      {/* Sidebar: Virtualized TreeView Container */}
      <div className="w-80 border-r border-gray-800 flex flex-col bg-gray-900">
        <div className="p-3 text-xs font-semibold tracking-wider text-gray-400 uppercase border-b border-gray-800">
          Project Navigator
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {treeData.map((node) => (
            <div 
              key={node.id} 
              onClick={() => handleNodeSelect(node)}
              className="px-2 py-1 hover:bg-gray-800 rounded cursor-pointer text-sm truncate"
            >
              {node.kind === "directory" ? "📁 " : "📄 "} {node.name}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content: Multi-Panel Webview Canvas */}
      <div className="flex-1 flex flex-col">
        <div className="flex bg-gray-900 border-b border-gray-800">
          {panels.map((panel) => (
            <button
              key={panel.id}
              onClick={() => setActivePanelId(panel.id)}
              className={`px-4 py-2 text-sm border-r border-gray-800 flex items-center space-x-2 ${
                activePanelId === panel.id ? "bg-gray-950 text-white border-t-2 border-t-blue-500" : "text-gray-400 hover:bg-gray-850"
              }`}
            >
              <span>{panel.title}</span>
              {panel.isDirty && <span className="w-2 h-2 rounded-full bg-blue-400"></span>}
            </button>
          ))}
        </div>
        <div className="flex-1 bg-gray-950 p-6 overflow-auto">
          {panels.find((p) => p.id === activePanelId)?.activeNodeId ? (
            <div className="text-gray-300">
              Active File Node ID: {panels.find((p) => p.id === activePanelId)?.activeNodeId}
            </div>
          ) : (
            <div className="text-gray-500 text-center mt-20">
              Select a file from the project navigator to load the view panel.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdvancedWorkspaceManager;
