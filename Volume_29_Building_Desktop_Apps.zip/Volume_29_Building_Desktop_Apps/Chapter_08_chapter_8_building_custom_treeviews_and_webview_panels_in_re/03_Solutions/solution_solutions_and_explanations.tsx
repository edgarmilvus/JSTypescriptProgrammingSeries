/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';

export interface TreeNode {
  id: string;
  name: string;
  isDir: boolean;
  isOpen?: boolean;
  loaded?: boolean;
  children?: TreeNode[];
}

interface VirtualizedTreeViewProps {
  initialNodes: TreeNode[];
}

export function VirtualizedTreeView({ initialNodes }: VirtualizedTreeViewProps) {
  const [nodes, setNodes] = useState<TreeNode[]>(initialNodes);
  const [focusedId, setFocusedId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Flatten tree for windowing/virtualization based on visibility of open nodes
  const flattenTree = (list: TreeNode[], acc: TreeNode[] = []): TreeNode[] => {
    for (const node of list) {
      acc.push(node);
      if (node.isDir && node.isOpen && node.children) {
        flattenTree(node.children, acc);
      }
    }
    return acc;
  };

  const visibleNodes = flattenTree(nodes);

  // Lazy load node children using Tauri IPC
  const toggleNode = async (targetId: string) => {
    const updateNodes = async (list: TreeNode[]): Promise<TreeNode[]> => {
      return Promise.all(
        list.map(async (node) => {
          if (node.id === targetId) {
            let children = node.children;
            let loaded = node.loaded;
            const isOpen = !node.isOpen;

            // Fetch from Tauri backend if it's a directory, open, and not loaded yet
            if (isOpen && node.isDir && !loaded) {
              try {
                children = await invoke<TreeNode[]>('plugin:fs|read_dir_lazy', { id: node.id });
                loaded = true;
              } catch (err) {
                console.error(`Failed to load directory contents for ${node.id}:`, err);
              }
            }

            return { ...node, isOpen, loaded, children };
          }
          if (node.children) {
            return { ...node, children: await updateNodes(node.children) };
          }
          return node;
        })
      );
    };

    const updated = await updateNodes(nodes);
    setNodes(updated);
  };

  // Keyboard navigation handler
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!focusedId) return;
    const index = visibleNodes.findIndex(n => n.id === focusedId);
    if (index === -1) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (index < visibleNodes.length - 1) {
        setFocusedId(visibleNodes[index + 1].id);
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (index > 0) {
        setFocusedId(visibleNodes[index - 1].id);
      }
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      const node = visibleNodes[index];
      if (node.isDir && !node.isOpen) {
        toggleNode(node.id);
      }
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      const node = visibleNodes[index];
      if (node.isDir && node.isOpen) {
        toggleNode(node.id);
      }
    }
  }, [focusedId, visibleNodes]);

  return (
    <div 
      ref={containerRef} 
      tabIndex={0} 
      onKeyDown={handleKeyDown}
      className="tree-view-container"
      style={{ height: '400px', overflowY: 'auto', outline: 'none' }}
    >
      {visibleNodes.map((node, idx) => (
        <div
          key={node.id}
          onClick={() => {
            setFocusedId(node.id);
            if (node.isDir) toggleNode(node.id);
          }}
          style={{
            paddingLeft: `${idx * 0}px`, // Simplified indentation logic placeholder
            background: focusedId === node.id ? '#e0e0e0' : 'transparent',
            cursor: 'pointer'
          }}
        >
          {node.isDir ? (node.isOpen ? '📂 ' : '📁 ') : '📄 '}
          {node.name}
        </div>
      ))}
    </div>
  );
}
