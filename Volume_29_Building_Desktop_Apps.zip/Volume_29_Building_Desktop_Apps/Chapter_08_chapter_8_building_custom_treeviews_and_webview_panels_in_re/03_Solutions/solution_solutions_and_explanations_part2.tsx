/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';

export type SplitDirection = 'horizontal' | 'vertical';

export interface SplitPaneNode {
  id: string;
  direction: SplitDirection;
  sizes: number[];
  children: Array<SplitPaneNode | LeafPanelNode>;
}

export interface LeafPanelNode {
  id: string;
  componentId: string;
}

export function usePaneResizer(initialLayout: SplitPaneNode) {
  const [layout, setLayout] = useState<SplitPaneNode>(initialLayout);
  const draggingRef = useRef<{ nodeId: string; index: number; startX: number; startY: number } | null>(null);

  const handleDragStart = (nodeId: string, index: number, e: React.MouseEvent) => {
    e.preventDefault();
    draggingRef.current = {
      nodeId,
      index,
      startX: e.clientX,
      startY: e.clientY,
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!draggingRef.current) return;
    const { nodeId, index, startX, startY } = draggingRef.current;
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;

    setLayout((prevLayout) => {
      // Helper function to update node sizes recursively
      const updateSizes = (node: SplitPaneNode): SplitPaneNode => {
        if (node.id === nodeId) {
          const newSizes = [...node.sizes];
          const delta = node.direction === 'horizontal' ? deltaX : deltaY;
          // Apply percentage boundary constraints logic
          newSizes[index] += delta;
          newSizes[index + 1] -= delta;
          return { ...node, sizes: newSizes };
        }
        return {
          ...node,
          children: node.children.map((child) =>
            'direction' in child ? updateSizes(child) : child
          ),
        };
      };
      return updateSizes(prevLayout);
    });
  };

  const handleMouseUp = useCallback(async () => {
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);

    if (draggingRef.current) {
      draggingRef.current = null;
      try {
        // Persist final layout configuration state to Rust backend via Tauri
        await invoke('plugin:config|save_layout', { layout });
      } catch (err) {
        console.error('Failed to save pane layout configuration:', err);
      }
    }
  }, [layout]);

  return { layout, handleDragStart };
}
