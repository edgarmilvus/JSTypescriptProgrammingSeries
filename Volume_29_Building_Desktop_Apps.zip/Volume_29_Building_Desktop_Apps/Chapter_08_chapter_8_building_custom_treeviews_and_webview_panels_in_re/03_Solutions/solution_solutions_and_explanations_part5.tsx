/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect, useRef } from 'react';
import { listen } from '@tauri-apps/api/event';

export function useBufferedStream<T>(
  eventName: string, 
  batchIntervalMs: number = 50, 
  maxBufferSize: number = 2000
) {
  const [buffer, setBuffer] = useState<T[]>([]);
  const queueRef = useRef<T[]>([] as T[]);

  useEffect(() => {
    let unlisten: (() => void) | undefined;

    async function init() {
      unlisten = await listen<T>(eventName, (event) => {
        queueRef.current.push(event.payload);
        // Maintain an immutable ring buffer window limit to conserve memory
        if (queueRef.current.length > maxBufferSize) {
          queueRef.current = queueRef.current.slice(-maxBufferSize);
        }
      });
    }

    init();

    // Throttle state updates using fixed-time intervals
    const intervalId = setInterval(() => {
      if (queueRef.current.length > 0) {
        setBuffer([...queueRef.current]);
      }
    }, batchIntervalMs);

    return () => {
      if (unlisten) unlisten();
      clearInterval(intervalId);
    };
  }, [eventName, batchIntervalMs, maxBufferSize]);

  return buffer;
}
