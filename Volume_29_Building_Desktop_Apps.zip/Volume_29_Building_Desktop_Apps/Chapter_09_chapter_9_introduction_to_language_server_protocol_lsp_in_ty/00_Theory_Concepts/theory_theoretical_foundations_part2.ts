/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Define a generic wrapper for JSON-RPC messages
export interface JsonRpcRequest<TParams = unknown> {
    jsonrpc: '2.0';
    id: number | string;
    method: string;
    params?: TParams;
}

export interface JsonRpcResponse<TResult = unknown> {
    jsonrpc: '2.0';
    id: number | string;
    result?: TResult;
    error?: JsonRpcError;
}

export interface JsonRpcError {
    code: number;
    message: string;
    data?: unknown;
}

// A generic transport connection class managing bidirectional messaging
export class LspConnection {
    private nextId: number = 1;
    private pendingRequests = new Map<number | string, {
        resolve: (value: any) => void;
        reject: (reason: any) => void;
    }>();

    /**
     * Sends an LSP request and returns a strongly typed Promise resolving to the expected result type.
     * 
     * @template TParams The type of the parameter object required by the specific method.
     * @template TResult The type of the result object returned by the language server.
     * @param method The LSP method name (e.g., 'textDocument/completion').
     * @param params The strongly typed parameter payload.
     * @returns A Promise resolving to the strongly typed result.
     */
    public sendRequest<TParams, TResult>(
        method: string, 
        params: TParams
    ): Promise<TResult> {
        return new Promise<TResult>((resolve, reject) => {
            const id = this.nextId++;
            
            // Store the resolver/rejecter in our pending map using the unique request ID
            this.pendingRequests.set(id, { resolve, reject });

            const request: JsonRpcRequest<TParams> = {
                jsonrpc: '2.0',
                id,
                method,
                params,
            };

            // Transmit the serialized request over Tauri IPC or WebSocket transport
            this.writeMessageToTransport(request);
        });
    }

    /**
     * Handles incoming messages received from the language server process.
     */
    public handleIncomingMessage(message: string): void {
        const parsed = JSON.parse(message);

        // Check if the message is a response to a pending request (has an 'id' and matches a pending request)
        if ('id' in parsed && this.pendingRequests.has(parsed.id)) {
            const { resolve, reject } = this.pendingRequests.get(parsed.id)!;
            this.pendingRequests.delete(parsed.id);

            const response = parsed as JsonRpcResponse;
            if (response.error) {
                reject(new Error(`LSP Error [${response.error.code}]: ${response.error.message}`));
            } else {
                resolve(response.result);
            }
        } 
        // Otherwise, handle incoming notifications (e.g., textDocument/publishDiagnostics)
        else if ('method' in parsed && !('id' in parsed)) {
            this.handleNotification(parsed.method, parsed.params);
        }
    }

    private writeMessageToTransport(request: unknown): void {
        // Implementation details for writing to Tauri backend or WebSocket
        console.log('Sending message:', JSON.stringify(request));
    }

    private handleNotification(method: string, params: unknown): void {
        console.log(`Received notification for ${method}:`, params);
    }
}
