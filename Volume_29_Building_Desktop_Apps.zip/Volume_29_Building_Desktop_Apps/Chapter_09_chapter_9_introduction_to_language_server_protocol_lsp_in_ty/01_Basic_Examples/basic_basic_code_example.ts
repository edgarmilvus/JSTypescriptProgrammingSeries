/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Child, Command } from '@tauri-apps/plugin-shell';

/**
 * Represents the structure of a JSON-RPC 2.0 message payload.
 */
interface JsonRpcMessage {
  jsonrpc: '2.0';
  id?: number | string;
  method?: string;
  params?: unknown;
  result?: unknown;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}

/**
 * A robust, production-grade LSP Client designed to run inside a Tauri 2.0 
 * desktop application, managing a child process over stdio.
 */
export class TauriLspClient {
  private serverProcess: Child | null = null;
  private messageId = 1;
  private responseHandlers = new Map<number | string, { resolve: (val: any) => void; reject: (err: any) => void }>();
  private buffer = '';

  /**
   * Spawns the language server binary and attaches listeners to its stdout/stderr.
   * @param binaryPath The absolute path or executable name of the language server.
   */
  public async startServer(binaryPath: string): Promise<void> {
    try {
      // Create a new Tauri 2.0 command pointing to the language server binary
      const command = Command.create(binaryPath, ['--stdio']);

      // Attach an event listener to capture standard output streams from the server
      command.stdout.on('data', (data: string) => {
        this.handleIncomingData(data);
      });

      // Attach an error listener for server-side anomalies
      command.stderr.on('data', (data: string) => {
        console.error(`[LSP Server Error]: ${data}`);
      });

      // Spawn the child process asynchronously
      this.serverProcess = await command.spawn();
      console.log(`[LSP Client]: Successfully spawned server with PID: ${this.serverProcess.pid}`);
    } catch (error) {
      console.error('[LSP Client]: Failed to initialize language server process:', error);
      throw error;
    }
  }

  /**
   * Sends the mandatory 'initialize' request to the language server.
   * @param rootUri The workspace root URI string.
   */
  public async initialize(rootUri: string): Promise<any> {
    const initParams = {
      processId: null,
      rootUri: rootUri,
      capabilities: {
        textDocument: {
          synchronization: {
            dynamicRegistration: false,
            didSave: true,
          },
          completion: {
            dynamicRegistration: false,
            completionItem: {
              snippetSupport: true,
            },
          },
        },
      },
    };

    return this.sendRequest('initialize', initParams);
  }

  /**
   * Notifies the language server that a document has been opened in the editor.
   * Notifications do not expect a response payload.
   * @param uri Document identifier URI.
   * @param text Initial content of the file.
   */
  public async didOpenTextDocument(uri: string, text: string): Promise<void> {
    const notification: JsonRpcMessage = {
      jsonrpc: '2.0',
      method: 'textDocument/didOpen',
      params: {
        textDocument: {
          uri: uri,
          languageId: 'typescript',
          version: 1,
          text: text,
        },
      },
    };

    await this.sendNotification(notification);
  }

  /**
   * Requests code completion items for a specific cursor position.
   * @param uri Document identifier URI.
   * @param line Zero-based line index.
   * @param character Zero-based character offset.
   */
  public async requestCompletions(uri: string, line: number, character: number): Promise<any> {
    const params = {
      textDocument: { uri },
      position: { line, character },
    };

    return this.sendRequest('textDocument/completion', params);
  }

  /**
   * Sends a JSON-RPC Request (expects a response, tracked via an incrementing ID).
   */
  private sendRequest(method: string, params: unknown): Promise<any> {
    return new Promise((resolve, reject) => {
      const id = this.messageId++;
      const message: JsonRpcMessage = {
        jsonrpc: '2.0',
        id,
        method,
        params,
      };

      // Register the resolver/rejecter in our map to process the response later
      this.responseHandlers.set(id, { resolve, reject });

      this.writeMessage(message);
    });
  }

  /**
   * Sends a JSON-RPC Notification (fire-and-forget, no ID, no response expected).
   */
  private async sendNotification(message: JsonRpcMessage): Promise<void> {
    this.writeMessage(message);
  }

  /**
   * Formats a JSON-RPC message with the mandatory Content-Length header and writes it to the server's stdin.
   */
  private async writeMessage(message: JsonRpcMessage):- void {
    if (!this.serverProcess) {
      throw new Error('[LSP Client]: Cannot write message; server process is not active.');
    }

    const jsonString = JSON.stringify(message);
    // LSP specification mandates Content-Length header followed by double CRLF (\r\n\r\n)
    const payload = `Content-Length: ${Buffer.byteLength(jsonString, 'utf8')}\r\n\r\n${jsonString}`;

    // Write to the child process's standard input stream via Tauri 2.0 shell plugin
    await this.serverProcess.write(payload);
  }

  /**
   * Accumulates incoming raw chunks and parses them according to the LSP Header-Body framing rules.
   */
  private handleIncomingData(chunk: string): void {
    this.buffer += chunk;

    while (true) {
      // Find the separator between the HTTP-style header and the JSON body
      const headerEndIndex = this.buffer.indexOf('\r\n\r\n');
      if (headerEndIndex === -1) {
        // Incomplete headers received; wait for the next chunk
        break;
      }

      const headerPart = this.buffer.substring(0, headerEndIndex);
      const contentLengthMatch = headerPart.match(/Content-Length:\s*(\d+)/i);

      if (!contentLengthMatch) {
        console.error('[LSP Client]: Malformed LSP header received, missing Content-Length.');
        // Flush buffer to prevent infinite loops on unrecoverable stream corruption
        this.buffer = '';
        break;
      }

      const contentLength = parseInt(contentLengthMatch[1], 10);
      const bodyStartIndex = headerEndIndex + 4;
      const totalMessageLength = bodyStartIndex + contentLength;

      if (this.buffer.length < totalMessageLength) {
        // We haven't received the full body yet; wait for more chunks
        break;
      }

      // Extract the exact JSON body payload
      const jsonBody = this.buffer.substring(bodyStartIndex, totalMessageLength);
      // Remove the processed message from our internal buffer
      this.buffer = this.buffer.substring(totalMessageLength);

      try {
        const parsedMessage: JsonRpcMessage = JSON.parse(jsonBody);
        this.dispatchMessage(parsedMessage);
      } catch (e) {
        console.error('[LSP Client]: Failed to parse incoming JSON payload:', e);
      }
    }
  }

  /**
   * Routes incoming JSON-RPC messages either to waiting response handlers or server-initiated notifications.
   */
  private dispatchMessage(message: JsonRpcMessage): void {
    // Check if the message is a response to a previous request
    if (message.id !== undefined && this.responseHandlers.has(message.id)) {
      const handler = this.responseHandlers.get(message.id)!;
      this.responseHandlers.delete(message.id);

      if (message.error) {
        handler.reject(message.error);
      } else {
        handler.resolve(message.result);
      }
      return;
    }

    // Check if the message is a server-initiated request or notification (e.g., diagnostics)
    if (message.method) {
      this.handleServerNotification(message.method, message.params);
    }
  }

  /**
   * Handles inbound notifications pushed directly from the language server.
   */
  private handleServerNotification(method: string, params: unknown): void {
    switch (method) {
      case 'textDocument/publishDiagnostics':
        console.log('[LSP Diagnostics Received]:', params);
        // Hook this up to your UI state manager (e.g., Zustand, Redux) to render red squigglies
        break;
      default:
        console.log(`[LSP Unhandled Notification]: ${method}`, params);
        break;
    }
  }

  /**
   * Gracefully shuts down the LSP session and terminates the child process.
   */
  public async shutdown(): Promise<void> {
    try {
      await this.sendRequest('shutdown', null);
      // Notifications do not have message IDs, send exit notification directly
      await this.sendNotification({ jsonrpc: '2.0', method: 'exit' });
    } catch (e) {
      console.error('[LSP Client]: Error during clean shutdown sequence:', e);
    } finally {
      if (this.serverProcess) {
        this.serverProcess.kill();
        this.serverProcess = null;
        console.log('[LSP Client]: Server process terminated.');
      }
    }
  }
}
