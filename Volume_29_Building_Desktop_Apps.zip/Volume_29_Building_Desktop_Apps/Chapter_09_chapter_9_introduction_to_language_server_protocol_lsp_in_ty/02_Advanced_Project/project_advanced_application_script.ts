/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file lsp-client-manager.ts
 * @description Advanced LSP Client implementation for Tauri 2.0 and TypeScript developer tools.
 * Manages bidirectional JSON-RPC communication, state synchronization, and diagnostic reporting.
 */

import { EventEmitter } from "events";

/**
 * Represents the standard JSON-RPC 2.0 message structure required by the LSP specification.
 */
interface JsonRpcMessage {
  jsonrpc: "2.0";
  id?: number | string;
  method?: string;
  params?: unknown;
  result?: unknown;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}

/**
 * Configuration options for initializing the Language Server Client.
 */
interface LspClientOptions {
  serverCommand: string;
  serverArgs: string[];
  workspaceRoot: string;
}

/**
 * Diagnostic structure returned by the language server.
 */
interface Diagnostic {
  range: {
    start: { line: number; character: number };
    end: { line: number; character: number };
  };
  severity: 1 | 2 | 3 | 4; // 1: Error, 2: Warning, 3: Info, 4: Hint
  code?: string | number;
  source?: string;
  message: string;
}

/**
 * Main LSP Client Manager class handling lifecycle, message dispatching, and event emission.
 */
export class LspClientManager extends EventEmitter {
  private messageId = 1;
  private pendingRequests = new Map<
    number | string,
    { resolve: (value: any) => void; reject: (reason: any) => void }
  >();
  private isInitialized = false;
  private documentVersions = new Map<string, number>();

  constructor(private options: LspClientOptions) {
    super();
  }

  /**
   * Initializes the connection to the language server.
   * In a Tauri environment, this typically bridges to a Rust-spawned child process via IPC.
   */
  public async connect(): Promise<void> {
    console.log(`[LSP Client] Connecting to server: ${this.options.serverCommand}`);
    
    // Simulating IPC connection handshake to the Rust backend process hosting the LSP binary
    // In actual Tauri implementations, you would invoke a Tauri command like:
    // await invoke('spawn_lsp_server', { command: this.options.serverCommand });

    this.setupMessageListeners();
    await this.sendInitializeRequest();
  }

  /**
   * Sends the mandatory 'initialize' request to the language server.
   */
  private async sendInitializeRequest(): Promise<void> {
    const initParams = {
      processId: process.pid,
      rootUri: `file://${this.options.workspaceRoot}`,
      capabilities: {
        textDocument: {
          synchronization: {
            dynamicRegistration: true,
            didSave: true,
          },
          completion: {
            completionItem: {
              snippetSupport: true,
            },
          },
          diagnostic: {},
        },
      },
    };

    const response = await this.sendRequest("initialize", initParams);
    this.isInitialized = true;
    console.log("[LSP Client] Server initialized successfully:", response);

    // Send the required initialized notification after receiving initialize response
    this.sendNotification("initialized", {});
  }

  /**
   * Dispatches a JSON-RPC request and returns a promise that resolves upon receiving the server's response.
   */
  public sendRequest(method: string, params: unknown): Promise<any> {
    return new Promise((resolve, reject) => {
      const id = this.messageId++;
      const message: JsonRpcMessage = {
        jsonrpc: "2.0",
        id,
        method,
        params,
      };

      this.pendingRequests.set(id, { resolve, reject });
      this.writeMessage(message);
    });
  }

  /**
   * Dispatches a JSON-RPC notification (no response expected).
   */
  public sendNotification(method: string, params: unknown): void {
    const message: JsonRpcMessage = {
      jsonrpc: "2.0",
      method,
      params,
    };
    this.writeMessage(message);
  }

  /**
   * Synchronizes document text changes with the language server using incremental or full updates.
   */
  public didOpenTextDocument(uri: string, languageId: string, text: string): void {
    this.documentVersions.set(uri, 1);
    this.sendNotification("textDocument/didOpen", {
      textDocument: {
        uri,
        languageId,
        version: 1,
        text,
      },
    });
  }

  public didChangeTextDocument(uri: string, newText: string): void {
    const version = (this.documentVersions.get(uri) || 0) + 1;
    this.documentVersions.set(uri, version);

    this.sendNotification("textDocument/didChange", {
      textDocument: {
        uri,
        version,
      },
      contentChanges: [
        {
          text: newText,
        },
      ],
    });
  }

  /**
   * Requests code completion suggestions at a specific document cursor position.
   */
  public async requestCompletions(uri: string, line: number, character: number): Promise<any[]> {
    if (!this.isInitialized) throw new Error("LSP Client is not initialized.");

    const response = await this.sendRequest("textDocument/completion", {
      textDocument: { uri },
      position: { line, character },
    });

    return response?.items || response || [];
  }

  /**
   * Low-level method to write serialized JSON-RPC payloads over the transport layer.
   */
  private writeMessage(message: JsonRpcMessage): void {
    const jsonString = JSON.stringify(message);
    const payload = `Content-Length: ${Buffer.byteLength(jsonString, "utf8")}\r\n\r\n${jsonString}`;
    
    // In a Tauri application, this would stream through a Tauri channel or IPC plugin to Rust
    console.debug(`[LSP Outbound] ${jsonString}`);
  }

  /**
   * Listens for inbound messages from the language server backend.
   */
  private setupMessageListeners(): void {
    // Mock ingestion loop for inbound data streams
    // Real applications parse headers (Content-Length) and extract JSON payloads
  }

  /**
   * Routes incoming messages based on whether they are responses, requests, or notifications.
   */
  public handleIncomingMessage(rawMessage: string): void {
    const message: JsonRpcMessage = JSON.parse(rawMessage);

    if (message.id !== undefined && this.pendingRequests.has(message.id)) {
      // Handle request responses
      const { resolve, reject } = this.pendingRequests.get(message.id)!;
      this.pendingRequests.delete(message.id);

      if (message.error) {
        reject(message.error);
      } else {
        resolve(message.result);
      }
    } else if (message.method) {
      // Handle server-to-client notifications (e.g., diagnostics)
      this.handleServerNotification(message.method, message.params);
    }
  }

  /**
   * Processes notifications pushed asynchronously by the language server.
   */
  private handleServerNotification(method: string, params: any): void {
    switch (method) {
      case "textDocument/publishDiagnostics":
        const { uri, diagnostics } = params;
        this.emit("diagnostics", { uri, diagnostics } as { uri: string; diagnostics: Diagnostic[] });
        break;
      default:
        console.log(`[LSP Notification] Unhandled method: ${method}`);
    }
  }
}
