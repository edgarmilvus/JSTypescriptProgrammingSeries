/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { ChildProcess } from 'node:child_process';

export class LspStdioTransport {
  private process: ChildProcess;
  private buffer: Buffer = Buffer.alloc(0);

  constructor(serverProcess: ChildProcess) {
    this.process = serverProcess;
    this.setupListeners();
  }

  private setupListeners(): void {
    if (!this.process.stdout) {
      throw new Error('Server process stdout is not available.');
    }

    this.process.stdout.on('data', (chunk: Buffer) => {
      // Accumulate incoming bytes into our persistent buffer
      this.buffer = Buffer.concat([this.buffer, chunk]);
      this.processBuffer();
    });

    this.process.on('error', (err) => {
      console.error('LSP process error:', err);
    });

    this.process.on('exit', (code, signal) => {
      console.warn(`LSP process exited with code ${code} and signal ${signal}`);
    });
  }

  private processBuffer(): void {
    while (true) {
      // Look for the header/body separator: \r\n\r\n
      const headerSeparatorIndex = this.buffer.indexOf('\r\n\r\n');
      if (headerSeparatorIndex === -1) {
        // Incomplete headers, wait for more data
        break;
      }

      // Extract the header section as a string
      const headerSection = this.buffer.subarray(0, headerSeparatorIndex).toString('utf8');
      const contentLengthMatch = headerSection.match(/Content-Length:\s*(\d+)/i);

      if (!contentLengthMatch) {
        throw new Error(`Invalid LSP headers received: ${headerSection}`);
      }

      const contentLength = parseInt(contentLengthMatch[1], 10);
      const bodyStartIndex = headerSeparatorIndex + 4;
      const totalMessageLength = bodyStartIndex + contentLength;

      // Check if we have received the complete message body yet
      if (this.buffer.length < totalMessageLength) {
        // Complete body not yet arrived; wait for next chunk
        break;
      }

      // Slice out the JSON body
      const bodyBuffer = this.buffer.subarray(bodyStartIndex, totalMessageLength);
      // Advance our buffer past this processed message
      this.buffer = this.buffer.subarray(totalMessageLength);

      try {
        const jsonString = bodyBuffer.toString('utf8');
        const message = JSON.parse(jsonString);
        this.handleMessage(message);
      } catch (err) {
        console.error('Failed to parse JSON-RPC message body:', err);
      }
    }
  }

  private handleMessage(message: object): void {
    // Dispatch parsed message to higher-level LSP client handlers
    console.log('Received LSP Message:', message);
  }

  public send(message: object): void {
    if (!this.process.stdin) {
      throw new Error('Server process stdin is not available.');
    }

    const jsonContent = JSON.stringify(message);
    const contentLength = Buffer.byteLength(jsonContent, 'utf8');
    
    // Construct LSP-compliant payload with Content-Length header
    const formattedMessage = `Content-Length: ${contentLength}\r\n\r\n${jsonContent}`;
    
    this.process.stdin.write(formattedMessage, 'utf8', (err) => {
      if (err) {
        console.error('Failed to write message to language server stdin:', err);
      }
    });
  }
}
