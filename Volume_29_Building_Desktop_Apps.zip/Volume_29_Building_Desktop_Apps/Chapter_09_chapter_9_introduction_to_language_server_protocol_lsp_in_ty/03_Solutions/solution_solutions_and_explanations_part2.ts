/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface BaseMessage {
  jsonrpc: string;
}

export interface NotificationMessage extends BaseMessage {
  method: string;
  params?: unknown;
}

export interface DiagnosticItem {
  range: {
    start: { line: number; character: number };
    end: { line: number; character: number };
  };
  severity?: number;
  message: string;
}

export interface PublishDiagnosticsParams {
  uri: string;
  diagnostics: DiagnosticItem[];
}

export interface PublishDiagnosticsNotification extends NotificationMessage {
  method: 'textDocument/publishDiagnostics';
  params: PublishDiagnosticsParams;
}

export function isPublishDiagnosticsNotification(
  message: NotificationMessage
): message is PublishDiagnosticsNotification {
  if (!message || typeof message !== 'object') {
    return false;
  }

  // Verify the exact method string required for diagnostics notification
  if (message.method !== 'textDocument/publishDiagnostics') {
    return false;
  }

  const params = message.params;
  if (!params || typeof params !== 'object') {
    return false;
  }

  // Type assertion / runtime validation for params shape
  const candidate = params as Record<string, unknown>;
  
  return (
    typeof candidate.uri === 'string' &&
    Array.isArray(candidate.diagnostics) &&
    candidate.diagnostics.every(
      (d: any) =>
        d &&
        typeof d === 'object' &&
        typeof d.message === 'string' &&
        d.range &&
        typeof d.range === 'object' &&
        d.range.start &&
        typeof d.range.start.line === 'number' &&
        typeof d.range.start.character === 'number' &&
        d.range.end &&
        typeof d.range.end.line === 'number' &&
        typeof d.range.end.character === 'number'
    )
  );
}

export function handleIncomingMessage(message: NotificationMessage): void {
  if (isPublishDiagnosticsNotification(message)) {
    // TypeScript safely knows message.params is of type PublishDiagnosticsParams here
    const diagnosticsCount = message.params.diagnostics.length;
    console.log(`Received ${diagnosticsCount} diagnostics for ${message.params.uri}`);
  }
}
