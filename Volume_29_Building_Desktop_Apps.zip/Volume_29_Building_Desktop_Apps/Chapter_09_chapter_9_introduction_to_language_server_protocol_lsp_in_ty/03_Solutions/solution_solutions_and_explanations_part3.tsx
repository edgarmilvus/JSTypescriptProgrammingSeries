/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export enum DiagnosticSeverity {
  Error = 1,
  Warning = 2,
  Information = 3,
  Hint = 4,
}

export interface UIEditorPosition {
  line: number;
  character: number;
}

export interface UIDiagnosticEntry {
  id: string;
  uri: string;
  range: {
    start: UIEditorPosition;
    end: UIEditorPosition;
  };
  severity: DiagnosticSeverity;
  message: string;
  source?: string;
}

export interface DiagnosticsPanelProps {
  diagnostics: UIDiagnosticEntry[];
  onSelectDiagnostic: (diagnostic: UIDiagnosticEntry) => void;
  isLoading?: boolean;
}

export const DiagnosticsPanel: React.FC<DiagnosticsPanelProps> = ({
  diagnostics,
  onSelectDiagnostic,
  isLoading = false,
}) => {
  const getSeverityBadgeClass = (severity: DiagnosticSeverity): string => {
    switch (severity) {
      case DiagnosticSeverity.Error:
        return 'badge-error';
      case DiagnosticSeverity.Warning:
        return 'badge-warning';
      case DiagnosticSeverity.Information:
        return 'badge-info';
      case DiagnosticSeverity.Hint:
        return 'badge-hint';
      default:
        return 'badge-default';
    }
  };

  if (isLoading) {
    return <div className="lsp-diagnostics-panel loading">Analyzing document...</div>;
  }

  if (diagnostics.length === 0) {
    return (
      <div className="lsp-diagnostics-panel empty">
        <p>No diagnostics found - all clear!</p>
      </div>
    );
  }

  return (
    <div className="lsp-diagnostics-panel">
      <h3>Diagnostics ({diagnostics.length})</h3>
      <ul className="diagnostic-list">
        {diagnostics.map((diag) => (
          <li
            key={diag.id}
            className="diagnostic-item"
            onClick={() => onSelectDiagnostic(diag)}
            role="button"
            tabIndex={0}
          >
            <span className={`badge ${getSeverityBadgeClass(diag.severity)}`}>
              {DiagnosticSeverity[diag.severity]}
            </span>
            <span className="diagnostic-location">
              [{diag.range.start.line + 1}:{diag.range.start.character + 1}]
            </span>
            <span className="diagnostic-message">{diag.message}</span>
            {diag.source && <span className="diagnostic-source">({diag.source})</span>}
          </li>
        ))}
      </ul>
    </div>
  );
};
