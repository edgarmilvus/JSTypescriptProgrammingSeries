/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface TextDocumentItem {
  uri: string;
  languageId: string;
  version: number;
  text: string;
}

export interface Range {
  start: { line: number; character: number };
  end: { line: number; character: number };
}

export interface TextDocumentContentChangeEvent {
  range?: Range;
  rangeLength?: number;
  text: string;
}

export class DocumentSyncManager {
  private openDocuments: Map<string, TextDocumentItem> = new Map();

  public openDocument(uri: string, languageId: string, initialText: string): TextDocumentItem {
    const document: TextDocumentItem = {
      uri,
      languageId,
      version: 1,
      text: initialText,
    };
    this.openDocuments.set(uri, document);
    return document;
  }

  public applyChange(uri: string, changes: TextDocumentContentChangeEvent[]): TextDocumentItem {
    const document = this.openDocuments.get(uri);
    if (!document) {
      throw new Error(`Cannot apply changes to unopened document: ${uri}`);
    }

    let currentText = document.text;

    for (const change of changes) {
      if (!change.range) {
        // Full text synchronization payload
        currentText = change.text;
      } else {
        // Incremental text synchronization
        currentText = this.applyIncrementalChange(currentText, change.range, change.text);
      }
    }

    // Increment document version to maintain sequential ordering for the LSP backend
    const updatedDocument: TextDocumentItem = {
      ...document,
      version: document.version + 1,
      text: currentText,
    };

    this.openDocuments.set(uri, updatedDocument);
    return updatedDocument;
  }

  private applyIncrementalChange(text: string, range: Range, newText: string): string {
    const lines = text.split(/\r?\n/);
    
    const startIndex = this.positionToOffset(lines, range.start);
    const endIndex = this.positionToOffset(lines, range.end);

    if (startIndex === -1 || endIndex === -1) {
      throw new Error('Incremental change range is out of document bounds.');
    }

    return text.substring(0, startIndex) + newText + text.substring(endIndex);
  }

  private positionToOffset(lines: string[], position: { line: number; character: number }): number {
    if (position.line < 0 || position.line >= lines.length) {
      return -1;
    }

    let offset = 0;
    for (let i = 0; i < position.line; i++) {
      // Add line length plus newline character length (assuming 1 for simplicity)
      offset += lines[i].length + 1;
    }

    if (position.character > lines[position.line].length) {
      return -1;
    }

    return offset + position.character;
  }

  public getDocument(uri: string): TextDocumentItem | undefined {
    return this.openDocuments.get(uri);
  }
}
