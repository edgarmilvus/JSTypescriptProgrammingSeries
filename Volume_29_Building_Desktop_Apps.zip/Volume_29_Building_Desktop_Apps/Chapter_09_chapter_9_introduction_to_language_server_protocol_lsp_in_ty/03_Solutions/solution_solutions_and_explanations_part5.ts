/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface CompletionParams {
  uri: string;
  position: { line: number; character: number };
}

export interface CompletionItem {
  label: string;
  kind?: number;
  detail?: string;
  documentation?: string | { kind: string; value: string };
  insertText?: string;
}

export interface CompletionList {
  isIncomplete: boolean;
  items: CompletionItem[];
}

export interface LspConnection {
  sendRequest(method: string, params: unknown, signal?: AbortSignal): Promise<unknown>;
}

export class CompletionManager {
  private activeControllers: Map<string, AbortController> = new Map();
  private connection: LspConnection;

  constructor(connection: LspConnection) {
    this.connection = connection;
  }

  public async fetchCompletions(params: CompletionParams): Promise<CompletionItem[]> {
    const { uri } = params;

    // Abort any pending completion request for this specific URI
    if (this.activeControllers.has(uri)) {
      const existingController = this.activeControllers.get(uri)!;
      existingController.abort();
      this.activeControllers.delete(uri);
    }

    // Create a new AbortController for the current request
    const controller = new AbortController();
    this.activeControllers.set(uri, controller);

    try {
      const response = await this.connection.sendRequest(
        'textDocument/completion',
        params,
        controller.signal
      );

      // Clean up controller reference upon successful completion
      this.activeControllers.delete(uri);

      if (!response) {
        return [];
      }

      // Handle responses conforming to CompletionItem[] or CompletionList
      if (Array.isArray(response)) {
        return response as CompletionItem[];
      }

      const listResponse = response as CompletionList;
      if (listResponse && Array.isArray(listResponse.items)) {
        return listResponse.items;
      }

      return [];
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log(`Completion request for ${uri} was safely cancelled.`);
        return [];
      }
      console.error('Failed to fetch code completions:', error);
      throw error;
    } finally {
      // Ensure controller is cleaned up if map still holds it
      if (this.activeControllers.get(uri) === controller) {
        this.activeControllers.delete(uri);
      }
    }
  }
}
