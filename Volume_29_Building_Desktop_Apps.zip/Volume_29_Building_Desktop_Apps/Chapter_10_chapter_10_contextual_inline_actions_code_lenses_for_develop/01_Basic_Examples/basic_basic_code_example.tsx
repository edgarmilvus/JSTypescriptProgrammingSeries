/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';

/**
 * Represents a single Code Lens item rendered above a line of code.
 */
interface CodeLensItem {
  id: string;
  line: number;
  title: string;
  command: string;
  status: 'idle' | 'running' | 'success' | 'error';
}

/**
 * Payload structure returned by the Rust AST parser backend.
 */
interface AstAnalysisResult {
  lenses: CodeLensItem[];
  fileHash: string;
}

/**
 * SaaS Code Lens Workspace Component.
 * Acts as the primary view controller for inline code annotations inside the Tauri WebView.
 */
export const CodeLensWorkspace: React.FC = () => {
  // State tracking active code lenses for the current active file buffer
  const [lenses, setLenses] = useState<CodeLensItem[]>([]);
  // State tracking the active file path loaded in the desktop editor
  const [activeFile, setActiveFile] = useState<string>('src/core/auth.rs');
  // Loading state for asynchronous AST parsing operations
  const [isParsing, setIsParsing] = useState<boolean>(false);

  /**
   * Triggers the Rust backend via Tauri IPC to parse the current file's AST 
   * and return contextual Code Lens injection points.
   */
  const fetchCodeLenses = useCallback(async (filePath: string) => {
    setIsParsing(true);
    try {
      // Invoke the Rust command registered in Tauri's builder lifecycle
      const result = await invoke<AstAnalysisResult>('analyze_source_ast', { 
        path: filePath,
        includeMetrics: true 
      });
      
      setLenses(result.lenses);
    } catch (error) {
      console.error('Failed to parse AST via Rust core:', error);
    } finally {
      setIsParsing(false);
    }
  }, []);

  // Fetch code lenses on initial component mount and when activeFile changes
  useEffect(() => {
    fetchCodeLenses(activeFile);
  }, [activeFile, fetchCodeLenses]);

  /**
   * Executes a specific inline action associated with a Code Lens.
   * Communicates asynchronously with the Tauri backend to run refactoring or debugging tasks.
   */
  const handleExecuteAction = async (lensId: string, command: string) => {
    // Optimistically update UI state to running
    setLenses(prevLenses => 
      prevLenses.map(lens => 
        lens.id === lensId ? { ...lens, status: 'running' } : lens
      )
    );

    try {
      // Execute the heavy task in Rust to bypass V8/Node.js single-threaded constraints
      const success = await invoke<boolean>('execute_inline_task', { 
        lensId, 
        command 
      });

      setLenses(prevLenses => 
        prevLenses.map(lens => 
          lens.id === lensId ? { ...lens, status: success ? 'success' : 'error' } : lens
        )
      );
    } catch (err) {
      console.error(`Execution failed for lens ${lensId}:`, err);
      setLenses(prevLenses => 
        prevLenses.map(lens => 
          lens.id === lensId ? { ...lens, status: 'error' } : lens
        )
      );
    }
  };

  return (
    <div className="tauri-editor-container" style={{ padding: '20px', fontFamily: 'monospace' }}>
      <header style={{ marginBottom: '16px' }}>
        <h3>SaaS Developer Workspace - Tauri 2.0</h3>
        <p>Active File: <strong>{activeFile}</strong></p>
        {isParsing && <span style={{ color: '#007acc' }}>Analyzing AST in Rust core...</span>}
      </header>

      <div className="editor-mock-viewport" style={{ border: '1px solid #333', padding: '10px', background: '#1e1e1e', color: '#d4d4d4' }}>
        {lenses.map((lens) => (
          <div key={lens.id} className="code-lens-wrapper" style={{ margin: '8px 0', borderLeft: '2px solid #007acc', paddingLeft: '8px' }}>
            {/* Render the Code Lens widget above the target line */}
            <div className="code-lens-widget" style={{ fontSize: '12px', color: '#858585', marginBottom: '4px' }}>
              <span>⚡ Line {lens.line}: </span>
              <button 
                onClick={() => handleExecuteAction(lens.id, lens.command)}
                disabled={lens.status === 'running'}
                style={{ background: '#333', color: '#fff', border: 'none', padding: '2px 6px', cursor: 'pointer', marginLeft: '6px' }}
              >
                {lens.status === 'running' ? 'Running...' : lens.title}
              </button>
              {lens.status === 'success' && <span style={{ color: '#4ec9b0', marginLeft: '6px' }}>✓ Completed</span>}
              {lens.status === 'error' && <span style={{ color: '#f44747', marginLeft: '6px' }}>✕ Failed</span>}
            </div>
            
            {/* Mock code line representation */}
            <div style={{ fontFamily: 'monospace', color: '#9cdcfe' }}>
              pub async fn authenticate_user(token: &str) -&gt; Result&lt;User, AuthError&gt; &#123;
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CodeLensWorkspace;
