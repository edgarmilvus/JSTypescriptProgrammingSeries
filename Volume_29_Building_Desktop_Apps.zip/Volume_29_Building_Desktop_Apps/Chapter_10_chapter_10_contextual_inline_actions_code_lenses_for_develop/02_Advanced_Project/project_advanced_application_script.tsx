/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

/**
 * Represents a single Code Lens action rendered above a line of code.
 */
export interface CodeLensItem {
  id: string;
  line: number;
  character: number;
  title: string;
  command: string;
  arguments: Record<string, unknown>;
}

/**
 * Payload structure received from the Rust core when document AST changes.
 */
interface AstUpdatePayload {
  filePath: string;
  codeLenses: CodeLensItem[];
}

/**
 * SaaS Developer Workspace Component managing inline Code Lenses and Contextual Actions.
 */
export function CodeLensWorkspace({ filePath, fileContent }: { filePath: string; fileContent: string }) {
  const [codeLenses, setCodeLenses] = useState<CodeLensItem[]>([]);
  const [activeExecutingId, setActiveExecutingId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Reference to track the latest content version to prevent race conditions during rapid typing.
  const contentRef = useRef(fileContent);
  contentRef.current = fileContent;

  /**
   * Requests an updated set of Code Lenses from the Rust AST parser backend.
   */
  const fetchCodeLenses = useCallback(async () => {
    try {
      const lenses = await invoke<CodeLensItem[]>('plugin:code-lens|get_lenses', {
        filePath,
        content: contentRef.current,
      });
      setCodeLenses(lenses);
      setErrorMessage(null);
    } catch (err) {
      console.error('Failed to resolve Code Lenses from Rust core:', err);
      setErrorMessage(String(err));
    }
  }, [filePath]);

  // Synchronize AST and Code Lenses on component mount and when file path changes.
  useEffect(() => {
    fetchCodeLenses();

    // Listen to background file watcher events emitted from Rust.
    const unlistenPromise = listen<AstUpdatePayload>('ast-updated', (event) => {
      if (event.payload.filePath === filePath) {
        setCodeLenses(event.payload.codeLenses);
      }
    });

    return () => {
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, [filePath, fetchCodeLenses]);

  /**
   * Executes the contextual inline action associated with a specific Code Lens.
   * Bridges the UI action directly to the Rust backend command executor.
   */
  const handleExecuteLens = async (lens: CodeLensItem) => {
    setActiveExecutingId(lens.id);
    setErrorMessage(null);

    try {
      // Invoke the generic Tauri command handler routing to our Rust refactoring engine.
      const result = await invoke<{ success: boolean; modifiedContent?: string; error?: string }>(
        'execute_contextual_action',
        {
          command: lens.command,
          filePath,
          args: lens.arguments,
        }
      );

      if (!result.success) {
        throw new Error(result.error || 'Unknown execution failure in Rust core.');
      }

      // Refresh lenses after successful mutation
      await fetchCodeLenses();
    } catch (err) {
      console.error(`Execution failed for Code Lens [${lens.id}]:`, err);
      setErrorMessage(err instanceof Error ? err.message : String(err));
    } finally {
      setActiveExecutingId(null);
    }
  };

  return (
    <div className="relative flex flex-col h-full w-full bg-slate-950 text-slate-100 font-mono text-sm">
      {/* Error Banner if IPC or AST parsing fails */}
      {errorMessage && (
        <div className="bg-red-900/50 border-b border-red-700 p-2 text-xs text-red-200 flex justify-between items-center">
          <span><strong>Code Lens Error:</strong> {errorMessage}</span>
          <button 
            onClick={() => setErrorMessage(null)}
            className="px-2 py-0.5 bg-red-800 hover:bg-red-700 rounded text-xs"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Editor Simulation Area */}
      <div className="flex-1 overflow-auto p-4 relative">
        {fileContent.split('\n').map((lineText, lineIdx) => {
          const currentLineNumber = lineIdx + 1;
          const matchingLens = codeLenses.find((lens) => lens.line === currentLineNumber);
          const isExecuting = matchingLens ? activeExecutingId === matchingLens.id : false;

          return (
            <div key={lineIdx} className="group relative flex flex-col py-0.5">
              {/* Render Code Lens Widget Inline Above Target Line */}
              {matchingLens && (
                <div className="flex items-center space-x-2 my-1 text-xs bg-slate-900 border border-slate-800 rounded px-2 py-1 shadow-sm w-max">
                  <span className="text-cyan-400 font-semibold">⚡ Code Lens</span>
                  <button
                    disabled={isExecuting}
                    onClick={() => handleExecuteLens(matchingLens)}
                    className="text-slate-300 hover:text-white hover:underline disabled:opacity-50 flex items-center space-x-1"
                  >
                    <span>{isExecuting ? 'Running...' : matchingLens.title}</span>
                  </button>
                  <span className="text-slate-600 text-[10px]">({matchingLens.command})</span>
                </div>
              )}

              {/* Source Code Line */}
              <div className="flex">
                <span className="w-12 text-right pr-4 text-slate-600 select-none">
                  {currentLineNumber}
                </span>
                <span className="flex-1 whitespace-pre">{lineText}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
