/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';

// Define the interface matching the Rust CodeLensTarget struct
export interface CodeLensTarget {
  line: number;
  character: number;
  label: string;
  actionId: string;
}

/**
 * Invokes the Rust Tauri command to analyze source code and return Code Lens insertion coordinates.
 * @param sourceCode The raw text content of the active editor buffer.
 * @returns A promise resolving to an array of CodeLensTarget objects.
 */
export async function fetchCodeLensTargets(sourceCode: string): Promise<CodeLensTarget[]> {
  try {
    // Invoke the Rust backend command "detect_code_lens_targets" with the source payload
    const targets = await invoke<CodeLensTarget[]>('detect_code_lens_targets', {
      sourceCode,
    });
    return targets;
  } catch (error) {
    console.error('Failed to fetch Code Lens targets from Rust backend:', error);
    throw new Error(`AST Parsing Error: ${error instanceof Error ? error.message : String(error)}`);
  }
}
