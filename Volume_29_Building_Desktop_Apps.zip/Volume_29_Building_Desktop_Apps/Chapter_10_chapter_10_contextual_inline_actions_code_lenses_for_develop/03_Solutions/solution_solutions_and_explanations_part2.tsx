/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useCallback } from 'react';
import { CodeLensTarget } from './types';

export interface InlineActionOverlayProps {
  targets: CodeLensTarget[];
  lineHeight: number;
  charWidth: number;
  scrollTop: number;
  scrollLeft: number;
  onExecuteAction: (actionId: string, target: CodeLensTarget) => void;
}

export const InlineActionOverlay: React.FC<InlineActionOverlayProps> = ({
  targets,
  lineHeight,
  charWidth,
  scrollTop,
  scrollLeft,
  onExecuteAction,
}) => {
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle keyboard navigation across action chips
  const handleKeyDown = useCallback((e: React.KeyboardEvent, target: CodeLensTarget, index: number) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault();
      setFocusedIndex((prev) => (prev + 1) % targets.length);
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault();
      setFocusedIndex((prev) => (prev - 1 + targets.length) % targets.length);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onExecuteAction(target.actionId, target);
    } else if (e.key === 'Escape') {
      setFocusedIndex(-1);
    }
  }, [targets, onExecuteAction]);

  return (
    <div 
      ref={containerRef}
      className="code-lens-overlay-container" 
      role="toolbar"
      aria-label="Code Lens Inline Actions"
      style={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        right: 0,
        bottom: 0,
        pointerEvents: 'none',
        overflow: 'hidden' 
      }}
    >
      {targets.map((target, index) => {
        // Calculate absolute top and left positions based on editor metrics and scroll offsets
        const top = target.line * lineHeight - scrollTop;
        const left = target.character * charWidth - scrollLeft;

        return (
          <div
            key={`${target.actionId}-${target.line}-${target.character}`}
            style={{
              position: 'absolute',
              top: `${top}px`,
              left: `${left}px`,
              pointerEvents: 'auto',
              transform: 'translateY(-100%)', // Position slightly above the target line
            }}
          >
            <button
              tabIndex={focusedIndex === index ? 0 : -1}
              onClick={() => onExecuteAction(target.actionId, target)}
              onKeyDown={(e) => handleKeyDown(e, target, index)}
              className="code-lens-chip"
              style={{
                background: '#1e1e1e',
                color: '#9cdcfe',
                border: '1px solid #3c3c3c',
                borderRadius: '3px',
                padding: '2px 6px',
                fontSize: '11px',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              <span>{target.label}</span>
            </button>
          </div>
        );
      })}
    </div>
  );
};
