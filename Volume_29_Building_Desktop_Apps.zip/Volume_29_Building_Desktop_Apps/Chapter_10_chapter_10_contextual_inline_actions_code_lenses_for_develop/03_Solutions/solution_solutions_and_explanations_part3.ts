/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { listen, UnlistenFn } from '@tauri-apps/api/event';
import { useState, useEffect } from 'react';

export interface RefactorProgressPayload {
  taskId: string;
  progressPercentage: number;
  statusMessage: string;
}

/**
 * Custom React hook to manage asynchronous refactoring tasks via Tauri events.
 */
export function useRefactorProgress(taskId: string | null) {
  const [progress, setProgress] = useState<number>(0);
  const [status, setStatus] = useState<string>('Idle');
  const [isComplete, setIsComplete] = useState<boolean>(false);

  useEffect(() => {
    if (!taskId) {
      setProgress(0);
      setStatus('Idle');
      setIsComplete(false);
      return;
    }

    let unlisten: UnlistenFn | undefined;
    let isMounted = true;

    const setupListener = async () => {
      // Listen to the backend event stream "refactor-progress"
      unlisten = await listen<RefactorProgressPayload>('refactor-progress', (event) => {
        if (!isMounted) return;
        
        const payload = event.payload;
        // Filter events matching the current active task ID
        if (payload.taskId === taskId) {
          setProgress(payload.progressPercentage);
          setStatus(payload.statusMessage);
          
          if (payload.progressPercentage >= 100) {
            setIsComplete(true);
          }
        }
      });
    };

    setupListener();

    return () => {
      isMounted = false;
      if (unlisten) {
        unlisten();
      }
    };
  }, [taskId]);

  return { progress, status, isComplete };
}
