/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';

export type WorkerAgentType = 'test-generator' | 'doc-generator' | 'refactor-agent';

export interface WorkerTaskRequest {
  agentType: WorkerAgentType;
  sourceSnippet: string;
  contextPath: string;
}

export interface WorkerTaskResponse {
  taskId: string;
  agentType: WorkerAgentType;
  resultOutput: string;
  executionTimeMs: number;
}

/**
 * Dispatches a batch of tasks to the Rust worker pool via Tauri commands.
 * Handles concurrent resolutions and returns an aggregated map of results.
 */
export async function dispatchBatchWorkerTasks(
  requests: WorkerTaskRequest[]
): Promise<Map<string, WorkerTaskResponse>> {
  try {
    // Map each request to an asynchronous Tauri command invocation
    const taskPromises = requests.map(async (request, index) => {
      const response = await invoke<WorkerTaskResponse>('dispatch_worker_task', {
        request,
      });
      return response;
    });

    // Execute all worker tasks concurrently without blocking the main UI thread
    const results = await Promise.allSettled(taskPromises);
    
    const resultMap = new Map<string, WorkerTaskResponse>();

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        resultMap.set(result.value.taskId, result.value);
      } else {
        console.error(`Worker task at index ${index} failed:`, result.reason);
        // Fallback placeholder for failed tasks to maintain batch integrity
        const failedId = `failed-task-${index}`;
        resultMap.set(failedId, {
          taskId: failedId,
          agentType: requests[index].agentType,
          resultOutput: `Error: ${result.reason}`,
          executionTimeMs: 0,
        });
      }
    });

    return resultMap;
  } catch (error) {
    console.error('Batch worker dispatch fatal error:', error);
    throw new Error(`Worker pool execution failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
