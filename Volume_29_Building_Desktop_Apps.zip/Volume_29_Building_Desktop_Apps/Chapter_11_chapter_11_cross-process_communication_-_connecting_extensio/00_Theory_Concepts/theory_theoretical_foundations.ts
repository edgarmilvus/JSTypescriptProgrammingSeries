/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica", fontsize=12];
    
    subgraph cluster_tauri {
        label = "Tauri Application Boundary";
        style = dashed;
        color = "#555555";
        
        Webview [label="Webview Process\n(TypeScript / UI)", fillcolor="#e1f5fe", style="filled,rounded"];
        Core [label="Core Process\n(Rust Backend)", fillcolor="#e8f5e9", style="filled,rounded"];
        
        Webview -> Core [label="Tauri IPC (Invoke/Events)", dir=both];
    }
    
    Daemon [label="Local System Daemon\n(Background Process / Sidecar)", fillcolor="#fff3e0", style="filled,rounded"];
    
    Core -> Daemon [label="IPC: Named Pipes / Unix Sockets / WebSockets", dir=both];
}
