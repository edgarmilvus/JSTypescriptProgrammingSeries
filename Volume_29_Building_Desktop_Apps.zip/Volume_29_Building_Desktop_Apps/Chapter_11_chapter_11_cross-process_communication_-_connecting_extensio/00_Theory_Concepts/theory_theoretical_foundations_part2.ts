/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

digraph IPC_Mechanisms {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica", fontsize=12];

    RustCore [label="Rust Core Process", fillcolor="#e8f5e9", style="filled,rounded"];

    subgraph cluster_transports {
        label = "Local IPC Transport Layers";
        style = dotted;
        
        NamedPipes [label="Named Pipes\n(Windows IPC)", fillcolor="#ede7f6", style="filled,rounded"];
        UnixSockets [label="Unix Domain Sockets\n(POSIX / Linux / macOS)", fillcolor="#ede7f6", style="filled,rounded"];
        WebSockets [label="WebSockets / TCP\n(Cross-Platform Localhost)", fillcolor="#ede7f6", style="filled,rounded"];
    }

    Daemon [label="Local Daemon Process", fillcolor="#fff3e0", style="filled,rounded"];

    RustCore -> NamedPipes [dir=both];
    RustCore -> UnixSockets [dir=both];
    RustCore -> WebSockets [dir=both];

    NamedPipes -> Daemon [dir=both];
    UnixSockets -> Daemon [dir=both];
    WebSockets -> Daemon [dir=both];
}
