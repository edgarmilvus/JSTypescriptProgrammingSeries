/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

digraph RequestLifecycle {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica", fontsize=12];

    UI [label="1. TypeScript Frontend\n(User clicks 'Run Vector Search')", fillcolor="#e1f5fe", style="filled,rounded"];
    TauriIPC [label="2. Tauri IPC Bridge\n(invoke('send_to_daemon'))", fillcolor="#fff9c4", style="filled,rounded"];
    RustCore [label="3. Rust Core Backend\n(Serde validation & routing)", fillcolor="#e8f5e9", style="filled,rounded"];
    Socket [label="4. Unix Socket / Named Pipe\n(Kernel-mediated transport)", fillcolor="#ede7f6", style="filled,rounded"];
    Daemon [label="5. Local Daemon\n(Executes model inference / DB query)", fillcolor="#fff3e0", style="filled,rounded"];

    UI -> TauriIPC [label="Async Promise"];
    TauriIPC -> RustCore [label="Serialized JSON / Binary"];
    RustCore -> Socket [label="Byte Stream Write"];
    Socket -> Daemon [label="Stream Read & Parse"];
    
    Daemon -> Socket [label="Response Byte Stream", style=dashed];
    Socket -> RustCore [label="Read Response", style=dashed];
    RustCore -> TauriIPC [label="Emit Event / Resolve Promise", style=dashed];
    TauriIPC -> UI [label="Update React State", style=dashed];
}
