/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Represents the incoming configuration payload from the local daemon.
 */
interface DaemonHandshakeResponse {
    status: 'success' | 'error';
    daemonVersion: string;
    activeWorkspaceId: string;
    timestamp: number;
}

/**
 * Represents the raw outbound command payload sent to the Rust backend.
 */
interface HandshakePayload {
    clientToken: string;
    extensionId: string;
}

/**
 * Establishes and manages the lifecycle of the local daemon connection bridge.
 */
class DaemonBridgeService {
    private isConnected: boolean = false;
    private unlistenEvent: UnlistenFn | null = null;

    /**
     * Initializes the connection to the local daemon by invoking the Tauri command bridge
     * and setting up real-time event listeners for asynchronous daemon broadcasts.
     * 
     * @param clientToken - The API token provisioned for the current SaaS workspace session.
     * @param extensionId - The unique identifier of the active developer tool extension.
     * @returns A promise resolving to the initial handshake response from the daemon.
     */
    public async initializeDaemonConnection(
        clientToken: string,
        extensionId: string
    ): Promise<DaemonHandshakeResponse> {
        // Construct the payload matching the Rust backend's expected Serde struct layout
        const payload: HandshakePayload = {
            clientToken,
            extensionId,
        };

        try {
            // Type Narrowing and type assertion via Tauri's generic invoke wrapper
            // This safely crosses the boundary from TypeScript into the Rust core process.
            const rawResponse = await invoke<DaemonHandshakeResponse>('connect_local_daemon', {
                payload,
            });

            // Perform runtime validation to ensure the response structurally matches our interface
            if (this.isValidHandshake(rawResponse)) {
                this.isConnected = true;
                console.info(`[DaemonBridge]: Successfully connected to local daemon v${rawResponse.daemonVersion}`);
                
                // Set up persistent asynchronous event listening for daemon-pushed telemetry
                await this.registerDaemonEventListeners();
                
                return rawResponse;
            } else {
                throw new Error('Received malformed handshake structure from local daemon process.');
            }
        } catch (error: unknown) {
            this.isConnected = false;
            // Detailed error boundary handling for cross-process communication failures
            if (error instanceof Error) {
                console.error(`[DaemonBridge]: Failed to establish connection - ${error.message}`);
                throw new Error(`Daemon Connection Error: ${error.message}`);
            } else {
                console.error('[DaemonBridge]: Unknown non-error rejection encountered during IPC invocation.');
                throw new Error('Daemon Connection Error: Unknown system failure.');
            }
        }
    }

    /**
     * Runtime type guard checking if an unknown object conforms to the DaemonHandshakeResponse interface.
     * Utilizes TypeScript type narrowing to eliminate runtime instability.
     */
    private isValidHandshake(response: unknown): response is DaemonHandshakeResponse {
        return (
            typeof response === 'object' &&
            response !== null &&
            'status' in response &&
            'daemonVersion' in response &&
            'activeWorkspaceId' in response &&
            'timestamp' in response &&
            ((response as DaemonHandshakeResponse).status === 'success' ||
             (response as DaemonHandshakeResponse).status === 'error')
        );
    }

    /**
     * Registers an event listener to capture background broadcast events pushed from the Rust daemon.
     */
    private async registerDaemonEventListeners(): Promise<void> {
        // Clean up any existing listeners to prevent memory leaks during hot-reloads
        if (this.unlistenEvent) {
            this.unlistenEvent();
        }

        // Listen for the custom Tauri event emitted by the Rust background thread reading the socket
        this.unlistenEvent = await listen<string>('daemon-telemetry-broadcast', (event) => {
            try {
                const parsedTelemetry = JSON.parse(event.payload);
                console.debug('[DaemonBridge]: Received telemetry push:', parsedTelemetry);
            } catch (err) {
                console.error('[DaemonBridge]: Failed to parse incoming telemetry JSON string:', err);
            }
        });
    }

    /**
     * Gracefully tears down the connection bridge and unregisters active listeners.
     */
    public async disconnect(): Promise<void> {
        if (this.unlistenEvent) {
            this.unlistenEvent();
            this.unlistenEvent = null;
        }
        
        try {
            await invoke('disconnect_local_daemon');
            this.isConnected = false;
            console.info('[DaemonBridge]: Successfully disconnected from local daemon.');
        } catch (error) {
            console.error('[DaemonBridge]: Error occurred while tearing down daemon connection:', error);
        }
    }
}

// Export a singleton instance for consumption across SaaS extension views
export const daemonBridge = new DaemonBridgeService();
