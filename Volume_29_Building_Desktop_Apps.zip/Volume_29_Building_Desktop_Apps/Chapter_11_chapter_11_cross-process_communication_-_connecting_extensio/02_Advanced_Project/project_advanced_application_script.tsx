/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file daemon-bridge.ts
 * @description Production-grade TypeScript bridge for connecting a Tauri 2.0 Next.js 
 * frontend to a local system daemon via secure WebSocket/IPC channels.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Represents the operational state of the local system daemon connection.
 */
export type DaemonConnectionState = 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'DEGRADED' | 'ERROR';

/**
 * Standardized envelope for cross-process communication payloads.
 * @template T The shape of the specific payload data.
 */
export interface DaemonMessage<T = unknown> {
  id: string;
  type: 'INFERENCE_REQUEST' | 'INFERENCE_RESPONSE' | 'DEPENDENCY_SCAN' | 'SYSTEM_METRICS' | 'ERROR';
  payload: T;
  timestamp: number;
}

/**
 * Payload structure for tracking Machine Learning Inference Latency and status.
 */
export interface InferencePayload {
  modelId: string;
  prompt: string;
  tokensGenerated: number;
  inferenceLatencyMs: number;
  resultText?: string;
}

/**
 * Payload structure for local package manager Dependency Resolution tasks.
 */
export interface DependencyResolutionPayload {
  projectName: string;
  resolvedPackagesCount: number;
  lockfileVersion: string;
  vulnerabilitiesFound: number;
}

/**
 * Configuration options for the DaemonBridge client.
 */
export interface DaemonBridgeConfig {
  daemonPort: number;
  autoReconnect: boolean;
  maxReconnectAttempts: number;
  heartbeatIntervalMs: number;
}

/**
 * Manages the lifecycle and message multiplexing between the Tauri UI and the local daemon.
 */
export class DaemonBridge {
  private state: DaemonConnectionState = 'DISCONNECTED';
  private reconnectAttempts = 0;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private responseListeners: Map<string, (msg: DaemonMessage) => void> = new Map();
  private unlistenEvent: UnlistenFn | null = null;

  constructor(private config: DaemonBridgeConfig) {}

  /**
   * Initializes the bridge, sets up Tauri event listeners, and establishes the daemon connection.
   */
  public async initialize(): Promise<void> {
    this.updateState('CONNECTING');

    try {
      // 1. Register Tauri event listener for unsolicited daemon push events
      this.unlistenEvent = await listen<DaemonMessage>('daemon-push-event', (event) => {
        this.handleIncomingDaemonMessage(event.payload);
      });

      // 2. Invoke Rust backend to spin up or verify the local daemon socket connection
      const connected = await invoke<boolean>('connect_to_local_daemon', { 
        port: this.config.daemonPort 
      });

      if (!connected) {
        throw new Error('Rust backend failed to establish socket connection with local daemon.');
      }

      this.updateState('CONNECTED');
      this.startHeartbeat();
    } catch (error) {
      console.error('[DaemonBridge] Initialization failed:', error);
      this.updateState('ERROR');
      this.handleReconnect();
    }
  }

  /**
   * Sends an asynchronous command to the local daemon and awaits a correlated response.
   * Leverages TypeScript Type Inference to return the precisely typed response payload.
   * 
   * @template TRequest The request payload type.
   * @template TResponse The expected response payload type.
   */
  public async sendCommand<TRequest, TResponse>(
    type: DaemonMessage['type'],
    payload: TRequest
  ): Promise<DaemonMessage<TResponse>> {
    if (this.state !== 'CONNECTED') {
      throw new Error(`Cannot send command. Daemon state is: ${this.state}`);
    }

    const messageId = crypto.randomUUID();
    const message: DaemonMessage<TRequest> = {
      id: messageId,
      type,
      payload,
      timestamp: Date.now(),
    };

    return new Promise((resolve, reject) => {
      // Register a one-time callback keyed by the unique message ID for response multiplexing
      const timeout = setTimeout(() => {
        this.responseListeners.delete(messageId);
        reject(new Error(`Daemon command timed out for message ID: ${messageId}`));
      }, 15000);

      this.responseListeners.set(messageId, (response) => {
        clearTimeout(timeout);
        if (response.type === 'ERROR') {
          reject(new Error(JSON.stringify(response.payload)));
        } else {
          resolve(response as DaemonMessage<TResponse>);
        }
      });

      // Dispatch through Tauri core to the Rust IPC layer
      invoke('dispatch_daemon_message', { rawMessage: JSON.stringify(message) }).catch((err) => {
        this.responseListeners.delete(messageId);
        clearTimeout(timeout);
        reject(err);
      });
    });
  }

  /**
   * Dispatches an ML inference task and measures Inference Latency via the local daemon.
   */
  public async runInference(modelId: string, prompt: string): Promise<InferencePayload> {
    const response = await this.sendCommand<
      { modelId: string; prompt: string }, 
      InferencePayload
    >('INFERENCE_REQUEST', { modelId, prompt });

    return response.payload;
  }

  /**
   * Triggers a local Dependency Resolution audit via the daemon workspace manager.
   */
  public async resolveDependencies(projectName: string): Promise<DependencyResolutionPayload> {
    const response = await this.sendCommand<
      { projectName: string }, 
      DependencyResolutionPayload
    >('DEPENDENCY_SCAN', { projectName });

    return response.payload;
  }

  /**
   * Handles incoming messages routed from the Rust backend via Tauri events.
   */
  private handleIncomingDaemonMessage(message: DaemonMessage): void {
    const listener = this.responseListeners.get(message.id);
    if (listener) {
      listener(message);
      this.responseListeners.delete(message.id);
    } else {
      // Handle unsolicited broadcast events from the daemon (e.g., system metrics updates)
      console.info(`[DaemonBridge] Unsolicited daemon broadcast [${message.type}]:`, message.payload);
    }
  }

  /**
   * Internal routine to maintain health checks against the local daemon.
   */
  private startHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);

    this.heartbeatTimer = setInterval(async () => {
      try {
        const alive = await invoke<boolean>('ping_local_daemon');
        if (!alive && this.state === 'CONNECTED') {
          this.updateState('DEGRADED');
          this.handleReconnect();
        }
      } catch {
        this.updateState('ERROR');
        this.handleReconnect();
      }
    }, this.config.heartbeatIntervalMs);
  }

  /**
   * Manages reconnection strategies with exponential backoff.
   */
  private handleReconnect(): void {
    if (!this.config.autoReconnect || this.reconnectAttempts >= this.config.maxReconnectAttempts) {
      console.error('[DaemonBridge] Max reconnection attempts reached or auto-reconnect disabled.');
      return;
    }

    this.reconnectAttempts++;
    const backoffDelay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);

    console.warn(`[DaemonBridge] Reconnecting in ${backoffDelay}ms (Attempt ${this.reconnectAttempts})...`);

    setTimeout(async () => {
      try {
        await this.initialize();
        this.reconnectAttempts = 0; // Reset counter on success
      } catch {
        // Retry loop continues via recursion
      }
    }, backoffDelay);
  }

  /**
   * Updates internal state and safely notifies observers.
   */
  private updateState(newState: DaemonConnectionState): void {
    this.state = newState;
    console.debug(`[DaemonBridge] State transitioned to: ${newState}`);
  }

  /**
   * Gracefully tears down listeners and timers.
   */
  public async destroy(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.unlistenEvent) this.unlistenEvent();
    await invoke('disconnect_local_daemon').catch(() => {});
    this.updateState('DISCONNECTED');
  }
}
