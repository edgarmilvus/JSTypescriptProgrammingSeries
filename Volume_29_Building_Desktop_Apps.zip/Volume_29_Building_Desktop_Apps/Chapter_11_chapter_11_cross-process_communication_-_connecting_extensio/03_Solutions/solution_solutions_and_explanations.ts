/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';

export type DaemonRequest = 
  | { type: 'ExecuteCommand'; payload: { commandId: string; args: string[] } }
  | { type: 'FetchMetrics'; payload: { timeframe: '1h' | '24h' | '7d' } }
  | { type: 'StreamLogs'; payload: { filterLevel: 'info' | 'warn' | 'error' } };

export interface DaemonResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
}

/**
 * TypeScript utility class that wraps Tauri invoke calls to send 
 * typed payloads to the Rust daemon bridge.
 */
export class DaemonBridgeClient {
  async sendRequest<T>(request: DaemonRequest): Promise<DaemonResponse<T>> {
    try {
      // Invoke the Rust command handler registered in Tauri, passing the strongly typed request
      const response = await invoke<DaemonResponse<T>>('send_daemon_request', { request });
      return response;
    } catch (error: unknown) {
      // Handle Tauri invocation or network bridge failures gracefully
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
        timestamp: Date.now(),
      };
    }
  }
}
