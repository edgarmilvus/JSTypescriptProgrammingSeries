/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { listen, UnlistenFn } from '@tauri-apps/api/event';

export interface LogFrame {
  channelId: string;
  level: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  message: string;
  timestamp: number;
}

/**
 * Manager class that subscribes to multiplexed log events emitted from the Tauri backend,
 * maintaining a rolling buffer of log entries per channel.
 */
export class MultiplexedLogManager {
  private unlistenFn: UnlistenFn | null = null;
  private buffers: Map<string, LogFrame[]> = new Map();
  private maxBufferSize = 1000;

  async initialize(onNewLog: (channelId: string, log: LogFrame) => void): Promise<void> {
    if (this.unlistenFn) {
      return; // Already initialized
    }

    // Listen to the global Tauri event channel where multiplexed frames are broadcasted
    this.unlistenFn = await listen<LogFrame>('daemon-log-frame', (event) => {
      const logFrame = event.payload;
      const { channelId } = logFrame;

      // Maintain or retrieve the buffer for this specific channel
      if (!this.buffers.has(channelId)) {
        this.buffers.set(channelId, []);
      }

      const channelBuffer = this.buffers.get(channelId)!;
      channelBuffer.push(logFrame);

      // Enforce the max buffer size constraint (FIFO pruning) to prevent memory leaks
      if (channelBuffer.length > this.maxBufferSize) {
        channelBuffer.shift();
      }

      // Notify the caller callback of the incoming log entry
      onNewLog(channelId, logFrame);
    });
  }

  getLogsForChannel(channelId: string): LogFrame[] {
    // Return a shallow copy of buffered logs for a specific channel
    return [...(this.buffers.get(channelId) || [])];
  }

  async cleanup(): Promise<void> {
    if (this.unlistenFn) {
      this.unlistenFn();
      this.unlistenFn = null;
    }
    this.buffers.clear();
  }
}
