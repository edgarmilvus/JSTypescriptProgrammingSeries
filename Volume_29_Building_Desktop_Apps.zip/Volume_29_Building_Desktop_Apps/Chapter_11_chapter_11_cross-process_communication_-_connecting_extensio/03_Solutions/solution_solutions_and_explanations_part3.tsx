/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';

export interface DaemonStatusState {
  isConnected: boolean;
  activeProtocol: 'NamedPipe' | 'UnixSocket' | 'WebSocket' | 'Disconnected';
  latencyMs: number;
  cpuUsagePercent: number;
  memoryUsageMb: number;
  lastPingTimestamp: number;
}

export interface DaemonHealthDashboardProps {
  refreshIntervalMs?: number;
  onRestartRequested?: () => Promise<boolean>;
  fetchMetrics?: () => Promise<DaemonStatusState>;
}

export const DaemonHealthDashboard: React.FC<DaemonHealthDashboardProps> = ({
  refreshIntervalMs = 2000,
  onRestartRequested,
  fetchMetrics,
}) => {
  const [status, setStatus] = useState<DaemonStatusState>({
    isConnected: false,
    activeProtocol: 'Disconnected',
    latencyMs: 0,
    cpuUsagePercent: 0,
    memoryUsageMb: 0,
    lastPingTimestamp: Date.now(),
  });
  const [isRestarting, setIsRestarting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const pollMetrics = async () => {
      if (!fetchMetrics) return;
      try {
        const metrics = await fetchMetrics();
        if (isMounted) {
          setStatus(metrics);
          setErrorMessage(null);
        }
      } catch (err: unknown) {
        if (isMounted) {
          setErrorMessage(err instanceof Error ? err.message : 'Failed to fetch daemon metrics');
        }
      }
    };

    // Initial poll
    pollMetrics();

    // Set up polling interval
    const intervalId = setInterval(pollMetrics, refreshIntervalMs);

    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, [refreshIntervalMs, fetchMetrics]);

  const handleRestart = async () => {
    if (!onRestartRequested) return;
    setIsRestarting(true);
    setErrorMessage(null);
    try {
      const success = await onRestartRequested();
      if (!success) {
        setErrorMessage('Daemon restart command returned failure status.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Error executing daemon restart.');
    } finally {
      setIsRestarting(false);
    }
  };

  return (
    <div className="daemon-health-dashboard p-6 bg-slate-900 text-white rounded-xl shadow-2xl max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Local Daemon Health & Status</h2>
        <div className="flex items-center space-x-2">
          <span
            className={`h-3 w-3 rounded-full ${
              status.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
            }`}
          />
          <span className="text-sm font-medium text-slate-300">
            {status.isConnected ? status.activeProtocol : 'Offline'}
          </span>
        </div>
      </div>

      {errorMessage && (
        <div className="mb-4 p-3 bg-rose-900/50 border border-rose-500 rounded-lg text-rose-200 text-sm">
          {errorMessage}
        </div>
      )}

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 text-xs uppercase tracking-wider mb-1">Latency</div>
          <div className="text-xl font-semibold">{status.latencyMs} ms</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 text-xs uppercase tracking-wider mb-1">CPU Usage</div>
          <div className="text-xl font-semibold">{status.cpuUsagePercent.toFixed(1)}%</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 text-xs uppercase tracking-wider mb-1">Memory</div>
          <div className="text-xl font-semibold">{status.memoryUsageMb.toFixed(1)} MB</div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleRestart}
          disabled={isRestarting}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            isRestarting
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white'
          }`}
        >
          {isRestarting ? 'Restarting Daemon...' : 'Restart Daemon'}
        </button>
      </div>
    </div>
  );
};
