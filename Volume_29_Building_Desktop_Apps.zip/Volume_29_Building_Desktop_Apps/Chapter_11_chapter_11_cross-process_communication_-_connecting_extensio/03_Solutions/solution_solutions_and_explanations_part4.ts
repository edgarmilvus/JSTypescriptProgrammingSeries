/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as msgpack from '@msgpack/msgpack';

export interface DecodedPayload<T> {
  isValid: boolean;
  data?: T;
  error?: string;
  bytesProcessed: number;
}

export class BinaryPayloadCodec {
  /**
   * Decodes a raw Uint8Array buffer received from the Rust backend IPC bridge.
   * Utilizes MessagePack for efficient binary deserialization.
   */
  static decodeMessage<T>(buffer: Uint8Array): DecodedPayload<T> {
    try {
      if (!buffer || buffer.length === 0) {
        throw new Error('Received empty binary buffer');
      }

      // Decode the raw byte array using MessagePack spec
      const decodedData = msgpack.decode(buffer) as T;

      return {
        isValid: true,
        data: decodedData,
        bytesProcessed: buffer.length,
      };
    } catch (err: unknown) {
      return {
        isValid: false,
        error: err instanceof Error ? err.message : 'Unknown binary decoding error',
        bytesProcessed: 0,
      };
    }
  }

  /**
   * Encodes a structured TypeScript object into a binary Uint8Array 
   * ready for transmission back to the Rust daemon bridge.
   */
  static encodeMessage<T>(payload: T): Uint8Array {
    try {
      return msgpack.encode(payload);
    } catch (err: unknown) {
      throw new Error(`Failed to encode message to binary: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
}
