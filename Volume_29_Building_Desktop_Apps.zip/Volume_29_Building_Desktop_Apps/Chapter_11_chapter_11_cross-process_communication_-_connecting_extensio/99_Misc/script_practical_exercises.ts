/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Note: While the daemon backend is written in Rust, your TypeScript extension 
// definitions must mirror the data structures expected by the Rust Serde backend.
// Complete the following TypeScript type definitions and mock client interface 
// that will eventually interface with this named pipe bridge via Tauri commands.

export type DaemonRequest = 
  | { type: 'ExecuteCommand'; payload: { commandId: string; args: string[] } }
  | { type: 'FetchMetrics'; payload: { timeframe: '1h' | '24h' | '7d' } }
  | { type: 'StreamLogs'; payload: { filterLevel: 'info' | 'warn' | 'error' } };

export interface DaemonResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
}

/**
 * Challenge: Implement a TypeScript utility class that wraps Tauri invoke calls 
 * to send these typed payloads to your Rust daemon bridge, ensuring proper 
 * serialization and error management.
 */
export class DaemonBridgeClient {
  async sendRequest<T>(request: DaemonRequest): Promise<DaemonResponse<T>> {
    // TODO: Implement the Tauri invoke call to pass the request to the backend bridge
    throw new Error('Not implemented');
  }
}
