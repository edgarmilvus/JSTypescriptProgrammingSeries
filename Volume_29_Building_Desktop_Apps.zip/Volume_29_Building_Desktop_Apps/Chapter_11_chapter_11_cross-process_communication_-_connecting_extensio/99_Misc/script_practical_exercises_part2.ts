/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { listen, UnlistenFn } from '@tauri-apps/api/event';

export interface LogFrame {
  channelId: string;
  level: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  message: string;
  timestamp: number;
}

/**
 * Challenge: Write a TypeScript React hook or class-based manager that subscribes 
 * to multiplexed log events emitted from the Tauri backend, manages a rolling 
 * buffer of the last N log entries, and exposes clean subscription methods 
 * for individual extension UI components.
 */
export class MultiplexedLogManager {
  private unlistenFn: UnlistenFn | null = null;
  private buffers: Map<string, LogFrame[]> = new Map();
  private maxBufferSize = 1000;

  async initialize(onNewLog: (channelId: string, log: LogFrame) => void): Promise<void> {
    // TODO: Setup Tauri event listener for multiplexed logs and update internal buffers
  }

  getLogsForChannel(channelId: string): LogFrame[] {
    // TODO: Return the buffered logs for a specific channel
    return [];
  }

  async cleanup(): Promise<void> {
    // TODO: Teardown event listeners safely
  }
}
