/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useEffect, useState } from 'react';

export interface DaemonStatusState {
  isConnected: boolean;
  activeProtocol: 'NamedPipe' | 'UnixSocket' | 'WebSocket' | 'Disconnected';
  latencyMs: number;
  cpuUsagePercent: number;
  memoryUsageMb: number;
  lastPingTimestamp: number;
}

export interface DaemonHealthDashboardProps {
  refreshIntervalMs?: number;
  onRestartRequested?: () => Promise<boolean>;
}

/**
 * Challenge: Implement the React TSX component below. Fulfill the feature request 
 * by incorporating state management for daemon metrics, async effect hooks for 
 * polling health data, and clean JSX rendering with loading states and hydration safety.
 */
export const DaemonHealthDashboard: React.FC<DaemonHealthDashboardProps> = ({
  refreshIntervalMs = 2000,
  onRestartRequested,
}) => {
  const [status, setStatus] = useState<DaemonStatusState>({
    isConnected: false,
    activeProtocol: 'Disconnected',
    latencyMs: 0,
    cpuUsagePercent: 0,
    memoryUsageMb: 0,
    lastPingTimestamp: Date.now(),
  });
  const [isRestarting, setIsRestarting] = useState<boolean>(false);

  useEffect(() => {
    // TODO: Implement polling or event subscription for real-time daemon metrics
  }, [refreshIntervalMs]);

  const handleRestart = async () => {
    if (!onRestartRequested) return;
    setIsRestarting(true);
    try {
      await onRestartRequested();
    } finally {
      setIsRestarting(false);
    }
  };

  return (
    <div className="daemon-health-dashboard p-6 bg-slate-900 text-white rounded-xl shadow-2xl">
      <h2 className="text-2xl font-bold mb-4">Local Daemon Health & Status</h2>
      {/* TODO: Render connection badges, metrics progress bars, and the restart button */}
    </div>
  );
};
