/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

use tauri::{App, Manager};
use tauri_plugin_global_shortcut::{Code, Modifiers, Shortcut, ShortcutState};

/// Initializes the Tauri application, registers the global hotkey plugin,
/// and sets up an OS-level background event listener for shortcut activations.
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        // Register the global shortcut plugin with the Tauri runtime
        .plugin(tauri_plugin_global_shortcut::Builder::new().with_handler(|app, shortcut, event| {
            // Check if the event state is Pressed (we ignore Released events for this toggle action)
            if event.state() == ShortcutState::Pressed {
                // Define the target shortcut combination: Ctrl + Shift + Space (or Cmd + Shift + Space on macOS)
                let target_shortcut = Shortcut::new(Some(Modifiers::CONTROL | Modifiers::SHIFT), Code::Space);

                if shortcut == &target_shortcut {
                    println!("Global hotkey triggered: Ctrl+Shift+Space");

                    // Retrieve the main application window handle
                    if let Some(window) = app.get_webview_window("main") {
                        // Check visibility status and toggle accordingly
                        let is_visible = window.is_visible().unwrap_or(false);

                        if is_visible {
                            // If visible and focused, hide it to background/tray
                            let _ = window.hide();
                        } else {
                            // If hidden or unfocused, bring it to the foreground and focus it
                            let _ = window.show();
                            let _ = window.set_focus();
                            
                            // Emit a custom payload event to the TypeScript frontend to focus the input field
                            let _ = window.emit("quick-capture-activated", "Hotkey summoned window");
                        }
                    }
                }
            }
        }).build())
        .setup(|app| {
            // Explicitly register our hotkey target during app initialization
            let shortcut_string = "Ctrl+Shift+Space";
            let parsed_shortcut: Shortcut = shortcut_string.parse().unwrap();
            
            app.handle().plugin(tauri_plugin_global_shortcut::Builder::new().build())?;
            
            // Register the shortcut globally with the operating system
            global_shortcut_ext::GlobalShortcutExt::register(app.handle(), parsed_shortcut)?;
            
            println!("Global hotkey '{}' registered successfully.", shortcut_string);
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
