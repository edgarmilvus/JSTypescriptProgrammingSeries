/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.tsx
// Description: Basic Code Example
// ==========================================

import React, { useEffect, useState, useRef } from 'react';
import { listen } from '@tauri-apps/api/event';
import { getCurrentWindow } from '@tauri-apps/api/window';

/**
 * Interface representing the payload structure sent from the Rust backend
 * when the global shortcut event is emitted.
 */
interface ShortcutPayload {
  message: string;
}

/**
 * SaaS Quick Capture Overlay Component
 * Listens for system-wide OS events from Tauri and manages local UI state.
 */
export default function App() {
  const [notes, setNotes] = useState<string[]>([]);
  const [currentInput, setCurrentInput] = useState<string>('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Setup the background event listener on component mount
  useEffect(() => {
    let unlistenFn: (() => void) | undefined;

    /**
     * Asynchronously sets up the event listener for the Rust backend signal.
     */
    async function setupEventListener() {
      // Listen for the custom event emitted by the Rust window manager
      unlistenFn = await listen<string>('quick-capture-activated', (event) => {
        console.log('Received quick-capture activation event from OS:', event.payload);
        
        // Safely focus the HTML input element when the hotkey triggers the window
        if (inputRef.current) {
          inputRef.current.focus();
        }
      });
    }

    setupEventListener();

    // Cleanup function: remove the event listener when the component unmounts
    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  /**
   * Handles form submission to save the captured note and hide the window,
   * simulating a quick-capture SaaS workflow.
   */
  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentInput.trim()) return;

    // Append new note to local state
    setNotes((prev) => [currentInput, ...prev]);
    setCurrentInput('');

    try {
      // Once captured, hide the window back to the background tray state
      const appWindow = getCurrentWindow();
      await appWindow.hide();
    } catch (error) {
      console.error('Failed to hide window after capture:', error);
    }
  };

  return (
    <main className="min-h-screen bg-slate-900 text-slate-100 p-6 flex flex-col items-center">
      <div className="w-full max-w-md bg-slate-800 rounded-xl shadow-2xl p-6 border border-slate-700">
        <header className="mb-4">
          <h1 className="text-xl font-bold tracking-tight">SaaS Quick-Capture</h1>
          <p className="text-xs text-slate-400">Press <kbd className="bg-slate-700 px-1.5 py-0.5 rounded text-slate-200">Ctrl+Shift+Space</kbd> anywhere.</p>
        </header>

        <form onSubmit={handleSaveNote} className="space-y-4">
          <div>
            <input
              ref={inputRef}
              type="text"
              value={currentInput}
              onChange={(e) => setCurrentInput(e.target.value)}
              placeholder="What's on your mind? Type and hit Enter..."
              className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm text-slate-100 placeholder-slate-500"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-sm transition-colors shadow-lg"
          >
            Capture & Dismiss
          </button>
        </form>

        <section className="mt-6">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Recent Captures</h2>
          <ul className="space-y-2 max-h-48 overflow-y-auto">
            {notes.length === 0 ? (
              <li className="text-xs text-slate-500 italic">No notes captured yet during this session.</li>
            ) : (
              notes.map((note, index) => (
                <li key={index} className="bg-slate-900/50 p-2.5 rounded border border-slate-700/50 text-sm">
                  {note}
                </li>
              ))
            )}
          </ul>
        </section>
      </div>
    </main>
  );
}
