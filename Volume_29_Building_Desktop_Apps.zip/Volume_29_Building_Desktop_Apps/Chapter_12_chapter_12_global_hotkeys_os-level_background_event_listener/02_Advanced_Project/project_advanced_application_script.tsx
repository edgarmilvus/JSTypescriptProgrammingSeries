/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { register, unregisterAll } from '@tauri-apps/plugin-global-shortcut';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing an AI model configuration item.
 * Adheres to Immutable State Management principles.
 */
interface ModelConfig {
  readonly id: string;
  readonly name: string;
  readonly activeFeatureVector: readonly number[];
}

/**
 * Interface representing a streamed chunk from Server-Sent Events (SSE).
 */
interface StreamChunk {
  readonly token: string;
  readonly sequence: number;
}

/**
 * SaaS AI Copilot Floating Palette Component.
 * Integrates Tauri 2.0 Global Hotkeys with React State Management and SSE streaming.
 */
export default function AdvancedCommandPalette() {
  // Application State
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [query, setQuery] = useState<string>('');
  const [responseStream, setResponseStream] = useState<string>('');
  const [modelConfigs, setModelConfigs] = useState<readonly ModelConfig[]>([
    { id: 'm-1', name: 'GPT-4o Enterprise', activeFeatureVector: [0.12, 0.45, 0.89] },
    { id: 'm-2', name: 'Claude 3.5 Sonnet', activeFeatureVector: [0.34, 0.76, 0.21] },
  ]);
  const [activeModelId, setActiveModelId] = useState<string>('m-1');

  // Ref to maintain persistent unlisten handle references without re-triggering effects
  const unlistenRef = useRef<UnlistenFn | null>(null);

  /**
   * Toggles the main application window visibility and focus state via Tauri IPC.
   */
  const toggleWindowVisibility = useCallback(async () => {
    const appWindow = getCurrentWindow();
    const visible = await appWindow.isVisible();

    if (visible) {
      await appWindow.hide();
      setIsVisible(false);
    } else {
      await appWindow.show();
      await appWindow.setFocus();
      setIsVisible(true);
    }
  }, []);

  /**
   * Initializes global shortcuts and OS-level event listeners on component mount.
   */
  useEffect(() => {
    let isMounted = true;

    async function setupGlobalEnvironment() {
      try {
        // Register system-wide shortcut: Command/Control + Shift + Space
        await register('CommandOrControl+Shift+Space', async () => {
          if (isMounted) {
            await toggleWindowVisibility();
          }
        });

        // Listen for backend-emitted background events (e.g., system tray interactions)
        const unlistenTray = await listen<string>('tray-menu-clicked', async (event) => {
          if (event.payload === 'toggle-palette' && isMounted) {
            await toggleWindowVisibility();
          }
        });

        unlistenRef.current = unlistenTray;
      } catch (error) {
        console.error('Failed to register global hotkeys or listeners:', error);
      }
    }

    setupGlobalEnvironment();

    // Cleanup routine: Unregister all shortcuts and listeners when unmounting
    return () => {
      isMounted = false;
      unregisterAll().catch((err) => console.error('Failed to unregister hotkeys:', err));
      if (unlistenRef.current) {
        unlistenRef.current();
      }
    };
  }, [toggleWindowVisibility]);

  /**
   * Handles submission of the AI prompt and opens an SSE stream connection.
   * Demonstrates immutable state transformations and safe async iteration.
   */
  const handlePromptSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!query.trim()) return;

    // Reset response stream immutably
    setResponseStream('');

    try {
      // Invoke Rust backend command to initialize streaming pipeline
      const streamId = await invoke<string>('init_ai_stream', {
        prompt: query,
        modelId: activeModelId,
      });

      // Listen to Server-Sent Events pushed from the Tauri backend event emitter
      const unlistenStream = await listen<StreamChunk>(`stream-${streamId}`, (event) => {
        // Immutable state update appending new tokens
        setResponseStream((prev) => prev + event.payload.token);
      });

      // Automatically cleanup the specific stream listener once finished (handled by backend signal)
      const unlistenComplete = await listen(`stream-complete-${streamId}`, () => {
        unlistenStream();
        unlistenComplete();
      });

    } catch (error) {
      console.error('Error during AI stream execution:', error);
      setResponseStream((prev) => prev + '\n[Error: Failed to fetch stream response]');
    }
  };

  /**
   * Immutably updates the active model configuration feature vector.
   */
  const handleModelSwitch = (newModelId: string) => {
    setActiveModelId(newModelId);
    setModelConfigs((currentConfigs) =>
      currentConfigs.map((model) =>
        model.id === newModelId
          ? { ...model, activeFeatureVector: [...model.activeFeatureVector] }
          : model
      )
    );
  };

  return (
    <div className={`fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 transition-opacity duration-200 ${isVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
      <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl overflow-hidden flex flex-col text-zinc-100">
        
        {/* Header with Model Selector */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-800/50 border-b border-zinc-700">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Tauri AI Command Center</span>
          <div className="flex gap-2">
            {modelConfigs.map((model) => (
              <button
                key={model.id}
                onClick={() => handleModelSwitch(model.id)}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors ${activeModelId === model.id ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'}`}
              >
                {model.name}
              </button>
            ))}
          </div>
        </div>

        {/* Search & Prompt Input Form */}
        <form onSubmit={handlePromptSubmit} className="p-4 border-b border-zinc-800">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command or ask AI (Global Hotkey: Cmd+Shift+Space)..."
            className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-4 py-3 text-sm text-zinc-100 focus:outline-none focus:border-indigo-500 transition-colors"
            autoFocus
          />
        </form>

        {/* Streaming Output Console (Simulated SSE Output) */}
        <div className="p-4 h-64 overflow-y-auto bg-zinc-950/50 font-mono text-xs text-zinc-300 whitespace-pre-wrap">
          {responseStream || '// Awaiting background prompt execution...'}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 bg-zinc-900 border-t border-zinc-800 text-[10px] text-zinc-500 flex justify-between">
          <span>OS Background Listener: Active</span>
          <span>Press ESC or Hotkey to Hide</span>
        </div>
      </div>
    </div>
  );
}
