/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Interactive Challenge: Implement the conflict-aware hotkey registration utility
import { invoke } from '@tauri-apps/api/core';

interface HotkeyRegistrationOptions {
  id: string;
  shortcut: string;
  description: string;
  callback: () => void;
}

export class HotkeyManager {
  private activeHotkeys: Map<string, string> = new Map(); // id -> shortcut

  public async registerHotkey(options: HotkeyRegistrationOptions): Promise<boolean> {
    const { id, shortcut } = options;

    // Check for duplicate shortcut assignments across existing registrations
    for (const [existingId, existingShortcut] of this.activeHotkeys.entries()) {
      if (existingShortcut.toLowerCase() === shortcut.toLowerCase() && existingId !== id) {
        console.warn(`[HotkeyManager] Conflict detected: Shortcut "${shortcut}" is already claimed by ID "${existingId}".`);
        return false;
      }
    }

    try {
      // Invoke the Tauri backend command to register the OS-level global hotkey
      await invoke('register_custom_hotkey', { id, shortcut });
      
      // Store the mapping upon successful backend registration
      this.activeHotkeys.set(id, shortcut);
      return true;
    } catch (error) {
      console.error(`[HotkeyManager] Failed to register hotkey "${shortcut}" for ID "${id}":`, error);
      return false;
    }
  }

  public async unregisterHotkey(id: string): Promise<void> {
    const shortcut = this.activeHotkeys.get(id);
    if (!shortcut) return;

    try {
      await invoke('unregister_custom_hotkey', { id, shortcut });
    } catch (error) {
      console.error(`[HotkeyManager] Error unregistering hotkey for ID "${id}":`, error);
    } finally {
      this.activeHotkeys.delete(id);
    }
  }
}
