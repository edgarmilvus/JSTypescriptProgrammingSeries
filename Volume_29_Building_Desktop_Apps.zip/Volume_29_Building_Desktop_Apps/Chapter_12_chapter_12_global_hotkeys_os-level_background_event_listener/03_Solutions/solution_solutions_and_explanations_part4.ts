/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Interactive Challenge: Write the TypeScript settings management service that communicates with the persistent Rust backend
import { invoke } from '@tauri-apps/api/core';

export interface HotkeyConfigurationMap {
  [actionId: string]: string; // e.g., "toggle_launcher": "CommandOrControl+Shift+Space"
}

export class HotkeyPersistenceService {
  public async loadConfiguration(): Promise<HotkeyConfigurationMap> {
    try {
      const config = await invoke<HotkeyConfigurationMap>('load_hotkey_config');
      return config || {};
    } catch (error) {
      console.warn('[HotkeyPersistenceService] Failed to load configuration from disk, returning defaults:', error);
      return {};
    }
  }

  public async saveBinding(actionId: string, newShortcut: string): Promise<void> {
    try {
      // Invoke the Rust backend command to update, validate, and persist the new binding
      await invoke('update_hotkey_binding', { actionId, newShortcut });
    } catch (error) {
      throw new Error(`Failed to update hotkey binding for "${actionId}": ${error}`);
    }
  }

  public async resetToDefaults(): Promise<HotkeyConfigurationMap> {
    try {
      const defaultConfig = await invoke<HotkeyConfigurationMap>('reset_hotkey_config');
      return defaultConfig;
    } catch (error) {
      console.error('[HotkeyPersistenceService] Failed to reset hotkey configurations:', error);
      throw error;
    }
  }
}
