/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Implement the conflict-aware hotkey registration utility
import { invoke } from '@tauri-apps/api/core';

interface HotkeyRegistrationOptions {
  id: string;
  shortcut: string;
  description: string;
  callback: () => void;
}

export class HotkeyManager {
  private activeHotkeys: Map<string, string> = new Map(); // id -> shortcut

  public async registerHotkey(options: HotkeyRegistrationOptions): Promise<boolean> {
    // TODO: Implement duplicate detection across all values in the activeHotkeys map.
    // TODO: If a conflict exists, throw or return false with a console warning.
    // TODO: Invoke the Tauri command 'register_custom_hotkey' with the shortcut string.
    // TODO: Store the mapping upon successful registration.
    return false;
  }

  public async unregisterHotkey(id: string): Promise<void> {
    // TODO: Look up shortcut by id, call Tauri unregister command, and delete from map.
  }
}
