/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Implement the keyboard navigation and focus management hook for the QuickLauncherOverlay
import React, { useState, useEffect, useRef, KeyboardEvent } from 'react';
import { getCurrentWindow } from '@tauri-apps/api/window';

interface SearchItem {
  id: string;
  title: string;
  category: string;
  action: () => void;
}

interface QuickLauncherProps {
  items: SearchItem[];
}

export const QuickLauncherOverlay: React.FC<QuickLauncherProps> = ({ items }) => {
  const [query, setQuery] = useState<string>('');
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // Filter items based on query
  const filteredItems = items.filter(item => 
    item.title.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    // TODO: Focus the input ref when component mounts or window becomes visible
  }, []);

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    // TODO: Implement ArrowDown, ArrowUp, Enter, and Escape key handlers.
    // TODO: Prevent default behavior for navigation keys.
    // TODO: Implement index boundary clamping or wrapping for filteredItems length.
  };

  return (
    <div className="flex flex-col w-full max-w-2xl bg-zinc-900 text-zinc-100 rounded-xl shadow-2xl border border-zinc-800 overflow-hidden">
      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setSelectedIndex(0); // Reset selection on new query
        }}
        onKeyDown={handleKeyDown}
        placeholder="Type a command or search..."
        className="w-full px-5 py-4 bg-transparent text-lg outline-none border-b border-zinc-800 placeholder-zinc-500"
      />
      <ul className="max-h-80 overflow-y-auto p-2">
        {filteredItems.map((item, index) => (
          <li
            key={item.id}
            className={`px-4 py-3 rounded-lg flex justify-between items-center cursor-pointer ${
              index === selectedIndex ? 'bg-indigo-600 text-white' : 'hover:bg-zinc-800 text-zinc-300'
            }`}
          >
            <span>{item.title}</span>
            <span className="text-xs opacity-60 uppercase tracking-wider">{item.category}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};
