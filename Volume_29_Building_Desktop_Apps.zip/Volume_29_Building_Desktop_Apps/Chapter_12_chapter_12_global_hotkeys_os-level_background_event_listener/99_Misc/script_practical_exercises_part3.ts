/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Implement the debounced clipboard history hook in TypeScript
import { useEffect, useState, useRef, useCallback } from 'react';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

export interface ClipboardItem {
  id: string;
  timestamp: number;
  snippet: string;
  length: number;
}

export function useClipboardHistory(maxItems: number = 50) {
  const [history, setHistory] = useState<ClipboardItem[]>([]);
  const pendingUpdatesRef = useRef<ClipboardItem[]>([]);
  const timerRef = useRef<number | null>(null);

  const flushUpdates = useCallback(() => {
    // TODO: Flush pending updates into the main history state array,
    // ensuring the total length does not exceed maxItems by slicing from the front.
  }, [maxItems]);

  useEffect(() => {
    let unlisten: UnlistenFn | undefined;

    async function setupListener() {
      // TODO: Listen to 'clipboard-item-captured' events from Tauri.
      // TODO: Push incoming event payloads to pendingUpdatesRef.current.
      // TODO: Set up a debounced timer (e.g., 250ms) to call flushUpdates().
    }

    setupListener();

    return () => {
      if (unlisten) {
        unlisten();
      }
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }
    };
  }, [flushUpdates]);

  const clearHistory = () => {
    setHistory([]);
    pendingUpdatesRef.current = [];
  };

  return { history, clearHistory };
}
