/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Represents a single message within the AI chat session.
 */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  isOptimistic?: boolean;
}

/**
 * Configuration payload for the local Ollama generation request.
 */
export interface GenerationOptions {
  model: string;
  prompt: string;
  systemPrompt?: string;
  temperature?: number;
}

/**
 * Response structure returned by the local Zero-Shot Classification model.
 */
export interface ClassificationResult {
  category: string;
  confidence: number;
  tokensEvaluated: number;
}

/**
 * Manages local AI inference, streaming, and state reconciliation for the desktop SaaS client.
 */
export class LocalAIClient {
  private ollamaEndpoint: string;
  private defaultModel: string;
  private isModelWarmedUp: boolean = false;

  /**
   * Initializes the LocalAIClient instance.
   * @param port The port on which the local Ollama instance is listening (default: 11434).
   * @param model The default local model tag to use for generations.
   */
  constructor(port: number = 11434, model: string = 'llama3') {
    this.ollamaEndpoint = `http://localhost:${port}`;
    this.defaultModel = model;
  }

  /**
   * Checks if the local Ollama daemon is active and handles the Cold Start phase.
   * @returns A promise that resolves to true if the service is reachable.
   */
  public async checkColdStart(): Promise<boolean> {
    try {
      // We invoke a custom Rust Tauri command to bypass CORS restrictions if running in standard webview contexts,
      // or fall back to a direct fetch if Tauri capabilities allow localhost binding.
      const isHealthy = await invoke<boolean>('check_ollama_status', {
        endpoint: this.ollamaEndpoint,
      });
      
      this.isModelWarmedUp = isHealthy;
      return isHealthy;
    } catch (error) {
      console.error('Cold Start failure: Local Ollama instance is unreachable.', error);
      return false;
    }
  }

  /**
   * Streams a completion from the local Ollama instance token by token.
   * Demonstrates Optimistic UI state management and stream processing.
   * 
   * @param options Configuration options for generation.
   * @param onTokenReceived Callback executed whenever a new token string chunk is parsed.
   * @returns The final aggregated text response.
   */
  public async streamCompletion(
    options: GenerationOptions,
    onTokenReceived: (token: string) => void
  ): Promise<string> {
    const payload = {
      model: options.model || this.defaultModel,
      prompt: options.prompt,
      system: options.systemPrompt,
      options: {
        temperature: options.temperature ?? 0.7,
      },
      stream: true,
    };

    let fullResponseText = '';

    try {
      // Execute a POST request against the local Ollama API endpoint
      const response = await window.fetch(`${this.ollamaEndpoint}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok || !response.body) {
        throw new Error(`Local inference failed with HTTP status ${response.status}`);
      }

      // Read the ReadableStream returned by Ollama using a TextDecoder stream reader
      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');

        // Retain the last potentially incomplete line in the buffer
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.trim() === '') continue;
          
          try {
            const parsed = JSON.parse(line);
            if (parsed.response) {
              fullResponseText += parsed.response;
              onTokenReceived(parsed.response);
            }
          } catch (jsonError) {
            console.warn('Failed to parse streaming JSON chunk:', jsonError);
          }
        }
      }

      return fullResponseText;
    } catch (error) {
      console.error('Error during local stream generation:', error);
      throw error;
    }
  }

  /**
   * Performs local Zero-Shot Classification on an incoming customer support ticket.
   * 
   * @param text The raw input text to classify.
   * @param categories An array of allowed category labels.
   * @returns Structured classification data including confidence metrics.
   */
  public async classifyTicketZeroShot(
    text: string,
    categories: string[]
  ): Promise<ClassificationResult> {
    const prompt = `
      Classify the following support text into exactly one of these categories: [${categories.join(', ')}].
      Return ONLY a valid JSON object with keys "category" (string) and "confidence" (number between 0 and 1).
      Text: "${text}"
    `;

    const payload = {
      model: this.defaultModel,
      prompt: prompt,
      stream: false,
      format: 'json', // Forces Ollama to output strict JSON
    };

    const response = await window.fetch(`${this.ollamaEndpoint}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error('Zero-shot classification network request failed.');
    }

    const data = await response.json();
    
    try {
      const parsedResult = JSON.parse(data.response);
      return {
        category: categories.includes(parsedResult.category) ? parsedResult.category : 'Unassigned',
        confidence: typeof parsedResult.confidence === 'number' ? parsedResult.confidence : 0.0,
        tokensEvaluated: data.eval_count || 0,
      };
    } catch (parseError) {
      console.error('Model failed to return valid JSON despite format constraints:', data.response);
      return { category: 'Unassigned', confidence: 0.0, tokensEvaluated: 0 };
    }
  }
}

/**
 * Demonstrates the end-to-end UI reconciliation loop for a desktop chat widget.
 */
export async function runDesktopChatWorkflow() {
  const aiClient = new LocalAIClient(11434, 'llama3');

  // Step 1: Check for Cold Start / Daemon availability
  const isReady = await aiClient.checkColdStart();
  if (!isReady) {
    console.warn('Ollama daemon not detected. Prompting user to start local service.');
    return;
  }

  // Step 2: Initialize Optimistic UI State
  const userMessage: ChatMessage = {
    id: 'msg-user-001',
    role: 'user',
    content: 'Summarize our local database performance metrics.',
    timestamp: Date.now(),
    isOptimistic: false,
  };

  const assistantMessageId = 'msg-asst-001';
  let assistantMessage: ChatMessage = {
    id: assistantMessageId,
    role: 'assistant',
    content: '',
    timestamp: Date.now(),
    isOptimistic: true, // Mark as optimistically rendering placeholder
  };

  console.log('Optimistic State Rendered:', assistantMessage);

  // Step 3: Stream response and perform reconciliation
  await aiClient.streamCompletion(
    {
      model: 'llama3',
      prompt: userMessage.content,
      systemPrompt: 'You are a helpful, local enterprise database assistant.',
    },
    (token) => {
      // Append incoming tokens to the local state object
      assistantMessage.content += token;
      
      // Trigger UI redraw here (e.g., React state setter: setMessages(...))
    }
  );

  // Step 4: Reconciliation complete - finalize state
  assistantMessage.isOptimistic = false;
  console.log('Reconciliation Confirmed. Final State:', assistantMessage);

  // Step 5: Run Zero-Shot Classification on user intent
  const classification = await aiClient.classifyTicketZeroShot(
    userMessage.content,
    ['Database', 'Billing', 'Authentication', 'General']
  );

  console.log('Zero-Shot Classification Result:', classification);
}
