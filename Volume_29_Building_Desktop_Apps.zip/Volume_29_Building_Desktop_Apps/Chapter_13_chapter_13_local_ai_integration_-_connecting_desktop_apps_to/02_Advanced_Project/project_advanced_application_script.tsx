/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing a single chat message within the local RAG session.
 */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  sources?: string[];
}

/**
 * Payload structure received from the Rust backend during streaming inference.
 */
interface StreamChunkPayload {
  chunk: string;
  done: boolean;
  message_id: string;
}

/**
 * Properties for the LocalAIChatWorkspace component.
 */
interface LocalAIChatWorkspaceProps {
  modelName: string;
  vaultPath: string;
}

/**
 * LocalAIChatWorkspace Component
 * 
 * Provides a production-grade chat interface connected to a local Ollama instance
 * running via the Tauri 2.0 Rust backend. Supports real-time token streaming,
 * local vector retrieval context injection, and zero-shot categorization.
 */
export const LocalAIChatWorkspace: React.FC<LocalAIChatWorkspaceProps> = ({
  modelName = 'llama3',
  vaultPath,
}) => {
  // Application state management using React hooks
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [activeCategory, setActiveCategory] = useState<string>('General');
  const [ragEnabled, setRagEnabled] = useState<boolean>(true);

  // Reference to track the container for automatic scrolling during token streams
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Reference to store active Tauri event listener cleanup functions
  const unlistenRef = useRef<UnlistenFn | null>(null);

  /**
   * Automatically scrolls the chat view to the most recent message chunk.
   */
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  /**
   * Sets up the Tauri event listener for incoming token streams from the Rust backend.
   */
  useEffect(() => {
    let isMounted = true;

    async function setupEventListener() {
      // Listen to the custom Rust event emitter 'ollama-stream-chunk'
      const unlisten = await listen<StreamChunkPayload>('ollama-stream-chunk', (event) => {
        if (!isMounted) return;

        const { chunk, done, message_id } = event.payload;

        setMessages((prevMessages) => {
          return prevMessages.map((msg) => {
            if (msg.id === message_id) {
              return {
                ...msg,
                content: msg.content + chunk,
              };
            }
            return msg;
          });
        });

        if (done) {
          setIsGenerating(false);
        }
      });

      unlistenRef.current = unlisten;
    }

    setupEventListener();

    return () => {
      isMounted = false;
      if (unlistenRef.current) {
        unlistenRef.current();
      }
    };
  }, []);

  /**
   * Handles user submission, triggers local RAG embedding lookup, 
   * and invokes the Rust Ollama bridge command.
   */
  const handleSendMessage = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isGenerating) return;

    const userMessageId = `user-${Date.now()}`;
    const assistantMessageId = `assistant-${Date.now()}`;
    const userText = inputValue;

    // Clear input field immediately for snappy UX
    setInputValue('');

    // Construct new message array including the user prompt and an empty assistant placeholder
    const newMessages: ChatMessage[] = [
      ...messages,
      {
        id: userMessageId,
        role: 'user',
        content: userText,
        timestamp: Date.now(),
      },
      {
        id: assistantMessageId,
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
      },
    ];

    setMessages(newMessages);
    setIsGenerating(true);

    try {
      let contextSnippets: string[] = [];

      // Step 1: If RAG is enabled, query the local vector database via Rust
      if (ragEnabled) {
        contextSnippets = await invoke<string[]>('query_local_vector_db', {
          vaultPath,
          query: userText,
          topK: 3,
        });
      }

      // Step 2: Perform Zero-Shot Classification on the input prompt locally
      const classifiedCategory = await invoke<string>('classify_text_local', {
        text: userText,
        categories: ['Technical Architecture', 'Bug Report', 'General Inquiry', 'Feature Request'],
      });

      setActiveCategory(classifiedCategory);

      // Step 3: Invoke the core streaming command in the Rust backend
      await invoke('stream_ollama_chat', {
        model: modelName,
        prompt: userText,
        context: contextSnippets,
        messageId: assistantMessageId,
      });

    } catch (error) {
      console.error('Failed to communicate with local AI daemon:', error);
      
      // Update assistant placeholder with error message
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessageId
            ? { ...msg, content: `[Error: Unable to connect to local Ollama daemon. Ensure Ollama is running on port 11434.]` }
            : msg
        )
      );
      setIsGenerating(false);
    }
  }, [inputValue, isGenerating, messages, modelName, ragEnabled, vaultPath]);

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-slate-100 font-sans">
      {/* Workspace Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
        <div className="flex items-center space-x-3">
          <span className="h-3 w-3 rounded-full bg-emerald-500 animate-pulse" />
          <h1 className="text-lg font-semibold tracking-wide">LocalAI Workspace ({modelName})</h1>
        </div>
        <div className="flex items-center space-x-4 text-xs text-slate-400">
          <span className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700">
            Category: <strong className="text-emerald-400">{activeCategory}</strong>
          </span>
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={ragEnabled}
              onChange={(e) => setRagEnabled(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-0"
            />
            <span>Offline RAG Context</span>
          </label>
        </div>
      </header>

      {/* Chat Messages Container */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 space-y-2">
            <p className="text-base font-medium">No messages in this secure local session.</p>
            <p className="text-xs max-w-sm">
              All inference is executed completely offline via Ollama. Your documents never leave your machine.
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-2xl rounded-2xl px-5 py-3.5 text-sm leading-relaxed shadow-md ${
                  msg.role === 'user'
                    : 'bg-emerald-600 text-white rounded-br-none'
                    : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-700/50 text-xs text-slate-400">
                    <span className="font-semibold text-slate-300">Retrieved Context:</span>
                    <ul className="list-disc list-inside mt-1 space-y-0.5">
                      {msg.sources.map((src, idx) => (
                        <li key={idx} className="truncate">{src}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              <span className="text-[10px] text-slate-500 mt-1.5 px-1">
                {new Date(msg.timestamp).toLocaleTimeString()}
              </span>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Prompt Form */}
      <footer className="p-4 bg-slate-950 border-t border-slate-800">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-3 max-w-4xl mx-auto">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={isGenerating ? "AI is generating offline..." : "Ask your local vault anything..."}
            disabled={isGenerating}
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isGenerating || !inputValue.trim()}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white px-6 py-3 rounded-xl text-sm font-medium transition-colors shadow-lg shadow-emerald-900/20"
          >
            {isGenerating ? 'Thinking...' : 'Send'}
          </button>
        </form>
      </footer>
    </div>
  );
};
