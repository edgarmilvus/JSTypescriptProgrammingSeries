/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

interface StreamPayload {
  chunk: string;
  done: boolean;
}

export async function startChatSession(
  model: string, 
  prompt: string, 
  onChunk: (text: string) => void
): Promise<void> {
  let unlisten: UnlistenFn | null = null;

  try {
    // 1. Set up the event listener BEFORE invoking the command to avoid missing early chunks
    unlisten = await listen<StreamPayload>('ollama-stream-chunk', (event) => {
      const { chunk, done } = event.payload;
      if (chunk) {
        onChunk(chunk);
      }
      if (done && unlisten) {
        unlisten();
      }
    });

    // 2. Invoke the Rust backend command
    await invoke('stream_ollama_response', { model, prompt });
  } catch (error) {
    console.error("Failed to execute chat stream:", error);
    if (unlisten) {
      unlisten();
    }
  }
}
