/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';

interface SearchResult {
  id: string;
  filePath: string;
  contentSnippet: string;
  similarityScore: number;
}

interface RAGSearchPanelProps {
  vaultPath: string;
  selectedModel: string;
}

export const RAGSearchPanel: React.FC<RAGSearchPanelProps> = ({ vaultPath, selectedModel }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async () => {
    if (!query.trim()) return;
    setIsSearching(true);
    setError(null);

    try {
      const searchHits = await invoke<SearchResult[]>('search_local_embeddings', {
        vaultPath,
        model: selectedModel,
        query,
      });
      setResults(searchHits);
    } catch (err) {
      setError(typeof err === 'string' ? err : 'Failed to query local knowledge base.');
    } finally {
      setIsSearching(false);
    }
  }, [query, vaultPath, selectedModel]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSearch();
    }
  };

  return (
    <div className="rag-search-panel flex flex-col h-full p-4 bg-slate-900 text-slate-100">
      <h2 className="text-xl font-bold mb-4">Local Knowledge Base Search</h2>
      
      <div className="flex flex-col gap-2 mb-4">
        <textarea
          aria-label="Vault Search Query"
          className="p-3 bg-slate-800 border border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-100 resize-none h-24"
          placeholder="Ask a question about your local vault... (Ctrl+Enter to submit)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <div className="flex justify-between items-center">
          <span className="text-xs text-slate-400 bg-slate-800 px-2 py-1 rounded border border-slate-700">
            WebGPU Accelerated
          </span>
          <button
            onClick={handleSearch}
            disabled={isSearching}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-medium rounded-md transition-colors"
          >
            {isSearching ? 'Searching...' : 'Search Vault'}
          </button>
        </div>
      </div>

      {error && <div className="p-3 mb-4 bg-red-900/50 border border-red-700 rounded text-red-200 text-sm">{error}</div>}

      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {results.map((hit) => (
          <div key={hit.id} className="p-3 bg-slate-800/80 border border-slate-700/80 rounded-md flex flex-col gap-2">
            <div className="flex justify-between items-center text-xs text-slate-400">
              <span className="truncate max-w-[70%]" title={hit.filePath}>{hit.filePath}</span>
              <span className="bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-800 font-mono">
                {(hit.similarityScore * 100).toFixed(1)}% match
              </span>
            </div>
            <p className="text-sm text-slate-300 font-mono bg-slate-900/50 p-2 rounded">{hit.contentSnippet}</p>
            <button 
              onClick={() => console.log('Injecting:', hit.id)}
              className="self-end text-xs text-blue-400 hover:text-blue-300 font-medium"
            >
              + Inject into Context
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
