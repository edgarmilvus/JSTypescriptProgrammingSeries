/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

use std::path::PathBuf;
use serde::{Serialize, Deserialize};
use tokio::fs;
use walkdir::WalkDir;
use reqwest::Client;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct DocumentEmbedding {
    pub file_path: String,
    pub chunk_index: usize,
    pub content: String,
    pub vector: Vec<f32>,
}

#[derive(Serialize)]
<'a>
struct OllamaEmbeddingRequest<'a> {
    model: &'a str,
    prompt: &'a str,
}

#[derive(Deserialize)]
struct OllamaEmbeddingResponse {
    embedding: Vec<f32>,
}

pub async fn generate_vault_embeddings(
    vault_path: PathBuf,
    model_name: String,
) -> Result<Vec<DocumentEmbedding>, String> {
    let client = Client::new();
    let mut embeddings = Vec::new();

    // 1. Traverse directory recursively
    let walker = WalkDir::new(vault_path).into_iter().filter_map(|e| e.ok());

    for entry in walker {
        let path = entry.path();
        if path.is_file() {
            if let Some(ext) = path.extension() {
                if ext == "md" || ext == "txt" {
                    let content = fs::read_to_string(path).await
                        .map_err(|e| format!("Failed to read file: {}", e))?;

                    // 2. Simple token-approximate chunking (~500 chars per chunk with overlap)
                    let chunks = chunk_text(&content, 500, 50);

                    for (idx, chunk) in chunks.into_iter().enumerate() {
                        let req_body = OllamaEmbeddingRequest {
                            model: &model_name,
                            prompt: &chunk,
                        };

                        // 3. Post to local Ollama embedding endpoint
                        let res = client
                            .post("http://localhost:11434/api/embeddings")
                            .json(&req_body)
                            .send()
                            .await
                            .map_err(|e| format!("Ollama connection error: {}", e))?;

                        if !res.status().is_success() {
                            return Err(format!("Ollama API returned error status: {}", res.status()));
                        }

                        let json_res: OllamaEmbeddingResponse = res.json().await
                            .map_err(|e| format!("Failed to parse embedding JSON: {}", e))?;

                        embeddings.push(DocumentEmbedding {
                            file_path: path.to_string_lossy().into_owned(),
                            chunk_index: idx,
                            content: chunk,
                            vector: json_res.embedding,
                        });
                    }
                }
            }
        }
    }

    Ok(embeddings)
}

fn chunk_text(text: &str, chunk_size: usize, overlap: usize) -> Vec<String> {
    let mut chunks = डाctor = Vec::new(); // placeholder for safe iteration logic
    let chars: Vec<char> = text.chars().collect();
    let mut start = 0;

    while start < chars.len() {
        let end = std::cmp::min(start + chunk_size, chars.len());
        let chunk: String = chars[start..end].iter().collect();
        chunks.push(chunk);
        if end == chars.len() {
            break;
        }
        start += chunk_size - overlap;
    }

    chunks
}
