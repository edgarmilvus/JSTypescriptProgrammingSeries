/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// src/workers/compute.worker.ts
// This file runs inside a dedicated Web Worker thread, completely isolated from the DOM.

self.onmessage = async (event: MessageEvent) => {
  const { taskId, payload } = event.data;

  try {
    // Simulate a heavy computational workload (e.g., matrix manipulation or tokenization)
    console.log(`[WebWorker] Starting heavy task ${taskId} with payload size:`, payload.length);

    let accumulator = 0;
    for (let i = 0; i < payload.length; i++) {
      // Perform CPU-intensive math iterations
      accumulator += Math.sqrt(payload[i]) * Math.sin(payload[i]);
    }

    // Send the computed result back to the main UI thread without blocking rendering
    self.postMessage({
      taskId,
      success: true,
      result: accumulator,
    });
  } catch (error: any) {
    self.postMessage({
      taskId,
      success: false,
      error: error.message,
    });
  }
};
