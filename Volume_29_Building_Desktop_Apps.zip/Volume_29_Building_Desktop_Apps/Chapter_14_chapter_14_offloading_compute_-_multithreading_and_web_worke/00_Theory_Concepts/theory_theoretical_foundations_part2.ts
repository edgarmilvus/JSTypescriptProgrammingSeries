/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// src/services/WorkerManager.ts
// Manages the lifecycle and message routing for frontend background workers.

export class ComputeWorkerManager {
  private worker: Worker;
  private callbacks: Map<string, { resolve: (val: any) => void; reject: (err: any) => void }>;
  private nextId: number;

  constructor() {
    // Instantiate the Web Worker using Vite's worker import syntax supported by Tauri
    this.worker = new Worker(new URL('../workers/compute.worker.ts', import.meta.url), {
      type: 'module',
    });

    this.callbacks = new Map();
    this.nextId = 1;

    // Set up the global message listener to route responses back to their respective promises
    this.worker.onmessage = (event: MessageEvent) => {
      const { taskId, success, result, error } = event.data;
      const callback = this.callbacks.get(taskId);

      if (callback) {
        if (success) {
          callback.resolve(result);
        } else {
          callback.reject(new Error(error));
        }
        this.callbacks.delete(taskId);
      }
    };
  }

  /**
   * Dispatches a heavy payload to the background worker thread.
   * Keeps the main UI thread completely unblocked.
   */
  public executeHeavyComputation(payload: Float64Array): Promise<number> {
    return new Promise((resolve, reject) => {
      const taskId = `task_${this.nextId++}`;
      this.callbacks.set(taskId, { resolve, reject });

      // Post the message to the Web Worker thread
      this.worker.postMessage({ taskId, payload });
    });
  }

  public terminate(): void {
    this.worker.terminate();
    this.callbacks.clear();
  }
}
