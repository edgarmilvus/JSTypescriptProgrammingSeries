/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// FILE: analytics.worker.ts (Web Worker Implementation)
// ============================================================================

/**
 * Interface representing the incoming payload from the main UI thread.
 */
interface WorkerInputPayload {
    taskId: string;
    dataPoints: number[];
}

/**
 * Interface representing the outgoing payload returned to the main UI thread.
 */
interface WorkerOutputPayload {
    taskId: string;
    average: number;
    processedCount: number;
}

// Listen for messages dispatched from the main UI thread via postMessage
self.onmessage = (event: MessageEvent<WorkerInputPayload>) => {
    const { taskId, dataPoints } = event.data;

    // Guard clause to ensure valid telemetry payload exists
    if (!dataPoints || dataPoints.length === 0) {
        self.postMessage({
            taskId,
            average: 0,
            processedCount: 0
        } as WorkerOutputPayload);
        return;
    }

    // Perform CPU-intensive calculation (simulating heavy data processing loop)
    let sum = 0;
    for (let i = 0; i < dataPoints.length; i++) {
        sum += dataPoints[i];
    }

    const average = sum / dataPoints.length;

    // Package the results and send them back across the thread boundary
    const response: WorkerOutputPayload = {
        taskId,
        average,
        processedCount: dataPoints.length
    };

    // Post the computed result back to the main thread
    self.postMessage(response);
};


// ============================================================================
// FILE: main.ts (Main UI Thread Implementation)
// ============================================================================

/**
 * Initializes the Web Worker and orchestrates non-blocking telemetry computation.
 */
function initializeAnalyticsProcessor(): void {
    // 1. Instantiate the Web Worker using Vite's native worker import syntax.
    // In Tauri 2.0, Vite compiles this into a separate worker bundle automatically.
    const analyticsWorker = new Worker(
        new URL('./analytics.worker.ts', import.meta.url),
        { type: 'module' }
    );

    // 2. Define a map or tracking mechanism for pending asynchronous tasks.
    // This allows us to resolve Promises when the worker responds asynchronously.
    const pendingTasks = new Map<string, { resolve: (val: number) => void; reject: (err: Error) => void }>();

    // 3. Register the global message listener on the worker instance to catch responses.
    analyticsWorker.onmessage = (event: MessageEvent<WorkerOutputPayload>) => {
        const { taskId, average, processedCount } = event.data;

        // Retrieve the promise resolver associated with this specific task ID
        const task = pendingTasks.get(taskId);
        if (task) {
            console.log(`[UI Thread] Successfully processed ${processedCount} data points in background worker.`);
            task.resolve(average);
            pendingTasks.delete(taskId);
        }
    };

    // 4. Register an error handler to catch unhandled exceptions inside the worker thread.
    analyticsWorker.onerror = (error: ErrorEvent) => {
        console.error('[UI Thread] Error encountered inside Web Worker:', error.message);
        // Clear out pending tasks to avoid memory leaks
        pendingTasks.clear();
    };

    /**
     * 5. Helper function to dispatch work to the worker and return a Promise.
     * This bridges event-driven Web Workers with modern async/await syntax.
     */
    const computeTelemetryAverage = (dataPoints: number[]): Promise<number> => {
        return new Promise((resolve, reject) => {
            // Generate a unique identifier for this computational request
            const taskId = `task_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

            // Store the promise handlers in our tracking map
            pendingTasks.set(taskId, { resolve, reject });

            // Construct the payload matching our WorkerInputPayload interface
            const payload: WorkerInputPayload = {
                taskId,
                dataPoints
            };

            // Dispatch the payload across the thread boundary using structured cloning
            analyticsWorker.postMessage(payload);
        });
    };

    // 6. Simulate triggering this heavy computational task from a UI action (e.g., button click)
    const executeDemoComputation = async () => {
        // Generate an array of 5,000,000 floating-point numbers to simulate heavy analytics
        console.log('[UI Thread] Generating mock telemetry dataset...');
        const heavyDataset: number[] = Array.from({ length: 5000000 }, () => Math.random() * 1000);

        console.log('[UI Thread] Dispatching dataset to Web Worker. Notice UI remains fully responsive...');
        
        try {
            const startTime = performance.now();
            
            // Await the asynchronous calculation performed off the main thread
            const result = await computeTelemetryAverage(heavyDataset);
            
            const endTime = performance.now();
            console.log(`[UI Thread] Computation complete. Result: ${result.toFixed(2)} (Took ${(endTime - startTime).toFixed(2)}ms)`);
        } catch (error) {
            console.error('[UI Thread] Computation failed:', error);
        }
    };

    // Trigger the demo execution immediately upon initialization
    executeDemoComputation();
}

// Execute the initializer
initializeAnalyticsProcessor();
