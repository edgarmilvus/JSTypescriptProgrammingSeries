/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import React, { useEffect, useState, useRef, useCallback } from 'react';

/**
 * Interface representing the analytical payload dispatched to the Web Worker.
 */
interface ComputePayload {
  taskId: string;
  matrixData: Float32Array;
  dimensions: [number, number];
  configuration: {
    useWasmThreads: boolean;
    useWebGpu: boolean;
  };
}

/**
 * Interface representing the structured response from the worker thread.
 */
interface ComputeResult {
  taskId: string;
  success: boolean;
  executionTimeMs: number;
  processedData?: Float32Array;
  error?: string;
}

/**
 * SaaS Desktop Analytics Workspace Component.
 * Integrates Web Workers, SharedArrayBuffer, and Tauri IPC for local hardware-accelerated processing.
 */
export function EnterpriseAnalyticsWorkspace() {
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progressLog, setProgressLog] = useState<string[]>([]);
  const [lastMetrics, setLastMetrics] = useState<string | null>(null);
  
  // Reference to hold the background Web Worker instance
  const workerRef = useRef<Worker | null>(null);
  
  // Shared memory buffer for zero-copy data transfer between main thread and worker
  const sharedBufferRef = useRef<SharedArrayBuffer | null>(null);

  /**
   * Appends an operational log message to the UI console state.
   */
  const logMessage = useCallback((message: string) => {
    setProgressLog((prev) => [...prev, `[${new Date().toISOString()}] ${message}`]);
  }, []);

  /**
   * Initialize the Web Worker and set up message listeners on component mount.
   */
  useEffect(() => {
    logMessage("Initializing enterprise compute worker environment...");

    try {
      // Instantiate the dedicated Web Worker utilizing Vite's worker import syntax
      workerRef.current = new Worker(
        new URL('../workers/compute.worker.ts', import.meta.url),
        { type: 'module' }
      );

      // Handle incoming messages from the compute worker
      workerRef.current.onmessage = (event: MessageEvent<ComputeResult>) => {
        const { taskId, success, executionTimeMs, error } = event.data;
        
        if (success) {
          logMessage(`Task ${taskId} completed successfully in ${executionTimeMs.toFixed(2)}ms.`);
          setLastMetrics(`Completed in ${executionTimeMs.toFixed(2)}ms using localized WASM/WebGPU pipeline.`);
        } else {
          logMessage(`Task ${taskId} failed: ${error}`);
        }
        
        setIsProcessing(false);
      };

      workerRef.current.onerror = (error) => {
        logMessage(`Worker critical fault encountered: ${error.message}`);
        setIsProcessing(false);
      };

      // Listen for system-level hardware events pushed from the Rust core via Tauri IPC
      const unlistenHardware = listen<string>('rust-hardware-alert', (event) => {
        logMessage(`Hardware Telemetry [Rust Core]: ${event.payload}`);
      });

      return () => {
        workerRef.current?.terminate();
        unlistenHardware.then((f) => f());
      };
    } catch (err: any) {
      logMessage(`Failed to initialize worker infrastructure: ${err.message}`);
    }
  }, [logMessage]);

  /**
   * Allocates a SharedArrayBuffer for zero-copy tensor data transmission.
   */
  const handleAllocateSharedMemory = () => {
    try {
      // Allocate 16MB of shared memory suitable for large tensor operations
      const bufferSize = 16 * 1024 * 1024; 
      sharedBufferRef.current = new SharedArrayBuffer(bufferSize);
      logMessage(`Successfully allocated SharedArrayBuffer of size: ${bufferSize / (1024 * 1024)} MB`);
    } catch (err: any) {
      logMessage(`SharedArrayBuffer allocation failed (Check CORS/COOP/COEP headers): ${err.message}`);
    }
  };

  /**
   * Triggers the offloaded compute job by passing data to the Web Worker and syncing with Rust.
   */
  const handleExecuteComputePipeline = async () => {
    if (!workerRef.current) {
      logMessage("Error: Compute worker is not initialized.");
      return;
    }

    setIsProcessing(true);
    logMessage("Initiating heavy computational workload...");

    const taskId = `task_${Date.now()}`;
    const dimensions: [number, number] = [2048, 2048];
    const totalElements = dimensions[0] * dimensions[1];

    // Create a typed array backed by SharedArrayBuffer if available, otherwise fallback to standard heap
    let matrixData: Float32Array;
    if (sharedBufferRef.current) {
      matrixData = new Float32Array(sharedBufferRef.current, 0, totalElements);
    } else {
      matrixData = new Float32Array(totalElements);
    }

    // Populate matrix with dummy high-precision analytical data
    for (let i = 0; i < totalElements; i++) {
      matrixData[i] = Math.sin(i) * Math.cos(i);
    }

    const payload: ComputePayload = {
      taskId,
      matrixData,
      dimensions,
      configuration: {
        useWasmThreads: true,
        useWebGpu: true,
      },
    };

    try {
      // Inform the Tauri Rust backend that local compute has started (for telemetry/fan control)
      await invoke('notify_compute_started', { taskId, elementCount: totalElements });

      // Dispatch payload to Web Worker via structured cloning / transferable objects
      workerRef.current.postMessage(payload, [matrixData.buffer]);
      logMessage(`Dispatched task ${taskId} to background Web Worker thread.`);
    } catch (err: any) {
      logMessage(`Failed to dispatch compute workload to Rust/Worker bridge: ${err.message}`);
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl font-sans">
      <header className="mb-6 border-b border-slate-700 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">Enterprise Analytics Compute Node</h1>
        <p className="text-sm text-slate-400">Tauri 2.0 Multithreaded Web Worker & Rust IPC Workspace</p>
      </header>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <button
          onClick={handleAllocateSharedMemory}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded font-medium transition"
        >
          Initialize Shared Memory
        </button>
        <button
          onClick={handleExecuteComputePipeline}
          disabled={isProcessing}
          className={`px-4 py-2 rounded font-medium transition ${
            isProcessing ? 'bg-slate-600 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-500'
          }`}
        >
          {isProcessing ? 'Processing Compute...' : 'Run Parallel Compute Pipeline'}
        </button>
      </div>

      {lastMetrics && (
        <div className="mb-6 p-4 bg-slate-800 border border-slate-700 rounded text-emerald-400 text-sm">
          <strong>Latest Execution Metrics:</strong> {lastMetrics}
        </div>
      )}

      <div className="bg-slate-950 p-4 rounded border border-slate-800 h-64 overflow-y-auto font-mono text-xs text-slate-300">
        <div className="text-slate-500 mb-2"># System Event Stream & Worker Telemetry</div>
        {progressLog.map((log, index) => (
          <div key={index} className="py-0.5">{log}</div>
        ))}
      </div>
    </div>
  );
}
