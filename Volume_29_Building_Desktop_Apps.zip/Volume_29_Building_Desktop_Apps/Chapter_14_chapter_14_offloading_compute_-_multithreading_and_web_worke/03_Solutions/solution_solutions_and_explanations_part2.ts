/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

use tauri::{AppHandle, Emitter};
use tokio::sync::mpsc;
use tokio::sync::Semaphore;
use std::sync::Arc;

#[derive(serde::Deserialize, Debug)]
pub enum Priority {
    High,
    Normal,
    Low,
}

#[derive(serde::Deserialize, Debug)]
pub struct TaskBatch {
    paths: Vec<String>,
    priority: Priority,
}

#[derive(serde::Serialize, Clone)]
struct ProgressPayload {
    id: String,
    progress: u8,
    result: Option<String>,
}

struct WorkerPool {
    high_tx: mpsc::Sender<(String, Priority)>,
    semaphore: Arc<Semaphore>,
}

impl WorkerPool {
    fn new(app: AppHandle, capacity: usize) -> Self {
        let (high_tx, mut high_rx) = mpsc::channel::<(String, Priority)>(capacity);
        let semaphore = Arc::new(Semaphore::new(capacity));

        // Spawn background worker loop
        tauri::async_runtime::spawn(async move {
            while let Some((path, _priority)) = high_rx.recv().as_mut().await {
                let app_handle = app.clone();
                tokio::spawn(async move {
                    let id = path.clone();
                    // Simulate processing steps with progress updates
                    for p in (10..=100).step_by(20) {
                        tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                        let _ = app_handle.emit("computation-progress", ProgressPayload {
                            id: id.clone(),
                            progress: p as u8,
                            result: None,
                        });
                    }
                });
            }
        });

        Self { high_tx, semaphore }
    }
}

#[taur::command]
async fn enqueue_tasks(
    app: AppHandle,
    batch: TaskBatch,
    pool: tauri::State<'_, WorkerPool>,
) -> Result<(), String> {
    // Acquire permit to respect bounded channel capacity without blocking runtime
    let _permit = pool.semaphore.acquire().await.map_err(|e| e.to_string())?;

    for path in batch.paths {
        pool.high_tx.send((path, batch.priority)).await.map_err(|e| e.to_string())?;
    }

    Ok(())
}
