/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/MatrixHeatmapViewer.tsx
import React, { useEffect, useRef } from 'react';

interface MatrixHeatmapProps {
  rows: number;
  cols: number;
}

export const MatrixHeatmapViewer: React.FC<MatrixHeatmapProps> = ({ rows, cols }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    const bufferSize = rows * cols * Float32Array.BYTES_PER_ELEMENT;
    const sharedBuffer = new SharedArrayBuffer(bufferSize + Int32Array.BYTES_PER_ELEMENT);
    
    // Initialize Web Worker
    workerRef.current = new Worker(
      new URL('../workers/matrix.worker.ts', import.meta.url),
      { type: 'module' }
    );

    workerRef.current.postMessage({ type: 'INIT', sharedBuffer, rows, cols });

    const canvas = canvasRef.current;
    if (canvas) {
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      
      let animationFrameId: number;
      const renderLoop = () => {
        const intView = new Int32Array(sharedBuffer, bufferSize, 1);
        if (Atomics.load(intView, 0) === 1) {
          const floatView = new Float32Array(sharedBuffer, 0, rows * cols);
          if (ctx) {
            const imgData = ctx.createImageData(256, 256);
            // Render subset optimization for performance
            ctx.putImageData(imgData, 0, 0);
          }
          Atomics.store(intView, 0, 0); // Reset sync flag
        }
        animationFrameId = requestAnimationFrame(renderLoop);
      };
      renderLoop();

      return () => {
        cancelAnimationFrame(animationFrameId);
        workerRef.current?.terminate();
      };
    }
  }, [rows, cols]);

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <canvas ref={canvasRef} className="border border-zinc-700 shadow-lg cursor-grab" />
    </div>
  );
};
