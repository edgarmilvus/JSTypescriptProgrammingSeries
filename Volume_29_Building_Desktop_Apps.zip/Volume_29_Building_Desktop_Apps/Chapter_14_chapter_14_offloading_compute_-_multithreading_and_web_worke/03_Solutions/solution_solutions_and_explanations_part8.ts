/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

use tauri::{AppHandle, Emitter};
use tokio::sync::mpsc;

struct DspState {
    tx: mpsc::Sender<Vec<f32>>,
}

pub fn init_dsp_pipeline(app: AppHandle) -> DspState {
    let (tx, mut rx) = mpsc::channel::<Vec<f32>>(100);

    tauri::async_runtime::spawn(async move {
        while let Some(chunk) = rx.recv().await {
            // Apply simulated windowing and FFT transformation
            let mut fft_bins: Vec<f32> = chunk.iter().map(|v| v.abs()).collect();
            fft_bins.truncate(128); // Standard visualization bin size

            let _ = app.emit("fft-data", fft_bins);
        }
    });

    DspState { tx }
}

#[tauri::command]
async fn process_audio_chunk(
    data: Vec<f32>,
    state: tauri::State<'_, DspState>,
) -> Result<(), String> {
    // Drop frames if backpressure limit is reached to prevent latency spikes
    match state.tx.try_send(data) {
        Ok(_) => Ok(()),
        Err(tokio::sync::mpsc::error::TrySendError::Full(_)) => {
            // Frame dropped for performance preservation
            Ok(())
        }
        Err(e) => Err(e.to_string()),
    }
}
