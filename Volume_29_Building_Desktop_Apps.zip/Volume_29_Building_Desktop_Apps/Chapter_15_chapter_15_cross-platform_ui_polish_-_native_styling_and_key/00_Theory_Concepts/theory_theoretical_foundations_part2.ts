/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

/* src/styles/platform-polish.css */

/* Base reset for desktop application viewports */
* {
  box-sizing: border-box;
  user-select: none;
  cursor: default;
}

input, textarea, [contenteditable="true"] {
  user-select: text;
  cursor: text;
}

/* macOS Specific Polish */
html[data-platform="macos"] body {
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Icons", "Helvetica Neue", Helvetica, Arial, sans-serif;
  letter-spacing: -0.01em;
  background-color: rgba(246, 246, 246, 0.85);
  backdrop-filter: blur(20px);
}

/* Windows Specific Polish */
html[data-platform="windows"] body {
  font-family: "Segoe UI Variable", "Segoe UI",-apple-system, BlinkMacSystemFont, sans-serif;
  letter-spacing: 0em;
  background-color: #f3f3f3;
}

/* Linux Specific Polish */
html[data-platform="linux"] body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background-color: #1e1e2e;
  color: #cdd6f4;
}

/* Custom Draggable Region for Frameless Windows */
.tauri-drag-region {
  app-region: drag;
  -webkit-app-region: drag;
}

.tauri-no-drag {
  app-region: no-drag;
  -webkit-app-region: no-drag;
}
