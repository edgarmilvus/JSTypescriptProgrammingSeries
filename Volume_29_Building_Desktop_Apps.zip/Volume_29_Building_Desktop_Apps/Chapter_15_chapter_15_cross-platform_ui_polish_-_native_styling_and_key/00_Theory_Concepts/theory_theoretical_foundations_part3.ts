/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// src/services/shortcutManager.ts
type ShortcutCallback = (event: KeyboardEvent) => void;

interface ShortcutRegistration {
  key: string;
  ctrl?: boolean;
  meta?: boolean;
  shift?: boolean;
  alt?: boolean;
  callback: ShortcutCallback;
  description: string;
}

class KeyboardShortcutManager {
  private static instance: KeyboardShortcutManager;
  private registeredShortcuts: Map<string, ShortcutRegistration> = new Map();
  private isListening: boolean = false;

  private constructor() {}

  public static getInstance(): KeyboardShortcutManager {
    if (!KeyboardShortcutManager.instance) {
      KeyboardShortcutManager.instance = new KeyboardShortcutManager();
    }
    return KeyboardShortcutManager.instance;
  }

  public init(): void {
    if (this.isListening) return;
    
    window.addEventListener('keydown', (event: KeyboardEvent) => {
      this.handleKeyDown(event);
    });

    this.isListening = true;
    console.log('[ShortcutManager] Local keyboard shortcut listener initialized.');
  }

  public register(id: string, registration: ShortcutRegistration): void {
    this.registeredShortcuts.set(id, registration);
  }

  public unregister(id: string): void {
    this.registeredShortcuts.delete(id);
  }

  private handleKeyDown(event: KeyboardEvent): void {
    // Do not trigger shortcuts if user is typing inside an input or textarea
    const target = event.target as HTMLElement;
    if (
      target && 
      (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)
    ) {
      // Allow specific escape or save overrides if necessary
      if (event.key !== 'Escape') {
        return;
      }
    }

    for (const [id, shortcut] of this.registeredShortcuts.entries()) {
      const matchesKey = event.key.toLowerCase() === shortcut.key.toLowerCase();
      const matchesCtrl = !!shortcut.ctrl === (event.ctrlKey || event.metaKey); // Handle Cmd on Mac as Ctrl equivalent if desired
      const matchesShift = !!shortcut.shift === event.shiftKey;
      const matchesAlt = !!shortcut.alt === event.altKey;

      if (matchesKey && matchesCtrl && matchesShift && matchesAlt) {
        event.preventDefault();
        try {
          shortcut.callback(event);
          console.debug(`[ShortcutManager] Triggered local shortcut: ${id}`);
        } catch (err) {
          console.error(`[ShortcutManager] Error executing shortcut callback for ${id}:`, err);
        }
        break;
      }
    }
  }
}

export const shortcutManager = KeyboardShortcutManager.getInstance();
