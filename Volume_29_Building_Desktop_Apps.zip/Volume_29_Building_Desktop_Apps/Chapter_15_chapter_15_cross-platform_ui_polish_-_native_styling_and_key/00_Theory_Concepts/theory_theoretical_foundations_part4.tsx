/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.tsx
// Description: Theoretical Foundations
// ==========================================

// src/components/CommandPaletteController.tsx
import React, { useEffect, useState } from 'react';
import { shortcutManager } from '../services/shortcutManager';

export const CommandPaletteController: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Initialize global keyboard manager
    shortcutManager.init();

    // Register local shortcut: Ctrl+K or Cmd+K
    shortcutManager.register('open-command-palette', {
      key: 'k',
      ctrl: true,
      description: 'Open Command Palette',
      callback: () => {
        setIsOpen((prev) => !prev);
      },
    });

    // Register local shortcut: Escape to close
    shortcutManager.register('close-modals', {
      key: 'Escape',
      description: 'Close active modal or palette',
      callback: () => {
        setIsOpen(false);
      },
    });

    return () => {
      shortcutManager.unregister('open-command-palette');
      shortcutManager.unregister('close-modals');
    };
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 tauri-no-drag">
      <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-2xl w-full max-w-xl p-4 border border-zinc-200 dark:border-zinc-800">
        <h2 className="text-lg font-semibold text-zinc-800 dark:text-zinc-100 mb-3">
          Developer Tool Command Palette
        </h2>
        <input 
          type="text" 
          placeholder="Type a command or search files..." 
          className="w-full px-3 py-2 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          autoFocus
        />
        <div className="mt-3 text-xs text-zinc-500 dark:text-zinc-400 flex justify-between">
          <span>Press ESC to dismiss</span>
          <span>Tauri 2.0 UI Polish</span>
        </div>
      </div>
    </div>
  );
};
