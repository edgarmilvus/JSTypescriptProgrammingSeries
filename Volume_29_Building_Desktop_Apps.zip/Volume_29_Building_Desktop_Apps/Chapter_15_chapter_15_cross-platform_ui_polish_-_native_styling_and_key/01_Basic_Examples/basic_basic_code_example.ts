/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file app.ts
 * @description Demonstrates cross-platform UI initialization, dynamic OS detection 
 * for native styling injection, and keyboard shortcut binding within a Tauri 2.0 application.
 */

import { invoke } from '@tauri-apps/api/core';
import { register, unregister } from '@tauri-apps/plugin-global-shortcut';

/**
 * Interface representing the current operating system environment details
 * retrieved from the Rust backend via Tauri commands.
 */
interface SystemEnvironment {
  osName: 'macos' | 'windows' | 'linux';
  osVersion: string;
}

/**
 * Applies platform-specific CSS classes to the document root element
 * to allow native-looking typography, window controls, and scrollbars.
 * 
 * @param env - The system environment object containing the OS name.
 */
function applyPlatformStyles(env: SystemEnvironment): void {
  const rootElement = document.documentElement;
  
  // Remove any legacy platform markers
  rootElement.classList.remove('platform-macos', 'platform-windows', 'platform-linux');

  // Inject the precise platform class for scoped CSS rules
  rootElement.classList.add(`platform-${env.osName}`);

  console.info(`[Tauri UI Polish] Applied styling rules for: ${env.osName} (${env.osVersion})`);
}

/**
 * Initializes global and local keyboard shortcut listeners.
 * Binds `Cmd+Shift+P` (macOS) or `Ctrl+Shift+P` (Windows/Linux) to trigger a command palette.
 */
async function initializeShortcuts(): Promise<void> {
  const shortcutKey = 'CommandOrControl+Shift+P';

  try {
    // Register a global system-wide shortcut using the Tauri v2 plugin
    await register(shortcutKey, (event) => {
      if (event.state === 'Pressed') {
        console.log(`[Shortcut Plugin] Global shortcut triggered: ${shortcutKey}`);
        triggerCommandPalette();
      }
    });

    console.info(`[Shortcut Plugin] Successfully registered global shortcut: ${shortcutKey}`);
  } catch (error) {
    console.error('[Shortcut Plugin] Failed to register global shortcut. Falling back to local listener:', error);
    setupLocalFallbackShortcut();
  }
}

/**
 * Triggers the application's command palette view state.
 */
function triggerCommandPalette(): void {
  const palette = document.getElementById('command-palette');
  if (palette) {
    palette.classList.toggle('hidden');
    const inputField = palette.querySelector('input');
    if (inputField) {
      inputField.focus();
    }
  }
}

/**
 * Fallback local keyboard event listener for standard web-view scoped shortcuts.
 */
function setupLocalFallbackShortcut(): void {
  window.addEventListener('keydown', (keyboardEvent: KeyboardEvent) => {
    // Check for Cmd+Shift+P or Ctrl+Shift+P locally
    const isMacModifier = keyboardEvent.metaKey && keyboardEvent.shiftKey;
    const isWinLinModifier = keyboardEvent.ctrlKey && keyboardEvent.shiftKey;

    if ((isMacModifier || isWinLinModifier) && keyboardEvent.key.toLowerCase() === 'p') {
      keyboardEvent.preventDefault();
      console.log('[DOM Event] Local fallback shortcut triggered.');
      triggerCommandPalette();
    }
  });
}

/**
 * Main application bootstrapping routine.
 */
async function bootstrapApp(): Promise<void> {
  try {
    // Step 1: Query the Rust backend for operating system metadata
    const systemEnv = await invoke<SystemEnvironment>('get_system_environment');

    // Step 2: Apply OS-specific styling classes to the DOM
    applyPlatformStyles(systemEnv);

    // Step 3: Register application keyboard shortcuts
    await initializeShortcuts();

    // Step 4: Render initial UI components
    renderShell();
  } catch (err) {
    console.error('[Bootstrap Error] Failed to initialize Tauri UI polish layer:', err);
  }
}

/**
 * Renders the structural SaaS developer tool shell into the DOM.
 */
function renderShell(): void {
  const appContainer = document.getElementById('app');
  if (!appContainer) return;

  appContainer.innerHTML = `
    <div class="devtool-shell">
      <header class="titlebar-drag-region">
        <div class="window-controls-spacer"></div>
        <span class="app-title">Tauri DevTools 2.0</span>
      </header>
      <main class="content-body">
        <h1>Cross-Platform UI Polish Active</h1>
        <p>Press <kbd>Cmd/Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>P</kbd> to open the command palette.</p>
      </main>
      <div id="command-palette" class="command-palette hidden">
        <input type="text" placeholder="Type a command or search workspace..." />
      </div>
    </div>
  `;
}

// Execute bootstrap when DOM is fully parsed
document.addEventListener('DOMContentLoaded', () => {
  bootstrapApp();
});
