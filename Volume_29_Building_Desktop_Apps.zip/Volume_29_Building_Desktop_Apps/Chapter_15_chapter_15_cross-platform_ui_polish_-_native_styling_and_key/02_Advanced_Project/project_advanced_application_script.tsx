/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { useEffect, useState, useCallback } from 'react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { register, unregisterAll } from '@tauri-apps/plugin-shortcut';
import { invoke } from '@tauri-apps/api/core';

/**
 * Interface representing the application's global configuration state.
 */
interface AppConfig {
  theme: 'dark' | 'light' | 'system';
  isDecorated: boolean;
  shortcutEnabled: boolean;
  activeWorkspace: string;
}

/**
 * Interface for system diagnostic telemetry metrics.
 */
interface SystemTelemetry {
  cpuUsage: number;
  memoryUsage: number;
  activeThreads: number;
}

/**
 * Advanced Tauri 2.0 Desktop Orchestration Hook and Component.
 * Manages native window styling, platform-aware keyboard shortcuts, and telemetry state.
 */
export default function AdvancedDesktopDashboard() {
  const [config, setConfig] = useState<AppConfig>({
    theme: 'dark',
    isDecorated: false,
    shortcutEnabled: true,
    activeWorkspace: 'Default-Workspace',
  });

  const [telemetry, setTelemetry] = useState<SystemTelemetry>({
    cpuUsage: 0.0,
    memoryUsage: 0.0,
    activeThreads: 0,
  });

  const [statusMessage, setStatusMessage] = useState<string>('Initializing system...');

  /**
   * Applies platform-specific CSS variables and window styling attributes.
   * Handles macOS traffic light positioning and Windows/Linux frameless borders.
   */
  const applyPlatformStyles = useCallback(async () => {
    try {
      const appWindow = getCurrentWindow();
      const platform = await invoke<string>('get_operating_system_type');

      if (platform === 'macos') {
        // macOS specific adjustment for hidden titlebar with visible traffic lights
        document.documentElement.style.setProperty('--window-titlebar-height', '28px');
        await appWindow.setDecorations(true);
      } else {
        // Windows and Linux custom frameless decoration handling
        document.documentElement.style.setProperty('--window-titlebar-height', '32px');
        await appWindow.setDecorations(config.isDecorated);
      }

      setStatusMessage(`Platform styling applied for: ${platform}`);
    } catch (error) {
      console.error('Failed to apply platform styling:', error);
      setStatusMessage('Error applying window decorations.');
    }
  }, [config.isDecorated]);

  /**
   * Registers global keyboard shortcuts using the Tauri 2.0 plugin ecosystem.
   * Binds system-wide accelerators for quick command palette invocation.
   */
  const setupGlobalShortcuts = useCallback(async () => {
    if (!config.shortcutEnabled) return;

    try {
      // Clear existing shortcuts to prevent duplicate registration collisions
      await unregisterAll();

      // Register Command+Shift+P (macOS) or Ctrl+Shift+P (Windows/Linux) for Command Palette
      await register('CommandOrControl+Shift+P', async (event) => {
        if (event.state === 'Pressed') {
          console.log('Global shortcut triggered: Command Palette opened.');
          setStatusMessage('Command Palette invoked via global shortcut.');
          // Trigger backend state mutation via Tauri invoke
          await invoke('toggle_command_palette');
        }
      });

      // Register shortcut to toggle window pinning (always-on-top)
      await register('CommandOrControl+Alt+T', async (event) => {
        if (event.state === 'Pressed') {
          const appWindow = getCurrentWindow();
          const isAlwaysOnTop = await appWindow.isAlwaysOnTop();
          await appWindow.setAlwaysOnTop(!isAlwaysOnTop);
          setStatusMessage(`Window always-on-top set to: ${!isAlwaysOnTop}`);
        }
      });

      setStatusMessage('Global keyboard shortcuts successfully registered.');
    } catch (error) {
      console.error('Shortcut registration failed:', error);
      setStatusMessage('Failed to register global shortcuts. Check system permissions.');
    }
  }, [config.shortcutEnabled]);

  /**
   * Initializes background telemetry polling loop via Tauri backend commands.
   */
  useEffect(() => {
    let isMounted = true;

    applyPlatformStyles();
    setupGlobalShortcuts();

    const telemetryInterval = setInterval(async () => {
      try {
        // Fetch raw system metrics from the Rust core layer
        const metrics = await invoke<SystemTelemetry>('fetch_system_telemetry');
        if (isMounted) {
          setTelemetry(metrics);
        }
      } catch (error) {
        console.error('Telemetry fetch error:', error);
      }
    }, 2000);

    // Cleanup listeners and intervals on component unmount
    return () => {
      isMounted = false;
      clearInterval(telemetryInterval);
      unregisterAll().catch(console.error);
    };
  }, [applyPlatformStyles, setupGlobalShortcuts]);

  return (
    <div className={`app-container ${config.theme}`}>
      <header className="window-titlebar" data-tauri-drag-region>
        <div className="titlebar-drag-region">
          <span className="app-title">Enterprise Developer Console</span>
        </div>
        <div className="window-controls">
          <button 
            onClick={() => setConfig(prev => ({ ...prev, isDecorated: !prev.isDecorated }))}
            className="control-btn"
            title="Toggle Window Decorations"
          >
            ⚙️
          </button>
        </div>
      </header>

      <main className="dashboard-content">
        <section className="telemetry-panel">
          <h2>System Telemetry</h2>
          <div className="metric-card">
            <span>CPU Usage:</span>
            <strong>{telemetry.cpuUsage.toFixed(1)}%</strong>
          </div>
          <div className="metric-card">
            <span>Memory Usage:</span>
            <strong>{telemetry.memoryUsage.toFixed(1)} MB</strong>
          </div>
          <div className="metric-card">
            <span>Active Threads:</span>
            <strong>{telemetry.activeThreads}</strong>
          </div>
        </section>

        <section className="status-footer">
          <p><strong>System Status:</strong> {statusMessage}</p>
        </section>
      </main>
    </div>
  );
}
