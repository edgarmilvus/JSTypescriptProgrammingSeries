/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { platform } from '@tauri-apps/plugin-os';

interface CustomTitleBarProps {
  title: string;
}

export const CustomTitleBar: React.FC<CustomTitleBarProps> = ({ title }) => {
  const [currentPlatform, setCurrentPlatform] = useState<string>('');
  const [isMaximized, setIsMaximized] = useState<boolean>(false);
  const appWindow = getCurrentWindow();

  useEffect(() => {
    let unlistenResize: (() => void) | undefined;

    async function initWindow() {
      try {
        const currentOS = platform();
        setCurrentPlatform(currentOS);

        const maximized = await appWindow.isMaximized();
        setIsMaximized(maximized);

        unlistenResize = await appWindow.onResized(async () => {
          const maximizedState = await appWindow.isMaximized();
          setIsMaximized(maximizedState);
        });
      } catch (error) {
        console.error('Failed to initialize window state:', error);
      }
    }

    initWindow();

    return () => {
      if (unlistenResize) {
        unlistenResize();
      }
    };
  }, [appWindow]);

  const handleMinimize = () => appWindow.minimize();
  const handleMaximize = async () => {
    await appWindow.toggleMaximize();
    setIsMaximized(await appWindow.isMaximized());
  };
  const handleClose = () => appWindow.close();

  return (
    <div 
      data-tauri-drag-region 
      className={`titlebar ${currentPlatform} ${isMaximized ? 'maximized' : ''}`}
      style={{
        display: 'flex',
        height: '40px',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: currentPlatform === 'macos' && !isMaximized ? '80px' : '12px',
        paddingRight: '12px',
        borderRadius: isMaximized ? '0px' : '8px 8px 0 0',
        userSelect: 'none',
        WebkitUserSelect: 'none'
      }}
    >
      <div 
        className="titlebar-title" 
        data-tauri-drag-region
        style={{ flexGrow: 1, fontSize: '14px', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
      >
        {title}
      </div>
      <div 
        className="titlebar-controls" 
        style={{ display: 'flex', gap: '8px' }}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={handleMinimize} aria-label="Minimize">🗕</button>
        <button onClick={handleMaximize} aria-label="Maximize">🗖</button>
        <button onClick={handleClose} aria-label="Close">✕</button>
      </div>
    </div>
  );
};
