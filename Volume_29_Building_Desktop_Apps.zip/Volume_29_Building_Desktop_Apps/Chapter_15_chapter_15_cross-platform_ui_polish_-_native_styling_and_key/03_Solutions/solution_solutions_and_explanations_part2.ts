/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { register, unregister, isRegistered } from '@tauri-apps/plugin-global-shortcut';

export class ShortcutManager {
  private activeShortcuts: Set<string> = new Set();

  async registerGlobal(shortcutString: string, callback: () => void): Promise<void> {
    try {
      const alreadyRegistered = await isRegistered(shortcutString);
      if (alreadyRegistered) {
        await this.unregisterGlobal(shortcutString);
      }

      await register(shortcutString, (event) => {
        if (event.state === 'Pressed') {
          callback();
        }
      });

      this.activeShortcuts.add(shortcutString);
    } catch (error) {
      console.error(`Failed to register global shortcut ${shortcutString}:`, error);
      throw error;
    }
  }

  async unregisterGlobal(shortcutString: string): Promise<void> {
    try {
      const registered = await isRegistered(shortcutString);
      if (registered) {
        await unregister(shortcutString);
      }
      this.activeShortcuts.delete(shortcutString);
    } catch (error) {
      console.error(`Failed to unregister global shortcut ${shortcutString}:`, error);
    }
  }

  async cleanupAll(): Promise<void> {
    for (const shortcut of this.activeShortcuts) {
      await this.unregisterGlobal(shortcut);
    }
  }

  async handleUserKeyCapture(event: KeyboardEvent): Promise<string | null> {
    const modifiers: string[] = [];
    
    if (event.ctrlKey) modifiers.push('Ctrl');
    if (event.altKey) modifiers.push('Alt');
    if (event.shiftKey) modifiers.push('Shift');
    if (event.metaKey) modifiers.push('Command');

    const key = event.key.toUpperCase();
    
    // Ensure the key isn't just a modifier itself and requires at least one modifier
    const isModifierKey = ['CONTROL', 'ALT', 'SHIFT', 'META'].includes(key);
    if (modifiers.length === 0 || isModifierKey) {
      return null;
    }

    const formattedKey = key.length === 1 ? key : key;
    return [...modifiers, formattedKey].join('+');
  }
}
