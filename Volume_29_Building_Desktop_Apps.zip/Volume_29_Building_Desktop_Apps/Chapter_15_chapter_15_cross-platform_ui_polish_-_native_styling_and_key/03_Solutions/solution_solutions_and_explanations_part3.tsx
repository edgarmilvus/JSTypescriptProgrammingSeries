/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, MouseEvent } from 'react';
import { Menu, MenuItem } from '@tauri-apps/api/menu';

export interface ContextMenuItem {
  id: string;
  label: string;
  enabled?: boolean;
  action?: () => void | Promise<void>;
  subItems?: ContextMenuItem[];
}

interface NativeContextMenuProps {
  items: ContextMenuItem[];
  children: React.ReactNode;
  onAsyncCheckGitStatus?: () => Promise<string>;
}

export const NativeContextMenu: React.FC<NativeContextMenuProps> = ({ 
  items, 
  children,
  onAsyncCheckGitStatus 
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [dynamicItems, setDynamicItems] = useState<ContextMenuItem[]>(items);

  const handleContextMenu = async (e: MouseEvent<HTMLDivElement>) => {
    e.preventDefault();

    try {
      let currentItems = items;

      if (onAsyncCheckGitStatus) {
        setIsLoading(true);
        const statusLabel = await onAsyncCheckGitStatus();
        currentItems = items.map(item => 
          item.id === 'git-status' ? { ...item, label: statusLabel } : item
        );
        setDynamicItems(currentItems);
        setIsLoading(false);
      }

      const menuItems = await Promise.all(
        currentItems.map(async (item) => {
          return await MenuItem.new({
            id: item.id,
            text: item.label,
            enabled: item.enabled ?? true,
            action: async () => {
              if (item.action) await item.action();
            }
          });
        })
      );

      const menu = await Menu.new({
        items: menuItems,
      });

      await menu.popup();
    } catch (error) {
      console.error('Failed to display native context menu:', error);
      setIsLoading(false);
    }
  };

  return (
    <div onContextMenu={handleContextMenu} className="context-menu-wrapper" style={{ position: 'relative' }}>
      {children}
      {isLoading && (
        <div className="menu-loader" style={{ position: 'absolute', bottom: 0, right: 0, background: 'rgba(0,0,0,0.7)', color: '#fff', padding: '4px 8px', fontSize: '12px' }}>
          Checking Git status...
        </div>
      )}
    </div>
  );
};
