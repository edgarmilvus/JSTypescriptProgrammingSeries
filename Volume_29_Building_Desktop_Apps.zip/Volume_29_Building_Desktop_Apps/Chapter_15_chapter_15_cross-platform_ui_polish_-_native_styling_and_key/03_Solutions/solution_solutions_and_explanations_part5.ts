/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { getCurrentWindow, LogicalPosition, LogicalSize } from '@tauri-apps/api/window';
import { availableMonitors, currentMonitor } from '@tauri-apps/api/window';

interface WindowState {
  x: number;
  y: number;
  width: number;
  height: number;
  isMaximized: boolean;
}

export class WindowPersistenceManager {
  private appWindow = getCurrentWindow();
  private storageKey = 'tauri_window_state';

  async saveState(): Promise<void> {
    try {
      const isMaximized = await this.appWindow.isMaximized();
      const position = await this.appWindow.outerPosition();
      const size = await this.appWindow.outerSize();

      const state: WindowState = {
        x: position.x,
        y: position.y,
        width: size.width,
        height: size.height,
        isMaximized,
      };

      localStorage.setItem(this.storageKey, JSON.stringify(state));
    } catch (error) {
      console.error('Failed to save window state:', error);
    }
  }

  async restoreState(): Promise<void> {
    try {
      const storedState = localStorage.getItem(this.storageKey);
      if (!storedState) return;

      const state: WindowState = JSON.parse(storedState);
      const monitors = await availableMonitors();

      // Bounds checking against available displays to avoid off-screen positioning
      const isVisible = monitors.some(monitor => {
        const { x, y, width, height } = monitor.size;
        return (
          state.x >= x &&
          state.x < x + width &&
          state.y >= y &&
          state.y < y + height
        );
      });

      if (isVisible) {
        await this.appWindow.setPosition(new LogicalPosition(state.x, state.y));
        await this.appWindow.setSize(new LogicalSize(state.width, state.height));
      }

      if (state.isMaximized) {
        await this.appWindow.maximize();
      }
    } catch (error) {
      console.error('Failed to restore window state:', error);
    }
  }

  async monitorDpiCheck(): Promise<number> {
    try {
      const monitor = await currentMonitor();
      const scaleFactor = monitor ? monitor.scaleFactor : 1.0;

      const rootElement = document.documentElement;
      rootElement.classList.remove('high-dpi-scaling-2x', 'standard-dpi');

      if (scaleFactor >= 2.0) {
        rootElement.classList.add('high-dpi-scaling-2x');
      } else {
        rootElement.classList.add('standard-dpi');
      }

      return scaleFactor;
    } catch (error) {
      console.error('Failed to execute monitor DPI check:', error);
      return 1.0;
    }
  }
}
