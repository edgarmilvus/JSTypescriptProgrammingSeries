/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Interactive Challenge Starter Code: VirtualLogViewer.tsx
import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';

interface LogItem {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error';
  message: string;
}

interface VirtualLogViewerProps {
  logs: LogItem[];
  rowHeight: number;
  viewportHeight: number;
}

export const VirtualLogViewer: React.FC<VirtualLogViewerProps> = ({
  logs,
  rowHeight,
  viewportHeight,
}) => {
  const [scrollTop, setScrollTop] = useState<number>(0);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [filterQuery, setFilterQuery] = useState<string>('');
  const containerRef = useRef<HTMLDivElement>(null);

  // TODO: Filter logs based on filterQuery efficiently
  const filteredLogs = logs;

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    // TODO: Implement arrow key navigation, Home, End, and Enter selection
  };

  const totalHeight = filteredLogs.length * rowHeight;
  const startIndex = Math.max(0, Math.floor(scrollTop / rowHeight) - 2);
  const endIndex = Math.min(
    filteredLogs.length,
    Math.ceil((scrollTop + viewportHeight) / rowHeight) + 2
  );
  const visibleLogs = filteredLogs.slice(startIndex, endIndex);

  return (
    <div className="virtual-log-container">
      <input
        type="text"
        placeholder="Filter logs..."
        value={filterQuery}
        onChange={(e) => setFilterQuery(e.target.value)}
        className="log-filter-input"
      />
      <div
        ref={containerRef}
        tabIndex={0}
        role="feed"
        aria-busy={false}
        aria-live="polite"
        onScroll={handleScroll}
        onKeyDown={handleKeyDown}
        style={{ height: viewportHeight, overflowY: 'auto', position: 'relative' }}
        className="virtual-scroll-viewport"
      >
        <div style={{ height: totalHeight, width: '100%', position: 'relative' }}>
          <div
            style={{
              transform: `translateY(${startIndex * rowHeight}px)`,
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
            }}
          >
            {visibleLogs.map((log, index) => {
              const actualIndex = startIndex + index;
              const isSelected = actualIndex === selectedIndex;
              return (
                <div
                  key={log.id}
                  role="article"
                  aria-selected={isSelected}
                  style={{ height: rowHeight }}
                  className={`log-row ${log.level} ${isSelected ? 'selected' : ''}`}
                >
                  <span className="log-time">[{log.timestamp}]</span>
                  <span className="log-msg">{log.message}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
