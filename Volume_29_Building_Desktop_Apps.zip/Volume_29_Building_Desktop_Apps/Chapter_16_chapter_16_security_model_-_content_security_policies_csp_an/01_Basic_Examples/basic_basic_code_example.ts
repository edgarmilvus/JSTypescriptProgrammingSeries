/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file secure-saas-bridge.ts
 * @description Production-grade TypeScript module for a SaaS desktop client 
 * enforcing strict CSP constraints and safe Tauri 2.0 IPC communication.
 */

import { invoke } from '@tauri-apps/api/core';
import { listen, UnlistenFn } from '@tauri-apps/api/event';

/**
 * Interface representing a sanitized user telemetry payload 
 * received from the Rust backend via restricted IPC channels.
 */
interface TelemetryPayload {
  userId: string;
  activeSessionTime: number;
  featureFlagHash: string;
}

/**
 * Interface representing incoming system status updates.
 */
interface SystemStatusEvent {
  status: 'nominal' | 'degraded' | 'critical';
  timestamp: number;
}

/**
 * Validates whether an incoming payload conforms to the expected TelemetryPayload structure.
 * This mitigates prototype pollution and injection attacks from compromised web views.
 * 
 * @param data - Unknown input data from the IPC boundary.
 * @returns boolean indicating structural validity.
 */
function isValidTelemetryPayload(data: unknown): data is TelemetryPayload {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const record = data as Record<string, unknown>;
  
  return (
    typeof record.userId === 'string' &&
    record.userId.length > 0 &&
    typeof record.activeSessionTime === 'number' &&
    Number.isFinite(record.activeSessionTime) &&
    typeof record.featureFlagHash === 'string'
  );
}

/**
 * Safely requests encrypted user session credentials from the Rust backend.
 * Uses Tauri 2.0 capability-scoped command invocation.
 * 
 * @param tenantId - The current SaaS organization tenant identifier.
 * @returns Promise resolving to the session token or rejecting on security failure.
 */
export async function fetchEncryptedSessionToken(tenantId: string): Promise<string> {
  // Defensive input sanitization before crossing the IPC boundary
  if (!/^[a-zA-Z0-9_-]{3,64}$/.test(tenantId)) {
    throw new Error('Security Error: Invalid tenant identifier format detected.');
  }

  try {
    // Invoke the Rust backend command 'get_secure_token' restricted by capability permissions
    const token = await invoke<string>('get_secure_token', { tenantId });
    
    if (typeof token !== 'string' || token.length === 0) {
      throw new Error('Security Error: Malformed token received from backend.');
    }

    return token;
  } catch (error) {
    // Log securely without leaking sensitive error stacks to the DOM
    console.error('[Tauri Security Layer] Failed to retrieve session token:', error);
    throw new Error('Authentication handshake failed.');
  }
}

/**
 * Initializes secure event listeners for system status broadcasts from the Rust core.
 * Ensures that all incoming event payloads pass strict structural validation.
 * 
 * @param onStatusChange - Callback function executed upon receiving a validated status update.
 * @returns Promise resolving to an unlisten function for cleanup.
 */
export async function registerSystemStatusListener(
  onStatusChange: (status: SystemStatusEvent) => void
): Promise<UnlistenFn> {
  // Listen to the 'tauri://system-status' event channel restricted by capabilities
  const unlisten = await listen<unknown>('tauri://system-status', (event) => {
    const payload = event.payload;

    // Runtime type validation of the event payload
    if (
      typeof payload === 'object' &&
      payload !== null &&
      'status' in payload &&
      'timestamp' in payload
    ) {
      const typedPayload = payload as SystemStatusEvent;
      
      if (['nominal', 'degraded', 'critical'].includes(typedPayload.status)) {
        onStatusChange(typedPayload);
        return;
      }
    }

    console.warn('[Tauri Security Layer] Dropped malformed or unauthorized system status event.');
  });

  return unlisten;
}
