/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { emit, listen } from '@tauri-apps/api/event';

interface SandboxPayload {
  htmlContent: string;
  nonce: string;
}

/**
 * Safely sends raw preview content to the sandboxed preview window 
 * using Tauri's event-emitting API with input sanitization.
 */
export async function sendToSandbox(htmlContent: string): Promise<void> {
  // Basic input validation/sanitization layer to prevent injection exploits
  if (typeof htmlContent !== 'string' || htmlContent.length > 500000) {
    throw new Error('Invalid payload: Content must be a string under 500KB.');
  }

  // Generate a cryptographically secure nonce for message integrity
  const nonce = crypto.randomUUID();

  const payload: SandboxPayload = {
    htmlContent,
    nonce,
  };

  // Emit event specifically targeting the isolated preview window channel
  await emit('tauri://sandbox-preview-sync', payload);
}
