/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

use tauri::{AppHandle, Manager};
use std::path::{Path, PathBuf};

#[tauri::command]
pub async fn secure_read_file(
    app: AppHandle,
    filename: String,
) -> Result<String, String> {
    // 1. Resolve base app data directory safely using Tauri's path API
    let app_dir = app.path().app_data_dir()
        .map_err(|e| format!("Failed to resolve app data dir: {}", e))?;

    // 2. Combine candidate paths
    let raw_target_path = app_dir.join(filename);

    // 3. Canonicalize both paths to resolve symbolic links and relative components (e.g., "..")
    let canonical_base = std::fs::canonicalize(&app_dir)
        .map_err(|_| "Access Denied: Base directory resolution failed".to_string())?;
        
    let canonical_target = std::fs::canonicalize(&raw_target_path)
        .map_err(|_| "Access Denied: Target file does not exist or path is invalid".to_string())?;

    // 4. Validate that the target path explicitly starts with the canonical base directory prefix
    if !canonical_target.starts_with(&canonical_base) {
        return Err("Access Denied: Path traversal attack detected".into());
    }

    // 5. Read file contents securely after successful verification
    let contents = std::fs::read_to_string(&canonical_target)
        .map_err(|e| format!("Failed to read file: {}", e))?;

    Ok(contents)
}
