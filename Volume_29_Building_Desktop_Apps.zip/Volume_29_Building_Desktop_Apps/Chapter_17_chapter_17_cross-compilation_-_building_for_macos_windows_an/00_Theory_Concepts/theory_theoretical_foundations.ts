/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f8f9fa", color="#dee2e6"];
    edge [fontname="Arial", fontsize=10];

    subgraph cluster_host {
        label = "Host Environment (macOS ARM64)";
        style=filled;
        color="#e9ecef";
        fillcolor="#f1f3f5";
        
        HostTypeScript [label="TypeScript Source Code\n(Strict Type Discipline)"];
        HostRust [label="Rust Backend Source Code\n(Tauri 2.0 Core)"];
        HostCompiler [label="Host Rust Compiler (rustc)\nLLVM Code Generator"];
    }

    subgraph cluster_target {
        label = "Target Environment (Windows x86_64)";
        style=filled;
        color="#e9ecef";
        fillcolor="#f1f3f5";
        
        TargetBundler [label="Tauri CLI Bundler"];
        TargetArtifact [label="Windows Executable (.msi / .exe)\n+ WebView2 Dependent Binaries"];
        TargetLinker [label="MinGW-w64 Linker\n(Target-Specific C Runtime)"];
    }

    HostTypeScript -> TargetBundler [label="Vite Bundles JS/TS assets\n(Platform Agnostic)"];
    HostRust -> HostCompiler [label="Feeds AST"];
    HostCompiler -> TargetLinker [label="Emits x86_64 Object Code (.o)"];
    TargetLinker -> TargetArtifact [label="Resolves Windows Win32 API symbols\nProduces final binary"];
    TargetBundler -> TargetArtifact [label="Embeds frontend assets\ninto Windows binary"];
}
