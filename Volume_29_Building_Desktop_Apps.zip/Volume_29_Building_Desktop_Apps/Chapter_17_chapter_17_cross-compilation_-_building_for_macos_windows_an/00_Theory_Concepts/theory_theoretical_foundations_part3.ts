/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#eef2f7", color="#cbd5e1"];
    edge [fontname="Arial", fontsize=10];

    Rustc [label="rustc (Rust Compiler)", fillcolor="#fed7aa", color="#fb923c"];
    
    Target1 [label="x86_64-unknown-linux-gnu\n(Linux Host / Target)", fillcolor="#bbf7d0", color="#4ade80"];
    Target2 [label="aarch64-apple-darwin\n(Apple Silicon macOS)", fillcolor="#bfdbfe", color="#60a5fa"];
    Target3 [label="x86_64-pc-windows-msvc\n(Windows Target)", fillcolor="#fecaca", color="#f87171"];
    
    LinkerLinux [label="GNU ld / gold Linker\nLinks against glibc", fillcolor="#d1fae5"];
    LinkerApple [label="Apple ld64 Linker\nLinks against libSystem", fillcolor="#dbeafe"];
    LinkerWindows [label="Microsoft link.exe / lld-link\nLinks against ucrt.lib", fillcolor="#fee2e2"];

    Rustc -> Target1 [label="--target x86_64-unknown-linux-gnu"];
    Rustc -> Target2 [label="--target aarch64-apple-darwin"];
    Rustc -> Target3 [label="--target x86_64-pc-windows-msvc"];

    Target1 -> LinkerLinux;
    Target2 -> LinkerApple;
    Target3 -> LinkerWindows;
}
