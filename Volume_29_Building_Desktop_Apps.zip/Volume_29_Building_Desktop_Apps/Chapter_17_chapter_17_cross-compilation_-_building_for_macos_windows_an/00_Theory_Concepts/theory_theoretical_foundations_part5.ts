/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.ts
// Description: Theoretical Foundations
// ==========================================

digraph {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f0fdf4", color="#bbf7d0"];
    edge [fontname="Arial", fontsize=10];

    Trigger [label="Git Push / Tag Release", fillcolor="#fef3c7", color="#f59e0b"];

    subgraph cluster_matrix {
        label = "GitHub Actions Matrix Strategy (Parallel Execution)";
        style=filled;
        color="#f8fafc";
        fillcolor="#f1f5f9";

        JobLinux [label="Ubuntu Runner\n- Builds Linux Binary\n- Packages .AppImage / .deb", fillcolor="#e0f2fe", color="#38bdf8"];
        JobWindows [label="Windows Runner\n- Builds Windows Binary\n- Packages .msi / .exe\n- Resolves WebView2", fillcolor="#fee2e2", color="#f87171"];
        JobMacOS [label="macOS Runner\n- Builds macOS Universal Binary\n- Signs & Notarizes App\n- Packages .dmg", fillcolor="#f3e8ff", color="#c084fc"];
    }

    ArtifactCollector [label="GitHub Release / Artifact Storage\nConsolidates Multi-Platform Binaries", fillcolor="#dcfce7", color="#22c55e"];

    Trigger -> JobLinux;
    Trigger -> JobWindows;
    Trigger -> JobMacOS;

    JobLinux -> ArtifactCollector;
    JobWindows -> ArtifactCollector;
    JobMacOS -> ArtifactCollector;
}
