/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file cross-platform-validator.ts
 * @description A pre-flight build validation tool for a Tauri 2.0 SaaS desktop application.
 * This script ensures that all target architectures, environment variables, and output 
 * configurations are valid before handing off execution to the Rust compilation toolchain.
 */

// ============================================================================
// 1. Zod Schema Definitions for Runtime Validation
// ============================================================================

/**
 * Schema defining the supported target operating systems for the Tauri build pipeline.
 */
const TargetOSSchema = z.enum(['macos', 'windows', 'linux']);

/**
 * Schema defining the supported architectures for desktop deployment.
 */
const TargetArchSchema = z.enum(['x64', 'arm64', 'universal']);

/**
 * Schema for SaaS desktop application configuration flags.
 */
const AppConfigSchema = z.object({
  appName: z.string().min(1, "App name cannot be empty"),
  bundleIdentifier: z.string().regex(/^[a-z0-9.-]+$/, "Invalid bundle identifier format"),
  targetOS: TargetOSSchema,
  targetArch: TargetArchSchema,
  enableAutoUpdates: z.boolean(),
  sentryDsn: z.string().url("Sentry DSN must be a valid URL").optional(),
});

// Infer the TypeScript type from the Zod schema for type-safe usage downstream
type AppConfig = z.infer<typeof AppConfigSchema>;

// ============================================================================
// 2. Mock Environment Input (Simulating external CI/CD or config file read)
// ============================================================================

/**
 * Raw input data fetched from an external source (e.g., environment variables, 
 * a CI/CD build matrix JSON file, or an LLM-generated build configuration).
 */
const rawBuildInput: unknown = {
  appName: "CloudSync Pro",
  bundleIdentifier: "com.cloudsync.desktop",
  targetOS: "macos",
  targetArch: "universal",
  enableAutoUpdates: true,
  sentryDsn: "https://examplePublicKey@o0.ingest.sentry.io/0"
};

// ============================================================================
// 3. Validation and Execution Logic
// ============================================================================

/**
 * Validates the raw configuration input against the strict Zod schema.
 * Throws a detailed runtime error if validation fails.
 * 
 * @param input - The unknown input data to validate.
 * @returns A strictly typed AppConfig object.
 */
function validateAppConfiguration(input: unknown): AppConfig {
  console.log("[Pre-Flight Check] Inspecting Tauri cross-compilation environment...");

  // Parse the input against the Zod schema to enforce runtime safety
  const result = AppConfigSchema.safeParse(input);

  if (!result.success) {
    // Format and throw errors if validation fails
    const errorDetails = result.error.errors.map(err => `-> ${err.path.join('.')}: ${err.message}`).join('\n');
    throw new Error(`[Validation Error] Failed to validate Tauri build configuration:\n${errorDetails}`);
  }

  console.log("[Pre-Flight Check] Configuration successfully validated against schema.");
  return result.data;
}

/**
 * Simulates generating the appropriate target flags for the Tauri CLI based on validated config.
 * 
 * @ník - Validated application configuration.
 */
function generateTauriBuildArguments(config: AppConfig): string[] {
  const args: string[] = ["build"];

  // Map target OS to Tauri CLI flags
  if (config.targetOS === 'macos') {
    args.push("--target", config.targetArch === 'arm64' ? "aarch64-apple-darwin" : "x86_64-apple-darwin");
  } else if (config.targetOS === 'windows') {
    args.push("--target", "x86_64-pc-windows-msvc");
  } else if (config.targetOS === 'linux') {
    args.push("--target", "x86_64-unknown-linux-gnu");
  }

  if (config.enableAutoUpdates) {
    console.log("[Build Setup] Auto-updater module enabled for this build artifact.");
  }

  return args;
}

// Execute the validation and build preparation pipeline
try {
  const validatedConfig = validateAppConfiguration(rawBuildInput);
  const tauriCliArgs = generateTauriBuildArguments(validatedConfig);

  console.log(`[Success] Ready to spawn Tauri build process with args:`, tauriCliArgs);
} catch (error: unknown) {
  if (error instanceof Error) {
    console.error(error.message);
  } else {
    console.error("An unknown error occurred during pre-flight validation.", error);
  }
  process.exit(1);
}
