/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part9.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file advanced-matrix-validator.ts
 * @description Advanced multi-platform release matrix validation for Tauri 2.0 SaaS apps.
 */

// Define the comprehensive release schema
const ReleaseMatrixSchema = z.object({
  version: z.string().regex(/^\d+\.\d+\.\d+(-[a-z0-9.]+)?$/, "Must follow Semantic Versioning (SemVer)"),
  releaseChannels: z.array(z.enum(['stable', 'beta', 'nightly'])),
  targets: z.array(
    z.object({
      os: z.enum(['macos', 'windows', 'linux']),
      arch: z.enum(['x64', 'arm64']),
      signArtifacts: z.boolean(),
    })
  ).min(1, "At least one build target must be specified"),
  environmentVariables: z.record(z.string(), z.string()).optional(),
});

type ReleaseMatrix = z.infer<typeof ReleaseMatrixSchema>;

/**
 * Validates a complex release matrix payload received from a release automation webhook.
 */
function parseReleaseMatrix(payload: unknown): ReleaseMatrix {
  const validationResult = ReleaseMatrixSchema.safeParse(payload);

  if (!validationResult.success) {
    console.error("[Matrix Validation] Critical error in release configuration payload:");
    validationResult.error.errors.forEach((err) => {
      console.error(`  - Field [${err.path.join(' -> ')}]: ${err.message}`);
    });
    throw new Error("Release matrix validation failed. Aborting build pipeline.");
  }

  return validationResult.data;
}

// Example usage with a simulated webhook payload
const incomingWebhookPayload = {
  version: "2.1.0-beta.1",
  releaseChannels: ["beta"],
  targets: [
    { os: "macos", arch: "arm64", signArtifacts: true },
    { os: "windows", arch: "x64", signArtifacts: true },
    { os: "linux", arch: "x64", signArtifacts: false }
  ],
  environmentVariables: {
    RUST_BACKTRACE: "1",
    TAURI_PRIVATE_KEY: "enc_key_sample_12345"
  }
};

try {
  const validatedMatrix = parseReleaseMatrix(incomingWebhookPayload);
  console.log(`[Matrix Success] Successfully parsed release matrix for version v${validatedMatrix.version}`);
  validatedMatrix.targets.forEach(target => {
    console.log(` -> Queuing build for Target OS: ${target.os}, Arch: ${target.arch}, Signing: ${target.signArtifacts}`);
  });
} catch (error) {
  if (error instanceof Error) {
    console.error(error.message);
  }
  process.exit(1);
}
