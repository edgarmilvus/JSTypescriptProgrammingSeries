/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';
import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

/**
 * @file cross-compilation-orchestrator.ts
 * @description Validates cross-compilation target environments for Tauri 2.0 apps
 * and orchestrates multi-platform build configurations using Zod for runtime validation.
 */

// ============================================================================
// 1. Zod Schemas for Runtime Configuration & Target Validation
// ============================================================================

/**
 * Schema defining supported target architectures for Tauri 2.0 cross-compilation.
 */
const TargetArchitectureSchema = z.enum([
  'x86_64-apple-darwin',
  'aarch64-apple-darwin',
  'x86_64-pc-windows-msvc',
  'x86_64-unknown-linux-gnu',
  'aarch64-unknown-linux-gnu',
]);

/**
 * Schema defining the structure of the cross-compilation build manifest.
 */
const BuildManifestSchema = z.object({
  appName: z.string().min(1, 'Application name is required'),
  version: z.string().regex(/^\d+\.\d+\.\d+$/, 'Version must follow semver (e.g., 1.0.0)'),
  targets: z.array(TargetArchitectureSchema).min(1, 'At least one build target is required'),
  outputDirectory: z.string().default('./src-tauri/target'),
  environment: z.enum(['development', 'staging', 'production']),
});

type BuildManifest = z.infer<typeof BuildManifestSchema>;

// ============================================================================
// 2. Helper Functions & System Inspection Utilities
// ============================================================================

/**
 * Safely reads and parses a JSON configuration file from disk.
 * Applies runtime validation via Zod to guarantee data integrity.
 * 
 * @param filePath Path to the JSON configuration file
 * @returns Validated BuildManifest object
 */
function loadAndValidateManifest(filePath: string): BuildManifest {
  console.log(`[Orchestrator] Reading build manifest from: ${filePath}`);
  
  if (!fs.existsSync(filePath)) {
    throw new Error(`[Orchestrator Error] Manifest file not found at: ${filePath}`);
  }

  const rawData = fs.readFileSync(filePath, 'utf-8');
  let parsedJson: unknown;

  try {
    parsedJson = JSON.parse(rawData);
  } catch (error) {
    throw new Error(`[Orchestrator Error] Failed to parse JSON: ${(error as Error).message}`);
  }

  // Enforce runtime validation boundary using Zod
  const validationResult = BuildManifestSchema.safeParse(parsedJson);

  if (!validationResult.success) {
    console.error('[Orchestrator Error] Validation failed against schema:');
    console.error(JSON.stringify(validationResult.error.format(), null, 2));
    throw new Error('Invalid build manifest configuration.');
  }

  console.log('[Orchestrator] Manifest successfully validated at runtime.');
  return validationResult.data;
}

/**
 * Checks if the required Rust compilation target is installed on the host system.
 * 
 * @param target Rust target triple (e.g., x86_64-pc-windows-msvc)
 */
function verifyRustTargetInstalled(target: string): boolean {
  console.log(`[Orchestrator] Checking installed Rust targets for: ${target}`);
  try {
    const output = execSync('rustup target list --installed', { encoding: 'utf-8' });
    const installedTargets = output.split('\n').map(t => t.trim());
    const isInstalled = installedTargets.includes(target);
    
    if (isInstalled) {
      console.log(`[Orchestrator] Target ${target} is present.`);
    } else {
      console.warn(`[Orchestrator Warning] Target ${target} is MISSING. Attempting installation...`);
      execSync(`rustup target add ${target}`, { stdio: 'inherit' });
    }
    return true;
  } catch (error) {
    console.error(`[Orchestrator Error] Failed to verify Rust target ${target}: ${(error as Error).message}`);
    return false;
  }
}

// ============================================================================
// 3. Main Orchestration Routine
// ============================================================================

/**
 * Main execution function for running cross-compilation sanity checks and builds.
 */
function runCrossCompilationPipeline() {
  const manifestPath = path.resolve(process.cwd(), 'tauri-build-manifest.json');

  // Step 1: Load and runtime-validate configuration
  const config = loadAndValidateManifest(manifestPath);

  console.log(`\nStarting Build Pipeline for: ${config.appName} (v${config.version})`);
  console.log(`Target Environment: ${config.environment}\n`);

  // Step 2: Iterate through targets and verify toolchain prerequisites
  for (const target of config.targets) {
    console.log(`--------------------------------------------------`);
    console.log(`Processing Target: ${target}`);
    
    const isReady = verifyRustTargetInstalled(target);
    
    if (!isReady) {
      throw new Error(`Pipeline aborted: Toolchain requirement unmet for target ${target}`);
    }

    // Step 3: Construct Tauri cross-compilation command
    // In actual CI pipelines, we pass the target flag to cargo/tauri CLI
    const buildCommand = `npx tauri build --target ${target}`;
    console.log(`[Orchestrator] Prepared Command: ${buildCommand}`);
    
    // Note: Actual execution commented out for dry-run safety in environments without full toolchains
    // execSync(buildCommand, { stdio: 'inherit' });
  }

  console.log(`--------------------------------------------------`);
  console.log('[Orchestrator] All target environments successfully validated and prepared.');
}

// Execute pipeline if run directly
if (require.main === module) {
  try {
    runCrossCompilationPipeline();
  } catch (err) {
    console.error(`\n[Fatal Error] Pipeline failed: ${(err as Error).message}`);
    process.exit(1);
  }
}
