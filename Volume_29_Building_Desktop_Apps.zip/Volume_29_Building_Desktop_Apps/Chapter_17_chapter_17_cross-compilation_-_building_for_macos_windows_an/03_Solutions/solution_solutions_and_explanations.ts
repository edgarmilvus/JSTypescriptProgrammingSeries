/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { execSync } from 'child_process';
import { z } from 'zod';

// Define the schema for the target validation status
const TargetStatusSchema = z.object({
  target: z.string(),
  isInstalled: z.boolean(),
  activeToolchain: z.string(),
});

type TargetStatus = z.infer<typeof TargetStatusSchema>;

/**
 * Queries the local rustup environment, checks if the requested target is installed, 
 * and validates the output against the TargetStatusSchema.
 */
export function verifyRustTarget(targetTriple: string): TargetStatus {
  try {
    // Fetch installed targets via rustup
    const output = execSync('rustup target list --installed', { encoding: 'utf-8' });
    const installedTargets = output
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);

    // Fetch active toolchain information
    const toolchainOutput = execSync('rustup show active-toolchain', { encoding: 'utf-8' });
    const activeToolchain = toolchainOutput.split(' ')[0] || 'unknown';

    const isInstalled = installedTargets.includes(targetTriple);

    const rawResult: TargetStatus = {
      target: targetTriple,
      isInstalled,
      activeToolchain,
    };

    // Runtime validation using Zod
    return TargetStatusSchema.parse(rawResult);
  } catch (error: any) {
    throw new Error(`Failed to verify Rust target toolchain: ${error.message}`);
  }
}
