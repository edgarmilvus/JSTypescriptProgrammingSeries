/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

// Define the diagnostic result schema
const DiagnosticResultSchema = z.object({
  targetOS: z.enum(['macos', 'windows', 'linux']),
  status: z.enum(['success', 'warning', 'error']),
  missingDependencies: z.array(z.string()),
  recommendation: z.string(),
});

type DiagnosticResult = z.infer<typeof DiagnosticResultSchema>;

export const CrossCompileDiagnostics: React.FC = () => {
  const [selectedOS, setSelectedOS] = useState<'macos' | 'windows' | 'linux'>('linux');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<DiagnosticResult | null>(null);

  const runPreflightCheck = () => {
    setLoading(true);
    setResult(null);

    // Simulate asynchronous system dependency check
    setTimeout(() => {
      let mockData: unknown;

      if (selectedOS === 'linux') {
        mockData = {
          targetOS: 'linux',
          status: 'warning',
          missingDependencies: ['libwebkit2gtk-4.1-dev', 'libayatana-appindicator3-dev'],
          recommendation: 'Install missing GTK and WebKit libraries using your distribution package manager (e.g., apt install libwebkit2gtk-4.1-dev).',
        };
      } else if (selectedOS === 'windows') {
        mockData = {
          targetOS: 'windows',
          status: 'success',
          missingDependencies: [],
          recommendation: 'MSVC build tools and Windows SDK are correctly registered.',
        };
      } else {
        mockData = {
          targetOS: 'macos',
          status: 'error',
          missingDependencies: ['Xcode Command Line Tools'],
          recommendation: 'Run xcode-select --install to configure macOS compilation toolchains.',
        };
      }

      // Validate runtime payload against Zod schema
      const parsedResult = DiagnosticResultSchema.parse(mockData);
      setResult(parsedResult);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold text-gray-800">Tauri Cross-Compilation Diagnostics</h2>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Target Operating System:</label>
        <select 
          value={selectedOS} 
          onChange={(e) => setSelectedOS(e.target.value as any)}
          className="w-full p-2 border border-gray-300 rounded-md"
        >
          <option value="linux">Linux (x86_64 / aarch64)</option>
          <option value="windows">Windows (MSVC/GNU)</option>
          <option value="macos">macOS (Darwin)</option>
        </select>
      </div>

      <button 
        onClick={runPreflightCheck}
        disabled={loading}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Running Pre-flight Check...' : 'Run Linker Pre-flight Check'}
      </button>

      {result && (
        <div className={`p-4 rounded-md border ${result.status === 'success' ? 'bg-green-50 border-green-200' : result.status === 'warning' ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200'}`}>
          <h3 className="font-semibold capitalize">Status: {result.status}</h3>
          <p className="text-sm mt-1"><strong>Recommendation:</strong> {result.recommendation}</p>
          {result.missingDependencies.length > 0 && (
            <div className="mt-2 text-xs">
              <span className="font-bold">Missing System Packages:</span>
              <ul className="list-disc pl-5 mt-1">
                {result.missingDependencies.map((dep, idx) => (
                  <li key={idx}>{dep}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
