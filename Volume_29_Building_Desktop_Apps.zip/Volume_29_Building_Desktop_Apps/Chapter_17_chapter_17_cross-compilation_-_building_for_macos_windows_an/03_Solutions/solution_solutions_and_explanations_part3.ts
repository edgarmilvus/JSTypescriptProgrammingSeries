/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import { z } from 'zod';

// Schema for Tauri configuration bundling subset
const TauriConfigSchema = z.object({
  package: z.object({
    productName: z.string(),
    version: z.string(),
  }),
  tauri: z.object({
    bundle: z.object({
      active: z.boolean(),
      targets: z.array(z.string()),
      icon: z.array(z.string()),
    }),
  }),
}).passthrough(); // Allows extra properties in tauri.conf.json without stripping them

type TauriConfig = z.infer<typeof TauriConfigSchema>;

/**
 * Patches target bundles dynamically prior to invoking cargo tauri build.
 */
export function patchTauriConfig(configPath: string, targetPlatform: 'darwin' | 'win32' | 'linux'): void {
  try {
    if (!fs.existsSync(configPath)) {
      throw new Error(`Configuration file not found at path: ${configPath}`);
    }

    const fileContent = fs.readFileSync(configPath, 'utf-8');
    const rawJson = JSON.parse(fileContent);

    // Validate raw structure against Zod schema
    const parsedConfig = TauriConfigSchema.parse(rawJson);

    // Dynamically adjust bundle targets based on platform
    if (targetPlatform === 'darwin') {
      parsedConfig.tauri.bundle.targets = ['dmg', 'app'];
    } else if (targetPlatform === 'win32') {
      parsedConfig.tauri.bundle.targets = ['msi', 'nsis'];
    } else if (targetPlatform === 'linux') {
      parsedConfig.tauri.bundle.targets = ['deb', 'AppImage'];
    }

    // Write modified configuration safely back to disk
    fs.writeFileSync(configPath, JSON.stringify(parsedConfig, null, 2), 'utf-8');
  } catch (error: any) {
    throw new Error(`Failed to patch Tauri configuration: ${error.message}`);
  }
}
