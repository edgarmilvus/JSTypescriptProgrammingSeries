/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

const WorkflowConfigSchema = z.object({
  platforms: z.array(z.enum(['ubuntu-latest', 'macos-latest', 'windows-latest'])),
  nodeVersion: z.string().default('18.x'),
  rustVersion: z.string().default('stable'),
});

type WorkflowConfig = z.infer<typeof WorkflowConfigSchema>;

/**
 * Constructs a GitHub Actions YAML string optimized for Tauri 2.0 cross-platform compilation matrices.
 */
export function generateTauriWorkflow(config: WorkflowConfig): string {
  const validatedConfig = WorkflowConfigSchema.parse(config);

  const platformsYaml = JSON.stringify(validatedConfig.platforms);

  return `name: "Tauri Cross-Compilation Pipeline"

on:
  push:
    branches: [ "main" ]

jobs:
  build:
    strategy:
      fail-fast: false
      matrix:
        platform: ${platformsYaml}

    runs-on: \${{ matrix.platform }}

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '${validatedConfig.nodeVersion}'
          cache: 'npm'

      - name: Install Rust Stable
        uses: dtolnay/rust-action@stable
        with:
          toolchain: '${validatedConfig.rustVersion}'

      - name: Install Ubuntu Dependencies
        if: matrix.platform == 'ubuntu-latest'
        run: |
          sudo apt-get update
          sudo apt-get install -y libwebkit2gtk-4.1-dev libappindicator3-dev librsvg2-dev patchelf

      - name: Install Frontend Dependencies & Build
        run: |
          npm install
          npm run build

      - name: Build Tauri Application
        uses: tauri-apps/tauri-action@v0.5.0
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
        with:
          tagName: app-v\${{ github.ref_name }}
          releaseName: 'App v\${{ github.ref_name }}'
          body: 'Automated release build.'
          draft: false
          prerelease: false
`;
}
