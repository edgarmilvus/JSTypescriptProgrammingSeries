/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs/promises';
import * as path from 'path';
import { z } from 'zod';

// Define the schema for individual build artifacts
const ArtifactSchema = z.object({
  filename: z.string(),
  extension: z.enum(['.app', '.msi', '.exe', '.AppImage', '.deb', '.dmg']),
  sizeBytes: z.number().positive(),
  platform: z.enum(['macos', 'windows', 'linux']),
  checksumValid: z.boolean(),
});

const ReleaseVerificationReportSchema = z.object({
  totalArtifactsChecked: z.number().int().nonnegative(),
  passed: z.boolean(),
  artifacts: z.array(ArtifactSchema),
  errors: z.array(z.string()),
});

type ReleaseVerificationReport = z.infer<typeof ReleaseVerificationReportSchema>;

/**
 * Scans the output directory, validates each artifact against the ArtifactSchema, 
 * and compiles a comprehensive verification report.
 */
export async function verifyReleaseArtifacts(outputDir: string): Promise<ReleaseVerificationReport> {
  const verifiedArtifacts: z.infer<typeof ArtifactSchema>[] = [];
  const errors: string[] = [];

  try {
    try {
      await fs.access(outputDir);
    } catch {
      return {
        totalArtifactsChecked: 0,
        passed: false,
        artifacts: [],
        errors: [`Output directory does not exist: ${outputDir}`],
      };
    }

    const files = await fs.readdir(outputDir);

    if (files.length === 0) {
      return {
        totalArtifactsChecked: 0,
        passed: false,
        artifacts: [],
        errors: [`Output directory is empty: ${outputDir}`],
      };
    }

    for (const file of files) {
      const filePath = path.join(outputDir, file);
      const stats = await fs.stat(filePath);

      if (stats.isDirectory() && !file.endsWith('.app')) {
        continue; // Skip standard subdirectories, but keep macOS .app bundles
      }

      const ext = path.extname(file);
      let platform: 'macos' | 'windows' | 'linux' = 'linux';

      if (['.dmg', '.app'].includes(ext)) {
        platform = 'macos';
      } else if (['.msi', '.exe'].includes(ext)) {
        platform = 'windows';
      } else if (['.AppImage', '.deb'].includes(ext)) {
        platform = 'linux';
      } else {
        errors.append ? errors.push(`Unrecognized file extension encountered: ${file}`) : errors.push(`Unrecognized file extension encountered: ${file}`);
        continue;
      }

      // Mock checksum validation check (in production, verify against sha256 checksum files)
      const checksumValid = stats.size > 1024; 

      const candidateArtifact = {
        filename: file,
        extension: ext,
        sizeBytes: stats.size,
        platform,
        checksumValid,
      };

      try {
        const validatedArtifact = ArtifactSchema.parse(candidateArtifact);
        verifiedArtifacts.push(validatedArtifact);
      } catch (validationError: any) {
        errors.push(`Artifact validation failed for ${file}: ${validationError.message}`);
      }
    }

    const passed = errors.length === 0 && verifiedArtifacts.length > 0;

    return ReleaseVerificationReportSchema.parse({
      totalArtifactsChecked: verifiedArtifacts.length,
      passed,
      artifacts: verifiedArtifacts,
      errors,
    });
  } catch (err: any) {
    return {
      totalArtifactsChecked: verifiedArtifacts.length,
      passed: false,
      artifacts: verifiedArtifacts,
      errors: [...errors, `Fatal pipeline error: ${err.message}`],
    };
  }
}
