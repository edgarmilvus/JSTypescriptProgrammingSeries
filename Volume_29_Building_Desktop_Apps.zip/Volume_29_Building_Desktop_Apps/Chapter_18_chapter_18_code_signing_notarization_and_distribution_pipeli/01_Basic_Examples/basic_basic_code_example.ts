/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { execSync } from 'node:child_process';
import { existsSync, statSync } from 'node:fs';
import { resolve, join } from 'node:path';

/**
 * Configuration interface representing environment variables 
 * and settings required for code signing and distribution.
 */
interface SigningConfig {
  appName: string;
  targetPlatform: 'darwin' | 'win32';
  buildOutputDir: string;
  signingIdentity: string;
  appleId?: string;
  appleIdPassword?: string;
  appleTeamId?: string;
  windowsCertPath?: string;
  windowsCertPassword?: string;
}

/**
 * Result object returned after a signing and verification attempt.
 */
interface SigningResult {
  success: boolean;
  signedBinaryPath: string;
  timestamp: string;
  logs: string[];
}

/**
 * Validates that all required environment variables and target binaries 
 * exist before executing native signing commands.
 * 
 * @param config - The active signing configuration object
 * @throws Error if critical files or configurations are missing
 */
function validateEnvironment(config: SigningConfig): void {
  // Resolve absolute path to the build output directory
  const resolvedOutputDir = resolve(config.buildOutputDir);
  
  if (!existsSync(resolvedOutputDir)) {
    throw new Error(`Build output directory does not exist: ${resolvedOutputDir}`);
  }

  // Validate platform-specific cryptographic assets
  if (config.targetPlatform === 'darwin') {
    if (!config.signingIdentity) {
        throw new Error('macOS Developer ID Application identity is missing.');
    }
    if (!config.appleId || !config.appleIdPassword || !config.appleTeamId) {
        throw new Error('Notarization credentials (Apple ID, App-Specific Password, Team ID) are missing.');
    }
  } else if (config.targetPlatform === 'win32') {
    if (!config.windowsCertPath || !existsSync(config.windowsCertPath)) {
        throw new Error(`Windows Authenticode certificate path is invalid: ${config.windowsCertPath}`);
    }
  }
}

/**
 * Executes a shell command synchronously and captures stdout/stderr,
 * sanitizing sensitive variables from error outputs.
 * 
 * @param command - The shell command to execute
 * @returns The standard output of the executed command
 */
function executeSecureCommand(command: string): string {
  try {
    // Execute command with inherited stdio for real-time CI/CD logging
    const output = execSync(command, { encoding: 'utf8', stdio: 'pipe' });
    return output.trim();
  } catch (error: any) {
    // Strip potential secrets out of the error message before throwing
    const sanitizedMessage = error.stderr ? error.stderr.toString() : error.message;
    throw new Error(`Command execution failed: ${sanitizedMessage}`);
  }
}

/**
 * Signs and notarizes a macOS application bundle (.app) using Apple's codesign 
 * and notarytool utilities.
 * 
 * @param appPath - Absolute path to the compiled .app bundle
 * @param config - Active signing configuration
 * @returns Array of operational log strings
 */
function processMacOSSignAndNotarize(appPath: string, config: SigningConfig): string[] {
  const logs: string[] = [];
  
  // Step 1: Deep sign the application bundle with hardened runtime enabled
  // Hardened runtime is strictly required by macOS Gatekeeper for notarization
  logs.push(`Initiating deep code signing for macOS bundle: ${appPath}`);
  const signCommand = `codesign --deep --force --options runtime --sign "${config.signingIdentity}" "${appPath}"`;
  executeSecureCommand(signCommand);
  logs.push('Successfully signed application bundle with hardened runtime.');

  // Step 2: Verify the cryptographic signature locally
  logs.push('Verifying local code signature and entitlements...');
  const verifyCommand = `codesign --verify --deep --strict --verbose=2 "${appPath}"`;
  const verifyOutput = executeSecureCommand(verifyCommand);
  logs.push(verifyOutput);

  // Step 3: Package the .app into a ZIP archive for notarization submission
  const zipPath = `${appPath}.zip`;
  logs.push(`Compressing bundle to ZIP for notarization submission: ${zipPath}`);
  executeSecureCommand(`ditto -c -k --keepParent "${appPath}" "${zipPath}"`);

  // Step 4: Submit the archive to Apple notary service asynchronously and wait for completion
  logs.push('Submitting binary to Apple Notary Service (notarytool)...');
  const notarizeCommand = `xcrun notarytool submit "${zipPath}" ` +
    `--apple-id "${config.appleId}" ` +
    `--password "${config.appleIdPassword}" ` +
    `--team-id "${config.appleTeamId}" ` +
    `--wait`;
  
  const notarizeOutput = executeSecureCommand(notarizeCommand);
  logs.push(notarizeOutput);
  logs.push('Notarization process completed successfully.');

  // Step 5: Staple the notarization ticket directly to the application bundle
  logs.push('Stapling notarization ticket to the .app bundle...');
  executeSecureCommand(`xcrun stapler staple "${appPath}"`);
  logs.push('Ticket successfully stapled.');

  return logs;
}

/**
 * Signs a Windows executable (.exe) using Microsoft's SignTool utility 
 * via an Authenticode certificate.
 * 
 * @param exePath - Absolute path to the compiled executable
 * @param config - Active signing configuration
 * @returns Array of operational log strings
 */
function processWindowsSign(exePath: string, config: SigningConfig): string[] {
  const logs: string[] = [];

  logs.push(`Initiating Windows Authenticode signing for binary: ${exePath}`);
  
  // Construct the SignTool invocation using a timestamp server for long-term validity
  // Timestamp servers ensure signatures remain valid even after the code signing certificate expires
  const timestampServer = 'http://timestamp.digicert.com';
  const signtoolPath = 'signtool.exe'; // Assumes signtool is in system PATH (standard in Windows CI runners)
  
  const signCommand = `"${signtoolPath}" sign /f "${config.windowsCertPath}" ` +
    `/p "${config.windowsCertPassword}" ` +
    `/tr "${timestampServer}" ` +
    `/td sha256 /fd sha256 ` +
    `"${exePath}"`;

  executeSecureCommand(signCommand);
  logs.push('Successfully applied Windows Authenticode signature.');

  // Verify the signature and timestamp integrity
  logs.push('Verifying Windows binary signature...');
  const verifyCommand = `"${signtoolPath}" verify /pa /v "${exePath}"`;
  const verifyOutput = executeSecureCommand(verifyCommand);
  logs.push(verifyOutput);

  return logs;
}

/**
 * Main orchestrator function handling the end-to-end signing lifecycle 
 * for Tauri desktop binaries.
 * 
 * @param config - Validated deployment configuration parameters
 * @returns A structured promise resolving to the signing operation report
 */
async function runDistributionPipeline(config: SigningConfig): Promise<SigningResult> {
  const executionLogs: string[] = [];
  
  try {
    executionLogs.push(`Starting distribution pipeline for SaaS app: ${config.appName}`);
    executionLogs.push(`Target Platform: ${config.targetPlatform}`);

    // Validate configuration integrity
    validateEnvironment(config);
    executionLogs.push('Environment validation passed successfully.');

    let targetBinaryPath = '';

    if (config.targetPlatform === 'darwin') {
      targetBinaryPath = resolve(config.buildOutputDir, `${config.appName}.app`);
      if (!existsSync(targetBinaryPath)) {
        throw new Error(`Target macOS bundle not found at expected path: ${targetBinaryPath}`);
      }
      const macLogs = processMacOSSignAndNotarize(targetBinaryPath, config);
      executionLogs.push(...macLogs);

    } else if (config.targetPlatform === 'win32') {
      targetBinaryPath = resolve(config.buildOutputDir, `${config.appName}.exe`);
      if (!existsSync(targetBinaryPath)) {
        throw new Error(`Target Windows executable not found at expected path: ${targetBinaryPath}`);
      }
      const winLogs = processWindowsSign(targetBinaryPath, config);
      executionLogs.push(...winLogs);
    } else {
      throw new Error(`Unsupported target platform: ${config.targetPlatform}`);
    }

    return {
      success: true,
      signedBinaryPath: targetBinaryPath,
      timestamp: new Date().toISOString(),
      logs: executionLogs
    };

  } catch (error: any) {
    executionLogs.push(`CRITICAL ERROR: ${error.message}`);
    return {
      success: false,
      signedBinaryPath: '',
      timestamp: new Date().toISOString(),
      logs: executionLogs
    };
  }
}

// ==========================================
// Execution Example (Simulated SaaS CI Script)
// ==========================================
const sampleConfig: SigningConfig = {
  appName: 'EnterpriseSaaSClient',
  targetPlatform: process.platform === 'darwin' ? 'darwin' : 'win32',
  buildOutputDir: './src-tauri/target/release/bundle',
  signingIdentity: process.env.MACOS_SIGNING_IDENTITY || 'Developer ID Application: SaaS Corp (ABC123XYZ)',
  appleId: process.env.APPLE_ID,
  appleIdPassword: process.env.APPLE_PASSWORD,
  appleTeamId: process.env.APPLE_TEAM_ID,
  windowsCertPath: process.env.WINDOWS_CERT_PATH,
  windowsCertPassword: process.env.WINDOWS_CERT_PASSWORD
};

// Execute pipeline if run directly via Node.js
if (require.main === module) {
  runDistributionPipeline(sampleConfig)
    .then((result) => {
      console.log('\n--- DISTRIBUTION PIPELINE EXECUTION REPORT ---');
      console.log(`Status: ${result.success ? 'SUCCESS' : 'FAILED'}`);
      console.log(`Timestamp: ${result.timestamp}`);
      console.log(`Target Binary: ${result.signedBinaryPath || 'N/A'}`);
      console.log('\nDetailed Operation Logs:');
      result.logs.forEach(log => console.log(`  [LOG] ${log}`));
      
      if (!result.success) {
        process.exit(1);
      }
    })
    .catch((err) => {
      console.error('Fatal unhandled error in distribution pipeline:', err);
      process.exit(1);
    });
}
