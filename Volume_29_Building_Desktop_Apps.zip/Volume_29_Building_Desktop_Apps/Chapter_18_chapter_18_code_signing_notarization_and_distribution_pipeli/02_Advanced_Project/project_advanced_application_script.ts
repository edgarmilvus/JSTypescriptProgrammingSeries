/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { execSync } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';

/**
 * Interface representing the build configuration context required
 * for signing and distributing a Tauri 2.0 application.
 */
interface DistributionConfig {
  appName: string;
  bundleVersion: string;
  targetPlatform: 'darwin' | 'win32' | 'linux';
  codesignIdentity?: string;
  appleId?: string;
  applePassword?: string;
  appleTeamId?: string;
  windowsCertPath?: string;
  windowsCertPassword?: string;
}

/**
 * Result object returned after an orchestration execution cycle.
 */
interface PipelineResult {
  success: boolean;
  artifacts: string[];
  durationMs: number;
  error?: string;
}

/**
 * Validates that all necessary environment variables and cryptographic assets
 * are present prior to invoking the Tauri build and sign sequence.
 * 
 * @param config - The distribution configuration object.
 * @throws Error if critical signing parameters are missing for the target platform.
 */
function validateEnvironment(config: DistributionConfig): void {
  console.log(`[Pipeline] Validating environment for target platform: ${config.targetPlatform}`);

  if (config.targetPlatform === 'darwin') {
    if (!config.codesignIdentity) {
      throw new Error('Missing CODESIGN_IDENTITY for macOS packaging.');
    }
    if (!config.appleId || !config.applePassword || !config.appleTeamId) {
      console.warn('[Pipeline Warning] Apple notarization credentials missing. App will be signed but not notarized.');
    }
  } else if (config.targetPlatform === 'win32') {
    if (!config.windowsCertPath || !config.windowsCertPassword) {
      console.warn('[Pipeline Warning] Windows signing certificate path or password missing. Binaries will be unsigned.');
    } else if (!fs.existsSync(config.windowsCertPath)) {
      throw new Error(`Windows signing certificate not found at path: ${config.windowsCertPath}`);
    }
  }

  console.log('[Pipeline] Environment validation completed successfully.');
}

/**
 * Executes the underlying Tauri 2.0 CLI build command with environment injections
 * necessary for code signing and notarization hooks.
 * 
 * @param config - The distribution configuration object.
 */
function executeTauriBuild(config: DistributionConfig): void {
  console.log(`[Pipeline] Initializing Tauri 2.0 build sequence for ${config.appName} v${config.bundleVersion}...`);

  // Construct environment variables to pass down to cargo/tauri-bundler
  const env = { ...process.env };
  
  if (config.targetPlatform === 'darwin' && config.codesignIdentity) {
    env['APPLE_SIGNING_IDENTITY'] = config.codesignIdentity;
    if (config.appleId && config.applePassword && config.appleTeamId) {
      env['APPLE_ID'] = config.appleId;
      env['APPLE_PASSWORD'] = config.applePassword;
      env['APPLE_TEAM_ID'] = config.appleTeamId;
    }
  }

  const buildCommand = 'npx tauri build';
  
  try {
    const startTime = Date.now();
    // Execute the build command synchronously, streaming output to the parent process stdout
    execSync(buildCommand, { stdio: 'inherit', env });
    const duration = Date.now() - startTime;
    console.log(`[Pipeline] Tauri build completed in ${(duration / 1000).toFixed(2)} seconds.`);
  } catch (error: unknown) {
    if (error instanceof Error) {
      throw new Error(`Tauri build execution failed: ${error.message}`);
    }
    throw new Error('Tauri build execution failed with an unknown error.');
  }
}

/**
 * Scans the standard Tauri output directories to locate generated installers
 * and binaries, preparing them for staging and upload to a distribution server.
 * 
 * @param targetPlatform - The operating system target.
 * @returns An array of absolute paths pointing to the generated artifacts.
 */
function collectArtifacts(targetPlatform: 'darwin' | 'win32' | 'linux'): string[] {
  console.log('[Pipeline] Collecting and verifying distribution artifacts...');
  
  // Standard Tauri 2.0 target release bundle directory layout
  const baseOutputDir = path.resolve(process.cwd(), 'src-tauri', 'target', 'release', 'bundle');
  let searchSubDir = '';

  if (targetPlatform === 'darwin') {
    searchSubDir = 'macos';
  } else if (targetPlatform === 'win32') {
    searchSubDir = 'nsis';
  } else {
    searchSubDir = 'appimage';
  }

  const targetDir = path.join(baseOutputDir, searchSubDir);

  if (!fs.existsSync(targetDir)) {
    throw new Error(`Expected bundle directory does not exist: ${targetDir}`);
  }

  const files = fs.readdirSync(targetDir);
  const artifacts = files
    .filter(file => {
      if (targetPlatform === 'darwin') return file.endsWith('.dmg') || file.endsWith('.app');
      if (targetPlatform === 'win32') return file.endsWith('.exe');
      return file.endsWith('.AppImage');
    })
    .map(file => path.join(targetDir, file));

  console.log(`[Pipeline] Found ${artifacts.length} artifacts for distribution.`);
  artifacts.forEach(art => console.log(` - Staged: ${art}`));

  return artifacts;
}

/**
 * Main orchestration entrypoint for the distribution pipeline script.
 */
async function runDistributionPipeline(): Promise<PipelineResult> {
  const startTime = Date.now();
  
  const config: DistributionConfig = {
    appName: 'EnterpriseStudio',
    bundleVersion: '2.0.4',
    targetPlatform: (process.platform === 'darwin' ? 'darwin' : process.platform === 'win32' ? 'win32' : 'linux'),
    codesignIdentity: process.env.CODESIGN_IDENTITY,
    appleId: process.env.APPLE_ID,
    applePassword: process.env.APPLE_PASSWORD,
    appleTeamId: process.env.APPLE_TEAM_ID,
    windowsCertPath: process.env.WINDOWS_CERT_PATH,
    windowsCertPassword: process.env.WINDOWS_CERT_PASSWORD,
  };

  try {
    validateEnvironment(config);
    executeTauriBuild(config);
    const artifacts = collectArtifacts(config.targetPlatform);

    return {
      success: true,
      artifacts,
      durationMs: Date.now() - startTime,
    };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown pipeline error occurred.';
    console.error(`[Pipeline Error] ${errorMessage}`);
    return {
      success: false,
      artifacts: [],
      durationMs: Date.now() - startTime,
      error: errorMessage,
    };
  }
}

// Execute pipeline if run directly
if (require.main === module) {
  runDistributionPipeline().then(result => {
    if (!result.success) {
      process.exit(1);
    }
    console.log('[Pipeline] All signing, building, and collection steps finished successfully.');
  });
}
