/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';

export interface SigningConfigBase {
  appName: string;
  version: string;
}

export interface WindowsSigningConfig {
  certificatePath: string;
  certificatePasswordEnvName: string;
  timestampServerUrl: string;
}

export interface MacOsSigningConfig {
  signingIdentity: string;
  notarizationProfile: string;
  entitlementsPath: string;
}

export interface DistributionManifest extends SigningConfigBase {
  windows?: WindowsSigningConfig;
  macos?: MacOsSigningConfig;
}

/**
 * Responsibility 1: File System Asset Validation
 */
export class FileSystemValidator {
  public static validatePathExists(filePath: string): boolean {
    return fs.existsSync(filePath);
  }
}

/**
 * Responsibility 2: Environment Variable Extraction & Verification
 */
export class EnvironmentValidator {
  public static validateEnvVar(envName: string): boolean {
    return typeof process.env[envName] === 'string' && process.env[envName]!.length > 0;
  }
}

/**
 * Responsibility 3: Platform-Specific Schema Assertion & Configuration Reader
 */
export class ConfigurationReader<T extends DistributionManifest> {
  constructor(private rawConfig: T) {}

  public assertWindowsConfig(): void {
    if (this.rawConfig.windows) {
      const { certificatePath, certificatePasswordEnvName } = this.rawConfig.windows;
      
      if (!FileSystemValidator.validatePathExists(certificatePath)) {
        throw new Error(`Windows signing certificate not found at path: ${certificatePath}`);
      }
      
      if (!EnvironmentValidator.validateEnvVar(certificatePasswordEnvName)) {
        throw new Error(`Environment variable missing or empty for Windows cert password: ${certificatePasswordEnvName}`);
      }
    }
  }

  public assertMacOsConfig(): void {
    if (this.rawConfig.macos) {
      const { entitlementsPath } = this.rawConfig.macos;
      
      if (!FileSystemValidator.validatePathExists(entitlementsPath)) {
        throw new Error(`macOS entitlements file not found at path: ${entitlementsPath}`);
      }
    }
  }

  public validate(): T {
    if (!this.rawConfig.appName || !this.rawConfig.version) {
      throw new Error("Invalid base configuration: appName and version are mandatory.");
    }
    this.assertWindowsConfig();
    this.assertMacOsConfig();
    return this.rawConfig;
  }
}
