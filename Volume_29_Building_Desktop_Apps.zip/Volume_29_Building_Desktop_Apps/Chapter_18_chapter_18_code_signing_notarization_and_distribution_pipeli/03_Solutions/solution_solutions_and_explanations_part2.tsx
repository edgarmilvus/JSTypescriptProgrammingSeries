/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

export type PipelineStage = 'idle' | 'signing' | 'notarizing' | 'stapling' | 'completed' | 'failed';

export interface PipelineEvent<T = Record<string, unknown>> {
  stage: PipelineStage;
  timestamp: number;
  message: string;
  metadata: T;
}

export interface SigningPipelineMonitorProps<T> {
  currentEvent: PipelineEvent<T>;
  onRetry?: () => void;
}

/**
 * SRP Module 1: Step Status Indicator Icon/Badge
 */
export const StageIndicator: React.FC<{ stage: PipelineStage; currentStage: PipelineStage }> = ({ stage, currentStage }) => {
  const isActive = stage === currentStage;
  return <span className={`badge ${isActive ? 'active' : 'inactive'}`}>{stage.toUpperCase()}</span>;
};

/**
 * SRP Module 2: Log Output Container
 */
export const LogOutputContainer: React.FC<{ message: string; timestamp: number }> = ({ message, timestamp }) => {
  return (
    <div className="log-container">
      <span className="timestamp">[{new Date(timestamp).toLocaleTimeString()}]</span>
      <p className="log-message">{message}</p>
    </div>
  );
};

/**
 * Main Component adhering to SRP by delegating rendering sub-concerns
 */
export const SigningPipelineMonitor = <T,>({ currentEvent }: SigningPipelineMonitorProps<T>) => {
  const stages: PipelineStage[] = ['signing', 'notarizing', 'stapling'];

  return (
    <div className="signing-monitor-container">
      <div className="stages-progress-bar">
        {stages.map((stg) => (
          <StageIndicator key={stg} stage={stg} currentStage={currentEvent.stage} />
        ))}
      </div>
      <LogOutputContainer message={currentEvent.message} timestamp={currentEvent.timestamp} />
    </div>
  );
};
