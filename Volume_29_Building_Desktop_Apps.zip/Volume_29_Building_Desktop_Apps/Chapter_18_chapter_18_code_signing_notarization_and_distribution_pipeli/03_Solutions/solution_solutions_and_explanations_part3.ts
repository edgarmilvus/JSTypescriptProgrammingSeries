/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface ToolDependency {
  name: string;
  executableName: string;
  minVersion: string;
  targetPlatform: 'win32' | 'darwin' | 'linux';
}

/**
 * Responsibility 1: Process Execution Abstraction Mock
 */
export class ProcessExecutor {
  public static async executeVersionCheck(_executable: string): Promise<string> {
    // Mock implementation for dependency version output extraction
    return "v1.0.0";
  }
}

/**
 * Responsibility 2: Semantic Version Parsing & Assertion Engine
 */
export class VersionParser {
  public static satisfiesMinimum(currentVersion: string, minVersion: string): boolean {
    const cleanCurrent = currentVersion.replace(/[^0-9.]/g, '');
    const cleanMin = minVersion.replace(/[^0-9.]/g, '');
    return cleanCurrent >= cleanMin;
  }
}

/**
 * Responsibility 3: Dependency Resolution Coordinator
 */
export class DependencyResolver<T extends ToolDependency> {
  constructor(private dependencies: T[]) {}

  public async verifyDependency(dependency: T): Promise<boolean> {
    try {
      const output = await ProcessExecutor.executeVersionCheck(dependency.executableName);
      return VersionParser.satisfiesMinimum(output, dependency.minVersion);
    } catch {
      return false;
    }
  }

  public async resolveAll(): Promise<Map<string, boolean>> {
    const results = new Map<string, boolean>();
    for (const dep of this.dependencies) {
      const isValid = await this.verifyDependency(dep);
      results.set(dep.name, isValid);
    }
    return results;
  }
}
