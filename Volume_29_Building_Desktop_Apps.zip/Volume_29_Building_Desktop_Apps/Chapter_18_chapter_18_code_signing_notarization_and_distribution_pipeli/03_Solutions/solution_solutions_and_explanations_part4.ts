/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface GitHubActionStep {
  name: string;
  run?: string;
  uses?: string;
  with?: Record<string, string | number | boolean>;
  env?: Record<string, string>;
}

export interface GitHubActionJob<T = Record<string, string>> {
  runsOn: string;
  strategy?: {
    matrix: T;
  };
  steps: GitHubActionStep[];
}

/**
 * SRP Module 1: Job Matrix Builder
 */
export class MatrixBuilder<TMatrix extends Record<string, any>> {
  constructor(private matrixConfig: TMatrix) {}
  public build(): { matrix: TMatrix } {
    return { matrix: this.matrixConfig };
  }
}

/**
 * SRP Module 2: Pipeline Step Injection Engine
 */
export class StepInjector {
  public static createRustSetupStep(): GitHubActionStep {
    return { name: 'Setup Rust Toolchain', uses: 'actions-rs/toolchain@v1', with: { profile: 'minimal', toolchain: 'stable' } };
  }

  public static createTauriExecutionStep(envVars: Record<string, string>): GitHubActionStep {
    return { name: 'Run Tauri Bundler', run: 'npm run tauri build', env: envVars };
  }
}

/**
 * SRP Module 3: Workflow Orchestrator
 */
export class WorkflowBuilder<TMatrix extends Record<string, any>> {
  private jobs: Record<string, GitHubActionJob<TMatrix>> = {};

  public addJob(jobId: string, job: GitHubActionJob<TMatrix>): this {
    this.jobs[jobId] = job;
    return this;
  }

  public getJobs(): Record<string, GitHubActionJob<TMatrix>> {
    return this.jobs;
  }
}
