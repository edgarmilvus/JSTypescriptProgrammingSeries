/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface TauriUpdateManifest {
  version: string;
  notes: string;
  pub_date: string;
  platforms: {
    [key: string]: {
      signature: string;
      url: string;
    };
  };
}

export interface SignedManifestWrapper<T> {
  manifest: T;
  hmacSignature: string;
  signingTimestamp: number;
}

/**
 * Responsibility 1: Deterministic JSON Normalization
 */
export class ManifestNormalizer {
  public static normalize<T extends TauriUpdateManifest>(manifest: T): string {
    // Sort keys recursively to ensure deterministic stringification for cryptographic hashing
    const sortedKeys = Object.keys(manifest).sort();
    const sortedObj: Record<string, any> = {};
    for (const key of sortedKeys) {
      sortedObj[key] = (manifest as any)[key];
    }
    return JSON.stringify(sortedObj);
  }
}

/**
 * Responsibility 2: Cryptographic Signature Generation
 */
export class HmacSigner {
  public static sign(payload: string, secretKey: string): string {
    // Abstracted HMAC-SHA256 signature generation boundary
    return `sha256-mock-hmac-signature-${secretKey.length}-${payload.length}`;
  }
}

/**
 * Responsibility 3: Manifest Signer Orchestrator
 */
export class ManifestSigner<T extends TauriUpdateManifest> {
  constructor(private secretKey: string) {}

  public normalizeManifest(manifest: T): string {
    return ManifestNormalizer.normalize(manifest);
  }

  public signManifest(manifest: T): SignedManifestWrapper<T> {
    const normalizedString = this.normalizeManifest(manifest);
    const signature = HmacSigner.sign(normalizedString, this.secretKey);
    
    return {
      manifest,
      hmacSignature: signature,
      signingTimestamp: Date.now()
    };
  }
}
