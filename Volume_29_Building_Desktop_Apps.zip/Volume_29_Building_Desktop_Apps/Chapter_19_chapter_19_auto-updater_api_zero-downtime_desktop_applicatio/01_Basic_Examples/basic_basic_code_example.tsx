/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useEffect } from 'react';
import { check } from '@plugin-updater/api';
import { relaunch } from '@tauri-apps/plugin-process';

/**
 * Interface representing the update status payload returned 
 * by the Tauri 2.0 update check routine.
 */
interface UpdateInfo {
  version: string;
  notes?: string;
  date?: string;
}

/**
 * SaaS Desktop Application Component for Managing Auto-Updates.
 * 
 * This component handles the lifecycle of checking, downloading, 
 * and applying zero-downtime updates within a Tauri 2.0 environment.
 */
export const SaaSUpdaterManager: React.FC = () => {
  // State tracking for the update lifecycle
  const [checking, setChecking] = useState<boolean>(false);
  const [updateAvailable, setUpdateAvailable] = useState<boolean>(false);
  const [updateDetails, setUpdateDetails] = useState<UpdateInfo | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [downloading, setDownloading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Triggers an asynchronous check against the configured SaaS update server endpoint.
   * Utilizes Tauri 2.0's cryptographic signature verification under the hood.
   */
  const checkForAppUpdates = async (): Promise<void> => {
    try {
      setChecking(true);
      setError(null);

      // 1. Invoke the Tauri 2.0 updater check API
      const update = await check();

      if (update) {
        // 2. An update is available on the remote server
        setUpdateAvailable(true);
        setUpdateDetails({
          version: update.version,
          notes: update.body,
          date: update.date,
        });
      } else {
        // 3. Application is already on the latest version
        console.info('Application is up to date.');
      }
    } catch (err) {
      // Catch network failures, signature mismatches, or malformed JSON responses
      console.error('Failed to check for updates:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred during update check.');
    } finally {
      setChecking(false);
    }
  };

  /**
   * Executes the download and installation sequence for the discovered update.
   * Streams binary data directly to disk and verifies integrity before final staging.
   */
  const executeUpdateDownloadAndInstall = async (): Promise<void> => {
    try {
      setDownloading(true);
      setError(null);

      // Re-fetch the update object handle to perform operational mutations
      const update = await check();

      if (!update) {
        throw new Error('Update handle could not be resolved for downloading.');
      }

      let downloadedBytes = 0;
      let totalBytes = 0;

      // 4. Download the update package with progress event streaming
      await update.downloadAndInstall((event) => {
        switch (event.event) {
          case 'Started':
            totalBytes = event.data.contentLength ?? 0;
            console.info(`Update download started. Total bytes: ${totalBytes}`);
            break;
          case 'Progress':
            downloadedBytes += event.data.chunkLength;
            if (totalBytes > 0) {
              const progressPercentage = Math.round((downloadedBytes / totalBytes) * 100);
              setDownloadProgress(progressPercentage);
            }
            break;
          case 'Finished':
            console.info('Update download completed successfully.');
            break;
        }
      });

      // 5. Trigger zero-downtime application restart to swap binaries
      await relaunch();
    } catch (err) {
      console.error('Failed to download and install update:', err);
      setError(err instanceof Error ? err.message : 'Failed to install the update.');
      setDownloading(false);
    }
  };

  // Automatically check for updates upon application mount (SaaS Best Practice)
  useEffect(() => {
    checkForAppUpdates();
  }, []);

  return (
    <div style={{ padding: '24px', fontFamily: 'sans-serif', maxWidth: '400px' }}>
      <h2>Software Update Manager</h2>
      
      {/* Status Indicators */}
      {checking && <p>Checking for updates from SaaS server...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {/* Update Prompt Card */}
      {updateAvailable && updateDetails && !downloading && (
        <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px' }}>
          <h3>Version {updateDetails.version} Available</h3>
          <p>{updateDetails.notes || 'Performance improvements and bug fixes.'}</p>
          <button 
            onClick={executeUpdateDownloadAndInstall}
            style={{ background: '#0070f3', color: '#white', border: 'none', padding: '10px 16px', borderRadius: '4px', cursor: 'pointer' }}
          >
            Download and Install
          </button>
        </div>
      )}

      {/* Download Progress State */}
      {downloading && (
        <div>
          <p>Downloading update: {downloadProgress}%</p>
          <progress value={downloadProgress} max="100" style={{ width: '100%' }} />
        </div>
      )}
    </div>
  );
};

export default SaaSUpdaterManager;
