/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { check } from '@tauri-apps/plugin-updater';
import { relaunch } from '@tauri-apps/plugin-process';
import { invoke } from '@tauri-apps/api/core';

/**
 * Represents the detailed metadata returned by the Tauri update server.
 */
interface UpdateMetadata {
  version: string;
  notes: string;
  date: string;
}

/**
 * Tracks the granular states of the update lifecycle machine.
 */
type UpdateStatus = 
  | 'IDLE' 
  | 'CHECKING' 
  | 'AVAILABLE' 
  | 'UP-TO-DATE' 
  | 'DOWNLOADING' 
  | 'DOWNLOADED' 
  | 'ERROR';

interface DownloadProgressEvent {
  event: 'Started' | 'Progress' | 'Finished';
  data: {
    chunkLength?: number;
    contentLength?: number;
  };
}

/**
 * Enterprise Updater Manager Component for Tauri 2.0 Desktop Apps.
 * Handles background checks, cryptographic verification handling, 
 * incremental download tracking, and zero-downtime restarts.
 */
export default function DesktopUpdaterController() {
  const [status, setStatus] = useState<UpdateStatus>('IDLE');
  const [updateInfo, setUpdateInfo] = useState<UpdateMetadata | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  /**
   * Step 1: Executes an explicit update check against the remote endpoint.
   * Leverages Tauri 2.0's plugin-updater to query the JSON manifest 
   * and verify Ed25519 signatures automatically under the hood.
   */
  const checkForUpdates = useCallback(async (isSilent: boolean = false) => {
    try {
      setStatus('CHECKING');
      setErrorMessage(null);

      // Invoke the Tauri updater check API
      const update = await check();

      if (update) {
        setUpdateInfo({
          version: update.version,
          notes: update.body || 'No release notes provided.',
          date: update.date || new Date().toISOString(),
        });
        setStatus('AVAILABLE');
        
        if (!isSilent) {
          console.info(`[Updater] New version ${update.version} discovered.`);
        }
      } else {
        setStatus('UP-TO-DATE');
        if (!isSilent) {
          console.info('[Updater] Application is running the latest version.');
        }
      }
    } catch (error) {
      console.error('[Updater] Failed to check for updates:', error);
      setStatus('ERROR');
      setErrorMessage(error instanceof Error ? error.message : String(error));
    }
  }, []);

  /**
   * Step 2: Downloads the verified update package with real-time byte tracking.
   * Listens to chunk-by-chunk download events to drive native progress UI elements.
   */
  const downloadAndInstallUpdate = async () => {
    try {
      setStatus('DOWNLOADING');
      setDownloadProgress(0);

      const update = await check();
      if (!update) {
        throw new Error('No active update instance found during download execution.');
      }

      let downloadedBytes = 0;
      let totalBytes = 0;

      // Execute download with stream event listeners
      await update.downloadAndInstall((event: DownloadProgressEvent) => {
        switch (event.event) {
          case 'Started':
            totalBytes = event.data.contentLength || 0;
            console.info(`[Updater] Download started. Total size: ${totalBytes} bytes`);
            break;
          case 'Progress':
            downloadedBytes += event.data.chunkLength || 0;
            if (totalBytes > 0) {
              const percentage = Math.round((downloadedBytes / totalBytes) * 100);
              setDownloadProgress(percentage);
            }
            break;
          case 'Finished':
            console.info('[Updater] Download and cryptographic verification complete.');
            setDownloadProgress(100);
            break;
        }
      });

      setStatus('DOWNLOADED');
      
      // Automatically trigger zero-downtime relaunch upon successful installation
      await executeZeroDowntimeRelaunch();

    } catch (error) {
      console.error('[Updater] Download or installation sequence failed:', error);
      setStatus('ERROR');
      setErrorMessage(error instanceof Error ? error.message : String(error));
    }
  };

  /**
   * Step 3: Executes a zero-downtime application restart.
   * Flushes active states, persists critical user session caches via Rust backend,
   * and restarts the Tauri binary seamlessly.
   */
  const executeZeroDowntimeRelaunch = async () => {
    try {
      // Optional: Invoke a Rust backend command to flush caches or save state safely
      await invoke('persist_app_state_before_update');

      // Relaunch the Tauri application instance
      await relaunch();
    } catch (error) {
      console.error('[Updater] Zero-downtime relaunch failed:', error);
      setErrorMessage('Failed to restart automatically. Please restart manually.');
    }
  };

  // Automatically check for updates on component mount (background check)
  useEffect(() => {
    checkForUpdates(true);
  }, [checkForUpdates]);

  return (
    <div className="p-6 max-w-md mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold tracking-tight">Software Updates</h2>
        <span className="text-xs uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-800 text-slate-400 font-medium">
          {status}
        </span>
      </div>

      {status === 'CHECKING' && (
        <p className="text-sm text-slate-400 animate-pulse">Checking for available updates...</p>
      )}

      {status === 'UP-TO-ENTIRETY' && (
        <p className="text-sm text-emerald-400">You are running the latest version of the application.</p>
      )}

      {status === 'AVAILABLE' && updateInfo && (
        <div className="space-y-3">
          <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/50">
            <p className="text-sm font-medium text-slate-200">Version {updateInfo.version} is available</p>
            <p className="text-xs text-slate-400 mt-1 line-clamp-3">{updateInfo.notes}</p>
          </div>
          <button
            onClick={downloadAndInstallUpdate}
            className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm rounded-lg transition-colors shadow-lg shadow-indigo-600/20"
          >
            Download & Install Update
          </button>
        </div>
      )}

      {status === 'DOWNLOADING' && (
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Downloading secure package...</span>
            <span>{downloadProgress}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-indigo-500 h-full transition-all duration-300 ease-out" 
              style={{ width: `${downloadProgress}%` }}
            />
          </div>
        </div>
      )}

      {status === 'DOWNLOADED' && (
        <p className="text-sm text-emerald-400 font-medium">Update installed successfully. Restarting application...</p>
      )}

      {status === 'ERROR' && (
        <div className="space-y-2">
          <p className="text-sm text-rose-400">Update encountered an issue: {errorMessage}</p>
          <button
            onClick={() => checkForUpdates(false)}
            className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium rounded-lg transition-colors"
          >
            Retry Check
          </button>
        </div>
      )}
    </div>
  );
}
