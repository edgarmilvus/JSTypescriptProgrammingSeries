/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src-tauri/src/lib.rs
use tauri::{AppHandle, Emitter};
use tauri_plugin_updater::UpdaterExt;
use std::time::Duration;
use tokio::time::sleep;

#[derive(Clone, serde::Serialize)]
pub struct DownloadProgressPayload {
    status: String,
    chunk_length: usize,
    content_length: Option<u64>,
}

#[tauri::command]
pub async fn check_and_install_update(app: AppHandle) -> Result<bool, String> {
    let updater = app.updater().map_err(|e| e.to_string())?;
    
    let update = match updater.check().await {
        Ok(Some(update)) => update,
        Ok(None) => return Ok(false), // No update available
        Err(e) => return Err(format!("Failed to check for updates: {}", e)),
    };

    let mut downloaded = 0;
    let max_retries = 3;
    let mut attempt = 0;

    // Retry loop with exponential backoff for network resilience
    loop {
        attempt += 1;
        let app_handle_clone = app.clone();
        
        let result = update.download_and_install(
            |chunk_length, content_length| {
                downloaded += chunk_length;
                let _ = app_handle_clone.emit("update-progress", DownloadProgressPayload {
                    status: "Downloading".into(),
                    chunk_length: downloaded,
                    content_length,
                });
            },
            || {
                let _ = app_handle_clone.emit("update-progress", DownloadProgressPayload {
                    status: "Finished".into(),
                    chunk_length: 0,
                    content_length: None,
                });
            },
        ).await;

        match result {
            Ok(_) => break,
            Err(e) if attempt < max_retries => {
                let backoff_duration = Duration::from_secs(2u64.pow(attempt));
                eprintln!("Download failed ({:?}). Retrying in {:?}...", e, backoff_duration);
                // Clean up partial cache triggers implicitly handled by plugin workspace, 
                // backing off before next iteration
                sleep(backoff_duration).await;
            }
            Err(e) => return Err(format!("Update installation failed after {} attempts: {}", max_retries, e)),
        }
    }

    Ok(true)
}

#[tauri::command]
pub async fn restart_application(app: AppHandle) {
    app.restart();
}
