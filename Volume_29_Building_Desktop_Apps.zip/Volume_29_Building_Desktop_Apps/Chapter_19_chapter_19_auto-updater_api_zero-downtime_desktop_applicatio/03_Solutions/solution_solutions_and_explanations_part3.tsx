/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/UpdateBanner.tsx
import React, { useState, useEffect } from 'react';
import { check } from '@tauri-apps/plugin-updater';
import { listen } from '@tauri-apps/api/event';
import { invoke } from '@tauri-apps/api/core';

type UpdateState = 'idle' | 'checking' | 'available' | 'downloading' | 'ready_to_restart' | 'error';

interface ProgressEvent {
  status: string;
  chunk_length: number;
  content_length?: number;
}

export const UpdateBanner: React.FC = () => {
  const [state, setState] = useState<UpdateState>('idle');
  const [version, setVersion] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [progress, setProgress] = useState<number>(0);
  const [silentMode, setSilentMode] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    const unlisten = listen<ProgressEvent>('update-progress', (event) => {
      if (event.payload.content_length && event.payload.content_length > 0) {
        const pct = Math.round((event.payload.chunk_length / event.payload.content_length) * 100);
        setProgress(pct);
      }
      if (event.payload.status === 'Finished') {
        setState('ready_to_restart');
      }
    });

    return () => {
      unlisten.then((fn) => fn());
    };
  }, []);

  const checkForUpdates = async () => {
    setState('checking');
    try {
      const update = await check();
      if (update) {
        setVersion(update.version);
        setNotes(update.body || 'No release notes provided.');
        setState('available');
        
        if (silentMode) {
          handleStartDownload();
        }
      } else {
        setState('idle');
      }
    } catch (err) {
      setErrorMessage(String(err));
      setState('error');
    }
  };

  const handleStartDownload = async () => {
    setState('downloading');
    try {
      await invoke('check_and_install_update');
    } catch (err) {
      setErrorMessage(String(err));
      setState('error');
    }
  };

  const handleRestart = async () => {
    await invoke('restart_application');
  };

  if (state === 'idle' || (state === 'checking' && !silentMode)) {
    return (
      <div className="p-4 bg-slate-900 text-white flex justify-between items-center">
        <span>DevToolkit is up to date.</span>
        <button onClick={checkForUpdates} className="px-3 py-1 bg-blue-600 rounded text-sm hover:bg-blue-500">
          Check for Updates
        </button>
      </div>
    );
  }

  if (silentMode && (state === 'downloading' || state === 'checking')) {
    return null; // Suppress UI completely during background silent downloads
  }

  return (
    <div className="fixed bottom-4 right-4 max-w-md w-full bg-slate-800 border border-slate-700 text-white p-5 rounded-xl shadow-2xl z-50">
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-bold text-lg">Update Available ({version})</h3>
        <label className="flex items-center text-xs text-slate-400 gap-1 cursor-pointer">
          <input 
            type="checkbox" 
            checked={silentMode} 
            onChange={(e) => setSilentMode(e.target.checked)} 
          />
          Silent Download
        </label>
      </div>

      {state === 'available' && (
        <>
          <div className="max-h-32 overflow-y-auto text-xs text-slate-300 bg-slate-900 p-2 rounded mb-4 font-mono">
            {notes}
          </div>
          <div className="flex justify-end gap-2">
            <button onClick={() => setState('idle')} className="px-3 py-1.5 text-xs bg-slate-700 rounded hover:bg-slate-600">
              Later
            </button>
            <button onClick={handleStartDownload} className="px-4 py-1.5 text-xs bg-blue-600 font-semibold rounded hover:bg-blue-500">
              Download Update
            </button>
          </div>
        </>
      )}

      {state === 'downloading' && (
        <div>
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Downloading payload...</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
            <div className="bg-blue-500 h-full transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      {state === 'ready_to_restart' && (
        <div className="flex flex-col gap-3">
          <p className="text-xs text-emerald-400">Update successfully verified and unpacked.</p>
          <button onClick={handleRestart} className="w-full py-2 bg-emerald-600 text-white font-bold rounded text-sm hover:bg-emerald-500">
            Restart Now to Apply
          </button>
        </div>
      )}

      {state === 'error' && (
        <div className="flex flex-col gap-2">
          <p className="text-xs text-red-400">Error: {errorMessage}</p>
          <button onClick={checkForUpdates} className="px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-500">
            Retry Download
          </button>
        </div>
      )}
    </div>
  );
};
