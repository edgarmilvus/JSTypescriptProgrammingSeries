/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState } from 'react';
import { useChat } from 'ai/react';
import { z } from 'zod';

/**
 * @fileoverview Cursor-Lite Copilot Chat Component
 * Demonstrates streaming AI interactions coupled with strict JSON Schema 
 * output validation using Zod, integrated via the Vercel AI SDK useChat hook.
 */

// 1. Define the desired JSON Schema using Zod for runtime validation
// This guarantees the LLM's response can be safely parsed by our desktop app backend.
const CodeModificationSchema = z.object({
  filePath: z.string().describe("The relative path of the file to modify."),
  explanation: z.string().describe("A brief description of why this change is being made."),
  diffSnippet: z.string().describe("The exact code patch or replacement block."),
  confidenceScore: z.number().min(0).max(100).describe("AI confidence metric from 0 to 100.")
});

// TypeScript type derived automatically from the Zod schema
type CodeModificationResponse = z.infer<typeof CodeModificationSchema>;

export function CopilotWorkspacePanel() {
  // State to hold successfully parsed structured outputs from the LLM stream
  const [structuredEdits, setStructuredEdits] = useState<CodeModificationResponse[]>([]);
  const [validationError, setValidationError] = useState<string | null>(null);

  // 2. Initialize the Vercel AI SDK useChat hook
  // Handles message threading, typing indicators, and HTTP streaming underneath.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat/copilot',
    onFinish: (message) => {
      // 3. Post-process the final message content to extract and validate JSON
      try {
        setValidationError(null);
        // Assuming the LLM wraps its JSON response in a markdown code block or outputs raw JSON
        const rawJsonMatch = message.content.match(/\{[\s\S]*\}/);
        
        if (!rawJsonMatch) {
          throw new Error("No valid JSON structure found in the AI response.");
        }

        const parsedJson = JSON.parse(rawJsonMatch[0]);

        // 4. Validate the parsed object against our strict Zod schema
        const validatedData = CodeModificationSchema.parse(parsedJson);

        // Store the valid structured output into component state
        setStructuredEdits((prev) => [...prev, validatedData]);
      } catch (err: any) {
        // Handle structural drift or schema violation gracefully
        setValidationError(`Schema validation failed: ${err.message}`);
      }
    },
  });

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'sans-serif', backgroundColor: '#1e1e1e', color: '#d4d4d4' }}>
      {/* Left Pane: Chat Interface */}
      <div style={{ width: '50%', display: 'flex', flexDirection: 'column', borderRight: '1px solid #333', padding: '16px' }}>
        <h2>Cursor-Lite Copilot Chat</h2>
        
        {/* Chat message history container */}
        <div style={{ flex: 1, overflowY: 'auto', marginBottom: '16px', padding: '8px', background: '#252526', borderRadius: '6px' }}>
          {messages.map((m) => (
            <div key={m.id} style={{ marginBottom: '12px', padding: '8px', borderRadius: '4px', background: m.role === 'user' ? '#007acc' : '#2d2d2d' }}>
              <strong>{m.role === 'user' ? 'You: ' : 'Copilot: '}</strong>
              <span style={{ whiteSpace: 'pre-wrap' }}>{m.content}</span>
            </div>
          ))}
          {isLoading && <div style={{ fontStyle: 'italic', color: '#858585' }}>Copilot is thinking and structuring code...</div>}
        </div>

        {/* Validation Error Banner */}
        {validationError && (
          <div style={{ background: '#5a1d1d', color: '#f88', padding: '8px', borderRadius: '4px', marginBottom: '8px', fontSize: '12px' }}>
            {validationError}
          </div>
        )}

        {/* Chat Input Form */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '8px' }}>
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Ask Copilot to refactor or write code..."
            style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #333', background: '#3c3c3c', color: '#fff' }}
          />
          <button type="submit" disabled={isLoading} style={{ padding: '8px 16px', background: '#0e639c', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Send
          </button>
        </form>
      </div>

      {/* Right Pane: Structured Code Modifications Feed */}
      <div style={{ width: '50%', padding: '16px', overflowY: 'auto' }}>
        <h2>Verified Workspace Edits</h2>
        <p style={{ fontSize: '12px', color: '#858585' }}>
          Guaranteed by JSON Schema & Zod runtime validation. Ready for native Rust backend execution.
        </p>

        {structuredEdits.length === 0 ? (
          <p style={{ color: '#666', fontStyle: 'italic' }}>No structured edits generated yet.</p>
        ) : (
          structuredEdits.map((edit, index) => (
            <div key={index} style={{ background: '#2d2d2d', border: '1px solid #3c3c3c', borderRadius: '6px', padding: '12px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontFamily: 'monospace', color: '#4ec9b0', fontWeight: 'bold' }}>{edit.filePath}</span>
                <span style={{ background: '#1b4721', color: '#4ec9b0', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' }}>
                  Confidence: {edit.confidenceScore}%
                </span>
              </div>
              <p style={{ fontSize: '13px', margin: '0 0 8px 0', color: '#cccccc' }}>{edit.explanation}</p>
              <pre style={{ background: '#1e1e1e', padding: '8px', borderRadius: '4px', overflowX: 'auto', margin: 0, fontSize: '12px', color: '#ce9178' }}>
                <code>{edit.diffSnippet}</code>
              </pre>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
