/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part10.ts
// Description: Basic Code Example
// ==========================================

        <div style={{ flex: 1, overflowY: 'auto', marginBottom: '16px', padding: '8px', background: '#252526', borderRadius: '6px' }}>
          {messages.map((m) => (
            <div key={m.id} style={{ marginBottom: '12px', padding: '8px', borderRadius: '4px', background: m.role === 'user' ? '#007acc' : '#2d2d2d' }}>
              <strong>{m.role === 'user' ? 'You: ' : 'Copilot: '}</strong>
              <span style={{ whiteSpace: 'pre-wrap' }}>{m.content}</span>
            </div>
          ))}
          {isLoading && <div style={{ fontStyle: 'italic', color: '#858585' }}>Copilot is thinking and structuring code...</div>}
        </div>
