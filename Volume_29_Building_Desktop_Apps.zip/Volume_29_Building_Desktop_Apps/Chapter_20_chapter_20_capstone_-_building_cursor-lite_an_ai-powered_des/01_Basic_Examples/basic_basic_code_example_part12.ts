/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part12.ts
// Description: Basic Code Example
// ==========================================

      {/* Right Pane: Structured Code Modifications Feed */}
      <div style={{ width: '50%', padding: '16px', overflowY: 'auto' }}>
        <h2>Verified Workspace Edits</h2>
        <p style={{ fontSize: '12px', color: '#858585' }}>
          Guaranteed by JSON Schema & Zod runtime validation. Ready for native Rust backend execution.
        </p>

        {structuredEdits.length === 0 ? (
          <p style={{ color: '#666', fontStyle: 'italic' }}>No structured edits generated yet.</p>
        ) : (
          structuredEdits.map((edit, index) => (
            <div key={index} style={{ background: '#2d2d2d', border: '1px solid #3c3c3c', borderRadius: '6px', padding: '12px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontFamily: 'monospace', color: '#4ec9b0', fontWeight: 'bold' }}>{edit.filePath}</span>
                <span style={{ background: '#1b4721', color: '#4ec9b0', padding: '2px 6px', borderRadius: '4px', fontSize: '11px' }}>
                  Confidence: {edit.confidenceScore}%
                </span>
              </div>
              <p style={{ fontSize: '13px', margin: '0 0 8px 0', color: '#cccccc' }}>{edit.explanation}</p>
              <pre style={{ background: '#1e1e1e', padding: '8px', borderRadius: '4px', overflowX: 'auto', margin: 0, fontSize: '12px', color: '#ce9178' }}>
                <code>{edit.diffSnippet}</code>
              </pre>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
