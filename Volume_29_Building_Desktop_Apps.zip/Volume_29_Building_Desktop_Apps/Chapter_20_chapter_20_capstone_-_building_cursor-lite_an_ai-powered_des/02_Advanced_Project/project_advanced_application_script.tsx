/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file Cursor-Lite IDE Copilot - Advanced Application Script
 * @description Orchestrates Tauri IPC, LLM streaming via Vercel AI SDK, 
 * and Zod schema validation for automated IDE refactoring tasks.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { useChat } from 'ai/react';
import { z } from 'zod';

/**
 * Zod schema defining the expected structural output from the LLM 
 * when performing an automated workspace refactor or code modification.
 */
const RefactorActionSchema = z.object({
  filePath: z.string().describe('The relative path of the file to modify'),
  action: z.enum(['CREATE', 'MODIFY', 'DELETE']),
  originalSnippet: z.string().optional().describe('The code snippet to find and replace'),
  newSnippet: z.string().describe('The new code snippet to insert'),
  explanation: z.string().describe('Reasoning for the architectural change'),
});

type RefactorAction = z.infer<typeof RefactorActionSchema>;

/**
 * Interface representing a workspace file payload indexed by the Rust backend.
 */
interface WorkspaceFile {
  path: string;
  content: string;
  language: string;
}

/**
 * Main application component for the Cursor-Lite Copilot interface.
 */
export function CursorLiteCopilot() {
  const [workspaceFiles, setWorkspaceFiles] = useState<WorkspaceFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [isIndexing, setIsIndexing] = useState<boolean>(false);
  const [activeRefactor, setActiveRefactor] = useState<RefactorAction | null>(null);
  const [errorLog, setErrorLog] = useState<string | null>(null);

  // Initialize the Vercel AI SDK useChat hook for conversational copilot features
  const { messages, input, handleInputChange, handleSubmit, isLoading, setMessages } = useChat({
    api: '/api/copilot/stream',
    onFinish: (message) => {
      try {
        // Attempt to parse structured JSON block if the model returned an action schema
        const jsonMatch = message.content.match(/\{[\s\S]*\D\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          const validationResult = RefactorActionSchema.safeParse(parsed);
          if (validationResult.success) {
            setActiveRefactor(validationResult.data);
          }
        }
      } catch (err) {
        console.warn('Response was conversational, no JSON schema detected.');
      }
    },
  });

  /**
   * 1. Trigger the Rust backend to index the active workspace directory.
   * Listens to Tauri window events for real-time progress updates.
   */
  const handleIndexWorkspace = async () => {
    setIsIndexing(true);
    setErrorLog(null);
    try {
      // Invoke Rust command via Tauri 2.0 IPC bridge
      const files = await invoke<WorkspaceFile[]>('index_workspace_directory');
      setWorkspaceFiles(files);
    } catch (err) {
      setErrorLog(`Failed to index workspace: ${err}`);
    } finally {
      setIsIndexing(false);
    }
  };

  /**
   * 2. Set up event listeners for background file-system changes 
   * captured by the Rust notify crate.
   */
  useEffect(() => {
    const unlistenPromise = listen<WorkspaceFile>('fs-change-event', (event) => {
      setWorkspaceFiles((prev) => {
        const index = prev.findIndex((f) => f.path === event.payload.path);
        if (index >= 0) {
          const updated = [...prev];
          updated[index] = event.payload;
          return updated;
        }
        return [...prev, event.payload];
      });
    });

    return () => {
      unlistenPromise.then((unlisten) => unlisten());
    };
  }, []);

  /**
   * 3. Apply the validated LLM refactor action back to the Rust backend
   * for native file system writing.
   */
  const executeRefactor = async () => {
    if (!activeRefactor) return;
    try {
      await invoke('apply_file_modification', { action: activeRefactor });
      setActiveRefactor(null);
      await handleIndexWorkspace(); // Refresh workspace state
    } catch (err) {
      setErrorLog(`Failed to write file modification: ${err}`);
    }
  };

  return (
    <div className="flex h-screen bg-gray-950 text-gray-100 font-sans">
      {/* Sidebar: Workspace File Explorer */}
      <aside className="w-80 border-r border-gray-800 flex flex-col">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h2 className="font-semibold text-sm tracking-wide">Workspace Explorer</h2>
          <button
            onClick={handleIndexWorkspace}
            disabled={isIndexing}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-xs rounded font-medium transition"
          >
            {isIndexing ? 'Indexing...' : 'Index Project'}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {workspaceFiles.map((file) => (
            <div
              key={file.path}
              onClick={() => setSelectedFile(file.path)}
              className={`p-2 rounded cursor-pointer text-sm truncate ${
                selectedFile === file.path ? 'bg-gray-800 text-white' : 'text-gray-400 hover:bg-gray-900'
              }`}
            >
              {file.path}
            </div>
          ))}
        </div>
      </aside>

      {/* Main Chat and Copilot Workspace */}
      <main className="flex-1 flex flex-col">
        <header className="h-14 border-b border-gray-800 flex items-center px-6">
          <h1 className="text-sm font-medium">Cursor-Lite IDE Copilot (Tauri 2.0 + Rust)</h1>
        </header>

        {errorLog && (
          <div className="bg-red-900/50 border-b border-red-700 p-3 text-xs text-red-200">
            {errorLog}
          </div>
        )}

        {/* Chat History Container */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-xl rounded-lg p-4 text-sm ${
                  m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-900 border border-gray-800 text-gray-200'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}
        </div>

        {/* Structured Refactor Action Banner */}
        {activeRefactor && (
          <div className="bg-gray-900 border-t border-blue-500 p-4 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Suggested Refactor</span>
              <p className="text-sm font-medium">{activeRefactor.explanation}</p>
              <span className="text-xs text-gray-400">Target: {activeRefactor.filePath} ({activeRefactor.action})</span>
            </div>
            <div className="space-x-2">
              <button
                onClick={() => setActiveRefactor(null)}
                className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-xs rounded"
              >
                Reject
              </button>
              <button
                onClick={executeRefactor}
                className="px-3 py-1.5 bg-green-600 hover:bg-green-500 text-xs rounded font-medium"
              >
                Apply Changes
              </button>
            </div>
          </div>
        )}

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-gray-800 flex gap-2">
          <input
            value={input}
            onChange={handleInputChange}
            placeholder="Ask your copilot to refactor code or explain files..."
            className="flex-1 bg-gray-900 border border-gray-800 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-sm font-medium rounded-lg transition"
          >
            Send
          </button>
        </form>
      </main>
    </div>
  );
}
