/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { invoke } from '@tauri-apps/api/core';

// Complete Zod schema definition matching requirements
const CodeAnalysisSchema = z.object({
  issues: z.array(
    z.object({
      file: z.string(),
      line: z.number(),
      severity: z.enum(["low", "medium", "high", "critical"]),
      message: z.string(),
      suggestedFix: z.string().optional(),
    })
  ),
  summary: z.string(),
});

export type CodeAnalysisResult = z.infer<typeof CodeAnalysisSchema>;

export async function requestStructuredCodeAnalysis(sourceCode: string, filePath: string): Promise<CodeAnalysisResult> {
  try {
    // Invoke the Tauri backend command that interfaces with the LLM provider
    const rawResponse = await invoke<string>('ai_analyze_code_structured', {
      sourceCode,
      filePath,
      schema: CodeAnalysisSchema.shape, // Passing schema metadata to backend/LLM provider
    });

    // Parse the raw string response and validate it against the Zod schema
    const parsedData = JSON.parse(rawResponse);
    return CodeAnalysisSchema.parse(parsedData);

  } catch (error) {
    console.error("Failed to parse structured LLM output:", error);
    // Return a safe fallback structure instead of throwing
    return {
      issues: [],
      summary: "Error: Failed to process structured AI analysis due to schema validation failure."
    };
  }
}
