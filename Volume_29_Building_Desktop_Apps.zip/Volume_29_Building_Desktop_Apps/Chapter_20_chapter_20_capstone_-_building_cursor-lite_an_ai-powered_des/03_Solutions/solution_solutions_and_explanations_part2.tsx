/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { useChat } from 'ai/react';

interface ChatSidebarProps {
  activeFileContext?: string;
}

export const CopilotChatSidebar: React.FC<ChatSidebarProps> = ({ activeFileContext }) => {
  // Configure useChat hook with context parameters routed via Tauri IPC / proxy
  const { messages, input, handleInputChange, handleSubmit, stop, isLoading } = useChat({
    api: '/api/tauri-chat-proxy', 
    body: {
      context: activeFileContext,
    },
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const userScrolledUp = useRef<boolean>(false);

  // Handle scroll events to detect if user manually scrolled up
  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
      userScrolledUp.current = !isAtBottom;
    }
  };

  // Auto-scrolling behavior respecting manual user scroll interruptions
  useEffect(() => {
    if (scrollRef.current && !userScrolledUp.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100 p-4">
      <div 
        ref={scrollRef} 
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto space-y-4 pr-2"
      >
        {messages.map((m) => (
          <div key={m.id} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
            <span className="text-xs text-slate-400 mb-1">{m.role}</span>
            <div className={`p-3 rounded-lg max-w-[85%] ${m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-800 border border-slate-700'}`}>
              {m.content}
            </div>
          </div>
        ))}
      </div>

      {isLoading && (
        <div className="flex items-center justify-between py-2">
          <span className="text-xs text-amber-400 animate-pulse">Copilot is thinking...</span>
          <button 
            type="button"
            onClick={() => stop()}
            className="px-2 py-1 bg-red-600 hover:bg-red-700 text-xs rounded text-white transition-colors"
          >
            Stop Generation
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask Cursor-Lite anything about your workspace..."
          className="flex-1 bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
        />
        <button 
          type="submit" 
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 px-4 py-2 rounded text-sm font-medium transition-colors"
        >
          Send
        </button>
      </form>
    </div>
  );
};
