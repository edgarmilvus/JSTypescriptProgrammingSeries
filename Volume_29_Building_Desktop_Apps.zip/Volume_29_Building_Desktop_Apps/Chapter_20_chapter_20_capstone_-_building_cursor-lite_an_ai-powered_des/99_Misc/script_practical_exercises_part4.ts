/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import { listen, UnlistenFn } from '@tauri-apps/api/event';

interface TokenPayload {
  chunk: string;
  isFinished: boolean;
  error?: string;
}

export class TauriStreamManager {
  private unlistenTokenEvent: UnlistenFn | null = null;
  private tokenBuffer: string[] = [];
  private isFlushScheduled = false;

  public async subscribeToStream(
    onTokenUpdate: (accumulatedText: string) => void,
    onComplete: () => void,
    onError: (errorMessage: string) => void
  ): Promise<void> {
    
    // TODO: Subscribe to the Tauri event 'llm-token-stream' using listen()
    this.unlistenTokenEvent = await listen<TokenPayload>('llm-token-stream', (event) => {
      const { chunk, isFinished, error } = event.payload;

      if (error) {
        onError(error);
        this.cleanup();
        return;
      }

      if (isFinished) {
        onComplete();
        this.cleanup();
        return;
      }

      // TODO: Push chunk into buffer and schedule a batched update using requestAnimationFrame
      this.tokenBuffer.push(chunk);
      this.scheduleFlush(onTokenUpdate);
    });
  }

  private scheduleFlush(callback: (text: string) => void) {
    if (this.isFlushScheduled) return;

    this.isFlushScheduled = true;
    requestAnimationFrame(() => {
      // Flush buffered tokens into the UI callback in a single batch operation
      const fullTextBatch = this.tokenBuffer.join('');
      callback(fullTextBatch);
      this.isFlushScheduled = false;
    });
  }

  public cleanup() {
    if (this.unlistenTokenEvent) {
      this.unlistenTokenEvent();
      this.unlistenTokenEvent = null;
    }
    this.tokenBuffer = [];
  }
}
