/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * FinTech Architecture in TypeScript: Precision Math
 * Chapter 1: The IEEE 754 Trap - Basic Code Example
 * 
 * This module demonstrates the failure of native JS numbers in payment processing
 * and the correct approach using arbitrary-precision decimal mathematics.
 */

import Decimal from 'decimal.js';

// ==========================================
// 1. DOMAIN INTERFACES & TYPES
// ==========================================

/**
 * Represents an incoming raw payment payload from a client web application.
 * Note that financial amounts are frequently transmitted as strings or numbers.
 */
interface RawPaymentPayload {
  transactionId: string;
  baseAmount: number;
  taxRate: number;
  discountAmount: number;
}

/**
 * Represents the finalized, precision-guaranteed financial calculation result.
 */
interface VerifiedLedgerEntry {
  transactionId: string;
  subtotal: string;
  taxAmount: string;
  totalPayable: string;
}

// ==========================================
// 2. CONFIGURATION & SETUP
// ==========================================

// Configure Decimal.js to use standard rounding (ROUND_HALF_UP) 
// and maintain sufficient precision for financial intermediate steps.
Decimal.set({ 
  precision: 20, 
  rounding: Decimal.ROUND_HALF_UP 
});

// ==========================================
// 3. CORE PROCESSING FUNCTIONS
// ==========================================

/**
 * ANTI-PATTERN: Demonstrates the inherent danger of native IEEE 754 arithmetic.
 * DO NOT use this for real financial pipelines.
 * 
 * @param payload - The raw payment data
 */
function processPaymentWithNativeMath(payload: RawPaymentPayload): void {
  console.log(`\n--- [INSECURE] Native IEEE 754 Calculation ---`);
  console.log(`Input Base Amount: ${payload.baseAmount}`);
  console.log(`Input Tax Rate: ${payload.taxRate}`);

  // Flaw 1: Multiplying floats directly
  const naiveTax = payload.baseAmount * payload.taxRate;
  console.log(`Naive Calculated Tax (baseAmount * taxRate): ${naiveTax}`);
  // Expected output conceptually: 15.675 (if base 105.00 and tax 0.149285...) 
  // Let's use a classic trap: 0.1 + 0.2 or 100.55 * 1.05

  const subtotal = 100.55;
  const taxMultiplier = 1.05;
  const insecureResult = subtotal * taxMultiplier;

  console.log(`Multiplying 100.55 * 1.05 using native numbers yields: ${insecureResult}`);
  console.log(`Type of result: ${typeof insecureResult}`);
  
  // Notice the trailing floating point artifact: 105.57750000000001 instead of 105.5775
  // When truncated to cents (e.g., toFixed(2)), it might round incorrectly due to representation error.
  console.log(`To Fixed 2: ${insecureResult.toFixed(2)}`);
}

/**
 * BEST PRACTICE: Processes financial transactions using arbitrary-precision arithmetic.
 * Ensures strict safety margins for ledger entries.
 * 
 * @param payload - The raw payment data
 * @returns VerifiedLedgerEntry with exact string-representation amounts
 */
function processPaymentWithExactPrecision(payload: RawPaymentPayload): VerifiedLedgerEntry {
  console.log(`\n--- [SECURE] Decimal.js Exact-Precision Calculation ---`);

  // Convert inputs immediately to Decimal instances to isolate from IEEE 754 contamination
  const base = new Decimal(payload.baseAmount);
  const taxRate = new Decimal(payload.taxRate);
  const discount = new Decimal(payload.discountAmount);

  // Perform arithmetic operations using method chaining
  // Formula: Subtotal = Base - Discount
  const subtotal = base.minus(discount);

  // Formula: Tax Amount = Subtotal * Tax Rate
  const rawTaxAmount = subtotal.times(taxRate);

  // Round tax to 2 decimal places for fiat currency compliance (Cents precision)
  const taxAmount = rawTaxAmount.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

  // Formula: Total Payable = Subtotal + Tax Amount
  const totalPayable = subtotal.plus(taxAmount).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

  return {
    transactionId: payload.transactionId,
    subtotal: subtotal.toFixed(2),
    taxAmount: taxAmount.toFixed(2),
    totalPayable: totalPayable.toFixed(2),
  };
}

// ==========================================
// 4. EXECUTION SIMULATION (SaaS Context)
// ==========================================

// Simulate an incoming JSON payload from a Stripe/Checkout webhook or frontend API
const incomingWebhookPayload: RawPaymentPayload = {
  transactionId: "txn_998127364509",
  baseAmount: 100.55,
  taxRate: 0.0825,      // 8.25% Sales Tax
  discountAmount: 10.00 // $10 promotional discount
};

// Execute insecure method to expose the flaw
processPaymentWithNativeMath(incomingWebhookPayload);

// Execute secure method to demonstrate resolution
const secureLedgerRecord = processPaymentWithExactPrecision(incomingWebhookPayload);

console.log(`\n--- Final Verified Ledger Output ---`);
console.log(JSON.stringify(secureLedgerRecord, null, 2));
