/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import Decimal from 'decimal.js';
import { z } from 'zod';

// Configure global Decimal precision and rounding modes for financial compliance
Decimal.set({
  precision: 20,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Zod schema enforcing strict boundary parsing for incoming payment payloads.
 * Prevents IEEE 754 contamination by intercepting strings or numbers and converting 
 * them safely into validated Decimal instances via transforms.
 */
export const FinancialPayloadSchema = z.object({
  sourceAmount: z.union([z.string(), z.number()]).transform((val) => new Decimal(val)),
  sourceCurrency: z.string().length(3),
  targetCurrency: z.string().length(3),
  exchangeRate: z.union([z.string(), z.number()]).transform((val) => new Decimal(val)),
  feePercentage: z.union([z.string(), z.number()]).transform((val) => new Decimal(val)),
});

export type FinancialPayload = z.infer<typeof FinancialPayloadSchema>;

/**
 * Interface representing the immutable output of our financial calculation pipeline.
 */
export interface ExchangeResult {
  rawSourceAmount: string;
  sourceCurrency: string;
  targetCurrency: string;
  exchangeRate: string;
  calculatedFee: string;
  netTargetAmount: string;
  timestamp: string;
}

/**
 * Executes high-precision currency conversion and fee calculation without IEEE 754 degradation.
 * 
 * @param payload - The validated financial input payload containing Decimal objects.
 * @returns An immutable ExchangeResult object ready for ledger insertion.
 */
export function executeFinancialPipeline(payload: FinancialPayload): ExchangeResult {
  const { sourceAmount, sourceCurrency, targetCurrency, exchangeRate, feePercentage } = payload;

  // 1. Calculate platform fee using exact multiplication
  // fee = sourceAmount * (feePercentage / 100)
  const normalizedFeeRate = feePercentage.dividedBy(new Decimal(100));
  const rawFee = sourceAmount.times(normalizedFeeRate);
  
  // Round fee to 2 decimal places for standard fiat currency representation
  const roundedFee = rawFee.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

  // 2. Subtract fee from source amount to determine net convertible balance
  const netSourceAmount = sourceAmount.minus(roundedFee);

  // 3. Apply exchange rate to net source amount
  // targetAmount = netSourceAmount * exchangeRate
  const rawTargetAmount = netSourceAmount.times(exchangeRate);

  // 4. Round target amount to 2 decimal places
  const netTargetAmount = rawTargetAmount.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

  return {
    rawSourceAmount: sourceAmount.toFixed(2),
    sourceCurrency,
    targetCurrency,
    exchangeRate: exchangeRate.toFixed(6), // Maintain higher precision for rates
    calculatedFee: roundedFee.toFixed(2),
    netTargetAmount: netTargetAmount.toFixed(2),
    timestamp: new Date().toISOString(),
  };
}

/**
 * Next.js Server Component demonstrating zero-bundle financial rendering.
 * Executes exclusively on the server, safely processing raw boundary data 
 * into an auditable ledger view component.
 */
export async function FinancialReportServerComponent({ rawData }: { rawData: unknown }) {
  // Step 1: Parse and validate at the system boundary
  const parseResult = FinancialPayloadSchema.safeParse(rawData);

  if (!parseResult.success) {
    return (
      <div className="p-4 border border-red-500 bg-red-50 text-red-700 rounded-md">
        <h3 className="font-bold">Financial Pipeline Validation Error</h3>
        <pre className="text-xs mt-2">{JSON.stringify(parseResult.error.format(), null, 2)}</pre>
      </div>
    );
  }

  // Step 2: Execute precision math pipeline
  const result = executeFinancialPipeline(parseResult.data);

  // Step 3: Render secure server-side markup
  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-xl shadow-lg border border-slate-800">
      <div className="flex justify-between items-center border-b border-slate-700 pb-4 mb-4">
        <h2 className="text-xl font-semibold tracking-wide text-emerald-400">
          Secure Ledger Pipeline Execution
        </h2>
        <span className="text-xs font-mono text-slate-400">{result.timestamp}</span>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-slate-400">Source Principal:</p>
          <p className="text-lg font-mono font-medium">{result.rawSourceAmount} {result.sourceCurrency}</p>
        </div>
        <div>
          <p className="text-slate-400">Calculated Platform Fee:</p>
          <p className="text-lg font-mono font-medium text-amber-400">-{result.calculatedFee} {result.sourceCurrency}</p>
        </div>
        <div>
          <p className="text-slate-400">Applied Exchange Rate:</p>
          <p className="text-lg font-mono font-medium">{result.exchangeRate}</p>
        </div>
        <div>
          <p className="text-slate-400">Net Settled Target:</p>
          <p className="text-lg font-mono font-bold text-emerald-400">{result.netTargetAmount} {result.targetCurrency}</p>
        </div>
      </div>
    </div>
  );
}
