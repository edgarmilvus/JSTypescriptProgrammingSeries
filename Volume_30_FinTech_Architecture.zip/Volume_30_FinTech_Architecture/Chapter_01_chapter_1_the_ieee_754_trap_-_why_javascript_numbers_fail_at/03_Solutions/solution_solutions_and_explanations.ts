/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Decimal } from 'decimal.js';

export type Moneta = {
  readonly value: Decimal;
  readonly currency: string;
};

export interface RawWebhookPayload {
  transactionId: string;
  currency: string;
  amount: number | string;
  breakdown: {
    subtotal: number | string;
    tax: number | string;
    processingFee: number | string;
  };
}

export interface SanitizedWebhookPayload {
  readonly transactionId: string;
  readonly currency: string;
  readonly amount: Decimal;
  readonly breakdown: {
    readonly subtotal: Decimal;
    readonly tax: Decimal;
    readonly processingFee: Decimal;
  };
}

/**
 * Validates whether a raw number is suspect of floating-point contamination.
 * Checks for non-finite values and artifacts like 0.30000000000000004.
 */
function validateAndConvertNumber(val: number | string): Decimal {
  if (typeof val === 'number') {
    if (!Number.isFinite(val)) {
      throw new Error(`Unsafe non-finite number encountered: ${val}`);
    }
    
    // Check for common floating point contamination artifacts (e.g., many digits after decimal)
    const strVal = val.toString();
    if (strVal.includes('.') && strVal.split('.')[1].length > 15) {
      throw new Error(`Suspected floating-point contamination artifact detected: ${val}`);
    }

    return new Decimal(strVal);
  }

  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (trimmed === '' || isNaN(Number(trimmed))) {
      throw new Error(`Invalid numeric string representation: "${val}"`);
    }
    return new Decimal(trimmed);
  }

  throw new Error(`Unsupported type for monetary conversion: ${typeof val}`);
}

export function parseMonetaryPayload(raw: unknown): SanitizedWebhookPayload {
  if (!raw || typeof raw !== 'object') {
    throw new Error('Invalid payload: must be a non-null object.');
  }

  const payload = raw as Record<string, unknown>;

  if (typeof payload.transactionId !== 'string') {
    throw new Error('Missing or invalid transactionId');
  }
  if (typeof payload.currency !== 'string') {
    throw new Error('Missing or invalid currency');
  }

  const breakdown = payload.breakdown as Record<string, unknown>;
  if (!breakdown || typeof breakdown !== 'object') {
    throw new Error('Missing or invalid breakdown object');
  }

  return {
    transactionId: payload.transactionId,
    currency: payload.currency,
    amount: validateAndConvertNumber(payload.amount as number | string),
    breakdown: {
      subtotal: validateAndConvertNumber(breakdown.subtotal as number | string),
      tax: validateAndConvertNumber(breakdown.tax as number | string),
      processingFee: validateAndConvertNumber(breakdown.processingFee as number | string),
    },
  };
}
