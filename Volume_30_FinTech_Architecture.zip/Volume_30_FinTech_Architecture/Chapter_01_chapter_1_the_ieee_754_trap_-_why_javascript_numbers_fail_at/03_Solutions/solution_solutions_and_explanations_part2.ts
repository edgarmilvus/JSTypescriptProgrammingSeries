/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Decimal } from 'decimal.js';

export function allocateAmount(
  totalAmount: Decimal,
  shares: Record<string, Decimal>
): Record<string, Decimal> {
  // Ensure we work with a scale suitable for currency (2 decimal places for cents)
  const scale = 2;
  const hundred = new Decimal(100);

  // Normalize shares if they do not sum up to 100 exactly
  const shareEntries = Object.entries(shares);
  const totalShares = shareEntries.reduce(
    (sum, [, share]) => sum.plus(share),
    new Decimal(0)
  );

  const normalizedShares: [string, Decimal][] = shareEntries.map(([id, share]) => {
    if (totalShares.isZero()) {
      return [id, new Decimal(0)];
    }
    // Normalize percentage relative to totalShares
    const normalized = share.times(hundred).dividedBy(totalShares);
    return [id, normalized];
  });

  const results: Record<string, Decimal> = {};
  const remainders: { id: string; remainder: Decimal }[] = [];

  let allocatedSum = new Decimal(0);

  // Initial proportional allocation using ROUND_DOWN
  for (const [id, normalizedShare] of normalizedShares) {
    const rawAllocation = totalAmount
      .times(normalizedShare)
      .dividedBy(hundred);

    // Floor to currency precision (e.g., 2 decimal places)
    const flooredAllocation = rawAllocation.toDecimalPlaces(scale, Decimal.ROUND_DOWN);
    results[id] = flooredAllocation;
    allocatedSum = allocatedSum.plus(flooredAllocation);

    // Calculate remainder fraction for post-processing adjustment
    const exactScaled = rawAllocation.times(new Decimal(10).pow(scale));
    const remainder = exactScaled.minus(exactScaled.floor());
    remainders.push({ id, remainder });
  }

  // Calculate missing dust (pennies) to distribute
  const subunit = new Decimal(1).dividedBy(new Decimal(10).pow(scale));
  let difference = totalAmount.minus(allocatedSum);
  let penniesToDistribute = difference.dividedBy(subunit).round().toNumber();

  // Sort recipients by largest fractional remainder descending
  remainders.sort((a, b) => b.remainder.comparedTo(a.remainder));

  // Distribute leftover pennies one by one to the largest remainders
  let index = 0;
  while (penniesToDistribute > 0 && index < remainders.length) {
    const targetId = remainders[index].id;
    results[targetId] = results[targetId].plus(subunit);
    penniesToDistribute--;
    index++;
  }

  return results;
}
