/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Decimal } from 'decimal.js';

export type Currency = 'USD' | 'EUR' | 'GBP';

export type Money<TCurrency extends Currency> = {
  readonly __brand: 'Money';
  readonly currency: TCurrency;
  readonly amount: Decimal;
};

export type EntryType = 'DEBIT' | 'CREDIT';

export interface LineItem<TCurrency extends Currency> {
  readonly accountId: string;
  readonly type: EntryType;
  readonly money: Money<TCurrency>;
}

export interface ExchangeRate {
  readonly rate: Decimal;
  readonly timestamp: Date;
}

export interface MultiCurrencyLineItem {
  readonly accountId: string;
  readonly type: EntryType;
  readonly money: Money<Currency>;
  readonly exchangeRate?: ExchangeRate; // Required if cross-currency
}

export interface JournalEntry<TCurrency extends Currency> {
  readonly id: string;
  readonly timestamp: Date;
  readonly lineItems: ReadonlyArray<LineItem<TCurrency>>;
}

/**
 * Validates that a journal entry satisfies the double-entry invariant:
 * Sum(Debits) === Sum(Credits) within the exact same currency.
 */
export function validateJournalEntry<TCurrency extends Currency>(
  entry: JournalEntry<TCurrency>
): boolean {
  let totalDebits = new Decimal(0);
  let totalCredits = new Decimal(0);

  for (const item of entry.lineItems) {
    if (item.type === 'DEBIT') {
      totalDebits = totalDebits.plus(item.money.amount);
    } else if (item.type === 'CREDIT') {
      totalCredits = totalCredits.plus(item.money.amount);
    }
  }

  // Exact comparison using decimal.js .eq() method
  return totalDebits.eq(totalCredits);
}
