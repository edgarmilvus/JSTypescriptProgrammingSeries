/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { Decimal } from 'decimal.js';

export interface TransactionInputFormProps {
  currency: string;
  feePercentage: Decimal;
  fixedFee: Decimal;
  onSubmit: (finalAmount: Decimal, feeAmount: Decimal, netPayout: Decimal) => void;
}

export const TransactionInputForm: React.FC<TransactionInputFormProps> = ({
  currency,
  feePercentage,
  fixedFee,
  onSubmit,
}) => {
  const [rawInput, setRawInput] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Live calculations memoized using decimal.js
  const calculations = useMemo(() => {
    try {
      if (!rawInput.trim()) {
        return { fee: new Decimal(0), net: new Decimal(0) };
      }
      const amount = new Decimal(rawInput);
      if (amount.isNegative()) {
        throw new Error('Amount cannot be negative');
      }

      // Fee = (Amount * (feePercentage / 100)) + fixedFee
      const percentageFee = amount.times(feePercentage).dividedBy(100);
      const totalFee = percentageFee.plus(fixedFee).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
      const netPayout = amount.minus(totalFee).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

      return { fee: totalFee, net: netPayout };
    } catch {
      return { fee: null, net: null };
    }
  }, [rawInput, feePercentage, fixedFee]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow valid partial decimal entry (digits and a single decimal point)
    const sanitized = value.replace(/[^0-9.]/g, '');
    
    // Prevent multiple decimal points
    const parts = sanitized.split('.');
    if (parts.length > 2) return;

    setRawInput(sanitized);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const amount = new Decimal(rawInput);
      if (amount.isZero() || amount.isNegative()) {
        setError('Please enter a valid positive amount.');
        return;
      }
      if (calculations.fee && calculations.net) {
        onSubmit(amount, calculations.fee, calculations.net);
      }
    } catch {
      setError('Invalid numeric input.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="amount-input">Transaction Amount ({currency})</label>
        <input
          id="amount-input"
          type="text"
          placeholder="0.00"
          value={rawInput}
          onChange={handleChange}
        />
      </div>
      {error && <div className="error-message" style={{ color: 'red' }}>{error}</div>}
      <div className="fee-preview">
        <p>Estimated Fee: {calculations.fee ? calculations.fee.toFixed(2) : '0.00'}</p>
        <p>Net Payout: {calculations.net ? calculations.net.toFixed(2) : '0.00'}</p>
      </div>
      <button type="submit">Process Transaction</button>
    </form>
  );
};
