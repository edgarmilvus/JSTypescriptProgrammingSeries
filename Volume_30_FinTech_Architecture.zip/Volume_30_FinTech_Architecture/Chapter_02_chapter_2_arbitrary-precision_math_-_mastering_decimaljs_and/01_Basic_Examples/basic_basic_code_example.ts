/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import Decimal from 'decimal.js';

// Configure global Decimal.js settings for financial consistency.
// We set precision to 20 digits, which is more than enough for currency calculations,
// and enforce ROUND_HALF_UP (standard financial rounding: .5 rounds up).
Decimal.set({
    precision: 20,
    rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Represents a sanitized monetary amount in a specific currency.
 */
export interface Money {
    readonly amount: Decimal;
    readonly currency: string;
}

/**
 * Creates a validated Money object from a primitive number, string, or existing Decimal.
 * 
 * @param value - The raw input value (string preferred to avoid pre-parsing IEEE 754 errors)
 * @param currency - The ISO 4217 currency code (e.g., 'USD', 'EUR')
 * @returns A frozen Money object with arbitrary precision applied
 */
export function createMoney(value: number | string | Decimal, currency: string = 'USD'): Money {
    // Guard against invalid types or NaN states
    const decimalValue = new Decimal(value);
    
    if (!decimalValue.isFinite()) {
        throw new Error(`Invalid monetary value provided: ${value}`);
    }

    return {
        // Enforce immutability and lock precision to 2 decimal places for standard display/storage
        amount: decimalValue.toDecimalPlaces(2),
        currency: currency.toUpperCase(),
    };
}

/**
 * Calculates the prorated charge for a subscription upgrade mid-billing cycle.
 * Formula: (Remaining Days / Total Days in Cycle) * Plan Price
 * 
 * @param planPrice - The full price of the subscription tier
 * @param remainingDays - Number of days left in the billing period
 * @param totalDays - Total days in the current billing period
 * @returns The exact prorated Money amount
 */
export function calculateProration(
    planPrice: Money,
    remainingDays: number,
    totalDays: number
): Money {
    if (totalDays <= 0) {
        throw new Error('Total days in billing cycle must be greater than zero.');
    }
    if (remainingDays < 0 || remainingDays > totalDays) {
        throw new Error('Remaining days must be between 0 and total days.');
    }

    // Convert raw numbers to Decimal instances for high-precision arithmetic
    const rem = new Decimal(remainingDays);
    const tot = new Decimal(totalDays);

    // Step 1: Calculate the time ratio
    const ratio = rem.dividedBy(tot);

    // Step 2: Multiply by the plan price amount
    const rawProratedAmount = planPrice.amount.times(ratio);

    // Step 3: Return a new Money object with standard 2-decimal rounding applied
    return {
        amount: rawProratedAmount.toDecimalPlaces(2, Decimal.ROUND_HALF_UP),
        currency: planPrice.currency,
    };
}

/**
 * Applies a regional sales tax rate to a subtotal amount.
 * 
 * @param subtotal - The base Money amount before tax
 * @param taxRatePercentage - The tax rate as a percentage (e.g., '8.25' for 8.25%)
 * @returns The calculated tax amount as a Money object
 */
export function calculateTax(subtotal: Money, taxRatePercentage: string | number): Money {
    const rate = new Decimal(taxRatePercentage);
    
    if (rate.isNegative()) {
        throw new Error('Tax rate cannot be negative.');
    }

    // Convert percentage to a decimal multiplier (e.g., 8.25% -> 0.0825)
    const multiplier = rate.dividedBy(100);

    // Calculate tax and round to 2 decimal places
    const taxAmount = subtotal.amount.times(multiplier).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

    return {
        amount: taxAmount,
        currency: subtotal.currency,
    };
}

/**
 * Computes the final invoice total by adding subtotal and tax.
 * 
 * @param subtotal - The base Money amount
 * @param tax - The calculated tax Money amount
 * @returns The final gross Money amount
 */
export function addMoney(subtotal: Money, tax: Money): Money {
    if (subtotal.currency !== tax.currency) {
        throw new Error(`Currency mismatch: Cannot add ${subtotal.currency} to ${tax.currency}`);
    }

    const totalAmount = subtotal.amount.plus(tax.amount).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

    return {
        amount: totalAmount,
        currency: subtotal.currency,
    };
}

// ==========================================
// Execution Example (SaaS Billing Pipeline)
// ==========================================

try {
    // 1. Initialize a SaaS monthly plan price of $49.99
    const basePlan = createMoney('49.99', 'USD');
    console.log(`Base Plan Price: $${basePlan.amount.toString()} ${basePlan.currency}`);

    // 2. Client upgrades with 18 days remaining out of a 30-day billing cycle
    const proratedCharge = calculateProration(basePlan, 18, 30);
    console.log(`Prorated Charge (18/30 days): $${proratedCharge.amount.toString()}`);
    // Expected calculation: (18 / 30) * 49.99 = 0.6 * 49.99 = 29.994 -> rounds to 29.99

    // 3. Calculate an enterprise tax rate of 8.875% on the prorated charge
    const tax = calculateTax(proratedCharge, '8.875');
    console.log(`Calculated Tax (8.875%): $${tax.amount.toString()}`);
    // Expected calculation: 29.99 * 0.08875 = 2.6616625 -> rounds to 2.66

    // 4. Compute final invoice total
    const finalInvoiceTotal = addMoney(proratedCharge, tax);
    console.log(`Final Invoice Total: $${finalInvoiceTotal.amount.toString()} ${finalInvoiceTotal.currency}`);
    // Expected total: 29.99 + 2.66 = 32.65

} catch (error) {
    console.error('Payment pipeline computation error:', error);
}
