/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import Decimal from 'decimal.js';

/**
 * Configure global precision and rounding settings for Decimal.js.
 * Setting precision to 20 ensures sufficient headroom for intermediate calculations
 * involving currency multiplications and division ratios.
 */
Decimal.set({
  precision: 20,
  rounding: Decimal.ROUND_HALF_UP, // Standard financial rounding mode
  toExpNeg: -7,
  toExpPos: 21,
});

/**
 * Branded types to ensure type safety across currency boundaries.
 * Prevents mixing USD values with EUR values or raw numbers at compile-time.
 */
export type USD = { readonly __brand: unique symbol } & Decimal;
export type Percentage = { readonly __brand: unique symbol } & Decimal;

/**
 * Utility factory to instantiate branded Decimal instances safely from primitives.
 */
export const Money = {
  from: (value: string | number | Decimal): USD => {
    return new Decimal(value).toDecimalPlaces(2) as unknown as USD;
  },
  zero: (): USD => {
    return new Decimal(0).toDecimalPlaces(2) as unknown as USD;
  },
};

export const Rate = {
  from: (value: string | number | Decimal): Percentage => {
    return new Decimal(value).toDecimalPlaces(6) as unknown as Percentage;
  },
};

/**
 * Interface representing a line item in a recurring invoice.
 */
export interface InvoiceLineItem {
  readonly id: string;
  readonly unitPrice: USD;
  readonly quantity: number;
  readonly taxRate: Percentage;
}

/**
 * Interface representing the calculated totals for an invoice.
 */
export interface InvoiceTotals {
  readonly subtotal: USD;
  readonly totalTax: USD;
  readonly grandTotal: USD;
}

/**
 * Core Financial Engine class implementing immutable, precision-safe operations
 * designed for Next.js API route execution.
 */
export class FinancialEngine {
  /**
   * Computes the compound interest for an account balance over a specified duration.
   * Formula: A = P(1 + r/n)^(nt)
   * 
   * @param principal The initial balance (USD)
   * @param annualRate The annual interest rate (e.g., 0.05 for 5%)
   * @param compoundingPeriodsPerYear Number of compounding periods per year
   * @param years Duration in years
   * @returns The final accumulated amount as a branded USD Decimal
   */
  public static calculateCompoundInterest(
    principal: USD,
    annualRate: Percentage,
    compoundingPeriodsPerYear: number,
    years: number
  ): USD {
    const p = new Decimal(principal);
    const r = new Decimal(annualRate);
    const n = new Decimal(compoundingPeriodsPerYear);
    const t = new Decimal(years);

    // Inner calculation: (1 + r / n)
    const ratePerPeriod = r.dividedBy(n);
    const base = new Decimal(1).plus(ratePerPeriod);

    // Exponent calculation: n * t
    const exponent = n.times(t);

    // Final calculation: P * (base ^ exponent)
    const compoundFactor = base.pow(exponent);
    const rawResult = p.times(compoundFactor);

    return Money.from(rawResult);
  }

  /**
   * Computes pro-rata billing adjustments when a customer upgrades or downgrades 
   * their subscription tier mid-cycle.
   * 
   * @param monthlyRate The full monthly subscription cost
   * @param totalDaysInCycle Total number of days in the billing period
   * @param remainingDays Active days remaining in the billing period
   * @returns The adjusted pro-rata amount
   */
    public static calculateProRata(
    monthlyRate: USD,
    totalDaysInCycle: number,
    remainingDays: number
  ): USD {
    if (totalDaysInCycle <= 0) {
      throw new Error('Total days in cycle must be greater than zero.');
    }
    if (remainingDays < 0 || remainingDays > totalDaysInCycle) {
      throw new Error('Remaining days must fall within the billing cycle bounds.');
    }

    const rate = new Decimal(monthlyRate);
    const totalDays = new Decimal(totalDaysInCycle);
    const daysLeft = new Decimal(remainingDays);

    // Daily rate = monthlyRate / totalDaysInCycle
    const dailyRate = rate.dividedBy(totalDays);

    // Pro-rata amount = dailyRate * remainingDays
    const proRataAmount = dailyRate.times(daysLeft);

    return Money.from(proRataAmount);
  }

  /**
   * Processes a batch of invoice line items, computing precise sub-totals, taxes, 
   * and grand totals without floating-point drift.
   * 
   * @param items Array of invoice line items
   * @returns Detailed invoice summary with rounded ledger totals
   */
  public static processInvoice(items: readonly InvoiceLineItem[]): InvoiceTotals {
    let subtotal = new Decimal(0);
    let totalTax = new Decimal(0);

    for (const item of items) {
      const unitPrice = new Decimal(item.unitPrice);
      const qty = new Decimal(item.quantity);
      const taxRate = new Decimal(item.taxRate);

      // Line item subtotal = unitPrice * quantity
      const lineSubtotal = unitPrice.times(qty);
      subtotal = subtotal.plus(lineSubtotal);

      // Line item tax = lineSubtotal * taxRate
      const lineTax = lineSubtotal.times(taxRate);
      totalTax = totalTax.plus(lineTax);
    }

    const grandTotal = subtotal.plus(totalTax);

    return {
      subtotal: Money.from(subtotal),
      totalTax: Money.from(totalTax),
      grandTotal: Money.from(grandTotal),
    };
  }
}
