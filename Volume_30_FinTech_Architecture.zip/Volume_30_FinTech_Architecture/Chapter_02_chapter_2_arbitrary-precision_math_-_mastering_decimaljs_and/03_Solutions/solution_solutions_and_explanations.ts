/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Decimal from 'decimal.js';

// Configure global Decimal settings for tax and financial calculations
Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_UP });

export type DecimalMoney = {
  readonly _brand: unique symbol;
  readonly value: Decimal;
};

export function createDecimalMoney(val: string | number): DecimalMoney {
  const decimalValue = new Decimal(val).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
  return {
    value: decimalValue,
  } as DecimalMoney;
}

export function calculateTaxAndTotal(subtotal: string, taxRate: string): { tax: DecimalMoney; total: DecimalMoney } {
  const sub = new Decimal(subtotal);
  const rate = new Decimal(taxRate);

  // Intermediate calculations use higher scale (4 decimal places) with Banker's Rounding
  const rawTax = sub.mul(rate).toDecimalPlaces(4, Decimal.ROUND_HALF_EVEN);
  const rawTotal = sub.add(rawTax).toDecimalPlaces(4, Decimal.ROUND_HALF_EVEN);

  return {
    tax: { value: rawTax.toDecimalPlaces(2, Decimal.ROUND_HALF_EVEN) } as DecimalMoney,
    total: { value: rawTotal.toDecimalPlaces(2, Decimal.ROUND_HALF_EVEN) } as DecimalMoney,
  };
}

export function calculateProratedRefunds(
  totalRefund: string,
  schedule: number[]
): DecimalMoney[] {
  const total = new Decimal(totalRefund);
  
  // Replace native reduce with Decimal-based reduction
  const sumWeights = schedule.reduce(
    (acc, val) => acc.add(new Decimal(val)),
    new Decimal(0)
  );

  if (sumWeights.isZero()) {
    return schedule.map(() => createDecimalMoney(0));
  }

  return schedule.map((weight) => {
    const weightDecimal = new Decimal(weight);
    // Use Decimal division and multiplication methods exclusively
    const share = weightDecimal.div(sumWeights);
    const amount = total.mul(share);
    
    // Apply ROUND_HALF_UP to 2 decimal places as requested
    const roundedAmount = amount.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
    
    return {
      value: roundedAmount,
    } as DecimalMoney;
  });
}
