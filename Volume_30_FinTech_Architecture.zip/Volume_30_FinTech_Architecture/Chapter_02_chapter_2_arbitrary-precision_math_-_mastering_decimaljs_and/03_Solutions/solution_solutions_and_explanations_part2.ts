/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import Big from 'big.js';

export interface AccrualConfig {
  principal: string;
  annualRate: string;
  days: number;
  currencyScale: number;
}

export interface AccrualAuditRecord {
  day: number;
  openingBalance: Big;
  interestEarned: Big;
  closingBalance: Big;
}

export interface BigMoney {
  readonly _brand: unique symbol;
  readonly balance: Big;
  readonly auditTrail: AccrualAuditRecord[];
}

export function simulateCompoundAccrual(config: AccrualConfig): AccrualAuditRecord[] {
  // Ensure Big.js does not throw on small numbers and handles high precision internally
  Big.DP = 20;
  Big.RM = 1; // Round down / truncate for conservative institutional accruals

  let currentPrincipal = new Big(config.principal);
  const annualRate = new Big(config.annualRate);
  
  // Daily interest rate factor: Annual Rate / 365 days
  const dailyRate = annualRate.div(new Big(365));
  const auditTrail: AccrualAuditRecord[] = [];

  for (let day = 1; day <= config.days; day++) {
    const openingBalance = new Big(currentPrincipal);
    
    // Calculate daily interest: Principal * dailyRate
    const interestEarned = openingBalance.mul(dailyRate);
    
    // Accumulate interest into principal without early rounding
    const closingBalance = openingBalance.add(interestEarned);

    auditTrail.push({
      day,
      openingBalance: openingBalance.round(config.currencyScale, 0),
      interestEarned: interestEarned.round(config.currencyScale, 0),
      closingBalance: closingBalance.round(config.currencyScale, 0),
    });

    currentPrincipal = closingBalance;
  }

  return auditTrail;
}

export function accruesCompoundInterest(
  principal: string,
  annualRate: string,
  days: number,
  scale: number
): BigMoney {
  const auditTrail = simulateCompoundAccrual({
    principal,
    annualRate,
    days,
    currencyScale: scale,
  });

  const finalRecord = auditTrail[auditTrail.length - 1];
  const finalBalance = finalRecord ? finalRecord.closingBalance : new Big(principal);

  return {
    balance: finalBalance.round(scale, 1),
  } as unknown as BigMoney;
}
