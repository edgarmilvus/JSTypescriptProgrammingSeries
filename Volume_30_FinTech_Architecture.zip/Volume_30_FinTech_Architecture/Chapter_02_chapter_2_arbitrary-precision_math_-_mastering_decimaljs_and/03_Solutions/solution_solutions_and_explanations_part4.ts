/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import Decimal from 'decimal.js';

export interface RawTransaction {
  id: string;
  amount: string; // e.g. "150.50"
  currency: string;
  sourceAccount: string;
  destinationAccount: string;
}

export interface LedgerPosting {
  accountId: string;
  amount: Decimal;
  direction: 'DEBIT' | 'CREDIT';
}

export interface LedgerJournalEntry {
  transactionId: string;
  postings: LedgerPosting[];
}

export interface PipelineResult {
  journalEntries: LedgerJournalEntry[];
  totalBatchVolume: Decimal;
  totalFeesCollected: Decimal;
  suspenseAdjustments: Decimal;
}

export class LedgerImbalanceError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LedgerImbalanceError';
  }
}

export function processPaymentBatch(
  transactions: RawTransaction[],
  platformFeeRate: string,
  flatFee: string
): PipelineResult {
  // Configure Decimal.js precision and rounding for the pipeline context
  Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_EVEN });

  const journalEntries: LedgerJournalEntry[] = [];
  let totalBatchVolume = new Decimal(0);
  let totalFeesCollected = new Decimal(0);
  let batchDebitSum = new Decimal(0);
  let batchCreditSum = new Decimal(0);

  const feeRateDec = new Decimal(platformFeeRate);
  const flatFeeDec = new Decimal(flatFee);
  const platformFeeAccount = 'PLATFORM_FEE_REVENUE';

  for (const tx of transactions) {
    const grossAmount = new Decimal(tx.amount);
    totalBatchVolume = totalBatchVolume.add(grossAmount);

    // Fee formula: (grossAmount * platformFeeRate) + flatFee
    const calculatedFee = grossAmount.mul(feeRateDec).add(flatFeeDec).toDecimalPlaces(2, Decimal.ROUND_HALF_EVEN);
    totalFeesCollected = totalFeesCollected.add(calculatedFee);

    const netMerchantPayout = grossAmount.sub(calculatedFee).toDecimalPlaces(2, Decimal.ROUND_HALF_EVEN);

    // Double-entry postings:
    // Debit: Source Account (Gross Amount)
    // Credit: Destination Account (Net Payout)
    // Credit: Platform Fee Account (Calculated Fee)
    const postings: LedgerPosting[] = [
      { accountId: tx.sourceAccount, amount: grossAmount, direction: 'DEBIT' },
      { accountId: tx.destinationAccount, amount: netMerchantPayout, direction: 'CREDIT' },
      { accountId: platformFeeAccount, amount: calculatedFee, direction: 'CREDIT' },
    ];

    // Verify internal transaction leg balancing: Debits === Credits
    const txDebits = postings.filter(p => p.direction === 'DEBIT').reduce((acc, p) => acc.add(p.amount), new Decimal(0));
    const txCredits = postings.filter(p => p.direction === 'CREDIT').reduce((acc, p) => acc.add(p.amount), new Decimal(0));

    if (!txDebits.equals(txCredits)) {
      throw new LedgerImbalanceError(`Transaction ${tx.id} failed internal balance check: Debits (${txDebits}) !== Credits (${txCredits})`);
    }

    batchDebitSum = batchDebitSum.add(txDebits);
    batchCreditSum = batchCreditSum.add(txCredits);

    journalEntries.push({
      transactionId: tx.id,
      postings,
    });
  }

  // Calculate batch-level rounding dust and append suspense adjustments if necessary
  let suspenseAdjustments = new Decimal(0);
  const batchImbalance = batchDebitSum.sub(batchCreditSum);

  if (!batchImbalance.isZero()) {
    suspenseAdjustments = batchImbalance;
    const suspenseAccount = 'ROUNDING_SUSPENSE_ACCOUNT';

    journalEntries.push({
      transactionId: 'BATCH_SUSPENSE_ADJUSTMENT',
      postings: [
        {
          accountId: suspenseAccount,
          amount: batchImbalance.abs(),
          direction: batchImbalance.isPositive() ? 'CREDIT' : 'DEBIT',
        },
      ],
    });
  }

  return {
    journalEntries,
    totalBatchVolume,
    totalFeesCollected,
    suspenseAdjustments,
  };
}
