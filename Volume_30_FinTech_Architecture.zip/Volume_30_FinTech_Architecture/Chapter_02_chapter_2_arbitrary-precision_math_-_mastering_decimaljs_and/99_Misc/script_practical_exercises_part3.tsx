/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';
import Decimal from 'decimal.js';

export interface PrecisionCurrencyConverterProps {
  baseCurrency: string;
  targetCurrencies: string[];
  exchangeRates: Record<string, string>; // e.g. { EUR: '0.92', GBP: '0.79' }
  onValidatedChange?: (amount: Decimal) => void;
}

export const PrecisionCurrencyConverter: React.FC<PrecisionCurrencyConverterProps> = ({
  baseCurrency,
  targetCurrencies,
  exchangeRates,
  onValidatedChange,
}) => {
  const [rawInput, setRawInput] = useState<string>('0.00');
  const [errorState, setErrorState] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    
    // TODO: Implement strict regex validation for decimal strings
    // TODO: Attempt Decimal instantiation; catch errors and set errorState
    // TODO: Invoke onValidatedChange if valid
  };

  return (
    <div className="precision-converter-container">
      <h3>Currency Converter ({baseCurrency})</h3>
      <div className="input-group">
        <label htmlFor="base-amount">Amount:</label>
        <input
          id="base-amount"
          type="text"
          value={rawInput}
          onChange={handleInputChange}
          placeholder="0.00"
        />
        {errorState && <span className="error-text">{errorState}</span>}
      </div>

      <div className="conversion-results">
        {targetCurrencies.map((currency) => {
          // TODO: Calculate and render converted values using Decimal.js safely
          return (
            <div key={currency} className="conversion-row">
              <span>{currency}:</span>
              <span data-testid={`converted-${currency}`}>
                {/* Render calculated value here */}
            </div>
          );
        })}
      </div>
    </div>
  );
};
