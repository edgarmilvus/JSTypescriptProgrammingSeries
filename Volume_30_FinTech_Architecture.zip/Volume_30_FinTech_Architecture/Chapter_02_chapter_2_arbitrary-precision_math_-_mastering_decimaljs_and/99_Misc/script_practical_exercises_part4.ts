/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import Decimal from 'decimal.js';

export interface RawTransaction {
  id: string;
  amount: string; // e.g. "150.50"
  currency: string;
  sourceAccount: string;
  destinationAccount: string;
}

export interface LedgerPosting {
  accountId: string;
  amount: Decimal;
  direction: 'DEBIT' | 'CREDIT';
}

export interface LedgerJournalEntry {
  transactionId: string;
  postings: LedgerPosting[];
}

export interface PipelineResult {
  journalEntries: LedgerJournalEntry[];
  totalBatchVolume: Decimal;
  totalFeesCollected: Decimal;
  suspenseAdjustments: Decimal;
}

export class LedgerImbalanceError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LedgerImbalanceError';
  }
}

export function processPaymentBatch(
  transactions: RawTransaction[],
  platformFeeRate: string,
  flatFee: string
): PipelineResult {
  // Configure Decimal.js precision and rounding for the pipeline context
  Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_EVEN });

  const journalEntries: LedgerJournalEntry[] = [];
  let totalBatchVolume = new Decimal(0);
  let totalFeesCollected = new Decimal(0);
  let suspenseAdjustments = new Decimal(0);

  for (const tx of transactions) {
    const grossAmount = new Decimal(tx.amount);
    
    // TODO: Calculate fee: (grossAmount * platformFeeRate) + flatFee
    // TODO: Calculate net merchant payout: grossAmount - fee
    
    // TODO: Construct double-entry postings (Debit source, Credit destination & Fee account)
    // TODO: Verify that sum(Debits) === sum(Credits). If not, throw LedgerImbalanceError.
  }

  // TODO: Calculate batch-level rounding dust and append suspense adjustments if necessary

  return {
    journalEntries,
    totalBatchVolume,
    totalFeesCollected,
    suspenseAdjustments,
  };
}
