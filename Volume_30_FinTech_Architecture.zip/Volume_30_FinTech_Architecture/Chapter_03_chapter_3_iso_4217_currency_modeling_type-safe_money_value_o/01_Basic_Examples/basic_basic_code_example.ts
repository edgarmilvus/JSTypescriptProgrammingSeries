/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file money.ts
 * @description Production-grade ISO 4217 Currency and Money Value Object implementation in TypeScript.
 * Prevents IEEE 754 float drift and enforces compile-time currency safety.
 */

// ============================================================================
// 1. BRANDED TYPES & ISO 4217 PRIMITIVES
// ============================================================================

/**
 * Creates a branded type to prevent primitive obsession and accidental mixing
 * of unrelated values (e.g., passing a raw number where a minor unit is required).
 */
declare const __brand: unique symbol;
type Brand<T, TBrand> = T & { readonly [__brand]: TBrand };

/**
 * Represents an integer value of a currency's minor unit (e.g., cents for USD, yen has 0, dinar has 3).
 */
export type MinorUnit = Brand<number, 'MinorUnit'>;

/**
 * A strict union of supported ISO 4217 currency codes used within our SaaS platform.
 */
export type SupportedCurrency = 'USD' | 'EUR' | 'GBP' | 'JPY';

/**
 * Metadata contract defining the exponent (decimal places) for a given ISO 4217 currency.
 */
export interface CurrencyMetadata {
  readonly code: SupportedCurrency;
  readonly exponent: number;
  readonly symbol: string;
}

/**
 * Central registry mapping ISO 4217 codes to their respective sub-unit exponents.
 */
const CURRENCY_REGISTRY: Record<SupportedCurrency, CurrencyMetadata> = {
  USD: { code: 'USD', exponent: 2, symbol: '$' },
  EUR: { code: 'EUR', exponent: 2, symbol: '€' },
  GBP: { code: 'GBP', exponent: 2, symbol: '£' },
  JPY: { code: 'JPY', exponent: 0, symbol: '¥' }, // Japanese Yen has no minor units
};

// ============================================================================
// 2. MONEY VALUE OBJECT IMPLEMENTATION
// ============================================================================

/**
 * Immutable Money Value Object.
 * Encapsulates an integer minor unit amount and an ISO 4217 currency code,
 * guaranteeing safe arithmetic and formatting across global transactions.
 */
export class Money {
  private constructor(
    public readonly amount: MinorUnit,
    public readonly currency: SupportedCurrency
  ) {
    // Enforce that minor units are always integers to protect against fractional state
    if (!Number.isInteger(amount)) {
      throw new Error(`Invalid money initialization: Minor units must be integers. Received: ${amount}`);
    }
  }

  /**
   * Factory method to create a Money instance from major units (e.g., dollars, pounds)
   * by scaling up according to the currency's ISO 4217 exponent.
   * 
   * @param majorAmount - The human-readable decimal amount (e.g., 10.50)
   * @param currency - The target ISO 4217 currency code
   */
  public static fromMajor(majorAmount: number, currency: SupportedCurrency): Money {
    const metadata = CURRENCY_REGISTRY[currency];
    if (!metadata) {
      throw new Error(`Unsupported currency code: ${currency}`);
    }

    // Calculate scaling factor (e.g., 10^2 = 100 for USD)
    const factor = Math.pow(10, metadata.exponent);
    
    // Scale and round to nearest safe integer to mitigate floating-point input artifacts
    const minorUnits = Math.round(majorAmount * factor);

    return new Money(minorUnits as MinorUnit, currency);
  }

  /**
   * Factory method to create a Money instance directly from raw minor units (e.g., Stripe API cents).
   * 
   * @param minorAmount - The integer minor unit amount
   * @param currency - The target ISO 4217 currency code
   */
  public static fromMinor(minorAmount: number, currency: SupportedCurrency): Money {
    if (!CURRENCY_REGISTRY[currency]) {
      throw new Error(`Unsupported currency code: ${currency}`);
    }
    return new Money(Math.trunc(minorAmount) as MinorUnit, currency);
  }

  /**
   * Adds another Money instance to this instance.
   * Validates that both operands share the exact same ISO 4217 currency code.
   * 
   * @param other - The Money instance to add
   */
  public add(other: Money): Money {
    this.assertSameCurrency(other);
    const summedMinorUnits = (this.amount + other.amount) as MinorUnit;
    return new Money(summedMinorUnits, this.currency);
  }

  /**
   * Subtracts another Money instance from this instance.
   * Validates currency compatibility.
   * 
   * @param other - The Money instance to subtract
   */
  public subtract(other: Money): Money {
    this.assertSameCurrency(other);
    const subtractedMinorUnits = (this.amount - other.amount) as MinorUnit;
    return new Money(subtractedMinorUnits, this.currency);
  }

  /**
   * Multiplies the money value by a scalar multiplier (e.g., applying tax rates or quantities).
   * Rounds the resulting minor units using banker's rounding (round half to even) or standard round.
   * 
   * @param multiplier - Numeric factor
   */
  public multiply(multiplier: number): Money {
    const calculated = this.amount * multiplier;
    // Round to nearest integer to maintain MinorUnit invariant
    const rounded = Math.round(calculated) as MinorUnit;
    return new Money(rounded, this.currency);
  }

  /**
   * Returns the major unit representation as a floating-point number for UI display.
   */
  public toMajorNumber(): number {
    const metadata = CURRENCY_REGISTRY[this.currency];
    const factor = Math.pow(10, metadata.exponent);
    return this.amount / factor;
  }

  /**
   * Formats the money value into a localized string using standard `Intl.NumberFormat`.
   * 
   * @param locale - BCP 47 language tag (e.g., 'en-US', 'de-DE', 'ja-JP')
   */
  public format(locale: string = 'en-US'): string {
    const metadata = CURRENCY_REGISTRY[this.currency];
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: metadata.code,
      minimumFractionDigits: metadata.exponent,
      maximumFractionDigits: metadata.exponent,
    }).format(this.toMajorNumber());
  }

  /**
   * Internal guard to prevent currency mixing bugs at runtime.
   */
  private assertSameCurrency(other: Money): void {
    if (this.currency !== other.currency) {
      throw new Error(
        `Currency mismatch error: Cannot perform operation between ${this.currency} and ${other.currency}.`
      );
    }
  }
}

// ============================================================================
// 3. SAAS PIPELINE EXECUTION EXAMPLE
// ============================================================================

/**
 * Example SaaS Checkout Calculator demonstrating type-safe billing pipelines.
 */
function processSaaSInvoice() {
  // User adds a monthly subscription plan: $49.99 USD
  const basePlan = Money.fromMajor(49.99, 'USD');

  // User adds an API usage overage: $12.50 USD
  const usageOverage = Money.fromMajor(12.50, 'USD');

  // Compute subtotal safely without float drift
  const subtotal = basePlan.add(usageOverage);

  // Apply a 10% promotional discount
  const discount = subtotal.multiply(0.10);

  // Compute final invoice total
  const total = subtotal.subtract(discount);

  console.log(`Subtotal: ${subtotal.format('en-US')}`); // Subtotal: $62.49
  console.log(`Discount: ${discount.format('en-US')}`); // Discount: $6.25
  console.log(`Final Total: ${total.format('en-US')}`);     // Final Total: $56.24

  // COMPILE-TIME / RUNTIME SAFETY CHECK:
  // const invalidAttempt = basePlan.add(Money.fromMajor(15.00, 'EUR'));
  // Throws Error: Currency mismatch error: Cannot perform operation between USD and EUR.
}

// Execute pipeline
processSaaSInvoice();
