/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';

/**
 * ============================================================================
 * DOMAIN PRIMITIVES & BRANDED TYPES
 * ============================================================================
 */

// Branded type helpers to enforce nominal typing at compile time
type Brand<T, BrandName extends string> = T & { readonly __brand: BrandName };

export type CurrencyCode = Brand<string, 'CurrencyCode'>;
export type MinorUnitAmount = Brand<bigint, 'MinorUnitAmount'>;

/**
 * ISO 4217 Currency Definition interface containing essential metadata
 * for scaling, formatting, and precision accounting.
 */
export interface CurrencyDefinition {
  code: string;
  numericCode: string;
  exponent: number; // Number of decimal places (e.g., 2 for USD, 0 for JPY, 3 for BHD)
  symbol: string;
}

/**
 * Static registry of supported ISO 4217 currencies.
 * Prevents arbitrary or malformed currency definitions entering the pipeline.
 */
export const ISO_CURRENCIES: Record<string, CurrencyDefinition> = {
  USD: { code: 'USD', numericCode: '840', exponent: 2, symbol: '$' },
  EUR: { code: 'EUR', numericCode: '978', exponent: 2, symbol: '€' },
  JPY: { code: 'JPY', numericCode: '392', exponent: 0, symbol: '¥' },
  BHD: { code: 'BHD', numericCode: '048', exponent: 3, symbol: '.د.ب' },
};

/**
 * ============================================================================
 * MONEY VALUE OBJECT
 * ============================================================================
 */

export class Money {
  private readonly _amount: MinorUnitAmount;
  private readonly _currency: CurrencyDefinition;

  /**
   * Private constructor to enforce factory method usage (e.g., fromMajor, fromMinor).
   * Guarantees that internal amounts are always stored as discrete BigInt minor units.
   */
  private constructor(amount: bigint, currency: CurrencyDefinition) {
    this._amount = amount as MinorUnitAmount;
    this._currency = currency;
  }

  /**
   * Factory method to instantiate Money from major units (e.g., standard decimal strings or numbers).
   * Automatically scales the value using the currency's ISO exponent to prevent floating-point loss.
   */
  public static fromMajor(amount: number | string, currencyCode: string): Money {
    const currency = ISO_CURRENCIES[currencyCode.toUpperCase()];
    if (!currency) {
      throw new Error(`Unsupported or unrecognized ISO 4217 currency: ${currencyCode}`);
    }

    // Parse input safely using BigInt multiplier scaling
    const parsedAmount = typeof amount === 'number' ? amount.toString() : amount;
    const parts = parsedAmount.split('.');
    const integerPart = parts[0] || '0';
    let fractionalPart = parts[1] || '';

    if (fractionalPart.length > currency.exponent) {
      throw new Error(
        `Precision overflow: Value ${amount} exceeds maximum allowed decimal places (${currency.exponent}) for ${currency.code}`
      );
    }

    // Pad fractional part with trailing zeros to match the exponent scale
    fractionalPart = fractionalPart.padEnd(currency.exponent, '0');
    
    const combinedString = `${integerPart}${fractionalPart}`;
    const minorUnits = BigInt(combinedString);

    return new Money(minorUnits, currency);
  }

  /**
   * Factory method to instantiate Money directly from pre-scaled minor units (e.g., database integers).
   */
  public static fromMinor(amount: bigint | number, currencyCode: string): Money {
    const currency = ISO_CURRENCIES[currencyCode.toUpperCase()];
    if (!currency) {
      throw new Error(`Unsupported or unrecognized ISO 4217 currency: ${currencyCode}`);
    }
    return new Money(BigInt(amount), currency);
  }

  public get amount(): MinorUnitAmount {
    return this._amount;
  }

  public get currency(): CurrencyDefinition {
    return this._currency;
  }

  /**
   * Adds two Money objects together. Throws a compile/runtime error if currencies mismatch.
   */
  public add(other: Money): Money {
    this.assertSameCurrency(other);
    return new Money(this._amount + other._amount, this._currency);
  }

  /**
   * Subtracts another Money object from this instance. Throws on currency mismatch.
   */
  public subtract(other: Money): Money {
    this.assertSameCurrency(other);
    return new Money(this._amount - other._amount, this._currency);
  }

  /**
   * Asserts that two Money instances share the exact same ISO 4217 currency code.
   */
  private assertSameCurrency(other: Money): void {
    if (this._currency.code !== other._currency.code) {
      throw new Error(
        `Currency mismatch error: Cannot perform arithmetic operations between ${this._currency.code} and ${other._currency.code}`
      );
    }
  }

  /**
   * Serializes the Money value object into a JSON-safe ledger format.
   */
  public toJSON() {
    return {
      amount: this._amount.toString(),
      currency: this._currency.code,
      formatted: this.format(),
    };
  }

  /**
   * Formats the minor units back into a human-readable major unit string.
   */
  public format(): string {
    const divisor = BigInt(10 ** this._currency.exponent);
    const integerPart = this._amount / divisor;
    const fractionalPart = (this._amount % divisor).toString().padStart(this._currency.exponent, '0');

    if (this._currency.exponent === 0) {
      return `${this._currency.symbol}${integerPart.toString()}`;
    }

    return `${this._currency.symbol}${integerPart}.${fractionalPart}`;
  }
}

/**
 * ============================================================================
 * NEXT.JS API ROUTE HANDLER (WEB APP CONTEXT)
 * ============================================================================
 */

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { baseAmount, taxAmount, currencyCode } = body;

    // 1. Validate incoming payload parameters
    if (!baseAmount || !taxAmount || !currencyCode) {
      return NextResponse.json(
        { error: 'Missing required payload fields: baseAmount, taxAmount, currencyCode' },
        { status: 400 }
      );
    }

    // 2. Instantiate type-safe immutable Money value objects using ISO 4217 parsing
    const subtotal = Money.fromMajor(baseAmount, currencyCode);
    const tax = Money.fromMajor(taxAmount, currencyCode);

    // 3. Execute precise ledger arithmetic (Guaranteed immune to floating-point drift)
    const grandTotal = subtotal.add(tax);

    // 4. Return structured financial response for the SaaS frontend checkout pipeline
    return NextResponse.json(
      {
        success: true,
        ledgerEntry: {
          subtotal: subtotal.toJSON(),
          tax: tax.toJSON(),
          grandTotal: grandTotal.toJSON(),
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    // Catch precision overflows or currency mismatch errors safely
    return NextResponse.json(
      { success: false, error: error.message || 'Internal ledger processing error' },
      { status: 422 }
    );
  }
}
