/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. ISO 4217 Brand and Literal Types
export type SupportedCurrency = "USD" | "EUR" | "JPY" | "GBP";

declare const __brand: unique symbol;
export type Brand<T, TBrand extends string> = T & { readonly [__brand]: TBrand };

export type MoneyBrand<TCode extends SupportedCurrency> = Brand<number, `Money_${TCode}`>;

// 2. Dynamic Precision Mapping
export const CURRENCY_EXPONENTS: Record<SupportedCurrency, number> = {
  USD: 2,
  EUR: 2,
  JPY: 0,
  GBP: 2,
};

export type RoundingMode = "ROUND_HALF_UP" | "ROUND_DOWN";

// 3. Immutable Money Value Object
export class Money<TCode extends SupportedCurrency> {
  private constructor(
    public readonly amount: MoneyBrand<TCode>,
    public readonly currency: TCode
  ) {}

  public static create<TCode extends SupportedCurrency>(
    amountInMajorUnits: number,
    currency: TCode
  ): Money<TCode> {
    const exponent = CURRENCY_EXPONENTS[currency];
    const minorUnits = Math.round(amountInMajorUnits * Math.pow(10, exponent));
    return new Money(minorUnits as MoneyBrand<TCode>, currency);
  }

  public static fromMinorUnits<TCode extends SupportedCurrency>(
    minorUnits: number,
    currency: TCode
  ): Money<TCode> {
    if (!Number.isInteger(minorUnits)) {
      throw new Error("Minor units must be an integer.");
    }
    return new Money(minorUnits as MoneyBrand<TCode>, currency);
  }

  public add(other: Money<TCode>): Money<TCode> {
    this.assertSameCurrency(other);
    const newMinorUnits = (this.amount as number) + (other.amount as number);
    return Money.fromMinorUnits(newMinorUnits, this.currency);
  }

  public subtract(other: Money<TCode>): Money<TCode> {
    this.assertSameCurrency(other);
    const newMinorUnits = (this.amount as number) - (other.amount as number);
    return Money.fromMinorUnits(newMinorUnits, this.currency);
  }

  public scale(factor: number, mode: RoundingMode = "ROUND_HALF_UP"): Money<TCode> {
    const rawResult = (this.amount as number) * factor;
    const scaledUnits = mode === "ROUND_HALF_UP" ? Math.round(rawResult) : Math.trunc(rawResult);
    return Money.fromMinorUnits(scaledUnits, this.currency);
  }

  private assertSameCurrency(other: Money<any>): void {
    if (this.currency !== other.currency) {
      throw new Error(`Currency mismatch: Cannot operate on ${this.currency} and ${other.currency}`);
    }
  }
}

// 4. Interactive Challenge: Type Guard Implementation
export function isSameCurrency<T1 extends SupportedCurrency, T2 extends SupportedCurrency>(
  m1: Money<T1>,
  m2: Money<T2>
): m1 is Money<T2> {
  return m1.currency === m2.currency;
}

// Demonstration of Compile-Time Safeguards:
const usdMoney = Money.create(100, "USD");
const eurMoney = Money.create(100, "EUR");

// usdMoney.add(eurMoney); // TypeScript Error: Argument of type 'Money<"EUR">' is not assignable to parameter of type 'Money<"USD">'
