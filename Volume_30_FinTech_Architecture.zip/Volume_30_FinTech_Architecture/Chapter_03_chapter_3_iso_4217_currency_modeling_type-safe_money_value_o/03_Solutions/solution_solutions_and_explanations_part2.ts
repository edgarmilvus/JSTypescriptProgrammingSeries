/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

export const SupportedCurrencySchema = z.enum(["USD", "EUR", "JPY", "GBP"]);
export type SupportedCurrencyCode = z.infer<typeof SupportedCurrencySchema>;

const MAX_SAFE_MONEY = 9007199254740991;

// 2. Minor Unit String/Number Coercion Schema
export const MoneyAmountSchema = z.union([z.string(), z.number()]).transform((val, ctx) => {
  const num = typeof val === "string" ? Number(val) : val;
  
  if (isNaN(num) || !Number.isFinite(num)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Amount must be a valid numeric value.",
    });
    return z.NEVER;
  }
  
  return Math.round(num);
});

// Interactive Challenge: Custom Refinement for Boundaries & Negative Flags
export const CreateTransactionSchema = z.object({
  transactionId: z.string().uuid(),
  sourceAmount: MoneyAmountSchema.refine((val) => val <= MAX_SAFE_MONEY, {
    message: "Amount exceeds maximum safe integer boundary.",
  }),
  targetCurrency: SupportedCurrencySchema,
  timestamp: z.string().datetime(),
}).superRefine((data, ctx) => {
  // Assuming negative rule context simulation
  const allowNegative = false; 
  if (data.sourceAmount <= 0 && !allowNegative) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["sourceAmount"],
      message: "Zero or negative amounts are not permitted unless explicitly allowed.",
    });
  }
});

// 4. Error Handling & Parsing Wrapper
export function parseTransactionPayload(rawPayload: unknown) {
  const result = CreateTransactionSchema.safeParse(rawPayload);
  
  if (!result.success) {
    return {
      success: false as const,
      errors: result.error.format(),
    };
  }

  return {
    success: true as const,
    data: result.data,
  };
}
