/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from "react";

type SupportedCurrency = "USD" | "EUR" | "JPY" | "GBP";

declare const __brand: unique symbol;
type Brand<T, TBrand extends string> = T & { readonly [__brand]: TBrand };
type MoneyBrand<TCode extends SupportedCurrency> = Brand<number, `Money_${TCode}`>;

class Money<TCode extends SupportedCurrency> {
  private constructor(
    public readonly amount: MoneyBrand<TCode>,
    public readonly currency: TCode
  ) {}

  public static fromMinorUnits<TCode extends SupportedCurrency>(
    minorUnits: number,
    currency: TCode
  ): Money<TCode> {
    return new Money(minorUnits as MoneyBrand<TCode>, currency);
  }
}

const CURRENCY_EXPONENTS: Record<SupportedCurrency, number> = {
  USD: 2,
  EUR: 2,
  JPY: 0,
  GBP: 2,
};

// 1. Component Props Interface
export interface CurrencyInputFieldProps<T extends SupportedCurrency> {
  currency: T;
  value: Money<T> | null;
  onChange: (money: Money<T> | null) => void;
  disabled?: boolean;
  error?: string;
}

// 3. Conversion Logic & Component Implementation
export function CurrencyInputField<T extends SupportedCurrency>({
  currency,
  value,
  onChange,
  disabled,
  error,
}: CurrencyInputFieldProps<T>) {
  const exponent = CURRENCY_EXPONENTS[currency];
  
  const initialDisplay = value 
    ? ((value.amount as number) / Math.pow(10, exponent)).toFixed(exponent) 
    : "";

  const [displayValue, setDisplayValue] = useState<string>(initialDisplay);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawInput = e.target.value;

    // Regex guard: restricts based on decimal configuration
    const regex = exponent === 0 ? /^\d*$/ : new RegExp(`^\\d*\\.?\\d{0,${exponent}}$`);
    
    if (rawInput !== "" && !regex.test(rawInput)) {
      return; // Reject malformed inputs
    }

    setDisplayValue(rawInput);

    if (rawInput === "" || rawInput === "." || rawInput === "-") {
      onChange(null);
      return;
    }

    const parsedFloat = parseFloat(rawInput);
    if (isNaN(parsedFloat)) {
      onChange(null);
      return;
    }

    const minorUnits = Math.round(parsedFloat * Math.pow(10, exponent));
    onChange(Money.fromMinorUnits(minorUnits, currency));
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        <span>{currency}</span>
        <input
          type="text"
          value={displayValue}
          onChange={handleChange}
          disabled={disabled}
          placeholder={exponent > 0 ? "0.00" : "0"}
        />
      </div>
      {error && <span style={{ color: "red", fontSize: "12px" }}>{error}</span>}
    </div>
  );
}
