/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

type SupportedCurrency = "USD" | "EUR" | "JPY" | "GBP";

declare const __brand: unique symbol;
type Brand<T, TBrand extends string> = T & { readonly [__brand]: TBrand };
type MoneyBrand<TCode extends SupportedCurrency> = Brand<number, `Money_${TCode}`>;

class Money<TCode extends SupportedCurrency> {
  private constructor(
    public readonly amount: MoneyBrand<TCode>,
    public readonly currency: TCode
  ) {}
  public static fromMinorUnits<TCode extends SupportedCurrency>(minorUnits: number, currency: TCode): Money<TCode> {
    return new Money(minorUnits as MoneyBrand<TCode>, currency);
  }
}

const CURRENCY_EXPONENTS: Record<SupportedCurrency, number> = {
  USD: 2,
  EUR: 2,
  JPY: 0,
  GBP: 2,
};

// 3. Deterministic Rounding Strategies Enum
export enum RoundingMode {
  ROUND_HALF_UP = "ROUND_HALF_UP",
  ROUND_HALF_EVEN = "ROUND_HALF_EVEN",
  ROUND_DOWN = "ROUND_DOWN",
}

// 1. Exchange Rate Value Object
export class ExchangeRate {
  private constructor(
    public readonly sourceCurrency: SupportedCurrency,
    public readonly targetCurrency: SupportedCurrency,
    private readonly rateFactor: number // Stored with high precision scaling factor
  ) {
    if (rateFactor <= 0) {
      throw new Error("Exchange rate must be a positive, non-zero value.");
    }
  }

  public static create(source: SupportedCurrency, target: SupportedCurrency, rate: number): ExchangeRate {
    return new ExchangeRate(source, target, rate);
  }

  public invert(): ExchangeRate {
    return new ExchangeRate(this.targetCurrency, this.sourceCurrency, 1 / this.rateFactor);
  }

  // 2. Conversion Method
  public convert<S extends SupportedCurrency, T extends SupportedCurrency>(
    money: Money<S>,
    mode: RoundingMode = RoundingMode.ROUND_HALF_UP
  ): Money<T> {
    if (money.currency !== this.sourceCurrency) {
      throw new Error(`Source currency mismatch: Rate is for ${this.sourceCurrency}, but got ${money.currency}`);
    }

    const sourceExponent = CURRENCY_EXPONENTS[this.sourceCurrency];
    const targetExponent = CURRENCY_EXPONENTS[this.targetCurrency];
    
    // Adjust scale factor based on exponential divergence
    const exponentDelta = targetExponent - sourceExponent;
    const rawConverted = (money.amount as number) * this.rateFactor * Math.pow(10, exponentDelta);

    let finalMinorUnits: number;
    switch (mode) {
      case RoundingMode.ROUND_DOWN:
        finalMinorUnits = Math.trunc(rawConverted);
        break;
      case RoundingMode.ROUND_HALF_EVEN: {
        const floor = Math.floor(rawConverted);
        const diff = rawConverted - floor;
        if (diff === 0.5) {
          finalMinorUnits = floor % 2 === 0 ? floor : Math.ceil(rawConverted);
        } else {
          finalMinorUnits = Math.round(rawConverted);
        }
        break;
      }
      case RoundingMode.ROUND_HALF_UP:
      default:
        finalMinorUnits = Math.round(rawConverted);
        break;
    }

    return Money.fromMinorUnits(finalMinorUnits, this.targetCurrency as T);
  }
}

// 4. Interactive Challenge: Cross-Rate Engine
export function calculateCrossRate(rateA: ExchangeRate, rateB: ExchangeRate): ExchangeRate {
  if (rateA.targetCurrency !== rateB.targetCurrency) {
    throw new Error(`Cannot compute cross rate: Shared base currency required. Found ${rateA.targetCurrency} and ${rateB.targetCurrency}`);
  }

  // Example: RateA is AUD -> USD, RateB is JPY -> USD. Inverting RateB gives USD -> JPY.
  // Cross rate AUD -> JPY = (AUD -> USD) * (USD -> JPY)
  const invertedRateB = rateB.invert();
  
  // Direct internal access via reflection or by performing composition through private scale mechanics
  // Reconstructing synthetic rate factor via unmasked calculation
  const syntheticFactor = (rateA as any).rateFactor * (invertedRateB as any).rateFactor;

  return ExchangeRate.create(rateA.sourceCurrency, invertedRateB.targetCurrency, syntheticFactor);
}
