/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @file ledger-validation.ts
 * @description Strict boundary validation for financial double-entry ledger payloads using Zod.
 */

// ==========================================
// 1. DOMAIN PRIMITIVE SCHEMAS
// ==========================================

/**
 * Validates ISO-4217 3-letter uppercase currency codes.
 * E.g., USD, EUR, GBP.
 */
const CurrencyCodeSchema = z
  .string()
  .length(3, { message: 'Currency code must be exactly 3 characters.' })
  .transform((val) => val.toUpperCase())
  .refine((val) => /^[A-Z]{3}$/.test(val), {
    message: 'Invalid ISO-4217 currency code format.',
  });

/**
 * Validates financial monetary amounts. 
 * Rejects negative numbers, NaN, and Infinity. 
 * Ensures precision up to a maximum of 4 decimal places to support fractional sub-units 
 * (common in high-precision SaaS metrics like meter-based billing or crypto-denominations).
 */
const MonetaryAmountSchema = z
  .number({
    required_error: 'Amount is required.',
    invalid_type_error: 'Amount must be a valid numeric type.',
  })
  .finite({ message: 'Amount must be a finite number.' })
  .safe({ message: 'Amount exceeds safe integer precision limits for double-precision floats.' })
  .positive({ message: 'Financial amount must be strictly greater than zero.' })
  .refine(
    (val) => {
      // Convert to string to count decimal places accurately without floating-point drift
      const decimalStr = val.toString();
      if (decimalStr.includes('e-')) {
        // Scientific notation indicates extremely small fractions; handle accordingly or reject
        return false;
      }
      const parts = decimalStr.split('.');
      if (parts.length > 1 && parts[1].length > 4) {
        return false; // Max 4 decimal places allowed
      }
      return true;
    },
    { message: 'Amount cannot exceed 4 decimal places of precision.' }
  );

// ==========================================
// 2. COMPOSITE PAYLOAD SCHEMA
// ==========================================

/**
 * Schema for a single entry line item in a double-entry ledger transaction.
 */
const LedgerLineItemSchema = z.object({
  /** Unique identifier for the account being debited or credited */
  accountId: z.string().uuid({ message: 'Account ID must be a valid UUID.' }),
  
  /** Monetary amount for this line item */
  amount: MonetaryAmountSchema,
  
  /** Direction of the ledger movement */
  entryType: z.enum(['DEBIT', 'CREDIT'], {
    errorMap: () => ({ message: "Entry type must be explicitly either 'DEBIT' or 'CREDIT'." }),
  }),
});

/**
 * Comprehensive schema for a dual-entry financial transaction payload coming from an API client.
 */
const TransactionPayloadSchema = z.object({
  /** Unique idempotency key to prevent double-charging or duplicate processing */
  idempotencyKey: z.string().uuid({ message: 'Idempotency key must be a valid UUIDv4.' }),
  
  /** ISO-4217 currency code governing all line items in this payload */
  currency: CurrencyCodeSchema,
  
  /** Array of ledger line items. Must contain at least two entries to satisfy double-entry rules. */
  lineItems: z
    .array(LedgerLineItemSchema)
    .min(2, { message: 'A double-entry transaction must contain at least 2 line items.' }),
}).refine(
  (data) => {
    // Business logic validation: Sum of all DEBIT entries must equal sum of all CREDIT entries
    const debits = data.lineItems
      .filter((item) => item.entryType === 'DEBIT')
      .reduce((sum, item) => sum + item.amount, 0);

    const credits = data.lineItems
      .filter((item) => item.entryType === 'CREDIT')
      .reduce((sum, item) => sum + item.amount, 0);

    // Using a tight epsilon comparison or exact equality depending on integer scaling.
    // Here we use strict equality since we validated decimal places.
    return Math.abs(debits - credits) < 0.0001;
  },
  {
    message: 'Double-entry validation failed: Total DEBIT amounts must equal total CREDIT amounts.',
    path: ['lineItems'], // Attach error to the lineItems array in the final ZodError structure
  }
);

// Type inference export for downstream services
export type TransactionPayload = z.infer<typeof TransactionPayloadSchema>;

// ==========================================
// 3. API MIDDLEWARE SIMULATION
// ==========================================

/**
 * Simulates an Express/Next.js API middleware or server action entry point 
 * that validates incoming untrusted JSON payloads against the Zod schema.
 * 
 * @param rawBody - The unparsed, untrusted input from the HTTP request body.
 * @returns The strictly typed and sanitized TransactionPayload.
 * @throws Error if validation fails.
 */
function processIncomingFinancialPayload(rawBody: unknown): TransactionPayload {
  console.log('[API Middleware] Receiving raw payload for validation...');

  // Parse using Zod's safeParse to catch issues gracefully without throwing unhandled exceptions immediately
  const validationResult = TransactionPayloadSchema.safeParse(rawBody);

  if (!validationResult.success) {
    // Extract formatted formatting errors for structured logging and client response
    const formattedErrors = validationResult.error.format();
    console.error('[API Middleware] Validation Error detected at system boundary:', JSON.stringify(formattedErrors, null, 2));
    
    throw new Error(`Financial Payload Validation Failed: ${validationResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')}`);
  }

  console.log('[API Middleware] Payload successfully validated and sanitized.');
  return validationResult.data;
}

// ==========================================
// 4. EXECUTION DEMONSTRATION (TEST CASES)
// ==========================================

// Test Case A: Valid Balanced Transaction Payload
const validPayload = {
  idempotencyKey: 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
  currency: 'usd', // Lowercase input to test sanitization transformer
  lineItems: [
    {
      accountId: '123e4567-e89b-12d3-a456-426614174000',
      amount: 150.00,
      entryType: 'DEBIT',
    },
    {
      accountId: '789e4567-e89b-12d3-a456-426614174999',
      amount: 150.00,
      entryType: 'CREDIT',
    },
  ],
};

console.log('--- RUNNING TEST A (Valid Payload) ---');
try {
  const sanitizedData = processIncomingFinancialPayload(validPayload);
  console.log('Processed Output A:', sanitizedData);
} catch (error: any) {
  console.error('Test A Failed unexpectedly:', error.message);
}

// Test Case B: Unbalanced Transaction Payload (Should throw validation error)
const unbalancedPayload = {
  idempotencyKey: 'b1ffdc88-8b0a-3de7-aa5c-5aa8ac270b22',
  currency: 'EUR',
  lineItems: [
    {
      accountId: '123e4567-e89b-12d3-a456-426614174000',
      amount: 200.50,
      entryType: 'DEBIT',
    },
    {
      accountId: '789e4567-e89b-12d3-a456-426614174999',
      amount: 100.25, // Unbalanced!
      entryType: 'CREDIT',
    },
  ],
};

console.log('\n--- RUNNING TEST B (Unbalanced Payload) ---');
try {
  const sanitizedData = processIncomingFinancialPayload(unbalancedPayload);
  console.log('Processed Output B:', sanitizedData);
} catch (error: any) {
  console.error('Caught Expected Validation Error B:', error.message);
}
