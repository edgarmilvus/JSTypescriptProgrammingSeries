/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';
import { useState, useTransition } from 'react';

/**
 * @file ledger-action.ts
 * @description Advanced financial payload validation pipeline using Zod, 
 * enforcing strict ISO-4217 currency standards, safe integer arithmetic bounds,
 * and robust structural sanitization for a double-entry ledger system.
 */

// ==========================================
// 1. ZOD SCHEMA DEFINITIONS & REFINEMENTS
// ==========================================

/**
 * ISO-4217 Currency Code Enum definition.
 * Restricts allowed currencies to a strict whitelist to prevent injection or malformed data.
 */
const CurrencyCodeEnum = z.enum(['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY'], {
  errorMap: () => ({ message: 'Unsupported or invalid ISO-4217 currency code.' }),
});

/**
 * Precision Amount Schema.
 * Financial values must NEVER be passed as standard IEEE 754 floating-point numbers 
 * due to rounding errors (e.g., 0.1 + 0.2 !== 0.3). We accept string or positive integers 
 * representing minor units (e.g., cents) or precise decimal strings.
 */
const FinancialAmountSchema = z.union([
  z.number().positive('Amount must be strictly greater than zero.'),
  z.string().regex(/^\d+(\.\d{1,4})?$/, 'Must be a valid numeric string with up to 4 decimal places.'),
]).transform((val, ctx) => {
  // Convert incoming string/number to a normalized string representation for precision parsing
  const stringVal = typeof val === 'number' ? val.toString() : val;
  const [whole, decimal = ''] = stringVal.split('.');
  
  // Pad or truncate fractional parts to ensure consistent minor unit conversion (e.g., cents)
  const paddedDecimal = decimal.padEnd(4, '0').slice(0, 4);
  const rawMinorUnits = BigInt(whole + paddedDecimal);

  if (rawMinorUnits <= 0n) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Ledger entry absolute value must be greater than zero.',
    });
    return z.NEVER;
  }

  return {
    raw: stringVal,
    minorUnits: rawMinorUnits, // BigInt representation for safe ledger math
  };
});

/**
 * Comprehensive Transaction Payload Schema.
 * Enforces metadata constraints, account IDs, and balance validation rules.
 */
export const TransactionPayloadSchema = z.object({
  sourceAccountId: z.string().uuid('Source account must be a valid UUIDv4.'),
  destinationAccountId: z.string().uuid('Destination account must be a valid UUIDv4.'),
  amount: FinancialAmountSchema,
  currency: CurrencyCodeEnum,
  referenceId: z.string().min(8).max(64).regex(/^[A-Z0-9-_]+$/, 'Reference ID must be alphanumeric uppercase.'),
  metadata: z.record(z.string(), z.unknown()).optional(),
}).refine((data) => data.sourceAccountId !== data.destinationAccountId, {
  message: 'Source and destination accounts cannot be identical in a single ledger transfer.',
  path: ['destinationAccountId'],
});

// Infer TypeScript type automatically from the Zod schema
export type ValidatedTransactionPayload = z.infer<typeof TransactionPayloadSchema>;

// ==========================================
// 2. SERVER ACTION & PIPELINE PROCESSOR
// ==========================================

/**
 * Result state interface representing the boundary response of our financial pipeline.
 */
export type PipelineResult = 
  | { success: true; transactionId: string; processedAt: string; minorUnits: string }
  | { success: false; errors: Array<{ path: string; message: string }> };

/**
 * Executes strict schema validation and routes the payload to the double-entry ledger pipeline.
 * Designed to be executed directly within a Next.js Server Action context.
 * 
 * @untrustedInput Raw payload from client boundary
 */
export async function processLedgerTransaction(untrustedInput: unknown): Promise<PipelineResult> {
  // Step 1: Perform strict runtime validation using Zod's safeParse
  const validationResult = TransactionPayloadSchema.safeParse(untrustedInput);

  if (!validationResult.success) {
    // Flatten and format Zod issues into a clean error structure for the client UI
    const formattedErrors = validationResult.error.issues.map((issue) => ({
      path: issue.path.join('.'),
      message: issue.message,
    }));

    return {
      success: false,
      errors: formattedErrors,
    };
  }

  // Step 2: Extract fully validated and type-safe data
  const validatedData = validationResult.data;

  try {
    // Step 3: Simulate double-entry database transaction insertion
    // In production, this would execute inside an ACID database transaction block.
    console.log(`[Ledger Engine] Processing transfer: ${validatedData.amount.raw} ${validatedData.currency}`);
    console.log(`[Ledger Engine] Minor Units (BigInt): ${validatedData.amount.minorUnits.toString()}`);

    const simulatedTransactionId = `txn_${crypto.randomUUID()}`;

    return {
      success: true,
      transactionId: simulatedTransactionId,
      processedAt: new Date().toISOString(),
      minorUnits: validatedData.amount.minorUnits.toString(),
    };
  } catch (error: unknown) {
    return {
      success: false,
      errors: [{ path: 'server', message: error instanceof Error ? error.message : 'Unknown ledger processing error.' }],
    };
  }
}

// ==========================================
// 3. REACT UI INTEGRATION (NEXT.JS COMPONENT)
// ==========================================

/**
 * Interactive Ledger Form Component utilizing React useTransition 
 * for non-blocking UI updates during server-side validation and processing.
 */
export function LedgerTransactionForm() {
  const [isPending, startTransition] = useTransition();
  const [uiResult, setUiResult] = useState<PipelineResult | null>(null);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);

    // Construct raw payload object from form inputs
    const rawPayload = {
      sourceAccountId: formData.get('sourceAccountId'),
      destinationAccountId: formData.get('destinationAccountId'),
      amount: formData.get('amount'),
      currency: formData.get('currency'),
      referenceId: formData.get('referenceId'),
    };

    // Wrap execution in useTransition to keep the UI responsive
    startTransition(async () => {
      const result = await processLedgerTransaction(rawPayload);
      setUiResult(result);
    });
  }

  return (
    <form onSubmit={handleSubmit} className="p-6 max-w-lg mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl space-y-4">
      <h2 className="text-xl font-bold tracking-tight">Execute Ledger Transfer</h2>
      
      {/* Source Account Input */}
      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Source Account UUID</label>
        <input name="sourceAccountId" defaultValue="123e4567-e89b-12d3-a456-426614174000" className="w-full mt-1 p-2 bg-slate-800 rounded border border-slate-700" required />
      </div>

      {/* Destination Account Input */}
      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Destination Account UUID</label>
        <input name="destinationAccountId" defaultValue="765e4321-e89b-12d3-a456-426614174333" className="w-full mt-1 p-2 bg-slate-800 rounded border border-slate-700" required />
      </div>

      {/* Amount and Currency Row */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Amount</label>
          <input name="amount" type="text" defaultValue="1500.50" className="w-full mt-1 p-2 bg-slate-800 rounded border border-slate-700" required />
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Currency</label>
          <select name="currency" className="w-full mt-1 p-2 bg-slate-800 rounded border border-slate-700">
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
          </select>
        </div>
      </div>

      {/* Reference ID */}
      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Reference ID</label>
        <input name="referenceId" defaultValue="INV-2026-001" className="w-full mt-1 p-2 bg-slate-800 rounded border border-slate-700" required />
      </div>

      {/* Submit Button with Pending State */}
      <button 
        type="submit" 
        disabled={isPending}
        className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 font-semibold rounded transition disabled:opacity-50"
      >
        {isPending ? 'Validating & Processing...' : 'Submit Transaction'}
      </button>

      {/* Dynamic UI Feedback */}
      {uiResult && (
        <div className={`p-4 rounded text-sm ${uiResult.success ? 'bg-emerald-950 border border-emerald-800 text-emerald-200' : 'bg-rose-950 border border-rose-800 text-rose-200'}`}>
          {uiResult.success ? (
            <p>✅ Success! ID: {uiResult.transactionId} (Minor Units: {uiResult.minorUnits})</p>
          ) : (
            <div>
              <p className="font-bold">❌ Validation Failed:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                {uiResult.errors.map((err, idx) => (
                  <li key={idx}><span className="font-mono text-xs uppercase">{err.path}</span>: {err.message}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </form>
  );
}
