/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

interface AmountSchemaOptions {
  currency: string;
  exponent: number;
  allowNegative?: boolean;
}

export function createAmountSchema(options: AmountSchemaOptions) {
  const { currency, exponent, allowNegative = false } = options;

  // Build a regex pattern dynamically based on the currency's minor unit exponent.
  // Example for exponent 2: optional sign, digits, optional decimal point with 1 to 2 fractional digits.
  const regexPattern = allowNegative
    ? new RegExp(`^-?\\d+(\\.\\d{1,${exponent}})?$`)
    : new RegExp(`^\\d+(\\.\\d{1,${exponent}})?$`);

  return z.union([z.string(), z.number()]).superRefine((val, ctx) => {
    let stringVal: string;

    if (typeof val === 'number') {
      // Reject floats that cannot be safely represented or scientific notation inputs
      if (!Number.isFinite(val) || Object.is(val, -0)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Amount must be a finite number',
        });
        return;
      }
      if (!allowNegative && val < 0) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Negative amounts are not allowed for this currency',
        });
        return;
      }
      stringVal = val.toFixed(exponent);
    } else {
      stringVal = val.trim();
      if (!regexPattern.test(stringVal)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Invalid amount format or precision violation for ${currency} (max decimal places: ${exponent})`,
        });
        return;
      }
    }
  }).transform((val) => {
    const numVal = typeof val === 'number' ? val : parseFloat(val);
    // Convert to minor units using multiplication and Math.round to mitigate intermediate floating-point artifacts
    const multiplier = Math.pow(10, exponent);
    const minorUnits = Math.round(numVal * multiplier);

    if (Math.abs(minorUnits) > Number.MAX_SAFE_INTEGER) {
      throw new Error('Amount exceeds maximum safe integer limits');
    }

    return {
      raw: typeof val === 'number' ? val.toString() : val,
      minorUnits,
      currency,
    };
  });
}
