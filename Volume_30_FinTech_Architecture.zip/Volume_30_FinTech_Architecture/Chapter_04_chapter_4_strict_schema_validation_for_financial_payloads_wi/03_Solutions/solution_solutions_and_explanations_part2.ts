/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const JournalEntrySchema = z.object({
  accountId: z.string().uuid(),
  type: z.enum(['DEBIT', 'CREDIT']),
  amount: z.number().int().positive('Amount must be a positive integer in minor units'),
  currency: z.string().length(3).regex(/^[A-Z]{3}$/, 'Currency must be a valid ISO-4217 uppercase code'),
});

export const TransactionPayloadSchema = z.object({
  transactionId: z.string().uuid(),
  timestamp: z.string().datetime(),
  lines: z.array(JournalEntrySchema).min(2, 'A transaction must contain at least two journal lines'),
}).superRefine((data, ctx) => {
  const currencyTotals = new Map<string, { debits: number; credits: number }>();

  data.lines.forEach((line, index) => {
    const current = currencyTotals.get(line.currency) || { debits: 0, credits: 0 };
    
    if (line.type === 'DEBIT') {
      current.debits += line.amount;
    } else {
      current.credits += line.amount;
    }
    
    currencyTotals.set(line.currency, current);
  });

  for (const [currency, totals] of currencyTotals.entries()) {
    if (totals.debits !== totals.credits) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `Unbalanced transaction for currency ${currency}: Total debits (${totals.debits}) do not equal total credits (${totals.credits})`,
        path: ['lines'],
      });
    }
  }
});

export type TransactionPayload = z.infer<typeof TransactionPayloadSchema>;
