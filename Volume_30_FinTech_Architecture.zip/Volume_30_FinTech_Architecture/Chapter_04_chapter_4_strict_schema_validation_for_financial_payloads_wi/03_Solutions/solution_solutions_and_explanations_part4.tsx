/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

const TransferSchema = z.object({
  sourceAccountId: z.string().uuid('Invalid source account UUID'),
  destinationAccountId: z.string().uuid('Invalid destination account UUID'),
  amount: z.string().regex(/^\d+(\.\d{1,2})?$/, 'Amount must be a valid decimal format (max 2 decimal places)'),
}).refine(data => data.sourceAccountId !== data.destinationAccountId, {
  message: 'Source and destination accounts must be different',
  path: ['destinationAccountId'],
});

type TransferFormData = z.infer<typeof TransferSchema>;

interface TransferFundsFormProps {
  onSubmit: (data: TransferFormData) => void;
}

export const TransferFundsForm: React.FC<TransferFundsFormProps> = ({ onSubmit }) => {
  const [formState, setFormState] = useState<TransferFormData>({
    sourceAccountId: '',
    destinationAccountId: '',
    amount: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof TransferFormData, string>>>({});

  const validateField = (name: keyof TransferFormData, value: string) => {
    const updated = { ...formState, [name]: value };
    const result = TransferSchema.safeParse(updated);

    if (!result.success) {
      const fieldError = result.error.errors.find((err) => err.path[0] === name || (name === 'destinationAccountId' && err.path.includes('destinationAccountId')));
      setErrors((prev) => ({
        ...prev,
        [name]: fieldError ? fieldError.message : undefined,
      }));
    } else {
      setErrors((prev) => ({ ...prev, [name]: undefined, destinationAccountId: undefined }));
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
    validateField(name as keyof TransferFormData, value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = TransferSchema.safeParse(formState);
    if (result.success) {
      onSubmit(result.data);
    } else {
      const newErrors: Partial<Record<keyof TransferFormData, string>> = {};
      result.error.errors.forEach((err) => {
        const field = err.path[0] as keyof TransferFormData;
        if (field) newErrors[field] = err.message;
      });
      setErrors(newErrors);
    }
  };

  const isFormValid = TransferSchema.safeParse(formState).success;

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-4 max-w-md mx-auto bg-white rounded shadow">
      <div>
        <label className="block text-sm font-medium text-gray-700">Source Account ID</label>
        <input
          type="text"
          name="sourceAccountId"
          value={formState.sourceAccountId}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border"
        />
        {errors.sourceAccountId && <p className="text-red-500 text-xs mt-1">{errors.sourceAccountId}</p>}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Destination Account ID</label>
        <input
          type="text"
          name="destinationAccountId"
          value={formState.destinationAccountId}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border"
        />
        {errors.destinationAccountId && <p className="text-red-500 text-xs mt-1">{errors.destinationAccountId}</p>}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Amount</label>
        <input
          type="text"
          name="amount"
          value={formState.amount}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border"
        />
        {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
      </div>

      <button
        type="submit"
        disabled={!isFormValid}
        className="w-full bg-blue-600 text-white p-2 rounded disabled:opacity-50"
      >
        Transfer Funds
      </button>
    </form>
  );
};
