/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { describe, it, expect } from 'vitest';
import { TransactionPayloadSchema } from './ledger-schema';
import { ZodError } from 'zod';

describe('TransactionPayloadSchema Boundary Guard Stress Tests', () => {
  it('should reject transactions where debits do not equal credits', () => {
    const invalidTransaction = {
      transactionId: '123e4567-e89b-12d3-a456-426614174000',
      timestamp: '2023-10-25T10:00:00.000Z',
      lines: [
        { accountId: '123e4567-e89b-12d3-a456-426614174001', type: 'DEBIT', amount: 1000, currency: 'USD' },
        { accountId: '123e4567-e89b-12d3-a456-426614174002', type: 'CREDIT', amount: 999, currency: 'USD' },
      ],
    };

    const result = TransactionPayloadSchema.safeParse(invalidTransaction);
    expect(result.success).toBe(false);
    if (!result.success) {
      const error = result.error as ZodError;
      expect(error.errors[0].message).toContain('Unbalanced transaction');
      expect(error.errors[0].path).toContain('lines');
    }
  });

  it('should reject currency codes that do not conform to ISO-4217 3-letter uppercase standard', () => {
    const invalidCurrencyTransaction = {
      transactionId: '123e4567-e89b-12d3-a456-426614174000',
      timestamp: '2023-10-25T10:00:00.000Z',
      lines: [
        { accountId: '123e4567-e89b-12d3-a456-426614174001', type: 'DEBIT', amount: 1000, currency: 'usd' }, // lowercase
        { accountId: '123e4567-e89b-12d3-a456-426614174002', type: 'CREDIT', amount: 1000, currency: 'usd' },
      ],
    };

    const result = TransactionPayloadSchema.safeParse(invalidCurrencyTransaction);
    expect(result.success).toBe(false);
    if (!result.success) {
      const error = result.error as ZodError;
      expect(error.errors.some((e) => e.path.includes('currency'))).toBe(true);
    }
  });

  it('should reject amounts exceeding safe integer limits or containing negative values', () => {
    const invalidAmountTransaction = {
      transactionId: '123e4567-e89b-12d3-a456-426614174000',
      timestamp: '2023-10-25T10:00:00.000Z',
      lines: [
        { accountId: '123e4567-e89b-12d3-a456-426614174001', type: 'DEBIT', amount: -500, currency: 'USD' }, // negative
        { accountId: '123e4567-e89b-12d3-a456-426614174002', type: 'CREDIT', amount: -500, currency: 'USD' },
      ],
    };

    const result = TransactionPayloadSchema.safeParse(invalidAmountTransaction);
    expect(result.success).toBe(false);
    if (!result.success) {
      const error = result.error as ZodError;
      expect(error.errors.some((e) => e.path.includes('amount'))).toBe(true);
    }
  });
});
