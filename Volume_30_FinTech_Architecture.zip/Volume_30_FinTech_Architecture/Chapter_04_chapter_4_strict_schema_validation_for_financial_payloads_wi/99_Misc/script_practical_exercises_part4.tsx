/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

// TODO: Define the Transfer Form Zod Schema with cross-field validation
const TransferSchema = z.object({
  sourceAccountId: z.string().uuid(),
  destinationAccountId: z.string().uuid(),
  amount: z.string().regex(/^\d+(\.\d{1,2})?$/, 'Invalid currency format'),
}).refine(data => data.sourceAccountId !== data.destinationAccountId, {
  message: "Source and destination accounts must be different",
  path: ["destinationAccountId"],
});

type TransferFormData = z.infer<typeof TransferSchema>;

interface TransferFundsFormProps {
  onSubmit: (data: TransferFormData) => void;
}

// TODO: Implement the TransferFundsForm React component
export const TransferFundsForm: React.FC<TransferFundsFormProps> = ({ onSubmit }) => {
  // Your React state and validation handling code goes here

  return (
    <form onSubmit={(e) => { e.preventDefault(); }}>
      {/* Form inputs, error displays, and submit button */}
    </form>
  );
};
