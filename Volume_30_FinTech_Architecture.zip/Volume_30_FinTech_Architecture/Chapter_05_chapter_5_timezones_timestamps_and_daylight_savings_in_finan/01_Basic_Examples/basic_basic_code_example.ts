/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ledger-time.ts
 * @description Enterprise-grade UTC timestamp management for SaaS financial pipelines.
 * Enforces strict ISO 8601 compliance and immutable state management for audit trails.
 */

/**
 * Represents a high-precision, immutable financial timestamp in UTC.
 */
export interface ImmutableLedgerTimestamp {
  readonly epochMilliseconds: number;
  readonly isoString: string;
}

/**
 * Custom error class for invalid temporal formatting in financial transactions.
 */
class FinancialTimestampError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FinancialTimestampError";
  }
}

/**
 * Generates an immutable, strict UTC timestamp for a financial event.
 * In a SaaS context, this is called at the exact moment a payment intent 
 * or subscription charge is received by the API gateway.
 * 
 * @returns {ImmutableLedgerTimestamp} The frozen epoch and ISO representation.
 */
export function createFinancialTimestamp(inputDate: Date = new Date()): ImmutableLedgerTimestamp {
  // Validate that the input is a valid date object
  if (isNaN(inputDate.getTime())) {
    throw new FinancialTimestampError("Invalid Date object provided to ledger pipeline.");
  }

  const epochMilliseconds = inputDate.getTime();
  const isoString = inputDate.toISOString();

  // Enforce structural immutability using Object.freeze
  return Object.freeze({
    epochMilliseconds,
    isoString,
  });
}

/**
 * Parses an external ISO 8601 string from a webhook payload (e.g., Stripe, PayPal)
 * and normalizes it into our immutable ledger format.
 * 
 * @param {string} rawIsoString - The raw timestamp string from an external API.
 * @returns {ImmutableLedgerTimestamp} The normalized, validated ledger timestamp.
 */
export function parseExternalWebhookTimestamp(rawIsoString: string): ImmutableLedgerTimestamp {
  // Regex to validate basic ISO 8601 UTC string format (e.g., YYYY-MM-DDTHH:mm:ss.sssZ)
  const isoUtcRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/;

  if (!isoUtcRegex.test(rawIsoString)) {
    throw new FinancialTimestampError(
      `Webhook timestamp rejected: '${rawIsoString}' is not a valid strict UTC ISO 8601 string.`
    );
  }

  const parsedDate = new Date(rawIsoString);
  
  if (isNaN(parsedDate.getTime())) {
    throw new FinancialTimestampError(
      `Webhook timestamp rejected: '${rawIsoString}' resulted in an invalid epoch time.`
    );
  }

  return createFinancialTimestamp(parsedDate);
}

/**
 * Formats a ledger timestamp for localized enterprise reporting or customer invoices,
 * mapping a UTC epoch point to a specific regional timezone without altering the underlying ledger record.
 * 
 * @param {ImmutableLedgerTimestamp} timestamp - The immutable ledger timestamp.
 * @param {string} timeZone - The target IANA timezone (e.g., 'America/New_York', 'Europe/London').
 * @returns {string} The localized human-readable string.
 */
export function formatForCustomerInvoice(
  timestamp: ImmutableLedgerTimestamp,
  timeZone: string
): string {
  const date = new Date(timestamp.epochMilliseconds);

  try {
    return new Intl.DateTimeFormat('en-US', {
      timeZone,
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short',
    }).format(date);
  } catch (error) {
    throw new FinancialTimestampError(
      `Failed to format invoice date for timezone '${timeZone}': ${(error as Error).message}`
    );
  }
}

// ==========================================
// Execution / SaaS Pipeline Demonstration
// ==========================================

try {
  // 1. Capture internal SaaS transaction event time
  const transactionTime = createFinancialTimestamp();
  console.log("Internal Ledger Timestamp Created:");
  console.log(`- Epoch: ${transactionTime.epochMilliseconds}`);
  console.log(`- ISO String: ${transactionTime.isoString}\n`);

  // 2. Process external webhook payload simulation
  const incomingWebhookPayloadTime = "2023-11-01T14:30:00.000Z";
  const normalizedWebhookTime = parseExternalWebhookTimestamp(incomingWebhookPayloadTime);
  console.log("Normalized External Webhook Timestamp:");
  console.log(`- ISO String: ${normalizedWebhookTime.isoString}\n`);

  // 3. Render localized invoice string for a customer in New York
  const nyInvoiceString = formatForCustomerInvoice(normalizedWebhookTime, "America/New_York");
  console.log("Customer Invoice Display (New York):");
  console.log(`- ${nyInvoiceString}\n`);

  // 4. Render localized invoice string for a customer in Tokyo
  const tokyoInvoiceString = formatForCustomerInvoice(normalizedWebhookTime, "Asia/Tokyo");
  console.log("Customer Invoice Display (Tokyo):");
  console.log(`- ${tokyoInvoiceString}`);

} catch (error) {
  console.error("Financial Pipeline Temporal Error:", (error as Error).message);
}
