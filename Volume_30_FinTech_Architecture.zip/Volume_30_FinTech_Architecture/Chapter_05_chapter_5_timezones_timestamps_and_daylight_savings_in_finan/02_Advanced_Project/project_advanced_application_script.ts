/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Temporal } from '@js-temporal/polyfill';

/**
 * Represents the immutable status of a scheduled financial payout.
 */
type PayoutStatus = 'PENDING' | 'PROCESSED' | 'FAILED' | 'SKIPPED_DST_GAP';

/**
 * Immutable interface for a scheduled transaction request.
 */
interface ScheduledPayoutRequest {
  readonly accountId: string;
  readonly amountMinorUnits: bigint; // Stored in minor currency units (e.g., cents)
  readonly currency: string;
  readonly scheduledUtc: Temporal.Instant;
  readonly targetTimeZone: string;
  readonly status: PayoutStatus;
}

/**
 * Immutable interface for the resulting execution report.
 */
interface PayoutExecutionResult {
  readonly requestId: string;
  readonly accountId: string;
  readonly amountMinorUnits: bigint;
  readonly executionInstant: Temporal.Instant;
  readonly localCalendarDate: string;
  readonly status: PayoutStatus;
  readonly auditLog: string;
}

/**
 * Financial Timezone Engine for handling high-reliability payment pipelines.
 * Enforces strict UTC storage, precise ISO 8601 formatting, and safe DST navigation.
 */
class FinancialTimezoneEngine {
  /**
   * Validates and normalizes any incoming timestamp into an immutable UTC Temporal.Instant.
   * Prevents drift caused by local server time configurations.
   * 
   * @param rawInput - ISO 8601 string or existing Instant
   */
  public static normalizeToUtcInstant(rawInput: string): Temporal.Instant {
    try {
      const zdt = Temporal.Instant.from(rawInput);
      return zdt;
    } catch (error) {
      throw new Error(`[FinancialTimezoneEngine] Invalid ISO 8601 timestamp provided: ${rawInput}. Error: ${(error as Error).message}`);
    }
  }

  /**
   * Safely evaluates whether a target local time falls into a Daylight Saving Time gap 
   * (e.g., spring forward where local time jumps from 02:00 to 03:00).
   * 
   * @param instant - The UTC instant being evaluated
   * @param timeZone - The IANA timezone identifier (e.g., 'America/New_York')
   */
  public static isSafeFromDstAnomaly(instant: Temporal.Instant, timeZone: string): boolean {
    const tz = Temporal.TimeZone.from(timeZone);
    const zdt = instant.toZonedDateTimeISO(tz);
    
    // Check transition characteristics by inspecting surrounding offsets
    const previousHour = instant.subtract({ hours: 1 }).toZonedDateTimeISO(tz);
    const nextHour = instant.add({ hours: 1 }).toZonedDateTimeISO(tz);

    // If the offset shift is abrupt (> 1 hour change in offset relative to UTC), flag anomaly
    const offsetDiffMinutes = Math.abs(zdt.offsetNanoseconds - previousHour.offsetNanoseconds) / 60_000_000_000;
    
    if (offsetDiffMinutes > 60) {
      return false; // Indicates a DST transition gap/overlap disruption point
    }
    return true;
  }

  /**
   * Executes a scheduled payout with absolute determinism, returning an immutable result.
   * 
   * @param request - The immutable Payout Request object
   * @param currentExecutionInstant - The authoritative system time as a UTC Instant
   */
  public static processPayout(
    request: ScheduledPayoutRequest,
    currentExecutionInstant: Temporal.Instant
  ): PayoutExecutionResult {
    const requestId = `payout_${crypto.randomUUID()}`;
    const tz = Temporal.TimeZone.from(request.targetTimeZone);

    // 1. Guard against executing payouts ahead of their scheduled UTC time
    if (currentExecutionInstant.compare(request.scheduledUtc) < 0) {
      return Object.freeze({
        requestId,
        accountId: request.accountId,
        amountMinorUnits: request.amountMinorUnits,
        executionInstant: currentExecutionInstant,
        localCalendarDate: currentExecutionInstant.toZonedDateTimeISO(tz).toPlainDate().toString(),
        status: 'PENDING',
        auditLog: 'Execution attempted before scheduled UTC instant. Payout remains PENDING.'
      });
    }

    // 2. Evaluate DST safety for the target timezone at execution moment
    const isDstSafe = this.isSafeFromDstAnomaly(request.scheduledUtc, request.targetTimeZone);
    if (!isDstSafe) {
      return Object.freeze({
        requestId,
        accountId: request.accountId,
        amountMinorUnits: request.amountMinorUnits,
        executionInstant: currentExecutionInstant,
        localCalendarDate: currentExecutionInstant.toZonedDateTimeISO(tz).toPlainDate().toString(),
        status: 'SKIPPED_DST_GAP',
        auditLog: `Execution halted. Target timezone ${request.targetTimeZone} experienced a DST discontinuity at ${request.scheduledUtc.toString()}.`
      });
    }

    // 3. Successful processing path
    const localZdt = request.scheduledUtc.toZonedDateTimeISO(tz);
    return Object.freeze({
      requestId,
      accountId: request.accountId,
      amountMinorUnits: request.amountMinorUnits,
      executionInstant: currentExecutionInstant,
      localCalendarDate: localZdt.toPlainDate().toString(),
      status: 'PROCESSED',
      auditLog: `Successfully executed payout of ${request.amountMinorUnits} ${request.currency} for account ${request.accountId} at UTC ${request.scheduledUtc.toString()} (${localZdt.toPlainString()} local time).`
    });
  }
}

// --- Example Execution Context ---
// Simulating an incoming payout request in an isolated scope
const rawScheduledTime = "2026-03-08T08:30:00Z"; // Potential DST transition day in US Eastern
const targetTz = "America/New_York";

const sampleRequest: ScheduledPayoutRequest = Object.freeze({
  accountId: "acc_992810492",
  amountMinorUnits: 150000n, // $1,500.00 USD
  currency: "USD",
  scheduledUtc: FinancialTimezoneEngine.normalizeToUtcInstant(rawScheduledTime),
  targetTimeZone: targetTz,
  status: 'PENDING'
});

const authoritativeSystemClock = FinancialTimezoneEngine.normalizeToUtcInstant("2026-03-08T09:00:00Z");
const executionResult = FinancialTimezoneEngine.processPayout(sampleRequest, authoritativeSystemClock);

console.log("Immutable Ledger Execution Result:", JSON.stringify(executionResult, (_, v) => typeof v === 'bigint' ? v.toString() : v, 2));
