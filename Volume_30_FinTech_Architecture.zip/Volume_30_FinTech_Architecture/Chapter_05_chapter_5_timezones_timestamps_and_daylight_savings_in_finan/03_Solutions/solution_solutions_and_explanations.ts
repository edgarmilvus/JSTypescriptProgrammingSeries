/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export type EpochMillis = number & { readonly __brand: unique symbol };
export type ISO8601String = string & { readonly __brand: unique symbol };

export class TimezoneAmbiguityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'TimezoneAmbiguityError';
  }
}

export interface AccrualResult {
  readonly accruedInterest: bigint;
  readonly exactDaysElapsed: string; // High-precision string representation of the fractional day
  readonly startUtcEpoch: EpochMillis;
  readonly endUtcEpoch: EpochMillis;
}

/**
 * Validates whether an ISO string contains an explicit UTC 'Z' or numeric offset.
 * Throws TimezoneAmbiguityError if the timestamp lacks clear offset declarations.
 */
function parseAndValidateUtcEpoch(timestamp: ISO8601String | EpochMillis): EpochMillis {
  if (typeof timestamp === 'number') {
    return timestamp as EpochMillis;
  }

  // Check for explicit UTC indicator 'Z' or offset like '+HH:MM' / '-HH:MM'
  const hasUtcZ = timestamp.endsWith('Z');
  const hasNumericOffset = /[+-]\d{2}:?\d{2}$/.test(timestamp);

  if (!hasUtcZ && !hasNumericOffset) {
    throw new TimezoneAmbiguityError(
      `Timestamp '${timestamp}' is ambiguous because it lacks an explicit UTC designator ('Z') or offset.`
    );
  }

  const parsed = Date.parse(timestamp);
  if (Number.isNaN(parsed)) {
    throw new Error(`Invalid ISO 8601 timestamp format: '${timestamp}'`);
  }

  return parsed as EpochMillis;
}

/**
 * Calculates deterministic interest accrual across exact calendar day fractions using BigInt math.
 * 
 * @param balance - The account balance represented in minor currency units (e.g., cents) as a BigInt.
 * @param apyBasisPoints - Annual Percentage Yield represented in basis points (e.g., 500 = 5%).
 * @param start - Start timestamp (ISO string with explicit offset or EpochMillis).
 * @param end - End timestamp (ISO string with explicit offset or EpochMillis).
 */
export function calculateAccruedInterest(
  balance: bigint,
  apyBasisPoints: bigint,
  start: ISO8601String | EpochMillis,
  end: ISO8601String | EpochMillis
): AccrualResult {
  const startEpoch = parseAndValidateUtcEpoch(start);
  const endEpoch = parseAndValidateUtcEpoch(end);

  if (endEpoch < startEpoch) {
    throw new Error('End timestamp cannot precede start timestamp.');
  }

  const durationMs = BigInt(endEpoch - startEpoch);
  const msPerDay = 86400000n; // Exactly 24 * 60 * 60 * 1000 ms per standard calendar day

  // Precision scaling factor to avoid floating-point drift during integer division
  const PRECISION_SCALE = 1000000000000n; 
  const BASIS_DIVISOR = 10000n; // 100% = 10000 basis points
  const DAYS_IN_YEAR = 365n;

  // Calculate elapsed days as a high-precision scaled integer
  // elapsedDaysScaled = (durationMs * PRECISION_SCALE) / msPerDay
  const elapsedDaysScaled = (durationMs * PRECISION_SCALE) / msPerDay;

  // Interest Formula: Balance * APY * (DaysElapsed / 365)
  // Scaled calculation: (Balance * apyBasisPoints * elapsedDaysScaled) / (BASIS_DIVISOR * DAYS_IN_YEAR * PRECISION_SCALE)
  const numerator = balance * apyBasisPoints * elapsedDaysScaled;
  const denominator = BASIS_DIVISOR * DAYS_IN_YEAR * PRECISION_SCALE;

  const accruedInterest = numerator / denominator;

  // Compute human-readable fractional days for logging/audit purposes
  const wholeDays = durationMs / msPerDay;
  const remainderMs = durationMs % msPerDay;
  const exactDaysElapsed = `${wholeDays}.${(remainderMs * 100000n) / msPerDay}`;

  return Object.freeze({
    accruedInterest,
    exactDaysElapsed,
    startUtcEpoch: startEpoch,
    endUtcEpoch: endEpoch,
  });
}
