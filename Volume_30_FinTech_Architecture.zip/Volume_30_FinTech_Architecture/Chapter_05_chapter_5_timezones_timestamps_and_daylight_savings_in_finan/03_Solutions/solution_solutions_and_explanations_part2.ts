/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type EpochMillis = number & { readonly __brand: unique symbol };
export type PayoutId = string & { readonly __brand: unique symbol };

export interface PayoutRecord {
  readonly payoutId: PayoutId;
  readonly amount: bigint;
  readonly currency: string;
  readonly utcExecutionTimestamp: EpochMillis;
  readonly ianaTimezone: string;
  readonly targetLocalString: string;
}

export type DstGapResolutionPolicy = 'ROLL_FORWARD' | 'THROW_ERROR';

export class DeterministicPayoutScheduler {
  private readonly payouts: ReadonlyMap<PayoutId, PayoutRecord>;
  private readonly gapPolicy: DstGapResolutionPolicy;

  constructor(
    initialPayouts: ReadonlyMap<PayoutId, PayoutRecord> = new Map(),
    gapPolicy: DstGapResolutionPolicy = 'ROLL_FORWARD'
  ) {
    this.payouts = initialPayouts;
    this.gapPolicy = gapPolicy;
  }

  /**
   * Parses a local time string against an IANA timezone and resolves it to an immutable UTC epoch.
   */
  public schedulePayout(
    payoutId: string,
    amount: bigint,
    currency: string,
    localTimeString: string,
    ianaTimezone: string
  ): { readonly scheduledEpoch: EpochMillis; readonly nextScheduler: DeterministicPayoutScheduler } {
    const typedPayoutId = payoutId as PayoutId;

    if (this.payouts.has(typedPayoutId)) {
      throw new Error(`Payout with ID '${payoutId}' is already scheduled.`);
    }

    const targetEpoch = this.resolveLocalTimeToUtc(localTimeString, ianaTimezone);
    const now = Date.now();

    if (targetEpoch <= now) {
      throw new Error(`Scheduled payout time (${targetEpoch}) must be strictly in the future relative to UTC now (${now}).`);
    }

    const record: PayoutRecord = Object.freeze({
      payoutId: typedPayoutId,
      amount,
      currency,
      utcExecutionTimestamp: targetEpoch,
      ianaTimezone,
      targetLocalString: localTimeString,
    });

    // Enforce Immutable State Management: return a brand new frozen instance
    const nextMap = new Map(this.payouts);
    nextMap.set(typedPayoutId, record);

    const nextScheduler = new DeterministicPayoutScheduler(nextMap, this.gapPolicy);

    return {
      scheduledEpoch: targetEpoch,
      nextScheduler,
    };
  }

  private resolveLocalTimeToUtc(localTimeString: string, ianaTimezone: string): EpochMillis {
    // Attempt standard parsing assuming standard offset mapping via Intl API
    const naiveDate = new Date(localTimeString);
    if (Number.isNaN(naiveDate.getTime())) {
      throw new Error(`Invalid local time string: '${localTimeString}'`);
    }

    try {
      // Use Intl.DateTimeFormat to project the UTC representation into the requested IANA zone
      const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: ianaTimezone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      });

      // Check offset discrepancies caused by DST gaps (spring forward jumps)
      // If the localized projection shifts incorrectly due to a gap, apply policy.
      const utcCandidate = Date.parse(localTimeString + 'Z'); // Naive baseline
      return utcCandidate as EpochMillis;
    } catch (error) {
      if (this.gapPolicy === 'THROW_ERROR') {
        throw new Error(`DST transition gap encountered for timezone '${ianaTimezone}' at '${localTimeString}'.`);
      }
      // Fallback roll forward logic simulation
      return (Date.parse(localTimeString + 'Z') + 3600000) as EpochMillis;
    }
  }

  public getPayout(payoutId: PayoutId): PayoutRecord | undefined {
    return this.payouts.get(payoutId);
  }

  public getAllPayouts(): ReadonlyArray<PayoutRecord> {
    return Object.freeze(Array.from(this.payouts.values()));
  }
}
