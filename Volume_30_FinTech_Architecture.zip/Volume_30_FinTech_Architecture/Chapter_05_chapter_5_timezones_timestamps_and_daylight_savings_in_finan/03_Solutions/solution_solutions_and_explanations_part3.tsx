/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

export type TransactionUUID = string & { readonly __brand: unique symbol };
export type EpochTimestampMs = number & { readonly __brand: unique symbol };

export interface AuditTransactionRecord {
  readonly id: TransactionUUID;
  readonly timestamp: EpochTimestampMs;
  readonly amount: string; // Serialized high-precision decimal
  readonly currency: string;
  readonly sourceTimezone: string;
  readonly isDstBoundaryViolation: boolean;
}

export type SupportedDisplayTimezone = 
  | 'UTC' 
  | 'America/New_York' 
  | 'Europe/London' 
  | 'Asia/Tokyo' 
  | 'LOCAL_SYSTEM';

export interface LedgerAuditTimelineProps {
  readonly transactions: readonly AuditTransactionRecord[];
  readonly defaultDisplayTimezone: SupportedDisplayTimezone;
  readonly onTimezoneChange?: (newTimezone: SupportedDisplayTimezone) => void;
  readonly highlightDstBoundaries: boolean;
}

export interface LedgerAuditTimelineState {
  readonly currentDisplayTimezone: SupportedDisplayTimezone;
  readonly selectedTransactionId: TransactionUUID | null;
  readonly filterAmbiguousOnly: boolean;
}

export const LedgerAuditTimeline: React.FC<LedgerAuditTimelineProps> = ({
  transactions,
  defaultDisplayTimezone,
  onTimezoneChange,
  highlightDstBoundaries,
}) => {
  const [displayTimezone, setDisplayTimezone] = useState<SupportedDisplayTimezone>(defaultDisplayTimezone);
  const [selectedId, setSelectedId] = useState<TransactionUUID | null>(null);
  const [filterAmbiguous, setFilterAmbiguous] = useState<boolean>(false);

  const handleTimezoneSelect = (tz: SupportedDisplayTimezone) => {
    setDisplayTimezone(tz);
    if (onTimezoneChange) {
      onTimezoneChange(tz);
    }
  };

  const filteredTransactions = useMemo(() => {
    if (!filterAmbiguous) return transactions;
    return transactions.filter(tx => tx.isDstBoundaryViolation);
  }, [transactions, filterAmbiguous]);

  return (
    <div className="ledger-audit-timeline-container" style={{ padding: '20px', fontFamily: 'monospace' }}>
      <header style={{ marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center' }}>
        <label htmlFor="tz-select"><strong>Display Timezone:</strong></label>
        <select
          id="tz-select"
          value={displayTimezone}
          onChange={(e) => handleTimezoneSelect(e.target.value as SupportedDisplayTimezone)}
        >
          <option value="UTC">UTC (Coordinated Universal Time)</option>
          <option value="America/New_York">America/New_York (EST/EDT)</option>
          <option value="Europe/London">Europe/London (GMT/BST)</option>
          <option value="Asia/Tokyo">Asia/Tokyo (JST)</option>
          <option value="LOCAL_SYSTEM">Local System Time</option>
        </select>

        <label style={{ marginLeft: '20px' }}>
          <input
            type="checkbox"
            checked={filterAmbiguous}
            onChange={(e) => setFilterAmbiguous(e.target.checked)}
          />
          Filter DST Boundary Anomalies Only
        </label>
      </header>

      <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #ccc' }}>
        <thead>
          <tr style={{ background: '#f5f5f5', textAlign: 'left' }}>
            <th style={{ padding: '8px', border: '1px solid #ccc' }}>Transaction ID</th>
            <th style={{ padding: '8px', border: '1px solid #ccc' }}>Formatted Timestamp ({displayTimezone})</th>
            <th style={{ padding: '8px', border: '1px solid #ccc' }}>Amount</th>
            <th style={{ padding: '8px', border: '1px solid #ccc' }}>Compliance Status</th>
          </tr>
        </thead>
        <tbody>
          {filteredTransactions.map((tx) => {
            const dateObj = new Date(tx.timestamp);
            const tzOption = displayTimezone === 'LOCAL_SYSTEM' ? undefined : displayTimezone;
            const formattedDate = dateObj.toLocaleString('en-US', { timeZone: tzOption, hour12: false, fractionalSecondDigits: 3 });

            return (
              <tr 
                key={tx.id} 
                onClick={() => setSelectedId(tx.id)}
                style={{ 
                  background: selectedId === tx.id ? '#e6f2ff' : 'transparent',
                  cursor: 'pointer' 
                }}
              >
                <td style={{ padding: '8px', border: '1px solid #ccc' }}>{tx.id}</td>
                <td style={{ padding: '8px', border: '1px solid #ccc' }}>{formattedDate}</td>
                <td style={{ padding: '8px', border: '1px solid #ccc' }}>{tx.amount} {tx.currency}</td>
                <td style={{ padding: '8px', border: '1px solid #ccc' }}>
                  {highlightDstBoundaries && tx.isDstBoundaryViolation && (
                    <span style={{ color: '#d9534f', fontWeight: 'bold', border: '1px solid #d9534f', padding: '2px 6px', borderRadius: '4px' }}>
                      ⚠️ DST Transition Proximity Warning
                    </span>
                  )}
                  {(!highlightDstBoundaries || !tx.isDstBoundaryViolation) && (
                    <span style={{ color: '#5cb85c' }}>Verified Normal</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
