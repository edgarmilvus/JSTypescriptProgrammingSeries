/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export type AccountId = string & { readonly __brand: unique symbol };
export type LedgerPostingId = string & { readonly __brand: unique symbol };
export type UTCDateString = string & { readonly __brand: unique symbol }; // Format: YYYY-MM-DD

export interface LedgerPostingInput {
  readonly postingId: LedgerPostingId;
  readonly accountId: AccountId;
  readonly amount: bigint;
  readonly isDebit: boolean;
  readonly utcTimestamp: number;
  readonly localTimezone: string;
}

export interface TemporalMismatchReport {
  readonly postingIdA: LedgerPostingId;
  readonly postingIdB: LedgerPostingId;
  readonly assignedUtcDateA: UTCDateString;
  readonly assignedUtcDateB: UTCDateString;
  readonly disparityHours: number;
  readonly reconciliationStatus: 'FLAGGED_TIMELINE_MISMATCH' | 'RESOLVED_BY_POLICY';
}

export class TemporalLedgerReconciler {
  private readonly postings: ReadonlyArray<LedgerPostingInput>;

  constructor(postings: readonly LedgerPostingInput[] = []) {
    this.postings = Object.freeze([...postings]);
  }

  public addPostings(newPostings: readonly LedgerPostingInput[]): TemporalLedgerReconciler {
    // Immutable State Management: return a new instance with combined frozen array
    return new TemporalLedgerReconciler([...this.postings, ...newPostings]);
  }

  private getUtcDateString(epochMs: number): UTCDateString {
    const date = new Date(epochMs);
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    return `${year}-${month}-${day}` as UTCDateString;
  }

  public reconcile(targetDateRange?: { start: UTCDateString; end: UTCDateString }): {
    readonly isBalanced: boolean;
    readonly totalPostingsEvaluated: number;
    readonly temporalMismatches: readonly TemporalMismatchReport[];
  } {
    let netBalance = 0n;
    const dateMap = new Map<UTCDateString, bigint>();
    const mismatches: TemporalMismatchReport[] = [];

    for (const posting of this.postings) {
      const utcDate = this.getUtcDateString(posting.utcTimestamp);

      if (targetDateRange) {
        if (utcDate < targetDateRange.start || utcDate > targetDateRange.end) {
          continue;
        }
      }

      // Double entry balance tracking
      const signedAmount = posting.isDebit ? posting.amount : -posting.amount;
      netBalance += signedAmount;

      const currentDayTotal = dateMap.get(utcDate) || 0n;
      dateMap.set(utcDate, currentDayTotal + signedAmount);
    }

    // Detect cross-border temporal mismatches (paired postings with date discrepancies)
    for (let i = 0; i < this.postings.length; i++) {
      for (let j = i + 1; j < this.postings.length; j++) {
        const postingA = this.postings[i];
        const postingB = this.postings[j];

        // Example heuristic: if matching absolute amounts but different calendar dates due to timezones
        if (postingA.amount === postingB.amount && postingA.isDebit !== postingB.isDebit) {
          const dateA = this.getUtcDateString(postingA.utcTimestamp);
          const dateB = this.getUtcDateString(postingB.utcTimestamp);

          if (dateA !== dateB) {
            const diffMs = Math.abs(postingA.utcTimestamp - postingB.utcTimestamp);
            const disparityHours = diffMs / (1000 * 60 * 60);

            mismatches.push(Object.freeze({
              postingIdA: postingA.postingId,
              postingIdB: postingB.postingId,
              assignedUtcDateA: dateA,
              assignedUtcDateB: dateB,
              disparityHours,
              reconciliationStatus: 'FLAGGED_TIMELINE_MISMATCH',
            }));
          }
        }
      }
    }

    return Object.freeze({
      isBalanced: netBalance === 0n,
      totalPostingsEvaluated: this.postings.length,
      temporalMismatches: Object.freeze(mismatches),
    });
  }
}
