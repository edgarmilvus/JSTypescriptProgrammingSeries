/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Define your types and function signature for the interactive challenge here.
// Remember: NO SOLUTION CODE. Only definitions and stubs.

export type ISO8601String = string & { readonly __brand: unique symbol };
export type EpochMillis = number & { readonly __brand: unique symbol };

export interface AccrualAuditRequest {
  readonly batchId: string;
  readonly rawTimestamps: readonly ISO8601String[];
  readonly targetTimezone: string;
}

export interface SanitizedInterval {
  readonly original: ISO8601String;
  readonly utcEpochStart: EpochMillis;
  readonly utcEpochEnd: EpochMillis;
  readonly isAmbiguousDST: boolean;
}

export interface AccrualAuditResult {
  readonly batchId: string;
  readonly validIntervals: readonly SanitizedInterval[];
  readonly flaggedAmbiguities: readonly ISO8601String[];
}

export declare function audit_accrual_window(
  request: AccrualAuditRequest
): Promise<AccrualAuditResult>;
