/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Define your types and interfaces for the consensus payout validation here.
// Remember: NO SOLUTION CODE. Only definitions and stubs.

export type PayoutId = string & { readonly __brand: unique symbol };
export type UTCSeconds = number & { readonly __brand: unique symbol };

export interface AgentProposal {
  readonly agentId: string;
  readonly proposedUtcExecutionTime: UTCSeconds;
  readonly confidenceScore: number; // 0.0 to 1.0
  readonly computedOffsetMinutes: number;
}

export interface ConsensusEvaluationPayload {
  readonly payoutId: PayoutId;
  readonly targetLocalTime: string;
  readonly ianaTimezone: string;
  readonly agentProposals: readonly AgentProposal[];
}

export interface ConsensusResult {
  readonly payoutId: PayoutId;
  readonly agreedUtcExecutionTime: UTCSeconds;
  readonly varianceDetectedSeconds: number;
  readonly consensusReached: boolean;
  readonly dissentingAgents: readonly string[];
}

export declare function evaluatePayoutConsensus(
  payload: ConsensusEvaluationPayload
): ConsensusResult;
