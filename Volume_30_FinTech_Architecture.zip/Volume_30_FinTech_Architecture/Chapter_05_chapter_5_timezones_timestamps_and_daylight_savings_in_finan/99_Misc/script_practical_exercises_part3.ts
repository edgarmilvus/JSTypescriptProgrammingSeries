/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Define your TSX component props, state models, and function signature here.
// Remember: NO SOLUTION CODE. Only definitions and stubs.

import React from 'react';

export type TransactionUUID = string & { readonly __brand: unique symbol };
export type EpochTimestampMs = number & { readonly __brand: unique symbol };

export interface AuditTransactionRecord {
  readonly id: TransactionUUID;
  readonly timestamp: EpochTimestampMs;
  readonly amount: string; // Serialized high-precision decimal
  readonly currency: string;
  readonly sourceTimezone: string;
  readonly isDstBoundaryViolation: boolean;
}

export type SupportedDisplayTimezone = 
  | 'UTC' 
  | 'America/New_York' 
  | 'Europe/London' 
  | 'Asia/Tokyo' 
  | 'LOCAL_SYSTEM';

export interface LedgerAuditTimelineProps {
  readonly transactions: readonly AuditTransactionRecord[];
  readonly defaultDisplayTimezone: SupportedDisplayTimezone;
  readonly onTimezoneChange?: (newTimezone: SupportedDisplayTimezone) => void;
  readonly highlightDstBoundaries: boolean;
}

export interface LedgerAuditTimelineState {
  readonly currentDisplayTimezone: SupportedDisplayTimezone;
  readonly selectedTransactionId: TransactionUUID | null;
  readonly filterAmbiguousOnly: boolean;
}

export declare const LedgerAuditTimeline: React.FC<LedgerAuditTimelineProps>;
