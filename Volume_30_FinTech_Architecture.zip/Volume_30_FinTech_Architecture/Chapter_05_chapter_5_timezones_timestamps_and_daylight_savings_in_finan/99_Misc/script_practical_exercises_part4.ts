/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// Define your types and function signatures for the reconciliation tool-calling interface here.
// Remember: NO SOLUTION CODE. Only definitions and stubs.

export type AccountId = string & { readonly __brand: unique symbol };
export type LedgerPostingId = string & { readonly __brand: unique symbol };
export type UTCDateString = string & { readonly __brand: unique symbol }; // Format: YYYY-MM-DD

export interface LedgerPostingInput {
  readonly postingId: LedgerPostingId;
  readonly accountId: AccountId;
  readonly amount: bigint;
  readonly isDebit: boolean;
  readonly utcTimestamp: number;
  readonly localTimezone: string;
}

export interface TemporalMismatchReport {
  readonly postingIdA: LedgerPostingId;
  readonly postingIdB: LedgerPostingId;
  readonly assignedUtcDateA: UTCDateString;
  readonly assignedUtcDateB: UTCDateString;
  readonly disparityHours: number;
  readonly reconciliationStatus: 'FLAGGED_TIMELINE_MISMATCH' | 'RESOLVED_BY_POLICY';
}

export interface ReconciliationQueryRequest {
  readonly ledgerBatchId: string;
  readonly targetDateRange: {
    readonly start: UTCDateString;
    readonly end: UTCDateString;
  };
  readonly postings: readonly LedgerPostingInput[];
}

export interface ReconciliationQueryResponse {
  readonly batchId: string;
  readonly isBalanced: boolean;
  readonly totalPostingsEvaluated: number;
  readonly temporalMismatches: readonly TemporalMismatchReport[];
  readonly generatedAtUtc: number;
}

export declare function executeTemporalReconciliationQuery(
  request: ReconciliationQueryRequest
): Promise<ReconciliationQueryResponse>;
