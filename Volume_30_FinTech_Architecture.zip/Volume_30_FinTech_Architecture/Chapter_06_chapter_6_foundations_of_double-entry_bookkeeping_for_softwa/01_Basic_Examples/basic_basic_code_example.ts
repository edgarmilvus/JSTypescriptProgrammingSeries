/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ledger.ts
 * @description A foundational, self-contained double-entry bookkeeping engine in TypeScript
 * designed for SaaS and web application payment pipelines.
 */

/**
 * Enumeration of the five primary accounting categories.
 * These classifications dictate how normal balances behave.
 */
enum AccountType {
  ASSET = 'ASSET',         // Normal balance: Debit
  LIABILITY = 'LIABILITY', // Normal balance: Credit
  EQUITY = 'EQUITY',       // Normal balance: Credit
  REVENUE = 'REVENUE',     // Normal balance: Credit
  EXPENSE = 'EXPENSE'      // Normal balance: Debit
}

/**
 * Represents a distinct financial account within the ledger system.
 */
interface Account {
  readonly id: string;
  readonly name: string;
  readonly type: AccountType;
}

/**
 * Specifies the directional vector of a financial posting.
 */
enum PostingType {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT'
}

/**
 * Represents a single line item within a transaction.
 * Links an account to a monetary value and a direction (Debit or Credit).
 */
interface Posting {
  readonly account: Account;
  readonly amount: number; // Stored as an integer (e.g., cents) to prevent IEEE 754 float drift
  readonly type: PostingType;
}

/**
 * Represents an immutable, balanced financial transaction consisting of two or more postings.
 */
interface Transaction {
  readonly id: string;
  readonly description: string;
  readonly timestamp: Date;
  readonly postings: ReadonlyArray<Posting>;
}

/**
 * Validates the fundamental accounting invariant for a given transaction:
 * The sum of all DEBIT postings must exactly equal the sum of all CREDIT postings.
 * 
 * @param transaction The transaction to validate.
 * @throws Error if the transaction is unbalanced.
 */
function validateTransaction(transaction: Transaction): void {
  let totalDebits = 0;
  let totalCredits = 0;

  for (const posting of transaction.postings) {
    if (posting.amount <= 0) {
      throw new Error(`Invalid posting amount in account ${posting.account.name}: amounts must be strictly positive integers.`);
    }

    if (posting.type === PostingType.DEBIT) {
      totalDebits += posting.amount;
    } else {
      totalCredits += posting.amount;
    }
  }

  if (totalDebits !== totalCredits) {
    throw new Error(
      `Unbalanced transaction detected [ID: ${transaction.id}]: ` +
      `Total Debits (${totalDebits}) do not equal Total Credits (${totalCredits}).`
    );
  }
}

// ==========================================
// EXAMPLE USAGE: SaaS Subscription Checkout
// ==========================================

// 1. Define Chart of Accounts
const cashAccount: Account = {
  id: 'ACC-CASH-001',
  name: 'Operating Cash',
  type: AccountType.ASSET,
};

const subscriptionRevenueAccount: Account = {
  id: 'ACC-REV-001',
  name: 'Subscription Revenue',
  type: AccountType.REVENUE,
};

// 2. Construct a balanced transaction for a $50.00 SaaS subscription payment
// $50.00 is represented as 5000 cents to avoid floating-point errors.
const saasSubscriptionTransaction: Transaction = {
  id: 'TXN-2023-10-001',
  description: 'Monthly Pro Plan Subscription - Customer #8492',
  timestamp: new Date(),
  postings: [
    {
      account: cashAccount,
      amount: 5000,
      type: PostingType.DEBIT, // Increases Asset (Cash)
    },
    {
      account: subscriptionRevenueAccount,
      amount: 5000,
      type: PostingType.CREDIT, // Increases Revenue
    },
  ],
};

try {
  // 3. Execute validation rule
  validateTransaction(saasSubscriptionTransaction);
  console.log(`[LEDGER SUCCESS]: Transaction ${saasSubscriptionTransaction.id} posted successfully.`);
} catch (error: unknown) {
  if (error instanceof Error) {
    console.error(`[LEDGER ERROR]: ${error.message}`);
  } else {
    console.error('[LEDGER ERROR]: An unknown error occurred.');
  }
}
