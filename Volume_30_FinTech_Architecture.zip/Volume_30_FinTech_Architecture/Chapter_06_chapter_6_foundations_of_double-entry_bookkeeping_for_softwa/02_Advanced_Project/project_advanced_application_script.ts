/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file ledger-engine.ts
 * @description Enterprise-grade Double-Entry Bookkeeping Engine in TypeScript.
 * Enforces zero-sum invariants, arbitrary precision, and immutable audit trails
 * suitable for a SaaS financial pipeline.
 */

import { Decimal } from 'decimal.js';

// Configure Decimal.js for precise financial math (rounding to 4 decimal places, standard banker's rounding)
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_EVEN });

/**
 * Fundamental accounting classifications governing normal balances and financial statements.
 */
export enum AccountType {
  ASSET = 'ASSET',         // Normal balance: Debit (+), Credit (-)
  LIABILITY = 'LIABILITY', // Normal balance: Debit (-), Credit (+)
  EQUITY = 'EQUITY',       // Normal balance: Debit (-), Credit (+)
  REVENUE = 'REVENUE',     // Normal balance: Debit (-), Credit (+)
  EXPENSE = 'EXPENSE'      // Normal balance: Debit (+), Credit (-)
}

/**
 * Direction of a transaction posting.
 */
export enum PostingType {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT'
}

/**
 * Represents a distinct financial account within the chart of accounts.
 */
export interface Account {
  readonly id: string;
  readonly name: string;
  readonly type: AccountType;
  readonly currency: string;
  readonly isActive: boolean;
}

/**
 * Represents a single leg (line item) of a double-entry transaction.
 */
export interface Posting {
  readonly id: string;
  readonly accountId: string;
  readonly type: PostingType;
  readonly amount: Decimal;
}

/**
 * Represents an immutable, balanced journal entry containing two or more postings.
 */
export interface JournalEntry {
  readonly id: string;
  readonly timestamp: Date;
  readonly description: string;
  readonly referenceId: string; // e.g., Stripe Charge ID or Invoice UUID
  readonly postings: ReadonlyArray<Posting>;
}

/**
 * Validates whether a proposed posting balances against normal accounting rules.
 */
export class LedgerValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LedgerValidationError';
  }
}

/**
 * Core Ledger Engine managing posting verification, invariant enforcement,
 * and account balance calculations.
 */
export class LedgerEngine {
  private accounts: Map<string, Account> = new Map();
  private journalEntries: JournalEntry[] = [];

  /**
   * Registers a new account into the ledger's Chart of Accounts.
   */
  public createAccount(account: Account): void {
    if (this.accounts.has(account.id)) {
      throw new LedgerValidationError(`Account with ID ${account.id} already exists.`);
    }
    this.accounts.set(account.id, account);
  }

  /**
   * Commits an immutable journal entry after validating the zero-sum invariant
   * and account existence.
   */
  public commitTransaction(entry: JournalEntry): void {
    if (this.journalEntries.some(existing => existing.id === entry.id)) {
      throw new LedgerValidationError(`Duplicate journal entry ID: ${entry.id}`);
    }

    if (!entry.postings || entry.postings.length < 2) {
      throw new LedgerValidationError('A double-entry transaction must contain at least two postings.');
    }

    let totalDebits = new Decimal(0);
    let totalCredits = new Decimal(0);

    // Validate each posting line item
    for (const posting of entry.postings) {
      const account = this.accounts.get(posting.accountId);
      if (!account) {
        throw new LedgerValidationError(`Account ${posting.accountId} does not exist in the Chart of Accounts.`);
      }
      if (!account.isActive) {
        throw new LedgerValidationError(`Account ${account.id} is inactive and cannot accept postings.`);
      }
      if (posting.amount.lessThanOrEqualTo(0)) {
        throw new LedgerValidationError(`Posting amount must be strictly positive. Found: ${posting.amount.toString()}`);
      }

      if (posting.type === PostingType.DEBIT) {
        totalDebits = totalDebits.plus(posting.amount);
      } else {
        totalCredits = totalCredits.plus(posting.amount);
      }
    }

    // Enforce Zero-Sum Invariant: Sum(Debits) - Sum(Credits) === 0
    if (!totalDebits.equals(totalCredits)) {
      throw new LedgerValidationError(
        `Unbalanced journal entry. Total Debits (${totalDebits.toString()}) must equal Total Credits (${totalCredits.toString()}).`
      );
    }

    // Append to the immutable ledger log
    this.journalEntries.push(Object.freeze(entry));
  }

  /**
   * Computes the current balance of an account based on its normal balance type.
   */
  public getAccountBalance(accountId: string): Decimal {
    const account = this.accounts.get(accountId);
    if (!account) {
      throw new LedgerValidationError(`Account ${accountId} does not exist.`);
    }

    let balance = new Decimal(0);

    for (const entry of this.journalEntries) {
      for (const posting of entry.postings) {
        if (posting.accountId === accountId) {
          if (posting.type === PostingType.DEBIT) {
            balance = account.type === AccountType.ASSET || account.type === AccountType.EXPENSE
              ? balance.plus(posting.amount)
              : balance.minus(posting.amount);
          } else { // CREDIT
            balance = account.type === AccountType.ASSET || account.type === AccountType.EXPENSE
              ? balance.minus(posting.amount)
              : balance.plus(posting.amount);
          }
        }
      }
    }

    return balance;
  }
}

// ==========================================
// USAGE EXAMPLE: SaaS Subscription Checkout
// ==========================================

const ledger = new LedgerEngine();

// 1. Initialize Chart of Accounts
ledger.createAccount({ id: '1000', name: 'Cash / Stripe Clearing', type: AccountType.ASSET, currency: 'USD', isActive: true });
ledger.createAccount({ id: '2000', name: 'Unearned Subscription Revenue (Deferred)', type: AccountType.LIABILITY, currency: 'USD', isActive: true });
ledger.createAccount({ id: '4000', name: 'Subscription Revenue', type: AccountType.REVENUE, currency: 'USD', isActive: true });

// 2. Simulate a Customer Paying $99.00 for an Annual Subscription Upfront
// Debit Cash ($99.00), Credit Deferred Revenue ($99.00)
const subscriptionPayment: JournalEntry = {
  id: 'JE-2023-11-001',
  timestamp: new Date(),
  description: 'Customer subscription checkout via Stripe',
  referenceId: 'ch_3Mxyz123456789',
  postings: [
    { id: 'p1', accountId: '1000', type: PostingType.DEBIT, amount: new Decimal('99.00') },
    { id: 'p2', accountId: '2000', type: PostingType.CREDIT, amount: new Decimal('99.00') }
  ]
};

ledger.commitTransaction(subscriptionPayment);

console.log('Cash Balance:', ledger.getAccountBalance('1000').toString()); // Outputs: 99
console.log('Deferred Revenue Balance:', ledger.getAccountBalance('2000').toString()); // Outputs: 99
