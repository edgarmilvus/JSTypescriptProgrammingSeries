/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
export type Direction = 'DEBIT' | 'CREDIT';

export interface Account {
  readonly id: string;
  readonly name: string;
  readonly type: AccountType;
  readonly currency: string;
}

export interface Posting {
  readonly accountId: string;
  readonly amount: number;
  readonly direction: Direction;
}

export function calculateNewBalance(
  currentBalance: number,
  accountType: AccountType,
  posting: Posting
): number {
  const { amount, direction } = posting;

  switch (accountType) {
    case 'ASSET':
    case 'EXPENSE':
      // Natural debit balance: Debits increase, Credits decrease
      return direction === 'DEBIT' ? currentBalance + amount : currentBalance - amount;

    case 'LIABILITY':
    case 'EQUITY':
    case 'REVENUE':
      // Natural credit balance: Credits increase, Debits decrease
      return direction === 'CREDIT' ? currentBalance + amount : currentBalance - amount;

    default: {
      // TypeScript compile-time exhaustiveness guarantee (never-type check)
      const exhaustiveCheck: never = accountType;
      throw new Error(`Unhandled account type: ${exhaustiveCheck}`);
    }
  }
}
