/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { JournalEntryData, createJournalEntry } from './exercise-1';

export class ImmutableLedgerEngine {
  private readonly entries: readonly JournalEntryData[] = [];

  constructor(initialEntries: readonly JournalEntryData[] = []) {
    // Validate and defensively copy all initial entries
    const validatedEntries = initialEntries.map(entry => createJournalEntry(entry));
    this.entries = Object.freeze([...validatedEntries]);
  }

  public commitEntry(entry: JournalEntryData): void {
    const validatedEntry = createJournalEntry(entry);
    
    // Immutable append pattern: create a new array instance and freeze it
    (this as { entries: readonly JournalEntryData[] }).entries = Object.freeze([
      ...this.entries,
      validatedEntry,
    ]);
  }

  public getAccountBalanceAtTime(accountId: string, targetTimestamp: Date, accountTypeMap: Map<string, AccountType>): number {
    let balance = 0;

    for (const entry of this.entries) {
      if (entry.timestamp <= targetTimestamp) {
        for (const posting of entry.postings) {
          if (posting.accountId === accountId) {
            const type = accountTypeMap.get(accountId);
            if (!type) continue;

            const isNormalDebit = type === 'ASSET' || type === 'EXPENSE';
            if (posting.direction === 'DEBIT') {
              balance += isNormalDebit ? posting.amount : -posting.amount;
            } else {
              balance += isNormalDebit ? -posting.amount : posting.amount;
            }
          }
        }
      }
    }

    return balance;
  }

  public getAuditTrail(accountId: string): readonly JournalEntryData[] {
    return this.entries.filter(entry => 
      entry.postings.some(posting => posting.accountId === accountId)
    );
  }

  public getEntries(): readonly JournalEntryData[] {
    return this.entries;
  }
}
