/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

export type Direction = 'DEBIT' | 'CREDIT';
export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface Posting {
  readonly accountId: string;
  readonly amount: number;
  readonly direction: Direction;
}

export interface JournalEntry {
  readonly id: string;
  readonly timestamp: Date;
  readonly description: string;
  readonly postings: readonly Posting[];
}

export interface Account {
  readonly id: string;
  readonly name: string;
  readonly type: AccountType;
  readonly currency: string;
}

interface LedgerAuditDashboardProps {
  readonly initialEntries: readonly JournalEntry[];
  readonly accounts: readonly Account[];
}

export const LedgerAuditDashboard: React.FC<LedgerAuditDashboardProps> = ({
  initialEntries,
  accounts,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Calculate system-wide totals and check invariant health
  const ledgerMetrics = useMemo(() => {
    let totalDebits = 0;
    let totalCredits = 0;

    for (const entry of initialEntries) {
      for (const posting of entry.postings) {
        if (posting.direction === 'DEBIT') {
          totalDebits += posting.amount;
        } else {
          totalCredits += posting.amount;
        }
      }
    }

    const isBalanced = totalDebits === totalCredits;
    return { totalDebits, totalCredits, isBalanced };
  }, [initialEntries]);

  // Filter entries based on search query
  const filteredEntries = useMemo(() => {
    if (!searchTerm.trim()) return initialEntries;
    const query = searchTerm.toLowerCase();
    return initialEntries.filter(
      entry =>
        entry.description.toLowerCase().includes(query) ||
        entry.id.toLowerCase().includes(query) ||
        entry.postings.some(p => p.accountId.toLowerCase().includes(query))
    );
  }, [initialEntries, searchTerm]);

  const formatCurrency = (amountInCents: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amountInCents / 100);
  };

  return (
    <div className="ledger-dashboard" style={{ padding: '24px', fontFamily: 'sans-serif' }}>
      <header style={{ marginBottom: '20px' }}>
        <h1>Ledger Audit & Invariant Dashboard</h1>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginTop: '10px' }}>
          <span
            style={{
              padding: '6px 12px',
              borderRadius: '4px',
              fontWeight: 'bold',
              backgroundColor: ledgerMetrics.isBalanced ? '#d4edda' : '#f8d7da',
              color: ledgerMetrics.isBalanced ? '#155724' : '#721c24',
            }}
          >
            {ledgerMetrics.isBalanced ? '✓ LEDGER BALANCED' : '⚠ CORRUPTED - INVARIANT FAILED'}
          </span>
          <span>Total Debits: {formatCurrency(ledgerMetrics.totalDebits)}</span>
          <span>Total Credits: {formatCurrency(ledgerMetrics.totalCredits)}</span>
        </div>
      </header>
      
      <section className="controls" style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Search entries by description, ID, or account..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ width: '100%', padding: '8px', fontSize: '14px', borderRadius: '4px', border: '1px solid #ccc' }}
        />
      </section>

      <section className="transaction-stream">
        <h2>Journal Entries ({filteredEntries.length})</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {filteredEntries.map((entry) => (
            <div key={entry.id} style={{ border: '1px solid #e0e0e0', borderRadius: '6px', padding: '16px', background: '#fafafa' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <strong>{entry.description}</strong>
                <span style={{ fontSize: '12px', color: '#666' }}>{entry.timestamp.toISOString()}</span>
              </div>
              <div style={{ fontSize: '12px', color: '#886', marginBottom: '8px' }}>ID: {entry.id}</div>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #ddd', textAlign: 'left' }}>
                    <th>Account ID</th>
                    <th>Debit</th>
                    <th>Credit</th>
                  </tr>
                </thead>
                <tbody>
                  {entry.postings.map((posting, idx) => (
                    <tr key={idx}>
                      <td>{posting.accountId}</td>
                      <td>{posting.direction === 'DEBIT' ? formatCurrency(posting.amount) : '-'}</td>
                      <td>{posting.direction === 'CREDIT' ? formatCurrency(posting.amount) : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
