/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Type Definitions
export type Direction = 'DEBIT' | 'CREDIT';

export interface Posting {
  readonly accountId: string;
  readonly amount: number; // Stored in minor units (e.g., cents)
  readonly direction: Direction;
}

export interface JournalEntryData {
  readonly id: string;
  readonly timestamp: Date;
  readonly description: string;
  readonly postings: readonly Posting[];
}

export class UnbalancedEntryError extends Error {
  constructor(debitSum: number, creditSum: number) {
    super(`Journal entry is unbalanced. Total Debits (${debitSum}) do not equal Total Credits (${creditSum}).`);
    this.name = 'UnbalancedEntryError';
  }
}

// TODO: Implement the validation and factory function below
export function createJournalEntry(data: JournalEntryData): JournalEntryData {
  // Implementation goes here
  throw new Error('Not implemented');
}
