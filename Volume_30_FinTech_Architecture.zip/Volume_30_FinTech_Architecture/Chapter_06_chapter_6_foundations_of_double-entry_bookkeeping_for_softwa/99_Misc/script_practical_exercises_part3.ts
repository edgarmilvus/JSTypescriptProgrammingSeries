/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Type Definitions
import { JournalEntry } from './exercise-1';

export class ImmutableLedgerEngine {
  private readonly entries: JournalEntry[] = [];

  constructor(initialEntries: JournalEntry[] = []) {
    // Perform defensive copying or initial validation
    this.entries = [...initialEntries];
  }

  public commitEntry(entry: JournalEntry): void {
    // TODO: Validate zero-sum invariant and append immutably
    throw new Error('Not implemented');
  }

  public getAccountBalanceAtTime(accountId: string, targetTimestamp: Date): number {
    // TODO: Reconstruct account balance from the immutable stream up to targetTimestamp
    throw new Error('Not implemented');
  }

  public getAuditTrail(accountId: string): readonly JournalEntry[] {
    // TODO: Return all entries affecting a specific account
    throw new Error('Not implemented');
  }
}
