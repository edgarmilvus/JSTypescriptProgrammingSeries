/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Decimal } from 'decimal.js';

/**
 * Represents the fundamental type of a financial account,
 * which dictates its normal balance behavior in accounting equations.
 */
enum AccountType {
  ASSET = 'ASSET',
  LIABILITY = 'LIABILITY',
  EQUITY = 'EQUITY',
  REVENUE = 'REVENUE',
  EXPENSE = 'EXPENSE',
}

/**
 * Represents the direction of a financial entry.
 * Debits and Credits affect account types differently based on accounting rules.
 */
enum EntryDirection {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT',
}

/**
 * Represents an individual account within the chart of accounts.
 */
interface Account {
  id: string;
  name: string;
  type: AccountType;
  currency: string;
}

/**
 * Represents a single line item (entry) within a transaction.
 * Each entry must be strictly bound to an account and possess a precise monetary value.
 */
interface LedgerEntry {
  id: string;
  accountId: string;
  direction: EntryDirection;
  amount: Decimal;
}

/**
 * Represents the immutable transaction header wrapping two or more ledger entries.
 */
interface LedgerTransaction {
  id: string;
  timestamp: Date;
  description: string;
  entries: LedgerEntry[];
}

/**
 * Validates that a ledger transaction satisfies the fundamental double-entry invariant:
 * The sum of all DEBIT entries must exactly equal the sum of all CREDIT entries.
 * 
 * @param transaction The ledger transaction to evaluate.
 * @throws Error if the transaction violates the zero-sum balance invariant.
 */
function validateTransactionBalance(transaction: LedgerTransaction): void {
  let totalDebits = new Decimal(0);
  let totalCredits = new Decimal(0);

  for (const entry of transaction.entries) {
    if (entry.direction === EntryDirection.DEBIT) {
      totalDebits = totalDebits.plus(entry.amount);
    } else {
      totalCredits = totalCredits.plus(entry.amount);
    }
  }

  // Ensure absolute mathematical equality using Decimal.js precision
  if (!totalDebits.equals(totalCredits)) {
    throw new Error(
      `Transaction invariant violation: Total debits (${totalDebits.toString()}) do not equal total credits (${totalCredits.toString()}) for transaction ID: ${transaction.id}`
    );
  }
}

// ==========================================
// Execution Context: SaaS Subscription Payment
// ==========================================

// 1. Define our Chart of Accounts for the SaaS platform
const cashAccount: Account = {
  id: 'acc_cash_01',
  name: 'Operating Cash (Stripe)',
  type: AccountType.ASSET,
  currency: 'USD',
};

const subscriptionRevenueAccount: Account = {
  id: 'acc_rev_01',
  name: 'Subscription Revenue',
  type: AccountType.REVENUE,
  currency: 'USD',
};

// 2. Construct a balanced transaction for a $49.99 SaaS tier subscription fee
const subscriptionTransaction: LedgerTransaction = {
  id: 'tx_sub_998877',
  timestamp: new Date(),
  description: 'Monthly Pro Plan Subscription - Customer #8839',
  entries: [
    {
      id: 'entry_01',
      accountId: cashAccount.id,
      direction: EntryDirection.DEBIT,
      amount: new Decimal('49.99'),
    },
    {
      id: 'entry_02',
      accountId: subscriptionRevenueAccount.id,
      direction: EntryDirection.CREDIT,
      amount: new Decimal('49.99'),
    },
  ],
};

// 3. Execute validation rule
try {
  validateTransactionBalance(subscriptionTransaction);
  console.log(`[SUCCESS]: Transaction ${subscriptionTransaction.id} validated and committed successfully.`);
} catch (error: unknown) {
  if (error instanceof Error) {
    console.error(`[FAILURE]: Ledger rejected transaction: ${error.message}`);
  } else {
    console.error('[FAILURE]: An unknown error occurred during validation.');
  }
}
