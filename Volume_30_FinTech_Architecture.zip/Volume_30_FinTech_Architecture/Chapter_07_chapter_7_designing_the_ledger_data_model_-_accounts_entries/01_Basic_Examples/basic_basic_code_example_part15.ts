/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part15.ts
// Description: Basic Code Example
// ==========================================

import { PoolClient } from 'pg';

/**
 * Persists a validated transaction and its associated entries to PostgreSQL
 * inside an atomic ACID database transaction with row-level locking.
 * 
 * @param client Active PostgreSQL connection client from a connection pool.
 * @param transaction The validated LedgerTransaction object.
 */
async function commitTransactionToDatabase(client: PoolClient, transaction: LedgerTransaction): void {
  try {
    // 1. Begin atomic database transaction block
    await client.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE');

    // 2. Insert transaction header
    const txInsertQuery = `
      INSERT INTO transactions (id, description, timestamp)
      VALUES ($1, $2, $3)
    `;
    await client.query(txInsertQuery, [transaction.id, transaction.description, transaction.timestamp]);

    // 3. Iterate and insert individual entries with account locking
    for (const entry of transaction.entries) {
      // Lock the target account row to prevent concurrent balance race conditions
      const lockAccountQuery = `
        SELECT id FROM accounts WHERE id = $1 FOR UPDATE
      `;
      const accountResult = await client.query(lockAccountQuery, [entry.accountId]);
      
      if (accountResult.rowCount === 0) {
        throw new Error(`Account not found for ID: ${entry.accountId}`);
      }

      // Insert ledger entry line
      const entryInsertQuery = `
        INSERT INTO entries (id, transaction_id, account_id, direction, amount)
        VALUES ($1, $2, $3, $4, $5)
      `;
      await client.query(entryInsertQuery, [
        entry.id,
        transaction.id,
        entry.accountId,
        entry.direction,
        entry.amount.toString(), // Convert Decimal to string for safe database serialization
      ]);
    }

    // 4. Commit all operations atomically
    await client.query('COMMIT');
    console.log(`[DB SUCCESS]: Transaction ${transaction.id} committed securely.`);
  } catch (error) {
    // 5. Rollback on any failure to maintain database atomicity
    await client.query('ROLLBACK');
    console.error(`[DB ERROR]: Transaction rolled back due to error:`, error);
    throw error;
  }
}
