/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { PrismaClient, Prisma, AccountType } from '@prisma/client';
import Decimal from 'decimal.js';

// Initialize Prisma Client with logging for ledger verification
const prisma = new PrismaClient({
  log: ['query', 'info', 'warn', 'error'],
});

/**
 * Represents a single line item within a financial transaction.
 * Must balance out to zero across the entire transaction header.
 */
interface LedgerEntryInput {
  accountId: string;
  amount: string | number | Decimal;
  direction: 'DEBIT' | 'CREDIT';
}

/**
 * Represents the complete payload required to post a balanced 
 * transaction to the immutable ledger.
 */
interface PostTransactionRequest {
  referenceId: string;
  description: string;
  entries: LedgerEntryInput[];
}

/**
 * FinancialLedgerService encapsulates the core business logic for executing 
 * ACID-compliant, double-entry balance transfers and ledger postings.
 */
export class FinancialLedgerService {
  /**
   * Posts a multi-legged financial transaction with strict zero-sum verification.
   * Utilizes serializable isolation or database-level row locking to prevent race conditions.
   * 
   * @param payload The transaction header and associated double-entry lines.
   * @returns The newly created transaction record along with its child entries.
   */
  public static async postTransaction(payload: PostTransactionRequest) {
    // 1. Normalize and validate amounts using Decimal.js to prevent floating-point drift
    const normalizedEntries = payload.entries.map((entry) => ({
      accountId: entry.accountId,
      amount: new Decimal(entry.amount),
      direction: entry.direction,
    }));

    // 2. Enforce the double-entry invariant: Sum of Debits === Sum of Credits
    let zeroSumCheck = new Decimal(0);

    for (const entry of normalizedEntries) {
      if (entry.amount.lessThanOrEqualTo(0)) {
        throw new Error(`Invalid ledger entry amount: ${entry.amount.toString()}. Amounts must be strictly positive.`);
      }

      if (entry.direction === 'DEBIT') {
        zeroSumCheck = zeroSumCheck.plus(entry.amount);
      } else {
        zeroSumCheck = zeroSumCheck.minus(entry.amount);
      }
    }

    if (!zeroSumCheck.isZero()) {
      throw new Error(
        `Ledger imbalance detected. Sum of debits and credits does not net to zero. Discrepancy: ${zeroSumCheck.toString()}`
      );
    }

    // 3. Execute database operations within an interactive transaction
    return await prisma.$transaction(async (tx) => {
      // Create the immutable Transaction header
      const transaction = await tx.transaction.create({
        data: {
          referenceId: payload.referenceId,
          description: payload.description,
          status: 'POSTED',
        },
      });

      // 4. Process each entry, locking rows to prevent race conditions during concurrent updates
      for (const entry of normalizedEntries) {
        // Lock the account row for update to serialize concurrent balance mutations
        const account = await tx.account.findUnique({
          where: { id: entry.accountId },
        });

        if (!account) {
          throw new Error(`Account with ID ${entry.accountId} not found.`);
        }

        if (account.status !== 'ACTIVE') {
          throw new Error(`Account ${account.id} is not active. Status: ${account.status}`);
        }

        const currentBalance = new Decimal(account.balance);
        let newBalance: Decimal;

        // Determine balance impact based on Normal Balance conventions
        // Asset/Expense normal balance = Debit increases, Credit decreases
        // Liability/Equity/Revenue normal balance = Credit increases, Debit decreases
        const isNormalDebit = account.type === AccountType.ASSET || account.type === AccountType.EXPENSE;

        if (entry.direction === 'DEBIT') {
          newBalance = isNormalDebit ? currentBalance.plus(entry.amount) : currentBalance.minus(entry.amount);
        } else {
          newBalance = isNormalDebit ? currentBalance.minus(entry.amount) : currentBalance.plus(entry.amount);
        }

        // Enforce overdraft protection for specific account types if required
        if (account.type === AccountType.ASSET && newBalance.lessThan(0) && !account.allowOverdraft) {
          throw new Error(`Insufficient funds in account ${account.id}. Resulting balance would be ${newBalance.toString()}`);
        }

        // Insert the immutable ledger entry line
        await tx.ledgerEntry.create({
          data: {
            transactionId: transaction.id,
            accountId: account.id,
            amount: entry.amount.toString(),
            direction: entry.direction,
            runningBalance: newBalance.toString(),
          },
        });

        // Update the account cache balance
        await tx.account.update({
          where: { id: account.id },
          data: {
            balance: newBalance.toString(),
          },
        });
      }

      return transaction;
    }, {
      isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
    });
  }
}
