/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Decimal from 'decimal.js';

// 1. Branded Types for Domain Safety
export type TransactionId = string & { readonly __brand: unique symbol };
export type AccountId = string & { readonly __brand: unique symbol };
export type EntryId = string & { readonly __brand: unique symbol };

export type CurrencyCode = 'USD' | 'EUR' | 'GBP';
export type EntryDirection = 'DEBIT' | 'CREDIT';

export interface RawLedgerEntry {
  readonly id: EntryId;
  readonly accountId: AccountId;
  readonly direction: EntryDirection;
  readonly amount: string; // Precision decimal string representation
  readonly currency: CurrencyCode;
}

export interface RawTransactionPayload {
  readonly id: TransactionId;
  readonly timestamp: Date;
  readonly description: string;
  readonly entries: readonly RawLedgerEntry[];
  readonly exchangeRates?: Readonly<Record<string, string>>; // Interactive Challenge requirement
}

export type CommittedTransaction = RawTransactionPayload & {
  readonly __committed: unique symbol;
};

export type LedgerError =
  | { readonly type: 'INSUFFICIENT_ENTRIES'; readonly message: string }
  | { readonly type: 'ZERO_SUM_IMBALANCE'; readonly message: string }
  | { readonly type: 'MULTI_CURRENCY_IMBALANCE'; readonly message: string }
  | { readonly type: 'INVALID_ENTRY'; readonly message: string };

export type Result<T, E> = 
  | { readonly success: true; readonly data: T }
  | { readonly success: false; readonly error: E };

export function validateAndProcessTransaction(
  payload: RawTransactionPayload
): Result<CommittedTransaction, LedgerError> {
  // Rule 1: Minimum entry count validation
  if (!payload.entries || payload.entries.length < 2) {
    return {
      success: false,
      error: {
        type: 'INSUFFICIENT_ENTRIES',
        message: 'A valid ledger transaction must contain at least two entries.',
      },
    };
  }

  const firstCurrency = payload.entries[0].currency;
  const isMultiCurrency = payload.entries.some(entry => entry.currency !== firstCurrency);

  if (isMultiCurrency && !payload.exchangeRates) {
    return {
      success: false,
      error: {
        type: 'MULTI_CURRENCY_IMBALANCE',
        message: 'Multi-currency transaction detected without explicit exchange rates mapping.',
      },
    };
  }

  // Group balances by currency for validation
  const currencyTotals = new Map<CurrencyCode, { debits: Decimal; credits: Decimal }>();

  for (const entry of payload.entries) {
    if (!entry.accountId || entry.accountId.trim() === '') {
      return {
        success: false,
        error: { type: 'INVALID_ENTRY', message: `Entry ${entry.id} references an invalid account.` },
      };
    }
    if (!entry.currency) {
      return {
        success: false,
        error: { type: 'INVALID_ENTRY', message: `Entry ${entry.id} contains an empty currency code.` },
      };
    }

    const amt = new Decimal(entry.amount);
    if (amt.isNegative() || amt.isZero()) {
      return {
        success: false,
        error: { type: 'INVALID_ENTRY', message: `Entry ${entry.id} must have a strictly positive amount.` },
      };
    }

    let totals = currencyTotals.get(entry.currency);
    if (!totals) {
      totals = { debits: new Decimal(0), credits: new Decimal(0) };
      currencyTotals.set(entry.currency, totals);
    }

    if (entry.direction === 'DEBIT') {
      totals.debits = totals.debits.plus(amt);
    } else {
      totals.credits = totals.credits.plus(amt);
    }
  }

  // If single currency, debits must equal credits directly
  if (!isMultiCurrency) {
    const totals = currencyTotals.get(firstCurrency)!;
    if (!totals.debits.equals(totals.credits)) {
      return {
        success: false,
        error: {
          type: 'ZERO_SUM_IMBALANCE',
          message: `Zero-sum invariant violated. Total Debits (${totals.debits.toString()}) do not equal Total Credits (${totals.credits.toString()}).`,
        },
      };
    }
  } else {
    // Multi-currency normalization check using provided rates relative to base currency (firstCurrency)
    const baseTotals = currencyTotals.get(firstCurrency) || { debits: new Decimal(0), credits: new Decimal(0) };
    let normalizedDebits = baseTotals.debits;
    let normalizedCredits = baseTotals.credits;

    for (const [curr, totals] of currencyTotals.entries()) {
      if (curr === firstCurrency) continue;
      const rateStr = payload.exchangeRates?.[curr];
      if (!rateStr) {
        return {
          success: false,
          error: {
            type: 'MULTI_CURRENCY_IMBALANCE',
            message: `Missing conversion rate for currency ${curr}.`,
          },
        };
      }
      const rate = new Decimal(rateStr);
      normalizedDebits = normalizedDebits.plus(totals.debits.mul(rate));
      normalizedCredits = normalizedCredits.plus(totals.credits.mul(rate));
    }

    if (!normalizedDebits.equals(normalizedCredits)) {
      return {
        success: false,
        error: {
          type: 'ZERO_SUM_IMBALANCE',
          message: `Normalized multi-currency zero-sum invariant violated. Debits: ${normalizedDebits.toString()}, Credits: ${normalizedCredits.toString()}`,
        },
      };
    }
  }

  // Enforce structural immutability via Object.freeze
  const frozenEntries = payload.entries.map(entry => Object.freeze({ ...entry }));
  const immutablePayload = Object.freeze({
    ...payload,
    entries: Object.freeze(frozenEntries),
  }) as CommittedTransaction;

  return { success: true, data: immutablePayload };
}
