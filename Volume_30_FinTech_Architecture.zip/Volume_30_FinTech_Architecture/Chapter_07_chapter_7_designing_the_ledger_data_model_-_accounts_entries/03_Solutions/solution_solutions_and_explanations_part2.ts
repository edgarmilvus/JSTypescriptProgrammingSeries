/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { PoolClient } from 'pg';

export interface CommittedTransaction {
  id: string;
  timestamp: Date;
  description: string;
  entries: Array<{
    id: string;
    accountId: string;
    direction: 'DEBIT' | 'CREDIT';
    amount: string;
    currency: string;
  }>;
}

export class LedgerRepository {
  async commitTransaction(client: PoolClient, tx: CommittedTransaction): Promise<void> {
    try {
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;');

      // 1. Extract and sort unique account IDs to prevent deadlocks during row locking
      const uniqueAccountIds = Array.from(new Set(tx.entries.map(e => e.accountId))).sort();

      // 2. Acquire row-level exclusive locks (SELECT FOR UPDATE) on affected accounts
      if (uniqueAccountIds.length > 0) {
        await client.query(
          `SELECT id FROM accounts WHERE id = ANY($1::text[]) FOR UPDATE;`,
          [uniqueAccountIds]
        );
      }

      // 3. Insert transaction header record
      const insertTxQuery = `
        INSERT INTO transactions (id, timestamp, description)
        VALUES ($1, $2, $3);
      `;
      await client.query(insertTxQuery, [tx.id, tx.timestamp, tx.description]);

      // 4. Insert ledger entry lines associated with the transaction header
      const insertEntryQuery = `
        INSERT INTO entries (id, transaction_id, account_id, direction, amount, currency)
        VALUES ($1, $2, $3, $4, $5, $6);
      `;

      for (const entry of tx.entries) {
        await client.query(insertEntryQuery, [
          entry.id,
          tx.id,
          entry.accountId,
          entry.direction,
          entry.amount,
          entry.currency,
        ]);
      }

      await client.query('COMMIT;');
    } catch (error) {
      await client.query('ROLLBACK;');
      throw error;
    }
  }

  // Interactive Challenge: Retry wrapper with exponential backoff & jitter for SQLSTATE 40001
  async commitTransactionWithRetry(
    client: PoolClient,
    tx: CommittedTransaction,
    maxRetries: number = 3
  ): Promise<void> {
    let attempt = 0;
    while (true) {
      try {
        attempt++;
        await this.commitTransaction(client, tx);
        return;
      } catch (error: any) {
        const isSerializationError = error?.code === '40001';
        if (!isSerializationError || attempt >= maxRetries) {
          throw error;
        }
        // Calculate exponential backoff with random jitter
        const delayMs = Math.pow(2, attempt) * 100 + Math.random() * 50;
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }
}
