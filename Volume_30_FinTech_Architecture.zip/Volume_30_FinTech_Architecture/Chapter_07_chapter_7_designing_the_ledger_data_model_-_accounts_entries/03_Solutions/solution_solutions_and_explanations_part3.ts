/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import Decimal from 'decimal.js';

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface CommittedLedgerEntry {
  readonly id: string;
  readonly transactionId: string;
  readonly accountId: string;
  readonly direction: 'DEBIT' | 'CREDIT';
  readonly amount: Decimal;
  readonly postedAt: Date;
}

export function getNormalBalanceSign(accountType: AccountType, direction: 'DEBIT' | 'CREDIT'): Decimal {
  // Assets and Expenses normal balance is DEBIT (+1 for Debit, -1 for Credit)
  // Liabilities, Equity, and Revenues normal balance is CREDIT (-1 for Debit, +1 for Credit)
  switch (accountType) {
    case 'ASSET':
    case 'EXPENSE':
      return direction === 'DEBIT' ? new Decimal(1) : new Decimal(-1);
    case 'LIABILITY':
    case 'EQUITY':
    case 'REVENUE':
      return direction === 'CREDIT' ? new Decimal(1) : new Decimal(-1);
    default:
      throw new Error(`Unknown account classification: ${accountType}`);
  }
}

export function calculateAccountBalance(
  accountId: string,
  accountType: AccountType,
  asOfTimestamp: Date,
  entries: readonly CommittedLedgerEntry[]
): Decimal {
  let runningBalance = new Decimal(0);

  for (const entry of entries) {
    if (entry.accountId === accountId && entry.postedAt <= asOfTimestamp) {
      const sign = getNormalBalanceSign(accountType, entry.direction);
      // Contribution = amount * sign
      const contribution = entry.amount.mul(sign);
      runningBalance = runningBalance.plus(contribution);
    }
  }

  return runningBalance;
}

// Interactive Challenge: Trial Balance Report Generator
export interface AccountMetadata {
  readonly id: string;
  readonly type: AccountType;
}

export function generateTrialBalanceReport(
  accounts: readonly AccountMetadata[],
  asOfTimestamp: Date,
  entries: readonly CommittedLedgerEntry[]
): { readonly totalDebits: Decimal; readonly totalCredits: Decimal; readonly isBalanced: boolean } {
  let totalDebitNormal = new Decimal(0);
  let totalCreditNormal = new Decimal(0);

  for (const account of accounts) {
    const balance = calculateAccountBalance(account.id, account.type, asOfTimestamp, entries);
    if (account.type === 'ASSET' || account.type === 'EXPENSE') {
      totalDebitNormal = totalDebitNormal.plus(balance);
    } else {
      totalCreditNormal = totalCreditNormal.plus(balance);
    }
  }

  return {
    totalDebits: totalDebitNormal,
    totalCredits: totalCreditNormal,
    isBalanced: totalDebitNormal.equals(totalCreditNormal),
  };
}
