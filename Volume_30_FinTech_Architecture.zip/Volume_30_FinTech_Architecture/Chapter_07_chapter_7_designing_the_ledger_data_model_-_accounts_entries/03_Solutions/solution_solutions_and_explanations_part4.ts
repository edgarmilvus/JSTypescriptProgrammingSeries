/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export type TransactionState = 'PENDING' | 'PROCESSING' | 'COMMITTED' | 'FAILED' | 'REVERSED';

export type InvalidTransitionError = {
  readonly type: 'INVALID_TRANSITION';
  readonly message: string;
};

export type OptimisticLockConflictError = {
  readonly type: 'OPTIMISTIC_LOCK_CONFLICT';
  readonly message: string;
};

export type StateMachineResult<T> = 
  | { readonly success: true; readonly data: T }
  | { readonly success: false; readonly error: InvalidTransitionError | OptimisticLockConflictError };

const VALID_TRANSITIONS: Record<TransactionState, readonly TransactionState[]> = {
  PENDING: ['PROCESSING', 'FAILED'],
  PROCESSING: ['COMMITTED', 'FAILED'],
  COMMITTED: ['REVERSED'],
  FAILED: [],
  REVERSED: [],
};

export class TransactionStateMachine {
  private currentState: TransactionState;
  private version: number;

  constructor(initialState: TransactionState = 'PENDING', initialVersion: number = 1) {
    this.currentState = initialState;
    this.version = initialVersion;
  }

  public getState(): TransactionState {
    return this.currentState;
  }

  public getVersion(): number {
    return this.version;
  }

  public transition(
    targetState: TransactionState,
    databaseVersion: number
  ): StateMachineResult<TransactionState> {
    // Interactive Challenge: Optimistic Concurrency Control (OCC) check
    if (this.version !== databaseVersion) {
      return {
        success: false,
        error: {
          type: 'OPTIMISTIC_LOCK_CONFLICT',
          message: `Optimistic concurrency conflict. Expected version ${this.version}, found database version ${databaseVersion}.`,
        },
      };
    }

    const permittedNextStates = VALID_TRANSITIONS[this.currentState];
    if (!permittedNextStates.includes(targetState)) {
      return {
        success: false,
        error: {
          type: 'INVALID_TRANSITION',
          message: `Illegal state transition from ${this.currentState} to ${targetState}.`,
        },
      };
    }

    this.currentState = targetState;
    this.version += 1; // Increment version on successful mutation

    return { success: true, data: this.currentState };
  }
}
