/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface LedgerInspectorProps {
  readonly transactionId: string;
  readonly initialData?: {
    readonly id: string;
    readonly timestamp: string;
    readonly description: string;
    readonly entries: Array<{
      readonly id: string;
      readonly accountId: string;
      readonly direction: 'DEBIT' | 'CREDIT';
      readonly amount: string;
      readonly currency: string;
    }>;
  };
}

export async function LedgerInspector({ transactionId, initialData }: LedgerInspectorProps) {
  // Server-side database fetch simulation
  const tx = initialData || {
    id: transactionId,
    timestamp: new Date().toISOString(),
    description: 'Sample Ledger Transaction',
    entries: [
      { id: 'e1', accountId: 'acc-100', direction: 'DEBIT', amount: '150.00', currency: 'USD' },
      { id: 'e2', accountId: 'acc-200', direction: 'CREDIT', amount: '150.00', currency: 'USD' },
    ],
  };

  // Zero-sum calculation verification on server
  let debitSum = 0;
  let creditSum = 0;
  tx.entries.forEach(e => {
    const val = parseFloat(e.amount);
    if (e.direction === 'DEBIT') debitSum += val;
    else creditSum += val;
  });

  const isBalanced = Math.abs(debitSum - creditSum) < 0.0001;

  return (
    <div className="ledger-inspector-container p-6 bg-white rounded-lg shadow-md font-sans">
      <div className="flex justify-between items-center border-b pb-4 mb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Transaction: {tx.id}</h2>
          <p className="text-sm text-gray-500">{new Date(tx.timestamp).toLocaleString()}</p>
        </div>
        <div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${isBalanced ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {isBalanced ? 'ZERO-SUM BALANCED' : 'IMBALANCE DETECTED'}
          </span>
        </div>
      </div>

      <p className="text-gray-700 mb-4"><strong>Description:</strong> {tx.description}</p>

      {/* Client Interactive Viewer Component wrapper */}
      <ClientInspectorViewer entries={tx.entries} transactionId={tx.id} />
    </div>
  );
}

// Client Sub-Component for filtering and reversal simulation
function ClientInspectorViewer({ entries, transactionId }: { entries: LedgerInspectorProps['initialData']['entries']; transactionId: string }) {
  const [filter, setFilter] = useState<'ALL' | 'DEBIT' | 'CREDIT'>('ALL');
  const [reversalStatus, setReversalStatus] = useState<string | null>(null);

  const filteredEntries = entries.filter(e => {
    if (filter === 'DEBIT') return e.direction === 'DEBIT';
    if (filter === 'CREDIT') return e.direction === 'CREDIT';
    return true;
  });

  const handleSimulateReversal = async () => {
    setReversalStatus('Submitting reversal payload...');
    // Construct compensating transaction payload
    const compensatingEntries = entries.map(e => ({
      id: `rev-${e.id}`,
      accountId: e.accountId,
      direction: (e.direction === 'DEBIT' ? 'CREDIT' : 'DEBIT') as 'DEBIT' | 'CREDIT',
      amount: e.amount,
      currency: e.currency,
    }));

    // Simulate backend submission API call
    setTimeout(() => {
      setReversalStatus(`Compensating transaction successfully submitted for ${transactionId}!`);
    }, 1000);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <div className="space-x-2">
          <button onClick={() => setFilter('ALL')} className={`px-3 py-1 text-sm rounded ${filter === 'ALL' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>All</button>
          <button onClick={() => setFilter('DEBIT')} className={`px-3 py-1 text-sm rounded ${filter === 'DEBIT' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>Debits Only</button>
          <button onClick={() => setFilter('CREDIT')} className={`px-3 py-1 text-sm rounded ${filter === 'CREDIT' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>Credits Only</button>
        </div>
        <button 
          onClick={handleSimulateReversal}
          className="bg-amber-600 text-white px-4 py-2 text-sm rounded shadow hover:bg-amber-700 transition"
        >
          Simulate Reversal
        </button>
      </div>

      {reversalStatus && <p className="text-sm text-blue-600 mb-4 font-medium">{reversalStatus}</p>}

      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-gray-100 text-xs uppercase text-gray-600">
            <th className="p-2 border">Entry ID</th>
            <th className="p-2 border">Account ID</th>
            <th className="p-2 border">Direction</th>
            <th className="p-2 border text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          {filteredEntries.map(entry => (
            <tr key={entry.id} className="hover:bg-gray-50 text-sm">
              <td className="p-2 border font-mono text-xs">{entry.id}</td>
              <td className="p-2 border font-mono text-xs">{entry.accountId}</td>
              <td className={`p-2 border font-bold ${entry.direction === 'DEBIT' ? 'text-blue-600' : 'text-emerald-600'}`}>
                {entry.direction}
              </td>
              <td className="p-2 border text-right font-mono">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: entry.currency }).format(parseFloat(entry.amount))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
