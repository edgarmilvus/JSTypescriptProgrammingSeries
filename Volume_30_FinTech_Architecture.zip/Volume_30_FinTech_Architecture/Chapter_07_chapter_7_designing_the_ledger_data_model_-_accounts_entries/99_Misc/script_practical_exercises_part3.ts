/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import Decimal from 'decimal.js';

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface CommittedLedgerEntry {
  readonly id: string;
  readonly transactionId: string;
  readonly accountId: string;
  readonly direction: 'DEBIT' | 'CREDIT';
  readonly amount: Decimal;
  readonly postedAt: Date;
}

export function getNormalBalanceSign(accountType: AccountType, direction: 'DEBIT' | 'CREDIT'): Decimal {
  // TODO: Return 1 or -1 based on whether the direction increases or decreases the account type balance
  throw new Error('Not implemented');
}

export function calculateAccountBalance(
  accountId: string,
  accountType: AccountType,
  asOfTimestamp: Date,
  entries: readonly CommittedLedgerEntry[]
): Decimal {
  // TODO: Compute historical running balance with precision arithmetic
  throw new Error('Not implemented');
}
