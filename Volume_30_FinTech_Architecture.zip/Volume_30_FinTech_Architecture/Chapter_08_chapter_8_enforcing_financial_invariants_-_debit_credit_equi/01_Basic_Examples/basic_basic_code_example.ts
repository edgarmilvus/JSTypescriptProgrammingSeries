/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Book 30: FinTech Architecture in TypeScript
 * Chapter 8: Enforcing Financial Invariants - Debit & Credit Equilibrium
 * Section: Basic Code Example
 */

// Define the precise type for currency codes to prevent arbitrary string passing.
type SupportedCurrency = 'USD' | 'EUR' | 'GBP';

/**
 * Represents a single leg (either a debit or a credit) of a financial transaction.
 * All monetary amounts are stored as integers representing the minor unit (e.g., cents)
 * to completely eliminate IEEE 754 floating-point rounding errors.
 */
interface LedgerLine {
  /** Unique account identifier this line impacts */
  readonly accountId: string;
  /** The monetary amount in minor units (must be a positive integer) */
  readonly amount: bigint;
  /** Currency code associated with this line */
  readonly currency: SupportedCurrency;
}

/**
 * Represents a complete double-entry transaction posting containing balanced legs.
 */
interface TransactionPosting {
  readonly transactionId: string;
  readonly description: string;
  readonly lines: readonly LedgerLine[];
}

/**
 * Custom error thrown when a transaction violates the zero-sum invariant
 * or contains invalid monetary parameters.
 */
class UnbalancedLedgerError extends Error {
  constructor(message: string) {
    super(`[UnbalancedLedgerError]: ${message}`);
    this.name = 'UnbalancedLedgerError';
  }
}

/**
 * Validates that a transaction posting satisfies the foundational double-entry invariant:
 * Total Debits must exactly equal Total Credits across the same currency,
 * and there must be at least one debit and one credit line.
 * 
 * @param posting The transaction posting containing ledger lines to evaluate.
 * @throws {UnbalancedLedgerError} If the zero-sum invariant is violated.
 */
function validateTransactionEquilibrium(posting: TransactionPosting): void {
  // Step 1: Ensure the transaction has lines to process
  if (posting.lines.length === 0) {
    throw new UnbalancedLedgerError(`Transaction ${posting.transactionId} contains no ledger lines.`);
  }

  // Map to accumulate balances per currency. In a strict multi-currency ledger,
  // cross-currency balancing requires explicit exchange rate conversion lines.
  const balanceMap = new Map<SupportedCurrency, bigint>();

  // Step 2: Iterate through each line and accumulate sums
  // By convention, we can treat debits as positive changes to asset/expense accounts
  // and credits as positive changes to liability/equity/revenue accounts.
  // For a generic zero-sum validation, we assume lines are pre-signed or explicitly tagged.
  // In this simplified model, let's assume half are debits and half are credits, 
  // or that amounts are explicitly passed with directional intent via a sign bit.
  // To keep it robust, let's enforce an explicit direction property on the LedgerLine.
}

// Let's refine the LedgerLine to explicitly carry a direction.
type LedgerDirection = 'DEBIT' | 'CREDIT';

interface StrictLedgerLine {
  readonly accountId: string;
  /** Absolute value of the amount in minor units */
  readonly amount: bigint;
  readonly currency: SupportedCurrency;
  readonly direction: LedgerDirection;
}

interface StrictTransactionPosting {
  readonly transactionId: string;
  readonly description: string;
  readonly lines: readonly StrictLedgerLine[];
}

/**
 * Validates a strict transaction posting where each line explicitly declares its direction.
 * Enforces that Total Debits === Total Credits per currency.
 */
function validateStrictEquilibrium(posting: StrictTransactionPosting): void {
  if (posting.lines.length < 2) {
    throw new UnbalancedLedgerError(
      `Transaction ${posting.transactionId} must have at least 2 lines to form a double-entry pair.`
    );
  }

  // Track debits and credits per currency
  const totalsByCurrency = new Map<SupportedCurrency, { debits: bigint; credits: bigint }>();

  for (const line of posting.lines) {
    // Invariant check: Amount must be strictly positive
    if (line.amount <= 0n) {
      throw new UnbalancedLedgerError(
        -`Invalid amount ${line.amount} on account ${line.accountId}. Amounts must be positive integers.`
      );
    }

    // Initialize currency record if it doesn't exist
    if (!totalsByCurrency.has(line.currency)) {
      totalsByCurrency.set(line.currency, { debits: 0n, credits: 0n });
    }

    const currentTotals = totalsByCurrency.get(line.currency)!;

    if (line.direction === 'DEBIT') {
      totalsByCurrency.set(line.currency, {
        debits: currentTotals.debits + line.amount,
        credits: currentTotals.credits,
      });
    } else {
      totalsByCurrency.set(line.currency, {
        debits: currentTotals.debits,
        credits: currentTotals.credits + line.amount,
      });
    }
  }

  // Verify equilibrium for every currency involved
  for (const [currency, totals] of totalsByCurrency.entries()) {
    if (totals.debits !== totals.credits) {
      throw new UnbalancedLedgerError(
        `Currency mismatch in transaction ${posting.transactionId} (${currency}). ` +
        `Total Debits (${totals.debits}) do not equal Total Credits (${totals.credits}).`
      );
    }
  }
}

// ==========================================
// EXAMPLE USAGE IN A SaaS BILLING CONTEXT
// ==========================================

try {
  // A customer pays $50.00 USD for a monthly SaaS subscription.
  // Debit: Cash / Clearing Account ($50.00 -> 5000 cents)
  // Credit: Subscription Revenue Account ($50.00 -> 5000 cents)
  
  const customerPaymentPosting: StrictTransactionPosting = {
    transactionId: 'txn_2023_10_001',
    description: 'Monthly SaaS Tier 1 Subscription Payment',
    lines: [
      {
        accountId: 'acc_cash_stripe_clearing',
        amount: 5000n,
        currency: 'USD',
        direction: 'DEBIT',
      },
      {
        accountId: 'acc_revenue_subscriptions',
        amount: 5000n,
        currency: 'USD',
        direction: 'CREDIT',
      },
    ],
  };

  validateStrictEquilibrium(customerPaymentPosting);
  console.log(`[SUCCESS]: Transaction ${customerPaymentPosting.transactionId} verified and balanced.`);

} catch (error) {
  if (error instanceof UnbalancedLedgerError) {
    console.error(`[LEDGER REJECTED]: ${error.message}`);
  } else {
    console.error(`[UNEXPECTED ERROR]:`, error);
  }
}
