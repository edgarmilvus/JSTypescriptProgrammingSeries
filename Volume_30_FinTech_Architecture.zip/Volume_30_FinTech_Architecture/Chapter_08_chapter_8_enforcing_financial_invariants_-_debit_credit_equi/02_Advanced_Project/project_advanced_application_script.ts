/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

/**
 * Defines the structural types of financial accounts supported by the ledger.
 */
export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

/**
 * Represents a discrete financial account within the multi-tenant ledger.
 */
export interface Account {
  readonly id: string;
  readonly tenantId: string;
  readonly name: string;
  readonly type: AccountType;
  readonly currency: string; // ISO 4217 currency code (e.g., 'USD', 'EUR')
  readonly isActive: boolean;
}

/**
 * Represents a single leg of a financial transaction.
 * Amount is stored as an integer representing the smallest currency unit (e.g., cents).
 */
export interface LedgerPosting {
  readonly accountId: string;
  readonly amount: bigint; // Must be strictly positive
  readonly direction: 'DEBIT' | 'CREDIT';
}

/**
 * Represents an immutable, multi-legged financial transaction proposal.
 */
export interface TransactionDraft {
  readonly tenantId: string;
  readonly description: string;
  readonly postings: readonly LedgerPosting[];
  readonly metadata?: Record<string, string | number>;
}

/**
 * Represents a committed ledger entry with cryptographic traceability.
 */
export interface CommittedTransaction extends TransactionDraft {
  readonly id: string;
  readonly timestamp: number;
  readonly checksum: string;
}

/**
 * Custom error class thrown when a double-entry invariant check fails.
 */
class LedgerInvariantViolationError extends Error {
  constructor(message: string) {
    super(`[Ledger Invariant Violation]: ${message}`);
    this.name = 'LedgerInvariantViolationError';
  }
}

/**
 * High-Reliability Double-Entry Ledger Engine
 * Ensures absolute zero-sum equilibrium across complex multi-currency postings.
 */
export class LedgerEngine {
  private accounts: Map<string, Account> = new Map();
  private journal: CommittedTransaction[] = [];

  /**
     * Registers a new account within the engine's state.
     */
  public registerAccount(account: Account): void {
    if (this.accounts.has(account.id)) {
      throw new LedgerInvariantViolationError(`Account ID collision detected: ${account.id}`);
    }
    this.accounts.set(account.id, account);
  }

  /**
     * Validates and commits a transaction draft to the immutable journal.
     * Enforces the zero-sum invariant and currency homogeneity across all legs.
     */
  public commitTransaction(draft: TransactionDraft): CommittedTransaction {
    this.validateTenantIntegrity(draft);
    this.validateNonEmptyPostings(draft);
    this.validatePostingsStructure(draft);
    this.validateZeroSumEquilibrium(draft);

    const committed: CommittedTransaction = {
      ...draft,
      id: randomUUID(),
      timestamp: Date.now(),
      checksum: this.generateChecksum(draft),
    };

    this.journal.push(committed);
    return committed;
  }

  /**
     * Verifies that all accounts referenced in the draft belong to the transaction tenant.
     */
  private validateTenantIntegrity(draft: TransactionDraft): void {
    for (const posting of draft.postings) {
      const account = this.accounts.get(posting.accountId);
      if (!account) {
        throw new LedgerInvariantViolationError(`Referenced account does not exist: ${posting.accountId}`);
      }
      if (!account.isActive) {
        throw new LedgerInvariantViolationError(`Attempted posting to inactive account: ${account.id}`);
      }
      if (account.tenantId !== draft.tenantId) {
        throw new LedgerInvariantViolationError(
          `Cross-tenant violation: Account ${account.id} belongs to tenant ${account.tenantId}, but transaction targets ${draft.tenantId}`
        );
      }
    }
  }

  /**
     * Ensures the transaction contains at least one debit and one credit leg.
     */
  private validateNonEmptyPostings(draft: TransactionDraft): void {
    if (draft.postings.length < 2) {
      throw new LedgerInvariantViolationError('A balanced transaction must contain at least two postings.');
    }
  }

  /**
     * Ensures all posting amounts are positive integers and currencies match across accounts.
     */
  private validatePostingsStructure(draft: TransactionDraft): void {
    let baselineCurrency: string | null = null;

    for (const posting of draft.postings) {
      if (posting.amount <= 0n) {
        throw new LedgerInvariantViolationError('Posting amounts must be strictly positive integers.');
      }

      const account = this.accounts.get(posting.accountId)!;
      if (baselineCurrency === null) {
        baselineCurrency = account.currency;
      } else if (account.currency !== baselineCurrency) {
        throw new LedgerInvariantViolationError(
          `Multi-currency mismatch within single transaction: Found ${account.currency}, expected ${baselineCurrency}`
        );
      }
    }
  }

  /**
     * Core Invariant Check: Sum of Debits must precisely equal the Sum of Credits.
     */
  private validateZeroSumEquilibrium(draft: TransactionDraft): void {
    let totalDebits = 0n;
    let totalCredits = 0n;

    for (const posting of draft.postings) {
      if (posting.direction === 'DEBIT') {
        totalDebits += posting.amount;
      } else if (posting.direction === 'CREDIT') {
        totalCredits += posting.amount;
      } else {
        throw new LedgerInvariantViolationError(`Invalid posting direction: ${String((posting as any).direction)}`);
      }
    }

    if (totalDebits !== totalCredits) {
      throw new LedgerInvariantViolationError(
        `Zero-sum equilibrium violated. Total Debits (${totalDebits}) do not equal Total Credits (${totalCredits}).`
      );
    }
  }

  /**
     * Generates a deterministic audit checksum for immutable compliance logs.
     */
  private generateChecksum(draft: TransactionDraft): string {
    const rawData = JSON.stringify(draft, (_, v) => (typeof v === 'bigint' ? v.toString() + 'n' : v));
    let hash = 0;
    for (let i = 0; i < rawData.length; i++) {
      const char = rawData.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0; // Convert to 32bit integer
    }
    return `0x${Math.abs(hash).toString(16)}`;
  }

  /**
     * Computes the real-time balance of an account based on account type normal balances.
     */
  public getAccountBalance(accountId: string): bigint {
    const account = this.accounts.get(accountId);
    if (!account) {
      throw new LedgerInvariantViolationError(`Account not found: ${accountId}`);
    }

    let balance = 0n;

    for (const tx of this.journal) {
      for (const posting of tx.postings) {
        if (posting.accountId ===accountId) {
          if (account.type === 'ASSET' || account.type === 'EXPENSE') {
            if (posting.direction === 'DEBIT') balance += posting.amount;
            if (posting.direction === 'CREDIT') balance -= posting.amount;
          } else {
            // LIABILITY, EQUITY, REVENUE
            if (posting.direction === 'CREDIT') balance += posting.amount;
            if (posting.direction === 'DEBIT') balance -= posting.amount;
          }
        }
      }
    }

    return balance;
  }
}
