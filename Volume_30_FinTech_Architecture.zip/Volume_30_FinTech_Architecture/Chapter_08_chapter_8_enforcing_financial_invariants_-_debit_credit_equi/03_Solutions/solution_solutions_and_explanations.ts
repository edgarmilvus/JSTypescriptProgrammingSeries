/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the direction of the posting line
export type Direction = 'DEBIT' | 'CREDIT';

// Define the posting line structure using bigint for precision
export interface PostingLine {
  readonly accountId: string;
  readonly direction: Direction;
  readonly amount: bigint;
}

// Define the transaction structure
export interface LedgerTransaction {
  readonly id: string;
  readonly postings: readonly PostingLine[];
}

// Custom error classes for precise failure reporting
export class ZeroSumViolationError extends Error {
  constructor(public readonly debitSum: bigint, public readonly creditSum: bigint) {
    super(`Zero-sum invariant violated. Total debits (${debitSum}) do not equal total credits (${creditSum}).`);
    this.name = 'ZeroSumViolationError';
  }
}

export class EmptyTransactionError extends Error {
  constructor() {
    super('Transaction must contain at least one debit and one credit posting.');
    this.name = 'EmptyTransactionError';
  }
}

export class InvalidAmountError extends Error {
  constructor(public readonly amount: bigint) {
    super(`Posting amounts must be strictly positive integers. Received: ${amount}`);
    this.name = 'InvalidAmountError';
  }
}

/**
 * Validates that a ledger transaction satisfies the zero-sum invariant
 * and contains valid posting lines.
 */
export function validateTransactionBalance(transaction: LedgerTransaction): void {
  if (!transaction.postings || transaction.postings.length === 0) {
    throw new EmptyTransactionError();
  }

  let debitSum = 0n;
  let creditSum = 0n;
  let hasDebit = false;
  let hasCredit = false;

  for (const posting of transaction.postings) {
    if (posting.amount <= 0n) {
      throw new InvalidAmountError(posting.amount);
    }

    if (posting.direction === 'DEBIT') {
      hasDebit = true;
      debitSum += posting.amount;
    } else if (posting.direction === 'CREDIT') {
      hasCredit = true;
      creditSum += posting.amount;
    }
  }

  if (!hasDebit || !hasCredit) {
    throw new EmptyTransactionError();
  }

  if (debitSum !== creditSum) {
    throw new ZeroSumViolationError(debitSum, creditSum);
  }
}
