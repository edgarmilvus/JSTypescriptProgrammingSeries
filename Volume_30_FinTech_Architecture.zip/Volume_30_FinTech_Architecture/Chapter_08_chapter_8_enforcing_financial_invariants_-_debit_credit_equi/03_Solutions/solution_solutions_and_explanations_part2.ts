/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'JPY';

export interface MultiCurrencyPosting {
  readonly accountId: string;
  readonly direction: 'DEBIT' | 'CREDIT';
  readonly currency: CurrencyCode;
  readonly amount: bigint; // Minor units (e.g., cents)
}

export interface ExchangeRateMap {
  // Rates scaled by 10^8 relative to base currency (USD)
  readonly [currency: string]: bigint;
}

export interface NormalizationConfig {
  readonly baseCurrency: CurrencyCode;
  readonly discrepancyAccountId: string;
  readonly exchangeRates: ExchangeRateMap;
}

export interface NormalizedPosting {
  readonly accountId: string;
  readonly direction: 'DEBIT' | 'CREDIT';
  readonly normalizedAmount: bigint;
}

const SCALE_FACTOR = 10n ** 8n;

export function normalizeAndBalancePostings(
  postings: readonly MultiCurrencyPosting[],
  config: NormalizationConfig
): readonly NormalizedPosting[] {
  const normalized: NormalizedPosting[] = [];
  let totalDebitNormalized = 0n;
  let totalCreditNormalized = 0n;

  for (const posting of postings) {
    let normalizedAmount: bigint;

    if (posting.currency === config.baseCurrency) {
      normalizedAmount = posting.amount;
    } else {
      const rate = config.exchangeRates[posting.currency];
      if (rate === undefined) {
        throw new Error(`Missing exchange rate for currency: ${posting.currency}`);
      }
      // Convert to base currency: (amount * rate) / SCALE_FACTOR
      // Integer division truncation occurs here, generating fractional remnants
      normalizedAmount = (posting.amount * rate) / SCALE_FACTOR;
    }

    normalized.push({
      accountId: posting.accountId,
      direction: posting.direction,
      normalizedAmount,
    });

    if (posting.direction === 'DEBIT') {
      totalDebitNormalized += normalizedAmount;
    } else {
      totalCreditNormalized += normalizedAmount;
    }
  }

  // Calculate rounding discrepancy remnant
  const difference = totalDebitNormalized - totalCreditNormalized;

  if (difference !== 0n) {
    // If debits > credits, we need an extra CREDIT to balance (or vice versa)
    const adjustmentDirection: 'DEBIT' | 'CREDIT' = difference > 0n ? 'CREDIT' : 'DEBIT';
    const adjustmentAmount = difference > 0n ? difference : -difference;

    normalized.push({
      accountId: config.discrepancyAccountId,
      direction: adjustmentDirection,
      normalizedAmount: adjustmentAmount,
    });
  }

  return normalized;
}

