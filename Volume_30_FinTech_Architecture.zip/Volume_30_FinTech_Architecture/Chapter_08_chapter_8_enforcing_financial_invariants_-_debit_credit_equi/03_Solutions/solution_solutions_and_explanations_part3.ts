/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Branded types for compile-time safety
declare const __brand: unique symbol;
export type Branded<T, TBrand> = T & { readonly [__brand]: TBrand };

export type RawAmount = bigint;
export type ValidatedAmount = Branded<bigint, 'ValidatedAmount'>;
export type AccountId = Branded<string, 'AccountId'>;

export interface DebitPosting {
  readonly type: 'DEBIT';
  readonly accountId: AccountId;
  readonly amount: ValidatedAmount;
}

export interface CreditPosting {
  readonly type: 'CREDIT';
  readonly accountId: AccountId;
  readonly amount: ValidatedAmount;
}

export type Posting = DebitPosting | CreditPosting;

/**
 * A type-safe transaction builder that prevents compilation if the 
 * zero-sum invariant is not statically or dynamically proven.
 */
export class TransactionBuilder<IsBalanced extends boolean = false> {
  private postings: Posting[] = [];
  private debitSum: bigint = 0n;
  private creditSum: bigint = 0n;

  private constructor(postings: Posting[] = [], debitSum: bigint = 0n, creditSum: bigint = 0n) {
    this.postings = [...postings];
    this.debitSum = debitSum;
    this.creditSum = creditSum;
  }

  public static create(): TransactionBuilder<false> {
    return new TransactionBuilder<false>();
  }

  public addDebit(accountId: AccountId, amount: ValidatedAmount): TransactionBuilder<boolean> {
    const newPostings = [...this.postings, { type: 'DEBIT' as const, accountId, amount }];
    const newDebitSum = this.debitSum + amount;
    const isNowBalanced = newDebitSum === this.creditSum && newPostings.length > 0;
    
    // Cast to general TransactionBuilder<boolean> to allow state shifts at compile time
    return new TransactionBuilder(newPostings, newDebitSum, this.creditSum) as unknown as TransactionBuilder<boolean>;
  }

  public addCredit(accountId: AccountId, amount: ValidatedAmount): TransactionBuilder<boolean> {
    const newPostings = [...this.postings, { type: 'CREDIT' as const, accountId, amount }];
    const newCreditSum = this.creditSum + amount;
    const isNowBalanced = this.debitSum === newCreditSum && newPostings.length > 0;

    return new TransactionBuilder(newPostings, this.debitSum, newCreditSum) as unknown as TransactionBuilder<boolean>;
  }

  // Conditional method: Only available when IsBalanced is strictly true
  public commit(this: TransactionBuilder<true>): { readonly id: string; readonly postings: readonly Posting[] } {
    return {
      id: crypto.randomUUID(),
      postings: this.postings,
    };
  }
}
