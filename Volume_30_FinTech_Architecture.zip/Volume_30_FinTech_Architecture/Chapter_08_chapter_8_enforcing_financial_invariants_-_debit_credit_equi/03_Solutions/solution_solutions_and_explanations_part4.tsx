/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

export type Direction = 'DEBIT' | 'CREDIT';

export interface UIPostingLine {
  readonly id: string;
  readonly accountName: string;
  readonly direction: Direction;
  readonly amountCents: bigint;
}

export interface LedgerInspectorProps {
  readonly transactionId: string;
  readonly initialPostings: readonly UIPostingLine[];
  readonly baseCurrencySymbol?: string;
  readonly onTransactionCommitted?: (postings: readonly UIPostingLine[]) => void;
}

/**
 * Helper function to format integer minor units (cents) into a human-readable decimal string.
 * Example: 1250n -> "$12.50"
 */
export function formatCurrency(amountCents: bigint, symbol: string = '$'): string {
  const isNegative = amountCents < 0n;
  const absoluteValue = isNegative ? -amountCents : amountCents;
  const dollars = absoluteValue / 100n;
  const cents = absoluteValue % 100n;
  
  // Pad cents with leading zero if needed
  const centsString = cents.toString().padStart(2, '0');
  const signPrefix = isNegative ? '-' : '';

  return `${signPrefix}${symbol}${dollars.toString()}.${centsString}`;
}

export const LedgerInspector: React.FC<LedgerInspectorProps> = ({
  transactionId,
  initialPostings,
  baseCurrencySymbol = '$',
  onTransactionCommitted,
}) => {
  const [postings, setPostings] = useState<readonly UIPostingLine[]>(initialPostings);

  // Calculate total debits, total credits, and balance difference using BigInt
  const { totalDebits, totalCredits, discrepancy, isBalanced } = useMemo(() => {
    let debits = 0n;
    let credits = 0n;

    for (const posting of postings) {
      if (posting.direction === 'DEBIT') {
        debits += posting.amountCents;
      } else {
        credits += posting.amountCents;
      }
    }

    const diff = debits - credits;
    return {
      totalDebits: debits,
      totalCredits: credits,
      discrepancy: diff < 0n ? -diff : diff,
      isBalanced: debits === credits && postings.length > 0,
    };
  }, [postings]);

  const handleAddAdjustment = () => {
    if (totalDebits === totalCredits) return;

    // Determine direction of balancing adjustment posting
    const adjustmentDirection: Direction = totalDebits > totalCredits ? 'CREDIT' : 'DEBIT';
    const adjustmentPosting: UIPostingLine = {
      id: `adjustment-${Date.now()}`,
      accountName: 'Exchange/Rounding Discrepancy Account',
      direction: adjustmentDirection,
      amountCents: discrepancy,
    };

    setPostings((prev) => [...prev, adjustmentPosting]);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-white rounded-xl shadow-md space-y-4">
      <div className="flex justify-between items-center border-b pb-4">
        <h2 className="text-xl font-bold text-gray-800">Ledger Transaction Inspector</h2>
        <span className="text-sm font-mono text-gray-500">ID: {transactionId}</span>
      </div>

      {/* Status Banner */}
      <div className={`p-4 rounded-lg flex items-center justify-between ${isBalanced ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
        <div>
          <span className="font-semibold">{isBalanced ? 'Invariant Satisfied' : 'Zero-Sum Violation Detected'}</span>
          {!isBalanced && (
            <p className="text-sm mt-1">Discrepancy: {formatCurrency(discrepancy, baseCurrencySymbol)}</p>
          )}
        </div>
        {!isBalanced && (
          <button
            onClick={handleAddAdjustment}
            className="px-3 py-1.5 bg-red-600 text-white text-sm font-medium rounded hover:bg-red-700 transition-colors cursor-pointer"
          >
            Auto-Balance
          </button>
        )}
      </div>

      {/* Postings Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Direction</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 font-mono text-sm">
            {postings.map((posting) => (
              <tr key={posting.id}>
                <td className="px-6 py-4 whitespace-nowrap text-gray-900">{posting.accountName}</td>
                <td className={`px-6 py-4 whitespace-nowrap font-bold ${posting.direction === 'DEBIT' ? 'text-blue-600' : 'text-purple-600'}`}>
                  {posting.direction}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-gray-900">
                  {formatCurrency(posting.amountCents, baseCurrencySymbol)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Footer */}
      <div className="flex justify-end pt-4 border-t">
        <button
          disabled={!isBalanced}
          onClick={() => onTransactionCommitted?.(postings)}
          className={`px-4 py-2 rounded font-medium text-white transition-colors ${isBalanced ? 'bg-blue-600 hover:bg-blue-700 cursor-pointer' : 'bg-gray-300 cursor-not-allowed'}`}
        >
          Commit to Ledger
        </button>
      </div>
    </div>
  );
};
