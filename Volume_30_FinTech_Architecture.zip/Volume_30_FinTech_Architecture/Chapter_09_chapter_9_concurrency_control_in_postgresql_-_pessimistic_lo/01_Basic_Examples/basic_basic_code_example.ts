/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Pool, PoolClient } from 'pg';

/**
 * Database connection pool configured for a high-reliability fintech SaaS environment.
 * In production, connection parameters should be sourced from secure environment variables.
 */
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/ledger_db',
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

/**
 * Represents the structure of an account row in the database.
 */
interface Account {
  id: string;
  balance: number; // Stored as a numeric/decimal type in PostgreSQL
  version: number;
}

/**
 * Initializes a mock database table for demonstration purposes.
 */
async function setupDatabase(): Promise<void> {
  const client: PoolClient = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS accounts (
        id VARCHAR(50) PRIMARY KEY,
        balance NUMERIC(18, 4) NOT NULL,
        version INT NOT NULL DEFAULT 1
      );
    `);
    
    // Seed a test account with an initial balance of 100.0000
    await client.query(`
      INSERT INTO accounts (id, balance, version)
      VALUES ('acc_saas_user_123', 100.0000, 1)
      ON CONFLICT (id) DO NOTHING;
    `);
    console.log('[Setup] Database initialized and test account seeded.');
  } finally {
    client.release();
  }
}

/**
 * Safely debits an account using pessimistic locking (SELECT ... FOR UPDATE).
 * 
 * @ابات The database client or pool used to execute the transaction.
 * @param accountId The unique identifier of the target account.
 * @param amount The numerical amount to debit.
 */
async function debitAccountPessimistic(accountId: string, amount: number): Promise<void> {
  // Step 1: Acquire a dedicated client from the pool for transactional safety
  const client: PoolClient = await pool.connect();

  try {
    // Step 2: Begin the explicit transaction block
    await client.query('BEGIN');
    console.log(`[Tx ${process.pid}] Transaction started. Attempting to lock account: ${accountId}`);

    // Step 3: Execute SELECT ... FOR UPDATE.
    // This locks the specific row until the transaction terminates (COMMIT or ROLLBACK).
    // Other concurrent transactions attempting this query on the same row will block here.
    const selectQuery = `
      SELECT id, balance, version 
      FROM accounts 
      WHERE id = $1 
      FOR UPDATE;
    `;
    const selectResult = await client.query<Account>(selectQuery, [accountId]);

    if (selectResult.rows.length === 0) {
      throw new Error(`Account with ID ${accountId} not found.`);
    }

    const account = selectResult.rows[0];
    const currentBalance = parseFloat(String(account.balance));
    console.log(`[Tx ${process.pid}] Successfully acquired lock. Current Balance: ${currentBalance}`);

    // Step 4: Validate funds availability (Precision Math handled via standard JS numbers or BigNumber libraries)
    if (currentBalance < amount) {
      throw new Error(`Insufficient funds. Available: ${currentBalance}, Requested: ${amount}`);
    }

    const newBalance = currentBalance - amount;

    // Step 5: Perform the update within the same locked transaction
    const updateQuery = `
      UPDATE accounts 
      SET balance = $1, version = version + 1 
      WHERE id = $2;
    `;
    await client.query(updateQuery, [newBalance, accountId]);
    console.log(`[Tx ${process.pid}] Balance updated to: ${newBalance}. Committing transaction...`);

    // Step 6: Commit the transaction, releasing the row lock
    await client.query('COMMIT');
    console.log(`[Tx ${process.pid}] Transaction committed successfully.\n`);

  } catch (error) {
    // Step 7: Rollback the transaction on any error to maintain data integrity
    await client.query('ROLLBACK');
    console.error(`[Tx ${process.pid}] Transaction failed and rolled back. Error: ${(error as Error).message}\n`);
    throw error;
  } finally {
    // Step 8: Always release the client back to the pool
    client.release();
  }
}

/**
 * Main execution harness to simulate concurrent payment requests hitting the system.
 */
async function runSimulation() {
  await setupDatabase();

  console.log('--- STARTING CONCURRENT PAYMENT SIMULATION ---');
  console.log('Simulating two parallel API requests attempting to debit $60 each from an account with $100.');

  // Fire two concurrent calls to debit the exact same account
  const worker1 = debitAccountPessimistic('acc_saas_user_123', 60.00);
  const worker2 = debitAccountPessimistic('acc_saas_user_123', 60.00);

  // Await both operations. Worker 1 should succeed; Worker 2 should block, then fail due to insufficient funds.
  try {
    await Promise.allSettled([worker1, worker2]);
  } catch (err) {
    console.error('Simulation encountered an unhandled rejection:', err);
  } finally {
    // Inspect final account balance
    const finalCheck = await pool.query('SELECT balance FROM accounts WHERE id = $1', ['acc_saas_user_123']);
    console.log(`--- SIMULATION COMPLETE ---`);
    console.log(`Final Database Balance: ${finalCheck.rows[0].balance} (Expected: 40.0000)`);
    await pool.end();
  }
}

// Execute simulation if run directly
if (require.main === module) {
  runSimulation();
}
