/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pool, PoolClient } from 'pg';

/**
 * Configuration interface for the PostgreSQL connection pool.
 */
interface DatabaseConfig {
  connectionString: string;
  maxConnections?: number;
}

/**
 * Payload required to execute a secure balance transfer transaction.
 */
interface TransferRequest {
  sourceAccountId: string;
  destinationAccountId: string;
  amountCents: number; // Stored as integer cents to avoid floating-point errors
  idempotencyKey: string;
}

/**
 * Result structure returned upon transaction settlement.
 */
interface TransferResult {
  success: boolean;
  transactionId: string;
  sourceNewBalance: number;
  destinationNewBalance: number;
}

/**
 * PostgreSQL Ledger Account Management Service.
 * Implements strict pessimistic locking via SELECT FOR UPDATE to prevent race conditions.
 */
export class SecureLedgerService {
  private pool: Pool;

  constructor(config: DatabaseConfig) {
    this.pool = new Pool({
      connectionString: config.connectionString,
      max: config.maxConnections ?? 20,
    });
  }

  /**
   * Executes an atomic funds transfer between two accounts with strict ordering
   * to prevent deadlocks, utilizing PostgreSQL row-level locks.
   */
  public async executeTransfer(request: TransferRequest): Promise<TransferResult> {
    const client: PoolClient = await this.pool.connect();

    try {
      // 1. Begin an explicit transaction with serializable-safe behavior
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED');

      // 2. Idempotency Check: Verify if this transfer has already been processed
      const existingTxQuery = `
        SELECT id, status FROM ledger_transactions 
        WHERE idempotency_key = $1 FOR UPDATE;
      `;
      const existingTxResult = await client.query(existingTxQuery, [request.idempotencyKey]);

      if (existingTxResult.rows.length > 0) {
        const tx = existingTxResult.rows[0];
        if (tx.status === 'COMPLETED') {
          await client.query('COMMIT');
          throw new Error(`Idempotent violation: Transaction ${request.idempotencyKey} already completed.`);
        }
      }

      // 3. Deadlock Prevention: Sort account IDs lexicographically to acquire locks in a deterministic order
      const [firstId, secondId] = [request.sourceAccountId, request.destinationAccountId].sort();

      // 4. Lock the first account row exclusively
      const lockFirstQuery = `
        SELECT id, balance_cents, currency, status 
        FROM accounts 
        WHERE id = $1 
        FOR UPDATE;
      `;
      const firstAccountResult = await client.query(lockFirstQuery, [firstId]);

      if (firstAccountResult.rows.length === 0) {
        throw new Error(`Account with ID ${firstId} not found.`);
      }

      // 5. Lock the second account row exclusively
      const lockSecondQuery = `
        SELECT id, balance_cents, currency, status 
        FROM accounts 
        WHERE id = $1 
        FOR UPDATE;
      `;
      const secondAccountResult = await client.query(lockSecondQuery, [secondId]);

      if (secondAccountResult.rows.length === 0) {
        throw new Error(`Account with ID ${secondId} not found.`);
      }

      // Map rows back to source and destination semantics
      const sourceAccount = firstId === request.sourceAccountId 
        ? firstAccountResult.rows[0] 
        : secondAccountResult.rows[0];
        
      const destinationAccount = firstId === request.destinationAccountId 
        ? firstAccountResult.rows[0] 
        : secondAccountResult.rows[0];

      // 6. Validate account statuses and sufficient funds
      if (sourceAccount.status !== 'ACTIVE' || destinationAccount.status !== 'ACTIVE') {
        throw new Error('One or both accounts are inactive or suspended.');
      }

      if (sourceAccount.currency !== destinationAccount.currency) {
        throw new Error('Cross-currency transfers require an explicit exchange rate service.');
      }

      if (sourceAccount.balance_cents < request.amountCents) {
        throw new Error(`Insufficient funds. Available: ${sourceAccount.balance_cents}, Requested: ${request.amountCents}`);
      }

      const newSourceBalance = sourceAccount.balance_cents - request.amountCents;
      const newDestinationBalance = destinationAccount.balance_cents + request.amountCents;

      // 7. Perform balance updates
      await client.query(
        'UPDATE accounts SET balance_cents = $1, updated_at = NOW() WHERE id = $2',
        [newSourceBalance, request.sourceAccountId]
      );

      await client.query(
        'UPDATE accounts SET balance_cents = $1, updated_at = NOW() WHERE id = $2',
        [newDestinationBalance, request.destinationAccountId]
      );

      // 8. Record the immutable ledger entry
      const insertLedgerQuery = `
        INSERT INTO ledger_transactions (id, source_id, destination_id, amount_cents, idempotency_key, status, created_at)
        VALUES (gen_random_uuid(), $1, $2, $3, $4, 'COMPLETED', NOW())
        RETURNING id;
      `;
      const ledgerInsertResult = await client.query(insertLedgerQuery, [
        request.sourceAccountId,
        request.destinationAccountId,
        request.amountCents,
        request.idempotencyKey,
      ]);

      // 9. Commit the transaction, releasing all row locks
      await client.query('COMMIT');

      return {
        success: true,
        transactionId: ledgerInsertResult.rows[0].id,
        sourceNewBalance: newSourceBalance,
        destinationNewBalance: newDestinationBalance,
      };

    } catch (error) {
      // Rollback transaction on any validation failure or database error
      await client.query('ROLLBACK');
      throw error;
    } finally {
      // Ensure the client is returned to the pool
      client.release();
    }
  }

  /**
   * Gracefully shuts down the connection pool.
   */
  public async close(): Promise<void> {
    await this.pool.end();
  }
}
