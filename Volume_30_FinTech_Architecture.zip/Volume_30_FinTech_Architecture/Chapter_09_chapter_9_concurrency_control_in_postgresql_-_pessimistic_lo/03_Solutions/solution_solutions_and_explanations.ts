/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Pool, PoolClient } from 'pg';

export interface TransferRequest {
  sourceAccountId: string;
  destinationAccountId: string;
  amount: bigint; // Stored as minor units (e.g., cents)
  currency: string;
  idempotencyKey: string;
}

export interface TransferResult {
  success: boolean;
  transferId?: string;
  executedAt?: Date;
  error?: string;
  errorCode?: string;
}

export class LedgerTransferService {
  constructor(private pool: Pool) {}

  public async executeTransfer(request: TransferRequest): Promise<TransferResult> {
    if (request.sourceAccountId === request.destinationAccountId) {
      return { success: false, error: 'Source and destination accounts must be distinct.' };
    }
    if (request.amount <= 0n) {
      return { success: false, error: 'Transfer amount must be greater than zero.' };
    }

    // Determine deterministic lock order (lexicographical sort) to prevent deadlocks
    const [firstId, secondId] = [request.sourceAccountId, request.destinationAccountId].sort();

    const client: PoolClient = await this.pool.connect();

    try {
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED');

      // 1. Acquire explicit row locks in deterministic order using SELECT ... FOR UPDATE
      const accounts: Record<string, { balance: bigint; currency: string }> = {};

      // We fetch both accounts regardless of direction, locking them sequentially
      const lockQuery = 'SELECT id, balance, currency FROM accounts WHERE id = $1 FOR UPDATE';
      
      // Determine which query runs first based on sorted IDs
      const firstRes = await client.query(lockQuery, [firstId]);
      if (firstRes.rows.length === 0) {
        throw new Error(`Account not found: ${firstId}`);
      }
      accounts[firstRes.rows[0].id] = {
        balance: BigInt(firstRes.rows[0].balance),
        currency: firstRes.rows[0].currency,
      };

      const secondRes = await client.query(lockQuery, [secondId]);
      if (secondRes.rows.length === 0) {
        throw new Error(`Account not found: ${secondId}`);
      }
      accounts[secondRes.rows[0].id] = {
        balance: BigInt(secondRes.rows[0].balance),
        currency: secondRes.rows[0].currency,
      };

      const sourceAccount = accounts[request.sourceAccountId];
      const destAccount = accounts[request.destinationAccountId];

      // 2. Validate currencies match
      if (sourceAccount.currency !== request.currency || destAccount.currency !== request.currency) {
        throw new Error('Currency mismatch between accounts and transfer request.');
      }

      // 3. Invariant validation: check sufficient liquidity
      if (sourceAccount.balance < request.amount) {
        throw new Error('Insufficient available liquidity in source account.');
      }

      // 4. Mutate account states
      await client.query(
        'UPDATE accounts SET balance = balance - $1, version = version + 1, updated_at = NOW() WHERE id = $2',
        [request.amount.toString(), request.sourceAccountId]
      );

      await client.query(
        'UPDATE accounts SET balance = balance + $1, version = version + 1, updated_at = NOW() WHERE id = $2',
        [request.amount.toString(), request.destinationAccountId]
      );

      // 5. Insert double-entry journal ledger lines
      const journalRes = await client.query(
        `INSERT INTO journal_entries (idempotency_key, currency, status, created_at)
         VALUES ($1, $2, 'POSTED', NOW())
         RETURNING id, created_at`,
        [request.idempotencyKey, request.currency]
      );
      const journalId = journalRes.rows[0].id;
      const createdAt = journalRes.rows[0].created_at;

      // Insert transaction legs (double-entry balancing lines)
      const legQuery = `
        INSERT INTO transaction_legs (journal_id, account_id, amount, direction)
        VALUES ($1, $2, $3, $4)
      `;
      // Source leg (Debit / negative impact on normal credit balance system representation, or explicit direction)
      await client.query(legQuery, [journalId, request.sourceAccountId, request.amount.toString(), 'DEBIT']);
      // Destination leg (Credit)
      await client.query(legQuery, [journalId, request.destinationAccountId, request.amount.toString(), 'CREDIT']);

      await client.query('COMMIT');

      return {
        success: true,
        transferId: journalId,
        executedAt: createdAt,
      };
    } catch (error: any) {
      await client.query('ROLLBACK');
      return {
        success: false,
        error: error.message,
        errorCode: error.code, // Captures PostgreSQL error codes like '40001' or '40P01'
      };
    } finally {
      client.release();
    }
  }
}
