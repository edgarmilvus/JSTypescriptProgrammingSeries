/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { PoolClient } from 'pg';

export interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  onRetry?: (error: Error, attempt: number, delayMs: number) => void;
}

export class ConcurrencyErrorHandler {
  /**
   * Checks if a database error is a transient concurrency failure eligible for retry.
   * 40001: serialization_failure
   * 40P01: deadlock_detected
   */
  public static isTransientConcurrencyError(error: any): boolean {
    const transientCodes = ['40001', '40P01'];
    return error && transientCodes.includes(error.code);
  }

  public static async withPessimisticRetry<T>(
    client: PoolClient,
    operation: (client: PoolClient) => Promise<T>,
    options: RetryOptions = { maxRetries: 3, baseDelayMs: 50, maxDelayMs: 2000 }
  ): Promise<T> {
    let attempt = 0;

    while (true) {
      try {
        // Execute operation within transaction scope
        return await operation(client);
      } catch (error: any) {
        attempt++;
        
        const isTransient = this.isTransientConcurrencyError(error);
        const canRetry = attempt <= options.maxRetries;

        if (!isTransient || !canRetry) {
          // Ensure rollback if unhandled or max retries exceeded
          try {
            await client.query('ROLLBACK');
          } catch (rollbackError) {
            // Suppress secondary rollback errors
          }
          throw error;
        }

        // Calculate Exponential Backoff with Full Decorrelated Jitter
        const exponentialDelay = options.baseDelayMs * Math.pow(2, attempt - 1);
        const cappedDelay = Math.min(exponentialDelay, options.maxDelayMs);
        // Add random jitter between 0% and 50% of the calculated delay to prevent thundering herd
        const jitteredDelay = cappedDelay * (0.5 + Math.random() * 0.5);

        if (options.onRetry) {
          options.onRetry(error, attempt, jitteredDelay);
        }

        await new Promise((resolve) => setTimeout(resolve, jitteredDelay));
      }
    }
  }
}
