/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Pool } from 'pg';

export enum PaymentState {
  PENDING = 'PENDING',
  LOCKED = 'LOCKED',
  SETTLED = 'SETTLED',
  FAILED = 'FAILED',
}

export interface PaymentPipelineContext {
  paymentId: string;
  accountId: string;
  amount: bigint;
  externalGatewayUrl: string;
}

export class AsynchronousPaymentPipeline {
  constructor(private pool: Pool) {}

  public async processPayment(context: PaymentPipelineContext): Promise<boolean> {
    const client = await this.pool.connect();

    try {
      // Step 1: Acquire short-lived pessimistic lock to validate balance and transition to LOCKED
      await client.query('BEGIN');

      const accountRes = await client.query(
        'SELECT balance FROM accounts WHERE id = $1 FOR UPDATE',
        [context.accountId]
      );

      if (accountRes.rows.length === 0) {
        throw new Error(`Account not found: ${context.accountId}`);
      }

      const currentBalance = BigInt(accountRes.rows[0].balance);
      if (currentBalance < context.amount) {
        throw new Error('Insufficient funds for payment processing.');
      }

      // Debit account immediately and set ledger payment intent state to LOCKED
      await client.query(
        `UPDATE accounts 
         SET balance = balance - $1, version = version + 1, updated_at = NOW() 
         WHERE id = $2`,
        [context.amount.toString(), context.accountId]
      );

      await client.query(
        `INSERT INTO payment_intents (id, account_id, amount, state, created_at)
         VALUES ($1, $2, $3, $4, NOW())
         ON CONFLICT (id) DO NOTHING`,
        [context.paymentId, context.accountId, context.amount.toString(), PaymentState.LOCKED]
      );

      // Step 2: Commit transaction immediately to release database connection lock
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      client.release();
      return false;
    } finally {
      client.release();
    }

    // Step 3: Perform non-blocking external network I/O OUTSIDE of the database transaction
    let gatewaySuccess = false;
    try {
      const response = await fetch(context.externalGatewayUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentId: context.paymentId,
          amount: context.amount.toString(),
          accountId: context.accountId,
        }),
      });
      gatewaySuccess = response.ok;
    } catch (networkError) {
      gatewaySuccess = false;
    }

    // Step 4: Re-acquire a short connection to finalize or execute compensating transaction
    const finalClient = await this.pool.connect();
    try {
      await finalClient.query('BEGIN');

      if (gatewaySuccess) {
        await finalClient.query(
          'UPDATE payment_intents SET state = $1, updated_at = NOW() WHERE id = $2',
          [PaymentState.SETTLED, context.paymentId]
        );
      } else {
        // Compensating Transaction: Credit funds back and transition state to FAILED
        await finalClient.query(
          `UPDATE accounts 
           SET balance = balance + $1, version = version + 1, updated_at = NOW() 
           WHERE id = $2`,
          [context.amount.toString(), context.accountId]
        );
        await finalClient.query(
          'UPDATE payment_intents SET state = $1, updated_at = NOW() WHERE id = $2',
          [PaymentState.FAILED, context.paymentId]
        );
      }

      await finalClient.query('COMMIT');
      return gatewaySuccess;
    } catch (finalError) {
      await finalClient.query('ROLLBACK');
      return false;
    } finally {
      finalClient.release();
    }
  }
}
