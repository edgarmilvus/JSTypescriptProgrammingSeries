/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

export interface ConcurrencyMetricPayload {
  activeLocks: number;
  deadlocksPerMinute: number;
  serializationFailures: number;
  averageLockWaitTimeMs: number;
  connectionPoolUsagePercent: number;
}

export interface LedgerDashboardProps {
  websocketEndpoint: string;
  onTriggerSimulation: (scenario: 'contention' | 'deadlock') => Promise<void>;
}

export const LedgerConcurrencyDashboard: React.FC<LedgerDashboardProps> = ({
  websocketEndpoint,
  onTriggerSimulation,
}) => {
  const [metrics, setMetrics] = useState<ConcurrencyMetricPayload>({
    activeLocks: 12,
    deadlocksPerMinute: 0.2,
    serializationFailures: 1,
    averageLockWaitTimeMs: 45,
    connectionPoolUsagePercent: 62,
  });
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [alertThresholds, setAlertThresholds] = useState({
    maxWaitTimeMs: 100,
    maxDeadlocksPerMin: 2.0,
  });

  // Establish WebSocket connection for real-time telemetry
  useEffect(() => {
    const ws = new WebSocket(websocketEndpoint);

    ws.onmessage = (event) => {
      try {
        const data: ConcurrencyMetricPayload = JSON.parse(event.data);
        setMetrics(data);
        setLogs((prev) => [
          `[${new Date().toLocaleTimeString()}] Metric telemetry updated: Locks=${data.activeLocks}, Wait=${data.averageLockWaitTimeMs}ms`,
          ...prev.slice(0, 49),
        ]);
      } catch (err) {
        console.error('Failed to parse WebSocket telemetry payload', err);
      }
    };

    ws.onerror = (error) => {
      setLogs((prev) => [`[${new Date().toLocaleTimeString()}] WebSocket error encountered.`, ...prev]);
    };

    return () => {
      ws.close();
    };
  }, [websocketEndpoint]);

  const handleSimulationTrigger = useCallback(
    async (scenario: 'contention' | 'deadlock') => {
      setIsSimulating(true);
      setLogs((prev) => [`[${new Date().toLocaleTimeString()}] Triggering simulation: ${scenario}...`, ...prev]);
      try {
        await onTriggerSimulation(scenario);
        setLogs((prev) => [`[${new Date().toLocaleTimeString()}] Simulation completed successfully.`, ...prev]);
      } catch (err: any) {
        setLogs((prev) => [`[${new Date().toLocaleTimeString()}] Simulation error: ${err.message}`, ...prev]);
      } finally {
        setIsSimulating(false);
      }
    },
    [onTriggerSimulation]
  );

  // Dynamic alert evaluations
  const isWaitTimeExceeded = metrics.averageLockWaitTimeMs > alertThresholds.maxWaitTimeMs;
  const isDeadlockExceeded = metrics.deadlocksPerMinute > alertThresholds.maxDeadlocksPerMin;

  return (
    <div className="p-6 max-w-7xl mx-auto bg-gray-900 text-white rounded-xl shadow-2xl font-sans">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 border-b border-gray-800 pb-4 gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">PostgreSQL Concurrency & Ledger Monitor</h1>
          <p className="text-sm text-gray-400">Real-time telemetry of row locks, wait states, and transaction pipelines.</p>
        </div>
        <div className="flex space-x-4">
          <button
            onClick={() => handleSimulationTrigger('contention')}
            disabled={isSimulating}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded font-medium disabled:opacity-50 transition-colors"
          >
            {isSimulating ? 'Running...' : 'Simulate Contention'}
          </button>
          <button
            onClick={() => handleSimulationTrigger('deadlock')}
            disabled={isSimulating}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 rounded font-medium disabled:opacity-50 transition-colors"
          >
            {isSimulating ? 'Running...' : 'Trigger Deadlock'}
          </button>
        </div>
      </header>

      {/* Metric Summary Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
          <p className="text-sm text-gray-400">Active Locks</p>
          <p className="text-3xl font-semibold mt-1">{metrics.activeLocks}</p>
        </div>
        <div
          className={`p-4 rounded-lg border transition-colors ${
            isDeadlockExceeded ? 'bg-rose-950/40 border-rose-600 animate-pulse' : 'bg-gray-800 border-gray-700'
          }`}
        >
          <p className="text-sm text-gray-400">Deadlocks / Min</p>
          <p className="text-3xl font-semibold mt-1">{metrics.deadlocksPerMinute}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
          <p className="text-sm text-gray-400">Serialization Failures</p>
          <p className="text-3xl font-semibold mt-1">{metrics.serializationFailures}</p>
        </div>
        <div
          className={`p-4 rounded-lg border transition-colors ${
            isWaitTimeExceeded ? 'bg-amber-950/40 border-amber-600 animate-pulse' : 'bg-gray-800 border-gray-700'
          }`}
        >
          <p className="text-sm text-gray-400">Avg Lock Wait Time</p>
          <p className="text-3xl font-semibold mt-1">{metrics.averageLockWaitTimeMs} ms</p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
          <p className="text-sm text-gray-400">Pool Usage</p>
          <p className="text-3xl font-semibold mt-1">{metrics.connectionPoolUsagePercent}%</p>
        </div>
      </div>

      {/* Real-time Event Audit Log Terminal */}
      <div className="bg-black/60 border border-gray-800 rounded-lg p-4 font-mono text-sm">
        <div className="flex justify-between items-center mb-2 pb-2 border-b border-gray-800">
          <span className="text-gray-400 font-semibold">Live Event Audit Stream</span>
          <span className="text-xs text-emerald-400 flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span> Live WebSocket Feed
          </span>
        </div>
        <div className="h-48 overflow-y-auto space-y-1 text-gray-300">
          {logs.length === 0 ? (
            <p className="text-gray-500 italic">Waiting for telemetry events...</p>
          ) : (
            logs.map((log, index) => (
              <div key={index} className="leading-relaxed">
                {log}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
