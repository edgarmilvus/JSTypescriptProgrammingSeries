/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { Pool } from 'pg';

export enum PaymentState {
  PENDING = 'PENDING',
  LOCKED = 'LOCKED',
  SETTLED = 'SETTLED',
  FAILED = 'FAILED',
}

export interface PaymentPipelineContext {
  paymentId: string;
  accountId: string;
  amount: bigint;
  externalGatewayUrl: string;
}

export class AsynchronousPaymentPipeline {
  constructor(private pool: Pool) {}

  /**
   * Processes a payment through minimal-duration locking and non-blocking external API dispatch.
   */
  public async processPayment(context: PaymentPipelineContext): Promise<boolean> {
    // TODO: Step 1 - Acquire short-lived pessimistic lock to debit account and set state to LOCKED
    // TODO: Step 2 - Release database transaction immediately
    // TODO: Step 3 - Perform non-blocking network I/O call to external payment gateway
    // TODO: Step 4 - If success, transition state to SETTLED. If failure, execute compensating credit transaction.
    throw new Error('Not implemented');
  }
}
