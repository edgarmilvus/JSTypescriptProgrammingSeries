/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Define supported currency types to enforce type safety at compile time
export type SupportedCurrency = 'USD' | 'EUR' | 'GBP' | 'BTC';

// Represents a single account within the chart of accounts
export interface Account<TCode extends string = string> {
  id: string;
  code: TCode;
  name: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  currency: SupportedCurrency;
  isActive: boolean;
  createdAt: Date;
}

// Represents a single posting (leg) of a double-entry transaction
export interface Posting<TMetadata = Record<string, unknown>> {
  id: string;
  accountId: string;
  // Amount in minor units (e.g., cents), stored as a bigint to prevent precision loss
  amount: bigint;
  // 'DEBIT' or 'CREDIT'
  direction: 'DEBIT' | 'CREDIT';
  currency: SupportedCurrency;
  metadata?: TMetadata;
}

// Represents an immutable journal entry containing two or more balanced postings
export interface JournalEntry<TMetadata = Record<string, unknown>> {
  id: string;
  transactionId: string;
  description: string;
  status: 'POSTED' | 'REVERSED' | 'PENDING';
  effectiveDate: Date;
  createdAt: Date;
  postings: Posting<TMetadata>[];
  // Optional reference to the original entry if this is a reversal
  reversalOfEntryId?: string;
}

// Generic type utility to enforce balance validation across postings
export type BalanceValidator<T extends Posting> = (postings: T[]) => boolean;
