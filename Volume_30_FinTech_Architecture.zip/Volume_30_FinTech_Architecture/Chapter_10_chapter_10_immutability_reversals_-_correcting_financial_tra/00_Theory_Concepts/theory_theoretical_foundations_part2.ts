/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

export class LedgerValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LedgerValidationError';
  }
}

/**
 * Validates that a collection of postings satisfies the double-entry accounting invariant:
 * Sum(Debits) - Sum(Credits) === 0 (assuming debits are positive and credits are negative, 
 * or handled via directional summation).
 */
export function validateDoubleEntryBalance<T extends Posting>(postings: T[]): void {
  if (!postings || postings.length < 2) {
    throw new LedgerValidationError('A journal entry must contain at least two postings.');
  }

  let totalDebit = 0n;
  let totalCredit = 0n;
  const currencyCheck = postings[0].currency;

  for (const posting of postings) {
    // Ensure all postings in a single journal entry share the exact same currency
    if (posting.currency !== currencyCheck) {
      throw new LedgerValidationError(
        `Currency mismatch in journal entry: found ${posting.currency}, expected ${currencyCheck}.`
      );
    }

    if (posting.amount <= 0n) {
      throw new LedgerValidationError(`Posting amount must be strictly positive: ${posting.amount}`);
    }

    if (posting.direction === 'DEBIT') {
      totalDebit += posting.amount;
    } else if (posting.direction === 'CREDIT') {
      totalCredit += posting.amount;
    } else {
      throw new LedgerValidationError(`Invalid posting direction: ${(posting as Posting).direction}`);
    }
  }

  if (totalDebit !== totalCredit) {
    throw new LedgerValidationError(
      `Unbalanced journal entry: Total Debits (${totalDebit}) do not equal Total Credits (${totalCredit}).`
    );
  }
}
