/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

import { Pool, PoolClient } from 'pg';

export class LedgerRepository {
  constructor(private readonly pool: Pool) {}

  /**
   * Atomically writes an immutable journal entry and its associated postings to the database.
   */
  async postJournalEntry(entry: Omit<JournalEntry, 'id' | 'createdAt'>): Promise<string> {
    // 1. Validate balance symmetry in TypeScript before touching the database
    validateDoubleEntryBalance(entry.postings);

    const client: PoolClient = await this.pool.connect();

    try {
      // Begin atomic transaction
      await client.query('BEGIN');

      // 2. Insert the journal entry header
      const entryQuery = `
        INSERT INTO journal_entries (id, transaction_id, description, status, effective_date, reversal_of_entry_id)
        VALUES (uuid_generate_v4(), $1, $2, $3, $4, $5)
        RETURNING id;
      `;

      const entryId = crypto.randomUUID(); // Node.js native crypto
      const entryResult = await client.query(entryQuery, [
        entry.transactionId,
        entry.description,
        entry.status,
        entry.effectiveDate,
        entry.reversalOfEntryId || null,
      ]);

      const insertedEntryId = entryResult.rows[0].id;

      // 3. Insert all associated postings
      for (const posting of entry.postings) {
        const postingQuery = `
          INSERT INTO postings (id, journal_entry_id, account_id, amount, direction, currency)
          VALUES (uuid_generate_v4(), $1, $2, $3, $4, $5);
        `;

        await client.query(postingQuery, [
          insertedEntryId,
          posting.accountId,
          posting.amount.toString(), // Convert bigint to string for PostgreSQL bigint driver compatibility
          posting.direction,
          posting.currency,
        ]);
      }

      // Commit transaction
      await client.query('COMMIT');
      return insertedEntryId;
    } catch (error) {
      // Rollback transaction on any failure
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
