/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.ts
// Description: Theoretical Foundations
// ==========================================

export class ReversalService {
  constructor(
    private readonly dbPool: Pool,
    private readonly ledgerRepository: LedgerRepository
  ) {}

  /**
   * Generates and posts a complete reversal entry for a given historical journal entry ID.
   */
  async reverseJournalEntry(
    originalEntryId: string,
    reason: string,
    actorId: string
  ): Promise<string> {
    const client = await this.dbPool.connect();

    try {
      await client.query('BEGIN');

      // 1. Fetch the original journal entry
      const entryResult = await client.query(
        `SELECT id, transaction_id, description, status, effective_date, reversal_of_entry_id 
         FROM journal_entries WHERE id = $1;`,
        [originalEntryId]
      );

      if (entryResult.rows.length === 0) {
        throw new LedgerValidationError(`Journal entry not found: ${originalEntryId}`);
      }

      const originalEntry = entryResult.rows[0];

      if (originalEntry.status === 'REVERSED') {
        throw new LedgerValidationError(`Journal entry ${originalEntryId} has already been reversed.`);
      }

      // 2. Fetch all postings associated with the original entry
      const postingsResult = await client.query(
        `SELECT id, account_id, amount, direction, currency 
         FROM postings WHERE journal_entry_id = $1;`,
        [originalEntryId]
      );

      const originalPostings = postingsResult.rows;

      // 3. Construct inverted reversal postings
      const reversalPostings: Omit<Posting, 'id'>[] = originalPostings.map((p) => ({
        accountId: p.account_id,
        amount: BigInt(p.amount),
        // Invert the direction: DEBIT becomes CREDIT, CREDIT becomes DEBIT
        direction: p.direction === 'DEBIT' ? 'CREDIT' : 'DEBIT',
        currency: p.currency,
        metadata: {
          reversedPostingId: p.id,
          reason,
          actorId,
        },
      }));

      // 4. Construct the reversal journal entry payload
      const reversalEntryPayload = {
        transactionId: crypto.randomUUID(), // New unique transaction ID for the reversal event
        description: `REVERSAL of ${originalEntry.id}: ${reason}`,
        status: 'POSTED' as const,
        effectiveDate: new Date(), // Effective immediately upon correction
        reversalOfEntryId: originalEntry.id,
        postings: reversalPostings,
      };

      // 5. Post the reversal entry using the ledger repository (includes balance validation)
      const reversalEntryId = await this.ledgerRepository.postJournalEntry(reversalEntryPayload);

      // 6. Mark the original entry status as REVERSED (metadata update, not a data deletion/mutation of core ledger facts)
      await client.query(
        `UPDATE journal_entries SET status = 'REVERSED' WHERE id = $1;`,
        [originalEntryId]
      );

      await client.query('COMMIT');
      return reversalEntryId;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
