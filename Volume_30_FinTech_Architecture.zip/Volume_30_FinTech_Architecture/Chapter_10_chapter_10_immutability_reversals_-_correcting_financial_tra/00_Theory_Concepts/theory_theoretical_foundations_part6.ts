/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.ts
// Description: Theoretical Foundations
// ==========================================

export class CompensationService {
  constructor(private readonly ledgerRepository: LedgerRepository) {}

  /**
   * Posts a compensating journal entry to correct a specific fee overcharge error
   * without reversing the underlying valid transfer transaction.
   */
  async compensateFeeOvercharge(params: {
    originalTransactionId: string;
    customerAccountId: string;
    platformRevenueAccountId: string;
    refundAmountInCents: bigint;
    currency: SupportedCurrency;
    reason: string;
  }): Promise<string> {
    const {
      originalTransactionId,
      customerAccountId,
      platformRevenueAccountId,
      refundAmountInCents,
      currency,
      reason,
    } = params;

    if (refundAmountInCents <= 0n) {
      throw new LedgerValidationError('Compensating refund amount must be greater than zero.');
    }

    // Construct the compensating journal entry:
    // Debit Platform Revenue (reducing platform income)
    // Credit Customer Checking Account (refunding the fee to the customer)
    const compensatingEntry = {
      transactionId: crypto.randomUUID(),
      description: `COMPENSATION for overcharged fee on tx ${originalTransactionId}: ${reason}`,
      status: 'POSTED' as const,
      effectiveDate: new Date(),
      postings: [
        {
          accountId: platformRevenueAccountId,
          amount: refundAmountInCents,
          direction: 'DEBIT' as const,
          currency,
          metadata: { originalTransactionId, correctionType: 'FEE_REFUND' },
        },
        {
          accountId: customerAccountId,
          amount: refundAmountInCents,
          direction: 'CREDIT' as const,
          currency,
          metadata: { originalTransactionId, correctionType: 'FEE_REFUND' },
        },
      ],
    };

    // Post the compensating entry to the immutable ledger
    return await this.ledgerRepository.postJournalEntry(compensatingEntry);
  }
}
