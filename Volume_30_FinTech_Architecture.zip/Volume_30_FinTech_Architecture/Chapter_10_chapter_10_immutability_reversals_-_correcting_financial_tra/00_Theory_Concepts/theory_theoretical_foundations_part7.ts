/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part7.ts
// Description: Theoretical Foundations
// ==========================================

export class BalanceQueryService {
  constructor(private readonly pool: Pool) {}

  /**
   * Computes the current balance of an account by aggregating all immutable postings.
   */
  async getAccountBalance(accountId: string): Promise<{ balance: bigint; currency: SupportedCurrency }> {
    const query = `
      SELECT 
        currency,
        SUM(
          CASE 
            WHEN direction = 'DEBIT' THEN amount 
            WHEN direction = 'CREDIT' THEN -amount 
            ELSE 0 
          END
        ) as net_balance
      FROM postings
      WHERE account_id = $1
      GROUP BY currency;
    `;

    const result = await this.pool.query(query, [accountId]);

    if (result.rows.length === 0) {
      // Default zero balance if no postings exist
      return { balance: 0n, currency: 'USD' };
    }

    const row = result.rows[0];
    return {
      balance: BigInt(row.net_balance),
      currency: row.currency as SupportedCurrency,
    };
  }
}
