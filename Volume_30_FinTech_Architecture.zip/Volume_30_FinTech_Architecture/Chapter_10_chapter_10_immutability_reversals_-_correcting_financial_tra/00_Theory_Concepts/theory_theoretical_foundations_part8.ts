/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part8.ts
// Description: Theoretical Foundations
// ==========================================

export interface TransferRequest {
  sourceAccountId: string;
  destinationAccountId: string;
  amount: bigint;
  currency: SupportedCurrency;
  description: string;
  idempotencyKey: string;
}

export class PaymentPipelineService {
  constructor(private readonly pool: Pool) {}

  /**
   * Executes a high-reliability payment transfer between two accounts using pessimistic locking
   * and idempotency protection.
   */
  async executeTransfer(request: TransferRequest): Promise<string> {
    const { sourceAccountId, destinationAccountId, amount, currency, description, idempotencyKey } = request;

    if (amount <= 0n) {
      throw new LedgerValidationError('Transfer amount must be strictly positive.');
    }

    const client = await this.pool.connect();

    try {
      // Begin serializable or repeatable read transaction
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ');

      // 1. Idempotency Check: Ensure this transaction has not already been processed
      const existingTx = await client.query(
        `SELECT id FROM journal_entries WHERE transaction_id = $1;`,
        [idempotencyKey]
      );

      if (existingTx.rows.length > 0) {
        await client.query('ROLLBACK');
        return existingTx.rows.id; // Return existing journal entry ID for idempotent requests
      }

      // 2. Pessimistic Locking: Lock the source and destination account rows in a deterministic order 
      // (e.g., ordered by account ID string) to prevent database deadlocks across concurrent requests.
      const accountIds = [sourceAccountId, destinationAccountId].sort();

      for (const accId of accountIds) {
        const lockResult = await client.query(
          `SELECT id, currency, is_active FROM accounts WHERE id = $1 FOR UPDATE;`,
          [accId]
        );

        if (lockResult.rows.length === 0) {
          throw new LedgerValidationError(`Account not found: ${accId}`);
        }

        if (!lockResult.rows.is_active) {
          throw new LedgerValidationError(`Account is inactive and cannot participate in transfers: ${accId}`);
        }

        if (lockResult.rows.currency !== currency) {
          throw new LedgerValidationError(`Currency mismatch for account ${accId}: expected ${currency}`);
        }
      }

      // 3. Compute current balance of the source account to verify sufficient funds
      const balanceResult = await client.query(
        `SELECT SUM(
           CASE 
             WHEN direction = 'DEBIT' THEN amount 
             WHEN direction = 'CREDIT' THEN -amount 
             ELSE 0 
           END
         ) as net_balance
         FROM postings WHERE account_id = $1;`,
        [sourceAccountId]
      );

      const sourceBalance = BigInt(balanceResult.rows.net_balance || '0');

      // Assuming source is an Asset account where debits increase and credits decrease balance,
      // or adjusting based on your chart of accounts convention. Let's assume positive balance means available funds.
      if (sourceBalance < amount) {
        throw new LedgerValidationError(
          `Insufficient funds in source account ${sourceAccountId}. Available: ${sourceBalance}, Required: ${amount}`
        );
      }

      // 4. Insert the immutable journal entry header
      const entryId = crypto.randomUUID();
      await client.query(
        `INSERT INTO journal_entries (id, transaction_id, description, status, effective_date)
         VALUES ($1, $2, $3, 'POSTED', NOW());`,
        [entryId, idempotencyKey, description]
      );

      // 5. Insert balanced postings: Credit source account, Debit destination account
      // (Assuming asset account transfer: Credit reduces source asset, Debit increases destination asset)
      const postings = [
        {
          accountId: sourceAccountId,
          amount: amount.toString(),
          direction: 'CREDIT',
        },
        {
          accountId: destinationAccountId,
          amount: amount.toString(),
          direction: 'DEBIT',
        },
      ];

      for (const p of postings) {
        await client.query(
          `INSERT INTO postings (id, journal_entry_id, account_id, amount, direction, currency)
           VALUES (uuid_generate_v4(), $1, $2, $3, $4, $5);`,
          [entryId, p.accountId, p.amount, p.direction, currency]
        );
      }

      await client.query('COMMIT');
      return entryId;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
