/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Billing Ledger Pipeline - Immutable Double-Entry & Reversal Engine
 * 
 * This module demonstrates a type-safe, append-only double-entry ledger system
 * written in TypeScript. It uses Generics to handle account identifiers and 
 * monetary amounts safely, enforcing the core accounting invariant: 
 * Sum of Debits === Sum of Credits.
 */

// ==========================================
// 1. TYPE DEFINITIONS & GENERICS
// ==========================================

/**
 * Represents the distinct categories of accounts in our double-entry system.
 */
type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

/**
 * Represents the direction of a financial entry.
 * - DEBIT: Increases Assets/Expenses, decreases Liabilities/Equity/Revenue.
 * - CREDIT: Increases Liabilities/Equity/Revenue, decreases Assets/Expenses.
 */
type EntryDirection = 'DEBIT' | 'CREDIT';

/**
 * Represents an individual line item within a journal entry.
 * Uses a Generic type parameter <TAccountId> to allow consumers to define 
 * their own account identifier structures (e.g., strings, UUID brands, or enums).
 */
interface LedgerLine<TAccountId> {
  readonly accountId: TAccountId;
  readonly direction: EntryDirection;
  /**
   * Stored as an integer (smallest currency unit, e.g., cents) 
   * to completely eliminate IEEE 754 floating-point rounding errors.
   */
  readonly amountCents: number;
}

/**
 * Represents a complete, balanced journal entry (a transaction batch).
 */
interface JournalEntry<TAccountId, TMetadata = Record<string, unknown>> {
  readonly id: string;
  readonly timestamp: number;
  readonly description: string;
  readonly lines: ReadonlyArray<LedgerLine<TAccountId>>;
  readonly metadata?: TMetadata;
  /**
   * If this entry is a reversal, points to the original JournalEntry ID.
   */
  readonly reversalOfId?: string;
}

/**
 * Configuration options for creating a new journal entry.
 */
interface CreateEntryInput<TAccountId, TMetadata> {
  readonly id: string;
  readonly description: string;
  readonly lines: ReadonlyArray<LedgerLine<TAccountId>>;
  readonly metadata?: TMetadata;
  readonly reversalOfId?: string;
}

// ==========================================
// 2. THE IMMUTABLE LEDGER ENGINE CLASS
// ==========================================

/**
 * The core engine managing the append-only ledger state.
 * Implemented using Generics <TAccountId> for maximum reusability across 
 * different SaaS application domains.
 */
class ImmutableLedgerEngine<TAccountId extends string | number> {
  // Private, internal storage array. Marked as readonly to prevent external mutations.
  private readonly _journal: JournalEntry<TAccountId>[] = [];

  /**
   * Appends a new journal entry to the ledger after validating accounting invariants.
   * Throws an error if the transaction is unbalanced.
   */
  public postEntry(input: CreateEntryInput<TAccountId, any>): JournalEntry<TAccountId> {
    // 1. Enforce Double-Entry Invariant (Sum of Debits must equal Sum of Credits)
    let totalDebits = 0;
    let totalCredits = 0;

    for (const line of input.lines) {
      if (line.amountCents <= 0) {
        throw new Error(`Invalid line amount: ${line.amountCents}. Amounts must be strictly positive integers.`);
      }
      if (line.direction === 'DEBIT') {
        totalDebits += line.amountCents;
      } else {
        totalCredits += line.amountCents;
      }
    }

    if (totalDebits !== totalCredits) {
      throw new Error(
        `Unbalanced Journal Entry [${input.id}]. Total Debits (${totalDebits}) do not equal Total Credits (${totalCredits}).`
      );
    }

    // 2. Create the immutable entry structure using Object.freeze for runtime protection
    const entry: JournalEntry<TAccountId> = Object.freeze({
      id: input.id,
      timestamp: Date.now(),
      description: input.description,
      lines: Object.freeze(input.lines.map(line => Object.freeze({ ...line }))),
      metadata: input.metadata ? Object.freeze({ ...input.metadata }) : undefined,
      reversalOfId: input.reversalOfId,
    });

    // 3. Append to historical log
    this._journal.push(entry);
    return entry;
  }

  /**
   * Creates a precise compensating reversal for an existing historical entry.
   * Instead of deleting or mutating the original entry, this method generates 
   * an inverse entry where all DEBITs become CREDITs and vice versa.
   */
  public reverseEntry(
    originalEntryId: string,
    newReversalId: string,
    reason: string
  ): JournalEntry<TAccountId> {
    // Find the original historical record
    const originalEntry = this._journal.find(e => e.id === originalEntryId);
    if (!originalEntry) {
      throw new Error(`Cannot reverse non-existent journal entry ID: ${originalEntryId}`);
    }

    // Check if this entry has already been reversed to prevent duplicate reversals
    const alreadyReversed = this._journal.some(e => e.reversalOfId === originalEntryId);
    if (alreadyReversed) {
      throw new Error(`Journal entry ID ${originalEntryId} has already been reversed.`);
    }

    // Generate compensating lines by flipping the directions
    const compensatingLines: LedgerLine<TAccountId>[] = originalEntry.lines.map(line => ({
      accountId: line.accountId,
      // Invert direction: DEBIT -> CREDIT, CREDIT -> DEBIT
      direction: line.direction === 'DEBIT' ? 'CREDIT' : 'DEBIT',
      amountCents: line.amountCents,
    }));

    // Post the compensating entry to the ledger
    return this.postEntry({
      id: newReversalId,
      description: `REVERSAL of [${originalEntry.id}]: ${reason}`,
      lines: compensatingLines,
      reversalOfId: originalEntry.id,
      metadata: { originalTimestamp: originalEntry.timestamp },
    });
  }

  /**
   * Computes the current balance of a specific account by scanning the append-only log.
   */
  public getAccountBalance(accountId: TAccountId, normalDirection: EntryDirection): number {
    let balanceCents = 0;

    for (const entry of this._journal) {
      for (const line of entry.lines) {
        if (line.accountId === accountId) {
          if (line.direction === normalDirection) {
            balanceCents += line.amountCents;
          } else {
            balanceCents -= line.amountCents;
          }
        }
      }
    }

    return balanceCents;
  }

  /**
   * Returns a frozen, read-only view of the entire ledger history.
   */
  public getAuditTrail(): ReadonlyArray<JournalEntry<TAccountId>> {
    return Object.freeze([...this._journal]);
  }
}

// ==========================================
// 3. SAAS EXECUTION & SIMULATION
// ==========================================

// Define concrete account IDs for our SaaS platform
type SaaSAccount = 'CASH_CHECKOUT' | 'ACCOUNTS_RECEIVABLE' | 'SUBSCRIPTION_REVENUE' | 'REFUND_EXPENSE';

// Instantiate our engine
const saasLedger = new ImmutableLedgerEngine<SaaSAccount>();

console.log('--- STEP 1: INITIAL SUBSCRIPTION PURCHASE ---');
// A customer purchases a $50.00 SaaS subscription.
// Debit: Cash (Asset increases) -> $50.00
// Credit: Subscription Revenue (Revenue increases) -> $50.00
const initialTx = saasLedger.postEntry({
  id: 'JE-2026-001',
  description: 'Monthly Pro Plan Subscription - Customer #8834',
  lines: [
    { accountId: 'CASH_CHECKOUT', direction: 'DEBIT', amountCents: 5000 },
    { accountId: 'SUBSCRIPTION_REVENUE', direction: 'CREDIT', amountCents: 5000 },
  ],
  metadata: { customerId: 'cust_99abc', plan: 'PRO_MONTHLY' },
});

console.log('Posted Entry:', JSON.stringify(initialTx, null, 2));
console.log('Cash Balance:', saasLedger.getAccountBalance('CASH_CHECKOUT', 'DEBIT')); // 5000 cents ($50.00)

console.log('\n--- STEP 2: PROCESSING AN ERROR CORRECTION (REFUND) ---');
// Due to a billing bug, the customer was double-billed, or requested a cancellation within policy.
// Instead of deleting JE-2026-001, we issue a compensating reversal entry.
const reversalTx = saasLedger.reverseEntry(
  'JE-2026-001',
  'JE-2026-002-REV',
  'Duplicate charge reported by customer support ticket #4491'
);

console.log('Posted Reversal Entry:', JSON.stringify(reversalTx, null, 2));

console.log('\n--- STEP 3: AUDIT & FINAL BALANCES ---');
// Verify that Cash is now zeroed out, proving accurate correction without mutations.
console.log('Final Cash Balance:', saasLedger.getAccountBalance('CASH_CHECKOUT', 'DEBIT')); // 0 cents
console.log('Final Revenue Balance:', saasLedger.getAccountBalance('SUBSCRIPTION_REVENUE', 'CREDIT')); // 0 cents

console.log('\n--- COMPLETE IMMUTABLE AUDIT TRAIL ---');
console.log(`Total Journal Entries Recorded: ${saasLedger.getAuditTrail().length}`);
