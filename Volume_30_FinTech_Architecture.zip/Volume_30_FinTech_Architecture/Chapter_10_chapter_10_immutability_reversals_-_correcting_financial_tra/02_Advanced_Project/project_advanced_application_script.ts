/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pool, PoolClient } from 'pg';

// Initialize a connection pool for a PostgreSQL append-only ledger architecture
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

/**
 * Represents the fundamental currencies supported by the payment pipeline.
 */
export type Currency = 'USD' | 'EUR' | 'GBP';

/**
 * Represents a single line item within a journal entry.
 * Implements strict type safety for double-entry bookkeeping.
 */
export interface JournalLineInput {
  accountId: string;
  // Amounts are stored as integers (minor units) to prevent floating-point drift
  amount: number; 
  currency: Currency;
  // Direction of the financial impact
  direction: 'DEBIT' | 'CREDIT';
}

/**
 * Payload required to post an initial financial transaction.
 */
export interface PostTransactionRequest {
  tenantId: string;
  idempotencyKey: string;
  description: string;
  lines: JournalLineInput[];
}

/**
 * Payload required to reverse or correct an existing journal entry.
 */
export interface ReverseTransactionRequest {
  tenantId: string;
  idempotencyKey: string;
  originalJournalId: string;
  reason: string;
}

/**
 * Core engine for managing immutable double-entry ledgers in a Next.js/Node backend.
 */
export class ImmutableLedgerEngine {
  
  /**
   * Validates that the sum of all debits equals the sum of all credits.
   * Enforces the fundamental equation of double-entry bookkeeping: Assets = Liabilities + Equity (or Debits = Credits).
   */
  private static validateDoubleEntry(lines: JournalLineInput[]): void {
    const totals = lines.reduce((acc, line) => {
      acc[line.direction] = (acc[line.direction] || 0) + line.amount;
      return acc;
    }, {} as Record<'DEBIT' | 'CREDIT', number>);

    const totalDebits = totals['DEBIT'] || 0;
    const totalCredits = totals['CREDIT'] || 0;

    if (totalDebits !== totalCredits) {
      throw new Error(
        `Imbalanced double-entry: Total Debits (${totalDebits}) must equal Total Credits (${totalCredits}).`
      );
    }

    if (totalDebits <= 0) {
      throw new Error('Transaction amount must be greater than zero.');
    }
  }

  /**
   * Posts an immutable journal entry to the database using an append-only pattern.
   * No updates or deletes are ever permitted on journal headers or lines.
   */
  public static async postTransaction(
    client: PoolClient,
    payload: PostTransactionRequest
  ): Promise<string> {
    this.validateDoubleEntry(payload.lines);

    // 1. Insert the immutable Journal Header
    const journalResult = await client.query(
      `
      INSERT INTO journals (tenant_id, idempotency_key, description, status)
      VALUES ($1, $2, $3, 'POSTED')
      RETURNING id;
      `,
      [payload.tenantId, payload.idempotencyKey, payload.description]
    );

    const journalId = journalResult.rows[0].id;

    // 2. Insert immutable Journal Lines linked to the header
    for (const line of payload.lines) {
      await client.query(
        `
        INSERT INTO journal_lines (journal_id, account_id, amount, currency, direction)
        VALUES ($1, $2, $3, $4, $5);
        `,
        [journalId, line.accountId, line.amount, line.currency, line.direction]
      );
    }

    return journalId;
  }

  /**
   * Safely corrects an erroneous transaction by issuing a full compensating reversal.
   * This creates a brand-new journal entry that mirrors the original lines with inverted directions,
   * preserving complete auditability without altering past records.
   */
  public static async reverseTransaction(
    payload: ReverseTransactionRequest
  ): Promise<string> {
    const client = await pool.connect();

    try {
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;');

      // 1. Fetch the original journal entry and its lines
      const originalJournalQuery = await client.query(
        `SELECT id, tenant_id, status FROM journals WHERE id = $1 AND tenant_id = $2;`,
        [payload.originalJournalId, payload.tenantId]
      );

      if (originalJournalQuery.rows.length === 0) {
        throw new Error(`Original journal entry ${payload.originalJournalId} not found.`);
      }

      const originalJournal = originalJournalQuery.rows[0];
      if (originalJournal.status === 'REVERSED') {
        throw new Error(`Journal entry ${payload.originalJournalId} has already been reversed.`);
      }

      const originalLinesQuery = await client.query(
        `SELECT account_id, amount, currency, direction FROM journal_lines WHERE journal_id = $1;`,
        [payload.originalJournalId]
      );

      // 2. Construct compensating lines (invert DEBIT and CREDIT)
      const compensatingLines: JournalLineInput[] = originalLinesQuery.rows.map((row) => ({
        accountId: row.account_id,
        amount: row.amount,
        currency: row.currency,
        direction: row.direction === 'DEBIT' ? 'CREDIT' : 'DEBIT',
      }));

      // 3. Post the reversal transaction
      const reversalJournalId = await this.postTransaction(client, {
        tenantId: payload.tenantId,
        idempotencyKey: payload.idempotencyKey,
        description: `REVERSAL of ${payload.originalJournalId}: ${payload.reason}`,
        lines: compensatingLines,
      });

      // 4. Mark the original journal status as REVERSED (Metadata update only, data remains intact)
      await client.query(
        `UPDATE journals SET status = 'REVERSED', reversed_by_journal_id = $1 WHERE id = $2;`,
        [reversalJournalId, payload.originalJournalId]
      );

      await client.query('COMMIT;');
      return reversalJournalId;
    } catch (error) {
      await client.query('ROLLBACK;');
      throw error;
    } finally {
      client.release();
    }
  }
}
