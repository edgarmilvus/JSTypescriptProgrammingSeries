/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export type AccountId = string & { readonly __brand: unique symbol };

export interface LineItem<TAccId = AccountId> {
  readonly accountId: TAccId;
  readonly amount: bigint; // Stored in minor units (e.g., cents)
  readonly direction: 'DEBIT' | 'CREDIT';
}

export interface JournalEntry<TAccId = AccountId> {
  readonly id: string;
  readonly timestamp: Date;
  readonly description: string;
  readonly lineItems: readonly LineItem<TAccId>[];
}

export function validateJournalEntry<TAccId>(entry: JournalEntry<TAccId>): boolean {
  let totalDebits = 0n;
  let totalCredits = 0n;

  for (const item of entry.lineItems) {
    if (item.amount <= 0n) {
      return false; // Financial amounts must be positive strictly; direction dictates sign
    }
    if (item.direction === 'DEBIT') {
      totalDebits += item.amount;
    } else if (item.direction === 'CREDIT') {
      totalCredits += item.amount;
    } else {
      return false;
    }
  }

  return totalDebits === totalCredits && entry.lineItems.length > 0;
}

export function postJournalEntry<TAccId>(
  entry: JournalEntry<TAccId>
): Readonly<JournalEntry<TAccId>> {
  if (!validateJournalEntry(entry)) {
    throw new Error('Unbalanced journal entry: Total debits must equal total credits.');
  }

  // Deeply freeze the entry and its line items to guarantee runtime immutability
  const frozenLineItems = entry.lineItems.map(item => Object.freeze({ ...item }));
  
  return Object.freeze({
    ...entry,
    lineItems: Object.freeze(frozenLineItems),
  });
}
