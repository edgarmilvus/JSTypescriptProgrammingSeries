/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { JournalEntry, LineItem, AccountId } from './exercise-1';

export interface ReversalMetadata {
  readonly originalEntryId: string;
  readonly reason: string;
  readonly reversedAt: Date;
}

export function generateReversalEntry(
  original: JournalEntry<AccountId>,
  metadata: ReversalMetadata
): Readonly<JournalEntry<AccountId>> {
  const reversedLineItems: LineItem<AccountId>[] = original.lineItems.map(item => ({
    accountId: item.accountId,
    amount: item.amount,
    direction: item.direction === 'DEBIT' ? 'CREDIT' : 'DEBIT',
  }));

  const reversalEntry: JournalEntry<AccountId> = {
    id: `rev-${crypto.randomUUID()}`,
    timestamp: metadata.reversedAt,
    description: `REVERSAL of [${original.id}]: ${metadata.reason}`,
    lineItems: reversedLineItems,
  };

  // Validate that the reversed entry itself balances properly before locking
  let totalDebits = 0n;
  let totalCredits = 0n;
  for (const item of reversalEntry.lineItems) {
    if (item.direction === 'DEBIT') totalDebits += item.amount;
    else totalCredits += item.amount;
  }

  if (totalDebits !== totalCredits) {
    throw new Error('Generated reversal entry fails double-entry balance check.');
  }

  return Object.freeze({
    ...reversalEntry,
    lineItems: Object.freeze(reversalEntry.lineItems.map(item => Object.freeze({ ...item }))),
  });
}
