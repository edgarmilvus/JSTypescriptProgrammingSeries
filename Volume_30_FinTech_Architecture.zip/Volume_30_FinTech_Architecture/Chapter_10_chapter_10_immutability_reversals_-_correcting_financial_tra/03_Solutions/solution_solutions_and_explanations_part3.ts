/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { createHash } from 'crypto';
import { JournalEntry } from './exercise-1';

export interface ChainedLedgerEntry extends JournalEntry {
  readonly previousHash: string;
  readonly currentHash: string;
}

export function computeEntryHash(entry: Omit<ChainedLedgerEntry, 'currentHash'>): string {
  // Deterministic serialization of entry components excluding currentHash
  const payload = JSON.stringify({
    id: entry.id,
    timestamp: entry.timestamp.toISOString(),
    description: entry.description,
    lineItems: entry.lineItems.map(item => ({
      accountId: item.accountId,
      amount: item.amount.toString(), // Convert bigint to string for deterministic JSON serialization
      direction: item.direction,
    })),
    previousHash: entry.previousHash,
  });

  return createHash('sha256').update(payload).digest('hex');
}

export function verifyLedgerIntegrity(entries: readonly ChainedLedgerEntry[]): boolean {
  if (entries.length === 0) return true;

  for (let i = 0; i < entries.length; i++) {
    const current = entries[i];

    // 1. Verify previous hash linkage (except for the genesis block)
    if (i === 0) {
      if (current.previousHash !== 'GENESIS') return false;
    } else {
      const previous = entries[i - 1];
      if (current.previousHash !== previous.currentHash) {
        return false;
      }
    }

    // 2. Recompute current hash and verify cryptographic fingerprint match
    const { currentHash, ...entryWithoutHash } = current;
    const recomputedHash = computeEntryHash(entryWithoutHash);

    if (currentHash !== recomputedHash) {
      return false;
    }
  }

  return true;
}
