/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useTransition, useState } from 'react';

interface TransactionRecord<TAssetMetadata = { symbol: string }> {
  readonly id: string;
  readonly amount: bigint;
  readonly asset: TAssetMetadata;
  readonly status: 'POSTED' | 'REVERSED';
}

// 1. Server Component: Fetches initial ledger state
export async function LedgerAuditDashboard() {
  // Simulating direct database fetch in an RSC
  const initialTransactions: TransactionRecord[] = [
    { id: 'tx-101', amount: 15000n, asset: { symbol: 'USD' }, status: 'POSTED' },
    { id: 'tx-102', amount: 15000n, asset: { symbol: 'USD' }, status: 'POSTED' },
  ];

  return (
    <div className="p-6 bg-slate-900 text-white rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Immutable Ledger Audit Workspace</h2>
      <TransactionActionPanel transactions={initialTransactions} />
    </div>
  );
}

interface TransactionActionPanelProps<T> {
  readonly transactions: readonly TransactionRecord<T>[];
}

// 2. Client Component: Handles user interactions and reversals with useTransition
export function TransactionActionPanel<T>({ transactions }: TransactionActionPanelProps<T>) {
  const [isPending, startTransition] = useTransition();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const handleExecuteReversal = (id: string) => {
    setSelectedId(id);
    startTransition(async () => {
      // Simulate network round-trip / Server Action execution
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log(`Compensating reversal posted successfully for transaction: ${id}`);
    });
  };

  return (
    <div>
      <div className={`space-y-3 ${isPending ? 'opacity-50 pointer-events-none' : ''}`}>
        {transactions.map(tx => (
          <div key={tx.id} className="flex justify-between items-center p-4 bg-slate-800 rounded border border-slate-700">
            <div>
              <p className="font-mono text-sm">ID: {tx.id}</p>
              <p className="text-lg font-semibold">
                {Number(tx.amount) / 100} {(tx.asset as { symbol: string }).symbol}
              </p>
              <span className={`text-xs px-2 py-0.5 rounded ${tx.status === 'POSTED' ? 'bg-green-900 text-green-200' : 'bg-red-900 text-red-200'}`}>
                {tx.status}
              </span>
            </div>
            <button
              onClick={() => handleExecuteReversal(tx.id)}
              disabled={isPending || tx.status === 'REVERSED'}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 rounded text-sm font-medium transition-colors"
            >
              {isPending && selectedId === tx.id ? 'Reversing...' : 'Execute Reversal'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
