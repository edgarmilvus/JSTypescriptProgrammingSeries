/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Strict Append-Only Journal Entry Posting Engine

export type AccountId = string & { readonly __brand: unique symbol };

export interface LineItem<TAccId = AccountId> {
  readonly accountId: TAccId;
  readonly amount: bigint; // Stored in minor units (e.g., cents)
  readonly direction: 'DEBIT' | 'CREDIT';
}

export interface JournalEntry<TAccId = AccountId> {
  readonly id: string;
  readonly timestamp: Date;
  readonly description: string;
  readonly lineItems: readonly LineItem<TAccId>[];
}

// TODO: Implement the validation logic that ensures sum(Debits) === sum(Credits)
export function validateJournalEntry<TAccId>(entry: JournalEntry<TAccId>): boolean {
  // Your implementation here
  throw new Error('Not implemented');
}

// TODO: Implement the posting function that returns a frozen/immutable object
export function postJournalEntry<TAccId>(
  entry: JournalEntry<TAccId>
): Readonly<JournalEntry<TAccId>> {
  // Your implementation here
  throw new Error('Not implemented');
}
