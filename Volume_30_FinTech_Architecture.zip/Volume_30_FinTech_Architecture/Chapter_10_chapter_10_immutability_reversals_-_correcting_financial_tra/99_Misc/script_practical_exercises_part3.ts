/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Cryptographic Hash-Chaining for Immutable Ledgers

import { createHash } from 'crypto';
import { JournalEntry } from './exercise-1';

export interface ChainedLedgerEntry extends JournalEntry {
  readonly previousHash: string;
  readonly currentHash: string;
}

export function computeEntryHash(entry: Omit<ChainedLedgerEntry, 'currentHash'>): string {
  // TODO: Serialize the entry deterministically and compute its SHA-256 hash
  throw new Error('Not implemented');
}

export function verifyLedgerIntegrity(entries: readonly ChainedLedgerEntry[]): boolean {
  // TODO: Iterate through the chain, verifying that:
  // 1. entries[i].previousHash === entries[i - 1].currentHash
  // 2. entries[i].currentHash matches the recomputed hash of entries[i]
  throw new Error('Not implemented');
}
