/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: React Server Component & useTransition Reversal Workspace

import React, { useTransition, useState } from 'react';

// Definitions applied:
// - Data Fetching in SCs: Fetching initial audit context directly in the Server Component.
// - React useTransition: Managing pending states for asynchronous financial Server Actions.
// - Generics: Reusable transaction row component supporting various asset types.

interface TransactionRecord<TAssetMetadata = { symbol: string }> {
  readonly id: string;
  readonly amount: bigint;
  readonly asset: TAssetMetadata;
  readonly status: 'POSTED' | 'REVERSED';
}

// 1. Server Component: Fetches initial ledger state
export async function LedgerAuditDashboard() {
  // TODO: Fetch initial immutable ledger data directly on the server
  const initialTransactions: TransactionRecord[] = []; // Mock fetch result

  return (
    <div className="p-6 bg-slate-900 text-white rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Immutable Ledger Audit Workspace</h2>
      <TransactionActionPanel transactions={initialTransactions} />
    </div>
  );
}

interface TransactionActionPanelProps<T> {
  readonly transactions: readonly TransactionRecord<T>[];
}

// 2. Client Component: Handles user interactions and reversals with useTransition
export function TransactionActionPanel<T>({ transactions }: TransactionActionPanelProps<T>) {
  const [isPending, startTransition] = useTransition();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const handleExecuteReversal = (id: string) => {
    startTransition(async () => {
      // TODO: Invoke Server Action to post compensating reversal
      console.log(`Executing reversal for transaction: ${id}`);
    });
  };

  return (
    <div>
      {/* TODO: Render table of transactions with a disabled/loading state when isPending is true */}
      <div className={isPending ? 'opacity-50 pointer-events-none' : ''}>
        {/* Render transaction rows here */}
      </div>
    </div>
  );
}
