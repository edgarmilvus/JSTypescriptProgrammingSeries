/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph PaymentGatewayFoundations {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica", fontsize=10];
    
    subgraph cluster_internal {
        label = "Internal TypeScript Architecture";
        style = dashed;
        color = blue;
        Ledger [label="Double-Entry Ledger\n(Deterministic & Strict Types)"];
        TypeGuards [label="Runtime Type Guards\n& Type Inference"];
        StateEngine [label="Payment Pipeline State Engine\n(FSM)"];
    }
    
    subgraph cluster_boundary {
        label = "Network Boundary";
        style = dotted;
        color = orange;
        WebhookVerify [label="Cryptographic Verification\n(HMAC Signatures)"];
        PayloadNormalization [label="Payload Normalization\n& Schema Validation"];
    }
    
    subgraph cluster_external {
        label = "External Payment Gateways";
        style = filled;
        color = lightgrey;
        Stripe [label="Stripe API\n(JSON / REST)"];
        Adyen [label="Adyen API\n(JSON / SOAP-REST)"];
    }

    Ledger -> StateEngine [label="1. Intent"];
    StateEngine -> Stripe [label="2. API Request"];
    StateEngine -> Adyen [label="2. API Request"];
    Stripe -> WebhookVerify [label="3. Asynchronous Event"];
    Adyen -> WebhookVerify [label="3. Asynchronous Event"];
    WebhookVerify -> PayloadNormalization [label="4. Raw Payload"];
    PayloadNormalization -> TypeGuards [label="5. Unknown Data"];
    TypeGuards -> Ledger [label="6. Validated Mutation"];
}
