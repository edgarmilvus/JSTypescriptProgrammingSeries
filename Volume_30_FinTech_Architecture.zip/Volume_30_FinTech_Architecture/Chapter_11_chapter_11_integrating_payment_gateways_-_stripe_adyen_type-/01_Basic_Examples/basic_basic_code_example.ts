/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';
import { createHmac, timingSafeEqual } from 'node:crypto';

// ============================================================================
// 1. DOMAIN MODELS & ZOD RUNTIME SCHEMAS
// ============================================================================

/**
 * Zod schema defining the precise shape of a successful payment intent 
 * webhook payload received from a payment provider (e.g., Stripe).
 */
const PaymentSucceededSchema = z.object({
  id: z.string().min(1, { message: "Event ID cannot be empty" }),
  type: z.literal('payment_intent.succeeded'),
  data: z.object({
    object: z.object({
      id: z.string().startsWith('pi_', { message: "Invalid Stripe PaymentIntent ID format" }),
      amount: z.number().int().positive({ message: "Amount must be a positive integer in cents" }),
      currency: z.string().length(3, { message: "Currency must be a 3-letter ISO code" }),
      customer: z.string().nullable(),
      metadata: z.record(z.string(), z.string()).optional(),
    }),
  }),
  created: z.number().int().positive(),
});

/**
 * Type Inference: Automatically derive the TypeScript type from the Zod schema.
 * This ensures our compile-time types are 100% synchronized with runtime validations.
 */
type PaymentSucceededEvent = z.infer<typeof PaymentSucceededSchema>;

// ============================================================================
// 2. CRYPTOGRAPHIC VERIFICATION LAYER
// ============================================================================

/**
 * Verifies the cryptographic signature of an incoming webhook to prevent spoofing.
 * 
 * @param rawBody - The unparsed, raw string body of the incoming HTTP request.
 * @param signatureHeader - The signature header sent by the payment provider (e.g., 'Stripe-Signature').
 * @param secret - The webhook signing secret configured in the dashboard.
 * @returns boolean indicating whether the signature is authentic.
 */
function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string,
  secret: string
): boolean {
  try {
    // Parse the signature header (e.g., "t=123456789,v1=abc123hash...")
    const parts = signatureHeader.split(',');
    const timestampPart = parts.find(p => p.startsWith('t='));
    const signaturePart = parts.find(p => p.startsWith('v1='));

    if (!timestampPart || !signaturePart) {
      return false;
    }

    const timestamp = timestampPart.split('=')[1];
    const signature = signaturePart.split('=')[1];

    // Construct the signed payload string per provider specs
    const signedPayload = `${timestamp}.${rawBody}`;

    // Compute HMAC SHA256 signature
    const expectedSignature = createHmac('sha256', secret)
      .update(signedPayload)
      .digest('hex');

    // Convert strings to buffers for timing-safe comparison to prevent timing attacks
    const signatureBuffer = Buffer.from(signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');

    if (signatureBuffer.length !== expectedBuffer.length) {
      return false;
    }

    return timingSafeEqual(signatureBuffer, expectedBuffer);
  } catch (error) {
    // Catch any parsing or buffer allocation errors securely
    return false;
  }
}

// ============================================================================
// 3. SERVICE LAYER & LEDGER PIPELINE
// ============================================================================

/**
 * Represents the result of processing a webhook event within the SaaS pipeline.
 */
type ProcessingResult = 
  | { success: true; transactionId: string; amountCredited: number }
  | { success: false; error: string };

/**
 * Simulates a double-entry ledger integration layer for a SaaS billing subscription.
 * 
 * @param event - The fully validated and type-safe payment succeeded event.
 * @returns A promise resolving to the processing outcome.
 */
async function fulfillSaaSOrder(event: PaymentSucceededEvent): Promise<ProcessingResult> {
  const paymentIntent = event.data.object;
  const customerId = paymentIntent.customer;
  const amountInCents = paymentIntent.amount;

  if (!customerId) {
    return { success: false, error: "PaymentIntent missing required customer identifier." };
  }

  // --- DOUBLE-ENTRY LEDGER SIMULATION ---
  // In a robust financial pipeline, we would execute a database transaction here:
  // 1. Credit Accounts Receivable / Cash asset account.
  // 2. Credit Customer Revenue / Deferred Revenue liability account.
  
  console.log(`[Ledger] Posting transaction for customer: ${customerId}`);
  console.log(`[Ledger] Crediting amount: ${amountInCents} ${paymentIntent.currency.toUpperCase()}`);

  // Simulating asynchronous database latency
  await new Promise(resolve => setTimeout(resolve, 100));

  return {
    success: true,
    transactionId: paymentIntent.id,
    amountCredited: amountInCents,
  };
}

// ============================================================================
// 4. WEBHOOK ROUTING CONTROLLER
// ============================================================================

/**
 * Main entry point for handling incoming webhook HTTP requests in a SaaS web framework.
 * 
 * @param rawBodyString - The raw string body extracted from the HTTP request stream.
 * @param signatureHeader - The value of the provider's signature HTTP header.
 * @returns HTTP response object structure.
 */
async function handleStripeWebhook(
  rawBodyString: string,
  signatureHeader: string
): Promise<{ statusCode: number; body: string }> {
  const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_test_dummy_secret';

  // Step A: Verify cryptographic authenticity
  const isAuthentic = verifyWebhookSignature(rawBodyString, signatureHeader, WEBHOOK_SECRET);
  if (!isAuthentic) {
    return { statusCode: 401, body: JSON.stringify({ error: "Invalid Webhook Signature" }) };
  }

  let parsedJson: unknown;
  try {
    // Step B: Safely parse JSON from the raw string
    parsedJson = JSON.parse(rawBodyString);
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: "Malformed JSON payload" }) };
  }

  // Step C: Enforce Runtime Validation using Zod
  const validationResult = PaymentSucceededSchema.safeParse(parsedJson);
  if (!validationResult.success) {
    // Zod provides granular formatting errors for debugging type mismatches
    console.error("Validation failed:", validationResult.error.format());
    return { 
      statusCode: 422, 
      body: JSON.stringify({ error: "Unprocessable Entity: Payload structure validation failed" }) 
    };
  }

  // At this precise execution branch, TypeScript statically knows `validationResult.data` 
  // matches the exact shape of `PaymentSucceededEvent` through Type Inference and Guarding.
  const validatedEvent = validationResult.data;

  // Step D: Filter and handle specific event types (Extensibility point)
  switch (validatedEvent.type) {
    case 'payment_intent.succeeded': {
      const result = await fulfillSaaSOrder(validatedEvent);
      if (!result.success) {
        return { statusCode: 500, body: JSON.stringify({ error: result.error }) };
      }
      return { statusCode: 200, body: JSON.stringify({ received: true, transactionId: result.transactionId }) };
    }
    default: {
      // Exhaustiveness check safety net (Never reachable due to Zod literal validation, but safe practice)
      const _exhaustiveCheck: never = validatedEvent;
      return { statusCode: 400, body: JSON.stringify({ error: "Unhandled event type" }) };
    }
  }
}
