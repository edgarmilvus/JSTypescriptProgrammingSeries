/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use server';

import { z } from 'zod';
import crypto from 'crypto';

/**
 * ============================================================================
 * 1. ZOD SCHEMAS & TYPE INFERENCE
 * ============================================================================
 */

/**
 * Schema defining the input payload for initiating a payment intent.
 * Enforces primitive type boundaries, regex constraints for currency codes,
 * and minimum positive integer amounts (stored in minor currency units like cents).
 */
const InitiatePaymentSchema = z.object({
  amount: z.number().int().positive('Payment amount must be a positive integer.'),
  currency: z.string().length(3, 'Currency must be an ISO 4217 three-letter code.').transform(val => val.toUpperCase()),
  paymentMethodId: z.string().min(1, 'A valid payment method ID is required.'),
  customerId: z.string().min(1, 'A valid customer ID is required.'),
  idempotencyKey: z.string().uuid('A valid UUID idempotency key is required to prevent double charging.'),
});

/**
 * Inferred TypeScript type derived directly from the Zod validation schema.
 * This guarantees that runtime validation maps 1:1 with compile-time expectations.
 */
type InitiatePaymentInput = z.infer<typeof InitiatePaymentSchema>;

/**
 * Strongly-typed return contract for the Server Action.
 * Discriminated union pattern ensures consumers explicitly handle both success and error branches.
 */
type PaymentResult = 
  | { success: true; transactionId: string; status: 'succeeded' | 'requires_action' }
  | { success: false; errorCode: string; errorMessage: string };

/**
 * ============================================================================
 * 2. MOCK EXTERNAL PSP CLIENT (STRIPE/ADYEN ABSTRACTION)
 * ============================================================================
 */

/**
 * Simulates a third-party payment gateway client with strict internal typings.
 */
const mockStripeClient = {
  paymentIntents: {
    create: async (params: InitiatePaymentInput, options: { idempotencyKey: string }) => {
      // In a real-world scenario, this executes an HTTPS POST to api.stripe.com/v1/payment_intents
      if (params.amount > 99999999) {
        throw new Error('Amount exceeds maximum allowable transaction limit.');
      }
      return {
        id: `pi_${crypto.randomBytes(12).toString('hex')}`,
        status: 'succeeded' as const,
        client_secret: `pi_${crypto.randomBytes(12).toString('hex')}_secret_${crypto.randomBytes(8).toString('hex')}`,
      };
    }
  }
};

/**
 * ============================================================================
 * 3. SERVER ACTION IMPLEMENTATION
 * ============================================================================
 */

/**
 * Secure Next.js Server Action for processing payments with rigorous validation,
 * cryptographic idempotency tracking, and exhaustive error boundary handling.
 * 
 * @param rawInput - Unvalidated input directly from client forms or API callers.
 * @returns A strongly-typed PaymentResult discriminated union.
 */
export async function processPaymentAction(rawInput: unknown): Promise<PaymentResult> {
  try {
    // Step A: Parse and validate untrusted input using the Zod schema
    const parseResult = InitiatePaymentSchema.safeParse(rawInput);

    if (!parseResult.success) {
      // Extract flattened validation error messages for debugging and client feedback
      const errorDetail = parseResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
      console.error(`[Payment Validation Error]: ${errorDetail}`);
      
      return {
        success: false,
        errorCode: 'VALIDATION_ERROR',
        errorMessage: `Invalid payment payload: ${errorDetail}`,
      };
    }

    const validatedData: InitiatePaymentInput = parseResult.data;

    // Step B: Enforce idempotency via the cryptographically secure key supplied in the payload
    // In production, verify this key against Redis or PostgreSQL uniqueness constraints.
    const isIdempotent = await checkAndStoreIdempotencyKey(validatedData.idempotencyKey);
    if (!isIdempotent) {
      return {
        success: false,
        errorCode: 'DUPLICATE_TRANSACTION',
        errorMessage: 'An operation with this idempotency key has already been processed.',
      };
    }

    // Step C: Dispatch payload to the PSP with strict timeout and error catch blocks
    console.info(`[Payment Initiation]: Processing charge of ${validatedData.amount} ${validatedData.currency} for customer ${validatedData.customerId}`);

    const pspResponse = await mockStripeClient.paymentIntents.create(validatedData, {
      idempotencyKey: validatedData.idempotencyKey,
    });

    // Step D: Return strongly-typed success structure
    return {
      success: true,
      transactionId: pspResponse.id,
      status: pspResponse.status,
    };

  } catch (error: unknown) {
    // Step E: Handle unexpected network faults, gateway timeouts, or serialization issues
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred during payment processing.';
    console.error(`[Payment Processing Exception]: ${errorMessage}`, error);

    return {
      success: false,
      errorCode: 'PSP_GATEWAY_ERROR',
      errorMessage: errorMessage,
    };
  }
}

/**
 * Helper stub simulating an atomic distributed lock or database write 
 * to ensure an idempotency key is processed precisely once.
 */
async function checkAndStoreIdempotencyKey(key: string): Promise<boolean> {
  // Production implementation should use a database constraint (UNIQUE index) or Redis SETNX
  return true; 
}
