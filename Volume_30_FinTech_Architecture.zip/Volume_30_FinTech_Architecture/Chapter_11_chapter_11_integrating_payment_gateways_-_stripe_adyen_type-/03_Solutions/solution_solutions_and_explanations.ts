/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the raw Stripe error shape
interface StripeRawError {
  type: string;
  message: string;
  code?: string;
}

// Define successful and failed response variants using discriminated unions
type StripeSuccessResponse<T> = {
  status: 'succeeded' | 'processing' | 'requires_action';
  data: T;
  error: null;
};

type StripeErrorResponse = {
  status: 'failed';
  data: null;
  error: StripeRawError;
};

type StripeApiResponse<T> = StripeSuccessResponse<T> | StripeErrorResponse;

// Custom Error class for typed exception throwing
class StripeApiError extends Error {
  public readonly code?: string;
  public readonly type: string;

  constructor(rawError: StripeRawError) {
    super(rawError.message);
    this.name = 'StripeApiError';
    this.type = rawError.type;
    this.code = rawError.code;
  }
}

/**
 * Handles Stripe API responses, narrowing the union type based on the 'status' discriminant.
 * Throws a typed StripeApiError if the status indicates a failure.
 */
function handleStripeResponse<T>(response: StripeApiResponse<T>): T {
  // Check the discriminant property 'status' or check for error existence
  if (response.status === 'failed' || response.error !== null) {
    throw new StripeApiError(response.error);
  }

  // TypeScript now safely narrows the type to StripeSuccessResponse<T>, 
  // meaning response.data is guaranteed to be of type T.
  return response.data;
}
