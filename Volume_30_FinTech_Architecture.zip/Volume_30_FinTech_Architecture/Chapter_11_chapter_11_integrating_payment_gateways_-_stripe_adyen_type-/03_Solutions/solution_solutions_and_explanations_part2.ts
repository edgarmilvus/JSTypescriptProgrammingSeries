/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

interface BaseStripeEvent {
  id: string;
  created: number;
  api_version: string;
  type: string;
}

interface PaymentIntentSucceededEvent extends BaseStripeEvent {
  type: 'payment_intent.succeeded';
  data: {
    object: {
      id: string;
      amount: number;
      currency: string;
      status: 'succeeded';
    };
  };
}

/**
 * User-defined type guard to narrow a base event to a PaymentIntentSucceededEvent.
 */
function isPaymentIntentEvent(event: BaseStripeEvent): event is PaymentIntentSucceededEvent {
  return (
    event.type === 'payment_intent.succeeded' &&
    typeof event === 'object' &&
    event !== null &&
    'data' in event &&
    typeof (event as any).data?.object === 'object' &&
    (event as any).data.object.status === 'succeeded'
  );
}

/**
 * Verifies the cryptographic signature of an incoming Stripe webhook request.
 * Expected header format: "t=1614556800,v1=abcdef123456..."
 */
function verifyStripeSignature(
  payload: string,
  header: string,
  secret: string,
  toleranceSeconds: number = 300
): boolean {
  try {
    const elements = header.split(',');
    const signatureParts: { [key: string]: string } = {};

    for (const element of elements) {
      const [key, value] = element.split('=');
      if (key && value) {
        signatureParts[key.trim()] = value.trim();
      }
    }

    const timestamp = signatureParts['t'];
    const v1Signature = signatureParts['v1'];

    if (!timestamp || !v1Signature) {
      return false;
    }

    // Check timestamp tolerance to prevent replay attacks
    const parsedTimestamp = parseInt(timestamp, 10);
    const currentTimestamp = Math.floor(Date.now() / 1000);
    if (Math.abs(currentTimestamp - parsedTimestamp) > toleranceSeconds) {
      return false;
    }

    // Compute expected HMAC SHA-256 signature
    const signedPayload = `${timestamp}.${payload}`;
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(signedPayload, 'utf8')
      .digest('hex');

    // Secure timing-safe comparison to prevent timing attacks
    const providedBuffer = Buffer.from(v1Signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');

    if (providedBuffer.length !== expectedBuffer.length) {
      return false;
    }

    return crypto.timingSafeEqual(providedBuffer, expectedBuffer);
  } catch (error) {
    return false;
  }
}
