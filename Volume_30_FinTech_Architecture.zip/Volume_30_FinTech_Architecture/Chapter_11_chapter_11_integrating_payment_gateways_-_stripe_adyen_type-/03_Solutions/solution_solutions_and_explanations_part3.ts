/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

type PaymentState = 'IDLE' | 'PROCESSING' | 'RETRYING' | 'SUCCEEDED' | 'FAILED';

type PaymentAction = 'START_PAYMENT' | 'API_TIMEOUT' | 'PAYMENT_SUCCESS' | 'PAYMENT_ERROR' | 'MAX_RETRIES_EXCEEDED';

// Define the precise mapping of allowed transitions
type AllowedTransitions = {
  IDLE: ['PROCESSING'];
  PROCESSING: ['SUCCEEDED', 'RETRYING', 'FAILED'];
  RETRYING: ['PROCESSING', 'FAILED'];
  SUCCEEDED: [];
  FAILED: [];
};

class PaymentStateMachine {
  private currentState: PaymentState = 'IDLE';
  private attemptCount: number = 0;
  private maxRetries: number = 3;

  // Static matrix enforcing compile-time validation rules
  private readonly transitionMatrix: Record<PaymentState, PaymentState[]> = {
    IDLE: ['PROCESSING'],
    PROCESSING: ['SUCCEEDED', 'RETRYING', 'FAILED'],
    RETRYING: ['PROCESSING', 'FAILED'],
    SUCCEEDED: [],
    FAILED: [],
  };

  public getState(): PaymentState {
    return this.currentState;
  }

  public getAttemptCount(): number {
    return this.attemptCount;
  }

  /**
   * Validates and executes a state transition based on the provided action.
   */
  public transition(action: PaymentAction): void {
    const nextState = this.determineNextState(this.currentState, action);

    if (!nextState) {
      throw new Error(`Invalid state transition: Action '${action}' is not allowed from state '${this.currentState}'.`);
    }

    // Verify against our transition matrix record
    const allowed = this.transitionMatrix[this.currentState];
    if (!allowed.includes(nextState)) {
      throw new Error(`State machine violation: Cannot transition from ${this.currentState} to ${nextState}.`);
    }

    if (nextState === 'PROCESSING' && this.currentState === 'IDLE') {
      this.attemptCount = 1;
    } else if (nextState === 'PROCESSING' && this.currentState === 'RETRYING') {
      this.attemptCount += 1;
    }

    this.currentState = nextState;
  }

  private determineNextState(current: PaymentState, action: PaymentAction): PaymentState | null {
    switch (action) {
      case 'START_PAYMENT':
        return current === 'IDLE' ? 'PROCESSING' : null;
      case 'PAYMENT_SUCCESS':
        return current === 'PROCESSING' ? 'SUCCEEDED' : null;
      case 'API_TIMEOUT':
      case 'PAYMENT_ERROR':
        if (current === 'PROCESSING') {
          return this.attemptCount < this.maxRetries ? 'RETRYING' : 'FAILED';
        }
        return null;
      case 'MAX_RETRIES_EXCEEDED':
        return current === 'RETRYING' ? 'FAILED' : null;
      default:
        return null;
    }
  }
}
