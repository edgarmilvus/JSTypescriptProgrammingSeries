/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'react';

// Define precision money representation for the checkout amount
interface AmountObject {
  value: number; // Stored in minor units (e.g., cents)
  currency: string; // ISO 4217 currency code (e.g., 'USD', 'EUR')
}

// Strict props interface for the AdyenCheckoutWidget component
interface AdyenCheckoutWidgetProps {
  clientKey: string;
  environment: 'test' | 'live';
  amount: AmountObject;
  sessionData: {
    id: string;
    paymentData: string;
  };
  onPaymentComplete: (result: { resultCode: string; pspReference?: string }) => void;
  onError: (error: Error) => void;
}

export const AdyenCheckoutWidget: React.FC<AdyenCheckoutWidgetProps> = ({
  clientKey,
  environment,
  amount,
  sessionData,
  onPaymentComplete,
  onError,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [componentError, setComponentError] = useState<string | null>(null);
  const checkoutInstanceRef = useRef<any>(null);

  useEffect(() => {
    let isMounted = true;

    async function initAdyen() {
      try {
        // Ensure browser execution context
        if (typeof window === 'undefined') return;

        // Dynamic import or global window check for Adyen Checkout SDK script
        const AdyenCheckout = (window as any).AdyenCheckout;
        if (!AdyenCheckout) {
          throw new Error('AdyenCheckout script failed to load on the window object.');
        }

        const checkout = await AdyenCheckout({
          environment,
          clientKey,
          session: {
            id: sessionData.id,
            sessionData: sessionData.paymentData,
          },
          onPaymentCompleted: (result: any) => {
            if (isMounted) {
              onPaymentComplete({
                resultCode: result.resultCode,
                pspReference: result.pspReference,
              });
            }
          },
          onError: (error: any) => {
            const err = new Error(error.message || 'Adyen checkout encountered an error');
            if (isMounted) {
              setComponentError(err.message);
              onError(err);
            }
          },
        });

        if (isMounted && containerRef.current) {
          checkoutInstanceRef.current = checkout;
          // Mount the drop-in UI component into the DOM container
          checkout.create('dropin').mount(containerRef.current);
          setIsLoading(false);
        }
      } catch (err) {
        const errorInstance = err instanceof Error ? err : new Error(String(err));
        if (isMounted) {
          setComponentError(errorInstance.message);
          setIsLoading(false);
          onError(errorInstance);
        }
      }
    }

    initAdyen();

    return () => {
      isMounted = false;
      if (checkoutInstanceRef.current) {
        try {
          checkoutInstanceRef.current.unmount();
        } catch (e) {
          console.error('Failed to cleanup Adyen checkout instance:', e);
        }
      }
    };
  }, [clientKey, environment, sessionData, onPaymentComplete, onError]);

  if (componentError) {
    return (
      <div className="w-full max-w-md mx-auto p-6 bg-red-50 border border-red-200 rounded-lg shadow-md">
        <h3 className="text-red-800 font-semibold mb-2">Payment Gateway Error</h3>
        <p className="text-red-600 text-sm">{componentError}</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <div className="text-gray-500 animate-pulse font-medium">Initializing secure payment channel...</div>
        </div>
      )}
      <div ref={containerRef} id="adyen-container" className="w-full" />
    </div>
  );
};
