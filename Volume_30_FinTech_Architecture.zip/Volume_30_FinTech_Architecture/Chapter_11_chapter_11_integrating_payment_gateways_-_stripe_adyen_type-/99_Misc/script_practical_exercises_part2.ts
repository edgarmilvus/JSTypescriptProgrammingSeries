/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import * as crypto from 'crypto';

interface BaseStripeEvent {
  id: string;
  created: number;
  api_version: string;
  type: string;
}

interface PaymentIntentSucceededEvent extends BaseStripeEvent {
  type: 'payment_intent.succeeded';
  data: {
    object: {
      id: string;
      amount: number;
      currency: string;
      status: 'succeeded';
    };
  };
}

// TODO: Implement the user-defined type guard for PaymentIntentSucceededEvent
function isPaymentIntentEvent(event: BaseStripeEvent): event is PaymentIntentSucceededEvent {
  // Write your type-checking logic here
}

// TODO: Implement the webhook signature verification helper
function verifyStripeSignature(
  payload: string,
  header: string,
  secret: string,
  toleranceSeconds: number = 300
): boolean {
  // Write your HMAC verification logic here
}
