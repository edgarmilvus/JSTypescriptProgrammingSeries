/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'react';

// Define precision money representation for the checkout amount
interface AmountObject {
  value: number; // Stored in minor units (e.g., cents)
  currency: string; // ISO 4217 currency code (e.g., 'USD', 'EUR')
}

// TODO: Define the strict props interface for the AdyenCheckoutWidget component
interface AdyenCheckoutWidgetProps {
  clientKey: string;
  environment: 'test' | 'live';
  amount: AmountObject;
  sessionData: {
    id: string;
    paymentData: string;
  };
  onPaymentComplete: (result: { resultCode: string; pspReference?: string }) => void;
  onError: (error: Error) => void;
}

export const AdyenCheckoutWidget: React.FC<AdyenCheckoutWidgetProps> = ({
  clientKey,
  environment,
  amount,
  sessionData,
  onPaymentComplete,
  onError,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [componentError, setComponentError] = useState<string | null>(null);

  // TODO: Implement the useEffect hook to initialize the Adyen SDK client-side
  useEffect(() => {
    // Write client-side initialization, container mounting, and cleanup logic here
  }, [clientKey, environment, sessionData]);

  if (componentError) {
    return <div className="text-red-600 p-4">Error loading payment gateway: {componentError}</div>;
  }

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      {isLoading && <div className="text-gray-500 animate-pulse">Initializing secure payment channel...</div>}
      <div ref={containerRef} id="adyen-container" />
    </div>
  );
};
