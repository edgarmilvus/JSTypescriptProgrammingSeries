/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as crypto from 'crypto';

/**
 * Represents the incoming raw HTTP request captured from the payment gateway.
 */
interface IncomingWebhookRequest {
  rawBody: string;
  signatureHeader: string;
  eventId: string;
  timestampHeader: string;
}

/**
 * Represents the parsed event structure from the payment gateway.
 */
interface PaymentEvent {
  id: string;
  type: string;
  created: number;
  data: {
    object: {
      id: string;
      amount: number;
      currency: string;
      status: string;
    };
  };
}

/**
 * In-memory mock of a distributed cache (e.g., Redis) to track processed event IDs
 * and enforce idempotency and replay protection.
 */
class DistributedCacheMock {
  private store = new Set<string>();

  /**
  * Atomically checks if an event ID exists and stores it if missing.
  * @param eventId The unique identifier of the webhook event.
  * @returns true if the event was newly added, false if it was already present (replay detected).
  */
  async setIfNotExists(eventId: string): Promise<boolean> {
    if (this.store.has(eventId)) {
      return false; // Replay detected
    }
    this.store.add(eventId);
    return true; // Newly recorded event
  }
}

/**
 * Main webhook processing service handling security and parsing.
 */
class WebhookProcessorService {
  private readonly webhookSecret: string;
  private readonly cache: DistributedCacheMock;
  private readonly maxClockSkewSeconds: number;

  /**
   * Initializes the webhook processor.
   * @param webhookSecret The secret key shared with the payment gateway for HMAC verification.
   * @param cache Distributed cache instance for idempotency checks.
   * @param maxClockSkewSeconds Maximum allowable time difference to prevent stale replays (default: 300s).
   */
  constructor(webhookSecret: string, cache: DistributedCacheMock, maxClockSkewSeconds: number = 300) {
    this.webhookSecret = webhookSecret;
    this.cache = cache;
    this.maxClockSkewSeconds = maxClockSkewSeconds;
  }

  /**
   * Verifies the cryptographic HMAC signature using a constant-time comparison algorithm.
   * @param rawBody The exact, unparsed string body received from the HTTP request.
   * @param signatureHeader The signature string extracted from the request headers.
   * @returns boolean indicating whether the signature is authentic.
   */
  private verifySignature(rawBody: string, signatureHeader: string): boolean {
    // 1. Extract timestamp and signature components from the header (format: t=1614556800,v1=hexsignature)
    const elements = signatureHeader.split(',');
    let timestamp: string | null = null;
    let receivedSignature: string | null = null;

    for (const element of elements) {
      const [prefix, value] = element.split('=');
      if (prefix === 't') timestamp = value;
      if (prefix === 'v1') receivedSignature = value;
    }

    if (!timestamp || !receivedSignature) {
      return false;
    }

    // 2. Enforce timestamp tolerance to prevent historical replay attacks
    const eventTime = parseInt(timestamp, 10);
    const currentTime = Math.floor(Date.now() / 1000);
    if (Math.abs(currentTime - eventTime) > this.maxClockSkewSeconds) {
      console.warn(`Webhook rejected: Timestamp skew exceeds limit. Event time: ${eventTime}, Current time: ${currentTime}`);
      return false;
    }

    // 3. Reconstruct the expected payload signature string: timestamp + "." + rawBody
    const signedPayload = `${timestamp}.${rawBody}`;

    // 4. Compute the HMAC SHA-256 hash using the webhook secret
    const computedSignature = crypto
      .createHmac('sha256', this.webhookSecret)
      .update(signedPayload, 'utf8')
      .digest('hex');

    // 5. Convert signatures to buffers for timing-safe comparison
    try {
      const computedBuffer = Buffer.from(computedSignature, 'hex');
      const receivedBuffer = Buffer.from(receivedSignature, 'hex');

      // Buffers must be of equal length for timingSafeEqual, otherwise it throws an error
      if (computedBuffer.length !== receivedBuffer.length) {
        return false;
      }

      return crypto.timingSafeEqual(computedBuffer, receivedBuffer);
    } catch (error) {
      // Handles malformed hex strings safely
      return false;
    }
  }

  /**
   * Processes the incoming webhook request through the full security pipeline.
   * @param request The incoming raw webhook request object.
   * @returns The parsed payment event if successful, or throws an error if validation fails.
   */
  public async handleWebhook(request: IncomingWebhookRequest): Promise<PaymentEvent> {
    // Step 1: Verify cryptographic signature and timestamp freshness
    const isSignatureValid = this.verifySignature(request.rawBody, request.signatureHeader);
    if (!isSignatureValid) {
      throw new Error('Unauthorized: Invalid webhook signature or expired timestamp.');
    }

    // Step 2: Check for event replay using atomic cache constraint
    const isNewEvent = await this.cache.setIfNotExists(request.eventId);
    if (!isNewEvent) {
      // Gracefully acknowledge duplicate events with a custom error or status flag
      throw new Error('Idempotency Conflict: Event has already been processed.');
    }

    // Step 3: Safely parse the verified raw JSON string into strongly typed structures
    let parsedEvent: PaymentEvent;
    try {
      parsedEvent = JSON.parse(request.rawBody) as PaymentEvent;
    } catch (error) {
      throw new Error('Bad Request: Malformed JSON payload.');
    }

    // Step 4: Validate essential structural properties of the parsed event
    if (!parsedEvent.id || !parsedEvent.type || !parsedEvent.data) {
      throw new Error('Unprocessable Entity: Missing required event schema fields.');
    }

    return parsedEvent;
  }
}

// ==========================================
// Execution Demonstration (Simulated Runtime)
// ==========================================
async function runDemo() {
  const SECRET = 'whsec_test_secret_key_123456789';
  const cache = new DistributedCacheMock();
  const processor = new WebhookProcessorService(SECRET, cache);

  // Construct a realistic payload
  const eventPayload: PaymentEvent = {
    id: 'evt_1Mzu0aLkdJ3f2z1S8v90W1x2',
    type: 'payment_intent.succeeded',
    created: Math.floor(Date.now() / 1000),
    data: {
      object: {
        id: 'pi_3Mzu0aLkdJ3f2z1S90812345',
        amount: 5000, // $50.00 in cents
        currency: 'usd',
        status: 'succeeded',
      },
    },
  };

  const rawBody = JSON.stringify(eventPayload);
  const timestamp = Math.floor(Date.now() / 1000).toString();
  
  // Generate valid signature
  const signedPayload = `${timestamp}.${rawBody}`;
  const signatureHash = crypto.createHmac('sha256', SECRET).update(signedPayload, 'utf8').digest('hex');
  const signatureHeader = `t=${timestamp},v1=${signatureHash}`;

  const incomingRequest: IncomingWebhookRequest = {
    rawBody,
    signatureHeader,
    eventId: eventPayload.id,
    timestampHeader: timestamp,
  };

  console.log('--- TEST 1: Processing Valid, Fresh Webhook ---');
  try {
    const result = await processor.handleWebhook(incomingRequest);
    console.log('Successfully processed event:', result.id, 'Type:', result.type);
  } catch (error: any) {
    console.error('Failed to process:', error.message);
  }

  console.log('\n--- TEST 2: Replay Attack Simulation (Duplicate Event ID) ---');
  try {
    // Submitting the exact same request again
    await processor.handleWebhook(incomingRequest);
  } catch (error: any) {
    console.error('Caught expected replay error:', error.message);
  }

  console.log('\n--- TEST 3: Tampered Payload Simulation ---');
  try {
    const tamperedRequest: IncomingWebhookRequest = {
      ...incomingRequest,
      rawBody: rawBody.replace('5000', '99999'), // Maliciously modifying amount
    };
    await processor.handleWebhook(tamperedRequest);
  } catch (error: any) {
    console.error('Caught expected signature failure:', error.message);
  }
}

runDemo();
