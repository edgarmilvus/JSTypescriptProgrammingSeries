/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { PrismaClient, Prisma } from '@prisma/client';

// Initialize the Prisma Client for database operations
const prisma = new PrismaClient();

// Retrieve the webhook secret from secure environment variables
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_dummy_secret_key';

// Define the maximum allowed clock drift or age for a webhook event (e.g., 5 minutes)
const MAX_TIMESTAMP_TOLERANCE_SECONDS = 300;

/**
 * Interface representing the core structure of an incoming payment gateway webhook event.
 */
interface WebhookEventPayload {
  id: string;
  type: string;
  created: number;
  data: {
    object: {
      id: string;
      amount: number;
      currency: string;
      customer: string;
      status: string;
    };
  };
}

/**
 * Performs a constant-time string comparison to prevent Timing Attacks.
 * Standard equality operators short-circuit on the first mismatched byte,
 * leaking timing information to a malicious actor trying to forge a signature.
 */
function safeTimingEqual(a: string, b: string): boolean {
  try {
    const bufferA = Buffer.from(a, 'utf-8');
    const bufferB = Buffer.from(b, 'utf-8');
    
    // crypto.timingSafeEqual throws if buffer lengths do not match
    if (bufferA.length !== bufferB.length) {
      return false;
    }
    
    return crypto.timingSafeEqual(bufferA, bufferB);
  } catch (error) {
    return false;
  }
}

/**
 * Verifies the cryptographic signature passed in the webhook headers.
 * Extracts the timestamp and signatures, computes the expected HMAC-SHA256 hash,
 * and validates the timestamp against the current server time to prevent replay attacks.
 */
function verifyWebhookSignature(
  rawBody: string,
  sigHeader: string | null
): { isValid: boolean; error?: string } {
  if (!sigHeader) {
    return { isValid: false, error: 'Missing signature header' };
  }

  // Parse the signature header (Format: t=1614556800,v1=abcdef...)
  const elements = sigHeader.split(',');
  let timestamp: string | null = null;
  const signatures: string[] = [];

  for (const element of elements) {
    const [prefix, value] = element.split('=');
    if (prefix === 't') {
      timestamp = value;
    } else if (prefix === 'v1') {
      signatures.push(value);
    }
  }

  if (!timestamp || signatures.length === 0) {
    return { isValid: false, error: 'Invalid signature header format' };
  }

  // 1. Replay Protection: Validate timestamp tolerance
  const eventTimestamp = parseInt(timestamp, 10);
  const currentTimestamp = Math.floor(Date.now() / 1000);

  if (isNaN(eventTimestamp)) {
    return { isValid: false, error: 'Invalid timestamp value' };
  }

  if (Math.abs(currentTimestamp - eventTimestamp) > MAX_TIMESTAMP_TOLERANCE_SECONDS) {
    return { isValid: false, error: 'Webhook timestamp outside of the allowed tolerance window' };
  }

  // 2. Cryptographic Verification: Compute HMAC-SHA256
  const signedPayload = `${timestamp}.${rawBody}`;
  const expectedSignature = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(signedPayload, 'utf-8')
    .digest('hex');

  // 3. Constant-Time Comparison
  const isValidSignature = signatures.some((sig) => safeTimingEqual(sig, expectedSignature));

  if (!isValidSignature) {
    return { isValid: false, error: 'Signature mismatch' };
  }

  return { isValid: true };
}

/**
 * Next.js API Route Handler for Ingesting Webhooks
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    // Read the raw body as a string. CRITICAL: Do not parse JSON before signature verification,
    // as whitespace normalization or key reordering will break the cryptographic hash.
    const rawBody = await req.text();
    const signatureHeader = req.headers.get('stripe-signature');

    // Step 1: Verify the signature and timestamp
    const verification = verifyWebhookSignature(rawBody, signatureHeader);
    if (!verification.isValid) {
      console.warn(`[SECURITY] Webhook verification failed: ${verification.error}`);
      return NextResponse.json({ error: verification.error }, { status: 400 });
    }

    // Step 2: Parse the verified payload
    const event: WebhookEventPayload = JSON.parse(rawBody);
    const { id: eventId, type: eventType, data } = event;

    console.log(`[INFO] Processing verified webhook event: ${eventId} (${eventType})`);

    // Step 3: Idempotency enforcement using an atomic database transaction
    // We attempt to insert the event ID into a processed_webhooks tracking table.
    // If the event ID already exists, a unique constraint violation occurs,
    // safely short-circuiting duplicate delivery attempts.
    try {
      await prisma.$transaction(async (tx) => {
        // Attempt to record the incoming webhook event ID
        await tx.processedWebhook.create({
          data: {
            eventId: eventId,
            eventType: eventType,
            status: 'PROCESSING',
            createdAt: new Date(),
          },
        });

        // Execute domain-specific business logic based on event type
        switch (eventType) {
          case 'payment_intent.succeeded': {
            const paymentIntent = data.object;
            console.log(`[LEDGER] Recording successful payment for intent: ${paymentIntent.id}`);
            
            // Example: Update user account balance or invoice status in the database
            // await tx.invoice.update({ ... });
            break;
          }
          case 'payment_intent.payment_failed': {
            const paymentIntent = data.object;
            console.log(`[LEDGER] Handling failed payment for intent: ${paymentIntent.id}`);
            break;
          }
          default:
            console.log(`[INFO] Unhandled event type: ${eventType}`);
        }

        // Update tracking record status to completed
        await tx.processedWebhook.update({
          where: { eventId: eventId },
          data: { status: 'COMPLETED' },
        });
      });
    } catch (dbError: any) {
      // Check for Prisma unique constraint violation error code (P2002)
      if (dbError instanceof Prisma.PrismaClientKnownRequestError && dbError.code === 'P2002') {
        console.warn(`[IDEMPOTENCY] Duplicate webhook event detected and ignored: ${eventId}`);
        // Return 200 OK to the payment gateway so it stops retrying the duplicate event
        return NextResponse.json({ received: true, duplicate: true }, { status: 200 });
      }
      
      // Re-throw unexpected database errors to trigger a 500 response (gateway will retry)
      throw dbError;
    }

    // Step 4: Return a successful 200 acknowledgment response
    return NextResponse.json({ received: true }, { status: 200 });

  } catch (error: any) {
    console.error('[FATAL] Error processing webhook pipeline:', error);
    // Returning a 500 status instructs the webhook provider to retry the request later
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
