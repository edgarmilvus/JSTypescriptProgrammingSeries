/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import crypto from 'crypto';

export type VerificationResult = 
  | { success: true; timestamp: number }
  | { success: false; error: 'MALFORMED_HEADER' | 'EXPIRED_TIMESTAMP' | 'INVALID_SIGNATURE' };

export interface WebhookVerificationOptions {
  secrets: string[]; // Updated to support key rotation array
  toleranceSeconds?: number;
  signatureHeaderName?: string;
  timestampHeaderName?: string;
}

/**
 * Verifies the cryptographic signature and timestamp of an incoming webhook request.
 * Supports multi-secret key rotation and constant-time comparison.
 */
export function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string | undefined,
  options: WebhookVerificationOptions
): VerificationResult {
  if (!signatureHeader || typeof signatureHeader !== 'string') {
    return { success: false, error: 'MALFORMED_HEADER' };
  }

  const tolerance = options.toleranceSeconds ?? 300;
  const secrets = options.secrets;

  if (!secrets || secrets.length === 0) {
    return { success: false, error: 'INVALID_SIGNATURE' };
  }

  // Parse header composite string: t=<timestamp>,v1=<signature>
  const parts = signatureHeader.split(',');
  let timestampStr: string | undefined;
  const signatures: string[] = [];

  for (const part of parts) {
    const [key, value] = part.split('=');
    if (!key || !value) continue;
    if (key.trim() === 't') {
      timestampStr = value.trim();
    } else if (key.trim() === 'v1' || key.trim() === 'v0') {
      signatures.push(value.trim());
    }
  }

  if (!timestampStr || signatures.length === 0) {
    return { success: false, error: 'MALFORMED_HEADER' };
  }

  const timestamp = parseInt(timestampStr, 10);
  if (isNaN(timestamp)) {
    return { success: false, error: 'MALFORMED_HEADER' };
  }

  // Validate timestamp tolerance window (protects against replay and clock skew)
  const currentTime = Math.floor(Date.now() / 1000);
  if (Math.abs(currentTime - timestamp) > tolerance) {
    return { success: false, error: 'EXPIRED_TIMESTAMP' };
  }

  // Recompute expected signatures and check against all active secrets
  const signedPayload = `${timestamp}.${rawBody}`;
  let signatureMatched = false;

  for (const secret of secrets) {
    const computedSignature = crypto
      .createHmac('sha256', secret)
      .update(signedPayload, 'utf8')
      .digest('hex');

    const computedBuffer = Buffer.from(computedSignature, 'hex');

    for (const sig of signatures) {
      let sigBuffer: Buffer;
      try {
        sigBuffer = Buffer.from(sig, 'hex');
      } catch {
        continue;
      }

      // Ensure buffers are identical in length before calling timingSafeEqual
      if (computedBuffer.length === sigBuffer.length) {
        if (crypto.timingSafeEqual(computedBuffer, sigBuffer)) {
          signatureMatched = true;
          break;
        }
      }
    }
    if (signatureMatched) break;
  }

  if (!signatureMatched) {
    return { success: false, error: 'INVALID_SIGNATURE' };
  }

  return { success: true, timestamp };
}
