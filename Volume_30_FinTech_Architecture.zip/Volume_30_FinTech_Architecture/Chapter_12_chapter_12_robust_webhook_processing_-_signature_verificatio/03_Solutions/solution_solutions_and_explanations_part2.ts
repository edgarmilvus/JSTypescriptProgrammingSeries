/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Redis } from 'ioredis';
import { Pool } from 'pg';

export type EventProcessingState = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';

export interface IdempotencyManagerConfig {
  redisClient: Redis;
  pgPool: Pool;
  defaultTtlSeconds?: number;
}

export class DistributedIdempotencyManager {
  private redis: Redis;
  private pg: Pool;
  private ttl: number;

  constructor(config: IdempotencyManagerConfig) {
    this.redis = config.redisClient;
    this.pg = config.pgPool;
    this.ttl = config.defaultTtlSeconds ?? 86400;
  }

  public async acquireLock(eventId: string, retryCount = 3): Promise<boolean> {
    const redisKey = `webhook:lock:${eventId}`;

    for (let attempt = 0; attempt <= retryCount; attempt++) {
      try {
        // Attempt atomic Redis claim: SET key value NX EX seconds
        const result = await this.redis.set(redisKey, 'PROCESSING', 'EX', this.ttl, 'NX');
        if (result === 'OK') {
          return true;
        }

        // If lock exists, check its state or wait via exponential backoff (spin-lock)
        const currentState = await this.redis.get(redisKey);
        if (currentState === 'COMPLETED') {
          return false; // Already processed successfully
        }

        if (attempt < retryCount) {
          const jitter = Math.random() * 100;
          const backoffMs = Math.pow(2, attempt) * 100 + jitter;
          await new Promise((resolve) => setTimeout(resolve, backoffMs));
          continue;
        }

        return false;
      } catch (redisError) {
        // Redis failure fallback to PostgreSQL
        console.warn('Redis unavailable, falling back to PostgreSQL idempotency check:', redisError);
        return await this.acquirePgFallbackLock(eventId);
      }
    }

    return false;
  }

  private async acquirePgFallbackLock(eventId: string): Promise<boolean> {
    const client = await this.pg.connect();
    try {
      await client.query('BEGIN');
      
      // Attempt inserting an idempotency record. Unique constraint on event_id handles duplicates.
      const query = `
        INSERT INTO webhook_idempotency (event_id, state, created_at)
        VALUES ($1, 'PROCESSING', NOW())
        ON CONFLICT (event_id) DO UPDATE 
        SET state = 'PROCESSING' 
        WHERE webhook_idempotency.state = 'FAILED'
        RETURNING state;
      `;
      const res = await client.query(query, [eventId]);
      await client.query('COMMIT');

      // If a row was returned, we successfully claimed or retried a failed event
      return res.rowCount !== null && res.rowCount > 0;
    } catch (pgError) {
      await client.query('ROLLBACK');
      return false;
    } finally {
      client.release();
    }
  }

  public async markCompleted(eventId: string): Promise<void> {
    const redisKey = `webhook:lock:${eventId}`;
    try {
      await this.redis.set(redisKey, 'COMPLETED', 'EX', this.ttl);
    } catch {
      // Fallback update to PG
      await this.pg.query(
        `UPDATE webhook_idempotency SET state = 'COMPLETED', updated_at = NOW() WHERE event_id = $1`,
        [eventId]
      );
    }
  }

  public async markFailed(eventId: string, reason: string): Promise<void> {
    const redisKey = `webhook:lock:${eventId}`;
    try {
      await this.redis.set(redisKey, 'FAILED', 'EX', this.ttl);
    } catch {
      await this.pg.query(
        `UPDATE webhook_idempotency SET state = 'FAILED', error_reason = $2, updated_at = NOW() WHERE event_id = $1`,
        [eventId, reason]
      );
    }
  }
}
