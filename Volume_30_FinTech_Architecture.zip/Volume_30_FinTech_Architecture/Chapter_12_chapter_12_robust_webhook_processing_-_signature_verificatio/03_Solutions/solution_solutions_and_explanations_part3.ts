/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { PoolClient } from 'pg';

export interface PaymentWebhookPayload {
  eventId: string;
  eventType: string;
  accountId: string;
  amountMinorUnits: number;
  currency: string;
  sourceTransactionId: string;
}

export class LedgerTransactionError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = 'LedgerTransactionError';
  }
}

/**
 * Executes a double-entry ledger mutation and outbox event insertion within an atomic database transaction.
 */
export async function processPaymentWebhookTransaction(
  dbClient: PoolClient,
  payload: PaymentWebhookPayload
): Promise<void> {
  try {
    await dbClient.query('BEGIN');

    // 1. Validate target account status and currency matching
    const accountCheck = await dbClient.query(
      `SELECT status, currency FROM accounts WHERE id = $1 FOR UPDATE`,
      [payload.accountId]
    );

    if (accountCheck.rowCount === 0) {
      throw new Error(`Account ${payload.accountId} not found.`);
    }

    const account = accountCheck.rows[0];
    if (account.status !== 'ACTIVE') {
      // Divert to dead-letter compliance queue if account is frozen or closed
      await dbClient.query(
        `INSERT INTO dead_letter_queue_events (event_id, payload, reason, created_at) VALUES ($1, $2, $3, NOW())`,
        [payload.eventId, JSON.stringify(payload), `Account is frozen or closed: ${account.status}`]
      );
      await dbClient.query('COMMIT');
      return;
    }

    if (account.currency !== payload.currency) {
      throw new Error(`Currency mismatch: account holds ${account.currency}, webhook sent ${payload.currency}`);
    }

    // 2. Insert double-entry journal transaction (Integer arithmetic prevents float drift)
    const journalRes = await dbClient.query(
      `INSERT INTO journal_entries (description, reference_id, created_at) VALUES ($1, $2, NOW()) RETURNING id`,
      [`Payment received: ${payload.sourceTransactionId}`, payload.sourceTransactionId]
    );
    const journalId = journalRes.rows[0].id;

    // Posting line 1: Credit user account (liability increase)
    await dbClient.query(
      `INSERT INTO posting_lines (journal_id, account_id, amount, direction) VALUES ($1, $2, $3, 'CREDIT')`,
      [journalId, payload.accountId, payload.amountMinorUnits]
    );

    // Posting line 2: Debit clearing/gateway cash account (asset increase)
    await dbClient.query(
      `INSERT INTO posting_lines (journal_id, account_id, amount, direction) VALUES ($1, $2, $3, 'DEBIT')`,
      [journalId, 'SYSTEM_CLEARING_CASH_ACCOUNT', payload.amountMinorUnits]
    );

    // 3. Insert outbox event for downstream async publishing (e.g., invoice generation)
    await dbClient.query(
      `INSERT INTO outbox_events (aggregate_id, event_type, payload, status, created_at) VALUES ($1, $2, $3, 'PENDING', NOW())`,
      [payload.accountId, 'invoice.pdf.generate', JSON.stringify(payload)]
    );

    // 4. Mark webhook event ingestion log as processed
    await dbClient.query(
      `UPDATE webhook_events SET status = 'PROCESSED', processed_at = NOW() WHERE event_id = $1`,
      [payload.eventId]
    );

    await dbClient.query('COMMIT');
  } catch (error) {
    await dbClient.query('ROLLBACK');
    throw new LedgerTransactionError(`Failed to process payment transaction for event ${payload.eventId}`, error);
  }
}
