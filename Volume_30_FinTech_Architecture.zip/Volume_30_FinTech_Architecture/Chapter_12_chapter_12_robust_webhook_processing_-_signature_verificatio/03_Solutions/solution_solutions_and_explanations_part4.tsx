/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// actions/webhooks.ts
'use server';

import { revalidatePath } from 'next/cache';

export type RedriveState = {
  success: boolean;
  message: string;
  redrivedAt?: string;
};

/**
 * Server Action to manually redrive a failed webhook event from the DLQ.
 */
export async function redriveWebhookAction(
  prevState: RedriveState,
  formData: FormData
): Promise<RedriveState> {
  const webhookId = formData.get('webhookId');

  if (!webhookId || typeof webhookId !== 'string') {
    return { success: false, message: 'Invalid or missing webhook ID.' };
  }

  try {
    // TODO: Insert session authentication & admin role authorization checks here
    // const session = await auth();
    // if (!session || session.user.role !== 'ADMIN') { throw new Error('Unauthorized'); }

    // Simulate webhook payload retrieval and pipeline redrive execution
    console.log(`[Redrive] Processing webhook ID: ${webhookId}`);
    
    // Simulating successful re-execution
    await new Promise((resolve) => setTimeout(resolve, 600));

    revalidatePath('/admin/webhooks');
    return {
      success: true,
      message: `Successfully redrived webhook ${webhookId}`,
      redrivedAt: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Unknown redrive failure.',
    };
  }
}
