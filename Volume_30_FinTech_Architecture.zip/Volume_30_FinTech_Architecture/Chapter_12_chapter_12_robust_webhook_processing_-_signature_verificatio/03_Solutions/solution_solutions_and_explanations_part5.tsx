/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// components/WebhookDLQMonitor.tsx
'use client';

import React, { useTransition } from 'react';
import { redriveWebhookAction, RedriveState } from '@/actions/webhooks';

export interface FailedWebhookRecord {
  id: string;
  eventId: string;
  eventType: string;
  failureReason: string;
  rawPayload: string;
  createdAt: string;
}

export interface WebhookDLQMonitorProps {
  failedEvents: FailedWebhookRecord[];
}

/**
 * Administrative dashboard component for monitoring and redriving dead-lettered webhooks.
 */
export default function WebhookDLQMonitor({ failedEvents }: WebhookDLQMonitorProps) {
  const [isPending, startTransition] = useTransition();
  const [actionState, setActionState] = React.useState<RedriveState | null>(null);

  const handleRedrive = (webhookId: string) => {
    const formData = new FormData();
    formData.append('webhookId', webhookId);

    startTransition(async () => {
      const result = await redriveWebhookAction({ success: false, message: '' }, formData);
      setActionState(result);
    });
  };

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <h2 className="text-2xl font-bold mb-4">Webhook Dead-Letter Queue (DLQ)</h2>

      {actionState && (
        <div className={`p-3 mb-4 rounded ${actionState.success ? 'bg-emerald-800' : 'bg-rose-800'}`}>
          {actionState.message}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-700 text-slate-400">
              <p className="p-3">Event ID</p>
              <p className="p-3">Type</p>
              <p className="p-3">Failure Reason</p>
              <p className="p-3">Created At</p>
              <p className="p-3">Actions</p>
            </tr>
          </thead>
          <tbody>
            {failedEvents.map((event) => (
              <tr key={event.id} className="border-b border-slate-800 hover:bg-slate-800/50">
                <td className="p-3 font-mono text-sm">{event.eventId}</td>
                <td className="p-3">{event.eventType}</td>
                <td className="p-3 text-rose-400">{event.failureReason}</td>
                <td className="p-3 text-sm text-slate-400">{event.createdAt}</td>
                <td className="p-3">
                  <button
                    onClick={() => handleRedrive(event.id)}
                    disabled={isPending}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded font-medium text-sm transition-colors"
                  >
                    {isPending ? 'Redriving...' : 'Redrive'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
