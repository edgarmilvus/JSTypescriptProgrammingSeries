/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import express, { Request, Response, NextFunction } from 'express';

// ==========================================
// TYPES & INTERFACES
// ==========================================

/**
 * Represents the lifecycle states of an idempotent request.
 * - 'PROCESSING': The request is currently being handled. Prevents race conditions.
 * - 'COMPLETED': The request finished successfully; stores the response payload.
 * - 'FAILED': The request failed with an unrecoverable error.
 */
type IdempotencyStatus = 'PROCESSING' | 'COMPLETED' | 'FAILED';

/**
 * Structure of the cached ledger response associated with an idempotency key.
 */
interface CachedResponse {
    status: IdempotencyStatus;
    statusCode?: number;
    body?: any;
    createdAt: number;
}

/**
 * Extended Express Request interface to include custom properties
 * populated by our idempotency middleware.
 */
interface IdempotentRequest extends Request {
    idempotencyKey?: string;
}

// ==========================================
// MOCK DISTRIBUTED CACHE (SIMULATING REDIS)
// ==========================================

/**
 * A thread-safe simulation of a distributed key-value store.
 * In a real SaaS architecture, this would be an instance of Redis or Amazon ElastiCache
 * using atomic operations like SETNX (Set if Not Exists) with TTLs.
 */
class DistributedCacheMock {
    private store = new Map<string, CachedResponse>();
    private lockTtlMs = 30000; // 30 seconds processing lock

    /**
     * Attempts to acquire an atomic lock for a given idempotency key.
     * 
     * @param key - The unique idempotency token provided by the client.
     * @returns boolean - True if the lock was acquired, false if it already exists.
     */
    public acquireLock(key: string): boolean {
        const existing = this.store.get(key);
        const now = Date.now();

        // If the key exists and is still marked as PROCESSING, check for lock expiration (deadlock prevention)
        if (existing && existing.status === 'PROCESSING') {
            if (now - existing.createdAt < this.lockTtlMs) {
                return false; // Still actively processing
            }
            // Lock expired, assume previous worker crashed; allow overwrite
        }

        // If the key already completed or failed, we don't acquire a new lock; we return the old result
        if (existing && (existing.status === 'COMPLETED' || existing.status === 'FAILED')) {
            return false; 
        }

        // Set initial PROCESSING state
        this.store.set(key, {
            status: 'PROCESSING',
            createdAt: now
        });

        return true;
    }

    /**
     * Retrieves the cached state of an idempotency key.
     */
    public get(key: string): CachedResponse | undefined {
        return this.store.get(key);
    }

    /**
     * Updates the cache with the final result of the executed operation.
     */
    public saveResult(key: string, statusCode: number, body: any, status: 'COMPLETED' | 'FAILED'): void {
        this.store.set(key, {
            status,
            statusCode,
            body,
            createdAt: Date.now()
        });
    }
}

// Instantiate our mock cache globally for the application
const idempotencyCache = new DistributedCacheMock();

// ==========================================
/**
 * Express Middleware: Enforces Idempotency for mutating API endpoints.
 * 
 * This middleware intercepts incoming requests, checks for the 'Idempotency-Key' header,
 * manages locking states to prevent concurrent duplicate execution, and replays cached
 * responses if a duplicate request arrives.
 */
// ==========================================
const idempotencyMiddleware = async (req: IdempotentRequest, res: Response, next: NextFunction): Promise<void> => {
    // 1. Extract the idempotency key from headers
    const idempotencyKey = req.headers['idempotency-key'] as string;

    // Financial endpoints REQUIRE an idempotency key for safe retries
    if (!idempotencyKey) {
        res.status(400).json({
            error: 'MISSING_IDEMPOTENCY_KEY',
            message: 'Mutating financial endpoints require a valid Idempotency-Key header.'
        });
        return;
    }

    // Attach to request object for downstream controllers if needed
    req.idempotencyKey = idempotencyKey;

    // 2. Attempt to acquire an atomic execution lock
    const lockAcquired = idempotencyCache.acquireLock(idempotencyKey);

    if (!lockAcquired) {
        // Fetch the current state of this key from our cache
        const cachedResponse = idempotencyCache.get(idempotencyKey);

        if (!cachedResponse) {
            res.status(500).json({ error: 'INTERNAL_CACHE_ERROR', message: 'Failed to resolve idempotency lock state.' });
            return;
        }

        // 3. Handle concurrent in-flight requests (Race condition prevention)
        if (cachedResponse.status === 'PROCESSING') {
            res.status(409).json({
                error: 'REQUEST_IN_FLIGHT',
                message: 'A request with this idempotency key is currently being processed. Please retry shortly.'
            });
            return;
        }

        // 4. Handle completed/failed requests by returning the exact cached payload
        if (cachedResponse.status === 'COMPLETED' || cachedResponse.status === 'FAILED') {
            // Add a custom response header to indicate this was a cached replay
            res.setHeader('X-Idempotent-Replay', 'true');
            res.status(cachedResponse.statusCode || 500).json(cachedResponse.body);
            return;
        }
    }

    // 5. Intercept the Express response object's `json` and `send` methods
    // This allows us to capture the downstream controller's output and cache it automatically.
    const originalJson = res.json.bind(res);

    res.json = (body: any): Response => {
        const statusCode = res.statusCode;
        const finalStatus = statusCode >= 400 ? 'FAILED' : 'COMPLETED';

        // Save the execution result back into our idempotency store
        if (idempotencyKey) {
            idempotencyCache.saveResult(idempotencyKey, statusCode, body, finalStatus);
        }

        // Call the original Express json method to send the response to the client
        return originalJson(body);
    };

    // Proceed to the business logic controller
    next();
};

// ==========================================
// APPLICATION SETUP & ROUTING
// ==========================================

const app = express();
app.use(express.json());

/**
 * SaaS Billing Route: Charges a customer's payment method.
 * Protected by the idempotency middleware.
 */
app.post('/api/v1/billing/charge', idempotencyMiddleware, (req: IdempotentRequest, res: Response) => {
    const { customerId, amountCents, currency } = req.body;

    // Basic payload validation
    if (!customerId || !amountCents || !currency) {
        res.status(400).json({ error: 'INVALID_PAYLOAD', message: 'Missing required billing fields.' });
        return;
    }

    console.log(`[LEDGER] Executing charge of ${amountCents} ${currency} for customer ${customerId}...`);

    // Simulate occasional downstream payment processor delay/logic
    // In a real system, this is where double-entry ledger accounts are debited/credited.
    const transactionId = `txn_${Math.random().toString(36).substring(2, 11)}`;

    // Return successful billing response
    res.status(201).json({
        success: true,
        transactionId,
        customerId,
        amountCents,
        currency,
        processedAt: new Date().toISOString()
    });
});

// Start server if run directly
if (require.main === module) {
    const PORT = 3000;
    app.listen(PORT, () => {
        console.log(`FinTech API Gateway running on port ${PORT}`);
    });
}
