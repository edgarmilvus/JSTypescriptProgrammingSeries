/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import Redis from 'ioredis';
import { z } from 'zod';

// Initialize Redis client for caching idempotency states and holding locks
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Define the payload validation schema using Zod to guarantee structural integrity
const PaymentRequestSchema = z.object({
  amount: z.number().positive({ message: 'Amount must be a positive number' }),
  currency: z.string().length(3, { message: 'Currency must be a 3-letter ISO code' }),
  sourceAccount: z.string().uuid({ message: 'Source account must be a valid UUID' }),
  destinationAccount: z.string().uuid({ message: 'Destination account must be a valid UUID' }),
});

type PaymentRequest = z.infer<typeof PaymentRequestSchema>;

/**
 * Represents the stored execution state of an idempotent operation.
 */
interface IdempotentRecord {
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  statusCode?: number;
  responseBody?: unknown;
}

/**
 * Executes a simulated double-entry ledger transaction.
 * In a real-world system, this interacts with a relational database inside a serializable transaction.
 */
async function executeLedgerTransaction(payload: PaymentRequest) {
  // Simulate database latency and atomic double-entry ledger posting
  await new Promise((resolve) => setTimeout(resolve, 400));

  // Mock processing failure for demonstration of error handling
  if (payload.amount > 100000) {
    throw new Error('Insufficient liquidity in source account for high-value transfer.');
  }

  return {
    transactionId: `txn_${Math.random().toString(36).substring(2, 11)}`,
    status: 'POSTED',
    postedAt: new Date().toISOString(),
    ...payload,
  };
}

/**
 * Next.js API Route Handler for Idempotent Payments
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  // 1. Extract and validate the Idempotency-Key header mandatory for mutating requests
  const idempotencyKey = req.headers.get('idempotency-key');
  if (!idempotencyKey) {
    return NextResponse.json(
      { error: 'Missing required header: Idempotency-Key' },
      { status: 400 }
    );
  }

  // 2. Parse and validate the incoming JSON payload against the Zod schema
  let rawBody: unknown;
  try {
    rawBody = await req.json();
  } catch {
    return NextResponse.json(
      { error: 'Malformed JSON payload in request body' },
      { status: 400 }
    );
  }

  const parseResult = PaymentRequestSchema.safeParse(rawBody);
  if (!parseResult.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: parseResult.error.format() },
      { status: 422 }
    );
  }

  const paymentData = parseResult.data;
  const cacheKey = `idempotency:${idempotencyKey}`;
  const lockKey = `lock:${idempotencyKey}`;
  const clientIdentifier = req.headers.get('x-client-id') || 'anonymous';

  try {
    // 3. Check if the idempotency key already exists in Redis
    const cachedRecord = await redis.get(cacheKey);
    if (cachedRecord) {
      const record: IdempotentRecord = JSON.parse(cachedRecord);

      // If the request is still processing concurrently, return a Conflict response
      if (record.status === 'PENDING') {
        return NextResponse.json(
          { error: 'Concurrent request processing for this idempotency key. Please retry shortly.' },
          { status: 409 }
        );
      }

      // If already completed or failed, return the exact cached response (Replay mechanism)
      return NextResponse.json(record.responseBody, { status: record.statusCode });
    }

    // 4. Acquire a distributed lock using Redis SET NX with a TTL to prevent deadlocks
    // Lock expires in 5 seconds, ensuring safety if the worker crashes mid-execution
    const acquiredLock = await redis.set(lockKey, clientIdentifier, 'EX', 5, 'NX');
    if (!acquiredLock) {
      return NextResponse.json(
        { error: 'Concurrent request collision detected. Lock acquisition failed.' },
        { status: 409 }
      );
    }

    // 5. Atomically mark the idempotency key as PENDING in Redis
    const pendingRecord: IdempotentRecord = { status: 'PENDING' };
    await redis.set(cacheKey, JSON.stringify(pendingRecord), 'EX', 86400); // Retain for 24 hours

    let responseBody: unknown;
    let responseStatus = 200;

    try {
      // 6. Execute core business logic (Double-entry ledger processing)
      const ledgerResult = await executeLedgerTransaction(paymentData);
      responseBody = { success: true, data: ledgerResult };
      responseStatus = 201;

      // 7. Update Redis cache with the SUCCESSFUL response
      const completedRecord: IdempotentRecord = {
        status: 'COMPLETED',
        statusCode: responseStatus,
        responseBody,
      };
      await redis.set(cacheKey, JSON.stringify(completedRecord), 'EX', 86400);
    } catch (businessError: unknown) {
      // Handle domain or execution failures gracefully, caching the failure state
      const errorMessage = businessError instanceof Error ? businessError.message : 'Unknown error';
      responseBody = { success: false, error: errorMessage };
      responseStatus = 422;

      const failedRecord: IdempotentRecord = {
        status: 'FAILED',
        statusCode: responseStatus,
        responseBody,
      };
      await redis.set(cacheKey, JSON.stringify(failedRecord), 'EX', 86400);
    } finally {
      // 8. Release the distributed lock safely using a Lua script or direct deletion if lock is held by client
      const currentLockHolder = await redis.get(lockKey);
      if (currentLockHolder === clientIdentifier) {
        await redis.del(lockKey);
      }
    }

    return NextResponse.json(responseBody, { status: responseStatus });

  } catch (infrastructureError: unknown) {
    // Catch-all for Redis or unexpected infrastructural failures
    console.error('Critical infrastructure failure in idempotency pipeline:', infrastructureError);
    return NextResponse.json(
      { error: 'Internal gateway error during idempotency evaluation.' },
      { status: 500 }
    );
  }
}
