/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response, NextFunction } from 'express';
import Redis from 'ioredis';

// Extend Express Request to include the idempotency key type
declare global {
  namespace Express {
    interface Request {
      idempotencyKey?: string;
    }
  }
}

interface IdempotencyMiddlewareOptions {
  redisClient: Redis;
  ttlSeconds?: number;
}

/**
 * Creates an Express middleware for handling idempotent payment requests.
 */
export function idempotencyMiddleware(options: IdempotencyMiddlewareOptions) {
  const { redisClient, ttlSeconds = 86400 } = options;

  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const idempotencyKey = req.headers['idempotency-key'] as string;

    // 1. Extract and validate Idempotency-Key header
    if (!idempotencyKey || typeof idempotencyKey !== 'string') {
      res.status(400).json({ error: 'Missing or invalid Idempotency-Key header' });
      return;
    }

    req.idempotencyKey = idempotencyKey;
    const redisKey = `idempotency:${idempotencyKey}`;

    try {
      // 2. Attempt atomic Redis SET with NX and PX flags (60s lock for processing state)
      const acquired = await redisClient.set(
        redisKey,
        JSON.stringify({ status: 'PROCESSING' }),
        'NX',
        'PX',
        60000
      );

      if (!acquired) {
        // Key exists, fetch current state
        const cachedData = await redisClient.get(redisKey);
        if (!cachedData) {
          res.status(500).json({ error: 'Internal idempotency error' });
          return;
        }

        const parsed = JSON.parse(cachedData);

        // 3. Handle 'PROCESSING' and 'COMPLETED' states
        if (parsed.status === 'PROCESSING') {
          res.status(409).json({ error: 'Concurrent request in progress' });
          return;
        }

        if (parsed.status === 'COMPLETED') {
          res.status(parsed.statusCode).set(parsed.headers).json(parsed.body);
          return;
        }
      }

      // 4. Intercept res.json / res.send to cache the successful response
      const originalJson = res.json.bind(res);
      let responseBody: any;
      let responseStatusCode = 200;

      res.status = (code: number) => {
        responseStatusCode = code;
        return res;
      };

      res.json = (body: any) => {
        responseBody = body;
        
        // Execute caching asynchronously or synchronously before sending response
        const payload = {
          status: 'COMPLETED',
          statusCode: responseStatusCode,
          headers: { 'Content-Type': 'application/json' },
          body: responseBody,
        };

        // Update Redis state with completed payload and extend TTL
        redisClient.set(redisKey, JSON.stringify(payload), 'EX', ttlSeconds).catch((err) => {
          console.error('Failed to cache idempotency response:', err);
        });

        return originalJson(body);
      };

      next();
    } catch (error) {
      // 4. Error Rollback: Clear Redis lock on unhandled pipeline failure
      await redisClient.del(redisKey).catch(() => {});
      next(error);
    }
  };
}
