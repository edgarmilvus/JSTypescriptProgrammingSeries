/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type StateMatrix<TState extends string, TEvent extends string> = {
  [K in TState]?: {
    [E in TEvent]?: TState;
  };
};

export class InvalidTransitionError extends Error {
  constructor(currentState: string, event: string) {
    super(`Invalid transition: Cannot execute event '${event}' from state '${currentState}'`);
    this.name = 'InvalidTransitionError';
  }
}

export class PaymentStateMachine<
  TState extends string,
  TEvent extends string
> {
  private currentState: TState;
  private readonly matrix: StateMatrix<TState, TEvent>;
  private readonly history: Array<{ from: TState; to: TState; event: TEvent; timestamp: Date }> = [];

  constructor(initialState: TState, matrix: StateMatrix<TState, TEvent>) {
    this.currentState = initialState;
    this.matrix = matrix;
  }

  public getState(): TState {
    return this.currentState;
  }

  public getHistory(): ReadonlyArray<{ from: TState; to: TState; event: TEvent; timestamp: Date }> {
    return this.history;
  }

  public async transition(event: TEvent, guard?: () => Promise<boolean> | boolean): Promise<TState> {
    const allowedTransitions = this.matrix[this.currentState];
    const nextState = allowedTransitions ? allowedTransitions[event] : undefined;

    // 1. Check if the transition is defined in the matrix for the current state
    if (!nextState) {
      throw new InvalidTransitionError(this.currentState, event);
    }

    // 2. Execute the guard function if provided
    if (guard) {
      const canTransition = await guard();
      if (!canTransition) {
        throw new Error(`Guard condition failed for transition event '${event}' from state '${this.currentState}'`);
      }
    }

    const previousState = this.currentState;
    
    // 3. Update currentState and record the history entry
    this.currentState = nextState;
    this.history.push({
      from: previousState,
      to: nextState,
      event,
      timestamp: new Date(),
    });

    return this.currentState;
  }
}
