/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

interface OptimisticPaymentButtonProps {
  amount: number;
  currency: string;
  idempotencyKey: string;
  onExecutePayment: (key: string) => Promise<void>;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export const OptimisticPaymentButton: React.FC<OptimisticPaymentButtonProps> = ({
  amount,
  currency,
  idempotencyKey,
  onExecutePayment,
  onSuccess,
  onError,
}) => {
  const [status, setStatus] = useState<'IDLE' | 'OPTIMISTIC_SUCCESS' | 'CONFIRMED' | 'ERROR'>('IDLE');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleClick = async () => {
    // 1. Immediately set status to 'OPTIMISTIC_SUCCESS' for instant feedback
    setStatus('OPTIMISTIC_SUCCESS');
    setErrorMessage(null);

    startTransition(async () => {
      try {
        // 2. Execute asynchronous payment call in the background
        await onExecutePayment(idempotencyKey);
        
        // 4. Confirm state on successful resolution
        setStatus('CONFIRMED');
        if (onSuccess) onSuccess();
      } catch (err: any) {
        // 3. Catch errors, rollback status to 'ERROR', and trigger onError callback
        setStatus('ERROR');
        setErrorMessage(err.message || 'Unknown payment error occurred');
        if (onError) onError(err);
      }
    });
  };

  return (
    <div className="payment-container">
      <button 
        onClick={handleClick} 
        disabled={status === 'OPTIMISTIC_SUCCESS' || isPending}
        className={`payment-btn ${status.toLowerCase()}`}
      >
        {status === 'OPTIMISTIC_SUCCESS' ? 'Processing Payment...' : `Pay ${currency} ${amount}`}
      </button>

      {status === 'ERROR' && errorMessage && (
        <div className="error-banner" role="alert">
          <span>Payment Failed: {errorMessage}</span>
          <button onClick={() => setStatus('IDLE')}>Retry</button>
        </div>
      )}

      {status === 'CONFIRMED' && (
        <div className="success-banner">
          <span>Payment successfully recorded!</span>
        </div>
      )}
    </div>
  );
};
