/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Pool, PoolClient } from 'pg';
import Redis from 'ioredis';

interface TransferRequest {
  sourceAccountId: string;
  destinationAccountId: string;
  amount: bigint; // Using BigInt for precision math
  currency: string;
  idempotencyKey: string;
}

interface TransferResult {
  journalId: string;
  status: 'COMMITTED' | 'REPLAYED';
}

export class LedgerService {
  private dbPool: Pool;
  private redisClient: Redis;

  constructor(dbPool: Pool, redisClient: Redis) {
    this.dbPool = dbPool;
    this.redisClient = redisClient;
  }

  public async transfer(request: TransferRequest): Promise<TransferResult> {
    const { sourceAccountId, destinationAccountId, amount, currency, idempotencyKey } = request;
    const redisKey = `ledger:idempotency:${idempotencyKey}`;

    // 1. Check Redis idempotency lock and cache
    const existingLock = await this.redisClient.get(redisKey);
    if (existingLock) {
      const parsed = JSON.parse(existingLock);
      if (parsed.status === 'PROCESSING') {
        throw new Error('Concurrent transfer execution in progress');
      }
      if (parsed.status === 'COMMITTED') {
        return { journalId: parsed.journalId, status: 'REPLAYED' };
      }
    }

    // Acquire processing lock in Redis
    await this.redisClient.set(redisKey, JSON.stringify({ status: 'PROCESSING' }), 'EX', 60);

    const client: PoolClient = await this.dbPool.connect();

    try {
      // 2. Begin PostgreSQL Transaction
      await client.query('BEGIN');

      // 3. Lock accounts to prevent race conditions (SELECT ... FOR UPDATE)
      // Order accounts deterministically by ID to prevent deadlocks
      const [firstId, secondId] = [sourceAccountId, destinationAccountId].sort();
      
      const accountQuery = `SELECT id, balance FROM accounts WHERE id = ANY($1::uuid[]) FOR UPDATE`;
      const accountResult = await client.query(accountQuery, [[firstId, secondId]]);

      if (accountResult.rows.length !== 2) {
        throw new Error('One or more accounts not found');
      }

      const accountsMap = new Map(accountResult.rows.map(row => [row.id, BigInt(row.balance)]));
      const sourceBalance = accountsMap.get(sourceAccountId)!;

      // 4. Verify sufficient funds in source account
      if (sourceBalance < amount) {
        throw new Error('Insufficient funds in source account');
      }

      // 5. Insert journal entry and posting lines (double-entry bookkeeping)
      const journalInsert = `INSERT INTO journals (currency, description) VALUES ($1, $2) RETURNING id`;
      const journalResult = await client.query(journalInsert, [currency, 'Automated transfer']);
      const journalId = journalResult.rows[0].id;

      const postingInsert = `
        INSERT INTO postings (journal_id, account_id, amount) 
        VALUES 
        ($1, $2, $3), 
        ($1, $4, $5)
      `;
      // Debit source account (negative amount) and credit destination account (positive amount)
      await client.query(postingInsert, [
        journalId,
        sourceAccountId,
        -amount.toString(),
        destinationAccountId,
        amount.toString()
      ]);

      // Update actual balances
      await client.query(`UPDATE accounts SET balance = balance - $1 WHERE id = $2`, [amount.toString(), sourceAccountId]);
      await client.query(`UPDATE accounts SET balance = balance + $1 WHERE id = $2`, [amount.toString(), destinationAccountId]);

      // 6. Commit transaction
      await client.query('COMMIT');

      // Update Redis cache with committed result (24h TTL)
      const successPayload = { status: 'COMMITTED', journalId };
      await this.redisClient.set(redisKey, JSON.stringify(successPayload), 'EX', 86400);

      return { journalId, status: 'COMMITTED' };
    } catch (error) {
      // Rollback database transaction and clear Redis lock on failure
      await client.query('ROLLBACK');
      await this.redisClient.del(redisKey).catch(() => {});
      throw error;
    } finally {
      // 7. Ensure proper client release back to pool
      client.release();
    }
  }
}
