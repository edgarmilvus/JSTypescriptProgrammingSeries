/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import { Pool, PoolClient } from 'pg';
import Redis from 'ioredis';

interface TransferRequest {
  sourceAccountId: string;
  destinationAccountId: string;
  amount: bigint; // Using BigInt for precision math
  currency: string;
  idempotencyKey: string;
}

interface TransferResult {
  journalId: string;
  status: 'COMMITTED' | 'REPLAYED';
}

export class LedgerService {
  private dbPool: Pool;
  private redisClient: Redis;

  constructor(dbPool: Pool, redisClient: Redis) {
    this.dbPool = dbPool;
    this.redisClient = redisClient;
  }

  public async transfer(request: TransferRequest): Promise<TransferResult> {
    const { sourceAccountId, destinationAccountId, amount, currency, idempotencyKey } = request;

    // TODO: Implement atomic double-entry transfer pipeline
    // 1. Check Redis idempotency lock and cache
    // 2. Acquire PG client and begin transaction
    // 3. Lock accounts to prevent race conditions (SELECT ... FOR UPDATE)
    // 4. Verify sufficient funds in source account
    // 5. Insert journal entry and posting lines (debit and credit)
    // 6. Commit transaction and update Redis cache with success status
    // 7. Ensure proper try/catch/finally block for rollbacks and client release
    
    throw new Error('Not implemented');
  }
}
