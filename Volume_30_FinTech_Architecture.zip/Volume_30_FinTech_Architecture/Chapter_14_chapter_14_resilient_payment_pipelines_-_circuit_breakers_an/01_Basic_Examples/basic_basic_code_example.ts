/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file paymentPipeline.ts
 * @description A self-contained, enterprise-grade payment pipeline featuring an immutable 
 * configuration pattern, exponential backoff with jitter, and a runtime circuit breaker 
 * designed for high-reliability SaaS architectures.
 */

// ============================================================================
// Types & Interfaces
// ============================================================================

/**
 * Represents the immutable configuration parameters for the payment execution pipeline.
 */
interface PipelineConfig {
  readonly maxRetries: number;
  readonly baseDelayMs: number;
  readonly maxDelayMs: number;
  readonly failureThreshold: number;
  readonly resetTimeoutMs: number;
}

/**
 * The payload required to process a single billing transaction.
 */
interface ChargeRequest {
  readonly transactionId: string;
  readonly customerId: string;
  readonly amountCents: number;
  readonly currency: string;
}

/**
 * The standard response returned by the payment gateway or pipeline wrapper.
 */
interface ChargeResult {
  readonly success: boolean;
  readonly transactionId: string;
  readonly providerReference?: string;
  readonly errorMessage?: string;
  readonly attemptsMade: number;
}

/**
 * Internal states of the Circuit Breaker lifecycle.
 */
enum CircuitState {
  CLOSED = 'CLOSED',       // Normal operation; requests pass through.
  OPEN = 'OPEN',           // Failing state; requests fail fast without calling gateway.
  HALF_OPEN = 'HALF_OPEN'  // Probe state; testing if downstream recovery has occurred.
}

// ============================================================================
// Circuit Breaker & Retry Pipeline Implementation
// ============================================================================

/**
 * ResilientPaymentPipeline manages the execution of financial transactions, 
 * shielding the core ledger from cascading downstream gateway outages.
 */
class ResilientPaymentPipeline {
  // Immutable configuration using TypeScript's readonly modifier
  private readonly config: PipelineConfig;
  
  // Circuit breaker mutable runtime state
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount: number = 0;
  private lastFailureTimestamp: number = 0;
  private successProbeCount: number = 0;

  /**
   * Initializes the pipeline with immutable operational parameters.
   * @param customConfig Partial configuration overrides.
   */
  constructor(customConfig?: Partial<PipelineConfig>) {
    this.config = Object.freeze({
      maxRetries: 3,
      baseDelayMs: 500,
      maxDelayMs: 10000,
      failureThreshold: 5,
      resetTimeoutMs: 30000,
      ...customConfig,
    });
  }

  /**
   * Executes a payment request against an external gateway with integrated 
   * circuit breaker state evaluation and exponential backoff retry mechanics.
   * 
   * @param request The charge transaction payload.
   * @returns A promise resolving to the final charge result.
   */
  public async executeCharge(request: ChargeRequest): Promise<ChargeResult> {
    // Step 1: Evaluate and potentially transition the Circuit Breaker state
    this.evaluateCircuitState();

    if (this.state === CircuitState.OPEN) {
      console.warn(`[CircuitBreaker] Circuit is OPEN. Fast-failing transaction ${request.transactionId}`);
      return {
        success: false,
        transactionId: request.transactionId,
        errorMessage: 'Payment gateway temporarily unavailable (Circuit Breaker OPEN)',
        attemptsMade: 0,
      };
    }

    let attempt = 0;
    let lastError: Error | null = null;

    // Step 2: Execute retry loop with Exponential Backoff + Jitter
    while (attempt < this.config.maxRetries) {
      attempt++;
      try {
        console.log(`[Pipeline] Processing transaction ${request.transactionId} | Attempt ${attempt}/${this.config.maxRetries}`);
        
        // Invoke downstream mock payment gateway
        const gatewayResponse = await this.mockGatewayCall(request);

        // Step 3: Handle successful execution
        this.handleSuccess();
        return {
          success: true,
          transactionId: request.transactionId,
          providerReference: gatewayResponse.reference,
          attemptsMade: attempt,
        };

      } catch (error: any) {
        lastError = error;
        console.warn(`[Pipeline] Attempt ${attempt} failed for ${request.transactionId}: ${error.message}`);

        // If this is the last attempt, do not sleep; break out to handle failure
        if (attempt >= this.config.maxRetries) {
          break;
        }

        // Calculate backoff duration with full jitter
        const delay = this.calculateBackoffWithJitter(attempt);
        console.log(`[Pipeline] Retrying in ${delay.toFixed(2)}ms...`);
        await this.delay(delay);
      }
    }

    // Step 4: Handle terminal failure after exhausting all retries
    this.handleFailure();
    return {
      success: false,
      transactionId: request.transactionId,
      errorMessage: lastError?.message || 'Unknown payment processing error',
      attemptsMade: attempt,
    };
  }

  /**
   * Evaluates if an OPEN circuit should transition to HALF_OPEN based on elapsed time.
   */
  private evaluateCircuitState(): void {
    const now = Date.now();
    if (this.state === CircuitState.OPEN) {
      if (now - this.lastFailureTimestamp >= this.config.resetTimeoutMs) {
        console.info('[CircuitBreaker] Reset timeout elapsed. Transitioning from OPEN to HALF_OPEN.');
        this.state = CircuitState.HALF_OPEN;
        this.successProbeCount = 0;
      }
    }
  }

  /**
   * Records a successful execution, resetting circuit breaker metrics if necessary.
   */
  private handleSuccess(): void {
    if (this.state === CircuitState.HALF_OPEN) {
      this.successProbeCount++;
      // If we receive consecutive successes in half-open, close the circuit completely
      if (this.successProbeCount >= 2) {
        console.info('[CircuitBreaker] Probe successful. Transitioning from HALF_OPEN to CLOSED.');
        this.state = CircuitState.CLOSED;
        this.failureCount = 0;
        this.successProbeCount = 0;
      }
    } else if (this.state === CircuitState.CLOSED) {
      // Decay failure count on successful requests during normal operations
      this.failureCount = Math.max(0, this.failureCount - 1);
    }
  }

  /**
   * Records a terminal failure, updating thresholds and potentially tripping the circuit.
   */
  private handleFailure(): void {
    this.failureCount++;
    this.lastFailureTimestamp = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      console.warn('[CircuitBreaker] Probe failed in HALF_OPEN state. Tripping back to OPEN.');
      this.state = CircuitState.OPEN;
    } else if (this.state === CircuitState.CLOSED && this.failureCount >= this.config.failureThreshold) {
      console.error(`[CircuitBreaker] Failure threshold reached (${this.failureCount}/${this.config.failureThreshold}). Tripping circuit to OPEN.`);
      this.state = CircuitState.OPEN;
    }
  }

  /**
   * Computes exponential backoff delay with randomized full jitter to prevent thundering herds.
   * Formula: Random(0, Min(maxDelayMs, baseDelayMs * 2^(attempt - 1)))
   */
  private calculateBackoffWithJitter(attempt: number): number {
    const exponentialMultiplier = Math.pow(2, attempt - 1);
    const rawDelay = this.config.baseDelayMs * exponentialMultiplier;
    const cappedDelay = Math.min(this.config.maxDelayMs, rawDelay);
    // Apply full jitter: random value between 0 and cappedDelay
    return Math.random() * cappedDelay;
  }

  /**
   * Utility helper to pause execution async.
   */
  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Simulates an external payment gateway call that intermittently fails due to network partitions.
   */
  private async mockGatewayCall(request: ChargeRequest): Promise<{ reference: string }> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate random gateway degradation (70% failure rate for demonstration)
        const isNetworkError = Math.random() < 0.70;
        if (isNetworkError) {
          reject(new Error('Gateway Timeout: 504 Gateway Gateway Error'));
        } else {
          resolve({ reference: `gw_ref_${Math.random().toString(36).substring(2, 11)}` });
        }
      }, 100);
    });
  }

  /**
   * Exposes current pipeline metrics for monitoring and health check endpoints.
   */
  public getMetrics() {
    return {
      state: this.state,
      failureCount: this.failureCount,
      lastFailureTimestamp: this.lastFailureTimestamp,
    };
  }
}

// ============================================================================
Usage Example (SaaS Webhook / Billing Cron Worker)
// ============================================================================

async function runSaaSBillingJob() {
  // Instantiate pipeline with immutable config
  const billingPipeline = new ResilientPaymentPipeline({
    maxRetries: 3,
    baseDelayMs: 200,
    failureThreshold: 3,
    resetTimeoutMs: 5000,
  });

  const sampleCharge: ChargeRequest = {
    transactionId: 'tx_109823491823',
    customerId: 'cust_saas_9981',
    amountCents: 4999, // $49.99 SaaS Subscription Fee
    currency: 'USD',
  };

  console.log('--- Initiating SaaS Billing Pipeline Execution ---');
  const result = await billingPipeline.executeCharge(sampleCharge);
  console.log('--- Pipeline Execution Completed ---');
  console.log(JSON.stringify(result, null, 2));
}

// Execute the simulation if run directly
runSaaSBillingJob();
