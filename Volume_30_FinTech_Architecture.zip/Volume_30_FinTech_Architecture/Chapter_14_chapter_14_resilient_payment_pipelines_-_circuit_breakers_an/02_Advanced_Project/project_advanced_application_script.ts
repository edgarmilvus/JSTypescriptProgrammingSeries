/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file payment-pipeline.ts
 * @description Enterprise-grade payment execution pipeline featuring an asynchronous 
 * Circuit Breaker, Exponential Backoff with Full Jitter, and Precision Double-Entry Logging.
 * Context: Next.js API Route / Server Action execution context.
 */

import { performance } from 'perf_hooks';

// ============================================================================
// TYPES & INTERfACES
// ============================================================================

export type CurrencyCode = 'USD' | 'EUR' | 'GBP';

export interface Money {
  amount: number; // Expressed in minor units (e.g., cents) to prevent floating-point drift
  currency: CurrencyCode;
}

export interface PaymentRequest {
  transactionId: string;
  sourceAccount: string;
  destinationAccount: string;
  amount: Money;
  idempotencyKey: string;
}

export interface PaymentResult {
  success: boolean;
  gatewayTransactionId?: string;
  error?: string;
  latencyMs: number;
}

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerOptions {
  failureThreshold: number;      // Number of failures before tripping to OPEN
  successThreshold: number;      // Number of successes in HALF_OPEN before returning to CLOSED
  cooldownPeriodMs: number;      // Time to wait in OPEN state before testing with HALF_OPEN
  requestTimeoutMs: number;      // Maximum allowed execution time per attempt
}

export interface RetryOptions {
  maxRetries: number;            // Maximum number of retry attempts
  baseDelayMs: number;           // Initial backoff delay in milliseconds
  maxDelayMs: number;            // Maximum upper bound for backoff delay
}

// ============================================================================
// CORE PAYMENT PIPELINE IMPLEMENTATION
// ============================================================================

/**
 * Simulates a downstream payment gateway call with potential transient network errors.
 */
async function mockGatewayExecution(request: PaymentRequest): Promise<PaymentResult> {
  const start = performance.now();
  
  // Simulate random latency and occasional provider failure (HTTP 503 / Timeout)
  const randomValue = Math.random();
  await new Promise((resolve) => setTimeout(resolve, 150 + Math.random() * 100));

  if (randomValue < 0.4) {
    throw new Error('GATEWAY_TIMEOUT: Upstream provider failed to respond within 200ms');
  }

  return {
    success: true,
    gatewayTransactionId: `gw_txn_${Math.random().toString(36).substring(2, 11)}`,
    latencyMs: Math.round(performance.now() - start),
  };
}

/**
 * Circuit Breaker implementation managing payment gateway health states.
 */
export class PaymentCircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private failureCount: number = 0;
  private successCount: number = 0;
  private nextAttemptTimestamp: number = 0;

  constructor(private options: CircuitBreakerOptions) {}

  /**
   * Evaluates current circuit state and routes execution accordingly.
   */
  public async execute(request: PaymentRequest, retryOpts: RetryOptions): Promise<PaymentResult> {
    this.evaluateStateTransition();

    if (this.state === 'OPEN') {
      throw new Error(`CIRCUIT_BREAKER_OPEN: Gateway is isolated. Fast-failing transaction ${request.transactionId}`);
    }

    try {
      // Execute operation with timeout wrapper and exponential backoff
      const result = await this.executeWithRetryAndTimeout(request, retryOpts);
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  /**
   * Enforces state machine transition rules based on time and thresholds.
   */
  private evaluateStateTransition(): void {
    const now = Date.now();
    if (this.state === 'OPEN' && now >= this.nextAttemptTimestamp) {
      this.state = 'HALF_OPEN';
      this.successCount = 0;
      console.warn('[CircuitBreaker] Transitioned from OPEN to HALF_OPEN. Probing gateway...');
    }
  }

  /**
   * Handles successful transaction execution.
   */
  private onSuccess(): void {
    this.failureCount = 0;
    if (this.state === 'HALF_OPEN') {
      this.successCount++;
      if (this.successCount >= this.options.successThreshold) {
        this.state = 'CLOSED';
        console.info('[CircuitBreaker] Gateway recovered. Transitioned from HALF_OPEN to CLOSED.');
      }
    }
  }

  /**
   * Handles transaction failures and trips circuit if threshold is reached.
   */
  private onFailure(): void {
    this.failureCount++;
    if (this.state === 'HALF_OPEN' || this.failureCount >= this.options.failureThreshold) {
      this.state = 'OPEN';
      this.nextAttemptTimestamp = Date.now() + this.options.cooldownPeriodMs;
      console.error(
        `[CircuitBreaker] Threshold breached (${this.failureCount} failures). Tripping circuit to OPEN until ${new Date(
          this.nextAttemptTimestamp
        ).toISOString()}`
      );
    }
  }

  /**
   * Executes the payment request with exponential backoff, full jitter, and timeout protection.
   */
  private async executeWithRetryAndTimeout(request: PaymentRequest, retryOpts: RetryOptions): Promise<PaymentResult> {
    let attempt = 0;

    while (true) {
      attempt++;
      try {
        return await this.invokeWithTimeout(request);
      } catch (error: any) {
        if (attempt > retryOpts.maxRetries) {
          console.error(`[PaymentPipeline] Max retries (${retryOpts.maxRetries}) exhausted for transaction ${request.transactionId}`);
          throw error;
        }

        // Calculate Exponential Backoff with Full Jitter: Sleep = random_between(0, min(max_delay, base_delay * 2^attempt))
        const exponentialDelay = retryOpts.baseDelayMs * Math.pow(2, attempt - 1);
        const cappedDelay = Math.min(retryOpts.maxDelayMs, exponentialDelay);
        const jitteredDelay = Math.random() * cappedDelay;

        console.warn(
          `[PaymentPipeline] Attempt ${attempt} failed for txn ${request.transactionId}: ${error.message}. Retrying in ${Math.round(
            jitteredDelay
          )}ms...`
        );

        await new Promise((resolve) => setTimeout(resolve, jitteredDelay));
      }
    }
  }

  /**
   * Wraps the gateway call with a strict execution timeout.
   */
  private invokeWithTimeout(request: PaymentRequest): Promise<PaymentResult> {
    return new Promise((resolve, reject) => {
      let isCompleted = false;

      const timer = setTimeout(() => {
        if (!isCompleted) {
          isCompleted = true;
          reject(new Error(`GATEWAY_TIMEOUT: Operation exceeded ${this.options.requestTimeoutMs}ms limit`));
        }
      }, this.options.requestTimeoutMs);

      mockGatewayExecution(request)
        .then((result) => {
          if (!isCompleted) {
            isCompleted = true;
            clearTimeout(timer);
            resolve(result);
          }
        })
        .catch((error) => {
          if (!isCompleted) {
            isCompleted = true;
            clearTimeout(timer);
            reject(error);
          }
        });
    });
  }

  public getState(): CircuitState {
    return this.state;
  }
}

// ============================================================================
// EXECUTION DEMONSTRATION
// ============================================================================

export async function processEnterprisePayment(request: PaymentRequest): Promise<void> {
  const breaker = new PaymentCircuitBreaker({
    failureThreshold: 3,
    successThreshold: 2,
    cooldownPeriodMs: 5000,
    requestTimeoutMs: 300,
  });

  const retryConfig: RetryOptions = {
    maxRetries: 3,
    baseDelayMs: 100,
    maxDelayMs: 2000,
  };

  try {
    console.info(`[Ledger] Initiating double-entry hold for transaction: ${request.transactionId}`);
    const result = await breaker.execute(request, retryConfig);
    console.info(`[Ledger] Payment successfully settled. Gateway ID: ${result.gatewayTransactionId} (Latency: ${result.latencyMs}ms)`);
  } catch (error: any) {
    console.error(`[Ledger] Payment pipeline failed permanently. Rolling back ledger state. Reason: ${error.message}`);
  }
}
