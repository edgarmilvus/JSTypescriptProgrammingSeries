/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  factor: number;
  shouldRetry: (error: unknown) => boolean;
  onRetry?: (info: { attempt: number; delayMs: number; error: unknown }) => void;
}

export async function executeWithRetry<T>(
  action: () => Promise<T>,
  options: RetryOptions
): Promise<T> {
  let attempt = 0;

  while (true) {
    try {
      return await action();
    } catch (error) {
      attempt++;

      if (attempt > options.maxRetries || !options.shouldRetry(error)) {
        throw error;
      }

      // Calculate exponential backoff with ceiling limit
      const exponentialDelay = options.baseDelayMs * Math.pow(options.factor, attempt - 1);
      const cappedDelay = Math.min(options.maxDelayMs, exponentialDelay);

      // Apply Full Jitter: random value between 0 and cappedDelay
      const jitteredDelay = Math.random() * cappedDelay;

      if (options.onRetry) {
        options.onRetry({
          attempt,
          delayMs: Math.round(jitteredDelay),
          error,
        });
      }

      await new Promise((resolve) => setTimeout(resolve, jitteredDelay));
    }
  }
}

// --- Mock Payment Gateway Example ---
async function mockPaymentGatewayCall(): Promise<string> {
  const isTransientFailure = Math.random() > 0.3;
  if (isTransientFailure) {
    throw new Error("HTTP 503: Service Unavailable");
  }
  return "TXN_SUCCESS_987654";
}

// Execution wrapper demonstration
export async function processPaymentWithResilience(correlationId: string) {
  return executeWithRetry(mockPaymentGatewayCall, {
    maxRetries: 3,
    baseDelayMs: 200,
    maxDelayMs: 5000,
    factor: 2,
    shouldRetry: (err: unknown) => {
      if (err instanceof Error) {
        return err.message.includes("503") || err.message.includes("TIMEOUT");
      }
      return false;
    },
    onRetry: ({ attempt, delayMs, error }) => {
      console.warn(
        JSON.stringify({
          level: "WARN",
          correlationId,
          message: "Payment gateway transient failure, retrying with jitter",
          attempt,
          delayMs,
          error: error instanceof Error ? error.message : String(error),
        })
      );
    },
  });
}
