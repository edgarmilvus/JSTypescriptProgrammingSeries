/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { EventEmitter } from "events";

export enum CircuitState {
  CLOSED = "CLOSED",
  OPEN = "OPEN",
  HALF_OPEN = "HALF_OPEN",
}

export interface CircuitBreakerOptions {
  failureThreshold: number;
  successThreshold: number;
  resetTimeoutMs: number;
  executionTimeoutMs: number;
}

export class CircuitOpenError extends Error {
  constructor(message = "Circuit breaker is OPEN. Execution aborted.") {
    super(message);
    this.name = "CircuitOpenError";
  }
}

export class PaymentCircuitBreaker extends EventEmitter {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private nextAttemptTimestamp = 0;
  private options: CircuitBreakerOptions;

  constructor(options: CircuitBreakerOptions) {
    super();
    this.options = options;
  }

  public getState(): CircuitState {
    return this.state;
  }

  public async exec<T>(action: () => Promise<T>): Promise<T> {
    this.checkStateTransition();

    if (this.state === CircuitState.OPEN) {
      this.emit("onReject", { state: this.state, timestamp: Date.now() });
      throw new CircuitOpenError();
    }

    try {
      const result = await this.executeWithTimeout(action);
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure(error);
      throw error;
    }
  }

  private checkStateTransition(): void {
    if (this.state === CircuitState.OPEN && Date.now() >= this.nextAttemptTimestamp) {
      this.transitionTo(CircuitState.HALF_OPEN);
      this.successCount = 0;
    }
  }

  private async executeWithTimeout<T>(action: () => Promise<T>): Promise<T> {
    let timeoutHandle: NodeJS.Timeout;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutHandle = setTimeout(
        () => reject(new Error("Gateway execution timed out")),
        this.options.executionTimeoutMs
      );
    });

    try {
      return await Promise.race([action(), timeoutPromise]);
    } finally {
      clearTimeout(timeoutHandle!);
    }
  }

  private onSuccess(): void {
    this.emit("onSuccess");
    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.options.successThreshold) {
        this.transitionTo(CircuitState.CLOSED);
      }
    } else if (this.state === CircuitState.CLOSED) {
      this.failureCount = 0; // Reset consecutive failures on success
    }
  }

  private onFailure(error: unknown): void {
    this.emit("onFailure", { error });
    this.failureCount++;

    if (this.state === CircuitState.HALF_OPEN) {
      this.transitionTo(CircuitState.OPEN);
    } else if (this.state === CircuitState.CLOSED && this.failureCount >= this.options.failureThreshold) {
      this.transitionTo(CircuitState.OPEN);
    }
  }

  private transitionTo(newState: CircuitState): void {
    const previousState = this.state;
    this.state = newState;

    if (newState === CircuitState.OPEN) {
      this.nextAttemptTimestamp = Date.now() + this.options.resetTimeoutMs;
      this.failureCount = 0;
    }

    this.emit("onStateChange", { previousState, newState, timestamp: Date.now() });
  }
}

// --- Webhook Telemetry Integration Demo ---
const breaker = new PaymentCircuitBreaker({
  failureThreshold: 3,
  successThreshold: 2,
  resetTimeoutMs: 10000,
  executionTimeoutMs: 3000,
});

breaker.on("onStateChange", ({ previousState, newState }) => {
  if (newState === CircuitState.OPEN) {
    console.error(`[ALERT] Gateway tripped from ${previousState} to OPEN. Paging Infrastructure Team.`);
  }
});
