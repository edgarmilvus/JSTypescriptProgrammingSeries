/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface LedgerTransactionRequest {
  idempotencyKey: string;
  amount: bigint;
  sourceAccount: string;
  destinationAccount: string;
}

export type TransactionStatus = "PENDING" | "SUCCESS" | "FAILED";

export interface LedgerRecord {
  status: TransactionStatus;
  result?: string;
  createdAt: number;
}

export class ConcurrentExecutionError extends Error {
  constructor(message = "Transaction with idempotency key is currently processing.") {
    super(message);
    this.name = "ConcurrentExecutionError";
  }
}

export class IdempotentPaymentPipeline {
  private ledgerStore = new Map<string, LedgerRecord>();
  private activeLocks = new Map<string, Promise<any>>();

  public async processTransaction(
    req: LedgerTransactionRequest,
    paymentAction: () => Promise<string>
  ): Promise<string> {
    // Ensure serial execution for identical idempotency keys using promise-chaining locks
    while (this.activeLocks.has(req.idempotencyKey)) {
      await this.activeLocks.get(req.idempotencyKey);
    }

    let releaseLock!: () => void;
    const lockPromise = new Promise((resolve) => {
      releaseLock = resolve;
    });
    this.activeLocks.set(req.idempotencyKey, lockPromise);

    try {
      const existingRecord = this.ledgerStore.get(req.idempotencyKey);

      if (existingRecord) {
        if (existingRecord.status === "SUCCESS" && existingRecord.result) {
          return existingRecord.result;
        }
        if (existingRecord.status === "PENDING") {
          throw new ConcurrentExecutionError();
        }
        if (existingRecord.status === "FAILED") {
          // Allow re-attempting if the previous attempt failed
        }
      }

      // Atomically set state to PENDING
      this.ledgerStore.set(req.idempotencyKey, {
        status: "PENDING",
        createdAt: Date.now(),
      });

      // Execute downstream financial operation
      const transactionId = await paymentAction();

      // Commit transaction state to ledger
      this.ledgerStore.set(req.idempotencyKey, {
        status: "SUCCESS",
        result: transactionId,
        createdAt: Date.now(),
      });

      return transactionId;
    } catch (error) {
      this.ledgerStore.set(req.idempotencyKey, {
        status: "FAILED",
        createdAt: Date.now(),
      });
      throw error;
    } finally {
      this.activeLocks.delete(req.idempotencyKey);
      releaseLock();
    }
  }
}
