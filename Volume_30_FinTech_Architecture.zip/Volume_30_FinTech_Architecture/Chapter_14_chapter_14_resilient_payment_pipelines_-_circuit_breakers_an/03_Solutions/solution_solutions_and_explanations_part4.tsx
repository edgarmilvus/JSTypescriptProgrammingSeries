/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from "react";

export type CircuitState = "CLOSED" | "OPEN" | "HALF_OPEN";

export interface GatewayMetric {
  id: string;
  name: string;
  status: CircuitState;
  failureRate: number;
  pendingRetries: number;
}

interface DashboardProps {
  initialGateways: GatewayMetric[];
}

// Simulated CPU-bound headless inference worker
async function runHealthInference(gateways: GatewayMetric[]): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const avgFailure = gateways.reduce((acc, g) => acc + g.failureRate, 0) / gateways.length;
      resolve(avgFailure > 15 ? "Status: Degraded (High Cascade Risk)" : "Status: Optimal Routing Stable");
    }, 800);
  });
}

export const PaymentPipelineDashboard: React.FC<DashboardProps> = ({ initialGateways }) => {
  const [gateways, setGateways] = useState<GatewayMetric[]>(initialGateways);
  const [inferenceResult, setInferenceResult] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [errorToast, setErrorToast] = useState<string | null>(null);

  const handleRunInference = () => {
    startTransition(async () => {
      const result = await runHealthInference(gateways);
      setInferenceResult(result);
    });
  };

  // Optimistic UI update for manual circuit breaker reset
  const handleOptimisticReset = (gatewayId: string) => {
    const previousGateways = [...gateways];

    // Optimistically apply HALF_OPEN state
    setGateways((prev) =>
      prev.map((g) => (g.id === gatewayId ? { ...g, status: "HALF_OPEN" } : g))
    );

    // Simulate network server action
    setTimeout(() => {
      const serverActionFailed = Math.random() < 0.2; // 20% simulated failure
      if (serverActionFailed) {
        // Rollback state and show correlation toast
        setGateways(previousGateways);
        setErrorToast(`Failed to reset gateway ${gatewayId}. Correlation ID: corr_${Date.now()}`);
      }
    }, 500);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h2>Payment Pipeline Operations Dashboard</h2>
      {errorToast && <div style={{ background: "#ffdddd", padding: "10px", margin: "10px 0" }}>{errorToast}</div>}

      <button onClick={handleRunInference} disabled={isPending} style={{ padding: "8px 16px" }}>
        {isPending ? "Running Diagnostic Inference..." : "Run Gateway Health Inference"}
      </button>

      {inferenceResult && <p><strong>Inference Output:</strong> {inferenceResult}</p>}

      <table style={{ width: "100%", marginTop: "20px", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#f4f4f4", textAlign: "left" }}>
            <th style={{ padding: "8px" }}>Gateway</th>
            <th style={{ padding: "8px" }}>Status</th>
            <th style={{ padding: "8px" }}>Failure Rate (%)</th>
            <th style={{ padding: "8px" }}>Pending Retries</th>
            <th style={{ padding: "8px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {gateways.map((gw) => (
            <tr key={gw.id} style={{ borderBottom: "1px solid #ddd" }}>
              <td style={{ padding: "8px" }}>{gw.name}</td>
              <td style={{ padding: "8px" }}>
                <span style={{ fontWeight: "bold", color: gw.status === "OPEN" ? "red" : gw.status === "HALF_OPEN" ? "orange" : "green" }}>
                  {gw.status}
                </span>
              </td>
              <td style={{ padding: "8px" }}>{gw.failureRate}%</td>
              <td style={{ padding: "8px" }}>{gw.pendingRetries}</td>
              <td style={{ padding: "8px" }}>
                <button onClick={() => handleOptimisticReset(gw.id)}>Force Reset (HALF-OPEN)</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
