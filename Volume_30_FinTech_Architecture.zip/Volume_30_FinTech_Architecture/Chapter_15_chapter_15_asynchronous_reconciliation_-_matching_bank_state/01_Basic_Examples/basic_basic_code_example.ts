/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file reconciliationEngine.ts
 * @description A self-contained TypeScript module demonstrating basic 
 * deterministic reconciliation between internal ledger transactions and 
 * external bank statement lines using immutable state principles.
 */

/**
 * Represents the currency supported by the financial pipeline.
 */
type Currency = 'USD' | 'EUR' | 'GBP';

/**
 * Immutable internal ledger transaction record.
 */
interface InternalLedgerEntry {
    readonly id: string;
    readonly amount: number; // Stored in minor units (cents) to avoid floating-point drift
    readonly currency: Currency;
    readonly timestamp: number; // Epoch milliseconds
    readonly referenceCode: string;
}

/**
 * Immutable external bank statement line item.
 */
interface BankStatementLine {
    readonly id: string;
    readonly amount: number; // Stored in minor units (cents)
    readonly currency: Currency;
    readonly timestamp: number; // Epoch milliseconds
    readonly description: string;
}

/**
 * Represents the outcome of a reconciliation pass.
 */
type MatchStatus = 'EXACT_MATCH' | 'DISCREPANCY_UNMATCHED_INTERNAL' | 'DISCREPANCY_UNMATCHED_EXTERNAL';

/**
 * Immutable reconciliation result record linking internal and external entities.
 */
interface ReconciliationResult {
    readonly reconciliationId: string;
    readonly internalId: string | null;
    readonly externalId: string | null;
    readonly status: MatchStatus;
    readonly deltaAmount: number; // Difference in minor units
}

/**
 * Configuration options for matching tolerances.
 */
interface ReconciliationConfig {
    readonly maxTimeWindowMs: number; // Maximum allowed time drift between ledger and bank
}

/**
 * Performs deterministic reconciliation between internal ledger entries and bank statements.
 * Adheres strictly to immutable state management by returning brand new arrays and objects.
 * 
 * @param internalEntries Readonly array of internal financial events.
 * @param externalLines Readonly array of bank statement items.
 * @param config Tolerances and matching constraints.
 * @returns An immutable array of ReconciliationResult records.
 */
function reconcileLedgers(
    internalEntries: ReadonlyArray<InternalLedgerEntry>,
    externalLines: ReadonlyArray<BankStatementLine>,
    config: ReconciliationConfig
): ReadonlyArray<ReconciliationResult> {
    // Keep track of matched IDs to prevent double-matching in a single pass
    const matchedInternalIds = new Set<string>();
    const matchedExternalIds = new Set<string>();
    
    const results: ReconciliationResult[] = [];

    // Step 1: Iterate through internal entries to find deterministic exact matches
    for (const internal of internalEntries) {
        let foundMatch = false;

        for (const external of externalLines) {
            // Skip if this external line is already claimed by another internal entry
            if (matchedExternalIds.has(external.id)) {
                continue;
            }

            // Check deterministic matching criteria:
            // 1. Currency must match exactly
            // 2. Amount must match exactly (minor units)
            // 3. Timestamp difference must fall within the configured window
            const currencyMatch = internal.currency === external.currency;
            const amountMatch = internal.amount === external.amount;
            const timeDiff = Math.abs(internal.timestamp - external.timestamp);
            const timeMatch = timeDiff <= config.maxTimeWindowMs;

            if (currencyMatch && amountMatch && timeMatch) {
                // Register matches immutably in tracking sets
                matchedInternalIds.add(internal.id);
                matchedExternalIds.add(external.id);

                results.push({
                    reconciliationId: `rec_${internal.id}_${external.id}`,
                    internalId: internal.id,
                    externalId: external.id,
                    status: 'EXACT_MATCH',
                    deltaAmount: 0,
                });

                foundMatch = true;
                break; // Stop searching external lines for this internal entry
            }
        }

        // If no matching bank line was found, flag internal entry as an unmatched discrepancy
        if (!foundMatch) {
            results.push({
                reconciliationId: `rec_unmatched_int_${internal.id}`,
                internalId: internal.id,
                externalId: null,
                status: 'DISCREPANCY_UNMATCHED_INTERNAL',
                deltaAmount: internal.amount,
            });
        }
    }

    // Step 2: Identify external bank lines that had no corresponding internal ledger entry
    for (const external of externalLines) {
        if (!matchedExternalIds.has(external.id)) {
            results.push({
                reconciliationId: `rec_unmatched_ext_${external.id}`,
                internalId: null,
                externalId: external.id,
                status: 'DISCREPANCY_UNMATCHED_EXTERNAL',
                deltaAmount: external.amount,
            });
        }
    }

    // Return frozen/immutable result array
    return Object.freeze(results);
}

// ==========================================
// Execution Example (SaaS Billing Context)
// ==========================================

// Define a 24-hour time window in milliseconds
const ONE_DAY_MS = 24 * 60 * 60 * 1000;

const mockInternalLedger: ReadonlyArray<InternalLedgerEntry> = Object.freeze([
    {
        id: 'txn_101',
        amount: 4999, // $49.99
        currency: 'USD',
        timestamp: 1717000000000,
        referenceCode: 'INV-001',
    },
    {
        id: 'txn_102',
        amount: 15000, // $150.00
        currency: 'USD',
        timestamp: 1717086400000,
        referenceCode: 'INV-002',
    }
]);

const mockBankStatement: ReadonlyArray<BankStatementLine> = Object.freeze([
    {
        id: 'bank_901',
        amount: 4999,
        currency: 'USD',
        timestamp: 1717004300000, // Within 24 hours of txn_101
        description: 'STRIPE TRANSFER INV-001',
    },
    {
        id: 'bank_902',
        amount: 2500, // Mysterious incoming deposit with no internal record
        currency: 'USD',
        timestamp: 1717100000000,
        description: 'UNKNOWN WIRE DEPOSIT',
    }
]);

// Run the reconciliation engine
const reconciliationReport = reconcileLedgers(
    mockInternalLedger, 
    mockBankStatement, 
    { maxTimeWindowMs: ONE_DAY_MS }
);

console.log('Reconciliation Report Generated:', JSON.stringify(reconciliationReport, null, 2));
