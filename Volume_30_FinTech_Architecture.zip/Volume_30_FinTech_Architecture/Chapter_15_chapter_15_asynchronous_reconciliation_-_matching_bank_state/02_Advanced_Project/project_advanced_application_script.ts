/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { randomUUID } from 'crypto';

// ============================================================================
// DOMAIN MODELS & TYPES
// ============================================================================

/**
 * Represents a discrete monetary value to prevent floating-point rounding errors.
 * Stored as the smallest currency unit (e.g., cents).
 */
export type Cents = number & { readonly __brand: unique symbol };

export function toCents(amount: number): Cents {
  return Math.round(amount * 100) as Cents;
}

export type Currency = 'USD' | 'EUR' | 'GBP';

export interface Money {
  amount: Cents;
  currency: Currency;
}

export type LedgerStatus = 'PENDING' | 'SETTLED' | 'RECONCILED' | 'FLAGGED';

export interface InternalLedgerEntry {
  id: string;
  transactionId: string;
  amount: Money;
  timestamp: Date;
  status: LedgerStatus;
  referenceCode?: string;
  metadata: Record<string, string>;
}

export interface BankStatementRecord {
  id: string;
  externalRef: string;
  amount: Money;
  postedDate: Date;
  description: string;
  matched: boolean;
}

export type DiscrepancyType = 'MISSING_IN_LEDGER' | 'MISSING_IN_BANK' | 'AMOUNT_MISMATCH' | 'TIMING_DRIFT';

export interface ReconciliationException {
  id: string;
  batchId: string;
  type: DiscrepancyType;
  internalEntryId?: string;
  bankRecordId?: string;
  discrepancyAmount: Money;
  detectedAt: Date;
  resolved: boolean;
}

// ============================================================================
// TYPE GUARDS
// ============================================================================

/**
 * Type guard to verify if an unknown object conforms to the InternalLedgerEntry structure.
 * Essential for safely parsing unstructured data payloads coming from legacy databases or streams.
 */
export function isInternalLedgerEntry(item: unknown): item is InternalLedgerEntry {
  return (
    typeof item === 'object' &&
    item !== null &&
    typeof (item as InternalLedgerEntry).id === 'string' &&
    typeof (item as InternalLedgerEntry).transactionId === 'string' &&
    typeof (item as InternalLedgerEntry).amount === 'object' &&
    (item as InternalLedgerEntry).timestamp instanceof Date &&
    ['PENDING', 'SETTLED', 'RECONCILED', 'FLAGGED'].includes((item as InternalLedgerEntry).status)
  );
}

/**
 * Type guard to ensure safe handling of bank statement records.
 */
export function isBankStatementRecord(item: unknown): item is BankStatementRecord {
  return (
    typeof item === 'object' &&
    item !== null &&
    typeof (item as BankStatementRecord).id === 'string' &&
    typeof (item as BankStatementRecord).externalRef === 'string' &&
    typeof (item as BankStatementRecord).amount === 'object' &&
    (item as BankStatementRecord).postedDate instanceof Date
  );
}

// ============================================================================
// RECONCILIATION ENGINE CORE
// ============================================================================

export interface ReconciliationResult {
  batchId: string;
  matchedPairs: Array<{ ledgerId: string; bankId: string }>;
  exceptions: ReconciliationException[];
  processedAt: Date;
}

/**
 * Core Reconciliation Engine handling asynchronous matching between bank statements
 * and internal double-entry ledgers.
 */
export class AsynchronousReconciliationEngine {
  private batchId: string;

  constructor() {
    this.batchId = randomUUID();
  }

  /**
   * Executes the multi-pass reconciliation algorithm.
   * Pass 1: Deterministic Matching (Exact Amount + External Reference / Transaction ID)
   * Pass 2: Fuzzy Matching (Exact Amount + Date Window tolerance for settlement delays)
   */
  public reconcile(
    rawLedgerEntries: unknown[],
    rawBankStatements: unknown[]
  ): ReconciliationResult {
    // Step 1: Safely filter and parse inputs using TypeScript Type Guards
    const ledgers: InternalLedgerEntry[] = rawLedgerEntries.filter(isInternalLedgerEntry);
    const bankStatements: BankStatementRecord[] = rawBankStatements.filter(isBankStatementRecord);

    const matchedPairs: Array<{ ledgerId: string; bankId: string }> = [];
    const exceptions: ReconciliationException[] = [];

    const unmatchedLedgers = new Map<string, InternalLedgerEntry>(
      ledgers.map((l) => [l.id, { ...l }])
    );
    const unmatchedBanks = new Map<string, BankStatementRecord>(
      bankStatements.map((b) => [b.id, { ...b }])
    );

    // ========================================================================
    // PASS 1: Deterministic Matching (O(N) lookup via reference keys)
    // ========================================================================
    for (const [ledgerId, ledger] of unmatchedLedgers.entries()) {
      for (const [bankId, bank] of unmatchedBanks.entries()) {
        const exactReferenceMatch =
          ledger.transactionId === bank.externalRef ||
          ledger.referenceCode === bank.externalRef;

        const exactAmountMatch =
          ledger.amount.amount === bank.amount.amount &&
          ledger.amount.currency === bank.amount.currency;

        if (exactReferenceMatch && exactAmountMatch) {
          matchedPairs.push({ ledgerId, bankId });
          unmatchedLedgers.delete(ledgerId);
          unmatchedBanks.delete(bankId);
          break;
        }
      }
    }

    // ========================================================================
    // PASS 2: Fuzzy Matching (Amount + Timing Drift Tolerance Window)
    // ========================================================================
    const MAX_TIME_DRIFT_MS = 72 * 60 * 60 * 1000; // 72 hours settlement window

    for (const [ledgerId, ledger] of unmatchedLedgers.entries()) {
      for (const [bankId, bank] of unmatchedBanks.entries()) {
        const exactAmountMatch =
          ledger.amount.amount === bank.amount.amount &&
          ledger.amount.currency === bank.amount.currency;

        const timeDiff = Math.abs(ledger.timestamp.getTime() - bank.postedDate.getTime());

        if (exactAmountMatch && timeDiff <= MAX_TIME_DRIFT_MS) {
          // Fuzzy match found within acceptable settlement lag
          matchedPairs.push({ ledgerId, bankId });
          unmatchedLedgers.delete(ledgerId);
          unmatchedBanks.delete(bankId);

          // Log a timing drift exception for auditing purposes
          exceptions.push({
            id: randomUUID(),
            batchId: this.batchId,
            type: 'TIMING_DRIFT',
            internalEntryId: ledgerId,
            bankRecordId: bankId,
            discrepancyAmount: { amount: 0 as Cents, currency: ledger.amount.currency },
            detectedAt: new Date(),
            resolved: true, // Auto-resolved by fuzzy matching engine
          });
          break;
        }
      }
    }

    // ========================================================================
    // PASS 3: Exception Generation for Unresolved Records
    // ========================================================================
    for (const [ledgerId, ledger] of unmatchedLedgers.entries()) {
      exceptions.push({
        id: randomUUID(),
        batchId: this.batchId,
        type: 'MISSING_IN_BANK',
        internalEntryId: ledgerId,
        discrepancyAmount: ledger.amount,
        detectedAt: new Date(),
        resolved: false,
      });
    }

    for (const [bankId, bank] of unmatchedBanks.entries()) {
      exceptions.push({
        id: randomUUID(),
        batchId: this.batchId,
        type: 'MISSING_IN_INDIRECT_LEDGER', // Mapped to internal discrepancy type
        bankRecordId: bankId,
        discrepancyAmount: bank.amount,
        detectedAt: new Date(),
        resolved: false,
      });
    }

    return {
      batchId: this.batchId,
      matchedPairs,
      exceptions,
      processedAt: new Date(),
    };
  }
}
