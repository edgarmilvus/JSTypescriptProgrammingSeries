/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define strict types for monetary amounts and identifiers
export type MinorUnits = bigint;
export type CurrencyCode = 'USD' | 'EUR' | 'GBP';
export type Branded<T, BrandName> = T & { readonly __brand: BrandName };

export type BankStatementID = Branded<string, 'BankStatementID'>;
export type LedgerEntryID = Branded<string, 'LedgerEntryID'>;

export interface BankStatementLine {
  id: BankStatementID;
  amount: MinorUnits;
  currency: CurrencyCode;
  effectiveDate: Date;
  reference: string;
}

export interface InternalLedgerEntry {
  id: LedgerEntryID;
  amount: MinorUnits;
  currency: CurrencyCode;
  createdAt: Date;
  metadataReference: string;
}

export interface MatchedPair {
  bankLineId: BankStatementID;
  ledgerEntryId: LedgerEntryID;
  matchedAt: Date;
  varianceDays: number;
}

export function reconcileExact(
  statements: BankStatementLine[],
  ledgers: InternalLedgerEntry[]
): [MatchedPair[], BankStatementLine[], InternalLedgerEntry[]] {
  const matchedPairs: MatchedPair[] = [];
  const unmatchedStatements: BankStatementLine[] = [];
  
  // Track claimed ledger IDs to enforce 1:1 uniqueness mapping
  const claimedLedgerIds = new Set<string>();
  const ledgerMap = new Map<string, InternalLedgerEntry>();

  for (const ledger of ledgers) {
    ledgerMap.set(ledger.id, ledger);
  }

  for (const statement of statements) {
    let bestMatch: InternalLedgerEntry | null = null;
    let minVarianceDays = Infinity;

    // Search through available ledger entries for an exact match
    for (const ledger of ledgerMap.values()) {
      if (claimedLedgerIds.has(ledger.id)) continue;

      // Validate exact financial criteria: amount and currency
      if (statement.amount === ledger.amount && statement.currency === ledger.currency) {
        // Enforce strict temporal validation: statement date must be >= ledger date
        const timeDiff = statement.effectiveDate.getTime() - ledger.createdAt.getTime();
        const varianceDays = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

        // Allowed window: T+0 to T+1 settlement variance (0 to 1 day inclusive)
        if (varianceDays >= 0 && varianceDays <= 1) {
          if (varianceDays < minVarianceDays) {
            minVarianceDays = varianceDays;
            bestMatch = ledger;
          }
        }
      }
    }

    if (bestMatch) {
      claimedLedgerIds.add(bestMatch.id);
      matchedPairs.push({
        bankLineId: statement.id,
        ledgerEntryId: bestMatch.id,
        matchedAt: new Date(),
        varianceDays: minVarianceDays,
      });
    } else {
      unmatchedStatements.push(statement);
    }
  }

  // Collect any internal ledgers that were never claimed
  const unmatchedLedgers = ledgers.filter((ledger) => !claimedLedgerIds.has(ledger.id));

  return [matchedPairs, unmatchedStatements, unmatchedLedgers];
}
