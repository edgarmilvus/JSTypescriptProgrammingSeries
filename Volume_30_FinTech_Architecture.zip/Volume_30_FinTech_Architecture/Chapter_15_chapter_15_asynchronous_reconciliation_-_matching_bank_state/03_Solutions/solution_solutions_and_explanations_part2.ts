/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export type ScoringWeights = {
  amountWeight: number;
  stringWeight: number;
  temporalWeight: number;
};

export interface FuzzyMatchResult {
  statement: BankStatementLine;
  ledger: InternalLedgerEntry;
  confidenceScore: number;
  heuristicsBreakdown: {
    amountScore: number;
    stringScore: number;
    temporalScore: number;
  };
}

/**
 * Computes Jaccard similarity coefficient between two strings using whitespace tokenization.
 */
function calculateTokenJaccard(str1: string, str2: string): number {
  const tokenize = (s: string) => new Set(s.toLowerCase().replace(/[^\w\s]/gi, '').split(/\s+/).filter(Boolean));
  const set1 = tokenize(str1);
  const set2 = tokenize(str2);

  if (set1.size === 0 && set2.size === 0) return 1.0;

  let intersectionSize = 0;
  for (const token of set1) {
    if (set2.has(token)) {
      intersectionSize++;
    }
  }

  const unionSize = set1.size + set2.size - intersectionSize;
  return unionSize === 0 ? 0 : intersectionSize / unionSize;
}

export function calculateMatchScore(
  statement: BankStatementLine,
  ledger: InternalLedgerEntry,
  weights: ScoringWeights
): number {
  // 1. Amount Score: 1.0 if exact, penalize small variance (e.g., fee deductions up to 500 minor units)
  let amountScore = 0.0;
  if (statement.amount === ledger.amount) {
    amountScore = 1.0;
  } else {
    const diff = Number(statement.amount > ledger.amount ? statement.amount - ledger.amount : ledger.amount - statement.amount);
    const maxTolerance = 500; // e.g., $5.00 fee window
    if (diff <= maxTolerance) {
      amountScore = 1.0 - (diff / maxTolerance);
    }
  }

  // If currency does not match, return 0 immediately
  if (statement.currency !== ledger.currency) {
    return 0.0;
  }

  // 2. String Score: Token Jaccard similarity between statement reference and internal metadata reference
  const stringScore = calculateTokenJaccard(statement.reference, ledger.metadataReference);

  // 3. Temporal Score: Exponential decay based on absolute day differences (half-life of 2 days)
  const timeDiffMs = Math.abs(statement.effectiveDate.getTime() - ledger.createdAt.getTime());
  const dayDiff = timeDiffMs / (1000 * 60 * 60 * 24);
  const temporalScore = Math.exp(-dayDiff / 2.0);

  // Weighted composite score calculation
  const totalWeight = weights.amountWeight + weights.stringWeight + weights.temporalWeight;
  if (totalWeight === 0) return 0.0;

  const weightedSum = 
    (amountScore * weights.amountWeight) +
    (stringScore * weights.stringWeight) +
    (temporalScore * weights.temporalWeight);

  return weightedSum / totalWeight;
}

export function reconcileFuzzy(
  statements: BankStatementLine[],
  ledgers: InternalLedgerEntry[],
  weights: ScoringWeights,
  threshold: number
): [FuzzyMatchResult[], BankStatementLine[], InternalLedgerEntry[]] {
  const potentialMatches: Array<{
    statement: BankStatementLine;
    ledger: InternalLedgerEntry;
    score: number;
    breakdown: { amountScore: number; stringScore: number; temporalScore: number };
  }> = [];

  // Generate all cross-pairs for evaluation
  for (const statement of statements) {
    for (const ledger of ledgers) {
      const amountDiff = statement.amount > ledger.amount ? statement.amount - ledger.amount : ledger.amount - statement.amount;
      // Pre-filter: skip comparison if amount discrepancy exceeds absolute structural tolerance ($50.00)
      if (statement.currency === ledger.currency && amountDiff <= 5000) {
        const amountScore = statement.amount === ledger.amount ? 1.0 : Math.max(0, 1.0 - Number(amountDiff) / 5000);
        const stringScore = calculateTokenJaccard(statement.reference, ledger.metadataReference);
        const dayDiff = Math.abs(statement.effectiveDate.getTime() - ledger.createdAt.getTime()) / (1000 * 60 * 60 * 24);
        const temporalScore = Math.exp(-dayDiff / 2.0);

        const totalWeight = weights.amountWeight + weights.stringWeight + weights.temporalWeight;
        const confidenceScore = totalWeight > 0 ? ((amountScore * weights.amountWeight) + (stringScore * weights.stringWeight) + (temporalScore * weights.temporalWeight)) / totalWeight : 0;

        if (confidenceScore >= threshold) {
          potentialMatches.push({
            statement,
            ledger,
            score: confidenceScore,
            breakdown: { amountScore, stringScore, temporalScore },
          });
        }
      }
    }
  }

  // Sort potential matches by descending confidence score (Greedy selection strategy)
  potentialMatches.sort((a, b) => b.score - a.score);

  const matchedResults: FuzzyMatchResult[] = [];
  const claimedStatements = new Set<string>();
  const claimedLedgers = new Set<string>();

  for (const match of potentialMatches) {
    if (!claimedStatements.has(match.statement.id) && !claimedLedgers.has(match.ledger.id)) {
      claimedStatements.add(match.statement.id);
      claimedLedgers.add(match.ledger.id);

      matchedResults.push({
        statement: match.statement,
        ledger: match.ledger,
        confidenceScore: match.score,
        heuristicsBreakdown: match.breakdown,
      });
    }
  }

  const remainingStatements = statements.filter((s) => !claimedStatements.has(s.id));
  const remainingLedgers = ledgers.filter((l) => !claimedLedgers.has(l.id));

  return [matchedResults, remainingStatements, remainingLedgers];
}
