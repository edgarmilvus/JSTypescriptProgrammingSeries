/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export type DiscrepancyType = 
  | 'MISSING_INTERNAL' 
  | 'MISSING_EXTERNAL' 
  | 'AMOUNT_DISCREpancy'; // Keeping naming consistent with schema

export interface BaseDiscrepancy {
  id: string;
  detectedAt: Date;
  currency: CurrencyCode;
}

export interface MissingInternalDiscrepancy extends BaseDiscrepancy {
  type: 'MISSING_INTERNAL';
  bankLine: BankStatementLine;
}

export interface AmountDiscrepancy extends BaseDiscrepancy {
  type: 'AMOUNT_DISCREpancy';
  bankLine: BankStatementLine;
  internalEntry: InternalLedgerEntry;
  varianceAmount: MinorUnits;
}

export type LedgerDiscrepancy = MissingInternalDiscrepancy | AmountDiscrepancy;

export type RemediationAction = 
  | { kind: 'GENERATE_VOUCHER'; compensatingAmount: MinorUnits; accountId: string }
  | { kind: 'ESCALATE'; reason: string }
  | { kind: 'NO_ACTION' };

export class DiscrepancyPipeline {
  private queue: Map<string, LedgerDiscrepancy> = new Map();
  private processedIds: Set<string> = new Set();

  public ingest(discrepancies: LedgerDiscrepancy[]): void {
    for (const discrepancy of discrepancies) {
      // Ensure idempotency: if already processed or already in queue, ignore duplicates
      if (!this.processedIds.has(discrepancy.id) && !this.queue.has(discrepancy.id)) {
        this.queue.set(discrepancy.id, discrepancy);
      }
    }
  }

  public evaluateAndHeal(): RemediationAction[] {
    const actions: RemediationAction[] = [];

    for (const [id, discrepancy] of this.queue.entries()) {
      let action: RemediationAction = { kind: 'NO_ACTION' };

      // Type guard evaluation for discriminated union branches
      if (discrepancy.type === 'MISSING_INTERNAL') {
        // Auto-remediate minor missing internal fees under 500 minor units ($5.00)
        if (discrepancy.bankLine.amount <= 500n) {
          action = {
            kind: 'GENERATE_VOUCHER',
            compensatingAmount: discrepancy.bankLine.amount,
            accountId: 'FEES_EXPENSE_ACCOUNT',
          };
        } else {
          action = {
            kind: 'ESCALATE',
            reason: `Missing internal entry exceeds automated threshold: amount ${discrepancy.bankLine.amount}`,
          };
        }
      } else if (discrepancy.type === 'AMOUNT_DISCREpancy') {
        // Auto-remediate small rounding or processing variances under 100 minor units ($1.00)
        const absVariance = discrepancy.varianceAmount < 0n ? -discrepancy.varianceAmount : discrepancy.varianceAmount;
        if (absVariance <= 100n) {
          action = {
            kind: 'GENERATE_VOUCHER',
            compensatingAmount: discrepancy.varianceAmount,
            accountId: 'ROUNDING_VARIANCE_ACCOUNT',
          };
        } else {
          action = {
            kind: 'ESCALATE',
            reason: `Amount variance exceeds automated remediation limit: ${discrepancy.varianceAmount}`,
          };
        }
      }

      actions.push(action);
      this.processedIds.add(id);
      this.queue.delete(id);
    }

    return actions;
  }
}
