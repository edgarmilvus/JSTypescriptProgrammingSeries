/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

export interface DiscrepancyItem {
  id: string;
  description: string;
  amount: string;
  type: 'MISSING_INTERNAL' | 'AMOUNT_DISCREpancy';
}

interface ReconciliationDashboardProps {
  initialDiscrepancies: DiscrepancyItem[];
  onResolveMutation: (id: string, resolutionType: string) => Promise<boolean>;
}

export const ReconciliationDashboard: React.FC<ReconciliationDashboardProps> = ({
  initialDiscrepancies,
  onResolveMutation,
}) => {
  const [discrepancies, setDiscrepancies] = useState<DiscrepancyItem[]>(initialDiscrepancies);
  const [isPending, startTransition] = useTransition();
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const handleResolve = async (id: string, resolutionType: string) => {
    // Clear previous error banners before starting new mutation
    setErrorBanner(null);

    // 1. Snapshot previous state for rollback protection
    const previousDiscrepancies = [...discrepancies];

    // 2. Optimistically update UI by filtering out the resolved discrepancy
    setDiscrepancies((current) => current.filter((item) => item.id !== id));

    startTransition(async () => {
      try {
        // 3. Execute asynchronous mutation against backend persistence layer
        const success = await onResolveMutation(id, resolutionType);
        
        if (!success) {
          throw new Error('Backend mutation rejected reconciliation adjustment.');
        }
      } catch (err) {
        // 4. Catch failures, restore state from snapshot, and alert user via banner
        setDiscrepancies(previousDiscrepancies);
        setErrorBanner(err instanceof Error ? err.message : 'Failed to reconcile discrepancy. State restored.');
      }
    });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <h2 className="text-2xl font-bold mb-4">Reconciliation Discrepancy Queue</h2>
      {errorBanner && (
        <div className="bg-red-500/20 border border-red-500 p-3 mb-4 rounded text-red-300">
          {errorBanner}
        </div>
      )}
      <div className="divide-y divide-slate-700">
        {discrepancies.length === 0 ? (
          <p className="py-4 text-slate-400">All discrepancies reconciled. System fully balanced.</p>
        ) : (
          discrepancies.map((item) => (
            <div key={item.id} className="py-4 flex items-center justify-between">
              <div>
                <span className="inline-block px-2 py-1 text-xs font-semibold bg-amber-500/20 text-amber-300 rounded mr-3">
                  {item.type}
                </span>
                <span className="font-medium">{item.description}</span>
                <span className="ml-4 text-slate-400">{item.amount}</span>
              </div>
              <button
                onClick={() => handleResolve(item.id, 'MANUAL_MATCH')}
                disabled={isPending}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded font-medium transition-colors"
              >
                Resolve
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
