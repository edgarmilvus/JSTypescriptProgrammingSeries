/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

export type DiscrepancyType = 
  | 'MISSING_INTERNAL' 
  | 'MISSING_EXTERNAL' 
  | 'AMOUNT_DISCREPANCY';

export interface BaseDiscrepancy {
  id: string;
  detectedAt: Date;
  currency: CurrencyCode;
}

export interface MissingInternalDiscrepancy extends BaseDiscrepancy {
  type: 'MISSING_INTERNAL';
  bankLine: BankStatementLine;
}

export interface AmountDiscrepancy extends BaseDiscrepancy {
  type: 'AMOUNT_DISCREPANCY';
  bankLine: BankStatementLine;
  internalEntry: InternalLedgerEntry;
  varianceAmount: MinorUnits;
}

export type LedgerDiscrepancy = MissingInternalDiscrepancy | AmountDiscrepancy;

export type RemediationAction = 
  | { kind: 'GENERATE_VOUCHER'; compensatingAmount: MinorUnits; accountId: string }
  | { kind: 'ESCALATE'; reason: string }
  | { kind: 'NO_ACTION' };

export class DiscrepancyPipeline {
  private queue: LedgerDiscrepancy[] = [];

  public ingest(discrepancies: LedgerDiscrepancy[]): void {
    // TODO: Ingest discrepancies with idempotency checks.
  }

  public evaluateAndHeal(): RemediationAction[] {
    // TODO: Process queue, apply auto-remediation rules, and return generated actions.
    throw new Error('Not implemented');
  }
}
