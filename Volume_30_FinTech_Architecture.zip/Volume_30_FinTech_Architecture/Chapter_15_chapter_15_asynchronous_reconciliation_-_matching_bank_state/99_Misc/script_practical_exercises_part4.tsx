/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useTransition } from 'react';

export interface DiscrepancyItem {
  id: string;
  description: string;
  amount: string;
  type: 'MISSING_INTERNAL' | 'AMOUNT_DISCREPANCY';
}

interface ReconciliationDashboardProps {
  initialDiscrepancies: DiscrepancyItem[];
  onResolveMutation: (id: string, resolutionType: string) => Promise<boolean>;
}

export const ReconciliationDashboard: React.FC<ReconciliationDashboardProps> = ({
  initialDiscrepancies,
  onResolveMutation,
}) => {
  const [discrepancies, setDiscrepancies] = useState<DiscrepancyItem[]>(initialDiscrepancies);
  const [isPending, startTransition] = useTransition();
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // TODO: Implement handleResolve with optimistic UI updates and rollback support.
  const handleResolve = async (id: string, resolutionType: string) => {
    // 1. Snapshot previous state for rollback
    // 2. Optimistically remove item from state
    // 3. Execute mutation inside startTransition / async handler
    // 4. Catch errors and restore previous state
    throw new Error('Not implemented');
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <h2 className="text-2xl font-bold mb-4">Reconciliation Discrepancy Queue</h2>
      {errorBanner && (
        <div className="bg-red-500/20 border border-red-500 p-3 mb-4 rounded text-red-300">
          {errorBanner}
        </div>
      )}
      <div className="divide-y divide-slate-700">
        {discrepancies.length === 0 ? (
          <p className="py-4 text-slate-400">All discrepancies reconciled. System fully balanced.</p>
        ) : (
          discrepancies.map((item) => (
            <div key={item.id} className="py-4 flex items-center justify-between">
              <div>
                <span className="inline-block px-2 py-1 text-xs font-semibold bg-amber-500/20 text-amber-300 rounded mr-3">
                  {item.type}
                </span>
                <span className="font-medium">{item.description}</span>
                <span className="ml-4 text-slate-400">{item.amount}</span>
              </div>
              <button
                onClick={() => handleResolve(item.id, 'MANUAL_MATCH')}
                disabled={isPending}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded font-medium transition-colors"
              >
                Resolve
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
