/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from 'plaid';

/**
 * Configuration interface for the Plaid integration service.
 */
interface PlaidServiceConfig {
  clientId: string;
  secret: string;
  environment: keyof typeof PlaidEnvironments;
}

/**
 * Normalized transaction structure for internal system ingestion.
 * Decouples the internal database schema from the third-party provider's wire format.
 */
interface NormalizedTransaction {
  transactionId: string;
  accountId: string;
  amount: number;
  isoCurrencyCode: string;
  date: string;
  merchantName: string | null;
  pending: boolean;
}

/**
 * Service wrapper for interacting with the Plaid API safely.
 */
class PlaidIntegrationService {
  private client: PlaidApi;

  /**
   * Initializes the Plaid API client using strict type-safe configuration.
   * @param config - The Plaid service configuration parameters.
   */
  constructor(config: PlaidServiceConfig) {
    const configuration = new Configuration({
      basePath: PlaidEnvironments[config.environment],
      baseOptions: {
        headers: {
          'PLAID-CLIENT-ID': config.clientId,
          'PLAID-SECRET': config.secret,
          'Plaid-Version': '2020-09-14',
        },
      },
    });

    this.client = new PlaidApi(configuration);
  }

  /**
   * Exchanges a temporary public token (received from Plaid Link) for a permanent access token.
   * 
   * @param publicToken - The temporary public token from the client-side widget.
   * @returns A promise resolving to the permanent access token and item ID.
   */
  public async exchangePublicToken(publicToken: string): Promise<{ accessToken: string; itemId: string }> {
    try {
      const response = await this.client.itemPublicTokenExchange({
        public_token: publicToken,
      });

      return {
        accessToken: response.data.access_token,
        itemId: response.data.item_id,
      };
    } catch (error: any) {
      // Handle known Plaid API errors gracefully
      if (error.response && error.response.data) {
        const { error_code, error_message } = error.response.data;
        throw new Error(`Plaid Exchange Failed [${error_code}]: ${error_message}`);
      }
      throw new Error(`Unexpected error during token exchange: ${error.message}`);
    }
  }

  /**
   * Fetches and normalizes transactions for a given access token within a date range.
   * 
   * @param accessToken - The permanent user access token.
   * @param startDate - The start date in YYYY-MM-DD format.
   * @param endDate - The end date in YYYY-MM-DD format.
   * @returns An array of normalized transactions.
   */
  public async fetchTransactions(
    accessToken: string,
    startDate: string,
    endDate: string
  ): Promise<NormalizedTransaction[]> {
    try {
      const response = await this.client.transactionsGet({
        access_token: accessToken,
        start_date: startDate,
        end_date: endDate,
      });

      // Map raw API response to internal normalized format
      const normalizedTransactions: NormalizedTransaction[] = response.data.transactions.map((txn) => ({
        transactionId: txn.transaction_id,
        accountId: txn.account_id,
        amount: txn.amount,
        isoCurrencyCode: txn.iso_currency_code || 'USD',
        date: txn.date,
        merchantName: txn.merchant_name || txn.name,
        pending: txn.pending,
      }));

      return normalizedTransactions;
    } catch (error: any) {
      if (error.response && error.response.data) {
        const { error_code, error_message } = error.response.data;
        
        // Handle explicit re-authentication requirements
        if (error_code === 'ITEM_LOGIN_REQUIRED') {
          throw new Error('User intervention required: Bank credentials have changed or session expired.');
        }

        throw new Error(`Plaid Transactions API Error [${error_code}]: ${error_message}`);
      }
      throw new Error(`Network or parsing failure during transaction fetch: ${error.message}`);
    }
  }
}

// ==========================================
// Execution Example (Simulated SaaS Entrypoint)
// ==========================================
async function runDemo() {
  const plaidService = new PlaidIntegrationService({
    clientId: process.env.PLAID_CLIENT_ID || 'sandbox_client_id',
    secret: process.env.PLAID_SECRET || 'sandbox_secret',
    environment: 'sandbox',
  });

  try {
    console.log('Step 1: Exchanging public token...');
    // In a real application, this public-token comes from the Plaid Link frontend callback
    const simulatedPublicToken = 'public-sandbox-12345678-abcd-efgh-ijkl-mnopqrstuvwx';
    
    // Note: In sandbox, token exchange requires a valid sandbox public token generated via Plaid's test endpoints
    // const { accessToken } = await plaidService.exchangePublicToken(simulatedPublicToken);
    
    console.log('Step 2: Fetching normalized transaction feeds...');
    // const transactions = await plaidService.fetchTransactions(accessToken, '2023-01-01', '2023-10-31');
    // console.log(`Successfully ingested ${transactions.length} transactions.`);
    
  } catch (err: any) {
    console.error('Pipeline Execution Error:', err.message);
  }
}

// Uncomment to run in a test environment
// runedio();
