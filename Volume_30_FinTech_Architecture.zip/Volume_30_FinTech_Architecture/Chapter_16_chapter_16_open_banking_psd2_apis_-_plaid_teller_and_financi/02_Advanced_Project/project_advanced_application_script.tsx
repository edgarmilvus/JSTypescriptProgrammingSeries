/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useTransition } from 'react';

/**
 * Interface representing the status of an external Open Banking connection.
 */
interface InstitutionConnectionState {
  institutionId: string;
  institutionName: string;
  status: 'PENDING' | 'CONNECTED' | 'ERROR' | 'DISCONNECTED';
  lastSyncedAt?: string;
  errorCode?: string;
}

/**
 * Props for the OpenBankingManager component.
 */
interface OpenBankingManagerProps {
  userId: string;
  initialConnections: InstitutionConnectionState[];
}

/**
 * Server Action type definition for triggering an OAuth link token initialization.
 */
type InitializeLinkAction = (userId: string, provider: 'plaid' | 'teller') => Promise<{ linkToken: string; error?: string }>;

/**
 * Server Action type definition for exchanging public tokens.
 */
type ExchangeTokenAction = (userId: string, publicToken: string, provider: 'plaid' | 'teller') => Promise<{ success: boolean; error?: string }>;

/**
 * OpenBankingManager Client Component (CC)
 * Manages the UI lifecycle for connecting bank accounts via Plaid and Teller,
 * handling state mutations, transition loading states, and error handling.
 */
export default function OpenBankingManager({ userId, initialConnections }: OpenBankingManagerProps) {
  const [connections, setConnections] = useState<InstitutionConnectionState[]>(initialConnections);
  const [selectedProvider, setSelectedProvider] = useState<'plaid' | 'teller'>('plaid');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  /**
   * Handles the initiation of the Open Banking linking flow.
   * Requests a short-lived link token from the Next.js backend server action.
   */
  const handleInitiateLink = async () => {
    setErrorMessage(null);
    startTransition(async () => {
      try {
        // Step 1: Request link token generation from backend server action
        const response = await fetch('/api/banking/link-token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, provider: selectedProvider }),
        });

        if (!response.ok) {
          throw new Error(`Failed to initialize link token: ${response.statusText}`);
        }

        const { linkToken } = await response.json();

        // Step 2: Invoke the respective provider SDK (Mocked here for demonstration)
        // In a real implementation, window.Plaid.create({ token: linkToken, ... }).open() is invoked.
        console.info(`[OpenBanking] Initialized ${selectedProvider} with token:`, linkToken);
        
        // Simulating successful token exchange callback from client SDK
        const mockPublicToken = `public-${selectedProvider}-mock-token-${Date.now()}`;
        await handleTokenExchange(mockPublicToken);

      } catch (err: unknown) {
        if (err instanceof Error) {
          setErrorMessage(err.message);
        } else {
          setErrorMessage('An unexpected error occurred during link initialization.');
        }
      }
    });
  };

  /**
   * Sends the public token received from the client SDK to the server
   * for permanent access token exchange and database persistence.
   */
  const handleTokenExchange = async (publicToken: string) => {
    try {
      const response = await fetch('/api/banking/exchange-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, publicToken, provider: selectedProvider }),
      });

      if (!response.ok) {
        throw new Error('Token exchange failed on server.');
      }

      const result = await response.json();

      if (result.success) {
        // Optimistically update connection state
        setConnections((prev) => [
          ...prev.filter(c => c.institutionId !== result.institutionId),
          {
            institutionId: result.institutionId || 'inst_mock_123',
            institutionName: selectedProvider === 'plaid' ? 'Plaid Test Bank' : 'Teller Test Union',
            status: 'CONNECTED',
            lastSyncedAt: new Date().toISOString(),
          },
        ]);
      } else {
        throw new Error(result.error || 'Unknown exchange error.');
      }
    } catch (err: unknown) {
      if (err instanceof Error) {
        setErrorMessage(err.message);
      }
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800">
      <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Open Banking Aggregation</h2>
          <p className="text-sm text-slate-400">Connect institutional checking, savings, and credit accounts securely via PSD2 & Open Banking APIs.</p>
        </div>
        <div className="flex space-x-2">
          <select 
            aria-label="Select financial data provider"
            value={selectedProvider} 
            onChange={(e) => setSelectedProvider(e.target.value as 'plaid' | 'teller')}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="plaid">Plaid API</option>
            <option value="teller">Teller API</option>
          </select>
          <button
            onClick={handleInitiateLink}
            disabled={isPending}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-4 py-1.5 rounded-lg text-sm font-medium transition-colors shadow-sm"
          >
            {isPending ? 'Connecting...' : 'Link Account'}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="mb-4 p-3 bg-red-950/50 border border-red-800 rounded-lg text-red-200 text-sm">
          <strong>Error:</strong> {errorMessage}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {connections.map((conn) => (
          <div key={conn.institutionId} className="bg-slate-800/60 border border-slate-700/60 rounded-lg p-4 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-2">
                <span className="font-semibold text-base">{conn.institutionName}</span>
                <span className={`px-2 py-0.5 text-xs rounded-full font-semibold ${
                  conn.status === 'CONNECTED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                  conn.status === 'PENDING' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                  'bg-rose-950 text-rose-300 border border-rose-800'
                }`}>
                  {conn.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mb-4">ID: {conn.institutionId}</p>
            </div>
            <div className="flex justify-between items-center text-xs text-slate-500 border-t border-slate-700/50 pt-3">
              <span>Last Synced: {conn.lastSyncedAt ? new Date(conn.lastSyncedAt).toLocaleString() : 'Never'}</span>
              <button 
                className="text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
                onClick={() => alert(`Triggering manual sync for ${conn.institutionId}`)}
              >
                Sync Now
              </button>
            </div>
          </div>
        ))}
        {connections.length === 0 && (
          <div className="col-span-2 text-center py-8 text-slate-500 border border-dashed border-slate-800 rounded-lg">
            No institutional connections found. Link a bank account to begin transaction ingestion.
          </div>
        )}
      </div>
    </div>
  );
}
