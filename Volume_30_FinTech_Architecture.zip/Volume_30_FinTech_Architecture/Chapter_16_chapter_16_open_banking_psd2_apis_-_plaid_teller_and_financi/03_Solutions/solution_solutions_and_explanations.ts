/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from 'plaid';

// Define the Result pattern for safe error handling
type Result<T, E> = 
  | { success: true; data: T }
  | { success: false; error: E };

export class PlaidApiError extends Error {
  constructor(
    public readonly message: string,
    public readonly errorCode: string,
    public readonly statusCode: number
  ) {
    super(message);
    this.name = 'PlaidApiError';
  }
}

export interface CreateLinkTokenParams {
  userId: string;
  clientName: string;
  products: Products[];
  countryCodes: CountryCode[];
  language: string;
}

export interface TokenExchangeResult {
  accessToken: string;
  itemId: string;
}

export class PlaidService {
  private plaidClient: PlaidApi;

  constructor(secret: string, clientId: string, environment: keyof typeof PlaidEnvironments) {
    const configuration = new Configuration({
      basePath: PlaidEnvironments[environment],
      baseOptions: {
        headers: {
          'PLAID-CLIENT-ID': clientId,
          'PLAID-SECRET': secret,
        },
      },
    });
    this.plaidClient = new PlaidApi(configuration);
  }

  public async createLinkToken(params: CreateLinkTokenParams): Promise<Result<string, PlaidApiError>> {
    try {
      const response = await this.plaidClient.linkTokenCreate({
        user: { client_user_id: params.userId },
        client_name: params.clientName,
        products: params.products,
        country_codes: params.countryCodes,
        language: params.language,
      });

      const linkToken = response.data.link_token;
      return { success: true, data: linkToken };
    } catch (error: any) {
      const statusCode = error.response?.status || 500;
      const errorCode = error.response?.data?.error_code || 'UNKNOWN_ERROR';
      const message = error.response?.data?.error_message || error.message || 'An unexpected error occurred with Plaid API';

      return {
        success: false,
        error: new PlaidApiError(message, errorCode, statusCode),
      };
    }
  }

  public async exchangePublicToken(publicToken: string): Promise<Result<TokenExchangeResult, PlaidApiError>> {
    try {
      const response = await this.plaidClient.itemPublicTokenExchange({
        public_token: publicToken,
      });

      return {
        success: true,
        data: {
          accessToken: response.data.access_token,
          itemId: response.data.item_id,
        },
      };
    } catch (error: any) {
      const statusCode = error.response?.status || 500;
      const errorCode = error.response?.data?.error_code || 'UNKNOWN_ERROR';
      const message = error.response?.data?.error_message || error.message || 'Failed to exchange public token';

      return {
        success: false,
        error: new PlaidApiError(message, errorCode, statusCode),
      };
    }
  }

  public async createUpdateModeLinkToken(accessToken: string): Promise<Result<string, PlaidApiError>> {
    try {
      // Re-authentication workflow requires passing access_token to generate an update-mode link_token
      const response = await this.plaidClient.linkTokenCreate({
        user: { client_user_id: 're-auth-user' }, // Plaid requires user object even in update mode
        client_name: 'Financial Dashboard',
        access_token: accessToken,
        country_codes: [CountryCode.Us],
        language: 'en',
      });

      return { success: true, data: response.data.link_token };
    } catch (error: any) {
      const statusCode = error.response?.status || 500;
      const errorCode = error.response?.data?.error_code || 'UPDATE_MODE_ERROR';
      const message = error.response?.data?.error_message || error.message || 'Failed to create update-mode link token';

      return {
        success: false,
        error: new PlaidApiError(message, errorCode, statusCode),
      };
    }
  }
}
