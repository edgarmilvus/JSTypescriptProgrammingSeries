/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response } from 'express';

export type WebhookType = 'TRANSACTIONS' | 'ITEM' | 'HOLDINGS' | 'AUTH';

export interface BaseWebhookPayload {
  webhook_type: WebhookType;
  webhook_code: string;
  item_id: string;
  error?: {
    error_code: string;
    error_message: string;
  };
}

export interface TransactionsWebhookPayload extends BaseWebhookPayload {
  webhook_type: 'TRANSACTIONS';
  webhook_code: 'DEFAULT_UPDATE' | 'INITIAL_UPDATE' | 'HISTORICAL_UPDATE' | 'TRANSACTIONS_REMOVED';
  new_transactions?: number;
  removed_transactions?: string[];
  webhook_id?: string; // Often provided or computed via fingerprint
}

export interface DatabaseAdapter {
  isEventProcessed(eventId: string): Promise<boolean>;
  logWebhookEvent(eventId: string, type: string, status: 'RECEIVED' | 'PROCESSING' | 'COMPLETED' | 'FAILED'): Promise<void>;
  updateEventStatus(eventId: string, status: 'COMPLETED' | 'FAILED', error?: string): Promise<void>;
}

export class WebhookEngine {
  constructor(private db: DatabaseAdapter, private jwtSecret: string) {}

  public async handleWebhook(req: Request, res: Response): Promise<void> {
    const payload = req.body as TransactionsWebhookPayload;
    
    // Extract unique event identifier from body or headers (fallback to deterministic hash if missing)
    const eventId = req.headers['plaid-verification'] as string || payload.webhook_id || `${payload.item_id}_${payload.webhook_type}_${payload.webhook_code}_${Date.now()}`;

    try {
      // 1. Perform idempotency check
      const alreadyProcessed = await this.db.isEventProcessed(eventId);
      if (alreadyProcessed) {
        res.status(200).json({ status: 'acknowledged', message: 'Event already processed (idempotent skip)' });
        return;
      }

      // 2. Log receipt in database state table
      await this.db.logWebhookEvent(eventId, `${payload.webhook_type}:${payload.webhook_code}`, 'RECEIVED');

      // Acknowledge receipt immediately to avoid provider timeouts (at-least-once delivery design)
      res.status(200).json({ status: 'received' });

      // 3. Update state to PROCESSING and dispatch
      await this.db.logWebhookEvent(eventId, `${payload.webhook_type}:${payload.webhook_code}`, 'PROCESSING');

      if (payload.webhook_type === 'TRANSACTIONS') {
        await this.processTransactionsWebhook(payload);
      } else {
        // Handle other webhook types or ignore safely
      }

      // 4. Mark successful completion
      await this.db.updateEventStatus(eventId, 'COMPLETED');

    } catch (error: any) {
      // 5. Catch failures and update log status
      await this.db.updateEventStatus(eventId, 'FAILED', error.message);
    }
  }

  private async processTransactionsWebhook(payload: TransactionsWebhookPayload): Promise<void> {
    if (payload.webhook_code === 'TRANSACTIONS_REMOVED') {
      // Handle removal staging or transactional deletion logic
      const removedIds = payload.removed_transactions || [];
      // If transactions do not exist yet due to out-of-order delivery, buffer them in a staging table
      console.log(`Staging or processing deletion for transaction IDs:`, removedIds);
      return;
    }

    // Handle updates (DEFAULT_UPDATE, INITIAL_UPDATE, HISTORICAL_UPDATE)
    console.log(`Triggering transaction fetch for item: ${payload.item_id}, new items count: ${payload.new_transactions}`);
  }
}
