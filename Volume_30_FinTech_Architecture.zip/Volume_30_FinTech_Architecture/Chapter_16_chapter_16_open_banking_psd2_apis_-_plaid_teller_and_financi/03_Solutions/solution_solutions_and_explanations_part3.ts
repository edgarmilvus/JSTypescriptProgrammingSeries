/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface RawPlaidTransaction {
  transaction_id: string;
  account_id: string;
  amount: number; // Floating point (e.g., 12.34)
  iso_currency_code: string;
  date: string;
  name: string;
  pending: boolean;
  category: string[];
}

export type AccountType = 'ASSET_USER_CASH' | 'EXPENSE_MERCHANT' | 'LIABILITY_CLEARING';

export interface JournalPosting {
  accountId: string;
  accountType: AccountType;
  amountMinorUnits: bigint;
  direction: 'DEBIT' | 'CREDIT';
}

export interface JournalEntry {
  transactionId: string;
  timestamp: Date;
  currency: string;
  postings: JournalPosting[];
}

export class ImbalancedLedgerError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ImbalancedLedgerError';
  }
}

export class TransactionNormalizer {
  /**
   * Converts floating point currency to integer minor units (cents).
   */
  public static toMinorUnits(amount: number): bigint {
    // Multiply by 100 and round to bypass IEEE 754 floating point inaccuracies
    return BigInt(Math.round(amount * 100));
  }

  /**
   * Transforms a raw Plaid transaction into a balanced double-entry journal entry.
   */
  public static normalizeToJournalEntry(
    raw: RawPlaidTransaction,
    internalAssetAccountId: string,
    clearingAccountId: string
  ): JournalEntry {
    const minorAmount = this.toMinorUnits(raw.amount);
    const absoluteAmount = minorAmount < 0n ? -minorAmount : minorAmount;

    let assetDirection: 'DEBIT' | 'CREDIT';
    let clearingDirection: 'DEBIT' | 'CREDIT';

    if (raw.amount >= 0) {
      // Standard purchase: Money leaves the user's asset account (Credit), 
      // entering the merchant expense/clearing account (Debit).
      assetDirection = 'CREDIT';
      clearingDirection = 'DEBIT';
    } else {
      // Refund/Reversal: Money enters the user's asset account (Debit),
      // coming out of the merchant clearing account (Credit).
      assetDirection = 'DEBIT';
      clearingDirection = 'CREDIT';
    }

    const postings: JournalPosting[] = [
      {
        accountId: internalAssetAccountId,
        accountType: 'ASSET_USER_CASH',
        amountMinorUnits: absoluteAmount,
        direction: assetDirection,
      },
      {
        accountId: clearingAccountId,
        accountType: 'LIABILITY_CLEARING',
        amountMinorUnits: absoluteAmount,
        direction: clearingDirection,
      },
    ];

    // Validate double-entry ledger balance: Sum of Debits must equal Sum of Credits
    const totalDebits = postings
      .filter((p) => p.direction === 'DEBIT')
      .reduce((sum, p) => sum + p.amountMinorUnits, 0n);

    const totalCredits = postings
      .filter((p) => p.direction === 'CREDIT')
      .reduce((sum, p) => sum + p.amountMinorUnits, 0n);

    if (totalDebits !== totalCredits) {
      throw new ImbalancedLedgerError(
        `Journal entry imbalance detected for transaction ${raw.transaction_id}: Debits (${totalDebits}) do not equal Credits (${totalCredits})`
      );
    }

    return {
      transactionId: raw.transaction_id,
      timestamp: new Date(raw.date),
      currency: raw.iso_currency_code || 'USD',
      postings,
    };
  }
}
