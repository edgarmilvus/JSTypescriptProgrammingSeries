/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export interface BankConnectionState {
  status: 'DISCONNECTED' | 'LOADING_TOKEN' | 'READY_TO_LINK' | 'CONNECTED' | 'ERROR';
  institutionName?: string;
  maskedAccountNumber?: string;
  errorCode?: string;
  errorMessage?: string;
}

export interface PlaidConnectionManagerProps {
  userId: string;
  apiBaseUrl: string;
  onSuccessCallback?: (publicToken: string, metadata: any) => void;
}

export const PlaidConnectionManager: React.FC<PlaidConnectionManagerProps> = ({
  userId,
  apiBaseUrl,
  onSuccessCallback,
}) => {
  const [connectionState, setConnectionState] = useState<BankConnectionState>({
    status: 'DISCONNECTED',
  });

  const fetchLinkToken = async (): Promise<string> => {
    const response = await fetch(`${apiBaseUrl}/api/plaid/create-link-token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate link token from backend');
    }

    const data = await response.json();
    return data.linkToken;
  };

  const handleConnectClick = async () => {
    try {
      setConnectionState({ status: 'LOADING_TOKEN' });
      const linkToken = await fetchLinkToken();

      // Simulated Plaid Link SDK initialization and opening sequence
      // In production, integrate with `react-plaid-link` or load window.Plaid handler
      setTimeout(() => {
        // Mocking successful token exchange callback response
        const mockSuccess = true;
        if (mockSuccess) {
          setConnectionState({
            status: 'CONNECTED',
            institutionName: 'Chase Bank',
            maskedAccountNumber: '•••• 4921',
          });
          if (onSuccessCallback) {
            onSuccessCallback('public-sandbox-mock-token', { institution: { name: 'Chase Bank' } });
          }
        } else {
          setConnectionState({
            status: 'ERROR',
            errorMessage: 'User exited the Plaid Link flow prematurely.',
          });
        }
      }, 1500);

    } catch (error: any) {
      setConnectionState({
        status: 'ERROR',
        errorMessage: error.message || 'An unexpected error occurred during connection initialization.',
      });
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold text-gray-900">Bank Account Integration</h2>
      
      {connectionState.status === 'DISCONNECTED' && (
        <div>
          <p className="text-gray-600 mb-4">Connect your bank account securely via Open Banking.</p>
          <button
            onClick={handleConnectClick}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Connect Bank Account
          </button>
        </div>
      )}

      {connectionState.status === 'LOADING_TOKEN' && (
        <div className="flex justify-center items-center py-6">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Initializing secure connection...</span>
        </div>
      )}

      {connectionState.status === 'CONNECTED' && (
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-green-800 font-semibold">Successfully Connected!</p>
          <p className="text-sm text-green-600 mt-1">Institution: {connectionState.institutionName}</p>
          <p className="text-sm text-green-600">Account: {connectionState.maskedAccountNumber}</p>
        </div>
      )}

      {connectionState.status === 'ERROR' && (
        <div className="bg-red-50 p-4 rounded-lg border border-red-200">
          <p className="text-red-800 font-semibold">Connection Error</p>
          <p className="text-sm text-red-600 mt-1">{connectionState.errorMessage}</p>
          <button
            onClick={handleConnectClick}
            className="mt-3 w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 text-sm"
          >
            Retry Connection
          </button>
        </div>
      )}
    </div>
  );
};
