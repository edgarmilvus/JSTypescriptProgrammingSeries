/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton

import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from 'plaid';

// Define the Result pattern for safe error handling
type Result<T, E> = 
  | { success: true; data: T }
  | { success: false; error: E };

export class PlaidApiError extends Error {
  constructor(
    public readonly message: string,
    public readonly errorCode: string,
    public readonly statusCode: number
  ) {
    super(message);
    this.name = 'PlaidApiError';
  }
}

export interface CreateLinkTokenParams {
  userId: string;
  clientName: string;
  products: Products[];
  countryCodes: CountryCode[];
  language: string;
}

export interface TokenExchangeResult {
  accessToken: string;
  itemId: string;
}

export class PlaidService {
  private plaidClient: PlaidApi;

  constructor(secret: string, clientId: string, environment: keyof typeof PlaidEnvironments) {
    const configuration = new Configuration({
      basePath: PlaidEnvironments[environment],
      baseOptions: {
        headers: {
          'PLAID-CLIENT-ID': clientId,
          'PLAID-SECRET': secret,
        },
      },
    });
    this.plaidClient = new PlaidApi(configuration);
  }

  public async createLinkToken(params: CreateLinkTokenParams): Promise<Result<string, PlaidApiError>> {
    // TODO: Implement Plaid Link Token generation
    // 1. Construct the request payload meeting Plaid's API specs (user object, client_name, products, etc.)
    // 2. Call this.plaidClient.linkTokenCreate()
    // 3. Extract the link_token and return it via the Result pattern
    // 4. Catch errors and map them to PlaidApiError
    throw new Error('Not implemented');
  }

  public async exchangePublicToken(publicToken: string): Promise<Result<TokenExchangeResult, PlaidApiError>> {
    // TODO: Implement public token exchange
    // 1. Call this.plaidClient.itemPublicTokenExchange({ public_token: publicToken })
    // 2. Extract access_token and item_id
    // 3. Return via Result pattern, handling errors appropriately
    throw new Error('Not implemented');
  }
}
