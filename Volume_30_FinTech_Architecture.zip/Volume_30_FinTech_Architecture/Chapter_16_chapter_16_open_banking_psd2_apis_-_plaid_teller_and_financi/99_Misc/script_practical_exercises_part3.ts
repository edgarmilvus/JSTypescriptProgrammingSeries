/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton

export interface RawPlaidTransaction {
  transaction_id: string;
  account_id: string;
  amount: number; // Floating point (e.g., 12.34)
  iso_currency_code: string;
  date: string;
  name: string;
  pending: boolean;
  category: string[];
}

export type AccountType = 'ASSET_USER_CASH' | 'EXPENSE_MERCHANT' | 'LIABILITY_CLEARING';

export interface JournalPosting {
  accountId: string;
  accountType: AccountType;
  amountMinorUnits: bigint;
  direction: 'DEBIT' | 'CREDIT';
}

export interface JournalEntry {
  transactionId: string;
  timestamp: Date;
  currency: string;
  postings: JournalPosting[];
}

export class ImbalancedLedgerError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ImbalancedLedgerError';
  }
}

export class TransactionNormalizer {
  /**
   * Converts floating point currency to integer minor units (cents).
   */
  public static toMinorUnits(amount: number): bigint {
    // TODO: Implement safe conversion avoiding IEEE 754 floating-point errors
    // Hint: Math.round(amount * 100) converted to BigInt, but watch out for large numbers.
    throw new Error('Not implemented');
  }

  /**
   * Transforms a raw Plaid transaction into a balanced double-entry journal entry.
   */
  public static normalizeToJournalEntry(
    raw: RawPlaidTransaction,
    internalAssetAccountId: string,
    clearingAccountId: string
  ): JournalEntry {
    // TODO: Implement double-entry generation
    // 1. Normalize amount to minor units using toMinorUnits.
    // 2. Determine debit/credit directions based on transaction polarity (Positive amount in Plaid typically means money leaving account/expense or positive charge).
    // 3. Construct postings array.
    // 4. Validate that sum(debits) === sum(credits). If not, throw ImbalancedLedgerError.
    // 5. Return the structured JournalEntry.
    throw new Error('Not implemented');
  }
}
