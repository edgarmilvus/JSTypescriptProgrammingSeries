/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual illustration of resilient asynchronous ledger appending
export async function appendToLedgerSecurely<T>(
  payload: T,
  ledgerRepository: LedgerRepository,
  signer: CryptographicSigner
): Promise<SignedLedgerEntry<T>> {
  const lock = await ledgerRepository.acquireExclusiveLock();
  
  try {
    // 1. Retrieve the absolute latest tail entry
    const tailEntry = await ledgerRepository.getLatestEntry();
    const sequenceNumber = tailEntry ? tailEntry.sequenceNumber + 1 : 0;
    const previousHash = tailEntry ? tailEntry.hash : '0000000000000000000000000000000000000000000000000000000000000000';

    // 2. Construct raw entry data
    const rawEntryData = {
      sequenceNumber,
      timestamp: new Date().toISOString(),
      payload,
      previousHash
    };

    // 3. Compute hash (canonical serialization omitted for brevity)
    const hash = computeSha256Hash(rawEntryData);

    // 4. Sign cryptographically
    const signature = await signer.signHash(hash);

    const signedEntry: SignedLedgerEntry<T> = {
      ...rawEntryData,
      hash,
      signature
    };

    // 5. Persist to append-only storage
    await ledgerRepository.persistEntry(signedEntry);

    return signedEntry;
  } catch (error) {
    // Log structured failure context and bubble up for pipeline handling
    logger.error('Failed to append entry to immutable ledger chain', { error, payload });
    throw new LedgerAppendError('Append operation failed catastrophically', { cause: error });
  } finally {
    // Guarantee lock release under all execution paths (success or failure)
    await lock.release();
  }
}
