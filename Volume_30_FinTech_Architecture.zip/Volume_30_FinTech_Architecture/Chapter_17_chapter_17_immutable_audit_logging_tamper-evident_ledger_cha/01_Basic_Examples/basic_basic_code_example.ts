/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as crypto from 'crypto';

/**
 * Represents the fundamental structure of a financial transaction event
 * within our SaaS billing and payment pipeline.
 */
interface TransactionEvent {
  readonly transactionId: string;
  readonly accountId: string;
  readonly amountCents: number;
  readonly currency: 'USD' | 'EUR' | 'GBP';
  readonly timestamp: number;
}

/**
 * Represents a node in our immutable, hash-chained ledger.
 * Extends the raw transaction with cryptographic linkage properties.
 */
interface LedgerNode {
  readonly index: number;
  readonly previousHash: string;
  readonly data: TransactionEvent;
  readonly nonce: number;
  readonly currentHash: string;
}

/**
 * Manages the append-only, tamper-evident ledger chain.
 * Implements strict immutability and exhaustive cryptographic verification.
 */
class ImmutableLedgerChain {
  private chain: LedgerNode[] = [];
  readonly genesisPreviousHash: string = '0'.repeat(64);

  constructor() {
    // Automatically initialize the chain with a genesis block upon instantiation.
    this.initializeGenesisBlock();
  }

  /**
   * Creates the foundational genesis block of the ledger.
   * This block serves as the cryptographic anchor for all subsequent transactions.
   */
  private initializeGenesisBlock(): void {
    const genesisData: TransactionEvent = {
      transactionId: 'TXN-GENESIS-000',
      accountId: 'SYS-ROOT-ACCOUNT',
      amountCents: 0,
      currency: 'USD',
      timestamp: Date.now(),
    };

    const genesisNode: LedgerNode = {
      index: 0,
      previousHash: this.genesisPreviousHash,
      data: genesisData,
      nonce: 0,
      currentHash: this.calculateHash(0, this.genesisPreviousHash, genesisData, 0),
    };

    // Push using internal mutation on private array, exposed only via readonly interfaces.
    this.chain.push(genesisNode);
  }

  /**
   * Cryptographically computes the SHA-256 hash for a given ledger node payload.
   * 
   * @param index - The sequential position of the node in the chain.
   * @param previousHash - The hex-encoded hash of the preceding block.
   * @param data - The immutable transaction event payload.
   * @param nonce - An incrementing integer used to ensure determinism.
   * @returns A 64-character hexadecimal SHA-256 hash string.
   */
  private calculateHash(
    index: number,
    previousHash: string,
    data: TransactionEvent,
    nonce: number
  ): string {
    const payload = JSON.stringify({ index, previousHash, data, nonce });
    return crypto.createHash('sha256').update(payload).digest('hex');
  }

  /**
   * Appends a new financial transaction to the ledger, binding it cryptographically
   * to the tail of the existing chain.
   * 
   * @param transaction - The validated transaction event data.
   * @returns The newly created and appended LedgerNode.
   */
  public appendTransaction(transaction: TransactionEvent): LedgerNode {
    // Exhaustive asynchronous resilience pattern applied synchronously for state tracking:
    // Ensure we reference the exact tail of the immutable chain.
    const lastNode = this.chain[this.chain.length - 1];
    const newIndex = lastNode.index + 1;
    const previousHash = lastNode.currentHash;
    let nonce = 0;
    
    // Compute the hash for this new entry
    let currentHash = this.calculateHash(newIndex, previousHash, transaction, nonce);

    const newNode: LedgerNode = {
      index: newIndex,
      previousHash,
      data: transaction,
      nonce,
      currentHash,
    };

    // Append the node to our private chain array
    this.chain.push(newNode);
    return newNode;
  }

  /**
   * Performs an exhaustive integrity verification of the entire ledger chain.
   * Recalculates hashes from index 0 onward and verifies cryptographic continuity.
   * 
   * @boolean Returns true if the chain is entirely intact; throws or returns false upon tampering.
   */
  public verifyChainIntegrity(): boolean {
    try {
      for (let i = 1; i < this.chain.length; i++) {
        const currentNode = this.chain[i];
        const previousNode = this.chain[i - 1];

        // 1. Verify that the current node correctly points to the previous node's hash
        if (currentNode.previousHash !== previousNode.currentHash) {
          console.error(`[Ledger Integrity Failure] Broken link detected at index ${i}: Previous hash mismatch.`);
          return false;
        }

        // 2. Recompute the hash of the current node to ensure its data has not been altered
        const recalculatedHash = this.calculateHash(
          currentNode.index,
          currentNode.previousHash,
          currentNode.data,
          currentNode.nonce
        );

        if (currentNode.currentHash !== recalculatedHash) {
          console.error(`[Ledger Integrity Failure] Data tampering detected at index ${i}: Hash mismatch.`);
          return false;
        }
      }
      return true;
    } catch (error) {
      console.error('An unexpected error occurred during ledger integrity verification:', error);
      return false;
    } finally {
      // Resource state logging or metric collection placeholder
      console.log('[Audit System] Chain verification check completed.');
    }
  }

  /**
   * Exposes a deep-copied, read-only snapshot of the ledger chain for external auditing services.
   */
  public getReadonlyChain(): ReadonlyArray<Readonly<LedgerNode>> {
    return this.chain;
  }
}

// ==========================================
// Execution Demonstration (SaaS Billing Pipeline)
// ==========================================

const saasLedger = new ImmutableLedgerChain();

// Simulate high-reliability payment events
const firstPayment: TransactionEvent = {
  transactionId: 'TXN-908123',
  accountId: 'ACCT-ENTERPRISE-44',
  amountCents: 49900, // $499.00 USD SaaS Subscription
  currency: 'USD',
  timestamp: Date.now(),
};

const secondPayment: TransactionEvent = {
  transactionId: 'TXN-908124',
  accountId: 'ACCT-STARTUP-12',
  amountCents: 9900, // $99.00 USD SaaS Subscription
  currency: 'USD',
  timestamp: Date.now() + 1000,
};

saasLedger.appendTransaction(firstPayment);
saasLedger.appendTransaction(secondPayment);

console.log('Initial Chain Integrity Check:', saasLedger.verifyChainIntegrity());

// SIMULATING TAMPERING ATTACK:
// Accessing internal private storage via prototype escape (simulated malice)
const exposedChain = saasLedger.getReadonlyChain() as LedgerNode[];
// Attempting to maliciously alter the amount of the first payment retroactively
// @ts-expect-error: Demonstrating runtime immutability enforcement violation
exposedChain[1].data = {
  ...exposedChain[1].data,
  amountCents: 100 // Maliciously reducing a $499 payment to $1.00
};

console.log('Post-Tampering Chain Integrity Check:', saasLedger.verifyChainIntegrity());
