/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createHash, verify, sign } from 'crypto';

/**
 * Represents the fundamental structural states of any immutable ledger entry.
 * Using Readonly utility types ensures structural immutability at the type level.
 */
export type LedgerEventType = 
  | 'ACCOUNT_CREATED'
  | 'FUNDS_DEPOSITED'
  | 'FUNDS_WITHDRAWN'
  | 'FUNDS_TRANSFERRED'
  | 'LEDGER_CHECKPOINT';

/**
 * Core payload structure for financial transactions.
 */
export interface TransactionPayload {
  readonly transactionId: string;
  readonly sourceAccountId: string;
  readonly destinationAccountId?: string;
  readonly amountMinorUnits: bigint; // Stored as integer minor units (e.g., cents) for precision math
  readonly currency: string;
  readonly metadata: Readonly<Record<string, string>>;
}

/**
 * The raw ledger event structure prior to cryptographic sealing.
 */
export interface UnsealedLedgerEvent {
  readonly eventId: string;
  readonly sequenceNumber: number;
  readonly timestamp: number;
  readonly eventType: LedgerEventType;
  readonly payload: TransactionPayload;
  readonly previousHash: string;
}

/**
 * The fully sealed, tamper-evident ledger block containing cryptographic proofs.
 */
export interface SealedLedgerEvent extends UnsealedLedgerEvent {
  readonly currentHash: string;
  readonly signature: string;
}

/**
 * Utility type to derive a partial state update configuration for logging pipelines.
 */
export type LedgerEventDraft = Omit<UnsealedLedgerEvent, 'previousHash' | 'sequenceNumber'>;

/**
 * In-memory secure append-only store implementation modeling high-reliability payment pipelines.
 */
export class ImmutableLedgerStore {
  private chain: SealedLedgerEvent[] = [];
  private privateKey: string;
  private publicKey: string;

  constructor(privateKey: string, publicKey: string) {
    this.privateKey = privateKey;
    this.publicKey = publicKey;
    this.initializeGenesisBlock();
  }

  /**
   * Initializes the cryptographic chain with a genesis block.
   */
  private initializeGenesisBlock(): void {
    const genesisUnsealed: UnsealedLedgerEvent = {
      eventId: 'genesis-0000-0000-0000-000000000000',
      sequenceNumber: 0,
      timestamp: Date.now(),
      eventType: 'LEDGER_CHECKPOINT',
      payload: {
        transactionId: 'genesis',
        sourceAccountId: 'SYSTEM',
        amountMinorUnits: 0n,
        currency: 'USD',
        metadata: Object.freeze({ note: 'Genesis Block Initialization' }),
      },
      previousHash: '0'.repeat(64),
    };

    const currentHash = this.computeHash(genesisUnsealed);
    const signature = this.signData(currentHash);

    const genesisBlock: SealedLedgerEvent = Object.freeze({
      ...genesisUnsealed,
      currentHash,
      signature,
    });

    this.chain.push(genesisBlock);
  }

  /**
   * Computes a SHA-256 cryptographic hash of the unsealed event combined with the previous hash.
   */
  private computeHash(event: UnsealedLedgerEvent): string {
    const hashPayload = JSON.stringify({
      eventId: event.eventId,
      sequenceNumber: event.sequenceNumber,
      timestamp: event.timestamp,
      eventType: event.eventType,
      payload: {
        ...event.payload,
        // Convert bigint to string for deterministic JSON serialization
        amountMinorUnits: event.payload.amountMinorUnits.toString(),
      },
      previousHash: event.previousHash,
    });

    return createHash('sha256').update(hashPayload).digest('hex');
  }

  /**
   * Signs the computed hash using the system's private key.
   */
  private signData(dataHash: string): string {
    return sign('sha256', Buffer.from(dataHash), {
      key: this.privateKey,
      padding: 1, // RSA_PKCS1_PADDING
    }).toString('hex');
  }

  /**
   * Appends a new financial event to the ledger with exhaustive async resilience.
   */
  public async appendEvent(draft: LedgerEventDraft): Promise<SealedLedgerEvent> {
    try {
      // Step 1: Retrieve the latest block to enforce chain continuity
      const latestBlock = this.getLatestBlock();
      const sequenceNumber = latestBlock.sequenceNumber + 1;
      const previousHash = latestBlock.currentHash;

      // Step 2: Construct the unsealed state safely using immutable patterns
      const unsealedEvent: UnsealedLedgerEvent = {
        ...draft,
        sequenceNumber,
        previousHash,
      };

      // Step 3: Compute cryptographic proofs
      const currentHash = this.computeHash(unsealedEvent);
      const signature = this.signData(currentHash);

      // Step 4: Finalize the sealed block
      const sealedEvent: SealedLedgerEvent = Object.freeze({
        ...unsealedEvent,
        currentHash,
        signature,
      });

      // Step 5: Simulate atomic append operation to persistent storage
      await this.persistToStorage(sealedEvent);
      
      this.chain.push(sealedEvent);
      return sealedEvent;

    } catch (error: unknown) {
      // Exhaustive Asynchronous Resilience: Error interception and graceful degradation
      const errorMessage = error instanceof Error ? error.message : 'Unknown persistence error';
      console.error(`[LedgerError] Failed to append event ID ${draft.eventId}: ${errorMessage}`);
      throw new Error(`Immutable ledger write failure: ${errorMessage}`);
    } finally {
      // Guaranteed execution block for releasing transaction locks or connection cleanup
      this.releaseResources();
    }
  }

  /**
   * Simulates writing to a persistent, immutable storage medium (e.g., WORM storage).
   */
  private async persistToStorage(event: SealedLedgerEvent): Promise<void> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!event.currentHash) {
          reject(new Error('Data corruption detected prior to storage commit.'));
        } else {
          resolve();
        }
      }, 10);
    });
  }

  private releaseResources(): void {
    // Resource cleanup hook placeholder
  }

  /**
   * Returns the most recent block in the chain safely.
   */
  public getLatestBlock(): SealedLedgerEvent {
    const block = this.chain[this.chain.length - 1];
    if (!block) {
      throw new Error('Critical Ledger Fault: Chain is empty.');
    }
    return block;
  }

  /**
   * Verifies the cryptographic integrity of the entire ledger chain.
   */
  public verifyChainIntegrity(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      // Check 1: Verify sequence continuity
      if (currentBlock.sequenceNumber !== previousBlock.sequenceNumber + 1) {
        return false;
      }

      // Check 2: Verify hash linkage
      if (currentBlock.previousHash !== previousBlock.currentHash) {
        return false;
      }

      // Check 3: Recompute hash to detect tampering
      const { currentHash: storedHash, signature: storedSignature, ...unsealedData } = currentBlock;
      const recomputedHash = this.computeHash(unsealedData);

      if (recomputedHash !== storedHash) {
        return false;
      }

      // Check 4: Verify cryptographic signature
      const isSignatureValid = verify(
        'sha256',
        Buffer.from(storedHash),
        { key: this.publicKey, padding: 1 },
        Buffer.from(storedSignature, 'hex')
      );

      if (!isSignatureValid) {
        return false;
      }
    }

    return true;
  }
}
