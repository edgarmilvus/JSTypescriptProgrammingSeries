/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { createHash } from 'crypto';

export interface FinancialTransactionPayload {
  readonly transactionId: string;
  readonly sourceAccountId: string;
  readonly destinationAccountId: string;
  readonly amount: string; // Stored as string to preserve precision math rules
  readonly currency: string;
}

export interface LedgerEvent<T> {
  readonly index: number;
  readonly timestamp: number;
  readonly previousHash: string;
  readonly nonce: number;
  readonly payload: T;
  readonly hash: string;
}

export class LedgerIntegrityError extends Error {
  constructor(message: string, public readonly index?: number) {
    super(message);
    this.name = 'LedgerIntegrityError';
  }
}

export class HashChainedLedger<T> {
  private chain: LedgerEvent<T>[] = [];
  private readonly GENESIS_HASH = '0'.repeat(64);

  constructor() {
    // Optionally initialize with a genesis block or leave empty until first append
  }

  private async computeHash(
    index: number,
    timestamp: number,
    previousHash: string,
    nonce: number,
    payload: T
  ): Promise<string> {
    try {
      const canonicalData = JSON.stringify({
        index,
        timestamp,
        previousHash,
        nonce,
        payload,
      });
      return createHash('sha256').update(canonicalData).digest('hex');
    } catch (error) {
      throw new LedgerIntegrityError(
        `Failed to compute cryptographic hash at index ${index}: ${(error as Error).message}`,
        index
      );
    }
  }

  public async appendEvent(payload: T): Promise<LedgerEvent<T>> {
    try {
      const index = this.chain.length;
      const timestamp = Date.now();
      const previousHash =
        index === 0
          ? this.GENESIS_HASH
          : this.chain[index - 1].hash;
      const nonce = Math.floor(Math.random() * 1_000_000);

      const hash = await this.computeHash(index, timestamp, previousHash, nonce, payload);

      const newEvent: LedgerEvent<T> = Object.freeze({
        index,
        timestamp,
        previousHash,
        nonce,
        payload,
        hash,
      });

      this.chain.push(newEvent);
      return newEvent;
    } catch (error) {
      if (error instanceof LedgerIntegrityError) {
        throw error;
      }
      throw new LedgerIntegrityError(
        `Failed to append event to ledger: ${(error as Error).message}`
      );
    } finally {
      // Enforce rigorous cleanup or audit logging hooks if necessary
    }
  }

  public async verifyIntegrity(): Promise<{ isValid: boolean; brokenAtIndex?: number }> {
    try {
      for (let i = 0; i < this.chain.length; i++) {
        const event = this.chain[i];

        // 1. Validate previousHash linkage
        const expectedPreviousHash =
          i === 0 ? this.GENESIS_HASH : this.chain[i - 1].hash;
        if (event.previousHash !== expectedPreviousHash) {
          return { isValid: false, brokenAtIndex: i };
        }

        // 2. Recalculate hash and validate integrity
        const recomputedHash = await this.computeHash(
          event.index,
          event.timestamp,
          event.previousHash,
          event.nonce,
          event.payload
        );

        if (event.hash !== recomputedHash) {
          return { isValid: false, brokenAtIndex: i };
        }
      }

      return { isValid: true };
    } catch (error) {
      throw new LedgerIntegrityError(
        `Integrity verification aborted due to error: ${(error as Error).message}`
      );
    }
  }

  public getLatestEvent(): Readonly<LedgerEvent<T>> | null {
    if (this.chain.length === 0) return null;
    return Object.freeze({ ...this.chain[this.chain.length - 1] });
  }
}
