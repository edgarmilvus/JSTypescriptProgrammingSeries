/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { HashChainedLedger } from './Exercise1';

export interface LedgerSnapshot<T> {
  readonly snapshotId: string;
  readonly atLedgerIndex: number;
  readonly ledgerHash: string;
  readonly accountBalances: Readonly<Record<string, string>>;
  readonly createdAt: number;
}

export class SnapshotError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SnapshotError';
  }
}

export class LedgerSnapshotManager {
  private snapshots: LedgerSnapshot<any>[] = [];

  public async createSnapshot<T>(
    ledger: HashChainedLedger<T>,
    currentBalances: Record<string, string>
  ): Promise<LedgerSnapshot<T>> {
    try {
      const integrityCheck = await ledger.verifyIntegrity();
      if (!integrityCheck.isValid) {
        throw new SnapshotError(
          `Cannot create snapshot: Ledger integrity compromised at index ${integrityCheck.brokenAtIndex}`
        );
      }

      const latestEvent = ledger.getLatestEvent();
      if (!latestEvent) {
        throw new SnapshotError('Cannot snapshot an empty ledger.');
      }

      // Deep clone and freeze balances to ensure state immutability
      const frozenBalances: Record<string, string> = {};
      for (const [key, value] of Object.entries(currentBalances)) {
        frozenBalances[key] = value;
      }
      Object.freeze(frozenBalances);

      const snapshot: LedgerSnapshot<T> = Object.freeze({
        snapshotId: crypto.randomUUID(),
        atLedgerIndex: latestEvent.index,
        ledgerHash: latestEvent.hash,
        accountBalances: frozenBalances,
        createdAt: Date.now(),
      });

      this.snapshots.push(snapshot);
      return snapshot;
    } catch (error) {
      if (error instanceof SnapshotError) {
        throw error;
      }
      throw new SnapshotError(
        `Failed to generate ledger snapshot: ${(error as Error).message}`
      );
    } finally {
      // Execution cleanup boundary
    }
  }

  public getSnapshotByIndex(index: number): Readonly<LedgerSnapshot<any>> | undefined {
    const found = this.snapshots.find((s) => s.atLedgerIndex === index);
    if (!found) return undefined;
    return Object.freeze({ ...found });
  }
}
