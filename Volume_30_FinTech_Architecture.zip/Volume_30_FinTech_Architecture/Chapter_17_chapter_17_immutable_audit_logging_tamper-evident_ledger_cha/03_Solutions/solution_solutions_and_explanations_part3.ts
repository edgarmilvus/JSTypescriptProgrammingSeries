/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { sign, verify, createHash } from 'crypto';

export type SignedPayload<T> = T & {
  readonly signature: string;
  readonly signedAt: number;
  readonly signerKeyId: string;
};

export class SignatureVerificationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SignatureVerificationError';
  }
}

export class PaymentPipelineSigner {
  private static canonicalize(payload: object): string {
    // Sort object keys recursively to ensure deterministic stringification for signatures
    const sortedKeys = Object.keys(payload).sort();
    const canonicalObj: Record<string, any> = {};
    for (const key of sortedKeys) {
      const val = (payload as Record<string, any>)[key];
      canonicalObj[key] =
        val && typeof val === 'object' && !Array.isArray(val)
          ? JSON.parse(PaymentPipelineSigner.canonicalize(val))
          : val;
    }
    return JSON.stringify(canonicalObj);
  }

  public static signTransaction<T extends object>(
    payload: T,
    privateKey: string,
    signerKeyId: string
  ): SignedPayload<T> {
    try {
      const signedAt = Date.now();
      const canonicalString = PaymentPipelineSigner.canonicalize(payload);
      const dataHash = createHash('sha256').update(canonicalString).digest();

      const signatureBuffer = sign(
        'sha256',
        dataHash,
        {
          key: privateKey,
          padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
        }
      );

      return Object.freeze({
        ...payload,
        signature: signatureBuffer.toString('hex'),
        signedAt,
        signerKeyId,
      }) as SignedPayload<T>;
    } catch (error) {
      throw new SignatureVerificationError(
        `Failed to sign transaction payload: ${(error as Error).message}`
      );
    }
  }

  public static verifyTransaction<T extends object>(
    signedPayload: SignedPayload<T>,
    publicKey: string
  ): boolean {
    try {
      // Extract payload fields by omitting signature metadata
      const { signature, signedAt, signerKeyId, ...rawPayload } = signedPayload as any;
      const canonicalString = PaymentPipelineSigner.canonicalize(rawPayload);
      const dataHash = createHash('sha256').update(canonicalString).digest();

      const signatureBuffer = Buffer.from(signature, 'hex');

      return verify(
        'sha256',
        dataHash,
        {
          key: publicKey,
          padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
        },
        signatureBuffer
      );
    } catch (error) {
      throw new SignatureVerificationError(
        `Signature verification execution failed: ${(error as Error).message}`
      );
    }
  }
}
