/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import { HashChainedLedger, LedgerEvent } from './Exercise1';

interface AuditLogInspectorProps<T> {
  ledger: HashChainedLedger<T>;
  onIntegrityViolation?: (index: number) => void;
}

type VerificationState = 'IDLE' | 'VERIFYING' | 'VALID' | 'INVALID';

export const AuditLogInspector = <T,>({
  ledger,
  onIntegrityViolation,
}: AuditLogInspectorProps<T>) => {
  const [events, setEvents] = useState<LedgerEvent<T>[]>([]);
  const [status, setStatus] = useState<VerificationState>('IDLE');
  const [brokenIndex, setBrokenIndex] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load events immutably from ledger instance on mount or update
  useEffect(() => {
    try {
      const latest = ledger.getLatestEvent();
      if (latest) {
        // Collect all events up to the latest index
        const collected: LedgerEvent<T>[] = [];
        // Since HashChainedLedger hides internal array, we poll or verify
        // For demonstration, we trigger a verify which checks the chain
      }
    } catch (err) {
      setErrorMessage((err as Error).message);
    }
  }, [ledger]);

  const handleVerifyLedger = useCallback(async () => {
    setStatus('VERIFYING');
    setErrorMessage(null);
    setBrokenIndex(null);

    try {
      const result = await ledger.verifyIntegrity();
      if (result.isValid) {
        setStatus('VALID');
      } else {
        setStatus('INVALID');
        setBrokenIndex(result.brokenAtIndex ?? null);
        if (result.brokenAtIndex !== undefined && onIntegrityViolation) {
          onIntegrityViolation(result.brokenAtIndex);
        }
      }
    } catch (err) {
      setStatus('INVALID');
      setErrorMessage((err as Error).message);
    } finally {
      // Cleanup execution state if needed
    }
  }, [ledger, onIntegrityViolation]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-xl font-mono">
      <h2 className="text-xl font-bold mb-4">Immutable Audit Log Inspector</h2>
      
      <div className="flex gap-4 mb-6">
        <button
          onClick={handleVerifyLedger}
          disabled={status === 'VERIFYING'}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 rounded font-semibold transition-colors"
        >
          {status === 'VERIFYING' ? 'Verifying Chain...' : 'Run Cryptographic Integrity Check'}
        </button>

        <div className="flex items-center gap-2">
          <span>Status:</span>
          <span
            className={`px-2 py-1 rounded text-xs font-bold ${
              status === 'VALID'
                ? 'bg-green-900 text-green-300'
                : status === 'INVALID'
                ? 'bg-red-900 text-red-300'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            {status}
          </span>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 mb-4 bg-red-950 border border-red-800 rounded text-red-200">
          Error: {errorMessage}
        </div>
      )}

      {brokenIndex !== null && (
        <div className="p-4 mb-4 bg-red-950 border border-red-800 rounded text-red-200">
          CRITICAL: Tampering detected at ledger event index {brokenIndex}!
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="border-b border-slate-700 text-slate-400">
              <th className="p-2">Index</th>
              <th className="p-2">Timestamp</th>
              <th className="p-2">Previous Hash</th>
              <th className="p-2">Event Hash</th>
              <th className="p-2">Payload</th>
            </tr>
          </thead>
          <tbody>
            {events.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-4 text-center text-slate-500">
                  No ledger events loaded or chain is empty.
                </td>
              </tr>
            ) : (
              events.map((evt) => (
                <tr
                  key={evt.index}
                  className={`border-b border-slate-800 ${
                    brokenIndex === evt.index ? 'bg-red-950/50' : ''
                  }`}
                >
                  <td className="p-2">{evt.index}</td>
                  <td className="p-2">{new Date(evt.timestamp).toISOString()}</td>
                  <td className="p-2 truncate max-w-[150px]">{evt.previousHash}</td>
                  <td className="p-2 truncate max-w-[150px]">{evt.hash}</td>
                  <td className="p-2">{JSON.stringify(evt.payload)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
