/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { HashChainedLedger, LedgerEvent, FinancialTransactionPayload } from './Exercise1';
import { PaymentPipelineSigner, SignedPayload } from './Exercise3';

export class PipelineExecutionError extends Error {
  constructor(message: string, public readonly stage: string) {
    super(message);
    this.name = 'PipelineExecutionError';
  }
}

export class PaymentPipelineOrchestrator {
  constructor(
    private readonly ledger: HashChainedLedger<FinancialTransactionPayload>,
    private readonly trustedPublicKey: string
  ) {}

  public async processPayment(
    signedPayload: SignedPayload<FinancialTransactionPayload>
  ): Promise<LedgerEvent<FinancialTransactionPayload>> {
    let currentStage = 'INITIALIZATION';

    try {
      // Stage 1: Cryptographic Signature Verification
      currentStage = 'SIGNATURE_VERIFICATION';
      const isSignatureValid = PaymentPipelineSigner.verifyTransaction(
        signedPayload,
        this.trustedPublicKey
      );

      if (!isSignatureValid) {
        throw new PipelineExecutionError(
          'Cryptographic signature validation failed for payment payload.',
          currentStage
        );
      }

      // Stage 2: Precision Math & Balance Validation
      currentStage = 'PRECISION_VALIDATION';
      const amountNum = parseFloat(signedPayload.amount);
      if (isNaN(amountNum) || amountNum <= 0) {
        throw new PipelineExecutionError(
          `Invalid transaction amount precision: ${signedPayload.amount}`,
          currentStage
        );
      }

      if (!signedPayload.sourceAccountId || !signedPayload.destinationAccountId) {
        throw new PipelineExecutionError(
          'Missing source or destination account identifiers.',
          currentStage
        );
      }

      // Stage 3: Hash-Chained Ledger Append
      currentStage = 'LEDGER_APPEND';
      const transactionPayload: FinancialTransactionPayload = {
        transactionId: signedPayload.transactionId,
        sourceAccountId: signedPayload.sourceAccountId,
        destinationAccountId: signedPayload.destinationAccountId,
        amount: signedPayload.amount,
        currency: signedPayload.currency,
      };

      const sealedEvent = await this.ledger.appendEvent(transactionPayload);
      return sealedEvent;
    } catch (error) {
      if (error instanceof PipelineExecutionError) {
        throw error;
      }
      throw new PipelineExecutionError(
        `Pipeline execution failed at stage [${currentStage}]: ${(error as Error).message}`,
        currentStage
      );
    } finally {
      // Exhaustive cleanup or metrics emission boundary
    }
  }
}
