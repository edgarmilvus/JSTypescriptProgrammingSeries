/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Exercise 1: HashChainedLedger Starter Code

import { createHash } from 'crypto';

export interface FinancialTransactionPayload {
  readonly transactionId: string;
  readonly sourceAccountId: string;
  readonly destinationAccountId: string;
  readonly amount: string; // Stored as string to preserve precision math rules
  readonly currency: string;
}

export interface LedgerEvent<T> {
  readonly index: number;
  readonly timestamp: number;
  readonly previousHash: string;
  readonly nonce: number;
  readonly payload: T;
  readonly hash: string;
}

export class LedgerIntegrityError extends Error {
  constructor(message: string, public readonly index?: number) {
    super(message);
    this.name = 'LedgerIntegrityError';
  }
}

export class HashChainedLedger<T> {
  private chain: LedgerEvent<T>[] = [];
  private readonly GENESIS_HASH = '0'.repeat(64);

  constructor() {
    // Optionally initialize with a genesis block or leave empty until first append
  }

  private async computeHash(
    index: number,
    timestamp: number,
    previousHash: string,
    nonce: number,
    payload: T
  ): Promise<string> {
    // TODO: Implement cryptographic hashing using Node.js 'crypto' module (SHA-256)
    // Combine all fields into a deterministic canonical string representation.
    throw new Error('Not implemented');
  }

  public async appendEvent(payload: T): Promise<LedgerEvent<T>> {
    // TODO: Implement immutable state appending with Exhaustive Asynchronous Resilience
    // 1. Determine previousHash (GENESIS_HASH if chain is empty, otherwise hash of last element)
    // 2. Compute index and timestamp
    // 3. Compute hash of the new event
    // 4. Push immutably to internal chain and return
    throw new Error('Not implemented');
  }

  public async verifyIntegrity(): Promise<{ isValid: boolean; brokenAtIndex?: number }> {
    // TODO: Iterate through the entire chain and validate hashes
    throw new Error('Not implemented');
  }

  public getLatestEvent(): Readonly<LedgerEvent<T>> | null {
    if (this.chain.length === 0) return null;
    return Object.freeze({ ...this.chain[this.chain.length - 1] });
  }
}
