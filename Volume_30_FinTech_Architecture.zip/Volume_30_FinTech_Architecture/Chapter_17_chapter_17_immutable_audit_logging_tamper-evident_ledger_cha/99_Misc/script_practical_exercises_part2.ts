/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Exercise 2: LedgerSnapshotManager Starter Code

import { HashChainedLedger, LedgerEvent } from './Exercise1';

export interface LedgerSnapshot<T> {
  readonly snapshotId: string;
  readonly atLedgerIndex: number;
  readonly ledgerHash: string;
  readonly accountBalances: Readonly<Record<string, string>>;
  readonly createdAt: number;
}

export class SnapshotError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SnapshotError';
  }
}

export class LedgerSnapshotManager {
  private snapshots: LedgerSnapshot<any>[] = [];

  public async createSnapshot<T>(
    ledger: HashChainedLedger<T>,
    currentBalances: Record<string, string>
  ): Promise<LedgerSnapshot<T>> {
    // TODO: Implement snapshot creation with asynchronous resilience
    // 1. Verify ledger integrity before snapshotting
    // 2. Fetch latest event from ledger
    // 3. Deep freeze currentBalances record
    // 4. Store and return the snapshot
    throw new Error('Not implemented');
  }

  public getSnapshotByIndex(index: number): Readonly<LedgerSnapshot<any>> | undefined {
    // TODO: Return read-only snapshot matching the index
    throw new Error('Not implemented');
  }
}
