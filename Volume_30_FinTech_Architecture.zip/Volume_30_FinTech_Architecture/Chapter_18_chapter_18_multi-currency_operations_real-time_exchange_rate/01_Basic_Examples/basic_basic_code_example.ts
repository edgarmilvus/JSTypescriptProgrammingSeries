/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file MultiCurrencyEngine.ts
 * @description Enterprise-grade precision multi-currency conversion and ledger entry engine.
 * Avoids floating-point drift by utilizing scaled integer representations (BigInt) 
 * and handles real-time FX rate mapping.
 */

/**
 * Supported ISO 4217 currency codes and their respective decimal scaling factors.
 */
export enum CurrencyCode {
  USD = 'USD', // 2 decimal places (scale factor: 100)
  EUR = 'EUR', // 2 decimal places (scale factor: 100)
  JPY = 'JPY', // 0 decimal places (scale factor: 1)
  BTC = 'BTC', // 8 decimal places (scale factor: 100,000,000)
}

/**
 * Mapping of currency codes to their minor-unit scaling factor powers of 10.
 */
const CURRENCY_SCALE: Record<CurrencyCode, number> = {
  [CurrencyCode.USD]: 2,
  [CurrencyCode.EUR]: 2,
  [CurrencyCode.JPY]: 0,
  [CurrencyCode.BTC]: 8,
};

/**
 * Represents a monetary amount in its minor unit (integer) form to prevent precision loss.
 */
export interface Money {
  readonly amount: bigint;
  readonly currency: CurrencyCode;
}

/**
 * Represents an exchange rate with high precision scaling (10^8 factor for rates).
 */
export interface ExchangeRate {
  readonly baseCurrency: CurrencyCode;
  readonly targetCurrency: CurrencyCode;
  /** Rate scaled by 10^8 to maintain integer precision during multiplication */
  readonly rateScaled: bigint;
  readonly timestamp: number;
}

/**
 * Represents a single leg of a double-entry ledger transaction.
 */
export interface LedgerEntryLine {
  readonly accountId: string;
  readonly money: Money;
  readonly isCredit: boolean;
}

/**
 * Represents a balanced multi-currency transaction.
 */
export interface LedgerTransaction {
  readonly transactionId: string;
  readonly description: string;
  readonly lines: LedgerEntryLine[];
  readonly createdAt: number;
}

/**
 * Utility class for handling precision monetary arithmetic and FX conversions.
 */
class PrecisionFXEngine {
  private rates: Map<string, ExchangeRate> = new Map();
  private static readonly RATE_SCALE_FACTOR = 100_000_000n; // 10^8

  /**
   * Registers or updates an exchange rate in the engine cache.
   * @param base Source currency
   * @param target Destination currency
   * @param rawRate Floating point rate (e.g., 1 USD = 0.85 EUR -> rate = 0.85)
   */
  public setRate(base: CurrencyCode, target: CurrencyCode, rawRate: number): void {
    // Convert floating point rate to scaled integer (multiply by 10^8)
    const scaledRate = BigInt(Math.round(rawRate * Number(PrecisionFXEngine.RATE_SCALE_FACTOR)));
    const key = `${base}->${target}`;
    
    this.rates.set(key, {
      baseCurrency: base,
      targetCurrency: target,
      rateScaled: scaledRate,
      timestamp: Date.now(),
    });

    // Automatically compute and set the inverse rate
    if (scaledRate > 0n) {
      const inverseKey = `${target}->${base}`;
      // Inverse rate calculation: (SCALE^2) / rateScaled
      const inverseScaled = (PrecisionFXEngine.RATE_SCALE_FACTOR * PrecisionFXEngine.RATE_SCALE_FACTOR) / scaledRate;
      this.rates.set(inverseKey, {
        baseCurrency: target,
        targetCurrency: base,
        rateScaled: inverseScaled,
        timestamp: Date.now(),
      });
    }
  }

  /**
   * Converts a monetary amount from one currency to another using integer scaling.
   * 
   * Formula:
   * Target Amount = (Source Amount * RateScaled * TargetScaleFactor) / (SourceScaleFactor * RATE_SCALE_FACTOR)
   */
  public convert(money: Money, targetCurrency: CurrencyCode): Money {
    if (money.currency === targetCurrency) {
      return { ...money };
    }

    const key = `${money.currency}->${targetCurrency}`;
    const exchangeRate = this.rates.get(key);

    if (!exchangeRate) {
      throw new Error(`Exchange rate not found for pair: ${money.currency} -> ${targetCurrency}`);
    }

    const sourceScale = BigInt(10 ** CURRENCY_SCALE[money.currency]);
    const targetScale = BigInt(10 ** CURRENCY_SCALE[targetCurrency]);

    // Intermediate calculation preserving precision
    const numerator = money.amount * exchangeRate.rateScaled * targetScale;
    const denominator = sourceScale * PrecisionFXEngine.RATE_SCALE_FACTOR;

    // Perform integer division with half-even rounding (simplified here to truncation/floor)
    const convertedAmount = numerator / denominator;

    return {
      amount: convertedAmount,
      currency: targetCurrency,
    };
  }
}

/**
 * Engine for creating and validating multi-currency double-entry ledger transactions.
 */
class MultiCurrencyLedgerEngine {
  private fxEngine: PrecisionFXEngine;
  private baseLedgerCurrency: CurrencyCode;

  constructor(fxEngine: PrecisionFXEngine, baseLedgerCurrency: CurrencyCode = CurrencyCode.USD) {
    this.fxEngine = fxEngine;
    this.baseLedgerCurrency = baseLedgerCurrency;
  }

  /**
   * Validates that a transaction's debits equal its credits when converted to the base ledger currency.
   * This guarantees the fundamental accounting equation (Assets = Liabilities + Equity) holds true
   * across multiple currencies.
   */
  public createTransaction(
    transactionId: string,
    description: string,
    lines: LedgerEntryLine[]
  ): LedgerTransaction {
    let totalDebitsBaseCurrency = 0n;
    let totalCreditsBaseCurrency = 0n;

    for (const line of lines) {
      // Normalize line amount to base ledger currency for balance verification
      const normalizedMoney = this.fxEngine.convert(line.money, this.baseLedgerCurrency);

      if (line.isCredit) {
        totalCreditsBaseCurrency += normalizedMoney.amount;
      } else {
        totalDebitsBaseCurrency += normalizedMoney.amount;
      }
    }

    if (totalDebitsBaseCurrency !== totalCreditsBaseCurrency) {
      throw new Error(
        `Ledger imbalance detected! Total Debits (${totalDebitsBaseCurrency}) do not equal Total Credits (${totalCreditsBaseCurrency}) in base currency ${this.baseLedgerCurrency}.`
      );
    }

    return {
      transactionId,
      description,
      lines,
      createdAt: Date.now(),
    };
  }
}

// ==========================================
// EXECUTION DEMONSTRATION
// ==========================================

// 1. Initialize the FX Engine and Ledger
const fx = new PrecisionFXEngine();
const ledger = new MultiCurrencyLedgerEngine(fx, CurrencyCode.USD);

// 2. Register real-time exchange rates (ingested via WebSocket/API)
fx.setRate(CurrencyCode.USD, CurrencyCode.EUR, 0.9250); // 1 USD = 0.9250 EUR
fx.setRate(CurrencyCode.USD, CurrencyCode.JPY, 154.50); // 1 USD = 154.50 JPY

// 3. Construct a multi-currency transaction:
// Customer in Japan pays 15,450 JPY for a service, which needs to be split:
// - Credit Revenue Account: 50 USD equivalent
// - Credit Tax Liability Account: Remaining JPY converted to USD
const invoiceTransaction = ledger.createTransaction(
  'tx_1001',
  'Cross-border invoice settlement with multi-currency split',
  [
    // Debit: Cash Clearing Account (Receiving 15,450 JPY)
    {
      accountId: 'acc_cash_jpy',
      money: { amount: 15450n, currency: CurrencyCode.JPY },
      isCredit: false,
    },
    // Credit: Revenue Account (Equivalent to 70 USD credited in USD terms)
    {
      accountId: 'acc_revenue_usd',
      money: { amount: 7000n, currency: CurrencyCode.USD }, // 70.00 USD
      isCredit: true,
    },
    // Credit: Clearing/FX Variance Account (Remaining balance: 15,450 JPY -> ~100 USD total debit, minus 70 USD = 30 USD equivalent in JPY)
    // 30 USD * 154.50 JPY/USD = 4,635 JPY
    {
      accountId: 'acc_tax_jpy',
      money: { amount: 4635n, currency: CurrencyCode.JPY }, // 46.35 JPY
      isCredit: true,
    },
  ]
);

console.log('Successfully created balanced multi-currency transaction:', JSON.stringify(invoiceTransaction, (_, v) => typeof v === 'bigint' ? v.toString() : v, 2));
