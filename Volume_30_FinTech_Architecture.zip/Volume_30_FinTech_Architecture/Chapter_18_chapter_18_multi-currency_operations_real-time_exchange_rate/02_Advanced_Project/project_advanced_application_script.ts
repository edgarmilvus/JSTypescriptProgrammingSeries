/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Decimal } from 'decimal.js';

// Enforce strict configuration for financial calculations
Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_EVEN });

/**
 * Supported currency codes adhering to ISO 4217.
 */
export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CAD';

/**
 * Represents a raw foreign exchange tick received from a liquidity provider.
 */
interface FXRateTick {
  readonly baseCurrency: CurrencyCode;
  readonly targetCurrency: CurrencyCode;
  readonly bid: string;
  readonly ask: string;
  readonly timestamp: number;
}

/**
 * Cached exchange rate entry with TTL support.
 */
interface CachedRate {
  readonly rate: Decimal;
  readonly timestamp: number;
  readonly expiresAt: number;
}

/**
 * Represents a single leg of a double-entry financial transaction.
 */
export interface LedgerPosting {
  readonly accountId: string;
  readonly amount: Decimal;
  readonly currency: CurrencyCode;
}

/**
 * Represents an immutable, multi-currency journal entry.
 */
export interface JournalEntry {
  readonly transactionId: string;
  readonly description: string;
  readonly postings: readonly LedgerPosting[];
  readonly createdAt: number;
}

/**
 * High-performance real-time FX engine managing rates and immutable ledgers.
 */
export class MultiCurrencyEngine {
  private readonly rateCache = new Map<string, CachedRate>();
  private readonly ttlMs: number;

  constructor(ttlMs: number = 5000) {
    this.ttlMs = ttlMs;
  }

  /**
   * Generates a composite cache key for currency pairs.
   */
  private getCacheKey(base: CurrencyCode, target: CurrencyCode): string {
    return `${base}_${target}`;
  }

  /**
   * Ingests a real-time FX rate tick asynchronously, updating the in-memory cache.
   * Utilizes non-blocking execution suited for the Node.js Event Loop.
   */
  public async ingestRateTick(tick: FXRateTick): Promise<void> {
    // Wrap execution to guarantee non-blocking processing on the Event Loop
    await new Promise<void>((resolve) => {
      setImmediate(() => {
        const rateDecimal = new Decimal(tick.ask); // Utilizing ask rate for customer conversions
        const now = Date.now();
        
        const cacheEntry: CachedRate = {
          rate: rateDecimal,
          timestamp: tick.timestamp,
          expiresAt: now + this.ttlMs,
        };

        const key = this.getCacheKey(tick.baseCurrency, tick.targetCurrency);
        this.rateCache.set(key, cacheEntry);

        // Also compute and store the inverse rate for bidirectional flexibility
        const inverseKey = this.getCacheKey(tick.targetCurrency, tick.baseCurrency);
        const inverseRate = new Decimal(1).dividedBy(rateDecimal);
        
        this.rateCache.set(inverseKey, {
          rate: inverseRate,
          timestamp: tick.timestamp,
          expiresAt: now + this.ttlMs,
        });

        resolve();
      });
    });
  }

  /**
   * Retrieves a live exchange rate from the cache with strict validation.
   */
  public getRate(base: CurrencyCode, target: CurrencyCode): Decimal {
    if (base === target) {
      return new Decimal(1);
    }

    const key = this.getCacheKey(base, target);
    const cached = this.rateCache.get(key);

    if (!cached) {
      throw new Error(`FX Rate unavailable for pair: ${base}/${target}`);
    }

    if (Date.now() > cached.expiresAt) {
      throw new Error(`FX Rate expired for pair: ${base}/${target}`);
    }

    return cached.rate;
  }

  /**
   * Converts an amount from a source currency to a target currency using arbitrary precision.
   */
  public convertAmount(
    amount: Decimal,
    base: CurrencyCode,
    target: CurrencyCode
  ): Decimal {
    const rate = this.getRate(base, target);
    return amount.times(rate).toDecimalPlaces(2, Decimal.ROUND_HALF_EVEN);
  }

  /**
   * Validates and constructs an immutable multi-currency double-entry journal entry.
   * Ensures that converted sums balance across differing currencies using base-equivalent values.
   */
  public createBalancedJournalEntry(
    transactionId: string,
    description: string,
    postings: readonly LedgerPosting[],
    baseCurrencyForValidation: CurrencyCode = 'USD'
  ): JournalEntry {
    let baseEquivalentSum = new Decimal(0);

    // Validate balance invariant by converting all legs to a common base currency
    for (const posting of postings) {
      const converted = this.convertAmount(
        posting.amount,
        posting.currency,
        baseCurrencyForValidation
      );
      baseEquivalentSum = baseEquivalentSum.plus(converted);
    }

    // Invariant check: Total debits must equal total credits (sum to zero in signed ledger logic)
    if (!baseEquivalentSum.isZero()) {
      throw new Error(
        `Ledger imbalance detected. Base equivalent sum is ${baseEquivalentSum.toString()} ${baseCurrencyForValidation}, expected 0.`
      );
    }

    // Return the deeply frozen, immutable journal entry structure
    return Object.freeze({
      transactionId,
      description,
      postings: postings.map((p) => Object.freeze({ ...p })),
      createdAt: Date.now(),
    });
  }
}
