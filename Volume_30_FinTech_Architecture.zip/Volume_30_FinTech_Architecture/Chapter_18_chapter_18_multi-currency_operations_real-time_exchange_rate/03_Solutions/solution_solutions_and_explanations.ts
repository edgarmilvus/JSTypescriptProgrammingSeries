/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Branded types for currency safety
export type CurrencyCode = string & { readonly __brand: unique symbol };

export function createCurrencyCode(code: string): CurrencyCode {
  if (!/^[A-Z]{3}$/.test(code)) {
    throw new Error(`Invalid currency code format: ${code}`);
  }
  return code as CurrencyCode;
}

export interface NormalizedRate {
  base: CurrencyCode;
  quote: CurrencyCode;
  bid: bigint; // Stored in fixed-point integer basis or micro-units
  ask: bigint;
  timestamp: number;
  providerId: string;
}

// Provider A Zod Schema (String-based decimal values e.g., "1.0854")
export const ProviderARawSchema = z.object({
  provider: z.literal('PROVIDER_A'),
  symbol: z.string().regex(/^[A-Z]{6}$/), // e.g., "USDEUR"
  bidPrice: z.string().refine((val) => !isNaN(Number(val)), { message: 'Invalid decimal string' }),
  askPrice: z.string().refine((val) => !isNaN(Number(val)), { message: 'Invalid decimal string' }),
  ts: z.number(),
});

// Provider B Zod Schema (Integer-scaled basis points e.g., 108540 for 1.08540)
export const ProviderBRawSchema = z.object({
  source: z.literal('PROVIDER_B'),
  baseCurrency: z.string().length(3),
  quoteCurrency: z.string().length(3),
  bidBasis: z.number().int(),
  askBasis: z.number().int(),
  timestamp: z.number(),
});

export type SpreadWideningAnomalyEvent = {
  type: 'SPREAD_WIDENING_ANOMALY';
  pair: string;
  providerId: string;
  historicalAverageSpread: number;
  currentSpread: number;
  timestamp: number;
};

export class RateCache {
  private cache: Map<string, NormalizedRate> = new Map();
  private spreadHistory: Map<string, number[]> = new Map();
  private anomalyListeners: ((event: SpreadWideningAnomalyEvent) => void)[] = [];

  public onAnomaly(listener: (event: SpreadWideningAnomalyEvent) => void): void {
    this.anomalyListeners.push(listener);
  }

  public updateRate(rate: NormalizedRate): void {
    const key = `${rate.base}-${rate.quote}`;
    
    // Calculate current spread magnitude (ask - bid)
    const currentSpread = Number(rate.ask - rate.bid);
    
    // Manage sliding-window history for moving average (e.g., max 100 data points)
    let history = this.spreadHistory.get(key);
    if (!history) {
      history = [];
      this.spreadHistory.set(key, history);
    }

    if (history.length > 0) {
      const avgSpread = history.reduce((sum, val) => sum + val, 0) / history.length;
      
      // Challenge Rule: If spread widens by more than 300% (i.e., current > avg * 4)
      if (avgSpread > 0 && currentSpread > avgSpread * 4) {
        const anomalyEvent: SpreadWideningAnomalyEvent = {
          type: 'SPREAD_WIDENING_ANOMALY',
          pair: key,
          providerId: rate.providerId,
          historicalAverageSpread: avgSpread,
          currentSpread,
          timestamp: Date.now(),
        };
        this.anomalyListeners.forEach((listener) => listener(anomalyEvent));
      }
    }

    history.push(currentSpread);
    if (history.length > 100) {
      history.shift();
    }

    this.cache.set(key, rate);
  }

  public getRate(base: CurrencyCode, quote: CurrencyCode): NormalizedRate | undefined {
    return this.cache.get(`${base}-${quote}`);
  }
}

export function parseAndNormalizeMessage(rawMessage: unknown): NormalizedRate {
  const parseA = ProviderARawSchema.safeParse(rawMessage);
  if (parseA.success) {
    const data = parseA.data;
    const baseStr = data.symbol.slice(0, 3);
    const quoteStr = data.symbol.slice(3, 6);
    
    // Scale decimal strings to micro-units (10^6 multiplier) to fit bigint securely
    const bidMicro = BigInt(Math.round(Number(data.bidPrice) * 1_000_000));
    const askMicro = BigInt(Math.round(Number(data.askPrice) * 1_000_000));

    return {
      base: createCurrencyCode(baseStr),
      quote: createCurrencyCode(quoteStr),
      bid: bidMicro,
      ask: askMicro,
      timestamp: data.ts,
      providerId: 'PROVIDER_A',
    };
  }

  const parseB = ProviderBRawSchema.safeParse(rawMessage);
  if (parseB.success) {
    const data = parseB.data;
    return {
      base: createCurrencyCode(data.baseCurrency),
      quote: createCurrencyCode(data.quoteCurrency),
      bid: BigInt(data.bidBasis),
      ask: BigInt(data.askBasis),
      timestamp: data.timestamp,
      providerId: 'PROVIDER_B',
    };
  }

  throw new Error(`[IngestionPipeline] Dropping corrupted or unknown message schema payload: ${JSON.stringify(rawMessage)}`);
}
