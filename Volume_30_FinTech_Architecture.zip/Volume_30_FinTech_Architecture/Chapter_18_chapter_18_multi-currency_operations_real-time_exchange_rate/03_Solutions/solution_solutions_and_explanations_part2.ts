/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { CurrencyCode } from './exercise-1';

export type AccountId = string & { readonly __brand: unique symbol };

export function createAccountId(id: string): AccountId {
  return id as AccountId;
}

export interface Account {
  id: AccountId;
  name: string;
  currency: CurrencyCode;
  balance: bigint;
  creditLimit: bigint; // Max negative balance allowed (positive magnitude representation)
}

export interface TransactionLeg {
  accountId: AccountId;
  amount: bigint; // Positive for Debit, Negative for Credit
  currency: CurrencyCode;
}

export interface LedgerTransaction {
  id: string;
  timestamp: number;
  legs: TransactionLeg[];
  description: string;
}

export type LedgerError = 
  | { type: 'UNBALANCED_TRANSACTION'; message: string }
  | { type: 'INSUFFICIENT_FUNDS'; accountId: AccountId }
  | { type: 'CURRENCY_MISMATCH'; expected: CurrencyCode; actual: CurrencyCode }
  | { type: 'ACCOUNT_NOT_FOUND'; accountId: AccountId };

export type Result<T, E> = 
  | { success: true; data: T }
  | { success: false; error: E };

export class LedgerEngine {
  private accounts: Map<AccountId, Account> = new Map();

  public registerAccount(account: Account): void {
    this.accounts.set(account.id, account);
  }

  public getAccount(id: AccountId): Account | undefined {
    return this.accounts.get(id);
  }

  public validateJournalBalance(transaction: LedgerTransaction): boolean {
    const currencySums = new Map<string, bigint>();

    for (const leg of transaction.legs) {
      const currentSum = currencySums.get(leg.currency) || 0n;
      currencySums.set(leg.currency, currentSum + leg.amount);
    }

    // Every currency denomination must sum precisely to zero (Debits + Credits = 0)
    for (const sum of currencySums.values()) {
      if (sum !== 0n) {
        return false;
      }
    }

    return true;
  }

  public post(txn: LedgerTransaction): Result<void, LedgerError> {
    // 1. Validate double-entry balance invariant across each currency
    if (!this.validateJournalBalance(txn)) {
      return { 
        success: false, 
        error: { type: 'UNBALANCED_TRANSACTION', message: 'Transaction legs do not sum to zero per currency.' } 
      };
    }

    // 2. Validate accounts, currencies, and resulting balances provisionally
    const accountUpdates = new Map<AccountId, { account: Account; newBalance: bigint }>();

    for (const leg of txn.legs) {
      const account = this.accounts.get(leg.accountId);
      if (!account) {
        return { success: false, error: { type: 'ACCOUNT_NOT_FOUND', accountId: leg.accountId } };
      }

      if (account.currency !== leg.currency) {
        return { 
          success: false, 
          error: { type: 'CURRENCY_MISMATCH', expected: account.currency, actual: leg.currency } 
        };
      }

      const currentBalanceState = accountUpdates.has(leg.accountId) 
        ? accountUpdates.get(leg.accountId)!.newBalance 
        : account.balance;

      const newBalance = currentBalanceState + leg.amount;

      // Check credit limit invariant (Balance cannot drop below -creditLimit)
      if (newBalance < -account.creditLimit) {
        return { success: false, error: { type: 'INSUFFICIENT_FUNDS', accountId: leg.accountId } };
      }

      accountUpdates.set(leg.accountId, { account, newBalance });
    }

    // 3. Apply atomic state mutation
    for (const { account, newBalance } of accountUpdates.values()) {
      account.balance = newBalance;
    }

    return { success: true, data: undefined };
  }

  // Interactive Challenge: Multi-Currency Trial Balance Report Generator
  public generateTrialBalanceReport(
    presentationCurrency: CurrencyCode, 
    rateFetcher: (base: CurrencyCode, quote: CurrencyCode) => bigint // returns scale multiplier
  ): { totalAssets: bigint; totalLiabilitiesAndEquity: bigint; isBalanced: boolean } {
    let totalAssetsConverted = 0n;
    let totalLiabilitiesAndEquityConverted = 0n;

    for (const account of this.accounts.values()) {
      let convertedBalance = account.balance;
      
      if (account.currency !== presentationCurrency) {
        const exchangeRate = rateFetcher(account.currency, presentationCurrency);
        // Assuming exchangeRate is scaled by 1,000,000
        convertedBalance = (account.balance * exchangeRate) / 1,000,000n;
      }

      // Simplified classification: Positive balances considered assets, negative as liabilities/equity
      if (convertedBalance >= 0n) {
        totalAssetsConverted += convertedBalance;
      } else {
        totalLiabilitiesAndEquityConverted += (-convertedBalance);
      }
    }

    // Tolerance range check (within 1 minor unit, i.e., 1)
    const variance = totalAssetsConverted > totalLiabilitiesAndEquityConverted 
      ? totalAssetsConverted - totalLiabilitiesAndEquityConverted 
      : totalLiabilitiesAndEquityConverted - totalAssetsConverted;

    return {
      totalAssets: totalAssetsConverted,
      totalLiabilitiesAndEquity: totalLiabilitiesAndEquityConverted,
      isBalanced: variance <= 1n,
    };
  }
}
