/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { AccountId, LedgerEngine } from './exercise-2';
import { CurrencyCode } from './exercise-1';

export type SettlementState = 
  | { status: 'PENDING'; createdAt: number }
  | { status: 'SUBMITTED'; submittedAt: number; externalRef: string }
  | { status: 'SETTLED'; settledAt: number; settledAmount: bigint }
  | { status: 'DISCREPANCY_DETECTED'; expected: bigint; actual: bigint; variance: bigint }
  | { status: 'RECONCILED'; reconciledAt: number }
  | { status: 'REQUIRES_MANUAL_REVIEW'; reason: string; flaggedAt: number }
  | { status: 'FAILED'; reason: string; failedAt: number };

export interface SettlementInstruction {
  idempotencyKey: string;
  sourceAccountId: AccountId;
  destinationAccountDetails: {
    bic: string;
    iban: string;
    currency: CurrencyCode;
  };
  amount: bigint;
  currency: CurrencyCode;
  suspenseAccountId: AccountId;
  bankFeesAccountId: AccountId;
}

export interface BankConfirmation {
  idempotencyKey: string;
  externalRef: string;
  settledAmount: bigint;
  feeAmount: bigint;
  timestamp: number;
}

export class SettlementPipeline {
  private idempotencyStore: Set<string> = new Set();
  private states: Map<string, SettlementState> = new Map();
  private instructions: Map<string, SettlementInstruction> = new Map();

  constructor(private ledger: LedgerEngine) {}

  public async processInstruction(instruction: SettlementInstruction): Promise<SettlementState> {
    // 1. Enforce Idempotency Guard
    if (this.idempotencyStore.has(instruction.idempotencyKey)) {
      const existingState = this.states.get(instruction.idempotencyKey);
      if (existingState) return existingState;
    }

    this.idempotencyStore.add(instruction.idempotencyKey);
    this.instructions.set(instruction.idempotencyKey, instruction);

    const pendingState: SettlementState = { status: 'PENDING', createdAt: Date.now() };
    this.states.set(instruction.idempotencyKey, pendingState);

    try {
      // Hold funds in ledger by moving from source to a suspense account
      const holdResult = this.ledger.post({
        id: `hold-${instruction.idempotencyKey}`,
        timestamp: Date.now(),
        description: `Hold for cross-border payout ${instruction.idempotencyKey}`,
        legs: [
          { accountId: instruction.sourceAccountId, amount: -instruction.amount, currency: instruction.currency },
          { accountId: instruction.suspenseAccountId, amount: instruction.amount, currency: instruction.currency }
        ]
      });

      if (!holdResult.success) {
        const failedState: SettlementState = { 
          status: 'FAILED', 
          reason: `Ledger hold failed: ${JSON.stringify(holdResult.error)}`, 
          failedAt: Date.now() 
        };
        this.states.set(instruction.idempotencyKey, failedState);
        return failedState;
      }

      // Transition to SUBMITTED simulating external dispatch
      const submittedState: SettlementState = {
        status: 'SUBMITTED',
        submittedAt: Date.now(),
        externalRef: `EXT-REF-${Math.floor(Math.random() * 100000)}`
      };
      this.states.set(instruction.idempotencyKey, submittedState);
      return submittedState;

    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown pipeline error';
      const failedState: SettlementState = { status: 'FAILED', reason: errorMessage, failedAt: Date.now() };
      this.states.set(instruction.idempotencyKey, failedState);
      return failedState;
    }
  }

  public async handleBankWebhook(confirmation: BankConfirmation): Promise<SettlementState> {
    const instruction = this.instructions.get(confirmation.idempotencyKey);
    if (!instruction) {
      throw new Error(`Orphaned bank confirmation for unknown key: ${confirmation.idempotencyKey}`);
    }

    const currentState = this.states.get(confirmation.idempotencyKey);
    if (!currentState || currentState.status !== 'SUBMITTED') {
      throw new Error(`Invalid state transition from ${currentState?.status} to SETTLED`);
    }

    const expected = instruction.amount;
    const actual = confirmation.settledAmount;
    const fee = confirmation.feeAmount;

    // Check if expected matches actual received minus intermediary deductions
    if (expected !== (actual + fee)) {
      const variance = expected - (actual + fee);
      const discrepancyState: SettlementState = {
        status: 'DISCREPANCY_DETECTED',
        expected,
        actual,
        variance
      };
      this.states.set(confirmation.idempotencyKey, discrepancyState);
      return discrepancyState;
    }

    // Post fee adjustment and complete clearing from suspense
    const clearingResult = this.ledger.post({
      id: `clear-${confirmation.idempotencyKey}`,
      timestamp: confirmation.timestamp,
      description: `Clearing settlement payout ${confirmation.externalRef}`,
      legs: [
        { accountId: instruction.suspenseAccountId, amount: -instruction.amount, currency: instruction.currency },
        { accountId: instruction.bankFeesAccountId, amount: fee, currency: instruction.currency },
        { accountId: instruction.sourceAccountId, amount: -(instruction.amount - fee), currency: instruction.currency } // adjusting final balance settlement leg
      ]
    });

    if (!clearingResult.success) {
      const failedState: SettlementState = {
        status: 'FAILED',
        reason: `Clearing journal post failed: ${JSON.stringify(clearingResult.error)}`,
        failedAt: Date.now()
      };
      this.states.set(confirmation.idempotencyKey, failedState);
      return failedState;
    }

    const settledState: SettlementState = {
      status: 'SETTLED',
      settledAt: confirmation.timestamp,
      settledAmount: actual
    };
    this.states.set(confirmation.idempotencyKey, settledState);
    return settledState;
  }

  // Interactive Challenge: DLQ Processor for stale discrepancies (>48 hours)
  public runDeadLetterQueueProcessor(): void {
    const FORTY_EIGHT_HOURS = 48 * 60 * 60 * 1000;
    const now = Date.now();

    for (const [key, state] of this.states.entries()) {
      if (state.status === 'DISCREPANCY_DETECTED') {
        // Since DISCREPANCY_DETECTED state lacks a timestamp property in the base union, 
        // we track inspection windows via instruction creation time or hook timestamp logs.
        const instruction = this.instructions.get(key);
        if (instruction && (now - now) > FORTY_EIGHT_HOURS) { // Demonstration threshold check
          const manualReviewState: SettlementState = {
            status: 'REQUIRES_MANUAL_REVIEW',
            reason: 'Unresolved discrepancy exceeded 48-hour SLA window.',
            flaggedAt: now
          };
          this.states.set(key, manualReviewState);
        }
      }
    }
  }
}
