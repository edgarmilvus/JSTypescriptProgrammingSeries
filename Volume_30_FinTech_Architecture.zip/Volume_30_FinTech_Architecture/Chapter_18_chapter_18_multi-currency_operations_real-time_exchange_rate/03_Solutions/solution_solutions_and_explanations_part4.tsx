/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { CurrencyCode, NormalizedRate } from './exercise-1';

export interface FXWidgetProps {
  availableCurrencies: CurrencyCode[];
  userBalances: Record<string, bigint>;
  onExecuteConversion: (base: CurrencyCode, quote: CurrencyCode, amount: bigint, rate: NormalizedRate) => Promise<void>;
  fetchLatestRate: (base: CurrencyCode, quote: CurrencyCode) => Promise<NormalizedRate>;
}

export const FXConversionWidget: React.FC<FXWidgetProps> = ({
  availableCurrencies,
  userBalances,
  onExecuteConversion,
  fetchLatestRate,
}) => {
  const [baseCurrency, setBaseCurrency] = useState<CurrencyCode>(availableCurrencies[0]);
  const [quoteCurrency, setQuoteCurrency] = useState<CurrencyCode>(availableCurrencies[1]);
  const [amountInput, setAmountInput] = useState<string>('');
  const [currentRate, setCurrentRate] = useState<NormalizedRate | null>(null);
  const [isStale, setIsStale] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(10);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  
  // Interactive Challenge States: Slippage Guard
  const [slippageGuardEnabled, setSlippageGuardEnabled] = useState<boolean>(false);
  const [maxSlippagePercent, setMaxSlippagePercent] = useState<string>('0.5');
  const [slippageWarning, setSlippageWarning] = useState<string | null>(null);

  // Poll or stream live rate effects
  useEffect(() => {
    let isMounted = true;
    const loadRate = async () => {
      try {
        const rate = await fetchLatestRate(baseCurrency, quoteCurrency);
        if (isMounted) {
          setCurrentRate(rate);
          setIsStale(false);
          setCountdown(10); // Reset quote lock timer
        }
      } catch {
        if (isMounted) setIsStale(true);
      }
    };

    loadRate();
    const interval = setInterval(loadRate, 5000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [baseCurrency, quoteCurrency, fetchLatestRate]);

  // Countdown timer effect (10-second quote expiry window)
  useEffect(() => {
    if (countdown <= 0 || !currentRate) return;
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [countdown, currentRate]);

  const handleExecution = async () => {
    if (!currentRate || countdown === 0 || isStale) return;

    const parsedAmount = BigInt(Math.round(Number(amountInput) * 1_000_000));
    const availableBalance = userBalances[baseCurrency] || 0n;

    if (parsedAmount > availableBalance) {
      alert('Error: Input amount exceeds account balance.');
      return;
    }

    setIsExecuting(true);
    setSlippageWarning(null);

    try {
      // Slippage guard check simulation
      if (slippageGuardEnabled) {
        const freshRate = await fetchLatestRate(baseCurrency, quoteCurrency);
        const baselineAsk = Number(currentRate.ask);
        const newAsk = Number(freshRate.ask);
        const deltaPercent = Math.abs((newAsk - baselineAsk) / baselineAsk) * 100;
        const maxAllowed = parseFloat(maxSlippagePercent);

        if (deltaPercent > maxAllowed) {
          setSlippageWarning(`Slippage Guard Triggered! Rate drifted by ${deltaPercent.toFixed(3)}%, exceeding max tolerance of ${maxAllowed}%.`);
          setIsExecuting(false);
          return;
        }
      }

      await onExecuteConversion(baseCurrency, quoteCurrency, parsedAmount, currentRate);
      alert('Conversion successfully executed!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Execution failed';
      alert(`Transaction Error: ${msg}`);
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="fx-conversion-widget p-6 bg-slate-900 text-white rounded-xl shadow-2xl max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4 border-b border-slate-700 pb-2">Corporate Treasury FX Conversion</h2>
      
      {isStale && (
        <div className="bg-amber-600/30 border border-amber-500 p-3 rounded mb-4 text-amber-200 text-sm">
          Warning: Pricing feed connection is stale or disconnected. Quotes unavailable.
        </div>
      )}

      {slippageWarning && (
        <div className="bg-red-600/30 border border-red-500 p-3 rounded mb-4 text-red-200 text-sm" role="alert">
          {slippageWarning}
        </div>
      )}

      <div className="mb-4">
        <label className="block text-xs uppercase tracking-wider text-slate-400 mb-1">Source Account ({baseCurrency})</label>
        <select 
          className="w-full bg-slate-800 border border-slate-700 p-2 rounded text-white"
          value={baseCurrency}
          onChange={(e) => setBaseCurrency(e.target.value as CurrencyCode)}
        >
          {availableCurrencies.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <span className="text-xs text-slate-400 mt-1 block">
          Available Balance: {Number(userBalances[baseCurrency] || 0n) / 1_000_000} {baseCurrency}
        </span>
      </div>

      <div className="mb-4">
        <label className="block text-xs uppercase tracking-wider text-slate-400 mb-1">Target Quote ({quoteCurrency})</label>
        <select 
          className="w-full bg-slate-800 border border-slate-700 p-2 rounded text-white"
          value={quoteCurrency}
          onChange={(e) => setQuoteCurrency(e.target.value as CurrencyCode)}
        >
          {availableCurrencies.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="mb-4">
        <label className="block text-xs uppercase tracking-wider text-slate-400 mb-1">Conversion Amount</label>
        <input 
          type="number" 
          className="w-full bg-slate-800 border border-slate-700 p-2 rounded text-white"
          placeholder="0.00"
          value={amountInput}
          onChange={(e) => setAmountInput(e.target.value)}
        />
      </div>

      {currentRate && (
        <div className="bg-slate-800 p-3 rounded mb-4 flex justify-between items-center text-sm" aria-live="polite">
          <div>
            <span className="text-slate-400 block text-xs">Live Rate</span>
            <span className="font-mono text-emerald-400">Ask: {Number(currentRate.ask) / 1_000_000}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-xs">Quote Expires In</span>
            <span className={`font-mono font-bold ${countdown <= 3 ? 'text-red-400 animate-pulse' : 'text-blue-400'}`}>
              {countdown}s
            </span>
          </div>
        </div>
      )}

      {/* Interactive Challenge Slippage Guard Control */}
      <div className="mb-4 bg-slate-800/60 p-3 rounded border border-slate-700">
        <label className="flex items-center space-x-2 cursor-pointer mb-2">
          <input 
            type="checkbox" 
            checked={slippageGuardEnabled} 
            onChange={(e) => setSlippageGuardEnabled(e.target.checked)}
            className="rounded bg-slate-700 border-slate-600 text-blue-600 focus:ring-blue-500"
          />
          <span className="text-sm font-medium">Enable Slippage Guard</span>
        </label>
        {slippageGuardEnabled && (
          <div>
            <label className="block text-xs text-slate-400 mb-1">Max Tolerance Percentage (%)</label>
            <input 
              type="number" 
              step="0.1" 
              className="w-full bg-slate-900 border border-slate-700 p-1.5 rounded text-sm text-white"
              value={maxSlippagePercent}
              onChange={(e) => setMaxSlippagePercent(e.target.value)}
            />
          </div>
        )}
      </div>

      <button 
        onClick={handleExecution}
        disabled={isExecuting || countdown === 0 || isStale || !amountInput}
        className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold p-3 rounded transition"
      >
        {isExecuting ? 'Executing...' : countdown === 0 ? 'Quote Expired' : 'Lock Quote & Execute'}
      </button>
    </div>
  );
};
