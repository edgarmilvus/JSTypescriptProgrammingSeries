/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton for Exercise 1
import { z } from 'zod';

// Branded types for currency safety
export type CurrencyCode = string & { readonly __brand: unique symbol };

export function createCurrencyCode(code: string): CurrencyCode {
  if (!/^[A-Z]{3}$/.test(code)) {
    throw new Error(`Invalid currency code format: ${code}`);
  }
  return code as CurrencyCode;
}

export interface NormalizedRate {
  base: CurrencyCode;
  quote: CurrencyCode;
  bid: bigint; // Stored in fixed-point integer basis or micro-units
  ask: bigint;
  timestamp: number;
  providerId: string;
}

// TODO: Implement Provider A Zod Schema (String-based decimal values)
export const ProviderARawSchema = z.object({
  // Implement schema definition here
});

// TODO: Implement Provider B Zod Schema (Integer-scaled basis points)
export const ProviderBRawSchema = z.object({
  // Implement schema definition here
});

export class RateCache {
  private cache: Map<string, NormalizedRate> = new Map();

  public updateRate(rate: NormalizedRate): void {
    // TODO: Store rate in cache using a composite key (e.g., `${base}-${quote}`)
  }

  public getRate(base: CurrencyCode, quote: CurrencyCode): NormalizedRate | undefined {
    // TODO: Retrieve and return the latest rate
    return undefined;
  }
}
