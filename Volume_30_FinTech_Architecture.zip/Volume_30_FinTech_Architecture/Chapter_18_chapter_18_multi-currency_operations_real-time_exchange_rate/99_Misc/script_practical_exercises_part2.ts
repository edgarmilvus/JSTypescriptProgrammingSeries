/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton for Exercise 2
import { CurrencyCode } from './exercise-1';

export type AccountId = string & { readonly __brand: unique symbol };

export interface Account {
  id: AccountId;
  name: string;
  currency: CurrencyCode;
  balance: bigint;
  creditLimit: bigint; // Max negative balance allowed
}

export interface TransactionLeg {
  accountId: AccountId;
  amount: bigint; // Positive for debit, negative for credit (or vice versa, specify convention)
  currency: CurrencyCode;
}

export interface LedgerTransaction {
  id: string;
  timestamp: number;
  legs: TransactionLeg[];
  description: string;
}

export type LedgerError = 
  | { type: 'UNBALANCED_TRANSACTION'; message: string }
  | { type: 'INSUFFICIENT_FUNDS'; accountId: AccountId }
  | { type: 'CURRENCY_MISMATCH'; expected: CurrencyCode; actual: CurrencyCode };

export type Result<T, E> = 
  | { success: true; data: T }
  | { success: false; error: E };

export class LedgerEngine {
  private accounts: Map<AccountId, Account> = new Map();

  public registerAccount(account: Account): void {
    this.accounts.set(account.id, account);
  }

  public post(txn: LedgerTransaction): Result<void, LedgerError> {
    // TODO: Implement balance validation, currency verification, and atomic state mutation
    return { success: true, data: undefined };
  }
}
