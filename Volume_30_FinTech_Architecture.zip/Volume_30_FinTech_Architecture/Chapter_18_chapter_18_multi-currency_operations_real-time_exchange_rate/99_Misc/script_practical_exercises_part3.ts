/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton for Exercise 3
import { AccountId, LedgerEngine, LedgerTransaction } from './exercise-2';
import { CurrencyCode } from './exercise-1';

export type SettlementState = 
  | { status: 'PENDING'; createdAt: number }
  | { status: 'SUBMITTED'; submittedAt: number; externalRef: string }
  | { status: 'SETTLED'; settledAt: number; settledAmount: bigint }
  | { status: 'DISCREPANCY_DETECTED'; expected: bigint; actual: bigint; variance: bigint }
  | { status: 'RECONCILED'; reconciledAt: number }
  | { status: 'FAILED'; reason: string; failedAt: number };

export interface SettlementInstruction {
  idempotencyKey: string;
  sourceAccountId: AccountId;
  destinationAccountDetails: {
    bic: string;
    iban: string;
    currency: CurrencyCode;
  };
  amount: bigint;
  currency: CurrencyCode;
}

export interface BankConfirmation {
  externalRef: string;
  settledAmount: bigint;
  feeAmount: bigint;
  timestamp: number;
}

export class SettlementPipeline {
  private idempotencyStore: Set<string> = new Set();
  private states: Map<string, SettlementState> = new Map();

  constructor(private ledger: LedgerEngine) {}

  public processInstruction(instruction: SettlementInstruction): Promise<SettlementState> {
    // TODO: Implement idempotency check, state transition to PENDING, and submission logic
    throw new Error('Not implemented');
  }

  public handleBankWebhook(confirmation: BankConfirmation): Promise<SettlementState> {
    // TODO: Process bank confirmation, calculate variance, and trigger discrepancy handler if needed
    throw new Error('Not implemented');
  }
}
