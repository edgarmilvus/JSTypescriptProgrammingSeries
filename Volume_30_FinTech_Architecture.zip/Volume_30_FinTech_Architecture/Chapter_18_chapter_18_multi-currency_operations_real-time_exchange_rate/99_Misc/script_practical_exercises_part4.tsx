/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Starter Code & Skeleton for Exercise 4
import React, { useState, useEffect } from 'react';
import { CurrencyCode, NormalizedRate } from './exercise-1';

export interface FXWidgetProps {
  availableCurrencies: CurrencyCode[];
  userBalances: Record<CurrencyCode, bigint>;
  onExecuteConversion: (base: CurrencyCode, quote: CurrencyCode, amount: bigint, rate: NormalizedRate) => Promise<void>;
  fetchLatestRate: (base: CurrencyCode, quote: CurrencyCode) => Promise<NormalizedRate>;
}

export const FXConversionWidget: React.FC<FXWidgetProps> = ({
  availableCurrencies,
  userBalances,
  onExecuteConversion,
  fetchLatestRate,
}) => {
  const [baseCurrency, setBaseCurrency] = useState<CurrencyCode>(availableCurrencies[0]);
  const [quoteCurrency, setQuoteCurrency] = useState<CurrencyCode>(availableCurrencies[1]);
  const [amountInput, setAmountInput] = useState<string>('');
  const [currentRate, setCurrentRate] = useState<NormalizedRate | null>(null);
  const [isStale, setIsStale] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(10);

  // TODO: Implement live rate polling/streaming hook integration
  // TODO: Implement quote countdown timer and expiration logic

  return (
    <div className="fx-conversion-widget p-6 bg-slate-900 text-white rounded-xl shadow-2xl">
      <h2 className="text-xl font-bold mb-4">Corporate Treasury FX Conversion</h2>
      {/* TODO: Implement form inputs, currency selectors, balance display, and execution button */}
    </div>
  );
};
