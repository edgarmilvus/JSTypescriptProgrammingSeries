/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { performance } from 'node:perf_hooks';

// ==========================================
// TYPES & INTERfACES
// ==========================================

export interface SettlementInstruction {
    id: string;
    accountId: string;
    counterpartyId: string;
    amountMinorUnits: number; // Stored in cents/satoshis to avoid floating-point errors
    currency: string;
    timestamp: number;
}

export interface BatchProcessingResult {
    processedCount: number;
    failedCount: number;
    totalAmountProcessed: number;
    durationMs: number;
}

// ==========================================
// WORKER THREAD LOGIC (Executed if not Main)
// ==========================================

if (!isMainThread) {
    /**
     * Heavy computation worker. Handles validation, precision math, 
     * and external core-banking API payload preparation for a chunk of records.
     */
    const executeBatchProcessing = async (chunk: SettlementInstruction[]): Promise<BatchProcessingResult> => {
        const startTime = performance.now();
        let processedCount = 0;
        let failedCount = 0;
        let totalAmountProcessed = 0;

        for (const instruction of chunk) {
            try {
                // Validate precision ledger invariants
                if (instruction.amountMinorUnits <= 0) {
                    throw new Error(`Invalid settlement amount for instruction ${instruction.id}`);
                }

                // Simulate secure cryptographic hashing or ledger balance mutation check
                totalAmountProcessed += instruction.amountMinorUnits;
                processedCount++;
            } catch (error) {
                failedCount++;
                // In production, emit to dead-letter queue (DLQ)
            }
        }

        const endTime = performance.now();
        return {
            processedCount,
            failedCount,
            totalAmountProcessed,
            durationMs: endTime - startTime,
        };
    };

    // Listen for messages from the main thread
    parentPort?.on('message', async (chunk: SettlementInstruction[]) => {
        try {
            const result = await executeBatchProcessing(chunk);
            parentPort?.postMessage({ status: 'SUCCESS', result });
        } catch (error: any) {
            parentPort?.postMessage({ status: 'ERROR', error: error.message });
        }
    });
}

// ==========================================
// MAIN THREAD PIPELINE & STREAMING ORCHESTRATION
// ==========================================

if (isMainThread) {
    /**
     * Generates a mock high-volume stream of financial ledger transactions 
     * representing incoming webhook payloads or database cursors.
     */
    function createMockLedgerStream(totalRecords: number): Readable {
        let currentRecord = 0;
        return new Readable({
            objectMode: true,
            read() {
                if (currentRecord >= totalRecords) {
                    this.push(null); // End of stream
                    return;
                }
                
                const record: SettlementInstruction = {
                    id: `txn_${++currentRecord}`,
                    accountId: `acc_${Math.floor(Math.random() * 1000)}`,
                    counterpartyId: `cp_${Math.floor(Math.random() * 500)}`,
                    amountMinorUnits: Math.floor(Math.random() * 100000) + 100, // $1.00 to $1,000.00
                    currency: 'USD',
                    timestamp: Date.now(),
                };
                
                this.push(record);
            }
        });
    }

    /**
     * Custom Transform stream that groups incoming individual stream objects 
     * into fixed-size arrays (batches) before offloading to worker threads.
     */
    class BatchingTransformStream extends Transform {
        private batchSize: number;
        private currentBatch: SettlementInstruction[] = [];

        constructor(batchSize: number = 1000) {
            super({ objectMode: true });
            this.batchSize = batchSize;
        }

        _transform(chunk: SettlementInstruction, encoding: BufferEncoding, callback: Function) {
            this.currentBatch.push(chunk);
            if (this.currentBatch.length >= this.batchSize) {
                this.push(this.currentBatch);
                this.currentBatch = [];
            }
            callback();
        }

        _flush(callback: Function) {
            if (this.currentBatch.length > 0) {
                this.push(this.currentBatch);
                this.currentBatch = [];
            }
            callback();
        }
    }

    /**
     * Spawns a worker thread to process a single batch asynchronously.
     */
    async function processBatchViaWorker(batch: SettlementInstruction[]): Promise<BatchProcessingResult> {
        return new Promise((resolve, reject) => {
            const worker = new Worker(__filename, { workerData: {} });
            
            worker.postMessage(batch);
            
            worker.on('message', (message) => {
                worker.terminate();
                if (message.status === 'SUCCESS') {
                    resolve(message.result);
                } else {
                    reject(new Error(message.error));
                }
            });

            worker.on('error', (err) => {
                worker.terminate();
                reject(err);
            });
        });
    }

    // ==========================================
    // EXECUTION ENTRYPOINT
    // ==========================================

    (async () => {
        console.log('[Settlement Engine] Initializing high-throughput settlement pipeline...');
        const startTime = performance.now();

        const TOTAL_RECORDS_TO_SIMULATE = 50_000;
        const BATCH_SIZE = 5000;
        
        const inputStream = createMockLedgerStream(TOTAL_RECORDS_TO_SIMULATE);
        const batchStream = new BatchingTransformStream(BATCH_SIZE);

        let totalProcessed = 0;
        let totalFailed = 0;
        let cumulativeVolume = 0;

        // Pipe stream data and handle backpressure safely
        const processingPromise = pipeline(
            inputStream,
            batchStream,
            async function* (source) {
                for await (const batch of source) {
                    try {
                        console.log(`[Pipeline] Offloading batch of ${batch.length} items to worker thread...`);
                        const result = await processBatchViaWorker(batch as SettlementInstruction[]);
                        totalProcessed += result.processedCount;
                        totalFailed += result.failedCount;
                        cumulativeVolume += result.totalAmountProcessed;
                        yield result;
                    } catch (err: any) {
                        console.error(`[Pipeline Error] Batch processing failed: ${err.message}`);
                    }
                }
            }
        );

        await processingPromise;
        
        const endTime = performance.now();
        console.log('============================================');
        console.log('[Settlement Engine] End-of-Day Pipeline Complete.');
        console.log(`- Total Records Processed: ${totalProcessed}`);
        console.log(`- Total Failed Records:    ${totalFailed}`);
        console.log(`- Cumulative Volume:       $${(cumulativeVolume / 100).toFixed(2)} USD`);
        console.log(`- Execution Time:          ((endTime - startTime).toFixed(2)) ms`);
        console.log('============================================');
    })().catch((err) => {
        console.error('[Fatal Error] Settlement pipeline crashed:', err);
        process.exit(1);
    });
}
