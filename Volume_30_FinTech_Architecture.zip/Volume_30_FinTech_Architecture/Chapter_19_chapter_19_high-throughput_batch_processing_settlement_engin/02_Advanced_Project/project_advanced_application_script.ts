/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import { Readable, Transform, Writable } from 'stream';
import { pipeline } from 'stream/promises';
import { createClient } from 'redis';
import { performance } from 'perf_hooks';

/**
 * Interface representing a raw ledger entry fetched from the transaction store.
 */
interface LedgerTransaction {
  id: string;
  accountId: string;
  amountMinorUnits: number; // Stored as integer to prevent floating-point precision loss
  currency: string;
  type: 'DEBIT' | 'CREDIT';
  timestamp: number;
  idempotencyKey: string;
}

/**
 * Interface representing the aggregated settlement state for an account.
 */
interface SettlementSummary {
  accountId: string;
  netChangeMinorUnits: number;
  transactionCount: number;
  currency: string;
}

/**
 * Configuration options for the batch settlement engine.
 */
interface SettlementConfig {
  batchSize: number;
  concurrencyLimit: number;
  redisUrl: string;
  settlementDate: string;
}

/**
 * Redis client singleton for distributed locking and state tracking.
 */
const redisClient = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });

/**
 * Distributed Lock Utility using Redis SET NX PX to guarantee exactly-once
 * execution of settlement batches across multiple worker nodes.
 */
async function acquireDistributedLock(lockKey: string, ttlMs: number = 30000): Promise<boolean> {
  if (!redisClient.isOpen) {
    await redisClient.connect();
  }
  const result = await redisClient.set(lockKey, 'LOCKED', {
    NX: true,
    PX: ttlMs,
  });
  return result === 'OK';
}

/**
 * Releases the distributed lock.
 */
async function releaseDistributedLock(lockKey: string): Promise<void> {
  if (redisClient.isOpen) {
    await redisClient.del(lockKey);
  }
}

/**
 * Worker Thread Execution Logic
 * Handles CPU-bound ledger calculations for a chunk of transactions.
 */
if (!isMainThread) {
  const transactions: LedgerTransaction[] = workerData.transactions;
  
  // Aggregate transactions by account ID
  const summaryMap = new Map<string, SettlementSummary>();

  for (const tx of transactions) {
    const current = summaryMap.get(tx.accountId) || {
      accountId: tx.accountId,
      netChangeMinorUnits: 0,
      transactionCount: 0,
      currency: tx.currency,
    };

    const multiplier = tx.type === 'CREDIT' ? 1 : -1;
    current.netChangeMinorUnits += tx.amountMinorUnits * multiplier;
    current.transactionCount += 1;

    summaryMap.set(tx.accountId, current);
  }

  // Send aggregated results back to the main thread
  const results = Array.from(summaryMap.values());
  parentPort?.postMessage(results);
} else {
  /**
   * Main Thread Settlement Pipeline Orchestrator
   */
  class SettlementEngine {
    private config: SettlementConfig;

    constructor(config: SettlementConfig) {
      this.config = config;
    }

    /**
     * Simulates a readable stream of transactions from a database cursor or file.
     */
    private createTransactionSourceStream(): Readable {
      let dispatchedCount = 0;
      const totalTransactions = 500_000; // Simulated large dataset

      return new Readable({
        objectMode: true,
        read() {
          if (dispatchedCount >= totalTransactions) {
            this.push(null); // End of stream
            return;
          }

          const chunkLimit = Math.min(1000, totalTransactions - dispatchedCount);
          const batch: LedgerTransaction[] = [];

          for (let i = 0; i < chunkLimit; i++) {
            dispatchedCount++;
            batch.push({
              id: `tx_${dispatchedCount}`,
              accountId: `acc_${(dispatchedCount % 5000) + 1}`,
              amountMinorUnits: Math.floor(Math.random() * 10000) + 1,
              currency: 'USD',
              type: dispatchedCount % 2 === 0 ? 'CREDIT' : 'DEBIT',
              timestamp: Date.now(),
              idempotencyKey: `idem_${dispatchedCount}`,
            });
          }

          this.push(batch);
        },
      });
    }

    /**
     * Creates a Transform stream that offloads chunk processing to Worker Threads.
     */
    private createWorkerTransformStream(): Transform {
      return new Transform({
        objectMode: true,
        transform(chunk: LedgerTransaction[], encoding, callback) {
          const worker = new __filename, {
            workerData: { transactions: chunk },
          };

          worker.on('message', (summaries: SettlementSummary[]) => {
            callback(null, summaries);
          });

          worker.on('error', (err) => {
            callback(err);
          });

          worker.on('exit', (code) => {
            if (code !== 0) {
              callback(new Error(`Worker stopped with exit code ${code}`));
            }
          });
        },
      });
    }

    /**
     * Creates a Writable stream to persist aggregated settlements to the database.
     */
    private createPersistenceWriteStream(): Writable {
      return new Writable({
        objectMode: true,
        write(summaries: SettlementSummary[], encoding, callback) {
          // In a real application, perform a bulk upsert into the database
          // e.g., PostgreSQL INSERT INTO settlements ... ON CONFLICT (account_id) DO UPDATE ...
          setTimeout(() => {
            console.log(`[Persistence] Successfully flushed ${summaries.length} account summaries.`);
            callback();
          }, 10); // Simulate DB I/O latency
        },
      });
    }

    /**
     * Executes the end-to-end settlement pipeline.
     */
    public async run(): Promise<void> {
      const lockKey = `lock:settlement:${this.config.settlementDate}`;
      const acquired = await acquireDistributedLock(lockKey, 60000);

      if (!acquired) {
        console.warn(`[SettlementEngine] Settlement for date ${this.config.settlementDate} is already running. Aborting.`);
        return;
      }

      const startTime = performance.now();
      console.log(`[SettlementEngine] Starting settlement pipeline for ${this.config.settlementDate}...`);

      try {
        await pipeline(
          this.createTransactionSourceStream(),
          this.createWorkerTransformStream(),
          this.createPersistenceWriteStream()
        );

        const duration = (performance.now() - startTime) / 1000;
        console.log(`[SettlementEngine] Settlement completed successfully in ${duration.toFixed(2)}s.`);
      } catch (error) {
        console.error('[SettlementEngine] Pipeline failed with error:', error);
        throw error;
      } finally {
        await releaseDistributedLock(lockKey);
        if (redisClient.isOpen) {
          await redisClient.quit();
        }
      }
    }
  }

  // Example execution context
  if (require.main === module) {
    const engine = new SettlementEngine({
      batchSize: 1000,
      concurrencyLimit: 4,
      redisUrl: 'redis://localhost:6379',
      settlementDate: '2023-10-25',
    });

    engine.run().catch((err) => {
      console.error('Fatal settlement engine error:', err);
      process.exit(1);
    });
  }
}
