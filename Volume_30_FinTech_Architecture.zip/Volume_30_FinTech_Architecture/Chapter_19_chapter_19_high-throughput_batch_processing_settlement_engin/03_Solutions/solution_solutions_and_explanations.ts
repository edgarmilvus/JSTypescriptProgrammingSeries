/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Transform, TransformCallback } from 'node:stream';
import { createReadStream, createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import * as readline from 'node:readline';

export interface RawTransaction {
  id: string;
  amount: string; // Stored as string to prevent float precision loss
  currency: string;
  sourceAccount: string;
  destinationAccount: string;
  timestamp: number;
}

export interface NormalizedTransaction {
  transactionId: string;
  amountMinorUnits: bigint;
  currencyCode: string;
  debitAccount: string;
  creditAccount: string;
  executionTimestamp: Date;
}

export class TransactionNormalizationTransform extends Transform {
  private recordsProcessed = 0;
  private recordsDropped = 0;
  private bytesRead = 0;
  private dlqStream: ReturnType<typeof createWriteStream>;

  constructor(dlqFilePath: string) {
    super({
      objectMode: true,
      highWaterMark: 1024 // Controls buffer capacity and backpressure
    });
    this.dlqStream = createWriteStream(dlqFilePath, { flags: 'a' });
  }

  public _transform(
    chunk: any, 
    encoding: BufferEncoding, 
    callback: TransformCallback
  ): void {
    try {
      this.bytesRead += Buffer.byteLength(chunk);
      const raw: RawTransaction = JSON.parse(chunk.toString());

      // Type guard and invariant validation
      if (
        !raw.id ||
        typeof raw.amount !== 'string' ||
        !raw.currency ||
        !raw.sourceAccount ||
        !raw.destinationAccount ||
        isNaN(Number(raw.amount))
      ) {
        this.recordsDropped++;
        this.dlqStream.write(JSON.stringify({ raw, reason: 'INVALID_SCHEMA', timestamp: Date.now() }) + '\n');
        return callback();
      }

      const amountFloat = parseFloat(raw.amount);
      if (amountFloat <= 0) {
        this.recordsDropped++;
        this.dlqStream.write(JSON.stringify({ raw, reason: 'NON_POSITIVE_AMOUNT', timestamp: Date.now() }) + '\n');
        return callback();
      }

      // Convert to minor units (assuming 2 decimal places standard, e.g., cents)
      const amountMinorUnits = BigInt(Math.round(amountFloat * 100));

      const normalized: NormalizedTransaction = {
        transactionId: raw.id,
        amountMinorUnits,
        currencyCode: raw.currency.toUpperCase(),
        debitAccount: raw.sourceAccount,
        creditAccount: raw.destinationAccount,
        executionTimestamp: new Date(raw.timestamp)
      };

      this.recordsProcessed++;
      this.push(normalized);
      callback();
    } catch (err: any) {
      this.recordsDropped++;
      this.dlqStream.write(JSON.stringify({ chunk: chunk.toString(), error: err.message, timestamp: Date.now() }) + '\n');
      callback();
    }
  }

  public _flush(callback: TransformCallback): void {
    this.dlqStream.end();
    console.info(`[Telemetry] Processed: ${this.recordsProcessed}, Dropped: ${this.recordsDropped}, Bytes: ${this.bytesRead}, Peak RSS: ${process.memoryUsage().rss}`);
    callback();
  }
}

export async function runSettlementStreamPipeline(
  inputFilePath: string,
  outputFilePath: string,
  dlqFilePath: string
): Promise<void> {
  const fileStream = createReadStream(inputFilePath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  const transformer = new TransactionNormalizationTransform(dlqFilePath);
  const outputStream = createWriteStream(outputFilePath);

  // Custom readable wrapper for readline to feed into stream pipeline
  const { Readable } = await import('node:stream');
  const readlineStream = Readable.from(
    (async function* () {
      for await (const line of rl) {
        if (line.trim()) yield line + '\n';
      }
    })(),
    { objectMode: false, highWaterMark: 1024 }
  );

  await pipeline(
    readlineStream,
    transformer,
    new Transform({
      objectMode: true,
      transform(chunk: NormalizedTransaction, enc, cb) {
        cb(null, JSON.stringify(chunk, (_, v) => typeof v === 'bigint' ? v.toString() : v) + '\n');
      }
    }),
    outputStream
  );
}
