/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Worker } from 'node:worker_threads';
import { EventEmitter } from 'node:events';

export interface SettlementTask {
  batchId: string;
  transactions: Array<{
    id: string;
    amountMinorUnits: string; // Serialized BigInt for thread transfer
    currencyCode: string;
  }>;
}

export interface SettlementResult {
  batchId: string;
  postings: Array<{
    transactionId: string;
    entries: Array<{
      account: string;
      direction: 'DEBIT' | 'CREDIT';
      amountMinorUnits: string;
    }>;
  }>;
  errors: Array<{
    transactionId: string;
    reason: string;
  }>;
}

export class SettlementWorkerPool extends EventEmitter {
  private workers: Worker[] = [];
  private freeWorkers: Worker[] = [];
  private taskQueue: Array<{
    task: SettlementTask;
    resolve: (result: SettlementResult) => void;
    reject: (error: Error) => void;
    retries: number;
  }> = [];

  constructor(private poolSize: number, private workerScriptPath: string) {
    super();
    this.initializePool();
  }

  private initializePool(): void {
    for (let i = 0; i < this.poolSize; i++) {
      this.spawnWorker();
    }
  }

  private spawnWorker(): void {
    const worker = new Worker(this.workerScriptPath);
    
    worker.on('message', (message: { batchId: string; result?: SettlementResult; error?: string }) => {
      const busyIndex = this.workers.indexOf(worker);
      // Worker finished task, return to free pool
      this.freeWorkers.push(worker);
      this.processQueue();
    });

    worker.on('error', (err) => {
      this.handleWorkerFailure(worker, err);
    });

    worker.on('exit', (code) => {
      if (code !== 0) {
        this.handleWorkerFailure(worker, new Error(`Worker stopped with exit code ${code}`));
      }
    });

    this.workers.push(worker);
    this.freeWorkers.push(worker);
  }

  private handleWorkerFailure(deadWorker: Worker, error: Error): void {
    const index = this.workers.indexOf(deadWorker);
    if (index !== -1) {
      this.workers.splice(index, 1);
      const freeIndex = this.freeWorkers.indexOf(deadWorker);
      if (freeIndex !== -1) this.freeWorkers.splice(freeIndex, 1);
    }
    deadWorker.terminate();
    // Spawn replacement worker
    this.spawnWorker();
    this.emit('workerError', { error });
  }

  public async runTask(task: SettlementTask): Promise<SettlementResult> {
    return new Promise((resolve, reject) => {
      this.taskQueue.push({ task, resolve, reject, retries: 0 });
      this.processQueue();
    });
  }

  private processQueue(): void {
    if (this.taskQueue.length === 0 || this.freeWorkers.length === 0) {
      return;
    }

    const worker = this.freeWorkers.pop()!;
    const { task, resolve, reject, retries } = this.taskQueue.shift()!;

    const messageHandler = (message: { batchId: string; result?: SettlementResult; error?: string }) => {
      if (message.batchId === task.batchId) {
        worker.off('message', messageHandler);
        if (message.error) {
          if (retries < 3) {
            // Re-queue with retry count
            this.taskQueue.push({ task, resolve, reject, retries: retries + 1 });
          } else {
            reject(new Error(message.error));
          }
        } else if (message.result) {
          resolve(message.result);
        }
      }
    };

    worker.on('message', messageHandler);
    worker.postMessage(task);
  }

  public async terminate(): Promise<void> {
    await Promise.all(this.workers.map(w => w.terminate()));
    this.workers = [];
    this.freeWorkers = [];
  }
}
