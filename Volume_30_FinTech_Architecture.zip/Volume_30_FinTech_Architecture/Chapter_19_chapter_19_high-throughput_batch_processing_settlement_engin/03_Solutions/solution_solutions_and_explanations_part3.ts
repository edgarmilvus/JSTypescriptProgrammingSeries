/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis';
import { PoolClient } from 'pg';
import { randomBytes } from 'node:crypto';

export interface LockOptions {
  ttlMs: number;
  retryCount: number;
  retryDelayMs: number;
}

export class BatchLockManager {
  constructor(private redisClient: Redis) {}

  public async acquireLock(batchId: string, options: LockOptions): Promise<string | null> {
    const resourceKey = `lock:batch:${batchId}`;
    const lockToken = randomBytes(16).toString('hex');

    for (let i = 0; i < options.retryCount; i++) {
      const result = await this.redisClient.set(resourceKey, lockToken, 'PX', options.ttlMs, 'NX');
      if (result === 'OK') {
        return lockToken;
      }
      await new Promise(res => setTimeout(res, options.retryDelayMs));
    }
    return null;
  }

  public async releaseLock(batchId: string, lockToken: string): Promise<boolean> {
    const resourceKey = `lock:batch:${batchId}`;
    const luaScript = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
      else
        return 0
      end
    `;
    const res = await this.redisClient.eval(luaScript, 1, resourceKey, lockToken);
    return res === 1;
  }

  public async extendLock(batchId: string, lockToken: string, additionalTtlMs: number): Promise<boolean> {
    const resourceKey = `lock:batch:${batchId}`;
    const luaScript = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("pexpire", KEYS[1], ARGV[2])
      else
        return 0
      end
    `;
    const res = await this.redisClient.eval(luaScript, 1, resourceKey, lockToken, additionalTtlMs);
    return res === 1;
  }
}

export async function executeIdempotentBatchCommit(
  dbClient: PoolClient,
  batchId: string,
  postings: Array<any>
): Promise<{ status: 'COMMITTED' | 'ALREADY_EXCEPTED' | 'CONFLICT' }> {
  try {
    await dbClient.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE');

    // 1. Check idempotency audit log table
    const auditCheck = await dbClient.query(
      'SELECT status FROM settlement_audit_log WHERE batch_id = $1 FOR UPDATE',
      [batchId]
    );

    if (auditCheck.rows.length > 0) {
      const currentStatus = auditCheck.rows[0].status;
      await dbClient.query('COMMIT');
      return { status: currentStatus === 'COMPLETED' ? 'ALREADY_EXCEPTED' : 'CONFLICT' };
    }

    // 2. Insert audit log record as PENDING
    await dbClient.query(
      'INSERT INTO settlement_audit_log (batch_id, status, created_at) VALUES ($1, $2, NOW())',
      [batchId, 'PENDING']
    );

    // 3. Insert double-entry ledger postings
    for (const posting of postings) {
      for (const entry of posting.entries) {
        await dbClient.query(
          'INSERT INTO ledger_entries (transaction_id, account, direction, amount_minor_units) VALUES ($1, $2, $3, $4)',
          [posting.transactionId, entry.account, entry.direction, entry.amountMinorUnits]
        );
      }
    }

    // 4. Update audit log to COMPLETED
    await dbClient.query(
      'UPDATE settlement_audit_log SET status = $1, completed_at = NOW() WHERE batch_id = $2',
      ['COMPLETED', batchId]
    );

    await dbClient.query('COMMIT');
    return { status: 'COMMITTED' };
  } catch (err) {
    await dbClient.query('ROLLBACK');
    throw err;
  }
}
