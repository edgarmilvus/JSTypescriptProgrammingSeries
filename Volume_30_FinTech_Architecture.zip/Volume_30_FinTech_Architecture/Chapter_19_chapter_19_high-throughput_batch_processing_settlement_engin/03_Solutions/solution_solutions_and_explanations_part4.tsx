/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useReducer, useCallback } from 'react';

export type PipelineStatus = 'IDLE' | 'RUNNING' | 'PAUSED' | 'FAILED' | 'COMPLETED';

export interface TelemetryPayload {
  batchId: string;
  status: PipelineStatus;
  totalRecords: number;
  processedRecords: number;
  failedRecords: number;
  activeWorkers: number;
  memoryUsageRssMb: number;
  timestamp: number;
}

interface DashboardState {
  connectionStatus: 'CONNECTING' | 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  activeBatches: Map<string, TelemetryPayload>;
  dlqCount: number;
  lastError: string | null;
}

type DashboardAction =
  | { type: 'SET_CONNECTION'; payload: DashboardState['connectionStatus'] }
  | { type: 'UPDATE_TELEMETRY'; payload: TelemetryPayload }
  | { type: 'SET_ERROR'; payload: string };

const dashboardReducer = (state: DashboardState, action: DashboardAction): DashboardState => {
  switch (action.type) {
    case 'SET_CONNECTION':
      return { ...state, connectionStatus: action.payload };
    case 'UPDATE_TELEMETRY': {
      const newBatches = new Map(state.activeBatches);
      newBatches.set(action.payload.batchId, action.payload);
      return { ...state, activeBatches: newBatches };
    }
    case 'SET_ERROR':
      return { ...state, lastError: action.payload, connectionStatus: 'ERROR' };
    default:
      return state;
  }
};

export const SettlementDashboard: React.FC<{ websocketUrl: string }> = ({ websocketUrl }) => {
  const [state, dispatch] = useReducer(dashboardReducer, {
    connectionStatus: 'CONNECTING',
    activeBatches: new Map(),
    dlqCount: 0,
    lastError: null
  });

  useEffect(() => {
    let ws: WebSocket;
    let throttleTimer: NodeJS.Timeout | null = null;
    let pendingPayloads: TelemetryPayload[] = [];

    const connect = () => {
      dispatch({ type: 'SET_CONNECTION', payload: 'CONNECTING' });
      ws = new WebSocket(websocketUrl);

      ws.onopen = () => dispatch({ type: 'SET_CONNECTION', payload: 'CONNECTED' });
      ws.onclose = () => {
        dispatch({ type: 'SET_CONNECTION', payload: 'DISCONNECTED' });
        setTimeout(connect, 3000);
      };
      ws.onerror = (err) => dispatch({ type: 'SET_ERROR', payload: 'WebSocket failure occurred.' });

      ws.onmessage = (event) => {
        try {
          const payload: TelemetryPayload = JSON.parse(event.data);
          pendingPayloads.push(payload);

          if (!throttleTimer) {
            throttleTimer = setTimeout(() => {
              pendingPayloads.forEach(p => dispatch({ type: 'UPDATE_TELEMETRY', payload: p }));
              pendingPayloads = [];
              throttleTimer = null;
            }, 16); // Throttle to max 60fps
          }
        } catch (e) {
          console.error('Failed to parse telemetry message', e);
        }
      };
    };

    connect();

    return () => {
      if (ws) ws.close();
      if (throttleTimer) clearTimeout(throttleTimer);
    };
  }, [websocketUrl]);

  return (
    <div className="settlement-dashboard-container" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Settlement Engine Telemetry Dashboard</h2>
      <div style={{ marginBottom: '15px' }}>
        <strong>Status: </strong> 
        <span style={{ color: state.connectionStatus === 'CONNECTED' ? 'green' : 'red' }}>
          {state.connectionStatus}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
        {Array.from(state.activeBatches.values()).map((batch) => {
          const percent = batch.totalRecords > 0 ? (batch.processedRecords / batch.totalRecords) * 100 : 0;
          return (
            <div key={batch.batchId} style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '8px' }}>
              <h4>Batch ID: {batch.batchId}</h4>
              <p>Status: {batch.status}</p>
              <p>Processed: {batch.processedRecords} / {batch.totalRecords} ({percent.toFixed(1)}%)</p>
              <div style={{ background: '#eee', borderRadius: '4px', height: '10px', width: '100%', overflow: 'hidden' }}>
                <div style={{ background: '#4caf50', width: `${percent}%`, height: '100%' }} />
              </div>
              <p style={{ fontSize: '0.85rem', color: '#666', marginTop: '10px' }}>
                Active Workers: {batch.activeWorkers} | RSS Memory: {batch.memoryUsageRssMb} MB
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
