/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { createHash } from 'node:crypto';

export type DiscrepancyType = 'ORPHAN_INTERNAL' | 'ORPHAN_EXTERNAL' | 'AMOUNT_MISMATCH';

export interface ReconciliationDiscrepancy {
  transactionId: string;
  type: DiscrepancyType;
  internalAmountMinorUnits?: bigint;
  externalAmountMinorUnits?: bigint;
  currency: string;
  detectedAt: Date;
}

export interface ReconciliationReport {
  reportId: string;
  totalInternalRecords: number;
  totalExternalRecords: number;
  matchedCount: number;
  discrepancies: ReconciliationDiscrepancy[];
  integrityHash: string;
}

export class LedgerReconciliationEngine {
  constructor(
    private internalDataSource: AsyncIterable<any>, 
    private externalClearinghouseSource: AsyncIterable<any>
  ) {}

  public async *reconcile(): AsyncGenerator<ReconciliationDiscrepancy[], void, unknown> {
    const internalMap = new Map<string, { amount: bigint; currency: string }>();
    const externalMap = new Map<string, { amount: bigint; currency: string }>();

    for await (const item of this.internalDataSource) {
      internalMap.set(item.transactionId, { 
        amount: BigInt(item.amountMinorUnits), 
        currency: item.currencyCode 
      });
    }

    for await (const item of this.externalClearinghouseSource) {
      externalMap.set(item.transactionId, { 
        amount: BigInt(item.amountMinorUnits), 
        currency: item.currencyCode 
      });
    }

    const batch: ReconciliationDiscrepancy[] = [];
    const now = new Date();

    // Check internal against external
    for (const [id, internal] of internalMap.entries()) {
      const external = externalMap.get(id);
      if (!external) {
        batch.push({
          transactionId: id,
          type: 'ORPHAN_INTERNAL',
          internalAmountMinorUnits: internal.amount,
          currency: internal.currency,
          detectedAt: now
        });
      } else if (external.amount !== internal.amount || external.currency !== internal.currency) {
        batch.push({
          transactionId: id,
          type: 'AMOUNT_MISMATCH',
          internalAmountMinorUnits: internal.amount,
          externalAmountMinorUnits: external.amount,
          currency: internal.currency,
          detectedAt: now
        });
      }
      externalMap.delete(id); // Processed
      if (batch.length >= 1000) {
        yield batch.splice(0, batch.length);
      }
    }

    // Remaining external items are orphans
    for (const [id, external] of externalMap.entries()) {
      batch.push({
        transactionId: id,
        type: 'ORPHAN_EXTERNAL',
        externalAmountMinorUnits: external.amount,
        currency: external.currency,
        detectedAt: now
      });
      if (batch.length >= 1000) {
        yield batch.splice(0, batch.length);
      }
    }

    if (batch.length > 0) {
      yield batch;
    }
  }

  public async generateFinalReport(reportId: string): Promise<ReconciliationReport> {
    const discrepancies: ReconciliationDiscrepancy[] = [];
    let totalInternalRecords = 0;
    let totalExternalRecords = 0;
    let matchedCount = 0;

    // Stream through generator batches
    for await (const batch of this.reconcile()) {
      discrepancies.push(...batch);
    }

    // Compute cryptographic SHA-256 integrity hash for compliance verification
    const reportPayload = JSON.stringify({ reportId, discrepancies }, (_, v) => typeof v === 'bigint' ? v.toString() : v);
    const integrityHash = createHash('sha256').update(reportPayload).digest('hex');

    return {
      reportId,
      totalInternalRecords,
      totalExternalRecords,
      matchedCount,
      discrepancies,
      integrityHash
    };
  }
}
