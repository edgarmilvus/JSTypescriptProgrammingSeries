/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { Transform, TransformCallback } from 'node:stream';
import { createReadStream, createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import * as readline from 'node:readline';

// Define your types here
export interface RawTransaction {
  id: string;
  amount: string; // Stored as string to prevent float precision loss
  currency: string;
  sourceAccount: string;
  destinationAccount: string;
  timestamp: number;
}

export interface NormalizedTransaction {
  transactionId: string;
  amountMinorUnits: bigint;
  currencyCode: string;
  debitAccount: string;
  creditAccount: string;
  executionTimestamp: Date;
}

export class TransactionNormalizationTransform extends Transform {
  // TODO: Implement internal counters and state tracking
  
  constructor() {
    super({
      objectMode: true,
      highWaterMark: 1024 // Control buffer capacity
    });
  }

  public _transform(
    chunk: any, 
    encoding: BufferEncoding, 
    callback: TransformCallback
  ): void {
    // TODO: Implement line parsing, validation, decimal conversion to BigInt,
    // and push downstream or route to DLQ
  }
}

export async function runSettlementStreamPipeline(
  inputFilePath: string,
  outputFilePath: string,
  dlqFilePath: string
): Promise<void> {
  // TODO: Wire up createReadStream, readline interface, transform, and output streams using pipeline()
}
