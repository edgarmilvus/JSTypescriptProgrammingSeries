/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

import { randomUUID } from 'crypto';

// ==========================================
// 1. DOMAIN TYPES & BRIDGED PRIMITIVES
// ==========================================

/**
 * Represents monetary value as an integer in the smallest currency unit (e.g., cents).
 * Prevents IEEE 754 floating-point rounding errors.
 */
type Cents = number;

export enum AccountType {
  ASSET = 'ASSET',
  LIABILITY = 'LIABILITY',
  EQUITY = 'EQUITY',
  REVENUE = 'REVENUE',
  EXPENSE = 'EXPENSE',
}

export enum PostingDirection {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT',
}

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  currency: string;
}

export interface Posting {
  accountId: string;
  direction: PostingDirection;
  amount: Cents;
}

export interface JournalTransaction {
  id: string;
  timestamp: Date;
  description: string;
  postings: Posting[];
  metadata?: Record<string, unknown>;
}

export class LedgerValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LedgerValidationError';
  }
}

// ==========================================
// 2. PRECISION MATH & INVARIANT ENGINE
// ==========================================

export class LedgerMath {
  /**
   * Validates that the sum of all DEBIT postings equals the sum of all CREDIT postings.
   * This is the fundamental invariant of double-entry bookkeeping.
   */
  public static validateDoubleEntry(postings: Posting[]): void {
    let totalDebits: Cents = 0;
    let totalCredits: Cents = 0;

    for (const posting of postings) {
      if (posting.amount <= 0) {
        throw new LedgerValidationError(
          `Posting amount must be strictly greater than zero. Invalid amount: ${posting.amount}`
        );
      }

      if (posting.direction === PostingDirection.DEBIT) {
        totalDebits += posting.amount;
      } else if (posting.direction === PostingDirection.CREDIT) {
        totalCredits += posting.amount;
      } else {
        throw new LedgerValidationError(`Unknown posting direction: ${posting.direction}`);
      }
    }

    if (totalDebits !== totalCredits) {
      throw new LedgerValidationError(
        `Double-entry invariant violated. Total Debits (${totalDebits}) do not equal Total Credits (${totalCredits}).`
      );
    }
  }

  /**
   * Safely distributes a total amount into N split proportions without losing fractional cents.
   */
  public static splitAmount(total: Cents, ratios: number[]): Cents[] {
    const totalRatio = ratios.reduce((acc, r) => acc + r, 0);
    if (totalRatio <= 0) {
      throw new LedgerValidationError('Sum of ratios must be greater than zero.');
    }

    let allocatedSum = 0;
    const splits = ratios.map((ratio, index) => {
      // If it's the last item, allocate the exact remainder to prevent rounding drift
      if (index === ratios.length - 1) {
        return total - allocatedSum;
      }
      const share = Math.round((total * ratio) / totalRatio);
      allocatedSum += share;
      return share;
    });

    return splits;
  }
}

// ==========================================
// 3. IMMUTABLE LEDGER STORAGE & ENGINE
// ==========================================

export class CoreLedgerEngine {
  private accounts: Map<string, Account> = new Map();
  private transactions: JournalTransaction[] = [];
  private accountBalances: Map<string, Cents> = new Map();

  public createAccount(name: string, type: AccountType, currency: string = 'USD'): Account {
    const account: Account = {
      id: `acc_${randomUUID()}`,
      name,
      type,
      currency,
    };
    this.accounts.set(account.id, account);
    this.accountBalances.set(account.id, 0);
    return account;
  }

  /**
   * Atomically commits a balanced journal transaction to the ledger.
   * If validation fails, the ledger state remains completely unmutated.
   */
  public commitTransaction(
    description: string,
    postings: Posting[],
    metadata?: Record<string, unknown>
  ): JournalTransaction {
    // 1. Enforce Double-Entry Invariant
    LedgerMath.validateDoubleEntry(postings);

    // 2. Verify all accounts exist and share currency context
    for (const posting of postings) {
      if (!this.accounts.has(posting.accountId)) {
        throw new LedgerValidationError(`Account not found: ${posting.accountId}`);
      }
    }

    // 3. Calculate tentative new balances to ensure no negative asset constraints are violated if applicable
    const tentativeBalances = new Map(this.accountBalances);
    for (const posting of postings) {
      const currentBalance = tentativeBalances.get(posting.accountId) || 0;
      const account = this.accounts.get(posting.accountId)!;

      // Normal balance rule application:
      // ASSET & EXPENSE increase with DEBIT, decrease with CREDIT.
      // LIABILITY, EQUITY & REVENUE increase with CREDIT, decrease with DEBIT.
      const isNormalDebit =
        account.type === AccountType.ASSET || account.type === AccountType.EXPENSE;

      const delta =
        posting.direction === PostingDirection.DEBIT
          ? isNormalDebit
            ? posting.amount
            : -posting.amount
          : isNormalDebit
          ? -posting.amount
          : posting.amount;

      tentativeBalances.set(posting.accountId, currentBalance + delta);
    }

    // 4. Construct Immutable Transaction Record
    const transaction: JournalTransaction = {
      id: `txn_${randomUUID()}`,
      timestamp: new Date(),
      description,
      postings,
      metadata,
    };

    // 5. Commit state changes atomically
    this.transactions.push(transaction);
    this.accountBalances = tentativeBalances;

    return transaction;
  }

  public getAccountBalance(accountId: string): Cents {
    const balance = this.accountBalances.get(accountId);
    if (balance === undefined) {
      throw new LedgerValidationError(`Account not found: ${accountId}`);
    }
    return balance;
  }
}

// ==========================================
// 4. USAGE DEMONSTRATION & PAYMENT PIPELINE
// ==========================================

// Initialize Ledger
const ledger = new CoreLedgerEngine();

// Setup Chart of Accounts
const cashClearing = ledger.createAccount('Stripe Clearing Account', AccountType.ASSET);
const customerWallet = ledger.createAccount('Customer Wallet - User_99', AccountType.LIABILITY);
const platformRevenue = ledger.createAccount('Platform Fee Revenue', AccountType.REVENUE);

// Simulate a $100.00 payment processing event with a $2.50 platform fee
const paymentAmount: Cents = 10000; // $100.00 in cents
const platformFee: Cents = 250;    // $2.50 in cents
const netCustomerCredit: Cents = paymentAmount - platformFee; // $97.50

try {
  const tx = ledger.commitTransaction(
    'Process Customer Deposit & Platform Fee',
    [
      // Total cash received enters our clearing account (Debit Asset)
      { accountId: cashClearing.id, direction: PostingDirection.DEBIT, amount: paymentAmount },
      
      // Customer wallet is credited with net amount (Credit Liability)
      { accountId: customerWallet.id, direction: PostingDirection.CREDIT, amount: netCustomerCredit },
      
      // Platform collects its processing fee (Credit Revenue)
      { accountId: platformRevenue.id, direction: PostingDirection.CREDIT, amount: platformFee },
    ],
    { gateway: 'stripe', chargeId: 'ch_3Mxyz123' }
  );

  console.log('Successfully committed transaction:', tx.id);
  console.log('Clearing Balance:', ledger.getAccountBalance(cashClearing.id));
  console.log('Customer Wallet Balance:', ledger.getAccountBalance(customerWallet.id));
  console.log('Revenue Balance:', ledger.getAccountBalance(platformRevenue.id));

} catch (error) {
  console.error('Transaction failed validation:', (error as Error).message);
}
