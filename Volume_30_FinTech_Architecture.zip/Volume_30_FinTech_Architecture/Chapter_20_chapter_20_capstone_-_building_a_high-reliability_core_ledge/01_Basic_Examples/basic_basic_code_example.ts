/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ledger-core.ts
 * @description A fully self-contained, high-reliability double-entry ledger entry pipeline
 * built in TypeScript, featuring precision math handling to prevent floating-point drift,
 * transactional atomicity guarantees, and idempotent event ingestion for a FinTech SaaS context.
 */

// ==========================================
// 1. TYPES, INTERFACES, AND DOMAIN MODELS
// ==========================================

/**
 * Represents the account classification type in a standard accounting equation.
 */
type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

/**
 * Represents a discrete account within the core ledger system.
 */
interface Account {
  id: string;
  name: string;
  type: AccountType;
  /** Stored as an integer representing the smallest currency unit (e.g., cents, satoshis) */
  balance: bigint;
  currency: string;
}

/**
 * Represents one side of a double-entry transaction (a single leg).
 */
interface JournalEntryLine {
  accountId: string;
  /** Positive integer representing the magnitude in minor units */
  amount: bigint;
  /** Direction of the monetary movement */
  direction: 'DEBIT' | 'CREDIT';
}

/**
 * Represents a balanced, immutable financial transaction container.
 */
interface Transaction {
  id: string;
  idempotencyKey: string;
  timestamp: number;
  description: string;
  lines: JournalEntryLine[];
}

/**
 * In-memory data store acting as our simulated transactional database engine.
 */
class LedgerDatabase {
  public accounts: Map<string, Account> = new Map();
  public transactions: Map<string, Transaction> = new Map();
  public idempotencyCache: Set<string> = new Set();

  /**
   * Resets or seeds the database state.
   */
  public reset(): void {
    this.accounts.clear();
    this.transactions.clear();
    this.idempotencyCache.clear();
  }
}

// ==========================================
// 2. CORE LEDGER ENGINE IMPLEMENTATION
// ==========================================

class CoreLedgerEngine {
  private db: LedgerDatabase;

  constructor(db: LedgerDatabase) {
    this.db = db;
  }

  /**
   * Creates a new financial account within the ledger.
   * 
   * @param id Unique identifier for the account (e.g., UUID v4).
   * @param name Human-readable account label.
   * @param type The accounting category type.
   * @param currency ISO-4217 currency code (e.g., 'USD').
   */
  public createAccount(id: string, name: string, type: AccountType, currency: string): Account {
    if (this.db.accounts.has(id)) {
      throw new Error(`Account violation: Account with ID ${id} already exists.`);
    }

    const account: Account = {
      id,
      name,
      type,
      balance: 0n, // Initialize with BigInt zero
      currency,
    };

    this.db.accounts.set(id, account);
    return account;
  }

  /**
   * Validates and posts an immutable, double-entry financial transaction.
   * Enforces strict accounting invariants: Sum of Debits MUST equal Sum of Credits.
   * 
   * @param transaction The unposted transaction candidate.
   * @returns boolean indicating success.
   */
  public postTransaction(transaction: Transaction): boolean {
    // 1. Idempotency Check: Prevent duplicate processing of network retries
    if (this.db.idempotencyCache.has(transaction.idempotencyKey)) {
      console.warn(`[Idempotency Warning] Transaction with key '${transaction.idempotencyKey}' already processed. Skipping.`);
      return true; // Return true as it was successfully processed previously
    }

    if (this.db.transactions.has(transaction.id)) {
      throw new Error(`Transaction violation: Transaction ID ${transaction.id} already exists.`);
    }

    // 2. Structural Validation: Must contain at least two entry lines
    if (!transaction.lines || transaction.lines.length < 2) {
      throw new Error(`Double-Entry Violation: Transaction must contain at least 2 entry lines.`);
    }

    let totalDebits = 0n;
    let totalCredits = 0n;

    // 3. Line-by-line verification and existence checks
    const affectedAccounts: Map<string, { account: Account; netDelta: bigint }> = new Map();

    for (const line of transaction.lines) {
      if (line.amount <= 0n) {
        throw new Error(`Precision Violation: Line amounts must be strictly positive integers. Found: ${line.amount}`);
      }

      const account = this.db.accounts.get(line.accountId);
      if (!account) {
        throw new Error(`Referential Integrity Error: Account ID ${line.accountId} does not exist.`);
      }

      // Aggregate global transaction balance verification
      if (line.direction === 'DEBIT') {
        totalDebits += line.amount;
      } else if (line.direction === 'CREDIT') {
        totalCredits += line.amount;
      } else {
        throw new Error(`Syntax Error: Invalid entry direction '${line.direction}'. Expected 'DEBIT' or 'CREDIT'.`);
      }

      // Calculate net change per account for atomic updating
      // Normal balance rules: Assets/Expenses increase with Debits. Liabilities/Equity/Revenue increase with Credits.
      let currentDelta = affectedAccounts.get(line.accountId)?.netDelta ?? 0n;
      
      const multiplier = (line.direction === 'DEBIT') ? 1n : -1n;
      // For Assets and Expenses, a debit increases the balance. For Liabilities, Equity, and Revenue, a credit increases it.
      const isNormalDebitType = account.type === 'ASSET' || account.type === 'EXPENSE';
      const directionalMultiplier = isNormalDebitType ? multiplier : -multiplier;

      currentDelta += (line.amount * directionalMultiplier);
      
      affectedAccounts.set(line.accountId, { account, netDelta: currentDelta });
    }

    // 4. Invariant Check: Debits MUST equal Credits precisely
    if (totalDebits !== totalCredits) {
      throw new Error(`Accounting Invariant Broken: Total Debits (${totalDebits}) do not match Total Credits (${totalCredits}).`);
    }

    // 5. Atomic Application: Update balances and persist transaction record
    for (const [accountId, data] of affectedAccounts.entries()) {
      const updatedBalance = data.account.balance + data.netDelta;
      
      // Safety check for asset accounts going negative (overdraft protection, if applicable)
      if (data.account.type === 'ASSET' && updatedBalance < 0n) {
        throw new Error(`Insufficient Funds: Account ${accountId} (${data.account.name}) would drop below zero balance (${updatedBalance}).`);
      }

      data.account.balance = updatedBalance;
      this.db.accounts.set(accountId, data.account);
    }

    // Mark idempotency key and store transaction
    this.db.idempotencyCache.add(transaction.idempotencyKey);
    this.db.transactions.set(transaction.id, transaction);

    return true;
  }
}

// ==========================================
// 3. EXECUTION DEMONSTRATION (SaaS Flow)
// ==========================================

// Initialize our mock database and ledger engine
const db = new LedgerDatabase();
const ledger = new CoreLedgerEngine(db);

// Seed Accounts for a mock SaaS payment processing pipeline
// Asset Account: Cash Clearing Account (e.g., Stripe/Bank holding account)
ledger.createAccount('acc_cash_01', 'Stripe Clearing Account', 'ASSET', 'USD');
// Revenue Account: Subscription Revenue
ledger.createAccount('acc_rev_01', 'SaaS Tier 1 Subscription Revenue', 'REVENUE', 'USD');

console.log('--- INITIAL STATE ---');
console.log(db.accounts.get('acc_cash_01'));
console.log(db.accounts.get('acc_rev_01'));

// Construct a balanced payment ingestion transaction ($49.99 represented in cents: 4999)
const txnIdempotencyKey = 'idemp_txn_9988776655';
const subscriptionPaymentTxn: Transaction = {
  id: 'txn_2023_10_001',
  idempotencyKey: txnIdempotencyKey,
  timestamp: Date.now(),
  description: 'Monthly SaaS subscription charge for user_xyz',
  lines: [
    {
      accountId: 'acc_cash_01',
      amount: 4999n,
      direction: 'DEBIT', // Increases our cash asset
    },
    {
      accountId: 'acc_rev_01',
      amount: 4999n,
      direction: 'CREDIT', // Increases our revenue account
    },
  ],
};

console.log('\n--- POSTING TRANSACTION ---');
try {
  ledger.postTransaction(subscriptionPaymentTxn);
  console.log('Transaction posted successfully.');
} catch (error: any) {
  console.error('Failed to post transaction:', error.message);
}

console.log('\n--- FINAL STATE ---');
console.log(db.accounts.get('acc_cash_01'));
console.log(db.accounts.get('acc_rev_01'));

console.log('\n--- TESTING IDEMPOTENCY RETRY ---');
// Simulating a network retry sending the exact same payload with the same idempotency key
try {
  ledger.postTransaction(subscriptionPaymentTxn);
  console.log('Retry processed gracefully without duplicating financial impact.');
} catch (error: any) {
  console.error('Retry failed:', error.message);
}

console.log('Final Cash Balance after retry:', db.accounts.get('acc_cash_01')?.balance);
