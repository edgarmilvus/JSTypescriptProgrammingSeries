/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pool, PoolClient } from 'pg';
import { createHash } from 'crypto';

/**
 * Configuration interface for the database connection pool.
 */
interface DatabaseConfig {
  connectionString: string;
}

/**
 * Payload required to ingest and process a payment transaction.
 */
interface PaymentPayload {
  tenantId: string;
  idempotencyKey: string;
  sourceAccountId: string;
  destinationAccountId: string;
  amountMinorUnits: bigint; // Stored as integer cents/satoshis to prevent float errors
  currency: string;
  metadata?: Record<string, unknown>;
}

/**
 * Result returned by the ledger transaction engine.
 */
interface TransactionResult {
  success: boolean;
  transactionId?: string;
  error?: string;
  code?: string;
}

/**
 * High-Reliability Core Ledger & Payment Gateway Engine.
 * Enforces double-entry bookkeeping invariants and absolute idempotency.
 */
export class PaymentLedgerEngine {
  private pool: Pool;

  constructor(config: DatabaseConfig) {
    this.pool = new Pool({ connectionString: config.connectionString });
  }

  /**
   * Generates a deterministic SHA-256 hash to act as an idempotency guard.
   */
  private generateIdempotencyHash(tenantId: string, key: string): string {
    return createHash('sha256')
      .update(`${tenantId}:${key}`)
      .digest('hex');
  }

  /**
   * Executes a payment inside an isolated, serializable PostgreSQL transaction.
   * Ensures atomicity: either both ledger legs post successfully, or the entire state rolls back.
   */
  public async processPayment(payload: PaymentPayload): Promise<TransactionResult> {
    const client: PoolClient = await this.pool.connect();
    const idempotencyHash = this.generateIdempotencyHash(payload.tenantId, payload.idempotencyKey);

    try {
      // 1. Begin strict transaction isolation
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE');

      // 2. Check for existing idempotency record to prevent duplicate processing
      const existingCheck = await client.query(
        `SELECT transaction_id, status FROM idempotency_keys WHERE tenant_id = $1 AND key_hash = $2 FOR UPDATE`,
        [payload.tenantId, idempotencyHash]
      );

      if (existingCheck.rows.length > 0) {
        const record = existingCheck.rows[0];
        await client.query('COMMIT');
        return {
          success: record.status === 'COMPLETED',
          transactionId: record.transaction_id,
          error: record.status === 'FAILED' ? 'Idempotent request previously failed.' : undefined,
          code: 'IDEMPOTENT_REPLAY'
        };
      }

      // 3. Insert pending idempotency lock
      await client.query(
        `INSERT INTO idempotency_keys (tenant_id, key_hash, status) VALUES ($1, $2, 'PENDING')`,
        [payload.tenantId, idempotencyHash]
      );

      // 4. Validate Account Status and Balances (Invariant Check)
      const sourceAccountCheck = await client.query(
        `SELECT id, currency, status, balance FROM accounts WHERE id = $1 AND tenant_id = $2 FOR UPDATE`,
        [payload.sourceAccountId, payload.tenantId]
      );

      if (sourceAccountCheck.rows.length === 0) {
        throw new Error(`Source account ${payload.sourceAccountId} not found.`);
      }

      const sourceAccount = sourceAccountCheck.rows[0];
      if (sourceAccount.currency !== payload.currency) {
        throw new Error(`Currency mismatch. Account uses ${sourceAccount.currency}, payment requested in ${payload.currency}.`);
      }

      // Check if source has sufficient funds (assuming balance is tracked via ledger sum or cached view)
      if (BigInt(sourceAccount.balance) < payload.amountMinorUnits) {
        throw new Error(`Insufficient funds in source account ${payload.sourceAccountId}.`);
      }

      // 5. Create the parent financial transaction record
      const txnInsert = await client.query(
        `INSERT INTO financial_transactions (tenant_id, currency, status) VALUES ($1, $2, 'POSTED') RETURNING id`,
        [payload.tenantId, payload.currency]
      );
      const transactionId = txnInsert.rows[0].id;

      // 6. Execute Double-Entry Postings (Debit Source, Credit Destination)
      // Leg 1: Credit the source account (Reducing liability/asset depending on type, e.g., outflow)
      await client.query(
        `INSERT INTO ledger_postings (transaction_id, account_id, direction, amount) VALUES ($1, $2, 'DEBIT', $3)`,
        [transactionId, payload.sourceAccountId, payload.amountMinorUnits.toString()]
      );

      // Leg 2: Credit the destination account (Inflow)
      await client.query(
        `INSERT INTO ledger_postings (transaction_id, account_id, direction, amount) VALUES ($1, $2, 'CREDIT', $3)`,
        [transactionId, payload.destinationAccountId, payload.amountMinorUnits.toString()]
      );

      // 7. Update materialized or cached account balances atomically
      await client.query(
        `UPDATE accounts SET balance = balance - $1 WHERE id = $2`,
        [payload.amountMinorUnits.toString(), payload.sourceAccountId]
      );

      await client.query(
        `UPDATE accounts SET balance = balance + $1 WHERE id = $2`,
        [payload.amountMinorUnits.toString(), payload.destinationAccountId]
      );

      // 8. Update idempotency record to COMPLETED with reference transaction ID
      await client.query(
        `UPDATE idempotency_keys SET status = 'COMPLETED', transaction_id = $1 WHERE tenant_id = $2 AND key_hash = $3`,
        [transactionId, payload.tenantId, idempotencyHash]
      );

      // 9. Commit the distributed ACID transaction block
      await client.query('COMMIT');

      return {
        success: true,
        transactionId,
        code: 'TRANSACTION_POSTED'
      };

    } catch (error: any) {
      // Rollback all changes upon encountering any violation or infrastructure exception
      await client.query('ROLLBACK');

      // Attempt to record failure state for idempotency key if transaction failed mid-way
      try {
        await this.pool.query(
          `UPDATE idempotency_keys SET status = 'FAILED' WHERE tenant_id = $1 AND key_hash = $2`,
          [payload.tenantId, idempotencyHash]
        );
      } catch (logErr) {
        console.error('Failed to update idempotency failure state:', logErr);
      }

      return {
        success: false,
        error: error.message || 'Unknown internal ledger processing error.',
        code: 'TRANSACTION_FAILED'
      };
    } finally {
      // Release the dedicated client back to the connection pool
      client.release();
    }
  }

  /**
   * Gracefully shuts down the connection pool.
   */
  public async close(): Promise<void> {
    await this.pool.end();
  }
}
