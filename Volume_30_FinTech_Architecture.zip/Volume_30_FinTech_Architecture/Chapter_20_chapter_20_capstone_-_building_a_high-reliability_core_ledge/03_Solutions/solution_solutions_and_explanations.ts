/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'BTC';

export interface IMoney {
  readonly amount: bigint; // Stored in minor units (e.g., cents, satoshis)
  readonly currency: CurrencyCode;
}

export type Direction = 'DEBIT' | 'CREDIT';

export interface ILedgerLine {
  readonly accountId: string;
  readonly money: IMoney;
  readonly direction: Direction;
}

export interface IJournalEntry {
  readonly transactionId: string;
  readonly timestamp: number;
  readonly metadata: Record<string, string>;
  readonly lines: readonly ILedgerLine[];
}

export class UnbalancedLedgerError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnbalancedLedgerError';
  }
}

export class CurrencyMismatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CurrencyMismatchError';
  }
}

export class MoneyOperations {
  static create(amount: number, currency: CurrencyCode, scaleFactor: number = 100): IMoney {
    return {
      amount: BigInt(Math.round(amount * scaleFactor)),
      currency,
    };
  }

  static add(a: IMoney, b: IMoney): IMoney {
    if (a.currency !== b.currency) {
      throw new CurrencyMismatchError(`Cannot add ${a.currency} and ${b.currency}`);
    }
    return { amount: a.amount + b.amount, currency: a.currency };
  }

  static subtract(a: IMoney, b: IMoney): IMoney {
    if (a.currency !== b.currency) {
      throw new CurrencyMismatchError(`Cannot subtract ${a.currency} and ${b.currency}`);
    }
    return { amount: a.amount - b.amount, currency: a.currency };
  }

  static isZero(money: IMoney): boolean {
    return money.amount === 0n;
  }
}

export function validateLedgerBalance(entry: IJournalEntry): boolean {
  const currencyTotals = new Map<CurrencyCode, bigint>();

  for (const line of entry.lines) {
    const { currency, amount } = line.money;
    const currentSum = currencyTotals.get(currency) || 0n;

    if (line.direction === 'DEBIT') {
      currencyTotals.set(currency, currentSum + amount);
    } else {
      currencyTotals.set(currency, currentSum - amount);
    }
  }

  for (const [currency, netBalance] of currencyTotals.entries()) {
    if (netBalance !== 0n) {
      throw new UnbalancedLedgerError(
        `Unbalanced ledger entry ${entry.transactionId} for currency ${currency}. Net imbalance: ${netBalance}`
      );
    }
  }

  return true;
}

export function postJournalEntry(
  entry: IJournalEntry,
  existingAccounts: Map<string, IMoney>
): void {
  validateLedgerBalance(entry);

  // Validate account existence and currency alignment
  for (const line of entry.lines) {
    const accountBalance = existingAccounts.get(line.accountId);
    if (!accountBalance) {
      throw new Error(`Account ID ${line.accountId} does not exist.`);
    }
    if (accountBalance.currency !== line.money.currency) {
      throw new CurrencyMismatchError(
        `Account ${line.accountId} currency (${accountBalance.currency}) does not match line item currency (${line.money.currency}).`
      );
    }
  }

  // Simulate updating account balances atomically
  for (const line of entry.lines) {
    const currentBalance = existingAccounts.get(line.accountId)!;
    const updatedAmount =
      line.direction === 'DEBIT'
        ? currentBalance.amount + line.money.amount
        : currentBalance.amount - line.money.amount;

    existingAccounts.set(line.accountId, {
      amount: updatedAmount,
      currency: currentBalance.currency,
    });
  }
}
