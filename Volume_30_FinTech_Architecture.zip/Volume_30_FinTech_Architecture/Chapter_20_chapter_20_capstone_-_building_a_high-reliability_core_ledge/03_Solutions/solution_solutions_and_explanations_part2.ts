/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { IMoney } from './exercise-1';

export interface IPaymentCommand {
  readonly idempotencyKey: string;
  readonly paymentId: string;
  readonly customerId: string;
  readonly amount: IMoney;
  readonly paymentMethodToken: string;
}

export type PaymentEvent =
  | { type: 'PAYMENT_INITIATED'; eventId: string; paymentId: string; timestamp: number; payload: IPaymentCommand }
  | { type: 'PAYMENT_AUTHORIZED'; eventId: string; paymentId: string; timestamp: number; authCode: string }
  | { type: 'PAYMENT_FAILED'; eventId: string; paymentId: string; timestamp: number; reason: string }
  | { type: 'PAYMENT_SETTLED'; eventId: string; paymentId: string; timestamp: number };

export type ExecutionState = 'PENDING' | 'COMPLETED' | 'FAILED';

export interface IIdempotencyRecord {
  readonly state: ExecutionState;
  readonly result?: IPaymentResult;
  readonly error?: string;
}

export interface IIdempotencyStore {
  get(key: string): Promise<IIdempotencyRecord | undefined>;
  setIfAbsent(key: string, record: IIdempotencyRecord): Promise<boolean>;
  update(key: string, record: IIdempotencyRecord): Promise<void>;
}

export interface IPaymentResult {
  readonly success: boolean;
  readonly paymentId: string;
  readonly status: string;
  readonly events: readonly PaymentEvent[];
}

export class ConcurrentExecutionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ConcurrentExecutionError';
  }
}

export class PaymentIngestionPipeline {
  constructor(
    private readonly idempotencyStore: IIdempotencyStore,
    private readonly eventStore: (event: PaymentEvent) => Promise<void>,
    private readonly gatewayClient: (command: IPaymentCommand) => Promise<{ authCode: string }>
  ) {}

  async processPayment(command: IPaymentCommand): Promise<IPaymentResult> {
    const existing = await this.idempotencyStore.get(command.idempotencyKey);

    if (existing) {
      if (existing.state === 'PENDING') {
        throw new ConcurrentExecutionError('Concurrent payment processing for this idempotency key is already in progress.');
      }
      if (existing.result) {
        return existing.result;
      }
    }

    const acquired = await this.idempotencyStore.setIfAbsent(command.idempotencyKey, {
      state: 'PENDING',
    });

    if (!acquired) {
      throw new ConcurrentExecutionError('Concurrent lock acquisition failed for idempotency key.');
    }

    const events: PaymentEvent[] = [];
    const timestamp = Date.now();

    const initiatedEvent: PaymentEvent = {
      type: 'PAYMENT_INITIATED',
      eventId: `evt_${Math.random()}`,
      paymentId: command.paymentId,
      timestamp,
      payload: command,
    };
    events.push(initiatedEvent);
    await this.eventStore(initiatedEvent);

    try {
      const gatewayResponse = await this.gatewayClient(command);
      
      const authorizedEvent: PaymentEvent = {
        type: 'PAYMENT_AUTHORIZED',
        eventId: `evt_${Math.random()}`,
        paymentId: command.paymentId,
        timestamp: Date.now(),
        authCode: gatewayResponse.authCode,
      };
      events.push(authorizedEvent);
      await this.eventStore(authorizedEvent);

      const result: IPaymentResult = {
        success: true,
        paymentId: command.paymentId,
        status: 'AUTHORIZED',
        events,
      };

      await this.idempotencyStore.update(command.idempotencyKey, {
        state: 'COMPLETED',
        result,
      });

      return result;
    } catch (error: any) {
      const failedEvent: PaymentEvent = {
        type: 'PAYMENT_FAILED',
        eventId: `evt_${Math.random()}`,
        paymentId: command.paymentId,
        timestamp: Date.now(),
        reason: error.message,
      };
      events.push(failedEvent);
      await this.eventStore(failedEvent);

      const result: IPaymentResult = {
        success: false,
        paymentId: command.paymentId,
        status: 'FAILED',
        events,
      };

      await this.idempotencyStore.update(command.idempotencyKey, {
        state: 'FAILED',
        result,
      });

      return result;
    }
  }
}
