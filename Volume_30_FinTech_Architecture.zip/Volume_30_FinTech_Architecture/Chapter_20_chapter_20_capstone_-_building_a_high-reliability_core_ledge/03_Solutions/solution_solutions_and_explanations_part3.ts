/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface ICircuitBreakerConfig {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenMaxRequests: number;
}

export enum CircuitState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN',
  HALF_OPEN = 'HALF_OPEN',
}

export interface IDeadLetterQueueMessage<T> {
  readonly id: string;
  readonly payload: T;
  readonly errorHistory: string[];
  readonly retryCount: number;
  readonly lastFailureTimestamp: number;
}

export class CircuitOpenError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CircuitOpenError';
  }
}

export class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private nextAttemptTimestamp = 0;

  constructor(private readonly config: ICircuitBreakerConfig) {}

  async execute<T>(action: () => Promise<T>): Promise<T> {
    const now = Date.now();

    if (this.state === CircuitState.OPEN) {
      if (now >= this.nextAttemptTimestamp) {
        this.state = CircuitState.HALF_OPEN;
        this.successCount = 0;
      } else {
        throw new CircuitOpenError('Circuit breaker is OPEN. Fast-failing request.');
      }
    }

    try {
      const result = await action();
      this.onSuccess();
      return result;
    } catch (error: any) {
      this.onFailure(error);
      throw error;
    }
  }

  private onSuccess(): void {
    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.config.halfOpenMaxRequests) {
        this.state = CircuitState.CLOSED;
        this.failureCount = 0;
      }
    } else if (this.state === CircuitState.CLOSED) {
      this.failureCount = 0;
    }
  }

  private onFailure(error: Error): void {
    this.failureCount++;
    if (this.state === CircuitState.HALF_OPEN || this.failureCount >= this.config.failureThreshold) {
      this.state = CircuitState.OPEN;
      this.nextAttemptTimestamp = Date.now() + this.config.resetTimeoutMs;
    }
  }

  getState(): CircuitState {
    return this.state;
  }
}

export function handleJobFailure<T>(
  message: IDeadLetterQueueMessage<T>,
  error: Error,
  maxRetries: number,
  deadLetterStore: (msg: IDeadLetterQueueMessage<T>) => void,
  retryQueue: (msg: IDeadLetterQueueMessage<T>, delayMs: number) => void
): void {
  const updatedRetryCount = message.retryCount + 1;
  const updatedHistory = [...message.errorHistory, error.message];

  const failedMessage: IDeadLetterQueueMessage<T> = {
    ...message,
    retryCount: updatedRetryCount,
    errorHistory: updatedHistory,
    lastFailureTimestamp: Date.now(),
  };

  if (updatedRetryCount > maxRetries) {
    deadLetterStore(failedMessage);
  } else {
    const exponentialDelay = Math.pow(2, updatedRetryCount) * 1000;
    retryQueue(failedMessage, exponentialDelay);
  }
}
