/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { IJournalEntry, ILedgerLine } from './exercise-1';

export interface ILedgerInspectorProps {
  readonly entries: readonly IJournalEntry[];
  readonly isConnected: boolean;
}

export const LedgerTransactionInspector: React.FC<ILedgerInspectorProps> = ({ entries, isConnected }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'BALANCED' | 'UNBALANCED'>('ALL');
  const [selectedTransactionId, setSelectedTransactionId] = useState<string | null>(null);

  const filteredEntries = useMemo(() => {
    return entries.filter((entry) => {
      const matchesSearch =
        entry.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.lines.some((line) => line.accountId.toLowerCase().includes(searchTerm.toLowerCase()));

      // Simplified balance check simulation for filtering
      const isBalanced = entry.lines.reduce((acc, l) => acc + (l.direction === 'DEBIT' ? l.money.amount : -l.money.amount), 0n) === 0n;

      if (statusFilter === 'BALANCED' && !isBalanced) return false;
      if (statusFilter === 'UNBALANCED' && isBalanced) return false;

      return matchesSearch;
    });
  }, [entries, searchTerm, statusFilter]);

  const selectedEntry = useMemo(() => {
    return entries.find((e) => e.transactionId === selectedTransactionId);
  }, [entries, selectedTransactionId]);

  return (
    <div className="p-6 bg-slate-900 text-slate-100 min-h-screen font-sans">
      <header className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">Core Ledger Transaction Inspector</h1>
        <div className="flex items-center space-x-2">
          <span className={`h-3 w-3 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
          <span className="text-sm text-slate-400">{isConnected ? 'Live Stream Active' : 'Disconnected'}</span>
        </div>
      </header>

      <div className="flex gap-4 mb-6">
        <input
          type="text"
          placeholder="Search by Transaction ID or Account ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 flex-1"
        />
        <select
          value={statusFilter}
          onChange={(e: any) => setStatusFilter(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-sm focus:outline-none focus:border-indigo-500"
        >
          <option value="ALL">All Statuses</option>
          <option value="BALANCED">Balanced Only</option>
          <option value="UNBALANCED">Unbalanced (Alerts)</option>
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-lg overflow-hidden shadow-lg">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-700/50 text-xs uppercase tracking-wider text-slate-400 border-b border-slate-700">
                <th className="p-3">Transaction ID</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Lines</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700 text-sm">
              {filteredEntries.map((entry) => {
                const isBalanced = entry.lines.reduce((acc, l) => acc + (l.direction === 'DEBIT' ? l.money.amount : -l.money.amount), 0n) === 0n;
                return (
                  <tr
                    key={entry.transactionId}
                    onClick={() => setSelectedTransactionId(entry.transactionId)}
                    className="hover:bg-slate-700/40 cursor-pointer transition-colors"
                  >
                    <td className="p-3 font-mono text-indigo-400">{entry.transactionId}</td>
                    <td className="p-3 text-slate-400">{new Date(entry.timestamp).toISOString()}</td>
                    <td className="p-3">{entry.lines.length} lines</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${
                          isBalanced ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400 animate-bounce'
                        }`}
                      >
                        {isBalanced ? 'BALANCED' : 'UNBALANCED'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 shadow-lg">
          <h2 className="text-lg font-semibold mb-4 border-b border-slate-700 pb-2">Double-Entry Breakdown</h2>
          {selectedEntry ? (
            <div>
              <p className="text-xs text-slate-400 mb-2 font-mono">ID: {selectedEntry.transactionId}</p>
              <div className="space-y-3 mt-4">
                {selectedEntry.lines.map((line, idx) => (
                  <div key={idx} className="flex justify-between items-center p-2 bg-slate-900 rounded border border-slate-700/50 text-xs">
                    <div>
                      <span className="font-mono text-slate-300 block">{line.accountId}</span>
                      <span className={`font-bold ${line.direction === 'DEBIT' ? 'text-blue-400' : 'text-amber-400'}`}>{line.direction}</span>
                    </div>
                    <span className="font-mono font-semibold">
                      {Number(line.money.amount) / 100} {line.money.currency}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-slate-500 italic">Select a transaction to inspect double-entry breakdown lines.</p>
          )}
        </div>
      </div>
    </div>
  );
};
