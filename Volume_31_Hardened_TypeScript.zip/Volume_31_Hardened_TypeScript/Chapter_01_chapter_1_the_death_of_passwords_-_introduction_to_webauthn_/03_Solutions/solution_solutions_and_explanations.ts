/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Interface representing the structure expected by the client to create credentials.
 * Matches standard PublicKeyCredentialCreationOptions requirements.
 */
export interface PublicKeyCredentialCreationOptionsJSON {
  challenge: string;
  rp: {
    name: string;
    id?: string;
  };
  user: {
    id: string;
    name: string;
    displayName: string;
  };
  pubKeyCredParams: Array<{
    type: 'public-key';
    alg: number;
  }>;
  timeout?: number;
  attestation?: 'none' | 'indirect' | 'direct' | 'enterprise';
}

/**
 * Generates registration options containing a cryptographically secure 32-byte challenge.
 */
export function generateRegistrationOptions(
  user: { id: string; name: string; displayName: string },
  rpName: string,
  rpId?: string
): PublicKeyCredentialCreationOptionsJSON {
  // 1. Generate a cryptographically strong 32-byte challenge using the Web Crypto API
  const challengeBuffer = new Uint8Array(32);
  crypto.getRandomValues(challengeBuffer);

  // Convert the binary buffer to a base64url string for transmission over JSON HTTP payloads.
  // Note: On the client side, this base64url string must be decoded back into an ArrayBuffer
  // before being passed into navigator.credentials.create().
  const challengeBase64Url = btoa(String.fromCharCode(...challengeBuffer))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  return {
    challenge: challengeBase64Url,
    rp: {
      name: rpName,
      ...(rpId && { id: rpId }),
    },
    user: {
      id: user.id,
      name: user.name,
      displayName: user.displayName,
    },
    pubKeyCredParams: [
      { type: 'public-key', alg: -7 },   // ES256 (ECDSA w/ SHA-256)
      { type: 'public-key', alg: -257 }, // RS256 (RSASSA-PKCS1-v1_5 w/ SHA-256)
    ],
    timeout: 60000,
    attestation: 'none',
  };
}

/**
 * Type guard utility to safely validate an unknown client response payload.
 * Ensures the incoming object conforms to the structural shape of a PublicKeyCredential.
 */
export function isRegistrationResponse(credential: unknown): credential is PublicKeyCredential {
  if (!credential || typeof credential !== 'object') {
    return false;
  }

  const cred = credential as Record<string, unknown>;

  return (
    typeof cred.id === 'string' &&
    cred.rawId instanceof ArrayBuffer &&
    cred.response !== null &&
    typeof cred.response === 'object' &&
    'attestationObject' in cred.response &&
    'clientDataJSON' in cred.response &&
    (cred.response as Record<string, unknown>).attestationObject instanceof ArrayBuffer &&
    (cred.response as Record<string, unknown>).clientDataJSON instanceof ArrayBuffer
  );
}
