/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface ClientRegistrationResponse {
  id: string;
  rawId: string;
  response: {
    attestationObject: string;
    clientDataJSON: string;
  };
  type: string;
}

export class WebAuthnClient {
  /**
   * Helper to convert base64url encoded strings to ArrayBuffer.
   */
  private static base64UrlToArrayBuffer(base64url: string): ArrayBuffer {
    const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
    const padLength = (4 - (base64.length % 4)) % 4;
    const padded = base64.padEnd(base64.length + padLength, '=');
    const binaryString = atob(padded);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  /**
   * Helper to convert ArrayBuffers or ArrayBufferViews to base64url strings.
   */
  private static arrayBufferToBase64Url(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }

  /**
   * Executes the client-side WebAuthn registration ceremony.
   */
  public async register(
    optionsJSON: any
  ): Promise<ClientRegistrationResponse> {
    try {
      // 1. Prepare options by decoding base64url fields into ArrayBuffers required by the WebAuthn API
      const decodedOptions: PublicKeyCredentialCreationOptions = {
        ...optionsJSON,
        challenge: WebAuthnClient.base64UrlToArrayBuffer(optionsJSON.challenge),
        user: {
          ...optionsJSON.user,
          id: WebAuthnClient.base64UrlToArrayBuffer(optionsJSON.user.id),
        },
        // If excluded credentials exist, decode their IDs as well
        excludeCredentials: optionsJSON.excludeCredentials?.map((cred: any) => ({
          ...cred,
          id: WebAuthnClient.base64UrlToArrayBuffer(cred.id),
        })),
      };

      // 2. Invoke the platform or roaming hardware authenticator via navigator.credentials.create()
      const credential = (await navigator.credentials.create({
        publicKey: decodedOptions,
      })) as PublicKeyCredential;

      if (!credential) {
        throw new Error('Credential creation returned null or undefined.');
      }

      const response = credential.response as AuthenticatorAttestationResponse;

      // 3. Serialize binary buffers back into base64url strings for JSON payload transmission
      return {
        id: credential.id,
        rawId: WebAuthnClient.arrayBufferToBase64Url(credential.rawId),
        type: credential.type,
        response: {
          attestationObject: WebAuthnClient.arrayBufferToBase64Url(response.attestationObject),
          clientDataJSON: WebAuthnClient.arrayBufferToBase64Url(response.clientDataJSON),
        },
      };
    } catch (error: unknown) {
      // 4. Handle errors gracefully, identifying specific browser WebAuthn exceptions
      if (error instanceof DOMException) {
        switch (error.name) {
          case 'NotAllowedError':
            throw new Error('The registration was aborted or timed out by the user.');
          case 'InvalidStateError':
            throw new Error('This authenticator is already registered with the user account.');
          case 'NotSupportedError':
            throw new Error('The requested cryptographic parameters or authenticator type are not supported.');
          case 'SecurityError':
            throw new Error('A security context violation occurred (ensure your site runs over HTTPS or localhost).');
          default:
            throw new Error(`WebAuthn registration failed: ${error.message}`);
        }
      }
      throw error;
    }
  }
}
