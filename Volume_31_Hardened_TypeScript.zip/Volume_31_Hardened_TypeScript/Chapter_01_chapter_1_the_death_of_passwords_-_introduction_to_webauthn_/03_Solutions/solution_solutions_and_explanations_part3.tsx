/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback } from 'react';

interface PasskeyAuthButtonProps {
  username: string;
  onSuccess: (credential: unknown) => void;
  onError: (error: Error) => void;
  className?: string;
}

export const PasskeyAuthButton: React.FC<PasskeyAuthButtonProps> = ({
  username,
  onSuccess,
  onError,
  className = '',
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');

  const handlePasskeyAuth = useCallback(async () => {
    setIsLoading(true);
    setStatusMessage('Fetching authentication options...');

    try {
      // 1. Fetch authentication challenge options from the server backend
      const response = await fetch('/api/auth/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch authentication challenge from server.');
      }

      const optionsJSON = await response.json();

      setStatusMessage('Waiting for authenticator... Touch your security key or use biometrics.');

      // 2. Decode base64url fields to ArrayBuffer for navigator.credentials.get()
      const decodeBase64Url = (base64url: string): ArrayBuffer => {
        const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
        const padLength = (4 - (base64.length % 4)) % 4;
        const padded = base64.padEnd(base64.length + padLength, '=');
        const binary = atob(padded);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        return bytes.buffer;
      };

      const publicKeyOptions: PublicKeyCredentialRequestOptions = {
        ...optionsJSON,
        challenge: decodeBase64Url(optionsJSON.challenge),
        allowCredentials: optionsJSON.allowCredentials?.map((cred: any) => ({
          ...cred,
          id: decodeBase64Url(cred.id),
        })),
      };

      // 3. Trigger WebAuthn assertion retrieval
      const assertion = await navigator.credentials.get({
        publicKey: publicKeyOptions,
      });

      setStatusMessage('Authentication successful!');
      onSuccess(assertion);
    } catch (err: unknown) {
      const error = err instanceof Error ? err.message : 'An unknown error occurred during authentication.';
      setStatusMessage(`Error: ${error}`);
      onError(err instanceof Error ? err : new Error(error));
    } finally {
      setIsLoading(false);
    }
  }, [username, onSuccess, onError]);

  return (
    <div className="passkey-auth-container">
      <button
        type="button"
        onClick={handlePasskeyAuth}
        disabled={isLoading}
        className={`passkey-btn ${className}`}
        aria-busy={isLoading}
      >
        <span className="icon" aria-hidden="true">🔑</span>
        <span>{isLoading ? 'Verifying...' : 'Sign in with Passkey'}</span>
      </button>

      {/* Screen reader accessible status updates */}
      <div className="sr-only" aria-live="polite" role="status">
        {statusMessage}
      </div>
    </div>
  );
};
