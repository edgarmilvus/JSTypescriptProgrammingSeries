/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface ClientAssertionPayload {
  id: string;
  rawId: string;
  response: {
    authenticatorData: string;
    clientDataJSON: string;
    signature: string;
    userHandle?: string;
  };
}

export interface VerificationResult {
  verified: boolean;
  newCounter: number;
}

export async function verifyAuthenticationAssertion(
  assertion: ClientAssertionPayload,
  expectedChallenge: string,
  expectedOrigin: string,
  storedPublicKey: JsonWebKey,
  storedCounter: number
): Promise<VerificationResult> {
  const { authenticatorData, clientDataJSON, signature } = assertion.response;

  // Helpers for buffer conversions
  const base64UrlToUint8Array = (base64url: string): Uint8Array => {
    const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
    const padLength = (4 - (base64.length % 4)) % 4;
    const padded = base64.padEnd(base64.length + padLength, '=');
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  };

  const clientDataBytes = base64UrlToUint8Array(clientDataJSON);
  const authDataBytes = base64UrlToUint8Array(authenticatorData);
  const signatureBytes = base64UrlToUint8Array(signature);

  // 1. Decode and parse clientDataJSON
  const clientDataString = new TextDecoder().decode(clientDataBytes);
  const clientData = JSON.parse(clientDataString);

  if (clientData.type !== 'web-authn.get') {
    throw new Error(`Invalid client data type: expected "web-authn.get", got "${clientData.type}"`);
  }

  if (clientData.challenge !== expectedChallenge) {
    throw new Error('Challenge mismatch: Potential replay attack detected.');
  }

  if (clientData.origin !== expectedOrigin) {
    throw new Error(`Origin mismatch: expected "${expectedOrigin}", got "${clientData.origin}"`);
  }

  // 2. Parse authData binary structure (37 bytes minimum)
  // - RP ID Hash: 32 bytes
  // - Flags: 1 byte
  // - Signature Counter (signCount): 4 bytes big-endian
  if (authDataBytes.length < 37) {
    throw new Error('Authenticator data buffer is too short.');
  }

  const flags = authDataBytes[32];
  const userPresentBit = (flags & 0x01) !== 0;

  if (!userPresentBit) {
    throw new Error('User Present (UP) flag is not set; authentication rejected.');
  }

  // Extract 4-byte signature counter (big-endian uint32)
  const dataView = new DataView(authDataBytes.buffer, authDataBytes.byteOffset, authDataBytes.byteLength);
  const signCount = dataView.getUint32(33, false); // false = big-endian

  // 3. Counter Validation (Clone Detection)
  // If the counter is 0 on both sides, some authenticators do not support counters.
  // Otherwise, new signCount must be strictly greater than storedCounter.
  if (signCount > 0 && storedCounter > 0 && signCount <= storedCounter) {
    throw new Error(
      `SECURITY ALERT: Authenticator clone detected! Signature counter value (${signCount}) ` +
      `is less than or equal to the stored counter (${storedCounter}).`
    );
  }

  // 4. Cryptographic Signature Verification
  // Signature is computed over: authData || sha256(clientDataJSON)
  const clientDataHash = await crypto.subtle.digest('SHA-256', clientDataBytes);
  
  const signedData = new Uint8Array(authDataBytes.byteLength + clientDataHash.byteLength);
  signedData.set(authDataBytes, 0);
  signedData.set(new Uint8Array(clientDataHash), authDataBytes.byteLength);

  // Import the stored public key
  const cryptoKey = await crypto.subtle.importKey(
    'jwk',
    storedPublicKey,
    { name: 'ECDSA', namedCurve: 'P-256' }, // Adjust curve algorithm based on your stored key properties
    false,
    ['verify']
  );

  // Verify signature using Web Crypto API
  const isValidSignature = await crypto.subtle.verify(
    { name: 'ECDSA', hash: { name: 'SHA-256' } },
    cryptoKey,
    signatureBytes,
    signedData
  );

  if (!isValidSignature) {
    throw new Error('Cryptographic signature verification failed.');
  }

  return {
    verified: true,
    newCounter: signCount,
  };
}
