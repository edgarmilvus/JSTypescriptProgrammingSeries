/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

import { z } from 'zod';
import * as crypto from 'crypto';

// ============================================================================
// 1. ZOD SCHEMAS & TYPE INFERENCE (Runtime Validation + Compile-Time Safety)
// ============================================================================

/**
 * Schema for initiating passkey registration.
 */
export const RegisterInitRequestSchema = z.object({
  username: z.string().email({ message: "A valid email address is required for registration." }),
  displayName: z.string().min(2, { message: "Display name must be at least 2 characters long." }),
});

export type RegisterInitRequest = z.infer<typeof RegisterInitRequestSchema>;

/**
 * Schema for verifying a passkey registration response from the client.
 */
export const RegisterVerifyRequestSchema = z.object({
  id: z.string().min(1, { message: "Credential ID is required." }),
  rawId: z.string().min(1, { message: "Raw ID is required." }),
  response: z.object({
    clientDataJSON: z.string().min(1, { message: "clientDataJSON is required." }),
    attestationObject: z.string().min(1, { message: "attestationObject is required." }),
    transports: z.array(z.string()).optional(),
  }),
  type: z.literal("public-key"),
});

export type RegisterVerifyRequest = z.infer<typeof RegisterVerifyRequestSchema>;

/**
 * Schema for initiating passkey authentication (login).
 */
export const LoginInitRequestSchema = z.object({
  username: z.string().email({ message: "A valid email address is required for authentication." }),
});

export type LoginInitRequest = z.infer<typeof LoginInitRequestSchema>;

/**
 * Schema for verifying a passkey authentication assertion response.
 */
export const LoginVerifyRequestSchema = z.object({
  id: z.string().min(1, { message: "Credential ID is required." }),
  rawId: z.string().min(1, { message: "Raw ID is required." }),
  response: z.object({
    clientDataJSON: z.string().min(1, { message: "clientDataJSON is required." }),
    authenticatorData: z.string().min(1, { message: "authenticatorData is required." }),
    signature: z.string().min(1, { message: "signature is required." }),
    userHandle: z.string().nullable().optional(),
  }),
  type: z.literal("public-key"),
});

export type LoginVerifyRequest = z.infer<typeof LoginVerifyRequestSchema>;

// ============================================================================
// 2. GRAPH STATE MANAGEMENT INTERFACES
// ============================================================================

export type WorkflowStep = 
  | 'IDLE'
  | 'CHALLENGE_ISSUED'
  | 'AWAITING_ASSERTION'
  | 'VERIFYING'
  | 'AUTHENTICATED'
  | 'FAILED';

export interface PasskeyWorkflowState {
  userId: string;
  username: string;
  challenge: string;
  origin: string;
  step: WorkflowStep;
  createdAt: number;
  attempts: number;
}

// ============================================================================
// 3. TYPE GUARDS & TYPE NARROWING UTILITIES
// ============================================================================

/**
 * Interface representing decoded Authenticator Data flags.
 */
interface AuthenticatorFlags {
  userPresent: boolean;
  userVerified: boolean;
  backupEligible: boolean;
  backupState: boolean;
  hasAttestedData: boolean;
  hasExtensionData: boolean;
}

/**
 * Type Guard to check if a parsed object is a valid AuthenticatorFlags structure.
 * This performs runtime validation to enable TypeScript type narrowing.
 */
function isAuthenticatorFlags(obj: unknown): obj is AuthenticatorFlags {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'userPresent' in obj &&
    typeof (obj as AuthenticatorFlags).userPresent === 'boolean' &&
    'userVerified' in obj &&
    typeof (obj as AuthenticatorFlags).userVerified === 'boolean'
  );
}

/**
 * Parses raw authenticator data bytes and extracts flag states with type safety.
 */
export function parseAuthenticatorFlags(authDataBuffer: Buffer): AuthenticatorFlags {
  // Flags are located at byte 32 of the authenticatorData structure
  if (authDataBuffer.length < 37) {
    throw new Error("Invalid authenticatorData length: buffer is too short.");
  }
  
  const flagsByte = authDataBuffer[32];
  
  const flags: AuthenticatorFlags = {
    userPresent: (flagsByte & 0x01) !== 0,
    userVerified: (flagsByte & 0x04) !== 0,
    backupEligible: (flagsByte & 0x08) !== 0,
    backupState: (flagsByte & 0x10) !== 0,
    hasAttestedData: (flagsByte & 0x40) !== 0,
    hasExtensionData: (flagsByte & 0x80) !== 0,
  };

  if (!isAuthenticatorFlags(flags)) {
    throw new Error("Failed type guard validation for authenticator flags.");
  }

  return flags;
}

// ============================================================================
// 4. CORE PASSKEY SERVICE IMPLEMENTATION
// ============================================================================

export class PasskeyService {
  private static readonly RP_ID = "auth.enterprise.internal";
  private static readonly EXPECTED_ORIGIN = "https://auth.enterprise.internal";
  
  // In-memory state store simulating a distributed Graph State or Redis cache
  private static workflowStore = new Map<string, PasskeyWorkflowState>();

  /**
   * Generates a cryptographically secure random challenge (nonce).
   */
  public static generateChallenge(): string {
    return crypto.randomBytes(32).toString('base64url');
  }

  /**
   * Initializes a registration workflow, creating and returning graph state.
   */
  public static initializeRegistration(input: RegisterInitRequest): {
    state: PasskeyWorkflowState;
    options: Record<string, unknown>;
  } {
    const validatedInput = RegisterInitRequestSchema.parse(input);
    const challenge = this.generateChallenge();
    const userId = crypto.randomBytes(16).toString('hex');

    const state: PasskeyWorkflowState = {
      userId,
      username: validatedInput.username,
      challenge,
      origin: this.EXPECTED_ORIGIN,
      step: 'CHALLENGE_ISSUED',
      createdAt: Date.now(),
      attempts: 0,
    };

    this.workflowStore.set(userId, state);

    // Construct PublicKeyCredentialCreationOptions conforming to WebAuthn spec
    const options = {
      rp: {
        name: "Enterprise Zero-Trust Identity Provider",
        id: this.RP_ID,
      },
      user: {
        id: Buffer.from(userId).toString('base64url'),
        name: validatedInput.username,
        displayName: validatedInput.displayName,
      },
      challenge,
      pubKeyCredParams: [
        { alg: -7, type: "public-key" },  // ES256
        { alg: -257, type: "public-key" }, // RS256
      ],
      timeout: 60000,
      attestation: "direct",
      authenticatorSelection: {
        authenticatorAttachment: "platform",
        userVerification: "required",
        residentKey: "preferred",
      },
    };

    return { state, options };
  }

  /**
   * Verifies a registration response payload received from the client.
   */
  public static verifyRegistration(userId: string, rawPayload: unknown): boolean {
    // 1. Runtime validation using Zod
    const payload = RegisterVerifyRequestSchema.parse(rawPayload);

    // 2. Retrieve graph state
    const state = this.workflowStore.get(userId);
    if (!state) {
      throw new Error("No active workflow state found for the given user ID.");
    }

    if (state.step !== 'CHALLENGE_ISSUED') {
      throw new Error(`Invalid workflow step transition: expected 'CHALLENGE_ISSUED', found '${state.step}'.`);
    }

    // Update state to verifying
    state.step = 'VERIFYING';
    state.attempts += 1;

    // 3. Parse clientDataJSON to verify origin and challenge
    const clientDataJSONStr = Buffer.from(payload.response.clientDataJSON, 'base64url').toString('utf8');
    const clientData = JSON.parse(clientDataJSONStr);

    if (clientData.type !== "webauthn.create") {
      throw new Error("Invalid client data type for registration.");
    }

    if (clientData.origin !== state.origin) {
      throw new Error(`Origin mismatch: expected '${state.origin}', received '${clientData.origin}'.`);
    }

    if (clientData.challenge !== state.challenge) {
      throw new Error("Challenge mismatch: potential replay attack or session hijacking detected.");
    }

    // 4. Transition state to authenticated upon successful cryptographic checks
    state.step = 'AUTHENTICATED';
    this.workflowStore.set(userId, state);

    // In a production environment, you would decode the attestationObject,
    // extract the COSE public key, and persist it to your database here.
    return true;
  }

  /**
   * Initializes an authentication (login) workflow.
   */
  public static initializeAuthentication(input: LoginInitRequest): {
    state: PasskeyWorkflowState;
    options: Record<string, unknown>;
  } {
    const validatedInput = LoginInitRequestSchema.parse(input);
    const challenge = this.generateChallenge();
    const workflowId = crypto.randomBytes(16).toString('hex');

    const state: PasskeyWorkflowState = {
      userId: workflowId,
      username: validatedInput.username,
      challenge,
      origin: this.EXPECTED_ORIGIN,
      step: 'CHALLENGE_ISSUED',
      createdAt: Date.now(),
      attempts: 0,
    };

    this.workflowStore.set(workflowId, state);

    const options = {
      challenge,
      timeout: 60000,
      rpId: this.RP_ID,
      userVerification: "required",
    };

    return { state, options };
  }

  /**
   * Verifies an authentication assertion response received from the client.
   */
  public static verifyAuthentication(workflowId: string, rawPayload: unknown): boolean {
    // 1. Runtime validation using Zod
    const payload = LoginVerifyRequestSchema.parse(rawPayload);

    // 2. Retrieve graph state
    const state = this.workflowStore.get(workflowId);
    if (!state) {
      throw new Error("Authentication session expired or invalid workflow ID.");
    }

    state.step = 'VERIFYING';

    // 3. Parse clientDataJSON
    const clientDataJSONStr = Buffer.from(payload.response.clientDataJSON, 'base64url').toString('utf8');
    const clientData = JSON.parse(clientDataJSONStr);

    if (clientData.type !== "webauthn.get") {
      throw new Error("Invalid client data type for authentication.");
    }

    if (clientData.origin !== state.origin) {
      throw new Error("Origin verification failed during authentication.");
    }

    if (clientData.challenge !== state.challenge) {
      throw new Error("Challenge verification failed during authentication.");
    }

    // 4. Parse and type-narrow authenticator data flags
    const authDataBuffer = Buffer.from(payload.response.authenticatorData, 'base64url');
    const flags = parseAuthenticatorFlags(authDataBuffer);

    if (!flags.userPresent) {
      throw new Error("User Presence (UP) flag was not asserted by the authenticator.");
    }

    if (!flags.userVerified) {
      throw new Error("User Verification (UV) flag was not asserted by the authenticator.");
    }

    // 5. Finalize state
    state.step = 'AUTHENTICATED';
    this.workflowStore.delete(workflowId); // Invalidate challenge (nonce consumption)

    return true;
  }
}
