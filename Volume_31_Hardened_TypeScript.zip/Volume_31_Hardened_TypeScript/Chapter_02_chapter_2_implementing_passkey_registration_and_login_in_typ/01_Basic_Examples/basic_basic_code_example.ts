/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import express, { Request, Response } from 'express';
import { z } from 'zod';

// Initialize the Express application server for our SaaS backend
const app = express();

// Middleware to parse incoming JSON request bodies securely
app.use(express.json());

/**
 * @fileoverview SaaS Passkey Registration Handler
 * @description Demonstrates interface definition, generic usage, and runtime 
 * validation for WebAuthn passkey registration payloads.
 */

// ==========================================
// 1. INTERFACE DEFINITIONS & TYPES
// ==========================================

/**
 * Represents the expected structural contract of a WebAuthn registration 
 * payload sent from the frontend client authenticator.
 */
interface PasskeyRegistrationPayload {
    userId: string;
    username: string;
    attestationObject: string;
    clientDataJSON: string;
}

/**
 * Generic response interface for standardizing API responses across 
 * our SaaS backend services.
 * 
 * @template T - The type of the data payload returned to the client.
 */
interface ApiResponse<T> {
    success: boolean;
    message: string;
    data: T | null;
}

// ==========================================
// 2. RUNTIME VALIDATION SCHEMA (ZOD)
// ==========================================

/**
 * Zod schema to validate untrusted incoming HTTP request bodies at runtime.
 * This guarantees that even if TypeScript's compile-time checks are bypassed,
 * malformed payloads will be caught immediately before database persistence.
 */
const PasskeyRegistrationSchema = z.object({
    userId: z.string().uuid({ message: "Invalid user ID format; expected UUID." }),
    username: z.string().email({ message: "Invalid username format; expected email." }),
    attestationObject: z.string().min(1, { message: "Attestation object cannot be empty." }),
    clientDataJSON: z.string().min(1, { message: "Client data JSON cannot be empty." }),
});

// ==========================================
// 3. REUSABLE UTILITY FUNCTION (GENERICS)
// ==========================================

/**
 * A generic helper function to format uniform API responses.
 * 
 * @template T - The data type encapsulated within the API response.
 * @param {boolean} success - Operation status flag.
 * @param {string} message - Human-readable status description.
 * @param {T | null} data - The payload data or null on failure.
 * @returns {ApiResponse<T>} The strictly typed response object.
 */
function createResponse<T>(success: boolean, message: string, data: T | null): ApiResponse<T> {
    return {
        success,
        message,
        data,
    };
}

// ==========================================
// 4. API ROUTE HANDLER
// ==========================================

/**
 * Express route handler for registering a new passkey credential.
 * Enforces runtime validation using Zod and maps types directly to our TypeScript interfaces.
 */
app.post('/api/auth/passkey/register', async (req: Request, res: Response) => {
    try {
        // Step A: Perform runtime validation on the incoming request body
        const validationResult = PasskeyRegistrationSchema.safeParse(req.body);

        if (!validationResult.success) {
            // Extract formatting errors for detailed client feedback
            const errorDetails = validationResult.error.errors.map(err => err.message);
            
            const errorResponse = createResponse<null>(
                false, 
                "Validation failed for passkey registration payload.", 
                { errors: errorDetails } as unknown as null
            );
            
            return res.status(400).json(errorResponse);
        }

        // Step B: Access validated and safely typed data
        const validPayload: PasskeyRegistrationPayload = validationResult.data;

        // --- MOCK DATABASE PERSISTENCE LAYER ---
        // In a production SaaS environment, you would verify the cryptographic
        // signature of the attestationObject and save the credential public key
        // to your primary database (e.g., PostgreSQL via Prisma or Drizzle).
        console.log(`[Database] Persisting passkey for user: ${validPayload.username}`);

        // Step C: Construct successful response using our generic utility
        const successResponse = createResponse<{ registeredAt: string }>(
            true,
            "Passkey successfully registered and verified.",
            { registeredAt: new Date().toISOString() }
        );

        return res.status(201).json(successResponse);

    } catch (error: unknown) {
        // Fallback error catcher for unexpected runtime anomalies
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
        
        const internalErrorResponse = createResponse<null>(
            false, 
            `Internal server error during registration: ${errorMessage}`, 
            null
        );
        
        return res.status(500).json(internalErrorResponse);
    }
});

// Start the server on port 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`[SaaS Server] Passkey authentication service running on port ${PORT}`);
});
