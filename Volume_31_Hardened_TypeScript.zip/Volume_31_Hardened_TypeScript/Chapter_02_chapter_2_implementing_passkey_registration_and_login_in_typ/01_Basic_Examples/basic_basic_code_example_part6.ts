/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.ts
// Description: Basic Code Example
// ==========================================

app.post('/api/auth/passkey/register', async (req: Request, res: Response) => {
    try {
        const validationResult = PasskeyRegistrationSchema.safeParse(req.body);

        if (!validationResult.success) {
            const errorDetails = validationResult.error.errors.map(err => err.message);
            
            const errorResponse = createResponse<null>(
                false, 
                "Validation failed for passkey registration payload.", 
                { errors: errorDetails } as unknown as null
            );
            
            return res.status(400).json(errorResponse);
        }

        const validPayload: PasskeyRegistrationPayload = validationResult.data;

        console.log(`[Database] Persisting passkey for user: ${validPayload.username}`);

        const successResponse = createResponse<{ registeredAt: string }>(
            true,
            "Passkey successfully registered and verified.",
            { registeredAt: new Date().toISOString() }
        );

        return res.status(201).json(successResponse);

    } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
        
        const internalErrorResponse = createResponse<null>(
            false, 
            `Internal server error during registration: ${errorMessage}`, 
            null
        );
        
        return res.status(500).json(internalErrorResponse);
    }
});
