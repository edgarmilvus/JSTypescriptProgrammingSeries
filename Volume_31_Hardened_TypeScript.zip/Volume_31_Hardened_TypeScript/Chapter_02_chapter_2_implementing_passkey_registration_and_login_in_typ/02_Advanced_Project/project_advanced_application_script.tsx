/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState } from 'react';

/**
 * Interface representing the server-generated registration options 
 * required by the browser's WebAuthn navigator.credentials API.
 */
interface ServerRegistrationOptions {
  challenge: string;
  rp: { name: string; id: string };
  user: { id: string; name: string; displayName: string };
  pubKeyCredParams: { alg: number; type: 'public-key' }[];
  timeout: number;
  attestation: 'none' | 'indirect' | 'direct';
}

/**
 * Interface representing the credential response returned by the platform authenticator
 * after successful user verification (e.g., TouchID, Windows Hello, YubiKey).
 */
interface SerializedCredentialResponse {
  id: string;
  rawId: string;
  response: {
    clientDataJSON: string;
    attestationObject: string;
  };
  type: 'public-key';
}

export function PasskeyRegistrationComponent() {
  const [status, setStatus] = useState<string>('Idle');
  const [loading, setLoading] = useState<boolean>(false);

  /**
   * Converts a base64url-encoded string into an ArrayBuffer required by WebAuthn APIs.
   */
  const bufferDecode = (base64Url: string): ArrayBuffer => {
    const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
    const base64 = (base64Url + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray.buffer;
  };

  /**
   * Converts an ArrayBuffer into a base64url-encoded string for safe JSON transmission.
   */
  const bufferEncode = (buffer: ArrayBuffer): string => {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
  };

  /**
   * Triggers the full Passkey registration sequence.
   */
  const handleRegisterPasskey = async () => {
    try {
      setLoading(true);
      setStatus('Fetching registration options from server...');

      // Step 1: Request cryptographic challenge and parameters from Next.js backend
      const response = await fetch('/api/auth/passkey/register-options', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch registration challenge options.');
      }

      const options: ServerRegistrationOptions = await response.json();

      // Step 2: Prepare options by decoding base64url strings to ArrayBuffers
      const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
        ...options,
        challenge: bufferDecode(options.challenge),
        user: {
          ...options.user,
          id: new TextEncoder().encode(options.user.id),
        },
      };

      setStatus('Prompting platform authenticator (TouchID / Windows Hello)...');

      // Step 3: Invoke browser WebAuthn API
      const credential = (await navigator.credentials.create({
        publicKey: publicKeyCredentialCreationOptions,
      })) as PublicKeyCredential;

      // Type narrowing check to ensure credential acquisition was successful
      if (!credential) {
        throw new Error('Credential creation returned null.');
      }

      // Step 4: Serialize binary properties for transport
      const responseObj = credential.response as AuthenticatorAttestationResponse;
      
      const payload: SerializedCredentialResponse = {
        id: credential.id,
        rawId: bufferEncode(credential.rawId),
        type: credential.type as 'public-key',
        response: {
          clientDataJSON: bufferEncode(responseObj.clientDataJSON),
          attestationObject: bufferEncode(responseObj.attestationObject),
        },
      };

      setStatus('Verifying credential on the server...');

      // Step 5: Send serialized credential back to server for cryptographic validation & storage
      const verificationResponse = await fetch('/api/auth/passkey/register-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!verificationResponse.ok) {
        throw new Error('Server verification of passkey failed.');
      }

      setStatus('Passkey registered successfully! You may now log in.');
    } catch (err: unknown) {
      // Type narrowing for unknown catch clause errors
      if (err instanceof Error) {
        setStatus(`Error: ${err.message}`);
      } else {
        setStatus('An unexpected error occurred during registration.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold text-slate-800">Secure Account Registration</h2>
      <p className="text-sm text-slate-600">
        Register a hardware-backed passkey for phishing-resistant authentication.
      </p>
      <button
        onClick={handleRegisterPasskey}
        disabled={loading}
        className="w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-md disabled:opacity-50 transition-colors"
      >
        {loading ? 'Processing...' : 'Register Passkey'}
      </button>
      <div className="text-sm font-medium text-slate-700 bg-slate-50 p-3 rounded-md border border-slate-200">
        Status: <span className="text-indigo-600">{status}</span>
      </div>
    </div>
  );
}
