/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define strict application models
export interface AppUser {
  readonly id: string;
  readonly username: string;
  readonly displayName: string;
}

export interface RegistrationOptionsConfig {
  readonly rpName: string;
  readonly rpId: string;
  readonly user: AppUser;
  readonly excludeCredentialIds?: readonly string[];
}

/**
 * Converts a base64url string to a Uint8Array.
 */
export function base64URLToBuffer(base64URL: string): Uint8Array {
  const base64 = base64URL.replace(/-/g, '+').replace(/_/g, '/');
  const padLength = (4 - (base64.length % 4)) % 4;
  const padded = base64.padEnd(base64.length + padLength, '=');
  const binaryString = atob(padded);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Converts a Uint8Array or ArrayBuffer to a base64url string.
 */
export function bufferToBase64URL(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

// Generates registration options adhering to WebAuthn types
export function generateRegistrationOptions(config: RegistrationOptionsConfig): PublicKeyCredentialCreationOptions {
  // Generate a random 32-byte challenge using crypto.getRandomValues
  const challenge = crypto.getRandomValues(new Uint8Array(32));

  // Convert string user ID to Uint8Array as required by WebAuthn spec
  const encoder = new TextEncoder();
  const userIdBytes = encoder.encode(config.user.id);

  return {
    challenge,
    rp: {
      name: config.rpName,
      id: config.rpId,
    },
    user: {
      id: userIdBytes,
      name: config.user.username,
      displayName: config.user.displayName,
    },
    pubKeyCredParams: [
      { alg: -7, type: 'public-key' },  // ES256
      { alg: -257, type: 'public-key' }, // RS256
    ],
    timeout: 60000,
    attestation: 'none',
    excludeCredentials: config.excludeCredentialIds?.map(id => ({
      id: base64URLToBuffer(id),
      type: 'public-key',
      transports: ['internal', 'usb', 'nfc', 'ble'],
    })),
  };
}

// User-Defined Type Guard to validate incoming registration responses
export function isValidRegistrationResponse(response: unknown): response is PublicKeyCredential<AuthenticatorAttestationResponse> {
  if (!response || typeof response !== 'object') {
    return false;
  }

  const candidate = response as Record<string, unknown>;

  return (
    candidate['type'] === 'public-key' &&
    typeof candidate['id'] === 'string' &&
    candidate['response'] !== null &&
    typeof candidate['response'] === 'object' &&
    'attestationObject' in (candidate['response'] as Record<string, unknown>) &&
    'clientDataJSON' in (candidate['response'] as Record<string, unknown>)
  );
}
