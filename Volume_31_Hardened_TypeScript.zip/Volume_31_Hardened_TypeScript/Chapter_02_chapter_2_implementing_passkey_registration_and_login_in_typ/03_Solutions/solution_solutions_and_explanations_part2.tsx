/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define discriminated union for UI states
type RegistrationState =
  | { readonly status: 'IDLE' }
  | { readonly status: 'REGISTERING' }
  | { readonly status: 'SUCCESS'; readonly credentialId: string }
  | { readonly status: 'ERROR'; readonly message: string };

interface PasskeyRegistrationProps {
  readonly username: string;
  readonly onRegistrationComplete?: (credentialId: string) => void;
}

/**
 * Helper to convert ArrayBuffer to base64url string.
 */
function bufferToBase64URL(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

export const PasskeyRegistrationCard: React.FC<PasskeyRegistrationProps> = ({ username, onRegistrationComplete }) => {
  const [state, setState] = useState<RegistrationState>({ status: 'IDLE' });

  const handleRegisterPasskey = async (): Promise<void> => {
    setState({ status: 'REGISTERING' });
    
    try {
      // 1. Fetch challenge options from backend API
      const challengeRes = await fetch('/api/register/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username }),
      });

      if (!challengeRes.ok) {
        throw new Error('Failed to fetch registration challenge from server.');
      }

      const options = await challengeRes.json();

      // Convert incoming challenge and user ID strings back to ArrayBuffers
      const creationOptions: PublicKeyCredentialCreationOptions = {
        ...options,
        challenge: Uint8Array.from(atob(options.challenge), c => c.charCodeAt(0)),
        user: {
          ...options.user,
          id: Uint8Array.from(atob(options.user.id), c => c.charCodeAt(0)),
        },
      };

      // 2. Invoke navigator.credentials.create()
      const credential = (await navigator.credentials.create({
        publicKey: creationOptions,
      })) as PublicKeyCredential;

      if (!credential || !('response' in credential)) {
        throw new Error('Invalid credential returned from authenticator.');
      }

      const attestationResponse = credential.response as AuthenticatorAttestationResponse;

      // 3. Serialize binary buffers to base64url
      const serializedPayload = {
        id: credential.id,
        rawId: bufferToBase64URL(credential.rawId),
        response: {
          clientDataJSON: bufferToBase64URL(attestationResponse.clientDataJSON),
          attestationObject: bufferToBase64URL(attestationResponse.attestationObject),
        },
      };

      // 4. Send serialized credential to backend verification endpoint
      const verifyRes = await fetch('/api/register/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, ...serializedPayload }),
      });

      if (!verifyRes.ok) {
        throw new Error('Server verification of passkey registration failed.');
      }

      // 5. Update state to SUCCESS
      setState({ status: 'SUCCESS', credentialId: credential.id });
      onRegistrationComplete?.(credential.id);
      
    } catch (error: unknown) {
      // Type-narrowing extraction for unknown error instances
      let errorMessage = 'An unknown error occurred during registration.';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      setState({ status: 'ERROR', message: errorMessage });
    }
  };

  return (
    <div className="passkey-card">
      <h2>Register Passkey for {username}</h2>
      {state.status === 'SUCCESS' && <p className="success-text">Passkey registered successfully! ID: {state.credentialId}</p>}
      {state.status === 'ERROR' && <p className="error-text">Error: {state.message}</p>}
      <button onClick={handleRegisterPasskey} disabled={state.status === 'REGISTERING'}>
        {state.status === 'REGISTERING' ? 'Registering...' : 'Register New Passkey'}
      </button>
    </div>
  );
};
