/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from './database.js';

export interface VerifyRegistrationInput {
  readonly userId: string;
  readonly credentialId: string;
  readonly clientDataJSON: string;
  readonly attestationObject: string;
}

export interface VerificationResult {
  readonly verified: boolean;
  readonly credentialId?: string;
  readonly publicKey?: Uint8Array;
  readonly counter?: number;
}

export class PasskeyVerificationService {
  private readonly db: Database;

  constructor(db: Database) {
    this.db = db;
  }

  public async verifyAndStoreRegistration(
    input: VerifyRegistrationInput,
    expectedChallenge: string
  ): Promise<VerificationResult> {
    // 1. Decode clientDataJSON and parse JSON structure
    const clientDataJSONString = Buffer.from(input.clientDataJSON, 'base64url').toString('utf8');
    const clientData = JSON.parse(clientDataJSONString);

    // Validate challenge match and origin domain match
    if (clientData.challenge !== expectedChallenge) {
      throw new Error('Challenge mismatch: Potential replay attack detected.');
    }
    if (clientData.type !== 'webauthn.create') {
      throw new Error('Invalid credential type for registration.');
    }

    // 2. Decode attestationObject (mock parsing step for CBOR / authenticatorData extraction)
    const attestationBuffer = Buffer.from(input.attestationObject, 'base64url');
    // In production, use a dedicated CBOR decoder library (e.g., cbor-x) to parse attestationBuffer
    
    // Extracted mock values for demonstration of strict typing
    const credentialId = input.credentialId;
    const publicKey = new Uint8Array([/* decoded public key bytes */]);
    const counter = 0;
    const transports = ['internal'];

    // 3. Check if credentialId already exists in database using strict null checks
    const existingCredential = await this.db.findCredentialById(credentialId);
    if (existingCredential !== null) {
      throw new Error('Credential ID already registered.');
    }

    // 4. Save credential metadata to database repository
    await this.db.saveCredential({
      credentialId,
      userId: input.userId,
      publicKey,
      counter,
      transports,
    });

    return {
      verified: true,
      credentialId,
      publicKey,
      counter,
    };
  }
}
