/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from './database.js';

export interface AuthenticationChallengeOutput {
  readonly challenge: string;
  readonly allowCredentials: ReadonlyArray<{
    readonly id: string;
    readonly type: 'public-key';
    readonly transports?: ReadonlyArray<string>;
  }>;
  readonly timeout: number;
  readonly rpId: string;
}

export interface VerifyAuthenticationInput {
  readonly username: string;
  readonly credentialId: string;
  readonly clientDataJSON: string;
  readonly authenticatorData: string;
  readonly signature: string;
}

export interface AuthenticationResult {
  readonly success: boolean;
  readonly sessionToken?: string;
  readonly errorMessage?: string;
}

export class PasskeyAuthenticationService {
  private readonly db: Database;

  constructor(db: Database) {
    this.db = db;
  }

  public async generateAuthenticationOptions(username: string): Promise<AuthenticationChallengeOutput> {
    // 1. Look up user and associated credentials in database with strict null checks
    const user = await this.db.findUserByUsername(username);
    if (user === null) {
      throw new Error('User not found.');
    }

    const credentials = await this.db.findCredentialsByUserId(user.id);
    
    // Generate secure random challenge
    const challengeBuffer = crypto.getRandomValues(new Uint8Array(32));
    const challenge = Buffer.from(challengeBuffer).toString('base64url');

    return {
      challenge,
      allowCredentials: credentials.map(cred => ({
        id: cred.credentialId,
        type: 'public-key',
        transports: cred.transports,
      })),
      timeout: 60000,
      rpId: 'auth.example.com',
    };
  }

  public async verifyAuthenticationAssertion(
    input: VerifyAuthenticationInput,
    expectedChallenge: string
  ): Promise<AuthenticationResult> {
    // 1. Retrieve stored credential record using credentialId with strict null checks
    const credential = await this.db.findCredentialById(input.credentialId);
    if (credential === null) {
      return { success: false, errorMessage: 'Credential not found.' };
    }

    // 2. Decode clientDataJSON and verify challenge/origin
    const clientDataJSONString = Buffer.from(input.clientDataJSON, 'base64url').toString('utf8');
    const clientData = JSON.parse(clientDataJSONString);

    if (clientData.challenge !== expectedChallenge) {
      return { success: false, errorMessage: 'Challenge mismatch.' };
    }

    // 3. Verify cryptographic signature using stored public key (mock verification step)
    // In production, compute SHA-256 of clientDataJSON and concatenate with authenticatorData,
    // then verify the ECDSA/RSA signature using the stored public key.
    const signatureValid = true; 
    if (!signatureValid) {
      return { success: false, errorMessage: 'Invalid cryptographic signature.' };
    }

    // 4. Perform signature counter validation (anti-clone check)
    // Extract incoming counter from authenticatorData buffer
    const incomingCounter = 5; // Parsed counter example
    if (incomingCounter <= credential.counter && incomingCounter !== 0) {
      // Potential clone attack detected! Lock credential
      await this.db.lockCredential(credential.credentialId);
      return { success: false, errorMessage: 'Security alert: Passkey clone detected. Credential locked.' };
    }

    // 5. Update signature counter in database and issue session token
    await this.db.updateCredentialCounter(credential.credentialId, incomingCounter);
    
    // Mock secure session token issuance
    const sessionToken = `jwt_session_${userTokenGenerate(input.username)}`;

    return {
      success: true,
      sessionToken,
    };
  }
}

function userTokenGenerate(username: string): string {
  return Buffer.from(username).toString('base64');
}
