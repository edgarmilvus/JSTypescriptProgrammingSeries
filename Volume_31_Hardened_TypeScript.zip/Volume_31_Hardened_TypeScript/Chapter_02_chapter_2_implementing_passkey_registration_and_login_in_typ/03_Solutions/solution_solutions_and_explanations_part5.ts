/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from './database.js';

// Define discriminated union for multi-modal login requests
export type LoginRequest =
  | { readonly type: 'PASSKEY'; readonly credentialId: string; readonly assertionData: unknown }
  | { readonly type: 'PASSWORD'; readonly email: string; readonly passwordPlaintext: string };

export interface LoginResponse {
  readonly success: boolean;
  readonly sessionToken?: string;
  readonly requiresPasskeyUpgrade: boolean;
  readonly error?: string;
}

export class DualAuthOrchestratorService {
  private readonly db: Database;

  constructor(db: Database) {
    this.db = db;
  }

  public async authenticate(request: LoginRequest): Promise<LoginResponse> {
    // Use switch statement with TypeScript discriminated union narrowing on request.type
    switch (request.type) {
      case 'PASSKEY': {
        // Delegate to PasskeyAuthenticationService or verify assertion directly
        const credential = await this.db.findCredentialById(request.credentialId);
        if (credential === null) {
          return { success: false, requiresPasskeyUpgrade: false, error: 'Invalid passkey credential.' };
        }

        const sessionToken = `session_passkey_${credential.userId}`;
        return {
          success: true,
          sessionToken,
          requiresPasskeyUpgrade: false,
        };
      }

      case 'PASSWORD': {
        // Verify email and password hash against database record with strict null checks
        const user = await this.db.findUserByEmail(request.email);
        if (user === null) {
          // Uniform error response to prevent user enumeration attacks
          return { success: false, requiresPasskeyUpgrade: false, error: 'Invalid credentials.' };
        }

        const passwordValid = await verifyPasswordHash(request.passwordPlaintext, user.passwordHash);
        if (!passwordValid) {
          return { success: false, requiresPasskeyUpgrade: false, error: 'Invalid credentials.' };
        }

        // For successful password logins, check if user has registered at least one passkey
        const credentials = await this.db.findCredentialsByUserId(user.id);
        const requiresPasskeyUpgrade = credentials.length === 0;

        const sessionToken = `session_password_${user.id}`;
        return {
          success: true,
          sessionToken,
          requiresPasskeyUpgrade,
        };
      }

      default: {
        // Exhaustive check to ensure all union branches are handled
        const exhaustiveCheck: never = request;
        throw new Error(`Unhandled login request type: ${JSON.stringify(exhaustiveCheck)}`);
      }
    }
  }
}

async function verifyPasswordHash(plain: string, hash: string): Promise<boolean> {
  // Mock secure hash verification (e.g., bcrypt/argon2)
  return plain.length > 0 && hash.length > 0;
}
