/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Define strict application models
export interface AppUser {
  readonly id: string;
  readonly username: string;
  readonly displayName: string;
}

export interface RegistrationOptionsConfig {
  readonly rpName: string;
  readonly rpId: string;
  readonly user: AppUser;
  readonly excludeCredentialIds?: readonly string[];
}

// TODO: Implement the challenge generation function adhering to WebAuthn types
export function generateRegistrationOptions(config: RegistrationOptionsConfig): PublicKeyCredentialCreationOptions {
  // Your code here: Generate a random 32-byte challenge using crypto.getRandomValues
  // Format the user object with id as Uint8Array
  // Return the fully typed PublicKeyCredentialCreationOptions object
  throw new Error("Not implemented");
}

// TODO: Implement a User-Defined Type Guard to validate incoming registration responses
export function isValidRegistrationResponse(response: unknown): response is PublicKeyCredential<AuthenticatorAttestationResponse> {
  // Your code here: perform runtime checks to ensure the object is a valid credential response
  throw new Error("Not implemented");
}
