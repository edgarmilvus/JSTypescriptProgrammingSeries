/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';

// Define discriminated union for UI states
type RegistrationState =
  | { readonly status: 'IDLE' }
  | { readonly status: 'REGISTERING' }
  | { readonly status: 'SUCCESS'; readonly credentialId: string }
  | { readonly status: 'ERROR'; readonly message: string };

interface PasskeyRegistrationProps {
  readonly username: string;
  readonly onRegistrationComplete?: (credentialId: string) => void;
}

export const PasskeyRegistrationCard: React.FC<PasskeyRegistrationProps> = ({ username, onRegistrationComplete }) => {
  const [state, setState] = useState<RegistrationState>({ status: 'IDLE' });

  const handleRegisterPasskey = async (): Promise<void> => {
    // TODO: Set state to REGISTERING
    
    try {
      // TODO: Fetch challenge options from backend API (/api/register/challenge)
      
      // TODO: Invoke navigator.credentials.create() with the fetched options
      
      // TODO: Serialize binary buffers (rawId, attestationObject, clientDataJSON) to base64url
      
      // TODO: Send serialized credential to backend verification endpoint (/api/register/verify)
      
      // TODO: Update state to SUCCESS and invoke onRegistrationComplete callback if provided
      
    } catch (error: unknown) {
      // TODO: Use type guarding/narrowing to extract error message from unknown error instance
      // Update state to ERROR with the extracted message
    }
  };

  return (
    <div className="passkey-card">
      <h2>Register Passkey for {username}</h2>
      {/* TODO: Render different UI elements based on current state discriminated union */}
      <button onClick={handleRegisterPasskey} disabled={state.status === 'REGISTERING'}>
        {state.status === 'REGISTERING' ? 'Registering...' : 'Register New Passkey'}
      </button>
    </div>
  );
};
