/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { Database } from './database.js'; // ESM import with explicit extension

export interface VerifyRegistrationInput {
  readonly userId: string;
  readonly credentialId: string;
  readonly clientDataJSON: string;
  readonly attestationObject: string;
}

export interface VerificationResult {
  readonly verified: boolean;
  readonly credentialId?: string;
  readonly publicKey?: Uint8Array;
  readonly counter?: number;
}

export class PasskeyVerificationService {
  private readonly db: Database;

  constructor(db: Database) {
    this.db = db;
  }

  public async verifyAndStoreRegistration(
    input: VerifyRegistrationInput,
    expectedChallenge: string
  ): Promise<VerificationResult> {
    // TODO: Decode clientDataJSON from base64url and parse as JSON
    // Validate challenge match and origin domain match

    // TODO: Decode attestationObject using CBOR parsing to extract authenticatorData
    // Extract credential ID, public key, and initial signature counter from authenticatorData

    // TODO: Check if credentialId already exists in database using strict null checks
    
    // TODO: Save credential metadata to database repository
    
    throw new Error("Not implemented");
  }
}
