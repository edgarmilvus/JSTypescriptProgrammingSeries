/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file webhook-signer.ts
 * @description A self-contained TypeScript implementation of public-key cryptography 
 * for signing and verifying SaaS webhook payloads using Node.js native crypto module.
 */

import { generateKeyPairSync, sign, verify, KeyPairSyncResult } from 'crypto';

/**
 * Interface representing the payload structure for our SaaS webhook event.
 */
interface WebhookPayload {
    eventId: string;
    eventType: string;
    tenantId: string;
    timestamp: number;
    data: {
        amountCents: number;
        currency: string;
        status: string;
    };
}

/**
 * Interface representing the output of our key generation utility.
 */
interface TenantCryptoKeys {
    publicKey: string;
    privateKey: string;
}

/**
 * Step 1: Generate an asymmetric key pair (RSA 2048-bit) for a specific SaaS tenant.
 * In a real-world scenario, the private key is kept strictly secret by the signer,
 * while the public key is distributed to verifying services.
 */
function generateTenantKeypair(): TenantCryptoKeys {
    console.log('[Setup] Generating RSA-2048 cryptographic key pair...');
    
    const keyPair: KeyPairSyncResult<string, string> = generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicKeyEncoding: {
            type: 'spki',
            format: 'pem'
        },
        privateKeyEncoding: {
            type: 'pkcs8',
            format: 'pem'
        }
    });

    return {
        publicKey: keyPair.publicKey,
        privateKey: keyPair.privateKey
    };
}

/**
 * Step 2: Sign a payload using the private key.
 * This simulates a SaaS backend signing an outgoing webhook before dispatching it over the network.
 * 
 * @param payload - The structured data object to be signed.
 * @param privateKeyPem - The PEM-encoded private key string.
 * @returns A hexadecimal string representing the cryptographic digital signature.
 */
function signWebhookPayload(payload: WebhookPayload, privateKeyPem: string): string {
    console.log('[Signer] Serializing and signing webhook payload...');
    
    // Canonicalize the payload to ensure consistent string representation
    const payloadString = JSON.stringify(payload);
    
    // Create a signing object using SHA-256 as the hashing algorithm
    const signature = sign('sha256', Buffer.from(payloadString), {
        key: privateKeyPem,
        padding: 1 // RSA_PKCS1_PADDING
    });

    // Return the binary signature encoded as a hexadecimal string for transport
    return signature.toString('hex');
}

/**
 * Step 3: Verify a signature using the public key.
 * This simulates a client application or downstream microservice validating an incoming webhook.
 * 
 * @param payload - The received webhook payload object.
 * @param signatureHex - The hexadecimal signature string received in the webhook headers.
 * @param publicKeyPem - The PEM-encoded public key belonging to the SaaS provider.
 * @returns boolean indicating whether the signature is authentic and untampered.
 */
function verifyWebhookSignature(
    payload: WebhookPayload, 
    signatureHex: string, 
    publicKeyPem: string
): boolean {
    console.log('[Verifier] Verifying cryptographic signature of incoming webhook...');
    
    // Re-serialize the payload using the exact same structure
    const payloadString = JSON.stringify(payload);
    
    // Convert the hex signature back into a binary Buffer
    const signatureBuffer = Buffer.from(signatureHex, 'hex');

    // Perform verification using the public key
    const isAuthentic = verify(
        'sha256',
        Buffer.from(payloadString),
        {
            key: publicKeyPem,
            padding: 1 // RSA_PKCS1_PADDING
        },
        signatureBuffer
    );

    return isAuthentic;
}

// ==========================================
// Execution Flow: Simulating the SaaS Lifecycle
// ==========================================

// 1. Provision cryptographic keys for the tenant
const tenantKeys = generateTenantKeypair();

// 2. Construct the outgoing SaaS event payload
const sampleEvent: WebhookPayload = {
    eventId: "evt_9876543210abcdef",
    eventType: "invoice.payment_succeeded",
    tenantId: "tenant_alpha_42",
    timestamp: Date.now(),
    data: {
        amountCents: 4999,
        currency: "USD",
        status: "paid"
    }
};

// 3. Sign the payload at the source (SaaS Server)
const digitalSignature = signWebhookPayload(sampleEvent, tenantKeys.privateKey);
console.log(`[Dispatch] Generated Hex Signature: ${digitalSignature.substring(0, 32)}...\n`);

// 4. Verify the payload at the destination (Customer Server)
const isValid = verifyWebhookSignature(sampleEvent, digitalSignature, tenantKeys.publicKey);

console.log(`----------------------------------------`);
console.log(`Verification Result: ${isValid ? 'SUCCESS (Authentic)' : 'FAILED (Tampered or Invalid)'}`);
console.log(`----------------------------------------`);

// 5. Demonstrate Tamper Detection (Security Check)
console.log('\n[Security Test] Attempting verification with a tampered payload...');
const tamperedEvent: WebhookPayload = {
    ...sampleEvent,
    data: {
        ...sampleEvent.data,
        amountCents: 100 // Attacker modified the price!
    }
};

const isTamperedValid = verifyWebhookSignature(tamperedEvent, digitalSignature, tenantKeys.publicKey);
console.log(`Tampered Payload Verification Result: ${isTamperedValid ? 'SUCCESS (VULNERABILITY!)' : 'REJECTED (Secure)'}`);
