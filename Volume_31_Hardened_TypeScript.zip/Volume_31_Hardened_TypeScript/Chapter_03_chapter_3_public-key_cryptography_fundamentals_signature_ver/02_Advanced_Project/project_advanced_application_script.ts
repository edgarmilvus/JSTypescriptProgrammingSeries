/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import * as crypto from 'crypto';

/**
 * Interface representing the cryptographic key pair used for signing and verification.
 */
interface TenantKeyPair {
  tenantId: string;
  publicKey: string;
  privateKey: string;
}

/**
 * Interface representing the outgoing webhook payload and its associated metadata headers.
 */
interface WebhookEnvelope {
  eventId: string;
  timestamp: number;
  eventType: string;
  data: Record<string, unknown>;
}

/**
 * Interface representing the incoming network transmission containing the payload and signature.
 */
interface SignedWebhookRequest {
  rawBody: string;
  signature: string;
  timestamp: number;
}

/**
 * Enterprise Webhook Cryptographic Engine
 * Handles key generation, payload canonicalization, signature generation, and verification.
 */
export class WebhookSecurityEngine {
  private static readonly ALGORITHM = 'sha256';
  private static readonly SIGNATURE_ENCODING = 'hex';
  private static readonly MAX_TIMESTAMP_DRIFT_MS = 5 * 60 * 1000; // 5 minutes tolerance

  /**
   * Generates an asymmetric RSA-PSS cryptographic key pair for a specific tenant.
   * RSA-PSS (Probabilistic Signature Scheme) is chosen for its superior security proofs compared to PKCS#1 v1.5.
   * 
   * @param tenantId - Unique identifier for the SaaS tenant.
   * @returns A promise resolving to the generated key pair.
   */
  public static async generateTenantKeyPair(tenantId: string): Promise<TenantKeyPair> {
    return new Promise((resolve, reject) => {
      crypto.generateKeyPair(
        'rsa',
        {
          modulusLength: 4096,
          publicKeyEncoding: {
            type: 'spki',
            format: 'pem',
          },
          privateKeyEncoding: {
            type: 'pkcs8',
            format: 'pem',
          },
        },
        (err, publicKey, privateKey) => {
          if (err) {
            return reject(new Error(`Failed to generate key pair: ${err.message}`));
          }
          resolve({
            tenantId,
            publicKey,
            privateKey,
          });
        }
      );
    });
  }

  /**
   * Canonicalizes and signs a webhook envelope using the tenant's private key.
   * 
   * @param envelope - The structured webhook payload.
   * @param privateKeyPem - The PEM-encoded private key of the sender.
   * @returns The signed webhook request object ready for transmission over HTTP.
   */
  public static signWebhook(envelope: WebhookEnvelope, privateKeyPem: string): SignedWebhookRequest {
    // Ensure deterministic serialization by sorting object keys or utilizing structured stringification.
    // Here we serialize the raw payload consistently.
    const rawBody = JSON.stringify(envelope);

    // Construct the canonical signing string by combining the timestamp and the exact raw body.
    // This prevents replay attacks where an attacker captures an old request and replays it with a new body (or vice versa).
    const canonicalString = `${envelope.timestamp}.${rawBody}`;

    // Create a crypto sign object using SHA-256
    const sign = crypto.createSign(this.ALGORITHM);
    sign.update(canonicalString);
    sign.end();

    // Generate the digital signature using RSA-PSS with salt length equal to digest length (PSS padding)
    const signature = sign.sign(
      {
        key: privateKeyPem,
        padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
        saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
      },
      this.SIGNATURE_ENCODING
    );

    return {
      rawBody,
      signature,
      timestamp: envelope.timestamp,
    };
  }

  /**
   * Verifies an incoming webhook request's digital signature and checks for timestamp validity (replay attack mitigation).
   * 
   * @param request - The incoming signed webhook request wrapper.
   * @param publicKeyPem - The PEM-encoded public key belonging to the tenant.
   * @returns boolean indicating whether the signature is authentic and the request is fresh.
   */
  public static verifyWebhook(request: SignedWebhookRequest, publicKeyPem: string): boolean {
    const currentTime = Date.now();

    // 1. Replay Attack Prevention: Validate that the timestamp is within an acceptable temporal window.
    const timeDelta = Math.abs(currentTime - request.timestamp);
    if (timeDelta > this.MAX_TIMESTAMP_DRIFT_MS) {
      console.warn(`Webhook verification failed: Timestamp drift detected (${timeDelta}ms). Possible replay attack.`);
      return false;
    }

    // 2. Reconstruct the exact canonical string used by the sender.
    const canonicalString = `${request.timestamp}.${request.rawBody}`;

    // 3. Initialize the verification utility
    const verify = crypto.createVerify(this.ALGORITHM);
    verify.update(canonicalString);
    verify.end();

    try {
      // 4. Perform cryptographic verification using the tenant's public key
      const isValid = verify.verify(
        {
          key: publicKeyPem,
          padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
          saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
        },
        request.signature,
        this.SIGNATURE_ENCODING
      );

      return isValid;
    } catch (error) {
      console.error(`Cryptographic verification threw an unexpected error: ${(error as Error).message}`);
      return false;
    }
  }
}

// ==========================================
// EXAMPLE EXECUTION FLOW (SIMULATION)
// ==========================================

async function runDemo() {
  console.log('--- Initializing SaaS Webhook Security Simulation ---');

  // 1. Generate tenant keys
  const tenantId = 'tenant_enterprise_99';
  console.log(`[Setup] Generating 4096-bit RSA-PSS key pair for ${tenantId}...`);
  const keyPair = await WebhookSecurityEngine.generateTenantKeyPair(tenantId);

  // 2. Construct sample webhook payload
  const samplePayload: WebhookEnvelope = {
    eventId: 'evt_2023_xyz789',
    timestamp: Date.now(),
    eventType: 'invoice.payment_succeeded',
    data: {
      invoiceId: 'inv_12345',
      amountDue: 150000,
      currency: 'USD',
      customer: 'acme_corp',
    },
  };

  // 3. Sender signs the webhook
  console.log('[Sender] Signing webhook payload...');
  const signedRequest = WebhookSecurityEngine.signWebhook(samplePayload, keyPair.privateKey);
  console.log(`[Sender] Generated Signature: ${signedRequest.signature.substring(0, 32)}...`);

  // 4. Receiver verifies the webhook
  console.log('[Receiver] Verifying incoming webhook signature and timestamp...');
  const isAuthentic = WebhookSecurityEngine.verifyWebhook(signedRequest, keyPair.publicKey);

  if (isAuthentic) {
    console.log('[Receiver] SUCCESS: Webhook signature is VALID. Processing business logic...');
    const parsedData = JSON.parse(signedRequest.rawBody);
    console.log('[Receiver] Event Data:', parsedData.eventType);
  } else {
    console.error('[Receiver] SECURITY ALERT: Webhook signature is INVALID or request expired!');
  }

  // 5. Simulate a tampering attack (Man-in-the-Middle modification of rawBody)
  console.log('\n--- Simulating Man-in-the-Middle Tampering Attack ---');
  const tamperedRequest: SignedWebhookRequest = {
    ...signedRequest,
    rawBody: JSON.stringify({
      ...samplePayload,
      data: { ...samplePayload.data, amountDue: 100 }, // Attacker changes amount
    }),
  };

  const isTamperedValid = WebhookSecurityEngine.verifyWebhook(tamperedRequest, keyPair.publicKey);
  console.log(`[Receiver] Tampered request verification result: ${isTamperedValid ? 'VALID (FAIL)' : 'INVALID (PASS - Attack Blocked)'}`);
}

// Execute the simulation if run directly
if (require.main === module) {
  runDemo().catch(console.error);
}
