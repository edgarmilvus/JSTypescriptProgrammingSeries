/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'node:crypto';

export interface SerializedKeyBundle {
  publicKey: string | object;
  privateKey?: string | object;
  algorithm: string;
  fingerprint: string;
}

interface HistoricalKeyRecord {
  publicKey: crypto.KeyObject;
  privateKey: crypto.KeyObject;
  algorithm: 'rsa' | 'ed25519';
  createdAt: number;
  expiresAt: number;
  fingerprint: string;
}

export class CryptographicIdentityManager {
  private activeKeyPair?: {
    publicKey: crypto.KeyObject;
    privateKey: crypto.KeyObject;
    algorithm: 'rsa' | 'ed25519';
    createdAt: number;
  };
  private historicalRegistry: HistoricalKeyRecord[] = [];

  public async generateKeyPair(
    algorithm: 'rsa' | 'ed25519',
    options?: { modulusLength?: number; passphrase?: string }
  ): Promise<SerializedKeyBundle> {
    let publicKey: crypto.KeyObject;
    let privateKey: crypto.KeyObject;

    if (algorithm === 'rsa') {
      const modulusLength = options?.modulusLength || 4096;
      const keys = crypto.generateKeyPairSync('rsa', {
        modulusLength,
        publicKeyEncoding: { type: 'spki', format: 'pem' },
        privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
      });
      publicKey = crypto.createPublicKey(keys.publicKey);
      privateKey = crypto.createPrivateKey(keys.privateKey);
    } else if (algorithm === 'ed25519') {
      const keys = crypto.generateKeyPairSync('ed25519', {
        publicKeyEncoding: { type: 'spki', format: 'pem' },
        privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
      });
      publicKey = crypto.createPublicKey(keys.publicKey);
      privateKey = crypto.createPrivateKey(keys.privateKey);
    } else {
      throw new Error(`Unsupported algorithm: ${algorithm}`);
    }

    this.activeKeyPair = {
      publicKey,
      privateKey,
      algorithm,
      createdAt: Date.now(),
    };

    const pubDer = publicKey.export({ type: 'spki', format: 'der' });
    const fingerprint = crypto.createHash('sha256').update(pubDer).digest('hex');

    return {
      publicKey: publicKey.export({ format: 'pem' }),
      privateKey: privateKey.export({ format: 'pem', type: 'pkcs8' }),
      algorithm,
      fingerprint,
    };
  }

  public exportKeys(format: 'pem' | 'jwk', passphrase?: string): SerializedKeyBundle {
    if (!this.activeKeyPair) {
      throw new Error('No active key pair generated. Call generateKeyPair first.');
    }

    const { publicKey, privateKey, algorithm } = this.activeKeyPair;
    const pubDer = publicKey.export({ type: 'spki', format: 'der' });
    const fingerprint = crypto.createHash('sha256').update(pubDer).digest('hex');

    if (format === 'jwk') {
      return {
        publicKey: publicKey.export({ format: 'jwk' }),
        privateKey: privateKey.export({ format: 'jwk' }),
        algorithm,
        fingerprint,
      };
    }

    // PEM format handling
    const pubExport = publicKey.export({ type: 'spki', format: 'pem' }) as string;
    let privExport: string;

    if (passphrase) {
      privExport = privateKey.export({
        type: 'pkcs8',
        format: 'pem',
        cipher: 'aes-256-cbc',
        passphrase,
      }) as string;
    } else {
      privExport = privateKey.export({
        type: 'pkcs8',
        format: 'pem',
      }) as string;
    }

    return {
      publicKey: pubExport,
      privateKey: privExport,
      algorithm,
      fingerprint,
    };
  }

  public importPublicKey(rawKey: string | object, format: 'pem' | 'jwk'): crypto.KeyObject {
    if (format === 'jwk') {
      if (typeof rawKey !== 'object' || rawKey === null) {
        throw new Error('Invalid JWK format: must be a JavaScript object');
      }
      return crypto.createPublicKey({ key: rawKey as crypto.JsonWebKey, format: 'jwk' });
    }

    if (typeof rawKey !== 'string') {
      throw new Error('Invalid PEM format: must be a string');
    }

    return crypto.createPublicKey({ key: rawKey, format: 'pem', type: 'spki' });
  }

  public async rotateKeys(passphrase: string): Promise<{ newFingerprint: string; transitionProof: string }> {
    if (!this.activeKeyPair) {
      throw new Error('Cannot rotate keys: No active key pair exists.');
    }

    const oldPair = this.activeKeyPair;
    const oldPubDer = oldPair.publicKey.export({ type: 'spki', format: 'der' });
    const oldFingerprint = crypto.createHash('sha256').update(oldPubDer).digest('hex');

    // Archive current key pair into historical registry
    this.historicalRegistry.push({
      ...oldPair,
      expiresAt: Date.now() + 90 * 24 * 60 * 60 * 1000, // 90 days validity window
      fingerprint: oldFingerprint,
    });

    // Generate new active key pair (defaulting to RSA 4096 or maintaining previous choice style)
    const newBundle = await this.generateKeyPair(oldPair.algorithm);
    
    // Construct transition payload proving the rotation chain of custody
    const transitionPayload = JSON.stringify({
      previousFingerprint: oldFingerprint,
      newFingerprint: newBundle.fingerprint,
      rotatedAt: Date.now(),
    });

    // Sign the transition payload using the OLD private key
    const sign = crypto.createSign('sha256');
    sign.update(transitionPayload);
    sign.end();
    
    const transitionProof = sign.sign(oldPair.privateKey, 'base64');

    return {
      newFingerprint: newBundle.fingerprint,
      transitionProof,
    };
  }
}
