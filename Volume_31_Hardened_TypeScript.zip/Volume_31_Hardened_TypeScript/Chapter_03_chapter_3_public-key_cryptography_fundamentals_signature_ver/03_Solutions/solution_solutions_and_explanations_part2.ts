/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response, NextFunction } from 'express';
import * as crypto from 'node:crypto';

export interface WebhookOptions {
  toleranceSeconds: number;
}

// Simulated Redis cache interface for replay prevention
interface ReplayCache {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, expirySeconds: number): Promise<void>;
}

export function signPayload(
  payload: Record<string, any>,
  privateKey: crypto.KeyObject,
  timestamp: number
): string {
  // Deterministic canonical serialization: sort keys recursively
  const canonicalString = JSON.stringify(payload, Object.keys(payload).sort());
  const signedContent = `${timestamp}.${canonicalString}`;

  const signer = crypto.createSign('sha256');
  signer.update(signedContent);
  signer.end();

  return signer.sign(privateKey, 'base64');
}

export function createWebhookVerificationMiddleware(
  publicKeyProvider: (keyId: string) => Promise<crypto.KeyObject>,
  options: WebhookOptions,
  cacheClient?: ReplayCache
): (req: Request, res: Response, next: NextFunction) => Promise<void> {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const signature = req.headers['x-signature-value'] as string;
      const keyId = req.headers['x-signature-keyid'] as string;
      const timestampHeader = req.headers['x-signature-timestamp'] as string;

      if (!signature || !keyId || !timestampHeader) {
        res.status(400).json({ error: 'Missing required cryptographic webhook headers.' });
        return;
      }

      const timestamp = parseInt(timestampHeader, 10);
      if (isNaN(timestamp)) {
        res.status(400).json({ error: 'Invalid timestamp format.' });
        return;
      }

      // 1. Enforce timestamp tolerance window against replay attacks
      const now = Math.floor(Date.now() / 1000);
      if (Math.abs(now - timestamp) > options.toleranceSeconds) {
        res.status(400).json({ error: 'Webhook timestamp outside tolerance window.' });
        return;
      }

      // 2. Interactive Challenge: Distributed Replay-Prevention Cache Check
      const nonceKey = `webhook:nonce:${signature}`;
      if (cacheClient) {
        const cached = await cacheClient.get(nonceKey);
        if (cached) {
          res.status(409).json({ error: 'Replay attack detected: Signature already processed.' });
          return;
        }
        // Store signature hash in cache with expiry matching the tolerance window
        await cacheClient.set(nonceKey, 'processed', options.toleranceSeconds);
      }

      // 3. Fetch public key dynamically using keyId provider
      const publicKey = await publicKeyProvider(keyId);
      if (!publicKey) {
        res.status(401).json({ error: 'Unknown signature key identifier.' });
        return;
      }

      // 4. Reconstruct signed content string from body and timestamp
      // Assuming body is already parsed or available as raw/JSON object
      const payload = req.body || {};
      const canonicalString = JSON.stringify(payload, Object.keys(payload).sort());
      const signedContent = `${timestamp}.${canonicalString}`;

      // 5. Verify cryptographic signature
      const verifier = crypto.createVerify('sha256');
      verifier.update(signedContent);
      verifier.end();

      const isValid = verifier.verify(publicKey, Buffer.from(signature, 'base64'));

      if (!isValid) {
        res.status(401).json({ error: 'Cryptographic signature verification failed.' });
        return;
      }

      next();
    } catch (err) {
      res.status(500).json({ error: 'Internal server error during webhook verification.' });
    }
  };
}
