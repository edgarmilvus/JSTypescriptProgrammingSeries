/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';

export interface VerificationReport {
  filePath: string;
  signaturePath: string;
  isValid: boolean;
  error?: string;
}

export class ArtifactVerifier {
  private trustedPublicKey: crypto.KeyObject;

  constructor(publicKeyPath: string) {
    const pemContent = fs.readFileSync(publicKeyPath, 'utf8');
    this.trustedPublicKey = crypto.createPublicKey({ key: pemContent, format: 'pem' });
  }

  public async verifyArtifact(filePath: string, signaturePath: string): Promise<boolean> {
    if (!fs.existsSync(filePath) || !fs.existsSync(signaturePath)) {
      throw new Error('Artifact or signature file does not exist.');
    }

    const signatureBuffer = fs.readFileSync(signaturePath);

    return new Promise((resolve, reject) => {
      const hashStream = crypto.createHash('sha384');
      const fileStream = fs.createReadStream(filePath);

      fileStream.on('error', (err) => reject(err));
      fileStream.on('data', (chunk) => hashStream.update(chunk));
      
      fileStream.on('end', () => {
        const fileDigest = hashStream.digest();
        try {
          const isValid = crypto.verify(
            'sha384',
            fileDigest,
            this.trustedPublicKey,
            signatureBuffer
          );
          resolve(isValid);
        } catch (err) {
          resolve(false);
        }
      });
    });
  }

  public async verifyBatch(directoryPath: string): Promise<VerificationReport[]> {
    const reports: VerificationReport[] = [];
    const entries = fs.readdirSync(directoryPath, { withFileTypes: true });

    for (const entry of entries) {
      if (entry.isFile()) {
        const fullPath = path.join(directoryPath, entry.name);
        
        // Skip signature files themselves during batch scan
        if (entry.name.endsWith('.sig')) {
          continue;
        }

        const signaturePath = `${fullPath}.sig`;
        if (fs.existsSync(signaturePath)) {
          try {
            const isValid = await this.verifyArtifact(fullPath, signaturePath);
            reports.push({ filePath: fullPath, signaturePath, isValid });
          } catch (err: any) {
            reports.push({ filePath: fullPath, signaturePath, isValid: false, error: err.message });
          }
        }
      }
    }

    return reports;
  }

  public async verifyWithCertificateChain(
    artifactPath: string,
    signaturePath: string,
    certificateChain: string[]
  ): Promise<boolean> {
    if (certificateChain.length === 0) {
      return false;
    }

    // Parse leaf public key from the first element of the chain
    const leafPublicKey = crypto.createPublicKey({ key: certificateChain[0], format: 'pem' });
    
    // 1. Verify artifact against leaf public key using streaming hash
    const signatureBuffer = fs.readFileSync(signaturePath);
    const fileDigest = await new Promise<Buffer>((resolve, reject) => {
      const hash = crypto.createHash('sha384');
      const stream = fs.createReadStream(artifactPath);
      stream.on('data', (chunk) => hash.update(chunk));
      stream.on('end', () => resolve(hash.digest()));
      stream.on('error', reject);
    });

    const isArtifactValid = crypto.verify('sha384', fileDigest, leafPublicKey, signatureBuffer);
    if (!isArtifactValid) return false;

    // 2. Validate Certificate Chain against Root of Trust
    let currentKey = leafPublicKey;
    for (let i = 0; i < certificateChain.length - 1; i++) {
      const signerPem = certificateChain[i + 1];
      const signerKey = crypto.createPublicKey({ key: signerPem, format: 'pem' });
      
      // In a strict X.509 setup, verify that certificate[i] was signed by certificate[i+1]
      // For demonstration, we ensure the chain terminates at our hardcoded root
      if (i === certificateChain.length - 2) {
        // Final link must match our application's trusted root key fingerprint
        const rootDer = this.trustedPublicKey.export({ type: 'spki', format: 'der' });
        const signerDer = signerKey.export({ type: 'spki', format: 'der' });
        if (!rootDer.equals(signerDer)) {
          return false;
        }
      }
    }

    return true;
  }
}
