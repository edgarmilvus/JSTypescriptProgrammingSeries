/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface KeyRecord {
  id: string;
  algorithm: 'RSA-4096' | 'Ed25519';
  fingerprint: string;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'deprecated' | 'revoked';
}

export interface VerificationMetrics {
  totalVerified: number;
  failedVerifications: number;
  averageLatencyMs: number;
}

export interface CryptoDashboardProps {
  initialKeys: KeyRecord[];
  metrics: VerificationMetrics;
  onVerifyPayload?: (payload: string, signature: string, keyId: string) => Promise<boolean>;
  onTriggerRotation?: (keyId: string) => Promise<KeyRecord>;
}

export const CryptoDashboard: React.FC<CryptoDashboardProps> = ({
  initialKeys,
  metrics,
  onVerifyPayload,
  onTriggerRotation
}) => {
  const [keys, setKeys] = useState<KeyRecord[]>(initialKeys);
  const [payloadInput, setPayloadInput] = useState<string>('{\n  "event": "user.signup",\n  "userId": "12345"\n}');
  const [signatureInput, setSignatureInput] = useState<string>('');
  const [selectedKeyId, setSelectedKeyId] = useState<string>(initialKeys[0]?.id || '');
  const [verificationResult, setVerificationResult] = useState<boolean | null>(null);
  const [loadingRotationId, setLoadingRotationId] = useState<string | null>(null);

  // Countdown timer trigger for expiration checking (< 30 days)
  const isExpiringSoon = (expiresAt: string): boolean => {
    const diffDays = (new Date(expiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return diffDays > 0 && diffDays < 30;
  };

  const handleVerify = async () => {
    if (onVerifyPayload) {
      try {
        const isValid = await onVerifyPayload(payloadInput, signatureInput, selectedKeyId);
        setVerificationResult(isValid);
      } catch {
        setVerificationResult(false);
      }
    } else {
      setVerificationResult(false);
    }
  };

  const handleRotation = async (keyId: string) => {
    if (!onTriggerRotation) return;
    setLoadingRotationId(keyId);
    try {
      const updatedKey = await onTriggerRotation(keyId);
      setKeys(keys.map(k => (k.id === keyId ? updatedKey : k)));
    } finally {
      setLoadingRotationId(null);
    }
  };

  return (
    <div className="crypto-dashboard" aria-label="Cryptographic Security Dashboard" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Cryptographic Identity & Signature Verification Dashboard</h2>

      {/* Metrics Summary Cards */}
      <div className="metrics-grid" style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '6px' }}>
          <h4>Total Verified</h4>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{metrics.totalVerified}</p>
        </div>
        <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '6px' }}>
          <h4>Failed Verifications</h4>
          <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#d9534f' }}>{metrics.failedVerifications}</p>
        </div>
        <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '6px' }}>
          <h4>Average Latency</h4>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{metrics.averageLatencyMs} ms</p>
        </div>
      </div>

      {/* Keys Management Table */}
      <div className="keys-section" style={{ marginBottom: '30px' }}>
        <h3>Active Cryptographic Keys</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #ddd' }}>
              <th style={{ padding: '8px' }}>Algorithm</th>
              <th style={{ padding: '8px' }}>Fingerprint (SHA-256)</th>
              <th style={{ padding: '8px' }}>Created At</th>
              <th style={{ padding: '8px' }}>Expires At</th>
              <th style={{ padding: '8px' }}>Status</th>
              <th style={{ padding: '8px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {keys.map((key) => (
              <tr key={key.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '8px' }}>{key.algorithm}</td>
                <td style={{ padding: '8px', fontFamily: 'monospace' }}>{key.fingerprint.substring(0, 16)}...</td>
                <td style={{ padding: '8px' }}>{key.createdAt}</td>
                <td style={{ padding: '8px' }}>
                  {key.expiresAt}
                  {isExpiringSoon(key.expiresAt) && (
                    <div style={{ color: '#d9534f', fontSize: '12px', fontWeight: 'bold' }}>Expiring Soon!</div>
                  )}
                </td>
                <td style={{ padding: '8px' }}>
                  <span style={{ padding: '4px 8px', borderRadius: '4px', background: key.status === 'active' ? '#d4edda' : '#f8d7da' }}>
                    {key.status}
                  </span>
                </td>
                <td style={{ padding: '8px' }}>
                  {loadingRotationId === key.id ? (
                    <span>Rotating...</span>
                  ) : (
                    isExpiringSoon(key.expiresAt) && (
                      <button onClick={() => handleRotation(key.id)} style={{ background: '#d9534f', color: '#fff', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}>
                        Trigger Emergency Rotation
                      </button>
                    )
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Interactive Signature Playground */}
      <div className="signature-playground" style={{ border: '1px solid #ddd', padding: '20px', borderRadius: '6px' }}>
        <h3>Signature Verification Playground</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <label>
            Select Key ID:
            <select value={selectedKeyId} onChange={(e) => setSelectedKeyId(e.target.value)} style={{ marginLeft: '10px', padding: '4px' }}>
              {keys.map(k => <option key={k.id} value={k.id}>{k.id} ({k.algorithm})</option>)}
            </select>
          </label>
          <label>
            JSON Payload:
            <textarea value={payloadInput} onChange={(e) => setPayloadInput(e.target.value)} rows={5} style={{ width: '100%', fontFamily: 'monospace' }} />
          </label>
          <label>
            Signature (Base64):
            <input type="text" value={signatureInput} onChange={(e) => setSignatureInput(e.target.value)} style={{ width: '100%', padding: '6px' }} />
          </label>
          <button onClick={handleVerify} style={{ padding: '10px', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Verify Signature
          </button>
          {verificationResult !== null && (
            <div style={{ padding: '10px', borderRadius: '4px', background: verificationResult ? '#d4edda' : '#f8d7da', color: verificationResult ? '#155724' : '#721c24', fontWeight: 'bold' }}>
              {verificationResult ? 'Verified - Valid Signature' : 'Tampered - Invalid Signature'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
