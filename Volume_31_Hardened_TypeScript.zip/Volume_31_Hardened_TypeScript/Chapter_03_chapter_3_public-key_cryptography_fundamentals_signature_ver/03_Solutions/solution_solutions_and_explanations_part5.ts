/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'node:crypto';

export class SessionExpiredError extends Error {}
export class InvalidSignatureError extends Error {}
export class SessionNotFoundError extends Error {}

export class ServerChallengeIssuer {
  private activeChallenges: Map<string, { nonce: string; expiresAt: number; ephemeralSecret?: string }> = new Map();
  private ttlSeconds: number;

  constructor(ttlSeconds: number = 60) {
    this.ttlSeconds = ttlSeconds;
  }

  public createChallenge(ephemeralSecret?: string): { sessionId: string; nonce: string } {
    const sessionId = crypto.randomUUID();
    const nonce = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + this.ttlSeconds * 1000;

    this.activeChallenges.set(sessionId, { nonce, expiresAt, ephemeralSecret });
    return { sessionId, nonce };
  }

  public getNonce(sessionId: string): { nonce: string; ephemeralSecret?: string } {
    const challenge = this.activeChallenges.get(sessionId);
    if (!challenge) {
      throw new SessionNotFoundError(`Session ID ${sessionId} not found.`);
    }

    if (Date.now() > challenge.expiresAt) {
      this.activeChallenges.delete(sessionId);
      throw new SessionExpiredError(`Session ID ${sessionId} has expired.`);
    }

    return { nonce: challenge.nonce, ephemeralSecret: challenge.ephemeralSecret };
  }

  public burnSession(sessionId: string): void {
    this.activeChallenges.delete(sessionId);
  }
}

export class ClientAuthenticator {
  private privateKey: crypto.KeyObject;
  private clientId: string;

  constructor(clientId: string, privateKey: crypto.KeyObject) {
    this.clientId = clientId;
    this.privateKey = privateKey;
  }

  public respondToChallenge(nonce: string, ephemeralSecret?: string): string {
    let contentToSign = nonce;

    // Interactive Challenge: Zero-Knowledge-inspired composite hash if ephemeral secret is present
    if (ephemeralSecret) {
      contentToSign = crypto.createHash('sha256').update(`${nonce}:${ephemeralSecret}`).digest('hex');
    }

    const signer = crypto.createSign('sha256');
    signer.update(contentToSign);
    signer.end();

    return signer.sign(this.privateKey, 'base64');
  }
}

export class ServerVerifier {
  private issuer: ServerChallengeIssuer;

  constructor(issuer: ServerChallengeIssuer) {
    this.issuer = issuer;
  }

  public verifyChallengeResponse(
    sessionId: string,
    signature: string,
    clientPublicKey: crypto.KeyObject
  ): boolean {
    try {
      const { nonce, ephemeralSecret } = this.issuer.getNonce(sessionId);

      let contentToVerify = nonce;
      if (ephemeralSecret) {
        contentToVerify = crypto.createHash('sha256').update(`${nonce}:${ephemeralSecret}`).digest('hex');
      }

      const verifier = crypto.createVerify('sha256');
      verifier.update(contentToVerify);
      verifier.end();

      const isValid = verifier.verify(clientPublicKey, Buffer.from(signature, 'base64'));

      // Burn the session immediately to prevent replay attacks regardless of validity outcome
      this.issuer.burnSession(sessionId);

      if (!isValid) {
        throw new InvalidSignatureError('Cryptographic challenge signature verification failed.');
      }

      return true;
    } catch (err) {
      // Ensure session is burned on error paths as well
      this.issuer.burnSession(sessionId);
      throw err;
    }
  }
}
