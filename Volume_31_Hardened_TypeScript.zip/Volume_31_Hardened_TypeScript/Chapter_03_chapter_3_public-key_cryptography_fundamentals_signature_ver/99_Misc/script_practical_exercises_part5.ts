/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

import * as crypto from 'node:crypto';

export class SessionExpiredError extends Error {}
export class InvalidSignatureError extends Error {}
export class SessionNotFoundError extends Error {}

export class ServerChallengeIssuer {
  private activeChallenges: Map<string, { nonce: string; expiresAt: number }> = new Map();

  public createChallenge(): { sessionId: string; nonce: string } {
    // TODO: Generate secure random nonce, store in map with TTL, return session details
    throw new Error('Not implemented');
  }

  public getNonce(sessionId: string): string {
    // TODO: Retrieve and validate session TTL
    throw new Error('Not implemented');
  }
}

export class ClientAuthenticator {
  private privateKey: crypto.KeyObject;
  private clientId: string;

  constructor(clientId: string, privateKey: crypto.KeyObject) {
    this.clientId = clientId;
    this.privateKey = privateKey;
  }

  public respondToChallenge(nonce: string): string {
    // TODO: Sign the challenge nonce using node:crypto sign
    throw new Error('Not implemented');
  }
}

export class ServerVerifier {
  private issuer: ServerChallengeIssuer;

  constructor(issuer: ServerChallengeIssuer) {
    this.issuer = issuer;
  }

  public verifyChallengeResponse(
    sessionId: string,
    signature: string,
    clientPublicKey: crypto.KeyObject
  ): boolean {
    // TODO: Verify signature, validate session, and burn the session token
    throw new Error('Not implemented');
  }
}
