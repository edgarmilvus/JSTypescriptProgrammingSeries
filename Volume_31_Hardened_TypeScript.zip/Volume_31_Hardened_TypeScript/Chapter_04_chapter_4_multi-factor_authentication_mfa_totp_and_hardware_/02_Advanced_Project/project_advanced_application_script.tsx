/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview FIDO2/WebAuthn Hardware Key Authentication Module
 * @module lib/auth/hardware-keys
 * @description Provides Next.js Server Actions and client utilities for registering 
 * and authenticating FIDO2-compliant hardware keys (YubiKeys) with anti-replay protection.
 */

import { headers } from 'next/headers';
import { 
  generateRegistrationOptions, 
  verifyRegistrationResponse, 
  generateAuthenticationOptions, 
  verifyAuthenticationResponse,
  VerifiedRegistrationResponse,
  VerifiedAuthenticationResponse
} from '@simplewebauthn/server';
import type { 
  RegistrationResponseJSON, 
  AuthenticationResponseJSON,
  AuthenticatorDevice 
} from '@simplewebauthn/typescript-types';

// ==========================================
// MOCK DATABASE & CONFIGURATION LAYER
// ==========================================

const RP_NAME = "Enterprise SaaS Secure Portal";
const RP_ID = process.env.NEXT_PUBLIC_RP_ID || "localhost";
const EXPECTED_ORIGIN = process.env.NEXT_PUBLIC_EXPECTED_ORIGIN || "http://localhost:3000";

/**
 * In-memory data store representing user hardware key credentials.
 * In a production environment, map this to PostgreSQL/Prisma or DynamoDB.
 */
interface UserRecord {
  userId: string;
  username: string;
  currentChallenge?: string;
  devices: AuthenticatorDevice[];
}

const userDatabase = new Map<string, UserRecord>();

// ==========================================
// SERVER ACTIONS (NEXT.JS APP ROUTER)
// ==========================================

/**
 * Step 1: Generate Registration Options for a new YubiKey
 * Sends cryptographic parameters (RP ID, User ID, algorithms) to the client 
 * to prompt the browser and hardware authenticator.
 */
export async function generateWebAuthnRegistrationOptions(userId: string, username: string) {
  'use server';

  // Retrieve or initialize user record in our database mock
  let user = userDatabase.get(userId);
  if (!user) {
    user = { userId, username, devices: [] };
    userDatabase.set(userId, user);
  }

  // Map existing devices to prevent registering the exact same YubiKey twice
  const excludeCredentials = user.devices.map(device => ({
    id: device.credentialID,
    type: 'public-key' as const,
    transports: device.transports,
  }));

  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID: RP_ID,
    userID: userId,
    userName: username,
    // Require resident keys (discoverable credentials) for passwordless flows
    authenticatorSelection: {
      residentKey: 'preferred',
      userVerification: 'required',
      authenticatorAttachment: 'cross-platform', // Targets external keys like YubiKey USB
    },
    supportedAlgorithmIDs: [-7, -257], // ES256 and RS256
    excludeCredentials,
  });

  // Persist challenge temporarily to verify the response later
  user.currentChallenge = options.challenge;
  userDatabase.set(userId, user);

  return options;
}

/**
 * Step 2: Verify Registration Response from Hardware Key
 * Validates the public key, attestation statement, and signature sent back by the browser.
 */
export async function verifyWebAuthnRegistration(
  userId: string, 
  response: RegistrationResponseJSON
): Promise<{ verified: boolean; error?: string }> {
  'use server';

  const user = userDatabase.get(userId);
  if (!user || !user.currentChallenge) {
    return { verified: false, error: 'User or challenge not found in state.' };
  }

  let verification: VerifiedRegistrationResponse;
  try {
    verification = await verifyRegistrationResponse({
      response,
      expectedChallenge: user.currentChallenge,
      expectedOrigin: EXPECTED_ORIGIN,
      expectedRPID: RP_ID,
      requireUserVerification: true,
    });
  } catch (error: any) {
    return { verified: false, error: error.message };
  }

  const { verified, registrationInfo } = verification;

  if (verified && registrationInfo) {
    const { credentialPublicKey, credentialID, counter, transports } = registrationInfo;

    // Store the new authenticator device securely in the database
    const newDevice: AuthenticatorDevice = {
      credentialID,
      credentialPublicKey,
      counter,
      transports: transports || [],
    };

    user.devices.push(newDevice);
    user.currentChallenge = undefined; // Clear challenge to prevent reuse
    userDatabase.set(userId, user);
  }

  return { verified };
}

/**
 * Step 3: Generate Authentication Options
 * Invoked during login to challenge the user's registered hardware key.
 */
export async function generateWebAuthnAuthenticationOptions(userId: string) {
  'use server';

  const user = userDatabase.get(userId);
  if (!user || user.devices.length === 0) {
    throw new Error('No registered hardware keys found for this user.');
  }

  const options = await generateAuthenticationOptions({
    rpID: RP_ID,
    allowCredentials: user.devices.map(device => ({
      id: device.credentialID,
      type: 'public-key',
      transports: device.transports,
    })),
    userVerification: 'required',
  });

  // Save challenge for the verification phase
  user.currentChallenge = options.challenge;
  userDatabase.set(userId, user);

  return options;
}

/**
 * Step 4: Verify Authentication Response (Assertion)
 * Validates the cryptographic signature, checks the signature counter to detect cloning.
 */
export async function verifyWebAuthnAuthentication(
  userId: string, 
  response: AuthenticationResponseJSON
): Promise<{ verified: boolean; error?: string }> {
  'use server';

  const user = userDatabase.get(userId);
  if (!user || !user.currentChallenge) {
    return { verified: false, error: 'Authentication context lost.' };
  }

  // Find the specific device matching the credential ID provided in the response
  const dbDevice = user.devices.find(d => d.credentialID === response.id);
  if (!dbDevice) {
    return { verified: false, error: 'Unregistered hardware key presented.' };
  }

  let verification: VerifiedAuthenticationResponse;
  try {
    verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: user.currentChallenge,
      expectedOrigin: EXPECTED_ORIGIN,
      expectedRPID: RP_ID,
      authenticator: dbDevice,
      requireUserVerification: true,
    });
  } catch (error: any) {
    return { verified: false, error: error.message };
  }

  const { verified, authenticationInfo } = verification;

  if (verified && authenticationInfo) {
    // CRITICAL: Update the signature counter. If counter is <= previous counter, 
    // it signals a cloned authenticator token attack vector.
    dbDevice.counter = authenticationInfo.newCounter;
    user.currentChallenge = undefined;
    userDatabase.set(userId, user);
  }

  return { verified };
}
