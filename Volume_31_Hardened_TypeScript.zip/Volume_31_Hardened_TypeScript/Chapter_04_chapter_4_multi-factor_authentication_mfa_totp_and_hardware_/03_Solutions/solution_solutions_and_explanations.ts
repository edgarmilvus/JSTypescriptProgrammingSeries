/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface TOTPOptions {
  step?: number; // Default: 30 seconds
  digits?: number; // Default: 6 digits
  window?: number; // Default: 1 (allows +/- 1 time step drift)
}

/**
 * Decodes a base32-encoded secret string into a raw byte array.
 * @param base32Str The base32 secret string (RFC 4648)
 */
export function decodeBase32(base32Str: string): Uint8Array {
  // Normalize string: remove padding '=', spaces, and convert to uppercase
  const cleaned = base32Str.replace(/=+$/, "").replace(/\s+/g, "").toUpperCase();
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  
  let bits = 0;
  let value = 0;
  let index = 0;
  
  const output = new Uint8Array(Math.floor((cleaned.length * 5) / 8));

  for (let i = 0; i < cleaned.length; i++) {
    const char = cleaned[i];
    const charValue = alphabet.indexOf(char);
    if (charValue === -1) {
      throw new Error(`Invalid base32 character: ${char}`);
    }

    value = (value << 5) | charValue;
    bits += 5;

    if (bits >= 8) {
      bits -= 8;
      output[index++] = (value >> bits) & 0xff;
    }
  }

  return output.subarray(0, index);
}

/**
 * Generates a Time-Based One-Time Password (TOTP) string.
 * @param secret Raw byte array of the shared secret
 * @param timeMs Current epoch timestamp in milliseconds
 * @param step Time step in seconds (usually 30)
 * @param digits Number of digits in the output token (usually 6)
 */
export async function generateTOTP(
  secret: Uint8Array,
  timeMs: number = Date.now(),
  step: number = 30,
  digits: number = 6
): Promise<string> {
  // Compute counter value (T)
  const timeSeconds = Math.floor(timeMs / 1000);
  const counter = Math.floor(timeSeconds / step);

  // Pack counter into an 8-byte big-endian buffer
  const counterBuffer = new ArrayBuffer(8);
  const view = new DataView(counterBuffer);
  // Setting high-order 32 bits to 0, writing low-order 32 bits
  view.setUint32(4, counter, false);

  // Import secret key for HMAC-SHA1
  const cryptoKey = await window.crypto.subtle.importKey(
    "raw",
    secret,
    { name: "HMAC", hash: { name: "SHA-1" } },
    false,
    ["sign"]
  );

  // Compute HMAC-SHA1
  const signature = await window.crypto.subtle.sign(
    "HMAC",
    cryptoKey,
    counterBuffer
  );
  const hmacResult = new Uint8Array(signature);

  // Dynamic truncation (RFC 4226 / RFC 6238)
  const offset = hmacResult[hmacResult.length - 1] & 0x0f;
  const binaryCode =
    ((hmacResult[offset] & 0x7f) << 24) |
    ((hmacResult[offset + 1] & 0xff) << 16) |
    ((hmacResult[offset + 2] & 0xff) << 8) |
    (hmacResult[offset + 3] & 0xff);

  const otp = binaryCode % Math.pow(10, digits);
  return otp.toString().padStart(digits, "0");
}

/**
 * Verifies a submitted TOTP token against a secret with time-drift tolerance.
 * @param token The 6-digit string provided by the user
 * @param secret Raw byte array of the shared secret
 * @param options Configuration options for step, digits, and drift window
 */
export async function verifyTOTP(
  token: string,
  secret: Uint8Array,
  options: TOTPOptions = {}
): Promise<boolean> {
  const step = options.step ?? 30;
  const digits = options.digits ?? 6;
  const window = options.window ?? 1;
  const currentTimeMs = Date.now();

  // Check the current window plus drift offsets (-window to +window)
  for (let i = -window; i <= window; i++) {
    const adjustedTimeMs = currentTimeMs + i * step * 1000;
    const generatedToken = await generateTOTP(secret, adjustedTimeMs, step, digits);
    
    if (generatedToken === token) {
      return true;
    }
  }

  return false;
}
