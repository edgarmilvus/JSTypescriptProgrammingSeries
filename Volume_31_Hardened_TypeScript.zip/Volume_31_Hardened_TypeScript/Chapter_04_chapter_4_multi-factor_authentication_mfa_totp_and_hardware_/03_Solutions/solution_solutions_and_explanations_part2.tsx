/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

interface WebAuthnManagerProps {
  username: string;
  registrationChallengeUrl: string;
  registrationVerifyUrl: string;
  authChallengeUrl: string;
  authVerifyUrl: string;
  onAuthenticationSuccess: (credentialId: string) => void;
  onError: (error: string) => void;
}

export const WebAuthnManager: React.FC<WebAuthnManagerProps> = ({
  username,
  registrationChallengeUrl,
  registrationVerifyUrl,
  authChallengeUrl,
  authVerifyUrl,
  onAuthenticationSuccess,
  onError,
}) => {
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Ready');

  // Helper utility to convert base64url string to ArrayBuffer
  const base64UrlToArrayBuffer = (base64Url: string): ArrayBuffer => {
    const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
    const base64 = (base64Url + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray.buffer;
  };

  // Helper utility to convert ArrayBuffer to base64url string
  const arrayBufferToBase64Url = (buffer: ArrayBuffer): string => {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  };

  const handleRegister = async () => {
    setIsRegistering(true);
    setStatusMessage('Fetching registration challenge...');
    try {
      const res = await fetch(registrationChallengeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username }),
      });
      if (!res.ok) throw new Error('Failed to fetch registration challenge');
      const options = await res.json();

      // Convert base64url fields to ArrayBuffers required by WebAuthn
      options.challenge = base64UrlToArrayBuffer(options.challenge);
      options.user.id = base64UrlToArrayBuffer(options.user.id);
      if (options.excludeCredentials) {
        options.excludeCredentials = options.excludeCredentials.map((c: any) => ({
          ...c,
          id: base64UrlToArrayBuffer(c.id),
        }));
      }

      setStatusMessage('Touch your hardware security key...');
      const credential = (await navigator.credentials.create({
        publicKey: options,
      })) as PublicKeyCredential;

      const response = credential.response as AuthenticatorAttestationResponse;
      const credentialPayload = {
        id: credential.id,
        rawId: arrayBufferToBase64Url(credential.rawId),
        type: credential.type,
        response: {
          clientDataJSON: arrayBufferToBase64Url(response.clientDataJSON),
          attestationObject: arrayBufferToBase64Url(response.attestationObject),
        },
      };

      setStatusMessage('Verifying registration with server...');
      const verifyRes = await fetch(registrationVerifyUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentialPayload),
      });

      if (!verifyRes.ok) throw new Error('Server rejected registration');
      setStatusMessage('Registration successful!');
    } catch (err: any) {
      const msg = err.message || 'Registration failed';
      setStatusMessage(`Error: ${msg}`);
      onError(msg);
    } finally {
      setIsRegistering(false);
    }
  };

  const handleAuthenticate = async () => {
    setIsAuthenticating(true);
    setStatusMessage('Fetching authentication challenge...');
    try {
      const res = await fetch(authChallengeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username }),
      });
      if (!res.ok) throw new Error('Failed to fetch authentication challenge');
      const options = await res.json();

      options.challenge = base64UrlToArrayBuffer(options.challenge);
      if (options.allowCredentials) {
        options.allowCredentials = options.allowCredentials.map((c: any) => ({
          ...c,
          id: base64UrlToArrayBuffer(c.id),
        }));
      }

      setStatusMessage('Touch your hardware security key...');
      const assertion = (await navigator.credentials.get({
        publicKey: options,
      })) as PublicKeyCredential;

      const response = assertion.response as AuthenticatorAssertionResponse;
      const assertionPayload = {
        id: assertion.id,
        rawId: arrayBufferToBase64Url(assertion.rawId),
        type: assertion.type,
        response: {
          clientDataJSON: arrayBufferToBase64Url(response.clientDataJSON),
          authenticatorData: arrayBufferToBase64Url(response.authenticatorData),
          signature: arrayBufferToBase64Url(response.signature),
          userHandle: response.userHandle ? arrayBufferToBase64Url(response.userHandle) : null,
        },
      };

      setStatusMessage('Verifying authentication with server...');
      const verifyRes = await fetch(authVerifyUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(assertionPayload),
      });

      if (!verifyRes.ok) throw new Error('Server rejected authentication');
      setStatusMessage('Authentication successful!');
      onAuthenticationSuccess(assertion.id);
    } catch (err: any) {
      const msg = err.message || 'Authentication failed';
      setStatusMessage(`Error: ${msg}`);
      onError(msg);
    } finally {
      setIsAuthenticating(false);
    }
  };

  return (
    <div className="webauthn-container p-4 border rounded shadow-md max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Hardware Security Key Manager</h2>
      <p className="text-sm text-gray-600 mb-4">User: {username}</p>
      
      <div className="flex flex-col gap-3">
        <button
          onClick={handleRegister}
          disabled={isRegistering || isAuthenticating}
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isRegistering ? 'Registering Key...' : 'Register New YubiKey'}
        </button>

        <button
          onClick={handleAuthenticate}
          disabled={isRegistering || isAuthenticating}
          className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 disabled:opacity-50"
        >
          {isAuthenticating ? 'Authenticating...' : 'Authenticate with YubiKey'}
        </button>
      </div>

      <div className="mt-4 p-2 bg-gray-100 rounded text-xs font-mono text-gray-800">
        Status: {statusMessage}
      </div>
    </div>
  );
};
