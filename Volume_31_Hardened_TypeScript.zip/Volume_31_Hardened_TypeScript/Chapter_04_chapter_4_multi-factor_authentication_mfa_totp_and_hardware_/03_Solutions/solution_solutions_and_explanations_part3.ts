/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface RecoveryCodeBatch {
  rawCodes: string[];
  hashedHashes: string[]; // Stored securely in database
}

/**
 * Helper to convert an ArrayBuffer to a hex string for hash comparison.
 */
async function sha256Hash(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await window.crypto.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Generates a batch of cryptographically secure backup recovery codes.
 * @param count Number of codes to generate (default: 10)
 * @param length Length of each alphanumeric recovery code segment
 */
export async function generateRecoveryCodes(
  count: number = 10,
  length: number = 12
): Promise<RecoveryCodeBatch> {
  const rawCodes: string[] = [];
  const hashedHashes: string[] = [];
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // Removed ambiguous characters (0, O, 1, I)

  for (let i = 0; i < count; i++) {
    const randomValues = new Uint8Array(length);
    window.crypto.getRandomValues(randomValues);
    let code = "";
    for (let j = 0; j < length; j++) {
      code += chars[randomValues[j] % chars.length];
    }
    // Format into hyphenated blocks (e.g., XXXX-XXXX-XXXX)
    const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
    rawCodes.push(formattedCode);
    hashedHashes.push(await sha256Hash(formattedCode));
  }

  return { rawCodes, hashedHashes };
}

/**
 * Verifies a user-submitted recovery code against a stored list of hashed codes.
 * Must execute in constant time to prevent timing side-channel attacks.
 * @param inputCode The plaintext code entered by the user
 * @param storedHashes Array of stored hash strings
 */
export async function verifyAndConsumeRecoveryCode(
  inputCode: string,
  storedHashes: string[]
): Promise<{ isValid: boolean; updatedHashes: string[] }> {
  const normalizedInput = inputCode.trim().toUpperCase();
  const inputHash = await sha256Hash(normalizedInput);

  let matchIndex = -1;

  // Constant-time comparison loop to prevent timing side-channel leaks
  for (let i = 0; i < storedHashes.length; i++) {
    const stored = storedHashes[i];
    let isEqual = stored.length === inputHash.length;
    for (let j = 0; j < stored.length; j++) {
      if (stored.charCodeAt(j) !== inputHash.charCodeAt(j % inputHash.length)) {
        isEqual = false;
      }
    }
    if (isEqual) {
      matchIndex = i;
      break;
    }
  }

  if (matchIndex === -1) {
    return { isValid: false, updatedHashes: [...storedHashes] };
  }

  // Remove the consumed code to prevent replay attacks
  const updatedHashes = [...storedHashes];
  updatedHashes.splice(matchIndex, 1);

  return { isValid: true, updatedHashes };
}

export class AdminEmergencyOverride {
  private requiredApprovals: number;

  constructor(requiredApprovals: number = 2) {
    this.requiredApprovals = requiredApprovals;
  }

  /**
   * Evaluates administrator approval tokens for an account recovery request.
   * @param targetUserId The ID of the locked-out user
   * @param adminTokens Array of cryptographic admin authorization tokens
   */
  public async authorizeEmergencyReset(
    targetUserId: string,
    adminTokens: string[]
  ): Promise<boolean> {
    if (adminTokens.length < this.requiredApprovals) {
      return false;
    }

    // Verify distinct administrative authorization tokens
    const verifiedAdmins = new Set<string>();
    for (const token of adminTokens) {
      // In a production system, decode and verify JWT or cryptographic admin assertion signatures
      // Here we validate token formatting and uniqueness
      if (token && typeof token === 'string' && token.length > 20) {
        verifiedAdmins.add(token);
      }
    }

    return verifiedAdmins.size >= this.requiredApprovals;
  }
}
