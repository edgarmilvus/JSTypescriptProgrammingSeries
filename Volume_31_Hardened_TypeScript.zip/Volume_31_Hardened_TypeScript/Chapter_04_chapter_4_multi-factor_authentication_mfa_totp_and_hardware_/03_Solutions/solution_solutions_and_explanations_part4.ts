/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

export interface DependencyManifest {
  packageName: string;
  version: string;
  integrityHash: string;
  dependencies: Record<string, string>;
}

/**
 * Verifies the cryptographic signature of a software dependency manifest.
 * @param manifestJson Raw JSON string of the dependency manifest
 * @param signatureBase64 Base64url-encoded signature of the manifest
 * @param publicKey Trusted public key of the maintainer or CI/CD pipeline
 */
export async function verifyDependencyManifest(
  manifestJson: string,
  signatureBase64: string,
  publicKey: JsonWebKey
): Promise<boolean> {
  try {
    const enc = new TextEncoder();
    const data = enc.encode(manifestJson);

    // Decode base64url signature
    const padding = '='.repeat((4 - (signatureBase64.length % 4)) % 4);
    const base64 = (signatureBase64 + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawSignature = Uint8Array.from(window.atob(base64), (c) => c.charCodeAt(0));

    // Import public key
    const key = await window.crypto.subtle.importKey(
      "jwk",
      publicKey,
      { name: "ECDSA", namedCurve: publicKey.crv || "P-256" },
      false,
      ["verify"]
    );

    // Verify signature using SHA-256
    return await window.crypto.subtle.verify(
      { name: "ECDSA", hash: { name: "SHA-256" } },
      key,
      rawSignature,
      data
    );
  } catch (err) {
    // Fail closed on any malformed payload or cryptographic exception
    return false;
  }
}

/**
 * Verifies the FIDO2 attestation certificate chain of a newly registered hardware key.
 * @param attestationStmt Object containing attestation statement, fmt, and authData
 * @param clientDataJSON Base64url-encoded client data JSON string
 * @param rootCA Pem-encoded root certificate of the hardware vendor
 */
export async function verifyFIDO2Attestation(
  attestationStmt: {
    fmt: string;
    attStmt: {
      sig: ArrayBuffer;
      x5c?: ArrayBuffer[];
    };
    authData: ArrayBuffer;
  },
  clientDataJSON: string,
  rootCA: string
): Promise<boolean> {
  try {
    if (attestationStmt.fmt !== "packed" && attestationStmt.fmt !== "fido-u2f") {
      // Unsupported or unverified attestation format
      return false;
    }

    if (!attestationStmt.attStmt.x5c || attestationStmt.attStmt.x5c.length === 0) {
      // Self attestation or missing certificate chain
      return false;
    }

    // Reconstruct signed data payload (authData || SHA-256(clientDataJSON))
    const clientDataHashBuffer = await window.crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(clientDataJSON)
    );

    const authData = new Uint8Array(attestationStmt.authData);
    const clientDataHash = new Uint8Array(clientDataHashBuffer);

    const signedData = new Uint8Array(authData.length + clientDataHash.length);
    signedData.set(authData, 0);
    signedData.set(clientDataHash, authData.length);

    // Extract leaf certificate from x5c chain
    const leafCertBuffer = attestationStmt.attStmt.x5c[0];
    
    // Import leaf certificate public key for verification
    // In production environments, parse ASN.1/X.509 structure to extract Subject Public Key Info.
    const leafKey = await window.crypto.subtle.importKey(
      "spki",
      leafCertBuffer,
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"]
    );

    // Verify attestation signature
    const isValidSignature = await window.crypto.subtle.verify(
      { name: "ECDSA", hash: { name: "SHA-256" } },
      leafKey,
      attestationStmt.attStmt.sig,
      signedData
    );

    return isValidSignature;
  } catch (err) {
    // Fail closed on cryptographic parsing errors
    return false;
  }
}
