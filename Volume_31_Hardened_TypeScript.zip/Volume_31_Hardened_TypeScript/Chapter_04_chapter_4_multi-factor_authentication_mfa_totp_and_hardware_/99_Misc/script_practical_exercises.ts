/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Implement the following interfaces and functions in TypeScript using the Web Crypto API.

interface TOTPOptions {
  step?: number; // Default: 30 seconds
  digits?: number; // Default: 6 digits
  window?: number; // Default: 1 (allows +/- 1 time step drift)
}

/**
 * Decodes a base32-encoded secret string into a raw byte array.
 * @param base32Str The base32 secret string (RFC 4648)
 */
export function decodeBase32(base32Str: string): Uint8Array {
  // TODO: Implement base32 decoding logic
  throw new Error("Not implemented");
}

/**
 * Generates a Time-Based One-Time Password (TOTP) string.
 * @param secret Raw byte array of the shared secret
 * @param timeMs Current epoch timestamp in milliseconds
 * @param step Time step in seconds (usually 30)
 * @param digits Number of digits in the output token (usually 6)
 */
export async function generateTOTP(
  secret: Uint8Array,
  timeMs: number = Date.now(),
  step: number = 30,
  digits: number = 6
): Promise<string> {
  // TODO: Implement HMAC-SHA1 and dynamic truncation logic using crypto.subtle
  throw new Error("Not implemented");
}

/**
 * Verifies a submitted TOTP token against a secret with time-drift tolerance.
 * @param token The 6-digit string provided by the user
 * @param secret Raw byte array of the shared secret
 * @param options Configuration options for step, digits, and drift window
 */
export async function verifyTOTP(
  token: string,
  secret: Uint8Array,
  options: TOTPOptions = {}
): Promise<boolean> {
  // TODO: Implement verification with drift checking
  throw new Error("Not implemented");
}
