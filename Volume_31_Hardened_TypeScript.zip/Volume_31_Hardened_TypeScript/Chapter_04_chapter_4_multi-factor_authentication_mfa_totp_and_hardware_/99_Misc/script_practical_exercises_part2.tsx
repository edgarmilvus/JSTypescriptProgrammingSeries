/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';

interface WebAuthnManagerProps {
  username: string;
  onAuthenticationSuccess: (credentialId: string) => void;
  onError: (error: string) => void;
}

export const WebAuthnManager: React.FC<WebAuthnManagerProps> = ({
  username,
  onAuthenticationSuccess,
  onError,
}) => {
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Ready');

  // Helper utility to convert base64url string to ArrayBuffer
  const base64UrlToArrayBuffer = (base64Url: string): ArrayBuffer => {
    // TODO: Implement base64url to ArrayBuffer conversion
    throw new Error("Not implemented");
  };

  // Helper utility to convert ArrayBuffer to base64url string
  const arrayBufferToBase64Url = (buffer: ArrayBuffer): string => {
    // TODO: Implement ArrayBuffer to base64url conversion
    throw new Error("Not implemented");
  };

  const handleRegister = async () => {
    // TODO: Fetch registration challenge, call navigator.credentials.create(), 
    // and send response to backend.
  };

  const handleAuthenticate = async () => {
    // TODO: Fetch authentication challenge, call navigator.credentials.get(), 
    // and send response to backend.
  };

  return (
    <div className="webauthn-container p-4 border rounded shadow-md max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Hardware Security Key Manager</h2>
      <p className="text-sm text-gray-600 mb-4">User: {username}</p>
      
      <div className="flex flex-col gap-3">
        <button
          onClick={handleRegister}
          disabled={isRegistering || isAuthenticating}
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isRegistering ? 'Registering Key...' : 'Register New YubiKey'}
        </button>

        <button
          onClick={handleAuthenticate}
          disabled={isRegistering || isAuthenticating}
          className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 disabled:opacity-50"
        >
          {isAuthenticating ? 'Authenticating...' : 'Authenticate with YubiKey'}
        </button>
      </div>

      <div className="mt-4 p-2 bg-gray-100 rounded text-xs font-mono text-gray-800">
        Status: {statusMessage}
      </div>
    </div>
  );
};
