/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// middleware.ts
// Edge middleware enforcing zero-trust boundary verification on incoming requests.
// Acts as the primary security checkpoint before hitting application routes.

import { NextRequest, NextResponse } from 'next/server';
import { verifyAccessToken } from '@/lib/security/tokenService';
import { SESSION_COOKIE_NAME, REFRESH_COOKIE_NAME } from '@/lib/security/cookieConfig';

export async function middleware(request: NextRequest): Promise<NextResponse> {
  const { pathname } = request.nextUrl;

  // Public routes bypass zero-trust verification
  if (pathname.startsWith('/api/auth') || pathname === '/login') {
    return NextResponse.next();
  }

  const accessTokenCookie = request.cookies.get(SESSION_COOKIE_NAME)?.value;

  if (!accessTokenCookie) {
    // Attempt automatic token refresh if access token is missing but refresh cookie exists
    const refreshTokenCookie = request.cookies.get(REFRESH_COOKIE_NAME)?.value;
    if (refreshTokenCookie) {
      // Internal redirect or invocation of refresh micro-flow
      return NextResponse.redirect(new URL('/api/auth/refresh', request.url));
    }
    return NextResponse.redirect(new URL('/login', request.url));
  }

  const validation = await verifyAccessToken(accessTokenCookie);

  if (!validation.isValid) {
    // Token expired or cryptographically invalid
    const response = NextResponse.redirect(new URL('/login', request.url));
    response.cookies.delete(SESSION_COOKIE_NAME);
    return response;
  }

  // Inject verified claims into request headers for downstream Server Components
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-user-id', validation.payload!.sub);
  requestHeaders.set('x-user-roles', JSON.stringify(validation.payload!.roles));

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

export const config = {
  matcher: ['/dashboard/:path*', '/api/protected/:path*'],
};
