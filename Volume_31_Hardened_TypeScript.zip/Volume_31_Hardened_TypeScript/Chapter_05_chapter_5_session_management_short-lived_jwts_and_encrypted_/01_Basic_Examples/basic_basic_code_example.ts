/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';
import * as http from 'http';

/**
 * Configuration Constants for Enterprise-Grade Security
 * In a real-world SaaS, these values must be sourced securely from environment variables.
 */
const JWT_SECRET = randomBytes(64).toString('hex'); // Secret used to sign the JWT payload
const COOKIE_ENCRYPTION_KEY = randomBytes(32);      // AES-256 key requirement: exactly 32 bytes
const COOKIE_NAME = '__Host-session';               // __Host- prefix enforces security rules in modern browsers

/**
 * Interface representing the authenticated user payload stored within the JWT.
 */
interface UserSessionPayload {
    userId: string;
    email: string;
    role: 'ADMIN' | 'MEMBER';
    iat?: number;
    exp?: number;
}

/**
 * Base64URL encoding helper functions for manual JWT handling without heavy external dependencies.
 */
function base64UrlEncode(str: string): string {
    return Buffer.from(str)
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
}

function base64UrlDecode(str: string): string {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) {
        str += '=';
    }
    return Buffer.from(str, 'base64').toString('utf8');
}

/**
 * Signs a short-lived JWT with an expiration window (e.g., 15 minutes).
 * 
 * @param payload - The user session data to embed.
 * @returns A compact JWT string: header.payload.signature
 */
function createShortLivedJwt(payload: UserSessionPayload): string {
    const header = { alg: 'HS256', typ: 'JWT' };
    const now = Math.floor(Date.now() / 1000);
    
    // Short-lived design: Expires in 900 seconds (15 minutes)
    const fullPayload: UserSessionPayload = {
        ...payload,
        iat: now,
        exp: now + 900 
    };

    const encodedHeader = base64UrlEncode(JSON.stringify(header));
    const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
    
    const signatureInput = `${encodedHeader}.${encodedPayload}`;
    const crypto = require('crypto');
    const signature = crypto
        .createHmac('sha256', JWT_SECRET)
        .update(signatureInput)
        .digest('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');

    return `${encodedHeader}.${encodedPayload}.${signature}`;
}

/**
 * Verifies a JWT's signature and ensures it has not expired.
 * 
 * @param token - The raw JWT string.
 * @returns The decoded session payload if valid, otherwise null.
 */
function verifyJwt(token: string): UserSessionPayload | null {
    try {
        const parts = token.split('.');
        if (parts.length !== 3) return null;

        const [encodedHeader, encodedPayload, signature] = parts;
        const signatureInput = `${encodedHeader}.${encodedPayload}`;

        const crypto = require('crypto');
        const expectedSignature = crypto
            .createHmac('sha256', JWT_SECRET)
            .update(signatureInput)
            .digest('base64')
            .replace(/=/g, '')
            .replace(/\+/g, '-')
            .replace(/\//g, '_');

        if (signature !== expectedSignature) {
            return null; // Signature mismatch (tampering detected)
        }

        const payload: UserSessionPayload = JSON.parse(base64UrlDecode(encodedPayload));
        
        // Check expiration
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp && payload.exp < now) {
            return null; // Token expired
        }

        return payload;
    } catch (err) {
        return null;
    }
}

/**
 * Encrypts cleartext data using AES-256-GCM to prevent client-side inspection of JWT claims.
 * 
 * @param text - The plaintext string (e.g., the JWT).
 * @returns An encrypted string containing the IV, auth tag, and ciphertext.
 */
function encryptCookieValue(text: string): string {
    const iv = randomBytes(12); // Initialization vector for GCM mode
    const cipher = createCipheriv('aes-256-gcm', COOKIE_ENCRYPTION_KEY, iv);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag().toString('hex');
    
    // Format: iv:authTag:encryptedText
    return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Decrypts an AES-256-GCM encrypted cookie value.
 * 
 * @param encryptedData - The colon-delimited encrypted payload.
 * @returns The original plaintext string, or throws/returns null on failure.
 */
function decryptCookieValue(encryptedData: string): string | null {
    try {
        const parts = encryptedData.split(':');
        if (parts.length !== 3) return null;

        const iv = Buffer.from(parts[0], 'hex');
        const authTag = Buffer.from(parts[1], 'hex');
        const encryptedText = parts[2];

        const decipher = createDecipheriv('aes-256-gcm', COOKIE_ENCRYPTION_KEY, iv);
        decipher.setAuthTag(authTag);

        let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
        decrypted += decipher.final('utf8');

        return decrypted;
    } catch (err) {
        return null; // Decryption failure (tampered data or wrong key)
    }
}

/**
 * Simple HTTP Server simulating a secure SaaS authentication gateway.
 */
const server = http.createServer((req, res) => {
    const url = new URL(req.url || '', `http://${req.headers.host}`);

    // Route 1: Login - Issues a short-lived JWT inside an encrypted HTTP-Only cookie
    if (url.pathname === '/api/login' && req.method === 'POST') {
        const mockUser: UserSessionPayload = {
            userId: 'usr_9981273',
            email: 'engineer@saas-platform.internal',
            role: 'ADMIN'
        };

        // 1. Generate the short-lived JWT
        const jwt = createShortLivedJwt(mockUser);

        // 2. Encrypt the JWT to conceal claims from client-side JavaScript and extensions
        const encryptedJwt = encryptCookieValue(jwt);

        // 3. Construct secure Set-Cookie headers
        // Using __Host- prefix requires: Secure, path=/, and NO domain attribute.
        const cookieOptions = [
            `${COOKIE_NAME}=${encryptedJwt}`,
            'HttpOnly',                  // Blocks XSS execution vectors from reading document.cookie
            'Secure',                    // Enforces HTTPS transmission exclusively
            'SameSite=Strict',           // Mitigates Cross-Site Request Forgery (CSRF)
            'Path=/',                    // Restricts scope to entire origin
            'Max-Age=900'                // Matches token lifetime (15 minutes)
        ].join('; ');

        res.setHeader('Set-Cookie', cookieOptions);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'success', message: 'Authenticated successfully. Session issued.' }));
        return;
    }

    // Route 2: Protected Dashboard - Reads, decrypts, and validates the session cookie
    if (url.pathname === '/api/dashboard' && req.method === 'GET') {
        const cookieHeader = req.headers.cookie;
        if (!cookieHeader) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Unauthorized: No session cookie provided.' }));
            return;
        }

        // Parse cookies from header string
        const cookies = Object.fromEntries(
            cookieHeader.split('; ').map(c => {
                const [key, ...v] = c.split('=');
                return [key, v.join('=')];
            })
        );

        const encryptedSession = cookies[COOKIE_NAME];
        if (!encryptedSession) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Unauthorized: Session cookie missing.' }));
            return;
        }

        // 1. Decrypt the cookie payload
        const decryptedJwt = decryptCookieValue(encryptedSession);
        if (!decryptedJwt) {
            res.writeHead(403, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Forbidden: Invalid session signature or decryption failure.' }));
            return;
        }

        // 2. Verify the inner JWT (signature & expiration check)
        const sessionPayload = verifyJwt(decryptedJwt);
        if (!sessionPayload) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Unauthorized: Session expired or invalid.' }));
            return;
        }

        // Authorized access granted
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: 'success',
            message: `Welcome back, ${sessionPayload.email}`,
            sessionData: sessionPayload
        }));
        return;
    }

    // Default Fallback
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found' }));
});

// Start listening on port 3000
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`[Zero-Trust Gateway] Secure session server running on http://localhost:${PORT}`);
});
