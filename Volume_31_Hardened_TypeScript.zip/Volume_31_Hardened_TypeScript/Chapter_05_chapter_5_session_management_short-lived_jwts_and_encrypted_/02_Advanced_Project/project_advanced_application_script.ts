/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { NextRequest, NextResponse } from 'next/server';
import { SignJWT, jwtVerify, type JWTPayload } from 'jose';
import { cookies } from 'next/headers';
import { createHash, randomBytes } from 'crypto';

/**
 * @fileoverview Secure Session Management and Token Rotation Engine.
 * Implements encrypted HTTP-Only cookies, short-lived JWT validation, and 
 * sliding session windows within a Next.js App Router paradigm.
 */

// Environment configuration and cryptographic key derivation
const JWT_SECRET_KEY = new TextEncoder().encode(
  process.env.JWT_SECRET_KEY || 'fallback_secret_key_change_in_production_32bytes!'
);

const COOKIE_NAME = '__Host-auth.session';
const REFRESH_COOKIE_NAME = '__Host-auth.refresh';

export interface UserSession extends JWTPayload {
  sub: string;
  email: string;
  role: 'admin' | 'user' | 'enterprise';
  tokenVersion: number;
}

/**
 * Cryptographic utility to generate a secure opaque token for refresh tracking.
 * Ensures resistance against brute-force and rainbow table attacks.
 */
export function generateSecureOpaqueToken(): { rawToken: string; hashedToken: string } {
  const rawToken = randomBytes(48).toString('hex');
  const hashedToken = createHash('sha256').update(rawToken).digest('hex');
  return { rawToken, hashedToken };
}

/**
 * Encrypts user claims into a short-lived stateless JWT.
 * 
 * @param payload - The core user identity claims.
 * @param expiresIn - Expiration window (e.g., '15m' for 15 minutes).
 * @returns A compact URL-safe JWT string.
 */
export async function createAccessToken(payload: UserSession, expiresIn: string = '15m'): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
    .setIssuedAt()
    .setSubject(payload.sub)
    .setExpirationTime(expiresIn)
    .sign(JWT_SECRET_KEY);
}

/**
 * Verifies and decodes an incoming JWT access token.
 * 
 * @param token - The raw JWT string extracted from the HTTP-Only cookie.
 * @returns The verified payload or null if verification fails.
 */
export async function verifyAccessToken(token: string): Promise<UserSession | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET_KEY, {
      algorithms: ['HS256'],
    });
    return payload as UserSession;
  } catch (error) {
    // Log verification failure safely without leaking stack traces in production
    console.warn('[Security] Access token verification failed:', (error as Error).message);
    return null;
  }
}

/**
 * Sets an encrypted, highly secure HTTP-Only cookie on the outgoing response.
 * Utilizes '__Host-' prefix requirements to enforce HTTPS, path restriction, and domain locking.
 * 
 * @param res - The Next.js NextResponse object.
 * @param name - The name of the cookie.
 * @param value - The token or payload value to store.
 * @param maxAge - Lifetime of the cookie in seconds.
 */
export function setSecureCookie(
  res: NextResponse,
  name: string,
  value: string,
  maxAge: number
): void {
  res.cookies.set({
    name,
    value,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/',
    maxAge,
    // Enforce modern cookie security flags
    // Note: '__Host-' prefix requires secure: true, path: '/', and NO domain specification
  });
}

/**
 * Core Middleware Handler executing zero-trust session validation and sliding window updates.
 * Designed to intercept requests, inspect HTTP-Only cookies, validate short-lived JWTs,
 * and seamlessly orchestrate token rotation when approaching expiration.
 */
export async function handleSecureSessionMiddleware(req: NextRequest): Promise<NextResponse> {
  const cookieStore = cookies();
  const accessTokenCookie = cookieStore.get(COOKIE_NAME);
  const refreshTokenCookie = cookieStore.get(REFRESH_COOKIE_NAME);

  const pathname = req.nextUrl.pathname;

  // 1. Bypass authentication checks for public assets and login routes
  if (pathname.startsWith('/api/auth') || pathname === '/login' || pathname.startsWith('/_next')) {
    return NextResponse.next();
  }

  // 2. If no access token exists, redirect to login or return 401 for API routes
  if (!accessTokenCookie) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Unauthorized: Missing session token.' }, { status: 401 });
    }
    const loginUrl = new URL('/login', req.url);
    loginUrl.searchParams.set('from', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // 3. Verify the cryptographic integrity of the short-lived JWT
  const session = await verifyAccessToken(accessTokenCookie.value);

  if (!session) {
    // Access token is invalid or expired. Check for refresh token state.
    if (!refreshTokenCookie) {
      const response = NextResponse.redirect(new URL('/login', req.url));
      response.cookies.delete(COOKIE_NAME);
      return response;
    }

    // Attempt automated refresh token rotation (Delegated to specialized DB service)
    try {
      const refreshedSession = await rotateSessionTokens(refreshTokenCookie.value);
      if (!refreshedSession) {
        throw new Error('Refresh token rotation rejected.');
      }

      const res = NextResponse.next();
      setSecureCookie(res, COOKIE_NAME, refreshedSession.newAccessToken, 15 * 60); // 15 mins
      setSecureCookie(res, REFRESH_COOKIE_NAME, refreshedSession.newRefreshToken, 7 * 24 * 60 * 60); // 7 days
      return res;
    } catch (rotationError) {
      console.error('[Security Critical] Token rotation failed:', rotationError);
      const res = NextResponse.redirect(new URL('/login', req.url));
      res.cookies.delete(COOKIE_NAME);
      res.cookies.delete(REFRESH_COOKIE_NAME);
      return res;
    }
  }

  // 4. Sliding Session Window: Issue fresh access token if expiration is within 5 minutes
  const currentTime = Math.floor(Date.now() / 1000);
  const tokenExp = session.exp || 0;
  const timeRemaining = tokenExp - currentTime;

  const response = NextResponse.next();

  if (timeRemaining < 300) { // Less than 5 minutes remaining
    const renewedAccessToken = await createAccessToken({
      sub: session.sub,
      email: session.email,
      role: session.role,
      tokenVersion: session.tokenVersion,
    }, '15m');

    setSecureCookie(response, COOKIE_NAME, renewedAccessToken, 15 * 60);
  }

  // Inject verified claims into request headers for downstream server components / API routes
  response.headers.set('x-user-id', session.sub);
  response.headers.set('x-user-role', session.role);

  return response;
}

/**
 * Stub representing a secure database interaction layer for token rotation.
 * In production, this verifies the hashed refresh token against a persistent store,
 * checks token revocation lists, and implements reuse detection.
 */
async function rotateSessionTokens(rawRefreshToken: string): Promise<{ newAccessToken: string; newRefreshToken: string } | null> {
  // Hash the incoming token to match database storage format
  const hashedInputToken = createHash('sha256').update(rawRefreshToken).digest('hex');

  // TODO: Query PostgreSQL / Redis cluster
  // const storedTokenRecord = await db.refreshToken.findUnique({ where: { tokenHash: hashedInputToken } });
  // if (!storedTokenRecord || storedTokenRecord.revoked || storedTokenRecord.expiresAt < new Date()) {
  //   // Potential token theft detected! Revoke all sessions for this user family.
  //   await db.refreshToken.updateMany({ where: { userId: storedTokenRecord.userId }, data: { revoked: true } });
  //   return null;
  // }

  // Generate brand new token pair (Token Rotation)
  const mockUser: UserSession = {
    sub: 'usr_enterprise_99182',
    email: 'security-admin@enterprise.io',
    role: 'enterprise',
    tokenVersion: 1,
  };

  const newAccessToken = await createAccessToken(mockUser, '15m');
  const { rawToken: newRefreshToken } = generateSecureOpaqueToken();

  return { newAccessToken, newRefreshToken };
}
