/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import jwt from 'jsonwebtoken';
import crypto from 'crypto';

interface RefreshTokenRecord {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: Date;
  isRevoked: boolean;
  replacedByTokenId?: string;
}

export class TokenRotationService {
  private secretAccess: string;
  private db: Map<string, RefreshTokenRecord>; // Mock database store for exercise

  constructor(secretAccess: string) {
    this.secretAccess = secretAccess;
    this.db = new Map();
  }

  /**
   * Generates a short-lived JWT access token.
   */
  public generateAccessToken(userId: string, role: string): string {
    return jwt.sign({ sub: userId, role }, this.secretAccess, { expiresIn: '15m' });
  }

  /**
   * Generates a cryptographically secure opaque refresh token.
   */
  public generateRefreshToken(): { rawToken: string; tokenHash: string } {
    const rawToken = crypto.randomBytes(40).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    return { rawToken, tokenHash };
  }

  /**
   * Rotates a refresh token. Validates existence, expiration, and checks for reuse attacks.
   * Throws an error and revokes all user tokens if a reused token is detected.
   */
  public async rotateToken(incomingRawToken: string): Promise<{ accessToken: string; newRefreshToken: string }> {
    const incomingHash = crypto.createHash('sha256').update(incomingRawToken).digest('hex');
    
    // 1. Find the token record in `this.db` using `incomingHash`.
    const record = this.db.get(incomingHash);
    if (!record) {
      throw new Error('Invalid refresh token.');
    }

    // 3. REUSE DETECTION: If `record.isRevoked` is true, this is a token theft replay attack!
    if (record.isRevoked) {
      // Mark ALL active refresh tokens for `record.userId` as revoked
      for (const [key, val] of this.db.entries()) {
        if (val.userId === record.userId) {
          val.isRevoked = true;
        }
      }
      throw new Error('CRITICAL SECURITY ALERT: Refresh token reuse detected. Revoking all user sessions.');
    }

    // 4. If `record.expiresAt` is in the past, throw an expired token error.
    if (record.expiresAt < new Date()) {
      throw new Error('Refresh token has expired.');
    }

    // 5. Mark the current record as revoked (`isRevoked = true`).
    record.isRevoked = true;

    // 6. Generate a brand new refresh token and access token pair
    const newTokenPair = this.generateRefreshToken();
    const newTokenId = crypto.randomUUID();
    
    const newRecord: RefreshTokenRecord = {
      id: newTokenId,
      userId: record.userId,
      tokenHash: newTokenPair.tokenHash,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      isRevoked: false,
    };

    record.replacedByTokenId = newTokenId;
    this.db.set(newTokenPair.tokenHash, newRecord);

    // 7. Mint a fresh short-lived JWT access token
    const accessToken = this.generateAccessToken(record.userId, 'user');

    return {
      accessToken,
      newRefreshToken: newTokenPair.rawToken,
    };
  }
}
