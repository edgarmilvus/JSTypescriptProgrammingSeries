/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

// Extend Express Request to include CSRF helper status if needed
export interface CsrfRequest extends Request {
  csrfToken?: string;
}

/**
 * Middleware to generate and attach a CSRF token cookie on GET requests.
 */
export function attachCsrfToken(req: CsrfRequest, res: Response, next: NextFunction): void {
  let token = req.cookies['XSRF-TOKEN'];
  if (!token) {
    token = crypto.randomBytes(32).toString('hex');
    // Set a non-httpOnly cookie so JavaScript can read it and attach it to headers
    res.cookie('XSRF-TOKEN', token, {
      httpOnly: false,
      secure: true,
      sameSite: 'strict',
      path: '/'
    });
  }
  req.csrfToken = token;
  next();
}

/**
 * Middleware to validate the Double-Submit Cookie pattern on state-changing requests.
 */
export function validateCsrfProtection(req: Request, res: Response, next: NextFunction): void {
  const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
  if (safeMethods.includes(req.method)) {
    return next();
  }

  // TODO: Implement CSRF validation logic:
  // 1. Extract the token from the cookie: req.cookies['XSRF-TOKEN']
  // 2. Extract the token from the request header: req.headers['x-xsrf-token'] or req.headers['csrf-token']
  // 3. Verify both tokens exist and use timing-safe comparison (crypto.timingSafeEqual) to prevent timing attacks.
  // 4. Additionally, inspect req.headers['sec-fetch-site'] to ensure it is either 'same-origin' or 'same-site'.
  // 5. If validation fails, respond with HTTP 403 Forbidden. Otherwise, call next().

  throw new Error('Not implemented');
}
