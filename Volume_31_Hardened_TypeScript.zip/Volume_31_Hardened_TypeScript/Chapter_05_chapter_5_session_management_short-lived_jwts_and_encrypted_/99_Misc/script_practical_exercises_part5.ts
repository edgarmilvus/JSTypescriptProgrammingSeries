/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

interface AuthenticatedRequest extends Request {
  user?: {
    sub: string;
    role: string;
    tokenVersion: number;
  };
}

interface UserAccountStore {
  getTokenVersion(userId: string): Promise<number>;
  incrementTokenVersion(userId: string): Promise<number>;
}

export class SessionRevocationMiddleware {
  private userStore: UserAccountStore;
  private jwtSecret: string;

  constructor(userStore: UserAccountStore, jwtSecret: string) {
    this.userStore = userStore;
    this.jwtSecret = jwtSecret;
  }

  /**
   * Express middleware to verify JWT signature, expiration, AND live token version.
   */
  public verifyAndCheckRevocation = async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        res.status(401).json({ error: 'Missing or malformed authorization token' });
        return;
      }

      const token = authHeader.split(' ')[1];
      
      // TODO: Implement verification and revocation check:
      // 1. Verify the JWT signature and expiration using jwt.verify(token, this.jwtSecret).
      // 2. Extract the payload containing `sub` (userId) and `tokenVersion`.
      // 3. Fetch the latest live `tokenVersion` for this user from `this.userStore.getTokenVersion(payload.sub)`.
      // 4. Compare the token's `tokenVersion` with the database version. 
      //    If payload.tokenVersion < currentDbVersion, the session has been revoked! Return HTTP 401.
      // 5. Attach user payload to `req.user` and call `next()`.

      throw new Error('Not implemented');
    } catch (err) {
      res.status(401).json({ error: 'Invalid or expired session' });
    }
  };
}
