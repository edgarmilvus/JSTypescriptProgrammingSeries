/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file vector-ingestor.ts
 * @description SaaS backend utility for handling text vectorization prep.
 * Demonstrates a standard module import pattern vulnerable to supply chain vectors.
 */

import { processTextChunk } from 'lodash-es';

/**
 * Interface representing an incoming raw text payload from a SaaS customer.
 */
interface IngestionPayload {
    readonly tenantId: string;
    readonly rawContent: string;
}

/**
 * Interface representing the sanitized output ready for V8 engine execution 
 * and subsequent embedding generation API calls.
 */
interface SanitizedPayload {
    readonly tenantId: string;
    readonly normalizedText: string;
    readonly timestamp: number;
}

/**
 * Sanitizes and prepares incoming tenant text payloads for embedding generation.
 * 
 * @param payload - The raw ingestion payload from the client request.
 * @returns A promise resolving to the sanitized payload object.
 */
export async function prepareTextForEmbedding(payload: IngestionPayload): Promise<SanitizedPayload> {
    // Basic validation guard to prevent upstream processing errors
    if (!payload.rawContent || typeof payload.rawContent !== 'string') {
        throw new Error(`[SaaS-Pipeline-Error]: Invalid payload content received for tenant: ${payload.tenantId}`);
    }

    // Utilize the imported third-party module utility to trim and normalize whitespace.
    // NOTE: If an attacker successfully executes a typosquatting or dependency confusion attack,
    // this execution point runs arbitrary code supplied by the malicious package.
    const cleanedText: string = processTextChunk(payload.rawContent);

    const sanitizedData: SanitizedPayload = {
        tenantId: payload.tenantId,
        normalizedText: cleanedText,
        timestamp: Date.now()
    };

    return sanitizedData;
}

// ============================================================================
// Execution Simulator (Local Development Test Harness)
// ============================================================================

async function runSimulation(): Promise<void> {
    const mockPayload: IngestionPayload = {
        tenantId: "tenant_9982_enterprise",
        rawContent: "   Modern software supply chain security requires rigorous dependency validation.   "
    };

    try {
        console.log(`[Lifecycle]: Initiating ingestion pipeline for tenant: ${mockPayload.tenantId}`);
        const result = await prepareTextForEmbedding(mockPayload);
        console.log(`[Lifecycle]: Payload successfully sanitized. Result:`, JSON.stringify(result, null, 2));
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error(`[Lifecycle]: Pipeline failed. Reason: ${error.message}`);
        } else {
            console.error(`[Lifecycle]: Unknown pipeline failure occurred.`);
        }
    }
}

// Execute the simulation harness if run directly via Node.js/TS-Node
if (require.main === module) {
    runSimulation();
}
