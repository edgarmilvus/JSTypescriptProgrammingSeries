/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Pinecone } from '@pinecone-database/pinecone';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Interface representing a package entry parsed from a package.json file.
 */
interface DependencyManifest {
  name: string;
  version: string;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
}

/**
 * Interface representing the result of a supply chain security audit.
 */
interface AuditResult {
  packageName: string;
  declaredVersion: string;
  threatType: 'TYPOSQUATTING' | 'DEPENDENCY_CONFUSION' | 'SECURE';
  confidenceScore: number;
  matchedSignatureId: string;
}

/**
 * Configuration options for the Supply Chain Validation Engine.
 */
interface EngineConfig {
  pineconeApiKey: string;
  pineconeIndexName: string;
  privateScopePrefix: string;
  similarityThreshold: number;
}

/**
 * @class SupplyChainSecurityEngine
 * @description Serves as the Entry Point Node for pipeline validation, connecting to Pinecone
 * to detect typosquatting and dependency confusion anomalies asynchronously.
 */
class SupplyChainSecurityEngine {
  private pinecone: Pinecone;
  private indexName: string;
  private privateScopePrefix: string;
  private similarityThreshold: number;

  /**
   * Initializes the security engine and validates environment configurations.
   * @param {EngineConfig} config - The configuration parameters for the engine.
   */
  constructor(config: EngineConfig) {
    if (!config.pineconeApiKey) {
      throw new Error('Critical: Pinecone API key is missing for the security validation engine.');
    }

    // Initialize the official Pinecone Client (Node.js)
    this.pinecone = new Pinecone({
      apiKey: config.pineconeApiKey,
    });
    this.indexName = config.pineconeIndexName;
    this.privateScopePrefix = config.privateScopePrefix;
    this.similarityThreshold = config.similarityThreshold;
  }

  /**
   * Asynchronously parses the local package.json manifest.
   * Utilizes the Node.js event loop for non-blocking disk I/O operations.
   * @param {string} manifestPath - Absolute path to the package.json file.
   * @returns {Promise<DependencyManifest>} Parsed dependency manifest object.
   */
  public async loadManifest(manifestPath: string): Promise<DependencyManifest> {
    try {
      const absolutePath = path.resolve(manifestPath);
      const rawData = await fs.promises.readFile(absolutePath, 'utf-8');
      const manifest: DependencyManifest = JSON.parse(rawData);
      return manifest;
    } catch (error: unknown) {
      const errMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to read or parse dependency manifest: ${errMessage}`);
    }
  }

  /**
   * Simulates generating a numerical embedding for a package name to detect typosquatting.
   * In a complete architecture, this calls an embedding microservice.
   * @param {string} name - The package name to vectorize.
   * @returns {number[] } A mock 8-dimensional embedding vector.
   */
  private vectorizePackageName(name: string): number[] {
    const vector = new Array(8).fill(0);
    for (let i = 0; i < name.length; i++) {
      const charCode = name.charCodeAt(i);
      vector[i % 8] += charCode / 1000;
    }
    return vector;
  }

  /**
   * Queries the Pinecone vector database to find semantic matches against known malicious packages.
   * @param {string} packageName - The name of the package being evaluated.
   * @returns {Promise<AuditResult>} The evaluated audit result for the package.
   */
  public async evaluatePackage(packageName: string, declaredVersion: string): Promise<AuditResult> {
    // Check for Dependency Confusion: Internal packages must use the strict private scope prefix
    if (!packageName.startsWith(this.privateScopePrefix) && this.isInternalNomenclature(packageName)) {
      return {
        packageName,
        declaredVersion,
        threatType: 'DEPENDENCY_CONFUSION',
        confidenceScore: 0.99,
        matchedSignatureId: 'heuristic-internal-namespace-leak',
      };
    }

    try {
      const index = this.pinecone.index(this.indexName);
      const queryVector = this.vectorizePackageName(packageName);

      // Execute high-performance similarity search query against Pinecone
      const queryResponse = await index.query({
        vector: queryVector,
        topK: 1,
        includeMetadata: true,
      });

      if (queryResponse.matches && queryResponse.matches.length > 0) {
        const topMatch = queryResponse.matches[0];
        const score = topMatch.score ?? 0;

        if (score >= this.similarityThreshold) {
          return {
            packageName,
            declaredVersion,
            threatType: 'TYPOSQUATTING',
            confidenceScore: score,
            matchedSignatureId: topMatch.id,
          };
        }
      }

      return {
        packageName,
        declaredVersion,
        threatType: 'SECURE',
        confidenceScore: 0.0,
        matchedSignatureId: '',
      };
    } catch (error: unknown) {
      console.error(`Warning: Pinecone lookup failed for package ${packageName}:`, error);
      // Fail open or closed depending on pipeline strictness; here we default to safe flag on error
      return {
        packageName,
        declaredVersion,
        threatType: 'SECURE',
        confidenceScore: 0.0,
        matchedSignatureId: 'error-fallback',
      };
    }
  }

  /**
   * Heuristic helper to determine if an unsecured package name mimics an internal pattern.
   * @param {string} name - Package name.
   * @returns {boolean} True if naming convention suggests internal enterprise scope.
   */
  private isInternalNomenclature(name: string): boolean {
    const internalKeywords = ['internal', 'corp', 'private', 'auth-service', 'design-system'];
    return internalKeywords.some((keyword) => name.includes(keyword));
  }

  /**
   * Executes a complete security audit across all dependencies and devDependencies.
   * Leverages Promise.all to process checks concurrently via the Node.js Event Loop.
   * @param {DependencyManifest} manifest - The parsed package manifest.
   * @returns {Promise<AuditResult[]>} Array of audit results for all packages.
   */
  public async auditManifest(manifest: DependencyManifest): Promise<AuditResult[]> {
    const allDependencies = {
      ...manifest.dependencies,
      ...manifest.devDependencies,
    };

    const auditPromises = Object.entries(allDependencies).map(async ([name, version]) => {
      return this.evaluatePackage(name, version);
    });

    // Event Loop processes these concurrent non-blocking validations efficiently
    const results = await Promise.all(auditPromises);
    return results;
  }
}

/**
 * Entry Point Node Execution Function
 * Orchestrates the workflow for Next.js build pipelines.
 */
async function runSupplyChainPipeline() {
  const engine = new SupplyChainSecurityEngine({
    pineconeApiKey: process.env.PINECONE_API_KEY || 'mock-api-key',
    pineconeIndexName: 'supply-chain-signatures',
    privateScopePrefix: '@my-enterprise/',
    similarityThreshold: 0.85,
  });

  const manifestPath = './package.json';
  console.log(`[Entry Point Node] Loading dependency manifest from ${manifestPath}...`);

  try {
    const manifest = await engine.loadManifest(manifestPath);
    console.log(`[Entry Point Node] Manifest loaded successfully. Auditing packages...`);

    const results = await engine.auditManifest(manifest);
    let securityViolationsFound = false;

    results.forEach((result) => {
      if (result.threatType !== 'SECURE') {
        securityViolationsFound = true;
        console.error(
          `[SECURITY ALERT] Threat Detected: ${result.threatType} in package "${result.packageName}@${result.declaredVersion}". Confidence: ${result.confidenceScore.toFixed(2)} (Signature: ${result.matchedSignatureId})`
        );
      } else {
        console.log(`[PASSED] Package "${result.packageName}" verified secure.`);
      }
    });

    if (securityViolationsFound) {
      console.error('[Pipeline Failed] Supply chain vulnerabilities detected. Aborting build.');
      process.exit(1);
    } else {
      console.log('[Pipeline Success] All dependencies verified against typosquatting and confusion vectors.');
      process.exit(0);
    }
  } catch (error) {
    console.error('[Pipeline Error] Execution failed:', error);
    process.exit(1);
  }
}

// Invoke the entry point if executed directly
if (require.main === module) {
  runSupplyChainPipeline();
}

export { SupplyChainSecurityEngine, AuditResult, DependencyManifest };
