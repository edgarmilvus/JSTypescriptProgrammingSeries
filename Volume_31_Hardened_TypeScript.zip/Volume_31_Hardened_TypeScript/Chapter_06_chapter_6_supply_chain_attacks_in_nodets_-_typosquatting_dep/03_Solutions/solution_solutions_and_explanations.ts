/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs/promises';

export interface AuditConfig {
  knownCriticalPackages: string[];
  maxAllowedDistance: number;
}

export interface TyposquatWarning {
  declaredPackage: string;
  suspectedTarget: string;
  levenshteinDistance: number;
}

export interface AuditResult {
  isSecure: boolean;
  warnings: TyposquatWarning[];
}

/**
 * Calculates the Levenshtein distance between two strings.
 */
function getLevenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          Math.min(
            matrix[i][j - 1] + 1,     // insertion
            matrix[i - 1][j] + 1      // deletion
          )
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

export async function auditPackageManifest(
  packageJsonPath: string,
  config: AuditConfig
): Promise<AuditResult> {
  const fileContent = await fs.readFile(packageJsonPath, 'utf-8');
  const manifest = JSON.parse(fileContent);

  const dependencies = {
    ...manifest.dependencies,
    ...manifest.devDependencies,
    ...manifest.peerDependencies,
  };

  const warnings: TyposquatWarning[] = [];

  for (const declaredPkg of Object.keys(dependencies)) {
    for (const criticalPkg of config.knownCriticalPackages) {
      if (declaredPkg === criticalPkg) {
        continue; // Exact match is secure
      }

      const distance = getLevenshteinDistance(declaredPkg, criticalPkg);

      if (distance > 0 && distance <= config.maxAllowedDistance) {
        warnings.push({
          declaredPackage: declaredPkg,
          suspectedTarget: criticalPkg,
          levenshteinDistance: distance,
        });
      }
    }
  }

  return {
    isSecure: warnings.length === 0,
    warnings,
  };
}
