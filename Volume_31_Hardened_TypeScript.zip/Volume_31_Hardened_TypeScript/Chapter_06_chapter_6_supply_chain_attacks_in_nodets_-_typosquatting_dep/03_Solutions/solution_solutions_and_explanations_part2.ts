/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs/promises';

export interface ScopeValidationRule {
  expectedScopePrefix: string;
  requiredRegistrySubstring: string;
}

export class DependencyConfusionVulnerabilityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DependencyConfusionVulnerabilityError';
  }
}

export interface NpmRcValidationResult {
  isValid: boolean;
  configuredScopes: Array<{ scope: string; registry: string }>;
  violations: string[];
}

export async function verifyRegistryScopes(
  npmrcPath: string,
  rules: ScopeValidationRule[]
): Promise<NpmRcValidationResult> {
  let fileContent: string;
  try {
    fileContent = await fs.readFile(npmrcPath, 'utf-8');
  } catch (error) {
    throw new DependencyConfusionVulnerabilityError(`Failed to read .npmrc at path: ${npmrcPath}`);
  }

  const lines = fileContent.split(/\r?\n/);
  const configuredScopes: Array<{ scope: string; registry: string }> = [];
  const violations: string[] = [];

  // Parse lines matching format: @scope:registry=https://registry.internal.net/
  const scopeRegistryRegex = /^(@[a-z0-9-~][a-z0-9-._~]*):registry\s*=\s*(.+)$/i;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    const match = trimmed.match(scopeRegistryRegex);
    if (match) {
      configuredScopes.push({
        scope: match[1],
        registry: match[2],
      });
    }
  }

  for (const rule of rules) {
    const found = configuredScopes.find((cs) => cs.scope === rule.expectedScopePrefix);

    if (!found) {
      violations.push(`Missing mandatory scope configuration for: ${rule.expectedScopePrefix}`);
    } else if (!found.registry.includes(rule.requiredRegistrySubstring)) {
      violations.push(
        `Scope ${rule.expectedScopePrefix} points to insecure registry: ${found.registry} (Expected substring: ${rule.requiredRegistrySubstring})`
      );
    }
  }

  const isValid = violations.length === 0;

  if (!isValid) {
    throw new DependencyConfusionVulnerabilityError(
      `Dependency confusion vulnerabilities detected in .npmrc:\n- ${violations.join('\n- ')}`
    );
  }

  return {
    isValid,
    configuredScopes,
    violations,
  };
}
