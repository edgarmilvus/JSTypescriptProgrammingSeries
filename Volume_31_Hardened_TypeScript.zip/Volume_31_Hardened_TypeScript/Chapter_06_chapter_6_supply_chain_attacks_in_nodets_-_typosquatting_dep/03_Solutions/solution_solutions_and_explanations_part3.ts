/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface LockfileDependencyEntry {
  version: string;
  resolved?: string;
  integrity?: string;
  requires?: Record<string, string>;
  dependencies?: Record<string, LockfileDependencyEntry>;
}

export interface LockfileAuditReport {
  passed: boolean;
  untrustedSourcesFound: Array<{ packageName: string; resolvedUrl: string }>;
  missingIntegrityHashes: string[];
}

export function auditLockfileIntegrity(
  parsedLockfile: Record<string, any>,
  trustedDomains: string[]
): LockfileAuditReport {
  const untrustedSourcesFound: Array<{ packageName: string; resolvedUrl: string }> = [];
  const missingIntegrityHashes: string[] = [];

  // Handles npm lockfile v2/v3 structure (packages dictionary) and v1 (dependencies tree)
  const packages = parsedLockfile.packages || parsedLockfile.dependencies || {};

  function validateEntry(name: string, entry: LockfileDependencyEntry) {
    if (entry.resolved) {
      try {
        const url = new URL(entry.resolved);
        const isTrusted = trustedDomains.some((domain) => url.hostname === domain || url.hostname.endsWith(`.${domain}`));

        if (!isTrusted) {
          untrustedSourcesFound.push({ packageName: name, resolvedUrl: entry.resolved });
        }
      } catch {
        untrustedSourcesFound.push({ packageName: name, resolvedUrl: entry.resolved });
      }
    }

    if (!entry.integrity && entry.version) {
      missingIntegrityHashes.push(name);
    }

    if (entry.dependencies) {
      for (const [subName, subEntry] of Object.entries(entry.dependencies)) {
        validateEntry(subName, subEntry);
      }
    }
  }

  for (const [pkgKey, pkgEntry] of Object.entries(packages)) {
    // Skip the root package entry "" if present in lockfile v2/v3
    if (pkgKey === '') continue;
    const packageName = pkgKey.startsWith('node_modules/') ? pkgKey.replace('node_modules/', '') : pkgKey;
    validateEntry(packageName, pkgEntry as LockfileDependencyEntry);
  }

  return {
    passed: untrustedSourcesFound.length === 0 && missingIntegrityHashes.length === 0,
    untrustedSourcesFound,
    missingIntegrityHashes,
  };
}
