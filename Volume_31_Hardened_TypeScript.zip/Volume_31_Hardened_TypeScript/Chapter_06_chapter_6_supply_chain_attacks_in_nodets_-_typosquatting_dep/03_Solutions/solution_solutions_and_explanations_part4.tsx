/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export type RiskLevel = 'SECURE' | 'TYPOSQUATTING_RISK' | 'DEPENDENCY_CONFUSION_RISK' | 'UNTRUSTED_REGISTRY';

export interface ScannedDependency {
  id: string;
  name: string;
  version: string;
  resolvedSource: string;
  riskLevel: RiskLevel;
  details: string;
}

export interface SupplyChainRiskDashboardProps {
  repositoryName: string;
  fetchAuditData: () => Promise<ScannedDependency[]>;
}

export const SupplyChainRiskDashboard: React.FC<SupplyChainRiskDashboardProps> = ({
  repositoryName,
  fetchAuditData,
}) => {
  const [dependencies, setDependencies] = useState<ScannedDependency[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<RiskLevel | 'ALL'>('ALL');

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    fetchAuditData()
      .then((data) => {
        if (isMounted) {
          setDependencies(data);
          setError(null);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err instanceof Error ? err.message : 'Unknown error occurred during fetch');
        }
      })
      .finally(() => {
        if (isMounted) {
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [fetchAuditData]);

  const filteredDependencies = dependencies.filter((dep) => {
    if (selectedFilter === 'ALL') return true;
    return dep.riskLevel === selectedFilter;
  });

  return (
    <div className="supply-chain-dashboard" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Supply Chain Security: {repositoryName}</h2>

      <div className="filter-controls" style={{ marginBottom: '15px' }}>
        <strong>Filter Risk Level: </strong>
        {(['ALL', 'SECURE', 'TYPOSQUATTING_RISK', 'DEPENDENCY_CONFUSION_RISK', 'UNTRUSTED_REGISTRY'] as const).map((filter) => (
          <button
            key={filter}
            onClick={() => setSelectedFilter(filter)}
            style={{
              marginRight: '8px',
              padding: '6px 12px',
              backgroundColor: selectedFilter === filter ? '#007bff' : '#f8f9fa',
              color: selectedFilter === filter ? '#fff' : '#333',
              border: '1px solid #ccc',
              cursor: 'pointer',
              borderRadius: '4px',
            }}
          >
            {filter}
          </button>
        ))}
      </div>

      {loading && <p>Loading supply chain audit data...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {!loading && !error && (
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
          <thead>
            <tr style={{ backgroundColor: '#f1f1f1', textAlign: 'left' }}>
              <th style={{ padding: '8px', border: '1px solid #ddd' }}>Package Name</th>
              <th style={{ padding: '8px', border: '1px solid #ddd' }}>Version</th>
              <th style={{ padding: '8px', border: '1px solid #ddd' }}>Risk Level</th>
              <th style={{ padding: '8px', border: '1px solid #ddd' }}>Details</th>
            </tr>
          </thead>
          <tbody>
            {filteredDependencies.length === 0 ? (
              <tr>
                <td colSpan={4} style={{ padding: '12px', textAlign: 'center', border: '1px solid #ddd' }}>
                  No dependencies match the selected filter.
                </td>
              </tr>
            ) : (
              filteredDependencies.map((dep) => (
                <tr key={dep.id}>
                  <td style={{ padding: '8px', border: '1px solid #ddd' }}>{dep.name}</td>
                  <td style={{ padding: '8px', border: '1px solid #ddd' }}>{dep.version}</td>
                  <td
                    style={{
                      padding: '8px',
                      border: '1px solid #ddd',
                      fontWeight: 'bold',
                      color: dep.riskLevel === 'SECURE' ? 'green' : 'red',
                    }}
                  >
                    {dep.riskLevel}
                  </td>
                  <td style={{ padding: '8px', border: '1px solid #ddd' }}>{dep.details}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};
