/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs/promises';

export interface CommitValidationResult {
  canCommit: boolean;
  errors: string[];
}

export async function validateCommitDependencies(
  stagedFiles: string[]
): Promise<CommitValidationResult> {
  const errors: string[] = [];

  const relevantFiles = stagedFiles.filter(
    (file) => file.endsWith('package.json') || file.endsWith('package-lock.json') || file.endsWith('.npmrc')
  );

  if (relevantFiles.length === 0) {
    return { canCommit: true, errors: [] };
  }

  for (const filePath of relevantFiles) {
    try {
      const stats = await fs.stat(filePath);
      if (!stats.isFile()) continue;

      if (filePath.endsWith('.npmrc')) {
        const content = await fs.readFile(filePath, 'utf-8');
        if (!content.includes(':registry=')) {
          errors.push(`[Dependency Confusion Risk] The .npmrc file at "${filePath}" lacks explicit scope registry mappings.`);
        }
      }

      if (filePath.endsWith('package.json')) {
        const content = await fs.readFile(filePath, 'utf-8');
        const parsed = JSON.parse(content);
        const allDeps = { ...parsed.dependencies, ...parsed.devDependencies };
        
        // Basic heuristic scan for known common typosquat patterns in commit
        const suspiciousPatterns = ['lodas', 'crossenv', 'react-domm', 'axio'];
        for (const dep of Object.keys(allDeps)) {
          if (suspiciousPatterns.includes(dep.toLowerCase())) {
            errors.push(`[Typosquatting Risk] Potentially malicious package name detected: "${dep}" in ${filePath}`);
          }
        }
      }
    } catch (err) {
      errors.push(`Failed to parse or inspect staged file "${filePath}": ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  return {
    canCommit: errors.length === 0,
    errors,
  };
}
