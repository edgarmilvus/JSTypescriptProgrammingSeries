/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview SaaS Supply Chain Security & Dependency Auditing Script
 * @description A self-contained TypeScript utility designed to parse package manifests,
 * validate lockfile integrity, and detect high-risk software supply chain vectors.
 * @module SupplyChainAuditor
 */

import * as crypto from 'crypto';

/**
 * Represents the structure of a standard Node.js package manifest (package.json).
 */
interface PackageManifest {
    name: string;
    version: string;
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
    resolutions?: Record<string, string>;
}

/**
 * Represents a parsed lockfile dependency entry with integrity hashes.
 */
interface LockfileDependencyEntry {
    version: string;
    resolved: string;
    integrity: string;
    dependencies?: Record<string, string>;
}

/**
 * Represents the structure of a simplified package-lock.json v2/v3 file.
 */
interface PackageLockFile {
    lockfileVersion: number;
    packages: Record<string, LockfileDependencyEntry>;
}

/**
 * Audit result interface capturing violations found during dependency analysis.
 */
interface AuditViolation {
    packageName: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    issue: string;
    remediation: string;
}

/**
 * Main SaaS Dependency Auditing Engine.
 * Encapsulates the logic required to inspect project manifests and lockfiles.
 */
class SupplyChainAuditor {
    private manifest: PackageManifest;
    private lockfile: PackageLockFile;
    private violations: AuditViolation[] = [];

    /**
     * Initializes the auditor with raw JSON strings representing the project manifest and lockfile.
     * @param manifestJson - The stringified contents of package.json
     * @param lockfileJson - The stringified contents of package-lock.json
     */
    constructor(manifestJson: string, lockfileJson: string) {
        try {
            this.manifest = JSON.parse(manifestJson) as PackageManifest;
            this.lockfile = JSON.parse(lockfileJson) as PackageLockFile;
        } catch (error: unknown) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to parse input JSON payloads: ${errorMessage}`);
        }
    }

    /**
     * Executes all security checks against the loaded dependency graph.
     * @returns An array of detected audit violations.
     */
    public runAudit(): AuditViolation[] {
        this.checkProtocolSecurity();
        this.checkVersionPinning();
        this.checkIntegrityHashesPresent();
        return this.violations;
    }

    /**
     * Verifies that all resolved dependency URLs utilize secure HTTPS protocols
     * rather than vulnerable plain-text HTTP or unverified local registry paths.
     */
    private checkProtocolSecurity(): void {
        const packages = this.lockfile.packages || {};

        for (const [pkgPath, entry] of Object.entries(packages)) {
            // Skip the root package entry
            if (pkgPath === "") continue;

            if (entry.resolved) {
                try {
                    const parsedUrl = new URL(entry.resolved);
                    if (parsedUrl.protocol !== 'https:') {
                        this.violations.push({
                            packageName: pkgPath,
                            severity: 'CRITICAL',
                            issue: `Insecure registry protocol detected: ${parsedUrl.protocol}`,
                            remediation: 'Force npm/yarn to resolve all packages exclusively via HTTPS registries.'
                        });
                    }
                } catch {
                    this.violations.push({
                        packageName: pkgPath,
                        severity: 'HIGH',
                        issue: `Malformed resolution URL: ${entry.resolved}`,
                        remediation: 'Rebuild lockfile using a clean npm install command.'
                    });
                }
            }
        }
    }

    /**
     * Scans direct dependencies for loose semantic versioning ranges (e.g., '*', '>=', caret ranges)
     * which expose the build pipeline to dynamic, unvetted upstream code changes.
     */
    private checkVersionPinning(): void {
        const allDeps = {
            ...(this.manifest.dependencies || {}),
            ...(this.manifest.devDependencies || {})
        };

        for (const [name, versionRange] of Object.entries(allDeps)) {
            // Check for wildcard versions or loose bounds
            if (versionRange === '*' || versionRange === 'latest' || versionRange.startsWith('>') || versionRange.startsWith('^')) {
                this.violations.push({
                    packageName: name,
                    severity: 'MEDIUM',
                    issue: `Unpinned or loose version range detected: "${versionRange}"`,
                    remediation: 'Pin dependencies to exact patch versions (e.g., "1.2.3") or utilize strict lockfiles.'
                });
            }
        }
    }

    /**
     * Ensures cryptographic integrity hashes (SHA-512/SHA-1) are present for every locked dependency
     * to prevent man-in-the-middle package tampering in the package registry.
     */
    private checkIntegrityHashesPresent(): void {
        const packages = this.lockfile.packages || {};

        for (const [pkgPath, entry] of Object.entries(packages)) {
            if (pkgPath === "") continue;

            if (!entry.integrity || entry.integrity.trim() === '') {
                this.violations.push({
                    packageName: pkgPath,
                    severity: 'HIGH',
                    issue: 'Missing cryptographic integrity hash in lockfile entry.',
                    remediation: 'Delete node_modules and package-lock.json, then regenerate using npm install.'
                });
            }
        }
    }
}

// ============================================================================
// Execution Example (SaaS Build Pipeline Context)
// ============================================================================

const mockPackageJson = JSON.stringify({
    name: "saas-core-api",
    version: "2.1.0",
    dependencies: {
        "express": "^4.18.2",
        "lodash": "*"
    }
});

const mockLockfileJson = JSON.stringify({
    lockfileVersion: 3,
    packages: {
        "": {
            version: "2.1.0",
            resolved: "",
            integrity: ""
        },
        "node_modules/express": {
            version: "4.18.2",
            resolved: "https://registry.npmjs.org/express/-/express-4.18.2.tgz",
            integrity: "sha512-5vtNXgy6Dto0IC6bx/jg.g.=="
        },
        "node_modules/lodash": {
            version: "4.17.21",
            resolved: "http://insecure-registry.internal/lodash/-/lodash-4.17.21.tgz",
            integrity: ""
        }
    }
});

// Execute the auditor inside a simulated CI/CD pipeline step
try {
    console.log("Initializing SaaS Supply Chain Security Auditor...");
    const auditor = new SupplyChainAuditor(mockPackageJson, mockLockfileJson);
    const auditResults = auditor.runAudit();

    if (auditResults.length > 0) {
        console.warn(`[SECURITY WARNING] Found ${auditResults.length} supply chain vulnerabilities!`);
        console.table(auditResults);
        // In a real CI/CD pipeline, process.exit(1) would be invoked here to fail the build.
    } else {
        console.log("[SECURITY SUCCESS] No supply chain vulnerabilities detected. Proceeding with deployment.");
    }
} catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[FATAL ERROR] Audit execution failed: ${errorMessage}`);
    process.exit(1);
}
