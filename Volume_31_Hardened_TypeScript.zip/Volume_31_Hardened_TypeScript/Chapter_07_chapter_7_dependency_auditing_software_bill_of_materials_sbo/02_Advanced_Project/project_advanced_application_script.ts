/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

/**
 * Represents the structure of a package.json manifest file.
 */
interface PackageJson {
  name: string;
  version: string;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  resolutions?: Record<string, string>;
}

/**
 * Represents an entry inside a package-lock.json (v2/v3 schema).
 */
interface LockfileDependency {
  version: string;
  resolved?: string;
  integrity?: string;
  dev?: boolean;
  requires?: Record<string, string>;
  dependencies?: Record<string, LockfileDependency>;
}

interface PackageLockJson {
  lockfileVersion: number;
  name: string;
  packages?: Record<string, {
    version?: string;
    resolved?: string;
    integrity?: string;
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  }>;
  dependencies?: Record<string, LockfileDependency>;
}

/**
 * Output format for the generated Software Bill of Materials (SBOM) component.
 */
interface SBOMComponent {
  componentName: string;
  version: string;
  scope: 'production' | 'development';
  integrityHash: string;
  sourceRegistry: string;
}

/**
 * Diagnostic result returned by the supply chain security analyzer.
 */
interface AuditReport {
  timestamp: string;
  totalDependenciesScanned: number;
  unpinnedVersionsFound: number;
  integrityMismatches: number;
  isSafeToBuild: boolean;
  components: SBOMComponent[];
  vulnerabilities: string[];
}



::: {style="text-align: center"}
![This diagram illustrates the data transformation pipeline from raw package-lock dependency structures into a standardized Software Bill of Materials (SBOM) and a comprehensive security audit report.](images/b31_c7_s3_diag1.png){width=80% caption="This diagram illustrates the data transformation pipeline from raw package-lock dependency structures into a standardized Software Bill of Materials (SBOM) and a comprehensive security audit report."}
:::



/**
 * SupplyChainSecurityAuditor provides programmatic lockfile inspection,
 * unpinned dependency warnings, and CycloneDX-compatible SBOM component mapping.
 */
export class SupplyChainSecurityAuditor {
  private projectRoot: string;
  private packageJsonPath: string;
  private lockfilePath: string;

  constructor(projectRoot: string = process.cwd()) {
    this.projectRoot = projectRoot;
    this.packageJsonPath = path.join(this.projectRoot, 'package.json');
    this.lockfilePath = path.join(this.projectRoot, 'package-lock.json');
  }

  /**
   * Executes the full suite of supply chain audits.
   */
  public runAudit(): AuditReport {
    console.log('[SupplyChainSecurity] Starting dependency verification and SBOM generation...');

    const packageJson = this.readJsonFile<PackageJson>(this.packageJsonPath);
    const lockfile = this.readJsonFile<PackageLockJson>(this.lockfilePath);

    const vulnerabilities: string[] = [];
    const components: SBOMComponent[] = [];
    let unpinnedCount = 0;
    let integrityFailures = 0;

    const allDirectDeps = {
      ...(packageJson.dependencies || {}),
      ...(packageJson.devDependencies || {})
    };

    // 1. Analyze direct dependencies for floating versions (e.g., ^, ~, or *)
    for (const [name, versionSpec] of Object.entries(allDirectDeps)) {
      if (this.isFloatingVersion(versionSpec)) {
        unpinnedCount++;
        vulnerabilities.push(`Unpinned dependency version detected for "${name}": "${versionSpec}". Use exact versions for high-security environments.`);
      }
    }

    // 2. Parse lockfile packages and build the SBOM component list
    if (lockfile.packages) {
      for (const [pkgPath, meta] of Object.entries(lockfile.packages)) {
        if (pkgPath === '' || !meta.version) continue; // Skip root project entry

        const componentName = pkgPath.replace(/^node_modules\//, '');
        const isDev = meta.devDependencies !== undefined || pkgPath.includes('dev');
        const integrity = meta.integrity || 'MISSING_INTEGRITY_HASH';

        if (!meta.integrity) {
          integrityFailures++;
          vulnerabilities.push(`Package "${componentName}" at path "${pkgPath}" lacks a cryptographic integrity hash.`);
        }

        components.push({
          componentName,
          version: meta.version,
          scope: isDev ? 'development' : 'production',
          integrityHash: integrity,
          sourceRegistry: meta.resolved || 'unknown'
        });
      }
    }

    const isSafeToBuild = integrityFailures === 0 && vulnerabilities.length === 0;

    return {
      timestamp: new Date().toISOString(),
      totalDependenciesScanned: components.length,
      unpinnedVersionsFound: unpinnedCount,
      integrityMismatches: integrityFailures,
      isSafeToBuild,
      components,
      vulnerabilities
    };
  }

  /**
   * Helper to safely read and parse a JSON configuration file.
   */
  private readJsonFile<T>(filePath: string): T {
    if (!fs.existsSync(filePath)) {
      throw new Error(`Critical security file missing: ${filePath}. Ensure lockfiles are committed.`);
    }
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(fileContent) as T;
  }

  /**
   * Determines if a version string relies on loose semantics (^, ~, >=, *).
   */
  private isFloatingVersion(versionSpec: string): boolean {
    const loosePrefixes = ['^', '~', '>', '<', '*', 'latest', 'x'];
    return loosePrefixes.some(prefix => versionSpec.startsWith(prefix) || versionSpec.includes('x'));
  }

  /**
   * Generates a cryptographic SHA-256 signature of the lockfile 
   * to verify that no unauthorized modifications occurred during transit.
   */
  public generateLockfileChecksum(): string {
    if (!fs.existsSync(this.lockfilePath)) {
      throw new Error('Lockfile not found for checksum generation.');
    }
    const fileBuffer = fs.readFileSync(this.lockfilePath);
    const hashSum = crypto.createHash('sha256');
    hashSum.update(fileBuffer);
    return hashSum.digest('hex');
  }
}

// Execution block for CI/CD pipelines
if (require.main === module) {
  try {
    const auditor = new SupplyChainSecurityAuditor();
    const checksum = auditor.generateLockfileChecksum();
    console.log(`[SupplyChainSecurity] Lockfile SHA-256 Checksum: ${checksum}`);

    const report = auditor.runAudit();
    console.log(`[SupplyChainSecurity] Scanned ${report.totalDependenciesScanned} components.`);
    console.log(`[SupplyChainSecurity] Unpinned versions: ${report.unpinnedVersionsFound}`);
    console.log(`[SupplyChainSecurity] Integrity failures: ${report.integrityMismatches}`);

    if (!report.isSafeToBuild) {
      console.error('[SupplyChainSecurity] BUILD FAILED: Supply chain vulnerabilities detected.');
      report.vulnerabilities.forEach(v => console.error(`  - ${v}`));
      process.exit(1);
    } else {
      console.log('[SupplyChainSecurity] BUILD PASSED: Dependency tree verified successfully.');
      process.exit(0);
    }
  } catch (error: unknown) {
    if (error instanceof Error) {
      console.error('[SupplyChainSecurity] Execution Error:', error.message);
    } else {
      console.error('[SupplyChainSecurity] Unknown Error:', error);
    }
    process.exit(1);
  }
}
