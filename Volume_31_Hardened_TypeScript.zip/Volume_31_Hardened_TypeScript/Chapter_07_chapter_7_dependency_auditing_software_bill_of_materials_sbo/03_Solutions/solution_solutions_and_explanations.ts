/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import * as path from 'path';

export interface AuditConfig {
  allowedRegistries: string[];
  requireSha512: boolean;
}

export interface AuditViolation {
  packageName: string;
  version: string;
  rule: string;
  details: string;
}

export interface AuditReport {
  passed: boolean;
  violations: AuditViolation[];
  warnings: string[];
}

export function auditLockfile(lockfilePath: string, config: AuditConfig): AuditReport {
  const violations: AuditViolation[] = [];
  const warnings: string[] = [];

  if (!fs.existsSync(lockfilePath)) {
    throw new Error(`Lockfile not found at: ${lockfilePath}`);
  }

  const rawContent = fs.readFileSync(lockfilePath, 'utf-8');
  let lockfile: any;

  try {
    lockfile = JSON.parse(rawContent);
  } catch (error) {
    throw new Error(`Failed to parse lockfile JSON: ${(error as Error).message}`);
  }

  // Handle Lockfile v2/v3 packages map
  const packages = lockfile.packages || {};

  for (const [pkgPath, pkgMeta] of Object.entries<any>(packages)) {
    if (pkgPath === '') continue; // Skip root node

    const packageName = pkgPath.startsWith('node_modules/') 
      ? pkgPath.replace('node_modules/', '') 
      : pkgPath;
    const version = pkgMeta.version || 'unknown';
    const resolved = pkgMeta.resolved;
    const integrity = pkgMeta.integrity;

    // 1. Check for unpinned or dangerous protocols / URLs
    if (resolved) {
      if (resolved.startsWith('http://') || resolved.startsWith('file:') || resolved.startsWith('git+http:')) {
        violations.push({
          packageName,
          version,
          rule: 'INSECURE_PROTOCOL',
          details: `Resolved URL uses unsecure or forbidden protocol: ${resolved}`
        });
      }

      // Check registry origin
      const matchesAllowed = config.allowedRegistries.some(reg => resolved.startsWith(reg));
      if (!matchesAllowed) {
        violations.push({
          packageName,
          version,
          rule: 'UNTRUSTED_REGISTRY',
          details: `Package resolved from untrusted source: ${resolved}`
        });
      }
    }

    // 2. Validate cryptographic integrity hashes
    if (config.requireSha512) {
      if (!integrity || !integrity.startsWith('sha512-')) {
        violations.push({
          packageName,
          version,
          rule: 'INVALID_OR_MISSING_INTEGRITY',
          details: `Missing or non-SHA512 integrity hash: ${integrity || 'none'}`
        });
      }
    } else {
      if (!integrity || (!integrity.startsWith('sha512-') && !integrity.startsWith('sha256-'))) {
        violations.push({
          packageName,
          version,
          rule: 'INVALID_OR_MISSING_INTEGRITY',
          details: `Integrity hash does not start with sha512- or sha256-: ${integrity || 'none'}`
        });
      }
    }
  }

  return {
    passed: violations.length === 0,
    violations,
    warnings
  };
}
