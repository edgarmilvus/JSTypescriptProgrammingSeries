/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import * as crypto from 'crypto';

interface PackageJson {
  name: string;
  version: string;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
}

interface CycloneDXComponent {
  type: string;
  name: string;
  version: string;
  purl: string;
  hashes?: { alg: string; content: string }[];
}

interface CycloneDXDocument {
  bomFormat: string;
  specVersion: string;
  serialNumber: string;
  version: number;
  metadata: {
    timestamp: string;
    tools: { components: { name: string; version: string }[] }[];
    component: { type: string; name: string; version: string };
  };
  components: CycloneDXComponent[];
}

export function generateCycloneDXSBOM(packageJsonPath: string, lockfilePath: string): CycloneDXDocument {
  const pkgData: PackageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
  const lockData = JSON.parse(fs.readFileSync(lockfilePath, 'utf-8'));
  
  const packages = lockData.packages || {};
  const components: CycloneDXComponent[] = [];

  for (const [pkgPath, pkgMeta] of Object.entries<any>(packages)) {
    if (pkgPath === '') continue;

    const name = pkgPath.startsWith('node_modules/') ? pkgPath.replace('node_modules/', '') : pkgPath;
    const version = pkgMeta.version || '0.0.0';

    // Construct valid purl (handling scoped packages like @babel/core -> %40babel/core)
    let purlName = name;
    if (name.startsWith('@')) {
      const [scope, baseName] = name.split('/');
      purlName = `${scope}/${baseName}`;
    }
    const encodedPurlName = purlName.replace('@', '%40');
    const purl = `pkg:npm/${encodedPurlName}@${version}`;

    const hashes: { alg: string; content: string }[] = [];
    if (pkgMeta.integrity) {
      const [alg, content] = pkgMeta.integrity.split('-');
      if (alg && content) {
        hashes.push({ alg: alg.toUpperCase(), content });
      }
    }

    components.push({
      type: 'library',
      name,
      version,
      purl,
      ...(hashes.length > 0 ? { hashes } : {})
    });
  }

  const serialNumber = `urn:uuid:${crypto.randomUUID()}`;

  return {
    bomFormat: 'CycloneDX',
    specVersion: '1.5',
    serialNumber,
    version: 1,
    metadata: {
      timestamp: new Date().toISOString(),
      tools: [{
        components: [{ name: 'enterprise-sbom-generator', version: '1.0.0' }]
      }],
      component: {
        type: 'application',
        name: pkgData.name || 'unknown-app',
        version: pkgData.version || '1.0.0'
      }
    },
    components
  };
}

export async function writeSBOMToFile(sbom: CycloneDXDocument, outputPath: string): Promise<void> {
  const jsonString = JSON.stringify(sbom, null, 2);
  await fs.promises.writeFile(outputPath, jsonString, 'utf-8');
}
