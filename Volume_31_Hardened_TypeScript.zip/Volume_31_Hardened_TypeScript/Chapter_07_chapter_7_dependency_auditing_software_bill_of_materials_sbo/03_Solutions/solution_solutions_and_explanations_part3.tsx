/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

export type SeverityLevel = 'critical' | 'high' | 'moderate' | 'low';

export interface VulnerabilityRecord {
  id: string;
  packageName: string;
  severity: SeverityLevel;
  vulnerableVersions: string;
  patchedVersions: string;
  dependencyPath: string[];
  cve?: string;
  remediated?: boolean;
}

interface VulnerabilityDashboardProps {
  vulnerabilities: VulnerabilityRecord[];
}

export const VulnerabilityDashboard: React.FC<VulnerabilityDashboardProps> = ({ vulnerabilities: initialVulns }) => {
  const [vulns, setVulns] = useState<VulnerabilityRecord[]>(initialVulns);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleFix = (id: string) => {
    setVulns(prev => prev.map(v => v.id === id ? { ...v, remediated: true } : v));
  };

  const filteredVulns = vulns.filter(v => {
    const matchesSearch = v.packageName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (v.cve && v.cve.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesSeverity = selectedSeverity === 'all' || v.severity === selectedSeverity;
    return matchesSearch && matchesSeverity;
  });

  const counts = vulns.reduce((acc, v) => {
    if (!v.remediated) acc[v.severity] = (acc[v.severity] || 0) + 1;
    return acc;
  }, {} as Record<SeverityLevel, number>);

  return (
    <div className="p-6 max-w-6xl mx-auto bg-slate-900 text-slate-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">Dependency Vulnerability Visualizer</h1>
      
      {/* Summary Header */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {(['critical', 'high', 'moderate', 'low'] as SeverityLevel[]).map(sev => (
          <div key={sev} className="p-4 bg-slate-800 rounded-lg border border-slate-700 shadow">
            <div className="text-sm uppercase tracking-wider text-slate-400">{sev}</div>
            <div className="text-2xl font-black mt-1">{counts[sev] || 0}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <input 
          type="text" 
          placeholder="Search by package or CVE..." 
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="flex-1 bg-slate-800 border border-slate-700 rounded px-4 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
          aria-label="Search vulnerabilities"
        />
        <select 
          value={selectedSeverity}
          onChange={e => setSelectedSeverity(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded px-4 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
          aria-label="Filter by severity"
        >
          <option value="all">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="moderate">Moderate</option>
          <option value="low">Low</option>
        </select>
      </div>

      {/* Vulnerability Cards */}
      <div className="space-y-4">
        {filteredVulns.map(v => (
          <div 
            key={v.id} 
            className={`p-4 rounded-lg border transition-all ${v.remediated ? 'bg-slate-800/40 border-emerald-800/50 opacity-60' : 'bg-slate-800 border-slate-700'}`}
          >
            <div className="flex justify-between items-center">
              <div>
                <span className="font-bold text-lg">{v.packageName}</span>
                <span className={`ml-3 px-2 py-0.5 text-xs rounded uppercase font-bold ${
                  v.severity === 'critical' ? 'bg-red-900 text-red-200' :
                  v.severity === 'high' ? 'bg-orange-900 text-orange-200' : 'bg-yellow-900 text-yellow-200'
                }`}>
                  {v.severity}
                </span>
                {v.cve && <span className="ml-3 text-sm text-slate-400">{v.cve}</span>}
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setExpandedId(expandedId === v.id ? null : v.id)}
                  className="text-sm text-blue-400 hover:underline focus:outline-none"
                  aria-expanded={expandedId === v.id}
                >
                  {expandedId === v.id ? 'Hide Path' : 'Inspect Path'}
                </button>
                <button 
                  disabled={v.remediated}
                  onClick={() => handleFix(v.id)}
                  className={`px-3 py-1 rounded text-sm font-medium ${v.remediated ? 'bg-emerald-900 text-emerald-300 cursor-default' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}
                >
                  {v.remediated ? 'Remediated' : 'Simulate Fix'}
                </button>
              </div>
            </div>

            {expandedId === v.id && (
              <div className="mt-4 pt-4 border-t border-slate-700 text-sm text-slate-300">
                <div><strong>Vulnerable Versions:</strong> {v.vulnerableVersions}</div>
                <div className="mt-1"><strong>Remediation:</strong> Upgrade to &gt;= {v.patchedVersions}</div>
                <div className="mt-2">
                  <strong>Dependency Path:</strong>
                  <div className="flex items-center gap-2 mt-1">
                    {v.dependencyPath.map((node, idx) => (
                      <React.Fragment key={idx}>
                        <span className="px-2 py-1 bg-slate-900 rounded font-mono text-xs">{node}</span>
                        {idx < v.dependencyPath.length - 1 && <span className="text-slate-500">→</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
