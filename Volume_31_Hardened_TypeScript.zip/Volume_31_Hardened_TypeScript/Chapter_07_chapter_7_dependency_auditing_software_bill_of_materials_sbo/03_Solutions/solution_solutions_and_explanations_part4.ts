/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';

export interface ScopeEnforcementConfig {
  internalScopes: string[];
  packageJsonPath: string;
  npmrcPath: string;
}

export function enforceDependencyScopes(config: ScopeEnforcementConfig): void {
  if (!fs.existsSync(config.packageJsonPath)) {
    throw new Error(`package.json not found at: ${config.packageJsonPath}`);
  }

  if (!fs.existsSync(config.npmrcPath)) {
    throw new Error(`.npmrc configuration file missing at: ${config.npmrcPath}. Private scopes cannot be verified.`);
  }

  const pkgData = JSON.parse(fs.readFileSync(config.packageJsonPath, 'utf-8'));
  const npmrcContent = fs.readFileSync(config.npmrcPath, 'utf-8');

  const dependencies = {
    ...(pkgData.dependencies || {}),
    ...(pkgData.devDependencies || {})
  };

  const violations: string[] = [];

  for (const pkgName of Object.keys(dependencies)) {
    // Check if the dependency belongs to any defined internal scope
    const matchesInternalScope = config.internalScopes.some(scope => pkgName.startsWith(scope));

    if (matchesInternalScope) {
      // Extract scope prefix (e.g., @my-org)
      const scopePrefix = pkgName.split('/')[0];
      const registryKey = `${scopePrefix}:registry`;

      // Verify if the .npmrc file defines a custom registry mapping for this specific scope
      const hasRegistryMapping = npmrcContent.includes(registryKey);

      if (!hasRegistryMapping) {
        violations.push(
          `Internal package '${pkgName}' matches restricted scope '${scopePrefix}', but lacks an explicit registry mapping ('${registryKey}=...') in .npmrc.`
        );
      }
    }
  }

  if (violations.length > 0) {
    console.error('[SECURITY ERROR] Dependency Confusion Vulnerability Risk Detected:\n');
    violations.forEach(v => console.error(` - ${v}`));
    console.error('\nRemediation: Configure private registry scopes in your .npmrc file before running installations.');
    process.exit(1);
  }
}
