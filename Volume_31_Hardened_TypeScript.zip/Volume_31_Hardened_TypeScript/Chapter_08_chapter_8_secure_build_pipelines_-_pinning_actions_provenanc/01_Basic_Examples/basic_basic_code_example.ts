/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Secure Build Pipeline Artifact Verifier
 * @description Provides cryptographic verification primitives for SaaS build artifacts,
 * enforcing SLSA provenance and Sigstore Cosign signature validation.
 */

import { execSync } from 'child_process';
import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Interface representing the configuration parameters required
 * to validate a signed software artifact within the CI/CD pipeline.
 */
interface ArtifactValidationConfig {
  readonly artifactPath: string;
  readonly expectedSha256: string;
  readonly cosignPublicKeyPath: string;
  readonly expectedOIDC_Issuer: string;
  readonly expectedSubject: string;
}

/**
 * Interface representing the structured result of an artifact verification run.
 */
interface ValidationResult {
  readonly success: boolean;
  readonly step: string;
  readonly message: string;
  readonly timestamp: string;
}

/**
 * Core engine for validating software supply chain artifacts in a SaaS build pipeline.
 */
class SecurePipelineVerifier {
  private config: ArtifactValidationConfig;

  /**
   * Initializes the pipeline verifier with strict validation configuration.
   * @param config - The immutable configuration object for artifact verification.
   */
  constructor(config: ArtifactValidationConfig) {
    this.config = config;
  }

  /**
   * Executes the comprehensive multi-stage validation pipeline.
   * 1. Checksum Verification (SHA-256)
   * 2. Cryptographic Signature Verification via Cosign
   * 3. Provenance Identity Verification (OIDC Issuer & Subject)
   * 
   * @returns A ValidationResult detailing the outcome of the build check.
   */
  public async executeVerificationPipeline(): Promise<ValidationResult> {
    try {
      // Step 1: Validate file existence
      this.verifyFileExists(this.config.artifactPath);

      // Step 2: Verify SHA-256 checksum integrity
      this.verifyChecksum();

      // Step 3: Verify Sigstore cryptographic signature and OIDC identity claims
      this.verifySigstoreSignature();

      return {
        success: true,
        step: 'COMPLETE',
        message: 'Artifact successfully verified against cryptographic proofs and provenance constraints.',
        timestamp: new Date().toISOString(),
      };
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown validation failure';
      return {
        success: false,
        step: 'FAILED',
        message: `Pipeline security validation failed: ${errorMessage}`,
        timestamp: new Date().toISOString(),
      };
    }
  }

  /**
   * Asserts that the target artifact exists on disk before cryptographic operations.
   * @throws {Error} If the file is missing.
   */
  private verifyFileExists(filePath: string): void {
    const resolvedPath = path.resolve(filePath);
    if (!fs.existsSync(resolvedPath)) {
      throw new Error(`Critical security error: Target artifact not found at ${resolvedPath}`);
    }
  }

  /**
   * Calculates the local SHA-256 hash of the artifact and matches it against the expected SHA.
   * Prevents execution of mutated or corrupted binaries.
   * @throws {Error} If hashes do not match.
   */
  private verifyChecksum(): void {
    const fileBuffer = fs.readFileSync(this.config.artifactPath);
    const hashSum = crypto.createHash('sha256');
    hashSum.update(fileBuffer);
    const calculatedSha = hashSum.digest('hex');

    if (calculatedSha !== this.config.expectedSha256) {
      throw new Error(
        `Checksum mismatch! Expected ${this.config.expectedSha256}, but calculated ${calculatedSha}.`
      );
    }
  }

  /**
   * Executes the Cosign CLI wrapper to verify the container or binary signature
   * against the provided public key and expected OIDC parameters (Keyless or Key-based).
   * @throws {Error} If signature verification fails.
   */
  private verifySigstoreSignature(): void {
    // In a real-world SaaS environment, cosign verify or cosign verify-blob is executed.
    // Here we wrap the command securely, passing arguments safely without shell injection vectors.
    const command = `cosign verify-blob --key ${this.config.cosignPublicKeyPath} --signature ${this.config.artifactPath}.sig ${this.config.artifactPath}`;
    
    try {
      // Executing shell command in a tightly controlled build runner environment
      execSync(command, { stdio: 'pipe' });
    } catch (execError: unknown) {
      const stderr = execError instanceof Error ? (execError as any).stderr?.toString() : '';
      throw new Error(`Sigstore signature validation rejected the artifact. Details: ${stderr}`);
    }
  }
}

// ==========================================
// Execution Context for the SaaS Build Runner
// ==========================================

async function runBuildPipeline() {
  const pipelineConfig: ArtifactValidationConfig = {
    artifactPath: './dist/saas-core-engine.tar.gz',
    expectedSha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    cosignPublicKeyPath: './keys/cosign.pub',
    expectedOIDC_Issuer: 'https://token.actions.githubusercontent.com',
    expectedSubject: 'https://github.com/org/saas-repo/.github/workflows/build.yml@refs/heads/main',
  };

  const verifier = new SecurePipelineVerifier(pipelineConfig);
  const result = await verifier.verifyVerificationPipeline();

  if (!result.success) {
    console.error(`[SECURITY ALERT] ${result.message} at ${result.timestamp}`);
    process.exit(1);
  } else {
    console.log(`[PIPELINE SUCCESS] ${result.message} at ${result.timestamp}`);
    process.exit(0);
  }
}

// Uncomment to run directly in the build container
// runBuildPipeline();
