/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createHash } from 'crypto';
import { readFile } from 'fs/promises';
import { verify } from 'crypto';

/**
 * Interface representing a pinned GitHub Action manifest entry.
 */
interface PinnedActionRule {
  actionPath: string;
  expectedVersion: string;
  pinnedSha: string;
}

/**
 * Interface representing the SLSA Provenance In-Toto Statement structure.
 */
interface SlsaProvenanceStatement {
  _type: string;
  subject: Array<{
    name: string;
    digest: {
      sha256: string;
      [key: string]: string;
    };
  }>;
  predicateType: string;
  predicate: {
    builder: {
      id: string;
    };
    buildType: string;
    invocation: {
      configSource: {
        uri: string;
        digest: {
          sha1: string;
        };
        entryPoint: string;
      };
    };
    metadata: {
      completeness: {
        parameters: boolean;
        environment: boolean;
        materials: boolean;
      };
      reproducible: boolean;
    };
    materials: Array<{
      uri: string;
      digest: {
        sha1?: string;
        sha256?: string;
      };
    }>;
  };
}

/**
 * Result object returned by the Supply Chain Security Auditor.
 */
export interface SecurityAuditResult {
  isSecure: boolean;
  actionVerification: {
    passed: boolean;
    errors: string[];
  };
  provenanceVerification: {
    passed: boolean;
    errors: string[];
  };
  signatureVerification: {
    passed: boolean;
    errors: string[];
  };
  timestamp: string;
}

/**
 * SupplyChainSecurityAuditor provides programmatic verification of CI/CD pipeline integrity,
 * ensuring actions are immutable, build provenance is intact, and artifacts are cryptographically signed.
 */
export class SupplyChainSecurityAuditor {
  private allowedBuilders: string[];
  private publicVerificationKey: string;

  constructor(allowedBuilders: string[], publicVerificationKey: string) {
    this.allowedBuilders = allowedBuilders;
    this.publicVerificationKey = publicVerificationKey;
  }

  /**
   * Validates that GitHub Action references in a workflow file are pinned to immutable SHAs
   * rather than mutable floating tags (like @v1, @main).
   * 
   * @param workflowContent Raw string content of the GitHub Actions YAML workflow.
   * @param rules Array of enterprise-mandated pinning rules.
   */
  public verifyActionPinning(workflowContent: string, rules: PinnedActionRule[]): { passed: boolean; errors: string[] } {
    const errors: string[] = [];
    let passed = true;

    for (const rule of rules) {
      // Construct the expected usage pattern: actions/checkout@<SHA>
      const expectedPattern = `${rule.actionPath}@${rule.pinnedSha}`;
      
      // Check if the exact pinned pattern exists in the workflow content
      if (!workflowContent.includes(expectedPattern)) {
        // Check if the action is used with a mutable tag instead
        const mutableRegex = new RegExp(`${rule.actionPath}@[a-zA-Z0-9_.-]+`, 'g');
        const matches = workflowContent.match(mutableRegex);

        if (matches) {
          errors.push(
            `Violation: Action '${rule.actionPath}' is using a mutable reference instead of pinned SHA '${rule.pinnedSha}'. Found: ${matches.join(', ')}`
          );
        } else {
          errors.push(
            `Violation: Mandated action '${rule.actionPath}' with SHA '${rule.pinnedSha}' was not found in the workflow.`
          );
        }
        passed = false;
      }
    }

    return { passed, errors };
  }

  /**
   * Validates an in-toto SLSA Provenance statement against enterprise security policies.
   * 
   * @param provenanceJson Parsed SLSA provenance statement.
   * @param expectedImageDigest The expected SHA256 digest of the built artifact.
   */
  public verifySlsaProvenance(
    provenanceJson: SlsaProvenanceStatement, 
    expectedImageDigest: string
  ): { passed: boolean; errors: string[] } {
    const errors: string[] = [];
    let passed = true;

    // 1. Verify in-toto statement type wrapper
    if (provenanceJson._type !== 'https://in-toto.io/Statement/v0.1' && 
        provenanceJson._type !== 'https://in-toto.io/Statement/v1') {
      errors.push(`Invalid in-toto statement type: ${provenanceJson._type}`);
      passed = false;
    }

    // 2. Verify predicate type matches SLSA provenance v0.2 or v1.0
    if (!provenanceJson.predicateType.includes('slsa.dev/provenance')) {
      errors.push(`Invalid predicate type. Expected SLSA provenance, got: ${provenanceJson.predicateType}`);
      passed = false;
    }

    // 3. Verify builder ID is within the organization's approved trust boundary
    const builderId = provenanceJson.predicate.builder.id;
    if (!this.allowedBuilders.includes(builderId)) {
      errors.push(`Untrusted build system ID: '${builderId}'. Allowed builders: ${this.allowedBuilders.join(', ')}`);
      passed = false;
    }

    // 4. Verify subject digest matches the deployment target artifact
    const matchingSubject = provenanceJson.subject.find(
      (sub) => sub.digest.sha256 === expectedImageDigest
    );

    if (!matchingSubject) {
      errors.push(
        `Provenance subject mismatch! Expected artifact SHA256 '${expectedImageDigest}' was not attested in the provenance payload.`
      );
      passed = false;
    }

    // 5. Verify build metadata completeness guarantees
    const completeness = provenanceJson.predicate.metadata?.completeness;
    if (!completeness || !completeness.parameters || !completeness.environment || !completeness.materials) {
      errors.push('SLSA provenance completeness criteria failed: parameters, environment, or materials are marked incomplete.');
      passed = false;
    }

    return { passed, errors };
  }

  /**
   * Verifies a cryptographic signature (Sigstore/Cosign style) over an artifact digest or payload.
   * 
   * @param payload The raw string or buffer of the payload that was signed.
   * @param signatureBase64 The base64-encoded cryptographic signature generated by Cosign.
   */
  public verifyCosignSignature(payload: string | Buffer, signatureBase64: string): { passed: boolean; errors: string[] } {
    const errors: string[] = [];
    let passed = true;

    try {
      const signatureBuffer = Buffer.from(signatureBase64, 'base64');
      const payloadBuffer = typeof payload === 'string' ? Buffer.from(payload) : payload;

      // Use Node.js crypto module to verify ECDSA or RSA signature against public key
      const isVerified = verify(
        'sha256',
        payloadBuffer,
        {
          key: this.publicVerificationKey,
          padding: 0 // Assumes standard ECDSA P-256 or RSASSA-PSS depending on key setup
        },
        signatureBuffer
      );

      if (!isVerified) {
        errors.push('Cryptographic signature verification failed: The signature does not match the payload or public key.');
        passed = false;
      }
    } catch (err: any) {
      errors.push(`Cryptographic execution error during signature verification: ${err.message}`);
      passed = false;
    }

    return { passed, errors };
  }

  /**
   * Orchestrates the full security audit pipeline.
   */
  public async executeAudit(
    workflowContent: string,
    actionRules: PinnedActionRule[],
    provenanceData: SlsaProvenanceStatement,
    targetArtifactSha: string,
    signatureBase64: string
  ): Promise<SecurityAuditResult> {
    const actionResult = this.verifyActionPinning(workflowContent, actionRules);
    const provenanceResult = this.verifySlsaProvenance(provenanceData, targetArtifactSha);
    
    // Convert provenance object to canonical string for signature validation matching
    const provenanceString = JSON.stringify(provenanceData);
    const signatureResult = this.verifyCosignSignature(provenanceString, signatureBase64);

    const isSecure = actionResult.passed && provenanceResult.passed && signatureResult.passed;

    return {
      isSecure,
      actionVerification: actionResult,
      provenanceVerification: provenanceResult,
      signatureVerification: signatureResult,
      timestamp: new Date().toISOString()
    };
  }
}
