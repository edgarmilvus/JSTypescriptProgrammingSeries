/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// TARGET: Refactor the insecure GitHub Actions workflow configuration and implement a security linter.

const securedWorkflowConfig = `
name: Production Deployment Pipeline

on:
  push:
    branches: [ "main" ]

concurrency:
  group: \${{ github.workflow }}-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      # @description: Checkout repository code for build
      # @original-tag: v3
      # @release-date: 2023-08-16
      - name: Checkout Repository
        uses: actions/checkout@8f4b7f84864484a7bf31766abe9204da3cbe65b3 # v3.5.0

      # @description: Setup Node.js runtime environment
      # @original-tag: v3
      # @release-date: 2023-09-06
      - name: Setup Node.js Environment
        uses: actions/setup-node@64ed1c7eab4cce3362f8c340dee64e5eaeef3f7c # v3.6.0
        with:
          node-version: '20.x'
          cache: 'npm'

      # @description: Run Snyk container/code vulnerability audit
      # @original-tag: master
      # @release-date: 2023-10-12
      - name: Run Security Audit
        uses: snyk/actions/node@0a98b182d8d85cb3b0f56a5c17b5fb31d87f5e8f # master

      # @description: Authenticate and deploy application to Azure Web App
      # @original-tag: v2
      # @release-date: 2023-06-20
      - name: Authenticate and Deploy
        uses: azure/webapps-deploy@de0f85eb3d325732788e0ae8e515d0a631165a25 # v2.3.0
        with:
          app-name: 'production-ai-service'
          publish-profile: \${{ secrets.AZURE_WEBAPP_PUBLISH_PROFILE }}
`;

function validateWorkflowActionPinning(yamlContent: string): void {
  // Regex matches 'uses: owner/repo@ref'
  const usesRegex = /uses:\s+([^\s@]+)@([^\s#]+)/g;
  const shaRegex = /^[0-9a-fA-F]{40}$/;

  let match: RegExpExecArray | null;
  const violations: string[] = [];

  while ((match = usesRegex.exec(yamlContent)) !== null) {
    const actionPath = match[1];
    const reference = match[2];

    if (!shaRegex.test(reference)) {
      violations.push(
        `Action '${actionPath}' uses mutable reference '${reference}'. It must be pinned to an exact 40-character commit SHA.`
      );
    }
  }

  if (violations.length > 0) {
    throw new Error(
      `Security Validation Failed: Unpinned GitHub Actions detected!\n\n${violations.join('\n')}`
    );
  }
}
