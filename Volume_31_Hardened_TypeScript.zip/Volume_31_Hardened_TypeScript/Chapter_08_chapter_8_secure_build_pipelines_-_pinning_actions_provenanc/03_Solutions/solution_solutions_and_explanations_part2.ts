/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as crypto from 'crypto';

export interface BuildArtifact {
  readonly path: string;
  readonly digest: {
    readonly sha256: string;
  };
  readonly sizeBytes: number;
}

export interface SLSAMaterial {
  readonly uri: string;
  readonly digest: {
    readonly sha256: string;
  };
}

export interface SLSAProvenanceDocument {
  readonly _type: string;
  readonly subject: ReadonlyArray<BuildArtifact>;
  readonly predicateType: string;
  readonly predicate: {
    readonly builder: {
      readonly id: string;
    };
    readonly buildType: string;
    readonly invocation: {
      readonly configSource: {
        readonly uri: string;
        readonly digest: {
          readonly sha256: string;
        };
        readonly entryPoint: string;
      };
      readonly parameters: Record<string, string>;
      readonly environment: Record<string, string>;
    };
    readonly materials: ReadonlyArray<SLSAMaterial>;
  };
}

export function generateAndSignProvenance(
  artifacts: ReadonlyArray<{ readonly path: string; readonly content: Buffer }>,
  buildUri: string,
  commitSha: string,
  privateKey: string
): { readonly provenance: SLSAProvenanceDocument; readonly signature: string } {
  const subjects: BuildArtifact[] = artifacts.map((artifact) => {
    const hash = crypto.createHash('sha256').update(artifact.content).digest('hex');
    return {
      path: artifact.path,
      digest: { sha256: hash },
      sizeBytes: artifact.content.length,
    };
  });

  const provenance: SLSAProvenanceDocument = {
    _type: 'https://in-toto.io/Statement/v0.1',
    subject: subjects,
    predicateType: 'https://slsa.dev/provenance/v1.0',
    predicate: {
      builder: {
        id: 'https://github.com/actions/runner',
      },
      buildType: 'https://github.com/slsa-framework/slsa-github-generator/typescript-build@v1',
      invocation: {
        configSource: {
          uri: buildUri,
          digest: {
            sha256: commitSha,
          },
          entryPoint: 'npm run build',
        },
        parameters: { environment: 'production' },
        environment: {
          nodeVersion: process.version,
          platform: process.platform,
        },
      },
      materials: [
        {
          uri: buildUri,
          digest: {
            sha256: commitSha,
          },
        },
      ],
    },
  };

  const canonicalJson = JSON.stringify(provenance);
  const signer = crypto.createSign('SHA256');
  signer.update(canonicalJson);
  signer.end();
  const signature = signer.sign(privateKey, 'hex');

  return { provenance, signature };
}
