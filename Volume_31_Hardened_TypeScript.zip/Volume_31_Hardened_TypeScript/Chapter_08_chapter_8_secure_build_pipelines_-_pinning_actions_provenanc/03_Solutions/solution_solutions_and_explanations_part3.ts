/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface CosignVerificationResult {
  readonly verified: boolean;
  readonly imageDigest: string;
  readonly certificates: ReadonlyArray<{
    readonly subjectAlternativeName: string;
    readonly issuer: string;
    readonly validFrom: string;
    readonly validTo: string;
  }>;
  readonly optionalBOM?: string;
}

export interface VerificationPolicy {
  readonly expectedIssuer: string;
  readonly allowedSubjectPattern: RegExp;
  readonly requireCertificateTransparencyLog: boolean;
}

export function verifyContainerImagePolicy(
  result: CosignVerificationResult,
  policy: VerificationPolicy
): void {
  if (!result.verified) {
    throw new Error(`Container Verification Failed: Image digest ${result.imageDigest} is not cryptographically verified.`);
  }

  if (result.certificates.length === 0) {
    throw new Error(`Container Verification Failed: No signing certificates found in verification bundle.`);
  }

  const matchingCert = result.certificates.find((cert) => {
    const isIssuerValid = cert.issuer === policy.expectedIssuer;
    const isSubjectValid = policy.allowedSubjectPattern.test(cert.subjectAlternativeName);
    return isIssuerValid && isSubjectValid;
  });

  if (!matchingCert) {
    throw new Error(
      `Policy Enforcement Failed: No certificate matched expected issuer '${policy.expectedIssuer}' and subject pattern '${policy.allowedSubjectPattern.toString()}'`
    );
  }

  const now = new Date();
  const validFrom = new Date(matchingCert.validFrom);
  const validTo = new Date(matchingCert.validTo);

  if (now < validFrom || now > validTo) {
    throw new Error(
      `Certificate Expiration Error: Certificate validity period (${matchingCert.validFrom} to ${matchingCert.validTo}) does not cover current timestamp.`
    );
  }
}
