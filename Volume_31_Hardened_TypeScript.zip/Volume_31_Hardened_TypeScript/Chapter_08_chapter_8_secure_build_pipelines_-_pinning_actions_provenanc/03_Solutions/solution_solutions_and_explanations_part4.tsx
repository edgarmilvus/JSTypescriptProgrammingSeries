/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React from 'react';
import { useChat } from 'ai/react';

export interface BuildSecurityAuditItem {
  readonly buildId: string;
  readonly repository: string;
  readonly commitSha: string;
  readonly actionsPinned: boolean;
  readonly slsaProvenanceGenerated: boolean;
  readonly cosignVerified: boolean;
  readonly timestamp: string;
}

export interface PipelineSecurityDashboardProps {
  readonly initialAudits: ReadonlyArray<BuildSecurityAuditItem>;
  readonly organizationId: string;
}

export function PipelineSecurityDashboard({
  initialAudits,
  organizationId,
}: PipelineSecurityDashboardProps): React.JSX.Element {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: `/api/organizations/${organizationId}/security-copilot`,
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8 bg-slate-900 text-slate-100 min-h-screen">
      <header className="border-b border-slate-800 pb-4">
        <h1 className="text-2xl font-bold tracking-tight">Pipeline Security Dashboard</h1>
        <p className="text-sm text-slate-400">Organization: {organizationId}</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {initialAudits.map((audit) => (
          <div key={audit.buildId} className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-mono text-xs text-slate-400">{audit.buildId}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-700">{audit.timestamp}</span>
            </div>
            <h2 className="font-semibold truncate">{audit.repository}</h2>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span>Actions Pinned:</span>
                <span className={audit.actionsPinned ? 'text-emerald-400' : 'text-rose-400'}>
                  {audit.actionsPinned ? 'Secured' : 'Vulnerable'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>SLSA Provenance:</span>
                <span className={audit.slsaProvenanceGenerated ? 'text-emerald-400' : 'text-rose-400'}>
                  {audit.slsaProvenanceGenerated ? 'Generated' : 'Missing'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Cosign Verified:</span>
                <span className={audit.cosignVerified ? 'text-emerald-400' : 'text-rose-400'}>
                  {audit.cosignVerified ? 'Verified' : 'Unsigned'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </section>

      <section className="bg-slate-800 border border-slate-700 rounded-lg p-6 space-y-4">
        <h2 className="text-lg font-semibold">Security Copilot Remediation Chat</h2>
        <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
          {messages.map((m) => (
            <div key={m.id} className={`flex flex-col space-y-1 ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
              <span className="text-xs text-slate-400 capitalize">{m.role}</span>
              <div className={`p-3 rounded-lg text-sm max-w-xl ${m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-700 text-slate-200'}`}>
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2 pt-2">
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Ask AI Copilot about build pipeline vulnerabilities..."
            className="flex-1 bg-slate-900 border border-slate-700 rounded-md px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 px-4 py-2 rounded-md text-sm font-medium transition-colors"
          >
            {isLoading ? 'Analyzing...' : 'Ask Copilot'}
          </button>
        </form>
      </section>
    </div>
  );
}
