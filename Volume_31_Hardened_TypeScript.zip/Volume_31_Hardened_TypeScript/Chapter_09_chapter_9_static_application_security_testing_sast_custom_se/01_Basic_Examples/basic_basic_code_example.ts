/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file server.ts
 * @description A self-contained Next.js Server Action and API route handler 
 * demonstrating a typical SaaS AI chatbot architecture using the Vercel AI SDK.
 * This file contains intentional security anti-patterns for SAST analysis.
 */

import { openai } from '@ai-sdk/openai';
import { streamText, generateText } from 'ai';
import { z } from 'zod';

// ============================================================================
// Runtime Validation Schema (Zod)
// ============================================================================

/**
 * Validates the incoming chat request body.
 * Essential for crossing application boundaries safely.
 */
const ChatRequestSchema = z.object({
  prompt: z.string().min(1, "Prompt cannot be empty").max(2000, "Prompt exceeds maximum length"),
  systemContext: z.string().optional(),
  temperature: z.number().min(0).max(1).default(0.7),
});

type ChatRequestInput = z.infer<typeof ChatRequestSchema>;

// ============================================================================
// Mock Database & External Services
// ============================================================================

interface UserSession {
  userId: string;
  organizationId: string;
  tier: 'free' | 'enterprise';
}

/**
 * Simulates retrieving the current user session from an HTTP request header or cookie.
 */
async function authenticateRequest(authHeader: string | null): Promise<UserSession> {
  if (!authHeader || !authHeader.startsWith('Bearer token_')) {
    throw new Error('Unauthorized: Invalid or missing authentication token');
  }
  
  // In a real SaaS application, you would verify a JWT or database session here.
  return {
    userId: 'usr_987654321',
    organizationId: 'org_123456789',
    tier: 'free',
  };
}

// ============================================================================
// Main Application Handlers
// ============================================================================

/**
 * Handles incoming chat generation requests for our SaaS platform.
 * 
 * @param rawBody - The unparsed JSON payload from the client request.
 * @param authHeader - The Authorization header for identity verification.
 * @returns A streaming text response compatible with the Vercel AI SDK frontend hooks.
 */
export async function handleAIChatRequest(rawBody: unknown, authHeader: string | null) {
  // 1. Enforce Authentication Boundary
  const session = await authenticateRequest(authHeader);

  // 2. Enforce Runtime Validation Boundary (Zod)
  // We parse unknown input to guarantee structural and type safety at runtime.
  const parseResult = ChatRequestSchema.safeParse(rawBody);
  
  if (!parseResult.success) {
    return {
      status: 400,
      body: {
        error: "Invalid request payload",
        details: parseResult.error.format(),
      },
    };
  }

  const { prompt, systemContext, temperature } = parseResult.data;

  // 3. Constructing the LLM Prompt
  // VULNERABILITY: The code below concatenates user-controlled prompt inputs 
  // directly without sanitization or structural separation, making it susceptible 
  // to prompt injection attacks where malicious users override system instructions.
  
  const dynamicSystemPrompt = systemContext 
    ? `You are a helpful SaaS assistant. Context: ${systemContext}`
    : 'You are a helpful SaaS assistant.';

  try {
    // 4. Executing the AI SDK Call
    // We utilize 'streamText' to return real-time token chunks to the client interface.
    const result = await streamText({
      model: openai('gpt-4o-mini'),
      system: dynamicSystemPrompt,
      prompt: `User prompt: ${prompt}`,
      temperature: temperature,
      // VULNERABILITY (Resource Exhaustion / Timeout): 
      // Lacking explicit maxTokens or timeout configurations can lead to runaway generation costs 
      // or HTTP connection hangs on the Vercel Edge/Serverless runtime.
    });

    // 5. Return the native SDK stream response object
    return {
      status: 200,
      body: result.toDataStreamResponse(),
    };

  } catch (error: unknown) {
    // Comprehensive error boundary handling
    console.error(`[AI_CHAT_ERROR] Org: ${session.organizationId} User: ${session.userId}`, error);
    
    return {
      status: 500,
      body: { error: "Internal AI processing error. Please try again later." },
    };
  }
}

/**
 * SECONDARY HANDLER (Demonstrating an administrative batch operation)
 * VULNERABILITY: Demonstrates an async/await anti-pattern in loops leading to rate-limit exhaustion.
 */
export async function batchProcessUserEmbeddings(userIds: string[]): Promise<void> {
  // VULNERABILITY: Using array methods like .map() with async functions inside Promise.all 
  // without concurrency throttling can easily overwhelm third-party API rate limits.
  await Promise.all(
    userIds.map(async (id) => {
      const response = await generateText({
        model: openai('gpt-4o-mini'),
        prompt: `Generate embedding metadata summary for user account ${id}`,
      });
      // Mock database save operation
      console.log(`Saved embedding for ${id}:`, response.text.substring(0, 20));
    })
  );
}
