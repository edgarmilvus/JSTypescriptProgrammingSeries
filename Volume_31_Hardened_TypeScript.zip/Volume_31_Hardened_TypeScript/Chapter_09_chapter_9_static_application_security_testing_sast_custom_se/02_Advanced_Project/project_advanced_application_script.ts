/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file secure-dashboard-actions.ts
 * @description Enterprise-grade Next.js Server Actions implementing secure 
 * asynchronous processing, strict input validation, and protection against 
 * common TypeScript/Node.js vulnerability patterns (e.g., NoSQL injection, 
 * unvalidated redirects, and unsafe data deserialization).
 */

'use server';

import { z } from 'zod';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

/**
 * Interface representing the structure of an incoming search request.
 */
interface VectorSearchInput {
  query: string;
  maxResults?: number;
}

/**
 * Interface representing the shape of a sanitized database entity.
 */
interface SecureDocumentRecord {
  id: string;
  title: string;
  embeddingSnippet: number[];
  createdAt: string;
}

/**
 * Zod validation schema for incoming vector search payloads.
 * Prevents injection attacks by enforcing strict type constraints and length limits.
 */
const VectorSearchSchema = z.object({
  query: z.string()
    .min(3, { message: "Query must be at least 3 characters long." })
    .max(500, { message: "Query cannot exceed 500 characters." })
    .trim(),
  maxResults: z.number()
    .int()
    .positive()
    .max(50, { message: "Cannot request more than 50 results at once." })
    .default(10),
});

/**
 * Verifies the user session via secure, HTTP-only cookies.
 * Throws an authorization error if the token is missing or malformed.
 * 
 * @throws {Error} When authentication fails.
 */
async function verifySecureSession(): Promise<string> {
  const cookieStore = cookies();
  const sessionToken = cookieStore.get('__Secure-Session-Token');

  if (!sessionToken || !sessionToken.value) {
    throw new Error("Unauthorized: Missing or invalid session cookie.");
  }

  // In a real-world system, cryptographic signature verification happens here.
  return sessionToken.value;
}

/**
 * Simulates a secure, non-blocking asynchronous call to an external AI model 
 * service for generating vector embeddings. Uses Node.js asynchronous primitives.
 * 
 * @param text - The sanitized search text.
 * @returns A promise resolving to an array of floating-point numbers.
 */
async function generateVectorEmbedding(text: string): Promise<number[]> {
  // Simulating async network latency for embedding generation API
  return new Promise((resolve) => {
    setTimeout(() => {
      // Mocking a 3-dimensional embedding vector for demonstration purposes
      const mockEmbedding = [0.1234, -0.5678, 0.9101];
      resolve(mockEmbedding);
    }, 150);
  });
}

/**
 * Executes a secure vector similarity search against a database backend.
 * Uses parameterized queries to prevent injection vulnerabilities.
 * 
 * @param embedding - The numeric embedding vector.
 * @param limit - Maximum number of records to return.
 * @returns A promise resolving to an array of secure document records.
 */
async function queryVectorDatabase(embedding: number[], limit: number): Promise<SecureDocumentRecord[]> {
  // Simulating asynchronous DB operation
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: "doc_981237",
          title: "Secure Supply Chain Compliance Guide",
          embeddingSnippet: embedding,
          createdAt: new Date().toISOString(),
        }
      ]);
    }, 200);
  });
}

/**
 * Primary Server Action for handling secure vector search requests.
 * Orchestrates session validation, input sanitization, asynchronous embedding 
 * generation, and database retrieval.
 * 
 * @param prevState - The previous state of the form or action response.
 * @param formData - The raw FormData submitted by the client component.
 * @returns An object containing either success data or validation/system errors.
 */
export async function executeSecureVectorSearch(
  prevState: any,
  formData: FormData
): Promise<{ success: boolean; data?: SecureDocumentRecord[]; error?: string }> {
  try {
    // Step 1: Enforce authentication and authorization checks
    const userId = await verifySecureSession();
    console.debug(`[Audit] Authorized search execution initiated by user: ${userId}`);

    // Step 2: Extract raw inputs from FormData
    const rawQuery = formData.get('query');
    const rawLimit = formData.get('maxResults');

    // Step 3: Validate and parse inputs using Zod schema to prevent injection
    const validationResult = VectorSearchSchema.safeParse({
      query: typeof rawQuery === 'string' ? rawQuery : '',
      maxResults: rawLimit ? parseInt(rawLimit as string, 10) : 10,
    });

    if (!validationResult.success) {
      return {
        success: false,
        error: validationResult.error.errors.map((e) => e.message).join(", "),
      };
    }

    const { query, maxResults } = validationResult.data;

    // Step 4: Perform asynchronous processing for AI embedding generation
    const embedding = await generateVectorEmbedding(query);

    // Step 5: Execute database query safely using the generated vector
    const searchResults = await queryVectorDatabase(embedding, maxResults);

    // Step 6: Return structured, sanitized data back to the caller
    return {
      success: true,
      data: searchResults,
    };

  } catch (error: unknown) {
    // Log unexpected errors securely without leaking stack traces to the client
    console.error("[Security Error] Failure during secure search execution:", error);
    
    return {
      success: false,
      error: "An unexpected error occurred while processing your request. Please try again.",
    };
  }
}
