/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file document-processor.ts
 * @description A SaaS microservice component that safely reads user-uploaded 
 * documents from a scoped directory and logs telemetry. Designed to run under 
 * the native Node.js Permission Model.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

/**
 * Interface representing the configuration parameters for the document processor.
 */
interface ProcessingOptions {
  /** The relative or absolute path to the designated storage vault */
  vaultPath: string;
  /** The target filename to read and process */
  filename: string;
}

/**
 * Safely reads a document from the file system, constrained by the Node.js 
 * native permission model flags passed at startup.
 * 
 * @param {ProcessingOptions} options - The operational parameters.
 * @returns {string} The raw content of the target file.
 * @throws {Error} If file access is denied by the runtime or the file is missing.
 */
function processUserDocument(options: ProcessingOptions): string {
  // 1. Resolve the absolute path to prevent traversal attacks
  const absoluteVaultPath = path.resolve(options.vaultPath);
  const targetFilePath = path.join(absoluteVaultPath, options.filename);

  console.log(`[Security Monitor]: Attempting to access file at: ${targetFilePath}`);

  // 2. Enforce structural validation: ensure the target remains within the vault
  if (!targetFilePath.startsWith(absoluteVaultPath)) {
    throw new Error('Security Violation: Path traversal attempt detected.');
  }

  try {
    // 3. Attempt synchronous read. 
    // If Node.js was started without '--allow-fs-read=<vaultPath>', 
    // this call will throw an ERR_ACCESS_DENIED security exception.
    const fileContent = fs.readFileSync(targetFilePath, { encoding: 'utf8' });
    
    console.log(`[Security Monitor]: Successfully read ${options.filename}. Length: ${fileContent.length} bytes.`);
    return fileContent;

  } catch (error: unknown) {
    if (error instanceof Error) {
      // Handle native permission errors specifically
      if ('code' in error && error.code === 'ERR_ACCESS_DENIED') {
        console.error(`[CRITICAL SECURITY ALERT]: Runtime permission denied for path: ${targetFilePath}`);
        console.error(`[Details]: ${error.message}`);
        throw new Error(`Access Denied: The SaaS runtime environment has blocked file system access to this resource.`);
      }
    }
    // Re-throw generic or unexpected errors (e.g., ENOENT)
    throw error;
  }
}

// Execution block simulating SaaS background worker invocation
if (require.main === module) {
  const designatedVault = './saas-vault';
  const targetDocument = 'customer-invoice-1049.txt';

  console.log('--- Initiating SaaS Document Processing Worker ---');
  
  try {
    const documentData = processUserDocument({
      vaultPath: designatedVault,
      filename: targetDocument
    });

    // Simulate downstream processing (e.g., parsing, embedding generation)
    console.log(`[Worker Status]: Processing payload preview -> "${documentData.substring(0, 30)}..."`);
  } catch (err: unknown) {
    if (err instanceof Error) {
      console.error(`[Worker Failure]: Terminating task due to error: ${err.message}`);
      process.exit(1);
    }
  }
}
