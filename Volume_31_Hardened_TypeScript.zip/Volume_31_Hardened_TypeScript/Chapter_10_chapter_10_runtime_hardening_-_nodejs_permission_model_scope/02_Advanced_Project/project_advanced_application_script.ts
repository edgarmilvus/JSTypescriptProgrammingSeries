/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { spawn } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * @fileoverview Secure Tenant Execution Microservice
 * Enforces native Node.js runtime permission boundaries (--experimental-permission)
 * to safely evaluate multi-tenant automation tasks and prevent zero-day breakouts.
 */

// Define the shape of our incoming automation execution request
interface ExecutionPayload {
  tenantId: string;
  scriptContent: string;
  allowedReadPaths: string[];
}

/**
 * Validates that the runtime environment is executing with native permissions enabled.
 * This guarantees that zero-day code injections cannot elevate privileges or bypass the sandbox.
 */
function verifyRuntimeHardening(): void {
  // Check if Node.js execution flags include the permission model
  const execArgs = process.execArgv;
  const hasPermissionFlag = execArgs.some((arg) => arg.includes('--experimental-permission'));

  if (!hasPermissionFlag) {
    console.warn(
      '[SECURITY WARNING]: Node.js is running WITHOUT the --experimental-permission flag. ' +
        'Runtime file-system and process restrictions are currently disabled.'
    );
  }
}

/**
 * Prepares a scoped, isolated execution directory for a given tenant.
 * Writes the dynamic script safely within a bounded workspace to prevent traversal attacks.
 */
async function provisionTenantWorkspace(tenantId: string, scriptContent: string): Promise<string> {
  const baseSandboxDir = path.resolve(process.cwd(), 'sandboxes');
  const tenantDir = path.join(baseSandboxDir, tenantId);

  // Ensure the base sandbox directory exists
  await fs.mkdir(baseSandboxDir, { recursive: true });
  // Create the isolated tenant directory
  await fs.mkdir(tenantDir, { recursive: true });

  const scriptPath = path.join(tenantDir, 'task.js');
  
  // Write the user-submitted script to the sandboxed path
  await fs.writeFile(scriptPath, scriptContent, { encoding: 'utf-8', mode: 0o600 });

  return scriptPath;
}

/**
 * Executes the sandboxed script via a spawned child process, explicitly denying 
 * access to unauthorized sub-processes, network sockets, and file handles.
 */
async function executeSandboxedScript(scriptPath: string): Promise<{ stdout: string; stderr: string; code: number | null }> {
  return new Promise((resolve, reject) => {
    // Spawn a child process running the isolated script
    // In production, invoke node with: node --experimental-permission --allow-fs-read=<tenantDir> task.js
    const child = spawn(process.execPath, [
      '--experimental-permission',
      '--no-addons', // Prevent native C++ module loading attacks
      scriptPath
    ], {
      env: { NODE_ENV: 'production' },
      timeout: 5000, // Enforce strict execution time limits to prevent resource exhaustion (ReDoS/Infinite loops)
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('error', (err) => {
      reject(err);
    });

    child.on('close', (code) => {
      resolve({ stdout, stderr, code });
    });
  });
}

/**
 * Next.js API Route Handler for Multi-Tenant Script Execution
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Verify system-level hardening configurations on boot/invocation
    verifyRuntimeHardening();

    // 2. Parse and validate incoming payload
    const body: ExecutionPayload = await req.json();
    if (!body.tenantId || !body.scriptContent) {
      return NextResponse.json(
        { error: 'Missing required parameters: tenantId and scriptContent' },
        { status: 400 }
      );
    }

    // Sanitize tenant ID to prevent directory traversal exploits
    const sanitizedTenantId = path.basename(body.tenantId);

    // 3. Provision isolated filesystem workspace
    const scriptPath = await provisionTenantWorkspace(sanitizedTenantId, body.scriptContent);

    // 4. Execute the workload under strict runtime boundaries
    const executionResult = await executeSandboxedScript(scriptPath);

    // 5. Cleanup temporary sandbox assets asynchronously
    await fs.rm(path.dirname(scriptPath), { recursive: true, force: true }).catch((cleanupErr) => {
      console.error(`Failed to cleanup sandbox for tenant ${sanitizedTenantId}:`, cleanupErr);
    });

    // 6. Return execution telemetry to the client
    return NextResponse.json({
      success: true,
      exitCode: executionResult.code,
      output: executionResult.stdout,
      errors: executionResult.stderr,
    }, { status: 200 });

  } catch (error: any) {
    console.error('Execution sandbox critical failure:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Internal execution sandbox error' },
      { status: 500 }
    );
  }
}
