/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// worker-harness.ts
import { Worker } from 'node:worker_threads';
import * as path from 'node:path';

export function initializeSecureWorkers(contextPayload: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const workerPath = path.resolve(__dirname, 'worker-task.js');
    const workerCount = 3;
    const results: string[] = [];
    let completedWorkers = 0;

    if (workerCount === 0) {
      return resolve(results);
    }

    for (let i = 0; i < workerCount; i++) {
      // Spawn worker threads. Under --experimental-permission, worker threads 
      // inherit the main thread's permission constraints.
      const worker = new Worker(workerPath, {
        workerData: { chunkId: i, payload: contextPayload }
      });

      worker.on('message', (message: string) => {
        results.push(message);
        completedWorkers++;
        if (completedWorkers === workerCount) {
          resolve(results);
        }
      });

      worker.on('error', (error) => {
        // Catch runtime permission or execution errors inside workers
        reject(new Error(`Worker execution failed: ${error.message}`));
      });

      worker.on('exit', (code) => {
        if (code !== 0) {
          reject(new Error(`Worker stopped with exit code ${code}`));
        }
      });
    }
  });
}
