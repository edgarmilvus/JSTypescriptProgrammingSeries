/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SecurityContextInspector.tsx
import React from 'react';

export interface PermissionStatus {
  hasFileSystemRead: boolean;
  hasFileSystemWrite: boolean;
  hasChildProcess: boolean;
  hasWorkerThreads: boolean;
  activeWhitelistPaths: string[];
}

// 1. Server Component fetching runtime permission telemetry safely via process metadata
export async function SecurityContextServer(): Promise<JSX.Element> {
  // Query native Node.js process permission API (available in modern Node runtime)
  const hasFsRead = typeof process.permission?.has === 'function' 
    ? process.permission.has('fs.read') 
    : false;
    
  const hasFsWrite = typeof process.permission?.has === 'function' 
    ? process.permission.has('fs.write') 
    : false;

  const hasChildProc = typeof process.permission?.has === 'function' 
    ? process.permission.has('child') 
    : false;

  const hasWorkers = typeof process.permission?.has === 'function' 
    ? process.permission.has('worker') 
    : true;

  const status: PermissionStatus = {
    hasFileSystemRead: hasFsRead,
    hasFileSystemWrite: hasFsWrite,
    hasChildProcess: hasChildProc,
    hasWorkerThreads: hasWorkers,
    activeWhitelistPaths: process.env.NODE_PERMISSION_WHITELIST?.split(',') || ['/app/templates']
  };

  return <SecurityDashboardClient status={status} />;
}

// 2. Client-side interactive dashboard component rendering telemetry and security states
export function SecurityDashboardClient(props: { status: PermissionStatus }): JSX.Element {
  const { hasFileSystemRead, hasFileSystemWrite, hasChildProcess, activeWhitelistPaths } = props.status;
  
  const isSecure = !hasChildProcess && hasFileSystemRead && hasFileSystemWrite;

  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-xl shadow-lg border border-slate-700">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <span>🛡️</span> Runtime Permission Inspector
      </h2>

      {!isSecure && (
        <div className="mb-4 p-4 bg-amber-900/50 border border-amber-500 rounded-lg text-amber-200 text-sm">
          <strong>Security Warning:</strong> Backend runtime is operating with relaxed or unverified permission constraints. Child process spawning is {hasChildProcess ? 'ENABLED (High Risk)' : 'DISABLED (Secure)'}.
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div className="p-3 bg-slate-800 rounded border border-slate-700">
          <span className="block text-slate-400">FS Read Whitelist:</span>
          <span className={hasFileSystemRead ? 'text-emerald-400 font-mono' : 'text-rose-400 font-mono'}>
            {hasFileSystemRead ? 'Restricted & Active' : 'Disabled'}
          </span>
        </div>
        <div className="p-3 bg-slate-800 rounded border border-slate-700">
          <span className="block text-slate-400">Child Process Execution:</span>
          <span className={hasChildProcess ? 'text-rose-400 font-mono' : 'text-emerald-400 font-mono'}>
            {hasChildProcess ? 'Allowed (Vulnerable)' : 'Blocked (Hardened)'}
          </span>
        </div>
      </div>

      <div className="text-xs text-slate-400">
        <span className="font-semibold text-slate-300">Active Whitelist Paths:</span>
        <ul className="list-disc list-inside mt-1 font-mono text-slate-300">
          {activeWhitelistPaths.map((p, idx) => (
            <li key={idx}>{p}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
