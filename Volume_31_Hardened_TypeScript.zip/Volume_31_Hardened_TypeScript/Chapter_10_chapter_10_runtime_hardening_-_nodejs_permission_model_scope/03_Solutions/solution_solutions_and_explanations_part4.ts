/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// container-validator.ts
import * as fs from 'node:fs';

export interface DeploymentConfig {
  image: string;
  runAsUser: number;
  command: string[];
  readOnlyRootFilesystem: boolean;
  droppedCapabilities: string[];
}

export function validateDeploymentManifest(configPath: string): boolean {
  if (!fs.existsSync(configPath)) {
    throw new Error(`[SECURITY ERROR] Deployment configuration not found at: ${configPath}`);
  }

  const rawContent = fs.readFileSync(configPath, 'utf8');
  let config: DeploymentConfig;

  try {
    config = JSON.parse(rawContent);
  } catch {
    throw new Error('[SECURITY ERROR] Failed to parse deployment configuration as valid JSON.');
  }

  // 1. Assert non-root execution (UID must not be 0 or root)
  if (config.runAsUser === 0 || config.runAsUser === undefined) {
    throw new Error('[SECURITY VIOLATION] Container must not run as root user (UID 0).');
  }

  // 2. Assert Node.js native permission model flags are explicitly present in entrypoint/command
  const hasExperimentalPermissionFlag = config.command.some(arg => arg.includes('--experimental-permission'));
  const hasReadConstraint = config.command.some(arg => arg.includes('--allow-fs-read'));

  if (!hasExperimentalPermissionFlag || !hasReadConstraint) {
    throw new Error('[SECURITY VIOLATION] Node.js runtime permission flags (--experimental-permission / --allow-fs-read) are missing from container command.');
  }

  // 3. Assert root filesystem immutability
  if (!config.readOnlyRootFilesystem) {
    throw new Error('[SECURITY VIOLATION] Container root filesystem must be configured as read-only.');
  }

  // 4. Assert high-privilege Linux capabilities are explicitly dropped
  const forbiddenCapabilities = ['CAP_SYS_ADMIN', 'CAP_NET_ADMIN', 'CAP_SETUID', 'CAP_SETGID'];
  const hasForbiddenCaps = config.droppedCapabilities.some(cap => forbiddenCapabilities.includes(cap) === false);

  if (hasForbiddenCaps && config.droppedCapabilities.length === 0) {
    throw new Error('[SECURITY VIOLATION] Dangerous Linux capabilities must be dropped in container runtime security profile.');
  }

  console.log('[SUCCESS] Container deployment manifest passed all zero-trust runtime hardening assertions.');
  return true;
}
