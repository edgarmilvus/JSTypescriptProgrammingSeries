/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// SecurityContextInspector.tsx
// Instructions: Implement the Server Component and Client Component pairing below.
// Adhere strictly to SC data-fetching practices and TypeScript typing standards.

import React from 'react';

interface PermissionStatus {
  hasFileSystemRead: boolean;
  hasFileSystemWrite: boolean;
  hasChildProcess: boolean;
  hasWorkerThreads: boolean;
  activeWhitelistPaths: string[];
}

// TODO: Implement the Server Component that fetches runtime permission metadata
export async function SecurityContextServer(): Promise<JSX.Element> {
  // Fetch runtime permission state via process.permission API
  throw new Error('Not implemented');
}

// TODO: Implement the interactive client-side dashboard component
export function SecurityDashboardClient(props: { status: PermissionStatus }): JSX.Element {
  // Render telemetry, warning banners, and cyclical graph state machine UI
  throw new Error('Not implemented');
}
