/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

digraph ArchitecturePipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#333333"];
    
    Client [label="Client Device\n(Passkey + Device Posture Check)"];
    EdgeProxy [label="Edge Gateway / PDP\n(Contextual Risk Evaluation)"];
    ServerActions [label="Server Actions & Components\n(Business Logic / SSRF Protection)"];
    ServiceMesh [label="Service Mesh\n(mTLS + Micro-Segmentation)"];
    Database [label="Dynamic Credentials &\nRow-Level Security"];
    
    Client -> EdgeProxy [label=" WebAuthn / FIDO2 Assertion", color="blue"];
    EdgeProxy -> ServerActions [label=" Context-Encoded Signed JWT", color="blue"];
    ServerActions -> ServiceMesh [label=" mTLS Encrypted Internal Call", color="blue"];
    ServiceMesh -> Database [label=" Short-Lived Scoped Token", color="blue"];
}
