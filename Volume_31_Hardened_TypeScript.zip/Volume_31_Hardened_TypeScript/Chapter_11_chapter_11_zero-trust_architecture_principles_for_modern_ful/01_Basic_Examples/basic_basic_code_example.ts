/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import http, { IncomingMessage, ServerResponse } from 'http';
import { URL } from 'url';
import crypto from 'crypto';

/**
 * @fileoverview Zero-Trust Request Verification Middleware
 * @description Intercepts incoming HTTP requests to enforce continuous identity verification,
 * cryptographic token validation, device context checks, and least-privilege role scoping.
 */

// ============================================================================
// Types and Interfaces
// ============================================================================

/**
 * Represents the contextual metadata extracted from the request for Zero-Trust evaluation.
 */
interface RequestContext {
    ip: string;
    userAgent: string;
    deviceId: string;
    timestamp: number;
}

/**
 * Represents the decoded claims within a verified Zero-Trust token.
 */
interface VerifiedClaims {
    sub: string;             // Subject (User ID)
    email: string;           // User email
    roles: string[];         // Assigned security roles
    deviceId: string;        // Bound device identifier
    tokenIssuedAt: number;   // Epoch timestamp of issuance
}

/**
 * Extended IncomingMessage interface to safely attach verified Zero-Trust context.
 */
interface ZeroTrustRequest extends IncomingMessage {
    user?: VerifiedClaims;
    context?: RequestContext;
}

/**
 * Handler function signature for application routes.
 */
type RouteHandler = (req: ZeroTrustRequest, res: ServerResponse) => void;

// ============================================================================
// Cryptographic Mock Utilities (Zero-Trust Simulation)
// ============================================================================

// In a real production environment, this secret would be dynamically fetched from a 
// secure Key Management Service (KMS) or hardware security module (HSM).
const TOKEN_SIGNING_SECRET = 'zt_secret_key_9876543210abcdef';

/**
 * Simulates a cryptographic signature verification of a JWT string.
 * Enforces strict cryptographic integrity checks.
 * 
 * @param {string} token - The raw bearer token string.
 * @returns {VerifiedClaims | null} Decoded claims if valid, null otherwise.
 */
function verifyCryptographicToken(token: string): VerifiedClaims | null {
    try {
        const parts = token.split('.');
        if (parts.length !== 3) return null;

        const [headerB64, payloadB64, signatureB64] = parts;
        
        // Re-calculate HMAC signature to prevent tampering
        const expectedSignature = crypto
            .createHmac('sha256', TOKEN_SIGNING_SECRET)
            .update(`${headerB64}.${payloadB64}`)
            .digest('base64url');

        if (signatureB64 !== expectedSignature) {
            // Cryptographic validation failed: Token has been modified or forged
            return null;
        }

        const decodedPayload: VerifiedClaims = JSON.parse(
            Buffer.from(payloadB64, 'base64url').toString('utf8')
        );

        // Enforce maximum token lifespan (e.g., 5 minutes for strict zero-trust posture)
        const MAX_TOKEN_AGE_MS = 5 * 60 * 1000;
        if (Date.now() - decodedPayload.tokenIssuedAt > MAX_TOKEN_AGE_MS) {
            // Token has expired; zero-trust requires re-authentication
            return null;
        }

        return decodedPayload;
    } catch (error) {
        // Malformed tokens or decoding failures automatically fail validation
        return null;
    }
}

// ============================================================================
// Zero-Trust Security Policies & Middleware Engine
// ============================================================================

/**
 * Core Zero-Trust Evaluation Engine.
 * Intercepts requests, validates crypto tokens, checks device binding, 
 * and enforces least-privilege scoping.
 * 
 * @param {ZeroTrustRequest} req - The incoming HTTP request.
 * @param {ServerResponse} res - The outgoing HTTP response.
 * @param {RouteHandler} next - The downstream route handler to execute if checks pass.
 * @param {string[]} requiredRoles - The minimum roles required to access this resource.
 */
function enforceZeroTrustPolicy(
    req: ZeroTrustRequest, 
    res: ServerResponse, 
    next: RouteHandler, 
    requiredRoles: string[]
): void {
    const startTime = process.hrtime();

    // Step 1: Extract and validate authorization headers
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
            error: 'Unauthorized', 
            message: 'Zero-Trust Policy Violation: Missing or malformed Bearer token.' 
        }));
        return;
    }

    const token = authHeader.split(' ')[1];

    // Step 2: Perform cryptographic validation and expiration checks
    const claims = verifyCryptographicToken(token);
    if (!claims) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
            error: 'Forbidden', 
            message: 'Zero-Trust Policy Violation: Invalid cryptographic signature or expired session.' 
        }));
        return;
    }

    // Step 3: Extract and evaluate contextual device posture headers
    const clientDeviceId = req.headers['x-device-id'] as string;
    const clientIp = req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    if (!clientDeviceId || clientDeviceId !== claims.deviceId) {
        // Device binding mismatch detected: Possible token theft or session hijacking
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
            error: 'Forbidden', 
            message: 'Zero-Trust Policy Violation: Device binding mismatch detected.' 
        }));
        return;
    }

    // Step 4: Enforce Least-Privilege Access Control (RBAC/ABAC check)
    const hasRequiredRole = requiredRoles.some(role => claims.roles.includes(role));
    if (!requiredRoles.length || !hasRequiredRole) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
            error: 'Forbidden', 
            message: 'Zero-Trust Policy Violation: Insufficient privileges for requested resource.' 
        }));
        return;
    }

    // Step 5: Attach verified context to request object for downstream consumption
    req.user = claims;
    req.context = {
        ip: clientIp,
        userAgent,
        deviceId: clientDeviceId,
        timestamp: Date.now()
    };

    // Log continuous verification telemetry (Internal audit trail)
    const [seconds, nanoseconds] = process.hrtime(startTime);
    const durationMs = (seconds * 1000) + (nanoseconds / 1000000);
    console.log(`[Zero-Trust Audit] User ${claims.sub} verified successfully in ${durationMs.toFixed(3)}ms from IP ${clientIp}`);

    // Step 6: Hand off control to the protected route handler
    next(req, res);
}

// ============================================================================
// Application Controllers (Protected Endpoints)
// ============================================================================

/**
 * Protected SaaS Financial Ledger Endpoint.
 * Requires explicit 'finance:read' privilege verified via Zero-Trust middleware.
 */
const handleGetFinancialLedger: RouteHandler = (req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
        status: 'success',
        data: {
            account: 'ACME-Corp-Ledger-001',
            balance: 1450230.50,
            currency: 'USD',
            auditContext: {
                verifiedUser: req.user?.email,
                verifiedDevice: req.context?.deviceId,
                accessTimestamp: new Date(req.context?.timestamp || Date.now()).toISOString()
            }
        }
    }));
};

/**
 * Public Health Check Endpoint.
 * Bypasses Zero-Trust policy for infrastructure health monitoring.
 */
const handleHealthCheck: RouteHandler = (req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'healthy', uptime: process.uptime() }));
};

// ============================================================================
// HTTP Server Routing & Initialization
// ============================================================================

const server = http.createServer((req: IncomingMessage, res: ServerResponse) => {
    const parsedUrl = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
    const pathname = parsedUrl.pathname;

    // Route: Health Check (Public)
    if (pathname === '/health' && req.method === 'GET') {
        handleHealthCheck(req, res);
        return;
    }

    // Route: Protected Financial Ledger (Requires Zero-Trust Verification + 'finance:read' role)
    if (pathname === '/api/v1/ledger' && req.method === 'GET') {
        enforceZeroTrustPolicy(
            req as ZeroTrustRequest, 
            res, 
            handleGetFinancialLedger, 
            ['finance:read', 'admin']
        );
        return;
    }

    // Fallback: 404 Not Found
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found', message: 'The requested resource does not exist.' }));
});

// Start the server (Demonstration safety guard: only start if executed directly)
if (require.main === module) {
    const PORT = 3000;
    server.listen(PORT, () => {
        console.log(`[Zero-Trust Gateway] Secure server running on port ${PORT}`);
    });
}

export { enforceZeroTrustPolicy, verifyCryptographicToken, ZeroTrustRequest };
