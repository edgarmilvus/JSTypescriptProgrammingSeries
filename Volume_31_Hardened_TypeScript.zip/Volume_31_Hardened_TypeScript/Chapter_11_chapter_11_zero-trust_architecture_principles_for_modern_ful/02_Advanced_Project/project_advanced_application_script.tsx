/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import 'server-only';
import { headers } from 'next/headers';
import { createServerClient } from '@supabase/ssr';
import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';

/**
 * Interface representing the evaluated device and user trust context.
 */
interface TrustContext {
  userId: string;
  devicePostureScore: number;
  ipAddress: string;
  isMfaVerified: boolean;
  clearanceLevel: 'PUBLIC' | 'CONFIDENTIAL' | 'RESTRICTED';
}

/**
 * Custom error thrown when a Zero-Trust policy evaluation fails.
 */
class ZeroTrustPolicyViolationError extends Error {
  constructor(message: string, public readonly code: string) {
    super(message);
    this.name = 'ZeroTrustPolicyViolationError';
  }
}

/**
 * Evaluates the incoming request headers and ambient environment to construct
 * a verifiable Zero-Trust profile before granting execution rights to downstream services.
 * 
 * @returns {Promise<TrustContext>} The validated trust context of the requestor.
 */
async function evaluateZeroTrustContext(): Promise<TrustContext> {
  const requestHeaders = await headers();
  
  // Extract immutable cryptographic identity and device telemetry headers
  const userId = requestHeaders.get('x-verified-user-id');
  const deviceScoreHeader = requestHeaders.get('x-device-posture-score');
  const ipAddress = requestHeaders.get('x-forwarded-for') || '127.0.0.1';
  const mfaStatus = requestHeaders.get('x-mfa-verified');
  const clearanceLevel = (requestHeaders.get('x-clearance-level') || 'PUBLIC') as TrustContext['clearanceLevel'];

  // Enforce mandatory identity presence
  if (!userId) {
    throw new ZeroTrustPolicyViolationError(
      'Access denied: Missing cryptographic user identity assertion.',
      'ERR_ZT_MISSING_IDENTITY'
    );
  }

  // Parse and validate device posture score (range: 0.0 to 100.0)
  const devicePostureScore = deviceScoreHeader ? parseFloat(deviceScoreHeader) : 0.0;
  if (isNaN(devicePostureScore) || devicePostureScore < 75.0) {
    throw new ZeroTrustPolicyViolationError(
      `Access denied: Device posture score (${devicePostureScore}) falls below the strict threshold of 75.0.`,
      'ERR_ZT_DEVICE_POSTURE_FAILED'
    );
  }

  // Enforce Multi-Factor Authentication requirement for non-public tiers
  const isMfaVerified = mfaStatus === 'true';
  if (clearanceLevel !== 'PUBLIC' && !isMfaVerified) {
    throw new ZeroTrustPolicyViolationError(
      'Access denied: Contextual policy requires verified MFA for elevated resource tiers.',
      'ERR_ZT_MFA_REQUIRED'
    );
  }

  return {
    userId,
    devicePostureScore,
    ipAddress,
    isMfaVerified,
    clearanceLevel,
  };
}

/**
 * Secure Server Component demonstrating Zero-Trust data access, micro-segmentation,
 * and contextual AI generation.
 */
export default async function SecureZeroTrustDashboard() {
  let trustContext: TrustContext;

  try {
    // Step 1: Execute continuous verification of user and device posture
    trustContext = await evaluateZeroTrustContext();
  } catch (error) {
    if (error instanceof ZeroTrustPolicyViolationError) {
      // Render safe fallback UI isolating the security failure without leaking internal topologies
      return (
        <div className="p-6 border border-red-500 bg-red-50 text-red-900 rounded-lg">
          <h2 className="text-lg font-bold">Zero-Trust Security Interception</h2>
          <p>{error.message}</p>
          <span className="text-xs font-mono mt-2 block">Error Code: {error.code}</span>
        </div>
      );
    }
    throw error;
  }

  // Step 2: Initialize scoped database client bound to the validated user context (Row-Level Security)
  const supabase = createServerClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          // In a real implementation, securely fetch cookies respecting strict partition boundaries
          return '';
        },
      },
    }
  );

  // Step 3: Fetch application data enforcing least-privilege database micro-segmentation
  const { data: sensitiveLogs, error: dbError } = await supabase
    .from('audit_logs')
    .select('id, event, created_at')
    .eq('user_id', trustContext.userId)
    .limit(10);

  if (dbError) {
    throw new Error(`Database isolation layer failure: ${dbError.message}`);
  }

  // Step 4: Utilize the Vercel AI SDK under strict Zero-Trust operational limits
  const aiPrompt = `Analyze the operational posture for user ID ${trustContext.userId} with clearance ${trustContext.clearanceLevel}. Recent event count: ${sensitiveLogs?.length || 0}.`;
  
  const aiResponse = await generateText({
    model: openai('gpt-4o-mini'),
    prompt: aiPrompt,
    system: 'You are an automated, zero-trust security auditor. Provide brief, factual summaries without exposing PII.',
  });

  // Step 5: Render the verified, contextually secure component view
  return (
    <div className="p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl">
      <h1 className="text-2xl font-bold mb-4">Zero-Trust Enforced Dashboard</h1>
      <div className="mb-4 p-3 bg-slate-800 rounded border border-slate-700 text-sm">
        <p><strong>Verified User:</strong> {trustContext.userId}</p>
        <p><strong>Device Posture Score:</strong> {trustContext.devicePostureScore}/100</p>
        <p><strong>Clearance Level:</strong> {trustContext.clearanceLevel}</p>
      </div>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Micro-Segmented Audit Logs</h2>
        <ul className="space-y-2">
          {sensitiveLogs?.map((log) => (
            <li key={log.id} className="p-2 bg-slate-800 rounded text-xs font-mono">
              {log.created_at} - {log.event}
            </li>
          ))}
        </ul>
      </section>

      <section className="p-4 bg-slate-800 rounded border border-slate-700">
        <h2 className="text-lg font-semibold mb-1">AI Security Telemetry Summary</h2>
        <p className="text-sm text-slate-300">{aiResponse.text}</p>
      </section>
    </div>
  );
}
