/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// Custom ValidationError structure to prevent internal path leaks
export class ValidationError extends Error {
  constructor(public readonly issues: z.ZodIssue[]) {
    super('Boundary validation failed: Malformed or unauthorized payload structure.');
    this.name = 'ValidationError';
  }
}

// 1. TelemetryPayloadSchema definition
export const TelemetryPayloadSchema = z.object({
  deviceId: z.string().uuid({ message: 'Invalid device identifier format; must be UUIDv4.' }),
  timestamp: z.number().int().positive({ message: 'Timestamp must be a positive integer representing epoch milliseconds.' }),
  metrics: z.object({
    cpuLoad: z.number().min(0).max(100, { message: 'CPU load must be between 0 and 100.' }),
    memoryUsagePercent: z.number().min(0).max(100, { message: 'Memory usage must be between 0 and 100.' }),
    activeConnections: z.number().int().nonnegative({ message: 'Active connections must be >= 0.' }),
  }),
  securityFlags: z.array(
    z.enum([
      'SECURE_BOOT_ENABLED',
      'ENCRYPTION_ACTIVE',
      'DEBUGGER_DETECTED',
      'ROOT_ACCESS_DETECTED',
    ])
  ),
});

// 2. UserRegistrationSchema definition with password complexity and refinement
const COMMON_WEAK_PATTERNS = ['1234', 'password', 'abcd', '1111', 'qwerty', 'admin'];

export const UserRegistrationSchema = z
  .object({
    email: z.string().email({ message: 'Invalid email format.' }),
    password: z
      .string()
      .min(12, { message: 'Password must be at least 12 characters long.' })
      .regex(/[A-Z]/, { message: 'Password must contain at least one uppercase letter.' })
      .regex(/[a-z]/, { message: 'Password must contain at least one lowercase letter.' })
      .regex(/[0-9]/, { message: 'Password must contain at least one number.' })
      .regex(/[^A-Za-z0-9]/, { message: 'Password must contain at least one special character.' }),
    metadata: z.record(z.string()).optional(),
  })
  .refine(
    (data) => {
      const lowerPassword = data.password.toLowerCase();
      // Check for common weak patterns or sequential repeating strings
      for (const pattern of COMMON_WEAK_PATTERNS) {
        if (lowerPassword.includes(pattern)) {
          return false;
        }
      }
      return true;
    },
    {
      message: 'Password contains common weak patterns or predictable sequences.',
      path: ['password'],
    }
  );

// 3. validateBoundaryData utility function
export async function validateBoundaryData<T>(
  schema: z.ZodSchema<T>,
  rawData: unknown
): Promise<T> {
  // .strict() ensures unknown keys trigger validation errors rather than passing silently
  // Alternatively, Zod's parse strips unrecognized properties if configured via schema transforms,
  // but standard .parse() with strict objects prevents mass-assignment injection vectors.
  const result = await schema.safeParseAsync(rawData);

  if (!result.success) {
    // Wrap issues in a structured custom error to sanitize outputs before returning to clients
    throw new ValidationError(result.error.issues);
  }

  return result.data;
}
