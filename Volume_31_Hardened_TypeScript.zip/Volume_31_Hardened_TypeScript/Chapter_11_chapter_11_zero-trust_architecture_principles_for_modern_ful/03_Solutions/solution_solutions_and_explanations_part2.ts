/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import jwt from 'jsonwebtoken';

export interface TokenPayload {
  sub: string;
  iss: string;
  aud: string;
  scopes: string[];
  exp: number;
  iat: number;
}

export class UnauthorizedScopeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnauthorizedScopeError';
  }
}

// 1. Verify incoming cryptographic tokens
export async function verifyIncomingToken(
  token: string,
  publicKey: string
): Promise<TokenPayload> {
  return new Promise((resolve, reject) => {
    jwt.verify(
      token,
      publicKey,
      { algorithms: ['RS256'] },
      (err, decoded) => {
        if (err) {
          return reject(new UnauthorizedScopeError(`Token verification failed: ${err.message}`));
        }
        resolve(decoded as TokenPayload);
      }
    );
  });
}

// 2. Mint down-scoped service-to-service tokens
export function mintDownScopedToken(
  parentPayload: TokenPayload,
  requestedScopes: string[],
  targetAudience: string,
  privateKey: string
): string {
  // Validate that requested scopes are a strict subset of the parent token's scopes
  const hasAllScopes = requestedScopes.every((scope) => parentPayload.scopes.includes(scope));
  
  if (!hasAllScopes) {
    throw new UnauthorizedScopeError(
      `Privilege escalation attempt detected: Requested scopes [${requestedScopes.join(', ')}] exceed parent token capabilities [${parentPayload.scopes.join(', ')}].`
    );
  }

  const now = Math.floor(Date.now() / 1000);
  
  const downScopedPayload: Omit<TokenPayload, 'iat' | 'exp'> = {
    sub: parentPayload.sub,
    iss: 'urn:auth:gateway',
    aud: targetAudience,
    scopes: requestedScopes,
  };

  // Issue a token with a strictly shortened expiration time (e.g., 5 minutes / 300 seconds)
  return jwt.sign(downScopedPayload, privateKey, {
    algorithm: 'RS256',
    expiresIn: '300s',
    notBefore: '0s',
  });
}

// 3. Downstream service middleware for permission enforcement
export function enforceServicePermission(requiredScope: string) {
  return async (req: any, res: any, next: any) => {
    try {
      const authHeader = req.headers['authorization'];
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or malformed authorization header.' });
      }

      const token = authHeader.split(' ')[1];
      // In production, fetch the downstream service trust store public key securely
      const publicKey = req.app.locals.publicKey; 

      const payload = await verifyIncomingToken(token, publicKey);

      if (!payload.scopes.includes(requiredScope)) {
        return res.status(403).json({ error: `Forbidden: Required scope '${requiredScope}' missing from service token.` });
      }

      // Attach verified payload to request context for downstream handlers
      req.auth = payload;
      next();
    } catch (error: any) {
      return res.status(401).json({ error: error.message });
    }
  };
}
