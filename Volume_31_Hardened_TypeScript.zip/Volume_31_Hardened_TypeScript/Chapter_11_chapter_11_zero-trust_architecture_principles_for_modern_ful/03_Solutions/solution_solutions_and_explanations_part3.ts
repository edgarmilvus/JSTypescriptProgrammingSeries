/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export interface RequestContext {
  userId: string;
  userRoles: string[];
  deviceContext: {
    isManagedDevice: boolean;
    deviceComplianceScore: number;
    osVersion: string;
  };
  networkContext: {
    ipAddress: string;
    isVpnActive: boolean;
    geoCoordinates: { latitude: number; longitude: number };
  };
  resourceContext: {
    sensitivityLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    classification: string;
  };
}

export type PolicyDecision = 'ALLOW' | 'DENY' | 'STEP_UP_MFA';

export interface PolicyRule {
  id: string;
  evaluate: (context: RequestContext) => boolean;
  action: PolicyDecision;
}

export class ContextualPolicyEngine {
  private rules: PolicyRule[] = [];

  public addPolicy(rule: PolicyRule): void {
    this.rules.push(rule);
  }

  public async evaluateAccess(
    context: RequestContext
  ): Promise<{ decision: PolicyDecision; triggeredRuleId: string | null }> {
    // Evaluate rules sequentially; implement fail-secure short-circuiting for DENY decisions
    for (const rule of this.rules) {
      const isTriggered = rule.evaluate(context);
      if (isTriggered) {
        // Zero-Trust fail-secure rule: Any matching DENY rule halts evaluation immediately
        if (rule.action === 'DENY') {
          return { decision: 'DENY', triggeredRuleId: rule.id };
        }
        if (rule.action === 'STEP_UP_MFA') {
          return { decision: 'STEP_UP_MFA', triggeredRuleId: rule.id };
        }
      }
    }

    // Default posture if no restriction rules trigger
    return { decision: 'ALLOW', triggeredRuleId: null };
  }
}

// ==========================================
// Concrete Zero-Trust Security Rules Setup
// ==========================================

// Rule 1: Critical Resource Policy
export const CriticalResourceRule: PolicyRule = {
  id: 'RULE-CRITICAL-RESOURCE-POSTURE',
  action: 'DENY',
  evaluate: (ctx) => {
    if (ctx.resourceContext.sensitivityLevel === 'CRITICAL') {
      const isNonCompliant =
        !ctx.deviceContext.isManagedDevice ||
        ctx.deviceContext.deviceComplianceScore < 90 ||
        !ctx.networkContext.isVpnActive;
      return isNonCompliant;
    }
    return false;
  },
};

// Rule 2: High Sensitivity Step-Up Policy
export const HighSensitivityStepUpRule: PolicyRule = {
  id: 'RULE-HIGH-SENSITIVITY-MFA',
  action: 'STEP_UP_MFA',
  evaluate: (ctx) => {
    if (ctx.resourceContext.sensitivityLevel === 'HIGH') {
      const isMarginalCompliance =
        ctx.deviceContext.deviceComplianceScore >= 75 &&
        ctx.deviceContext.deviceComplianceScore <= 89;
      return isMarginalCompliance;
    }
    return false;
  },
};

// Rule 3: Geo-Velocity Check Simulation
export const GeoVelocityCheckRule: PolicyRule = {
  id: 'RULE-GEO-VELOCITY-ANOMALY',
  action: 'DENY',
  evaluate: (ctx) => {
    // Simulated mock geo-velocity check: flag if IP is outside corporate range and impossible travel is detected
    const isCorporateSubnet = ctx.networkContext.ipAddress.startsWith('10.100.');
    if (!isCorporateSubnet && !ctx.networkContext.isVpnActive) {
      // Stub calculation for impossible travel delta
      return true; 
    }
    return false;
  },
};
