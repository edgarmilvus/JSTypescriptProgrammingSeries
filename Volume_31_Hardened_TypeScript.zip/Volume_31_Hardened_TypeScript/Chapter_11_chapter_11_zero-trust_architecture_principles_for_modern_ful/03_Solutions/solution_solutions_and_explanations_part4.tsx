/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback, useRef } from 'react';

export interface ZeroTrustDashboardProps {
  apiEndpoint: string;
  pollingIntervalMs?: number;
  onSessionRevoked: () => void;
}

export type PostureStatus = 'SECURE' | 'DEGRADED' | 'COMPROMISED';

export interface DevicePostureResponse {
  status: PostureStatus;
  complianceScore: number;
  sessionValid: boolean;
  reason?: string;
}

export const ZeroTrustDashboard: React.FC<ZeroTrustDashboardProps> = ({
  apiEndpoint,
  pollingIntervalMs = 30000,
  onSessionRevoked,
}) => {
  const [postureStatus, setPostureStatus] = useState<PostureStatus>('SECURE');
  const [complianceScore, setComplianceScore] = useState<number>(100);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [sessionTimeRemaining, setSessionTimeRemaining] = useState<number>(1800); // 30 mins
  const [compromiseReason, setCompromiseReason] = useState<string | undefined>(undefined);

  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);
  const IDLE_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes

  // Reset idle timer on user interaction
  const resetIdleTimer = useCallback(() => {
    if (isLocked) return;
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    
    idleTimerRef.current = setTimeout(() => {
      setIsLocked(true);
      setCompromiseReason('Session locked due to user inactivity.');
    }, IDLE_TIMEOUT_MS);
  }, [isLocked]);

  useEffect(() => {
    const events = ['mousemove', 'keydown', 'click', 'scroll'];
    events.forEach((event) => window.addEventListener(event, resetIdleTimer));
    resetIdleTimer();

    return () => {
      events.forEach((event) => window.removeEventListener(event, resetIdleTimer));
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [resetIdleTimer]);

  // Continuous background device posture polling hook/effect
  useEffect(() => {
    const controller = new AbortController();

    const pollPosture = async () => {
      try {
        const response = await fetch(`${apiEndpoint}/security/posture`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            // Pass short-lived assertion token instead of static localStorage tokens
            'Authorization': `Bearer ${sessionStorage.getItem('zt_ephemeral_token') || ''}`,
          },
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error('Posture verification endpoint returned an error.');
        }

        const data: DevicePostureResponse = await response.json();

        setComplianceScore(data.complianceScore);

        if (!data.sessionValid || data.status === 'COMPROMISED') {
          setPostureStatus('COMPROMISED');
          setIsLocked(true);
          setCompromiseReason(data.reason || 'Critical security posture violation detected.');
          onSessionRevoked();
        } else if (data.status === 'DEGRADED') {
          setPostureStatus('DEGRADED');
        } else {
          setPostureStatus('SECURE');
        }
      } catch (error: any) {
        if (error.name !== 'AbortError') {
          // Fail-secure: If posture polling fails entirely, assume compromised
          setPostureStatus('COMPROMISED');
          setIsLocked(true);
          setCompromiseReason('Unable to verify device posture with upstream authorization server.');
          onSessionRevoked();
        }
      }
    };

    pollPosture();
    const intervalId = setInterval(pollPosture, pollingIntervalMs);

    return () => {
      clearInterval(intervalId);
      controller.abort();
    };
  }, [apiEndpoint, pollingIntervalMs, onSessionRevoked]);

  return (
    <div className="zero-trust-dashboard" style={{ position: 'relative', minHeight: '400px', padding: '20px' }}>
      {/* Security Status Banner */}
      <div 
        style={{
          padding: '10px 15px',
          marginBottom: '20px',
          borderRadius: '4px',
          backgroundColor: postureStatus === 'SECURE' ? '#d4edda' : postureStatus === 'DEGRADED' ? '#fff3cd' : '#f8d7da',
          color: postureStatus === 'SECURE' ? '#155724' : postureStatus === 'DEGRADED' ? '#856404' : '#721c24',
          border: `1px solid ${postureStatus === 'SECURE' ? '#c3e6cb' : postureStatus === 'DEGRADED' ? '#ffeeba' : '#f5c6cb'}`,
        }}
      >
        <strong>Zero-Trust Posture: {postureStatus}</strong> (Compliance Score: {complianceScore}%)
        {postureStatus === 'DEGRADED' && <span> — Warning: Device compliance is degrading. Please renew security posture.</span>}
      </div>

      <h1>Secure Enterprise Dashboard</h1>
      <p>Authorized session active. Continuous background verification running.</p>

      {/* Lock Overlay Modal for Compromised or Inactive Sessions */}
      {isLocked && (
        <div 
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.85)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            color: '#fff',
            zIndex: 1000,
            padding: '20px',
            textAlign: 'center',
          }}
        >
          <h2>Access Revoked / Session Locked</h2>
          <p style={{ maxWidth: '400px', margin: '10px 0 20px 0', color: '#ff6b6b' }}>
            {compromiseReason || 'Continuous verification failed or session inactivity threshold reached.'}
          </p>
          <button 
            onClick={() => window.location.reload()}
            style={{
              padding: '10px 20px',
              backgroundColor: '#007bff',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            Re-Authenticate with Biometric Passkey
          </button>
        </div>
      )}
    </div>
  );
};
