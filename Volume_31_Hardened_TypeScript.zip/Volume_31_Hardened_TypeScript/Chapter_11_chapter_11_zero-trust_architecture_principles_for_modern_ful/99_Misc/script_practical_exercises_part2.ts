/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import jwt from 'jsonwebtoken';

export interface TokenPayload {
  sub: string;
  iss: string;
  aud: string;
  scopes: string[];
  exp: number;
  iat: number;
}

export class UnauthorizedScopeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnauthorizedScopeError';
  }
}

// ==========================================
// EXERCISE 2: YOUR CODE GOES BELOW
// ==========================================

export async function verifyIncomingToken(
  token: string,
  publicKey: string
): Promise<TokenPayload> {
  // TODO: Implement cryptographic verification and claim validation
  throw new Error('Not implemented');
}

export function mintDownScopedToken(
  parentPayload: TokenPayload,
  requestedScopes: string[],
  targetAudience: string,
  privateKey: string
): string {
  // TODO: Implement subset validation, scope reduction, and token signing
  throw new Error('Not implemented');
}

export function enforceServicePermission(requiredScope: string) {
  // TODO: Return middleware/guard function to check scopes on incoming service requests
  return async (req: any, res: any, next: any) => {
    throw new Error('Not implemented');
  };
}
