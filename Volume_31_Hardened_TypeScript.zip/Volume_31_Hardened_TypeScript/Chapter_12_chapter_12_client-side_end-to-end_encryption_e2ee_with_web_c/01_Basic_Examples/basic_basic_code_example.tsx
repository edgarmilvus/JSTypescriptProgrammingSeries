/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

'use client';

import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize the Supabase Client for browser-side interactions
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Interface representing the encrypted payload structure
 * designed for zero-trust storage.
 */
interface EncryptedPayload {
  ciphertext: string; // Base64 encoded encrypted data
  iv: string;         // Base64 encoded initialization vector
}

export default function SecureNoteEditor() {
  const [noteContent, setNoteContent] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  /**
   * Converts an ArrayBuffer to a Base64 encoded string for safe transport/storage.
   * @param buffer - The raw binary buffer from Web Crypto API.
   * @returns A Base64 string representation.
   */
  const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };

  /**
   * Generates a cryptographically secure AES-GCM 256-bit key on the client.
   * @returns Promise resolving to a CryptoKey instance.
   */
  const generateEncryptionKey = async (): Promise<CryptoKey> => {
    return await window.crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256,
      },
      true, // extractable (can be exported if wrapping keys are used)
      ['encrypt', 'decrypt']
    );
  };

  /**
   * Encrypts plaintext data using AES-GCM and a dynamically generated IV.
   * @param plaintext - The raw string input from the user.
   * @param key - The CryptoKey instance.
   * @returns Promise resolving to an EncryptedPayload object.
   */
  const encryptData = async (plaintext: string, key: CryptoKey): Promise<EncryptedPayload> => {
    // Encode the plaintext string into a UTF-8 Uint8Array
    const encoder = new TextEncoder();
    const encodedData = encoder.encode(plaintext);

    // Generate a cryptographically secure random 12-byte initialization vector (IV)
    const iv = window.crypto.getRandomValues(new Uint8Array(12));

    // Perform the encryption operation via the SubtleCrypto interface
    const encryptedBuffer = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv,
      },
      key,
      encodedData
    );

    return {
      ciphertext: arrayBufferToBase64(encryptedBuffer),
      iv: arrayBufferToBase64(iv.buffer),
    };
  };

  /**
   * Handles the form submission: encrypts locally and uploads ciphertext to Supabase.
   */
  const handleSaveSecureNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent) return;

    setIsProcessing(true);
    setStatusMessage('Generating client-side cryptographic keys...');

    try {
      // 1. Generate a fresh AES-GCM key locally (in a full app, this would be retrieved from IndexedDB)
      const cryptoKey = await generateEncryptionKey();

      setStatusMessage('Encrypting data locally via Web Crypto API...');
      
      // 2. Encrypt the plaintext note locally
      const { ciphertext, iv } = await encryptData(noteContent, cryptoKey);

      setStatusMessage('Syncing encrypted payload to Supabase database...');

      // 3. Send ONLY ciphertext and IV to the backend. The server never sees plaintext.
      const { error } = await supabase
        .from('secure_notes')
        .insert({
          encrypted_content: ciphertext,
          initialization_vector: iv,
          created_at: new Date().toISOString(),
        });

      if (error) {
        throw new Error(error.message);
      }

      setStatusMessage('Success! Data encrypted locally and stored securely.');
      setNoteContent('');
    } catch (err: any) {
      console.error('Encryption or storage error:', err);
      setStatusMessage(`Error: ${err.message || 'Unknown error occurred'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '40px auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Zero-Trust Client-Side E2EE Editor</h2>
      <p>Your notes are encrypted in your browser before they ever touch our servers.</p>
      
      <form onSubmit={handleSaveSecureNote}>
        <textarea
          rows={6}
          style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
          value={noteContent}
          onChange={(e) => setNoteContent(e.target.value)}
          placeholder="Type your confidential notes here..."
          disabled={isProcessing}
        />
        <br />
        <button 
          type="submit" 
          style={{ padding: '10px 20px', background: '#0070f3', color: '#fff', border: 'none', cursor: 'pointer' }}
          disabled={isProcessing}
        >
          {isProcessing ? 'Processing...' : 'Encrypt & Save Securely'}
        </button>
      </form>

      {statusMessage && (
        <div style={{ marginTop: '20px', padding: '10px', background: '#f4f4f4', borderLeft: '4px solid #0070f3' }}>
          <strong>Status:</strong> {statusMessage}
        </div>
      )}
    </div>
  );
}
