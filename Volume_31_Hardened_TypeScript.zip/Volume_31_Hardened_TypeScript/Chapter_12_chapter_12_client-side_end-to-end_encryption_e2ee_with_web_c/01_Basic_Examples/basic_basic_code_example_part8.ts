/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part8.ts
// Description: Basic Code Example
// ==========================================

  const handleSaveSecureNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent) return;

    setIsProcessing(true);
    setStatusMessage('Generating client-side cryptographic keys...');

    try {
      const cryptoKey = await generateEncryptionKey();

      setStatusMessage('Encrypting data locally via Web Crypto API...');
      const { ciphertext, iv } = await encryptData(noteContent, cryptoKey);

      setStatusMessage('Syncing encrypted payload to Supabase database...');

      const { error } = await supabase
        .from('secure_notes')
        .insert({
          encrypted_content: ciphertext,
          initialization_vector: iv,
          created_at: new Date().toISOString(),
        });

      if (error) {
        throw new Error(error.message);
      }

      setStatusMessage('Success! Data encrypted locally and stored securely.');
      setNoteContent('');
    } catch (err: any) {
      console.error('Encryption or storage error:', err);
      setStatusMessage(`Error: ${err.message || 'Unknown error occurred'}`);
    } finally {
      setIsProcessing(false);
    }
  };
