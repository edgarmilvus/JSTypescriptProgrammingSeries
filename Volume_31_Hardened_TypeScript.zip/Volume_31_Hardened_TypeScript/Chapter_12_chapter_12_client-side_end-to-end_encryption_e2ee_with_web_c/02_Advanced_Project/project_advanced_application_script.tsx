/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useEffect } from 'react';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface StoredKeyMaterial {
  salt: ArrayBuffer;
  iv: ArrayBuffer;
  wrappedKey: ArrayBuffer;
  publicKey: JsonWebKey;
}

interface EncryptionResult {
  ciphertext: string; // Base64 encoded
  iv: string;         // Base64 encoded
}

// ============================================================================
// INDEXEDDB STORAGE UTILITIES
// ============================================================================

const DB_NAME = 'ZeroTrustE2EE';
const STORE_NAME = 'crypto_keys';
const KEY_RECORD_ID = 'user_master_keys';

/**
 * Opens and initializes the IndexedDB store for secure local key storage.
 */
function openCryptoDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

/**
 * Persists wrapped key material and salts to local IndexedDB.
 */
async function saveKeyMaterialToIDB(data: StoredKeyMaterial): Promise<void> {
  const db = await openCryptoDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(data, KEY_RECORD_ID);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

/**
 * Retrieves persisted key material from local IndexedDB.
 */
async function getKeyMaterialFromIDB(): Promise<StoredKeyMaterial | undefined> {
  const db = await openCryptoDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(KEY_RECORD_ID);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

// ============================================================================
// CRYPTOGRAPHIC CORE ENGINE (Web Crypto API)
// ============================================================================

/**
 * Derives a robust AES-GCM key from a user passphrase using PBKDF2.
 */
async function deriveKeyFromPassphrase(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 100_000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['wrapKey', 'unwrapKey']
  );
}

/**
 * Generates a fresh RSA-OAEP key pair and AES-GCM master key, wrapping the
 * private RSA key with the derived passphrase key for safe local storage.
 */
export async function initializeCryptoVault(passphrase: string): Promise<JsonWebKey> {
  // 1. Generate an RSA-OAEP key pair for asymmetric operations & signing
  const rsaKeyPair = await window.crypto.subtle.generateKey(
    {
      name: 'RSA-OAEP',
      modulusLength: 4096,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: 'SHA-256',
    },
    true, // Extractable so we can wrap it
    ['encrypt', 'decrypt']
  );

  // 2. Generate a random salt and IV for key wrapping
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  // 3. Derive wrapping key from user passphrase
  const wrappingKey = await deriveKeyFromPassphrase(passphrase, salt);

  // 4. Wrap the private RSA key
  const wrappedKey = await window.crypto.subtle.wrapKey(
    'jwk',
    rsaKeyPair.privateKey,
    wrappingKey,
    {
      name: 'AES-GCM',
      iv: iv,
    }
  );

  // 5. Export public key to share with peers / server
  const publicKeyJwk = await window.crypto.subtle.exportKey('jwk', rsaKeyPair.publicKey);

  // 6. Save payload to IndexedDB
  await saveKeyMaterialToIDB({
    salt: salt.buffer,
    iv: iv.buffer,
    wrappedKey: wrappedKey,
    publicKey: publicKeyJwk,
  });

  return publicKeyJwk;
}

/**
 * Encrypts a plaintext string using an ephemeral AES-GCM key, returning
 * the ciphertext and IV encoded as Base64 strings.
 */
export async function encryptPayload(plaintext: string): Promise<EncryptionResult> {
  // 1. Generate an ephemeral AES-GCM 256-bit key for this specific payload
  const aesKey = await window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );

  // 2. Generate a unique 96-bit initialization vector (IV)
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const encodedData = new TextEncoder().encode(plaintext);

  // 3. Encrypt the payload
  const ciphertextBuffer = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    aesKey,
    encodedData
  );

  // 4. Convert buffers to Base64 for easy JSON transport
  const base64Ciphertext = btoa(String.fromCharCode(...new Uint8Array(ciphertextBuffer)));
  const base64Iv = btoa(String.fromCharCode(...iv));

  return {
    ciphertext: base64Ciphertext,
    iv: base64Iv,
  };
}

// ============================================================================
// REACT COMPONENT: Zero-Trust Data Vault
// ============================================================================

export default function ZeroTrustVaultComponent() {
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [passphrase, setPassphrase] = useState<string>('');
  const [plaintextInput, setPlaintextInput] = useState<string>('');
  const [encryptedOutput, setEncryptedOutput] = useState<EncryptionResult | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Checking local vault...');

  useEffect(() => {
    getKeyMaterialFromIDB()
      .then((mat) => {
        if (mat) {
          setIsInitialized(true);
          setStatusMessage('Vault loaded successfully from IndexedDB.');
        } else {
          setStatusMessage('No local vault found. Please initialize.');
        }
      })
      .catch((err) => {
        setStatusMessage(`Error loading vault: ${err.message}`);
      });
  }, []);

  const handleInitialize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passphrase) return;
    try {
      setStatusMessage('Generating 4096-bit RSA keys and deriving vault parameters...');
      await initializeCryptoVault(passphrase);
      setIsInitialized(true);
      setStatusMessage('Vault successfully initialized and keys securely stored locally.');
    } catch (err: any) {
      setStatusMessage(`Initialization failed: ${err.message}`);
    }
  };

  const handleEncrypt = async () => {
    if (!plaintextInput) return;
    try {
      setStatusMessage('Encrypting payload client-side via Web Crypto API...');
      const result = await encryptPayload(plaintextInput);
      setEncryptedOutput(result);
      setStatusMessage('Encryption complete. Plaintext never left memory unencrypted.');
    } catch (err: any) {
      setStatusMessage(`Encryption error: ${err.message}`);
    }
  };

  return (
    <div style={{ padding: '24px', maxWidth: '600px', margin: 'auto', fontFamily: 'sans-serif' }}>
      <h2>Client-Side Zero-Trust E2EE Vault</h2>
      <p style={{ background: '#f4f4f4', padding: '12px', borderLeft: '4px solid #0070f3' }}>
        Status: <strong>{statusMessage}</strong>
      </p>

      {!isInitialized ? (
        <form onSubmit={handleInitialize} style={{ marginTop: '20px' }}>
          <h3>Step 1: Initialize Client Cryptographic Vault</h3>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', marginBottom: '4px' }}>Master Passphrase:</label>
            <input
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              placeholder="Enter strong passphrase..."
              style={{ width: '100%', padding: '8px' }}
              required
            />
          </div>
          <button type="submit" style={{ padding: '10px 16px', background: '#0070f3', color: '#fff', border: 'none' }}>
            Initialize Vault
          </button>
        </form>
      ) : (
        <div style={{ marginTop: '20px' }}>
          <h3>Step 2: Encrypt Sensitive Data Client-Side</h3>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', marginBottom: '4px' }}>Sensitive Plaintext:</label>
            <textarea
              value={plaintextInput}
              onChange={(e) => setPlaintextInput(e.target.value)}
              placeholder="Type sensitive notes, health records, or tokens here..."
              rows={4}
              style={{ width: '100%', padding: '8px' }}
            />
          </div>
          <button
            onClick={handleEncrypt}
            style={{ padding: '10px 16px', background: '#10b981', color: '#fff', border: 'none' }}
          >
            Encrypt Payload Locally
          </button>

          {encryptedOutput && (
            <div style={{ marginTop: '20px', background: '#1e293b', color: '#f8fafc', padding: '16px', borderRadius: '6px' }}>
              <h4>Zero-Trust Transmission Payload (Safe for Server):</h4>
              <p style={{ wordBreak: 'break-all', fontSize: '12px' }}>
                <strong>Ciphertext:</strong> {encryptedOutput.ciphertext}
              </p>
              <p style={{ wordBreak: 'break-all', fontSize: '12px' }}>
                <strong>IV:</strong> {encryptedOutput.iv}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
