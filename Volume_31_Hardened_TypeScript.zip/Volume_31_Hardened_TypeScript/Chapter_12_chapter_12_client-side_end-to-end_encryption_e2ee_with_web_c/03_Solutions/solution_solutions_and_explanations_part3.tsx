/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, ChangeEvent, FormEvent } from 'react';

export interface E2EEMessageComposerProps {
  encryptionKey: CryptoKey;
  onSendEncryptedPayload: (payload: { ciphertext: ArrayBuffer; iv: Uint8Array }) => Promise<void>;
}

export const E2EEMessageComposer: React.FC<E2EEMessageComposerProps> = ({
  encryptionKey,
  onSendEncryptedPayload,
}) => {
  const [plaintext, setPlaintext] = useState<string>('');
  const [isEncrypting, setIsEncrypting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setPlaintext(e.target.value);
    if (error) setError(null);
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!plaintext.trim()) {
      setError('Message cannot be empty.');
      return;
    }

    setIsEncrypting(true);
    setError(null);

    try {
      // Generate a cryptographically secure random 12-byte IV for AES-GCM
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const encodedMessage = new TextEncoder().encode(plaintext);

      // Perform local client-side encryption
      const ciphertext = await window.crypto.subtle.encrypt(
        {
          name: 'AES-GCM',
          iv: iv,
        },
        encryptionKey,
        encodedMessage
      );

      // Transmit the encrypted payload to the parent handler
      await onSendEncryptedPayload({ ciphertext, iv });
      
      // Clear plaintext input after successful encryption and dispatch
      setPlaintext('');
    } catch (err) {
      setError('Encryption failed. Please verify your session key and try again.');
    } finally {
      setIsEncrypting(false);
    }
  };

  return (
    <div className="e2ee-composer" style={{ padding: '1rem', maxWidth: '500px' }}>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="secret-message" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
            Secret Message (E2EE)
          </label>
          <textarea
            id="secret-message"
            value={plaintext}
            onChange={handleInputChange}
            rows={4}
            style={{ width: '100%', padding: '0.5rem', resize: 'vertical' }}
            placeholder="Type your confidential message here..."
            disabled={isEncrypting}
          />
        </div>

        {error && <div style={{ color: 'red', marginBottom: '1rem' }}>{error}</div>}

        <button 
          type="submit" 
          disabled={isEncrypting || !plaintext.trim()}
          style={{ padding: '0.5rem 1rem', cursor: 'pointer' }}
        >
          {isEncrypting ? 'Encrypting...' : 'Encrypt & Send'}
        </button>
      </form>
    </div>
  );
};
