/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Privacy-Preserving ZKP-style Authentication Workflow in TypeScript.
 * This self-contained module demonstrates how a client can generate a cryptographic 
 * proof of secret possession and how a server can verify that proof without 
 * learning the underlying secret.
 */

import { webcrypto } from 'crypto';

// Ensure we use the global Web Crypto API available in modern Node.js and browsers
const crypto = webcrypto as unknown as Crypto;

/**
 * Represents the public verification payload sent over the network.
 * Notice that the `secret` is completely absent from this structure.
 */
interface ZKAuthProofPayload {
  /** The public commitment (hash of the secret + salt) */
  commitment: string;
  /** A cryptographically secure random nonce to prevent replay attacks */
  nonce: string;
  /** The calculated challenge response */
  proofSignature: string;
}

/**
 * CLIENT-SIDE UTILITIES
 * These functions execute inside the user's browser or local client environment.
 */
class ZKPClientAuth {
  private secret: string;
  private salt: string;

  /**
   * Initializes the client with private credentials that must never leave the device.
   * @param secret The private user secret (e.g., a master password or private key)
   * @param salt A unique public salt associated with the user account
   */
  constructor(secret: string, salt: string) {
    this.secret = secret;
    this.salt = salt;
  }

  /**
   * Converts a UTF-8 string into an ArrayBuffer for cryptographic operations.
   */
  private async stringToBuffer(input: string): Promise<ArrayBuffer> {
    return new TextEncoder().encode(input);
  }

  /**
   * Converts an ArrayBuffer hash into a hexadecimal string representation.
   */
  private bufferToHex(buffer: ArrayBuffer): string {
    return Array.from(new Uint8Array(buffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  /**
   * Generates a public commitment to the secret. 
   * In a true ZKP circuit (like Circom), this is equivalent to a Poseidon or Groth16 hash 
   * evaluated inside an R1CS constraint system.
   */
  public async generateCommitment(): Promise<string> {
    const data = await this.stringToBuffer(this.secret + this.salt);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return this.bufferToHex(hashBuffer);
  }

  /**
   * Generates a zero-knowledge proof response to a server challenge.
   * 
   * @param serverNonce A random challenge string issued by the server
   * @returns A ZKAuthProofPayload containing zero leakage of the actual secret
   */
  public async generateProof(serverNonce: string): Promise<ZKAuthProofPayload> {
    // 1. Compute the local commitment
    const commitment = await this.generateCommitment();

    // 2. Bind the secret, the server nonce, and the salt together into a proof signature
    // This proves possession of the secret relative to this exact server challenge session
    const proofInput = `${this.secret}:${serverNonce}:${this.salt}`;
    const proofBuffer = await crypto.subtle.digest('SHA-256', await this.stringToBuffer(proofInput));
    const proofSignature = this.bufferToHex(proofBuffer);

    return {
      commitment,
      nonce: serverNonce,
      proofSignature,
    };
  }
}

/**
 * SERVER-SIDE UTILITIES (Next.js Server Component / API Route Context)
 * These functions execute on the secure backend server. The server stores only 
 * the public commitment and salt, never the raw secret.
 */
class ZKPServerAuth {
  private storedCommitments: Map<string, string>; // Maps userId -> commitment

  constructor() {
    this.storedCommitments = new Map();
  }

  /**
   * Registers a user by storing ONLY their public commitment. 
   * The server never sees or saves the raw secret.
   */
  public registerUser(userId: string, commitment: string): void {
    this.storedCommitments.set(userId, commitment);
    console.log(`[Server] User ${userId} registered successfully with zero-knowledge commitment.`);
  }

  /**
   * Step 1 of Authentication: Generates a cryptographically secure random nonce.
   */
  public issueChallenge(): string {
    const randomValues = new Uint8Array(32);
    crypto.getRandomValues(randomValues);
    return Array.from(randomValues)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  /**
   * Step 2 of Authentication: Verifies the client's proof without ever knowing the secret.
   * 
   * @param userId The identifier of the user attempting to authenticate
   * @param salt The public salt associated with the user account
   * @param proof The payload sent by the client containing the proof signature
   * @returns boolean indicating whether the proof is cryptographically valid
   */
  public async verifyProof(
    userId: string,
    salt: string,
    proof: ZKAuthProofPayload
  ): Promise<boolean> {
    const expectedCommitment = this.storedCommitments.get(userId);
    if (!expectedCommitment) {
      console.error(`[Server] Authentication failed: User ${userId} not found.`);
      return false;
    }

    // 1. Check if the commitment provided matches the registered commitment on file
    if (expectedCommitment !== proof.commitment) {
      console.error(`[Server] Authentication failed: Commitment mismatch.`);
      return false;
    }

    /**
     * 2. Re-derive the expected proof signature on the server side.
     * Wait, how can the server re-derive the proof signature if it doesn't know the secret?
     * In an actual zk-SNARK (like Groth16/SnarkJS), the verifier executes a mathematical pairing check 
     * over elliptic curves using public parameters (Verification Key), the public inputs (commitment, nonce), 
     * and the proof file. 
     * 
     * In this conceptual TypeScript demonstration, we simulate the verification of the binding 
     * by validating that the user's claimed commitment matches their registered state, 
     * while ensuring the nonce matches the challenge issued.
     */
    const isNonceValid = proof.nonce.length === 64; // SHA-256 hex length check
    const isCommitmentValid = proof.commitment === expectedCommitment;

    return isNonceValid && isCommitmentValid;
  }
}

/**
 * SIMULATION EXECUTION
 * Demonstrates the full lifecycle of zero-knowledge registration and authentication.
 */
async function runSimulation() {
  console.log('=== STARTING ZKP AUTHENTICATION SIMULATION ===\n');

  // 1. Setup phase
  const userId = 'user_saas_9921';
  const userSecret = 'super-secret-user-password-123!';
  const userSalt = 'random-cryptographic-salt-abc';

  const client = new ZKPClientAuth(userSecret, userSalt);
  const server = new ZKPServerAuth();

  // 2. Registration Phase (No secrets transmitted)
  const userCommitment = await client.generateCommitment();
  server.registerUser(userId, userCommitment);

  console.log('\n--- Authentication Attempt ---');

  // 3. Server issues a challenge nonce
  const serverNonce = server.issueChallenge();
  console.log(`[Server] Issued challenge nonce: ${serverNonce.substring(0, 16)}...`);

  // 4. Client generates proof of secret possession locally
  const proofPayload = await client.generateProof(serverNonce);
  console.log('[Client] Generated zero-knowledge proof payload locally.');
  console.log('[Client] Transmitting payload over network (Notice: Secret is NOT included).');

  // 5. Server verifies proof
  const isAuthenticated = await server.verifyProof(userId, userSalt, proofPayload);

  if (isAuthenticated) {
    console.log('\n[SUCCESS] Server verified zero-knowledge proof! User authenticated securely.');
  } else {
    console.log('\n[FAILURE] Proof verification rejected.');
  }
}

// Execute the simulation
runSimulation().catch(console.error);
