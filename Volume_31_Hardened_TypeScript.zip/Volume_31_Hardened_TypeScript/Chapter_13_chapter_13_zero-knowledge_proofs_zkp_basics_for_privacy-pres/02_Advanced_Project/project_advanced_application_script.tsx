/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// ============================================================================
// FILE: app/api/verify-zkp/route.ts
// ============================================================================
/**
 * @fileoverview Server-side ZKP Verification API Route (Next.js App Router).
 * This Server Component / API Route handles verification of Groth16 zero-knowledge
 * proofs generated on the client side using SnarkJS.
 */

import { NextResponse } from 'next/server';
import * as snarkjs from 'snarkjs';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Interface representing the incoming ZKP proof payload from the client.
 */
interface ZKPVerificationRequest {
  proof: snarkjs.Groth16Proof;
  publicSignals: snarkjs.PublicSignals;
}

/**
 * Handles POST requests containing the ZKP proof and public signals.
 * Verifies the proof against the compiled verification key.
 * 
 * @param request - Incoming HTTP request containing proof and public signals.
 * @returns JSON response indicating proof validity.
 */
export async function POST(request: Request) {
  try {
    const body: ZKPVerificationRequest = await request.json();
    const { proof, publicSignals } = body;

    // Validate that proof and public signals exist in the payload
    if (!proof || !publicSignals) {
      return NextResponse.json(
        { success: false, error: 'Missing proof or public signals in request body.' },
        { status: 400 }
      );
    }

    // Resolve paths to the verification key stored on the server
    const vKeyPath = path.join(process.cwd(), 'public', 'zkp', 'verification_key.json');
    
    if (!fs.existsSync(vKeyPath)) {
      return NextResponse.json(
        { success: false, error: 'Server configuration error: Verification key not found.' },
        { status: 500 }
      );
    }

    const verificationKey = JSON.parse(fs.readFileSync(vKeyPath, 'utf8'));

    // Perform cryptographic verification using SnarkJS
    const isValid = await snarkjs.groth16.verify(verificationKey, publicSignals, proof);

    if (isValid) {
      // Proof is valid; proceed with issuing a session, token, or granting resource access
      return NextResponse.json({
        success: true,
        message: 'Zero-Knowledge Proof verified successfully. Access granted.',
        publicSignals,
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Invalid Zero-Knowledge Proof.' },
        { status: 401 }
      );
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown verification error';
    return NextResponse.json(
      { success: false, error: errorMessage },
      { status: 500 }
    );
  }
}

// ============================================================================
// FILE: app/auth/zkp-client.tsx
// ============================================================================
/**
 * @fileoverview Client-side ZKP Generation Hook and Component.
 * Executes the WebAssembly (Wasm) witness generator and Groth16 prover directly
 * within the user's browser, ensuring absolute privacy of secret inputs.
 */

'use client';

import React, { useState } from 'react';
// @ts-ignore - snarkjs types may require explicit declaration depending on project setup
import * as snarkjs from 'snarkjs';

export default function ZKPAuthComponent() {
  const [secretInput, setSecretInput] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  /**
   * Generates a Zero-Knowledge Proof locally in the browser and submits it
   * to the Next.js backend API for verification.
   */
  const handleGenerateAndVerifyProof = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusMessage('Generating local witness and zero-knowledge proof...');

    try {
      // Define paths to client-accessible public ZKP artifacts
      const wasmPath = '/zkp/auth_js/auth.wasm';
      const zkeyPath = '/zkp/auth_final.zkey';

      // Inputs passed to the circuit (secretInput is private, nullifier/target is public)
      const inputValues = {
        secret: secretInput,
        targetHash: '1234567890', // Example public expected commitment
      };

      // Generate the Groth16 proof and public signals using client-side Wasm
      const { proof, publicSignals } = await snarkjs.groth16.fullProve(
        inputValues,
        wasmPath,
        zkeyPath
      );

      setStatusMessage('Proof generated successfully! Submitting to server for validation...');

      // Transmit proof and public signals to the Next.js API route
      const response = await fetch('/api/verify-zkp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proof, publicSignals }),
      });

      const result = await response.json();

      if (result.success) {
        setStatusMessage(`Success: ${result.message}`);
      } else {
        setStatusMessage(`Verification Failed: ${result.error}`);
      }
    } catch (err: unknown) {
      const errMessage = err instanceof Error ? err.message : 'Error generating ZKP';
      setStatusMessage(`Error: ${errMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md border border-gray-200 mt-10">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Zero-Knowledge Authentication</h2>
      <form onSubmit={handleGenerateAndVerifyProof} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Private Secret Credential:
          </label>
          <input
            type="password"
            value={secretInput}
            onChange={(e) => setSecretInput(e.target.value)}
            placeholder="Enter your secret value..."
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition disabled:bg-gray-400"
        >
          {isLoading ? 'Processing ZKP...' : 'Authenticate Privately'}
        </button>
      </form>
      {statusMessage && (
        <div className="mt-4 p-3 bg-gray-50 border border-gray-200 rounded-md text-sm text-gray-700">
          {statusMessage}
        </div>
      )}
    </div>
  );
}
