/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// ==========================================
// File: circuits/age_verification.circom (Circuit Specification Template)
// ==========================================
/*
pragma circom 2.1.6;

include "../node_modules/circomlib/circuits/comparators.circom";

template AgeVerification() {
    // Private Inputs
    signal input birthYear;
    signal input currentYear;

    // Public Inputs
    signal input minimumAge;

    // Internal Signals & Constraints
    signal age;
    age <== currentYear - birthYear;

    // Use GreaterEqThan component from circomlib to securely constrain age >= minimumAge
    // 8 bits is sufficient for age values (0-255)
    component gte = GreaterEqThan(8);
    gte.in[0] <== age;
    gte.in[1] <== minimumAge;

    // Assert that the output of GreaterEqThan is strictly 1 (true)
    gte.out === 1;
}

component main {public [minimumAge]} = AgeVerification();
*/

// ==========================================
// File: generate-proof.ts
// ==========================================
import * as snarkjs from 'snarkjs';
import * as path from 'path';
import * as fs from 'fs';

interface ProofGenerationResult {
  proof: snarkjs.Groth16Proof;
  publicSignals: snarkjs.PublicSignals;
}

/**
 * Generates a Groth16 zero-knowledge proof for age verification.
 * 
 * @param birthYear User's private birth year
 * @param currentYear Current year (private or public context)
 * @param minimumAge Target minimum age threshold (public input)
 * @returns The generated proof object and public signals array
 */
export async function generateAgeProof(
  birthYear: number,
  currentYear: number,
  minimumAge: number
): Promise<ProofGenerationResult> {
  const artifactsDir = path.join(process.cwd(), 'build');
  const wasmPath = path.join(artifactsDir, 'age_verification_js', 'age_verification.wasm');
  const zkeyPath = path.join(artifactsDir, 'age_verification_final.zkey');

  if (!fs.existsSync(wasmPath) || !fs.existsSync(zkeyPath)) {
    throw new Error(`Circuit compilation artifacts not found at: ${artifactsDir}. Run compilation first.`);
  }

  // Construct circuit inputs matching the input signals in the Circom spec
  const circuitInputs = {
    birthYear: birthYear.toString(),
    currentYear: currentYear.toString(),
    minimumAge: minimumAge.toString(),
  };

  try {
    // Generate the Groth16 proof and public signals using SnarkJS
    const { proof, publicSignals } = await snarkjs.groth16.fullProve(
      circuitInputs,
      wasmPath,
      zkeyPath
    );

    return { proof, publicSignals };
  } catch (error: unknown) {
    if (error instanceof Error) {
      throw new Error(`Failed to generate ZK proof: ${error.message}`);
    }
    throw new Error('An unknown cryptographic error occurred during witness generation.');
  }
}

// Execution runner example
if (require.main === module) {
  generateAgeProof(1995, 2026, 18)
    .then(({ proof, publicSignals }) => {
      console.log('Proof generated successfully:');
      console.log(JSON.stringify(proof, null, 2));
      console.log('Public Signals:', publicSignals);
    })
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
