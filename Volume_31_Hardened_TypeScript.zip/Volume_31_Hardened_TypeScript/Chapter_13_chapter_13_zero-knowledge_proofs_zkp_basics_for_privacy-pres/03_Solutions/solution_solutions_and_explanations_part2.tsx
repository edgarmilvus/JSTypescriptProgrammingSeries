/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// ==========================================
// File: actions/verify-proof.ts
// ==========================================
'use server';

import * as snarkjs from 'snarkjs';
import path from 'path';
import fs from 'fs';

// Strict typing for incoming Groth16 proof payloads
export interface Groth16ProofPayload {
  pi_a: string[];
  pi_b: string[][];
  pi_c: string[];
  protocol: string;
  curve: string;
}

export interface VerificationResponse {
  success: boolean;
  message: string;
}

// Immutable path configuration to prevent path-traversal vulnerabilities
const VKEY_PATH = path.join(process.cwd(), 'config', 'verification_key.json');

// In-memory cache for the verification key to minimize disk I/O latency
let cachedVKey: any = null;

function loadVerificationKey() {
  if (!cachedVKey) {
    if (!fs.existsSync(VKEY_PATH)) {
      throw new Error('Critical Error: Verification key is missing from the secure server path.');
    }
    const fileContent = fs.readFileSync(VKEY_PATH, 'utf-8');
    cachedVKey = JSON.parse(fileContent);
  }
  return cachedVKey;
}

/**
 * Server Action to verify zero-knowledge proofs from untrusted client payloads.
 */
export async function verifyZkProof(
  proof: Groth16ProofPayload,
  publicSignals: string[]
): Promise<VerificationResponse> {
  try {
    const vKey = loadVerificationKey();

    // Execute cryptographic verification
    const isValid = await snarkjs.groth16.verify(vKey, publicSignals, proof);

    if (!isValid) {
      return { success: false, message: 'Invalid zero-knowledge proof verification failed.' };
    }

    return { success: true, message: 'Proof verified successfully.' };
  } catch (error: unknown) {
    console.error('ZKP Server Verification Error:', error);
    return { success: false, message: 'Internal server error occurred during cryptographic validation.' };
  }
}

// ==========================================
// File: components/VerificationDashboard.tsx
// ==========================================
import React from 'react';
import fs from 'fs';
import path from 'path';

/**
 * React Server Component that validates the presence of global verification artifacts
 * and renders the operational status of the ZK verifier service.
 */
export async function VerificationDashboard() {
  const vKeyPath = path.join(process.cwd(), 'config', 'verification_key.json');
  const isServiceOperational = fs.existsSync(vKeyPath);

  return (
    <div className="p-6 max-w-xl mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold text-gray-900">ZK Verifier Service Status</h2>
      <div className="flex items-center space-x-3">
        <span
          className={`h-4 w-4 rounded-full ${
            isServiceOperational ? 'bg-green-500 animate-pulse' : 'bg-red-500'
          }`}
        />
        <span className="text-sm font-medium text-gray-700">
          {isServiceOperational
            ? 'Global Verifier Service is Online and Operational'
            : 'Service Degraded: Verification Key Missing'}
        </span>
      </div>
      <p className="text-xs text-gray-500">
        All client submissions are cryptographically validated against pre-compiled Groth16 keys.
      </p>
    </div>
  );
}

export default VerificationDashboard;
