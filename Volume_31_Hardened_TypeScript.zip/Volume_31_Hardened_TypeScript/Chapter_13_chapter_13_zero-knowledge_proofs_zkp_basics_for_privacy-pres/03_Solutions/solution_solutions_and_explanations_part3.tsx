/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ==========================================
// File: components/ZkProofGenerator.tsx
// ==========================================
'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import * as snarkjs from 'snarkjs';

interface ZkProofGeneratorProps {
  baseUrl: string; // Base URL where .wasm and .zkey files are hosted publicly
}

export function ZkProofGenerator({ baseUrl }: { baseUrl: string }) {
  const [birthYear, setBirthYear] = useState<string>('1995');
  const [currentYear, setCurrentYear] = useState<string>('2026');
  const [minimumAge, setMinimumAge] = useState<string>('18');
  
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [proofResult, setProofResult] = useState<{ proof: any; publicSignals: any } | null>(null);

  const [isReady, setIsReady] = useState<boolean>(false);
  const isMountedRef = useRef<boolean>(true);

  // Safe async initialization hook preventing race conditions
  useEffect(() => {
    isMountedRef.current = true;
    let isCancelled = false;

    async function preloadArtifacts() {
      try {
        const res = await fetch(`${baseUrl}/age_verification.wasm`);
        if (!res.ok) throw new Error('Failed to fetch WASM asset.');
        if (!isCancelled && isMountedRef.current) {
          setIsReady(true);
        }
      } catch (err: any) {
        if (!isCancelled && isMountedRef.current) {
          setError(`Initialization failed: ${err.message}`);
        }
      }
    }

    preloadArtifacts();

    return () => {
      isCancelled = true;
      isMountedRef.current = false;
    };
  }, [baseUrl]);

  const handleGenerateProof = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isReady || loading) return;

    setLoading(true);
    setError(null);

    try {
      const inputs = {
        birthYear: Number(birthYear),
        currentYear: Number(currentYear),
        minimumAge: Number(minimumAge),
      };

      const wasmUrl = `${baseUrl}/age_verification.wasm`;
      const zkeyUrl = `${baseUrl}/age_verification_final.zkey`;

      const { proof, publicSignals } = await snarkjs.groth16.fullProve(
        inputs,
        wasmUrl,
        zkeyUrl
      );

      if (isMountedRef.current) {
        setProofResult({ proof, publicSignals });
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        setError(`Proof generation failed: ${err.message || 'Constraint violation check failed.'}`);
      }
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [isReady, loading, birthYear, currentYear, minimumAge, baseUrl]);

  return (
    <div className="max-w-lg mx-auto p-6 bg-white shadow-lg rounded-xl">
      <h2 className="text-2xl font-semibold mb-4 text-slate-800">Browser ZK Proof Generator</h2>
      
      <form onSubmit={handleGenerateProof} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-600">Birth Year (Private):</label>
          <input
            type="number"
            value={birthYear}
            onChange={(e) => setBirthYear(e.target.value)}
            className="mt-1 block w-full p-2 border border-slate-300 rounded-md"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-600">Current Year:</label>
          <input
            type="number"
            value={currentYear}
            onChange={(e) => setCurrentYear(e.target.value)}
            className="mt-1 block w-full p-2 border border-slate-300 rounded-md"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-600">Minimum Age (Public):</label>
          <input
            type="number"
            value={minimumAge}
            onChange={(e) => setMinimumAge(e.target.value)}
            className="mt-1 block w-full p-2 border border-slate-300 rounded-md"
            required
          />
        </div>

        <button
          type="submit"
          disabled={!isReady || loading}
          className={`w-full py-2 px-4 rounded-md font-medium text-white ${
            !isReady || loading ? 'bg-slate-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'
          }`}
        >
          {loading ? 'Generating Proof...' : isReady ? 'Generate Cryptographic Proof' : 'Loading Assets...'}
        </button>
      </form>

      {error && <div className="mt-4 p-3 bg-red-100 text-red-700 text-sm rounded-md">{error}</div>}

      {proofResult && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-slate-800 mb-2">Generated Proof Output:</h3>
          <pre className="p-4 bg-slate-900 text-emerald-400 text-xs rounded-md overflow-x-auto max-h-60">
            {JSON.stringify(proofResult, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}

export default ZkProofGenerator;
