/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ==========================================
// File: validate-circuit-supply-chain.ts
// ==========================================
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

interface ManifestEntry {
  filename: string;
  sha256: string;
}

interface CircuitManifest {
  version: string;
  artifacts: ManifestEntry[];
}

/**
 * Computes the SHA-256 cryptographic hash of a file using streams to prevent out-of-memory errors.
 */
function computeFileHashStream(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);

    stream.on('error', (err) => reject(err));
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

async function validateSupplyChain(): Promise<void> {
  const rootDir = process.cwd();
  const manifestPath = path.join(rootDir, 'config', 'circuit-manifest.json');

  if (!fs.existsSync(manifestPath)) {
    console.error(`[Supply Chain Error] Manifest file missing at: ${manifestPath}`);
    process.exit(1);
  }

  const manifestContent = fs.readFileSync(manifestPath, 'utf-8');
  let manifest: CircuitManifest;

  try {
    manifest = JSON.parse(manifestContent);
  } catch (err) {
    console.error('[Supply Chain Error] Failed to parse circuit-manifest.json as valid JSON.');
    process.exit(1);
  }

  console.log(`[Supply Chain Verification] Validating ${manifest.artifacts.length} compilation artifacts...`);

  for (const artifact of manifest.artifacts) {
    const artifactPath = path.join(rootDir, 'build', artifact.filename);

    if (!fs.existsSync(artifactPath)) {
      console.error(`[Integrity Failure] Missing required artifact: ${artifact.filename}`);
      process.exit(1);
    }

    try {
      const computedHash = await computeFileHashStream(artifactPath);

      if (computedHash !== artifact.sha256.toLowerCase()) {
        console.error(`[SECURITY ALERT] Hash mismatch detected for artifact: ${artifact.filename}!`);
        console.error(`  Expected: ${artifact.sha256}`);
        console.error(`  Actual:   ${computedHash}`);
        process.exit(1);
      }

      console.log(`[Verified] ${artifact.filename} matches expected SHA-256 hash.`);
    } catch (err: any) {
      console.error(`[Error] Failed to read artifact ${artifact.filename}: ${err.message}`);
      process.exit(1);
    }
  }

  console.log('[Success] All circuit compilation artifacts verified successfully.');
}

// Execute build validation
if (require.main === module) {
  validateSupplyChain().catch((err) => {
    console.error('Unhandled verification error:', err);
    process.exit(1);
  });
}
