/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// Define unique brand symbols to enforce strict type distinction at compile time
declare const __brand: unique symbol;

export type BrandedString<TBrand extends string> = string & {
    [__brand]: TBrand;
};

// Distinct data states in our application lifecycle
export type RawUserInput = BrandedString<'RawUserInput'>;
export type SanitizedHtml = BrandedString<'SanitizedHtml'>;
export type SafeUrl = BrandedString<'SafeUrl'>;

/**
 * Factory function to cast raw incoming HTTP or DOM input into a branded RawUserInput type.
 * This explicitly marks the data as untrusted at the application boundary.
 */
export function createRawInput(input: string): RawUserInput {
    return input as RawUserInput;
}

/**
 * Context-Aware HTML Sanitizer.
 * In a real production system, this would integrate with a robust underlying parser
 * like DOMPurify, configured with strict allow-lists for tags and attributes.
 */
export function sanitizeHtmlToContext(raw: RawUserInput): SanitizedHtml {
    // Simulate rigorous parsing and sanitization logic
    // Strips dangerous tags (<script>, <iframe>, <object>) and dangerous attributes (onload, onerror)
    const cleaned = raw
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
        .replace(/javascript:/gi, '');

    return cleaned as SanitizedHtml;
}

/**
 * URL Scheme Validator to prevent JavaScript execution via href injection.
 */
export function sanitizeUrl(url: RawUserInput): SafeUrl {
    const trimmed = url.trim().toLowerCase();
    
    // Explicitly reject dangerous execution protocols
    if (
        trimmed.startsWith('javascript:') ||
        trimmed.startsWith('data:') ||
        trimmed.startsWith('vbscript:')
    ) {
        throw new Error('SecurityException: Dangerous URL scheme detected.');
    }

    return url as SafeUrl;
}
