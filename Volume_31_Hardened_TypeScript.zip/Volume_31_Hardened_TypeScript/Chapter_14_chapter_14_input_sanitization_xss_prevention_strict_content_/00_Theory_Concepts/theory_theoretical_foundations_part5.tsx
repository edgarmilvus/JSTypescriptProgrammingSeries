/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.tsx
// Description: Theoretical Foundations
// ==========================================

import React from 'react';
import { SanitizedHtml, SafeUrl } from './sanitizer';

interface SecureCommentProps {
    author: string;
    // Enforcing that the body MUST be pre-sanitized through our branded type pipeline
    sanitizedBody: SanitizedHtml;
    userWebsite: SafeUrl;
}

export const SecureCommentComponent: React.FC<SecureCommentProps> = ({
    author,
    sanitizedBody,
    userWebsite,
}) => {
    return (
        <article className="p-4 border rounded-lg shadow-sm bg-white my-2">
            <header className="flex justify-between items-center mb-2">
                <span className="font-semibold text-gray-800">{author}</span>
                <a 
                    href={userWebsite} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline text-sm"
                >
                    Visit Website
                </a>
            </header>
            
            {/* 
              Using dangerouslySetInnerHTML with explicit type casting 
              guarantees that only SanitizedHtml branded strings can be rendered here.
            */}
            <div 
                className="text-gray-600 text-sm leading-relaxed"
                dangerouslySetInnerHTML={{ __html: sanitizedBody }} 
            />
        </article>
    );
};
