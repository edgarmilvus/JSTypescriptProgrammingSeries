/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.ts
// Description: Theoretical Foundations
// ==========================================

import crypto from 'crypto';

export interface CSPConfig {
    nonce: string;
    headerString: string;
}

/**
 * Generates a cryptographically secure random nonce for each HTTP response
 * and constructs a strict Content Security Policy header.
 */
export function generateContentSecurityPolicy(): CSPConfig {
    // Generate a 128-bit cryptographically secure random buffer and encode as base64
    const nonceBuffer = crypto.randomBytes(16);
    const nonce = nonceBuffer.toString('base64');

    // Construct a strict CSP directive set
    const directives = [
        "default-src 'self'",
        // Allow scripts only from self and matching our cryptographic nonce
        `script-src 'self' 'nonce-${nonce}' https://trusted-cdn.com`,
        // Allow styles from self and trusted UI component libraries
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        // Restrict image sources
        "img-src 'self' data: https:",
        // Restrict font sources
        "font-src 'self' https://fonts.gstatic.com",
        // Restrict connection endpoints (AJAX, WebSockets) to prevent data exfiltration
        "connect-src 'self' https://api.enterprise-app.com",
        // Block object/embed execution
        "object-src 'none'",
        // Enforce HTTPS upgrade for all mixed content
        "upgrade-insecure-requests",
    ];

    const headerString = directives.join('; ');

    return {
        nonce,
        headerString,
    };
}
