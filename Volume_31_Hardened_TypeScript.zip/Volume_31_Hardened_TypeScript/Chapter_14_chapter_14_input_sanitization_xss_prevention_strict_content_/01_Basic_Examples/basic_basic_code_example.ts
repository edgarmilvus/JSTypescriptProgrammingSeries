/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import express, { Request, Response, NextFunction } from 'express';
import { JSDOM } from 'jsdom';
import createDOMPurify from 'dompurify';
import crypto from 'crypto';

// Initialize DOMPurify in a Node.js environment utilizing JSDOM
const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window as unknown as Window);

/**
 * Interface representing the incoming body for a user profile update.
 */
interface UserProfileUpdateDTO {
    userId: string;
    biography: string;
}

/**
 * Interface extending the Express Request object to include a cryptographic CSP nonce.
 */
interface SecureExpressRequest extends Request {
    cspNonce?: string;
}

// Instantiate the Express application
const app = express();

// Parse incoming application/json payloads with a strict size limit to prevent DoS
app.use(express.json({ limit: '10kb' }));

/**
 * Middleware: Generates a cryptographically secure nonce per request and 
 * sets a strict Content Security Policy (CSP) header to restrict script execution.
 */
const strictCspMiddleware = (req: SecureExpressRequest, res: Response, next: NextFunction): void => {
    // 1. Generate a random 128-bit cryptographic nonce encoded in base64
    const nonce = crypto.randomBytes(16).toString('base64');
    
    // 2. Attach the nonce to the request object so downstream handlers or view engines can access it
    req.cspNonce = nonce;

    // 3. Construct the Content Security Policy header value
    // - default-src 'self': Restricts all resource loads to the origin domain by default.
    // - script-src: Allows scripts only from self and explicitly via our dynamic cryptographic nonce. Disallows unsafe-inline and eval.
    // - object-src 'none': Blocks plugins like Flash or Java applets entirely.
    // - frame-ancestors 'none': Protects the application against clickjacking by preventing it from being embedded in an iframe.
    const cspHeaderValue = [
        "default-src 'self'",
        `script-src 'self' 'nonce-${nonce}'`,
        "style-src 'self' 'unsafe-inline'", // Allowed cautiously for runtime CSS-in-JS injection if needed, ideally also nonced
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'"
    ].join('; ');

    // 4. Inject the CSP header into the HTTP response
    res.setHeader('Content-Security-Policy', cspHeaderValue);

    // 5. Continue processing the request chain
    next();
};

// Apply the CSP middleware globally across all routes
app.use(strictCspMiddleware);

/**
 * API Route: Handles user profile bio updates.
 * Sanitizes untrusted HTML inputs to neutralize stored XSS payloads.
 */
app.post('/api/v1/user/profile', (req: SecureExpressRequest, res: Response): void => {
    try {
        const { userId, biography }: UserProfileUpdateDTO = req.body;

        // Validate that the payload fields are present and of expected types
        if (!userId || typeof biography !== 'string') {
            res.status(400).json({ 
                error: 'Invalid Payload', 
                message: 'User ID and string-based biography are required.' 
            });
            return;
        }

        // 1. Sanitize the incoming biography string using DOMPurify
        // This strips out malicious elements (e.g., <script>, <object>, onload attributes) 
        // while safely preserving approved formatting tags (e.g., <b>, <i>, <p>).
        const cleanBiography = DOMPurify.sanitize(biography, {
            ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p', 'br'],
            ALLOWED_ATTR: []
        });

        // 2. Simulate persistence to a secure database layer
        // In a production app, cleanBiography is now safe to store in PostgreSQL/MongoDB
        const persistedRecord = {
            id: userId,
            bio: cleanBiography,
            updatedAt: new Date().toISOString()
        };

        // 3. Respond with confirmation, returning the sanitized payload along with the request's CSP nonce for verification
        res.status(200).json({
            success: true,
            message: 'Profile updated and sanitized successfully.',
            data: persistedRecord,
            debugNonceUsed: req.cspNonce
        });

    } catch (error: unknown) {
        // Handle unexpected application errors safely without leaking internal stack traces
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({
            success: false,
            error: 'Internal Server Error',
            details: errorMessage
        });
    }
});

// Start the server on port 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Secure SaaS backend running on port ${PORT}`);
});
