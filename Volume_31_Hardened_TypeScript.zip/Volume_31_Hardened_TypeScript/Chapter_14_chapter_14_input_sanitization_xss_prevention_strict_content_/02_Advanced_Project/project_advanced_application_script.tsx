/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import 'server-only';

import { z } from 'zod';
import DOMPurify from 'isomorphic-dompurify';
import { headers } from 'next/headers';

/**
 * Interface representing the incoming payload structure for user comments or posts.
 */
interface SubmitContentInput {
  title: string;
  rawHtmlContent: string;
  authorId: string;
}

/**
 * Interface representing the sanitized and validated output ready for database persistence.
 */
interface SanitizedContentOutput {
  success: boolean;
  sanitizedTitle: string;
  sanitizedBody: string;
  violationsCount: number;
  error?: string;
}

/**
 * Zod validation schema for structural verification prior to sanitization.
 * Enforces strict typing and length constraints to prevent buffer overflow and injection DOS.
 */
const ContentPayloadSchema = z.object({
  title: z
    .string()
    .min(1, 'Title cannot be empty')
    .max(150, 'Title exceeds maximum allowed length')
    .trim(),
  rawHtmlContent: z
    .string()
    .min(1, 'Content cannot be empty')
    .max(50000, 'Content payload is too large'),
  authorId: z.string().uuid('Invalid author identifier format'),
});

/**
 * Configuration options for DOMPurify to ensure a strict whitelist of HTML tags and attributes.
 * Disables dangerous execution contexts like scripts, event handlers, and data URIs.
 */
const DOM_PURIFY_CONFIG = {
  ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'a', 'p', 'ul', 'ol', 'li', 'br', 'code', 'pre'],
  ALLOWED_ATTR: ['href', 'title', 'target'],
  ALLOW_DATA_ATTR: false,
  USE_PROFILES: { html: true },
  FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input'],
  FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'style'],
  RETURN_DOM: false,
  RETURN_DOM_FRAGMENT: false,
  SANITIZE_DOM: true,
};

/**
 * Validates, sanitizes, and strips malicious payloads from user-submitted content.
 * Executes within a secure Next.js Server Action context.
 * 
 * @param {SubmitContentInput} payload - The raw incoming user data.
 * @returns {Promise<SanitizedContentOutput>} The sanitized payload ready for insertion.
 */
export async function processAndSanitizeContent(
  payload: SubmitContentInput
): Promise<SanitizedContentOutput> {
  try {
    // Step 1: Enforce structural validation using Zod
    const validationResult = ContentPayloadSchema.safeParse(payload);
    
    if (!validationResult.success) {
      const errorMessage = validationResult.error.errors
        .map((err) => `${err.path.join('.')}: ${err.message}`)
        .join(', ');
      
      console.warn(`[SECURITY_WARNING] Payload validation failed: ${errorMessage}`);
      return {
        success: false,
        sanitizedTitle: '',
        sanitizedBody: '',
        violationsCount: 1,
        error: `Validation Error: ${errorMessage}`,
      };
    }

    const { title, rawHtmlContent, authorId } = validationResult.data;

    // Step 2: Context-aware sanitization of plain text elements (Title)
    // Ensures zero raw HTML is rendered in contexts expecting strict text nodes.
    const sanitizedTitle = DOMPurify.sanitize(title, {
      ALLOWED_TAGS: [],
      ALLOWED_ATTR: [],
    });

    // Step 3: Deep structural sanitization of rich-text body content
    // Hook into DOMPurify hooks to inspect and drop malicious URI schemes (e.g., javascript:)
    let malformedAttemptCounter = 0;
    
    DOMPurify.addHook('uponSanitizeAttribute', (node, data) => {
      if (data.attrName === 'href' && data.attrValue) {
        const lowerVal = data.attrValue.toLowerCase().trim();
        if (lowerVal.startsWith('javascript:') || lowerVal.startsWith('data:') || lowerVal.startsWith('vbscript:')) {
          malformedAttemptCounter++;
          data.attrValue = '#unsafe-url-blocked';
        }
      }
    });

    const sanitizedBody = DOMPurify.sanitize(rawHtmlContent, DOM_PURIFY_CONFIG);

    // Remove hooks to prevent memory leaks across execution contexts
    DOMPurify.removeAllHooks();

    // Step 4: Verify Content Security Policy headers present in the request pipeline
    const requestHeaders = headers();
    const cspHeader = requestHeaders.get('content-security-Policy');
    
    if (!cspHeader) {
      console.error('[CRITICAL_SECURITY] Request executed without an active CSP header enforcement.');
    }

    // Step 5: Return successfully sanitized execution payload
    return {
      success: true,
      sanitizedTitle,
      sanitizedBody,
      violationsCount: malformedAttemptCounter,
    };

  } catch (error: unknown) {
    // Ensure no sensitive stack traces leak to client boundaries
    const errorMessage = error instanceof Error ? error.message : 'Unknown processing error';
    console.error(`[CRITICAL_ERROR] Sanitization pipeline exception for author: ${payload.authorId}`, errorMessage);
    
    return {
      success: false,
      sanitizedTitle: '',
      sanitizedBody: '',
      violationsCount: 1,
      error: 'Internal processing failure during input sanitization.',
    };
  }
}

/**
 * Generates secure CSP header strings enforcing strict nonces and domain whitelisting.
 * To be injected via Next.js middleware or Next Config output.
 * 
 * @param {string} nonce - Cryptographically secure random nonce for script execution.
 * @returns {string} Fully formatted CSP string.
 */
export function generateStrictCSP(nonce: string): string {
  const cspDirectives = [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'`,
    "style-src 'self' 'unsafe-inline'", // Required for certain CSS-in-JS libraries; restrict where possible
    "img-src 'self' blob: data: https://trusted-cdn.com",
    "font-src 'self' https://fonts.gstatic.com",
    "connect-src 'self' https://api.enterprise-saas.com",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "upgrade-insecure-requests",
  ];

  return cspDirectives.join('; ');
}
