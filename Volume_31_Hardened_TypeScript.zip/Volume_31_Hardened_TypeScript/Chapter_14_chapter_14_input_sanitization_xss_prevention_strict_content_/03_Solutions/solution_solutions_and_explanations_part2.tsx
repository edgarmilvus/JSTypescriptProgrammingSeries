/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo } from 'react';
import DOMPurify from 'dompurify';
import { marked } from 'marked';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface SecureChatMessageProps {
  message: Message;
}

// Utility to escape plain text entities to prevent reflected/stored XSS
const escapeHtml = (str: string): string => {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

export const SecureChatMessage: React.FC<SecureChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  const processedContent = useMemo(() => {
    if (isUser) {
      // Requirement: Completely escape HTML entities for user input
      return escapeHtml(message.content);
    } else {
      // Requirement: Parse markdown and sanitize HTML for assistant output
      const rawHtml = marked.parse(message.content) as string;
      return DOMPurify.sanitize(rawHtml, {
        ALLOWED_TAGS: ['p', 'strong', 'em', 'ul', 'ol', 'li', 'code', 'pre', 'br'],
        ALLOWED_ATTR: [],
      });
    }
  }, [message.content, isUser]);

  return (
    <div className={`chat-message ${message.role}`}>
      <span className="font-bold">{message.role}: </span>
      {isUser ? (
        // Render escaped text safely inside React's text node children
        <span>{processedContent}</span>
      ) : (
        // Render sanitized HTML for assistant responses
        <div dangerouslySetInnerHTML={{ __html: processedContent }} />
      )}
    </div>
  );
};
