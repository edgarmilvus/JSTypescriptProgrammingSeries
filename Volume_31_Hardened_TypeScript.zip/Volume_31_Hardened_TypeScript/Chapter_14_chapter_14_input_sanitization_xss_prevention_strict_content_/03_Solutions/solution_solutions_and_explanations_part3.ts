/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { pipeline } from '@huggingface/transformers';

export class SecurityViolationError extends Error {
  constructor(public category: string, public confidence: number) {
    super(`Input blocked due to security policy violation: ${category} (Confidence: ${confidence})`);
    this.name = 'SecurityViolationError';
  }
}

export class ClientInputFirewall {
  private classifier: any = null;
  private candidateLabels = [
    'benign_content',
    'cross_site_scripting',
    'prompt_injection',
    'sql_injection'
  ];

  async initialize(): Promise<void> {
    if (!this.classifier) {
      this.classifier = await pipeline('zero-shot-classification', 'Xenova/nli-deberta-v3-small');
    }
  }

  async inspectInput(inputData: string): Promise<{ category: string; confidence: number; isBlocked: boolean }> {
    if (!this.classifier) {
      throw new Error('Firewall classifier not initialized. Call initialize() first.');
    }

    // 1. Prevent DoS via memory exhaustion by truncating excessively long inputs
    const truncatedInput = inputData.slice(0, 2048);

    // 2. Execute zero-shot classification against threat taxonomy
    const classificationResult = await this.classifier(truncatedInput, this.candidateLabels);

    // Extract top prediction (labels and scores are aligned arrays)
    const topCategory: string = classificationResult.labels[0];
    const topConfidence: number = classificationResult.scores[0];

    // 3. Enforce strict blocking rules based on a confidence threshold
    const isThreat = topCategory !== 'benign_content';
    const isBlocked = isThreat && topConfidence > 0.85;

    if (isBlocked) {
      throw new SecurityViolationError(topCategory, topConfidence);
    }

    return {
      category: topCategory,
      confidence: topConfidence,
      isBlocked: false
    };
  }
}
