/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { randomBytes } from 'crypto';

interface CspConfig {
  reportUri?: string;
}

export function generateCspNonce(): string {
  // Generate a cryptographically secure 128-bit random nonce encoded in Base64
  return randomBytes(16).toString('base64');
}

export function buildStrictCspHeader(nonce: string, config?: CspConfig): string {
  const reportDirective = config?.reportUri ? `report-uri ${config.reportUri};` : '';

  // Construct a defense-in-depth CSP string utilizing nonces and strict-dynamic
  const directives = [
    `default-src 'self';`,
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic';`,
    `style-src 'self' 'nonce-${nonce}';`,
    `img-src 'self' data: https:;`,
    `connect-src 'self' https://api.openai.com;`, // Allows secure LLM streaming endpoints
    `object-src 'none';`,
    `base-uri 'self';`,
    `frame-ancestors 'none';`,
    reportDirective
  ];

  return directives.filter(Boolean).join(' ');
}
