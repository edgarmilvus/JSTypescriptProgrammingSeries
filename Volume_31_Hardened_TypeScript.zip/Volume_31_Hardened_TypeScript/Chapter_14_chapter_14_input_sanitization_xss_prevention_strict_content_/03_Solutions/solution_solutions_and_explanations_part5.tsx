/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

interface SecureUserProfileCardProps {
  bio?: string;
  redirectUrl?: string;
}

// Utility to validate safe external or relative URLs
const isValidRedirectUrl = (url: string): boolean => {
  try {
    // Allow relative paths starting with '/'
    if (url.startsWith('/') && !url.startsWith('//')) {
      return true;
    }
    const parsed = new URL(url);
    // Enforce strict protocol allowlist for external redirects
    return ['https:'].includes(parsed.protocol);
  } catch {
    return false;
  }
};

export const SecureUserProfileCard: React.FC<SecureUserProfileCardProps> = ({ 
  bio = 'No bio provided.', 
  redirectUrl 
}) => {
  // Validate and sanitize the redirect URL securely
  const safeRedirect = redirectUrl && isValidRedirectUrl(redirectUrl) ? redirectUrl : '#';

  return (
    <div className="profile-card">
      <h2>User Profile</h2>
      {/* VULNERABILITY REMOVED: Using React's native text rendering instead of innerHTML ref */}
      <div className="bio-container">
        <p>{bio}</p>
      </div>
      
      {/* VULNERABILITY REMOVED: Using a safe anchor element with validated href instead of programmatic click assignment */}
      <a 
        id="redirect-link" 
        href={safeRedirect} 
        className="btn"
        rel="noopener noreferrer"
      >
        External Link
      </a>
    </div>
  );
};
