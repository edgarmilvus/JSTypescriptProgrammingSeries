/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

import React, { useEffect, useRef } from 'react';

export const VulnerableUserProfileCard: React.FC = () => {
  const bioRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // VULNERABILITY 1: Reading raw window.location.search directly without validation
    const params = new URLSearchParams(window.location.search);
    const unsafeBio = params.get('bio') || 'No bio provided.';
    const unsafeRedirect = params.get('redirect');

    // VULNERABILITY 2: Direct DOM manipulation using dangerously assigned innerHTML via ref
    if (bioRef.current) {
      bioRef.current.innerHTML = `<p>${unsafeBio}</p>`;
    }

    // VULNERABILITY 3: Unvalidated URL navigation sink
    const linkButton = document.getElementById('redirect-link');
    if (linkButton && unsafeRedirect) {
      linkButton.onclick = () => {
        window.location.href = unsafeRedirect;
      };
    }
  }, []);

  return (
    <div className="profile-card">
      <h2>User Profile</h2>
      <div ref={bioRef} />
      <button id="redirect-link">External Link</button>
    </div>
  );
};
