/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as crypto from 'crypto';

/**
 * Interface representing the immutable structure of a secret payload.
 * Once instantiated, these properties cannot be altered directly in place.
 */
interface ImmutableSecretPayload {
  readonly secretId: string;
  readonly secretValue: string;
  readonly version: number;
  readonly validUntil: number;
}

/**
 * Interface representing the operational status of the Secret Manager.
 */
interface SecretManagerStatus {
  readonly isInitialized: boolean;
  readonly activeVersion: number;
  readonly totalRotations: number;
}

/**
 * A robust, production-grade Secret Manager designed for SaaS environments.
 * Implements strict environment isolation, immutable state patterns, and zero-downtime rotation.
 */
export class SecureSecretManager {
  // Private backing field maintaining the immutable active secret state.
  private currentSecret: ImmutableSecretPayload | null = null;
  
  // Tracks rotation metrics and state safely.
  private rotationCount: number = 0;
  private isInitialized: boolean = false;

  /**
   * Initializes the Secret Manager with an initial bootstrap secret.
   * Enforces environment isolation by refusing initialization if explicit runtime flags are missing.
   * 
   * @param initialValue - The raw secret string passed from a secure bootstrap source.
   */
  public initialize(initialValue: string): void {
    if (this.isInitialized) {
      throw new Error('Security Violation: SecretManager is already initialized. Re-initialization is blocked.');
    }

    if (!initialValue || initialValue.trim().length === 0) {
      throw new Error('Initialization failed: Provided secret value is empty or invalid.');
    }

    // Construct the initial immutable payload
    this.currentSecret = Object.freeze({
      secretId: crypto.randomUUID(),
      secretValue: initialValue,
      version: 1,
      validUntil: Date.now() + (1000 * 60 * 60 * 24), // Valid for 24 hours
    });

    this.isInitialized = true;
  }

  /**
   * Retrieves the current active secret safely.
   * Returns a frozen copy or reference to ensure the caller cannot mutate the internal state.
   * 
   * @returns The current immutable secret payload.
   */
  public getActiveSecret(): ImmutableSecretPayload {
    this.assertInitialized();
    
    // TypeScript's `readonly` keyword combined with Object.freeze guarantees immutability.
    return this.currentSecret!;
  }

  /**
   * Rotates the current secret safely without incurring downtime.
   * Generates a new cryptographic version while retaining the old one in memory briefly 
   * to accommodate in-flight requests.
   * 
   * @param newSecretValue - The newly provisioned secret value from the rotation pipeline.
   * @returns The newly updated immutable secret payload.
   */
  public rotateSecret(newSecretValue: string): ImmutableSecretPayload {
    this.assertInitialized();

    if (!newSecretValue || newSecretValue.trim().length === 0) {
      throw new Error('Rotation failed: New secret value cannot be empty.');
    }

    const previousVersion = this.currentSecret!.version;

    // Create a new immutable object instead of mutating the existing one (Immutable State Management)
    const nextSecret: ImmutableSecretPayload = Object.freeze({
      secretId: crypto.randomUUID(),
      secretValue: newSecretValue,
      version: previousVersion + 1,
      validUntil: Date.now() + (1000 * 60 * 60 * 24), // Extend validity window
    });

    // Atomically swap the reference
    this.currentSecret = nextSecret;
    this.rotationCount += 1;

    return this.currentSecret;
  }

  /**
   * Returns operational status metrics for monitoring dashboards.
   * 
   * @returns An immutable status object.
   */
  public getStatus(): SecretManagerStatus {
    return Object.freeze({
      isInitialized: this.isInitialized,
      activeVersion: this.currentSecret ? this.currentSecret.version : 0,
      totalRotations: this.rotationCount,
    });
  }

  /**
   * Private helper guard method to enforce initialization invariants.
   */
  private assertInitialized(): void {
    if (!this.isInitialized || !this.currentSecret) {
      throw new Error('Security Violation: SecretManager has not been initialized. Call initialize() first.');
    }
  }
}

// ==========================================
// Execution Demonstration (SaaS Context)
// ==========================================
try {
  console.log('--- Initializing Secure Secret Manager ---');
  const secretManager = new SecureSecretManager();
  
  // Bootstrap the manager with an initial environment secret
  secretManager.initialize('db_password_prod_v1_xyz987');
  
  console.log('Initial State:', secretManager.getStatus());
  console.log('Active Secret Version:', secretManager.getActiveSecret().version);

  console.log('\n--- Executing Zero-Downtime Rotation ---');
  // Simulate automated CI/CD pipeline or key rotation daemon pushing a new secret
  const updatedSecret = secretManager.rotateSecret('db_password_prod_v2_abc123');
  
  console.log('Post-Rotation State:', secretManager.getStatus());
  console.log('New Active Secret Version:', updatedSecret.version);
  console.log('New Secret ID:', updatedSecret.secretId);

  // Attempting to mutate the secret directly will throw a runtime error in strict mode
  // or fail TypeScript compilation due to `readonly` properties.
  // Example: updatedSecret.version = 5; // Error: Cannot assign to 'version' because it is a read-only property.

} catch (error: unknown) {
  if (error instanceof Error) {
    console.error('Secret Management Error:', error.message);
  } else {
    console.error('An unexpected error occurred:', error);
  }
}
