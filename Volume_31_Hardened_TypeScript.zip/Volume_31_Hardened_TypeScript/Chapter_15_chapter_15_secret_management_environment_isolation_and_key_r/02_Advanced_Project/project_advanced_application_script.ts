/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';

/**
 * Interface representing the structure of a rotating cryptographic key-set.
 */
interface KeyMetadata {
  keyId: string;
  secretKey: Buffer;
  version: number;
  createdAt: number;
  expiresAt: number;
}

/**
 * Interface for the encrypted payload structure passing through the application boundary.
 */
interface CiphertextPayload {
  iv: string;
  ciphertext: string;
  authTag: string;
  keyId: string;
  version: number;
}

/**
 * Mock Key Management Service (KMS) state holder for demonstrating 
 * zero-downtime key rotation patterns in an isolated environment.
 */
class KeyVaultManager {
  private static instance: KeyVaultManager;
  private keys: Map<string, KeyMetadata> = new Map();
  private activeKeyId: string = '';

  private constructor() {
    this.rotateKey(); // Initialize with a primary active key
  }

  public static getInstance(): KeyVaultManager {
    if (!KeyVaultManager.instance) {
      KeyVaultManager.instance = new KeyVaultManager();
    }
    return KeyVaultManager.instance;
  }

  /**
   * Generates a new cryptographic key, making it the active key while 
   * preserving older keys for decryption of in-flight payloads.
   */
  public rotateKey(): KeyMetadata {
    const newKeyId = `key_${randomBytes(4).toString('hex')}`;
    const rawSecret = randomBytes(32); // 256-bit key for AES-GCM
    // Derive a cryptographically secure key via scrypt for added defense-in-depth
    const derivedKey = scryptSync(rawSecret, 'salt_context_isolation', 32);

    const newMetadata: KeyMetadata = {
      keyId: newKeyId,
      secretKey: derivedKey,
      version: this.keys.size + 1,
      createdAt: Date.now(),
      expiresAt: Date.now() + 1000 * 60 * 60 * 24, // 24-hour rotation window
    };

    this.keys.set(newKeyId, newMetadata);
    this.activeKeyId = newKeyId;
    
    console.warn(`[Vault] Key rotation executed. Active Key ID: ${newKeyId} (Version ${newMetadata.version})`);
    return newMetadata;
  }

  /**
   * Retrieves the currently active key for encryption tasks.
   */
  public getActiveKey(): KeyMetadata {
    const key = this.keys.get(this.activeKeyId);
    if (!key) throw new Error('Critical: Active cryptographic key not found in vault.');
    return key;
  }

  /**
   * Retrieves a specific key by ID to support zero-downtime rotation during decryption.
   */
  public getKeyById(keyId: string): KeyMetadata | undefined {
    return this.keys.get(keyId);
  }
}

/**
 * Cryptographic engine handling authenticated encryption (AES-256-GCM).
 */
class SecretEnclaveEngine {
  private static readonly ALGORITHM = 'aes-256-gcm';

  /**
   * Encrypts plaintext data using the active key from the vault.
   */
  public static encrypt(plainText: string): CiphertextPayload {
    const vault = KeyVaultManager.getInstance();
    const activeKey = vault.getActiveKey();
    
    const iv = randomBytes(12); // Initialization vector for GCM
    const cipher = createCipheriv(this.ALGORITHM, activeKey.secretKey, iv);
    
    let ciphertext = cipher.update(plainText, 'utf8', 'hex');
    ciphertext += cipher.final('hex');
    const authTag = cipher.getAuthTag().toString('hex');

    return {
      iv: iv.toString('hex'),
      ciphertext,
      authTag,
      keyId: activeKey.keyId,
      version: activeKey.version,
    };
  }

  /**
   * Decrypts a payload, referencing the exact key version used at the time of encryption.
   */
  public static decrypt(payload: CiphertextPayload): string {
    const vault = KeyVaultManager.getInstance();
    const targetKey = vault.getKeyById(payload.keyId);

    if (!targetKey) {
      throw new Error(`Decryption failed: Key ID ${payload.keyId} has been revoked or does not exist.`);
    }

    const decipher = createDecipheriv(
      this.ALGORITHM, 
      targetKey.secretKey, 
      Buffer.from(payload.iv, 'hex')
    );
    
    decipher.setAuthTag(Buffer.from(payload.authTag, 'hex'));

    let decrypted = decipher.update(payload.ciphertext, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  }
}

/**
 * Next.js API Route handler enforcing secret isolation and secure rotation validation.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const { action, secretData } = body;

    const vault = KeyVaultManager.getInstance();

    if (action === 'encrypt') {
      if (!secretData) {
        return NextResponse.json({ error: 'Missing secretData for encryption' }, { status: 400 });
      }
      
      const encryptedPayload = SecretEnclaveEngine.encrypt(secretData);
      return NextResponse.json({ success: true, payload: encryptedPayload });
    }

    if (action === 'decrypt') {
      if (!secretData || !secretData.keyId) {
        return NextResponse.json({ error: 'Invalid payload structure for decryption' }, { status: 400 });
      }

      const decryptedText = SecretEnclaveEngine.decrypt(secretData);
      return NextResponse.json({ success: true, decryptedText });
    }

    if (action === 'rotate') {
      // Administrative trigger for automated key rotation pipelines
      const newKeyMeta = vault.rotateKey();
      return NextResponse.json({ 
        success: true, 
        message: 'Key rotation successful', 
        keyId: newKeyMeta.keyId,
        version: newKeyMeta.version 
      });
    }

    return NextResponse.json({ error: 'Unknown action command' }, { status: 400 });

  } catch (error: any) {
    console.error('[Security Enclave Error]:', error.message);
    return NextResponse.json(
      { error: 'Internal security exception processed securely.' }, 
      { status: 500 }
    );
  }
}
