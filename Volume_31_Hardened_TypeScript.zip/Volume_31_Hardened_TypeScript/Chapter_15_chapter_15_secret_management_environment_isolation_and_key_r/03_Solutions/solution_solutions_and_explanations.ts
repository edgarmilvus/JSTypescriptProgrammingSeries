/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import * as crypto from 'crypto';

export interface VaultCredentialRecord {
  id: string;
  service_id: string;
  token_hash: string;
  scope: string;
  expires_at: string;
  embedding?: number[]; // pgvector semantic audit log embedding
}

export class EphemeralVaultManager {
  private supabase: SupabaseClient;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Issues a short-lived ephemeral credential with a strict TTL.
   */
  public async issueEphemeralCredential(
    serviceId: string,
    scope: string,
    ttlSeconds: number
  ): Promise<{ token: string; expiresAt: Date }> {
    const token = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000);

    // Generate a dummy semantic embedding for pgvector audit logging (e.g., matching request context)
    const dummyEmbedding = Array.from({ length: 1536 }, () => Math.random() * 0.1);

    const { error } = await this.supabase.from('vault_credentials').insert({
      service_id: serviceId,
      token_hash: tokenHash,
      scope: scope,
      expires_at: expiresAt.toISOString(),
      embedding: dummyEmbedding,
    });

    if (error) {
      throw new Error(`Failed to issue ephemeral credential: ${error.message}`);
    }

    return { token, expiresAt };
  }

  /**
   * Validates an incoming ephemeral token against the vault database.
   */
  public async validateEphemeralToken(token: string, requiredScope: string): Promise<boolean> {
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const nowISO = new Date().toISOString();

    const { data, error } = await this.supabase
      .from('vault_credentials')
      .select('*')
      .eq('token_hash', tokenHash)
      .single();

    if (error || !data) {
      return false;
    }

    const record = data as VaultCredentialRecord;

    // Check expiration
    if (new Date(record.expires_at) < new Date()) {
      await this.supabase.from('vault_credentials').delete().eq('id', record.id);
      return false;
    }

    // Check scope match
    if (record.scope !== requiredScope && record.scope !== 'admin:*') {
      return false;
    }

    return true;
  }

  /**
   * Purges expired credentials from the persistent store.
   */
  public async purgeExpiredCredentials(): Promise<number> {
    const nowISO = new Date().toISOString();
    
    const { data, error } = await this.supabase
      .from('vault_credentials')
      .delete()
      .lt('expires_at', nowISO)
      .select('id');

    if (error) {
      throw new Error(`Failed to purge expired credentials: ${error.message}`);
    }

    return data ? data.length : 0;
  }
}
