/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import * as path from 'path';

export interface SecurityViolation {
  filePath: string;
  lineNumber: number;
  violationType: 'SECRET_LEAK' | 'HIGH_ENTROPY_STRING' | 'VULNERABLE_DEPENDENCY';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  snippet: string;
}

export interface DependencyAlert {
  packageName: string;
  installedVersion: string;
  vulnerabilityId: string;
  advisory: string;
}

export class SupplyChainScanner {
  private targetDirectory: string;

  constructor(targetDirectory: string) {
    this.targetDirectory = targetDirectory;
  }

  private calculateShannonEntropy(str: string): number {
    const freq: { [key: string]: number } = {};
    for (const char of str) {
      freq[char] = (freq[char] || 0) + 1;
    }
    let entropy = 0;
    const len = str.length;
    for (const char in freq) {
      const p = freq[char] / len;
      entropy -= p * Math.log2(p);
    }
    return entropy;
  }

  public async scanCodebase(): Promise<SecurityViolation[]> {
    const violations: SecurityViolation[] = [];
    const secretRegex = /(supabase_service_role_key|aws_access_key_id|private_key|api_key)\s*[:=]\s*['"][A-Za-z0-9_\-\.]{16,}['"]/i;

    const walkDir = (dir: string) => {
      const files = fs.readdirSync(dir);
      for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
          if (file !== 'node_modules' && file !== '.git') {
            walkDir(fullPath);
          }
        } else if (file.endsWith('.ts') || file.endsWith('.js') || file.endsWith('.json')) {
          const content = fs.readFileSync(fullPath, 'utf8');
          const lines = content.split('\n');

          lines.forEach((line, index) => {
            if (secretRegex.test(line)) {
              violations.push({
                filePath: fullPath,
                lineNumber: index + 1,
                violationType: 'SECRET_LEAK',
                severity: 'CRITICAL',
                snippet: line.trim(),
              });
            } else {
              // Check high entropy tokens
              const words = line.split(/\s+/);
              for (const word of words) {
                const cleaned = word.replace(/['"]/g, '');
                if (cleaned.length > 20 && this.calculateShannonEntropy(cleaned) > 4.5) {
                  violations.push({
                    filePath: fullPath,
                    lineNumber: index + 1,
                    violationType: 'HIGH_ENTROPY_STRING',
                    severity: 'MEDIUM',
                    snippet: line.trim(),
                  });
                }
              }
            }
          });
        }
      }
    };

    walkDir(this.targetDirectory);
    return violations;
  }

  public async scanDependencies(lockfilePath: string): Promise<DependencyAlert[]> {
    const alerts: DependencyAlert[] = [];
    if (!fs.existsSync(lockfilePath)) return alerts;

    const lockContent = JSON.parse(fs.readFileSync(lockfilePath, 'utf8'));
    const packages = lockContent.packages || lockContent.dependencies || {};

    // Simulated vulnerable package check
    const knownVulnerabilities: { [name: string]: { version: string; advisory: string } } = {
      'lodash': { version: '<4.17.21', advisory: 'Prototype pollution vulnerability in lodash' },
    };

    for (const [pkgName, details] of Object.entries(packages)) {
      const version = (details as any).version || (typeof details === 'string' ? details : '');
      for (const [vulnPkg, vulnData] of Object.entries(knownVulnerabilities)) {
        if (pkgName.includes(vulnPkg) && version.includes('4.17.20')) {
          alerts.push({
            packageName: pkgName,
            installedVersion: version,
            vulnerabilityId: 'CVE-2021-23337',
            advisory: vulnData.advisory,
          });
        }
      }
    }

    return alerts;
  }

  public evaluatePipelineGate(violations: SecurityViolation[], alerts: DependencyAlert[]): void {
    const hasCriticalSecret = violations.some((v) => v.severity === 'CRITICAL');
    const hasVulnerableDeps = alerts.length > 0;

    if (hasCriticalSecret || hasVulnerableDeps) {
      throw new Error(
        `Pipeline Security Gate Failed: Detected ${violations.length} codebase violations and ${alerts.length} dependency alerts.`
      );
    }
  }
}
