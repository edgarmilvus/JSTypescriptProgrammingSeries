/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

export interface KeyDashboardItem {
  id: string;
  state: 'ACTIVE' | 'DEPRECATED' | 'REVOKED';
  createdAt: string;
  expiresAt: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  event: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  details: string;
}

export interface SecurityOperationsDashboardProps {
  fetchKeysEndpoint: string;
  fetchAuditLogsEndpoint: string;
  onTriggerRotation: (adminToken: string) => Promise<void>;
  onRevokeToken: (tokenId: string) => Promise<void>;
}

export const SecurityOperationsDashboard: React.FC<SecurityOperationsDashboardProps> = ({
  fetchKeysEndpoint,
  fetchAuditLogsEndpoint,
  onTriggerRotation,
  onRevokeToken,
}) => {
  const [keys, setKeys] = useState<KeyDashboardItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [adminToken, setAdminToken] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Simulated API fetch calls
        setKeys([
          { id: 'key-uuid-1', state: 'ACTIVE', createdAt: '2023-10-01', expiresAt: '2023-11-01' },
          { id: 'key-uuid-0', state: 'DEPRECATED', createdAt: '2023-09-01', expiresAt: '2023-10-01' },
        ]);
        setAuditLogs([
          { id: 'log-1', timestamp: '2023-10-15 12:00:00', event: 'TOKEN_VALIDATION_FAILED', severity: 'CRITICAL', details: 'Expired ephemeral token presented.' },
          { id: 'log-2', timestamp: '2023-10-15 11:30:00', event: 'KEY_ROTATION_SUCCESS', severity: 'INFO', details: 'New RSA keypair established.' },
        ]);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [fetchKeysEndpoint, fetchAuditLogsEndpoint]);

  const handleRotationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onTriggerRotation(adminToken);
      setIsModalOpen(false);
      setAdminToken('');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="security-ops-dashboard p-6 bg-slate-900 text-slate-100 min-h-screen">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold tracking-tight">Security & Secret Management Operations</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded font-semibold transition"
        >
          Trigger Emergency Key Rotation
        </button>
      </header>

      {error && <div className="mb-4 p-4 bg-red-900/50 border border-red-500 rounded text-red-200">{error}</div>}

      {/* Cryptographic Keys Status Table */}
      <section className="mb-8 bg-slate-800 p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Cryptographic Key Lifecycle</h2>
        {loading ? (
          <p>Loading keys...</p>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-700 text-slate-400">
                <th className="py-2">Key ID</th>
                <th className="py-2">State</th>
                <th className="py-2">Created At</th>
                <th className="py-2">Expires At</th>
                <th className="py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {keys.map((key) => (
                <tr key={key.id} className="border-b border-slate-700/50">
                  <td className="py-3 font-mono text-sm">{key.id}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        key.state === 'ACTIVE'
                          ? 'bg-emerald-900 text-emerald-300'
                          : key.state === 'DEPRECATED'
                          ? 'bg-amber-900 text-amber-300'
                          : 'bg-red-900 text-red-300'
                      }`}
                    >
                      {key.state}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-slate-300">{key.createdAt}</td>
                  <td className="py-3 text-sm text-slate-300">{key.expiresAt}</td>
                  <td className="py-3">
                    <button
                      onClick={() => onRevokeToken(key.id)}
                      className="text-xs bg-slate-700 hover:bg-slate-600 px-3 py-1 rounded text-slate-200"
                    >
                      Revoke
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* Real-time Audit Log Stream */}
      <section className="bg-slate-800 p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Real-time Audit Log Stream (pgvector)</h2>
        <div className="space-y-3 font-mono text-sm">
          {auditLogs.map((log) => (
            <div
              key={log.id}
              className={`p-3 rounded border ${
                log.severity === 'CRITICAL'
                  ? 'bg-red-950/40 border-red-800 text-red-300'
                  : 'bg-slate-900/50 border-slate-700 text-slate-300'
              }`}
            >
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>{log.timestamp}</span>
                <span className="font-bold">{log.event}</span>
              </div>
              <p>{log.details}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Emergency Rotation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-slate-800 p-6 rounded-lg max-w-md w-full">
            <h3 className="text-lg font-bold mb-4 text-red-400">Emergency Key Rotation</h3>
            <p className="text-sm text-slate-300 mb-4">
              This will immediately deprecate the active signing key and generate a new keypair. Enter admin token to confirm.
            </p>
            <form onSubmit={handleRotationSubmit}>
              <input
                type="password"
                placeholder="Administrative Authorization Token"
                value={adminToken}
                onChange={(e) => setAdminToken(e.target.value)}
                className="w-full p-2 mb-4 bg-slate-900 border border-slate-700 rounded text-slate-100"
                required
              />
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded text-slate-300 text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-white text-sm font-semibold"
                >
                  Confirm Rotation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
