/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as jwt from 'jsonwebtoken';

export class CryptographicPropagationException extends Error {
  constructor(message: string, public readonly tokenKid: string) {
    super(message);
    this.name = 'CryptographicPropagationException';
  }
}

/**
 * Resiliently verifies a token with automatic JWKS cache invalidation and exponential backoff
 * to prevent cryptographic deadlocks during zero-downtime key rotation transitions.
 */
export async function resilientVerify(
  token: string,
  fetchJwksFn: () => Promise<object>,
  maxRetries: number = 3
): Promise<any> {
  let currentJwks: any = await fetchJwksFn();
  let attempt = 0;

  const decodedHeader = jwt.decode(token, { complete: true }) as { header: { kid?: string } } | null;
  const tokenKid = decodedHeader?.header?.kid || 'unknown';

  while (attempt < maxRetries) {
    try {
      // Find matching public key in JWKS
      const keyObj = currentJwks.keys?.find((k: any) => k.kid === tokenKid);
      if (!keyObj) {
        throw new Error(`Key ID ${tokenKid} not found in current JWKS cache.`);
      }

      // Convert JWK to PEM for verification
      const jwkToPem = require('jwk-to-pem');
      const publicKeyPem = jwkToPem(keyObj);

      const verifiedPayload = jwt.verify(token, publicKeyPem, { algorithms: ['RS256'] });
      return verifiedPayload;
    } catch (err: any) {
      attempt++;
      if (attempt >= maxRetries) {
        // Log forensic audit event (Simulated Supabase pgvector log insertion)
        console.error(`[CRITICAL] Cryptographic propagation deadlock encountered for kid: ${tokenKid}. All ${maxRetries} retries exhausted.`);
        throw new CryptographicPropagationException(
          `Failed to verify token after ${maxRetries} retries due to cryptographic propagation failure.`,
          tokenKid
        );
      }

      // Exponential backoff with jitter
      const delay = Math.pow(2, attempt) * 100 + Math.random() * 50;
      await new Promise((resolve) => setTimeout(resolve, delay));

      // Force refresh JWKS cache on validation failure due to unknown kid
      currentJwks = await fetchJwksFn();
    }
  }
}
