/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Exercise 3 Starter Code
import * as fs from 'fs';
import * as path from 'path';

export interface SecurityViolation {
  filePath: string;
  lineNumber: number;
  violationType: 'SECRET_LEAK' | 'HIGH_ENTROPY_STRING' | 'VULNERABLE_DEPENDENCY';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  snippet: string;
}

export interface DependencyAlert {
  packageName: string;
  installedVersion: string;
  vulnerabilityId: string;
  advisory: string;
}

export class SupplyChainScanner {
  private targetDirectory: string;

  constructor(targetDirectory: string) {
    this.targetDirectory = targetDirectory;
  }

  /**
   * Scans the codebase for hardcoded secrets and high-entropy strings.
   */
  public async scanCodebase(): Promise<SecurityViolation[]> {
    // TODO: Implement recursive directory traversal, regex matching, and entropy calculation.
    throw new Error('Not implemented');
  }

  /**
   * Analyzes dependency lockfiles for known supply chain vulnerabilities.
   */
  public async scanDependencies(lockfilePath: string): Promise<DependencyAlert[]> {
    // TODO: Implement lockfile parsing and vulnerability database lookup.
    throw new Error('Not implemented');
  }

  /**
   * Evaluates scan results and determines whether to fail the CI/CD pipeline.
   */
  public evaluatePipelineGate(violations: SecurityViolation[], alerts: DependencyAlert[]): void {
    // TODO: Implement pipeline blocking logic based on configurable thresholds.
    throw new Error('Not implemented');
  }
}
