/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

import { IncomingMessage, ServerResponse } from 'http';

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface RequestContext {
  ip: string;
  userAgent: string;
  path: string;
  method: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  query?: Record<string, string>;
}

export interface SecurityConfig {
  rateLimit: {
    maxCapacity: number;
    refillRatePerSecond: number;
    windowSeconds: number;
  };
  botDetection: {
    requireChallengeHeader: boolean;
    suspiciousUserAgents: RegExp[];
  };
  waf: {
    enabled: boolean;
    blockedPatterns: RegExp[];
  };
}

export interface SecurityResult {
  allowed: boolean;
  statusCode?: number;
  reason?: string;
}

// ============================================================================
// In-Memory Distributed State Simulation (Token Bucket & WAF)
// ============================================================================

interface TokenBucketState {
  tokens: number;
  lastRefillTimestamp: number;
}

/**
 * Simulates a distributed token bucket rate limiter store (e.g., backed by Redis).
 */
class DistributedTokenBucketStore {
  private store = new Map<string, TokenBucketState>();

  public async consume(
    identifier: string,
    capacity: number,
    refillRate: number
  ): Promise<{ allowed: boolean; remainingTokens: number }> {
    const now = Date.now();
    let bucket = this.store.get(identifier);

    if (!bucket) {
      bucket = { tokens: capacity, lastRefillTimestamp: now };
      this.store.set(identifier, bucket);
    }

    // Calculate time elapsed in seconds since last refill
    const elapsedSeconds = (now - bucket.lastRefillTimestamp) / 1000;
    bucket.lastRefillTimestamp = now;

    // Refill tokens proportionally
    const generatedTokens = elapsedSeconds * refillRate;
    bucket.tokens = Math.min(capacity, bucket.tokens + generatedTokens);

    // Check if sufficient tokens exist
    if (bucket.tokens >= 1) {
      bucket.tokens -= 1;
      this.store.set(identifier, bucket);
      return { allowed: true, remainingTokens: Math.floor(bucket.tokens) };
    }

    this.store.set(identifier, bucket);
    return { allowed: false, remainingTokens: 0 };
  }
}

// ============================================================================
// WAF Payload Inspection Engine
// ============================================================================

class WebApplicationFirewallEngine {
  private patterns: RegExp[];

  constructor(patterns: RegExp[]) {
    this.patterns = patterns;
  }

  /**
   * Recursively inspects nested objects, strings, and arrays for malicious attack signatures.
   */
  public inspectPayload(input: unknown): { safe: boolean; matchedPattern?: string } {
    if (typeof input === 'string') {
      for (const pattern of this.patterns) {
        if (pattern.test(input)) {
          return { safe: false, matchedPattern: pattern.source };
        }
      }
    } else if (Array.isArray(input)) {
      for (const item of input) {
        const result = this.inspectPayload(item);
        if (!result.safe) {
          return result;
        }
      }
    } else if (input !== null && typeof input === 'object') {
      for (const value of Object.values(input as Record<string, unknown>)) {
        const result = this.inspectPayload(value);
        if (!result.safe) {
          return result;
        }
      }
    }

    return { safe: true };
  }
}

// ============================================================================
// Unified API Protection Gateway Middleware
// ============================================================================

export class ApiProtectionGateway {
  private tokenBucketStore: DistributedTokenBucketStore;
  private wafEngine: WebApplicationFirewallEngine;
  private config: SecurityConfig;

  constructor(config: SecurityConfig) {
    this.config = config;
    this.tokenBucketStore = new DistributedTokenBucketStore();
    this.wafEngine = new WebApplicationFirewallEngine(config.waf.blockedPatterns);
  }

  /**
   * Evaluates an incoming HTTP request against Rate Limiting, Bot Detection, and WAF rules.
   */
  public async evaluateRequest(context: RequestContext): Promise<SecurityResult> {
    // 1. Bot Detection: Inspect User-Agent against known signatures
    for (const regex of this.config.botDetection.suspiciousUserAgents) {
      if (regex.test(context.userAgent)) {
        return {
          allowed: false,
          statusCode: 403,
          reason: 'Forbidden: Automated scraping tool detected via User-Agent fingerprint.'
        };
      }
    }

    // 2. Bot Detection: Validate cryptographic challenge header if enforced
    if (this.config.botDetection.requireChallengeHeader) {
      const challengeToken = context.headers['x-client-proof-of-work'];
      if (!challengeToken || typeof challengeToken !== 'string' || challengeToken.length < 16) {
        return {
          allowed: false,
          statusCode: 401,
          reason: 'Unauthorized: Missing or invalid client-side Proof-of-Work challenge header.'
        };
      }
    }

    // 3. WAF Inspection: Scan headers, query parameters, and body payloads
    if (this.config.waf.enabled) {
      // Inspect Query Parameters
      if (context.query) {
        const queryCheck = this.wafEngine.inspectPayload(context.query);
        if (!queryCheck.safe) {
          return {
            allowed: false,
            statusCode: 403,
            reason: `WAF Block: Malicious query payload detected matching pattern [${queryCheck.matchedPattern}]`
          };
        }
      }

      // Inspect Request Body
      if (context.body) {
        const bodyCheck = this.wafEngine.inspectPayload(context.body);
        if (!bodyCheck.safe) {
          return {
            allowed: false,
            statusCode: 403,
            reason: `WAF Block: Malicious body payload detected matching pattern [${bodyCheck.matchedPattern}]`
          };
        }
      }
    }

    // 4. Rate Limiting: Enforce distributed token bucket consumption
    const clientIdentifier = context.ip; // In production, combine IP with API Key or JWT Subject
    const rateLimitResult = await this.tokenBucketStore.consume(
      clientIdentifier,
      this.config.rateLimit.maxCapacity,
      this.config.rateLimit.refillRatePerSecond
    );

    if (!rateLimitResult.allowed) {
      return {
        allowed: false,
        statusCode: 429,
        reason: 'Too Many Requests: Rate limit exceeded. Please throttle request velocity.'
      };
    }

    // Request successfully passed all defensive layers
    return { allowed: true };
  }
}

// ============================================================================
// Example Enterprise Configuration & Server Integration
// ============================================================================

const enterpriseSecurityConfig: SecurityConfig = {
  rateLimit: {
    maxCapacity: 10,
    refillRatePerSecond: 2, // 2 tokens added per second
    windowSeconds: 60
  },
  botDetection: {
    requireChallengeHeader: true,
    suspiciousUserAgents: [
      /curl/i,
      /python-requests/i,
      /puppeteer/i,
      /selenium/i,
      /headlesschrome/i
    ]
  },
  waf: {
    enabled: true,
    blockedPatterns: [
      /(\bUNION\b.*\bSELECT\b)/i, // SQL Injection
      /(<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>)/gi, // Cross-Site Scripting
      /(\.\.\/)+/g, // Path Traversal
      /(\bDROP\b.*\bTABLE\b)/i // SQL Destructive Command
    ]
  }
};

const gateway = new ApiProtectionGateway(enterpriseSecurityConfig);

/**
 * Mock HTTP Node.js request handler demonstrating gateway integration.
 */
export async function handleIncomingApiTraffic(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const ip = req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'] || '';
  const path = req.url || '/';
  const method = req.method || 'GET';

  // Extract query parameters
  const urlObj = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
  const query: Record<string, string> = {};
  urlObj.searchParams.forEach((val, key) => {
    query[key] = val;
  });

  // Read request body for POST/PUT requests
  let body: unknown = undefined;
  if (method === 'POST' || method === 'PUT') {
    body = await new Promise((resolve) => {
      let data = '';
      req.on('data', (chunk) => { data += chunk; });
      req.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve(data);
        }
      });
    });
  }

  const context: RequestContext = {
    ip,
    userAgent,
    path,
    method,
    headers: req.headers,
    body,
    query
  };

  const securityEvaluation = await gateway.evaluateRequest(context);

  if (!securityEvaluation.allowed) {
    res.writeHead(securityEvaluation.statusCode || 403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: securityEvaluation.reason }));
    return;
  }

  // Pass request to downstream microservice handlers...
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'success', message: 'Request authorized and processed.' }));
}
