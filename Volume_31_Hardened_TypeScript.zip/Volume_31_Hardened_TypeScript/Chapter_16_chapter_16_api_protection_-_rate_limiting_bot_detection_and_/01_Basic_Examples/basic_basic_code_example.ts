/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import * as http from 'http';
import { URL } from 'url';

/**
 * Interface representing the structure of an incoming API request context.
 */
interface RequestContext {
  ip: string;
  userAgent: string;
  path: string;
  method: string;
  body: string;
}

/**
 * Interface representing the state of a rate-limited client bucket.
 */
interface TokenBucket {
  tokens: number;
  lastRefill: number;
}

/**
 * In-memory store for rate limiting tokens. 
 * In a distributed SaaS environment, this would be backed by Redis.
 */
const rateLimitStore = new Map<string, TokenBucket>();

// Rate limit configuration constants
const CAPACITY = 5;          // Maximum number of bursts allowed
const REFILL_RATE = 1;       // Tokens refilled per second
const WINDOW_MS = 1000;      // Refill interval in milliseconds

/**
 * Evaluates whether an incoming IP address has exceeded its rate limit using a token bucket algorithm.
 * 
 * @param ip - The client's IP address extracted from the request headers or socket.
 * @returns boolean - True if the request is permitted, false if rate-limited.
 */
function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  let bucket = rateLimitStore.get(ip);

  if (!bucket) {
    // Initialize a new bucket for a first-time visitor
    bucket = { tokens: CAPACITY, lastRefill: now };
    rateLimitStore.set(ip, bucket);
  } else {
    // Calculate elapsed time and replenish tokens accordingly
    const elapsed = now - bucket.lastRefill;
    const tokensToAdd = Math.floor(elapsed / WINDOW_MS) * REFILL_RATE;
    
    if (tokensToAdd > 0) {
      bucket.tokens = Math.min(CAPACITY, bucket.tokens + tokensToAdd);
      bucket.lastRefill = now;
    }
  }

  // Evaluate token availability
  if (bucket.tokens > 0) {
    bucket.tokens -= 1;
    return true;
  }

  return false;
}

/**
 * Performs heuristic bot detection based on User-Agent signatures and behavioral anomalies.
 * 
 * @param userAgent - The User-Agent header string provided by the client.
 * @returns boolean - True if the request appears to originate from a known bad bot or scraper.
 */
function detectMaliciousBot(userAgent: string | undefined): boolean {
  if (!userAgent || userAgent.trim() === '') {
    // Missing user agents are highly correlated with automated scripts
    return true;
  }

  const normalizedUA = userAgent.toLowerCase();
  const knownBadSignatures = ['curl', 'python-requests', 'scrapy', 'postmanruntime', 'axios/0.'];

  // Check if the user-agent matches common programmatic scraping tools
  for (const signature of knownBadSignatures) {
    if (normalizedUA.includes(signature)) {
      return true;
    }
  }

  return false;
}

/**
 * Scans the request payload for common SQL injection (SQLi) and Cross-Site Scripting (XSS) patterns.
 * 
 * @param payload - The raw string body of the incoming HTTP request.
 * @returns boolean - True if malicious patterns are detected.
 */
function inspectWafRules(payload: string): boolean {
  if (!payload) return false;

  // Basic regular expressions for common attack vectors (SQLi & XSS)
  const sqlInjectionPattern = /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER)\b|--|\bOR\b\s+\d+=\d+)/i;
  const xssPattern = /(<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>|javascript:|onerror=)/i;

  return sqlInjectionPattern.test(payload) || xssPattern.test(payload);
}

/**
 * Main HTTP Server acting as the API Protection Gateway.
 */
const server = http.createServer(async (req: http.IncomingMessage, res: http.ServerResponse) => {
  const parsedUrl = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'];

  // Accumulate request body chunks
  let bodyChunks: Uint8Array[] = [];
  req.on('data', (chunk) => {
    bodyChunks.push(chunk);
  });

  req.on('end', () => {
    const rawBody = Buffer.concat(bodyChunks).toString();

    // 1. Bot Detection Layer
    if (detectMaliciousBot(userAgent)) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Access Denied: Automated traffic detected.' }));
      return;
    }

    // 2. Rate Limiting Layer
    if (!checkRateLimit(clientIp)) {
      res.writeHead(429, { 'Content-Type': 'application/json', 'Retry-After': '1' });
      res.end(JSON.stringify({ error: 'Too Many Requests: Rate limit exceeded.' }));
      return;
    }

    // 3. WAF Payload Inspection Layer
    if (inspectWafRules(rawBody)) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Bad Request: Malicious payload structure identified.' }));
      return;
    }

    // 4. Routing and Core Business Logic Handler
    if (parsedUrl.pathname === '/api/v1/profile' && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'success', message: 'Profile updated successfully.' }));
      return;
    }

    // Fallback for unmatched routes
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Endpoint not found.' }));
  });
});

// Start the server on port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`API Protection Gateway running on port ${PORT}`);
});
