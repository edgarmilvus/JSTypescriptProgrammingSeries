/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use server';

import { headers } from 'next/headers';
import { z } from 'zod';

// Define the expected input schema for our Server Action
const TransferFundsSchema = z.object({
  recipientId: z.string().uuid({ message: "Invalid recipient identifier format." }),
  amount: z.number().positive({ message: "Transfer amount must be greater than zero." }),
  clientTimestamp: z.number().int().positive({ message: "Invalid client timestamp." }),
});

type TransferFundsInput = z.infer<typeof TransferFundsSchema>;

type ActionResult<T> = 
  | { success: true; data: T }
  | { success: false; error: string; code: string };

/**
 * In-memory or Edge-backed mock store for Rate Limiting.
 * In a distributed production app, replace this with a Redis token bucket implementation.
 */
const rateLimitStore = new Map<string, { tokens: number; lastRefill: number }>();

const RATE_LIMIT_CONFIG = {
  maxTokens: 5,         // Maximum burst capacity
  refillRateMs: 10000,  // Refill window (10 seconds)
  tokensPerRefill: 5,   // Tokens added per window
};

/**
 * Evaluates the client's request against a token-bucket rate limiting algorithm.
 * 
 * @param identifier Unique client key (e.g., hashed IP address + User Agent)
 * @returns boolean indicating if the request is allowed
 */
function checkRateLimit(identifier: string): boolean {
  const now = Date.now();
  let bucket = rateLimitStore.get(identifier);

  if (!bucket) {
    bucket = { tokens: RATE_LIMIT_CONFIG.maxTokens, lastRefill: now };
    rateLimitStore.set(identifier, bucket);
  }

  // Calculate elapsed time and replenish tokens
  const elapsed = now - bucket.lastRefill;
  if (elapsed > RATE_LIMIT_CONFIG.refillRateMs) {
    const refills = Math.floor(elapsed / RATE_LIMIT_CONFIG.refillRateMs);
    bucket.tokens = Math.min(
      RATE_LIMIT_CONFIG.maxTokens, 
      bucket.tokens + refills * RATE_LIMIT_CONFIG.tokensPerRefill
    );
    bucket.lastRefill = now;
  }

  // Evaluate token availability
  if (bucket.tokens > 0) {
    bucket.tokens -= 1;
    return true;
  }

  return false;
}

/**
 * Performs heuristic bot detection based on request headers and execution timing.
 * 
 * @param clientTimestamp Timestamp provided by the client when form rendering or submission started
 * @returns boolean indicating if the request appears to originate from a bot/script
 */
function detectAutomatedTraffic(clientTimestamp: number): boolean {
  const requestHeaders = headers();
  const userAgent = requestHeaders.get('user-agent') || '';
  const secChUa = requestHeaders.get('sec-ch-ua');

  // Heuristic 1: Missing standard User-Agent header
  if (!userAgent || userAgent.length < 5) {
    return true;
  }

  // Heuristic 2: Known headless browser or common scraping signatures
  const botSignatures = ['headless', 'puppeteer', 'selenium', 'playwright', 'curl', 'python-requests', 'axios'];
  const lowerAgent = userAgent.toLowerCase();
  if (botSignatures.some(sig => lowerAgent.includes(sig))) {
    return true;
  }

  // Heuristic 3: Impossible human interaction speed (submission took less than 800ms from view)
  const now = Date.now();
  const duration = now - clientTimestamp;
  if (duration < 800) {
    return true; // Too fast for a human to read inputs and click submit
  }

  return false;
}

/**
 * Secure Server Action handling financial mutations with integrated WAF principles,
 * rate limiting, and bot mitigation.
 */
export async function executeSecureTransfer(input: TransferFundsInput): Promise<ActionResult<{ transactionId: string }>> {
  try {
    // 1. Extract contextual headers for identification and filtering
    const reqHeaders = headers();
    const forwardedFor = reqHeaders.get('x-forwarded-for') || '127.0.0.1';
    const userAgent = reqHeaders.get('user-agent') || 'unknown';
    
    // Create a composite identifier for rate limiting (IP + User-Agent hash base)
    const clientIdentifier = `${forwardedFor}-${userAgent.slice(0, 20)}`;

    // 2. Enforce Rate Limiting Strategy
    const isAllowed = checkRateLimit(clientIdentifier);
    if (!isAllowed) {
      console.warn(`[SECURITY] Rate limit exceeded for identifier: ${clientIdentifier}`);
      return { 
        success: false, 
        error: 'Too many requests. Please try again later.', 
        code: 'RATE_LIMIT_EXCEEDED' 
      };
    }

    // 3. Enforce Bot Detection & WAF Heuristics
    const isBot = detectAutomatedTraffic(input.clientTimestamp);
    if (isBot) {
      console.warn(`[SECURITY] Automated traffic / Bot blocked from IP: ${forwardedFor}`);
      return { 
        success: false, 
        error: 'Access denied. Automated behavior detected.', 
        code: 'BOT_DETECTED' 
      };
    }

    // 4. Strict Input Validation (WAF Layer protection against injection & malformed payloads)
    const validationResult = TransferFundsSchema.safeParse(input);
    if (!validationResult.success) {
      return { 
        success: false, 
        error: validationResult.error.errors.map(e => e.message).join(', '), 
        code: 'VALIDATION_FAILED' 
      };
    }

    // 5. Business Logic Execution (Simulated Secure Database Mutation)
    const { recipientId, amount } = validationResult.data;
    
    // In a real application, call database transaction wrappers here securely
    console.log(`[DATABASE] Processing transfer of $${amount} to recipient ${recipientId}`);
    
    const mockTransactionId = `txn_${Math.random().toString(36.substring(2, 15))}`;

    return {
      success: true,
      data: { transactionId: mockTransactionId }
    };

  } catch (err: unknown) {
    console.error('[CRITICAL] Unhandled error in secure transfer action:', err);
    return { 
      success: false, 
      error: 'An unexpected internal server error occurred.', 
      code: 'INTERNAL_SERVER_ERROR' 
    };
  }
}
