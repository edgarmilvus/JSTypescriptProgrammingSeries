/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

export class RateLimitExceededError extends Error {
  public readonly retryAfterSeconds: number;

  constructor(retryAfterSeconds: number, message: string = 'Rate limit exceeded') {
    super(message);
    this.name = 'RateLimitExceededError';
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

interface RateLimitConfig {
  windowSizeInMs: number;
  maxRequests: number;
  blockDurationInMs: number;
}

interface RateLimitRecord {
  currentWindowCount: number;
  previousWindowCount: number;
  windowStartTime: number;
  blockedUntil?: number;
}

export interface RateLimitHeaders {
  'X-RateLimit-Limit': string;
  'X-RateLimit-Remaining': string;
  'X-RateLimit-Reset': string;
  'Retry-After'?: string;
}

export class EdgeRateLimiter {
  private store: Map<string, RateLimitRecord> = new Map();
  private config: RateLimitConfig;

  constructor(config: RateLimitConfig) {
    this.config = config;
  }

  public checkLimit(clientId: string): { allowed: boolean; headers: RateLimitHeaders } {
    const now = Date.now();
    let record = this.store.get(clientId);

    // Handle initial state or clean up expired blocks
    if (record?.blockedUntil) {
      if (now < record.blockedUntil) {
        const retryAfter = Math.ceil((record.blockedUntil - now) / 1000);
        throw new RateLimitExceededError(retryAfter, 'Client is temporarily blocked due to rate limit violations.');
      } else {
        // Block has expired, reset record
        record.blockedUntil = undefined;
        record.currentWindowCount = 0;
        record.previousWindowCount = 0;
        record.windowStartTime = now;
      }
    }

    if (!record) {
      record = {
        currentWindowCount: 0,
        previousWindowCount: 0,
        windowStartTime: now,
      };
      this.store.set(clientId, record);
    }

    const elapsed = now - record.windowStartTime;

    // Slide window if window size has elapsed
    if (elapsed >= this.config.windowSizeInMs) {
      // Calculate how many windows have passed to correctly handle stale previous counts
      const windowsPassed = Math.floor(elapsed / this.config.windowSizeInMs);
      if (windowsPassed === 1) {
        record.previousWindowCount = record.currentWindowCount;
      } else {
        record.previousWindowCount = 0; // More than one window passed, previous window drops to zero
      }
      record.currentWindowCount = 0;
      record.windowStartTime = now + (elapsed % this.config.windowSizeInMs); // Anchor to cadence
    }

    const timeIntoCurrentWindow = now - record.windowStartTime;
    const weightPreviousWindow = Math.max(0, (this.config.windowSizeInMs - timeIntoCurrentWindow) / this.config.windowSizeInMs);
    
    // Corrected sliding window counter estimation formula
    const estimatedCount = Math.floor(record.currentWindowCount + (record.previousWindowCount * weightPreviousWindow));

    const resetTimeMs = record.windowStartTime + this.config.windowSizeInMs;
    const remaining = Math.max(0, this.config.maxRequests - estimatedCount);

    const headers: RateLimitHeaders = {
      'X-RateLimit-Limit': this.config.maxRequests.toString(),
      'X-RateLimit-Remaining': remaining.toString(),
      'X-RateLimit-Reset': Math.ceil(resetTimeMs / 1000).toString(),
    };

    if (estimatedCount >= this.config.maxRequests) {
      record.blockedUntil = now + this.config.blockDurationInMs;
      const retryAfter = Math.ceil(this.config.blockDurationInMs / 1000);
      headers['Retry-After'] = retryAfter.toString();
      throw new RateLimitExceededError(retryAfter, 'Rate limit threshold exceeded.');
    }

    record.currentWindowCount++;
    return { allowed: true, headers };
  }
}
