/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface TelemetryPoint {
  x: number;
  y: number;
  timestamp: number;
}

export class MouseTelemetryCollector {
  private points: TelemetryPoint[] = [];
  private isListening: boolean = false;
  private rafId: number | null = null;
  private maxBufferSize: number;
  private lastRecordedTime: number = 0;
  private throttleIntervalMs: number = 16; // ~60fps target

  constructor(maxBufferSize: number = 50) {
    this.maxBufferSize = maxBufferSize;
  }

  public start(): void {
    if (this.isListening) return;
    this.isListening = true;

    const handleMouseMove = (event: MouseEvent) => {
      const now = performance.now();
      if (now - this.lastRecordedTime < this.throttleIntervalMs) {
        return; // Throttle events to avoid main-thread saturation
      }
      this.lastRecordedTime = now;

      if (this.rafId !== null) {
        cancelAnimationFrame(this.rafId);
      }

      this.rafId = requestAnimationFrame(() => {
        const newPoint: TelemetryPoint = {
          x: event.clientX,
          y: event.clientY,
          timestamp: now,
        };

        this.points.push(newPoint);

        // Maintain fixed size sliding buffer to prevent memory leaks
        if (this.points.length > this.maxBufferSize) {
          this.points.shift();
        }
      });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    // Store reference for clean removal if needed
    (this as any)._boundHandler = handleMouseMove;
  }

  public stop(): TelemetryPoint[] {
    this.isListening = false;
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if ((this as any)._boundHandler) {
      window.removeEventListener('mousemove', (this as any)._boundHandler);
    }
    return [...this.points];
  }

  public async generateSignedPayload(secretKey: string): Promise<string> {
    const dataString = JSON.stringify(this.points);
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secretKey);
    const msgData = encoder.encode(dataString);

    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const signature = await crypto.subtle.sign('HMAC', cryptoKey, msgData);
    const hashArray = Array.from(new Uint8Array(signature));
    const signatureHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    return btoa(JSON.stringify({ telemetry: this.points, signature: signatureHex }));
  }
}
