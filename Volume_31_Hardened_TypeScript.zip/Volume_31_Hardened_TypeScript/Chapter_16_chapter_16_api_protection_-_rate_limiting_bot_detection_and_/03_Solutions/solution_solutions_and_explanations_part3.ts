/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

export type WafSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type WafTarget = 'URI' | 'HEADERS' | 'BODY' | 'QUERY';
export type WafAction = 'BLOCK' | 'LOG' | 'CHALLENGE';

export interface WafRule {
  id: string;
  severity: WafSeverity;
  target: WafTarget;
  pattern: RegExp;
  action: WafAction;
}

export interface HttpRequest {
  uri: string;
  headers: Record<string, string>;
  body?: string;
  query: Record<string, string>;
}

export interface WafEvaluationResult {
  blocked: boolean;
  triggeredRules: WafRule[];
  sanitizedRequest: HttpRequest;
}

export class WafEngine {
  private rules: WafRule[];

  constructor(rules: WafRule[]) {
    this.rules = rules;
  }

  public normalizeInput(input: string): string {
    let previous;
    let current = input;
    let iterations = 0;
    const maxIterations = 10; // Prevent infinite loops on malformed strings

    // Recursively decode and strip traversal patterns to defeat nested obfuscation
    do {
      previous = current;
      try {
        current = decodeURIComponent(current);
      } catch {
        // Fallback if malformed URI component encountered
        current = current;
      }

      current = current
        .replace(/\0/g, '') // Null bytes
        .replace(/\/\.+\//g, '/') // Intermediate dot slashes like /./ or /../
        .replace(/\.\.\//g, '') // Standard traversal forward
        .replace(/\.\.\\/g, ''); // Standard traversal backward

      iterations++;
    } while (current !== previous && iterations < maxIterations);

    return current;
  }

  public evaluate(request: HttpRequest): WafEvaluationResult {
    const triggeredRules: WafRule[] = [];
    let isBlocked = false;

    const sanitizedRequest: HttpRequest = {
      uri: this.normalizeInput(request.uri),
      headers: Object.fromEntries(Object.entries(request.headers).map(([k, v]) => [k, this.normalizeInput(v)])),
      body: request.body ? this.normalizeInput(request.body) : undefined,
      query: Object.fromEntries(Object.entries(request.query).map(([k, v]) => [k, this.normalizeInput(v)])),
    };

    for (const rule of this.rules) {
      const targetValues = this.getTargetValues(sanitizedRequest, rule.target);

      for (const val of targetValues) {
        const startTime = performance.now();
        let matched = false;

        try {
          // Execution budget enforcement against ReDoS (5ms budget)
          matched = rule.pattern.test(val);
          const executionTime = performance.now() - startTime;

          if (executionTime > 5) {
            console.warn(`WAF Warning: Rule ${rule.id} exceeded execution budget (${executionTime.toFixed(2)}ms). Failing closed.`);
            if (rule.severity === 'HIGH' || rule.severity === 'CRITICAL') {
              triggeredRules.push(rule);
              isBlocked = true;
              break;
            }
          }
        } catch {
          // Fail-closed on regex evaluation catastrophic errors
          matched = true;
        }

        if (matched) {
          triggeredRules.push(rule);
          if (rule.action === 'BLOCK' || rule.severity === 'HIGH' || rule.severity === 'CRITICAL') {
            isBlocked = true;
          }
        }
      }
      if (isBlocked && rule.severity === 'CRITICAL') break;
    }

    return { blocked: isBlocked, triggeredRules, sanitizedRequest };
  }

  private getTargetValues(req: HttpRequest, target: WafTarget): string[] {
    switch (target) {
      case 'URI':
        return [req.uri];
      case 'HEADERS':
        return Object.values(req.headers);
      case 'BODY':
        return req.body ? [req.body] : [];
      case 'QUERY':
        return Object.values(req.query);
      default:
        return [];
    }
  }
}
