/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback } from 'react';

interface ProtectedApiWrapperProps {
  endpoint: string;
  onSuccess: (data: unknown) => void;
  onError: (error: Error) => void;
  children: (triggerAction: () => Promise<void>, isLoading: boolean, state: ComponentState) => React.ReactNode;
}

type ComponentState = 'IDLE' | 'EVALUATING' | 'CHALLENGE' | 'EXECUTING' | 'ERROR';

export const ProtectedApiWrapper: React.FC<ProtectedApiWrapperProps> = ({
  endpoint,
  onSuccess,
  onError,
  children,
}) => {
  const [state, setState] = useState<ComponentState>('IDLE');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Simulated WebGPU / WebWorker Proof-of-Work solver
  const solveChallenge = async (challengeToken: string): Promise<string> => {
    // In production, execute WebGPU compute pipeline or worker hash collision loop
    return `proof-resolved-${challengeToken}-${Date.now()}`;
  };

  const executeProtectedAction = useCallback(async () => {
    setIsLoading(true);
    setState('EXECUTING');

    try {
      let response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Client-Attestation': 'active-session',
        },
        body: JSON.stringify({ timestamp: Date.now() }),
      });

      if (response.status === 403 || response.status === 429) {
        const challengeHeader = response.headers.get('X-Security-Challenge');
        if (challengeHeader) {
          setState('CHALLENGE');
          const proofToken = await solveChallenge(challengeHeader);

          // Retry request with cryptographic proof attached
          response = await fetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Client-Attestation': 'active-session',
              'X-Proof-Of-Work': proofToken,
            },
            body: JSON.stringify({ timestamp: Date.now() }),
          });
        }
      }

      if (!response.ok) {
        throw new Error(`API request failed with status: ${response.status}`);
      }

      const data = await response.json();
      onSuccess(data);
      setState('IDLE');
    } catch (err) {
      setState('ERROR');
      onError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setIsLoading(false);
    }
  }, [endpoint, onSuccess, onError]);

  return <>{children(executeProtectedAction, isLoading, state)}</>;
};
