/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export interface ThreatEvent {
  ipAddress: string;
  reason: string;
  expiresAt: number;
}

export class ThreatIntelligenceCache {
  private blacklist: Map<string, number> = new Map(); // IP -> Expiration Timestamp
  private cleanupInterval: NodeJS.Timeout;

  constructor(cleanupIntervalMs: number = 60000) {
    // Background sweep interval to prevent memory leaks from unqueried keys
    this.cleanupInterval = setInterval(() => {
      this.purgeExpiredEntries();
    }, cleanupIntervalMs);
  }

  public handleIncomingThreat(event: ThreatEvent): void {
    this.blacklist.set(event.ipAddress, event.expiresAt);
  }

  public isBlacklisted(ipAddress: string): boolean {
    const expiresAt = this.blacklist.get(ipAddress);
    if (!expiresAt) return false;

    if (Date.now() > expiresAt) {
      this.blacklist.delete(ipAddress);
      return false;
    }

    return true;
  }

  private purgeExpiredEntries(): void {
    const now = Date.now();
    for (const [ip, expiresAt] of this.blacklist.entries()) {
      if (now > expiresAt) {
        this.blacklist.delete(ip);
      }
    }
  }

  public destroy(): void {
    clearInterval(this.cleanupInterval);
    this.blacklist.clear();
  }
}

export class ThreatIntelligenceSync {
  private cache: ThreatIntelligenceCache;
  private isConnected: boolean = false;
  private reconnectAttempts: number = 0;
  private maxRetries: number = 5;

  constructor() {
    this.cache = new ThreatIntelligenceCache();
    this.connectPubSub();
  }

  private connectPubSub(): void {
    // Simulated connection to Redis Pub/Sub backbone
    try {
      this.isConnected = true;
      this.reconnectAttempts = 0;
    } catch {
      this.handleConnectionFailure();
    }
  }

  private handleConnectionFailure(): void {
    this.isConnected = false;
    if (this.reconnectAttempts < this.maxRetries) {
      const jitter = Math.random() * 200;
      const delay = Math.pow(2, this.reconnectAttempts) * 100 + jitter;
      this.reconnectAttempts++;
      setTimeout(() => this.connectPubSub(), delay);
    }
  }

  public publishThreat(ipAddress: string, reason: string, ttlSeconds: number): void {
    const expiresAt = Date.now() + (ttlSeconds * 1000);
    const event: ThreatEvent = { ipAddress, reason, expiresAt };

    // Update local cache immediately
    this.cache.handleIncomingThreat(event);

    // Broadcast over Pub/Sub to cluster peers (simulated)
    if (!this.isConnected) {
      console.warn('Pub/Sub disconnected. Threat broadcast queued locally.');
    }
  }

  public evaluateRequest(ipAddress: string): boolean {
    return this.cache.isBlacklisted(ipAddress);
  }

  public shutdown(): void {
    this.cache.destroy();
  }
}
