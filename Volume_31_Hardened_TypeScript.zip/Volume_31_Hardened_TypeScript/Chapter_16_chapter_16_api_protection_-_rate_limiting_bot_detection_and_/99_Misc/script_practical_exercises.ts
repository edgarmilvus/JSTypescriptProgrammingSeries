/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

interface RateLimitRecord {
  currentWindowCount: number;
  previousWindowCount: number;
  windowStartTime: number;
}

class EdgeRateLimiter {
  private store: Map<string, RateLimitRecord> = new Map();
  private windowSize: number;
  private max: number;

  constructor(windowSizeMs: number, maxRequests: number) {
    this.windowSize = windowSizeMs;
    this.max = maxRequests;
  }

  public checkLimit(clientId: string): boolean {
    const now = Date.now();
    let record = this.store.get(clientId);

    if (!record) {
      record = {
        currentWindowCount: 0,
        previousWindowCount: 0,
        windowStartTime: now,
      };
      this.store.set(clientId, record);
    }

    const elapsed = now - record.windowStartTime;

    if (elapsed > this.windowSize) {
      record.previousWindowCount = record.currentWindowCount;
      record.currentWindowCount = 0;
      record.windowStartTime = now;
    }

    const timeIntoCurrentWindow = now - record.windowStartTime;
    const weightPreviousWindow = (this.windowSize - timeIntoCurrentWindow) / this.windowSize;
    
    // TODO: Identify the flaw in the estimated count calculation below
    const estimatedCount = record.currentWindowCount + (record.previousWindowCount * weightPreviousWindow);

    if (estimatedCount >= this.max) {
      return false; // Rate limit exceeded
    }

    record.currentWindowCount++;
    return true;
  }
}
