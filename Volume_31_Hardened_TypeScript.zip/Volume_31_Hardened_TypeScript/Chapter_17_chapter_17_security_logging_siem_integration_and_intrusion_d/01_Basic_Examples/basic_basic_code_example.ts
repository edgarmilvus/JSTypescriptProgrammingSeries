/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * @fileoverview SaaS Security Telemetry, SIEM Integration, and Intrusion Detection Engine.
 * Implements Zero-Trust logging, signature verification, and automated incident response.
 */

// ==========================================
// TYPESCRIPT INTERFACES AND TYPE DEFINITIONS
// ==========================================

/**
 * Defines the strict schema for an incoming security telemetry payload.
 */
interface TelemetryPayload {
  readonly eventId: string;
  readonly timestamp: number;
  readonly tenantId: string;
  readonly sourceIp: string;
  readonly identity: {
    readonly userId: string;
    readonly roles: readonly string[];
    readonly mfaVerified: boolean;
  };
  readonly action: string;
  readonly bytesTransferred: number;
  readonly microsegmentId: string;
}

/**
 * Defines the structure of an evaluated security event ready for SIEM ingestion.
 */
interface SiemLogRecord extends TelemetryPayload {
  readonly severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  readonly anomalyDetected: boolean;
  readonly threatVector?: string;
}

/**
 * Configuration options for the SIEM and IDS collector.
 */
interface CollectorConfig {
  readonly siemEndpoint: string;
  readonly hmacSecret: string;
  readonly maxBandwidthBytes: number;
  readonly timeoutMs: number;
}

// ==========================================
// CORE SECURITY LOGGING & IDS ENGINE
// ==========================================

class SecurityTelemetryEngine {
  private readonly config: CollectorConfig;

  /**
   * Initializes the Security Telemetry Engine with configuration constraints.
   * @param config - The collector configuration parameters.
   */
  constructor(config: CollectorConfig) {
    this.config = config;
  }

  /**
   * Generates a cryptographic HMAC-SHA256 signature for payload integrity validation.
   * @param payloadString - The serialized string representation of the log payload.
   * @returns The hex-encoded HMAC signature string.
   */
  private generateHmacSignature(payloadString: string): string {
    return createHmac('sha256', this.config.hmacSecret)
      .update(payloadString)
      .digest('hex');
  }

  /**
   * Evaluates the telemetry payload against Zero-Trust policies and IDS heuristics.
   * 
   * @param rawPayload - The unvalidated incoming telemetry data.
   * @returns An enriched SiemLogRecord ready for transmission.
   */
  public evaluateTelemetry(rawPayload: TelemetryPayload): SiemLogRecord {
    let severity: SiemLogRecord['severity'] = 'LOW';
    let anomalyDetected = false;
    let threatVector: string | undefined = undefined;

    // Heuristic 1: Zero-Trust identity validation check
    if (!rawPayload.identity.mfaVerified) {
      severity = 'HIGH';
      anomalyDetected = true;
      threatVector = 'UNVERIFIED_MFA_ACCESS_ATTEMPT';
    }

    // Heuristic 2: Microsegmentation Data Exfiltration Detection (IDS)
    if (rawPayload.bytesTransferred > this.config.maxBandwidthBytes) {
      severity = 'CRITICAL';
      anomalyDetected = true;
      threatVector = 'EXCESSIVE_BANDWIDTH_MICROSEGMENT_BREACH';
    }

    // Heuristic 3: Suspicious privilege escalation pattern
    if (rawPayload.identity.roles.includes('GUEST') && rawPayload.action === 'ADMIN_OVERRIDE') {
      severity = 'CRITICAL';
      anomalyDetected = true;
      threatVector = 'PRIVILEGE_ESCALATION_ATTEMPT';
    }

    return {
      ...rawPayload,
      severity,
      anomalyDetected,
      ...(threatVector && { threatVector }),
    };
  }

  /**
   * Dispatches the enriched log record to the centralized SIEM platform with 
   * exhaustive asynchronous resilience and automated incident response routing.
   * 
   * @param record - The evaluated SiemLogRecord.
   */
  public async shipToSiem(record: SiemLogRecord): Promise<void> {
    const payloadString = JSON.stringify(record);
    const signature = this.generateHmacSignature(payloadString);
    
    // Resource tracking variable for cleanup in finally block
    let operationCompleted = false;

    try {
      // Establish an AbortController for request timeout management (Vercel/Serverless safety)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeoutMs);

      // Simulate sending data to a centralized SIEM endpoint (e.g., Splunk, Datadog, ELK)
      console.log(`[Zero-Trust SIEM]: Dispatching event ${record.eventId} to ${this.config.siemEndpoint}...`);

      // Mocking fetch request to external SIEM ingest API
      const response = await fetch(this.config.siemEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Signature-HMAC': signature,
          'X-ZeroTrust-Tenant': record.tenantId,
        },
        body: payloadString,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`SIEM ingestion failed with status: ${response.status} ${response.statusText}`);
      }

      operationCompleted = true;
      console.log(`[Zero-Trust SIEM]: Successfully ingested event ${record.eventId}. Severity: ${record.severity}`);

      // Trigger automated incident response playbook if anomaly is detected
      if (record.anomalyDetected) {
        await this.triggerIncidentResponsePlaybook(record);
      }

    } catch (error: unknown) {
      // Handle asynchronous failures gracefully without crashing the core execution pipeline
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          console.error(`[SIEM Error]: Request timed out after ${this.config.timeoutMs}ms while shipping event ${record.eventId}`);
        } else {
          console.error(`[SIEM Error]: Failed to ship telemetry record ${record.eventId}:`, error.message);
        }
      } else {
        console.error(`[SIEM Error]: Unknown error occurred while shipping telemetry record ${record.eventId}`);
      }
      
      // Fallback mechanism: Write critical logs to secondary persistent storage or local dead-letter queue
      this.writeToFallbackDeadLetterQueue(record);

    } finally {
      // Mandatory resource cleanup and audit logging execution block
      if (!operationCompleted) {
        console.warn(`[Audit Warning]: Telemetry dispatch cycle completed with errors for eventId: ${record.eventId}`);
      }
      // Clean up internal connection pools, metrics timers, or cryptographic state references here
    }
  }

  /**
   * Executes an automated incident response playbook when an IDS anomaly is caught.
   * @param record - The security record that triggered the IDS alert.
   */
  private async triggerIncidentResponsePlaybook(record: SiemLogRecord): Promise<void> {
    console.warn(`[AUTOMATED PLAYBOOK]: Initializing containment for Threat Vector: [${record.threatVector}] on Tenant: ${record.tenantId}`);
    
    // Simulate programmatic API calls to revoke sessions, isolate microsegments, or alert SecOps SOC
    await new Promise((resolve) => setTimeout(resolve, 100)); // Simulate async network call
    
    console.warn(`[AUTOMATED PLAYBOOK]: User session ${record.identity.userId} terminated and IP ${record.sourceIp} quarantined.`);
  }

  /**
   * Fallback mechanism to ensure no log data is lost during SIEM network partitions.
   * @param record - The failed log record.
   */
  private writeToFallbackDeadLetterQueue(record: SiemLogRecord): void {
    // In a real production system, this writes to a local encrypted file or Redis stream
    console.error(`[DEAD-LETTER QUEUE]: Persisted failed event ${record.eventId} locally for manual forensic audit.`);
  }
}

// ==========================================
// EXECUTION DEMONSTRATION (SAAS CONTEXT)
// ==========================================

async function runSecurityPipeline(): Promise<void> {
  const engine = new SecurityTelemetryEngine({
    siemEndpoint: 'https://siem.internal.saas-provider.net/api/v1/ingest',
    hmacSecret: 'super-secure-production-hmac-secret-key-2026',
    maxBandwidthBytes: 5000000, // 5MB threshold for microsegment anomaly detection
    timeoutMs: 3000,
  });

  // Incoming anomalous telemetry sample simulating an insider threat or compromised container
  const incomingTelemetry: TelemetryPayload = {
    eventId: 'evt_9988776655_xyz',
    timestamp: Date.now(),
    tenantId: 'tenant_enterprise_alpha',
    sourceIp: '192.168.45.12',
    identity: {
      userId: 'usr_compromised_99',
      roles: ['GUEST'],
      mfaVerified: false,
    },
    action: 'ADMIN_OVERRIDE',
    bytesTransferred: 12500000, // Exceeds 5MB threshold!
    microsegmentId: 'seg-payment-gateway-db',
  };

  console.log('--- Initiating Zero-Trust Telemetry Evaluation ---');
  const evaluatedRecord = engine.evaluateTelemetry(incomingTelemetry);
  await engine.shipToSiem(evaluatedRecord);
}

// Execute the pipeline
runSecurityPipeline().catch((err) => {
  console.error('Fatal unhandled error in security pipeline runner:', err);
});
