/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Enterprise Security Telemetry & SIEM Integration Engine
 * @module SecurityTelemetry
 * @version 1.0.0
 */

import { headers } from 'next/headers';
import { createHmac } from 'crypto';

/**
 * Enumeration of critical security event severities.
 */
export enum SecuritySeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

/**
 * Standardized interface for security log payloads ingested by the SIEM.
 */
export interface SecurityEventPayload {
  eventId: string;
  timestamp: string;
  severity: SecuritySeverity;
  category: 'IAM' | 'AI_PROMPT_INJECTION' | 'SUPPLY_CHAIN' | 'MICROSEGMENTATION';
  actor: {
    userId?: string;
    ipAddress: string;
    userAgent: string;
  };
  details: Record<string, unknown>;
  signature: string;
}

/**
 * Configuration options for the SIEM Telemetry Dispatcher.
 */
interface SiemConfig {
  endpoint: string;
  apiKey: string;
  hmacSecret: string;
  environment: string;
}

/**
 * Production-grade SIEM Telemetry Engine enforcing Exhaustive Asynchronous Resilience.
 */
export class SecurityTelemetryEngine {
  private config: SiemConfig;

  constructor(config: SiemConfig) {
    this.config = config;
  }

  /**
   * Generates a cryptographic HMAC signature to ensure log integrity during transit.
   * @private
   */
  private generateSignature(payloadString: string): string {
    return createHmac('sha256', this.config.hmacSecret)
      .update(payloadString)
      .digest('hex');
  }

  /**
   * Captures, structures, signs, and dispatches a security event to the SIEM.
   * Implements mandatory try/catch/finally blocks for resilience.
   * 
   * @param severity The operational severity of the event.
   * @param category The security domain classification.
   * @param details Contextual metadata regarding the event.
   */
  public async logSecurityEvent(
    severity: SecuritySeverity,
    category: SecurityEventPayload['category'],
    details: Record<string, unknown>
  ): Promise<boolean> {
    const startTime = performance.now();
    let isDispatched = false;

    // Extract runtime headers securely within a Next.js Server context
    const requestHeaders = await headers();
    const ipAddress = requestHeaders.get('x-forwarded-for') || '127.0.0.1';
    const userAgent = requestHeaders.get('user-agent') || 'Unknown-Agent';
    const userId = (requestHeaders.get('x-user-id') as string) || undefined;

    const eventId = `sec_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const timestamp = new Date().toISOString();

    const rawPayload: Omit<SecurityEventPayload, 'signature'> = {
      eventId,
      timestamp,
      severity,
      category,
      actor: {
        userId,
        ipAddress,
        userAgent,
      },
      details: {
        ...details,
        environment: this.config.environment,
      },
    };

    const payloadString = JSON.stringify(rawPayload);
    const signature = this.generateSignature(payloadString);

    const finalPayload: SecurityEventPayload = {
      ...rawPayload,
      signature,
    };

    try {
      // Enforce timeout abort controller for external SIEM ingestion API calls
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const response = await fetch(this.config.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`,
          'X-SIEM-Environment': this.config.environment,
        },
        body: JSON.stringify(finalPayload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`SIEM ingestion failed with status: ${response.status} ${response.statusText}`);
      }

      isDispatched = true;
    } catch (error: unknown) {
      // Exhaustive fallback: Log locally to secure standard error stream if SIEM is unreachable
      const errorMessage = error instanceof Error ? error.message : 'Unknown asynchronous error';
      console.error(
        JSON.stringify({
          level: 'FATAL',
          message: 'CRITICAL_SIEM_INGESTION_FAILURE',
          originalEvent: finalPayload,
          error: errorMessage,
          timestamp: new Date().toISOString(),
        })
      );
      isDispatched = false;
    } finally {
      // Resource monitoring and telemetry execution latency audit
      const duration = performance.now() - startTime;
      if (duration > 1000) {
        console.warn(`[Performance Warning] Security telemetry dispatch took ${duration.toFixed(2)}ms`);
      }
    }

    return isDispatched;
  }
}

// Singleton instantiation for application-wide usage
export const securityEngine = new SecurityTelemetryEngine({
  endpoint: process.env.SIEM_INGESTION_ENDPOINT || 'https://siem.internal.enterprise/v1/logs',
  apiKey: process.env.SIEM_API_KEY || 'mock-api-key',
  hmacSecret: process.env.SIEM_HMAC_SECRET || 'mock-secret',
  environment: process.env.NODE_ENV || 'production',
});
