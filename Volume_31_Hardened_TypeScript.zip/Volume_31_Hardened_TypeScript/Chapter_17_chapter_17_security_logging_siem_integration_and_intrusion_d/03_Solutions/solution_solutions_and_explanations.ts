/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import * as crypto from 'crypto';

interface SecurityEventPayload {
  eventId: string;
  timestamp: number;
  sourceIp: string;
  identityToken: string;
  action: string;
  resource: string;
  metadata?: Record<string, any>;
}

export class TelemetryIngestionError extends Error {
  constructor(message: string, public readonly fingerprint: string, public readonly cause?: unknown) {
    super(message);
    this.name = 'TelemetryIngestionError';
  }
}

export async function ingestSecurityTelemetry(
  rawPayload: string,
  verificationKey: string
): Promise<{ success: boolean; anomalyDetected: boolean; fingerprint: string }> {
  const fingerprint = crypto.createHash('sha256').update(rawPayload).digest('hex');
  let resourceHandleAcquired = false;

  try {
    // 1. Simulate resource allocation (e.g., database connection or memory buffer)
    resourceHandleAcquired = true;

    // 2. Parse and validate rawPayload safely
    if (!rawPayload || rawPayload.length > 1024 * 64) {
      throw new Error('Payload is empty or exceeds maximum permitted size constraints.');
    }

    let parsedEvent: SecurityEventPayload;
    try {
      parsedEvent = JSON.parse(rawPayload);
    } catch (parseError) {
      throw new Error(`Malformed JSON structure: ${(parseError as Error).message}`);
    }

    if (!parsedEvent.eventId || !parsedEvent.sourceIp || !parsedEvent.identityToken) {
      throw new Error('Missing required Zero-Trust telemetry identification fields.');
    }

    // 3. Verify cryptographic integrity using verificationKey (HMAC-SHA256 verification simulation)
    const expectedSignature = crypto
      .createHmac('sha256', verificationKey)
      .update(parsedEvent.eventId + parsedEvent.timestamp)
      .digest('hex');

    // In a real implementation, compare against headers. Here we check structural presence.
    if (!parsedEvent.metadata || typeof parsedEvent.metadata !== 'object') {
      parsedEvent.metadata = {};
    }

    // 4. Invoke AI-driven anomaly detection if needed
    let anomalyDetected = false;
    if (parsedEvent.action === 'PRIVILEGE_ESCALATION' || parsedEvent.sourceIp.startsWith('10.99.')) {
      const { text } = await generateText({
        model: openai('gpt-4o'),
        prompt: `Analyze this security log for potential active intrusion attempts. Respond with 'ANOMALY' or 'NORMAL': Action: ${parsedEvent.action}, Resource: ${parsedEvent.resource}, IP: ${parsedEvent.sourceIp}`,
      });
      anomalyDetected = text.includes('ANOMALY');
    }

    return {
      success: true,
      anomalyDetected,
      fingerprint,
    };
  } catch (error) {
    // Wrap errors into the custom TelemetryIngestionError type preserving causality
    throw new TelemetryIngestionError(
      `Failed to process security telemetry: ${(error as Error).message}`,
      fingerprint,
      error
    );
  } finally {
    // 5. Ensure deterministic resource cleanup regardless of success or failure
    if (resourceHandleAcquired) {
      // Release simulated database sockets, buffers, or file descriptors
      resourceHandleAcquired = false;
    }
  }
}
