/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

export interface IdentityContext {
  userId: string;
  role: string;
  deviceAttestationScore: number;
  lastKnownGeo: { lat: number; lon: number };
  activePermissions: string[];
}

export interface AccessRequest {
  targetResource: string;
  requestedAction: string;
  currentGeo: { lat: number; lon: number };
  timestamp: number;
}

const AnomalySchema = z.object({
  anomalyScore: z.number().min(0).max(1),
  reasoning: z.string(),
  recommendedAction: z.enum(['ALLOW', 'CHALLENGE', 'BLOCK']),
});

export async function evaluateIdentityAnomaly(
  context: IdentityContext,
  request: AccessRequest
): Promise<z.infer<typeof AnomalySchema>> {
  let sessionLockAcquired = true;

  try {
    // 1. Construct prompt payload analyzing impossible travel or privilege variance
    const prompt = `
      Evaluate the following zero-trust access request for behavioral identity anomalies:
      User Context: ${JSON.stringify(context)}
      Access Request: ${JSON.stringify(request)}
      Consider distance between lastKnownGeo and currentGeo against elapsed time, role limitations, and device attestation score.
    `;

    // 2. Invoke generateObject with Zod validation backed by Vercel AI SDK
    const { object } = await generateObject({
      model: openai('gpt-4o'),
      schema: AnomalySchema,
      prompt,
    });

    return object;
  } catch (error) {
    // 3. Implement secure fallback: Fail closed (BLOCK) if the evaluation service times out or errors
    return {
      anomalyScore: 1.0,
      reasoning: `AI Identity evaluation pipeline failed due to error: ${(error as Error).message}. Zero-Trust fail-closed policy enforced.`,
      recommendedAction: 'BLOCK',
    };
  } finally {
    // 4. Guarantee session state cache unlocking or cleanup
    if (sessionLockAcquired) {
      sessionLockAcquired = false;
      // Release distributed redis lock or local memory mutex for the user session
    }
  }
}
