/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useChat } from 'ai/react';
import React from 'react';

interface SecurityAlert {
  id: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  timestamp: number;
  sourceService: string;
}

interface DashboardProps {
  initialAlerts: SecurityAlert[];
  systemHealthStatus: 'SECURE' | 'DEGRADED' | 'COMPROMISED';
}

export function NaturalLanguageSIEMQuery() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/security/chat',
  });

  return (
    <div className="p-4 border border-zinc-700 rounded-lg bg-zinc-900 text-zinc-100 shadow-xl">
      <h3 className="text-lg font-semibold mb-3">SIEM Natural Language Threat Hunter</h3>
      <div className="space-y-3 mb-4 max-h-60 overflow-y-auto p-2 bg-zinc-950 rounded border border-zinc-800">
        {messages.map((m) => (
          <div key={m.id} className={`text-sm ${m.role === 'user' ? 'text-blue-400' : 'text-emerald-400'}`}>
            <span className="font-bold">{m.role === 'user' ? 'Analyst: ' : 'SIEM AI: '}</span>
            {m.content}
          </div>
        ))}
        {messages.length === 0 && (
          <p className="text-zinc-500 italic text-sm">Ask questions like: &quot;Show high severity identity anomalies from the last 15 minutes.&quot;</p>
        )}
      </div>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Query active SIEM telemetry..."
          className="flex-1 bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-blue-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm font-medium transition-colors disabled:opacity-50"
        >
          {isLoading ? 'Analyzing...' : 'Query'}
        </button>
      </form>
    </div>
  );
}

export default async function SecurityOperationsDashboard({
  initialAlerts,
  systemHealthStatus,
}: DashboardProps) {
  let dashboardDataValid = true;

  try {
    // Perform any server-side validation or enrichment of initial props here
    if (!initialAlerts) {
      dashboardDataValid = false;
    }
  } catch (error) {
    dashboardDataValid = false;
  } finally {
    // Server-side cleanup or metric recording logic
  }

  if (!dashboardDataValid) {
    return (
      <main className="p-6 bg-zinc-950 text-red-500 min-h-screen">
        <h1 className="text-2xl font-bold">Zero-Trust Security Operations</h1>
        <p className="mt-4">Error: Unable to load security dashboard telemetry buffers.</p>
      </main>
    );
  }

  return (
    <main className="p-6 space-y-6 bg-zinc-950 text-zinc-100 min-h-screen">
      <div className="flex justify-between items-center border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-bold">Zero-Trust Security Operations</h1>
          <p className="text-sm text-zinc-400">Real-time telemetry, SIEM log analysis, and incident orchestration.</p>
        </div>
        <span
          className={`px-3 py-1 rounded text-sm font-semibold ${
            systemHealthStatus === 'SECURE'
              ? 'bg-emerald-900/50 text-emerald-300 border border-emerald-700'
              : systemHealthStatus === 'DEGRADED'
              ? 'bg-amber-900/50 text-amber-300 border border-amber-700'
              : 'bg-red-900/50 text-red-300 border border-red-700'
          }`}
        >
          Status: {systemHealthStatus}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xl font-semibold">Active Security Alerts</h2>
          <div className="border border-zinc-800 rounded-lg overflow-hidden bg-zinc-900">
            <table className="w-full text-left text-sm">
              <thead className="bg-zinc-800 text-zinc-300 uppercase text-xs">
                <tr>
                  <th className="p-3">Severity</th>
                  <th className="p-3">Source Service</th>
                  <th className="p-3">Description</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800">
                {initialAlerts.map((alert) => (
                  <tr key={alert.id} className="hover:bg-zinc-800/50">
                    <td className="p-3 font-bold">
                      <span
                        className={`px-2 py-0.5 rounded text-xs ${
                          alert.severity === 'CRITICAL'
                            ? 'bg-red-800 text-white'
                            : alert.severity === 'HIGH'
                            ? 'bg-orange-800 text-white'
                            : 'bg-yellow-800 text-white'
                        }`}
                      >
                        {alert.severity}
                      </span>
                    </td>
                    <td className="p-3 text-zinc-300">{alert.sourceService}</td>
                    <td className="p-3 text-zinc-100">{alert.description}</td>
                    <td className="p-3 text-zinc-400">{new Date(alert.timestamp).toLocaleTimeString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <NaturalLanguageSIEMQuery />
        </div>
      </div>
    </main>
  );
}
