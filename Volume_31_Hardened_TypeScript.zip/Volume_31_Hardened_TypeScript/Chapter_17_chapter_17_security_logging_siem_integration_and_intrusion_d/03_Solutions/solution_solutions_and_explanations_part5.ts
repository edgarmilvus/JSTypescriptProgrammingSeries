/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import * as crypto from 'crypto';

export interface ArtifactReceipt {
  artifactId: string;
  sha256Hash: string;
  signature: string;
  builderId: string;
  timestamp: number;
}

export interface VerificationResult {
  artifactId: string;
  verified: boolean;
  errorReason?: string;
}

const TamperingAnalysisSchema = z.object({
  riskLevel: z.enum(['NEGLIGIBLE', 'SUSPICIOUS', 'CRITICAL_TAMPERING']),
  analysisSummary: z.string(),
  recommendedAction: z.string(),
});

export async function verifySupplyChainAttestations(
  receipts: ArtifactReceipt[],
  rootPublicKey: string
): Promise<{ allPassed: boolean; results: VerificationResult[]; analysis?: z.infer<typeof TamperingAnalysisSchema> }> {
  const results: VerificationResult[] = [];
  let databaseBufferFlushed = false;

  try {
    // 1. Verify signatures across all receipts in parallel using Promise.allSettled
    const verificationPromises = receipts.map(async (receipt): Promise<VerificationResult> => {
      try {
        // Simulate cryptographic signature verification against rootPublicKey
        const hmac = crypto.createHmac('sha256', rootPublicKey);
        hmac.update(receipt.artifactId + receipt.sha256Hash + receipt.builderId);
        const computedSignature = hmac.digest('hex');

        // Simulate signature check (in real production, use crypto.verify)
        const isValid = receipt.signature.length > 0 && receipt.sha256Hash.length === 64;

        if (!isValid) {
          throw new Error(`Cryptographic signature mismatch for artifact ${receipt.artifactId}`);
        }

        return {
          artifactId: receipt.artifactId,
          verified: true,
        };
      } catch (err) {
        return {
          artifactId: receipt.artifactId,
          verified: false,
          errorReason: (err as Error).message,
        };
      }
    });

    const settledOutcomes = await Promise.allSettled(verificationPromises);

    for (const outcome of settledOutcomes) {
      if (outcome.status === 'fulfilled') {
        results.push(outcome.value);
      } else {
        results.push({
          artifactId: 'UNKNOWN',
          verified: false,
          errorReason: outcome.reason?.message || 'Unhandled asynchronous rejection during receipt verification',
        });
      }
    }

    const failedReceipts = results.filter((r) => !r.verified);
    const allPassed = failedReceipts.length === 0;

    let analysis: z.infer<typeof TamperingAnalysisSchema> | undefined = undefined;

    // 4. If failures exist, invoke Vercel AI SDK to analyze potential tampering vs benign drift
    if (!allPassed) {
      const { object } = await generateObject({
        model: openai('gpt-4o'),
        schema: TamperingAnalysisSchema,
        prompt: `
          Analyze the following supply chain verification failures to determine if they represent benign configuration drift or active tampering:
          Failures: ${JSON.stringify(failedReceipts)}
        `,
      });
      analysis = object;
    }

    return {
      allPassed,
      results,
      analysis,
    };
  } catch (error) {
    throw new Error(`Supply chain auditing pipeline encountered a fatal error: ${(error as Error).message}`);
  } finally {
    // 3. Guarantee state flushing and metric emission in a finally block
    databaseBufferFlushed = true;
    // Emit audit ledger metrics to SIEM store (Simulated)
  }
}
