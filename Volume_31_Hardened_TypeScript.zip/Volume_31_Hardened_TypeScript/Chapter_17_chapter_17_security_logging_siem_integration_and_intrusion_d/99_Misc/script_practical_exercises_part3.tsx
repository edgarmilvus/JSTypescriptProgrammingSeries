/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

'use client';

import { useChat } from 'ai/react';
import React from 'react';

interface SecurityAlert {
  id: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  timestamp: number;
  sourceService: string;
}

interface DashboardProps {
  initialAlerts: SecurityAlert[];
  systemHealthStatus: 'SECURE' | 'DEGRADED' | 'COMPROMISED';
}

export function NaturalLanguageSIEMQuery() {
  // TODO: Implement useChat hook for natural language security log interrogation
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/security/chat',
  });

  return (
    <div className="p-4 border rounded-lg bg-zinc-900 text-zinc-100">
      <h3 className="text-lg font-semibold mb-2">SIEM Natural Language Threat Hunter</h3>
      {/* Render chat messages and input form here */}
    </div>
  );
}

export default async function SecurityOperationsDashboard({
  initialAlerts,
  systemHealthStatus,
}: DashboardProps) {
  // TODO: Render the main dashboard layout combining metrics, alert tables, and the chat query component
  return (
    <main className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Zero-Trust Security Operations</h1>
        <span className={`px-3 py-1 rounded text-sm ${systemHealthStatus === 'SECURE' ? 'bg-green-800' : 'bg-red-800'}`}>
          Status: {systemHealthStatus}
        </span>
      </div>
      {/* Implement alert rendering and NaturalLanguageSIEMQuery integration */}
    </main>
  );
}
