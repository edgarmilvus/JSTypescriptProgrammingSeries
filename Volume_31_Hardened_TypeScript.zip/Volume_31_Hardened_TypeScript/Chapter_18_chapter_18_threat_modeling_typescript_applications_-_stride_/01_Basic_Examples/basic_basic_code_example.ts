/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import express, { Request, Response, NextFunction } from 'express';

// ============================================================================
// SAAS APP CONTEXT: User Profile & Workspace Settings Update Service
// ============================================================================

/**
 * Represents the database record of a SaaS user.
 */
interface UserRecord {
    id: string;
    email: string;
    role: 'MEMBER' | 'ADMIN' | 'SUPER_ADMIN';
    workspaceId: string;
    bio: string;
}

// In-memory mock database for demonstration purposes
const mockDatabase: Record<string, UserRecord> = {
    'user-123': {
        id: 'user-123',
        email: 'alice@saas-startup.com',
        role: 'MEMBER', // Standard user role
        workspaceId: 'workspace-alpha',
        bio: 'Just a regular team member.',
    },
};

// ============================================================================
// 1. VULNERABLE IMPLEMENTATION (Demonstrating STRIDE: Elevation of Privilege)
// ============================================================================

/**
 * VULNERABLE CONTROLLER: 
 * This controller blindly trusts the incoming request body, allowing a malicious 
 * client to inject properties like 'role' or 'workspaceId', leading to 
 * Privilege Escalation and Tampering.
 */
export function createVulnerableUpdateEndpoint(app: express.Application) {
    app.patch('/api/v1/profile/vulnerable', async (req: Request, res: Response) => {
        const userId = req.headers['x-user-id'] as string;
        const user = mockDatabase[userId];

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // VULNERABILITY: Using type assertion to bypass structural shape validation.
        // The developer assumes req.body only contains safe fields like 'bio', 
        // but an attacker can send JSON: { "bio": "hacked", "role": "SUPER_ADMIN" }
        const untrustedUpdates = req.body as UserRecord;

        // Mutating the database record directly with untrusted input fields
        user.bio = untrustedUpdates.bio ?? user.bio;
        
        // PRIVILEGE ESCALATION VULNERABILITY: 
        // Because 'role' was present in untrustedUpdates, the user becomes a SUPER_ADMIN.
        if (untrustedUpdates.role) {
            user.role = untrustedUpdates.role;
        }

        return res.status(200).json({
            success: true,
            message: 'Profile updated successfully (Vulnerable Mode)',
            data: user,
        });
    });
}

// ============================================================================
// 2. SECURE IMPLEMENTATION (Strict Type Discipline & Zero-Trust Mitigation)
// ============================================================================

/**
 * Explicit DTO (Data Transfer Object) for profile updates.
 * Only permits modification of non-sensitive fields. 'role' and 'id' are strictly excluded.
 */
interface SafeProfileUpdateDTO {
    bio: string;
}

/**
 * Runtime type guard to ensure strict type compliance at runtime 
 * against deserialization attacks or malformed JSON payloads.
 */
function isSafeProfileUpdateDTO(body: unknown): body is SafeProfileUpdateDTO {
    if (typeof body !== 'object' || body === null) {
        return false;
    }
    
    // Check that 'bio' exists and is a string
    const candidate = body as Record<string, unknown>;
    return typeof candidate.bio === 'string';
}

/**
 * SECURE CONTROLLER:
 * Implements strict type discipline, explicit DTO filtering, and least privilege.
 */
export function createSecureUpdateEndpoint(app: express.Application) {
    app.patch('/api/v1/profile/secure', (req: Request, res: Response, next: NextFunction) => {
        try {
            const userId = req.headers['x-user-id'];
            if (typeof userId !== 'string' || !mockDatabase[userId]) {
                return res.status(401).json({ error: 'Unauthorized' });
            }

            const user = mockDatabase[userId];
            const rawBody: unknown = req.body;

            // Runtime Boundary Enforcement: Validate shape before processing
            if (!isSafeProfileUpdateDTO(rawBody)) {
                return res.status(400).json({ 
                    error: 'Bad Request: Invalid payload structure. Only "bio" string is allowed.' 
                });
            }

            // At this point, TypeScript narrows 'rawBody' to 'SafeProfileUpdateDTO'.
            // Privileged fields like 'role', 'id', and 'workspaceId' cannot be accessed or modified.
            user.bio = rawBody.bio.trim();

            return res.status(200).json({
                success: true,
                message: 'Profile updated securely under Zero-Trust rules.',
                data: {
                    id: user.id,
                    email: user.email,
                    role: user.role, // Preserved securely from the server-side session, not client input
                    workspaceId: user.workspaceId,
                    bio: user.bio,
                },
            });
        } catch (error) {
            next(error);
        }
    });
}
