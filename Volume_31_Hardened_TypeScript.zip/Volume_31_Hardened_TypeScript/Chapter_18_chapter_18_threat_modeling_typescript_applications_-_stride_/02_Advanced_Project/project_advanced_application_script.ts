/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';
import { NextResponse } from 'next/server';

/**
 * @fileoverview Secure Tool Handler and Graph State Manager for ReAct Execution.
 * Implements strict STRIDE mitigations for a Next.js API route handling 
 * autonomous agent loops.
 */

// ============================================================================
// 1. Graph State & Tool Invocation Signatures (STRIDE: Tampering / Elevation)
// ============================================================================

/**
 * Defines the immutable Graph State interface passed between execution nodes.
 * Runtime validation ensures attackers cannot inject unauthorized properties 
 * to hijack the control flow (Elevation of Privilege).
 */
export const GraphStateSchema = z.object({
  sessionId: z.string().uuid({ message: "Invalid session identifier format." }),
  tenantId: z.string().min(1, { message: "Tenant ID is required." }),
  executionStep: z.number().int().nonnegative(),
  thought: z.string().max(2000, { message: "Thought trace exceeds maximum length." }),
  actionPayload: z.record(z.unknown()),
  observation: z.string().optional(),
});

export type GraphState = z.infer<typeof GraphStateSchema>;

/**
 * Tool Invocation Signature interface for dynamic function execution.
 * Enforces strict typing for parameters passed from the LLM framework.
 */
interface ToolExecutionContext {
  state: GraphState;
  secretContextToken: string;
}

type ToolHandlerResult = {
  success: boolean;
  updatedObservation: string;
  sanitizedMetadata?: Record<string, unknown>;
};

// ============================================================================
// 2. Secure Tool Handler Implementation (STRIDE: Information Disclosure)
// ============================================================================

/**
 * Executes a database or external API action requested by the LLM ReAct loop.
 * Strips sensitive internal error details to prevent Information Disclosure.
 * 
 * @param context - The tool execution context containing validated state and security tokens.
 * @returns Promise resolving to the tool execution results.
 */
async function executeDatabaseQueryTool(context: ToolExecutionContext): Promise<ToolHandlerResult> {
  const { state, secretContextToken } = context;

  // Verify internal execution authorization boundary
  if (!secretContextToken || secretContextToken !== process.env.INTERNAL_WORKER_SECRET) {
    throw new Error("Unauthorized tool execution attempt detected.");
  }

  try {
    // Extract parameters safely from the validated action payload
    const query = typeof state.actionPayload.query === 'string' 
      ? state.actionPayload.query 
      : '';

    if (!query.toLowerCase().startsWith('select')) {
      throw new Error("Only read-only SELECT queries are permitted through this tool handler.");
    }

    // Simulate secure database fetch using parameterized queries (Preventing SQL Injection)
    // In production, connect via a secure pool with tenant isolation.
    const mockDbResult = {
      rowsAffected: 0,
      data: [{ id: 1, tenant: state.tenantId, summary: "Sanitized query output record." }],
    };

    return {
      success: true,
      updatedObservation: JSON.stringify(mockDbResult.data),
      sanitizedMetadata: { rowsReturned: mockDbResult.data.length }
    };
  } catch (error: unknown) {
    // STRIDE Mitigation: Log full error internally, return generic message to caller
    console.error(`[Security Log] Tool execution failed for session ${state.sessionId}:`, error);
    
    return {
      success: false,
      updatedObservation: "Execution failed: An internal error occurred while processing the tool request.",
    };
  }
}

// ============================================================================
// 3. Next.js API Route Handler (STRIDE: Spoofing / DoS)
// ============================================================================

/**
 * Next.js Edge/Serverless API route handling the Thought-Action-Observation cycle.
 * Implements payload size limits, request validation, and timeout controls.
 */
export async function POST(request: Request): Promise<NextResponse> {
  try {
    // STRIDE Mitigation (DoS): Enforce strict Content-Type and payload constraints
    const contentType = request.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      return NextResponse.json({ error: "Unsupported Media Type" }, { status: 415 });
    }

    const rawBody = await request.json();

    // STRIDE Mitigation (Tampering / Spoofing): Validate untrusted input against Zod schema
    const parseResult = GraphStateSchema.safeParse(rawBody);
    if (!parseResult.success) {
      return NextResponse.json(
        { 
          error: "Validation Error", 
          details: parseResult.error.format() 
        }, 
        { status: 400 }
      );
    }

    const validatedState: GraphState = parseResult.data;

    // Extract internal secret token from secure headers
    const secretContextToken = request.headers.get("x-internal-worker-secret") || "";

    // Execute the tool handler within a defensive timeout wrapper (DoS Mitigation)
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("Tool execution timed out.")), 5000)
    );

    const executionPromise = executeDatabaseQueryTool({
      state: validatedState,
      secretContextToken,
    });

    const result = await Promise.race([executionPromise, timeoutPromise]);

    // Return the sanitized observation back to the agentic execution graph
    return NextResponse.json({
      status: "success",
      sessionId: validatedState.sessionId,
      observation: result.updatedObservation,
      metadata: result.sanitizedMetadata,
    }, { status: 200 });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    return NextResponse.json(
      { error: "Internal Server Error", message: errorMessage },
      { status: 500 }
    );
  }
}
