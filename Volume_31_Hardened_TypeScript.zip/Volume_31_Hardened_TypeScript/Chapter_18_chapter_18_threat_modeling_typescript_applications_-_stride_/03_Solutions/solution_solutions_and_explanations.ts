/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// secure-auth.ts
import { Request, Response, NextFunction } from 'express';
import jwt, { JwtPayload } from 'jsonwebtoken';
import { z } from 'zod';

// Define the runtime validation schema using Zod
const AuthenticatedUserSchema = z.object({
  id: z.string().uuid(),
  role: z.enum(['admin', 'user']),
  email: z.string().email(),
});

export type AuthenticatedUser = z.infer<typeof AuthenticatedUserSchema>;

// Extend Express Request interface globally
declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

interface CustomJwtPayload extends JwtPayload {
  role?: string;
  email?: string;
}

export function verifyAuthToken(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Access token missing or malformed' });
  }

  const token = authHeader.split(' ')[1];
  const secret = process.env.JWT_SECRET;

  if (!secret) {
    return res.status(500).json({ error: 'Internal server configuration error' });
  }

  try {
    // Cryptographically verify token and strictly validate expected claims (iss, aud)
    const decoded = jwt.verify(token, secret, {
      issuer: 'https://auth.example.com',
      audience: 'https://api.example.com',
    }) as CustomJwtPayload;

    // Validate structural integrity and types at runtime using Zod
    const validationResult = AuthenticatedUserSchema.safeParse({
      id: decoded.sub,
      role: decoded.role,
      email: decoded.email,
    });

    if (!validationResult.success) {
      return res.status(403).json({ error: 'Invalid token payload structure' });
    }

    // Attach validated, strongly-typed user object
    req.user = validationResult.data;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Failed to authenticate token' });
  }
}
