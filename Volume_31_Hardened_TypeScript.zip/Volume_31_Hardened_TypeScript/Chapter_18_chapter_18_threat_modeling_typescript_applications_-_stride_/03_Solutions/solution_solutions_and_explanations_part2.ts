/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// secure-pipeline.ts
import { z } from 'zod';

export interface SystemConfig {
  theme: 'light' | 'dark';
  notificationsEnabled: boolean;
  maxUploadSizeMb: number;
  isMaintenanceMode?: boolean; 
}

// Define strict runtime validation schema
const SystemConfigSchema = z.object({
  theme: z.enum(['light', 'dark']),
  notificationsEnabled: z.boolean(),
  maxUploadSizeMb: z.number().positive().max(100),
  isMaintenanceMode: z.boolean().optional(),
}).strict(); // .strict() rejects unknown properties (mitigating prototype pollution & over-posting)

export function parseAndValidateConfig(
  rawJsonInput: string, 
  userRole: 'admin' | 'user'
): Readonly<SystemConfig> {
  let parsedJson: unknown;

  try {
    // Parse JSON safely with a reviver function to strip prototype pollution keys
    parsedJson = JSON.parse(rawJsonInput, (key, value) => {
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
        return undefined;
      }
      return value;
    });
  } catch (err) {
    throw new Error('Malformed JSON input');
  }

  // Validate structure and primitive types against schema
  const validationResult = SystemConfigSchema.safeParse(parsedJson);
  if (!validationResult.success) {
    throw new Error(`Invalid configuration payload: ${validationResult.error.message}`);
  }

  const config = validationResult.data;

  // Enforce Role-Based Access Control (RBAC) on sensitive configuration parameters
  if (config.isMaintenanceMode !== undefined && userRole !== 'admin') {
    throw new Error('Unauthorized attempt to modify maintenance mode status');
  }

  // Return deeply frozen immutable object (Readonly)
  return Object.freeze(config);
}
