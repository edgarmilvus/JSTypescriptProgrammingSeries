/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// SecureFileUploadPanel.tsx
import React, { useState, useCallback } from 'react';

export type UserRole = 'admin' | 'editor' | 'viewer';

export interface SecureFileUploadPanelProps {
  userRole: UserRole;
  csrfToken: string;
  maxFileSizeMb?: number;
}

export const SecureFileUploadPanel: React.FC<SecureFileUploadPanelProps> = ({
  userRole,
  csrfToken,
  maxFileSizeMb = 5,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string>('');

  // Enforce strict memory limits to mitigate Client-Side DoS via unbounded binary loads
  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = event.target.files?.[0];
    
    if (!file) return;

    const maxBytes = maxFileSizeMb * 1024 * 1024;
    if (file.size > maxBytes) {
      setError(`File size exceeds maximum allowed limit of ${maxFileSizeMb}MB.`);
      setSelectedFile(null);
      return;
    }

    setSelectedFile(file);
  }, [maxFileSizeMb]);

  const handleAdminPurge = useCallback(() => {
    if (userRole !== 'admin') {
      setError('Elevation of Privilege blocked: Unauthorized action.');
      return;
    }
    setUploadStatus('Global cache purged successfully.');
  }, [userRole]);

  return (
    <div className="secure-upload-panel">
      <h3>Secure File Upload</h3>
      {error && <div className="alert-error" style={{ color: 'red' }}>{error}</div>}
      {uploadStatus && <div className="alert-success" style={{ color: 'green' }}>{uploadStatus}</div>}
      
      <div>
        <input 
          type="file" 
          onChange={handleFileChange} 
          aria-label="Upload file"
        />
        <p>Max file size: {maxFileSizeMb}MB</p>
      </div>

      {/* RBAC UI Rendering Guard: Administrative controls rendered exclusively for admins */}
      {userRole === 'admin' && (
        <div className="admin-controls" style={{ border: '1px dashed red', padding: '10px', marginTop: '10px' }}>
          <h4>Administrative Controls</h4>
          <button onClick={handleAdminPurge}>
            Purge Global Cache
          </button>
        </div>
      )}
    </div>
  );
};
