/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// vulnerable-controller.ts
import { Request, Response } from 'express';

interface UserRecord {
  id: string;
  username: string;
  email: string;
  passwordHash: string; // SENSITIVE
  mfaSecret: string;     // SENSITIVE
  internalNotes: string; // SENSITIVE
  createdAt: Date;
}

// MOCK Database query returning full record
async function fetchUserFromDb(userId: string): Promise<UserRecord> {
  return {
    id: userId,
    username: 'janedoe',
    email: 'jane@example.com',
    passwordHash: '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW',
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    internalNotes: 'Flagged for suspicious login attempts in 2023.',
    createdAt: new Date(),
  };
}

// VULNERABLE CONTROLLER: Returns the raw database entity directly
export async function getUserProfile(req: Request, res: Response) {
  const userId = req.params.id;
  const userRecord = await fetchUserFromDb(userId);
  
  // Vulnerability: passwordHash, mfaSecret, and internalNotes are leaked to the client
  return res.status(200).json(userRecord);
}
