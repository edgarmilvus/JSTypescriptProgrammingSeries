/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// branded-types-audit.ts

// Step 1: Define Branded Types to prevent primitive obsession and tampering via ID confusion
// Hint: Use unique symbol intersections (e.g., { readonly __brand: unique symbol })
export type UserId = string & { readonly __brand: 'UserId' };
export type TransactionId = string & { readonly __brand: 'TransactionId' };

// Helper constructor functions to safely cast raw strings into branded types after runtime validation
export function createUserId(id: string): UserId {
  if (!id || id.length < 5) throw new Error('Invalid UserId format');
  return id as UserId;
}

export function createTransactionId(id: string): TransactionId {
  if (!id || id.length < 5) throw new Error('Invalid TransactionId format');
  return id as TransactionId;
}

// Step 2: Implement a strongly typed audit logging interface and function to mitigate Repudiation
export interface AuditLogEntry {
  readonly timestamp: string;
  readonly actorId: UserId;
  readonly action: 'TRANSFER_FUNDS' | 'UPDATE_CONFIG' | 'DELETE_USER';
  readonly targetId: TransactionId | UserId;
  readonly ipAddress: string;
}

export function recordAuditLog(entry: AuditLogEntry): void {
  // TODO: Implement secure serialization and immutable log storage write
  console.log(`[AUDIT]: ${JSON.stringify(entry)}`);
}
