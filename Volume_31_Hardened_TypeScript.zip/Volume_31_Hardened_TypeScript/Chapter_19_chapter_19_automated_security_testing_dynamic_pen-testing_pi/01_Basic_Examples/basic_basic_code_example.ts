/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file dastSecurityGate.ts
 * @description A self-contained TypeScript utility that simulates an automated 
 * Dynamic Application Security Testing (DAST) gate for a SaaS microservice pipeline.
 */

import * as http from 'http';
import { URL } from 'url';

/**
 * Interface representing the configuration for the DAST security scan.
 */
interface ScanConfig {
  targetUrl: string;
  timeoutMs: number;
  requiredHeaders: string[];
}

/**
 * Interface representing the result of the security scan.
 */
interface ScanResult {
  passed: boolean;
  score: number;
  violations: string[];
  timestamp: string;
}

/**
 * Simulates executing an HTTP GET request against a target microservice endpoint 
 * to evaluate security headers and response structure.
 * 
 * @param config - The scanning configuration parameters.
 * @returns A promise resolving to the ScanResult object.
 */
async function executeDastSecurityScan(config: ScanConfig): Promise<ScanResult> {
  const violations: string[] = [];
  let score = 100;

  // 1. Parse and validate the target URL to prevent SSRF vulnerabilities in the test runner
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(config.targetUrl);
  } catch (err) {
    return {
      passed: false,
      score: 0,
      violations: [`Invalid target URL provided: ${config.targetUrl}`],
      timestamp: new Date().toISOString(),
    };
  }

  // 2. Construct the HTTP request options safely
  const options: http.RequestOptions = {
    hostname: parsedUrl.hostname,
    port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
    path: parsedUrl.pathname + parsedUrl.search,
    method: 'GET',
    timeout: config.timeoutMs,
  };

  // 3. Execute the network probe against the microservice
  const responseData = await new Promise<{ statusCode?: number; headers: http.IncomingHttpHeaders; body: string }>((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body,
        });
      });
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error(`DAST scan timed out after ${config.timeoutMs}ms`));
    });

    req.end();
  }).catch((error) => {
    return {
      statusCode: 520,
      headers: {},
      body: JSON.stringify({ error: error.message }),
    };
  });

  // 4. Evaluate HTTP Status Code Security Gate
  if (!responseData.statusCode || responseData.statusCode >= 500) {
    violations.push(`Target returned a server error status code: ${responseData.statusCode || 'UNKNOWN'}`);
    score -= 40;
  }

  // 5. Evaluate Security Headers against Zero-Trust Policy
  for (const headerName of config.requiredHeaders) {
    const lowerHeaderName = headerName.toLowerCase();
    const headerValue = responseData.headers[lowerHeaderName];
    
    if (!headerValue) {
      violations.push(`Missing mandatory security header: '${headerName}'`);
      score -= 15;
    } else {
      // Basic heuristic check for header value sanity
      if (lowerHeaderName === 'strict-transport-security' && !String(headerValue).includes('max-age')) {
        violations.push(`Insecure configuration for 'Strict-Transport-Security': missing max-age.`);
        score -= 10;
      }
    }
  }

  // 6. Evaluate Response Body for Sensitive Data Exposure (e.g., stack traces)
  const lowerBody = responseData.body.toLowerCase();
  if (lowerBody.includes('at object.<anonymous>') || lowerBody.includes('at async ')) {
    violations.push('Critical vulnerability detected: Unhandled exception stack trace exposed in response body.');
    score -= 50;
  }

  // 7. Compile final determination
  const passed = score >= 70 && violations.length === 0;

  return {
    passed,
    score: Math.max(0, score),
    violations,
    timestamp: new Date().toISOString(),
  };
}

/**
 * Self-contained execution runner for demonstration within a CI/CD build step.
 */
async function runPipelineSecurityGate() {
  console.log('[DAST Pipeline] Initializing Zero-Trust Security Gate...');

  // Mocking a local microservice response test setup
  const server = http.createServer((req, res) => {
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      // Deliberately omitting Strict-Transport-Security to trigger a policy warning
    });
    res.end(JSON.stringify({ status: 'healthy', version: '1.0.4' }));
  });

  server.listen(8081, async () => {
    console.log('[DAST Pipeline] Test harness microservice listening on port 8081.');

    const config: ScanConfig = {
      targetUrl: 'http://localhost:8081/api/v1/health',
      timeoutMs: 3000,
      requiredHeaders: ['X-Content-Type-Options', 'X-Frame-Options', 'Strict-Transport-Security'],
    };

    try {
      const result = await executeDastSecurityScan(config);
      console.log('[DAST Pipeline] Scan completed. Results:');
      console.log(JSON.stringify(result, null, 2));

      if (!result.passed) {
        console.error('[DAST Pipeline] FAILED: Security gate violations detected. Blocking deployment.');
        process.exitCode = 1;
      } else {
        console.log('[DAST Pipeline] PASSED: Microservice meets zero-trust security criteria.');
        process.exitCode = 0;
      }
    } catch (err) {
      console.error('[DAST Pipeline] Execution error during scan:', err);
      process.exitCode = 1;
    } finally {
      server.close();
    }
  });
}

// Execute the gate verification
runPipelineSecurityGate();
