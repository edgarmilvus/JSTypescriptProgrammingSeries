/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 2: Automated DAST Attack Payload Orchestrator for Microservices
// Implement the DastOrchestrator class and its supporting interfaces.

export type AttackVectorType = 'SQL_INJECTION' | 'SSRF' | 'BOLA' | 'PATH_TRAVERSAL';

export interface AttackPayload {
  id: string;
  type: AttackVectorType;
  vector: string;
  targetParameter: string;
}

export interface DastExecutionConfig {
  targetBaseUrl: string;
  concurrencyLimit: number;
  timeoutMs: number;
  customHeaders: Record<string, string>;
}

export interface AnomalyFinding {
  payloadId: string;
  vectorType: AttackVectorType;
  statusCode: number;
  responseSnippet: string;
  matchedHeuristic: string;
}

export interface DastReport {
  executionId: string;
  totalPayloadsTested: number;
  anomaliesDetected: AnomalyFinding[];
  durationMs: number;
}

export class DastOrchestrator {
  private config: DastExecutionConfig;

  constructor(config: DastExecutionConfig) {
    this.config = config;
  }

  /**
   * Executes a batch of attack payloads against the configured microservice target.
   * @param payloads Array of attack payloads to test.
   */
  public async executeScan(payloads: AttackPayload[]): Promise<DastReport> {
    const startTime = Date.now();
    const executionId = `dast-exec-${Math.random().toString(36).substring(2, 9)}`;
    const anomaliesDetected: AnomalyFinding[] = [];

    // Helper to process a single payload with timeout handling
    const runPayload = async (payload: AttackPayload): Promise<void> => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeoutMs);

      try {
        const targetUrl = new URL(this.config.targetBaseUrl);
        targetUrl.searchParams.append(payload.targetParameter, payload.vector);

        const response = await fetch(targetUrl.toString(), {
          method: 'GET',
          headers: this.config.customHeaders,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        const responseText = await response.text();
        const snippet = responseText.substring(0, 250);

        // Heuristic anomaly detection
        const lowerBody = responseText.toLowerCase();
        let matchedHeuristic = '';

        if (payload.type === 'SQL_INJECTION' && (lowerBody.includes('sql syntax') || lowerBody.includes('unclosed quotation mark') || lowerBody.includes('pg_query'))) {
          matchedHeuristic = 'SQL Database Error Signature Detected';
        } else if (payload.type === 'BOLA' && response.status === 200) {
          matchedHeuristic = 'Potential BOLA: Unauthorized Endpoint Returned HTTP 200';
        } else if (payload.type === 'PATH_TRAVERSAL' && lowerBody.includes('root:x:')) {
          matchedHeuristic = 'Potential Path Traversal: System File Content Exposed';
        } else if (response.status >= 500) {
          matchedHeuristic = 'Unhandled Server Exception (HTTP 5xx Stack Trace Exposure)';
        }

        if (matchedHeuristic) {
          anomaliesDetected.push({
            payloadId: payload.id,
            vectorType: payload.type,
            statusCode: response.status,
            responseSnippet: snippet,
            matchedHeuristic,
          });
        }
      } catch (error) {
        clearTimeout(timeoutId);
        // Network timeouts or connection aborts can be logged or ignored depending on policy
      }
    };

    // Concurrency pool execution
    let index = 0;
    const worker = async () => {
      while (index < payloads.length) {
        const currentIndex = index++;
        await runPayload(payloads[currentIndex]);
      }
    };

    const workers = Array.from(
      { length: Math.min(this.config.concurrencyLimit, payloads.length) },
      () => worker()
    );

    await Promise.all(workers);

    const durationMs = Date.now() - startTime;

    return {
      executionId,
      totalPayloadsTested: payloads.length,
      anomaliesDetected,
      durationMs,
    };
  }
}
