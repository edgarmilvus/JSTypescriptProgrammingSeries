/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 3: Supply Chain Software Bill of Materials & Dependency Verifier
// Implement the verification logic adhering to strict type checking.

export interface SbomDependency {
  purl: string; // Package URL (e.g., pkg:npm/lodash@4.17.21)
  name: string;
  version: string;
  sha256Hash: string;
}

export interface SbomDocument {
  specVersion: string;
  serialNumber: string;
  dependencies: SbomDependency[];
}

export interface VulnerableAdvisory {
  purl: string;
  vulnerabilityId: string;
  fixedInVersion: string;
}

export interface SupplyChainAuditResult {
  isSecure: boolean;
  verifiedCount: number;
  tamperedPackages: string[];
  vulnerablePackages: string[];
  auditTimestamp: string;
}

/**
 * Verifies the cryptographic integrity and vulnerability status of an SBOM document.
 * @param sbom The parsed Software Bill of Materials.
 * @param trustedRegistryHashes A map of package purls to their known valid SHA-256 hashes.
 * @param advisories A list of known active vulnerability advisories.
 */
export async function verifySupplyChain(
  sbom: SbomDocument,
  trustedRegistryHashes: Map<string, string>,
  advisories: VulnerableAdvisory[]
): Promise<SupplyChainAuditResult> {
  const tamperedPackages: string[] = [];
  const vulnerablePackages: string[] = [];
  let verifiedCount = 0;

  const advisoryMap = new Map<string, VulnerableAdvisory>();
  for (const advisory of advisories) {
    advisoryMap.set(advisory.purl, advisory);
  }

  for (const dep of sbom.dependencies ?? []) {
    const trustedHash = trustedRegistryHashes.get(dep.purl);

    // Verify cryptographic integrity
    if (!trustedHash || trustedHash.toLowerCase() !== dep.sha256Hash.toLowerCase()) {
      tamperedPackages.push(dep.purl);
    } else {
      verifiedCount++;
    }

    // Check vulnerability advisories
    const activeAdvisory = advisoryMap.get(dep.purl);
    if (activeAdvisory) {
      vulnerablePackages.push(`${dep.purl} (Advisory: ${activeAdvisory.vulnerabilityId})`);
    }
  }

  const isSecure = tamperedPackages.length === 0 && vulnerablePackages.length === 0;

  return {
    isSecure,
    verifiedCount,
    tamperedPackages,
    vulnerablePackages,
    auditTimestamp: new Date().toISOString(),
  };
}
