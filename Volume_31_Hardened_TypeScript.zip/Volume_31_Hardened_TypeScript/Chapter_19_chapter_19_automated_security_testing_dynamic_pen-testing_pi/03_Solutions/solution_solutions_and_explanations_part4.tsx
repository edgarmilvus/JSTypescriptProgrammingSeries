/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// Exercise 4: React Component Feature Request – Streamable AI Security Audit Console
// Implement the TSX component and its supporting type definitions below.

import React, { useState } from 'react';

export interface SecurityAuditConsoleProps {
  targetId: string;
  environment: 'staging' | 'production' | 'ephemeral-preview';
  onScanComplete?: (reportId: string) => void;
}

export type StreamedAuditContentType = 'LOG_TEXT' | 'VULNERABILITY_CARD' | 'REMEDIATION_WIDGET';

export interface StreamedAuditChunk {
  id: string;
  type: StreamedAuditContentType;
  payload: Record<string, unknown>;
  timestamp: string;
}

/**
 * Streamable AI Security Audit Console Component
 * Renders real-time pipeline execution logs and dynamic interactive remediation components.
 */
export const SecurityAuditConsole: React.FC<SecurityAuditConsoleProps> = ({
  targetId,
  environment,
  onScanComplete,
}) => {
  const [chunks, setChunks] = useState<StreamedAuditChunk[]>([]);
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Simulated stream injector for demonstration of type-safe chunk rendering
  const triggerSimulation = () => {
    setIsScanning(true);
    setChunks([
      {
        id: 'chunk-1',
        type: 'LOG_TEXT',
        payload: { text: `[INFO] Initializing DAST pipeline for target: ${targetId} in [${environment}]` },
        timestamp: new Date().toISOString(),
      },
      {
        id: 'chunk-2',
        type: 'VULNERABILITY_CARD',
        payload: {
          title: 'SQL Injection in /api/v1/users',
          severity: 'CRITICAL',
          cwe: 'CWE-89',
        },
        timestamp: new Date().toISOString(),
      },
    ]);
    setIsScanning(false);
    if (onScanComplete) {
      onScanComplete('rep-998877');
    }
  };

  return (
    <div className="security-audit-console border rounded-lg p-6 bg-slate-950 text-slate-50">
      <header className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold">Zero-Trust Pipeline Audit Console</h2>
          <p className="text-xs text-slate-400">Target ID: {targetId}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm px-2.5 py-1 bg-blue-900/80 rounded font-medium">{environment}</span>
          <button
            onClick={triggerSimulation}
            disabled={isScanning}
            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold rounded disabled:opacity-50"
          >
            {isScanning ? 'Streaming...' : 'Run Audit Stream'}
          </button>
        </div>
      </header>
      
      <div className="console-output-stream min-h-[300px] border border-slate-800 rounded p-4 font-mono text-sm overflow-y-auto bg-slate-900 space-y-3">
        {chunks.length === 0 ? (
          <p className="text-slate-500">// Awaiting security pipeline execution stream...</p>
        ) : (
          chunks.map((chunk) => {
            if (chunk.type === 'LOG_TEXT') {
              return (
                <div key={chunk.id} className="text-slate-300">
                  {String(chunk.payload.text ?? '')}
                </div>
              );
            }
            if (chunk.type === 'VULNERABILITY_CARD') {
              return (
                <div key={chunk.id} className="p-3 border border-red-900/60 bg-red-950/30 rounded">
                  <div className="flex justify-between items-center text-xs text-red-400 font-bold mb-1">
                    <span>{String(chunk.payload.cwe)}</span>
                    <span className="px-1.5 py-0.5 bg-red-900 rounded">{String(chunk.payload.severity)}</span>
                  </div>
                  <p className="text-slate-100 text-sm">{String(chunk.payload.title)}</p>
                </div>
              );
            }
            return null;
          })
        )}
      </div>
    </div>
  );
};
