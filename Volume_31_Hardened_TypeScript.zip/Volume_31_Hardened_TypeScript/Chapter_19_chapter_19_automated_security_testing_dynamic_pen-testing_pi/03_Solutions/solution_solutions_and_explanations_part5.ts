/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 5: Zero-Trust Edge Runtime Security Middleware & Token Validator
// Implement the edge middleware function and its supporting data contracts.

export interface EdgeRequestContext {
  method: string;
  url: string;
  headers: Record<string, string>;
  ipAddress: string;
}

export interface DevicePostureClaims {
  isDiskEncrypted: boolean;
  firewallEnabled: boolean;
  mdmEnrolled: boolean;
  deviceRiskScore: number;
}

export interface VerifiedTokenClaims {
  sub: string;
  iss: string;
  exp: number;
  roles: string[];
  device: DevicePostureClaims;
}

export interface EdgeSecurityResult {
  authorized: boolean;
  statusCode: number;
  claims?: VerifiedTokenClaims;
  errorReason?: string;
}

/**
 * Validates incoming requests at the edge under zero-trust principles.
 * @param context The edge request context containing headers and metadata.
 * @param publicKey The cryptographic public key used for token verification.
 * @returns An authorization result determining whether the request may proceed.
 */
export async function validateEdgeSecurity(
  context: EdgeRequestContext,
  publicKey: CryptoKey
): Promise<EdgeSecurityResult> {
  const authHeader = context.headers['authorization'] || context.headers['Authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return {
      authorized: false,
      statusCode: 401,
      errorReason: 'Missing or malformed Bearer authorization header.',
    };
  }

  const token = authHeader.substring(7);
  const parts = token.split('.');

  if (parts.length !== 3) {
    return {
      authorized: false,
      statusCode: 401,
      errorReason: 'Invalid JWT structure.',
    };
  }

  const [headerB64, payloadB64, signatureB64] = parts;

  try {
    // Decode claims payload
    const decodedPayloadJson = atob(payloadB64.replace(/-/g, '+').replace(/_/g, '/'));
    const claims = JSON.parse(decodedPayloadJson) as VerifiedTokenClaims;

    // Check expiration
    const currentTime = Math.floor(Date.now() / 1000);
    if (claims.exp && claims.exp < currentTime) {
      return {
        authorized: false,
        statusCode: 401,
        errorReason: 'Token has expired.',
      };
    }

    // Enforce Zero-Trust Device Posture
    const device = claims.device;
    if (!device || !device.isDiskEncrypted || !device.firewallEnabled || device.deviceRiskScore > 50) {
      return {
        authorized: false,
        statusCode: 403,
        errorReason: 'Device posture check failed: Non-compliant or high-risk device state.',
      };
    }

    // Verify cryptographic signature using Web Crypto API (RSASSA-PKCS1-v1_5 or HMAC)
    const dataToVerify = new TextEncoder().encode(`${headerB64}.${payloadB64}`);
    const signatureBytes = Uint8Array.from(atob(signatureB64.replace(/-/g, '+').replace(/_/g, '/')), (c) =>
      c.charCodeAt(0)
    );

    const isValidSignature = await crypto.subtle.verify(
      { name: 'RSASSA-PKCS1-v1_5' },
      publicKey,
      signatureBytes,
      dataToVerify
    );

    if (!isValidSignature) {
      return {
        authorized: false,
        statusCode: 401,
        errorReason: 'Cryptographic token signature verification failed.',
      };
    }

    return {
      authorized: true,
      statusCode: 200,
      claims,
    };
  } catch (err) {
    return {
      authorized: false,
      statusCode: 401,
      errorReason: 'Failed to parse or verify security token payload.',
    };
  }
}
