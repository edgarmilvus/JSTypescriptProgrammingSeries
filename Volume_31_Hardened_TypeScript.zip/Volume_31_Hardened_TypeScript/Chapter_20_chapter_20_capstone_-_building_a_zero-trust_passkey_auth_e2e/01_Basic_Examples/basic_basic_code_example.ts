/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file vault-crypto.ts
 * @description Self-contained TypeScript module demonstrating client-side E2EE key derivation,
 * payload encryption, and decryption for a Zero-Trust SaaS Vault.
 */

// We use the global Web Crypto API available in modern browsers and Node.js 18+
const cryptoObj = globalThis.crypto;

/**
 * Result structure of client-side encryption containing base64/hex-encoded strings
 * safe for JSON transport to an untrusted storage backend.
 */
export interface EncryptedPayload {
  ciphertext: string; // Base64 encoded AES-GCM ciphertext
  iv: string;         // Base64 encoded initialization vector
  salt: string;       // Base64 encoded PBKDF2 salt
}

/**
 * Derives a cryptographic AES-GCM key from a user passphrase and a unique salt.
 * 
 * @param passphrase - The user's secret master passphrase (never sent to the server).
 * @param salt - A cryptographically secure random salt (Uint8Array).
 * @returns A Promise resolving to a CryptoKey usable for encryption and decryption.
 */
async function deriveKeyFromPassphrase(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const passphraseKeyData = encoder.encode(passphrase);

  // Import the raw passphrase as a base key for PBKDF2
  const baseKey = await cryptoObj.subtle.importKey(
    "raw",
    passphraseKeyData,
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  // Derive an AES-GCM 256-bit key using PBKDF2 with 100,000 iterations
  return await cryptoObj.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false, // non-extractable key for enhanced security
    ["encrypt", "decrypt"]
  );
}

/**
 * Encrypts plaintext data completely on the client side before network transmission.
 * 
 * @param plaintext - The sensitive string data to protect.
 * @param passphrase - The user's master passphrase.
 * @returns A promise resolving to an EncryptedPayload ready for untrusted storage.
 */
export async function clientSideEncrypt(
  plaintext: string,
  passphrase: string
): Promise<EncryptedPayload> {
  // 1. Generate a cryptographically secure random salt for key derivation
  const salt = cryptoObj.getRandomValues(new Uint8Array(16));

  // 2. Derive the AES-GCM encryption key
  const cryptoKey = await deriveKeyFromPassphrase(passphrase, salt);

  // 3. Generate a unique Initialization Vector (IV) for AES-GCM (96 bits / 12 bytes)
  const iv = cryptoObj.getRandomValues(new Uint8Array(12));

  // 4. Encode the plaintext string into a Uint8Array
  const encoder = new TextEncoder();
  const encodedPlaintext = encoder.encode(plaintext);

  // 5. Perform authenticated encryption using AES-GCM
  const ciphertextBuffer = await cryptoObj.subtle.encrypt(
    {
      name: "AES-GCM",
      iv: iv,
    },
    cryptoKey,
    encodedPlaintext
  );

  // 6. Convert binary buffers to Base64 strings for safe JSON serialization
  return {
    ciphertext: Buffer.from(ciphertextBuffer).toString("base64"),
    iv: Buffer.from(iv).toString("base64"),
    salt: Buffer.from(salt).toString("base64"),
  };
}

/**
 * Decrypts an EncryptedPayload back into plaintext using the user's passphrase.
 * 
 * @param payload - The encrypted payload fetched from the untrusted backend.
 * @param passphrase - The user's master passphrase.
 * @returns A promise resolving to the decrypted plaintext string.
 */
export async function clientSideDecrypt(
  payload: EncryptedPayload,
  passphrase: string
): Promise<string> {
  // 1. Convert Base64 components back to Uint8Arrays
  const salt = Uint8Array.from(Buffer.from(payload.salt, "base64"));
  const iv = Uint8Array.from(Buffer.from(payload.iv, "base64"));
  const ciphertext = Buffer.from(payload.ciphertext, "base64");

  // 2. Re-derive the exact same AES-GCM key using the stored salt and passphrase
  const cryptoKey = await deriveKeyFromPassphrase(passphrase, salt);

  // 3. Decrypt and verify the authentication tag using AES-GCM
  const decryptedBuffer = await cryptoObj.subtle.decrypt(
    {
      name: "AES-GCM",
      iv: iv,
    },
    cryptoKey,
    ciphertext
  );

  // 4. Decode the decrypted binary buffer back into a UTF-8 string
  const decoder = new TextDecoder();
  return decoder.decode(decryptedBuffer);
}

// ==========================================
// EXAMPLE USAGE DEMONSTRATION
// ==========================================
(async () => {
  const secretPassphrase = "correct-horse-battery-staple-secure-vault-pass";
  const sensitiveData = "My credit card is 4111-2222-3333-4444 and my pin is 1234.";

  console.log("--- Zero-Trust E2EE Client-Side Lifecycle ---");
  console.log(`Original Plaintext: ${sensitiveData}`);

  // Encrypt on client
  const encryptedPayload = await clientSideEncrypt(sensitiveData, secretPassphrase);
  console.log("\n[Client] Payload generated and secured locally.");
  console.log("Ciphertext (Sent to Server):", encryptedPayload.ciphertext);
  console.log("Salt (Sent to Server):", encryptedPayload.salt);
  console.log("IV (Sent to Server):", encryptedPayload.iv);

  // Simulate untrusted storage round-trip (Backend only sees opaque bytes/strings)
  console.log("\n[Backend] Storing encrypted blob in database (zero visibility into content)...");

  // Decrypt on client
  const recoveredPlaintext = await clientSideDecrypt(encryptedPayload, secretPassphrase);
  console.log("\n[Client] Payload fetched and decrypted successfully.");
  console.log(`Decrypted Plaintext: ${recoveredPlaintext}`);
})();
