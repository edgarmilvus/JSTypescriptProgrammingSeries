/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Zero-Trust Secure Vault Service & API Gateway Middleware
 * @module VaultAuthEngine
 * @description Implements zero-trust context validation, cryptographic signature verification 
 * for WebAuthn/Passkey payloads, and strict memory-only E2EE envelope management.
 */

import { NextRequest, NextResponse } from 'next/server';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { webcrypto } from 'crypto';

// Ensure Web Crypto API is globally available for server-side cryptographic operations
const crypto = webcrypto as unknown as Crypto;

/**
 * Defines the Zero-Trust Context attached to verified requests.
 */
export interface ZeroTrustContext {
  userId: string;
  deviceId: string;
  sessionTokenId: string;
  authMethod: 'passkey' | 'hardware_token';
  deviceFingerprintHash: string;
  issuedAt: number;
  expiresAt: number;
}

/**
 * Interface representing the encrypted payload structure stored in the E2EE vault.
 */
export interface EncryptedVaultEnvelope {
  ciphertext: string; // Base64 encoded AES-GCM encrypted data
  iv: string;         // Base64 encoded Initialization Vector
  authTag: string;    // Base64 encoded authentication tag
  salt: string;       // PBKDF2 salt used for client-side key derivation
}

/**
 * Configuration parameters for Zero-Trust validation checks.
 */
const ZERO_TRUST_CONFIG = {
  maxSessionAgeSeconds: 900, // 15 minutes max without re-verification
  issuer: 'https://auth.zero-trust-vault.internal',
  audience: 'https://api.zero-trust-vault.internal/v1/vault',
};

/**
 * Cryptographically verifies a device fingerprint against the active session assertion.
 * 
 * @param {string} clientFingerprint - The runtime fingerprint collected from the browser environment.
 * @param {string} registeredHash - The securely stored hardware/browser hash from enrollment.
 * @returns {Promise<boolean>} True if the device parameters match identically.
 */
async function verifyDeviceIntegrity(
  clientFingerprint: string,
  registeredHash: string
): Promise<boolean> {
  const encoder = new TextEncoder();
  const data = encoder.encode(clientFingerprint);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  
  // Convert buffer to hex string for comparison
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const computedHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  // Constant-time comparison to prevent timing attacks
  if (computedHash.length !== registeredHash.length) return false;
  let mismatch = 0;
  for (let i = 0; i < computedHash.length; i++) {
    mismatch |= computedHash.charCodeAt(i) ^ registeredHash.charCodeAt(i);
  }
  return mismatch === 0;
}

/**
 * Next.js Zero-Trust API Middleware Gateway.
 * Intercepts incoming requests to the E2EE vault, validates cryptographically signed
 * tokens, evaluates device health context, and enforces continuous authorization.
 * 
 * @param {NextRequest} req - The incoming HTTP request object.
 * @returns {Promise<NextResponse>} Returns the downstream response or a 403/401 security rejection.
 */
export async function zeroTrustVaultMiddleware(req: NextRequest): Promise<NextResponse> {
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'ZeroTrustViolation: Missing or malformed authorization header.' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const deviceFingerprint = req.headers.get('X-Device-Fingerprint');
    const registeredDeviceHash = req.headers.get('X-Registered-Device-Hash');

    if (!deviceFingerprint || !registeredDeviceHash) {
      return NextResponse.json(
        { error: 'ZeroTrustViolation: Device posture telemetry missing.' },
        { status: 403 }
      );
    }

    // Step 1: Verify hardware device integrity context
    const isDeviceValid = await verifyDeviceIntegrity(deviceFingerprint, registeredDeviceHash);
    if (!isDeviceValid) {
      return NextResponse.json(
        { error: 'ZeroTrustViolation: Device fingerprint mismatch detected.' },
        { status: 403 }
      );
    }

    // Step 2: Validate JWT structure and cryptographic signature using remote JWKS
    // In production, configure the JWKS URL to point to your secure identity provider
    const JWKS = createRemoteJWKSet(new URL('https://auth.zero-trust-vault.internal/.well-known/jwks.json'));
    
    const { payload } = await jwtVerify(token, JWKS, {
      issuer: ZERO_TRUST_CONFIG.issuer,
      audience: ZERO_TRUST_CONFIG.audience,
    });

    const currentTime = Math.floor(Date.now() / 1000);
    const tokenAge = currentTime - (payload.iat as number);

    // Step 3: Enforce continuous authorization sliding window constraints
    if (tokenAge > ZERO_TRUST_CONFIG.maxSessionAgeSeconds) {
      return NextResponse.json(
        { error: 'SessionExpired: Continuous authorization window exceeded. Re-authentication via Passkey required.' },
        { status: 401 }
      );
    }

    // Attach validated zero-trust claims to request headers for downstream Server Components
    const requestHeaders = new Headers(req.headers);
    requestHeaders.set('x-authenticated-user-id', payload.sub as string);
    requestHeaders.set('x-authenticated-device-id', payload.device_id as string);

    // Pass request through to the protected backend route handler
    return NextResponse.next({
      request: {
        headers: requestHeaders,
      },
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown cryptographic validation error';
    return NextResponse.json(
      { error: `ZeroTrustSecurityFault: Authentication failed. Details: ${errorMessage}` },
      { status: 403 }
    );
  }
}
