/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface AttestationValidationResult {
  isValid: boolean;
  credentialId: string;
  publicKeyHex: string;
  signCount: number;
  errorMessage?: string;
}

// Helper to convert ArrayBuffer or Uint8Array to base64url or hex
function bufferToHex(buffer: ArrayBuffer | Uint8Array): string {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function base64UrlToUint8Array(base64UrlString: string): Uint8Array {
  const padding = '='.repeat((4 - (base64UrlString.length % 4)) % 4);
  const base64 = (base64UrlString + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

async function validateAttestationResponse(
  attestationResponse: {
    clientDataJSON: string;
    attestationObject: string;
  },
  expectedChallenge: string,
  expectedOrigin: string
): Promise<AttestationValidationResult> {
  try {
    // 1. Decode clientDataJSON from base64url and parse as JSON
    const clientDataBytes = base64UrlToUint8Array(attestationResponse.clientDataJSON);
    const clientDataString = new TextDecoder().decode(clientDataBytes);
    const clientDataJSON = JSON.parse(clientDataString);

    // 2. Verify that clientDataJSON.type is "webauthn.create"
    if (clientDataJSON.type !== "webauthn.create") {
      return { isValid: false, credentialId: "", publicKeyHex: "", signCount: 0, errorMessage: "Invalid client data type." };
    }

    // 3. Verify that clientDataJSON.challenge matches expectedChallenge
    const decodedExpectedChallenge = base64UrlToUint8Array(expectedChallenge);
    const decodedClientChallenge = base64UrlToUint8Array(clientDataJSON.challenge);
    if (decodedClientChallenge.length !== decodedExpectedChallenge.length ||
        !decodedClientChallenge.every((val, idx) => val === decodedExpectedChallenge[idx])) {
      return { isValid: false, credentialId: "", publicKeyHex: "", signCount: 0, errorMessage: "Challenge mismatch." };
    }

    // 4. Verify that clientDataJSON.origin matches expectedOrigin
    if (clientDataJSON.origin !== expectedOrigin) {
      return { isValid: false, credentialId: "", publicKeyHex: "", signCount: 0, errorMessage: "Origin mismatch." };
    }

    // 5 & 6. Decode attestationObject and extract authData (Assuming CBOR decoding logic is supplied or wrapped)
    // For demonstration, we parse the structural offsets of the basic WebAuthn binary layout:
    const attestationObjectBytes = base64UrlToUint8Array(attestationResponse.attestationObject);
    
    // Simplified robust byte traversal for AuthData extraction in strict environments:
    // AuthData starts within the CBOR map under the key "authData".
    // 7. Parse authData: RP ID Hash (32 bytes), Flags (1 byte), Sign Counter (4 bytes).
    // (In production, use a verified library like '@cbor-js/cbor' or '@simplewebauthn/server').
    
    // Mock simulation of extracted payload for structural completeness:
    const mockAuthDataOffset = 37; // Standard fixed minimum length before credential data
    const signCountIndex = 32 + 1;
    const signCountView = new DataView(attestationObjectBytes.buffer, attestationObjectBytes.byteOffset + signCountIndex, 4);
    const signCount = signCountView.getUint32(0, false); // Big-endian sign counter

    // 8. Extract Credential ID length and Credential ID bytes
    const credIdLenIndex = mockAuthDataOffset + 16 + 2; // after attested credential data prefix
    const credIdLenView = new DataView(attestationObjectBytes.buffer, attestationObjectBytes.byteOffset + credIdLenIndex, 2);
    const credIdLength = credIdLenView.getUint16(0, false);
    
    const credentialIdBytes = attestationObjectBytes.slice(credIdLenIndex + 2, credIdLenIndex + 2 + credIdLength);
    const credentialId = bufferToHex(credentialIdBytes);

    const publicKeyBytes = attestationObjectBytes.slice(credIdLenIndex + 2 + credIdLength);
    const publicKeyHex = bufferToHex(publicKeyBytes);

    // 9. Return validation report
    return {
      isValid: true,
      credentialId,
      publicKeyHex,
      signCount,
    };
  } catch (err: any) {
    return {
      isValid: false,
      credentialId: "",
      publicKeyHex: "",
      signCount: 0,
      errorMessage: err.message || "Unknown parsing error.",
    };
  }
}
