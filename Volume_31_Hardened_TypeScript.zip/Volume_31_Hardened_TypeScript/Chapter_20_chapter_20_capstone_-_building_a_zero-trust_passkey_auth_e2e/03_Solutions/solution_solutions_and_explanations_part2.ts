/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface EncryptedVaultItem {
  id: string;
  ciphertext: string; 
  iv: string;         
  encryptedDek: string; 
  dekIv: string;      
}

class ClientVaultManager {
  private kek: CryptoKey | null = null;

  constructor(private salt: Uint8Array) {}

  /**
   * Derives the Key Encryption Key (KEK) from a user master password and salt.
   */
  async initializeMasterKey(passphrase: string): Promise<void> {
    const enc = new TextEncoder();
    const passphraseKey = await window.crypto.subtle.importKey(
      "raw",
      enc.encode(passphrase),
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );

    this.kek = await window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: this.salt,
        iterations: 600_000,
        hash: "SHA-256",
      },
      passphraseKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }

  /**
   * Encrypts a plaintext JSON object using a freshly generated DEK.
   */
  async encryptItem(itemId: string, plaintext: object): Promise<EncryptedVaultItem> {
    if (!this.kek) throw new Error("Master key not initialized.");

    // 1. Generate a random AES-GCM 256 DEK.
    const dek = await window.crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt", "decrypt"]
    );

    // 2. Encrypt plaintext using DEK and a random IV.
    const itemIv = window.crypto.getRandomValues(new Uint8Array(12));
    const encodedPlaintext = new TextEncoder().encode(JSON.stringify(plaintext));
    const ciphertextBuffer = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv: itemIv },
      dek,
      encodedPlaintext
    );

    // 3. Export DEK and encrypt it using this.kek and a random DEK IV.
    const rawDek = await window.crypto.subtle.exportKey("raw", dek);
    const dekIv = window.crypto.getRandomValues(new Uint8Array(12));
    const encryptedDekBuffer = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv: dekIv },
      this.kek,
      rawDek
    );

    // 4. Return EncryptedVaultItem structure with base64 encoded fields.
    return {
      id: itemId,
      ciphertext: btoa(String.fromCharCode(...new Uint8Array(ciphertextBuffer))),
      iv: btoa(String.fromCharCode(...itemIv)),
      encryptedDek: btoa(String.fromCharCode(...new Uint8Array(encryptedDekBuffer))),
      dekIv: btoa(String.fromCharCode(...dekIv)),
    };
  }

  /**
   * Decrypts an EncryptedVaultItem back into its original plaintext object.
   */
  async decryptItem(item: EncryptedVaultItem): Promise<object> {
    if (!this.kek) throw new Error("Master key not initialized.");

    // 1. Decrypt encryptedDek using this.kek to recover the DEK.
    const encryptedDekBytes = Uint8Array.from(atob(item.encryptedDek), c => c.charCodeAt(0));
    const dekIvBytes = Uint8Array.from(atob(item.dekIv), c => c.charCodeAt(0));
    
    const rawDek = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: dekIvBytes },
      this.kek,
      encryptedDekBytes
    );

    const dek = await window.crypto.subtle.importKey(
      "raw",
      rawDek,
      { name: "AES-GCM", length: 256 },
      false,
      ["decrypt"]
    );

    // 2. Decrypt item ciphertext using the recovered DEK and item IV.
    const ciphertextBytes = Uint8Array.from(atob(item.ciphertext), c => c.charCodeAt(0));
    const itemIvBytes = Uint8Array.from(atob(item.iv), c => c.charCodeAt(0));

    const decryptedBuffer = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: itemIvBytes },
      dek,
      ciphertextBytes
    );

    // 3. Parse JSON and return plaintext object.
    const decryptedString = new TextDecoder().decode(decryptedBuffer);
    return JSON.parse(decryptedString);
  }
}
