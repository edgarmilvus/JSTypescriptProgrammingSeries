/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { ReactNode, useEffect, useState } from 'react';

interface SecurityPolicy {
  maxSessionAgeSeconds: number;
  requireBiometricStepUp: boolean;
  allowedIpSubnets?: string[];
}

interface ConditionalAccessBoundaryProps {
  policy: SecurityPolicy;
  children: ReactNode;
  fallbackComponent?: ReactNode;
}

/**
 * Custom hook to gather client-side zero-trust telemetry signals.
 */
function useDeviceTelemetry() {
  const [telemetryToken, setTelemetryToken] = useState<string>("");
  const [isCollecting, setIsCollecting] = useState<boolean>(true);

  useEffect(() => {
    async function collectSignals() {
      try {
        const glCanvas = document.createElement('canvas');
        const gl = glCanvas.getContext('webgl');
        const debugInfo = gl ? gl.getExtension('WEBGL_debug_renderer_info') : null;
        const renderer = debugInfo && gl ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : 'unknown';

        const signals = {
          hardwareConcurrency: navigator.hardwareConcurrency || 0,
          deviceMemory: (navigator as any).deviceMemory || 0,
          webglRenderer: renderer,
          timezoneOffset: new Date().getTimezoneOffset(),
          screenResolution: `${window.screen.width}x${window.screen.height}`,
          timestamp: Date.now(),
        };

        // Base64 encode telemetry payload for transport simulation
        const encoded = btoa(JSON.stringify(signals));
        setTelemetryToken(encoded);
      } catch (e) {
        setTelemetryToken("error-collecting");
      } finally {
        setIsCollecting(false);
      }
    }

    collectSignals();
  }, []);

  return { telemetryToken, isCollecting };
}

export const ConditionalAccessBoundary: React.FC<ConditionalAccessBoundaryProps> = ({
  policy,
  children,
  fallbackComponent
}) => {
  const { telemetryToken, isCollecting } = useDeviceTelemetry();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);

  useEffect(() => {
    if (isCollecting || !telemetryToken) return;

    let isMounted = true;
    async function evaluateAccess() {
      try {
        const response = await fetch('/api/auth/evaluate-context', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ policy, telemetryToken }),
        });
        
        const result = await response.json();
        if (isMounted) {
          setIsAuthorized(result.authorized === true);
        }
      } catch {
        if (isMounted) setIsAuthorized(false);
      }
    }

    evaluateAccess();
    return () => { isMounted = false; };
  }, [isCollecting, telemetryToken, policy]);

  if (isCollecting || isAuthorized === null) {
    return (
      <div className="p-6 text-center text-muted-foreground animate-pulse">
        <p>Evaluating Zero-Trust Access Policy & Device Posture...</p>
      </div>
    );
  }

  if (!isAuthorized) {
    return <>{fallbackComponent || <div className="p-4 bg-destructive/10 text-destructive rounded-md">Access Denied: Zero-Trust Context Violation or Risk Threshold Exceeded.</div>}</>;
  }

  return <>{children}</>;
};
