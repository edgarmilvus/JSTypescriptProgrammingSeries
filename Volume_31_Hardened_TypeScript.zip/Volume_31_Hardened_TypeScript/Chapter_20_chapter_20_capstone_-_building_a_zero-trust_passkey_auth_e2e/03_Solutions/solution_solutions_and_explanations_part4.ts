/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface AuditResult {
  passed: boolean;
  floatingDependenciesFound: string[];
  missingIntegrityHashes: string[];
  totalDependenciesInspected: number;
}

interface PackageLockFile {
  name: string;
  lockfileVersion: number;
  packages: Record<string, {
    version: string;
    integrity?: string;
    resolved?: string;
    dependencies?: Record<string, string>;
  }>;
}

function auditSupplyChainDependencies(lockFileContent: PackageLockFile): AuditResult {
  const floatingDependenciesFound: string[] = [];
  const missingIntegrityHashes: string[] = [];
  let totalDependenciesInspected = 0;

  const floatingVersionRegex = /^[\^~><*]|x/i;

  for (const [pkgPath, pkgMeta] of Object.entries(lockFileContent.packages)) {
    // Skip root package entry
    if (pkgPath === "") continue;

    totalDependenciesInspected++;

    // 1. Check for floating version numbers
    if (pkgMeta.version && floatingVersionRegex.test(pkgMeta.version)) {
      floatingDependenciesFound.push(`${pkgPath}@${pkgMeta.version}`);
    }

    // 2. Validate integrity checksum format (must start with sha512- or sha256-)
    const integrity = pkgMeta.integrity;
    if (!integrity || (!integrity.startsWith("sha512-") && !integrity.startsWith("sha256-"))) {
      missingIntegrityHashes.push(pkgPath);
    }
  }

  const passed = floatingDependenciesFound.length === 0 && missingIntegrityHashes.length === 0;

  return {
    passed,
    floatingDependenciesFound,
    missingIntegrityHashes,
    totalDependenciesInspected,
  };
}
