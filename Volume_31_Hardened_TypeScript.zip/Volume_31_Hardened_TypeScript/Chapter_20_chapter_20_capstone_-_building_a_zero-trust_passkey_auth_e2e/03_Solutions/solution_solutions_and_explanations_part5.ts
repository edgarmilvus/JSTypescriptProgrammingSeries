/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

interface ProvenanceAttestation {
  builderId: string;
  sourceRepository: string;
  commitSha: string;
  buildTimestamp: string;
  signature: string;
}

interface DeploymentVerificationResult {
  isVerified: boolean;
  provenanceDetails?: ProvenanceAttestation;
  rejectionReason?: string;
}

async function verifyDeploymentProvenance(
  artifactSha256: string,
  attestation: ProvenanceAttestation,
  trustedPublicKeyPem: string,
  expectedRepository: string,
  expectedCommitSha: string
): Promise<DeploymentVerificationResult> {
  try {
    // 1. Validate repository match
    if (attestation.sourceRepository !== expectedRepository) {
      return {
        isVerified: false,
        rejectionReason: `Repository mismatch. Expected: ${expectedRepository}, Got: ${attestation.sourceRepository}`,
      };
    }

    // 2. Validate commit SHA match
    if (attestation.commitSha !== expectedCommitSha) {
      return {
        isVerified: false,
        rejectionReason: `Commit SHA mismatch. Expected: ${expectedCommitSha}, Got: ${attestation.commitSha}`,
      };
    }

    // 3. Validate build timestamp freshness (within last 24 hours)
    const buildTime = new Date(attestation.buildTimestamp).getTime();
    const now = Date.now();
    const maxAgeMs = 24 * 60 * 60 * 1000;
    if (isNaN(buildTime) || now - buildTime > maxAgeMs || buildTime > now) {
      return {
        isVerified: false,
        rejectionReason: "Build timestamp is invalid or exceeds maximum allowable age window (24h).",
      };
    }

    // 4. Verify cryptographic signature against trusted public key using Web Crypto API
    const enc = new TextEncoder();
    const payloadString = JSON.stringify({
      builderId: attestation.builderId,
      sourceRepository: attestation.sourceRepository,
      commitSha: attestation.commitSha,
      buildTimestamp: attestation.buildTimestamp,
      artifactSha256,
    });

    // Import PEM public key (simplified DER/PEM conversion representation)
    const binaryKey = Uint8Array.from(atob(trustedPublicKeyPem), c => c.charCodeAt(0));
    const cryptoKey = await window.crypto.subtle.importKey(
      "spki",
      binaryKey,
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"]
    );

    const signatureBytes = Uint8Array.from(atob(attestation.signature), c => c.charCodeAt(0));
    const isValidSignature = await window.crypto.subtle.verify(
      { name: "ECDSA", hash: { name: "SHA-256" } },
      cryptoKey,
      signatureBytes,
      enc.encode(payloadString)
    );

    if (!isValidSignature) {
      return {
        isVerified: false,
        rejectionReason: "Cryptographic signature verification failed.",
      };
    }

    return {
      isVerified: true,
      provenanceDetails: attestation,
    };
  } catch (err: any) {
    return {
      isVerified: false,
      rejectionReason: err.message || "Verification routine threw an unexpected exception.",
    };
  }
}
