/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Parse and validate WebAuthn Attestation Data
interface AttestationValidationResult {
  isValid: boolean;
  credentialId: string;
  publicKeyHex: string;
  signCount: number;
  errorMessage?: string;
}

async function validateAttestationResponse(
  attestationResponse: {
    clientDataJSON: string;
    attestationObject: string;
  },
  expectedChallenge: string,
  expectedOrigin: string
): Promise<AttestationValidationResult> {
  // TODO: Implement the following steps:
  // 1. Decode clientDataJSON from base64url and parse as JSON.
  // 2. Verify that clientDataJSON.type is "webauthn.create".
  // 3. Verify that clientDataJSON.challenge matches expectedChallenge (base64url decoded).
  // 4. Verify that clientDataJSON.origin matches expectedOrigin.
  // 5. Decode attestationObject from base64url using a CBOR decoder.
  // 6. Extract authData from the attestation object.
  // 7. Parse authData to extract RP ID hash, flags (UP, UV), sign counter, and attested credential data.
  // 8. Extract credential ID and COSE-encoded public key.
  // 9. Return the validation report.
  throw new Error("Not implemented");
}
