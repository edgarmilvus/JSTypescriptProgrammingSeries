/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Client-Side E2EE Vault Manager
interface EncryptedVaultItem {
  id: string;
  ciphertext: string; // base64 encoded AES-GCM output
  iv: string;         // base64 encoded initialization vector
  encryptedDek: string; // base64 encoded DEK encrypted with KEK
  dekIv: string;      // IV used for DEK encryption
}

class ClientVaultManager {
  private kek: CryptoKey | null = null;

  constructor(private salt: Uint8Array) {}

  /**
   * Derives the Key Encryption Key (KEK) from a user master password and salt.
   */
  async initializeMasterKey(passphrase: string): Promise<void> {
    // TODO: Implement PBKDF2 key derivation using SubtleCrypto
    // Passphrase -> Key -> KEK (AES-GCM 256)
    throw new Error("Not implemented");
  }

  /**
   * Encrypts a plaintext JSON object using a freshly generated DEK.
   */
  async encryptItem(itemId: string, plaintext: object): Promise<EncryptedVaultItem> {
    // TODO: Implement envelope encryption:
    // 1. Generate a random AES-GCM 256 DEK.
    // 2. Encrypt plaintext using DEK and a random IV.
    // 3. Encrypt DEK using this.kek and a random DEK IV.
    // 4. Return EncryptedVaultItem structure with base64 encoded fields.
    throw new Error("Not implemented");
  }

  /**
   * Decrypts an EncryptedVaultItem back into its original plaintext object.
   */
  async decryptItem(item: EncryptedVaultItem): Promise<object> {
    // TODO: Implement decryption:
    // 1. Decrypt encryptedDek using this.kek to recover the DEK.
    // 2. Decrypt item ciphertext using the recovered DEK and item IV.
    // 3. Parse JSON and return plaintext object.
    throw new Error("Not implemented");
  }
}
