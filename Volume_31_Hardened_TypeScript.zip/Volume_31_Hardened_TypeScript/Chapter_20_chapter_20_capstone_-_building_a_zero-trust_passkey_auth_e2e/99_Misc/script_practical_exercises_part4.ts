/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Supply Chain Dependency Pinning and Integrity Auditor
interface AuditResult {
  passed: boolean;
  floatingDependenciesFound: string[];
  missingIntegrityHashes: string[];
  totalDependenciesInspected: number;
}

interface PackageLockFile {
  name: string;
  lockfileVersion: number;
  packages: Record<string, {
    version: string;
    integrity?: string;
    resolved?: string;
    dependencies?: Record<string, string>;
  }>;
}

function auditSupplyChainDependencies(lockFileContent: PackageLockFile): AuditResult {
  // TODO: Implement the following validation steps:
  // 1. Iterate over all entries in lockFileContent.packages.
  // 2. Detect if any version string or dependency reference contains floating operators (^, ~, x, *).
  // 3. Verify that every package entry (excluding root) has a valid `integrity` property starting with "sha512-" or "sha256-".
  // 4. Accumulate and return an AuditResult detailing violations.
  
  return {
    passed: false,
    floatingDependenciesFound: [],
    missingIntegrityHashes: [],
    totalDependenciesInspected: 0
  };
}
