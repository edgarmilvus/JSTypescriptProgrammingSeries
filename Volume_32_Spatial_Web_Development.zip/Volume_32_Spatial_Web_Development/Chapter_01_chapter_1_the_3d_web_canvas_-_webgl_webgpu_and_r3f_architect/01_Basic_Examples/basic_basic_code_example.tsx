/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useState, useMemo, useEffect } from 'https://esm.sh/react@18.2.0';
import { createRoot } from 'https://esm.sh/react-dom@18.2.0/client';
import { Canvas, useFrame, useThree } from 'https://esm.sh/@react-three/fiber@8.15.15';
import * as THREE from 'https://esm.sh/three@0.160.0';

/**
 * Interface defining the configuration state for our spatial product.
 */
interface ProductConfig {
  primaryColor: string;
  roughness: number;
  metalness: number;
  isInspected: boolean;
}

/**
 * Interface for AI inference telemetry payloads simulated via WebGPU compute pipelines.
 */
interface TensorTelemetry {
  inferenceTimeMs: number;
  confidenceScore: number;
  isWarmStart: boolean;
}

/**
 * R3F Component: InteractiveProductMesh
 * Renders a dynamic 3D asset with reactive material properties and continuous render-loop animations.
 */
const InteractiveProductMesh: React.FC<{ config: ProductConfig; onTelemetryUpdate: (data: TensorTelemetry) => void }> = ({
  config,
  onTelemetryUpdate,
}) => {
  // Reference to the underlying THREE.Mesh instance for direct imperative manipulation
  const meshRef = useRef<THREE.Mesh>(null!);
  
  // Track hover and interaction states locally to trigger declarative transitions
  const [hovered, setHovered] = useState(false);
  const [active, setActive] = useState(false);

  // Memoize material parameters to prevent unnecessary GPU pipeline recompilations
  const materialProps = useMemo(() => ({
    color: config.primaryColor,
    roughness: config.roughness,
    metalness: config.metalness,
    wireframe: config.isInspected,
  }), [config]);

  // High-performance render loop execution using R3F's useFrame hook
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smoothly rotate the product mesh based on clock time and interaction state
    const targetScale = active ? 1.2 : hovered ? 1.1 : 1.0;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), delta * 10);
    
    // Continuous subtle floating animation driven by delta time to ensure framerate independence
    meshRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 2) * 0.1;
  });

  /**
   * Simulates an asynchronous WebGPU-accelerated tensor feature extraction step
   * when the user clicks the 3D product node.
   */
  const handlePointerDown = async (e: THREE.Event) => {
    e.stopPropagation();
    setActive((prev) => !prev);

    const startTime = performance.now();

    // Simulate offloading matrix computations to a WebGPU compute shader or ONNX runtime worker
    await new Promise((resolve) => setTimeout(resolve, 15)); // Simulated tensor operation delay

    const endTime = performance.now();
    const duration = endTime - startTime;

    // Report telemetry back to the SaaS dashboard state layer
    onTelemetryUpdate({
      inferenceTimeMs: duration,
      confidenceScore: 0.984,
      isWarmStart: duration < 25, // If cached in GPU memory, classify as Warm Start
    });
  };

  return (
    <mesh
      ref={meshRef}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      onPointerDown={handlePointerDown}
    >
      <boxGeometry args={[1.5, 1.5, 1.5]} />
      <meshStandardMaterial {...materialProps} />
    </mesh>
  );
};

/**
 * Main Application Component: SpatialDashboard
 * Orchestrates UI state, Canvas rendering contexts, and local AI telemetry readouts.
 */
export const SpatialDashboard: React.FC = () => {
  const [config, setConfig] = useState<ProductConfig>({
    primaryColor: '#3b82f6',
    roughness: 0.2,
    metalness: 0.8,
    isInspected: false,
  });

  const [telemetry, setTelemetry] = useState<TensorTelemetry | null>(null);

  return (
    <div style={{ width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column', background: '#0f172a', fontFamily: 'sans-serif' }}>
      {/* SaaS Top Navigation / Control Panel */}
      <header style={{ padding: '1rem', background: '#1e293b', color: '#f8fafc', display: 'flex', gap: '1rem', alignItems: 'center', zIndex: 10 }}>
        <h1 style={{ fontSize: '1.25rem', margin: 0 }}>Spatial Web Configurator</h1>
        <button
          onClick={() => setConfig((c) => ({ ...c, primaryColor: c.primaryColor === '#3b82f6' ? '#ef4444' : '#3b82f6' }))}
          style={{ padding: '0.5rem 1rem', background: '#3b82f6', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Toggle Primary Color
        </button>
        <button
          onClick={() => setConfig((c) => ({ ...c, isInspected: !c.isInspected }))}
          style={{ padding: '0.5rem 1rem', background: '#475569', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          Toggle Wireframe
        </button>
        {telemetry && (
          <div style={{ marginLeft: 'auto', fontSize: '0.875rem', background: '#0f172a', padding: '0.5rem', borderRadius: '4px' }}>
            <span>Inference: {telemetry.inferenceTimeMs.toFixed(2)}ms</span> |{' '}
            <span style={{ color: telemetry.isWarmStart ? '#4ade80' : '#facc15' }}>
              {telemetry.isWarmStart ? 'Warm Start (GPU Cached)' : 'Cold Start'}
            </span>
          </div>
        )}
      </header>

      {/* R3F Canvas Viewport */}
      <div style={{ flex: 1, position: 'relative' }}>
        <Canvas
          camera={{ position: [0, 2, 5], fov: 50 }}
          gl={{ antialias: true, powerPreference: 'high-performance' }}
        >
          <ambientLight intensity={0.7} />
          <directionalLight position={[10, 20, 15]} intensity={1.5} />
          <InteractiveProductMesh config={config} onTelemetryUpdate={setTelemetry} />
        </Canvas>
      </div>
    </div>
  );
};
