/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface for interactive spatial node properties.
 */
interface SpatialNodeProps {
  position: [number, number, number];
  color: string;
  id: string;
}

/**
 * R3F Component: RotatingSpatialMesh
 * 
 * Represents an individual interactive 3D node within the spatial scene graph.
 * Utilizes imperative frame-by-frame updates via `useFrame` to rotate geometry
 * while maintaining a declarative state structure.
 */
function RotatingSpatialMesh({ position, color, id }: SpatialNodeProps) {
  // Reference to the underlying Three.js mesh instance for imperative animation loops
  const meshRef = useRef<THREE.Mesh>(null!);
  
  // Local state tracking hover interactions for spatial UI feedback
  const [hovered, setHovered] = React.useState(false);
  const [active, setActive] = React.useState(false);

  /**
   * High-performance render loop hook.
   * Executes code on every frame prior to the browser paint cycle.
   * 
   * @param state - The global R3F root state containing clock, camera, and GL renderer.
   * @param delta - Time elapsed since the last frame in seconds.
   */
  useFrame((state, delta) => {
    // Smooth rotational interpolation based on delta time for frame-rate independence
    meshRef.current.rotation.x += delta * 0.5;
    meshRef.current.rotation.y += delta * 0.8;

    // Dynamic scale scaling on active state toggle
    const targetScale = active ? 1.4 : hovered ? 1.2 : 1.0;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
  });

  return (
    <mesh
      ref={meshRef}
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        setActive(!active);
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
      }}
      onPointerOut={() => setHovered(false)}
      castShadow
      receiveShadow
    >
      {/* High-detail geometry for spatial realism */}
      <icosahedronGeometry args={[1, 2]} />
      
      {/* Physically Based Rendering (PBR) material reacting to environment maps */}
      <meshStandardMaterial
        color={hovered ? '#ff5722' : color}
        roughness={0.2}
        metalness={0.8}
        wireframe={active}
      />
    </mesh>
  );
}

/**
 * R3F Component: SpatialSceneManager
 * 
 * Manages the layout of spatial nodes, lighting configurations, 
 * and environment mapping within the R3F Canvas context.
 */
function SpatialSceneManager() {
  // Extract viewport metrics and WebGL capabilities via R3F hooks
  const { viewport } = useThree();

  // Memoized spatial node configurations to prevent unnecessary garbage collection cycles
  const nodes = useMemo<SpatialNodeProps[]>(() => [
    { id: 'node-1', position: [-3, 0, 0], color: '#3b82f6' },
    { id: 'node-2', position: [0, 0, 0], color: '#10b981' },
    { id: 'node-3', position: [3, 0, 0], color: '#8b5cf6' },
  ], []);

  return (
    <>
      {/* Ambient and directional scene illumination */}
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[10, 20, 15]}
        intensity={1.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />

      {/* Render spatial data nodes */}
      {nodes.map((node) => (
        <RotatingSpatialMesh key={node.id} {...node} />
      ))}

      {/* Real-time contact shadows for spatial grounding */}
      <ContactShadows
        position={[0, -2, 0]}
        opacity={0.6}
        scale={10}
        blur={2.5}
        far={4}
      />

      {/* Environment lighting for metallic PBR reflections */}
      <Environment preset="city" />

      {/* OrbitControls for desktop/VR spatial navigation */}
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        maxDistance={20}
        minDistance={2}
      />
    </>
  );
}

/**
 * Next.js Page Component: SpatialCanvasApp
 * 
 * Serves as the outer container mounting the React Three Fiber Canvas.
 * Configures WebGL/WebGPU context attributes, performance pixel-ratio limits,
 * and responsive sizing parameters.
 */
export default function SpatialCanvasApp() {
  return (
    <div className="w-full h-screen bg-slate-950 relative overflow-hidden">
      {/* Spatial Overlay UI */}
      <div className="absolute top-6 left-6 z-10 pointer-events-none">
        <h1 className="text-white text-2xl font-bold tracking-tight">Spatial Web Canvas</h1>
        <p className="text-slate-400 text-sm">Powered by React Three Fiber & WebGPU Pipeline</p>
      </div>

      {/* R3F Root Canvas */}
      <Canvas
        // Camera perspective configuration
        camera={{ position: [0, 2, 8], fov: 60 }}
        // Adaptive pixel ratio clamping to protect mobile GPU thermal states (max 2x)
        dpr={[1, 2]}
        // Performance optimization flags for WebGLRenderer
        gl={{
          antialias: true,
          powerPreference: 'high-performance',
          alpha: false,
          stencil: false,
        }}
        // Enable shadow map pipeline globally
        shadows
      >
        <SpatialSceneManager />
      </Canvas>
    </div>
  );
}
