/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const COUNT = 1000;

export function OscillatingGrid() {
  const meshRef = useRef<THREE.InstancedMesh>(null);

  // Pre-allocate temporary objects to prevent garbage collection stutters inside the loop
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const position = useMemo(() => new THREE.Vector3(), []);

  // Grid dimensions
  const gridWidth = Math.round(Math.sqrt(COUNT));

  useFrame((state) => {
    if (!meshRef.current) return;

    const time = state.clock.getElapsedTime();
    const { x: mouseX, y: mouseY } = state.pointer;

    let i = 0;
    for (let x = 0; x < gridWidth; x++) {
      for (let z = 0; z < gridWidth; z++) {
        if (i >= COUNT) break;

        // Compute base grid coordinates centered around origin
        const wx = (x - gridWidth / 2) * 0.7;
        const wz = (z - gridWidth / 2) * 0.7;

        // Calculate distance to normalized mouse position mapped to world space
        const distanceToMouse = Math.hypot(wx - mouseX * 5, wz - mouseY * 5);

        // Modulate frequency and amplitude based on cursor proximity
        const frequencyFactor = Math.max(0.5, 3.0 - distanceToMouse * 0.4);
        const yOffset = Math.sin(time * frequencyFactor + wx * 0.5 + wz * 0.5) * 0.5;

        dummy.position.set(wx, yOffset, wz);

        // Scale nodes near the mouse cursor dynamically
        const scaleFactor = Math.max(0.2, 1.2 - distanceToMouse * 0.2);
        dummy.scale.set(scaleFactor, scaleFactor + yOffset, scaleFactor);

        dummy.rotation.x = time * 0.5;
        dummy.rotation.y = time * 0.3;

        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        i++;
      }
    }

    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, COUNT]}>
      <boxGeometry args={[0.4, 0.4, 0.4]} />
      <meshStandardMaterial color="#38bdf8" roughness={0.3} metalness={0.8} />
    </instancedMesh>
  );
}

export default function App() {
  return (
    <Canvas camera={{ position: [0, 10, 15], fov: 60 }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 20, 10]} intensity={1.5} />
      <OscillatingGrid />
    </Canvas>
  );
}
