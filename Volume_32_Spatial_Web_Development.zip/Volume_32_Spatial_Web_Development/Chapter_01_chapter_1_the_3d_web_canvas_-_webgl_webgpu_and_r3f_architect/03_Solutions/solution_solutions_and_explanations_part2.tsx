/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

const PARTICLE_COUNT = 1024;

// WGSL Compute Shader for particle physics (gravity pull + velocity update)
const computeShaderCode = `
struct Particle {
    position: vec3<f32>,
    velocity: vec3<f32>,
};

struct Uniforms {
    attractor: vec3<f32>,
    deltaTime: f32,
};

@binding(0) @group(0) var<storage, read_write> particles: array<Particle>;
@binding(1) @group(0) var<uniform> uniforms: Uniforms;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) GlobalInvocationID: vec3<u32>) {
    let index = GlobalInvocationID.x;
    if (index >= 1024u) { return; }

    var p = particles[index];
    
    // Calculate vector toward interactive attractor point
    let direction = uniforms.attractor - p.position;
    let dist = length(direction);
    
    if (dist > 0.1) {
        let force = normalize(direction) * (1.0 / (dist * dist + 1.0));
        p.velocity += force * uniforms.deltaTime;
    }

    // Apply velocity damping and position integration
    p.velocity *= 0.98;
    p.position += p.velocity * uniforms.deltaTime;

    particles[index] = p;
}
`;

export function WebGPUParticleSystem() {
  const pointsRef = useRef<THREE.Points>(null);
  const { gl } = useThree();

  useEffect(() => {
    // Ensure renderer supports WebGPU features or establish fallback gracefully
    if (!navigator.gpu) {
      console.warn("WebGPU not supported on this client environment. Falling back to CPU simulation.");
      return;
    }

    // Initialization logic for WebGPU device, buffer allocation, and pipeline setup
    // would be instantiated here in a production WebGPU renderer context.
  }, [gl]);

  useFrame((state) => {
    // Frame-level updates for uniform buffers (e.g., updating attractor position from pointer)
    const { x, y } = state.pointer;
    const targetVector = new THREE.Vector3(x * 5, y * 5, 0);
    
    // In a full WebGPU interop setup, targetVector is pushed via device.queue.writeBuffer
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        {/* Placeholder attributes bound to WebGPU storage buffers */}
        <bufferAttribute
          attach="attributes-position"
          args={[new Float32Array(PARTICLE_COUNT * 3), 3]}
        />
      </bufferGeometry>
      <pointsMaterial size={0.1} color="#f43f5e" transparent opacity={0.8} />
    </points>
  );
}

export default function App() {
  return (
    <Canvas camera={{ position: [0, 0, 10] }}>
      <WebGPUParticleSystem />
    </Canvas>
  );
}
