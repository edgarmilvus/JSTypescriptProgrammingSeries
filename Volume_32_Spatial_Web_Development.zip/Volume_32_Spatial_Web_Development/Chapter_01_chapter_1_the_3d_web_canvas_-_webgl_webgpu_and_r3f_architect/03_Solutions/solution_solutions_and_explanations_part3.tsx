/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// app/actions/spatial-chat.ts
'use server';

export async function submitSpatialQuery(prompt: string, contextUuid?: string) {
  // Secure server-side processing with hidden API keys
  const apiKey = process.env.AI_API_KEY;
  
  // Simulated LLM reasoning returning structured tool execution commands
  const mockToolCall = prompt.toLowerCase().includes('red') 
    ? { tool: 'setColor', targetUuid: contextUuid, color: '#ef4444' }
    : { tool: 'spawnPrimitive', type: 'sphere', color: '#3b82f6' };

  return {
    response: `Processed query: "${prompt}". Executing spatial adjustment.`,
    toolCall: mockToolCall,
  };
}

// components/SpatialChatOverlay.tsx
'use client';

import React, { useState } from 'react';

interface SpatialChatOverlayProps {
  onToolCallReceived: (toolCall: { tool: string; targetUuid?: string; color?: string; type?: string }) => void;
  selectedObjectUuid?: string | null;
}

export function SpatialChatOverlay({ onToolCallReceived, selectedObjectUuid }: SpatialChatOverlayProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: string; text: string }>>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages((prev) => [...prev, { sender: 'User', text: userMsg }]);
    setLoading(true);

    try {
      const result = await submitSpatialQuery(userMsg, selectedObjectUuid || undefined);
      setMessages((prev) => [...prev, { sender: 'Assistant', text: result.response }]);
      if (result.toolCall) {
        onToolCallReceived(result.toolCall);
      }
    } catch (err) {
      console.error("Failed to execute spatial chat action", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="absolute bottom-6 left-6 z-50 w-96 rounded-xl bg-slate-900/80 p-4 backdrop-blur-md border border-slate-700 text-white shadow-2xl">
      <div className="mb-3 max-h-48 overflow-y-auto space-y-2 pr-1 text-sm">
        {messages.map((m, idx) => (
          <div key={idx} className={`p-2 rounded-lg ${m.sender === 'User' ? 'bg-sky-600/40 ml-4' : 'bg-slate-800 mr-4'}`}>
            <span className="font-semibold text-xs opacity-75">{m.sender}: </span>
            <p>{m.text}</p>
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={selectedObjectUuid ? "Command selected object..." : "Ask spatial AI..."}
          className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500"
        />
        <button
          type="submit"
          disabled={loading}
          className="bg-sky-500 hover:bg-sky-600 px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
        >
          {loading ? '...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
