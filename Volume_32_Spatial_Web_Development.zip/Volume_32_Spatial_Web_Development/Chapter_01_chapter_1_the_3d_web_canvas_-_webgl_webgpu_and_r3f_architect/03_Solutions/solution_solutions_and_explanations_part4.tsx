/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
// import * as ort from 'onnxruntime-web'; // Simulated import for ONNX Runtime

export async function createInferenceSession() {
  try {
    // Attempt initialization with WebGPU, fallback to WASM
    // return await ort.InferenceSession.create('/models/gesture_model.onnx', {
    //   executionProviders: ['webgpu', 'wasm'],
    // });
    return {
      run: async (_feeds: Record<string, any>) => ({
        output: { data: new Float32Array([1.5, 0.8]) }
      })
    };
  } catch (e) {
    console.warn("Hardware accelerator unavailable, using CPU fallback.", e);
    throw e;
  }
}

export function GestureControlledScene() {
  const meshRef = useRef<THREE.Mesh>(null);
  const [scaleFactor, setScaleFactor] = useState(1);
  const isInferencingRef = useRef(false);

  useEffect(() => {
    let active = true;
    let session: any = null;

    createInferenceSession()
      .then((s) => {
        if (active) session = s;
      })
      .catch(console.error);

    // Asynchronous non-blocking inference loop with frame-skipping
    const interval = setInterval(async () => {
      if (!session || isInferencingRef.current) return;

      isInferencingRef.current = true;
      try {
        // Mock input tensor generation from telemetry stream
        // const inputTensor = new ort.Tensor('float32', new Float32Array(224 * 224 * 3), [1, 3, 224, 224]);
        const results = await session.run({ input: {} });
        
        const outputData = results.output.data as Float32Array;
        const dynamicScale = outputData[0];

        if (active) {
          setScaleFactor(dynamicScale);
        }
      } catch (err) {
        console.error("Inference execution failed:", err);
      } finally {
        isInferencingRef.current = false;
      }
    }, 33); // Target ~30 FPS inference rate

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  useFrame((state) => {
    if (!meshRef.current) return;
    // Smoothly interpolate current scale toward target inference output
    meshRef.current.scale.lerp(new THREE.Vector3(scaleFactor, scaleFactor, scaleFactor), 0.1);
    meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.5;
  });

  return (
    <mesh ref={meshRef}>
      <icosahedronGeometry args={[1.5, 2]} />
      <meshStandardMaterial color="#10b981" wireframe />
    </mesh>
  );
}

export default function App() {
  return (
    <Canvas camera={{ position: [0, 0, 5] }}>
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 5, 5]} intensity={1.2} />
      <GestureControlledScene />
    </Canvas>
  );
}
