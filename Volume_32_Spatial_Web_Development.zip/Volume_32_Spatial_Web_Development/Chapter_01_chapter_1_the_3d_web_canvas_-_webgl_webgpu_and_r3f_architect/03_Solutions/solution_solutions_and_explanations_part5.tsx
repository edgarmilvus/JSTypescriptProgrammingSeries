/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useGLTF, LOD } from '@react-three/drei';
import * as THREE from 'three';

export function OptimizedScene() {
  const groupRef = useRef<THREE.Group>(null);
  const { gl, camera } = useThree();
  const [adaptivePixelRatio, setAdaptivePixelRatio] = useState(window.devicePixelRatio);
  
  // Performance sliding window tracking
  const fpsHistory = useRef<number[]>([]);

  useEffect(() => {
    // Setup explicit bounding volumes for custom culling optimization
    if (groupRef.current) {
      groupRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.computeBoundingBox();
          child.geometry.computeBoundingSphere();
          if (child.geometry.boundingSphere) {
            // Expand bounding sphere radius to prevent premature frustum culling clipping
            child.geometry.boundingSphere.radius *= 1.2;
          }
        }
      });
    }

    return () => {
      // Memory disposal protocol
      groupRef.current?.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach((mat) => mat.dispose());
          } else {
            child.material.dispose();
          }
        }
      });
    };
  }, []);

  // Adaptive resolution monitoring loop
  useFrame((state, delta) => {
    const currentFps = 1 / Math.max(delta, 0.001);
    fpsHistory.current.push(currentFps);
    if (fpsHistory.current.length > 60) fpsHistory.current.shift();

    const avgFps = fpsHistory.current.reduce((a, b) => a + b, 0) / fpsHistory.current.length;

    // Adaptive degradation pipeline
    if (avgFps < 55 && adaptivePixelRatio > 1.0) {
      const newRatio = Math.max(1.0, adaptivePixelRatio - 0.25);
      gl.setPixelRatio(newRatio);
      setAdaptivePixelRatio(newRatio);
    } else if (avgFps > 58 && adaptivePixelRatio < window.devicePixelRatio) {
      const newRatio = Math.min(window.devicePixelRatio, adaptivePixelRatio + 0.25);
      gl.setPixelRatio(newRatio);
      setAdaptivePixelRatio(newRatio);
    }
  });

  return (
    <group ref={groupRef}>
      {/* Dynamic LOD switching based on camera distance */}
      <LOD distances={[0, 10, 25]}>
        <mesh>
          <boxGeometry args={[2, 2, 2]} />
          <meshStandardMaterial color="#6366f1" />
        </mesh>
        <mesh>
          <boxGeometry args={[1.5, 1.5, 1.5]} />
          <meshStandardMaterial color="#818cf8" />
        </mesh>
        <mesh>
          <boxGeometry args={[1, 1, 1]} />
          <meshStandardMaterial color="#c7d2fe" />
        </mesh>
      </LOD>
    </group>
  );
}

export default function App() {
  return (
    <Canvas camera={{ position: [0, 5, 15] }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1.5} />
      <OptimizedScene />
    </Canvas>
  );
}
