/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @file ProductPreviewCanvas.tsx
 * @description A self-contained R3F component rendering an interactive 3D product SKU placeholder 
 * for a spatial SaaS web application. It includes a responsive canvas, reactive geometries,
 * customized physical materials, dynamic lighting, and a continuous render-loop animation.
 */

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Center } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface defining the property options for the interactive rotating product mesh.
 */
interface RotatingProductProps {
  /** The base color of the product material */
  color?: string;
  /** Scale modifier for the product dimensions */
  scale?: number;
}

/**
 * RotatingProduct Component
 * 
 * Renders an individual 3D mesh (a rounded box representing a hardware module SKU) 
 * inside the R3F scene. Utilizes the useFrame hook to hook directly into the Three.js 
 * render loop for smooth, frame-rate independent rotation animations.
 */
const RotatingProduct: React.FC<RotatingProductProps> = ({ 
  color = '#4f46e5', 
  scale = 1 
}) => {
  // Explicitly type the ref to target the Three.js Mesh instance.
  // This allows us to imperatively mutate transform matrices during the render loop.
  const meshRef = useRef<THREE.Mesh>(null!);

  // useFrame executes a callback on every single animation frame (typically 60fps or 120fps).
  // state provides access to the Three.js root state (camera, clock, gl renderer),
  // while delta represents the time elapsed since the last frame for smooth frame-rate normalization.
  useFrame((state, delta) => {
    if (meshRef.current) {
      // Increment rotation values along the X and Y axes continuously
      meshRef.current.rotation.x += delta * 0.5;
      meshRef.current.rotation.y += delta * 0.8;
      
      // Add a subtle floating animation using a sine wave derived from the global clock time
      meshRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 2) * 0.1;
    }
  });

  return (
    // Center utility from @react-three/drei ensures the bounding box geometry 
    // is perfectly centered at the origin (0,0,0) of its local coordinate space.
    <Center>
      <mesh ref={meshRef} scale={scale}>
        {/* BoxGeometry defines the 3D dimensions: width, height, depth, and optional bevel/segments */}
        <boxGeometry args={[1.5, 1.5, 1.5, 32, 32, 32]} />
        
        {/* 
          meshStandardMaterial is a physically-based rendering (PBR) material.
          It reacts realistically to light sources based on properties like roughness and metalness.
        */}
        <meshStandardMaterial 
          color={color} 
          roughness={0.2} 
          metalness={0.8}
          wireframe={false}
        />
      </mesh>
    </Center>
  );
};

/**
 * ProductPreviewCanvas Component
 * 
 * Serves as the primary viewport container for the 3D scene. 
 * Initializes the WebGL context, camera frustum, lighting rigs, and post-processing helpers.
 */
export const ProductPreviewCanvas: React.FC = () => {
  return (
    <div className="w-full h-[500px] bg-slate-950 rounded-xl overflow-hidden shadow-2xl relative border border-slate-800">
      {/* SaaS UI Overlay Header */}
      <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-lg border border-slate-700/50">
        <h3 className="text-white font-semibold text-sm">SKU-9904-X Spatial Inspector</h3>
        <p className="text-slate-400 text-xs">Interactive 3D Hardware Blueprint</p>
      </div>

      {/* 
        The Canvas component is the boundary where React DOM meets the Three.js WebGL renderer.
        It automatically manages the WebGL context lifecycle, canvas resizing, and render loop.
      */}
      <Canvas
        camera={{ position: [0, 0, 5], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
      >
        {/* Ambient light provides soft, non-directional base illumination across all geometries */}
        <ambientLight intensity={0.7} />

        {/* Directional light simulates a strong sun or studio spotlight casting shadows */}
        <directionalLight 
          position={[10, 10, 5]} 
          intensity={1.5} 
          castShadow 
        />

        {/* Point light adds a colorful secondary accent fill light from a specific coordinate */}
        <pointLight position={[-10, -10, -5]} intensity={0.5} color="#38bdf8" />

        {/* Render our custom interactive 3D product mesh */}
        <RotatingProduct color="#6366f1" scale={1.2} />

        {/* OrbitControls enables mouse/touch interaction (pan, zoom, rotate) around the target */}
        <OrbitControls 
          enablePan={true} 
          enableZoom={true} 
          minDistance={2} 
          maxDistance={10} 
        />
      </Canvas>
    </div>
  );
};

export default ProductPreviewCanvas;
