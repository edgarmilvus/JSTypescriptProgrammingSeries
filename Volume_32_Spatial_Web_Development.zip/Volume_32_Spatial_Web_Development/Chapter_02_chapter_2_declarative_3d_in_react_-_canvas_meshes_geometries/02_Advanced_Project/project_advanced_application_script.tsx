/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef, useState, useTransition, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html, Center, Float } from '@react-three/drei';
import * as THREE from 'three';
import { z } from 'zod';

/**
 * Zod schema defining the runtime structural contract for product configuration payloads.
 * Ensures data integrity when passing external updates to the 3D scene graph.
 */
const ProductConfigSchema = z.object({
  id: z.string().uuid(),
  modelName: z.string().min(1),
  finishType: z.enum(['matte', 'glossy', 'metallic', 'textured']),
  primaryColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a valid hex color"),
  scaleFactor: z.number().positive().min(0.5).max(2.0),
  enableFloatAnimation: z.boolean(),
});

type ProductConfig = z.infer<typeof ProductConfigSchema>;

interface ConfiguratorCanvasProps {
  initialConfig: unknown;
  onConfigChange?: (newConfig: ProductConfig) => void;
}

/**
 * Core 3D Product Mesh component. Handles custom geometry, reactive materials,
 * animations, and frame-by-frame updates without causing React re-renders.
 */
function ConfigurableProductMesh({ 
  config 
}: { 
  config: ProductConfig 
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [active, setActive] = useState(false);

  // Compute material properties dynamically based on the validated Zod configuration state.
  const materialProps = useMemo(() => {
    switch (config.finishType) {
      case 'matte':
        return { roughness: 0.8, metalness: 0.1, clearcoat: 0 };
      case 'glossy':
        return { roughness: 0.1, metalness: 0.1, clearcoat: 1.0, clearcoatRoughness: 0.1 };
      case 'metallic':
        return { roughness: 0.2, metalness: 0.95, clearcoat: 0.3 };
      case 'textured':
        return { roughness: 0.5, metalness: 0.4 };
      default:
        return { roughness: 0.5, metalness: 0.5 };
    }
  }, [config.finishType]);

  // Frame-by-frame rotation loop executed inside the WebGL render loop (60+ FPS).
  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    // Smoothly interpolate rotation towards target state based on user interaction
    const targetScale = active ? config.scaleFactor * 1.15 : config.scaleFactor;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    
    if (!hovered) {
      meshRef.current.rotation.y += delta * 0.4;
    }
  });

  return (
    <Float 
      speed={config.enableFloatAnimation ? 2 : 0} 
      rotationIntensity={config.enableFloatAnimation ? 0.5 : 0} 
      floatIntensity={config.enableFloatAnimation ? 1 : 0}
    >
      <Center>
        <mesh
          ref={meshRef}
          onClick={(e) => { e.stopPropagation(); setActive((prev) => !prev); }}
          onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
          onPointerOut={() => setHovered(false)}
          castShadow
          receiveShadow
        >
          {/* Declarative Primitive Geometry: Rounded Box representing a modular SaaS hardware unit */}
          <boxGeometry args={[2, 2, 2, 32, 32, 32]} />
          
          {/* Reactive Physical Material mapping dynamic hex colors and PBR attributes */}
          <meshPhysicalMaterial
            color={config.primaryColor}
            roughness={materialProps.roughness}
            metalness={materialProps.metalness}
            clearcoat={'clearcoat' in materialProps ? materialProps.clearcoat : 0}
            clearcoatRoughness={'clearcoatRoughness' in materialProps ? materialProps.clearcoatRoughness : 0}
          />
        </mesh>
      </Center>
    </Float>
  );
}

/**
 * Studio lighting rig setup to create accurate reflections, ambient shadows,
 * and dramatic key/fill lighting for high-end product visualization.
 */
function StudioLighting() {
  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight
        position={[10, 20, 15]}
        intensity={2.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.0001}
      />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />
      <spotLight
        position={[0, 15, 0]}
        intensity={1.2}
        angle={0.6}
        penumbra={0.8}
      />
    </>
  );
}

/**
 * Main application canvas wrapper managing the WebGL context, camera defaults,
 * progressive asset loading states, and React 18 transition hooks.
 */
export default function ProductConfiguratorCanvas({ 
  initialConfig, 
  onConfigChange 
}: ConfiguratorCanvasProps) {
  const [isPending, startTransition] = useTransition();
  const [config, setConfig] = useState<ProductConfig>(() => {
    // Validate initial properties at runtime using the Zod schema
    const result = ProductConfigSchema.safeParse(initialConfig);
    if (!result.success) {
      console.warn("Invalid initial configuration provided, falling back to defaults.", result.error);
      return {
        id: '123e4567-e89b-12d3-a456-426614174000',
        modelName: 'Enterprise SaaS Node v1',
        finishType: 'metallic',
        primaryColor: '#3b82f6',
        scaleFactor: 1.0,
        enableFloatAnimation: true,
      };
    }
    return result.data;
  });

  const handleColorUpdate = (newColor: string) => {
    startTransition(() => {
      const updated = { ...config, primaryColor: newColor };
      const validated = ProductConfigSchema.parse(updated);
      setConfig(validated);
      onConfigChange?.(validated);
    });
  };

  return (
    <div className="relative w-full h-[600px] bg-slate-950 rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
      {/* SaaS Overlay Controls */}
      <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur-md p-4 rounded-xl border border-slate-700/50 text-white flex flex-col gap-2">
        <h3 className="text-sm font-semibold text-slate-200">{config.modelName}</h3>
        <p className="text-xs text-slate-400">Finish: <span className="capitalize text-slate-200">{config.finishType}</span></p>
        
        <div className="flex items-center gap-2 mt-2">
          <span className="text-xs text-slate-400">Accent Color:</span>
          <input 
            type="color" 
            value={config.primaryColor}
            onChange={(e) => handleColorUpdate(e.target.value)}
            className="w-8 h-8 rounded border-0 cursor-pointer bg-transparent"
          />
        </div>
        {isPending && <span className="text-[10px] text-blue-400 animate-pulse">Updating spatial nodes...</span>}
      </div>

      {/* R3F Declarative Canvas Viewport */}
      <Canvas
        shadows
        camera={{ position: [0, 0, 6], fov: 50 }}
        gl={{ antialias: true, alpha: false }}
        className="w-full h-full"
      >
        <color attach="background" args={['#020617']} />
        
        {/* Environmental Lighting */}
        <StudioLighting />

        {/* 3D Asset Entity */}
        <ConfigurableProductMesh config={config} />

        {/* Camera Controls with Damping for Smooth Inertia */}
        <OrbitControls 
          enablePan={false} 
          enableZoom={true} 
          minDistance={3} 
          maxDistance={10} 
          maxPolarAngle={Math.PI / 2 + 0.1}
          dampingFactor={0.05}
        />
      </Canvas>
    </div>
  );
}
