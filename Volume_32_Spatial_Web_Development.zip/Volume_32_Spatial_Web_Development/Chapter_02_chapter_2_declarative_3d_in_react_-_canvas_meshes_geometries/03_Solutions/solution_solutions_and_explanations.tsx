/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { PerspectiveCamera, OrthographicCamera } from '@react-three/drei';
import * as THREE from 'three';

interface SpatialCanvasRigProps {
  children: React.ReactNode;
  cameraPosition?: [number, number, number];
  fov?: number;
  backgroundColor?: string;
}

const AnimatedRig: React.FC = () => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (groupRef.current) {
      // Gently oscillate the Y-position over time using delta for frame-rate independence
      groupRef.current.position.y = Math.sin(state.clock.getElapsedTime()) * 0.2;
      groupRef.current.rotation.y += delta * 0.2;
    }
  });

  return <group ref={groupRef} />;
};

export const SpatialCanvasRig: React.FC<SpatialCanvasRigProps> = ({
  children,
  cameraPosition = [0, 0, 5],
  fov = 75,
  backgroundColor = '#111111',
}) => {
  const [isOrthographic, setIsOrthographic] = useState(false);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'Space') {
        setIsOrthographic((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Canvas
        shadows
        gl={{ background: new THREE.Color(backgroundColor) }}
        camera={
          isOrthographic
            ? { position: cameraPosition, zoom: 50 }
            : { position: cameraPosition, fov }
        }
      >
        {isOrthographic ? (
          <OrthographicCamera makeDefault position={cameraPosition} zoom={50} />
        ) : (
          <PerspectiveCamera makeDefault position={cameraPosition} fov={fov} />
        )}
        <AnimatedRig />
        {children}
      </Canvas>
    </div>
  );
};
