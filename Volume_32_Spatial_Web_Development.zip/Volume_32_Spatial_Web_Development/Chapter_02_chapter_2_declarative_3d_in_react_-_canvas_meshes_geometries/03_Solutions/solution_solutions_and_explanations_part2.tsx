/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { Mesh, Group } from 'three';
import { useFrame } from '@react-three/fiber';

export const ModularRoboticArm: React.FC = () => {
  const baseRef = useRef<Mesh>(null);
  const shoulderRef = useRef<Mesh>(null);
  const upperArmRef = useRef<Mesh>(null);
  const clawRef = useRef<Group>(null);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    if (shoulderRef.current) {
      shoulderRef.current.rotation.y = Math.sin(time) * 0.5;
    }
    if (upperArmRef.current) {
      upperArmRef.current.rotation.z = Math.cos(time * 0.7) * 0.3;
    }
    if (clawRef.current) {
      clawRef.current.scale.x = 1 + Math.sin(time * 3) * 0.2;
    }
  });

  return (
    <group>
      {/* Base Mesh */}
      <mesh ref={baseRef} position={[0, -1.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[2, 0.5, 2]} />
        <meshStandardMaterial color="#444444" />
        
        {/* Shoulder Joint */}
        <mesh ref={shoulderRef} position={[0, 0.5, 0]} castShadow>
          <sphereGeometry args={[0.4, 32, 32]} />
          <meshStandardMaterial color="#ff5500" />
          
          {/* Upper Arm Segment */}
          <mesh ref={upperArmRef} position={[0, 1.2, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 2]} />
            <meshStandardMaterial color="#aaaaaa" />
            
            {/* Effector / Claw Assembly */}
            <group ref={clawRef} position={[0, 1.2, 0]}>
              <mesh position={[-0.2, 0, 0]} castShadow>
                <boxGeometry args={[0.1, 0.4, 0.4]} />
                <meshStandardMaterial color="#222222" />
              </mesh>
              <mesh position={[0.2, 0, 0]} castShadow>
                <boxGeometry args={[0.1, 0.4, 0.4]} />
                <meshStandardMaterial color="#222222" />
              </mesh>
            </group>
          </mesh>
        </mesh>
      </mesh>
    </group>
  );
};
