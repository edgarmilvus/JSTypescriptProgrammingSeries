/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Mesh } from 'three';

type MaterialType = 'basic' | 'standard' | 'physical';

interface MaterialWorkbenchProps {
  initialType?: MaterialType;
}

const RotatingIcosahedron: React.FC<{ type: MaterialType; roughness: number }> = ({ type, roughness }) => {
  const meshRef = useRef<Mesh>(null);
  const materialRef = useRef<any>(null);

  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.3;
      meshRef.current.rotation.y += delta * 0.5;
    }
    if (materialRef.current && type === 'standard') {
      // Shift hue over time
      const time = state.clock.getElapsedTime();
      materialRef.current.color.setHSL((time * 0.1) % 1, 0.8, 0.5);
    }
  });

  return (
    <mesh ref={meshRef} castShadow receiveShadow>
      <icosahedronGeometry args={[1.5, 0]} />
      {type === 'basic' && <meshBasicRef ref={materialRef} color="hotpink" />}
      {type === 'standard' && <meshStandardMaterial ref={materialRef} roughness={roughness} />}
      {type === 'physical' && (
        <meshPhysicalMaterial
          ref={materialRef}
          roughness={roughness}
          transmission={0.9}
          thickness={1.2}
          ior={1.5}
        />
      )}
    </mesh>
  );
};

export const MaterialWorkbench: React.FC<MaterialWorkbenchProps> = ({ initialType = 'standard' }) => {
  const [materialType, setMaterialType] = useState<MaterialType>(initialType);
  const [roughness, setRoughness] = useState<number>(0.5);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      <div style={{ position: 'absolute', zIndex: 10, padding: 20, display: 'flex', gap: '10px' }}>
        <button onClick={() => setMaterialType('basic')}>Basic</button>
        <button onClick={() => setMaterialType('standard')}>Standard</button>
        <button onClick={() => setMaterialType('physical')}>Physical</button>
        <label style={{ color: 'white' }}>
          Roughness:
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={roughness}
            onChange={(e) => setRoughness(parseFloat(e.target.value))}
          />
        </label>
      </div>
      <Canvas camera={{ position: [0, 0, 5] }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        <RotatingIcosahedron type={materialType} roughness={roughness} />
      </Canvas>
    </div>
  );
};

// Placeholder fix for JSX intrinsic element fallback if missing
const meshBasicRef = (props: any) => <meshBasicMaterial {...props} />;
