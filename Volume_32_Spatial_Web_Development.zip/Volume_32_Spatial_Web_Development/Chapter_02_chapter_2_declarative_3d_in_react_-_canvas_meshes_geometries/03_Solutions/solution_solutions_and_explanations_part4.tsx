/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { DirectionalLightHelper, PointLightHelper } from 'three';
import { useHelper } from '@react-three/drei';
import * as THREE from 'three';

interface SpatialLightingRigProps {
  showHelpers?: boolean;
}

const LightingRigContent: React.FC<SpatialLightingRigProps> = ({ showHelpers }) => {
  const dirLightRef = useRef<THREE.DirectionalLight>(null);
  const pointLightRef1 = useRef<THREE.PointLight>(null);
  const pointLightRef2 = useRef<THREE.PointLight>(null);

  // Utilize Drei helpers conditionally or safely
  useHelper(showHelpers && dirLightRef, DirectionalLightHelper, 1, 'yellow');
  useHelper(showHelpers && pointLightRef1, PointLightHelper, 0.5, 'cyan');
  useHelper(showHelpers && pointLightRef2, PointLightHelper, 0.5, 'magenta');

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    // Dynamic day-night orbital arc for directional light
    if (dirLightRef.current) {
      dirLightRef.current.position.x = Math.cos(time * 0.2) * 15;
      dirLightRef.current.position.y = Math.sin(time * 0.2) * 15;
    }
  });

  return (
    <>
      <ambientLight intensity={0.3} />
      <directionalLight
        ref={dirLightRef}
        position={[10, 10, 5]}
        intensity={1.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      <pointLight ref={pointLightRef1} position={[-5, 2, -5]} intensity={2} color="#ff0055" />
      <pointLight ref={pointLightRef2} position={[5, 2, 5]} intensity={2} color="#00ffff" />

      {/* Ground Plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#222222" roughness={0.8} />
      </mesh>

      {/* Cast Shadow Object */}
      <mesh position={[0, 0, 0]} castShadow>
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial color="#ffffff" />
      </mesh>
    </>
  );
};

export const SpatialLightingRig: React.FC<SpatialLightingRigProps> = ({ showHelpers = false }) => {
  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Canvas shadows camera={{ position: [0, 5, 10] }}>
        <LightingRigContent showHelpers={showHelpers} />
      </Canvas>
    </div>
  );
};
