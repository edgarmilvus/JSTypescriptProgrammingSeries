/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Group, Mesh } from 'three';

export const MatrixTransformationPipeline: React.FC = () => {
  const groupRef = useRef<Group>(null);
  const meshRefs = useRef<Mesh[]>([]);

  const gridSize = 8;
  const items = Array.from({ length: gridSize * gridSize });

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    meshRefs.current.forEach((mesh, index) => {
      if (!mesh) return;
      const x = (index % gridSize) - gridSize / 2;
      const z = Math.floor(index / gridSize) - gridSize / 2;
      
      // Calculate wave distance from center
      const distance = Math.sqrt(x * x + z * z);
      
      // Non-linear wave propagation on Y axis
      mesh.position.y = Math.sin(time * 3 - distance * 0.5) * 0.75;
      
      // Dynamic scaling pulse based on wave height
      const scale = 1 + Math.sin(time * 2 - distance) * 0.3;
      mesh.scale.set(scale, scale, scale);
    });
  });

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Canvas camera={{ position: [0, 10, 15] }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 20, 10]} intensity={1} />
        <group ref={groupRef}>
          {items.map((_, index) => {
            const x = (index % gridSize) - gridSize / 2;
            const z = Math.floor(index / gridSize) - gridSize / 2;
            return (
              <mesh
                key={index}
                ref={(el) => {
                  if (el) meshRefs.current[index] = el;
                }}
                position={[x * 1.2, 0, z * 1.2]}
              >
                <boxGeometry args={[0.8, 0.8, 0.8]} />
                <meshStandardMaterial color="#008080" roughness={0.3} />
              </mesh>
            );
          })}
        </group>
      </Canvas>
    </div>
  );
};
