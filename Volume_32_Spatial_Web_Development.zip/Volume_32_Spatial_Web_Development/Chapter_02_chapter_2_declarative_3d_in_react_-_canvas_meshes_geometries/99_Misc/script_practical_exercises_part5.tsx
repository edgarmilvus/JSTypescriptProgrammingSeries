/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// Starter template for Exercise 5
import React, { useRef } from 'react';
import { Group, Mesh } from 'three';
import { useFrame } from '@react-three/fiber';

export const MatrixTransformationPipeline: React.FC = () => {
  const groupRef = useRef<Group>(null);
  const meshRefs = useRef<Mesh[]>([]);

  // Generate grid items procedurally
  const gridSize = 5;
  const items = Array.from({ length: gridSize * gridSize });

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    // Apply wave transformations across meshRefs.current
  });

  return (
    <group ref={groupRef}>
      {items.(_, index) => {
        const x = (index % gridSize) - gridSize / 2;
        const z = Math.floor(index / gridSize) - gridSize / 2;
        return (
          <mesh
            key={index}
            ref={(el) => {
              if (el) meshRefs.current[index] = el;
            }}
            position={[x * 1.2, 0, z * 1.2]}
          >
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color="teal" />
          </mesh>
        );
      })}
    </group>
  );
};
