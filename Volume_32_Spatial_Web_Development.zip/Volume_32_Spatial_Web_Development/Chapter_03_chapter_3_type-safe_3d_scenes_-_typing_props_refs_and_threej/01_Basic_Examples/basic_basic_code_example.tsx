/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Mesh } from 'three';
import { Html } from '@react-three/drei';

/**
 * Interface representing the configuration options for our 3D Product Mesh.
 */
interface ProductMeshProps {
  /** The commercial product identifier used for telemetry and state tracking. */
  productId: string;
  /** Initial base color of the product mesh in hexadecimal format. */
  baseColor?: string;
  /** Scale multiplier for the product mesh. Defaults to 1. */
  scaleMultiplier?: number;
  /** Callback triggered when the user interacts with the product mesh. */
  onSelect?: (id: string) => void;
}

/**
 * A type-safe 3D Product Card component rendering an interactive mesh with R3F and Drei.
 */
const ProductMesh: React.FC<ProductMeshProps> = ({
  productId,
  baseColor = '#4f46e5', // Default Indigo-600
  scaleMultiplier = 1,
  onSelect,
}) => {
  // Explicitly type the ref using the Three.js Mesh class to ensure full auto-completion and type safety.
  const meshRef = useRef<Mesh>(null);

  // Local state tracking hover status for visual feedback.
  const [hovered, setHovered] = useState<boolean>(false);
  const [active, setActive] = useState<boolean>(false);

  // useFrame hook runs on every render frame; safely animate the mesh rotation if the ref is initialized.
  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    // Smoothly rotate the product mesh on the Y axis
    meshRef.current.rotation.y += delta * 0.5;

    // Dynamically scale based on active interaction state
    const targetScale = active ? scaleMultiplier * 1.2 : scaleMultiplier;
    meshRef.current.scale.lerp(
      { x: targetScale, y: targetScale, z: targetScale },
  });

  return (
    <mesh
      ref={meshRef}
      onClick={(e) => {
        // Prevent event propagation to underlying canvases
        e.stopPropagation();
        setActive((prev) => !prev);
        if (onSelect) onSelect(productId);
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
      }}
      onPointerOut={() => setHovered(false)}
    >
      {/* Primitive geometry: A rounded box or standard box */}
      <boxGeometry args={[1.5, 1.5, 1.5]} />
      
      {/* Standard Three.js material with dynamic color shifts based on hover/active state */}
      <meshStandardMaterial 
        color={hovered ? '#ec4899' : baseColor} 
        wireframe={false}
      />

      {/* HTML overlay anchored to the 3D position using Drei */}
      <Html position={[0, 1.2, 0]} center distanceFactor={8}>
        <div className="px-3 py-1 bg-slate-900/90 text-white text-xs font-sans rounded-md shadow-lg pointer-events-none backdrop-blur-sm border border-slate-700">
          <span className="font-semibold">ID:</span> {productId}
          {active && <span className="block text-pink-400 text-[10px]">Selected</span>}
        </div>
      </Html>
    </mesh>
  );
};

/**
 * Root Application Component setting up the Canvas and lighting for the SaaS dashboard.
 */
export default function SaaSProductConfigurator() {
  const handleProductSelect = (id: string) => {
    console.log(`Telemetry: Product configuration updated for SKU -> ${id}`);
  };

  return (
    <div className="w-full h-screen bg-slate-950 flex flex-col items-center justify-center">
      <header className="absolute top-6 left-6 z-10 text-white font-sans">
        <h1 className="text-xl font-bold tracking-tight">Spatial SaaS Configurator</h1>
        <p className="text-xs text-slate-400">Type-Safe 3D Scenes with React Three Fiber</p>
      </header>

      <Canvas camera={{ position: [0, 0, 5], fov: 60 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 10, 5]} intensity={1.5} />
        <pointLight position={[-10, -10, -5]} intensity={0.5} />
        
        {/* Render our type-safe component */}
        <ProductMesh 
          productId="SKU-8821-PRO" 
          baseColor="#3b82f6" 
          scaleMultiplier={1.1} 
          onSelect={handleProductSelect} 
        />
      </Canvas>
    </div>
  );
}
