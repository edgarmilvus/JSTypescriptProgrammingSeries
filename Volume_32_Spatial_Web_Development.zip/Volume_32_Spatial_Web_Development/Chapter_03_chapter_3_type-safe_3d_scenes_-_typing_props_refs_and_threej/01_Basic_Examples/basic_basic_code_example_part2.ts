/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph TypeSafeSpatialArchitecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f8fafc", color="#cbd5e1", fontcolor="#0f172a"];

    subgraph cluster_typescript {
        label = "TypeScript Compile-Time Layer";
        style=filled;
        fillcolor="#f1f5f9";
        
        Interfaces [label="Interfaces & Props\n(ProductMeshProps)", fillcolor="#e0e7ff", color="#818cf8"];
        RefTypes [label="Explicit Ref Generics\n(useRef<Mesh>)ีน", fillcolor="#e0e7ff", color="#818cf8"];
    }

    subgraph cluster_r3f {
        label = "React Three Fiber Runtime Layer";
        style=filled;
        fillcolor="#ecfdf5";

        Canvas [label="R3F Canvas Context\n(WebGL Renderer & Event System)", fillcolor="#d1fae5", color="#34d399"];
        FiberHooks [label="useFrame Loop & Synthetic Events\n(onClick, onPointerOver)", fillcolor="#d1fae5", color="#34d399"];
    }

    subgraph cluster_threejs {
        label = "Three.js Imperative Layer";
        style=filled;
        fillcolor="#fff7ed";

        ThreeObjects [label="THREE.Mesh, THREE.BoxGeometry,\nTHREE.MeshStandardMaterial", fillcolor="#ffedd5", color="#fb923c"];
    }

    subgraph cluster_dom {
        label = "DOM / UI Overlay Layer";
        style=filled;
        fillcolor="#fdf4ff";

        DreiHtml [label="Drei <Html> Component\n(Tailwind SaaS Tooltips)", fillcolor="#fae8ff", color="#e879f9"];
    }

    Interfaces -> FiberHooks [label="Enforces Prop Types"];
    RefTypes -> ThreeObjects [label="Safely Typed .current"];
    Canvas -> FiberHooks [label="Tick Orchestration"];
    FiberHooks -> ThreeObjects [label="Imperative Mutation (scale/rotation)"];
    ThreeObjects -> DreiHtml [label="Spatial Anchor Coordinates"];
}
