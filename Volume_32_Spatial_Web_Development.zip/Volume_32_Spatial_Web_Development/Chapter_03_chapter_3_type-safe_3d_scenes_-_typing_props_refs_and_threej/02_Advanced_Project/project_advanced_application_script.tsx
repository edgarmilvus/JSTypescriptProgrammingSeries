/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useRef, useState, useMemo, useCallback } from 'react';
import { Canvas, useFrame, ThreeEvent } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Supported finish types for the product customizer SaaS component.
 */
export type MaterialFinish = 'matte' | 'glossy' | 'metallic';

/**
 * Configuration payload representing an item's spatial state.
 */
export interface ProductConfig {
  id: string;
  name: string;
  baseColor: string;
  finish: MaterialFinish;
  scaleFactor: number;
}

/**
 * Props for the InteractiveProductMesh component.
 */
export interface InteractiveProductMeshProps {
  config: ProductConfig;
  onSelect?: (id: string) => void;
  isHighlighted?: boolean;
}

/**
 * Custom type guard to verify if an unknown intersection event target 
 * is a valid THREE.Mesh instance.
 */
function isMeshInstance(target: unknown): target is THREE.Mesh {
  return target instanceof THREE.Mesh;
}

/**
 * R3F Component representing the interactive 3D product model.
 * Demonstrates strict prop typing, ref management, and runtime type narrowing.
 */
export const InteractiveProductMesh: React.FC<InteractiveProductMeshProps> = ({
  config,
  onSelect,
  isHighlighted = false,
}) => {
  // Explicitly type the ref to target a THREE.Group holding sub-meshes
  const groupRef = useRef<THREE.Group>(null);
  
  // Local state for interactive hover effects
  const [hovered, setHovered] = useState<boolean>(false);

  // Memoize material parameters based on configuration to avoid redundant allocations
  const materialProps = useMemo(() => {
    switch (config.finish) {
      case 'glossy':
        return { roughness: 0.1, metalness: 0.2 };
      case 'metallic':
        return { roughness: 0.2, metalness: 0.9 };
      case 'matte':
      default:
        return { roughness: 0.8, metalness: 0.1 };
    }
  }, [config.finish]);

  // Imperative animation loop utilizing the typed group ref
  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    // Gentle floating animation
    const targetY = hovered ? 0.2 : 0;
    groupRef.current.position.y = THREE.MathUtils.lerp(
      groupRef.current.position.y,
      targetY,
      delta * 5
    );

    // Subtle idle rotation
    groupRef.current.rotation.y += delta * 0.5;
  });

  /**
   * Pointer event handler utilizing type guards and narrowing.
   */
  const handlePointerDown = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    
    // Runtime type check using our custom type guard function
    if (isMeshInstance(e.object)) {
      console.log(`Interacted with specific mesh: ${e.object.uuid}`);
    }

    if (onSelect) {
      onSelect(config.id);
    }
  }, [config.id, onSelect]);

  return (
    <group 
      ref={groupRef} 
      scale={[config.scaleFactor, config.scaleFactor, config.scaleFactor]}
    >
      <mesh
        onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
        onPointerOut={() => setHovered(false)}
        onPointerDown={handlePointerDown}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[1.5, 1.5, 1.5]} />
        <meshStandardMaterial
          color={config.baseColor}
          roughness={materialProps.roughness}
          metalness={materialProps.metalness}
        />
      </mesh>

      {/* Conditional HTML overlay anchored in 3D space */}
      {isHighlighted && (
        <Html position={[0, 1.2, 0]} center>
          <div className="bg-slate-900 text-white px-3 py-1 rounded shadow-lg text-xs font-sans pointer-events-none">
            {config.name} ({config.finish})
          </div>
        </Html>
      )}
    </group>
  );
};

/**
 * Main SaaS Canvas Application Container.
 */
export default function SpatialProductCanvas() {
  const [activeConfig, setActiveConfig] = useState<ProductConfig>({
    id: 'prod-001',
    name: 'Executive Spatial Desk',
    baseColor: '#3b82f6',
    finish: 'metallic',
    scaleFactor: 1.2,
  });

  const handleProductSelect = useCallback((id: string) => {
    console.log(`Selected product SKU: ${id}`);
  }, []);

  return (
    <div className="w-full h-[600px] bg-slate-950 relative rounded-xl overflow-hidden">
      <Canvas
        camera={{ position: [0, 2, 5], fov: 50 }}
        shadows
      >
        <color attach="background" args={['#090d16']} />
        <ambientLight intensity={0.7} />
        <directionalLight 
          position={[5, 8, 5]} 
          intensity={1.5} 
          castShadow 
        />
        
        <InteractiveProductMesh
          config={activeConfig}
          onSelect={handleProductSelect}
          isHighlighted={true}
        />

        <OrbitControls 
          enablePan={true}
          enableZoom={true}
          maxPolarAngle={Math.PI / 2 - 0.05} // Prevent camera going below ground plane
        />
      </Canvas>
    </div>
  );
}
