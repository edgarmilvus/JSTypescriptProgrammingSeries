/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// 1. Define custom dimensions and callback interfaces
export interface GridDimensions {
  width: number;
  height: number;
  spacing: number;
}

export type TileClickHandler = (id: string, point: THREE.Vector3) => void;

// 2. Extend standard R3F mesh/group props using ThreeElements
export interface ModularGridProps extends Omit<React.ComponentPropsWithoutRef<'group'>, 'onClick'> {
  dimensions: GridDimensions;
  tileColor?: string;
  onTileClick?: TileClickHandler;
}

export const ModularGrid: React.FC<ModularGridProps> = ({
  dimensions,
  tileColor = '#ffffff',
  onTileClick,
  ...props
}) => {
  // 3. Type the group reference explicitly as THREE.Group
  const groupRef = useRef<THREE.Group>(null);

  // 4. Safely animate the group reference in the render loop
  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.1;
    }
  });

  const { width, height, spacing } = dimensions;
  const tiles = [];

  for (let x = 0; x < width; x++) {
    for (let z = 0; z < height; z++) {
      const id = `tile-${x}-${z}`;
      const posX = (x - width / 2) * spacing;
      const posZ = (z - height / 2) * spacing;

      tiles.push(
        <mesh
          key={id}
          position={[posX, 0, posZ]}
          onClick={(e) => {
            e.stopPropagation();
            if (onTileClick) {
              onTileClick(id, e.point);
            }
          }}
        >
          <boxGeometry args={[spacing * 0.9, 0.1, spacing * 0.9]} />
          <meshStandardMaterial color={tileColor} />
        </mesh>
      );
    }
  }

  return (
    <group ref={groupRef} {...props}>
      {tiles}
    </group>
  );
};
