/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

type CameraDirectorProps = {
  activeTarget: [number, number, number];
  easingFactor?: number;
};

export const CameraDirector: React.FC<CameraDirectorProps> = ({
  activeTarget,
  easingFactor = 0.05,
}) => {
  // 1. Obtain camera from R3F context
  const { camera } = useThree();
  
  // 2. Create a ref to store the current look-at tracking vector
  const targetVectorRef = useRef(new THREE.Vector3(0, 0, 0));
  const destinationVector = new THREE.Vector3(...activeTarget);

  useFrame(() => {
    // 3. Interpolate camera position smoothly toward the target offset
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, destinationVector.x + 5, easingFactor);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, destinationVector.y + 5, easingFactor);
    camera.position.z = THREE.MathUtils.lerp(camera.position.z, destinationVector.z + 5, easingFactor);

    // 4. Interpolate the look-at target vector
    targetVectorRef.current.lerp(destinationVector, easingFactor);
    
    // 5. Update camera orientation
    camera.lookAt(targetVectorRef.current);
  });

  return null;
};
