/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { useFrame, extend, Object3DNode } from '@react-three/fiber';
import * as THREE from 'three';

// 1. Implement the custom HolographicMaterial class extending THREE.ShaderMaterial
class HolographicMaterial extends THREE.ShaderMaterial {
  constructor() {
    super({
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: new THREE.Color('#00ffcc') },
        uGlitchIntensity: { value: 0.1 },
      },
      vertexShader: `
        uniform float uTime;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec3 pos = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uColor;
        varying vec2 vUv;
        void main() {
          gl_FragColor = vec4(uColor + sin(vUv.xyx + uTime), 1.0);
        }
      `,
    });
  }

  get uTime(): number {
    return this.uniforms.uTime.value;
  }
  set uTime(v: number) {
    this.uniforms.uTime.value = v;
  }
}

// Make the material available to R3F imperative API
extend({ HolographicMaterial });

// 2. Extend R3F elements for JSX recognition and strong typing
declare module '@react-three/fiber' {
  interface ThreeElements {
    holographicMaterial: Object3DNode<HolographicMaterial, typeof HolographicMaterial>;
  }
}

export const HolographicSphere: React.FC = () => {
  // 3. Reference the custom material instance to update uniforms per frame
  const materialRef = useRef<HolographicMaterial>(null);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uTime = state.clock.getElapsedTime();
    }
  });

  return (
    <mesh>
      <sphereGeometry args={[1, 32, 32]} />
      {/* 4. Use the custom material declaratively with full type safety */}
      <holographicMaterial ref={materialRef} />
    </mesh>
  );
};
