/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { z } from 'zod';
import { Canvas } from '@react-three/fiber';

// 1. Define the SceneConfigSchema using Zod
const SceneConfigSchema = z.object({
  environment: z.enum(['sunset', 'warehouse', 'night']),
  spotlight: z.object({
    intensity: z.number().positive(),
    color: z.string(),
    position: z.tuple([z.number(), z.number(), z.number()]),
  }),
  interactiveObjects: z.array(
    z.object({
      id: z.string(),
      modelPath: z.string(),
      scale: z.number(),
    })
  ),
});

// 2. Infer the TypeScript type automatically from the schema
type SceneConfig = z.infer<typeof SceneConfigSchema>;

interface DynamicSceneLoaderProps {
  rawData: unknown;
}

export const DynamicSceneLoader: React.FC<DynamicSceneLoaderProps> = ({ rawData }) => {
  // 3. Validate rawData using safeParse at runtime
  const validationResult = SceneConfigSchema.safeParse(rawData);

  if (!validationResult.success) {
    // 4. Handle validation failures gracefully with a fallback UI
    return (
      <div style={{ padding: '20px', background: '#ffe6e6', color: '#d9534f' }}>
        <h3>Configuration Error</h3>
        <p>The provided 3D scene configuration is invalid or malformed.</p>
        <pre>{JSON.stringify(validationResult.error.format(), null, 2)}</pre>
      </div>
    );
  }

  // Type is now fully narrowed and verified as SceneConfig
  const config: SceneConfig = validationResult.data;

  return (
    <Canvas>
      <ambientLight intensity={0.5} />
      <spotLight
        intensity={config.spotlight.intensity}
        color={config.spotlight.color}
        position={config.spotlight.position}
      />
      {config.interactiveObjects.map((obj) => (
        <mesh key={obj.id} scale={[obj.scale, obj.scale, obj.scale]}>
          <boxGeometry />
          <meshStandardMaterial />
        </mesh>
      ))}
    </Canvas>
  );
};
