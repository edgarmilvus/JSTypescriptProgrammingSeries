/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

// 1. Define base model interface
interface ProductMetadata {
  id: string;
  sku: string;
  title: string;
  price: number;
  inStock: boolean;
  tags: string[];
  description: string;
}

// 2. Derive SpatialTooltipProps using TypeScript utility types
export type SpatialTooltipProps = {
  position: [number, number, number];
  onSelect?: (id: string) => void;
} & Pick<ProductMetadata, 'id' | 'title' | 'price' | 'inStock'>;

// 3. Implement the strictly typed component
export const SpatialTooltip: React.FC<SpatialTooltipProps> = ({
  id,
  position,
  title,
  price,
  inStock,
  onSelect,
}) => {
  // Manage hover state with strict boolean typing
  const [isHovered, setIsHovered] = useState<boolean>(false);

  return (
    <group position={position}>
      <Html position={[0, 0, 0]} center>
        <div
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onClick={(e) => {
            e.stopPropagation();
            if (onSelect) {
              onSelect(id);
            }
          }}
          style={{
            background: isHovered ? '#222' : '#fff',
            color: isHovered ? '#fff' : '#222',
            padding: '8px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
          }}
        >
          <h4 style={{ margin: 0, fontSize: '14px' }}>{title}</h4>
          <p style={{ margin: '4px 0', fontSize: '12px' }}>${price.toFixed(2)}</p>
          <span style={{ fontSize: '10px', color: inStock ? 'green' : 'red' }}>
            {inStock ? 'In Stock' : 'Out of Stock'}
          </span>
        </div>
      </Html>
    </group>
  );
};
