/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

// 1. Define base model interface
interface ProductMetadata {
  id: string;
  sku: string;
  title: string;
  price: number;
  inStock: boolean;
  tags: string[];
  description: string;
}

// 2. Derive SpatialTooltipProps using TypeScript utility types
// TODO: Create SpatialTooltipProps here

// 3. Implement the component
export const SpatialTooltip: React.FC<SpatialTooltipProps> = ({
  position,
  title,
  price,
  inStock,
  onSelect,
}) => {
  // TODO: Manage hover state with strict boolean typing
  const [isHovered, setIsHovered] = useState<boolean>(false);

  return (
    <group position={position}>
      <Html position={[0, 0, 0]} center>
        <div
          // TODO: Attach typed event handlers
          style={{
            background: isHovered ? '#222' : '#fff',
            color: isHovered ? '#fff' : '#222',
            padding: '8px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
        >
          <h4>{title}</h4>
          <p>${price.toFixed(2)}</p>
          <span>{inStock ? 'In Stock' : 'Out of Stock'}</span>
        </div>
      </Html>
    </group>
  );
};
