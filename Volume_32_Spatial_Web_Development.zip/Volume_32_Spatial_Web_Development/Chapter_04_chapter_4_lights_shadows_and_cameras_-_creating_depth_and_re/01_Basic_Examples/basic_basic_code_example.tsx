/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, ContactShadows, Environment } from '@react-three/drei';
import * as THREE from 'three';

/**
 * ProductMesh Component
 * Renders the central SaaS product (a stylized smart speaker) rotating slowly.
 * Demonstrates a standard mesh receiving and casting shadows.
 */
const ProductMesh: React.FC = () => {
  const meshRef = useRef<THREE.Mesh>(null!);

  // Rotate the product slightly every frame for a dynamic presentation
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.2;
    }
  });

  return (
    <mesh ref={meshRef} castShadow receiveShadow position={[0, 1, 0]}>
      {/* Cylinder geometry acting as the main body of the product */}
      <cylinderGeometry args={[0.7, 0.7, 2, 32]} />
      {/* Standard physical material optimized for metallic/matte realism */}
      <meshStandardMaterial 
        color="#1e293b" 
        metalness={0.8} 
        roughness={0.2} 
      />
    </mesh>
  );
};

/**
 * StudioLighting Component
 * Implements an intentional three-point lighting rig paired with environment maps
 * to establish commercial-grade depth, reflections, and shadow realism.
 */
const StudioLighting: React.FC = () => {
  return (
    <>
      {/* Ambient light for global baseline illumination without directionality */}
      <ambientLight intensity={0.4} />

      {/* Key Light: The primary illumination source casting crisp shadows */}
      <directionalLight
        position={[5, 8, 5]}
        intensity={1.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.0001}
      >
        <orthographicCamera 
          attach="shadow-camera" 
          args={[-5, 5, 5, -5, 0.1, 50]} 
        />
      </directionalLight>

      {/* Fill Light: Softens harsh shadows created by the key light on the opposite side */}
      directionalLight
        position={[-5, 4, -3]}
        intensity={0.5}
        color="#94a3b8"
      />

      {/* Rim Light: Backlight that separates the product silhouette from the background */}
      <directionalLight
        position={[0, 5, -6]}
        intensity={2.0}
        color="#38bdf8"
      />

      {/* Environment map wrapper from Drei to generate realistic specular highlights */}
      <Environment preset="city" />
    </>
  );
};

/**
 * ProductScene Component
 * Assembles the stage, lighting, product, and interactive camera controls.
 */
export default function ProductScene() {
  return (
    <div className="w-full h-screen bg-slate-950">
      <Canvas
        shadows
        camera={{ position: [0, 3, 6], fov: 50 }}
        gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
      >
        {/* Studio lighting rig configuration */}
        <StudioLighting />

        {/* The interactive e-commerce product */}
        <ProductMesh />

        {/* Minimal display stage floor */}
        <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
          <planeGeometry args={[20, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={0.4} />
        </mesh>

        {/* Contact shadows for enhanced grounding realism without heavy shadow map costs */}
        <ContactShadows 
          position={[0, 0.01, 0]} 
          opacity={0.7} 
          scale={10} 
          blur={2.5} 
          far={4} 
        />

        {/* Orbital camera controls with bounded constraints */}
        <OrbitControls 
          enablePan={false} 
          minDistance={3} 
          maxDistance={10} 
          maxPolarAngle={Math.PI / 2 - 0.05} // Prevent camera from going below the floor
        />
      </Canvas>
    </div>
  );
}
