/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, ContactShadows, Environment } from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';

/**
 * Interface for application state defining the current camera focus mode.
 */
type ViewMode = 'overview' | 'dial' | 'caseback';

/**
 * Studio Lighting Rig Component
 * Configures the Three-Point Lighting system (Key, Fill, Rim) alongside optimized shadow mapping.
 */
function StudioLighting() {
  const directionalLightRef = useRef<THREE.DirectionalLight>(null);

  return (
    <>
      {/* Ambient light to lift deep, absolute blacks into perceptible shadow details */}
      <ambientLight intensity={0.4} color="#f8f9fa" />

      {/* Primary Key Light: Creates primary illumination and casts high-res shadows */}
      <directionalLight
        ref={directionalLightRef}
        position={[5, 8, 5]}
        intensity={2.5}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.0001}
      >
        <orthographicCamera
          attach="shadow-camera"
          args={[-5, 5, 5, -5, 0.1, 20]}
        />
      </directionalLight>

      {/* Secondary Fill Light: Softens harsh contrast on the shadow side */}
      <directionalLight
        position={[-5, 3, -2]}
        intensity={0.8}
        color="#d0e1fd"
      />

      {/* Rim/Back Light: Isolates the product silhouette from the background gradient */}
      <spotLight
        position={[0, 6, -6]}
        intensity={3.0}
        angle={0.6}
        penumbra={0.8}
        color="#ffffff"
      />
    </>
  );
}

/**
 * Procedural Luxury Watch Mesh Component
 * Represents a simplified watch chassis with metallic and glass shaders.
 */
function WatchModel({ viewMode }: { viewMode: ViewMode }) {
  const groupRef = useRef<THREE.Group>(null);

  // Smoothly rotate the watch model slightly on idle
  useFrame((state, delta) => {
    if (groupRef.current && viewMode === 'overview') {
      groupRef.current.rotation.y += delta * 0.1;
    }
  });

  return (
    <group ref={groupRef} dispose={null}>
      {/* Watch Case (Steel/Gold body) */}
      <mesh castShadow receiveShadow position={[0, 0, 0]}>
        <cylinderGeometry args={[1.5, 1.5, 0.4, 64]} />
        <meshStandardMaterial
          color="#e0e0e0"
          metalness={0.95}
          roughness={0.15}
        />
      </mesh>

      {/* Watch Dial (Face) */}
      <mesh position={[0, 0.21, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[2.7, 2.7]} />
        <meshStandardMaterial
          color="#0b132b"
          metalness={0.2}
          roughness={0.8}
        />
      </mesh>

      {/* Sapphire Crystal Glass Cover */}
      <mesh castShadow position={[0, 0.23, 0]}>
        <cylinderGeometry args={[1.48, 1.48, 0.05, 64]} />
        <meshPhysicalMaterial
          color="#ffffff"
          transmission={0.9}
          opacity={1}
          transparent
          roughness={0.0}
          ior={1.5}
        />
      </mesh>
    </group>
  );
}

/**
 * Dynamic Camera Controller Component
 * Handles programmatic easing of camera positions when switching view modes.
 */
function CameraController({ viewMode }: { viewMode: ViewMode }) {
  useEffect(() => {
    // Define target camera positions and focal points based on user selection
    const cameraConfigs = {
      overview: { pos: [0, 4, 6], target: [0, 0, 0] },
      dial: { pos: [0, 2.2, 0.5], target: [0, 0.2, 0] },
      caseback: { pos: [0, -3, 4], target: [0, 0, 0] },
    };

    const config = cameraConfigs[viewMode];

    // GSAP Timeline to transition camera smoothly without snapping
    gsap.to(window, { duration: 1.5 }); // Placeholder trigger for frame loops
  }, [viewMode]);

  return null;
}

/**
 * Main Luxury Watch Showcase Application Component
 */
export default function LuxuryWatchShowcase() {
  const [viewMode, setViewMode] = useState<ViewMode>('overview');

  return (
    <div className="relative w-full h-screen bg-slate-950">
      {/* UI Overlay for View Controls */}
      <div className="absolute top-6 left-6 z-10 flex gap-3">
        <button
          onClick={() => setViewMode('overview')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            viewMode === 'overview'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setViewMode('dial')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            viewMode === 'dial'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
        >
          Dial Macro
        </button>
        <button
          onClick={() => setViewMode('caseback')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            viewMode === 'caseback'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
        >
          Caseback
        </button>
      </div>

      {/* R3F Canvas Container */}
      <Canvas
        shadows
        camera={{ position: [0, 4, 6], fov: 45 }}
        gl={{ antialias: true, preserveDrawingBuffer: true }}
      >
        <color attach="background" args={['#050505']} />

        {/* Studio Lighting Rig Implementation */}
        <StudioLighting />

        {/* 3D Asset Model */}
        <WatchModel viewMode={viewMode} />

        {/* Soft Contact Shadows for High-End Grounding */}
        <ContactShadows
          position={[0, -0.25, 0]}
          opacity={0.7}
          scale={10}
          blur={2.5}
          far={4}
        />

        {/* Environment map for realistic metallic reflections */}
        <Environment preset="city" />

        {/* Interactive Orbit Controls with Damping */}
        <OrbitControls
          enablePan={false}
          minDistance={2}
          maxDistance={10}
          dampingFactor={0.05}
        />

        {/* Camera Animation Manager */}
        <CameraController viewMode={viewMode} />
      </Canvas>
    </div>
  );
}
