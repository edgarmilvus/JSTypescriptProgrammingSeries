/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function LightingRig({ keyLightPosition, keyLightIntensity }: { keyLightPosition: [number, number, number], keyLightIntensity: number }) {
  const directionalLightRef = useRef<THREE.DirectionalLight>(null);

  return (
    <>
      {/* 1. Ambient Light for baseline visibility */}
      <ambientLight color="#1e293b" intensity={0.4} />

      {/* 2. Primary Directional Key Light with shadows */}
      <directionalLight
        ref={directionalLightRef}
        position={keyLightPosition}
        intensity={keyLightIntensity}
        color="#fffbf0"
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />

      {/* 3. Colored Rim/Back Light for silhouette separation */}
      <pointLight 
        position={[-4, 3, -4]} 
        intensity={2.5} 
        color="#06b6d4" 
      />
    </>
  );
}

export default function ArtGalleryScene() {
  const [intensity, setIntensity] = React.useState(3);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      <div style={{ position: 'absolute', zIndex: 10, padding: '20px' }}>
        <label style={{ color: 'white' }}>
          Key Light Intensity: {intensity}
          <input 
            type="range" 
            min="0.5" 
            max="10" 
            step="0.1" 
            value={intensity} 
            onChange={(e) => setIntensity(parseFloat(e.target.value))} 
          />
        </label>
      </div>

      <Canvas shadows camera={{ position: [0, 5, 10], fov: 50 }}>
        <color attach="background" args={['#0f172a']} />
        <LightingRig keyLightPosition={[5, 8, 5]} keyLightIntensity={intensity} />
        
        {/* Central Pedestal & Sculpture */}
        <mesh position={[0, -1, 0]} receiveShadow>
          <boxGeometry args={[3, 0.5, 3]} />
          <meshStandardMaterial color="#334155" />
        </mesh>
        
        <mesh position={[0, 1, 0]} castShadow receiveShadow>
          <icosahedronGeometry args={[1.2, 0]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.3} metalness={0.8} />
        </mesh>

        <OrbitControls />
      </Canvas>
    </div>
  );
}
