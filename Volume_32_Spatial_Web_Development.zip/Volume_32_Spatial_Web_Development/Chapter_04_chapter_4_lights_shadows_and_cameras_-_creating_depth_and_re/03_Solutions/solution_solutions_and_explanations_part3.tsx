/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

interface CinematicCameraProps {
  targetPosition: [number, number, number];
  targetLookAt: [number, number, number];
  projectionType: 'perspective' | 'orthographic';
  duration: number; // in seconds
}

function CinematicCameraController({ targetPosition, targetLookAt, projectionType, duration }: CinematicCameraProps) {
  const { camera, set } = useThree();
  const controlsRef = useRef<any>(null);
  
  const transitionRef = useRef({
    startTime: 0,
    isAnimating: false,
    startPos: new THREE.Vector3(),
    endPos: new THREE.Vector3(..targetPosition),
    startLook: new THREE.Vector3(),
    endLook: new THREE.Vector3(..targetLookAt),
  });

  useEffect(() => {
    transitionRef.current.startTime = performance.now();
    transitionRef.current.isAnimating = true;
    transitionRef.current.startPos.copy(camera.position);
    transitionRef.current.endPos.set(...targetPosition);
    
    if (controlsRef.current) {
      transitionRef.current.startLook.copy(controlsRef.current.target);
      transitionRef.current.endLook.set(...targetLookAt);
      controlsRef.current.enabled = false; // Disable user interaction during transition
    }
  }, [targetPosition, targetLookAt, camera]);

  useFrame(() => {
    if (!transitionRef.current.isAnimating) return;

    const elapsed = (performance.now() - transitionRef.current.startTime) / (duration * 1000);
    const progress = Math.min(elapsed, 1);

    // Custom cubic-bezier ease-in-out curve
    const easeProgress = progress < 0.5 
      ? 4 * progress * progress * progress 
      : 1 - Math.pow(-2 * progress + 2, 3) / 2;

    camera.position.lerpVectors(
      transitionRef.current.startPos,
      transitionRef.current.endPos,
      easeProgress
    );

    if (controlsRef.current) {
      controlsRef.current.target.lerpVectors(
        transitionRef.current.startLook,
        transitionRef.current.endLook,
        easeProgress
      );
      controlsRef.current.update();
    }

    if (progress >= 1) {
      transitionRef.current.isAnimating = false;
      if (controlsRef.current) controlsRef.current.enabled = true;
    }
  });

  return <OrbitControls ref={controlsRef} />;
}

export default function App() {
  const [pos, setPos] = React.useState<[number, number, number]>([0, 2, 8]);
  const [look, setLook] = React.useState<[number, number, number]>([0, 0, 0]);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      <div style={{ position: 'absolute', zIndex: 10, padding: '20px', display: 'flex', gap: '10px' }}>
        <button onClick={() => { setPos([0, 2, 8]); setLook([0, 0, 0]); }}>Exhibit A</button>
        <button onClick={() => { setPos([5, 4, -5]); setLook([2, 0, 0]); }}>Exhibit B</button>
      </div>

      <Canvas camera={{ position: [0, 2, 8], fov: 50 }}>
        <color attach="background" args={['#1e1b4b']} />
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        
        <CinematicCameraController 
          targetPosition={pos} 
          targetLookAt={look} 
          projectionType="perspective" 
          duration={1.5} 
        />

        {/* Scene Meshes */}
        <mesh position={[0, 0, 0]}><boxGeometry /><meshStandardMaterial color="#6366f1" /></mesh>
        <mesh position={[2, 0, -2]}><sphereGeometry /><meshStandardMaterial color="#ec4899" /></mesh>
      </Canvas>
    </div>
  );
}
