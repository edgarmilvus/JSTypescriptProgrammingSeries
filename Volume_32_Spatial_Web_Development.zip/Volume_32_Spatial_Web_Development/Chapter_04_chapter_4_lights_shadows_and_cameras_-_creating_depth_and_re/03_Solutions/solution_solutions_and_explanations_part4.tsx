/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { EffectComposer, DepthOfField } from '@react-three/postprocessing';
import * as THREE from 'three';

function InteractiveExhibitScene() {
  const [focusDistance, setFocusDistance] = useState(5);
  const targetFocusRef = useRef(5);

  // Smoothly interpolate current focus distance toward the target value
  useFrame((_, delta) => {
    focusDistance + (targetFocusRef.current - focusDistance) * delta * 5;
  });

  const handleMeshClick = (e: any, distance: number) => {
    e.stopPropagation();
    targetFocusRef.current = distance;
  };

  return (
    <>
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 10]} intensity={1.5} />

      {/* Near Mesh */}
      <mesh position={[-2, 0, 2]} onClick={(e) => handleMeshClick(e, 3)}>
        <boxGeometry args={[1.5, 1.5, 1.5]} />
        <meshStandardMaterial color="#10b981" />
      </mesh>

      {/* Midground Mesh */}
      <mesh position={[0, 0, 0]} onClick={(e) => handleMeshClick(e, 6)}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial color="#3b82f6" />
      </mesh>

      {/* Far Mesh */}
      <mesh position={[2, 0, -4]} onClick={(e) => handleMeshClick(e, 10)}>
        <coneGeometry args={[1, 2, 32]} />
        <meshStandardMaterial color="#f59e0b" />
      </mesh>

      <EffectComposer>
        <DepthOfField
          focusDistance={focusDistance}
          focalLength={0.02}
          bokehScale={6}
          height={480}
        />
      </EffectComposer>
    </>
  );
}

export default function DepthOfFieldApp() {
  return (
    <Canvas camera={{ position: [0, 2, 10], fov: 50 }}>
      <color attach="background" args={['#020617']} />
      <InteractiveExhibitScene />
      <OrbitControls />
    </Canvas>
  );
}
