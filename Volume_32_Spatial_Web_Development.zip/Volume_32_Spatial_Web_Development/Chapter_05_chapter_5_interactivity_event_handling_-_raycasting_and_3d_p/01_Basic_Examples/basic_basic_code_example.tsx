/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing the properties for our InteractiveServerNode component.
 */
interface ServerNodeProps {
  /** The unique identifier or name of the server rack. */
  id: string;
  /** Initial operational status of the server node. */
  status: 'healthy' | 'warning' | 'critical';
}

/**
 * An interactive 3D server node component that responds to R3F pointer events.
 * Demonstrates hover state changes, color interpolation, and click-to-mutate logic.
 */
function InteractiveServerNode({ id, status: initialStatus }: ServerNodeProps) {
  // Reference to the underlying Three.js mesh for imperative transformations
  const meshRef = useRef<THREE.Mesh>(null!);

  // Local state for tracking hover and active operational status
  const [hovered, setHovered] = useState<boolean>(false);
  const [activeStatus, setActiveStatus] = useState<'healthy' | 'warning' | 'critical'>(initialStatus);

  // Smoothly rotate the node or animate it slightly on every frame
  useFrame((state, delta) => {
    if (meshRef.current) {
      // Gentle floating animation based on elapsed time
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime + parseInt(id)) * 0.1;
    }
  });

  /**
   * Determine the mesh color based on hover state and operational status.
   */
  const getMeshColor = () => {
    if (hovered) return '#60a5fa'; // Tailwind blue-400 for hover feedback
    switch (activeStatus) {
      case 'healthy': return '#34d399'; // Tailwind emerald-400
      case 'warning': return '#fbbf24'; // Tailwind amber-400
      case 'critical': return '#f87171'; // Tailwind red-400
      default: return '#9ca3af';
    }
  };

  return (
    <group>
      {/* 
        The primary 3D mesh acting as our interactive target. 
        R3F automatically intercepts pointer events on this geometry.
      */}
      <mesh
        ref={meshRef}
        // Triggered when the pointer enters the bounding geometry
        onPointerOver={(e) => {
          e.stopPropagation(); // Prevent event bubbling to underlying canvases/objects
          setHovered(true);
          document.body.style.cursor = 'pointer'; // Update DOM cursor for feedback
        }}
        // Triggered when the pointer leaves the bounding geometry
        onPointerOut={(e) => {
          setHovered(false);
          document.body.style.cursor = 'auto';
        }}
        // Triggered on primary pointer click/tap
        onClick={(e) => {
          e.stopPropagation();
          // Cycle through server statuses on click as a SaaS state mutation simulation
          setActiveStatus((prev) => {
            if (prev === 'healthy') return 'warning';
            if (prev === 'warning') return 'critical';
            return 'healthy';
          });
          console.log(`Server Node ${id} status toggled.`);
        }}
      >
        <boxGeometry args={[1.5, 2, 0.5]} />
        <meshStandardMaterial 
          color={getMeshColor()} 
          roughness={0.3}
          metalness={0.8}
        />
      </mesh>

      {/* Floating text label anchored above the mesh */}
      <Text
        position={[0, 1.3, 0]}
        fontSize={0.2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`Server: ${id}\n[${activeStatus.toUpperCase()}]`}
      </Text>
    </group>
  );
}

/**
 * Main application component setting up the WebGL Canvas and scene lighting.
 */
export default function SpatialSaaSApp() {
  return (
    <div className="w-full h-screen bg-slate-950">
      <Canvas camera={{ position: [0, 0, 5], fov: 60 }}>
        <color attach="background" args={['#020617']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.5} />
        
        {/* Render our interactive server node */}
        <InteractiveServerNode id="SRV-01" status="healthy" />

        <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
      </Canvas>
    </div>
  );
}
