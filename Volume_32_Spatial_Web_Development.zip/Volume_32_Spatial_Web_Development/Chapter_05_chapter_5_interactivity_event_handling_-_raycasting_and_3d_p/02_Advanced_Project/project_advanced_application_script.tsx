/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useRef, Suspense } from 'vivid';
import { Canvas, useFrame, ThreeEvent } from '@react-three/fiber';
import { OrbitControls, Html, MeshReflectorMaterial, Environment } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing metadata for configurable product components.
 */
interface ProductPart {
  id: string;
  name: string;
  color: string;
  priceDelta: number;
}

/**
 * Props for the interactive configurable mesh component.
 */
interface ConfigurableMeshProps {
  part: ProductPart;
  position: [number, number, number];
  isExploded: boolean;
  onSelectPart: (part: ProductPart) => void;
}

/**
 * Individual 3D mesh component handling R3F pointer events, hover states, 
 * and animated target positioning during exploded-view transformations.
 */
function ConfigurableMesh({
  part,
  position,
  isExploded,
  onSelectPart,
}: ConfigurableMeshProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [active, setActive] = useState(false);

  // Calculate target positions for standard vs exploded states
  const targetX = position[0] * (isExploded ? 1.5 : 1);
  const targetY = position[1] * (isExploded ? 1.8 : 1);
  const targetZ = position[2] * (isExploded ? 1.5 : 1);

  // Non-blocking frame loop for smooth interpolation (Lerp) of positions and scales
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smoothly interpolate position towards target vector
    meshRef.current.position.x = THREE.MathUtils.lerp(meshRef.current.position.x, targetX, delta * 8);
    meshRef.current.position.y = THREE.MathUtils.lerp(meshRef.current.position.y, targetY, delta * 8);
    meshRef.current.position.z = THREE.MathUtils.lerp(meshRef.current.position.z, targetZ, delta * 8);

    // Subtle floating animation when hovered
    if (hovered) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  /**
   * Pointer over event handler. Triggers UI highlights and cursor changes.
   */
  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation(); // Prevent event bubbling to background planes
    setHovered(true);
    document.body.style.cursor = 'pointer';
  };

  /**
   * Pointer out event handler. Resets hover states and default cursor.
   */
  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(false);
    document.body.style.cursor = 'auto';
  };

  /**
   * Pointer down (click/tap) handler. Triggers parent selection state.
   */
  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setActive(!active);
    onSelectPart(part);
  };

  return (
    <mesh
      ref={meshRef}
      position={position}
      onPointerOver={handlePointerOver}
      onPointerOut={handlePointerOut}
      onPointerDown={handlePointerDown}
    >
      <boxGeometry args={[1.2, 1.2, 1.2]} />
      <meshStandardMaterial
        color={hovered ? '#3b82f6' : part.color}
        roughness={0.3}
        metalness={0.8}
        emissive={active ? '#1e40af' : '#000000'}
      />
      {hovered && (
        <Html position={[0, 1.5, 0]} center>
          <div className="px-2 py-1 bg-slate-900 text-white text-xs rounded shadow-lg pointer-events-none whitespace-nowrap">
            {part.name} (+${part.priceDelta})
          </div>
        </Html>
      )}
    </mesh>
  );
}

/**
 * Main SaaS Product Configurator Scene Component.
 */
export default function ProductConfiguratorScene() {
  const [isExploded, setIsExploded] = useState(false);
  const [selectedPart, setSelectedPart] = useState<ProductPart | null>(null);

  const parts: ProductPart[] = [
    { id: 'base', name: 'Aluminium Base', color: '#64748b', priceDelta: 0 },
    { id: 'seat', name: 'Ergonomic Cushion', color: '#0f172a', priceDelta: 150 },
    { id: 'backrest', name: 'Mesh Backrest', color: '#334155', priceDelta: 120 },
  ];

  return (
    <div className="w-full h-screen relative bg-slate-950">
      {/* SaaS Overlay UI Controls */}
      <div className="absolute top-6 left-6 z-10 flex flex-col gap-4 p-6 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl shadow-2xl max-w-sm">
        <h1 className="text-xl font-bold text-white tracking-tight">Apex Ergonomic Chair</h1>
        <p className="text-sm text-slate-400">
          Click any component to customize. Use the toggle below to inspect internal engineering.
        </p>

        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <span className="text-sm font-medium text-slate-300">Exploded View</span>
          <button
            onClick={() => setIsExploded(!isExploded)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-lg transition-colors shadow-lg shadow-blue-600/20"
          >
            {isExploded ? 'Collapse' : 'Expand'}
          </button>
        </div>

        {selectedPart && (
          <div className="mt-4 p-4 bg-slate-800/50 rounded-lg border border-slate-700/50">
            <span className="text-xs text-blue-400 font-semibold uppercase tracking-wider">Selected Component</span>
            <h3 className="text-base font-bold text-white mt-1">{selectedPart.name}</h3>
            <p className="text-xs text-slate-400 mt-0.5">Price Impact: +${selectedPart.priceDelta}</p>
          </div>
        )}
      </div>

      {/* R3F Canvas with Raycasting and Event Handling */}
      <Canvas
        camera={{ position: [4, 3, 5], fov: 50 }}
        raycaster={{ computeOffsets: (e) => ({ offsetX: e.clientX, offsetY: e.clientY }) }}
      >
        <color attach="background" args={['#020617']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />
        
        <Suspense fallback={null}>
          <group position={[0, 0, 0]}>
            <ConfigurableMesh
              part={parts[0]}
              position={[0, -1, 0]}
              isExploded={isExploded}
              onSelectPart={setSelectedPart}
            />
            <ConfigurableMesh
              part={parts[1]}
              position={[0, 0.2, 0]}
              isExploded={isExploded}
              onSelectPart={setSelectedPart}
            />
            <ConfigurableMesh
              part={parts[2]}
              position={[0, 1.4, -0.3]}
              isExploded={isExploded}
              onSelectPart={setSelectedPart}
            />
          </group>
          
          {/* Reflective Studio Floor */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
            <planeGeometry args={[50, 50]} />
            <MeshReflectorMaterial
              blur={[300, 100]}
              resolution={1024}
              mirror={0.5}
              mixBlur={1}
              mixStrength={40}
              roughness={1}
              depthScale={1.2}
              minDepthThreshold={0.4}
              maxDepthThreshold={1.4}
              color="#050505"
              metalness={0.5}
            />
          </mesh>
          <Environment preset="city" />
        </Suspense>

        <OrbitControls enablePan={false} maxPolarAngle={Math.PI / 2 - 0.05} />
      </Canvas>
    </div>
  );
}
