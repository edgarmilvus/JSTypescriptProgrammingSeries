/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

interface ProductCardProps {
  baseScale?: [number, number, number];
  productId: string;
}

interface CardState {
  scale: [number, number, number];
  emissiveIntensity: number;
}

export function ProductCard({ baseScale = [1, 1, 1], productId }: ProductCardProps) {
  // 1. Immutable state configuration
  const [cardState, setCardState] = useState<CardState>({
    scale: baseScale,
    emissiveIntensity: 0.1,
  });

  // 2. Memoized hover states to prevent unnecessary inline allocations
  const defaultState = useMemo<CardState>(() => ({
    scale: baseScale,
    emissiveIntensity: 0.1,
  }), [baseScale]);

  const hoveredState = useMemo<CardState>(() => ({
    scale: [baseScale[0] * 1.1, baseScale[1] * 1.1, baseScale[2] * 1.1],
    emissiveIntensity: 0.8,
  }), [baseScale]);

  // 3. Event handlers using immutable updates
  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation(); // Prevent propagation bubbling
    setCardState({ ...hoveredState });
  };

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setCardState({ ...defaultState });
  };

  return (
    <group>
      {/* Main Card Mesh */}
      <mesh
        scale={cardState.scale}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
      >
        <boxGeometry args={[2, 3, 0.2]} />
        <meshStandardMaterial 
          color="#2b2b2b" 
          emissive="#4f46e5" 
          emissiveIntensity={cardState.emissiveIntensity} 
        />
      </mesh>

      {/* Interactive Sub-Mesh (e.g., Badge) demonstrating isolated state */}
      <SubMeshBadge productId={productId} />
    </group>
  );
}

// Sub-component for independent child sub-mesh isolation
interface SubMeshBadgeProps {
  productId: string;
}

function SubMeshBadge({ productId }: SubMeshBadgeProps) {
  const [badgeHovered, setBadgeHovered] = useState(false);

  const badgeScale: [number, number, number] = badgeHovered ? [1.2, 1.2, 1.2] : [1, 1, 1];

  return (
    <mesh 
      position={[0, 1.2, 0.15]} 
      scale={badgeScale}
      onPointerOver={(e) => {
        e.stopPropagation();
        setBadgeHovered(true);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setBadgeHovered(false);
      }}
    >
      <sphereGeometry args={[0.3, 16, 16]} />
      <meshStandardMaterial color={badgeHovered ? "#10b981" : "#6b7280"} />
    </mesh>
  );
}
