/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useXR, Interactive } from '@react-three/xr';
import * as THREE from 'three';

export function XRControllerRaycaster() {
  const { controllers } = useXR();
  const lineRef = useRef<THREE.Line>(null);
  const [intersectionPoint, setIntersectionPoint] = useState<THREE.Vector3>(new THREE.Vector3(0, 0, -5));

  // Temporary vectors and raycaster for spatial intersection math
  const raycaster = useRef(new THREE.Raycaster());
  const tempMatrix = useRef(new THREE.Matrix4());

  useFrame((state, delta) => {
    // Check if controllers are active
    if (!controllers || controllers.length === 0) return;

    // Use the first available controller (e.g., right controller or primary ray origin)
    const controller = controllers[0]?.controller;
    if (!controller) return;

    // Extract controller world position and orientation matrix
    tempMatrix.current.identity().extractRotation(controller.matrixWorld);
    
    const rayOrigin = new THREE.Vector3();
    const rayDirection = new THREE.Vector3(0, 0, -1);

    rayOrigin.setFromMatrixPosition(controller.matrixWorld);
    rayDirection.applyMatrix4(tempMatrix.current).normalize();

    raycaster.current.set(rayOrigin, rayDirection);

    // Perform intersection tests against scene objects tagged as interactive
    // (Assumes a group or collection of objects exists in scene)
    const sceneChildren = state.scene.children;
    const intersects = raycaster.current.intersectObjects(sceneChildren, true);

    if (intersects.length > 0 && intersects[0].point) {
      setIntersectionPoint(intersects[0].point);
      
      // Update line geometry dynamically to intersection point
      if (lineRef.current) {
        const positions = lineRef.current.geometry.attributes.position;
        positions.setXYZ(1, intersects[0].point.x, intersects[0].point.y, intersects[0].point.z);
        positions.needsUpdate = true;
      }
    }
  });

  return (
    <group>
      {/* Dynamic Laser Line Visualizer */}
      <line ref={lineRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([0, 0, 0, 0, 0, -5]), 3]}
          />
        </bufferGeometry>
        <lineBasicMaterial color="red" linewidth={3} />
      </line>
    </group>
  );
}
