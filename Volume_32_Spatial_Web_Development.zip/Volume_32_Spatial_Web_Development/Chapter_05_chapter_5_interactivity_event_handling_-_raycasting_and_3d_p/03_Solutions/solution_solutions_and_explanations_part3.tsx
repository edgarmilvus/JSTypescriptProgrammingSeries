/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState, useEffect, useRef } from 'react';
import { ThreeEvent, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface AssetData {
  id: string;
  position: [number, number, number];
  color: string;
}

const STORAGE_KEY = 'spatial_scene_graph_v1';

export function DraggableAssetManager() {
  const [assets, setAssets] = useState<AssetData[]>([]);

  // Hydrate initial graph state from checkpointer storage on mount
  useEffect(() => {
    const savedGraph = localStorage.getItem(STORAGE_KEY);
    if (savedGraph) {
      try {
        const parsed: AssetData[] = JSON.parse(savedGraph);
        setAssets(parsed);
      } catch (e) {
        console.error('Failed to parse graph state hydration', e);
      }
    } else {
      // Default initial scene state if storage is empty
      setAssets([
        { id: 'chair-1', position: [0, 0, 0], color: '#3b82f6' }
      ]);
    }
  }, []);

  // Save graph state back to storage
  const persistGraphState = (updatedAssets: AssetData[]) => {
    setAssets(updatedAssets);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedAssets));
  };

  return (
    <group>
      {assets.map((asset) => (
        <DraggableAsset
          key={asset.id}
          id={asset.id}
          initialPosition={asset.position}
          color={asset.color}
          onDragComplete={(newPos) => {
            const updated = assets.map((a) => 
              a.id === asset.id ? { ...a, position: newPos } : a
            );
            persistGraphState(updated);
          }}
        />
      ))}
    </group>
  );
}

interface DraggableAssetProps {
  id: string;
  initialPosition: [number, number, number];
  color: string;
  onDragComplete: (pos: [number, number, number]) => void;
}

function DraggableAsset({ initialPosition, color, onDragComplete }: DraggableAssetProps) {
  const [position, setPosition] = useState<[number, number, number]>(initialPosition);
  const [isDragging, setIsDragging] = useState(false);
  const { camera, raycaster, pointer } = useThree();
  const planeRef = useRef(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0));

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setIsDragging(true);
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    if (!isDragging) return;
    e.stopPropagation();

    // Raycast against ground plane to compute new 3D world coordinates
    raycaster.setFromCamera(pointer, camera);
    const targetVector = new THREE.Vector3();
    raycaster.ray.intersectPlane(planeRef.current, targetVector);

    setPosition([targetVector.x, initialPosition[1], targetVector.z]);
  };

  const handlePointerUp = (e: ThreeEvent<PointerEvent>) => {
    if (!isDragging) return;
    e.stopPropagation();
    setIsDragging(false);
    onDragComplete(position);
  };

  return (
    <mesh
      position={position}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={isDragging ? '#ef4444' : color} />
    </mesh>
  );
}
