/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useMemo } from 'react';
import { ThreeEvent, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface OptimizedMeshWrapperProps {
  geometry: THREE.BufferGeometry;
  material: THREE.Material;
  maxDistance?: number;
}

export function OptimizedMeshWrapper({ geometry, material, maxDistance = 15 }: OptimizedMeshWrapperProps) {
  const groupRef = useRef<THREE.Group>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  // 1. Compute and cache Bounding Box upon initial load
  const boundingBox = useMemo(() => {
    geometry.computeBoundingBox();
    return geometry.boundingBox ? geometry.boundingBox.clone() : new THREE.Box3();
  }, [geometry]);

  const boxHelperGeometry = useMemo(() => {
    return new THREE.BoxHelper(new THREE.Mesh(geometry, material));
  }, [geometry, material]);

  // 2. Distance culling check inside useFrame loop
  useFrame(({ camera }) => {
    if (!groupRef.current) return;
    const distance = groupRef.current.position.distanceTo(camera.position);
    
    // If beyond max distance, disable interaction logic
    if (distance > maxDistance && isHovered) {
      setIsHovered(false);
    }
  });

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    
    // 3. Coarse bounding box test before detailed evaluation
    const ray = e.ray;
    const intersectsBox = ray.intersectsBox(boundingBox);

    if (!intersectsBox) {
      if (isHovered) setIsHovered(false);
      return;
    }

    // 4. Detailed intersection confirmed within bounding box bounds
    if (!isHovered) {
      setIsHovered(true);
    }
  };

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setIsHovered(false);
  };

  return (
    <group 
      ref={groupRef}
      onPointerMove={handlePointerMove}
      onPointerOut={handlePointerOut}
    >
      <mesh geometry={geometry} material={material} />

      {/* 5. Visual Wireframe Bounding Box rendered exclusively on hover */}
      {isHovered && (
        <primitive object={boxHelperGeometry} />
      )}
    </group>
  );
}
