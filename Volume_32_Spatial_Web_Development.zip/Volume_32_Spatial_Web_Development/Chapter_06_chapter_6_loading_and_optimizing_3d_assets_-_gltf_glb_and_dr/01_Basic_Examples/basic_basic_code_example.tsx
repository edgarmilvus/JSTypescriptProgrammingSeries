/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF, Center } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing the properties for our 3D Product Viewer component.
 */
interface ProductModelProps {
  /** The public URL pointing to the Draco-compressed GLB asset */
  modelUrl: string;
}

/**
 * Sub-component responsible for loading, parsing, and rendering the GLTF asset.
 * Utilizing `useGLTF` with built-in Draco support via Drei.
 */
function ProductModel({ modelUrl }: ProductModelProps) {
  // useGLTF automatically handles asynchronous loading, caching, and Draco decoding
  // The second argument enables the built-in CDN-based Draco decoder
  const { scene } = useGLTF(modelUrl, 'https://www.gstatic.com/draco/versioned/decoders/1.5.6/');

  // Traverse the scene graph to ensure all meshes cast and receive shadows for realistic rendering
  React.useEffect(() => {
    scene.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });
  }, [scene]);

  // Center the model dynamically regardless of its original coordinate origin
  return (
    <Center>
      <primitive object={scene} />
    </Center>
  );
}

// Preload the asset to eliminate runtime loading stutters upon navigation
useGLTF.preload('https://example.com/assets/3d/optimized-product.glb', 'https://www.gstatic.com/draco/versioned/decoders/1.5.6/');

/**
 * Main SaaS Spatial Dashboard Canvas Component
 */
export default function SaaSProductViewer() {
  const assetUrl = 'https://example.com/assets/3d/optimized-product.glb';

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#111' }}>
      <Canvas
        camera={{ position: [0, 2, 5], fov: 50 }}
        shadows
        gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
      >
        {/* Ambient light to ensure dark areas are not completely pitch black */}
        <ambientLight intensity={0.7} />
        
        {/* Directional light to simulate studio sun/overhead lighting and generate shadows */}
        <directionalLight
          position={[5, 8, 5]}
          intensity={1.5}
          castShadow
          shadow-mapSize={[1024, 1024]}
        />

        {/* Suspense fallback required because useGLTF suspends React rendering while loading */}
        <Suspense fallback={null}>
          <ProductModel modelUrl={assetUrl} />
        </Suspense>

        {/* Orbit controls allow the user to rotate, pan, and zoom around the product */}
        <OrbitControls enablePan={true} enableZoom={true} maxPolarAngle={Math.PI / 2} />
      </Canvas>
    </div>
  );
}
