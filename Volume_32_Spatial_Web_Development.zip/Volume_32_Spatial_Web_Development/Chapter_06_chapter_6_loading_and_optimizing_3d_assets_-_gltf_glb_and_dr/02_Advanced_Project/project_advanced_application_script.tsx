/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, useGLTF, Center, Html } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface defining the properties for our optimized 3D model component.
 */
interface OptimizedAssetProps {
  /** The public URL to the Draco-compressed GLB asset. */
  url: string;
  /** Scale factor to normalize the model within the scene. */
  scale?: number;
  /** Position vector [x, y, z]. */
  position?: [number, number, number];
}

/**
 * Individual Model Component that loads a Draco-compressed GLTF/GLB asset.
 * Utilizing useGLTF with a CDN-hosted Draco decoder path ensures efficient client-side decoding.
 */
function DracoModel({ url, scale = 1, position = [0, 0, 0] }: OptimizedAssetProps) {
  // useGLTF automatically handles caching and Draco decoding via the specified decoder path.
  // The second argument points to the decoder libraries (typically hosted on a public CDN like unpkg or cdnjs).
  const { scene } = useGLTF(url, 'https://www.gstatic.com/draco/versioned/decoders/1.5.6/');

  // Reference for subtle animation loop to verify render performance
  const modelRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (modelRef.current) {
      // Gentle floating rotation to demonstrate active render loop
      modelRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
    }
  });

  return (
    <group ref={modelRef} position={position}>
      <Center>
        {/* Clone the scene safely to prevent mutating the cached asset if rendered multiple times */}
        <primitive object={scene.clone()} scale={scale} />
      </Center>
    </group>
  );
}

/**
 * Fallback UI component rendered within the Suspense boundary while the 3D asset downloads and decodes.
 */
function LoadingSpinner() {
  return (
    <Html center>
      <div className="flex flex-col items-center justify-center space-y-3 bg-slate-900/80 backdrop-blur-md p-6 rounded-xl border border-slate-700 text-white shadow-2xl">
        <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-medium tracking-wide">Optimizing & Loading 3D Asset...</p>
      </div>
    </Html>
  );
}

/**
 * Main Spatial Viewer Scene composing lights, controls, and the compressed asset.
 */
function SpatialScene() {
  return (
    <>
      {/* Studio Lighting Setup */}
      <ambientLight intensity={0.7} />
      <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />

      {/* Suspense Boundary catches the asynchronous useGLTF promise */}
      <Suspense fallback={<LoadingSpinner />}>
        <DracoModel 
          url="https://modelviewer.dev/shared-assets/models/Astronaut.glb" 
          scale={2} 
          position={[0, -1, 0]} 
        />
      </Suspense>

      {/* Interactive Camera Controls */}
      <OrbitControls 
        enablePan={true} 
        enableZoom={true} 
        maxPolarAngle={Math.PI / 2 + 0.1} // Prevent going too far below ground plane
        minDistance={2} 
        maxDistance={20} 
      />
      
      {/* Subtle grid floor for spatial orientation */}
      <gridHelper args={[20, 20, 0x4f46e5, 0x334155]} position={[0, -1.5, 0]} />
    </>
  );
}

/**
 * Top-Level Next.js Page Component rendering the Canvas viewport.
 */
export default function SpatialAppPage() {
  return (
    <main className="w-full h-screen bg-slate-950 relative overflow-hidden flex flex-col">
      {/* SaaS Dashboard Header Overlay */}
      <header className="absolute top-0 left-0 w-full z-10 p-6 flex justify-between items-center pointer-events-none">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">Spatial Web Studio</h1>
          <p className="text-xs text-slate-400">Draco Compression & GLTF Streaming Engine</p>
        </div>
        <div className="pointer-events-auto bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-lg transition-all">
          Export Asset
        </div>
      </header>

      {/* R3F Canvas Viewport */}
      <div className="w-full h-full flex-1">
        <Canvas
          camera={{ position: [0, 2, 5], fov: 50 }}
          gl={{ antialias: true, powerPreference: 'high-performance' }}
        >
          <SpatialScene />
        </Canvas>
      </div>
    </main>
  );
}
