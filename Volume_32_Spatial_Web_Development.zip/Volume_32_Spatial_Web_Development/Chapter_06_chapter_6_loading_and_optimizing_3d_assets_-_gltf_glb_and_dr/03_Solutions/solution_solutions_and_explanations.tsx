/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { Suspense, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGLTF, OrbitControls, Html } from '@react-three/drei';

interface ModelProps {
  path: string;
}

function Model({ path }: ModelProps) {
  const { scene } = useGLTF(path);
  return <primitive object={scene} />;
}

// Preload multiple assets to optimize initial loading experience
useGLTF.preload('/models/model-a.glb');
useGLTF.preload('/models/model-b.glb');
useGLTF.preload('/models/model-c.glb');

// Custom 3D or HTML loading indicator for Suspense fallback
function LoadingFallback() {
  return (
    <Html center>
      <div style={{ color: 'white', background: 'rgba(0,0,0,0.8)', padding: '12px 24px', borderRadius: '8px', fontFamily: 'sans-serif' }}>
        Loading 3D Asset...
      </div>
    </Html>
  );
}

export function OptimizedModelViewer() {
  const models = [
    { name: 'Model A', path: '/models/model-a.glb' },
    { name: 'Model B', path: '/models/model-b.glb' },
    { name: 'Model C', path: '/models/model-c.glb' },
  ];

  const [currentModel, setCurrentModel] = useState(models[0].path);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', background: '#111' }}>
      {/* UI Overlay for Model Switching */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10, display: 'flex', gap: '10px' }}>
        {models.map((m) => (
          <button
            key={m.path}
            onClick={() => setCurrentModel(m.path)}
            style={{
              padding: '8px 16px',
              background: currentModel === m.path ? '#007acc' : '#333',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            {m.name}
          </button>
        ))}
      </div>

      <Canvas camera={{ position: [0, 2, 5] }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 10, 5]} intensity={1.5} />
        <Suspense fallback={<LoadingFallback />}>
          <Model path={currentModel} />
        </Suspense>
        <OrbitControls enableDamping />
      </Canvas>
    </div>
  );
}
