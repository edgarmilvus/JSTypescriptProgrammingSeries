/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGLTF, OrbitControls } from '@react-three/drei';

// Configure the global Draco decoder path to point to a reliable CDN
useGLTF.setDecoderPath('https://www.gstatic.com/triangles/draco/decoders/');

interface DracoModelProps {
  path: string;
  onLoadComplete: (duration: number) => void;
}

function DracoModelContent({ path, onLoadComplete }: DracoModelProps) {
  useEffect(() => {
    const startTime = performance.now();
    return () => {
      const duration = performance.now() - startTime;
      onLoadComplete(duration);
    };
  }, [path, onLoadComplete]);

  const { scene } = useGLTF(path);
  return <primitive object={scene} />;
}

export function DracoBenchmarkViewer() {
  const [useCompressed, setUseCompressed] = useState(true);
  const [loadTime, setLoadTime] = useState<number | null>(null);

  const modelPath = useCompressed ? '/models/statue-draco.glb' : '/models/statue-raw.glb';

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      {/* HUD Telemetry Overlay */}
      <div style={{ position: 'absolute', top: 20, right: 20, zIndex: 10, background: 'rgba(0,0,0,0.7)', color: '#fff', padding: '15px', borderRadius: '8px' }}>
        <h4>Draco Performance Benchmark</h4>
        <p>Mode: {useCompressed ? 'Draco Compressed' : 'Uncompressed Raw'}</p>
        <p>Mount/Parse Time: {loadTime ? `${loadTime.toFixed(2)} ms` : 'Measuring...'}</p>
        <button onClick={() => setUseCompressed(!useCompressed)} style={{ marginTop: '10px', padding: '6px 12px' }}>
          Toggle Compression
        </button>
      </div>

      <Canvas camera={{ position: [0, 1, 3] }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        <React.Suspense fallback={null}>
          <DracoModelContent path={modelPath} onLoadComplete={setLoadTime} />
        </React.Suspense>
        <OrbitControls />
      </Canvas>
    </div>
  );
}
