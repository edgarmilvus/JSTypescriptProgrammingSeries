/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useGLTF, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

interface AdaptiveLODModelProps {
  highPath: string;
  medPath: string;
  lowPath: string;
  onLevelChange?: (level: 'high' | 'med' | 'low') => void;
}

function LODController({ highPath, medPath, lowPath, onLevelChange }: AdaptiveLODModelProps) {
  const high = useGLTF(highPath);
  const med = useGLTF(medPath);
  const low = useGLTF(lowPath);

  const [activeLevel, setActiveLevel] = useState<'high' | 'med' | 'low'>('high');
  const groupRef = React.useRef<THREE.Group>(null);

  useFrame(({ camera }) => {
    if (!groupRef.current) return;
    const distance = groupRef.current.position.distanceTo(camera.position);

    let newLevel: 'high' | 'med' | 'low' = 'high';
    if (distance > 20) {
      newLevel = 'low';
    } else if (distance > 10) {
      newLevel = 'med';
    }

    if (newLevel !== activeLevel) {
      setActiveLevel(newLevel);
      if (onLevelChange) onLevelChange(newLevel);
    }
  });

  return (
    <group ref={groupRef}>
      {activeLevel === 'high' && <primitive object={high.scene} />}
      {activeLevel === 'med' && <primitive object={med.scene} />}
      {activeLevel === 'low' && <primitive object={low.scene} />}
    </group>
  );
}

export function LODSceneContainer() {
  const [currentLOD, setCurrentLOD] = useState('high');

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10, color: '#fff', background: 'rgba(0,0,0,0.6)', padding: '10px' }}>
        Active LOD State: <strong>{currentLOD.toUpperCase()}</strong>
      </div>
      <Canvas camera={{ position: [0, 0, 25] }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 10]} />
        <React.Suspense fallback={null}>
          <LODController
            highPath="/models/tree-high.glb"
            medPath="/models/tree-med.glb"
            lowPath="/models/tree-low.glb"
            onLevelChange={setCurrentLOD}
          />
        </React.Suspense>
        <OrbitControls maxDistance={40} />
      </Canvas>
    </div>
  );
}
