/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo, useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { Instances, Instance, useGLTF } from '@react-three/drei';
import * as THREE from 'three';

interface InstancedForestProps {
  modelPath: string;
  count: number;
}

export function InstancedForest({ modelPath, count }: InstancedForestProps) {
  const { nodes } = useGLTF(modelPath);
  
  // Extract the primary mesh geometry and material from the loaded GLTF nodes
  const meshNode = useMemo(() => {
    const key = Object.keys(nodes).find((k) => (nodes[k] as THREE.Mesh).isMesh);
    return key ? (nodes[key] as THREE.Mesh) : null;
  }, [nodes]);

  // Generate random transform data for all instances
  const data = useMemo(() => {
    const items = [];
    for (let i = 0; i < count; i++) {
      items.push({
        position: [
          (Math.random() - 0.5) * 50,
          0,
          (Math.random() - 0.5) * 50,
        ] as [number, number, number],
        rotation: [0, Math.random() * Math.PI * 2, 0] as [number, number, number],
        scale: [1 + Math.random() * 0.5, 1 + Math.random() * 1.5, 1 + Math.random() * 0.5] as [number, number, number],
      });
    }
    return items;
  }, [count]);

  const instanceRefs = useRef<any[]>([]);

  const handlePointerDown = (index: number, e: any) => {
    e.stopPropagation();
    // Dynamically update individual instance color without re-rendering the React tree
    if (instanceRefs.current[index]) {
      instanceRefs.current[index].color.set('#ff4757');
    }
  };

  if (!meshNode) return null;

  return (
    <Instances limit={count} range={count} geometry={meshNode.geometry} material={meshNode.material}>
      {data.map((props, index) => (
        <Instance
          key={index}
          ref={(el) => (instanceRefs.current[index] = el)}
          position={props.position}
          rotation={props.rotation}
          scale={props.scale}
          onPointerDown={(e) => handlePointerDown(index, e)}
        />
      ))}
    </Instances>
  );
}

export function InstancedSceneViewer() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#222' }}>
      <Canvas camera={{ position: [0, 15, 30] }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[10, 20, 10]} intensity={1.2} />
        <React.Suspense fallback={null}>
          <InstancedForest modelPath="/models/rock.glb" count={1500} />
        </React.Suspense>
        <OrbitControls />
      </Canvas>
    </div>
  );
}
