/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// TODO: Implement the InstancedEnvironment component using Drei's Instances and Instance abstractions.
import React, { useMemo } from 'react';
import { Instances, Instance, useGLTF } from '@react-three/drei';
import * as THREE from 'three';

interface InstancedEnvironmentProps {
  modelPath: string;
  count: number;
}

export function InstancedEnvironment({ modelPath, count }: InstancedEnvironmentProps) {
  const { nodes } = useGLTF(modelPath);
  // Extract geometry and material from nodes
  
  // Generate random or grid-based transform data for 'count' items
  const items = useMemo(() => {
    // Generate array of positions/rotations
    return [];
  }, [count]);

  return (
    <Instances limit={count} range={count}>
      {/* Attach geometry and material here */}
      {items.map((item, index) => (
        <Instance 
          key={index} 
          position={item.position} 
          rotation={item.rotation} 
          scale={item.scale} 
        />
      ))}
    </Instances>
  );
}
