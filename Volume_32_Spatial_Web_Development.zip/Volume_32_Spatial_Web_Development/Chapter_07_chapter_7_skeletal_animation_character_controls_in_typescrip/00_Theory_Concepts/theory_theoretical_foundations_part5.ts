/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.ts
// Description: Theoretical Foundations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", color="#64748b"];

    "State Input (Keyboard/Mouse)" -> "Animation State Machine" [label="Triggers State Change"];
    "Animation State Machine" -> "Action A (Walk)" [label="Weight: 1.0 -> 0.0"];
    "Animation State Machine" -> "Action B (Run)" [label="Weight: 0.0 -> 1.0"];
    "Action A (Walk)" -> "THREE.AnimationMixer" [label="Blends Transforms"];
    "Action B (Run)" -> "THREE.AnimationMixer" [label="Blends Transforms"];
    "THREE.AnimationMixer" -> "SkinnedMesh Updates" [label="Applied to Skeleton Every Frame"];
}
