/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useGLTF, useAnimations } from '@react-three/drei';
import * as THREE from 'three';
import { z } from 'zod';

/**
 * ---------------------------------------------------------------------------
 * ZOD SCHEMA & TYPESCRIPT INFERENCE
 * ---------------------------------------------------------------------------
 * We define a runtime validation schema for our avatar configuration payload.
 * This guarantees that data fetched from our SaaS backend matches the expected
 * animation states before handing it over to Three.js and React Three Fiber.
 */
const AvatarConfigSchema = z.object({
  modelUrl: z.string().url(),
  defaultAnimation: z.enum(['Idle', 'Walk', 'Run', 'Jump']),
  scale: z.number().positive().default(1),
  animationSpeed: z.number().min(0.1).max(5.0).default(1.0),
});

// Infer the static TypeScript type directly from the Zod schema
type AvatarConfig = z.infer<typeof AvatarConfigSchema>;

/**
 * ---------------------------------------------------------------------------
 * TYPE GUARDS & UTILITY TYPES
 * ---------------------------------------------------------------------------
 * User-defined type guard to verify if a given string is a valid animation key
 * within our strict union type, allowing TypeScript to narrow down scopes safely.
 */
type ValidAnimationAction = 'Idle' | 'Walk' | 'Run' | 'Jump';

function isValidAnimation(action: string): action is ValidAnimationAction {
  return ['Idle', 'Walk', 'Run', 'Jump'].includes(action);
}

/**
 * Utility Type example: Make all configuration properties optional for 
 * patch updates coming from user settings panels in our SaaS dashboard.
 */
type PartialAvatarConfig = Partial<AvatarConfig>;

/**
 * ---------------------------------------------------------------------------
 * REACT THREE FIBER COMPONENT: ANIMATED CHARACTER
 * ---------------------------------------------------------------------------
 */
interface CharacterProps {
  config: AvatarConfig;
  currentAction: ValidAnimationAction;
}

function CharacterModel({ config, currentAction }: CharacterProps) {
  // Reference to the root group of the loaded GLTF model
  const groupRef = useRef<THREE.Group>(null);

  // Load the GLTF model using drei's useGLTF hook
  const { scene, animations } = useGLTF(config.modelUrl);

  // Extract animation actions bound to the specific group reference using useAnimations
  const { actions, mixer } = useAnimations(animations, groupRef);

  // Adjust global animation mixer time scale based on configuration
  useEffect(() => {
    if (mixer) {
      mixer.timeScale = config.animationSpeed;
    }
  }, [mixer, config.animationSpeed]);

  // Handle cross-fading and animation state transitions safely
  useEffect(() => {
    // Type guard validation layer at runtime
    if (!isValidAnimation(currentAction)) {
      console.warn(`Unsupported animation state requested: ${currentAction}`);
      return;
    }

    const nextAction = actions[currentAction];
    const previousAction = Object.values(actions).find((action) => action?.isRunning());

    if (nextAction) {
      // Reset and fade into the new animation smoothly over 0.5 seconds
      nextAction.reset().fadeIn(0.5).play();

      if (previousAction && previousAction !== nextAction) {
        previousAction.fadeOut(0.5);
      }
    }

    // Cleanup phase: fade out current action when unmounting or changing
    return () => {
      if (nextAction) {
        nextAction.fadeOut(0.5);
      }
    };
  }, [currentAction, actions]);

  // Per-frame callback hook for spatial updates or custom character logic
  useFrame((state, delta) => {
    // Example: Add subtle breathing rotation to the root group
    if (groupRef.current && currentAction === 'Idle') {
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.02;
    }
  });

  return (
    <group ref={groupRef} dispose={null}>
      <primitive object={scene} scale={[config.scale, config.scale, config.scale]} />
    </group>
  );
}

/**
 * ---------------------------------------------------------------------------
 * SAAS CONTAINER & APPLICATION ENTRY POINT
 * ---------------------------------------------------------------------------
 */
export default function SpatialCharacterApp() {
  // Simulated SaaS state management for avatar customization
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>({
    modelUrl: 'https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/knight/model.gltf',
    defaultAnimation: 'Idle',
    scale: 1.5,
    animationSpeed: 1.0,
  });

  const [activeState, setActiveState] = useState<ValidAnimationAction>('Idle');

  // Function demonstrating usage of our Partial utility type for dynamic patches
  const updateSettings = (patch: PartialAvatarConfig) => {
    setAvatarConfig((prev) => ({ ...prev, ...patch }));
  };

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#111', position: 'relative' }}>
      {/* SaaS Overlay Controls */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10, color: '#fff', background: 'rgba(0,0,0,0.7)', padding: 15, borderRadius: 8 }}>
        <h3>SaaS Avatar Inspector</h3>
        <p>Current State: <strong>{activeState}</strong></p>
        <button onClick={() => setActiveState('Idle')} style={{ marginRight: 5 }}>Idle</button>
        <button onClick={() => setActiveState('Walk')} style={{ marginRight: 5 }}>Walk</button>
        <button onClick={() => setActiveState('Run')} style={{ marginRight: 5 }}>Run</button>
        <button onClick={() => updateSettings({ animationSpeed: avatarConfig.animationSpeed === 1.0 ? 1.5 : 1.0 })}>
          Toggle Speed ({avatarConfig.animationSpeed}x)
        </button>
      </div>

      {/* React Three Fiber Canvas */}
      <Canvas camera={{ position: [0, 2, 5], fov: 50 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.2} />
        <CharacterModel config={avatarConfig} currentAction={activeState} />
      </Canvas>
    </div>
  );
}
