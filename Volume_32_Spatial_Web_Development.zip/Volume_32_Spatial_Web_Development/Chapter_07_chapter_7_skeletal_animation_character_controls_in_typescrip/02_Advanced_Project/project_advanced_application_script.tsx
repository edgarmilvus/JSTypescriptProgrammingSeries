/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useAnimations, useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import { z } from 'zod';

/**
 * @file character-controller.tsx
 * @description Advanced R3F component managing skeletal animations, physics state, 
 * and runtime validation for a spatial web application avatar.
 */

// ==========================================
// 1. RUNTIME VALIDATION SCHEMA (ZOD)
// ==========================================

/**
 * Validates the runtime configuration properties passed into the character controller.
 * Ensures asset paths are strings and movement speeds fall within safe boundaries.
 */
const CharacterConfigSchema = z.object({
  modelUrl: z.string().min(1, { message: "Model URL cannot be empty." }),
  movementSpeed: z.number().positive().default(3.5),
  runMultiplier: z.number().positive().default(2.0),
  animationBlendDuration: z.number().nonnegative().default(0.25),
});

type CharacterConfig = z.infer<typeof CharacterConfigSchema>;

interface CharacterControllerProps {
  config: CharacterConfig;
}

// ==========================================
// 2. INNER CHARACTER MESH COMPONENT
// ==========================================

/**
 * Core component handling GLTF loading, skeletal bone caching, 
 * animation mixing, and real-time keyboard polling.
 */
function AvatarModel({ config }: CharacterControllerProps) {
  // Reference to the root group of the loaded 3D asset
  const group = useRef<THREE.Group>(null);

  // Load the GLTF character model and its embedded skeletal animations
  const { scene, animations } = useGLTF(config.modelUrl);

  // Extract animation actions using Drei's helper hook tied to our group reference
  const { actions, names } = useAnimations(animations, group);

  // Track the currently active animation track name
  const [activeAction, setActiveAction] = useState<string>('idle');

  // Input state tracking for real-time controls
  const inputRef = useRef({
    forward: false,
    backward: false,
    left: false,
    right: false,
    shift: false,
  });

  /**
   * Set up keyboard event listeners for movement polling.
   */
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': inputRef.current.forward = true; break;
        case 'KeyS': inputRef.current.backward = true; break;
        case 'KeyA': inputRef.current.left = true; break;
        case 'KeyD': inputRef.current.right = true; break;
        case 'ShiftLeft': inputRef.current.shift = true; break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': inputRef.current.forward = false; break;
        case 'KeyS': inputRef.current.backward = false; break;
        case 'KeyA': inputRef.current.left = false; break;
        case 'KeyD': inputRef.current.right = false; break;
        case 'ShiftLeft': inputRef.current.shift = false; break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  /**
   * Handle animation state transitions with smooth cross-fading.
   */
  useEffect(() => {
    // Fallback if animations haven't loaded or names array is empty
    if (names.length === 0) return;

    // Determine target animation based on input state
    let targetActionName = 'idle';
    const isMoving = inputRef.current.forward || inputRef.current.backward || inputRef.current.left || inputRef.current.right;
    
    if (isMoving) {
      targetActionName = inputRef.current.shift ? 'run' : 'walk';
    }

    // Fallback to 'idle' if the target animation doesn't exist in the GLTF file
    if (!actions[targetActionName]) {
      targetActionName = names[0];
    }

    if (activeAction !== targetActionName) {
      const prevAction = actions[activeAction];
      const nextAction = actions[targetActionName];

      if (nextAction && prevAction) {
        // Reset and fade into the new animation smoothly
        nextAction.reset().fadeIn(config.animationBlendDuration).play();
        prevAction.fadeOut(config.animationBlendDuration);
        setActiveAction(targetActionName);
      } else if (nextAction) {
        nextAction.play();
        setActiveAction(targetActionName);
      }
    }
  }, [inputRef.current, actions, names, activeAction, config.animationBlendDuration]);

  /**
   * Per-frame animation loop for position updates and spatial transformations.
   */
  useFrame((state, delta) => {
    if (!group.current) return;

    const { forward, backward, left, right, shift } = inputRef.current;
    const speed = config.movementSpeed * (shift ? config.runMultiplier : 1.0) * delta;

    // Calculate displacement vectors based on camera/world orientation
    const direction = new THREE.Vector3();
    if (forward) direction.z -= 1;
    if (backward) direction.z += 1;
    if (left) direction.x -= 1;
    if (right) direction.x += 1;

    if (direction.lengthSq() > 0) {
      direction.normalize();
      group.current.position.addScaledVector(direction, speed);

      // Rotate character smoothly toward movement heading
      const angle = Math.atan2(direction.x, direction.z);
      group.current.rotation.y = angle;
    }
  });

  return (
    <group ref={group}>
      {/* Render the parsed GLTF scene containing the skinned mesh and skeleton */}
      <primitive object={scene} dispose={null} />
    </group>
  );
}

// ==========================================
// 3. MAIN EXPORTED COMPONENT WITH VALIDATION
// ==========================================

/**
 * Main container component that validates props using Zod and 
 * wraps the R3F canvas around the character scene.
 */
export default function SpatialCharacterApp({ 
  modelUrl = '/models/avatar.glb', 
  movementSpeed = 4.0 
}: { modelUrl?: string; movementSpeed?: number }) {
  
  // Runtime validation check before rendering the 3D context
  const validationResult = CharacterConfigSchema.safeParse({
    modelUrl,
    movementSpeed,
    runMultiplier: 2.2,
    animationBlendDuration: 0.3,
  });

  if (!validationResult.success) {
    return (
      <div className="p-4 bg-red-100 text-red-700 rounded-lg">
        <h3 className="font-bold">Configuration Validation Error</h3>
        <pre className="text-xs mt-2">{JSON.stringify(validationResult.error.format(), null, 2)}</pre>
      </div>
    );
  }

  const validConfig = validationResult.data;

  return (
    <div className="w-full h-[600px] relative bg-slate-950 rounded-xl overflow-hidden shadow-2xl">
      <Canvas camera={{ position: [0, 5, 10], fov: 50 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />
        <AvatarModel config={validConfig} />
        <gridHelper args={[20, 20, 0x444444, 0x222222]} />
      </Canvas>
      <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md text-white px-4 py-2 rounded-lg text-sm pointer-events-none">
        Use <kbd className="bg-slate-700 px-1.5 py-0.5 rounded">W A S D</kbd> to move, <kbd className="bg-slate-700 px-1.5 py-0.5 rounded">Shift</kbd> to run.
      </div>
    </div>
  );
}
