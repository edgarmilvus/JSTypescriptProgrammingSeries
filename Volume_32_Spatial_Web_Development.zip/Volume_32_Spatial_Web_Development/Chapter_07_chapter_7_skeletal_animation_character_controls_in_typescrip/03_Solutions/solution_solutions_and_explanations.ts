/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import * as THREE from 'three';
import { z } from 'zod';

// 1. Define the Zod schema with refined animation naming validation
export const CharacterConfigSchema = z.object({
  id: z.string().min(1),
  modelUrl: z.string().url(),
  scale: z.tuple([z.number(), z.number(), z.number()]),
  supportedAnimations: z
    .array(
      z.string().refine((val) => /^[a-zA-Z0-9_-]+$/.test(val), {
        message: 'Animation names can only contain alphanumeric characters, hyphens, and underscores.',
      })
    )
    .min(1, { message: 'At least one supported animation is required.' }),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

// 2. Export the inferred TypeScript type
export type CharacterConfig = z.infer<typeof CharacterConfigSchema>;

// 3. Implement user-defined type guard for SkinnedMesh
export function isSkinnedMesh(node: unknown): node is THREE.SkinnedMesh {
  if (node === null || typeof node !== 'object') {
    return false;
  }
  
  const candidate = node as Record<string, unknown>;
  
  return (
    candidate['isSkinnedMesh'] === true ||
    (candidate['skeleton'] instanceof THREE.Skeleton && candidate['geometry'] instanceof THREE.BufferGeometry)
  );
}

// 4. Implement asynchronous validation and loading function
export async function validateAndLoadCharacter(rawData: unknown): Promise<CharacterConfig> {
  const result = CharacterConfigSchema.safeParse(rawData);
  
  if (!result.success) {
    const errorMessages = result.error.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join(', ');
    throw new Error(`Character configuration validation failed: ${errorMessages}`);
  }
  
  return result.data;
}
