/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF, useAnimations } from '@react-three/drei';
import * as THREE from 'three';

export interface AdvancedCharacterControllerProps {
  modelPath: string;
  position?: [number, number, number];
  speed?: number;
  onStateChange?: (state: 'idle' | 'walk' | 'run') => void;
}

export interface AdvancedCharacterControllerRef {
  triggerEmote: (emoteName: string) => void;
}

export const AdvancedCharacterController = forwardRef<AdvancedCharacterControllerRef, AdvancedCharacterControllerProps>(({
  modelPath,
  position = [0, 0, 0],
  speed = 3.0,
  onStateChange
}, ref) => {
  const groupRef = useRef<THREE.Group>(null);
  const { scene, animations } = useGLTF(modelPath);
  const { actions, mixer } = useAnimations(animations, groupRef);

  const [currentState, setCurrentState] = useState<'idle' | 'walk' | 'run'>('idle');
  const keysPressed = useRef<{ [key: string]: boolean }>({});

  // Expose imperative handle for custom emotes
  useImperativeHandle(ref, () => ({
    triggerEmote: (emoteName: string) => {
      const emoteAction = actions[emoteName];
      if (emoteAction) {
        emoteAction.reset();
        emoteAction.setLoop(THREE.LoopOnce, 1);
        emoteAction.clampWhenFinished = true;
        emoteAction.fadeIn(0.2);
        emoteAction.play();
      }
    },
  }));

  // Keyboard event listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { keysPressed.current[e.code] = true; };
    const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.code] = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Animation cross-fading state machine logic
  useEffect(() => {
    const idleAction = actions['idle'];
    const walkAction = actions['walk'];
    const runAction = actions['run'];

    if (!idleAction || !walkAction || !runAction) return;

    // Stop all and cross-fade to current
    const activeAction = currentState === 'run' ? runAction : currentState === 'walk' ? walkAction : idleAction;
    
    Object.values(actions).forEach((action) => {
      if (action && action !== activeAction) {
        action.fadeOut(0.2);
      }
    });

    activeAction.reset().fadeIn(0.2).play();
    onStateChange?.(currentState);
  }, [currentState, actions, onStateChange]);

  // Frame loop updates for movement and state evaluation
  useFrame((_, delta) => {
    const isW = keysPressed.current['KeyW'] || keysPressed.current['ArrowUp'];
    const isShift = keysPressed.current['ShiftLeft'] || keysPressed.current['ShiftRight'];

    let targetState: 'idle' | 'walk' | 'run' = 'idle';
    if (isW) {
      targetState = isShift ? 'run' : 'walk';
      const moveSpeed = (isShift ? speed * 2 : speed) * delta;
      if (groupRef.current) {
        groupRef.current.translateZ(moveSpeed);
      }
    }

    if (targetState !== currentState) {
      setCurrentState(targetState);
    }
  });

  return (
    <group ref={groupRef} position={position}>
      <primitive object={scene} />
    </group>
  );
});

AdvancedCharacterController.displayName = 'AdvancedCharacterController';
export const MemoizedAdvancedCharacterController = React.memo(AdvancedCharacterController);
