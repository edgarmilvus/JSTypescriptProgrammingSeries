/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import React from 'react';

// 1. Traverse and locate a bone by its exact name
export function findBoneByName(root: THREE.Object3D, boneName: string): THREE.Bone | null {
  let foundBone: THREE.Bone | null = null;
  
  root.traverse((node) => {
    if (node instanceof THREE.Bone && node.name === boneName) {
      foundBone = node;
    }
  });
  
  return foundBone;
}

// 2. Update a raycaster's origin to match a specific skeletal bone position
export function updateCharacterRaycast(
  characterRoot: THREE.Object3D,
  raycaster: THREE.Raycaster,
  boneName: string,
  direction: THREE.Vector3
): void {
  const bone = findBoneByName(characterRoot, boneName);
  if (!bone) return;

  const boneWorldPosition = new THREE.Vector3();
  bone.getWorldPosition(boneWorldPosition);

  raycaster.set(boneWorldPosition, direction.normalize());
}

// 3. Custom hook for ground alignment with slope orientation
export function useCharacterGroundAlignment(
  characterRef: React.RefObject<THREE.Group>,
  terrainMeshRef: React.RefObject<THREE.Mesh>
): void {
  const raycaster = React.useRef(new THREE.Raycaster());
  const downVector = new THREE.Vector3(0, -1, 0);

  useFrame(() => {
    if (!characterRef.current || !terrainMeshRef.current) return;

    // Update raycast from waist/hips bone
    updateCharacterRaycast(characterRef.current, raycaster.current, 'mixamorigHips', downVector);

    const intersects = raycaster.current.intersectObject(terrainMeshRef.current);
    if (intersects.length > 0) {
      const hit = intersects[0];
      
      // Adjust vertical position to match ground intersection point
      characterRef.current.position.y = hit.point.y;

      // Interactive Challenge: Orient character posture to match surface normal
      if (hit.face) {
        const normal = hit.face.normal.clone();
        normal.transformDirection(terrainMeshRef.current.matrixWorld);

        const targetQuaternion = new THREE.Quaternion().setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          normal
        );
        
        // Smoothly slerp rotation to prevent jarring snaps
        characterRef.current.quaternion.slerp(targetQuaternion, 0.1);
      }
    }
  });
}
