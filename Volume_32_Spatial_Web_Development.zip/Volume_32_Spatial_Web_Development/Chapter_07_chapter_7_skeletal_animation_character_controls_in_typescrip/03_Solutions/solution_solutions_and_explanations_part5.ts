/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import * as THREE from 'three';

export interface StateMachineConfig {
  mixer: THREE.AnimationMixer;
  actions: Map<string, THREE.AnimationAction>;
}

export class AnimationStateMachine {
  private mixer: THREE.AnimationMixer;
  private actions: Map<string, THREE.AnimationAction>;
  private currentState: string;
  private activeListener: ((e: { action: THREE.AnimationAction }) => void) | null = null;

  constructor(config: StateMachineConfig, initialActionName: string) {
    this.mixer = config.mixer;
    this.actions = config.actions;
    this.currentState = initialActionName;
    
    const initialAction = this.actions.get(initialActionName);
    if (initialAction) {
      initialAction.play();
    }
  }

  // Queue transition with intermediate state handling (e.g., Idle -> StartRun -> Run)
  public queueTransition(
    transitionState: string,
    targetState: string,
    transitionDuration: number = 0.2
  ): void {
    const currentAction = this.actions.get(this.currentState);
    const transitionAction = this.actions.get(transitionState);
    const targetAction = this.actions.get(targetState);

    if (!transitionAction || !targetAction) return;

    // Remove existing listener if a transition is interrupted
    if (this.activeListener) {
      this.mixer.removeEventListener('finished', this.activeListener as any);
      this.activeListener = null;
    }

    if (currentAction) {
      currentAction.fadeOut(transitionDuration);
    }

    transitionAction.reset().setLoop(THREE.LoopOnce, 1).fadeIn(transitionDuration).play();

    // Listen for completion of the transition clip to trigger the target state loop
    this.activeListener = (e: { action: THREE.AnimationAction }) => {
      if (e.action === transitionAction) {
        transitionAction.fadeOut(transitionDuration);
        targetAction.reset().fadeIn(transitionDuration).play();
        this.currentState = targetState;

        this.mixer.removeEventListener('finished', this.activeListener as any);
        this.activeListener = null;
      }
    };

    this.mixer.addEventListener('finished', this.activeListener as any);
  }

  public update(delta: number): void {
    this.mixer.update(delta);
  }

  public dispose(): void {
    if (this.activeListener) {
      this.mixer.removeEventListener('finished', this.activeListener as any);
      this.activeListener = null;
    }
    this.mixer.stopAllAction();
  }
}
