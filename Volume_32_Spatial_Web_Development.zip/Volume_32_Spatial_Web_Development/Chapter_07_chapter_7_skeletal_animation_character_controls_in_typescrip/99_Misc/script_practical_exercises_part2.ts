/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import React from 'react';
import * as THREE from 'three';

export interface AdvancedCharacterControllerProps {
  modelPath: string;
  position?: [number, number, number];
  speed?: number;
  onStateChange?: (state: 'idle' | 'walk' | 'run') => void;
}

export const AdvancedCharacterController: React.FC<AdvancedCharacterControllerProps> = React.memo(({
  modelPath,
  position = [0, 0, 0],
  speed = 3.0,
  onStateChange
}) => {
  // TODO: Implement loading logic with useGLTF and useAnimations.
  // TODO: Implement keyboard input listeners and state machine inside useFrame.
  // TODO: Implement smooth animation cross-fading.

  return (
    <group position={position}>
      {/* Render loaded primitive or mesh group here */}
    </group>
  );
});

AdvancedCharacterController.displayName = 'AdvancedCharacterController';
