/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import * as THREE from 'three';

export interface StateMachineConfig {
  mixer: THREE.AnimationMixer;
  actions: Map<string, THREE.AnimationAction>;
}

export class AnimationStateMachine {
  private mixer: THREE.AnimationMixer;
  private actions: Map<string, THREE.AnimationAction>;
  private currentState: string;

  constructor(config: StateMachineConfig, initialActionName: string) {
    this.mixer = config.mixer;
    this.actions = config.actions;
    this.currentState = initialActionName;
    
    const initialAction = this.actions.get(initialActionName);
    if (initialAction) {
      initialAction.play();
    }
  }

  // TODO: Implement 'queueTransition' to handle multi-stage animated state changes.
  public queueTransition(
    transitionState: string,
    targetState: string,
    transitionDuration: number = 0.2
  ): void {
    // Implement state queueing and mixer event listener logic...
  }

  // TODO: Implement the update loop driver.
  public update(delta: number): void {
    this.mixer.update(delta);
  }

  // TODO: Implement cleanup method to remove event listeners.
  public dispose(): void {
    // Implement cleanup logic...
  }
}
