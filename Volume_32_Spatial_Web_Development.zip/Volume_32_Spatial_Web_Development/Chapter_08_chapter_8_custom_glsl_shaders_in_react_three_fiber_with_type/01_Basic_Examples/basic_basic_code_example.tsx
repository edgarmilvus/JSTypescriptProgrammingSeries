/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { shaderMaterial } from '@react-three/drei';
import { extend } from '@react-three/fiber';

/**
 * @interface HolographicCardUniforms
 * Defines the strict shape of the uniform data passed to the GPU shader.
 * Ensuring type safety here prevents runtime type-mismatches between React state and GLSL.
 */
interface HolographicCardUniforms {
  uTime: number;
  uColor: THREE.Color;
  uIntensity: number;
  [key: string]: THREE.Uniform<any> | number | THREE.Color;
}

/**
 * @interface HolographicCardProps
 * Defines the component-level inputs for the SaaS telemetry node.
 */
interface HolographicCardProps {
  /** The primary brand color of the telemetry node */
  baseColor?: string;
  /** The activation intensity, driven by incoming user interactions or live data streams */
  intensity?: number;
}

// 1. Create the custom shader material using drei's shaderMaterial helper
const CustomHolographicMaterial = shaderMaterial(
  // Uniform initial values
  {
    uTime: 0,
    uColor: new THREE.Color('#4f46e5'), // Indigo-600 standard SaaS accent
    uIntensity: 1.0,
  },
  // Vertex Shader (GLSL)
  /* glsl */`
    varying vec2 vUv;
    varying vec3 vPosition;
    uniform float uTime;

    void main() {
      vUv = uv;
      vPosition = position;

      // Apply a subtle vertex displacement wave along the Z-axis based on time
      vec3 transformed = position;
      transformed.z += sin(transformed.x * 4.0 + uTime) * 0.05 * cos(transformed.y * 4.0 + uTime);

      gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
    }
  `,
  // Fragment Shader (GLSL)
  /* glsl */`
    varying vec2 vUv;
    varying vec3 vPosition;
    uniform float uTime;
    uniform vec3 uColor;
    uniform float uIntensity;

    void main() {
      // Create an evolving interference pattern using sine waves and UV coordinates
      float pattern = sin(vUv.x * 10.0 + uTime) * cos(vUv.y * 10.0 - uTime);
      
      // Blend the base SaaS brand color with the generated dynamic wave pattern
      vec3 finalColor = mix(uColor, vec3(0.1, 0.9, 0.8), pattern * 0.5 + 0.5);
      
      // Scale final color by the reactive intensity uniform
      finalColor *= uIntensity;

      gl_FragColor = vec4(finalColor, 0.85); // Semi-transparent spatial glass effect
    }
  `
);

// 2. Extend R3F's declarative catalogue so <customHolographicMaterial /> can be used as a JSX intrinsic element
extend({ CustomHolographicMaterial });

/**
 * Type augmentation for React Three Fiber JSX elements.
 * This guarantees that TypeScript recognizes our custom material attributes without casting.
 */
declare global {
  namespace JSX {
    interface IntrinsicElements {
      customHolographicMaterial: React.ThreeElements['shaderMaterial'] & {
        uTime?: number;
        uColor?: THREE.Color | string;
        uIntensity?: number;
      };
    }
  }
}

/**
 * HolographicCard Component
 * Renders a 3D plane inside a WebXR-ready Canvas, managed by a type-safe GLSL shader pipeline.
 */
const HolographicCard: React.FC<HolographicCardProps> = ({ 
  baseColor = '#4f46e5', 
  intensity = 1.2 
}) => {
  // Reference to the custom shader material instance
  const materialRef = useRef<THREE.ShaderMaterial & { uTime: number; uIntensity: number; uColor: THREE.Color }>(null);

  // Memoize the THREE.Color instance to prevent unnecessary garbage collection per frame
  const memoizedColor = useMemo(() => new THREE.Color(baseColor), [baseColor]);

  // Update uniforms on every animation frame (60+ FPS loop)
  useFrame((state) => {
    if (!materialRef.current) return;
    
    // Pass elapsed time to the GPU for real-time procedural animations
    materialRef.current.uTime = state.clock.getElapsedTime();
    materialRef.current.uIntensity = intensity;
  });

  return (
    <mesh position={[0, 0, -2]} rotation={[0, 0, 0]}>
      <planeGeometry args={[2.5, 1.5, 32, 32]} />
      {/* 
        3. Instantiate the extended custom material with strictly typed props.
           TypeScript will flag any invalid property names or data types at compile time.
      */}
      <customHolographicMaterial
        ref={materialRef}
        uColor={memoizedColor}
        transparent={true}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
};

/**
 * Application Entry Point
 * Sets up the React Three Fiber Canvas container optimized for spatial web and desktop viewports.
 */
export default function SaaSMetricsSpatialView() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#09090b' }}>
      <Canvas camera={{ position: [0, 0, 3], fov: 60 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        <HolographicCard baseColor="#6366f1" intensity={1.5} />
      </Canvas>
    </div>
  );
}
