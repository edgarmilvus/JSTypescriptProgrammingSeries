/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame, extend } from '@react-three/fiber';
import { shaderMaterial } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Define the TypeScript interface for our custom shader uniforms.
 * This ensures strict type safety when updating variables from React state or animation loops.
 */
interface DataWaveUniforms {
  uTime: number;
  uColorStart: THREE.Color;
  uColorEnd: THREE.Color;
  uElevation: number;
  uFrequency: THREE.Vector2;
  [key: string]: any; // Index signature required by Three.js material uniform mapping
}

/**
 * Create a custom shader material using drei's shaderMaterial helper.
 * This automatically generates a Three.js ShaderMaterial subclass and registers it with R3F.
 */
const DataWaveMaterial = shaderMaterial(
  // Uniform initial values
  {
    uTime: 0,
    uColorStart: new THREE.Color('#0f172a'), // Deep slate (SaaS dark mode aesthetic)
    uColorEnd: new THREE.Color('#38bdf8'),   // Electric sky blue
    uElevation: 0.3,
    uFrequency: new THREE.Vector2(4.0, 4.0),
  },
  // Vertex Shader (GLSL)
  /* glsl */ `
    uniform float uTime;
    uniform float uElevation;
    uniform vec2 uFrequency;

    varying vec2 vUv;
    varying float vElevation;

    void main() {
      vUv = uv;

      // Compute dynamic wave displacement based on position and time
      vec4 modelPosition = modelMatrix * vec4(position, 1.0);
      
      float elevation = sin(modelPosition.x * uFrequency.x + uTime) * 
                        cos(modelPosition.z * uFrequency.y + uTime) * 
                        uElevation;
      
      modelPosition.y += elevation;
      vElevation = elevation;

      vec4 viewPosition = viewMatrix * modelPosition;
      vec4 projectedPosition = projectionMatrix * viewPosition;

      gl_Position = projectedPosition;
    }
  `,
  // Fragment Shader (GLSL)
  /* glsl */ `
    uniform vec3 uColorStart;
    uniform vec3 uColorEnd;

    varying vec2 vUv;
    varying float vElevation;

    void main() {
      // Mix colors dynamically based on vertex elevation and UV coordinates
      float mixStrength = (vElevation + 0.5);
      vec3 finalColor = mix(uColorStart, uColorEnd, mixStrength);

      // Add subtle grid lines for data visualization look
      float grid = step(0.95, fract(vUv.x * 20.0)) + step(0.95, fract(vUv.y * 20.0));
      finalColor += vec3(grid * 0.15);

      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
);

// Extend R3F elements so <dataWaveMaterial> can be used declaratively in JSX
extend({ DataWaveMaterial });

/**
 * A strongly-typed wrapper component for the DataWaveMesh.
 * Handles continuous GPU uniform updates via the R3F useFrame hook.
 */
function DataWaveMesh() {
  // Create a strict reference to our custom material instance
  const materialRef = useRef<THREE.ShaderMaterial & DataWaveUniforms>(null);

  // Update the uTime uniform on every frame render tick (60+ FPS)
  useFrame((state, delta) => {
    if (materialRef.current) {
      materialRef.current.uTime += delta * 1.5;
    }
  });

  return (
    <mesh rotation={[-Math.PI / 4, 0, 0]} position={[0, -0.5, 0]}>
      {/* 
        PlaneGeometry with high segment density (64x64) 
        required for smooth vertex shader wave calculations 
      */}
      <planeGeometry args={[6, 6, 64, 64]} />
      {/* @ts-expect-error - Custom extended R3F materials require type casting */}
      <dataWaveMaterial ref={materialRef} wireframe={false} />
    </mesh>
  );
}

/**
 * Main SaaS Dashboard View exporting the Canvas context.
 */
export default function SpatialDataDashboard() {
  return (
    <div className="w-full h-[600px] bg-slate-950 rounded-xl overflow-hidden shadow-2xl relative">
      <div className="absolute top-4 left-4 z-10 pointer-events-none">
        <h2 className="text-white text-lg font-semibold tracking-wide">Real-Time Data Flow (GLSL)</h2>
        <p className="text-slate-400 text-xs">GPU-accelerated spatial telemetry mapping</p>
      </div>
      <Canvas
        camera={{ position: [0, 3, 5], fov: 50 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
      >
        <ambientLight intensity={0.5} />
        <DataWaveMesh />
      </Canvas>
    </div>
  );
}
