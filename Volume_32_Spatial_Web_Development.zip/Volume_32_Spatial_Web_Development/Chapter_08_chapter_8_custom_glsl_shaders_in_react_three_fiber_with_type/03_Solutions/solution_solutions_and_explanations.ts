/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame, useThree, extend } from '@react-three/fiber';
import { shaderMaterial } from '@react-three/drei';
import * as THREE from 'three';

// 1. Define the uniform interface
interface DistortedUniforms {
  uTime: number;
  uFrequency: number;
  uColor: THREE.Vector3;
  uMouse: THREE.Vector2;
  uIntensity: number;
}

// Create custom shader material using drei's shaderMaterial helper
const DistortedShaderMaterial = shaderMaterial(
  {
    uTime: 0,
    uFrequency: 1.0,
    uColor: new THREE.Vector3(0.1, 0.5, 1.0),
    uMouse: new THREE.Vector2(0, 0),
    uIntensity: 0.5,
  },
  // Vertex Shader
  /* glsl */ `
    uniform float uTime;
    uniform float uFrequency;
    uniform float uIntensity;
    uniform vec2 uMouse;
    
    varying vec2 vUv;
    varying float vDisplacement;

    void main() {
      vUv = uv;
      
      // Calculate displacement based on position, time, and frequency
      float displacement = sin(position.x * uFrequency + uTime) * cos(position.y * uFrequency + uTime) * uIntensity;
      
      // Interactive mouse influence
      float dist = distance(uv, uMouse);
      displacement += (1.0 - smoothstep(0.0, 0.5, dist)) * 0.2 * uIntensity;

      vDisplacement = displacement;

      vec3 newPosition = position + normal * displacement;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
    }
  `,
  // Fragment Shader
  /* glsl */ `
    uniform vec3 uColor;
    uniform float uTime;
    varying vec2 vUv;
    varying float vDisplacement;

    void main() {
      vec3 finalColor = uColor + vec3(vDisplacement * 2.0, sin(uTime) * 0.1, -vDisplacement);
      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
);

// Extend Three.js elements so <distortedShaderMaterial> can be used in JSX
extend({ DistortedShaderMaterial });

// Type declaration for JSX
declare global {
  namespace JSX {
    interface IntrinsicElements {
      distortedShaderMaterial: React.ThreeElements['shaderMaterial'] & DistortedUniforms;
    }
  }
}

interface DistortedPlaneProps extends Partial<DistortedUniforms> {
  intensity?: number;
}

export const DistortedPlane: React.FC<DistortedPlaneProps> = ({
  intensity = 0.5,
  uFrequency = 2.0,
  uColor = new THREE.Vector3(0.2, 0.6, 0.9),
}) => {
  const materialRef = useRef<any>(null);
  const { pointer } = useThree();

  // 4 & 5. Update uniforms per frame via useFrame without state reconciliation
  useFrame((state) => {
    if (!materialRef.current) return;
    materialRef.current.uTime = state.clock.getElapsedTime();
    materialRef.current.uMouse.lerp(pointer, 0.1);
    materialRef.current.uIntensity = intensity;
    materialRef.current.uFrequency = uFrequency;
    materialRef.current.uColor = uColor;
  });

  return (
    <mesh>
      <planeGeometry args={[5, 5, 64, 64]} />
      <distortedShaderMaterial ref={materialRef} />
    </mesh>
  );
};
