/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// 1. Strict TypeScript interface mapping uniforms to Three.js types
export interface CustomShaderUniforms {
  uResolution: { value: THREE.Vector2 };
  uTexture: { value: THREE.Texture | null };
  uBlendFactor: { value: number };
  uColorStops: { value: THREE.Vector3[] };
}

const MAX_STOPS = 8;

const fragmentShader = /* glsl */ `
  uniform vec2 uResolution;
  uniform sampler2D uTexture;
  uniform float uBlendFactor;
  uniform vec3 uColorStops[${MAX_STOPS}];
  varying vec2 vUv;

  void main() {
    vec2 st = gl_FragCoord.xy / uResolution;
    vec4 texColor = texture2D(uTexture, vUv);
    
    // Procedural noise/blend pattern using color stops
    vec3 mixedColor = uColorStops[0];
    for(int i = 1; i < ${MAX_STOPS}; i++) {
      float stepFactor = float(i) / float(${MAX_STOPS});
      mixedColor = mix(mixedColor, uColorStops[i], smoothstep(stepFactor - 0.1, stepFactor + 0.1, st.x));
    }

    vec3 finalColor = mix(texColor.rgb, mixedColor, uBlendFactor);
    gl_FragColor = vec4(finalColor, 1.0);
  }
`;

const vertexShader = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

// 3. Custom hook returning a strongly-typed material
export function useTypedShaderMaterial(initialUniforms: Omit<CustomShaderUniforms, 'uColorStops'> & { uColorStops: THREE.Vector3[] }) {
  const material = useMemo(() => {
    // Pad array to match MAX_STOPS fixed size in GLSL
    const paddedStops = [...initialUniforms.uColorStops];
    while (paddedStops.length < MAX_STOPS) {
      paddedStops.push(new THREE.Vector3(0, 0, 0));
    }

    return new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        uResolution: { value: initialUniforms.uResolution.value },
        uTexture: { value: initialUniforms.uTexture.value },
        uBlendFactor: { value: initialUniforms.uBlendFactor.value },
        uColorStops: { value: paddedStops },
      } as CustomShaderUniforms,
    });
  }, []);

  return material;
}
