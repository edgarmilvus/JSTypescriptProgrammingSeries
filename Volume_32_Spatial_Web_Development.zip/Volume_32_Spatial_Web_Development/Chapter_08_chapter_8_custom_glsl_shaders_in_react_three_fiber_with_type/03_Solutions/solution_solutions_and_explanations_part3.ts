/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useXR } from '@react-three/xr';
import * as THREE from 'three';

const raymarchFragmentShader = (maxSteps: number) => /* glsl */ `
  #define MAX_STEPS ${maxSteps}
  uniform float uTime;
  varying vec2 vUv;

  void main() {
    // Simplified Raymarching Simulation loop mock
    vec2 uv = vUv * 2.0 - 1.0;
    float d = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
      d += sin(uv.x + uTime + float(i) * 0.1) * 0.01;
    }
    gl_FragColor = vec4(vec3(d + 0.5), 1.0);
  }
`;

export const OptimizedXRShaderPlane: React.FC = () => {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const { camera } = useThree();
  const { isPresenting } = useXR(); // Detect XR headset mode

  const currentSteps = useRef(64);

  useFrame((state) => {
    if (!meshRef.current || !materialRef.current) return;

    // 3. Calculate distance between camera and mesh
    const distance = camera.position.distanceTo(meshRef.current.position);

    // 4. Determine target steps based on XR mode and distance LOD
    let targetSteps = 64;
    if (isPresenting || distance > 10.0) {
      targetSteps = 24; // Lower precision for performance in XR or far distance
    }

    if (currentSteps.current !== targetSteps) {
      currentSteps.current = targetSteps;
      // Recompile material with optimized preprocessor macro
      materialRef.current.fragmentShader = raymarchFragmentShader(targetSteps);
      materialRef.current.needsUpdate = true;
    }

    materialRef.current.uniforms.uTime = { value: state.clock.getElapsedTime() };
  });

  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[2, 2]} />
      <shaderMaterial
        ref={materialRef}
        vertexShader={`varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`}
        fragmentShader={raymarchFragmentShader(64)}
        uniforms={{ uTime: { value: 0 } }}
      />
    </mesh>
  );
};
