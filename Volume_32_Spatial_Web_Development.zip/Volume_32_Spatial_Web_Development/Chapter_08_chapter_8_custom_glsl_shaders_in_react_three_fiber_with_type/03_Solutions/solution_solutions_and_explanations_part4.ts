/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Effect } from 'postprocessing';
import { EffectComposer } from '@react-three/postprocessing';
import * as THREE from 'three';

// 2. Custom Post-Processing Effect implementation
const ChromaticAberrationShader = {
  uniforms: new Map([
    ['uOffset', new THREE.Uniform(new THREE.Vector2(0.005, 0.005))],
    ['uIntensity', new THREE.Uniform(0.0)],
  ]),
  fragmentShader: /* glsl */ `
    uniform vec2 uOffset;
    uniform float uIntensity;

    void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
      vec2 uvR = uv + uOffset * uIntensity;
      vec2 uvB = uv - uOffset * uIntensity;

      float r = texture2D(inputBuffer, uvR).r;
      float g = texture2D(inputBuffer, uv).g;
      float b = texture2D(inputBuffer, uvB).b;

      outputColor = vec4(r, g, b, inputColor.a);
    }
  `,
};

class ChromaticAberrationEffectImpl extends Effect {
  constructor({ offset = new THREE.Vector2(0.005, 0.005), intensity = 1.0 } = {}) {
    super('ChromaticAberrationEffect', ChromaticAberrationShader.fragmentShader, {
      uniforms: ChromaticAberrationShader.uniforms,
    });
    this.uniforms.get('uOffset')!.value = offset;
    this.uniforms.get('uIntensity')!.value = intensity;
  }

  setIntensity(val: number) {
    this.uniforms.get('uIntensity')!.value = val;
  }
}

// 3. Declarative wrapper component
export const ChromaticAberrationEffect = React.forwardRef<ChromaticAberrationEffectImpl, { intensity?: number }>(
  ({ intensity = 0.0 }, ref) => {
    const effectRef = useRef<ChromaticAberrationEffectImpl>(null);

    // Interactive damping challenge implementation inside useFrame
    useFrame((_, delta) => {
      if (effectRef.current) {
        const current = effectRef.current.uniforms.get('uIntensity')!.value;
        // Exponential spring damping towards target intensity
        const dampened = THREE.MathUtils.lerp(current, intensity, delta * 10.0);
        effectRef.current.setIntensity(dampened);
      }
    });

    return <primitive ref={ref || effectRef} object={new ChromaticAberrationEffectImpl()} />;
  }
);

// Example Scene Usage wrapper
export const PostProcessingScene: React.FC<{ triggerSpike: boolean }> = ({ triggerSpike }) => {
  return (
    <EffectComposer>
      <ChromaticAberrationEffect intensity={triggerSpike ? 5.0 : 0.0} />
    </EffectComposer>
  );
};
