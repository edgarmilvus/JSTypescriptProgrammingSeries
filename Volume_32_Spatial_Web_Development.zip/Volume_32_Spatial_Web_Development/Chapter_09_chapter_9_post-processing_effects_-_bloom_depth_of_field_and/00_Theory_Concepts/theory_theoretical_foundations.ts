/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph PostProcessingPipeline {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f0f4f8", color="#cbd5e1"];
    edge [fontname="Arial", color="#64748b"];

    Scene [label="3D Scene & R3F Canvas\n(Geometries, Materials, Lights)"];
    WebGL [label="Raw WebGL Render Pass\n(Color & Depth Buffers)"];
    EffectComposer [label="Effect Composer\n(Multipass Framebuffer Management)"];
    
    subgraph cluster_passes {
        label = "Post-Processing Effect Chain";
        style="rounded";
        color="#e2e8f0";
        fillcolor="#f8fafc";
        
        AO [label="Ambient Occlusion\n(Contact Shadows & Crevices)"];
        Bloom [label="Bloom\n(Luminance Threshold & Blur)"];
        DOF [label="Depth of Field\n(CoC Calculation & Bokeh)"];
        ToneMapping [label="Tone Mapping & Color Grading\n(HDR to LDR Conversion)"];
        
        AO -> Bloom -> DOF -> ToneMapping;
    }

    Final [label="Final Canvas Output\n(Immersive Spatial Display)"];

    Scene -> WebGL;
    WebGL -> EffectComposer;
    EffectComposer -> AO;
    ToneMapping -> Final;
}
