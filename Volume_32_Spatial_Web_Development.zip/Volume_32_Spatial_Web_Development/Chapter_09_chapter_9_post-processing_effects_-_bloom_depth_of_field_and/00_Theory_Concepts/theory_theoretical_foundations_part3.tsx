/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.tsx
// Description: Theoretical Foundations
// ==========================================

// Example architectural structure of a declarative post-processing pipeline
import React from 'react';
import { Canvas } from '@react-three/fiber';
import { EffectComposer, Bloom, DepthOfField, SSAO, ToneMapping } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';

export function CinematicScene() {
  return (
    <Canvas camera={{ position: [0, 5, 10], fov: 60 }}>
      {/* 3D Scene Content */}
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 20, 10]} intensity={1.5} />
      
      {/* The Declarative Post-Processing Composition Engine */}
      <EffectComposer multisampling={8} enableNormalPass={true}>
        <SSAO 
          intensity={1.2} 
          radius={0.4} 
          samples={31} 
          luminanceInfluence={0.6} 
        />
        <Bloom 
          intensity={1.5} 
          luminanceThreshold={0.85} 
          luminanceSmoothing={0.25} 
          blendFunction={BlendFunction.SCREEN}
        />
        <DepthOfField 
          focusDistance={0.02} 
          focalLength={0.05} 
          bokehScale={4} 
        />
        <ToneMapping 
          adaptive={true} 
          resolution={256} 
          middleGrey={0.6} 
          maxLuminance={16.0} 
          averageLuminance={0.01} 
        />
      </EffectComposer>
    </Canvas>
  );
}
