/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.tsx
// Description: Theoretical Foundations
// ==========================================

// Conceptual architecture of how custom uniforms map from React props to GLSL shaders
import { Effect } from 'postprocessing';
import { Uniform } from 'three';

const CustomGlitchShader = {
  uniforms: new Map([
    ['tDiffuse', new Uniform(null)],
    ['intensity', new Uniform(0.5)],
    ['time', new Uniform(0)]
  ]),
  fragmentShader: `
    uniform float intensity;
    uniform float time;
    
    void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
      // Sample distorted UV coordinates based on time and intensity
      vec2 distortedUV = uv + sin(uv.y * 10.0 + time) * 0.01 * intensity;
      
      // Fetch color from the input texture using modified coordinates
      vec4 sampledColor = texture2D(inputColor, distortedUV);
      
      // Output final composited color
      outputColor = sampledColor;
    }
  `
};
