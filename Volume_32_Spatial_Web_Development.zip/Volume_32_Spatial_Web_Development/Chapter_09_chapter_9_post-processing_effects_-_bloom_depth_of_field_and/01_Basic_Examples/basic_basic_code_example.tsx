/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { EffectComposer, Bloom, DepthOfField, SSAO } from '@react-three/postprocessing';
import * as THREE from 'three';

/**
 * Interface representing props for the interactive product mesh.
 */
interface ProductMeshProps {
  /** The base color of the SaaS product representation */
  color?: string;
}

/**
 * A rotating 3D product mesh that emits a glowing core, 
 * designed to simulate a high-end hardware or software node.
 */
const ProductMesh: React.FC<ProductMeshProps> = ({ color = '#4f46e5' }) => {
  const meshRef = useRef<THREE.Mesh>(null!);

  // Rotate the product mesh continuously on every frame tick
  useFrame((state, delta) => {
    meshRef.current.rotation.x += delta * 0.4;
    meshRef.current.rotation.y += delta * 0.6;
  });

  return (
    <mesh ref={meshRef} position={[0, 0, 0]}>
      {/* A rounded box geometry representing a futuristic SaaS hardware node */}
      <boxGeometry args={[2, 2, 2]} />
      {/* MeshStandardMaterial reacts to scene lighting and emissive properties */}
      <meshStandardMaterial 
        color={color} 
        emissive="#818cf8" 
        emissiveIntensity={0.8} 
        roughness={0.2}
        metalness={0.8}
      />
    </mesh>
  );
};

/**
 * Main application component setting up the WebGL canvas, 
 * studio lighting, camera controls, and the post-processing effects pipeline.
 */
export default function SaaSProductViewerApp() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#09090b' }}>
      <Canvas
        camera={{ position: [0, 2, 6], fov: 50 }}
        gl={{ powerPreference: 'high-performance', antialias: false }}
      >
        {/* Ambient light for base visibility */}
        <ambientLight intensity={0.5} />
        {/* Directional light to cast primary shadows and highlights */}
        <directionalLight position={[10, 10, 5]} intensity={1.5} />

        {/* The 3D SaaS Product Scene Element */}
        <ProductMesh color="#3b82f6" />

        {/* Orbit controls allowing users to inspect the product */}
        <OrbitControls enableZoom={true} autoRotate autoRotateSpeed={1.0} />

        {/* Post-Processing Effect Composer Pipeline */}
        <EffectComposer>
          {/* Ambient Occlusion (SSAO) to ground the object and darken crevices */}
          <SSAO 
            intensity={15} 
            radius={0.4} 
            luminanceInfluence={0.6} 
            bias={0.025} 
          />
          
          {/* Bloom Effect to make emissive surfaces glow dynamically */}
          <Bloom 
            intensity={1.2} 
            luminanceThreshold={0.2} 
            luminanceSmoothing={0.9} 
            mipmapBlur 
          />

          {/* Depth of Field to blur background/foreground elements and draw focus to the product */}
          <DepthOfField 
            focusDistance={0.01} 
            focalLength={0.02} 
            bokehScale={3} 
          />
        </EffectComposer>
      </Canvas>
    </div>
  );
}
