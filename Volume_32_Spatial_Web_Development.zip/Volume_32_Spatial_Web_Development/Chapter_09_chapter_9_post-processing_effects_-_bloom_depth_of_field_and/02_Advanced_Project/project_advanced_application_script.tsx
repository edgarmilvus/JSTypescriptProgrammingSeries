/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { EffectComposer, Bloom, DepthOfField, SSAO } from '@react-postprocessing/core';
import * as THREE from 'three';

/**
 * Interface representing props for the interactive spatial element.
 */
interface SpatialElementProps {
  position: [number, number, number];
  color: string;
}

/**
 * A rotating 3D geometry piece that emits an emissive glow, 
 * interacting directly with the Bloom post-processing pass.
 */
function EmissiveSpatialMesh({ position, color }: SpatialElementProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  // Rotate the mesh continuously on every animation frame
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.5;
      meshRef.current.rotation.y += delta * 0.3;
    }
  });

  return (
    <mesh ref={meshRef} position={position}>
      <boxGeometry args={[1.5, 1.5, 1.5]} />
      {/* MeshStandardMaterial with high emissive property to trigger Bloom */}
      <meshStandardMaterial 
        color={color} 
        emissive={color} 
        emissiveIntensity={2.5} 
        roughness={0.2}
        metalness={0.8}
      />
    </mesh>
  );
}

/**
 * Studio floor plane to receive contact shadows and ambient occlusion.
 */
function StudioFloor() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
      <planeGeometry args={[50, 50]} />
      <meshStandardMaterial color="#1a1a1a" roughness={0.4} metalness={0.1} />
    </mesh>
  );
}

/**
 * Main Cinematic Viewport Component integrating React Three Fiber and Postprocessing.
 */
export default function SpatialCinematicViewport() {
  return (
    <div className="w-full h-screen bg-black">
      <Canvas
        camera={{ position: [0, 2, 8], fov: 60 }}
        gl={{ antialias: false, powerPreference: 'high-performance' }}
      >
        {/* Basic scene lighting setup */}
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 10]} intensity={1.5} />

        {/* 3D Scene Elements */}
        <EmissiveSpatialMesh position={[-2, 0, 0]} color="#ff3366" />
        <EmissiveSpatialMesh position={[2, 0, 0]} color="#3366ff" />
        <StudioFloor />

        {/* Post-Processing Effect Composer Pipeline */}
        <EffectComposer multisampling={4}>
          {/* Ambient Occlusion for grounded contact shadows */}
          <SSAO 
            intensity={15} 
            radius={0.4} 
            luminanceInfluence={0.6} 
            bias={0.025} 
          />
          
          {/* Cinematic Bloom effect reacting to high emissive intensity */}
          <Bloom 
            intensity={1.2} 
            luminanceThreshold={0.6} 
            luminanceSmoothing={0.9} 
          />

          {/* Depth of Field focusing on the center coordinates */}
          <DepthOfField 
            focusDistance={0.02} 
            focalLength={0.05} 
            bokehScale={4} 
          />
        </EffectComposer>
      </Canvas>
    </div>
  );
}
