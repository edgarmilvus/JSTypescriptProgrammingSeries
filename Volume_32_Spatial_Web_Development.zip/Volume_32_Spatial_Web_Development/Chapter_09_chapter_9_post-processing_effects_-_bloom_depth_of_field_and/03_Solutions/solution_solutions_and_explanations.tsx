/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import * as THREE from 'three';

interface SciFiPanelProps {
  bloomMode: 'global' | 'selective';
}

const HolographicPanel: React.FC<SciFiPanelProps> = ({ bloomMode }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  useEffect(() => {
    if (!meshRef.current) return;
    
    if (bloomMode === 'selective') {
      // Assign the mesh to layer 1 for selective bloom isolation
      meshRef.current.layers.set(1);
    } else {
      // Reset mesh back to default layer 0 for global scene-wide bloom
      meshRef.current.layers.set(0);
      meshRef.current.layers.enable(1); // Ensure default visibility
    }
  }, [bloomMode]);

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.2;
    }
  });

  return (
    <mesh ref={meshRef}>
      <boxGeometry args={[2, 2, 0.1]} />
      <meshStandardMaterial 
        color="#111111" 
        emissive="#00ffcc" 
        emissiveIntensity={4} 
      />
    </mesh>
  );
};

export const SceneContainer: React.FC = () => {
  const [mode, setMode] = useState<'global' | 'selective'>('selective');

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <button 
        onClick={() => setMode(m => m === 'global' ? 'selective' : 'global')}
        style={{ position: 'absolute', zIndex: 10, top: 20, left: 20 }}
      >
        Toggle Mode: {mode}
      </button>
      <Canvas camera={{ position: [0, 0, 5] }}>
        <color attach="background" args={['#050505']} />
        <ambientLight intensity={0.5} />
        <HolographicPanel bloomMode={mode} />
        <EffectComposer>
          <Bloom 
            intensity={1.5} 
            luminanceThreshold={0.8} 
            luminanceSmoothing={0.2} 
            mipmapBlur 
            // If in selective mode, restrict bloom extraction pass to layer 1
            {...(mode === 'selective' ? { selection: 1 } : {})}
          />
        </EffectComposer>
      </Canvas>
    </div>
  );
};
