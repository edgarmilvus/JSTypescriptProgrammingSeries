/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { SSAO, EffectComposer } from '@react-three/postprocessing';
import * as THREE from 'three';

interface AdaptiveAOProps {
  initialQuality?: 'low' | 'medium' | 'high';
  intensity?: number;
  radius?: number;
}

export const AdaptiveAmbientOcclusion: React.FC<AdaptiveAOProps> = ({
  initialQuality = 'medium',
  intensity = 1.5,
  radius = 0.2
}) => {
  const [quality, setQuality] = useState<'low' | 'medium' | 'high'>(initialQuality);
  const frameCount = useRef<number>(0);
  const timeAccumulator = useRef<number>(0);

  useFrame((_, delta) => {
    timeAccumulator.current += delta;
    frameCount.current += 1;

    // Every 60 frames, evaluate average frame duration
    if (frameCount.current >= 60) {
      const avgDelta = timeAccumulator.current / frameCount.current;
      const fps = 1 / avgDelta;

      // If FPS drops below 70Hz threshold, step down quality level
      if (fps < 70) {
        setQuality(prev => {
          if (prev === 'high') return 'medium';
          if (prev === 'medium') return 'low';
          return 'low';
        });
      }

      frameCount.current = 0;
      timeAccumulator.current = 0;
    }
  });

  const getQualitySettings = (q: 'low' | 'medium' | 'high') => {
    switch(q) {
      case 'low': return { samples: 8, rings: 2, distanceAttenuation: 1 };
      case 'medium': return { samples: 16, rings: 3, distanceAttenuation: 1.5 };
      case 'high': return { samples: 32, rings: 4, distanceAttenuation: 2 };
    }
  };

  const settings = getQualitySettings(quality);

  return (
    <EffectComposer>
      <SSAO 
        intensity={intensity} 
        radius={radius} 
        samples={settings.samples}
        rings={settings.rings}
      />
    </EffectComposer>
  );
};
