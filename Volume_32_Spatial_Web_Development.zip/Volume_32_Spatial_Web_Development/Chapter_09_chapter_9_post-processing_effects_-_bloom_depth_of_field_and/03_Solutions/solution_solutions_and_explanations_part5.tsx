/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { EffectComposer, Bloom, DepthOfField } from '@react-three/postprocessing';
import { VRButton, XR } from '@react-three/xr';

const TARGET_FRAME_MS = 11.1; // Target for 90Hz WebXR

const PerformanceManager: React.FC<{ onScaleChange: (scale: number) => void }> = ({ onScaleChange }) => {
  const emaDelta = useRef<number>(11.1);
  const currentScale = useRef<number>(1.0);

  useFrame((_, delta) => {
    const deltaMs = delta * 1000;
    const alpha = 0.1; // Smoothing factor
    
    // Apply Exponential Moving Average (EMA) smoothing for deltaMs
    emaDelta.current = alpha * deltaMs + (1 - alpha) * emaDelta.current;

    // Evaluate against performance budget threshold
    if (emaDelta.current > TARGET_FRAME_MS * 1.1 && currentScale.current > 0.5) {
      currentScale.current = Math.max(0.5, currentScale.current - 0.05);
      onScaleChange(currentScale.current);
    } else if (emaDelta.current < TARGET_FRAME_MS * 0.8 && currentScale.current < 1.0) {
      currentScale.current = Math.min(1.0, currentScale.current + 0.02);
      onScaleChange(currentScale.current);
    }
  });

  return null;
};

export const XRPerformanceApp: React.FC = () => {
  const [resolutionScale, setResolutionScale] = useState<number>(1.0);

  return (
    <>
      <VRButton />
      <div style={{ position: 'absolute', top: 10, left: 10, color: 'white', zIndex: 100 }}>
        Resolution Scale: {resolutionScale.toFixed(2)}
      </div>
      <Canvas>
        <XR>
          <PerformanceManager onScaleChange={setResolutionScale} />
          <ambientLight intensity={0.5} />
          <mesh position={[0, 1.5, -3]}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color="orange" emissive="red" emissiveIntensity={0.5} />
          </mesh>
          <EffectComposer 
            resolutionScale={resolutionScale}
            multisampling={0} // Disable MSAA in XR for performance
          >
            <Bloom intensity={1.2} luminanceThreshold={0.6} />
            <DepthOfField focus={3} aperture={0.02} focalLength={0.03} />
          </EffectComposer>
        </XR>
      </Canvas>
    </>
  );
};
