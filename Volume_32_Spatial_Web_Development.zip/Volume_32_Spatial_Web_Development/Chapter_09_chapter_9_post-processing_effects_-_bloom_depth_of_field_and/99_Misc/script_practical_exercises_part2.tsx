/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import React, { useRef, useState } from 'tsx';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { EffectComposer, DepthOfField } from '@react-three/postprocessing';
import * as THREE from 'three';

interface InteractiveSceneProps {
  focalLength: number;
  bokehScale: number;
}

const TargetObjects: React.FC<{ onSelectTarget: (distance: number) => void }> = ({ onSelectTarget }) => {
  const { camera } = useThree();

  const handleClick = (e: THREE.Event, zPos: number) => {
    e.stopPropagation();
    // TODO: Calculate distance from camera to the clicked object's world position
    // and invoke onSelectTarget with the resulting scalar value.
  };

  return (
    <group>
      <mesh position={[-2, 0, -2]} onClick={(e) => handleClick(e, -2)}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="hotpink" />
      </mesh>
      <mesh position={[0, 0, -6]} onClick={(e) => handleClick(e, -6)}>
        <sphereGeometry args={[0.7, 32, 32]} />
        <meshStandardMaterial color="cyan" />
      </mesh>
      <mesh position={[2, 0, -12]} onClick={(e) => handleClick(e, -12)}>
        <coneGeometry args={[0.8, 1.5, 32]} />
        <meshStandardMaterial color="yellow" />
      </mesh>
    </group>
  );
};

export const DoFApp: React.FC = () => {
  const [targetDistance, setTargetDistance] = useState<number>(6);
  const currentFocus = useRef<number>(6);
  
  // Ref for the DepthOfField effect imperatively updated each frame
  const dofRef = useRef<any>(null);

  useFrame((_, delta) => {
    // TODO: Smoothly interpolate currentFocus.current towards targetDistance 
    // and update dofRef.current.focus accordingly.
  });

  return (
    <Canvas camera={{ position: [0, 0, 2], fov: 60 }}>
      <ambientLight intensity={1} />
      <TargetObjects onSelectTarget={setTargetDistance} />
      <EffectComposer>
        <DepthOfField 
          ref={dofRef}
          focus={currentFocus.current}
          aperture={0.02}
          focalLength={0.05}
          bokehScale={4}
        />
      </EffectComposer>
    </Canvas>
  );
};
