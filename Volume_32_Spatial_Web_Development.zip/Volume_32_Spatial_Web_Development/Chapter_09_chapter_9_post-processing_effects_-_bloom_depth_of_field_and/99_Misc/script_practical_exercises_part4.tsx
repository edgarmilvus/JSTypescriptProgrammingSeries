/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { 
  EffectComposer, 
  Bloom, 
  DepthOfField, 
  ChromaticAberration, 
  Vignette, 
  SSAO 
} from '@react-three/postprocessing';
import { Vector2 } from 'three';

interface PipelineConfig {
  enableAO: boolean;
  enableBloom: boolean;
  enableDoF: boolean;
  enableAberration: boolean;
  enableVignette: boolean;
}

export const CinematicPipeline: React.FC = () => {
  const [config, setConfig] = useState<PipelineConfig>({
    enableAO: true,
    enableBloom: true,
    enableDoF: true,
    enableAberration: true,
    enableVignette: true,
  });

  // TODO: Implement validation logic to warn if passes are ordered incorrectly 
  // relative to depth-buffer dependencies.

  return (
    <Canvas camera={{ position: [0, 2, 8], fov: 50 }}>
      <color attach="background" args={['#020205']} />
      <ambientLight intensity={0.2} />
      <directionalLight position={[5, 8, 5]} intensity={1.5} />
      
      {/* Scene meshes go here */}
      <mesh position={[0, 0, 0]}>
        <torusKnotGeometry args={[1, 0.3, 128, 32]} />
        <meshStandardMaterial roughness={0.2} metalness={0.8} color="#4477ff" />
      </mesh>

      <EffectComposer multisampling={4}>
        {/* 
          TODO: Arrange the following effects in the correct architectural order:
          1. SSAO / Ambient Occlusion
          2. Bloom
          3. DepthOfField
          4. ChromaticAberration
          5. Vignette
        */}
        {config.enableAO && <SSAO intensity={1.2} radius={0.4} />}
        {config.enableBloom && <Bloom intensity={2.0} luminanceThreshold={0.7} />}
        {config.enableDoF && <DepthOfField focus={8} aperture={0.03} focalLength={0.05} />}
        {config.enableAberration && <ChromaticAberration offset={new Vector2(0.002, 0.002)} />}
        {config.enableVignette && <Vignette darkness={0.5} offset={0.3} />}
      </EffectComposer>
    </Canvas>
  );
};
