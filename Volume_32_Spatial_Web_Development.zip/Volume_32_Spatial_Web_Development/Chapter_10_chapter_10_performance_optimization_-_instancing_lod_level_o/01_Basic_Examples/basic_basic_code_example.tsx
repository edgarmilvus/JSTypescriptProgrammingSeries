/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useMemo, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Html, OrbitControls } from '@react-three/drei';

/**
 * Interface representing the spatial configuration of a single instance.
 */
interface InstanceData {
  position: [number, number, number];
  scale: [number, number, number];
  color: string;
}

/**
 * SaaS Inventory Dashboard Component rendering 10,000 items via Hardware Instancing.
 */
const InstancedInventoryGrid: React.FC = () => {
  // Number of instances to render in the spatial grid
  const count = 10000;
  
  // Reference to the underlying Three.js InstancedMesh
  const meshRef = useRef<THREE.InstancedMesh>(null!);

  // State to track user interaction with specific instance IDs
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  // Temporary object used to compute transformation matrices per tick
  const dummy = useMemo(() => new THREE.Object3D(), []);

  // Pre-calculate randomized positions, scales, and colors for all 10,000 items
  const instances: InstanceData[] = useMemo(() => {
    const items: InstanceData[] = [];
    const gridSize = Math.cbrt(count); // Distribute evenly in a 3D cube
    const spacing = 2.5;

    let index = 0;
    for (let x = 0; x < gridSize; x++) {
      for (let y = 0; y < gridSize; y++) {
        for (let z = 0; z < gridSize; z++) {
          if (index >= count) break;
          
          const posX = (x - gridSize / 2) * spacing;
          const posY = (y - gridSize / 2) * spacing;
          const posZ = (z - gridSize / 2) * spacing;

          // Alternate SaaS status colors (Active, Pending, Deprecated)
          const colorPalette = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];
          const color = colorPalette[index % colorPalette.length];

          items.push({
            position: [posX, posY, posZ],
            scale: [1, 1, 1],
            color,
          });
          index++;
        }
      }
    }
    return items;
  }, [count]);

  // Initialize color attributes on the instanced mesh once on mount
  useMemo(() => {
    if (!meshRef.current) return;
    const color = new THREE.Color();
    instances.forEach((item, i) => {
      color.set(item.color);
      meshRef.current.setColorAt(i, color);
    });
    meshRef.current.instanceColor!.needsUpdate = true;
  }, [instances]);

  // Animate instances slightly on every frame to simulate a live data stream
  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const time = clock.getElapsedTime();

    instances.forEach((item, i) => {
      const [x, y, z] = item.position;
      
      // Apply a gentle floating wave transformation based on index and time
      dummy.position.set(x, y + Math.sin(time + i) * 0.1, z);
      
      // Scale down hovered item for visual feedback
      if (hoveredId === i) {
        dummy.scale.set(1.5, 1.5, 1.5);
      } else {
        dummy.scale.set(1, 1, 1);
      }

      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    });

    // Inform the WebGL backend that instance matrices have changed
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[undefined, undefined, count]}
      onPointerMove={(e) => {
        e.stopPropagation();
        // e.instanceId provides the exact index of the instanced mesh hit by the raycaster
        if (e.instanceId !== undefined) {
          setHoveredId(e.instanceId);
        }
      }}
      onPointerOut={() => setHoveredId(null)}
    >
      {/* Low-poly geometry to maintain GPU performance */}
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial roughness={0.3} metalness={0.8} />
      
      {/* Conditional HTML overlay anchored in 3D space for the hovered SaaS item */}
      {hoveredId !== null && (
        <Html
          position={instances[hoveredId].position}
          center
          distanceFactor={15}
        >
          <div style={{
            background: 'rgba(15, 23, 42, 0.9)',
            color: '#fff',
            padding: '8px 12px',
            borderRadius: '6px',
            fontSize: '12px',
            pointerEvents: 'none',
            border: '1px solid #334155',
            boxShadow: '0 10px 15px -3px rgba(0,0,0,0.5)'
          }}>
            <strong>Item #{hoveredId}</strong>
            <div>Status: Optimal</div>
            <div>Pos: {instances[hoveredId].position.map(n => n.toFixed(1)).join(', ')}</div>
          </div>
        </Html>
      )}
    </instancedMesh>
  );
};

/**
 * Main application entry point wrapping the 3D canvas and controls.
 */
export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#020617' }}>
      <Canvas camera={{ position: [0, 0, 50], fov: 60 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.5} />
        <pointLight position={[-10, -20, -15]} intensity={0.5} />
        <InstancedInventoryGrid />
        <OrbitControls makeDefault />
      </Canvas>
    </div>
  );
}
