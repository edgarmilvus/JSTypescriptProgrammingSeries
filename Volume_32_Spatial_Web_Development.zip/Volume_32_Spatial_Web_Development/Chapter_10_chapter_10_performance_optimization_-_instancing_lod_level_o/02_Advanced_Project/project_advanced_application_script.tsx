/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client'

import React, { useRef, useMemo, useEffect, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Html, OrbitControls, Stats } from '@react-three/drei'
import * as THREE from 'three'

/**
 * Interface representing a single server node's dynamic state in the SaaS cluster.
 */
interface ServerNodeData {
  id: number
  position: [number, number, number]
  status: 'optimal' | 'warning' | 'critical'
  cpuLoad: number
}

interface ServerClusterProps {
  nodeCount?: number
  onNodeSelect?: (id: number) => void
}

/**
 * High-performance Server Cluster component using THREE.InstancedMesh.
 * Renders thousands of distinct server representations with minimal draw calls.
 */
const ServerClusterInstancedMesh: React.FC<ServerClusterProps> = ({ nodeCount = 5000, onNodeSelect }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)
  
  // Temporary math objects to avoid garbage collection overhead inside animation loops
  const dummy = useMemo(() => new THREE.Object3D(), [])
  const color = useMemo(() => new THREE.Color(), [])

  // Generate deterministic pseudo-random spatial distribution for nodes
  const nodesData = useMemo<ServerNodeData[]>(() => {
    const items: ServerNodeData[] = []
    const gridSize = Math.ceil(Math.cbrt(nodeCount))
    const spacing = 3.5

    for (let i = 0; i < nodeCount; i++) {
      const x = (i % gridSize - gridSize / 2) * spacing
      const y = (Math.floor(i / gridSize) % gridSize - gridSize / 2) * spacing
      const z = (Math.floor(i / (gridSize * gridSize)) - gridSize / 2) * spacing

      items.push({
        id: i,
        position: [x, y, z],
        status: Math.random() > 0.85 ? (Math.random() > 0.5 ? 'critical' : 'warning') : 'optimal',
        cpuLoad: Math.random()
      })
    }
    return items
  }, [nodeCount])

  // Initialize matrix transforms and base colors on mount
  useEffect(() => {
    if (!meshRef.current) return

    nodesData.forEach((node, index) => {
      dummy.position.set(...node.position)
      dummy.updateMatrix()
      meshRef.current!.setMatrixAt(index, dummy.matrix)

      // Set initial state color
      if (node.status === 'critical') color.set('#ff3333')
      else if (node.status === 'warning') color.set('#ffaa00')
      else color.set('#33cc66')

      meshRef.current!.setColorAt(index, color)
    })

    meshRef.current.instanceMatrix.needsUpdate = true
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true
  }, [nodesData, dummy, color])

  // Animate status pulses or warning indicators on GPU via matrix manipulation
  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const time = clock.getElapsedTime()

    nodesData.forEach((node, index) => {
      if (node.status === 'critical') {
        // Fetch current transform matrix
        meshRef.current!.getMatrixAt(index, dummy.matrix)
        dummy.matrix.decompose(dummy.position, dummy.quaternion, dummy.scale)
        
        // Apply subtle breathing scale effect to critical nodes
        const pulse = 1 + Math.sin(time * 6 + index) * 0.15
        dummy.scale.set(pulse, pulse, pulse)
        
        dummy.updateMatrix()
        meshRef.current!.setMatrixAt(index, dummy.matrix)
      }
    })
    meshRef.current.instanceMatrix.needsUpdate = true
  })

  // Handle raycast interactions efficiently with instanced meshes
  const handlePointerMove = (event: any) => {
    event.stopPropagation()
    if (event.instanceId !== undefined) {
      setHoveredIndex(event.instanceId)
    }
  }

  const handlePointerOut = () => {
    setHoveredIndex(null)
  }

  const handleClick = (event: any) => {
    event.stopPropagation()
    if (event.instanceId !== undefined && onNodeSelect) {
      onNodeSelect(nodesData[event.instanceId].id)
    }
  }

  return (
    <group>
      <instancedMesh
        ref={meshRef}
        args={[undefined, undefined, nodeCount]}
        onPointerMove={handlePointerMove}
        onPointerOut={handlePointerOut}
        onClick={handleClick}
      >
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial 
          roughness={0.3} 
          metalness={0.8} 
        />
      </instancedMesh>

      {/* Render contextual HTML overlay if an instance is actively hovered */}
      {hoveredIndex !== null && (
        <Html
          position={nodesData[hoveredIndex].position}
          center
          distanceFactor={15}
        >
          <div className="px-3 py-2 bg-slate-900/90 text-white text-xs rounded-md border border-slate-700 shadow-xl pointer-events-none backdrop-blur-md">
            <p className="font-bold text-cyan-400">Node ID: {nodesData[hoveredIndex].id}</p>
            <p>Status: <span className={nodesData[hoveredIndex].status === 'critical' ? 'text-red-400' : 'text-green-400'}>{nodesData[hoveredIndex].status.toUpperCase()}</span></p>
            <p>CPU Load: {(nodesData[hoveredIndex].cpuLoad * 100).toFixed(1)}%</p>
          </div>
        </Html>
      )}
    </group>
  )
}

/**
 * Main SaaS Spatial Dashboard Wrapper Scene.
 */
export default function SpatialDashboardScene() {
  const [selectedNode, setSelectedNode] = useState<number | null>(null)
  const [activeCount, setActiveCount] = useState<number>(8000)

  return (
    <div className="w-full h-screen relative bg-slate-950">
      {/* SaaS UI Overlay */}
      <div className="absolute top-4 left-4 z-10 p-4 bg-slate-900/80 border border-slate-800 rounded-lg backdrop-blur-md text-white max-w-sm">
        <h1 className="text-lg font-bold text-cyan-400">Global Cluster Telemetry</h1>
        <p className="text-xs text-slate-400 mt-1">
          Hardware instancing active. Rendering {activeCount} spatial nodes with single draw-call batching.
        </p>
        
        <div className="mt-4 flex flex-col gap-2">
          <label className="text-xs font-semibold text-slate-300">Cluster Density Scaling:</label>
          <div className="flex gap-2">
            <button onClick={() => setActiveCount(1000)} className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-xs rounded">1k Nodes</button>
            <button onClick={() => setActiveCount(8000)} className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-xs rounded">8k Nodes</button>
            <button onClick={() => setActiveCount(27000)} className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-xs rounded">27k Nodes</button>
          </div>
        </div>

        {selectedNode !== null && (
          <div className="mt-4 p-2 bg-cyan-950/40 border border-cyan-800/50 rounded text-xs">
            <span className="font-semibold text-cyan-300">Active Telemetry Target:</span> Node #{selectedNode}
          </div>
        )}
      </div>

      {/* WebGL Canvas */}
      <Canvas
        camera={{ position: [30, 30, 50], fov: 60 }}
        gl={{ antialias: false, powerPreference: 'high-performance' }}
      >
        <color attach="background" args={['#020617']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[50, 100, 50]} intensity={1.5} />
        
        <ServerClusterInstancedMesh 
          nodeCount={activeCount} 
          onNodeSelect={(id) => setSelectedNode(id)} 
        />

        <OrbitControls makeDefault enableDamping dampingFactor={0.05} />
        <Stats />
      </Canvas>
    </div>
  )
}
