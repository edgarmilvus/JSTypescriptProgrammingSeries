/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ForestSceneProps {
  count?: number;
}

export const ForestScene: React.FC<ForestSceneProps> = ({ count = 5000 }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);

  // Temporary objects to compute matrices without triggering garbage collection
  const dummy = new THREE.Object3D();
  const treeData = useRef<{ position: THREE.Vector3; scale: number; rotation: number; speed: number }[]>([]);

  useEffect(() => {
    if (!meshRef.current) return;

    const data = [];
    for (let i = 0; i < count; i++) {
      // 1. Generate random positions in a 100x100 grid, avoiding center (0,0)
      let x = (Math.random() - 0.5) * 100;
      let z = (Math.random() - 0.5) * 100;
      if (Math.abs(x) < 5 && Math.abs(z) < 5) {
        x += 10;
        z += 10;
      }

      const position = new THREE.Vector3(x, 0, z);
      const scale = 0.5 + Math.random() * 0.8;
      const rotation = Math.random() * Math.PI * 2;
      const speed = 1 + Math.random() * 3;

      data.push({ position, scale, rotation, speed });

      // Apply initial transform to instance
      dummy.position.copy(position);
      dummy.scale.set(scale, scale * (1 + Math.random() * 0.5), scale);
      dummy.rotation.y = rotation;
      dummy.updateMatrix();

      meshRef.current.setMatrixAt(i, dummy.matrix);
    }

    treeData.current = data;
    meshRef.current.instanceMatrix.needsUpdate = true;
  }, [count]);

  // Interactive Challenge: Sway trees gently in the wind using useFrame
  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const elapsedTime = clock.getElapsedTime();

    treeData.current.forEach((tree, i) => {
      dummy.position.copy(tree.position);
      
      // Add slight rotational sway based on sine wave and individual tree speed
      const sway = Math.sin(elapsedTime * tree.speed + tree.position.x) * 0.05;
      
      dummy.scale.set(tree.scale, tree.scale, tree.scale);
      dummy.rotation.y = tree.rotation + sway;
      dummy.updateMatrix();

      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
        <coneGeometry args={[0.5, 2, 4]} />
        <meshStandardMaterial color="#2d5a27" roughness={0.8} />
      </instancedMesh>
    </group>
  );
};
