/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface AdaptiveLODProps {
  highPolyGeometry: THREE.BufferGeometry;
  midPolyGeometry: THREE.BufferGeometry;
  lowPolyGeometry: THREE.BufferGeometry;
  material: THREE.Material;
  thresholdMid?: number;
  thresholdLow?: number;
  debug?: boolean;
}

export const AdaptiveLOD: React.FC<AdaptiveLODProps> = ({
  highPolyGeometry,
  midPolyGeometry,
  lowPolyGeometry,
  material,
  thresholdMid = 15,
  thresholdLow = 30,
  debug = false,
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const [lodLevel, setLodLevel] = useState<'high' | 'mid' | 'low'>('high');
  const { camera } = useThree();

  // Hysteresis buffer delta to prevent thrashing
  const hysteresis = 2;

  useFrame(() => {
    if (!groupRef.current) return;

    const objectPosition = new THREE.Vector3();
    groupRef.current.getWorldPosition(objectPosition);
    const distance = camera.position.distanceTo(objectPosition);

    setLodLevel((prevLevel) => {
      if (prevLevel === 'high') {
        if (distance > thresholdMid + hysteresis) return distance > thresholdLow + hysteresis ? 'low' : 'mid';
      } else if (prevLevel === 'mid') {
        if (distance < thresholdMid - hysteresis) return 'high';
        if (distance > thresholdLow + hysteresis) return 'low';
      } else {
        if (distance < thresholdLow - hysteresis) {
          return distance < thresholdMid - hysteresis ? 'high' : 'mid';
        }
      }
      return prevLevel;
    });
  });

  // Clone material or create debug materials
  const activeMaterial = React.useMemo(() => {
    if (!debug) return material;
    const mat = material.clone() as THREE.MeshStandardMaterial;
    if (lodLevel === 'high') mat.color.set('#00ff00'); // Green
    else if (lodLevel === 'mid') mat.color.set('#ffff00'); // Yellow
    else mat.color.set('#ff0000'); // Red
    return mat;
  }, [material, lodLevel, debug]);

  return (
    <group ref={groupRef}>
      {lodLevel === 'high' && <mesh geometry={highPolyGeometry} material={activeMaterial} />}
      {lodLevel === 'mid' && <mesh geometry={midPolyGeometry} material={activeMaterial} />}
      {lodLevel === 'low' && <mesh geometry={lowPolyGeometry} material={activeMaterial} />}
    </group>
  );
};
