/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Html } from '@react-drei';

interface PerformanceGuardProps {
  maxDrawCalls?: number;
  minFps?: number;
  onBudgetExceeded?: (metrics: { drawCalls: number; fps: number }) => void;
  children: React.ReactNode;
}

export const PerformanceGuard: React.FC<PerformanceGuardProps> = ({
  maxDrawCalls = 100,
  minFps = 72,
  onBudgetExceeded,
  children,
}) => {
  const { gl } = useThree();
  const [budgetExceeded, setBudgetExceeded] = useState(false);
  const [currentMetrics, setCurrentMetrics] = useState({ drawCalls: 0, fps: 72 });
  
  const lastCheckRef = useRef(0);
  const frameCountRef = useRef(0);
  const lastTimeRef = useRef(performance.now());

  useFrame((state, delta) => {
    frameCountRef.current++;
    const now = performance.now();

    // Calculate rolling FPS every second
    if (now - lastTimeRef.current >= 1000) {
      const fps = Math.round((frameCountRef.current * 1000) / (now - lastTimeRef.current));
      const drawCalls = gl.info.render.calls;

      setCurrentMetrics({ drawCalls, fps });

      // Throttle callback execution to prevent event spamming (at most once every 3 seconds)
      if ((fps < minFps || drawCalls > maxDrawCalls) && now - lastCheckRef.current > 3000) {
        setBudgetExceeded(true);
        onBudgetExceeded?.({ drawCalls, fps });
        lastCheckRef.current = now;
      } else if (fps >= minFps && drawCalls <= maxDrawCalls && now - lastCheckRef.current > 3000) {
        setBudgetExceeded(false);
      }

      frameCountRef.current = 0;
      lastTimeRef.current = now;
      
      // Reset renderer info counters for the next interval
      gl.info.reset();
    }
  });

  return (
    <>
      {children}
      {budgetExceeded && (
        <Html position={[0, 2, -2]} center>
          <div style={{ background: 'rgba(255,0,0,0.8)', color: 'white', padding: '10px', borderRadius: '5px' }}>
            <h4>Performance Warning!</h4>
            <p>FPS: {currentMetrics.fps} (Target: {minFps})</p>
            <p>Draw Calls: {currentMetrics.drawCalls} (Max: {maxDrawCalls})</p>
          </div>
        </Html>
      )}
    </>
  );
};
