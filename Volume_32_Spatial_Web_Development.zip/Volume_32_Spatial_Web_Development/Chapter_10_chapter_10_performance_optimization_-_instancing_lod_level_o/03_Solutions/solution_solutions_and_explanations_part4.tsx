/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface CityGridProps {
  gridSize?: number;
  spacing?: number;
}

export const OptimizedCityGrid: React.FC<CityGridProps> = ({
  gridSize = 50,
  spacing = 5,
}) => {
  const highMeshRef = useRef<THREE.InstancedMesh>(null);
  const midMeshRef = useRef<THREE.InstancedMesh>(null);
  const lowMeshRef = useRef<THREE.InstancedMesh>(null);

  const { camera } = useThree();
  const totalInstances = gridSize * gridSize;

  // Store metadata for all buildings
  const buildingsRef = useRef<{ position: THREE.Vector3; lod: 'high' | 'mid' | 'low' | 'culled' }[]>([]);
  const dummy = new THREE.Object3D();

  useEffect(() => {
    const buildings = [];
    const halfGrid = (gridSize * spacing) / 2;

    for (let x = 0; x < gridSize; x++) {
      for (let z = 0; z < gridSize; z++) {
        const posX = x * spacing - halfGrid;
        const posZ = z * spacing - halfGrid;
        buildings.push({ position: new THREE.Vector3(posX, 0, posZ), lod: 'high' as const });
      }
    }
    buildingsRef.current = buildings;
  }, [gridSize, spacing]);

  // Frame-sliced scheduler and matrix updater
  useFrame(({ camera }) => {
    if (!highMeshRef.current || !midMeshRef.current || !lowMeshRef.current) return;

    const frustum = new THREE.Frustum();
    const cameraMatrix = new THREE.Matrix4().multiplyMatrices(
      camera.projectionMatrix,
      camera.matrixWorldInverse
    );
    frustum.setFromProjectionMatrix(cameraMatrix);

    const batchSize = Math.ceil(buildingsRef.current.length / 4); // Process 25% per frame
    const startIdx = (Math.floor(performance.now() / 16) % 4) * batchSize;
    const endIdx = Math.min(startIdx + batchSize, buildingsRef.current.length);

    let highIdx = 0, midIdx = 0, lowIdx = 0;

    buildingsRef.current.forEach((building, i) => {
      const distance = camera.position.distanceTo(building.position);
      const isVisible = frustum.containsPoint(building.position);

      dummy.position.copy(building.position);

      if (!isVisible || distance > 150) {
        // Frustum culled or too far: scale down to zero
        dummy.scale.set(0, 0, 0);
        building.lod = 'culled';
      } else if (distance < 30) {
        dummy.scale.set(1, 1 + (i % 3), 1);
        highMeshRef.current!.setMatrixAt(highIdx++, dummy.matrix);
        building.lod = 'high';
      } else if (distance < 75) {
        dummy.scale.set(1, 1, 1);
        midMeshRef.current!.setMatrixAt(midIdx++, dummy.matrix);
        building.lod = 'mid';
      } else {
        dummy.scale.set(1, 0.5, 1);
        lowMeshRef.current!.setMatrixAt(lowIdx++, dummy.matrix);
        building.lod = 'low';
      }
    });

    highMeshRef.current.count = highIdx;
    highMeshRef.current.instanceMatrix.needsUpdate = true;

    midMeshRef.current.count = midIdx;
    midMeshRef.current.instanceMatrix.needsUpdate = true;

    lowMeshRef.current.count = lowIdx;
    lowMeshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group>
      <instancedMesh ref={highMeshRef} args={[undefined, undefined, totalInstances]}>
        <boxGeometry args={[3, 10, 3]} />
        <meshStandardMaterial color="#4a90e2" />
      </instancedMesh>
      <instancedMesh ref={midMeshRef} args={[undefined, undefined, totalInstances]}>
        <boxGeometry args={[3, 10, 3]} />
        <meshStandardMaterial color="#50e3c2" />
      </instancedMesh>
      <instancedMesh ref={lowMeshRef} args={[undefined, undefined, totalInstances]}>
        <boxGeometry args={[3, 10, 3]} />
        <meshStandardMaterial color="#b8e986" />
      </instancedMesh>
    </group>
  );
};
