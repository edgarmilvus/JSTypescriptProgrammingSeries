/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Center, Text3D } from '@react-three/drei';
import { Physics, RigidBody, RapierRigidBody, CuboidCollider, SphereCollider } from '@react-three/rapier';
import * as THREE from 'three';

/**
 * Interface representing metadata for dropped product items in our SaaS dashboard.
 */
interface ProductItem {
  id: string;
  color: string;
  position: [number, number, number];
}

/**
 * A falling product box driven by Rapier rigid body physics.
 */
function ProductBox({ color, position }: { color: string; position: [number, number, number] }) {
  // Reference to the Rapier rigid body for imperative updates or impulse applications
  const rigidBodyRef = useRef<RapierRigidBody>(null);
  const [hovered, setHovered] = useState(false);

  /**
   * Applies an upward impulse when a user clicks the 3D product box.
   */
  const handlePointerDown = () => {
    if (rigidBodyRef.current) {
      // Apply an impulse along the Y-axis to make the box jump
      rigidBodyRef.current.applyImpulse({ x: 0, y: 7, z: 0 }, true);
    }
  };

  return (
    <RigidBody
      ref={rigidBodyRef}
      position={position}
      restitution={0.6} // Bounciness factor (0 to 1)
      friction={0.4}    // Surface friction
      mass={1.5}        // Physical mass in kilograms
    >
      <mesh
        castShadow
        receiveShadow
        onPointerDown={handlePointerDown}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={hovered ? '#ff5722' : color} roughness={0.2} />
      </mesh>
    </RigidBody>
  );
}

/**
 * Static platform serving as the ground and boundary for physics items.
 */
function SaaSPlatform() {
  return (
    <RigidBody type="fixed" restitution={0.5} friction={0.7}>
      {/* Ground plane collider and visual mesh */}
      <mesh receiveShadow position={[0, -2, 0]}>
        <boxGeometry args={[10, 0.5, 10]} />
        <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.2} />
      </mesh>
    </RigidBody>
  );
}

/**
 * Main application component setting up the R3F Canvas and Rapier Physics world.
 */
export default function SpatialProductShowcase() {
  // State tracking products dropped into the 3D simulation
  const [products, setProducts] = useState<ProductItem[]>([
    { id: '1', color: '#3b82f6', position: [-1, 5, 0] },
    { id: '2', color: '#10b981', position: [1, 7, 0] },
  ]);

  /**
   * Spawns a new product box at a random offset above the physics stage.
   */
  const spawnProduct = () => {
    const newProduct: ProductItem = {
      id: Math.random().toString(36.substring(2, 9)),
      color: ['#3b82f6', '#10b981', '#f59e0b', '#ec4899'][Math.floor(Math.random() * 4)],
      position: [(Math.random() - 0.5) * 4, 8 + Math.random() * 2, (Math.random() - 0.5) * 4],
    };
    setProducts((prev) => [...prev, newProduct]);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', background: '#0f172a' }}>
      {/* SaaS Dashboard UI Overlay */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10, display: 'flex', gap: '10px' }}>
        <button
          onClick={spawnProduct}
          style={{
            padding: '10px 20px',
            backgroundColor: '#6366f1',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontWeight: 'bold',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          }}
        >
          Spawn Product Box
        </button>
      </div>

      {/* R3F Canvas with Rapier Physics Provider */}
      <Canvas shadows camera={{ position: [0, 5, 10], fov: 60 }}>
        <color attach="background" args={['#0f172a']} />
        
        {/* Scene Lighting */}
        <ambientLight intensity={0.7} />
        <directionalLight
          position={[10, 20, 10]}
          intensity={1.5}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />

        {/* Physics World Simulation Context */}
        <Physics gravity={[0, -9.81, 0]}>
          <SaaSPlatform />
          {products.map((p) => (
            <ProductBox key={p.id} color={p.color} position={p.position} />
          ))}
        </Physics>

        <OrbitControls makeDefault />
      </Canvas>
    </div>
  );
}
