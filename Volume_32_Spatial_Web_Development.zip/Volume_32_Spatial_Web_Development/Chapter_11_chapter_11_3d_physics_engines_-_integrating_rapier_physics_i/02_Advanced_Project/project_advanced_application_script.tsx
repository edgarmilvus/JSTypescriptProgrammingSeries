/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Physics, 
  RigidBody, 
  RapierRigidBody, 
  ColliderProps 
} from '@react-three/rapier';
import * as THREE from 'three';
import { z } from 'zod';

/**
 * ============================================================================
 * 1. ZOD SCHEMA & RUNTIME VALIDATION
 * ============================================================================
 * Defines the strict structural contract for incoming spatial spawning 
 * payloads from an external SaaS control panel or telemetry stream.
 */
const SpatialSpawnPayloadSchema = z.object({
  entityId: z.string().uuid(),
  geometryType: z.enum(['cuboid', 'ball', 'capsule']),
  mass: z.number().positive().default(1.0),
  initialPosition: z.tuple([z.number(), z.number(), z.number()]),
  initialVelocity: z.tuple([z.number(), z.number(), z.number()]).optional(),
  materialProperties: z.object({
    restitution: z.min(0).max(1).default(0.7),
    friction: z.min(0).max(1).default(0.5),
  }),
});

// Infer the compile-time TypeScript type directly from the Zod schema
type SpatialSpawnPayload = z.infer<typeof SpatialSpawnPayloadSchema>;

/**
 * ============================================================================
 * 2. TYPESCRIPT INTERFACES
 * ============================================================================
 * Contract definitions for component props and internal state management.
 */
interface SimulationSpawnerProps {
  rawIncomingData: unknown;
  onSpawnSuccess?: (entityId: string) => void;
  onSpawnError?: (error: z.ZodError) => void;
}

interface DynamicEntityProps {
  config: SpatialSpawnPayload;
}

/**
 * ============================================================================
 * 3. TYPE GUARDS
 * ============================================================================
 * Runtime verification functions to ensure safe reference casting of 
 * Rapier physics handles inside high-frequency animation loops.
 */
function isRapierRigidBody(node: unknown): node is RapierRigidBody {
  return (
    node !== null &&
    typeof node === 'object' &&
    '翻译' in node === false && // placeholder for structural duck-typing check
    typeof (node as RapansRigidBody)?.translation === 'function' &&
    typeof (node as RapansRigidBody)?.applyImpulse === 'function'
  );
}

// Helper specific to @react-three/rapier ref structure
function isValidRigidBodyRef(
  ref: React.RefObject<RapierRigidBody | null>
): ref is React.MutableRefObject<RapierRigidBody> {
  return ref.current !== null && typeof ref.current.translation === 'function';
}

/**
 * ============================================================================
 * 4. REACT COMPONENTS: DYNAMIC ENTITY & SPAWNER
 * ============================================================================
 */

/**
 * Renders an individual physics-enabled entity driven by Rapier and R3F.
 */
const DynamicEntity: React.FC<DynamicEntityProps> = ({ config }) => {
  const rbRef = useRef<RapierRigidBody | null>(null);
  const [hovered, setHovered] = useState<boolean>(false);

  // High-frequency frame loop for telemetry tracking and interaction
  useFrame(() => {
    // Utilize our Type Guard to guarantee safety before accessing physics methods
    if (isValidRigidBodyRef(rbRef)) {
      const currentTranslation = rbRef.current.translation();
      
      // Example enterprise telemetry check: log out-of-bounds entities
      if (currentTranslation.y < -50) {
        console.warn(`Entity ${config.entityId} fell out of bounds! Resetting position.`);
        rbRef.current.setTranslation(
          { x: config.initialPosition[0], y: config.initialPosition[1], z: config.initialPosition[2] },
          true
        );
        rbRef.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
      }
    }
  });

  const handlePointerDown = () => {
    // Apply an upward impulse when clicked, validating the ref first
    if (isValidRigidBodyRef(rbRef)) {
      rbRef.current.applyImpulse({ x: 0, y: 15 * config.mass, z: 0 }, true);
    }
  };

  return (
    <RigidBody
      ref={rbRef}
      colliders={config.geometryType}
      mass={config.mass}
      position={config.initialPosition}
      linearVelocity={config.initialVelocity}
      restitution={config.materialProperties.restitution}
      friction={config.materialProperties.friction}
      onPointerDown={handlePointerDown}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <mesh castShadow receiveShadow>
        {config.geometryType === 'cuboid' && <boxGeometry args={[1, 1, 1]} />}
        {config.geometryType === 'ball' && <sphereGeometry args={[0.7, 32, 32]} />}
        {config.geometryType === 'capsule' && <capsuleGeometry args={[0.5, 1, 16, 32]} />}
        <meshStandardMaterial 
          color={hovered ? '#4f46e5' : '#06b6d4'} 
          roughness={0.3}
          metalness={0.8}
        />
      </mesh>
    </RigidBody>
  );
};

/**
 * Main Spawner component that handles runtime validation and scene orchestration.
 */
export const SimulationSpawner: React.FC<SimulationSpawnerProps> = ({
  rawIncomingData,
  onSpawnSuccess,
  onSpawnError,
}) => {
  // Memoize validation to prevent redundant runtime CPU cycles on re-renders
  const validatedConfig = useMemo(() => {
    const result = SpatialSpawnPayloadSchema.safeParse(rawIncomingData);
    if (!result.success) {
      onSpawnError?.(result.error);
      return null;
    }
    onSpawnSuccess?.(result.data.entityId);
    return result.data;
  }, [rawIncomingData, onSpawnSuccess, onSpawnError]);

  if (!validatedConfig) {
    return (
      <div className="p-4 bg-red-900/20 border border-red-500 rounded-md text-red-200">
        <p className="font-semibold">Spatial Entity Validation Failed</p>
        <p className="text-sm opacity-80">Check console telemetry for parsing diagnostics.</p>
      </div>
    );
  }

  return (
    <div className="w-full h-[600px] relative rounded-xl overflow-hidden shadow-2xl border border-slate-800">
      <Canvas shadows camera={{ position: [0, 5, 12], fov: 60 }}>
        <color attach="background" args={['#0f172a']} />
        <ambientLight intensity={0.7} />
        <directionalLight 
          position={[10, 20, 15]} 
          intensity={1.5} 
          castShadow 
          shadow-mapSize={[2048, 2048]} 
        />
        <Physics gravity={[0, -9.81, 0]}>
          {/* Static Ground Plane */}
          <RigidBody type="fixed" restitution={0.5} friction={0.6}>
            <mesh receiveShadow position={[0, -2, 0]}>
              <boxGeometry args={[30, 0.5, 30]} />
              <meshStandardMaterial color="#1e293b" roughness={0.9} />
            </mesh>
          </RigidBody>

          {/* Dynamically Spawned Entity driven by validated schema */}
          <DynamicEntity config={validatedConfig} />
        </Physics>
      </Canvas>
    </div>
  );
};

export default SimulationSpawner;
