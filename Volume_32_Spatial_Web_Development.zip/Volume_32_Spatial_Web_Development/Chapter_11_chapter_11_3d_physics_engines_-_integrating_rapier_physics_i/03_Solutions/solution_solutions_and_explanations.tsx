/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { 
  RigidBody, 
  CylinderCollider, 
  CuboidCollider, 
  BallCollider, 
  RapierRigidBody, 
  CollisionPayload 
} from '@react-three/rapier';
import * as THREE from 'three';

// 2. Define strict TypeScript interface for obstacle configurations
export interface ObstacleConfig {
  id: string;
  type: 'fixed' | 'dynamic' | 'kinematicPosition';
  shape: 'box' | 'cylinder' | 'ball';
  position: [number, number, number];
  rotation?: [number, number, number];
  scale: [number, number, number];
  restitution?: number;
  friction?: number;
}

// 3. Data array of obstacles typed against ObstacleConfig
const courseObstacles: ObstacleConfig[] = [
  { id: 'floor', type: 'fixed', shape: 'box', position: [0, -1, 0], scale: [20, 1, 20], restitution: 0.2, friction: 0.8 },
  { id: 'barrier-1', type: 'fixed', shape: 'box', position: [0, 1, -5], scale: [4, 2, 0.5] },
  { id: 'roller-1', type: 'dynamic', shape: 'cylinder', position: [0, 2, -10], scale: [1, 1, 1], restitution: 0.5 },
  { id: 'moving-platform', type: 'kinematicPosition', shape: 'box', position: [0, 0.5, -15], scale: [3, 0.5, 3] },
];

export const ObstacleCourse: React.FC = () => {
  // Reference for the interactive kinematic wall that transforms into dynamic
  const kinematicWallRef = useRef<RapierRigidBody>(null);
  const playerRef = useRef<RapierRigidBody>(null);
  const [isWallDynamic, setIsWallDynamic] = useState<boolean>(false);

  // 5. Kinematic platform movement logic using type-inferred frames
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (kinematicWallRef.current && !isWallDynamic) {
      const xOffset = Math.sin(t) * 3;
      kinematicWallRef.current.setTranslation({ x: xOffset, y: 0.5, z: -15 }, true);
    }
  });

  // 6. Collision handler for the checkpoint barrier with inferred safety
  const handleCheckpointCollision = (payload: CollisionPayload) => {
    console.log(`Collision detected with entity:`, payload.target.rigidBodyObject?.name);
  };

  // Interactive Challenge: Trigger zone handler
  const handleTriggerEnter = () => {
    if (playerRef.current) {
      // Cast upward impulse onto the player rigid body
      playerRef.current.applyImpulse({ x: 0, y: 8, z: 0 }, true);
    }
    // Transform adjacent kinematic wall into a falling dynamic block
    if (kinematicWallRef.current) {
      kinematicWallRef.current.setBodyType(0, true); // 0 corresponds to Dynamic in Rapier
      setIsWallDynamic(true);
    }
  };

  return (
    <group>
      {/* Player Sphere */}
      <RigidBody ref={playerRef} colliders="ball" position={[0, 2, 0]} restitution={0.3}>
        <mesh castShadow>
          <sphereGeometry args={[0.5, 32, 32]} />
          <meshStandardMaterial color="royalblue" />
        </mesh>
      </RigidBody>

      {/* 4. Render obstacles using mapped configurations */}
      {courseObstacles.map((obs) => (
        <RigidBody
          key={obs.id}
          type={obs.type}
          position={obs.position}
          rotation={obs.rotation ? new THREE.Euler(...obs.rotation) : undefined}
          restitution={obs.restitution}
          friction={obs.friction}
        >
          {obs.shape === 'box' && <CuboidCollider args={[obs.scale[0] / 2, obs.scale[1] / 2, obs.scale[2] / 2]} />}
          {obs.shape === 'cylinder' && <CylinderCollider args={[obs.scale[1] / 2, obs.scale[0]]} />}
          {obs.shape === 'ball' && <BallCollider args={[obs.scale[0] / 2]} />}
          <mesh castShadow receiveShadow>
            {obs.shape === 'box' && <boxGeometry args={obs.scale} />}
            {obs.shape === 'cylinder' && <cylinderGeometry args={[obs.scale[0], obs.scale[0], obs.scale[1], 32]} />}
            <meshStandardMaterial color="orange" />
          </mesh>
        </RigidBody>
      ))}

      {/* Checkpoint Barrier with Collision Listener */}
      <RigidBody type="fixed" position={[0, 1, -2]} onCollisionEnter={handleCheckpointCollision}>
        <CuboidCollider args={[1, 1, 0.1]} />
      </RigidBody>

      {/* Interactive Trigger Zone & Transformable Wall */}
      <RigidBody 
        ref={kinematicWallRef} 
        type={isWallDynamic ? 'dynamic' : 'kinematicPosition'} 
        position={[0, 0.5, -15]}
      >
        <CuboidCollider args={[1.5, 0.25, 1.5]} />
        <mesh>
          <boxGeometry args={[3, 0.5, 3]} />
          <meshStandardMaterial color={isWallDynamic ? 'crimson' : 'purple'} />
        </mesh>
      </RigidBody>

      {/* Trigger sensor zone */}
      <RigidBody type="fixed" sensor position={[0, 0.5, -12]} onIntersectionEnter={handleTriggerEnter}>
        <CuboidCollider args={[2, 1, 0.5]} />
      </RigidBody>
    </group>
  );
};
