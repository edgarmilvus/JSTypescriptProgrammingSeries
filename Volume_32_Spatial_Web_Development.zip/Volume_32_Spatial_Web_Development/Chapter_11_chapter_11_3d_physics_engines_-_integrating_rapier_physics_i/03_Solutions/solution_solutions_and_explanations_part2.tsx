/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { RigidBody, CuboidCollider, RapierRigidBody } from '@react-three/rapier';
import * as THREE from 'three';

// 1. Define TypeScript interface for dropped items
export interface DroppedItem {
  id: string;
  geometryType: 'box' | 'sphere';
  spawnPosition: [number, number, number];
  color: string;
  scale?: [number, number, number];
}

// 2. Component props interface
export interface SpatialDropZoneProps {
  items: DroppedItem[];
  maxCapacity?: number;
  onItemSettled?: (id: string) => void;
}

export const SpatialDropZone: React.FC<SpatialDropZoneProps> = ({ 
  items, 
  maxCapacity = 10, 
  onItemSettled 
}) => {
  // Track settled state of items to avoid redundant callbacks
  const settledItemsRef = useRef<Set<string>>(new Set());
  const itemRefs = useRef<Map<string, RapierRigidBody>>(new Map());
  const crateBaseRef = useRef<RapierRigidBody>(null);

  // Interactive challenge state for dynamic weight scaling
  const [isDepressed, setIsDepressed] = useState(false);

  // 3. Static open crate container using compound cuboid colliders
  const CrateContainer = () => (
    <group position={[0, 0, 0]}>
      {/* Base */}
      <RigidBody type="fixed" position={[0, 0, 0]}>
        <CuboidCollider args={[1.5, 0.1, 1.5]} />
        <mesh receiveShadow>
          <boxGeometry args={[3, 0.2, 3]} />
          <meshStandardMaterial color="#8B4513" />
        </mesh>
      </RigidBody>
      {/* Walls */}
      <RigidBody type="fixed" position={[0, 0.5, 1.5]}>
        <CuboidCollider args={[1.5, 0.5, 0.1]} />
      </RigidBody>
      <RigidBody type="fixed" position={[0, 0.5, -1.5]}>
        <CuboidCollider args={[1.5, 0.5, 0.1]} />
      </RigidBody>
      <RigidBody type="fixed" position={[1.5, 0.5, 0]}>
        <CuboidCollider args={[0.1, 0.5, 1.5]} />
      </RigidBody>
      <RigidBody type="fixed" position={[-1.5, 0.5, 0]}>
        <CuboidCollider args={[0.1, 0.5, 1.5]} />
      </RigidBody>
    </group>
  );

  // 5. Frame loop to track velocity thresholds indicating settled rest state
  useFrame(() => {
    if (items.length > 5 && !isDepressed) {
      setIsDepressed(true);
    }

    itemRefs.current.forEach((body, id) => {
      if (!settledItemsRef.current.has(id)) {
        const linVel = body.linvel();
        const angVel = body.angvel();

        // Check if linear and angular velocities drop near zero
        const speed = Math.sqrt(linVel.x ** 2 + linVel.y ** 2 + linVel.z ** 2);
        const rotationSpeed = Math.sqrt(angVel.x ** 2 + angVel.y ** 2 + angVel.z ** 2);

        if (speed < 0.05 && rotationSpeed < 0.05) {
          settledItemsRef.current.add(id);
          if (onItemSettled) {
            onItemSettled(id);
          }
        }
      }
    });
  });

  return (
    <group>
      <CrateContainer />
      
      {/* 4. Dynamic rendering loop mapping over active inventory drops */}
      {items.slice(0, maxCapacity).map((item) => {
        const scale = item.scale || [0.4, 0.4, 0.4];
        // Derive volumetric mass approximation
        const volume = scale[0] * scale[1] * scale[2];
        const mass = volume * 5;

        return (
          <RigidBody
            key={item.id}
            ref={(el) => {
              if (el) itemRefs.current.set(item.id, el);
              else itemRefs.current.delete(item.id);
            }}
            position={item.spawnPosition}
            mass={mass}
            colliders={item.geometryType}
            restitution={0.1}
          >
            <mesh castShadow>
              {item.geometryType === 'box' ? (
                <boxGeometry args={scale} />
              ) : (
                <sphereGeometry args={[scale[0] / 2, 16, 16]} />
              )}
              <meshStandardMaterial color={item.color} />
            </mesh>
          </RigidBody>
        );
      })}
    </group>
  );
};
