/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, CuboidCollider, RapierRigidBody } from '@react-three/rapier';
import * as THREE from 'three';

// 1. Define VehicleConfig TypeScript interface
export interface VehicleConfig {
  chassisMass: number;
  wheelBase: [number, number, number]; // [width, height, length]
  suspensionStiffness: number;
  suspensionRestLength: number;
  maxSteeringAngle: number;
}

interface RaycastVehicleProps {
  config: VehicleConfig;
}

export const RaycastVehicle: React.FC<RaycastVehicleProps> = ({ config }) => {
  const chassisRef = useRef<RapierRigidBody>(null);
  const [controls, setControls] = useState({ forward: false, backward: false, left: false, right: false });

  // Keyboard listeners for interactive challenge
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'w') setControls(c => ({ ...c, forward: true }));
      if (e.key === 's') setControls(c => ({ ...c, backward: true }));
      if (e.key === 'a') setControls(c => ({ ...c, left: true }));
      if (e.key === 'd') setControls(c => ({ ...c, right: true }));
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'w') setControls(c => ({ ...c, forward: false }));
      if (e.key === 's') setControls(c => ({ ...c, backward: false }));
      if (e.key === 'a') setControls(c => ({ ...c, left: false }));
      if (e.key === 'd') setControls(c => ({ ...c, right: false }));
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // 3 & 4. Frame loop calculating raycasts and Hooke's Law suspension forces
  useFrame(() => {
    if (!chassisRef.current) return;

    const chassisPosition = chassisRef.current.translation();
    const chassisRotation = chassisRef.current.rotation();
    const linVel = chassisRef.current.linvel();

    const q = new THREE.Quaternion(chassisRotation.x, chassisRotation.y, chassisRotation.z, chassisRotation.w);
    
    // Four wheel raycast attachment points relative to chassis
    const [width, height, length] = config.wheelBase;
    const wheelOffsets: THREE.Vector3[] = [
      new THREE.Vector3(-width / 2, -height / 2, length / 2),
      new THREE.Vector3(width / 2, -height / 2, length / 2),
      new THREE.Vector3(-width / 2, -height / 2, -length / 2),
      new THREE.Vector3(width / 2, -height / 2, -length / 2),
    ];

    wheelOffsets.forEach((offset, index) => {
      // Rotate offset by chassis orientation and add to global position
      const rayOrigin = offset.clone().applyQuaternion(q).add(new THREE.Vector3(chassisPosition.x, chassisPosition.y, chassisPosition.z));
      const downRay = new THREE.Vector3(0, -1, 0);

      // Simulated raycast hit calculation (assuming flat ground at y = 0 for demonstration)
      const hitDistance = rayOrigin.y; 
      if (hitDistance < config.suspensionRestLength) {
        const displacement = config.suspensionRestLength - hitDistance;
        const damping = 5.0;
        
        // Hooke's Law: F_s = -k * x - c * v
        const springForceScalar = (-config.suspensionStiffness * displacement) - (damping * linVel.y);
        const forceVector = new THREE.Vector3(0, Math.max(0, springForceScalar), 0);

        // Apply suspension force at wheel contact point
        chassisRef.current!.applyImpulseAtPoint(
          { x: forceVector.x * 0.016, y: forceVector.y * 0.016, z: forceVector.z * 0.016 },
          { x: rayOrigin.x, y: rayOrigin.y, z: rayOrigin.z },
          true
        );
      }

      // Interactive Challenge: Drive and Steering forces
      if (index >= 2 && controls.forward) { // Rear wheel drive
        chassisRef.current!.applyImpulseAtPoint({ x: 0, y: 0, z: -0.1 }, { x: rayOrigin.x, y: rayOrigin.y, z: rayOrigin.z }, true);
      }
      if (index >= 2 && controls.backward) {
        chassisRef.current!.applyImpulseAtPoint({ x: 0, y: 0, z: 0.1 }, { x: rayOrigin.x, y: rayOrigin.y, z: rayOrigin.z }, true);
      }
    });
  });

  return (
    <group>
      <RigidBody ref={chassisRef} mass={config.chassisMass} position={[0, 3, 0]} colliders={false}>
        <CuboidCollider args={[config.wheelBase[0] / 2, config.wheelBase[1] / 2, config.wheelBase[2] / 2]} />
        <mesh castShadow>
          <boxGeometry args={config.wheelBase} />
          <meshStandardMaterial color="teal" />
        </mesh>
      </RigidBody>
    </group>
  );
};
