/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { RigidBody, RapierRigidBody } from '@react-three/rapier';
import * as THREE from 'three';

// 1. Serialized network physics state interface
export interface NetworkPhysicsState {
  id: string;
  position: [number, number, number];
  rotation: [number, number, number, number]; // Quaternion tuple
  linearVelocity: [number, number, number];
  timestamp: number;
}

// 2. Interpolated component props interface
export interface InterpolatedBodyProps {
  networkStream: NetworkPhysicsState[];
  alpha: number; // Interpolation factor
}

export const NetworkSyncedSphere: React.FC<InterpolatedBodyProps> = ({ networkStream, alpha }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const rigidBodyRef = useRef<RapierRigidBody>(null);

  // 3. Internal buffers for previous and target authoritative states
  const [previousState, setPreviousState] = useState<NetworkPhysicsState | null>(null);
  const [targetState, setTargetState] = useState<NetworkPhysicsState | null>(null);
  
  // Interactive challenge state for packet loss / extrapolation timer
  const lastPacketTimeRef = useRef<number>(Date.now());

  useEffect(() => {
    if (networkStream.length > 0) {
      const latest = networkStream[networkStream.length - 1];
      setPreviousState(targetState || latest);
      setTargetState(latest);
      lastPacketTimeRef.current = Date.now();
    }
  }, [networkStream]);

  // 4 & 5. Animation loop handling interpolation and jitter/extrapolation fallback
  useFrame((_, delta) => {
    if (!meshRef.current || !targetState) return;

    const now = Date.now();
    const timeSinceLastPacket = now - lastPacketTimeRef.current;

    const targetPos = new THREE.Vector3(...targetState.position);
    const targetRot = new THREE.Quaternion(...targetState.rotation);

    if (timeSinceLastPacket > 500 && targetState.linearVelocity) {
      // Interactive Challenge: Extrapolate position using last known linear velocity during packet drop
      const vel = new THREE.Vector3(...targetState.linearVelocity);
      meshRef.current.position.addScaledVector(vel, delta);
    } else if (previousState) {
      // Normal interpolation path
      const prevPos = new THREE.Vector3(...previousState.position);
      const prevRot = new THREE.Quaternion(...previousState.rotation);

      meshRef.current.position.lerpVectors(prevPos, targetPos, alpha);
      meshRef.current.quaternion.slerpQuaternions(prevRot, targetRot, alpha);

      if (rigidBodyRef.current) {
        rigidBodyRef.current.setTranslation(meshRef.current.position, true);
        rigidBodyRef.current.setRotation(meshRef.current.rotation, true);
      }
    }
  });

  return (
    <RigidBody ref={rigidBodyRef} type="kinematicPosition" colliders="ball">
      <mesh ref={meshRef} castShadow>
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial color="coral" />
      </mesh>
    </RigidBody>
  );
};
