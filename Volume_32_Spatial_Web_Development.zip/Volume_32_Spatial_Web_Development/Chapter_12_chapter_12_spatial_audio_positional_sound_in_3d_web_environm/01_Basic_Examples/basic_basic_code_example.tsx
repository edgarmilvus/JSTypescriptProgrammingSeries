/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface for the ServerAudioBeacon props.
 * Defines the physical world position and the alert state of the SaaS node.
 */
interface ServerAudioBeaconProps {
  position: [number, number, number];
  serverName: string;
  isCritical: boolean;
}

/**
 * ServerAudioBeacon Component
 * 
 * Renders a 3D representation of a cloud server rack in the virtual office space.
 * Attaches a Three.js PositionalAudio listener to the mesh so that audio attenuates
 * and pans based on the camera's relative position and orientation.
 */
const ServerAudioBeacon: React.FC<ServerAudioBeaconProps> = ({ position, serverName, isCritical }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const audioRef = useRef<THREE.PositionalAudio>(null);
  
  // Access the Three.js camera and audio listener context
  const { camera } = useThree();
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [audioLoaded, setAudioLoaded] = useState<boolean>(false);

  // We initialize the Three.js AudioListener and attach it to the main camera once on mount
  useEffect(() => {
    const listener = new THREE.AudioListener();
    camera.add(listener);

    if (audioRef.current) {
      // Create an HTML audio element loader to stream our SaaS alert sound
      const audioLoader = new THREE.AudioLoader();
      
      // Using a reliable public domain sound asset for demonstration
      audioLoader.load(
        'https://actions.google.com/sounds/v1/alarms/beep_short.ogg', 
        (buffer) => {
          if (audioRef.current) {
            audioRef.current.setBuffer(buffer);
            audioRef.current.setRefDistance(1); // Distance where volume begins to reduce
            audioRef.current.setMaxDistance(10); // Maximum distance for hearing the sound
            audioRef.current.setRolloffFactor(2); // Rate of volume attenuation over distance
            audioRef.current.setLoop(true); // Loop the alert for continuous monitoring
            setAudioLoaded(true);
          }
        },
        undefined,
        (error) => {
          console.error(`[SaaS Audio Engine] Failed to load sound buffer for ${serverName}:`, error);
        }
      );
    }

    // Cleanup listener on unmount to prevent memory leaks in dynamic scenes
    return () => {
      camera.remove(listener);
    };
  }, [camera, serverName]);

  // Handle play/pause toggle for the spatial audio stream
  const toggleAudio = () => {
    if (!audioRef.current || !audioLoaded) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  // Rotate the server rack slightly each frame to simulate active data processing
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  return (
    <group position={position}>
      {/* 3D Visual Mesh representing the Server Rack */}
      <mesh ref={meshRef} onClick={toggleAudio}>
        <boxGeometry args={[1, 2, 1]} />
        <meshStandardMaterial 
          color={isCritical ? '#ff3333' : '#33ff88'} 
          emissive={isCritical ? '#550000' : '#003311'}
          roughness={0.2}
        />
        
        {/* Three.js PositionalAudio Node attached to the mesh */}
        <positionalAudio ref={audioRef} args={[new THREE.AudioListener()]} />
      </mesh>

      {/* HTML UI overlay positioned in 3D space above the server */}
      <Html position={[0, 1.5, 0]} center>
        <div style={{
          background: 'rgba(0, 0, 0, 0.8)',
          color: 'white',
          padding: '6px 10px',
          borderRadius: '4px',
          fontFamily: 'sans-serif',
          fontSize: '12px',
          whiteSpace: 'nowrap',
          pointerEvents: 'auto',
          cursor: 'pointer',
          border: isCritical ? '1px solid #ff3333' : '1px solid #33ff88'
        }} onClick={toggleAudio}>
          <strong>{serverName}</strong>
          <div>{isPlaying ? '🔊 Mute Alert' : '🔇 Play Alert'}</div>
          <div style={{ fontSize: '10px', color: isCritical ? '#ff9999' : '#99ffbb' }}>
            {isCritical ? 'Status: CRITICAL' : 'Status: Normal'}
          </div>
        </div>
      </Html>
    </group>
  );
};

/**
 * Main SaaS Scene Component
 * Sets up the WebGL canvas, lighting, camera controls, and spatial audio beacons.
 */
export default function SpatialAudioDashboard() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#111' }}>
      <Canvas camera={{ position: [0, 5, 10], fov: 60 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 20, 10]} intensity={1} />
        
        {/* Server Node 1: Normal Operation */}
        <ServerAudioBeacon position={[-3, 0, 0]} serverName="API-Gateway-01" isCritical={false} />
        
        {/* Server Node 2: Critical Failure */}
        <ServerAudioBeacon position={[3, 0, 0]} serverName="Database-Cluster-02" isCritical={true} />

        <OrbitControls makeDefault />
      </Canvas>
    </div>
  );
}
