/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useRef, useEffect, useState, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { PositionalAudio as ThreePositionalAudio, Vector3, Mesh } from 'three';
import * as THREE from 'three';

/**
 * Interface representing a remote participant emitting spatial audio.
 */
interface ParticipantAudioSource {
  id: string;
  name: string;
  position: [number, number, number];
  audioUrl: string;
  refDistance: number;
  maxDistance: number;
  rolloffFactor: number;
}

/**
 * Props for the SpatialEmitter component.
 */
interface SpatialEmitterProps {
  participant: ParticipantAudioSource;
  isPlaying: boolean;
}

/**
 * Individual Spatial Emitter Component.
 * Wraps a Three.js PositionalAudio node inside a visual mesh representation.
 */
function SpatialEmitter({ participant, isPlaying }: SpatialEmitterProps) {
  const soundRef = useRef<ThreePositionalAudio>(null);
  const meshRef = useRef<Mesh>(null);
  const { camera, scene } = useThree();

  // Initialize the AudioListener and attach it to the camera or listener context.
  // In a complete R3F app, Three.js automatically manages a default listener on the camera.
  const listener = useMemo(() => new THREE.AudioListener(), []);

  useEffect(() => {
    // Attach listener to active camera if not already attached
    camera.add(listener);
    return () => {
      camera.remove(listener);
    };
  }, [camera, listener]);

  useEffect(() => {
    const soundNode = soundRef.current;
    if (!soundNode) return;

    // Load audio buffer using HTML5 Audio element or Web Audio Loader
    const audioLoader = new THREE.AudioLoader();
    audioLoader.load(participant.audioUrl, (buffer) => {
      soundNode.setBuffer(buffer);
      soundNode.setRefDistance(participant.refDistance);
      soundNode.setMaxDistance(participant.maxDistance);
      soundNode.setRolloffFactor(participant.rolloffFactor);
      soundNode.setLoop(true);
      soundNode.setVolume(1.0);

      if (isPlaying && !soundNode.isPlaying) {
        soundNode.play();
      }
    });

    return () => {
      if (soundNode && soundNode.isPlaying) {
        soundNode.stop();
      }
    };
  }, [participant, isPlaying]);

  // Sync mesh position with the audio source emitter coordinates
  useFrame(() => {
    if (meshRef.current && soundRef.current) {
      const [x, y, z] = participant.position;
      meshRef.current.position.set(x, y, z);
    }
  });

  return (
    <group>
      {/* Visual representation of the sound emitter in the 3D environment */}
      <mesh ref={meshRef} position={participant.position}>
        <sphereGeometry args={[0.3, 32, 32]} />
        <meshStandardMaterial 
          color={isPlaying ? '#10B981' : '#6B7280'} 
          emissive={isPlaying ? '#059669' : '#111827'}
          emissiveIntensity={0.5}
        />
        {/* The Three.js PositionalAudio node attached to the spatial mesh */}
        <positionalAudio ref={soundRef} args={[listener]} />
      </mesh>
    </group>
  );
}

/**
 * Main Spatial Audio Environment Component.
 * Sets up the 3D canvas, lighting, listener state, and renders dynamic participants.
 */
export default function SpatialAudioWorkspace() {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Mocked state representing active conference participants in the 3D workspace
  const participants: ParticipantAudioSource[] = [
    {
      id: 'user-1',
      name: 'Alice (Engineering)',
      position: [-3, 0, -5],
      audioUrl: '/audio/voice-stream-1.mp3',
      refDistance: 1,
      maxDistance: 50,
      rolloffFactor: 2,
    },
    {
      id: 'user-2',
      name: 'Bob (Product)',
      position: [4, 1, -6],
      audioUrl: '/audio/voice-stream-2.mp3',
      refDistance: 1,
      maxDistance: 50,
      rolloffFactor: 2,
    },
  ];

  return (
    <div className="w-full h-screen relative bg-slate-950 flex flex-col">
      {/* SaaS App Control Overlay */}
      <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur-md p-4 rounded-xl border border-slate-800 text-white shadow-2xl">
        <h1 className="text-lg font-semibold tracking-wide">Spatial Meeting Room</h1>
        <p className="text-xs text-slate-400 mb-3">Chapter 12: WebXR Positional Audio Simulation</p>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            isPlaying 
              ? 'bg-rose-600 hover:bg-rose-500 text-white' 
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
        >
          {isPlaying ? 'Mute Spatial Audio' : 'Initialize & Join Audio Stream'}
        </button>
      </div>

      {/* 3D Canvas Viewport */}
      <Canvas
        camera={{ position: [0, 2, 5], fov: 75 }}
        className="w-full h-full"
      >
        <color attach="background" args={['#0f172a']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1} />

        {/* Render Environment Grid */}
        <gridHelper args={[50, 50, '#334155', '#1e293b']} />

        {/* Render Participant Emitters */}
        {participants.map((participant) => (
          <SpatialEmitter
            key={participant.id}
            participant={participant}
            isPlaying={isPlaying}
          />
        ))}
      </Canvas>
    </div>
  );
}
