/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface SpatialAmbientZoneProps {
  url: string;
  position: [number, number, number];
  radius: number;
  maxDistance: number;
  isOccluded: boolean;
}

export const SpatialAmbientZone: React.FC<SpatialAmbientZoneProps> = ({
  url,
  position,
  radius,
  maxDistance,
  isOccluded,
}) => {
  const { camera, gl } = useThree();
  const groupRef = useRef<THREE.Group>(null);
  const sphereRef = useRef<THREE.Mesh>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const pannerNodeRef = useRef<PannerNode | null>(null);
  const filterNodeRef = useRef<BiquadFilterNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  const [distanceRatio, setDistanceRatio] = useState<number>(1);

  useEffect(() => {
    // Initialize Web Audio Context and graph nodes
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const panner = ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = radius;
    panner.maxDistance = maxDistance;
    panner.rolloffFactor = 1.5;
    panner.positionX.setValueAtTime(position[0], ctx.currentTime);
    panner.positionY.setValueAtTime(position[1], ctx.currentTime);
    panner.positionZ.setValueAtTime(position[2], ctx.currentTime);
    pannerNodeRef.current = panner;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(20000, ctx.currentTime);
    filterNodeRef.current = filter;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(1.0, ctx.currentTime);
    gainNodeRef.current = gain;

    // Fetch and decode audio asset
    let isMounted = true;
    fetch(url)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => ctx.decodeAudioData(arrayBuffer))
      .then((audioBuffer) => {
        if (!isMounted || !ctx) return;

        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.loop = true;

        // Connect graph: Source -> Filter -> Panner -> Gain -> Destination
        source.connect(filter);
        filter.connect(panner);
        panner.connect(gain);
        gain.connect(ctx.destination);

        source.start(0);
        sourceNodeRef.current = source;
      })
      .catch((err) => console.error('Failed to load spatial audio buffer:', err));

    return () => {
      isMounted = false;
      if (sourceNodeRef.current) {
        try { sourceNodeRef.current.stop(); } catch {}
        sourceNodeRef.current.disconnect();
      }
      if (ctx.state !== 'closed') {
        ctx.close();
      }
    };
  }, [url, position, radius, maxDistance]);

  // Handle occlusion transitions via linear ramping
  useEffect(() => {
    if (!filterNodeRef.current || !audioContextRef.current) return;
    const ctx = audioContextRef.current;
    const filter = filterNodeRef.current;
    
    const targetFreq = isOccluded ? 800 : 20000;
    filter.frequency.cancelScheduledValues(ctx.currentTime);
    filter.frequency.linearRampToValueAtTime(targetFreq, ctx.currentTime + 0.5);
  }, [isOccluded]);

  // Per-frame distance evaluation and debug mesh color interpolation
  useFrame(() => {
    if (!groupRef.current) return;

    const worldPos = new THREE.Vector3(...position);
    const dist = camera.position.distanceTo(worldPos);

    // Calculate normalization ratio for interactive challenge visualization
    const ratio = Math.max(0, Math.min(1, dist / maxDistance));
    setDistanceRatio(ratio);

    if (sphereRef.current) {
      const material = sphereRef.current.material as THREE.MeshBasicMaterial;
      if (dist <= radius) {
        // Emerald green scaling in intensity as it approaches the center
        const intensity = 1 - (dist / radius);
        material.color.setRGB(0, 0.5 + 0.5 * intensity, 0.2);
      } else {
        // Calm cyan outside the inner radius
        material.color.setRGB(0, 0.8, 0.8);
      }
    }
  });

  return (
    <group ref={groupRef} position={position}>
      <mesh ref={sphereRef}>
        <sphereGeometry args={[radius, 32, 16]} />
        <meshBasicMaterial wireframe color="cyan" transparent opacity={0.4} />
      </mesh>
    </group>
  );
};
