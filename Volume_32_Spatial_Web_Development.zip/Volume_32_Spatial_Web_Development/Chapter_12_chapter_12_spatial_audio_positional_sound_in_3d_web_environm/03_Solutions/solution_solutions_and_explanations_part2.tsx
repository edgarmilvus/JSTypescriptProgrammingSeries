/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';

interface DirectionalConeSourceProps {
  url: string;
  position: [number, number, number];
  orientation: [number, number, number];
}

export const DirectionalConeSource: React.FC<DirectionalConeSourceProps> = ({
  url,
  position,
  orientation,
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const pannerNodeRef = useRef<PannerNode | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const panner = ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    
    // Configure directional cone parameters
    panner.coneInnerAngle = 45;
    panner.coneOuterAngle = 90;
    panner.coneOuterGain = 0.1;

    panner.positionX.setValueAtTime(position[0], ctx.currentTime);
    panner.positionY.setValueAtTime(position[1], ctx.currentTime);
    panner.positionZ.setValueAtTime(position[2], ctx.currentTime);

    const normOrientation = new THREE.Vector3(...orientation).normalize();
    panner.orientationX.setValueAtTime(normOrientation.x, ctx.currentTime);
    panner.orientationY.setValueAtTime(normOrientation.y, ctx.currentTime);
    panner.orientationZ.setValueAtTime(normOrientation.z, ctx.currentTime);

    pannerNodeRef.current = panner;

    fetch(url)
      .then((res) => res.arrayBuffer())
      .then((buf) => ctx.decodeAudioData(buf))
      .then((decodedBuffer) => {
        const source = ctx.createBufferSource();
        source.buffer = decodedBuffer;
        source.loop = true;

        source.connect(panner);
        panner.connect(ctx.destination);
        source.start(0);
        sourceNodeRef.current = source;
      });

    return () => {
      if (sourceNodeRef.current) {
        try { sourceNodeRef.current.stop(); } catch {}
        sourceNodeRef.current.disconnect();
      }
      if (ctx.state !== 'closed') ctx.close();
    };
  }, [url, position, orientation]);

  // Update orientation vector in real-time if the emitter rotates
  useFrame(() => {
    if (!groupRef.current || !pannerNodeRef.current || !audioContextRef.current) return;
    
    const worldDir = new THREE.Vector3(0, 0, 1);
    groupRef.current.getWorldDirection(worldDir);
    
    const ctx = audioContextRef.current;
    const panner = pannerNodeRef.current;
    
    panner.orientationX.setValueAtTime(worldDir.x, ctx.currentTime);
    panner.orientationY.setValueAtTime(worldDir.y, ctx.currentTime);
    panner.orientationZ.setValueAtTime(worldDir.z, ctx.currentTime);
  });

  return (
    <group ref={groupRef} position={position}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.5, 1.5, 16]} />
        <meshStandardMaterial color="royalblue" wireframe />
      </mesh>
    </group>
  );
};
