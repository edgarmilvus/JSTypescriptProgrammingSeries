/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface DopplerSourceProps {
  url: string;
  speed: number;
}

export const DopplerSource: React.FC<DopplerSourceProps> = ({ url }) => {
  const { camera } = useThree();
  const meshRef = useRef<THREE.Mesh>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  
  const prevSourcePos = useRef<THREE.Vector3>(new THREE.Vector3());
  const prevCameraPos = useRef<THREE.Vector3>(new THREE.Vector3());
  const isInitialized = useRef<boolean>(false);

  useEffect(() => {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(1.0, ctx.currentTime);
    gain.connect(ctx.destination);
    gainNodeRef.current = gain;

    fetch(url)
      .then((res) => res.arrayBuffer())
      .then((buf) => ctx.decodeAudioData(buf))
      .then((decodedBuffer) => {
        const source = ctx.createBufferSource();
        source.buffer = decodedBuffer;
        source.loop = true;
        source.connect(gain);
        source.start(0);
        sourceNodeRef.current = source;
        isInitialized.current = true;
      });

    return () => {
      if (sourceNodeRef.current) {
        try { sourceNodeRef.current.stop(); } catch {}
      }
      if (ctx.state !== 'closed') ctx.close();
    };
  }, [url]);

  useFrame((_, delta) => {
    if (!meshRef.current || !isInitialized.current || !sourceNodeRef.current || delta === 0) return;

    const currentSourcePos = meshRef.current.position;
    const currentCameraPos = camera.position;

    if (prevSourcePos.current.lengthSq() === 0) {
      prevSourcePos.current.copy(currentSourcePos);
      prevCameraPos.current.copy(currentCameraPos);
      return;
    }

    // Compute instantaneous velocities (units per second)
    const sourceVelocity = currentSourcePos.clone().sub(prevSourcePos.current).divideScalar(delta);
    const cameraVelocity = currentCameraPos.clone().sub(prevCameraPos.current).divideScalar(delta);

    prevSourcePos.current.copy(currentSourcePos);
    prevCameraPos.current.copy(currentCameraPos);

    // Unit vector from source to receiver (listener)
    const sourceToReceiverDir = currentCameraPos.clone().sub(currentSourcePos).normalize();

    // Project velocity vectors along the line of sight (Vr and Vs)
    const vr = cameraVelocity.dot(sourceToReceiverDir);
    const vs = sourceVelocity.dot(sourceToReceiverDir);

    const speedOfSound = 343; // m/s scale factor
    // Doppler equation: f = f0 * (v + vr) / (v + vs)
    let frequencyRatio = (speedOfSound + vr) / (speedOfSound + vs);
    
    // Clamp to prevent audio distortion boundaries
    frequencyRatio = Math.max(0.2, Math.min(3.0, frequencyRatio));

    // Smoothly apply playback rate modulation
    sourceNodeRef.current.playbackRate.linearRampToValueAtTime(
      frequencyRatio,
      audioContextRef.current!.currentTime + 0.1
    );
  });

  return (
    <mesh ref={meshRef}>
      <boxGeometry args={[1, 1, 2]} />
      <meshStandardMaterial color="orange" />
    </mesh>
  );
};
