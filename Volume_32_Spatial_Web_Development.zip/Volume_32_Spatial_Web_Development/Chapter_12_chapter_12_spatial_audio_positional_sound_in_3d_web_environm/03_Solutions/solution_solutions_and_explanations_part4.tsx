/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef, createContext, useContext } from 'react';
import * as THREE from 'three';

interface AcousticEnvironmentContextType {
  audioContext: AudioContext | null;
  convolverNode: ConvolverNode | null;
  wetGainNode: GainNode | null;
}

const AcousticEnvironmentContext = createContext<AcousticEnvironmentContextType>({
  audioContext: null,
  convolverNode: null,
  wetGainNode: null,
});

export const useAcousticEnvironment = () => useContext(AcousticEnvironmentContext);

interface AcousticEnvironmentProps {
  impulseResponseUrl: string;
  reverbAmount: number;
  roomDimensions: [number, number, number];
  children: React.ReactNode;
}

export const AcousticEnvironment: React.FC<AcousticEnvironmentProps> = ({
  impulseResponseUrl,
  reverbAmount,
  roomDimensions,
  children,
}) => {
  const audioContextRef = useRef<AudioContext | null>(null);
  const convolverRef = useRef<ConvolverNode | null>(null);
  const wetGainRef = useRef<GainNode | null>(null);

  useEffect(() => {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const convolver = ctx.createConvolver();
    convolverRef.current = convolver;

    const wetGain = ctx.createGain();
    wetGain.gain.setValueAtTime(reverbAmount, ctx.currentTime);
    wetGain.connect(ctx.destination);
    wetGainRef.current = wetGain;

    convolver.connect(wetGain);

    // Asynchronously load and decode room impulse response
    fetch(impulseResponseUrl)
      .then((res) => res.arrayBuffer())
      .then((buf) => ctx.decodeAudioData(buf))
      .then((decodedBuffer) => {
        convolver.buffer = decodedBuffer;
      })
      .catch((err) => console.error('Failed to load impulse response file:', err));

    return () => {
      if (ctx.state !== 'closed') ctx.close();
    };
  }, [impulseResponseUrl]);

  // Dynamically update reverb wet/dry send amounts
  useEffect(() => {
    if (wetGainRef.current && audioContextRef.current) {
      wetGainRef.current.gain.setTargetAtTime(
        reverbAmount,
        audioContextRef.current.currentTime,
    }
  }, [reverbAmount]);

  return (
    <AcousticEnvironmentContext.Provider
      value={{
        audioContext: audioContextRef.current,
        convolverNode: convolverRef.current,
        wetGainNode: wetGainRef.current,
      }}
    >
      <group>{children}</group>
    </AcousticEnvironmentContext.Provider>
  );
};
