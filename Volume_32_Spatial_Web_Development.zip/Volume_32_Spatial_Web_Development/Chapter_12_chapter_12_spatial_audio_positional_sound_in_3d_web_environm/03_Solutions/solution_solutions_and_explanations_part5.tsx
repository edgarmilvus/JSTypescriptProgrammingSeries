/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface AudioOcclusionOptimizerProps {
  maxConcurrentSources: number;
  cullDistance: number;
  occlusionMeshRef: React.RefObject<THREE.Object3D>;
  children: React.ReactNode;
}

export const AudioOcclusionOptimizer: React.FC<AudioOcclusionOptimizerProps> = ({
  cullDistance,
  occlusionMeshRef,
  children,
}) => {
  const { camera } = useThree();
  const raycaster = useRef(new THREE.Raycaster());
  const frameCounter = useRef(0);

  useFrame(() => {
    frameCounter.current += 1;
    // Stagger raycast occlusion evaluations every 4 frames to save CPU cycles
    if (frameCounter.current % 4 !== 0) return;

    if (!occlusionMeshRef.current) return;

    const listenerPos = camera.position;
    const obstacles = occlusionMeshRef.current.children;

    // Example optimization loop checking registered nodes in the scene graph
    camera.parent?.traverse((object) => {
      if (object.userData && object.userData.isSpatialAudioSource) {
        const sourcePos = object.position;
        const distance = listenerPos.distanceTo(sourcePos);

        // 1. Distance Culling Optimization
        if (distance > cullDistance) {
          if (object.userData.gainNode) {
            object.userData.gainNode.gain.value = 0; // Mute out-of-range source
          }
          return;
        }

        // 2. Layer-Based Raycasting Occlusion Check
        const dir = sourcePos.clone().sub(listenerPos).normalize();
        raycaster.current.set(listenerPos, dir);
        raycaster.current.far = distance;
        raycaster.current.layers.set(31); // Inspect strictly audio occlusion layer

        const intersections = raycaster.current.intersectObjects(obstacles, true);
        const isOccluded = intersections.length > 0;

        if (object.userData.filterNode) {
          const targetFreq = isOccluded ? 600 : 20000;
          object.userData.filterNode.frequency.value = targetFreq;
        }

        if (object.userData.gainNode) {
          object.userData.gainNode.gain.value = 1.0; // Restore gain if within range
        }
      }
    });
  });

  return <group>{children}</group>;
};
