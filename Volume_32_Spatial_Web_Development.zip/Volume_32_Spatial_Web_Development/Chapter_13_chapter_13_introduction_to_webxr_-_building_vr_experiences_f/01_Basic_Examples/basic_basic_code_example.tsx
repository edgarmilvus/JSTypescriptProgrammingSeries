/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { XR, createXRStore } from '@react-three/xr';
import * as THREE from 'three';

// 1. Initialize the XR Store for state management and session handling in WebXR
const xrStore = createXRStore();

/**
 * 2. Spatial Data Card Component
 * Represents a floating analytics widget in 3D space.
 * Uses useFrame to introduce a subtle idle floating animation.
 */
function SpatialAnalyticsCard() {
  // Reference to the mesh to manipulate its transformation matrix in the render loop
  const meshRef = useRef<THREE.Mesh>(null!);

  // Rotate the card slightly over time to give it a dynamic presence in spatial computing
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.2;
    }
  });

  return (
    <group position={[0, 1.5, -1.5]}>
      {/* Background panel for the SaaS metric card */}
      <mesh ref={meshRef}>
        <planeGeometry args={[0.8, 0.5]} />
        <meshStandardMaterial color="#1e1e2f" roughness={0.4} />
      </mesh>
      
      {/* Indicator light representing active SaaS pipeline status */}
      <mesh position={[-0.3, 0.18, 0.01]}>
        <sphereGeometry args={[0.03, 16, 16]} />
        <meshBasicMaterial color="#00ffcc" />
      </mesh>
    </group>
  );
}

/**
 * 3. Main SaaS Spatial Application Component
 * Sets up the WebGL canvas, lighting, and integrates the XR provider layer.
 */
export default function SaaSWebXRApp() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#05050a' }}>
      {/* UI Overlay button to enter Immersive VR/AR mode */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 1000 }}>
        <button 
          onClick={() => xrStore.enterVR()}
          style={{ padding: '12px 24px', background: '#6200ee', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          Enter Immersive VR
        </button>
      </div>

      {/* R3F Canvas configured with XR Store integration */}
      <Canvas camera={{ position: [0, 1.6, 0] }}>
        <XR store={xrStore}>
          {/* Ambient lighting to softly illuminate the virtual environment */}
          <ambientLight intensity={0.7} />
          
          {/* Directional light casting soft shadows to anchor virtual objects */}
          <directionalLight position={[5, 10, 5]} intensity={1} />
          
          {/* Render our SaaS Spatial Dashboard Component */}
          <SpatialAnalyticsCard />
        </XR>
      </Canvas>
    </div>
  );
}
