/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useRef, useEffect, useMemo } from 'lucide-react'; // Placeholder imports or framework icons
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  XR, 
  createXRStore, 
  useXR, 
  useController, 
  useHand,
  TeleportationArea,
  Interactive 
} from '@react-three/xr';
import * as THREE from 'three';
import { Html, Text, OrbitControls } from '@react-three/drei';

/**
 * Interface representing a configurable product variant within our spatial e-commerce suite.
 */
interface ProductVariant {
  id: string;
  name: string;
  color: string;
  price: number;
  roughness: number;
  metalness: number;
}

/**
 * Props for the InteractiveProduct component.
 */
interface InteractiveProductProps {
  variant: ProductVariant;
  onSelect: (variant: ProductVariant) => void;
}

/**
 * XR Store initialization for managing WebXR sessions (VR/AR) across platforms
 * like Meta Quest browsers and Safari visionOS environments.
 */
const xrStore = createXRStore({
  // Configure features required by the immersive session
  controller: true,
  hand: true,
});

/**
 * The 3D Product Mesh component that responds to XR controller rays, 
 * hand pinches, and hover states.
 */
function InteractiveProduct({ variant, onSelect }: InteractiveProductProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState<boolean>(false);
  const [active, setActive] = useState<boolean>(false);

  // Smoothly animate the product rotation and scale based on interaction state
  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    // Gentle floating idle animation
    meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.05 + 1.2;
    
    // Scale up slightly when hovered or grabbed
    const targetScale = hovered || active ? 1.15 : 1.0;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), delta * 10);
    
    // Continuous slow rotation if not actively manipulated
    if (!active) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  return (
    <group position={[0, 0, -1.5]}>
      <Interactive
        onHover={() => setHovered(true)}
        onBlur={() => setHovered(false)}
        onSelectStart={() => {
          setActive(true);
          onSelect(variant);
        }}
        onSelectEnd={() => setActive(false)}
      >
        <mesh ref={meshRef} castShadow receiveShadow>
          {/* Complex geometry representing an enterprise product */}
          <icosahedronGeometry args={[0.4, 2]} />
          <meshStandardMaterial 
            color={variant.color} 
            roughness={variant.roughness}
            metalness={variant.metalness}
            emissive={hovered ? '#222222' : '#000000'}
          />
        </mesh>
      </Interactive>
      
      {/* Spatial Label anchored directly above the 3D asset */}
      <Text
        position={[0, 0.7, 0]}
        fontSize={0.08}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {variant.name} - ${variant.price}
      </Text>
    </group>
  );
}

/**
 * Spatial UI Panel rendered in 3D space, allowing users to switch variants 
 * using spatial controllers or hand pinching.
 */
function SpatialConfiguratorPanel({ 
  variants, 
  currentVariant, 
  onVariantChange 
}: { 
  variants: ProductVariant[]; 
  currentVariant: ProductVariant; 
  onVariantChange: (v: ProductVariant) => void; 
}) {
  return (
    <group position={[0.8, 1.2, -1.2]} rotation={[0, -Math.PI / 6, 0]}>
      {/* HTML component maps DOM nodes into the WebXR scene via CSS3DRenderer/Planes */}
      <Html transform distanceFactor={1.2} okul-events>
        <div className="bg-slate-900/95 text-white p-6 rounded-2xl shadow-2xl backdrop-blur-md w-72 border border-slate-700">
          <h3 className="text-lg font-bold mb-3 flex items-center justify-between">
            <span>Product Configurator</span>
            <span className="text-xs bg-indigo-500 px-2 py-0.5 rounded-full">Spatial WebXR</span>
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Select a finish below to update the enterprise asset in real-time.
          </p>
          <div className="flex flex-col gap-2">
            {variants.map((v) => (
              <button
                key={v.id}
                onClick={() => onVariantChange(v)}
                className={`flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  currentVariant.id === v.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 ring-2 ring-indigo-400' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{v.name}</span>
                <span className="w-4 h-4 rounded-full border border-white/20" style={{ backgroundColor: v.color }} />
              </button>
            ))}
          </div>
        </div>
      </Html>
    </group>
  );
}

/**
 * Main Experience Component containing the Canvas, lighting, and XR hooks.
 */
export default function XRProductShowcaseApp() {
  const [variants] = useState<ProductVariant[]>([
    { id: '1', name: 'Titanium Matte', color: '#878a8f', price: 1299, roughness: 0.2, metalness: 0.9 },
    { id: '2', name: 'Obsidian Black', color: '#1a1a1a', price: 1399, roughness: 0.1, metalness: 0.95 },
    { id: '3', name: 'Champagne Gold', color: '#d4af37', price: 1499, roughness: 0.3, metalness: 0.8 },
  ]);
  
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(variants[0]);

  return (
    <div className="w-full h-screen relative bg-slate-950">
      {/* Traditional DOM Overlay for non-XR browsers or session launchers */}
      <div className="absolute top-6 left-6 z-50 flex flex-col gap-4">
        <h1 className="text-2xl font-black text-white tracking-tight">
          Spatial Commerce Engine <span className="text-indigo-400">XR</span>
        </h1>
        <button
          onClick={() => xrStore.enterVR()}
          className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold px-6 py-3 rounded-xl shadow-xl hover:opacity-90 transition-all flex items-center gap-3 w-fit"
        >
          <span>Launch Immersive VR Session</span>
        </button>
      </div>

      {/* R3F Canvas with WebXR Store Integration */}
      <Canvas 
        shadows 
        camera={{ position: [0, 1.6, 2], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
      >
        <XR store={xrStore}>
          {/* Environment Lighting */}
          <ambientLight intensity={0.7} />
          <directionalLight 
            position={[5, 8, 5]} 
            intensity={1.5} 
            castShadow 
            shadow-mapSize={[1024, 1024]} 
          />
          <hemisphereLight intensity={0.4} groundColor="#111111" />

          {/* Core Scene Elements */}
          <InteractiveProduct variant={selectedVariant} onSelect={setSelectedVariant} />
          <SpatialConfiguratorPanel 
            variants={variants} 
            currentVariant={selectedVariant} 
            onVariantChange={setSelectedVariant} 
          />

          {/* Ground Plane and Teleportation Target Area */}
          <TeleportationArea>
            <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow position={[0, 0, 0]}>
              <planeGeometry args={[20, 20]} />
              <meshStandardMaterial color="#0b0f19" roughness={0.9} metalness={0.1} />
            </mesh>
          </TeleportationArea>

          {/* Desktop fallback controls when not in an active WebXR session */}
          <OrbitControls makeDefault enablePan={false} maxPolarAngle={Math.PI / 2 - 0.05} />
        </XR>
      </Canvas>
    </div>
  );
}
