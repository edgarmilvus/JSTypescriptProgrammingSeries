/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { XR, createXRStore } from '@react-three/xr';

// Initialize the XR store with required features for Quest and Vision Pro
const xrStore = createXRStore({
  requiredFeatures: ['local-floor'],
  optionalFeatures: ['hand-tracking', 'hit-test'],
});

interface ImmersiveExperienceCanvasProps {
  children: React.ReactNode;
  onSessionStart?: () => void;
  onSessionEnd?: () => void;
}

export const ImmersiveExperienceCanvas: React.FC<ImmersiveExperienceCanvasProps> = ({
  children,
  onSessionStart,
  onSessionEnd,
}) => {
  const [isSupported, setIsSupported] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isInVR, setIsInVR] = useState<boolean>(false);

  useEffect(() => {
    // Check if WebXR is supported by the browser
    if ('xr' in navigator) {
      navigator.xr
        ?.isSessionSupported('immersive-vr')
        .then((supported) => {
          setIsSupported(supported);
          if (!supported) {
            setErrorMessage('Immersive VR is not supported on this browser or device.');
          }
        })
        .catch(() => {
          setIsSupported(false);
          setErrorMessage('Failed to query WebXR session support.');
        });
    } else {
      setIsSupported(false);
      setErrorMessage('WebXR API is not available in this environment (Insecure context or unsupported browser).');
    }

    // Listen to store events for session tracking if supported by store subscription
    const unsubscribeStart = xrStore.subscribe((state) => {
      if (state.session && !isInVR) {
        setIsInVR(true);
        onSessionStart?.();
        window.dispatchEvent(new CustomEvent('xr-session-change', { detail: { active: true } }));
      } else if (!state.session && isInVR) {
        setIsInVR(false);
        onSessionEnd?.();
        window.dispatchEvent(new CustomEvent('xr-session-change', { detail: { active: false } }));
      }
    });

    return () => {
      unsubscribeStart();
    };
  }, [isInVR, onSessionStart, onSessionEnd]);

  const handleEnterVR = async () => {
    try {
      setErrorMessage(null);
      // Explicitly request session entry via the store
      await xrStore.enterVR();
    } catch (error) {
      console.error('Error starting WebXR session:', error);
      setErrorMessage('Could not start VR session. Ensure you are using HTTPS and have granted permissions.');
    }
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', background: '#111' }}>
      <Canvas>
        <XR store={xrStore}>{children}</XR>
      </Canvas>

      {/* Custom UI Overlay & Fallback */}
      <div
        style={{
          position: 'absolute',
          bottom: '30px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 1000,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '12px',
          fontFamily: 'sans-serif',
        }}
      >
        {isSupported === false ? (
          <div style={{ background: '#ff4d4f', color: '#fff', padding: '12px 24px', borderRadius: '8px' }}>
            {errorMessage || 'VR Not Supported'}
          </div>
        ) : (
          <button
            onClick={handleEnterVR}
            style={{
              background: '#4f46e5',
              color: '#white',
              border: 'none',
              padding: '14px 28px',
              fontSize: '16px',
              fontWeight: 'bold',
              borderRadius: '30px',
              cursor: 'pointer',
              boxShadow: '0 4px 14px rgba(79, 70, 229, 0.4)',
              transition: 'background 0.2s',
            }}
          >
            {isSupported === null ? 'Checking VR Support...' : 'Enter Immersive VR'}
          </button>
        )}

        {errorMessage && isSupported !== false && (
          <div style={{ background: '#ffa940', color: '#111', padding: '8px 16px', borderRadius: '6px', fontSize: '14px' }}>
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};
