/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { useFrame, ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

interface TeleportationFloorProps {
  onTeleport: (newPosition: [number, number, number]) => void;
  restrictedZones?: THREE.Vector3[];
}

export const TeleportationFloor: React.FC<TeleportationFloorProps> = ({
  onTeleport,
  restrictedZones = [],
}) => {
  const [hoverPoint, setHoverPoint] = useState<THREE.Vector3 | null>(null);
  const [isRestricted, setIsRestricted] = useState<boolean>(false);
  const reticleRef = useRef<THREE.Mesh>(null);

  // Check if intersection point is within any restricted zone radius
  const checkRestriction = (point: THREE.Vector3) => {
    return restrictedZones.some((zone) => zone.distanceTo(point) < 1.5);
  };

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    const point = e.point;
    setHoverPoint(point);

    const restricted = checkRestriction(point);
    setIsRestricted(restricted);

    if (reticleRef.current) {
      reticleRef.current.position.copy(point);
      reticleRef.current.position.y += 0.01; // Lift slightly above floor to prevent z-fighting
    }
  };

  const handlePointerOut = () => {
    setHoverPoint(null);
  };

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    if (hoverPoint && !isRestricted) {
      onTeleport([hoverPoint.x, hoverPoint.y, hoverPoint.z]);
    } else if (isRestricted) {
      // Trigger haptic feedback simulation or warning logic here
      console.warn('Teleportation blocked: Restricted zone.');
    }
  };

  return (
    <>
      {/* Teleportation Floor Mesh */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        onPointerMove={handlePointerMove}
        onPointerOut={handlePointerOut}
        onPointerDown={handlePointerDown}
      >
        <planeGeometry args={[50, 50, 32, 32]} />
        <meshStandardMaterial color="#222" wireframe />
      </mesh>

      {/* Dynamic Visual Reticle */}
      {hoverPoint && (
        <mesh ref={reticleRef} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.2, 0.3, 32]} />
          <meshBasicMaterial color={isRestricted ? '#ef4444' : '#10b981'} side={THREE.DoubleSide} />
        </mesh>
      )}
    </>
  );
};
