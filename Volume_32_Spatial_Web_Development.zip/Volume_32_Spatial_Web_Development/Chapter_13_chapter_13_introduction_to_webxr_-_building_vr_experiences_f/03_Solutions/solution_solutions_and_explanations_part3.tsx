/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useXRHandState } from '@react-three/xr';
import * as THREE from 'three';

interface HandGestureResponderProps {
  onPinchStart: (position: [number, number, number]) => void;
  onPinchEnd?: () => void;
  threshold?: number;
}

interface ParticleEmitter {
  id: number;
  position: [number, number, number];
}

export const HandGestureResponder: React.FC<HandGestureResponderProps> = ({
  onPinchStart,
  onPinchEnd,
  threshold = 0.025, // 2.5 centimeters
}) => {
  const rightHand = useXRHandState('right');
  const [emitters, setEmitters] = useState<ParticleEmitter[]>([]);
  const isPinchingRef = useRef<boolean>(false);
  const pinchTimeAccumulator = useRef<number>(0);
  const REQUIRED_DURATION = 300; // ms

  useFrame((state, delta) => {
    if (!rightHand || !rightHand.joints) return;

    const indexTip = rightHand.joints['index-finger-tip'];
    const thumbTip = rightHand.joints['thumb-tip'];
    const wrist = rightHand.joints['wrist'];

    if (!indexTip || !thumbTip) return;

    const indexPos = new THREE.Vector3().setFromMatrixPosition(indexTip.matrixWorld);
    const thumbPos = new THREE.Vector3().setFromMatrixPosition(thumbTip.matrixWorld);

    const distance = indexPos.distanceTo(thumbPos);

    // Check Open Palm Gesture for Challenge Requirement
    if (wrist) {
      const wristPos = new THREE.Vector3().setFromMatrixPosition(wrist.matrixWorld);
      const fingertips = ['index-finger-tip', 'middle-finger-tip', 'ring-finger-tip', 'pinky-finger-tip'];
      let extendedCount = 0;
      
      fingertips.forEach((jointName) => {
        const joint = rightHand.joints[jointName];
        if (joint) {
          const pos = new THREE.Vector3().setFromMatrixPosition(joint.matrixWorld);
          if (pos.distanceTo(wristPos) > 0.12) extendedCount++;
        }
      });

      if (extendedCount >= 4) {
        // Clear all active emitters on open palm recognition
        setEmitters([]);
      }
    }

    // Pinch detection with time accumulator
    if (distance < threshold) {
      pinchTimeAccumulator.current += delta * 1000;

      if (pinchTimeAccumulator.current >= REQUIRED_DURATION && !isPinchingRef.current) {
        isPinchingRef.current = true;
        const midpoint: [number, number, number] = [
          (indexPos.x + thumbPos.x) / 2,
          (indexPos.y + thumbPos.y) / 2,
          (indexPos.z + thumbPos.z) / 2,
        ];
        onPinchStart(midpoint);
        setEmitters((prev) => [...prev, { id: Date.now(), position: midpoint }]);
      }
    } else {
      if (isPinchingRef.current) {
        isPinchingRef.current = false;
        onPinchEnd?.();
      }
      pinchTimeAccumulator.current = 0;
    }
  });

  return (
    <group>
      {emitters.map((emitter) => (
        <mesh key={emitter.id} position={emitter.position}>
          <sphereGeometry args={[0.015, 16, 16]} />
          <meshBasicMaterial color="#38bdf8" />
        </mesh>
      ))}
    </group>
  );
};
