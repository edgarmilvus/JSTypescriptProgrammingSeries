/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useMemo, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface OptimizedGallerySceneProps {
  pillarCount?: number;
}

export const OptimizedGalleryScene: React.FC<OptimizedGallerySceneProps> = ({ pillarCount = 50 }) => {
  const instancedMeshRef = useRef<THREE.InstancedMesh>(null);
  const { gl } = useThree();
  const fpsAccumulator = useRef<{ frames: number; time: number }>({ frames: 0, time: 0 });

  // 1. Setup Instanced Matrices for Pillars to minimize draw calls
  useEffect(() => {
    if (!instancedMeshRef.current) return;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < pillarCount; i++) {
      const x = (i % 10) * 3 - 15;
      const z = Math.floor(i / 10) * 3 - 15;
      dummy.position.set(x, 1, z);
      dummy.updateMatrix();
      instancedMeshRef.current.setMatrixAt(i, dummy.matrix);
    }
    instancedMeshRef.current.instanceMatrix.needsUpdate = true;
  }, [pillarCount]);

  // 2. Performance Monitoring & Dynamic Resolution Scaling
  useFrame((state, delta) => {
    fpsAccumulator.current.frames++;
    fpsAccumulator.current.time += delta;

    if (fpsAccumulator.current.time >= 1.0) {
      const currentFps = fpsAccumulator.current.frames / fpsAccumulator.current.time;
      
      // If FPS drops below 65, lower pixel ratio dynamically
      if (currentFps < 65) {
        const currentPixelRatio = gl.getPixelRatio();
        if (currentPixelRatio > 0.75) {
          gl.setPixelRatio(Math.max(currentPixelRatio - 0.25, 0.5));
          console.warn(`Low FPS detected (${currentFps.toFixed(1)}). Reducing renderer pixel ratio for performance.`);
        }
      }
      
      fpsAccumulator.current.frames = 0;
      fpsAccumulator.current.time = 0;
    }
  });

  // Optimized geometries with bounding spheres for culling
  const pillarGeometry = useMemo(() => {
    const geom = new THREE.CylinderGeometry(0.2, 0.2, 2, 8);
    geom.computeBoundingSphere();
    return geom;
  }, []);

  return (
    <group>
      {/* Instanced Decorative Pillars */}
      <instancedMesh
        ref={instancedMeshRef}
        args={[pillarGeometry, undefined, pillarCount]}
        frustumCulled={true}
      >
        <meshStandardMaterial color="#475569" roughness={0.4} />
      </instancedMesh>
    </group>
  );
};
