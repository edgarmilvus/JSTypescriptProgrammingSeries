/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { ARButton, XR, useXR } from '@react-three/xr';
import * as THREE from 'three';

/**
 * Interface for the placed object's state coordinate mapping.
 */
interface PlacedObjectState {
  position: [number, number, number];
  rotation: [number, number, number];
}

/**
 * Reticle component that tracks real-world surfaces via WebXR hit-testing.
 * It provides visual feedback to the user on where the 3D asset can be placed.
 */
function ARHitTestReticle({ onSelect }: { onSelect: (position: THREE.Vector3, rotation: THREE.Euler) => void }) {
  const reticleRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();
  const { session } = useXR();

  // Reference variables to persist hit-test source across animation frames
  const hitTestSourceRef = useRef<XRHitTestSource | null>(null);
  const hitTestSourceRequestedRef = useRef<boolean>(false);

  useEffect(() => {
    if (!session) {
      hitTestSourceRequestedRef.current = false;
      hitTestSourceRef.current = null;
      return;
    }

    // Request the hit-test source asynchronously from the XR session
    const requestHitTestSource = async () => {
      try {
        const viewerSpace = await session.requestReferenceSpace('viewer');
        const source = await session.requestHitTestSource!({ space: viewerSpace });
        hitTestSourceRef.current = source;
      } catch (err) {
        console.error('Failed to acquire WebXR Hit-Test Source:', err);
      }
    };

    requestHitTestSource();
  }, [session]);

  // Execute per-frame logic to query hit test results and update reticle matrix
  useFrame((state, delta, xrFrame) => {
    if (!xrFrame || !hitTestSourceRef.current || !reticleRef.current) return;

    const referenceSpace = gl.xr.getReferenceSpace();
    if (!referenceSpace) return;

    const hitTestResults = xrFrame.getHitTestResults(hitTestSourceRef.current);

    if (hitTestResults.length > 0) {
      const hit = hitTestResults[0];
      const pose = hit.getPose(referenceSpace);

      if (pose) {
        reticleRef.current.visible = true;
        reticleRef.current.matrix.fromArray(pose.transform.matrix);
      }
    } else {
      reticleRef.current.visible = false;
    }
  });

  // Handle user screen tap events to place the virtual object
  useEffect(() => {
    if (!session) return;

    const handleSelect = (event: XRInputSourceEvent) => {
      if (reticleRef.current && reticleRef.current.visible) {
        const position = new THREE.Vector3();
        const quaternion = new THREE.Quaternion();
        const scale = new THREE.Vector3();

        // Decompose the reticle transformation matrix into world coordinates
        reticleRef.current.matrix.decompose(position, quaternion, scale);
        const rotation = new THREE.Euler().setFromQuaternion(quaternion);

        onSelect(position, rotation);
      }
    };

    session.addEventListener('select', handleSelect);
    return () => {
      session.removeEventListener('select', handleSelect);
    };
  }, [session, onSelect]);

  return (
    <mesh ref={reticleRef} matrixAutoUpdate={false}>
      {/* A ring geometry acting as a surface targeting reticle */}
      <ringGeometry args={[0.1, 0.15, 32]} />
      <meshBasicMaterial color={0xffffff} side={THREE.DoubleSide} />
    </mesh>
  );
}

/**
 * The Virtual Desk 3D Model that gets instantiated upon user selection.
 */
function VirtualDesk({ position, rotation }: PlacedObjectState) {
  const meshRef = useRef<THREE.Group>(null);

  return (
    <group ref={meshRef} position={position} rotation={rotation}>
      {/* Desk Surface Tabletop */}
      <mesh position={[0, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.2, 0.05, 0.6]} />
        <meshStandardMaterial color="#8b5a2b" roughness={0.4} />
      </mesh>
      {/* Front Left Leg */}
      <mesh position={[-0.55, 0.375, 0.25]} castShadow>
        <cylinderGeometry args={[0.03, 0.03, 0.75]} />
        <meshStandardMaterial color="#333333" metalness={0.8} />
      </mesh>
      {/* Front Right Leg */}
      <mesh position={[0.55, 0.375, 0.25]} castShadow>
        <cylinderGeometry args={[0.03, 0.03, 0.75]} />
        <meshStandardMaterial color="#333333" metalness={0.8} />
      </mesh>
      {/* Back Left Leg */}
      <mesh position={[-0.55, 0.375, -0.25]} castShadow>
        <cylinderGeometry args={[0.03, 0.03, 0.75]} />
        <meshStandardMaterial color="#333333" metalness={0.8} />
      </mesh>
      {/* Back Right Leg */}
      <mesh position={[0.55, 0.375, -0.25]} castShadow>
        <cylinderGeometry args={[0.03, 0.03, 0.75]} />
        <meshStandardMaterial color="#333333" metalness={0.8} />
      </mesh>
    </group>
  );
}

/**
 * Main SaaS E-commerce AR Application Component.
 */
export default function AugmentedRealityApp() {
  const [placedObjects, setPlacedObjects] = useState<Array<{ id: string; position: [number, number, number]; rotation: [number, number, number] }>>([]);

  // Callback executed when user taps the screen to place an object at the reticle position
  const handleObjectPlacement = (position: THREE.Vector3, rotation: THREE.Euler) => {
    const newObject = {
      id: Math.random().toString(36.substring(2, 9)),
      position: [position.x, position.y, position.z] as [number, number, number],
      rotation: [rotation.x, rotation.y, rotation.z] as [number, number, number],
    };
    setPlacedObjects((prev) => [...prev, newObject]);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      {/* WebXR AR Initialization Button provided by @react-three/xr */}
      <div style={{ position: 'absolute', bottom: '20px', left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}>
        <ARButton
          sessionInit={{
            requiredFeatures: ['hit-test', 'dom-overlay'],
            optionalFeatures: ['light-estimation', 'depth-sensing'],
            domOverlay: { root: document.body },
          }}
        />
      </div>

      <Canvas shadows>
        <XR>
          <ambientLight intensity={0.7} />
          <directionalLight position={[5, 10, 5]} intensity={1.5} castShadow />

          {/* Hit test reticle guiding the user */}
          <ARHitTestReticle onSelect={handleObjectPlacement} />

          {/* Render all user-placed physical furniture items */}
          {placedObjects.map((obj) => (
            <VirtualDesk key={obj.id} position={obj.position} rotation={obj.rotation} />
          ))}
        </XR>
      </Canvas>
    </div>
  );
}
