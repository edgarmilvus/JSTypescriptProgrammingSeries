/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use type';

import React, { useState, useRef, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { ARButton, XR, Controllers, Hands, useHitTest, useXR } from '@react-three/xr';
import { Html, useGLTF } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface defining the properties for the placed 3D asset.
 */
interface PlacedAssetProps {
  position: [number, number, number];
  rotation: [number, number, number];
  modelUrl: string;
}

/**
 * Renders the 3D model at the user-specified anchor point in AR space.
 */
function PlacedAsset({ position, rotation, modelUrl }: PlacedAssetProps) {
  // Load the GLTF asset safely using Drei's hook
  const { scene } = useGLTF(modelUrl);
  const modelRef = useRef<THREE.Group>(null);

  return (
    <group ref={modelRef} position={position} rotation={rotation}>
      <primitive object={scene.clone()} scale={[0.5, 0.5, 0.5]} />
    </group>
  );
}

/**
 * Reticle component that tracks real-world surfaces via WebXR hit-testing.
 * Users tap or click to spawn an asset at the current reticle position.
 */
interface InteractiveHitTestProps {
  modelUrl: string;
  onPlaceAsset: (position: [number, number, number], rotation: [number, number, number]) => void;
}

function InteractiveHitTest({ modelUrl, onPlaceAsset }: InteractiveHitTestProps) {
  const reticleRef = useRef<THREE.Mesh>(null);
  const [isHitValid, setIsHitValid] = useState<boolean>(false);
  
  // Track if the XR session is currently active
  const { session } = useXR();

  /**
   * useHitTest hook provided by @react-three/xr.
   * Runs every frame during an active XR session, performing raycasting against detected planes.
   */
  useHitTest((hitMatrix, hitPose) => {
    if (!reticleRef.current) return;

    // Copy the hit matrix position and orientation directly to our reticle mesh
    reticleRef.current.matrix.copy(hitMatrix);
    reticleRef.current.matrix.decompose(
      reticleRef.current.position,
      reticleRef.current.quaternion,
      reticleRef.current.scale
    );

    // Ensure the reticle is visible once a valid plane hit is recorded
    if (!isHitValid) {
      setIsHitValid(true);
      reticleRef.current.visible = true;
    }
  });

  /**
   * Handles user input (screen tap or controller trigger) to place the asset.
   */
  const handleSelect = () => {
    if (!reticleRef.current || !isHitValid) return;

    const position: [number, number, number] = [
      reticleRef.current.position.x,
      reticleRef.current.position.y,
      reticleRef.current.position.z,
    ];

    const rotation: [number, number, number] = [
      reticleRef.current.rotation.x,
      reticleRef.current.rotation.y,
      reticleRef.current.rotation.z,
    ];

    onPlaceAsset(position, rotation);
  };

  return (
    <>
      {/* Visual Reticle pointing to the detected surface */}
      <mesh
        ref={reticleRef}
        rotation={[-Math.PI / 2, 0, 0]}
        visible={false}
        onPointerDown={handleSelect}
      >
        <ringGeometry args={[0.1, 0.15, 32]} />
        <meshBasicMaterial color={isHitValid ? '#00ffcc' : '#ff0033'} side={THREE.DoubleSide} />
      </mesh>
    </>
  );
}

/**
 * Main Application Component managing AR state and UI overlays.
 */
export default function SpatialApp() {
  const [placedAssets, setPlacedAssets] = useState<
    Array<{ id: string; position: [number, number, number]; rotation: [number, number, number] }>
  >([]);
  const [selectedModel] = useState<string>('/models/chair.glb');

  const handlePlaceAsset = (
    position: [number, number, number],
    rotation: [number, number, number]
  ) => {
    const newAsset = {
      id: Math.random().toString(36.2),
      position,
      rotation,
    };
    setPlacedAssets((prev) => [...prev, newAsset]);
  };

  return (
    <div className="relative w-full h-screen bg-gray-900 text-white">
      {/* DOM Overlay UI for Non-XR or In-Session controls */}
      <div className="absolute top-4 left-4 z-50 flex flex-col gap-2 bg-black/60 p-4 rounded-xl backdrop-blur-md">
        <h1 className="text-lg font-bold">Spatial Web E-Commerce</h1>
        <p className="text-sm text-gray-300">Point your device at the floor and tap to place.</p>
        <ARButton
          sessionInit={{
            requiredFeatures: ['hit-test', 'dom-overlay'],
            optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'],
            domOverlay: { root: document.getElementById('ar-ui-overlay')! },
          }}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-medium transition-colors"
        />
      </div>

      {/* DOM Overlay Root Container */}
      <div id="ar-ui-overlay" className="absolute inset-0 pointer-events-none">
        {/* Interactive UI elements rendered inside the immersive AR stream go here */}
      </div>

      {/* React Three Fiber Canvas configured for WebXR */}
      <Canvas className="w-full h-full">
        <XR>
          <ambientLight intensity={0.7} />
          <directionalLight position={[5, 10, 5]} intensity={1} />

          <Suspense fallback={<Html center>Loading 3D Engine...</Html>}>
            {/* Hit Test and Placement Controller */}
            <InteractiveHitTest modelUrl={selectedModel} onPlaceAsset={handlePlaceAsset} />

            {/* Render all placed assets in the spatial scene */}
            {placedAssets.map((asset) => (
              <PlacedAsset
                key={asset.id}
                position={asset.position}
                rotation={asset.rotation}
                modelUrl={selectedModel}
              />
            ))}
          </Suspense>

          <Controllers />
          <Hands />
        </XR>
      </Canvas>
    </div>
  );
}
