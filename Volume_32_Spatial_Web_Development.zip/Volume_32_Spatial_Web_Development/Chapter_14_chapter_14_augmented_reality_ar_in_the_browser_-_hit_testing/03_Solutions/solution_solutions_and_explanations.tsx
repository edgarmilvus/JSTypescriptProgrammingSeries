/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';

interface ARSessionInitializerProps {
  domOverlayElementId: string;
  onSessionStarted: (session: XRSession) => void;
  onSessionEnded: () => void;
}

export const ARSessionInitializer: React.FC<ARSessionInitializerProps> = ({
  domOverlayElementId,
  onSessionStarted,
  onSessionEnded
}) => {
  const [isSupported, setIsSupported] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && navigator.xr) {
      navigator.xr.isSessionSupported('immersive-ar')
        .then((supported) => {
          setIsSupported(supported);
        })
        .catch(() => {
          setIsSupported(false);
        });
    } else {
      setIsSupported(false);
    }
  }, []);

  const handleStartARSession = async () => {
    if (!navigator.xr) return;

    try {
      setIsInitializing(true);
      setErrorMessage(null);

      const overlayElement = document.getElementById(domOverlayElementId);
      if (!overlayElement) {
        throw new Error(`DOM overlay element with ID "${domOverlayElementId}" not found.`);
      }

      const session = await navigator.xr.requestSession('immersive-ar', {
        requiredFeatures: ['hit-test', 'dom-overlay'],
        domOverlay: { root: overlayElement }
      });

      session.addEventListener('end', () => {
        setIsInitializing(false);
        onSessionEnded();
      });

      onSessionStarted(session);
    } catch (error: any) {
      console.error('Failed to start AR session:', error);
      setErrorMessage(error.message || 'Could not start AR session.');
      setIsInitializing(false);
    }
  };

  if (isSupported === null) {
    return <div className="ar-status">Checking WebXR compatibility...</div>;
  }

  if (!isSupported) {
    return (
      <div className="ar-unsupported">
        <p>Augmented Reality (WebXR immersive-ar) is not supported on this device or browser.</p>
        <p>Please open this link on an AR-compatible mobile device (e.g., Android with Google Play Services for AR).</p>
      </div>
    );
  }

  return (
    <div id="ar-initializer-root">
      <button 
        onClick={handleStartARSession} 
        disabled={isInitializing}
        className="ar-start-button"
      >
        {isInitializing ? 'Initializing AR...' : 'Start AR Experience'}
      </button>
      {errorMessage && <p className="ar-error">{errorMessage}</p>}
    </div>
  );
};
