/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useXR } from '@react-three/xr';
import * as THREE from 'three';

export const ARPlacementReticle: React.FC = () => {
  const reticleRef = useRef<THREE.Group>(null);
  const { session } = useXR();
  const [hitDetected, setHitDetected] = useState(false);

  const hitTestSourceRef = useRef<XRHitTestSource | null>(null);
  const hitTestSourceRequestedRef = useRef<boolean>(false);

  useEffect(() => {
    if (!session) {
      hitTestSourceRequestedRef.current = false;
      hitTestSourceRef.current = null;
      setHitDetected(false);
      return;
    }

    let isCancelled = false;

    session.requestReferenceSpace('viewer').then((viewerSpace) => {
      if (isCancelled) return;
      session.requestHitTestSource({ space: viewerSpace }).then((source) => {
        if (!isCancelled) {
          hitTestSourceRef.current = source;
        }
      });
    });

    return () => {
      isCancelled = true;
      hitTestSourceRef.current = null;
    };
  }, [session]);

  useFrame((state, delta, frame) => {
    if (!frame || !hitTestSourceRef.current || !reticleRef.current) return;

    const referenceSpace = state.gl.xr.getReferenceSpace();
    if (!referenceSpace) return;

    const hitResults = frame.getHitTestResults(hitTestSourceRef.current);

    if (hitResults.length > 0) {
      const hit = hitResults[0];
      const pose = hit.getPose(referenceSpace);

      if (pose) {
        setHitDetected(true);
        reticleRef.current.visible = true;
        reticleRef.current.matrix.fromArray(pose.transform.matrix);
        reticleRef.current.matrix.decompose(
          reticleRef.current.position,
          reticleRef.current.quaternion,
          reticleRef.current.scale
        );
        return;
      }
    }

    setHitDetected(false);
    reticleRef.current.visible = false;
  });

  return (
    <group ref={reticleRef} visible={hitDetected}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.1, 0.12, 32]} />
        <meshBasicMaterial color={'white'} side={THREE.DoubleSide} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.015, 32]} />
        <meshBasicMaterial color={'royalblue'} />
      </mesh>
    </group>
  );
};
