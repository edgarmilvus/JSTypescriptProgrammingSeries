/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { useXR } from '@react-three/xr';
import * as THREE from 'three';

interface PlacedAsset {
  id: string;
  position: [number, number, number];
  rotation: [number, number, number, number];
}

interface ARPlacementManagerProps {
  reticleRef: React.RefObject<THREE.Group>;
  assetComponent: React.ComponentType<{ position: [number, number, number]; quaternion: THREE.Quaternion }>;
}

export const ARPlacementManager: React.FC<ARPlacementManagerProps> = ({
  reticleRef,
  assetComponent: AssetComponent
}) => {
  const [placedAssets, setPlacedAssets] = useState<PlacedAsset[]>([]);
  const { session } = useXR();
  const lastSpawnTimeRef = useRef<number>(0);

  useEffect(() => {
    if (!session) return;

    const handleSelect = (event: XRInputSourceEvent) => {
      if (!reticleRef.current || !reticleRef.current.visible) return;

      const now = performance.now();
      if (now - lastSpawnTimeRef.current < 300) return; // 300ms debounce
      lastSpawnTimeRef.current = now;

      const worldPosition = new THREE.Vector3();
      const worldQuaternion = new THREE.Quaternion();
      const worldScale = new THREE.Vector3();

      reticleRef.current.matrixWorld.decompose(worldPosition, worldQuaternion, worldScale);

      const newAsset: PlacedAsset = {
        id: Math.random().toString(36.2, 9),
        position: [worldPosition.x, worldPosition.y, worldPosition.z],
        rotation: [worldQuaternion.x, worldQuaternion.y, worldQuaternion.z, worldQuaternion.w]
      };

      setPlacedAssets((prev) => [...prev, newAsset]);
    };

    session.addEventListener('select', handleSelect);
    return () => {
      session.removeEventListener('select', handleSelect);
    };
  }, [session, reticleRef]);

  return (
    <>
      {placedAssets.map((asset) => (
        <AssetComponent 
          key={asset.id} 
          position={asset.position} 
          quaternion={new THREE.Quaternion(...asset.rotation)} 
        />
      ))}
    </>
  );
};
