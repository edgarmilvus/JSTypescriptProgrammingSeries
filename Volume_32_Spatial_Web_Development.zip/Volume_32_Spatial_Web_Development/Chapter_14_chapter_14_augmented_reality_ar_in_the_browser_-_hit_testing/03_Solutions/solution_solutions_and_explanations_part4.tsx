/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useXR } from '@react-three/xr';
import * as THREE from 'three';

export const ARLightingAndDepthManager: React.FC = () => {
  const directionalLightRef = useRef<THREE.DirectionalLight>(null);
  const ambientLightRef = useRef<THREE.AmbientLight>(null);
  const { session } = useXR();
  
  const lightProbeRef = useRef<XRLightProbe | null>(null);

  useEffect(() => {
    if (!session) return;

    let isMounted = true;

    if ('requestLightProbe' in session) {
      (session as any).requestLightProbe({ reflectionFormat: 'srgba8' }).then((probe: XRLightProbe) => {
        if (isMounted) {
          lightProbeRef.current = probe;
        }
      }).catch((err: any) => {
        console.warn('Light estimation not supported or denied:', err);
      });
    }

    return () => {
      isMounted = false;
      lightProbeRef.current = null;
    };
  }, [session]);

  useFrame((state, delta, frame) => {
    if (!frame) return;

    const referenceSpace = state.gl.xr.getReferenceSpace();
    if (!referenceSpace) return;

    if (lightProbeRef.current && (frame as any).getLightEstimate) {
      const lightEstimate = (frame as any).getLightEstimate(lightProbeRef.current);
      if (lightEstimate && directionalLightRef.current && ambientLightRef.current) {
        const primaryDirection = lightEstimate.primaryLightDirection;
        const primaryIntensity = lightEstimate.primaryLightIntensity;

        if (primaryDirection) {
          directionalLightRef.current.position.set(
            primaryDirection.x,
            primaryDirection.y,
            primaryDirection.z
          );
        }

        if (primaryIntensity) {
          const maxChannel = Math.max(primaryIntensity.x, primaryIntensity.y, primaryIntensity.z, 1.0);
          directionalLightRef.current.intensity = maxChannel;
          directionalLightRef.current.color.setRGB(
            primaryIntensity.x / maxChannel,
            primaryIntensity.y / maxChannel,
            primaryIntensity.z / maxChannel
          );
        }
      }
    }
  });

  return (
    <>
      <ambientLight ref={ambientLightRef} intensity={0.7} />
      <directionalLight ref={directionalLightRef} position={[5, 10, 5]} intensity={1.2} castShadow />
    </>
  );
};
