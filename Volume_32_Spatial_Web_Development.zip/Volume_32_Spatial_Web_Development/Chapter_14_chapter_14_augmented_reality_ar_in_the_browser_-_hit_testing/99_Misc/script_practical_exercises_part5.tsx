/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// Interactive Challenge: Implement InteractiveTransformWrapper.tsx
import React, { useRef, useState } from 'react';
import { useFrame, ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

interface InteractiveTransformWrapperProps {
  children: React.ReactNode;
  initialScale?: number;
}

export const InteractiveTransformWrapper: React.FC<InteractiveTransformWrapperProps> = ({
  children,
  initialScale = 1.0
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const [isSelected, setIsSelected] = useState(false);
  const [scale, setScale] = useState(initialScale);
  const [rotationY, setRotationY] = useState(0);

  // TODO: Implement pointerdown handler to mark object as selected.
  // TODO: Implement pointermove handler to update rotationY and scale based on drag deltas.
  // TODO: Implement pointerup handler to deselect or finalize transformation state.

  return (
    <group 
      ref={groupRef}
      scale={[scale, scale, scale]}
      rotation={[0, rotationY, 0]}
      onPointerDown={(e: ThreeEvent<PointerEvent>) => {
        e.stopPropagation();
        setIsSelected(true);
      }}
      onPointerUp={() => setIsSelected(false)}
    >
      {children}
      {/* Optional: Render bounding box outline when selected */}
      {isSelected && (
        <boxHelper args={[undefined as unknown as THREE.Object3D, 0xff0000]} />
      )}
    </group>
  );
};
