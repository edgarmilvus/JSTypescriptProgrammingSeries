/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useRef, useCallback } from 'react';
import { Canvas, useFrame, ThreeEvent } from '@react-three/fiber';
import { XR, createXRStore, useXR, useController, useHand } from '@react-three/xr';
import * as THREE from 'three';

// Initialize the WebXR store for managing immersive AR/VR sessions
const xrStore = createXRStore();

/**
 * Interface representing a SaaS metric card state in 3D space.
 */
interface MetricCardState {
  readonly id: string;
  readonly label: string;
  readonly value: string;
  readonly isHovered: boolean;
  readonly isPressed: boolean;
}

/**
 * InteractiveSpatialPanel Component
 * Renders a 3D SaaS dashboard card that responds to WebXR controller rays and hand gestures.
 */
const InteractiveSpatialPanel: React.FC = () => {
  // Immutable state for the metric card
  const [cardState, setCardState] = useState<MetricCardState>({
    id: 'card-01',
    label: 'Cloud Infrastructure Latency',
    value: '14.2ms',
    isHovered: false,
    isPressed: false,
  });

  const meshRef = useRef<THREE.Mesh>(null);

  // Access spatial controllers and hand tracking hooks from @react-three/xr
  const leftController = useController('left');
  const rightController = useController('right');
  const rightHand = useHand('right');

  /**
   * Handles pointer enter events using immutable state updates.
   */
  const handlePointerEnter = useCallback((event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    setCardState((prevState) => ({
      ...prevState,
      isHovered: true,
    }));
  }, []);

  /**
   * Handles pointer leave events using immutable state updates.
   */
  const handlePointerLeave = useCallback((event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    setCardState((prevState) => ({
      ...prevState,
      isHovered: false,
      isPressed: false,
    }));
  }, []);

  /**
   * Handles pointer down (squeeze/select) events.
   */
  const handlePointerDown = useCallback((event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    setCardState((prevState) => ({
      ...prevState,
      isPressed: true,
    }));
    console.info(`[SaaS Spatial telemetry] Card ${prevState.id} engaged via WebXR pointer.`);
  }, []);

  /**
   * Handles pointer up events, resetting the press state.
   */
  const handlePointerUp = useCallback((event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    setCardState((prevState) => ({
      ...prevState,
      isPressed: false,
    }));
  }, []);

  // Animation frame loop for subtle floating dynamics and gesture polling
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Apply a floating sinusoidal motion to simulate spatial UI presence
    meshRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 2) * 0.05 + 1.5;

    // Example of Exhaustive Asynchronous Resilience pattern for telemetry synchronization
    try {
      // Check if the user is performing a pinch gesture with their right hand index finger
      if (rightHand && rightHand.joints && rightHand.joints['index-finger-tip']) {
        const indexTipPos = rightHand.joints['index-finger-tip'].position;
        const panelPos = meshRef.current.position;
        const distance = indexTipPos.distanceTo(panelPos);

        // If the index finger is within 10cm of the panel, trigger programmatic interaction
        if (distance < 0.1 && !cardState.isPressed) {
          setCardState((prev) => ({ ...prev, isPressed: true }));
        }
      }
    } catch (error) {
      console.error('Failed to poll hand tracking joint telemetry:', error);
    } finally {
      // Guaranteed execution block for frame-level cleanup if necessary
    }
  });

  // Determine material color based on current immutable interaction state
  const currentCardColor = cardState.isPressed
    ? '#10b981' // Emerald green when pressed
    : cardState.isHovered
    ? '#3b82f6' // Bright blue when hovered
    : '#1f2937'; // Slate dark gray default

  return (
    <group position={[0, 0, -1.5]}>
      {/* Interactive 3D SaaS Metric Card Mesh */}
      <mesh
        ref={meshRef}
        onPointerEnter={handlePointerEnter}
        onPointerLeave={handlePointerLeave}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
      >
        <boxGeometry args={[0.6, 0.4, 0.02]} />
        <meshStandardMaterial color={currentCardColor} roughness={0.3} metalness={0.8} />
      </mesh>
    </group>
  );
};

/**
 * SaaSXRApp Root Component
 * Sets up the WebXR canvas and entry point with robust error handling.
 */
export default function SaaSXRApp() {
  const handleEnterAR = async () => {
    try {
      // Attempt to enter the immersive AR session with exhaustive resilience
      await xrStore.enterAR();
    } catch (err) {
      console.error('Critical failure initiating WebXR AR session:', err);
    } finally {
      console.info('WebXR session initialization pipeline finalized.');
    }
  };

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#0b0f19' }}>
      {/* HTML Overlay UI for initiating WebXR session */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10, color: '#fff' }}>
        <button
          onClick={handleEnterAR}
          style={{
            padding: '12px 24px',
            background: '#6366f1',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: 'bold',
          }}
        >
          Launch Spatial SaaS AR Session
        </button>
      </div>

      {/* R3F Canvas with WebXR Provider */}
      <Canvas camera={{ position: [0, 1.6, 0] }}>
        <XR store={xrStore}>
          <ambientLight intensity={0.8} />
          <pointLight position={[5, 5, 5]} intensity={1.5} />
          <InteractiveSpatialPanel />
        </XR>
      </Canvas>
    </div>
  );
}
