/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

"use client";

import React, { useRef, useState, useMemo } from "react";
import { Canvas, useFrame, ThreeEvent } from "@react-three/fiber";
import { XR, createXRStore, useXR, useXRInputSourceState } from "@react-three/xr";
import * as THREE from "three";

// Initialize the XR store for WebXR session management
const xrStore = createXRStore();

/**
 * Interface representing properties for an interactive 3D asset card in the spatial workspace.
 */
interface AssetCardProps {
  id: string;
  position: [number, number, number];
  color: string;
}

/**
 * A collaborative 3D Asset Card that responds to both standard pointer events,
 * WebXR raycasting controllers, and direct hand-tracking interactions.
 */
function SpatialAssetCard({ id, position, color }: AssetCardProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isSelected, setIsSelected] = useState(false);
  const [scale, setScale] = useState<number>(1);

  // Access current XR frame state to track spatial inputs
  const xrState = useXR();
  
  // Track left and right hand/controller states dynamically
  const leftInput = useXRInputSourceState("controller", "left");
  const rightInput = useXRInputSourceState("controller", "right");

  /**
   * Per-frame animation and gesture evaluation loop.
   * Checks for pinch distance or trigger pulls to execute scaling and manipulation.
   */
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smooth hover and selection visual feedback (Interpolation)
    const targetScale = isSelected ? scale * 1.2 : isHovered ? scale * 1.05 : scale;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), delta * 10);

    // Example: Evaluate distance-based hand pinch gesture if available via WebXR input sources
    if (rightInput && rightInput.inputSource.hand) {
      const hand = rightInput.inputSource.hand;
      const thumbTip = hand.get("thumb-tip");
      const indexTip = hand.get("index-finger-tip");

      if (thumbTip && indexTip) {
        // Retrieve spatial positions of fingertips to calculate pinch threshold
        const thumbPos = new THREE.Vector3();
        const indexPos = new THREE.Vector3();
        
        // Note: Real WebXR joint space requires evaluating transforms relative to reference space
        // This structural block demonstrates the calculation pattern for custom gestures.
      }
    }
  });

  /**
   * Handle pointer down events from mouse, gaze, or XR controllers.
   */
  const handlePointerDown = (event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    setIsSelected((prev) => !prev);
    console.log(`[Spatial Workspace] Asset ${id} selection toggled: ${!isSelected}`);
  };

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onPointerOver={(e) => { e.stopPropagation(); setIsHovered(true); }}
        onPointerOut={() => setIsHovered(false)}
        onPointerDown={handlePointerDown}
      >
        <boxGeometry args={[0.4, 0.6, 0.05]} />
        <meshStandardMaterial 
          color={isSelected ? "#4f46e5" : isHovered ? "#818cf8" : color} 
          roughness={0.3}
          metalness={0.8}
        />
      </mesh>
    </group>
  );
}

/**
 * Main application component setting up the WebXR canvas, lighting, and spatial UI layout.
 */
export default function SpatialWorkspaceApp() {
  return (
    <main className="w-full h-screen bg-slate-950 overflow-hidden relative">
      {/* HTML Overlay for Enterprise SaaS Controls */}
      <div className="absolute top-6 left-6 z-50 flex gap-4 pointer-events-auto">
        <button 
          onClick={() => xrStore.enterAR()}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl shadow-lg transition-all"
        >
          Enter Immersive AR/VR
        </button>
      </div>

      {/* WebXR Canvas */}
      <Canvas camera={{ position: [0, 1.6, 2], fov: 60 }}>
        <XR store={xrStore}>
          <ambientLight intensity={1.2} />
          <directionalLight position={[5, 5, 5]} intensity={1.5} />

          {/* Spatial Assets arranged in a curved enterprise workspace */}
          <SpatialAssetCard id="asset-1" position={[-0.6, 1.5, -1.2]} color="#3b82f6" />
          <SpatialAssetCard id="asset-2" position={[0.0, 1.5, -1.4]} color="#10b981" />
          <SpatialAssetCard id="asset-3" position={[0.6, 1.5, -1.2]} color="#f59e0b" />
        </XR>
      </Canvas>
    </main>
  );
}
