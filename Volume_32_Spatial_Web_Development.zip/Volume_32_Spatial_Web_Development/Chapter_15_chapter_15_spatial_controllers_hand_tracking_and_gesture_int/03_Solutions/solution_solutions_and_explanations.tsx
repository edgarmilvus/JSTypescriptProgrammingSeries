/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { XR, Controllers, useXR } from '@react-three/xr';
import * as THREE from 'three';
import { Line } from '@react-three/drei';

interface UICardProps {
  id: string;
  position: [number, number, number];
}

function InteractiveUICard({ id, position }: UICardProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isSelected, setIsSelected] = useState(false);

  // Expose state modifiers to global raycast manager or handle via XR ray intersections
  return (
    <mesh
      ref={meshRef}
      position={position}
      scale={isSelected ? [0.8, 0.8, 0.8] : [1, 1, 1]}
      onPointerOver={() => setIsHovered(true)}
      onPointerOut={() => {
        setIsHovered(false);
        setIsSelected(false);
      }}
      onPointerDown={() => setIsSelected(true)}
      onPointerUp={() => setIsSelected(false)}
    >
      <boxGeometry args={[0.4, 0.6, 0.05]} />
      <meshStandardMaterial
        color={isSelected ? '#ff4444' : isHovered ? '#44ff44' : '#4444ff'}
        emissive={isHovered ? new THREE.Color('#115511') : new THREE.Color('#000000')}
      />
    </mesh>
  );
}

function ControllerRayManager() {
  const { controllers } = useXR();
  const rayPoints = useMemo(() => [new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -2)], []);

  useFrame(() => {
    // Custom raycasting logic against interactive scene objects can be evaluated here
    controllers.forEach((controller) => {
      const gripSpace = controller.grip;
      if (gripSpace) {
        // Evaluate intersections using THREE.Raycaster if bypass default pointer events are needed
      }
    });
  });

  return (
    <>
      <Controllers />
      {controllers.map((controller, index) => (
        <group key={index} ref={controller.controller}>
          <Line points={rayPoints} color="cyan" lineWidth={2} transparent opacity={0.6} />
        </group>
      ))}
    </>
  );
}

export function MultiRayScene() {
  return (
    <Canvas>
      <XR>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <ControllerRayManager />
        <InteractiveUICard id="card-1" position={[-0.5, 1.5, -1.5]} />
        <InteractiveUICard id="card-2" position={[0.5, 1.5, -1.5]} />
      </XR>
    </Canvas>
  );
}
