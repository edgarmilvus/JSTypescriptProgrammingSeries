/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useHand } from '@react-three/xr';
import * as THREE from 'three';

interface PinchSliderProps {
  min?: number;
  max?: number;
  step?: number;
  defaultValue?: number;
  onChange: (value: number) => void;
}

export function PinchSlider({
  min = 0,
  max = 1,
  defaultValue = 0.5,
  onChange,
}: PinchSliderProps) {
  const [value, setValue] = useState(defaultValue);
  const [isPinching, setIsPinching] = useState(false);
  const handleRef = useRef<THREE.Mesh>(null);

  const rightHand = useHand('right');

  useFrame(() => {
    if (!rightHand || !rightHand.joints) return;

    const thumbTip = rightHand.joints['thumb-tip'];
    const indexTip = rightHand.joints['index-finger-tip'];

    if (thumbTip && indexTip) {
      const thumbPos = new THREE.Vector3().setFromMatrixPosition(thumbTip.matrixWorld);
      const indexPos = new THREE.Vector3().setFromMatrixPosition(indexTip.matrixWorld);

      const distance = thumbPos.distanceTo(indexPos);
      const pinchThreshold = 0.02; // 2 centimeters

      if (distance < pinchThreshold) {
        setIsPinching(true);
        // Project index position onto slider X axis (-0.5 to 0.5 local bounds)
        const localX = Math.max(-0.5, Math.min(0.5, indexPos.x));
        const normalizedValue = (localX + 0.5) / 1.0;
        const scaledValue = min + normalizedValue * (max - min);

        setValue(scaledValue);
        onChange(scaledValue);

        if (handleRef.current) {
          handleRef.current.position.x = localX;
        }
      } else {
        setIsPinching(false);
      }
    }
  });

  return (
    <group position={[0, 1.4, -1]}>
      {/* Slider Track */}
      <mesh>
        <boxGeometry args={[1.0, 0.02, 0.02]} />
        <meshStandardMaterial color="#666666" />
      </mesh>

      {/* Slider Handle */}
      <mesh ref={handleRef} position={[value - 0.5, 0, 0]}>
        <sphereGeometry args={[0.04, 32, 32]} />
        <meshStandardMaterial color={isPinching ? '#00ff88' : '#ffffff'} />
      </mesh>
    </group>
  );
}
