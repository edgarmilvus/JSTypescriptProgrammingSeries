/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useHand } from '@react-three/xr';
import * as THREE from 'three';

export type GestureType = 'NONE' | 'THUMBS_UP' | 'OPEN_PALM' | 'FIST';

interface UseGestureRecognizerProps {
  handedness: 'left' | 'right';
  onGestureRecognized: (gesture: GestureType) => void;
}

export function useGestureRecognizer({ handedness, onGestureRecognized }: UseGestureRecognizerProps) {
  const hand = useHand(handedness);
  const [currentGesture, setCurrentGesture] = useState<GestureType>('NONE');
  const [consecutiveFrames, setConsecutiveFrames] = useState(0);

  useFrame(() => {
    if (!hand || !hand.joints) return;

    const wrist = hand.joints['wrist'];
    const thumbTip = hand.joints['thumb-tip'];
    const indexTip = hand.joints['index-finger-tip'];
    const middleTip = hand.joints['middle-finger-tip'];
    const ringTip = hand.joints['ring-finger-tip'];
    const pinkyTip = hand.joints['pinky-finger-tip'];

    if (!wrist || !thumbTip || !indexTip || !middleTip || !ringTip || !pinkyTip) return;

    const wristPos = new THREE.Vector3().setFromMatrixPosition(wrist.matrixWorld);
    const thumbPos = new THREE.Vector3().setFromMatrixPosition(thumbTip.matrixWorld);
    const indexPos = new THREE.Vector3().setFromMatrixPosition(indexTip.matrixWorld);
    const middlePos = new THREE.Vector3().setFromMatrixPosition(middleTip.matrixWorld);
    const ringPos = new THREE.Vector3().setFromMatrixPosition(ringTip.matrixWorld);
    const pinkyPos = new THREE.Vector3().setFromMatrixPosition(pinkyTip.matrixWorld);

    // Helper checks
    const indexDist = indexPos.distanceTo(wristPos);
    const middleDist = middlePos.distanceTo(wristPos);
    const ringDist = ringPos.distanceTo(wristPos);
    const pinkyDist = pinkyPos.distanceTo(wristPos);

    let detected: GestureType = 'NONE';

    // FIST Check: All fingers curled close to wrist
    if (indexDist < 0.1 && middleDist < 0.1 && ringDist < 0.1 && pinkyDist < 0.1) {
      detected = 'FIST';
    } 
    // OPEN_PALM Check: All fingers extended far from wrist
    else if (indexDist > 0.15 && middleDist > 0.15 && ringDist > 0.15 && pinkyDist > 0.15) {
      detected = 'OPEN_PALM';
    } 
    // THUMBS_UP Check: Thumb points up, others curled
    else if (thumbPos.y > wristPos.y + 0.08 && indexDist < 0.12) {
      detected = 'THUMBS_UP';
    }

    // Debouncing / Smoothing buffer to eliminate optical jitter
    if (detected === currentGesture) {
      setConsecutiveFrames((prev) => {
        const next = prev + 1;
        if (next === 5) {
          onGestureRecognized(detected);
        }
        return next;
      });
    } else {
      setCurrentGesture(detected);
      setConsecutiveFrames(0);
    }
  });
}
