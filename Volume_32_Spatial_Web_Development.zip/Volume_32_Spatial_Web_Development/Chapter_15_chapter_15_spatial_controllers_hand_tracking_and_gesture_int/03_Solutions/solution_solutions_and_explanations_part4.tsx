/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { RigidBody, RapierRigidBody, Physics } from '@react-three/rapier';
import { Controllers, useXR } from '@react-three/xr';
import * as THREE from 'three';

function GrabbableBox() {
  const bodyRef = useRef<RapierRigidBody>(null);
  const [isGrabbed, setIsGrabbed] = useState(false);
  const { controllers } = useXR();

  const previousPosition = useRef(new THREE.Vector3());
  const velocityBuffer = useRef(new THREE.Vector3());

  useFrame((_, delta) => {
    if (!bodyRef.current) return;

    if (isGrabbed && controllers.length > 0) {
      const controller = controllers[0].controller;
      if (controller) {
        const controllerPos = new THREE.Vector3();
        controller.getWorldPosition(controllerPos);

        // Calculate velocity vector using rolling average delta
        velocityBuffer.current.copy(controllerPos).sub(previousPosition.current).divideScalar(delta);
        previousPosition.current.copy(controllerPos);

        // Snap body kinematically to controller
        bodyRef.current.setTranslation(controllerPos, true);
        bodyRef.current.setLinvel({ x: 0, y: 0, z: 0 }, true);
      }
    }
  });

  const handleGrabStart = () => {
    setIsGrabbed(true);
    if (bodyRef.current) {
      bodyRef.current.setGravityScale(0, true);
    }
  };

  const handleGrabEnd = () => {
    setIsGrabbed(false);
    if (bodyRef.current) {
      bodyRef.current.setGravityScale(1, true);
      // Apply momentum throw vector
      bodyRef.current.setLinvel(velocityBuffer.current, true);
    }
  };

  return (
    <RigidBody ref={bodyRef} colliders="cuboid" position={[0, 1.5, -1]}>
      <mesh
        onPointerDown={handleGrabStart}
        onPointerUp={handleGrabEnd}
      >
        <boxGeometry args={[0.2, 0.2, 0.2]} />
        <meshStandardMaterial color="orange" />
      </mesh>
    </RigidBody>
  );
}

export function PhysicsThrowScene() {
  return (
    <Canvas>
      <Physics>
        <ambientLight intensity={0.7} />
        <Controllers />
        <GrabbableBox />
      </Physics>
    </Canvas>
  );
}
