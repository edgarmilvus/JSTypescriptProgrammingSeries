/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual layout of a binary transform packet packer
function serializeTransform(buffer: ArrayBuffer, offset: number, objectId: number, position: [number, number, number], rotation: [number, number, number, number]): number {
  const view = new DataView(buffer);
  
  // Write Object ID (2 bytes)
  view.setUint16(offset, objectId, true);
  offset += 2;

  // Write Position (12 bytes: 3 x Float32)
  view.setFloat32(offset, position[0], true);
  view.setFloat32(offset + 4, position[1], true);
  view.setFloat32(offset + 8, position[2], true);
  offset += 12;

  // Write Rotation Quaternion (16 bytes: 4 x Float32)
  view.setFloat32(offset, rotation[0], true);
  view.setFloat32(offset + 4, rotation[1], true);
  view.setFloat32(offset + 8, rotation[2], true);
  view.setFloat32(offset + 12, rotation[3], true);
  offset += 16;

  return offset; // Returns new byte offset
}
