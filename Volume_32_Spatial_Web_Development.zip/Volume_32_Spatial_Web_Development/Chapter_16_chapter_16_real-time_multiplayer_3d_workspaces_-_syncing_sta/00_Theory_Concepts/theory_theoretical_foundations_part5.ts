/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.ts
// Description: Theoretical Foundations
// ==========================================

digraph LeaseModel {
    rankdir=TB;
    node [shape=box, style="filled,rounded", fontname="Arial", fillcolor="#f0f4f8", margin=0.2];
    edge [fontname="Arial", fontsize=10];

    Request [label="Client requests object lock\n(Intent to Modify)", fillcolor="#e1f5fe"];
    ServerEval [label="WebSocket Server evaluates lock table\n(Is object currently leased?)", fillcolor="#fff9c4"];
    Granted [label="Lock Granted\n(Client becomes authoritative for Asset)", fillcolor="#e8f5e9"];
    Denied [label="Lock Denied\n(Asset rendered as Locked/Read-Only)", fillcolor="#ffcdd2"];

    Request -> ServerEval;
    ServerEval -> Granted [label="Available"];
    ServerEval -> Denied [label="Occupied by Peer"];
}
