/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing the spatial state of a shared 3D object.
 */
interface ObjectState {
  id: string;
  position: [number, number, number];
  rotation: [number, number, number];
  lastUpdatedBy: string;
}

/**
 * Mock WebSocket client hook for spatial state synchronization.
 * In a real-world SaaS architecture, this would connect to a Node.js/WebSockets 
 * or Edge-compatible durable object backend (e.g., PartyKit or Supabase Realtime).
 */
function useSpatialWebSocket(roomId: string) {
  const [objectState, setObjectState] = useState<ObjectState>({
    id: 'shared-cube',
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    lastUpdatedBy: 'system',
  });

  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Initialize WebSocket connection (using a public echo/test server for illustration)
    const ws = new WebSocket(`wss://echo.websocket.events/.ws`);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log(`[WebSocket] Connected to room: ${roomId}`);
    };

    ws.onmessage = (event) => {
      try {
        const data: ObjectState = JSON.parse(event.data);
        // Only update if the message contains valid spatial coordinates
        if (data && data.id === 'shared-cube') {
          setObjectState(data);
        }
      } catch (err) {
        console.error('[WebSocket] Failed to parse incoming packet:', err);
      }
    };

    ws.onerror = (error) => {
      console.error('[WebSocket] Error encountered:', error);
    };

    return () => {
      ws.close();
    };
  }, [roomId]);

  /**
   * Function to broadcast local state modifications to other peers.
   */
  const updateRemoteState = (newState: Partial<ObjectState>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      const payload = JSON.stringify({
        id: 'shared-cube',
        ...objectState,
        ...newState,
        lastUpdatedBy: 'client-user-1',
      });
      wsRef.current.send(payload);
    }
  };

  return { objectState, updateRemoteState };
}

/**
 * R3F Component representing the synchronized 3D Mesh.
 */
function SynchronizedCube() {
  const meshRef = useRef<THREE.Mesh>(null!);
  const { objectState, updateRemoteState } = useSpatialWebSocket('room-alpha-123');
  
  // Track whether the local user is currently dragging/transforming the object
  const isDragging = useRef(false);

  // Sync incoming remote state changes to the Three.js mesh instance smoothly
  useFrame(() => {
    if (!meshRef.current || isDragging.current) return;

    const targetPos = new THREE.Vector3(...objectState.position);
    const targetRot = new THREE.Euler(...objectState.rotation);

    // Linear interpolation (lerp) for position to prevent snapping/jitter
    meshRef.current.position.lerp(targetPos, 0.1);
    
    // Slerp/interpolation for rotation can be added here for advanced smoothness
    meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, targetRot.x, 0.1);
    meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, targetRot.y, 0.1);
    meshRef.current.rotation.z = THREE.MathUtils.lerp(meshRef.current.rotation.z, targetRot.z, 0.1);
  });

  /**
   * Handle pointer down event to simulate user interaction.
   */
  const handlePointerDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    isDragging.current = true;
  };

  /**
   * Handle pointer up event to release control and broadcast final state.
   */
  const handlePointerUp = () => {
    if (!isDragging.current) return;
    isDragging.current = false;

    if (meshRef.current) {
      const { x, y, z } = meshRef.current.position;
      const { x: rx, y: ry, z: rz } = meshRef.current.rotation;
      
      // Broadcast final transformation to peers
      updateRemoteState({
        position: [x, y, z],
        rotation: [rx, ry, rz],
      });
    }
  };

  /**
   * Handle pointer move to dynamically shift object while dragging locally.
   */
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current || !meshRef.current) return;
    
    // Simple translation mapping based on pointer movement delta
    meshRef.current.position.x += e.movementX * 0.01;
    meshRef.current.position.y -= e.movementY * 0.01;

    // Throttle or stream updates in real-time if desired
    updateRemoteState({
      position: [meshRef.current.position.x, meshRef.current.position.y, meshRef.current.position.z],
      rotation: [meshRef.current.rotation.x, meshRef.current.rotation.y, meshRef.current.rotation.z],
    });
  };

  return (
    <mesh
      ref={meshRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerMove={handlePointerMove}
    >
      <boxGeometry args={[1.5, 1.5, 1.5]} />
      <meshStandardMaterial color={objectState.lastUpdatedBy === 'client-user-1' ? '#4f46e5' : '#db2777'} />
    </mesh>
  );
}

/**
 * Main application entry point containing the WebGL Canvas and scene lighting.
 */
export default function CollaborativeWorkspaceApp() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#0f172a' }}>
      <Canvas camera={{ position: [0, 2, 5], fov: 60 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1} />
        <SynchronizedCube />
        <OrbitControls makeDefault enableRotate={!window.PointerEvent} />
      </Canvas>
    </div>
  );
}
