/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file CollaborativeWorkspace.tsx
 * @description Real-time multiplayer 3D workspace syncing state via WebSockets & R3F.
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, TransformControls } from '@react-three/drei';
import * as THREE from 'three';

// Define the shape of a remote peer or local user state payload
interface UserTransformPayload {
  userId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  timestamp: number;
}

interface SharedObjectPayload {
  objectId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  lastUpdatedBy: string;
}

interface WorkspaceProps {
  workspaceId: string;
  currentUserId: string;
  websocketUrl: string;
}

/**
 * RemotePeerAvatar Component
 * Renders other users' avatars in the 3D space with interpolated movement to prevent jitter.
 */
const RemotePeerAvatar: React.FC<{ targetState: UserTransformPayload }> = ({ targetState }) => {
  const meshRef = useRef<THREE.Group>(null);
  
  // Smoothly interpolate (lerp) the remote avatar's position toward the latest server state
  useFrame((_, delta) => {
    if (!meshRef.current) return;
    const [tx, ty, tz] = targetState.position;
    meshRef.current.position.lerp(new THREE.Vector3(tx, ty, tz), delta * 15);
  });

  return (
    <group ref={meshRef}>
      <mesh position={[0, 0.5, 0]}>
        <capsuleGeometry args={[0.3, 1, 4, 8]} />
        <meshStandardMaterial color="#4f46e5" roughness={0.3} />
      </mesh>
      {/* User tag floating above avatar */}
      <mesh position={[0, 1.4, 0]}>
        <boxGeometry args={[0.6, 0.2, 0.05]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
    </group>
  );
};

/**
 * SyncableBox Component
 * A 3D object that can be manipulated by any client, utilizing TransformControls and optimistic updates.
 */
const SyncableBox: React.FC<{
  objectData: SharedObjectPayload;
  currentUserId: string;
  onTransformChange: (id: string, pos: [number, number, number], rot: [number, number, number]) => void;
}> = ({ objectData, currentUserId, onTransformChange }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Interpolate position when not being actively dragged by the local user
  useFrame((_, delta) => {
    if (!meshRef.current || isDragging) return;
    const [tx, ty, tz] = objectData.position;
    meshRef.current.position.lerp(new THREE.Vector3(tx, ty, tz), delta * 12);
  });

  const handleDragEnd = () => {
    setIsDragging(false);
    if (meshRef.current) {
      const pos: [number, number, number] = [
        meshRef.current.position.x,
        meshRef.current.position.y,
        meshRef.current.position.z,
      ];
      const rot: [number, number, number] = [
        meshRef.current.rotation.x,
        meshRef.current.rotation.y,
        meshRef.current.rotation.z,
      ];
      // Broadcast final transform to server
      onTransformChange(objectData.objectId, pos, rot);
    }
  };

  return (
    <TransformControls
      mode="translate"
      onMouseDown={() => setIsDragging(true)}
      onMouseUp={handleDragEnd}
    >
      <mesh
        ref={meshRef}
        position={objectData.position}
        rotation={objectData.rotation}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[1.5, 1.5, 1.5]} />
        <meshStandardMaterial 
          color={objectData.lastUpdatedBy === currentUserId ? "#10b981" : "#f59e0b"} 
          roughness={0.2}
        />
      </mesh>
    </TransformControls>
  );
};

/**
 * CollaborativeWorkspaceRoot Component
 * Manages WebSocket lifecycle, state distribution, and R3F Canvas context.
 */
export const CollaborativeWorkspaceRoot: React.FC<WorkspaceProps> = ({
  workspaceId,
  currentUserId,
  websocketUrl,
}) => {
  const socketRef = useRef<WebSocket | null>(null);
  const [peers, setPeers] = useState<Map<string, UserTransformPayload>>(new Map());
  const [sharedObjects, setSharedObjects] = useState<Map<string, SharedObjectPayload>>(
    new Map([
      ['box-1', { objectId: 'box-1', position: [0, 0.75, 0], rotation: [0, 0, 0], lastUpdatedBy: 'system' }]
    ])
  );

  // Throttling reference to avoid flooding the WebSocket with every single animation frame
  const lastSentRef = useRef<number>(0);

  useEffect(() => {
    const ws = new WebSocket(`${websocketUrl}?workspace=${workspaceId}&user=${currentUserId}`);
    socketRef.current = ws;

    ws.onopen = () => {
      console.log('Connected to Spatial WebRTC/WebSocket sync server.');
    };

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      
      if (message.type === 'USER_MOVE') {
        setPeers((prev) => {
          const next = new Map(prev);
          next.set(message.payload.userId, message.payload);
          return next;
        });
      } else if (message.type === 'OBJECT_TRANSFORM') {
        setSharedObjects((prev) => {
          const next = new Map(prev);
          next.set(message.payload.objectId, message.payload);
          return next;
        });
      }
    };

    return () => {
      ws.close();
    };
  }, [workspaceId, currentUserId, websocketUrl]);

  // Handle local user movement broadcasting (rate-limited to ~30fps / 33ms)
  const handleCameraMove = (position: [number, number, number], rotation: [number, number, number]) => {
    const now = performance.now();
    if (now - lastSentRef.current < 33) return; // Rate limit check
    lastSentRef.current = now;

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      const payload: UserTransformPayload = {
        userId: currentUserId,
        position,
        rotation,
        timestamp: Date.now(),
      };
      socketRef.current.send(JSON.stringify({ type: 'USER_MOVE', payload }));
    }
  };

  // Broadcast object modification
  const handleObjectTransform = (objectId: string, position: [number, number, number], rotation: [number, number, number]) => {
    const payload: SharedObjectPayload = {
      objectId,
      position,
      rotation,
      lastUpdatedBy: currentUserId,
    };

    // Optimistic local update
    setSharedObjects((prev) => {
      const next = new Map(prev);
      next.set(objectId, payload);
      return next;
    });

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'OBJECT_TRANSFORM', payload }));
    }
  };

  // Convert Maps to arrays for rendering
  const peerList = useMemo(() => Array.from(peers.values()), [peers]);
  const objectList = useMemo(() => Array.from(sharedObjects.values()), [sharedObjects]);

  return (
    <div className="w-full h-screen relative bg-slate-950">
      <Canvas shadows camera={{ position: [0, 5, 10], fov: 60 }}>
        <color attach="background" args={['#0f172a']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />
        
        {/* Render all active remote peers */}
        {peerList.map((peer) => (
          <RemotePeerAvatar key={peer.userId} targetState={peer} />
        ))}

        {/* Render synchronized 3D workspace objects */}
        {objectList.map((obj) => (
          <SyncableBox 
            key={obj.objectId} 
            objectData={obj} 
            currentUserId={currentUserId}
            onTransformChange={handleObjectTransform}
          />
        ))}

        <OrbitControls 
          makeDefault 
          onChange={(e) => {
            // Hook into OrbitControls to broadcast local camera/avatar position changes
            const camera = e?.target.object;
            if (camera) {
              handleCameraMove(
                [camera.position.x, camera.position.y, camera.position.z],
                [camera.rotation.x, camera.rotation.y, camera.rotation.z]
              );
            }
          }}
        />
        <gridHelper args={[30, 30, '#334155', '#1e293b']} />
      </Canvas>
    </div>
  );
};
