/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import { useRef, useEffect } from 'react';
import { Vector3, Euler, Object3D } from 'three';

interface ThrottledSyncOptions {
  ws: WebSocket;
  userId: string;
  objectRef: React.RefObject<Object3D>;
  intervalMs?: number;
  positionEpsilon?: number;
  rotationEpsilon?: number;
}

export function useThrottledTransformSync({
  ws,
  userId,
  objectRef,
  intervalMs = 66,
  positionEpsilon = 0.005,
  rotationEpsilon = 0.01,
}: ThrottledSyncOptions) {
  const lastSentRef = useRef<{
    pos: Vector3;
    rot: Euler;
    time: number;
  }>({
    pos: new Vector3(),
    rot: new Euler(),
    time: 0,
  });

  useEffect(() => {
    let animationFrameId: number;

    const checkAndSync = () => {
      const now = performance.now();
      const lastSent = lastSentRef.current;
      const obj = objectRef.current;

      if (obj && ws && ws.readyState === WebSocket.OPEN) {
        const timeElapsed = now - lastSent.time;
        const currentPos = obj.position;
        const currentRot = obj.rotation;

        // Calculate deltas
        const posDelta = currentPos.distanceTo(lastSent.pos);
        const rotDelta = 
          Math.abs(currentRot.x - lastSent.rot.x) +
          Math.abs(currentRot.y - lastSent.rot.y) +
          Math.abs(currentRot.z - lastSent.rot.z);

        // Check if interval has passed and delta exceeds epsilon, OR force sync every 2 seconds (2000ms)
        const exceedsEpsilon = posDelta > positionEpsilon || rotDelta > rotationEpsilon;
        const forceSync = timeElapsed >= 2000;

        if ((timeElapsed >= intervalMs && exceedsEpsilon) || forceSync) {
          const payload = {
            type: 'TRANSFORM_SYNC',
            userId,
            position: [currentPos.x, currentPos.y, currentPos.z],
            rotation: [currentRot.x, currentRot.y, currentRot.z],
            timestamp: now,
          };

          ws.send(JSON.stringify(payload));

          // Update last sent reference state
          lastSent.pos.copy(currentPos);
          lastSent.rot.copy(currentRot);
          lastSent.time = now;
        }
      }

      animationFrameId = requestAnimationFrame(checkAndSync);
    };

    animationFrameId = requestAnimationFrame(checkAndSync);
    return () => cancelAnimationFrame(animationFrameId);
  }, [ws, userId, objectRef, intervalMs, positionEpsilon, rotationEpsilon]);
}
