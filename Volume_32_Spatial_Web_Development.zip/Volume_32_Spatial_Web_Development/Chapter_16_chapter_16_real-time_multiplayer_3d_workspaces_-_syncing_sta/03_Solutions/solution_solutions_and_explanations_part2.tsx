/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import { Vector3, Quaternion } from 'three';

interface NetworkSnapshot {
  timestamp: number;
  position: Vector3;
  quaternion: Quaternion;
}

export class SpatialInterpolationBuffer {
  private buffer: NetworkSnapshot[] = [];
  private maxBufferSize: number = 30;
  private renderDelay: number = 100; // ms

  public addSnapshot(snapshot: NetworkSnapshot) {
    // Insert snapshot into buffer in chronological order
    const insertIndex = this.buffer.findIndex((s) => s.timestamp > snapshot.timestamp);
    if (insertIndex === -1) {
      this.buffer.push(snapshot);
    } else {
      this.buffer.splice(insertIndex, 0, snapshot);
    }

    // Maintain maxBufferSize limit
    if (this.buffer.length > this.maxBufferSize) {
      this.buffer.shift();
    }
  }

  public getInterpolatedState(now: number): { position: Vector3; quaternion: Quaternion } | null {
    if (this.buffer.length === 0) return null;

    const targetTime = now - this.renderDelay;

    // Handle edge case: target time is older than our oldest buffer entry
    if (targetTime <= this.buffer[0].timestamp) {
      return {
        position: this.buffer[0].position.clone(),
        quaternion: this.buffer[0].quaternion.clone(),
      };
    }

    // Handle edge case: target time is newer than our newest buffer entry (extrapolation/buffer dry)
    const newest = this.buffer[this.buffer.length - 1];
    if (targetTime >= newest.timestamp) {
      const timeSinceNewest = targetTime - newest.timestamp;
      // Grace period up to 300ms for extrapolation
      if (timeSinceNewest <= 300 && this.buffer.length >= 2) {
        const secondNewest = this.buffer[this.buffer.length - 2];
        const velocity = new Vector3()
          .subVectors(newest.position, secondNewest.position)
          .divideScalar(newest.timestamp - secondNewest.timestamp);
        
        const extrapolatedPos = new Vector3()
          .copy(newest.position)
          .addScaledVector(velocity, timeSinceNewest);

        return {
          position: extrapolatedPos,
          quaternion: newest.quaternion.clone(),
        };
      }
      return {
        position: newest.position.clone(),
        quaternion: newest.quaternion.clone(),
      };
    }

    // Find the two snapshots that bracket the target render time
    let snapshotA = this.buffer[0];
    let snapshotB = this.buffer[1];

    for (let i = 0; i < this.buffer.length - 1; i++) {
      if (this.buffer[i].timestamp <= targetTime && this.buffer[i + 1].timestamp >= targetTime) {
        snapshotA = this.buffer[i];
        snapshotB = this.buffer[i + 1];
        break;
      }
    }

    // Calculate interpolation alpha progress
    const totalSpan = snapshotB.timestamp - snapshotA.timestamp;
    const progress = totalSpan === 0 ? 0 : (targetTime - snapshotA.timestamp) / totalSpan;

    const interpolatedPosition = new Vector3().lerpVectors(
      snapshotA.position,
      snapshotB.position,
      progress
    );

    const interpolatedQuaternion = new Quaternion().slerpQuaternions(
      snapshotA.quaternion,
      snapshotB.quaternion,
      progress
    );

    return {
      position: interpolatedPosition,
      quaternion: interpolatedQuaternion,
    };
  }
}
