/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

interface LockedObjectProps {
  objectId: string;
  ws: WebSocket;
  userId: string;
}

export const LockedInteractiveObject: React.FC<LockedObjectProps> = ({ objectId, ws, userId }) => {
  const [isLocked, setIsLocked] = useState(false);
  const [isHeldByMe, setIsHeldByMe] = useState(false);
  const meshRef = useRef<THREE.Mesh>(null);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        if (data.objectId !== objectId) return;

        if (data.type === 'LOCK_GRANTED' && data.userId === userId) {
          setIsHeldByMe(true);
          setIsLocked(true);
        } else if (data.type === 'LOCK_DENIED') {
          setIsHeldByMe(false);
          setIsLocked(true);
          // Visual denial feedback: quick scale flash or color pulse
          if (meshRef.current) {
            meshRef.current.scale.set(1.2, 1.2, 1.2);
            setTimeout(() => meshRef.current?.scale.set(1, 1, 1), 200);
          }
        } else if (data.type === 'LOCK_RELEASED') {
          setIsLocked(false);
          setIsHeldByMe(false);
        }
      } catch (err) {
        console.error('Failed to parse WebSocket message', err);
      }
    };

    ws.addEventListener('message', handleMessage);
    return () => ws.removeEventListener('message', handleMessage);
  }, [ws, objectId, userId]);

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    if (isLocked) return;

    // Request exclusive lock from server
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(
        JSON.stringify({
          type: 'LOCK_REQUEST',
          objectId,
          userId,
        })
      );
    }
  };

  const handlePointerUp = () => {
    if (isHeldByMe) {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(
          JSON.stringify({
            type: 'LOCK_RELEASE',
            objectId,
            userId,
          })
        );
      }
      setIsHeldByMe(false);
      setIsLocked(false);
    }
  };

  return (
    <mesh
      ref={meshRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
    >
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={isHeldByMe ? 'green' : isLocked ? 'red' : 'blue'} />
    </mesh>
  );
};
