/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// Starter code structure for Exercise 2
import { useRef } from 'react';
import { Vector3, Quaternion } from 'three';

interface NetworkSnapshot {
  timestamp: number;
  position: Vector3;
  quaternion: Quaternion;
}

export class SpatialInterpolationBuffer {
  private buffer: NetworkSnapshot[] = [];
  private maxBufferSize: number = 30;
  private renderDelay: number = 100; // ms

  public addSnapshot(snapshot: NetworkSnapshot) {
    // TODO: Insert snapshot into buffer in chronological order,
    // maintaining maxBufferSize limits.
  }

  public getInterpolatedState(now: number): { position: Vector3; quaternion: Quaternion } | null {
    // TODO: Implement interpolation logic based on targetTime = now - renderDelay.
    return null;
  }
}
