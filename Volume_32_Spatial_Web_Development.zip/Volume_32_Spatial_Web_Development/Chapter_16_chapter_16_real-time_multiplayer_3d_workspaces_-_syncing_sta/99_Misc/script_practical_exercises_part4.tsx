/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// Starter code structure for Exercise 4
import React, { useState } from 'react';
import { useThree, ThreeEvent } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface Annotation {
  id: string;
  authorId: string;
  position: [number, number, number];
  text: string;
}

interface SpatialAnnotationManagerProps {
  ws: WebSocket;
  userId: string;
}

export const SpatialAnnotationManager: React.FC<SpatialAnnotationManagerProps> = ({ ws, userId }) => {
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [activeInput, setActiveInput] = useState<{ position: THREE.Vector3 } | null>(null);
  const [inputText, setInputText] = useState('');
  const { camera } = useThree();

  const handleDoubleClick = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    // TODO: Capture intersection point and open input modal
  };

  const handleSubmitAnnotation = () => {
    // TODO: Create annotation object, broadcast via WebSocket, update local state
  };

  return (
    <group onDoubleClick={handleDoubleClick}>
      {annotations.map((ann) => (
        <group key={ann.id} position={ann.position}>
          <Html position={[0, 0.2, 0]} center distanceFactor={15}>
            <div className="bg-white p-2 rounded shadow-md text-black text-xs pointer-events-auto">
              <strong>{ann.authorId}</strong>: {ann.text}
            </div>
          </Html>
          <mesh>
            <sphereGeometry args={[0.05, 16, 16]} />
            <meshBasicMaterial color="yellow" />
          </mesh>
        </group>
      ))}

      {activeInput && (
        <Html position={activeInput.position} center>
          <div className="bg-slate-900 text-white p-3 rounded shadow-xl flex flex-col gap-2 pointer-events-auto">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type annotation..."
              className="px-2 py-1 text-black rounded text-sm"
              autoFocus
            />
            <button
              onClick={handleSubmitAnnotation}
              className="bg-blue-600 text-white px-3 py-1 rounded text-xs"
            >
              Post Note
            </button>
          </div>
        </Html>
      )}
    </group>
  );
};
