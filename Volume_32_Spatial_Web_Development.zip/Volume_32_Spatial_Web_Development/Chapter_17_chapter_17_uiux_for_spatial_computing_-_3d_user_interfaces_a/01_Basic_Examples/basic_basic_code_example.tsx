/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import * as THREE from 'class-variance-authority'; // (Included for mock dependency parity if needed, standard styling used below)

/**
 * Interface representing the state of our SaaS hardware node.
 */
interface NodeState {
  id: string;
  name: string;
  status: 'optimal' | 'warning' | 'critical';
  cpuLoad: number;
}

/**
 * SpatialNode Component
 * Renders a 3D mesh representing a physical server node in a data center,
 * along with a floating HTML overlay anchored precisely to its top surface.
 */
function SpatialNode({ node }: { node: NodeState }) {
  // Local state to handle interactive UI toggles inside the spatial overlay
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  // Determine indicator color based on status
  const statusColor = 
    node.status === 'optimal' ? '#10B981' : 
    node.status === 'warning' ? '#F59E0B' : '#EF4444';

  return (
    <group position={[0, 0, 0]}>
      {/* 3D Mesh representing the physical hardware chassis */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[2, 1, 3]} />
        <meshStandardMaterial color="#1E293B" roughness={0.3} metalness={0.8} />
      </mesh>

      {/* 
        Drei Html Component: Bridges the DOM and WebGL canvas.
        - position: Sets the 3D coordinate offset relative to the parent group.
        - center: Centers the HTML element's bounding box around the target position.
        - distanceFactor: Scales the DOM element based on camera distance to maintain readability.
      * */}
      <Html
        position={[0, 1.2, 0]}
        center
        distanceFactor={8}
        zIndexRange={[100, 0]}
      >
        <div style={{
          background: 'rgba(15, 23, 42, 0.85)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: '12px',
          padding: '16px',
          color: '#F8FAFC',
          fontFamily: 'system-ui, sans-serif',
          width: '240px',
          boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)',
          userSelect: 'none',
          transition: 'all 0.2s ease-in-out'
        }}>
          {/* Card Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <span style={{ fontWeight: 600, fontSize: '14px' }}>{node.name}</span>
            <span style={{ 
              width: '10px', 
              height: '10px', 
              borderRadius: '50%', 
              backgroundColor: statusColor,
              boxShadow: `0 0 8px ${statusColor}`
            }} />
          </div>

          {/* Telemetry Metric */}
          <div style={{ fontSize: '12px', color: '#94A3B8', marginBottom: '12px' }}>
            CPU Load: <strong style={{ color: '#F8FAFC' }}>{node.cpuLoad}%</strong>
          </div>

          {/* Interactive Button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            style={{
              width: '100%',
              background: '#3B82F6',
              border: 'none',
              borderRadius: '6px',
              color: 'white',
              padding: '6px 12px',
              fontSize: '12px',
              fontWeight: 500,
              cursor: 'pointer'
            }}
          >
            {isExpanded ? 'Hide Diagnostics' : 'Inspect Node'}
          </button>

          {/* Conditional Expanded Content Panel */}
          {isExpanded && (
            <div style={{ 
              marginTop: '12px', 
              paddingTop: '12px', 
              borderTop: '1px solid rgba(255, 255, 255, 0.1)',
              fontSize: '11px',
              color: '#CBD5E1'
            }}>
              <div>Node ID: {node.id}</div>
              <div>Memory: 64GB ECC DDR5</div>
              <div>Uptime: 99.99%</div>
            </div>
          )}
        </div>
      </Html>
    </group>
  );
}

/**
 * SaaSAppDashboard Component
 * Initializes the React Three Fiber Canvas and orchestrates the 3D viewport.
 */
export default function SaaSAppDashboard() {
  const sampleNode: NodeState = {
    id: 'node-us-east-01',
    name: 'Edge Server Alpha',
    status: 'optimal',
    cpuLoad: 42,
  };

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#090D16' }}>
      <Canvas camera={{ position: [0, 3, 6], fov: 50 }}>
        {/* Ambient and Directional Lighting for the 3D scene */}
        <ambientLight intensity={0.7} />
        <directionalLight position={[5, 8, 5]} intensity={1.2} />

        {/* Render our Spatial UI component */}
        <SpatialNode node={sampleNode} />

        {/* Enable mouse orbit controls for desktop interaction */}
        <OrbitControls enablePan={true} enableZoom={true} maxPolarAngle={Math.PI / 2} />
      </Canvas>
    </div>
  );
}
