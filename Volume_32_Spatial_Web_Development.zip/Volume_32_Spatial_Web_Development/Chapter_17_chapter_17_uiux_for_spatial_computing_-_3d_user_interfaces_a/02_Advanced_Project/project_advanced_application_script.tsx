/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client'

import React, { useState, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Html, OrbitControls, Float } from '@react-three/drei'
import * as THREE from 'three'

/**
 * Interface representing a single SaaS analytics metric card
 */
interface MetricData {
  id: string
  title: string
  value: string
  trend: string
  isPositive: boolean
}

const metrics: MetricData[] = [
  { id: '1', title: 'Spatial Active Users', value: '24,592', trend: '+14.2%', isPositive: true },
  { id: '2', title: 'XR Render Latency', value: '4.2ms', trend: '-0.8ms', isPositive: true },
  { id: '3', title: 'Memory Bandwidth', value: '82.1%', trend: '+3.4%', isPositive: false },
]

/**
 * R3F Component representing a floating analytics panel in 3D space.
 * Uses Drei's <Html> component to project rich DOM elements over a 3D mesh wrapper.
 */
function SpatialAnalyticsCard({ metric, index }: { metric: MetricData; index: number }) {
  const cardRef = useRef<THREE.Group>(null)
  const [isHovered, setIsHovered] = useState(false)
  const [activeTab, setActiveTab] = useState<'overview' | 'telemetry'>('overview')

  // Smoothly rotate the card toward the center or react to spatial cursor states
  useFrame((state) => {
    if (!cardRef.current) return
    // Subtle breathing rotation or gaze-tracking simulation
    const targetY = Math.sin(state.clock.getElapsedTime() + index) * 0.05
    cardRef.current.rotation.y = THREE.MathUtils.lerp(cardRef.current.rotation.y, targetY, 0.1)
  })

  return (
    <group 
      ref={cardRef} 
      position={[(index - 1) * 2.2, 0, 0]}
    >
      {/* 3D Glassmorphism Backdrop Mesh */}
      <mesh 
        onPointerOver={() => setIsHovered(true)}
        onPointerOut={() => setIsHovered(false)}
      >
        <planeWidth args={[2, 2.5]} />
        <boxGeometry args={[2, 2.5, 0.05]} />
        <meshPhysicalMaterial 
          color={isHovered ? '#1e293b' : '#0f172a'} 
          roughness={0.2}
          metalness={0.8}
          transmission={0.6}
          thickness={0.5}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* 
        Floating HTML Overlay anchored to the 3D position.
        transform: enables CSS 3D transforms matching the R3F camera projection.
        occlude: hides DOM elements when occluded by other 3D geometry.
      */}
      <Html
        transform
        occlude
        position={[0, 0, 0.04]}
        scale={[0.15, 0.15, 0.15]}
        style={{
          width: '320px',
          background: 'rgba(15, 23, 42, 0.85)',
          backdropFilter: 'blur(12px)',
          borderRadius: '16px',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          color: 'white',
          padding: '24px',
          fontFamily: 'system-ui, sans-serif',
          boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)',
          transition: 'all 0.3s ease',
        }}
      >
        <div className="flex flex-col gap-4 select-none">
          {/* Card Header */}
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
              {metric.title}
            </span>
            <span 
              className={`text-xs px-2 py-1 rounded-full font-medium ${
                metric.isPositive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
              }`}
            >
              {metric.trend}
            </span>
          </div>

          {/* Core Metric Display */}
          <div>
            <div className="text-3xl font-extrabold tracking-tight text-white mt-1">
              {metric.value}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Updated live via WebXR telemetry stream
            </p>
          </div>

          {/* Interactive UI Switcher Tabs */}
          <div className="flex bg-slate-900/80 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${
                activeTab === 'overview' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('telemetry')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${
                activeTab === 'telemetry' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Telemetry
            </button>
          </div>

          {/* Dynamic Tab Content */}
          {activeTab === 'overview' ? (
            <div className="text-xs text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/60">
              🟢 Node synchronized with primary spatial cluster. Frame drops negligible.
            </div>
          ) : (
            <div className="text-xs text-indigo-300 bg-indigo-950/40 p-3 rounded-lg border border-indigo-900/40">
              ⚡ Raycasting precision: 99.8%. Hand-tracking latency: 12ms.
            </div>
          )}
        </div>
      </Html>
    </group>
  )
}

/**
 * Main Scene Export embedding spatial UI cards into a virtual workspace.
 */
export default function SpatialDashboardScene() {
  return (
    <div className="w-full h-screen bg-slate-950 relative overflow-hidden">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
      >
        <color attach="background" args={['#020617']} />
        
        {/* Ambient & Directional Lighting for 3D Cards */}
        <ambientLight intensity={0.7} />
        <directionalLight position={[5, 8, 5]} intensity={1.5} />

        {/* Floating wrapper adding organic spatial drift */}
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
          <group position={[0, 0, 0]}>
            {metrics.map((metric, idx) => (
              <SpatialAnalyticsCard key={metric.id} metric={metric} index={idx} />
            ))}
          </group>
        </Float>

        {/* Camera Controls for Desktop fallback */}
        <OrbitControls 
          enableZoom={true} 
          enablePan={true} 
          minDistance={2} 
          maxDistance={10} 
        />
      </Canvas>
    </div>
  )
}
