/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface BaseControl {
  id: string;
  label: string;
}

interface RangeControl extends BaseControl {
  type: 'range';
  min: number;
  max: number;
  step: number;
  value: number;
}

interface ToggleControl extends BaseControl {
  type: 'toggle';
  value: boolean;
}

type ControlItem = RangeControl | ToggleControl;

interface SpatialControlPanelProps {
  position: [number, number, number];
  controls: ControlItem[];
  onControlChange: (id: string, newValue: number | boolean) => void;
}

// User-defined Type Guard for RangeControl
function isRangeControl(control: ControlItem): control is RangeControl {
  return control.type === 'range';
}

export const SpatialControlPanel: React.FC<SpatialControlPanelProps> = ({
  position,
  controls,
  onControlChange,
}) => {
  return (
    <group position={position}>
      <Html transform distanceFactor={10} className="spatial-panel-root">
        <div style={{ background: 'rgba(20, 20, 20, 0.85)', padding: '16px', borderRadius: '12px', color: '#fff', width: '250px' }}>
          <h3>Spatial Controls</h3>
          {controls.map((control) => (
            <div key={control.id} style={{ margin: '10px 0', display: 'flex', flexDirection: 'column' }}>
              <label>{control.label}</label>
              {isRangeControl(control) ? (
                <input
                  type="range"
                  min={control.min}
                  max={control.max}
                  step={control.step}
                  value={control.value}
                  onChange={(e) => onControlChange(control.id, parseFloat(e.target.value))}
                />
              ) : (
                <input
                  type="checkbox"
                  checked={control.value}
                  onChange={(e) => onControlChange(control.id, e.target.checked)}
                />
              )}
            </div>
          ))}
        </div>
      </Html>
    </group>
  );
};
