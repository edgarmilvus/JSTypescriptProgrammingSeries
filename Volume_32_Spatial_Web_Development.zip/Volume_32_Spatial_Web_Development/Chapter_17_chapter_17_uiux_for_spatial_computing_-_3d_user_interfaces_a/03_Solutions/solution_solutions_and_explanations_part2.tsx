/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, useCursor } from '@react-three/drei';
import * as THREE from 'three';

interface DepthAwareMenuProps {
  position: [number, number, number];
  onSelect: (itemId: string) => void;
}

export const DepthAwareMenu: React.FC<DepthAwareMenuProps> = ({ position, onSelect }) => {
  const groupRef = useRef<THREE.Group>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [scaleFactor, setScaleFactor] = useState<number>(1);

  useCursor(hoveredIndex !== null);

  useFrame(({ camera }) => {
    if (!groupRef.current) return;
    
    // Calculate distance between active camera and menu world position
    const worldPos = new THREE.Vector3();
    groupRef.current.getWorldPosition(worldPos);
    const distance = camera.position.distanceTo(worldPos);

    // Apply distance thresholds to dynamically modulate scale to prevent clipping or illegibility
    const minDistance = 1;
    const maxDistance = 10;
    
    let calculatedScale = distance * 0.15;
    calculatedScale = Math.max(0.8, Math.min(calculatedScale, 2.5));
    
    setScaleFactor(calculatedScale);
  });

  return (
    <group ref={groupRef} position={position} scale={[scaleFactor, scaleFactor, scaleFactor]}>
      <Html transform distanceFactor={10}>
        <div className="spatial-menu-container" style={{ background: 'rgba(0,0,0,0.8)', padding: '12px', borderRadius: '8px', color: 'white' }}>
          <h4>Immersive Menu</h4>
          {['Resume', 'Settings', 'Exit'].map((label, index) => (
            <button
              key={label}
              onPointerOver={() => setHoveredIndex(index)}
              onPointerOut={() => setHoveredIndex(null)}
              onClick={() => onSelect(label.toLowerCase())}
              style={{
                display: 'block',
                margin: '6px 0',
                padding: '8px 12px',
                background: hoveredIndex === index ? '#4f46e5' : '#1f2937',
                border: 'none',
                borderRadius: '4px',
                color: 'white',
                cursor: 'pointer',
              }}
            >
              {label}
            </button>
          ))}
        </div>
      </Html>
    </group>
  );
};
