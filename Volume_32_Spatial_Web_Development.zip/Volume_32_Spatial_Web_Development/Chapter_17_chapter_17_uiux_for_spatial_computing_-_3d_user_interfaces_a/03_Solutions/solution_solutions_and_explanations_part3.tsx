/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { Html } from '@react-three/drei';
import { useChat } from 'ai/react';

interface SpatialAssistantOverlayProps {
  position: [number, number, number];
  edgeEndpoint: string;
}

function isValidMessagePayload(data: unknown): data is { text: string; timestamp: number } {
  return (
    typeof data === 'object' &&
    data !== null &&
    'text' in data &&
    typeof (data as any).text === 'string' &&
    'timestamp' in data &&
    typeof (data as any).timestamp === 'number'
  );
}

export const SpatialAssistantOverlay: React.FC<SpatialAssistantOverlayProps> = ({
  position,
  edgeEndpoint,
}) => {
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: edgeEndpoint,
  });

  const onSubmitWithValidation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (input.trim().length === 0) return;

    // Construct telemetry payload for edge validation check
    const payload = { text: input, timestamp: Date.now() };

    if (!isValidMessagePayload(payload)) {
      console.error('Validation failed: Malformed chat payload');
      return;
    }

    handleSubmit(e);
  };

  return (
    <group position={position}>
      <Html transform distanceFactor={12} className="spatial-chat-root">
        <div className="chat-window" style={{ width: '320px', background: 'rgba(15, 23, 42, 0.9)', padding: '16px', borderRadius: '12px', color: '#f8fafc' }}>
          <h3>Spatial AI Assistant</h3>
          <div className="messages-container" style={{ height: '200px', overflowY: 'auto', marginBottom: '10px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {messages.map((m) => (
              <div key={m.id} className={`message ${m.role}`} style={{ background: m.role === 'user' ? '#334155' : '#1e293b', padding: '8px', borderRadius: '6px' }}>
                <strong>{m.role === 'user' ? 'You' : 'AI'}: </strong>
                <span>{m.content}</span>
              </div>
            ))}
          </div>
          <form onSubmit={onSubmitWithValidation} style={{ display: 'flex', gap: '8px' }}>
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Ask the assistant..."
              style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #475569', background: '#0f172a', color: '#fff' }}
            />
            <button type="submit" style={{ padding: '8px 12px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: '4px' }}>Send</button>
          </form>
        </div>
      </Html>
    </group>
  );
};
