/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { Html } from '@react-three/drei';

interface BaseToast {
  id: string;
  timestamp: number;
  message: string;
}

interface ErrorToast extends BaseToast {
  type: 'error';
  errorCode: number;
  stackTrace?: string;
}

interface TelemetryToast extends BaseToast {
  type: 'telemetry';
  fps: number;
  latencyMs: number;
}

interface InfoToast extends BaseToast {
  type: 'info';
}

type SpatialNotification = ErrorToast | TelemetryToast | InfoToast;

function isErrorToast(toast: SpatialNotification): toast is ErrorToast {
  return toast.type === 'error';
}

function isTelemetryToast(toast: SpatialNotification): toast is TelemetryToast {
  return toast.type === 'telemetry';
}

interface SpatialToastManagerProps {
  position: [number, number, number];
  notifications: SpatialNotification[];
  onDismiss: (id: string) => void;
}

export const SpatialToastManager: React.FC<SpatialToastManagerProps> = ({
  position,
  notifications,
  onDismiss,
}) => {
  return (
    <group position={position}>
      <Html transform distanceFactor={8}>
        <div className="spatial-toast-stack" style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '280px' }}>
          {notifications.map((toast) => {
            let badgeColor = '#3b82f6';
            if (isErrorToast(toast)) badgeColor = '#ef4444';
            if (isTelemetryToast(toast)) badgeColor = '#10b981';

            return (
              <div
                key={toast.id}
                className={`toast-card ${toast.type}`}
                style={{
                  background: 'rgba(15, 23, 42, 0.9)',
                  borderLeft: `4px solid ${badgeColor}`,
                  padding: '10px 14px',
                  borderRadius: '6px',
                  color: '#fff',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                  <span style={{ fontSize: '13px' }}>{toast.message}</span>
                  {isErrorToast(toast) && (
                    <span style={{ fontSize: '10px', color: '#fca5a5' }}>Code: {toast.errorCode}</span>
                  )}
                  {isTelemetryToast(toast) && (
                    <span style={{ fontSize: '10px', color: '#6ee7b7' }}>FPS: {toast.fps} | Latency: {toast.latencyMs}ms</span>
                  )}
                </div>
                <button
                  onClick={() => onDismiss(toast.id)}
                  style={{ background: 'transparent', border: 'none', color: '#94a3b8', cursor: 'pointer', fontWeight: 'bold' }}
                >
                  ✕
                </button>
              </div>
            );
          })}
        </div>
      </Html>
    </group>
  );
};
