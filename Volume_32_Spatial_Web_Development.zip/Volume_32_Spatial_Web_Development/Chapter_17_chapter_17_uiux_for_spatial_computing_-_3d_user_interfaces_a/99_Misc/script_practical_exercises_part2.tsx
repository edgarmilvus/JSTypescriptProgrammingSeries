/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, useCursor } from '@react-three/drei';
import * as THREE from 'three';

interface DepthAwareMenuProps {
  position: [number, number, number];
  onSelect: (itemId: string) => void;
}

export const DepthAwareMenu: React.FC<DepthAwareMenuProps> = ({ position, onSelect }) => {
  const groupRef = useRef<THREE.Group>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [scaleFactor, setScaleFactor] = useState<number>(1);

  useCursor(hoveredIndex !== null);

  useFrame(({ camera }) => {
    if (!groupRef.current) return;
    
    // TODO: Calculate distance between camera and groupRef.current position
    // TODO: Update scaleFactor based on distance thresholds
  });

  return (
    <group ref={groupRef} position={position} scale={[scaleFactor, scaleFactor, scaleFactor]}>
      <Html transform distanceFactor={10}>
        <div className="spatial-menu-container">
          {/* Render interactive menu items here */}
        </div>
      </Html>
    </group>
  );
};
