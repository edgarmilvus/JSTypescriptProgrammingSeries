/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';
import { Html } from '@react-three/drei';
import { useChat } from 'ai/react';

interface SpatialAssistantOverlayProps {
  position: [number, number, number];
  edgeEndpoint: string;
}

// TODO: Implement edge validation type guard for incoming message payloads
function isValidMessagePayload(data: unknown): data is { text: string; timestamp: number } {
  return (
    typeof data === 'object' &&
    data !== null &&
    'text' in data &&
    typeof (data as any).text === 'string' &&
    'timestamp' in data &&
    typeof (data as any).timestamp === 'number'
  );
}

export const SpatialAssistantOverlay: React.FC<SpatialAssistantOverlayProps> = ({
  position,
  edgeEndpoint,
}) => {
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: edgeEndpoint,
  });

  const onSubmitWithValidation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Perform edge-first local sanitization and validation before submitting
    if (input.trim().length === 0) return;
    handleSubmit(e);
  };

  return (
    <group position={position}>
      <Html transform distanceFactor={12} className="spatial-chat-root">
        <div className="chat-window">
          <div className="messages-container">
            {messages.map((m) => (
              <div key={m.id} className={`message ${m.role}`}>
                <span>{m.role}: </span>
                <span>{m.content}</span>
              </div>
            ))}
          </div>
          <form onSubmit={onSubmitWithValidation}>
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Ask the spatial assistant..."
            />
            <button type="submit">Send</button>
          </form>
        </div>
      </Html>
    </group>
  );
};
