/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import React from 'react';
import { Html } from '@react-three/drei';
import { useXR } from '@react-three/xr'; // Assuming standard R3F XR hooks

interface AdaptiveNavigationBarProps {
  onNavigate: (route: string) => void;
}

export const AdaptiveNavigationBar: React.FC<AdaptiveNavigationBarProps> = ({ onNavigate }) => {
  // TODO: Retrieve presentational state from useXR hook
  const isPresenting = false; // Replace with actual useXR state check

  if (!isPresenting) {
    // Render standard DOM overlay for desktop mode
    return (
      <div style={{ position: 'fixed', bottom: '20px', left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}>
        <button onClick={() => onNavigate('home')}>Home</button>
        <button onClick={() => onNavigate('settings')}>Settings</button>
        <button onClick={() => onNavigate('analytics')}>Analytics</button>
      </div>
    );
  }

  // Render spatial 3D floating overlay for immersive WebXR mode
  return (
    <group position={[0, -0.4, -1]}>
      <Html transform distanceFactor={2}>
        <div className="spatial-nav-bar" style={{ display: 'flex', gap: '10px', background: 'rgba(0,0,0,0.8)', padding: '10px', borderRadius: '8px' }}>
          <button onClick={() => onNavigate('home')}>Home</button>
          <button onClick={() => onNavigate('settings')}>Settings</button>
          <button onClick={() => onNavigate('analytics')}>Analytics</button>
        </div>
      </Html>
    </group>
  );
};
