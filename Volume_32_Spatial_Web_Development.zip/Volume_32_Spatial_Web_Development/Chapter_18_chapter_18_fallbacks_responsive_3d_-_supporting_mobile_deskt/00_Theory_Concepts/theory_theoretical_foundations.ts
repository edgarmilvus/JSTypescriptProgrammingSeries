/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph SpatialResponsiveArchitecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Arial", fillcolor="#f0f4f8", color="#333333"];
    edge [fontname="Arial", fontsize=10];

    Client [label="Client Device Request\n(Browser / XR Runtime)", fillcolor="#d0e1fd"];
    Detection [label="Device & Capability Detection\n(WebXR API, Hardware Concurrency, GPU Tier)", fillcolor="#ffe5d9"];
    
    SubGraph [label="", style=invis];

    Desktop [label="Desktop / High-End GPU\n(Full 3D / 144Hz)", fillcolor="#d4edda"];
    Mobile [label="Mobile / Touchscreen\n(Optimized 3D / Touch Gestures)", fillcolor="#fff3cd"];
    XR [label="Immersive XR Headset\n(Stereoscopic Spatial / 90Hz)", fillcolor="#e2d9f3"];
    Fallback [label="Unsupported / Low-End\n(Graceful 2D Fallback Interface)", fillcolor="#f8d7da"];

    Client -> Detection;
    Detection -> Desktop [label="High Performance"];
    Detection -> Mobile [label="Touch & Constraints"];
    Detection -> XR [label="WebXR Capable"];
    Detection -> Fallback [label="No WebGL / Unsupported"];

    Desktop -> R3F_Full [label="Render Full Scene Graph"];
    Mobile -> R3F_Optimized [label="Reduce LOD & Shadow Maps"];
    XR -> R3F_Spatial [label="Enable Spatial Tracking & Controllers"];
    Fallback -> HTML_DOM [label="Render HTML / CSS UI"];
}
