/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing the operational metrics of a SaaS server node
 * visualized in the 3D spatial interface.
 */
interface ServerNodeProps {
  isMobile: boolean;
  nodeId: string;
}

/**
 * 3D Mesh Component representing an individual server node.
 * Dynamically scales its geometry and interaction radii based on device constraints.
 */
const ServerNodeMesh: React.FC<ServerNodeProps> = ({ isMobile, nodeId }) => {
  const meshRef = useRef<THREE.Mesh>(null!);
  const [hovered, setHovered] = useState(false);

  // Rotate the server node slightly each frame for ambient motion
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  // Scale down geometries for mobile viewports to prevent screen clipping
  const scaleFactor = isMobile ? 0.6 : 1.2;

  return (
    <group>
      <mesh
        ref={meshRef}
        scale={[scaleFactor, scaleFactor, scaleFactor]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <boxGeometry args={[1.5, 1.5, 1.5]} />
        <meshStandardMaterial 
          color={hovered ? '#3b82f6' : '#1e293b'} 
          roughness={0.3}
          metalness={0.8}
        />
      </mesh>
      
      {/* Floating UI text label anchored above the 3D node */}
      <Text
        position={[0, scaleFactor + 0.8, 0]}
        fontSize={0.25}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {`Node: ${nodeId}`}
      </Text>
    </group>
  );
};

/**
 * Main SaaS Dashboard Spatial Component containing hardware detection logic,
 * canvas orchestration, and automated 2D fallback handling.
 */
export default function SpatialDashboardApp() {
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [hasWebGLSupport, setHasWebGLSupport] = useState<boolean>(true);
  const [mounted, setMounted] = useState<boolean>(false);

  // Execute client-side hardware and viewport diagnostics on mount
  useEffect(() => {
    setMounted(true);

    // 1. Check for WebGL / WebGPU rendering context availability
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) {
        setHasWebGLSupport(false);
      }
    } catch (e) {
      setHasWebGLSupport(false);
    }

    // 2. Evaluate viewport dimensions to categorize mobile vs desktop layout profiles
    const checkViewport = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkViewport();
    window.addEventListener('resize', checkViewport);
    return () => window.removeEventListener('resize', checkViewport);
  }, []);

  // Prevent server-side hydration mismatches by returning null during SSR pass
  if (!mounted) return null;

  // Graceful 2D Fallback UI for hardware lacking WebGL/WebGPU/XR capabilities
  if (!hasWebGLSupport) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-950 text-slate-100 p-6">
        <div className="max-w-md bg-slate-900 border border-slate-800 rounded-xl p-8 shadow-2xl">
          <h2 className="text-xl font-bold mb-3 text-red-400">Spatial Context Unavailable</h2>
          <p className="text-slate-400 mb-6 text-sm leading-relaxed">
            Your current browser or hardware environment does not support WebGL/WebGPU acceleration required for this 3D SaaS infrastructure map. Displaying standard fallback metrics console.
          </p>
          <div className="bg-slate-950 p-4 rounded border border-slate-800 font-mono text-xs text-emerald-400">
            STATUS: 2D_FALLBACK_MODE_ACTIVE<br />
            NODE_CLUSTER_ID: us-east-prod-01<br />
            HEALTH: NOMINAL
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen bg-slate-950 overflow-hidden">
      {/* SaaS HTML HUD Overlay */}
      <div className="absolute top-4 left-4 z-10 pointer-events-none bg-slate-900/80 backdrop-blur-md border border-slate-800 p-4 rounded-lg shadow-lg">
        <h1 className="text-white font-bold text-sm">Cloud Infrastructure 3D</h1>
        <p className="text-xs text-slate-400">Mode: {isMobile ? 'Mobile Touch Viewport' : 'Desktop Spatial Viewport'}</p>
      </div>

      {/* React Three Fiber Canvas with Responsive Camera Settings */}
      <Canvas
        camera={{ position: [0, 0, isMobile ? 6 : 4], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
      >
        <color attach="background" args={['#020617']} />
        <ambientLight intensity={0.7} />
        <directionalLight position={[10, 10, 5]} intensity={1.5} />
        
        <ServerNodeMesh isMobile={isMobile} nodeId="us-east-cluster-01" />
        
        <OrbitControls 
          enableZoom={true} 
          enablePan={!isMobile} // Restrict panning on touch screens to avoid layout trapping
          maxDistance={10}
          minDistance={2}
        />
      </Canvas>
    </div>
  );
}
