/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { 
  useState, 
  useEffect, 
  useTransition, 
  useMemo, 
  useRef, 
  Suspense, 
  createContext, 
  useContext 
} from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  XR, 
  createXRStore, 
  XRStore, 
  useXR, 
  useController 
} from '@react-three/xr';
import { Html, OrbitControls, useGLTF } from '@react-three/drei';
import * as THREE from 'three';

/**
 * ============================================================================
 * SECTION 1: TYPES, INTERFACES, & APP CONTEXT
 * ============================================================================
 */

export type DeviceTier = 'desktop' | 'mobile' | 'xr';

export interface DeviceCapabilities {
  tier: DeviceTier;
  isXRSupported: boolean;
  maxTextureSize: number;
  pixelRatio: number;
  dpr: [number, number];
  targetFps: number;
}

interface SpatialAppState {
  capabilities: DeviceCapabilities;
  currentAssetId: string;
  isLowPowerMode: boolean;
  setAssetId: (id: string) => void;
  toggleLowPowerMode: () => void;
}

const SpatialAppContext = createContext<SpatialAppState | null>(null);

/**
 * Custom hook to consume the global spatial application state safely.
 */
export function useSpatialApp() {
  const context = useContext(SpatialAppContext);
  if (!context) {
    throw new Error('useSpatialApp must be used within a SpatialAppProvider');
  }
  return context;
}

/**
 * XR Store instance for WebXR session orchestration.
 */
const xrStore = createXRStore();

/**
 * ============================================================================
 * SECTION 2: DEVICE DETECTION & RESPONSIVE HOOKS
 * ============================================================================
 */

/**
 * Custom React hook that evaluates hardware capabilities, pixel density,
 * WebXR support, and categorizes the client into a performance tier.
 */
export function useDeviceCapabilities(): DeviceCapabilities {
  const [capabilities, setCapabilities] = useState<DeviceCapabilities>({
    tier: 'desktop',
    isXRSupported: false,
    maxTextureSize: 4096,
    pixelRatio: 1,
    dpr: [1, 2],
    targetFps: 60,
  });

  useEffect(() => {
    let isMounted = true;

    async function evaluateHardware() {
      // 1. Detect WebXR support via navigator
      let xrSupported = false;
      if (typeof navigator !== 'undefined' && 'xr' in navigator) {
        try {
          xrSupported = await (navigator as any).xr.isSessionSupported('immersive-vr');
        } catch (e) {
          xrSupported = false;
        }
      }

      // 2. Estimate max texture size using a temporary WebGL context
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      let maxTexSize = 4096;
      if (gl) {
        maxTexSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
      }

      // 3. Determine device tier based on user agent, touch capability, and hardware concurrency
      const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      const isMobileUA = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent
      );

      let detectedTier: DeviceTier = 'desktop';
      if (isMobileUA || (isTouch && window.innerWidth < 768)) {
        detectedTier = 'mobile';
      }

      const dpr = window.devicePixelRatio || 1;

      if (isMounted) {
        setCapabilities({
          tier: detectedTier,
          isXRSupported: xrSupported,
          maxTextureSize: maxTexSize,
          pixelRatio: dpr,
          dpr: detectedTier === 'mobile' ? [1, 1.5] : [1, Math.min(dpr, 2)],
          targetFps: detectedTier === 'mobile' ? 30 : 60,
        });
      }
    }

    evaluateHardware();

    return () => {
      isMounted = false;
    };
  }, []);

  return capabilities;
}

/**
 * ============================================================================
 * SECTION 3: 3D ASSET & INTERACTIVE COMPONENTS (R3F)
 * ============================================================================
 */

interface CADModelProps {
  assetId: string;
  isLowPowerMode: boolean;
}

/**
 * Renders the 3D asset with responsive level-of-detail (LOD) handling,
 * material downscaling for mobile/low-power modes, and spatial interaction logic.
 */
function CADModel({ assetId, isLowPowerMode }: CADModelProps) {
  const meshRef = useRef<THREE.Group>(null);
  const [isHovered, setIsHovered] = useState(false);
  const { viewport, camera } = useThree();

  // Continuous subtle rotation for idle state, scaled down in low power mode
  useFrame((state, delta) => {
    if (meshRef.current && !isLowPowerMode) {
      meshRef.current.rotation.y += delta * 0.2;
    }
  });

  return (
    <group ref={meshRef} position={[0, 0, -2]}>
      {/* Interactive 3D Mesh representing a CAD engineering part */}
      <mesh
        onPointerOver={() => setIsHovered(true)}
        onPointerOut={() => setIsHovered(false)}
        scale={isHovered ? [1.1, 1.1, 1.1] : [1, 1, 1]}
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial 
          color={isHovered ? '#3b82f6' : '#64748b'} 
          roughness={isLowPowerMode ? 0.8 : 0.3}
          metalness={isLowPowerMode ? 0.1 : 0.8}
          wireframe={isLowPowerMode}
        />
      </mesh>

      {/* Spatial HTML annotation anchored to the 3D model */}
      <Html position={[0, 1.2, 0]} center distanceFactor={8}>
        <div className="px-3 py-1 bg-slate-900/80 backdrop-blur-md text-white text-xs rounded-full border border-slate-700 shadow-xl pointer-events-none transition-all">
          Part #{assetId.toUpperCase()} {isLowPowerMode && '(Eco Mode)'}
        </div>
      </Html>
    </group>
  );
}

/**
 * Manages lighting setups dynamically based on performance budgets.
 */
function ResponsiveLighting({ isLowPowerMode }: { isLowPowerMode: boolean }) {
  return (
    <>
      <ambientLight intensity={isLowPowerMode ? 1.0 : 0.7} />
      {!isLowPowerMode && (
        <>
          <directionalLight position={[5, 5, 5]} intensity={1.5} castShadow />
          <pointLight position={[-5, -5, -5]} intensity={0.5} />
        </>
      )}
    </>
  );
}

/**
 * ============================================================================
 * SECTION 4: 2D FALLBACK INTERFACE (FOR NON-XR / LOW-POWER CLIENTS)
 * ============================================================================
 */

interface Fallback2DViewProps {
  assetId: string;
  onLaunchXRAttempt: () => void;
}

/**
 * Robust 2D HTML/CSS fallback interface providing full application parity
 * when WebXR or WebGL hardware acceleration is unavailable or disabled.
 */
function Fallback2DView({ assetId, onLaunchXRAttempt }: Fallback2DViewProps) {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-slate-100 p-6">
      <div className="max-w-md w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-8 shadow-2xl backdrop-blur-xl flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-blue-600/20 border border-blue-500/30 rounded-full flex items-center justify-center mb-6 text-blue-400">
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        </div>
        
        <h2 className="text-xl font-bold tracking-tight mb-2">2D Compatibility Mode</h2>
        <p className="text-sm text-slate-400 mb-6 leading-relaxed">
          Your current environment is optimized for standard desktop/mobile interaction. WebXR hardware or high-performance acceleration is bypassed.
        </p>

        <div className="w-full bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 mb-6 text-left">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Loaded Asset Spec</div>
          <div className="flex justify-between text-sm">
            <span className="text-slate-300">Identifier:</span>
            <span className="font-mono text-blue-400">{assetId}</span>
          </div>
          <div className="flex justify-between text-sm mt-1">
            <span className="text-slate-300">Rendering Engine:</span>
            <span className="font-mono text-emerald-400">SVG / HTML5 Fallback</span>
          </div>
        </div>

        <button
          onClick={onLaunchXRAttempt}
          className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-xl transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98]"
        >
          Attempt Immersive Session
        </button>
      </div>
    </div>
  );
}

/**
 * ============================================================================
 * SECTION 5: ROOT APPLICATION CONTAINER & STATE ORCHESTRATION
 * ============================================================================
 */

export default function SpatialAppRoot() {
  const capabilities = useDeviceCapabilities();
  const [assetId, setAssetId] = useState<string>('turbine-assembly-01');
  const [isLowPowerMode, setIsLowPowerMode] = useState<boolean>(false);
  const [isPending, startTransition] = useTransition();
  const [forceFallback, setForceFallback] = useState<boolean>(false);

  // Automatically enable low power mode on mobile devices by default
  useEffect(() => {
    if (capabilities.tier === 'mobile') {
      setIsLowPowerMode(true);
    }
  }, [capabilities.tier]);

  const handleAssetChange = (newId: string) => {
    startTransition(() => {
      setAssetId(newId);
    });
  };

  const toggleLowPowerMode = () => {
    setIsLowPowerMode((prev) => !prev);
  };

  const appContextValue = useMemo(() => ({
    capabilities,
    currentAssetId: assetId,
    isLowPowerMode,
    setAssetId: handleAssetChange,
    toggleLowPowerMode,
  }), [capabilities, assetId, isLowPowerMode]);

  // Determine whether to display the 3D Canvas or the 2D Fallback view
  const showFallback = forceFallback || (!capabilities.isXRSupported && capabilities.tier === 'mobile' && isLowPowerMode);

  return (
    <SpatialAppContext.Provider value={appContextValue}>
      <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans">
        {/* Top Control Bar / SaaS Header */}
        <header className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 bg-slate-900/60 backdrop-blur-md border-b border-slate-800/80">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
              <span className="font-bold text-sm tracking-tight text-white">SPATIAL-SaaS OS</span>
            </div>
            <div className="hidden md:flex items-center space-x-2 text-xs text-slate-400 bg-slate-800/50 px-3 py-1 rounded-full border border-slate-700/50">
              <span>Tier: <strong className="text-slate-200 uppercase">{capabilities.tier}</strong></span>
              <span>•</span>
              <span>XR: <strong className={capabilities.isXRSupported ? 'text-emerald-400' : 'text-amber-400'}>{capabilities.isXRSupported ? 'Ready' : 'Unavailable'}</strong></span>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => handleAssetChange(assetId === 'turbine-assembly-01' ? 'generator-unit-02' : 'turbine-assembly-01')}
              disabled={isPending}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 rounded-lg border border-slate-700 transition-all disabled:opacity-50"
            >
              {isPending ? 'Switching...' : 'Swap Asset'}
            </button>

            <button
              onClick={toggleLowPowerMode}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                isLowPowerMode 
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' 
                  : 'bg-slate-800 border-slate-700 text-slate-200'
              }`}
            >
              {isLowPowerMode ? 'Eco Mode: ON' : 'Eco Mode: OFF'}
            </button>

            {capabilities.isXRSupported && !forceFallback && (
              <button
                onClick={() => xrStore.enterVR()}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white rounded-lg shadow-lg shadow-indigo-600/20 transition-all"
              >
                Enter VR
              </button>
            )}

            <button
              onClick={() => setForceFallback((prev) => !prev)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-400 hover:text-slate-200 rounded-lg border border-slate-700 transition-all"
            >
              {forceFallback ? 'Return to 3D' : 'Force 2D Fallback'}
            </button>
          </div>
        </header>

        {/* Main Viewport Container */}
        <main className="w-full h-full pt-16">
          {showFallback ? (
            <Fallback2DView 
              assetId={assetId} 
              onLaunchXRAttempt={() => setForceFallback(false)} 
            />
          ) : (
            <Canvas
              gl={{ 
                powerPreference: isLowPowerMode ? 'low-power' : 'high-performance',
                antialias: !isLowPowerMode,
                stencil: false,
                depth: true
              }}
              dpr={capabilities.dpr}
              camera={{ position: [0, 0, 5], fov: 50 }}
            >
              <XR store={xrStore}>
                <ResponsiveLighting isLowPowerMode={isLowPowerMode} />
                <Suspense fallback={null}>
                  <CADModel assetId={assetId} isLowPowerMode={isLowPowerMode} />
                </Suspense>
                <OrbitControls 
                  enableDamping 
                  dampingFactor={0.05} 
                  maxDistance={10} 
                  minDistance={1.5} 
                />
              </XR>
            </Canvas>
          )}
        </main>
      </div>
    </SpatialAppContext.Provider>
  );
}
