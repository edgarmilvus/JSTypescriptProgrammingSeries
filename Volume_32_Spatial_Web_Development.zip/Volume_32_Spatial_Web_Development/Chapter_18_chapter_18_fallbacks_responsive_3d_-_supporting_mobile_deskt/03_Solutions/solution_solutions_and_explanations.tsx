/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import { useThree } from '@react-three/fiber';
import { useMemo } from 'react';
import * as THREE from 'three';

interface ResponsiveScaleOptions<T> {
  baseScale: T;
  factor?: number;
  min?: number;
  max?: number;
}

export function useResponsiveScale<T extends number | [number, number, number]>(
  options: ResponsiveScaleOptions<T>
): T {
  const { viewport } = useThree();
  const { baseScale, factor = 1, min = 0.1, max = 10 } = options;

  return useMemo(() => {
    // Determine screen scale factor based on viewport width/height ratio or absolute size
    const screenMultiplier = Math.min(Math.max(viewport.width / 10 * factor, min), max);

    if (typeof baseScale === 'number') {
      const scaledValue = Math.min(Math.max(baseScale * screenMultiplier, min), max);
      return scaledValue as T;
    }

    if (Array.isArray(baseScale)) {
      const scaledTuple: [number, number, number] = [
        Math.min(Math.max(baseScale[0] * screenMultiplier, min), max),
        Math.min(Math.max(baseScale[1] * screenMultiplier, min), max),
        Math.min(Math.max(baseScale[2] * screenMultiplier, min), max),
      ];
      return scaledTuple as T;
    }

    return baseScale;
  }, [viewport.width, viewport.height, baseScale, factor, min, max]);
}

// Example Component Usage:
export function ResponsiveProductCard() {
  const scale = useResponsiveScale({
    baseScale: [1.5, 1.5, 1.5] as [number, number, number],
    factor: 0.8,
    min: 0.5,
    max: 3.0,
  });

  return (
    <mesh scale={scale}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="royalblue" />
    </mesh>
  );
}
