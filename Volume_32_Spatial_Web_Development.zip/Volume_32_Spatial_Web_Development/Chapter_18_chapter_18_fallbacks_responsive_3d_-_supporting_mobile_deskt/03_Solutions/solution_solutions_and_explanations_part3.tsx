/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, ReactNode } from 'react';

interface XRCompatibilityBoundaryProps {
  children: ReactNode;
  fallback: (reason: string) => ReactNode;
}

export const XRCompatibilityBoundary: React.FC<XRCompatibilityBoundaryProps> = ({
  children,
  fallback
}) => {
  const [isSupported, setIsSupported] = useState<boolean | null>(null);
  const [reason, setReason] = useState<string>('Checking hardware capabilities...');

  useEffect(() => {
    let isMounted = true;

    async function checkXR() {
      if (typeof window === 'undefined' || !navigator.xr) {
        if (isMounted) {
          setIsSupported(false);
          setReason('WebXR is not supported by your browser or environment.');
        }
        return;
      }

      try {
        const supported = await navigator.xr.isSessionSupported('immersive-vr');
        if (isMounted) {
          setIsSupported(supported);
          if (!supported) {
            setReason('Immersive VR sessions are not supported on this device.');
          }
        }
      } catch (err) {
        if (isMounted) {
          setIsSupported(false);
          setReason('An error occurred while probing XR hardware.');
        }
      }
    }

    checkXR();

    return () => {
      isMounted = false;
    };
  }, []);

  if (isSupported === null) {
    return null; // Or a loading spinner
  }

  if (!isSupported) {
    return <>{fallback(reason)}</>;
  }

  return <>{children}</>;
};
