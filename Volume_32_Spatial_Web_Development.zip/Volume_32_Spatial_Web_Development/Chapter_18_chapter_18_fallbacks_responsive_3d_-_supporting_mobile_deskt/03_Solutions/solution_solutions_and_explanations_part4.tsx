/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import * as THREE from 'three';

interface ScreenCoordinates {
  x: number;
  y: number;
  visible: boolean;
}

export function calculateScreenPosition<T extends THREE.Vector3>(
  position: T,
  camera: THREE.Camera,
  size: { width: number; height: number }
): ScreenCoordinates {
  const tempVector = position.clone();
  
  // Project 3D vector to Normalized Device Coordinates (NDC) [-1, 1]
  tempVector.project(camera);

  // Check if object is behind the camera (NDC z > 1)
  const visible = tempVector.z <= 1;

  // Convert NDC to pixel coordinates relative to screen center, then offset to top-left origin
  const x = (tempVector.x * 0.5 + 0.5) * size.width;
  const y = (-(tempVector.y * 0.5) + 0.5) * size.height;

  // Clamp coordinates within screen bounds if needed
  const clampedX = Math.max(0, Math.min(size.width, x));
  const clampedY = Math.max(0, Math.min(size.height, y));

  return {
    x: clampedX,
    y: clampedY,
    visible,
  };
}
