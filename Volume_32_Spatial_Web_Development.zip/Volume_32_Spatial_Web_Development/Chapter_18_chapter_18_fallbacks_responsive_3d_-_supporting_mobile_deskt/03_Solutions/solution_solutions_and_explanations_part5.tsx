/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import { useFrame } from '@react-three/fiber';
import { useState, useCallback, useRef } from 'react';

type PerformanceTier = 'low' | 'medium' | 'high';

interface UsePerformanceMonitorReturn {
  tier: PerformanceTier;
  fps: number;
  manualOverride: (tier: PerformanceTier) => void;
}

export function usePerformanceMonitor(): UsePerformanceMonitorReturn {
  const [tier, setTier] = useState<PerformanceTier>('high');
  const [fps, setFps] = useState<number>(60);
  
  const frameCount = useRef(0);
  const accumulatedTime = useRef(0);
  const lowFpsCounter = useRef(0);

  useFrame((_, delta) => {
    frameCount.current += 1;
    accumulatedTime.current += delta;

    // Calculate metrics every 1 second
    if (accumulatedTime.current >= 1.0) {
      const currentFps = Math.round(frameCount.current / accumulatedTime.current);
      setFps(currentFps);

      // Frame-rate watchdog logic
      if (currentFps < 45) {
        lowFpsCounter.current += 1;
        // If FPS drops below 45 for 3 consecutive check cycles, downgrade tier
        if (lowFpsCounter.current >= 3) {
          setTier((prev) => (prev === 'high' ? 'medium' : prev === 'medium' ? 'low' : 'low'));
          lowFpsCounter.current = 0; // Reset counter
        }
      } else {
        lowFpsCounter.current = Math.max(0, lowFpsCounter.current - 1);
      }

      frameCount.current = 0;
      accumulatedTime.current = 0;
    }
  });

  const manualOverride = useCallback((newTier: PerformanceTier) => {
    setTier(newTier);
  }, []);

  return { tier, fps, manualOverride };
}
