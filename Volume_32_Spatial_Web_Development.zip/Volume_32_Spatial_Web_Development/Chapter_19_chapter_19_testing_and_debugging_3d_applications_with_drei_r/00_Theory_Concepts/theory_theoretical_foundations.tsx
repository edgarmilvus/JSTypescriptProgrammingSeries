/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.tsx
// Description: Theoretical Foundations
// ==========================================

import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface PerformanceMonitorProps {
  onMetricsUpdate?: (fps: number, frameTime: number) => void;
}

export const CustomPerformanceMonitor: React.FC<PerformanceMonitorProps> = ({ onMetricsUpdate }) => {
  const frameCount = useRef(0);
  const lastTime = useRef(performance.now());
  const accumulatedTime = useRef(0);

  useFrame((state, delta) => {
    const now = performance.now();
    frameCount.current += 1;
    accumulatedTime.current += (now - lastTime.current);
    lastTime.current = now;

    // Calculate metrics every second (1000ms)
    if (accumulatedTime.current >= 1000) {
      const fps = (frameCount.current * 1000) / accumulatedTime.current;
      const frameTimeMs = delta * 1000;

      if (onMetricsUpdate) {
        onMetricsUpdate(fps, frameTimeMs);
      }

      // Reset counters
      frameCount.current = 0;
      accumulatedTime.current = 0;
    }
  });

  return null; // This component is strictly for logic and profiling
};
