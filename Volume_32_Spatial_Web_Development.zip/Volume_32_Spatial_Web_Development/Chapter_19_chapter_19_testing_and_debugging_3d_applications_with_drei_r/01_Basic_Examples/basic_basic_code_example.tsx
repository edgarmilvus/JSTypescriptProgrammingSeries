/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useTransition, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  GizmoHelper, 
  GizmoViewport, 
  Center, 
  OrbitControls, 
  Stats 
} from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface representing the immutable configuration state of a 3D asset.
 */
interface AssetConfig {
  readonly id: string;
  readonly name: string;
  readonly scale: [number, number, number];
  readonly color: string;
  readonly roughness: number;
}

/**
 * Initial immutable state for our industrial CAD asset.
 */
const INITIAL_ASSET_CONFIG: AssetConfig = {
  id: 'asset-9021',
  name: 'Hydraulic Actuator v4',
  scale: [1, 1, 1],
  color: '#3b82f6', // Tailwind blue-500
  roughness: 0.2,
};

/**
 * R3F Component: IndustrialAsset
 * Renders the 3D mesh and updates internal materials using immutable properties.
 */
interface IndustrialAssetProps {
  config: AssetConfig;
  onInteract: () => void;
}

const IndustrialAsset: React.FC<IndustrialAssetProps> = ({ config, onInteract }) => {
  const meshRef = React.useRef<THREE.Mesh>(null!);
  const [hovered, setHovered] = useState(false);

  // Rotate the mesh slightly every frame to demonstrate render loop activity
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  return (
    // Center utility automatically computes bounding boxes and centers the model
    <Center>
      <mesh
        ref={meshRef}
        scale={config.scale}
        onClick={(e) => {
          e.stopPropagation();
          onInteract();
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHovered(true);
        }}
        onPointerOut={() => setHovered(false)}
      >
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial
          color={hovered ? '#60a5fa' : config.color}
          roughness={config.roughness}
          metalness={0.8}
        />
      </mesh>
    </Center>
  );
};

/**
 * Main SaaS Dashboard Component wrapping the 3D Canvas and UI Overlay.
 */
export default function SpatialAssetDashboard() {
  // Immutable state management for the 3D asset configuration
  const [assetConfig, setAssetConfig] = useState<AssetConfig>(INITIAL_ASSET_CONFIG);
  
  // React useTransition hook to keep UI responsive during heavy state changes or Server Actions
  const [isPending, startTransition] = useTransition();

  /**
   * Handles updating the asset color immutably.
   * Demonstrates copying the existing state object and overriding specific fields.
   */
  const handleColorChange = (newColor: string) => {
    startTransition(() => {
      setAssetConfig((prevConfig) => ({
        ...prevConfig,
        color: newColor,
      }));
    });
  };

  return (
    <div className="relative w-full h-screen bg-slate-950 text-white font-sans flex flex-col">
      {/* SaaS Top Navigation Bar */}
      <header className="flex justify-between items-center px-6 py-4 bg-slate-900 border-b border-slate-800 z-10">
        <h1 className="text-lg font-semibold tracking-wide">
          SpatialCorp CAD Inspector — <span className="text-blue-400">{assetConfig.name}</span>
        </h1>
        <div className="flex items-center gap-4 text-sm">
          {isPending && <span className="text-amber-400 animate-pulse">Updating State...</span>}
          <button
            onClick={() => handleColorChange('#10b981')} // Emerald
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded transition-colors"
          >
            Set Emerald Material
          </button>
          <button
            onClick={() => handleColorChange('#ef4444')} // Red
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 rounded transition-colors"
          >
            Set Ruby Material
          </button>
        </div>
      </header>

      {/* 3D Viewport Container */}
      <div className="relative flex-1 w-full h-full">
        <Canvas
          camera={{ position: [5, 5, 5], fov: 50 }}
          gl={{ antialias: true, powerPreference: 'high-performance' }}
        >
          {/* Ambient and Directional Lighting for PBR Materials */}
          <ambientLight intensity={0.7} />
          <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />

          {/* Suspense fallback for asynchronous 3D assets */}
          <Suspense fallback={null}>
            <IndustrialAsset
              config={assetConfig}
              onInteract={() => console.log('Asset interacted:', assetConfig.id)}
            />
          </Suspense>

          {/* Orbit Controls for User Navigation */}
          <OrbitControls makeDefault />

          {/* Drei Utility: GizmoHelper providing an orientation cube/axes */}
          <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
            <GizmoViewport 
              axisColors={['#ef4444', '#22c55e', '#3b82f6']} 
              labelColor="#ffffff" 
            />
          </GizmoHelper>

          {/* R3F Built-in / Drei Performance Monitor (FPS, Memory, Frames) */}
          <Stats />
        </Canvas>
      </div>
    </div>
  );
}
