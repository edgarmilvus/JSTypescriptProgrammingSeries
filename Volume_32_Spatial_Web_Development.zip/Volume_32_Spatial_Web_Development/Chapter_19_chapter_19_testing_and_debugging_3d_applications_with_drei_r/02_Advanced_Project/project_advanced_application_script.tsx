/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useRef, Suspense, useEffect } from 'react';
import { Canvas, useThree, useFrame } from '@react-three/fiber';
import { 
  GizmoHelper, 
  GizmoViewport, 
  Center, 
  OrbitControls, 
  useHelper,
  Html 
} from '@react-three/drei';
import * as THREE from 'three';

/**
 * Interface for application diagnostic metrics collected during runtime.
 */
interface DiagnosticMetrics {
  fps: number;
  drawCalls: number;
  triangles: number;
  memoryGeometries: number;
  memoryTextures: number;
}

/**
 * Performance monitor component that leverages useThree and useFrame 
 * to extract live WebGL renderer data and output to a React state interface.
 */
function SceneProfiler({ onUpdate }: { onUpdate: (metrics: DiagnosticMetrics) => void }) {
  const { gl } = useThree();
  const frameCount = useRef(0);
  const lastTime = useRef(performance.now());
  const currentFps = useRef(60);

  useFrame(() => {
    frameCount.current += 1;
    const now = performance.now();
    
    // Calculate FPS every second
    if (now - lastTime.current >= 1000) {
      currentFps.current = Math.round((frameCount.current * 1000) / (now - lastTime.current));
      frameCount.current = 0;
      lastTime.current = now;

      // Extract raw WebGL info parameters from the renderer
      const info = gl.info;
      onUpdate({
        fps: currentFps.current,
        drawCalls: info.render.calls,
        triangles: info.render.triangles,
        memoryGeometries: info.memory.geometries,
        memoryTextures: info.memory.textures,
      });
    }
  });

  return null;
}

/**
 * Target 3D Model with an attached helper for spatial orientation debugging.
 */
function ConfigurableAsset({ materialColor }: { materialColor: string }) {
  const meshRef = useRef<THREE.Mesh>(null!);
  
  // Attach a Three.js wireframe helper to visually inspect bounding boxes during development
  useHelper(meshRef, THREE.VertexNormalsHelper, 0.5, '#00ff00');

  useFrame((_, delta) => {
    // Gentle idle rotation to verify render loop stability
    meshRef.current.rotation.y += delta * 0.2;
  });

  return (
    // Drei's Center component automatically normalizes and centers arbitrary bounding boxes
    <Center>
      <mesh ref={meshRef} castShadow receiveShadow>
        <torusKnotGeometry args={[1, 0.3, 128, 32]} />
        <meshStandardMaterial color={materialColor} roughness={0.2} metalness={0.8} />
      </mesh>
    </Center>
  );
}

/**
 * Main application dashboard rendering the R3F Canvas and a Tailwind CSS diagnostic HUD.
 */
export default function SpatialConfiguratorApp() {
  const [color, setColor] = useState<string>('#3b82f6');
  const [metrics, setMetrics] = useState<DiagnosticMetrics>({
    fps: 60,
    drawCalls: 0,
    triangles: 0,
    memoryGeometries: 0,
    memoryTextures: 0,
  });

  return (
    <main className="w-full h-screen relative bg-slate-950 font-sans text-slate-100 flex flex-col">
      {/* Top Navigation Bar */}
      <header className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur z-10">
        <h1 className="text-lg font-semibold tracking-wide">Enterprise 3D Spatial Configurator</h1>
        <div className="flex items-center gap-4">
          <label className="text-sm text-slate-400">Material Finish:</label>
          <input 
            type="color" 
            value={color} 
            onChange={(e) => setColor(e.target.value)}
            className="w-8 h-8 rounded border-0 cursor-pointer bg-transparent"
          />
        </div>
      </header>

      {/* Main Viewport Container */}
      <div className="flex-1 relative">
        {/* Diagnostic Floating HUD */}
        <div className="absolute top-4 left-4 z-10 p-4 rounded-xl bg-slate-900/80 border border-slate-700/50 backdrop-blur-md shadow-2xl text-xs space-y-2 pointer-events-none w-64">
          <div className="font-bold text-slate-300 border-b border-slate-800 pb-1 flex justify-between">
            <span>R3F DIAGNOSTIC HUD</span>
            <span className={metrics.fps < 30 ? "text-red-400" : "text-emerald-400"}>{metrics.fps} FPS</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Draw Calls:</span>
            <span className="font-mono">{metrics.drawCalls}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Triangles:</span>
            <span className="font-mono">{metrics.triangles.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">GPU Geometries:</span>
            <span className="font-mono">{metrics.memoryGeometries}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">GPU Textures:</span>
            <span className="font-mono">{metrics.memoryTextures}</span>
          </div>
        </div>

        {/* R3F Canvas Context */}
        <Canvas 
          camera={{ position: [0, 2, 5], fov: 50 }}
          gl={{ antialias: true, powerPreference: "high-performance" }}
        >
          <color attach="background" args={['#090d16']} />
          
          {/* Lighting Rig */}
          <ambientLight intensity={0.7} />
          <directionalLight position={[10, 20, 15]} intensity={1.5} castShadow />
          
          {/* Scene Components & Testing Utilities */}
          <Suspense fallback={<Html center><div className="text-white animate-pulse">Loading Asset...</div></Html>}>
            <ConfigurableAsset materialColor={color} />
          </Suspense>

          {/* Drei Gizmo Helper for Axis Orientation */}
          <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
            <GizmoViewport axisColors={['#ef4444', '#22c55e', '#3b82f6']} labelColor="#ffffff" />
          </GizmoHelper>

          {/* Controls */}
          <OrbitControls makeDefault enableDamping dampingFactor={0.05} />

          {/* Performance Profiler Hook */}
          <SceneProfiler onUpdate={setMetrics} />
        </Canvas>
      </div>
    </main>
  );
}
