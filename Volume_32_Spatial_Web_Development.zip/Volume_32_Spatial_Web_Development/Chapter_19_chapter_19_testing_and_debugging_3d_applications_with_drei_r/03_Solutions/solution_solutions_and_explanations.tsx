/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';

interface PerformanceDebugOverlayProps {
  toggleKey?: string;
}

export const PerformanceDebugOverlay: React.FC<PerformanceDebugOverlayProps> = ({ toggleKey = 'd' }) => {
  const [visible, setVisible] = useState<boolean>(true);
  const [fps, setFps] = useState<number>(0);
  const [drawCalls, setDrawCalls] = useState<number>(0);
  const [memoryUsage, setMemoryUsage] = useState<string>('N/A');

  // Refs to track frame timing calculations without triggering React re-renders on every tick
  const frameCount = useRef<number>(0);
  const lastTime = useRef<number>(performance.now());

  // Keyboard toggle event listener
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === toggleKey.toLowerCase()) {
        setVisible((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [toggleKey]);

  // Calculate metrics on every frame tick
  useFrame((state) => {
    if (!visible) return;

    frameCount.current += 1;
    const currentTime = performance.now();
    const elapsed = currentTime - lastTime.current;

    // Update FPS once every second
    if (elapsed >= 1000) {
      setFps(Math.round((frameCount.current * 1000) / elapsed));
      frameCount.current = 0;
      lastTime.current = currentTime;

      // Extract WebGL renderer statistics
      setDrawCalls(state.gl.info.render.calls);

      // Check for Chrome's non-standard memory performance API
      const memory = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
      if (memory) {
        const usedMB = (memory.usedJSHeapSize / (1024 * 1024)).toFixed(2);
        setMemoryUsage(`${usedMB} MB`);
      }
    }
  });

  if (!visible) return null;

  return (
    <Html position={[0, 0, 0]} fullscreen>
      <div style={{
        position: 'absolute',
        top: '20px',
        right: '20px',
        background: 'rgba(0, 0, 0, 0.85)',
        color: '#00ffcc',
        padding: '12px 16px',
        borderRadius: '6px',
        fontFamily: 'monospace',
        fontSize: '13px',
        pointerEvents: 'none',
        zIndex: 9999,
        boxShadow: '0 4px 6px rgba(0,0,0,0.3)'
      }}>
        <h4 style={{ margin: '0 0 8px 0', borderBottom: '1px solid #00ffcc', paddingBottom: '4px' }}>
          Performance Monitor
        </h4>
        <div>FPS: {fps}</div>
        <div>Draw Calls: {drawCalls}</div>
        <div>JS Heap: {memoryUsage}</div>
      </div>
    </Html>
  );
};
