/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useRef, useEffect } from 'react';
import { Center, GizmoHelper, GizmoViewport } from '@react-three/drei';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface InspectableModelProps {
  children: React.ReactNode;
  showBoundingBox?: boolean;
}

export const InspectableModel: React.FC<InspectableModelProps> = ({ 
  children, 
  showBoundingBox = true 
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const boxHelperRef = useRef<THREE.BoxHelper | null>(null);
  const { scene } = useThree();

  useEffect(() => {
    if (!groupRef.current) return;

    if (showBoundingBox) {
      // Create and attach a BoxHelper around the grouped contents
      const helper = new THREE.BoxHelper(groupRef.current, 0xffff00);
      scene.add(helper);
      boxHelperRef.current = helper;

      return () => {
        if (boxHelperRef.current) {
          scene.remove(boxHelperRef.current);
          boxHelperRef.current.dispose();
        }
      };
    }
  }, [showBoundingBox, scene]);

  // Update box helper boundaries if geometries scale or transform dynamically
  useEffect(() => {
    if (boxHelperRef.current && groupRef.current) {
      boxHelperRef.current.update();
    }
  });

  return (
    <>
      <group ref={groupRef}>
        <Center>
          {children}
        </Center>
      </group>
      
      {/* Interactive viewport orientation gizmo */}
      <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
        <GizmoViewport 
          axisColors={['#973B45', '#407B55', '#3C4F76']} 
          labelColor="#ffffff" 
        />
      </GizmoHelper>
    </>
  );
};
