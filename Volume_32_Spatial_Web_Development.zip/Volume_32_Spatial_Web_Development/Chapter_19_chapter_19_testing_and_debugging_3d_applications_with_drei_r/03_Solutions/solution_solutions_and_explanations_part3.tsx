/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface XRDebugHUDProps {
  targetMeshRefs: React.RefObject<THREE.Object3D>[];
  enabled?: boolean;
}

export const XRDebugHUD: React.FC<XRDebugHUDProps> = ({ targetMeshRefs, enabled = true }) => {
  const [raycastInfo, setRaycastInfo] = useState<string>('No intersection');
  const [buttonState, setButtonState] = useState<string>('Idle');
  
  const raycaster = useRef(new THREE.Vector3());
  const { gl } = useThree();

  useFrame(() => {
    if (!enabled || !gl.xr.isPresenting) return;

    const session = gl.xr.getSession();
    if (!session) return;

    // Iterate through active XR input sources (controllers)
    for (const source of session.inputSources) {
      if (source.targetRayMode === 'tracked-pointer' && source.gamepad) {
        // Read primary trigger or button press states from standard gamepad mapping
        const triggerPressed = source.gamepad.buttons[0]?.pressed;
        const squeezePressed = source.gamepad.buttons[1]?.pressed;

        if (triggerPressed) {
          setButtonState('Trigger Pressed');
        } else if (squeezePressed) {
          setButtonState('Squeeze Pressed');
        } else {
          setButtonState('Idle');
        }

        // Extract controller spatial pose to construct a raycaster
        const controller = gl.xr.getController(0);
        const tempMatrix = new THREE.Matrix4();
        tempMatrix.identity().extractRotation(controller.matrixWorld);

        const ray = new THREE.Raycaster();
        ray.ray.origin.setFromMatrixPosition(controller.matrixWorld);
        ray.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);

        // Gather valid target objects from references
        const targets = targetMeshRefs
          .map((ref) => ref.current)
          .filter((obj): obj is THREE.Object3D => obj !== null);

        const intersects = ray.intersectObjects(targets, true);

        if (intersects.length > 0) {
          const intersectedObject = intersects[0].object;
          setRaycastInfo(intersectedObject.name || 'Unnamed Mesh');
        } else {
          setRaycastInfo('No intersection');
        }
      }
    }
  });

  if (!enabled) return null;

  return (
    <group>
      <Html position={[-0.5, 1.2, -1]}>
        <div style={{
          background: 'rgba(20, 20, 20, 0.9)',
          color: '#00ffcc',
          padding: '12px',
          fontSize: '12px',
          fontFamily: 'monospace',
          borderRadius: '6px',
          border: '1px solid #00ffcc',
          width: '200px'
        }}>
          <strong>XR Debug HUD</strong>
          <div style={{ marginTop: '6px' }}>Button: {buttonState}</div>
          <div style={{ marginTop: '4px' }}>Target: {raycastInfo}</div>
        </div>
      </Html>
    </group>
  );
};
