/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface LeakDetectorOptions {
  componentName: string;
  strictMode?: boolean;
}

export const useMemoryLeakDetector = (
  objectRef: React.RefObject<THREE.Object3D>, 
  options: LeakDetectorOptions
) => {
  const initialGeometries = useRef<number>(0);
  const initialMaterials = useRef<number>(0);
  const initialTextures = useRef<number>(0);

  // Helper function to recursively count GPU assets
  const countAssets = (obj: THREE.Object3D) => {
    let geos = 0;
    let mats = 0;
    let texs = 0;

    obj.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) geos += 1;
        if (mesh.material) {
          const materialArray = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          materialArray.forEach((mat) => {
            mats += 1;
            // Check for maps attached to materials
            Object.values(mat).forEach((value) => {
              if (value && typeof value === 'object' && 'isTexture' in value) {
                texs += 1;
              }
            });
          });
        }
      }
    });

    return { geos, mats, texs };
  };

  useEffect(() => {
    if (!objectRef.current) return;

    const counts = countAssets(objectRef.current);
    initialGeometries.current = counts.geos;
    initialMaterials.current = counts.mats;
    initialTextures.current = counts.texs;

    return () => {
      if (objectRef.current && options.strictMode) {
        const finalCounts = countAssets(objectRef.current);
        
        // If assets were not disposed prior to unmounting, counts will remain positive
        if (finalCounts.geos > 0 || finalCounts.mats > 0 || finalCounts.texs > 0) {
          console.warn(
            `[Memory Leak Warning] Component '${options.componentName}' unmounted with active, potentially undisposed GPU resources!`,
            {
              geometriesLeaked: finalCounts.geos,
              materialsLeaked: finalCounts.mats,
              texturesLeaked: finalCounts.texs
            }
          );
        }
      }
    };
  }, [objectRef, options]);

  // Manual cleanup utility function
  const disposeResources = () => {
    if (!objectRef.current) return;

    objectRef.current.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          const materialArray = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          materialArray.forEach((mat) => {
            Object.values(mat).forEach((value) => {
              if (value && typeof value === 'object' && 'isTexture' in value) {
                (value as THREE.Texture).dispose();
              }
            });
            mat.dispose();
          });
        }
      }
    });
  };

  return { disposeResources };
};
