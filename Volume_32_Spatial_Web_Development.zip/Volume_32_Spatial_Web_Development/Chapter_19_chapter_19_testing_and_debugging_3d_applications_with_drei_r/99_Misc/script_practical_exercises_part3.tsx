/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface XRDebugHUDProps {
  targetMeshRefs: React.RefObject<THREE.Object3D>[];
  enabled?: boolean;
}

export const XRDebugHUD: React.FC<XRDebugHUDProps> = ({ targetMeshRefs, enabled = true }) => {
  // TODO: Track controller states, raycasters, and intersection targets
  const [raycastInfo, setRaycastInfo] = useState<string>('No intersection');
  const [buttonState, setButtonState] = useState<string>('Idle');

  useFrame((state, delta) => {
    if (!enabled) return;
    // TODO: Implement continuous raycasting logic against targetMeshRefs
  });

  if (!enabled) return null;

  return (
    <group>
      {/* TODO: Attach HUD to controller or left side of camera view */}
      <Html position={[-0.5, 0, -1]}>
        <div style={{ background: 'rgba(20,20,20,0.9)', color: '#00ffcc', padding: '12px', fontSize: '12px', fontFamily: 'monospace' }}>
          <strong>XR Debug HUD</strong>
          <div>Button: {buttonState}</div>
          <div>Target: {raycastInfo}</div>
        </div>
      </Html>
    </group>
  );
};
