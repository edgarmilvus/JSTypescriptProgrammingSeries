/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface LeakDetectorOptions {
  componentName: string;
  strictMode?: boolean;
}

export const useMemoryLeakDetector = (
  objectRef: React.RefObject<THREE.Object3D>, 
  options: LeakDetectorOptions
) => {
  // TODO: Keep track of initial asset counts on mount
  const initialGeometries = useRef<number>(0);
  const initialMaterials = useRef<number>(0);
  const initialTextures = useRef<number>(0);

  useEffect(() => {
    // TODO: Traverse objectRef and count geometries, materials, and textures
    
    return () => {
      // TODO: Check on unmount if resources have been properly disposed
      // If not, log a descriptive warning with options.componentName
    };
  }, [objectRef, options]);

  // TODO: Return a manual cleanup/disposal helper function
  const disposeResources = () => {
    // Implement recursive disposal logic here
  };

  return { disposeResources };
};
