/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { XR, createXRStore } from '@react-xr';
import * as THREE from 'three';

// Initialize the WebXR store for AR/VR sessions
const xrStore = createXRStore();

/**
 * Interface representing a remote user's state synchronized via real-time networking.
 */
interface NetworkedUser {
  id: string;
  position: [number, number, number];
  color: string;
}

/**
 * Interactive 3D Product Display Component.
 * Represents a piece of merchandise in the virtual showroom that users can inspect.
 */
function ShowroomProduct() {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState<boolean>(false);
  const [selected, setSelected] = useState<boolean>(false);

  // Rotate the product slowly on every frame to catch showroom lighting
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.5;
    }
  });

  return (
    <mesh
      ref={meshRef}
      position={[0, 1, -2]}
      scale={selected ? [1.2, 1.2, 1.2] : [1, 1, 1]}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      onClick={() => setSelected((prev) => !prev)}
    >
      <boxGeometry args={[0.6, 0.6, 0.6]} />
      <meshStandardMaterial color={hovered ? '#4f46e5' : '#e0e7ff'} roughness={0.3} />
    </mesh>
  );
}

/**
 * Networked Avatar Component representing another participant in the showroom.
 */
function RemoteAvatar({ user }: { user: NetworkedUser }) {
  const avatarRef = useRef<THREE.Group>(null);

  // Smoothly interpolate or update avatar position based on network state
  useFrame(() => {
    if (avatarRef.current) {
      avatarRef.current.position.set(...user.position);
    }
  });

  return (
    <group ref={avatarRef}>
      {/* Head representation */}
       regra<mesh position={[0, 1.6, 0]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial color={user.color} />
      </mesh>
    </group>
  );
}

/**
 * Main Virtual Showroom Application Root.
 */
export default function VirtualShowroomApp() {
  const [users, setUsers] = useState<NetworkedUser[]>([]);

  // Simulate incoming WebSocket connection for multi-user synchronization
  useEffect(() => {
    // Mock initial remote user joining the showroom
    const timer = setTimeout(() => {
      setUsers([
        { id: 'user-2', position: [1.5, 0, -1], color: '#ef4444' },
      ]);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#111827' }}>
      {/* WebXR Enter Button UI Overlay */}
      <div style={{ position: 'absolute', top: 20, left: 20, zIndex: 10 } }>
        <button
          onClick={() => xrStore.enterVR()}
          style={{ padding: '10px 20px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
        >
          Enter Immersive VR
        </button>
      </div>

      <Canvas camera={{ position: [0, 1.6, 3] }}>
        <XR store={xrStore}>
          {/* Ambient environment lighting */}
          <ambientLight intensity={0.7} />
          <directionalLight position={[5, 8, 5]} intensity={1} />

          {/* Showroom Floor */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
            <planeGeometry args={[20, 20]} />
            <meshStandardMaterial color="#1f2937" roughness={0.8} />
          </mesh>

          {/* Central Product Display */}
          <ShowroomProduct />

          {/* Render all synchronized remote users */}
          {users.map((user) => (
            <RemoteAvatar key={user.id} user={user} />
          ))}
        </XR>
      </Canvas>
    </div>
  );
}
