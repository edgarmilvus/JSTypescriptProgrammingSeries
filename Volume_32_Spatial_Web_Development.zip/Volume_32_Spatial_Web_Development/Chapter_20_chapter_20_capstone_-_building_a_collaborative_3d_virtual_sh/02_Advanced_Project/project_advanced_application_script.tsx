/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @file Collaborative Virtual Showroom - Core Showroom Scene
 * @description Integrates R3F canvas setup, WebXR AR/VR session handshakes, real-time spatial socket streaming, and edge-first validation hooks.
 */

import React, { useRef, useState, useEffect, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { XR, ARButton, VRButton, XRController, useXR } from '@react-three/xr';
import { Orbit, TransformControls, Html, useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import { io, Socket } from 'socket.io-client';
import { z } from 'zod';

// ==========================================
// 1. ZOD SCHEMAS & TYPES FOR EDGE VALIDATION
// ==========================================

/**
 * Validates incoming spatial transform matrices from remote peers to prevent state injection exploits.
 */
const SpatialTransformSchema = z.object({
  userId: z.string().uuid(),
  position: z.tuple([z.number(), z.number(), z.number()]),
  rotation: z.tuple([z.number(), z.number(), z.number(), z.number()]),
  timestamp: z.number(),
});

type SpatialTransform = z.infer<typeof SpatialTransformSchema>;

interface ShowroomProps {
  roomId: string;
  currentUserId: string;
}

// ==========================================
// 2. REMOTE PEER AVATAR COMPONENT
// ==========================================

interface PeerAvatarProps {
  userId: string;
  initialPosition: [number, number, number];
  initialRotation: [number, number, number, number];
}

/**
 * Renders an interpolated remote user avatar inside the 3D space with a spatial audio emitter.
 */
function PeerAvatar({ userId, initialPosition, initialRotation }: PeerAvatarProps) {
  const avatarRef = useRef<THREE.Group>(null);
  const targetPos = useRef(new THREE.Vector3(...initialPosition));
  const targetRot = useRef(new THREE.Quaternion(...initialRotation));

  // Smooth interpolation (lerp) per frame to counteract network jitter
  useFrame((_, delta) => {
    if (avatarRef.current) {
      avatarRef.current.position.lerp(targetPos.current, delta * 10);
      avatarRef.current.quaternion.slerp(targetRot.current, delta * 10);
    }
  });

  return (
    <group ref={avatarRef}>
      {/* Head representation */}
      <mesh position={[0, 1.6, 0]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial color="#4f46e5" roughness={0.3} />
      </mesh>
      {/* User tag UI */}
      <Html position={[0, 1.9, 0]} center>
        <div className="bg-slate-900/80 text-white px-2 py-0.5 rounded text-xs backdrop-blur-sm pointer-events-none">
          User: {userId.slice(0, 6)}
        </div>
      </Html>
    </group>
  );
}

// ==========================================
// 3. SHOWROOM INTERACTIVE EXHIBIT
// ==========================================

interface ExhibitProps {
  modelUrl: string;
  position: [number, number, number];
  onInspect: (name: string) => void;
}

/**
 * Loads a 3D product asset with performance-optimized fallback states and interactive triggers.
 */
function InteractiveExhibit({ modelUrl, position, onInspect }: ExhibitProps) {
  const [hovered, setHovered] = useState(false);
  const meshRef = useRef<THREE.Mesh>(null);

  // Subtle idle animation
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.2;
    }
  });

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={() => onInspect("Designer Chair Model X")}
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={hovered ? '#6366f1' : '#e2e8f0'} metalness={0.8} roughness={0.2} />
      </mesh>
    </group>
  );
}

// ==========================================
// 4. MAIN COLLABORATIVE SHOWROOM SCENE
// ==========================================

export default function CollaborativeShowroom({ roomId, currentUserId }: ShowroomProps) {
  const [peers, setPeers] = useState<Map<string, SpatialTransform>>(new Map());
  const socketRef = useRef<Socket | null>(null);
  const { camera } = useThree();

  // Initialize Socket.io connection and WebRTC signaling hooks
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_WEBSOCKET_URL || 'http://localhost:4000', {
      query: { roomId, userId: currentUserId },
    });
    socketRef.current = socket;

    socket.on('spatial-update', (data: unknown) => {
      const result = SpatialTransformSchema.safeParse(data);
      if (!result.success) {
        console.warn('Dropped malformed spatial payload at edge client:', result.error);
        return;
      }
      const transform = result.data;
      if (transform.userId !== currentUserId) {
        setPeers((prev) => {
          const next = new Map(prev);
          next.set(transform.userId, transform);
          return next;
        });
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [roomId, currentUserId]);

  // Broadcast local user spatial transform at a throttled frame interval
  useFrame(() => {
    if (!socketRef.current) return;
    const quaternion = new THREE.Quaternion();
    camera.getWorldQuaternion(quaternion);

    const payload: SpatialTransform = {
      userId: currentUserId,
      position: [camera.position.x, camera.position.y, camera.position.z],
      rotation: [quaternion.x, quaternion.y, quaternion.z, quaternion.w],
      timestamp: Date.now(),
    };

    socketRef.current.emit('spatial-update', payload);
  });

  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight position={[10, 20, 10]} intensity={1.5} castShadow />

      {/* Showroom Environment Architecture */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#0f172a" roughness={0.9} />
      </mesh>

      {/* Interactive Products */}
      <InteractiveExhibit modelUrl="/models/chair.glb" position={[0, 0.5, -3]} onInspect={(name) => console.log(name)} />

      {/* Render Remote Peers */}
      {Array.from(peers.values()).map((peer) => (
        <PeerAvatar
          key={peer.userId}
          userId={peer.userId}
          initialPosition={peer.position}
          initialRotation={peer.rotation}
        />
      ))}
    </>
  );
}
