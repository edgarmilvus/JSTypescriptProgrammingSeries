/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import { useRef, useEffect, useState, useCallback } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export interface AvatarTransform {
  userId: string;
  position: [number, number, number];
  rotation: [number, number, number, number];
  audioStream?: MediaStream;
}

interface UseCollaborativeAvatarAudioProps {
  channel: RTCDataChannel | WebSocket;
  localUserId: string;
  audioListener: THREE.AudioListener;
  roomAcousticsMode?: 'gallery' | 'open-floor';
}

export function useCollaborativeAvatarAudio({
  channel,
  localUserId,
  audioListener,
  roomAcousticsMode = 'open-floor',
}: UseCollaborativeAvatarAudioProps) {
  const [remoteAvatars, setRemoteAvatars] = useState<Map<string, AvatarTransform>>(new Map());
  const positionalAudiosRef = useRef<Map<string, THREE.PositionalAudio>>(new Map());
  
  // Throttling state (Target: 20 updates per second -> 50ms interval)
  const lastSentTimestamp = useRef<number>(0);
  const THROTTLE_MS = 50;

  // Handle incoming transform and audio packets over signaling channel
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        const data: AvatarTransform = JSON.parse(event.data);
        if (data.userId === localUserId) return;

        setRemoteAvatars((prev) => {
          const next = new Map(prev);
          next.set(data.userId, data);
          return next;
        });
      } catch (err) {
        console.error('Failed to parse incoming avatar transform:', err);
      }
    };

    if (channel instanceof WebSocket) {
      channel.addEventListener('message', handleMessage);
      return () => channel.removeEventListener('message', handleMessage);
    } else {
      channel.onmessage = handleMessage;
    }
  }, [channel, localUserId]);

  // Update listener and audio parameters when acoustics mode changes
  useEffect(() => {
    positionalAudiosRef.current.forEach((audio) => {
      const panner = audio.getOutput() as PannerNode;
      if (panner) {
        if (roomAcousticsMode === 'gallery') {
          panner.maxDistance = 50;
          panner.rolloffFactor = 2.5; // Higher reverberation/attenuation simulation
        } else {
          panner.maxDistance = 100;
          panner.rolloffFactor = 1.0; // Open floor smooth attenuation
        }
      }
    });
  }, [roomAcousticsMode]);

  useFrame((state) => {
    const camera = state.camera;
    const now = performance.now();

    // 1. Network Throttling check (50ms)
    if (now - lastSentTimestamp.current >= THROTTLE_MS) {
      lastSentTimestamp.current = now;

      const transform: AvatarTransform = {
        userId: localUserId,
        position: [camera.position.x, camera.position.y, camera.position.z],
        rotation: [camera.quaternion.x, camera.quaternion.y, camera.quaternion.z, camera.quaternion.w],
      };

      if (channel.readyState === (channel instanceof WebSocket ? WebSocket.OPEN : 'open')) {
        channel.send(JSON.stringify(transform));
      }
    }

    // 2. Continuously update the audio listener orientation based on camera view
    const cameraQuaternion = camera.getWorldQuaternion(new THREE.Quaternion());
    audioListener.up.set(0, 1, 0).applyQuaternion(cameraQuaternion);
  });

  return {
    remoteAvatars: Array.from(remoteAvatars.values()),
    positionalAudiosRef,
  };
}
