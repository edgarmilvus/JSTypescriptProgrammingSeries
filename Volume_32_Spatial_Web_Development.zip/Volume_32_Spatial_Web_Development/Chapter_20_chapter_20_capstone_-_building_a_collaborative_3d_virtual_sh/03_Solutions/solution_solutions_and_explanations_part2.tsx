/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export interface OptimizedShowroomModelProps {
  url: string;
  lodDistances?: number[];
  onLoadComplete?: () => void;
}

export const OptimizedShowroomModel: React.FC<OptimizedShowroomModelProps> = ({
  url,
  lodDistances = [10, 25, 50],
  onLoadComplete,
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const [activeLodIndex, setActiveLodIndex] = useState<number>(0);
  const [modelScenes, setModelScenes] = useState<THREE.Group[]>([]);
  const [hasError, setHasError] = useState<boolean>(false);
  const { camera } = useThree();

  useEffect(() => {
    let isMounted = true;
    const worker = new Worker(new URL('./wasm-mesh-worker.ts', import.meta.url), { type: 'module' });

    worker.onmessage = async (event: MessageEvent) => {
      try {
        const { success, lodBuffers } = event.data;
        if (!success || !lodBuffers) throw new Error('WASM Processing failed');

        const loader = new GLTFLoader();
        const loadedScenes: THREE.Group[] = [];

        for (const buffer of lodBuffers) {
          const gltf = await loader.parseAsync(buffer, '');
          loadedScenes.push(gltf.scene);
        }

        if (isMounted) {
          setModelScenes(loadedScenes);
          if (onLoadComplete) onLoadComplete();
        }
      } catch (err) {
        console.error('Asset decompression/parsing error:', err);
        if (isMounted) setHasError(true);
      }
    };

    // Fetch and stream payload to Worker (Interactive Challenge stream implementation)
    fetch(url)
      .then(async (response) => {
        if (!response.body) throw new Error('ReadableStream not supported.');
        const reader = response.body.getReader();
        const chunks: Uint8Array[] = [];
        let receivedLength = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          receivedLength += value.length;
        }

        const fullBuffer = new Uint8Array(receivedLength);
        let position = 0;
        for (let chunk of chunks) {
          fullBuffer.set(chunk, position);
          position += chunk.length;
        }

        worker.postMessage({ buffer: fullBuffer.buffer, lodDistances }, [fullBuffer.buffer]);
      })
      .catch((err) => {
        console.error('Network error fetching asset:', err);
        if (isMounted) setHasError(true);
      });

    return () => {
      isMounted = false;
      worker.terminate();
    };
  }, [url, lodDistances, onLoadComplete]);

  useFrame(() => {
    if (!groupRef.current || modelScenes.length === 0) return;

    const groupCenter = new THREE.Vector3();
    groupRef.current.getWorldPosition(groupCenter);
    const distance = camera.position.distanceTo(groupCenter);

    let newIndex = 0;
    for (let i = 0; i < lodDistances.length; i++) {
      if (distance > lodDistances[i]) {
        newIndex = i + 1;
      }
    }

    const clampedIndex = Math.min(newIndex, modelScenes.length - 1);
    if (clampedIndex !== activeLodIndex) {
      setActiveLodIndex(clampedIndex);
    }
  });

  if (hasError) {
    return (
      <group ref={groupRef}>
        <mesh>
          <boxGeometry args={[1, 1, 1]} />
          <meshBasicMaterial wireframe color="red" />
        </mesh>
      </group>
    );
  }

  return (
    <group ref={groupRef}>
      {modelScenes.map((scene, index) => (
        <primitive
          key={index}
          object={scene}
          visible={index === activeLodIndex}
        />
      ))}
    </group>
  );
};
