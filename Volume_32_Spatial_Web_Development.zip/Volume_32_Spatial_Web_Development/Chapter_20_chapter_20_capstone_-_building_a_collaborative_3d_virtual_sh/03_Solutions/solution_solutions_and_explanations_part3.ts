/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

export const ShowroomMetadataSchema = z.object({
  title: z.string().max(50, "Title must be 50 characters or less"),
  priceUSD: z.number().positive("Price must be a positive number"),
  materialTags: z.array(z.string()),
  aiConfidenceScore: z.number().min(0).max(1),
});

export type ShowroomMetadata = z.infer<typeof ShowroomMetadataSchema>;

export interface EdgeValidationResult {
  success: boolean;
  data?: ShowroomMetadata;
  errors?: z.ZodError | string;
  latencyMs: number;
}

// In-memory Edge KV/Cache store simulation for the interactive challenge
const edgeValidationCache = new Map<string, { data: ShowroomMetadata; timestamp: number }>();
const CACHE_TTL_MS = 60000;

export async function validateExhibitMetadataAtEdge(
  rawInputText: string,
  edgeEndpointUrl: string,
  apiKey: string
): Promise<EdgeValidationResult> {
  const startTime = performance.now();

  // Check Edge Cache first
  const cached = edgeValidationCache.get(rawInputText);
  if (cached && performance.now() - cached.timestamp < CACHE_TTL_MS) {
    return {
      success: true,
      data: cached.data,
      latencyMs: performance.now() - startTime,
    };
  }

  try {
    const prompt = `Extract and format the following exhibit description into valid JSON conforming exactly to this schema: {"title": string (max 50 chars), "priceUSD": number, "materialTags": string[], "aiConfidenceScore": number (0 to 1)}. Text: "${rawInputText}"`;

    const response = await fetch(edgeEndpointUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'edge-llm-fast',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      throw new Error(`Edge LLM request failed with status ${response.status}`);
    }

    const jsonResponse = await response.json();
    const rawContent = jsonResponse.choices?.[0]?.message?.content;
    
    const parsedJson = JSON.parse(rawContent);
    const validatedData = ShowroomMetadataSchema.parse(parsedJson);

    // Save to cache
    edgeValidationCache.set(rawInputText, { data: validatedData, timestamp: performance.now() });

    const latencyMs = performance.now() - startTime;
    
    return {
      success: true,
      data: validatedData,
      latencyMs,
    };
  } catch (error) {
    const latencyMs = performance.now() - startTime;
    return {
      success: false,
      errors: error instanceof Error ? error.message : String(error),
      latencyMs,
    };
  }
}
