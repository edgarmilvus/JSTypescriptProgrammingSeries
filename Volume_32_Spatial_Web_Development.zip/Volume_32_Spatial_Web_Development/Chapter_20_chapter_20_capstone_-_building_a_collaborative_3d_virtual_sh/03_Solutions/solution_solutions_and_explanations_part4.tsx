/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useXR } from '@react-three/xr';

export type QualityLevel = 'HIGH' | 'MEDIUM' | 'LOW';

interface WebXRPerformanceGuardProps {
  onQualityChange?: (level: QualityLevel) => void;
  children: React.ReactNode;
}

export const WebXRPerformanceGuard: React.FC<WebXRPerformanceGuardProps> = ({
  onQualityChange,
  children,
}) => {
  const { isPresenting } = useXR();
  const [quality, setQuality] = useState<QualityLevel>('HIGH');

  // Performance tracking refs
  const lowFpsCounter = useRef<number>(0);
  const highFpsTimer = useRef<number>(0);

  useFrame((state, delta) => {
    if (!isPresenting) return;

    const currentFps = 1 / delta;

    // Evaluate low performance condition (< 68 FPS)
    if (currentFps < 68) {
      lowFpsCounter.current += 1;
      highFpsTimer.current = 0; // Reset high stabilization timer

      if (lowFpsCounter.current >= 3) {
        setQuality((prev) => {
          if (prev === 'HIGH') return 'MEDIUM';
          if (prev === 'MEDIUM') return 'LOW';
          return 'LOW';
        });
        lowFpsCounter.current = 0; // Reset counter
      }
    } 
    // Evaluate high performance stabilization condition (> 78 FPS)
    else if (currentFps > 78) {
      lowFpsCounter.current = 0;
      highFpsTimer.current += delta;

      if (highFpsTimer.current >= 5) {
        setQuality((prev) => {
          if (prev === 'LOW') return 'MEDIUM';
          if (prev === 'MEDIUM') return 'HIGH';
          return 'HIGH';
        });
        highFpsTimer.current = 0; // Reset timer
      }
    }
  });

  useEffect(() => {
    if (onQualityChange) {
      onQualityChange(quality);
    }
  }, [quality, onQualityChange]);

  return (
    <>
      {children}
      {quality === 'LOW' && isPresenting && (
        <group position={[0, 1.5, -1]}>
          {/* Immersive HUD Warning Plane */}
          <mesh>
            <planeGeometry args={[0.8, 0.2]} />
            <meshBasicMaterial color="orange" transparent opacity={0.8} />
          </mesh>
        </group>
      )}
    </>
  );
};
