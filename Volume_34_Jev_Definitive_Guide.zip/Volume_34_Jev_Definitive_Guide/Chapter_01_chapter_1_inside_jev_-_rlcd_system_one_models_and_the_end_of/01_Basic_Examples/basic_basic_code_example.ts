/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file ticket-triage.ts
 *
 * A minimal end-to-end Jev example.
 *
 * Takes one inbound support ticket, asks Jev four typed questions about it,
 * composes the answers with ordinary branching logic, and returns a routing
 * decision. Zero text generation. Zero parsing. One HTTP round trip.
 */

import {
  TypeSafeClient,
  noul,
  choice,
  score,
} from "@typesafe-ai/sdk";

/* ------------------------------------------------------------------ *
 * 1. The state — the raw material Jev reasons over.                   *
 * ------------------------------------------------------------------ */

interface SupportTicket {
  id: string;
  plan: "starter" | "growth" | "enterprise";
  mrrUsd: number;
  message: string;
}

const ticket: SupportTicket = {
  id: "TKT-10423",
  plan: "enterprise",
  mrrUsd: 4_200,
  message:
    "Our entire team has been locked out of the dashboard since our IdP " +
    "rotated its signing certs this morning. We are blocked on a live " +
    "customer demo in 40 minutes. Please escalate.",
};

/* ------------------------------------------------------------------ *
 * 2. The questions — a typed map. The keys are yours; Jev never sees  *
 *    them. Every question is atomic, so answers never influence each  *
 *    other.                                                           *
 * ------------------------------------------------------------------ */

const QUESTIONS = {
  /** Yes/no: is this ticket time-critical? Returns P(true) in [0,1]. */
  is_urgent: noul(
    "Does `ticket.message` convey time-critical urgency?",
    {
      true: "An explicit deadline, active outage, or irreversibly blocked work.",
      false: "No sense of timing pressure — a routine question or request.",
    },
  ),

  /** Choice: exactly one label. The SDK infers the union of option keys. */
  department: choice(
    "Which team should own `ticket.message`?",
    {
      auth: "Login, SSO, SAML, session, or identity-provider problems.",
      billing: "Charges, invoices, plans, or subscription changes.",
      platform: "API errors, latency, outages, or integration problems.",
      success: "How-to questions, onboarding, or feature requests.",
    },
  ),

  /** Score: position on an ordered rubric. Can land between levels. */
  frustration: score(
    "How frustrated does the sender of `ticket.message` appear?",
    [
      "Neutral: matter-of-fact, no complaint about the experience.",
      "Frustrated: annoyed, but still constructive.",
      "Angry: hostile language, or threatening to leave.",
    ] as const,
  ),

  /** Yes/no with a default-true fallback baked into our own convention. */
  is_enterprise: noul(
    "Is `ticket.plan` equal to `enterprise`?",
  ),
} as const;

/* ------------------------------------------------------------------ *
 * 3. The call — one network request, all four questions in parallel.  *
 * ------------------------------------------------------------------ */

type Route = {
  queue: string;
  priority: "P0" | "P1" | "P2";
  sla: string;
  /** If true, the two-speed layer would now hand off to a generator LLM. */
  shouldDraftReply: boolean;
};

async function triage(ticket: SupportTicket): Promise<Route> {
  const client = new TypeSafeClient();

  // One POST /v1/systemone. The `state` is sent once; every question is
  // evaluated in parallel against it.
  const response = await client.systemOne({
    state: ticket,
    questions: QUESTIONS,
  });

  // The SDK has narrowed every answer by its question type. No `any`,
  // no `unknown`, no runtime cast needed.
  const { is_urgent, department, frustration } = response.answers;

  /* -------------------------------------------------------------- *
   * 4. Compose in code. This is the "second speed" seam: Jev does   *
   *    the judgments; ordinary TypeScript does the arithmetic and   *
   *    control flow.                                                *
   * -------------------------------------------------------------- */

  // If Jev cannot honestly pick a department, we route to human triage
  // rather than guess. Confidence is a first-class output, not a heuristic.
  if (department.confidence < 0.65) {
    return {
      queue: "human-triage",
      priority: "P2",
      sla: "30m",
      shouldDraftReply: false,
    };
  }

  // Frustration is a Score, so it can land between levels (e.g. 1.4).
  // Thresholding on the raw score keeps the numeric nuance we paid for.
  const veryAngry = frustration.score >= 1.8;

  // Priority ladder, highest signal first. `is_urgent.noul` is already
  // a calibrated probability — one `>=` does the whole job.
  let priority: Route["priority"] = "P2";
  if (is_urgent.noul >= 0.8 || veryAngry) {
    priority = "P0";
  } else if (is_urgent.noul >= 0.4) {
    priority = "P1";
  }

  // Enterprise plans jump the SLA by one notch. Note that this branch
  // reads a *code-side* fact (`ticket.plan`) and a *model-side* fact
  // (`is_enterprise.noul`) and combines them without ambiguity.
  const enterpriseFastLane =
    ticket.plan === "enterprise" && is_enterprise.noul >= 0.8;

  const sla =
    enterpriseFastLane && priority === "P0"
      ? "5m"
      : priority === "P0"
        ? "15m"
        : priority === "P1"
          ? "1h"
          : "8h";

  // Two-speed handoff: only angry enterprise tickets get an LLM-drafted
  // first reply. Everyone else gets the deterministic route.
  const shouldDraftReply = enterpriseFastLane && veryAngry;

  return {
    queue: department.choice,
    priority,
    sla,
    shouldDraftReply,
  };
}

// ---------------------------------------------------------------------
// Demo
// ----------------------------------------------------------------------

triage(ticket)
  .then((route) => {
    console.log("route:", route);
    // -> {
    //      queue: "auth",
    //      priority: "P0",
    //      sla: "5m",
    //      shouldDraftReply: true
    //    }
  })
  .catch((err) => {
    // TypeSafeAPIError, TypeSafeAPIConnectionError, or a validation error.
    console.error("triage failed:", err);
  });
