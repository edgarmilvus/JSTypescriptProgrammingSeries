/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/copilot/route.ts
import { NextRequest, NextResponse } from "next/server";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type SystemOneResult,
} from "@typesafe-ai/sdk";
import { WORKERS } from "@/lib/workers";
import { redactSecrets } from "@/lib/redact";

/**
 * One long-lived client per server process. The SDK holds a connection pool
 * and a retry policy; constructing it per request throws both away.
 */
const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY!,
  defaultModel: "jev-latest",
  timeout: 5_000,
});

/* ------------------------------------------------------------------ 1. Rubric */

/**
 * The Supervisor's entire behavioural specification. This object is the code
 * review artefact: a human reads these five questions and knows exactly what
 * the system will and will not do. Nothing here is generated at runtime.
 *
 * `as const` is load-bearing — it freezes every criteria key into a literal
 * type, which is what makes the answers typed below.
 */
const SUPERVISOR_QUESTIONS = {
  worker: choice("Which specialist handler should own the turn in `message`?", {
    logs: "CI/CD, pipeline failures, runtime errors, deployments, infrastructure telemetry.",
    docs: "Product behaviour, policy, onboarding, or any 'how do I' question with a documented answer.",
    code: "Write, review, refactor or explain source code for `repoLanguage`.",
    billing: "Plans, seats, invoices, usage limits, subscription changes.",
    escalate: "Unprecedented, ambiguous, or sensitive enough that a human should own it.",
  }),

  complexity: score(
    "How much multi-step reasoning would a competent engineer need to fully resolve `message`?",
    [
      "A single fact lookup or a one-line answer.",
      "A short explanation, or a single small code change.",
      "Multi-step reasoning, or a change that spans several files.",
      "An open-ended investigation with unknown variables.",
    ],
  ),

  destructive: noul(
    "Does `message` ask the assistant to perform an irreversible action on a live system?",
    {
      true: "The request is to delete, drop, revoke, force-push, rotate, or otherwise permanently alter production data or infrastructure.",
      false: "The request is read-only, additive, or purely informational.",
    },
  ),

  contains_secret: noul("Does `message` contain a credential-shaped value?", {
    true: "An API key, bearer token, private key, password, or similar secret appears verbatim.",
    false: "No credential-shaped value is present.",
  }),

  needs_generative: noul(
    "Does resolving `message` require an authored, free-form answer?",
    {
      true: "The user expects prose: an explanation, a review, a draft, a comparison.",
      false: "A templated reply, a deterministic lookup, or a refusal would satisfy the turn.",
    },
  ),
} as const;

/* -------------------------------------------------------------------- 2. Types */

/** The answer packet for this rubric, inferred — never hand-written. */
type Supervisor = SystemOneResult<typeof SUPERVISOR_QUESTIONS>;
type WorkerId = Supervisor["answers"]["worker"]["choice"];

type Verdict =
  | { kind: "reject"; reason: "secret" }
  | { kind: "escalate"; reason: "destructive" | "uncertain" }
  | {
      kind: "answer";
      worker: Exclude<WorkerId, "escalate">;
      generative: boolean;
    };

/* --------------------------------------------------------------- 3. Thresholds */

const CONFIDENCE_FLOOR = 0.55; // below this we do not act unattended
const DESTRUCTIVE_CEILING = 0.15; // above this a human takes the wheel
const SECRET_CEILING = 0.4;

/**
 * Pure, synchronous, and free of I/O. Given a Supervisor result it returns a
 * Verdict and nothing else. Every threshold is a named constant so a test can
 * pin it and a product owner can argue about it in a PR, not in a prompt.
 */
function route({ answers }: Supervisor): Verdict {
  if (answers.contains_secret.noul >= SECRET_CEILING) {
    return { kind: "reject", reason: "secret" };
  }
  if (answers.destructive.noul >= DESTRUCTIVE_CEILING) {
    return { kind: "escalate", reason: "destructive" };
  }
  const { choice: picked, confidence } = answers.worker;
  if (confidence < CONFIDENCE_FLOOR || picked === "escalate") {
    return { kind: "escalate", reason: "uncertain" };
  }
  return {
    kind: "answer",
    worker: picked,
    generative: answers.needs_generative.noul >= 0.5,
  };
}

/* ------------------------------------------------------------------- 4. Handler */

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const body = await req.json();

  // Redaction is code's job and runs before anything is sent to a model.
  const state = { ...body, message: redactSecrets(body.message) };

  const t0 = performance.now();
  const supervisor = await jev.systemOne({
    state,
    questions: SUPERVISOR_QUESTIONS,
  });
  const jevMs = Math.round(performance.now() - t0);

  const verdict = route(supervisor);

  if (verdict.kind === "reject") {
    return NextResponse.json({ path: "blocked", jevMs, reply: SECRET_REPLY });
  }

  if (verdict.kind === "escalate") {
    // Audit trail: every probability the escalation was based on, verbatim.
    return NextResponse.json({
      path: "human",
      jevMs,
      reason: verdict.reason,
      evidence: supervisor.answers,
    });
  }

  const worker = WORKERS[verdict.worker];
  const reply = verdict.generative
    ? await worker.explain(state) // slow path: generative LLM, only when asked for
    : worker.lookup(state); // fast path: deterministic, non-blocking

  return NextResponse.json({
    path: "answered",
    jevMs,
    worker: verdict.worker,
    generative: verdict.generative,
    reply,
  });
}

const SECRET_REPLY =
  "I spotted what looks like a credential in that message. I've redacted it and will not forward it to any model. Please rotate the value.";
