/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/(chat)/SupervisorTrace.tsx
"use client";

import type { ChoiceAnswer, ScoreAnswer, NoulAnswer } from "@typesafe-ai/sdk";

/** Every Jev answer carries its distribution. Humans deserve to see it too. */
export function SupervisorTrace({ answers }: { answers: Record<string, unknown> }) {
  const nouls = ["destructive", "contains_secret", "needs_generative"];
  return (
    <dl className="grid gap-3 text-sm">
      <Row label="Route" value={answers.worker as ChoiceAnswer<any>} />
      <Row label="Complexity" value={answers.complexity as ScoreAnswer<any>} />
      {nouls.map((k) => (
        <Row key={k} label={k} value={answers[k] as NoulAnswer} />
      ))}
    </dl>
  );
}

function Row({ label, value }: { label: string; value: any }) {
  const detail =
    "choice" in value
      ? `${value.choice} · ${(value.confidence * 100).toFixed(0)}% confident`
      : "noul" in value
        ? `P(yes) = ${value.noul.toFixed(2)}`
        : `score ${value.score.toFixed(2)} · ${(value.confidence * 100).toFixed(0)}% confident`;

  return (
    <div className="flex justify-between border-b py-1">
      <dt className="text-slate-500">{label}</dt>
      <dd className="font-mono">{detail}</dd>
    </div>
  );
}
