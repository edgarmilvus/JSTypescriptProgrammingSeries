/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// src/server.ts (excerpt)
import http from "node:http";
import { concierge, getRouteHistogram } from "./concierge.js";
import { APIError } from "@typesafe-ai/sdk";

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/stats") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(getRouteHistogram()));
    return;
  }
  if (req.method === "POST" && req.url === "/concierge") {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    let body: { message?: string; orderId?: string; accountId?: string } = {};
    try {
      body = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
    } catch {
      res.writeHead(400).end(JSON.stringify({ error: "invalid JSON" }));
      return;
    }
    if (!body.message || typeof body.message !== "string") {
      res.writeHead(400).end(JSON.stringify({ error: "message required" }));
      return;
    }
    try {
      const result = await concierge(body.message, {
        orderId: body.orderId,
        accountId: body.accountId,
      });
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify(result));
    } catch (err) {
      if (err instanceof APIError) {
        res.writeHead(502, { "content-type": "application/json" });
        res.end(
          JSON.stringify({
            error: `router returned ${err.status}`,
            retryable: err.status === 429 || err.status >= 500,
          }),
        );
        return;
      }
      res.writeHead(500).end(JSON.stringify({ error: "internal error" }));
    }
    return;
  }
  res.writeHead(404).end();
});

server.listen(3000, () => console.log("concierge listening on :3000"));
