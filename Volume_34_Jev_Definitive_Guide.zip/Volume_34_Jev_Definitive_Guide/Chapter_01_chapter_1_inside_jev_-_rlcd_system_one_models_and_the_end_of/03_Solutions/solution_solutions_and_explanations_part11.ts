/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

<!-- NOTES.md -->
## Route semantics

- `order_status` — deterministic handler.
- `refund_request` — acknowledge and hand off. Refunds are not a decision
  this service should be allowed to make, and a generated "your refund has
  been processed" would be a lie. The reply is a canned string.
- `account_access` — deterministic canned reply. In a real service this
  would mint a one-time link; the point is that the path never touches a
  generative model.
- `general_question` — the only route that calls the generative model. The
  message is not passed alone; the system prompt carries the entity and the
  expectation-level instruction that Jev extracted, so the generative model
  writes instead of deciding.
- `needs_human` — replies with a hand-off string. Confidence below
  `ROUTE_CONFIDENCE_FLOOR = 0.7` is forced into this route.

## Confidence threshold
route contains easy-to-confuse pairs (refund vs. order when a broken order
implicates money; general vs. needs_human when the message is terse). A
confident wrong route costs more than an explicit escalation. On a labeled
fixture, this threshold produced __% of requests escalated; a lower threshold
would have absorbed more but risked wrong routing. (Fill in your own numbers.)

## Cost footnote

These are estimates from public pricing pages, **not verified billing**, and
they depend on token counts I did not measure.

Assume:
- 20 messages in a manual test with a distribution of roughly
  `order_status: 6, general_question: 8, needs_human: 3, refund_request: 2,
  account_access: 1`.
- Jev: ~600 input tokens per call, 30 output tokens. Priced at Jev's
  published rate.
- Generative: ~1,000 tokens per call (system + message + reply).

Rough monthly shape at 100k messages with this mix: Jev handles all 100k; the
generative model handles only the ~40% that route to `general_question`.
The generative call dominates cost per invocation by two to three orders of
magnitude over the Jev call, so the value of the router is precisely the size
of the share it *removes* from the generative path. If the router moved even
10% of generative traffic to a deterministic path, it would pay for its own
tokens many times over; the exact crossover depends on your traffic mix and
on the generative model's rate.
