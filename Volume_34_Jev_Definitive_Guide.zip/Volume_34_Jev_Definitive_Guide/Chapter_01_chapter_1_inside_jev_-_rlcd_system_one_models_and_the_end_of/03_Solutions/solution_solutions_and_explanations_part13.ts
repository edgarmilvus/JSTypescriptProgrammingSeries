/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// src/sweep.ts
export type Label = "adversarial" | "benign" | "ambiguous";

export interface SweepExample {
  id: string;
  text: string;
  label: Label;
  /** Pre-computed noul for `abusive_language` on this example. */
  noul: number;
}

export interface SweepRow {
  threshold: number;
  caughtAdversarial: number;
  falsePositives: number;
  escalatedAmbiguous: number;
}

export function sweepAbusiveLanguage(
  examples: SweepExample[],
  thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
): SweepRow[] {
  return thresholds.map((threshold) => {
    let caughtAdversarial = 0;
    let falsePositives = 0;
    let escalatedAmbiguous = 0;
    for (const ex of examples) {
      if (ex.noul < threshold) continue;
      if (ex.label === "adversarial") caughtAdversarial++;
      else if (ex.label === "benign") falsePositives++;
      else escalatedAmbiguous++;
    }
    return { threshold, caughtAdversarial, falsePositives, escalatedAmbiguous };
  });
}

// ---------------------------------------------------------------------------
// Latency assertion: p90 of 20 runs. This is what the exercise asks for —
// not a single-pass assertion that fails whenever the machine is busy.
// ---------------------------------------------------------------------------
export async function assertP90Latency(
  run: () => Promise<unknown>,
  budgetMs: number,
  runs = 20,
): Promise<{ p90Ms: number; headroomMs: number }> {
  const samples: number[] = [];
  for (let i = 0; i < runs; i++) {
    const t = performance.now();
    await run();
    samples.push(performance.now() - t);
  }
  samples.sort((a, b) => a - b);
  const p90 = samples[Math.floor(runs * 0.9)];
  const headroom = budgetMs - p90;
  console.log(
    JSON.stringify({
      event: "guardrail.latency",
      p90Ms: Math.round(p90 * 100) / 100,
      budgetMs,
      headroomMs: Math.round(headroom * 100) / 100,
    }),
  );
  if (p90 > budgetMs) {
    throw new Error(
      `p90 latency ${p90.toFixed(1)}ms exceeded budget ${budgetMs}ms ` +
        `(headroom ${headroom.toFixed(1)}ms)`,
    );
  }
  return { p90Ms: p90, headroomMs: headroom };
}
