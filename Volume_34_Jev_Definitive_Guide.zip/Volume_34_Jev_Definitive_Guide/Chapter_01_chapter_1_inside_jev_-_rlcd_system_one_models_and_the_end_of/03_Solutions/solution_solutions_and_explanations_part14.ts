/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

<!-- NOTES.md -->
## What soft_block vs. hard_block means

- `hard_block` — refuse the request entirely and reply with a canned
  redirect. Nothing further is generated.
- `soft_block` — allow the request to proceed, but change its shape:
  on the input side, harden the system prompt; on the output side, append
  a caution or rewrite the reply.

The difference is not "how bad" — it is "what the pipeline does next."

## Utility types: one bug each prevented

- `PartialPolicy`: the sweep runner wants to override exactly one threshold
  and leave the rest at their defaults. Without `Partial`, it would need to
  spread the whole `DEFAULT_POLICY` by hand every time, and any new hazard
  key would silently default to `undefined` in the test — which then compares
  as `false` in `value >= threshold` and quietly passes benign text. The
  type prevented a test that looked correct but validated nothing.

- `ReadonlyPolicy`: the guardrail's threshold map is loaded once at boot. A
  process that mutates it in one request path would silently affect every
  future request with no log line. The `Readonly` variant makes that class
  of bug a compile error at the exact call site, not a forensics problem at
  2 a.m.

## Threshold sweep result

| threshold | adversarial caught | benign false positives | ambiguous escalated |
|-----------|--------------------|------------------------|---------------------|
| 0.1       | __                 | __                     | __                  |
| 0.2       | __                 | __                     | __                  |
| ...       | ...                | ...                    | ...                 |
| 0.9       | __                 | __                     | __                  |

(Fill from your fixture. The interesting number is not "adversarial caught"
— any threshold catches adversarial text — it is the false-positive column
on the benign half and the escalation rate on the ambiguous third.)
