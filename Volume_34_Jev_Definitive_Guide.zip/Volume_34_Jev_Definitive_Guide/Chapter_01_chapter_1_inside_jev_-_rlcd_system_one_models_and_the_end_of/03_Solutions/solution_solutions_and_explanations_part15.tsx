/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part15.tsx
// Description: Solutions and Explanations
// ==========================================

// src/JevInspector.tsx
import type {
  SystemOneResult,
  Questions,
  ChoiceResponse,
  ScoreResponse,
  NoulResponse,
} from "@typesafe-ai/sdk";
import { memo, useCallback } from "react";
import "./jev-inspector.css";

// ---------------------------------------------------------------------------
// Props: one required, two optional. `result` is typed against the SDK's own
// `SystemOneResult<Questions>`, not a hand-rolled mirror of it. If the SDK
// narrows `answers` further in a future release, this component inherits
// that narrowing for free.
// ---------------------------------------------------------------------------
export interface JevInspectorProps {
  result: SystemOneResult<Questions>;
  title?: string;
  onSelectQuestion?: (questionId: string) => void;
}

// ---------------------------------------------------------------------------
// One answer's rendering rule is chosen by its `type` discriminant. The
// three cases are visually distinct on purpose — a reader should be able to
// tell a choice from a score from a noul without reading any label text.
// ---------------------------------------------------------------------------
function NoulView({ answer }: { answer: NoulResponse }) {
  const p = answer.noul;
  return (
    <div className="noul">
      <div
        className="noul-track"
        role="img"
        aria-label={`Probability of yes: ${p.toFixed(3)}`}
      >
        <div className="noul-fill" style={{ width: `${(p * 100).toFixed(1)}%` }} />
        {/* Tick at 0.5 so the decision boundary is visible, not inferred. */}
        <div className="noul-tick" style={{ left: "50%" }} aria-hidden="true" />
      </div>
      <span className="noul-value">{p.toFixed(3)}</span>
    </div>
  );
}

function ChoiceView({ answer }: { answer: ChoiceResponse<Record<string, unknown>> }) {
  const entries = Object.entries(answer.probabilities) as Array<[string, number]>;
  const summary = entries
    .map(([label, p]) => `${label} ${p.toFixed(3)}`)
    .join(", ");
  return (
    <div className="choice">
      <div
        className="choice-track"
        role="img"
        aria-label={`Distribution: ${summary}`}
      >
        {entries.map(([label, p]) => {
          const isWinner = label === answer.choice;
          return (
            <div
              key={label}
              className={`choice-segment${isWinner ? " winner" : ""}`}
              style={{ width: `${p * 100}%` }}
              title={`${label}: ${p.toFixed(3)}`}
              tabIndex={0}
              aria-label={`${label} ${p.toFixed(3)}${isWinner ? ", winning option" : ""}`}
            >
              <span className="choice-segment-label">{label}</span>
            </div>
          );
        })}
      </div>
      <div className="choice-meta">
        <strong>{answer.choice}</strong>
        <span aria-hidden="true"> · </span>
        <span>confidence {answer.confidence.toFixed(3)}</span>
      </div>
    </div>
  );
}

function ScoreView({ answer }: { answer: ScoreResponse<readonly unknown[]> }) {
  // `probabilities` and `legend` come back keyed by level as a string
  // ("0", "1", ...). We sort numerically so the bars read left to right.
  const probabilities = answer.probabilities as Record<string, number>;
  const legend = answer.legend as Record<string, string>;
  const levelKeys = Object.keys(probabilities)
    .map((k) => Number(k))
    .sort((a, b) => a - b);
  if (levelKeys.length === 0) return null;
  const minLevel = levelKeys[0];
  const maxLevel = levelKeys[levelKeys.length - 1];
  const span = maxLevel - minLevel;
  const markerPct = span === 0 ? 0 : ((answer.score - minLevel) / span) * 100;

  return (
    <div className="score">
      <div className="score-bars" role="img" aria-label={`Score ${answer.score.toFixed(3)}`}>
        {levelKeys.map((level) => {
          const p = probabilities[String(level)] ?? 0;
          return (
            <div key={level} className="score-column" tabIndex={0}
                 aria-label={`Level ${level} (${legend[String(level)] ?? ""}) probability ${p.toFixed(3)}`}>
              <div
                className="score-bar"
                style={{ height: `${Math.max(p, 0.02) * 100}%` }}
                title={`p=${p.toFixed(3)}`}
              />
              <span className="score-column-label">
                {legend[String(level)] ?? String(level)}
              </span>
            </div>
          );
        })}
        {/* Floating indicator can sit between two bars. */}
        <div className="score-marker" style={{ left: `${markerPct}%` }} aria-hidden="true" />
      </div>
      <div className="score-meta">
        score {answer.score.toFixed(3)} · confidence {answer.confidence.toFixed(3)}
      </div>
    </div>
  );
}

function AnswerView({ answer }: { answer: unknown }) {
  const t = (answer as { type?: string }).type;
  if (t === "noul") return <NoulView answer={answer as NoulResponse} />;
  if (t === "choice") return <ChoiceView answer={answer as ChoiceResponse<Record<string, unknown>>} />;
  if (t === "score") return <ScoreView answer={answer as ScoreResponse<readonly unknown[]>} />;
  return <em className="jev-unknown">Unknown answer type: {String(t)}</em>;
}

export const JevInspector = memo(function JevInspector({
  result,
  title,
  onSelectQuestion,
}: JevInspectorProps) {
  const handleClick = useCallback(
    (questionId: string) => {
      onSelectQuestion?.(questionId);
    },
    [onSelectQuestion],
  );

  const entries = Object.entries(result.answers) as Array<[string, unknown]>;

  return (
    <section className="jev-inspector" aria-label={title ?? "Jev result"}>
      {title ? <h2 className="jev-title">{title}</h2> : null}
      <p className="jev-meta">
        model <code>{result.model}</code>
      </p>
      <ul className="jev-rows">
        {entries.map(([id, answer]) => (
          <li key={id} className="jev-row">
            <button
              type="button"
              className="jev-row-button"
              onClick={() => handleClick(id)}
            >
              <span className="jev-question-id">{id}</span>
              <AnswerView answer={answer} />
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
});

// ---------------------------------------------------------------------------
// JevComparison — a thin wrapper that renders two results side by side and
// reports, per question id, whether the winning label agrees and how far
// apart the two confidences are.
// ---------------------------------------------------------------------------
export interface JevComparisonProps {
  a: SystemOneResult<Questions>;
  b: SystemOneResult<Questions>;
  aLabel?: string;
  bLabel?: string;
}

type Scalar = { kind: "scalar"; value: number; confidence?: number };
type Label = { kind: "label"; value: string; confidence: number };

function summarize(answer: unknown): Scalar | Label | null {
  const typed = answer as { type?: string; noul?: number; choice?: string; confidence?: number; score?: number };
  if (typed.type === "noul") return { kind: "scalar", value: typed.noul ?? 0 };
  if (typed.type === "choice" && typed.choice !== undefined && typed.confidence !== undefined) {
    return { kind: "label", value: typed.choice, confidence: typed.confidence };
  }
  if (typed.type === "score" && typed.score !== undefined && typed.confidence !== undefined) {
    return { kind: "scalar", value: typed.score, confidence: typed.confidence };
  }
  return null;
}

export function JevComparison({
  a,
  b,
  aLabel = "A",
  bLabel = "B",
}: JevComparisonProps) {
  const ids = Array.from(
    new Set([...Object.keys(a.answers), ...Object.keys(b.answers)]),
  );

  return (
    <div className="jev-compare">
      <div className="jev-compare-columns">
        <JevInspector result={a} title={aLabel} />
        <JevInspector result={b} title={bLabel} />
      </div>
      <ul className="jev-compare-diff">
        {ids.map((id) => {
          const left = summarize((a.answers as Record<string, unknown>)[id]);
          const right = summarize((b.answers as Record<string, unknown>)[id]);
          if (!left || !right) {
            return (
              <li key={id}>
                <code>{id}</code>: missing on one side
              </li>
            );
          }
          if (left.kind === "label" && right.kind === "label") {
            const agree = left.value === right.value;
            const delta =
              left.confidence !== undefined && right.confidence !== undefined
                ? Math.abs(left.confidence - right.confidence)
                : undefined;
            return (
              <li key={id}>
                <code>{id}</code>:{" "}
                {agree ? `agree on "${left.value}"` : `disagree ("${left.value}" vs "${right.value}")`}
                {agree && delta !== undefined ? ` · Δconfidence ${delta.toFixed(3)}` : ""}
              </li>
            );
          }
          if (left.kind === "scalar" && right.kind === "scalar") {
            const delta = Math.abs(left.value - right.value);
            return (
              <li key={id}>
                <code>{id}</code>: Δvalue {delta.toFixed(3)}
              </li>
            );
          }
          return (
            <li key={id}>
              <code>{id}</code>: incomparable answer kinds
            </li>
          );
        })}
      </ul>
    </div>
  );
}
