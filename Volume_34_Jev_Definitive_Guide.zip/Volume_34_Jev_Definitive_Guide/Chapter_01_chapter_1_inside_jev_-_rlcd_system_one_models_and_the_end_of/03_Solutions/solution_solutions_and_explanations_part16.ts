/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part16.ts
// Description: Solutions and Explanations
// ==========================================

/* src/jev-inspector.css (excerpt) */
.jev-inspector { font-family: ui-monospace, Menlo, monospace; font-size: 13px; }
.jev-rows { list-style: none; padding: 0; }
.jev-row-button { all: unset; display: block; width: 100%; cursor: pointer; }
.jev-row-button:focus-visible { outline: 2px solid #2a78d6; outline-offset: 2px; }

/* Noul: a single horizontal bar with a tick at 0.5 */
.noul-track { position: relative; height: 14px; background: #e1e0d9; border-radius: 3px; overflow: hidden; }
.noul-fill { height: 100%; background: #2a78d6; }
.noul-tick { position: absolute; top: 0; bottom: 0; width: 2px; background: #0b0b0b; opacity: 0.4; }
.noul-value { margin-left: 8px; }

/* Choice: a stacked distribution, one segment per option */
.choice-track { display: flex; height: 18px; border-radius: 3px; overflow: hidden; }
.choice-segment { display: flex; align-items: center; justify-content: center; font-size: 10px;
                  background: #c9cee0; border-right: 1px solid #fcfcfb; }
.choice-segment.winner { background: #2a78d6; color: white; font-weight: 600; }
.choice-meta { margin-top: 4px; }

/* Score: discrete bars + floating marker */
.score-bars { position: relative; display: flex; align-items: flex-end; gap: 4px; height: 44px; }
.score-column { width: 36px; display: flex; flex-direction: column; align-items: center; }
.score-bar { width: 100%; background: #6f9b52; border-radius: 2px 2px 0 0; align-self: flex-end; }
.score-column-label { font-size: 9px; color: #52514e; }
.score-marker { position: absolute; top: -2px; bottom: 14px; width: 2px; background: #eb6834; }
.score-meta { margin-top: 6px; }
