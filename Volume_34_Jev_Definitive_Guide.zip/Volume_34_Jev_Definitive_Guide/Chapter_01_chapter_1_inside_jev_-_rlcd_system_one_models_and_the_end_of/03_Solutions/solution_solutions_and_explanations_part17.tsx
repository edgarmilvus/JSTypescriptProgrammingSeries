/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part17.tsx
// Description: Solutions and Explanations
// ==========================================

// stories/Confident.stories.tsx
import type { SystemOneResult, Questions } from "@typesafe-ai/sdk";
import { JevInspector } from "../src/JevInspector";

// Hand-authored. No API call was made to produce this fixture.
export const FullyConfident: SystemOneResult<Questions> = {
  model: "jev-1.13.0",
  usage: { input_tokens: 0, output_tokens: 0 },
  answers: {
    team: {
      type: "choice",
      choice: "billing",
      confidence: 0.99,
      probabilities: { billing: 0.99, technical: 0.01, account: 0.0 },
    },
    urgent: { type: "noul", noul: 0.98 },
    frustration: {
      type: "score",
      score: 2.0,
      confidence: 0.99,
      legend: { "0": "Calm", "1": "Frustrated", "2": "Very angry" },
      probabilities: { "0": 0.0, "1": 0.01, "2": 0.99 },
    },
    resolution: {
      type: "choice",
      choice: "refund",
      confidence: 0.97,
      probabilities: { information: 0.01, refund: 0.97, fix: 0.01, other: 0.01 },
    },
  },
} as unknown as SystemOneResult<Questions>;

export default function Story() {
  return <JevInspector result={FullyConfident} title="Fully confident" />;
}
