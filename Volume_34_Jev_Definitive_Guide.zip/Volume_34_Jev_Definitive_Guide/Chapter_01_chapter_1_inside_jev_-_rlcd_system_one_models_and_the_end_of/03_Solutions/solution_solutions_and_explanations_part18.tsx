/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part18.tsx
// Description: Solutions and Explanations
// ==========================================

// stories/NearTie.stories.tsx
import type { SystemOneResult, Questions } from "@typesafe-ai/sdk";
import { JevInspector } from "../src/JevInspector";

// The point of this story: the winner is `billing`, but confidence is
// barely above a coin flip. A reader glancing at the component must see
// that immediately — not by reading `0.51` in the corner.
export const NearTie: SystemOneResult<Questions> = {
  model: "jev-1.13.0",
  usage: { input_tokens: 0, output_tokens: 0 },
  answers: {
    team: {
      type: "choice",
      choice: "billing",
      confidence: 0.04,
      probabilities: { billing: 0.51, technical: 0.49, account: 0.0 },
    },
    urgent: { type: "noul", noul: 0.52 },
    frustration: {
      type: "score",
      score: 1.02,
      confidence: 0.02,
      legend: { "0": "Calm", "1": "Frustrated", "2": "Very angry" },
      probabilities: { "0": 0.49, "1": 0.49, "2": 0.02 },
    },
    resolution: {
      type: "choice",
      choice: "information",
      confidence: 0.05,
      probabilities: { information: 0.4, refund: 0.35, fix: 0.15, other: 0.1 },
    },
  },
} as unknown as SystemOneResult<Questions>;

export default function Story() {
  return <JevInspector result={NearTie} title="Near tie - look at the shapes" />;
}
