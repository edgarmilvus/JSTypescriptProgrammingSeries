/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part20.ts
// Description: Solutions and Explanations
// ==========================================

<!-- NOTES.md -->
## Performance

One `<JevInspector />` with three answers renders in **__ ms** on my machine
(measure with React DevTools Profiler or `performance.mark`/`measure` around
a commit).

The component is wrapped in `memo`, and the only unstable prop is
`onSelectQuestion`, which is already a concern of the caller. When the
tooling grows to render dozens of inspectors, the parent should pass a
`useCallback`-stable handler, or memoization will silently stop helping.

## A11y

Every visual carries its information into the accessibility tree:

- The `noul` bar is a `role="img"` with an `aria-label` that contains the
  exact probability. A screen reader user hears "Probability of yes: 0.982".
- Each `choice` segment is focusable and carries an `aria-label` that names
  the option, its probability, and (if applicable) that it won. The order
  of segments is left-to-right in `Object.entries` order, which matches the
  criteria insertion order in practice.
- Each `score` column is focusable and carries a label naming the level, the
  level's description from `legend`, and the level's probability. The
  floating marker is `aria-hidden`; its meaning is conveyed by the `score`
  value in the meta line.

The relationship the screen-reader user must be able to recover is: "which
option won, and how sure is the model?" Both are on the DOM for every answer
kind.

## What a reader should conclude from a ChoiceAnswer

- Fully confident: "it picked billing."
- Near tie: **"it leaned billing but was not sure."**

The second conclusion is only reachable because the component shows the
shape of the distribution, not just the winner and a confidence number.
That is what makes the visual match the machinery: downstream code reads
`probabilities` and `confidence`, not just `choice`, so the reader's mental
model should too.
