/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// src/triage.ts
import {
  choice,
  noul,
  score,
  TypeSafeClient,
  APIError,
  APIConnectionError,
  APITimeoutError,
} from "@typesafe-ai/sdk";
import type {
  ChoiceResponse,
  NoulResponse,
  ScoreResponse,
} from "@typesafe-ai/sdk";

// The SDK exports Response types. The exercise asks for Answer names, so we
// alias them locally rather than redefining the shape — that way the
// compiler still validates our usage against the SDK's own definitions.
type ChoiceAnswer<T extends Record<string, unknown>> = ChoiceResponse<T>;
type NoulAnswer = NoulResponse;
type ScoreAnswer<T extends readonly [unknown, unknown, ...unknown[]]> =
  ScoreResponse<T>;

// ---------------------------------------------------------------------------
// Process-level singleton.
//
// A new TypeSafeClient per request would:
//   1. Re-negotiate TLS on every call (the SDK keeps a pooled fetch under the hood),
//   2. Throw away the SDK's retry policy and configured default model,
//   3. Allocate fresh state for every request in a hot path.
//
// The SDK is designed to be long-lived; one instance per process is the pattern.
// ---------------------------------------------------------------------------
const client: TypeSafeClient = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY,
  defaultModel: "jev-latest",
});

// ---------------------------------------------------------------------------
// Question set. Question IDs are ours; they never leave our process.
// All four go out in ONE systemOne call. Adding a fifth question does not
// add a round trip — Jev evaluates every question against the same state in
// parallel, which is the entire point of the System One contract.
// ---------------------------------------------------------------------------
const triageQuestions = {
  team: choice("Which team should handle this support ticket?", {
    billing: "Payments, invoices, refunds, subscriptions",
    technical: "Bugs, outages, integration failures",
    account: "Login, profile, permissions, security",
  }),
  urgent: noul(
    "Does this message express urgency or time-sensitivity?",
    {
      true: "The message says or clearly implies a deadline, outage, or block",
      false: "The message describes a routine issue with no time pressure",
    },
  ),
  frustration: score("How frustrated does the customer appear?", [
    "Calm and matter-of-fact",
    "Frustrated but civil",
    "Very angry, strong language, or threatening to leave",
  ]),
  resolution: choice("What outcome does the customer appear to want?", {
    information: "Just an answer; no action required",
    refund: "Money back",
    fix: "The underlying problem resolved",
    other: "Something else, or genuinely unclear",
  }),
} as const;

export interface TriageResponse {
  ticketId: string;
  latencyMs: number;
  decisions: {
    // `billing | technical | account` are the exact criteria keys, so
    // `decision.choice` is narrowed to that union at the type level.
    team: ChoiceAnswer<{ billing: string; technical: string; account: string }>;
    urgent: NoulAnswer;
    frustration: ScoreAnswer<readonly [string, string, string]>;
    resolution: ChoiceAnswer<{
      information: string;
      refund: string;
      fix: string;
      other: string;
    }>;
  };
}

// Typed error so the HTTP layer can distinguish a Jev outage (retry-worthy)
// from a bug in our own code (not retry-worthy).
export class UpstreamDecisionError extends Error {
  constructor(message: string, public readonly retryable: boolean) {
    super(message);
    this.name = "UpstreamDecisionError";
  }
}

export async function triage(
  ticketId: string,
  message: string,
): Promise<TriageResponse> {
  // Measure only the model round trip, not JSON parsing or HTTP scaffolding.
  const t0 = performance.now();

  try {
    const response = await client.systemOne({
      // Named fields, not a raw string. This gives Jev a place to hang a
      // "which part are you looking at?" reference and matches the chapter's
      // guidance on structured state.
      state: { ticketId, message },
      questions: triageQuestions,
    });

    const latencyMs = performance.now() - t0;
    console.log(
      JSON.stringify({
        event: "triage.system_one",
        ticketId,
        latencyMs: Math.round(latencyMs * 100) / 100,
        model: response.model,
        usage: response.usage,
      }),
    );

    // Pass the SDK answers through unchanged. We consume `choice`, `noul`,
    // `score`, `confidence`, and `probabilities` here; `legend` is preserved
    // so a downstream caller can render the score's rubric without a lookup.
    return {
      ticketId,
      latencyMs,
      decisions: {
        team: response.answers.team,
        urgent: response.answers.urgent,
        frustration: response.answers.frustration,
        resolution: response.answers.resolution,
      },
    };
  } catch (err) {
    if (err instanceof APITimeoutError || err instanceof APIConnectionError) {
      console.error(
        JSON.stringify({
          event: "triage.system_one.error",
          ticketId,
          kind: "connection",
          detail: String(err),
        }),
      );
      throw new UpstreamDecisionError(
        "Decision service unreachable",
        /* retryable */ true,
      );
    }
    if (err instanceof APIError) {
      // Covers AuthenticationError, RateLimitError, InternalServerError, etc.
      const retryable = err.status === 429 || err.status >= 500;
      console.error(
        JSON.stringify({
          event: "triage.system_one.error",
          ticketId,
          kind: "api",
          status: err.status,
          requestId: err.requestId,
        }),
      );
      throw new UpstreamDecisionError(
        `Decision service returned ${err.status}`,
        retryable,
      );
    }
    // A non-SDK error is our bug. Log it and rethrow as non-retryable so the
    // upstream doesn't hammer us.
    console.error(
      JSON.stringify({
        event: "triage.system_one.error",
        ticketId,
        kind: "unknown",
        detail: String(err),
      }),
    );
    throw new UpstreamDecisionError("Internal decision error", false);
  }
}
