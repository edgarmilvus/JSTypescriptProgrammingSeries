/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/server.ts
import http from "node:http";
import { triage, UpstreamDecisionError } from "./triage.js";

const PORT = Number(process.env.PORT ?? 3000);

const server = http.createServer(async (req, res) => {
  if (req.method !== "POST" || req.url !== "/triage") {
    res.writeHead(404, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "not found" }));
    return;
  }

  // --- Read + parse JSON body -------------------------------------------
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  let parsed: unknown;
  try {
    parsed = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    res.writeHead(400, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "invalid JSON body" }));
    return;
  }

  // --- Validate ---------------------------------------------------------
  const { ticketId, message } = (parsed ?? {}) as {
    ticketId?: unknown;
    message?: unknown;
  };
  if (
    typeof ticketId !== "string" ||
    ticketId.length === 0 ||
    typeof message !== "string" ||
    message.trim().length === 0
  ) {
    res.writeHead(400, { "content-type": "application/json" });
    res.end(
      JSON.stringify({
        error: "ticketId (non-empty string) and message (non-empty string) are required",
      }),
    );
    return;
  }

  // --- Dispatch ---------------------------------------------------------
  try {
    const result = await triage(ticketId, message);
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(result));
  } catch (err) {
    if (err instanceof UpstreamDecisionError) {
      // Never 500 with a stack trace for an upstream outage.
      res.writeHead(502, { "content-type": "application/json" });
      res.end(
        JSON.stringify({
          error: err.message,
          retryable: err.retryable,
        }),
      );
      return;
    }
    res.writeHead(500, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "internal error", retryable: false }));
  }
});

server.listen(PORT, () => {
  console.log(JSON.stringify({ event: "listen", port: PORT }));
});
