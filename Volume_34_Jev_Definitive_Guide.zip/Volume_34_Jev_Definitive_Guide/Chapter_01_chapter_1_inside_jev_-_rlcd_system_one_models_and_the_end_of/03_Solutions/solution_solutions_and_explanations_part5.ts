/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

<!-- NOTES.md -->
# Triage endpoint — notes

## Measured latency

Run on: <fill in your machine + region>
Command: `curl -sX POST localhost:3000/triage -d '{"ticketId":"T-1","message":"..."}'`

- Jev `systemOne` round trip, single call, four questions: **__ ms** (paste your
  three-run average here; do not paste numbers you did not measure).

Four questions in one call costs the same wall-clock time as one question,
because they are evaluated in parallel against the same state. My measurement
above is therefore *not* "four times the cost of one question" — it is the cost
of the whole request.

## Expected generative-LLM latency, for comparison

I did not run a generative model here. What I can say from the request path:
the four-question call is a single HTTP round trip; comparing it directly to a
generative call would require running one, and this exercise deliberately does
not. The comparison is left for a chapter where a generative model is in scope.

## Design notes

- The client is a process-level singleton so that pooled connections and the
  SDK's retry policy are not re-created per request.
- The `state` uses named fields (`ticketId`, `message`) rather than a raw string.
  This is the smallest possible place to practice that habit; it pays off as
  soon as a question references `ticket.message` by path.
- `latencyMs` is measured around `client.systemOne` only. Node's HTTP framing,
  JSON parsing, and validation are excluded on purpose — the number should be
  the model's, not the framework's.
- Jev is a decision model. Everything downstream reads `choice`, `noul`, `score`,
  `confidence`, and `probabilities`. Nothing in this file asks a model to write
  prose.
