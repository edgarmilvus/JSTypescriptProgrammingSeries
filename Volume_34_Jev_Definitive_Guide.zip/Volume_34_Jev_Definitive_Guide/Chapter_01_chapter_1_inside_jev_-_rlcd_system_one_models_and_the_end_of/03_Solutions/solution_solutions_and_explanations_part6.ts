/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// src/calibrate.ts
import { noul, TypeSafeClient } from "@typesafe-ai/sdk";

export interface LabeledExample {
  id: string;
  state: unknown;
  expected: "yes" | "no";
}

export interface BucketReport {
  lo: number;
  hi: number;
  n: number;
  meanPredicted: number;
  meanObserved: number;
}

export interface CalibrationResult {
  buckets: BucketReport[];
  brier: number;
  /** Wall-clock time for the same N examples under each strategy. */
  latency: { serialMs: number; batchedMs: number };
  /** Raw model output, so callers can re-derive precision/recall without re-calling. */
  nouls: number[];
}

const urgencyQuestion = noul(
  "Does this message express urgency or time-sensitivity?",
  {
    true:
      "The message says or clearly implies a deadline, outage, or time pressure",
    false: "The message is a routine request with no time pressure expressed",
  },
);

/** One systemOne call per example. The question goes out with every call;
 *  only the state changes. This is the smallest "unit of work" the exercise
 *  asks for, and the exercise's rule is: never one call per *question*. */
async function oneCall(
  client: TypeSafeClient,
  example: LabeledExample,
): Promise<number> {
  const response = await client.systemOne({
    state: example.state,
    questions: { urgent: urgencyQuestion },
  });
  return response.answers.urgent.noul;
}

export async function calibrateUrgency(
  examples: LabeledExample[],
  client: TypeSafeClient,
  batchSize = 5,
): Promise<CalibrationResult> {
  // ---------------- Strategy A: strictly serial -------------------------
  const tSerial = performance.now();
  const serialNouls: number[] = [];
  for (const example of examples) {
    serialNouls.push(await oneCall(client, example));
  }
  const serialMs = performance.now() - tSerial;

  // ---------------- Strategy B: batched in flight -----------------------
  // `batchSize` concurrent in-flight requests, not one request carrying N
  // examples. Wall-clock comparison is the point; token usage is unchanged.
  const tBatch = performance.now();
  const batchedNouls: number[] = new Array(examples.length);
  for (let i = 0; i < examples.length; i += batchSize) {
    const slice = examples.slice(i, i + batchSize);
    const results = await Promise.all(slice.map((ex) => oneCall(client, ex)));
    results.forEach((noul, j) => {
      batchedNouls[i + j] = noul;
    });
  }
  const batchedMs = performance.now() - tBatch;

  // Sanity: the two strategies should produce identical model outputs.
  // Any difference is worth a warning in the harness log.
  for (let i = 0; i < examples.length; i++) {
    if (serialNouls[i] !== batchedNouls[i]) {
      console.warn(
        JSON.stringify({
          event: "calibrate.non_determinism",
          id: examples[i].id,
          serial: serialNouls[i],
          batched: batchedNouls[i],
        }),
      );
    }
  }

  const nouls = batchedNouls;

  // ---------------- Reliability diagram ---------------------------------
  // Ten buckets: [0.0, 0.1), ..., [0.9, 1.0]. The last bucket is closed
  // so noul === 1.0 has a home.
  const buckets: BucketReport[] = [];
  for (let b = 0; b < 10; b++) {
    const lo = b / 10;
    const hiClosed = b === 9 ? 1 + Number.EPSILON : (b + 1) / 10;
    const inBucket: Array<{ expected: "yes" | "no"; p: number }> = [];
    for (let i = 0; i < examples.length; i++) {
      if (nouls[i] >= lo && nouls[i] < hiClosed) {
        inBucket.push({ expected: examples[i].expected, p: nouls[i] });
      }
    }
    if (inBucket.length === 0) {
      // Degenerate bucket: report NaN rather than a flattering 0.
      buckets.push({ lo, hi: Math.min(hiClosed, 1), n: 0, meanPredicted: NaN, meanObserved: NaN });
      continue;
    }
    const meanPredicted =
      inBucket.reduce((s, m) => s + m.p, 0) / inBucket.length;
    const meanObserved =
      inBucket.reduce((s, m) => s + (m.expected === "yes" ? 1 : 0), 0) /
      inBucket.length;
    buckets.push({
      lo,
      hi: Math.min(hiClosed, 1),
      n: inBucket.length,
      meanPredicted,
      meanObserved,
    });
  }

  // ---------------- Brier score -----------------------------------------
  // mean((p - truth)^2).
  //   0.00 = perfect calibration AND perfect discrimination
  //   0.25 = the score of a forecaster who always says p = 0.5
  // A model that always outputs 0.5 on a balanced fixture scores 0.25;
  // to beat it, the model must be both confident and right.
  const brier =
    examples.reduce((s, ex, i) => {
      const truth = ex.expected === "yes" ? 1 : 0;
      const diff = nouls[i] - truth;
      return s + diff * diff;
    }, 0) / examples.length;

  return { buckets, brier, latency: { serialMs, batchedMs }, nouls };
}

/** Precision and recall for the "urgent" class at a given noul threshold. */
export function precisionRecall(
  examples: LabeledExample[],
  nouls: number[],
  threshold: number,
): { precision: number; recall: number; counts: { tp: number; fp: number; fn: number; tn: number } } {
  let tp = 0, fp = 0, fn = 0, tn = 0;
  for (let i = 0; i < examples.length; i++) {
    const predicted = nouls[i] >= threshold;
    const actual = examples[i].expected === "yes";
    if (predicted && actual) tp++;
    else if (predicted && !actual) fp++;
    else if (!predicted && actual) fn++;
    else tn++;
  }
  const precision = tp + fp === 0 ? NaN : tp / (tp + fp);
  const recall = tp + fn === 0 ? NaN : tp / (tp + fn);
  return { precision, recall, counts: { tp, fp, fn, tn } };
}
