/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

<!-- NOTES.md -->
### Reading the reliability diagram

Each row says: of the examples where Jev emitted a noul in [lo, hi), what
fraction were actually yes? A perfectly calibrated model has meanPredicted ==
meanObserved in every non-empty bucket, so the pairs lie on the diagonal.

### Reading the Brier score

- 0.00 would mean: for every example the model assigned either p = 1 to a yes
  or p = 0 to a no, and it was right every time.
- 0.25 is what you get from a forecaster that always says p = 0.5 on a 50/50
  fixture. **A model scoring above 0.25 on a balanced fixture is worse than
  saying "no idea".** That is the bar.

### Threshold trade-off

- `threshold = 0.5` treats a coin flip as a decision. Higher recall, more
  false positives. Preferable when a missed urgent ticket is expensive and a
  spurious escalation is cheap — e.g. queuing to a human who can de-prioritize.
- `threshold = 0.7` requires the model to be reasonably sure before escalating.
  Higher precision, lower recall. Preferable when an escalation triggers a
  pager or another expensive resource. This is the same trade-off that drives
  the confidence-gated routing pattern in later chapters.

### Degenerate buckets

On a homogeneous fixture, one bucket can absorb nearly every example and the
rest are empty. Empty buckets are reported as NaN, not 0. A bucket with n=0
is not evidence of calibration; a bucket with n=1 is nearly meaningless. Both
are visible in the table on purpose.
