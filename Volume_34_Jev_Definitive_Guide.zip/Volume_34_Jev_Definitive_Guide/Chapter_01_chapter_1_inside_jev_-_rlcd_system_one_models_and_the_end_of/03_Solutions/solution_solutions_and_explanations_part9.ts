/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// src/concierge.ts
import { choice, noul, score, TypeSafeClient, APIError } from "@typesafe-ai/sdk";
import OpenAI from "openai";

export type Route =
  | "order_status"
  | "refund_request"
  | "account_access"
  | "general_question"
  | "needs_human";

// ---------------------------------------------------------------------------
// Both clients are created once at module scope. The generative client is
// expensive; creating it per request would be a pessimization for the same
// reasons as Exercise 1, plus it would thrash the underlying HTTP pool.
// ---------------------------------------------------------------------------
const ts = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY,
  defaultModel: "jev-latest",
});

const generative = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const GENERATIVE_MODEL = process.env.GENERATIVE_MODEL ?? "gpt-4o-mini";

// Confidence floor for the route decision. Below this, we override to
// `needs_human`, regardless of which label Jev picked. Reasoning: the
// five-way route contains pairs that are easy to confuse (`refund_request`
// vs `order_status` when the user mentions both a broken order and money,
// `general_question` vs `needs_human`). A confident wrong route is worse
// than an explicit hand-off, so we escalate on doubt. This mirrors the
// chapter's confidence-gated routing pattern.
const ROUTE_CONFIDENCE_FLOOR = 0.7;

// ---------------------------------------------------------------------------
// One systemOne call, four questions. The `expectation` score is what
// becomes the instruction we pass to the generative model when we hand off.
// ---------------------------------------------------------------------------
const routingQuestions = {
  route: choice("Which route should this support message take?", {
    order_status:
      "The user wants to know where an order is or what happened to it",
    refund_request:
      "The user wants money back, a cancellation, or a return",
    account_access:
      "The user cannot sign in, or is managing account settings and permissions",
    general_question:
      "An open-ended or informational question that needs an explanatory answer",
    needs_human:
      "The message is hostile, incomprehensible, or falls outside the other routes",
  }),
  polite: noul(
    "Is the tone of this message polite enough to auto-answer without extra care?",
    {
      true: "The message is neutral or friendly",
      false: "The message is curt, angry, or contains profanity",
    },
  ),
  expectation: score(
    "How much does the user appear to expect from an agent, rather than from a database?",
    [
      "Lookup: a fact they could have found themselves",
      "Explain: a short explanation of what something is or why something happened",
      "Advise: a recommendation or a plan for what to do next",
    ],
  ),
  entity: choice("What is the primary entity the message refers to?", {
    order: "An order, shipment, or delivery",
    account: "An account, login, or credentials",
    billing: "A charge, invoice, or subscription",
    none: "No specific entity",
  }),
} as const;

// ---------------------------------------------------------------------------
// Route histogram. In-memory, process-local, and deliberately tiny: it is
// the smallest thing that lets a human see whether the two-speed shape is
// spending generative calls where they expected.
// ---------------------------------------------------------------------------
const routeCounts: Record<Route, number> = {
  order_status: 0,
  refund_request: 0,
  account_access: 0,
  general_question: 0,
  needs_human: 0,
};

export function getRouteHistogram(): Record<Route, number> {
  return { ...routeCounts };
}

// ---------------------------------------------------------------------------
// Deterministic handler. Reads from local state, produces a string, and
// never touches a model. This is the "fast path" the two-speed design is
// built to make common.
// ---------------------------------------------------------------------------
function handleOrderStatus(orderId: string | undefined): string {
  if (!orderId) {
    return "I couldn't find an order on your account. Which order do you mean?";
  }
  // In a real service, this would hit an order service.
  return `Order ${orderId} shipped yesterday and is scheduled to arrive within two business days.`;
}

// ---------------------------------------------------------------------------
// The expectation score, mapped to a generative-model instruction.
// The score is a probability-weighted number; pickExpectationKey snaps it to
// the nearest legend entry. We keep this mapping in code, not in the model,
// so a product change is a diff, not a retraining.
// ---------------------------------------------------------------------------
function pickExpectationKey(
  scoreValue: number,
): "lookup" | "explain" | "advise" {
  if (scoreValue < 0.5) return "lookup";
  if (scoreValue < 1.5) return "explain";
  return "advise";
}

const EXPECTATION_INSTRUCTION: Record<
  "lookup" | "explain" | "advise",
  string
> = {
  lookup: "Answer briefly and functionally. One line is often enough.",
  explain: "Answer conversationally, in a short paragraph.",
  advise: "Answer with a clear recommendation and a brief rationale.",
};

export interface ConciergeResult {
  route: Route;
  latencyMs: { jev: number; generative?: number };
  reply: string;
}

export async function concierge(
  message: string,
  localState: { orderId?: string; accountId?: string },
): Promise<ConciergeResult> {
  // ---------------- Fast decision ---------------------------------------
  const tJev = performance.now();
  const decision = await ts.systemOne({
    state: {
      message,
      // Include only the fields a question might reference. In this design,
      // no question references order/account IDs, so we could omit them —
      // but they cost almost nothing and make the state self-describing
      // for whoever reads a playground link later.
      orderId: localState.orderId ?? null,
      accountId: localState.accountId ?? null,
    },
    questions: routingQuestions,
  });
  const jevMs = performance.now() - tJev;

  // ---------------- Confidence gate -------------------------------------
  const chosen = decision.answers.route;
  const route: Route =
    chosen.confidence < ROUTE_CONFIDENCE_FLOOR
      ? "needs_human"
      : (chosen.choice as Route);
  routeCounts[route]++;

  console.log(
    JSON.stringify({
      event: "concierge.route",
      jevMs: Math.round(jevMs * 100) / 100,
      chosen: chosen.choice,
      confidence: chosen.confidence,
      effectiveRoute: route,
    }),
  );

  // ---------------- Dispatch --------------------------------------------
  switch (route) {
    case "order_status":
      return {
        route,
        latencyMs: { jev: jevMs },
        reply: handleOrderStatus(localState.orderId),
      };

    case "refund_request":
      // Refunds require authorized action; the fast path is to acknowledge
      // and route, not to make the decision.
      return {
        route,
        latencyMs: { jev: jevMs },
        reply:
          "I can't approve refunds directly. I've flagged your ticket for the returns team and you'll hear back within one business day.",
      };

    case "account_access":
      // Also deterministic: we know the shape of the answer even if the
      // specifics (which link, which email) come from local state.
      return {
        route,
        latencyMs: { jev: jevMs },
        reply:
          "I've sent a secure sign-in link to the email on file. If you don't see it, check your spam folder.",
      };

    case "needs_human":
      return {
        route,
        latencyMs: { jev: jevMs },
        reply:
          "I'm going to hand this to a human agent so we get it right. Someone will follow up shortly.",
      };

    case "general_question": {
      // The only route that spends generative tokens. Jev has already:
      //  - classified the request,
      //  - extracted the primary entity,
      //  - rated the level of expectation.
      // Those three facts become the system prompt, so the generative
      // model writes; it does not decide.
      const entityKey = decision.answers.entity.choice;
      const expectationKey = pickExpectationKey(
        decision.answers.expectation.score,
      );

      const systemPrompt = [
        `Route: general_question.`,
        `Primary entity: ${entityKey}.`,
        `Instruction: ${EXPECTATION_INSTRUCTION[expectationKey]}`,
        `The user's original message follows.`,
      ].join("\n");

      const tGen = performance.now();
      const gen = await generative.chat.completions.create({
        model: GENERATIVE_MODEL,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message },
        ],
      });
      const genMs = performance.now() - tGen;

      console.log(
        JSON.stringify({
          event: "concierge.generative",
          genMs: Math.round(genMs * 100) / 100,
          model: GENERATIVE_MODEL,
        }),
      );

      return {
        route,
        latencyMs: { jev: jevMs, generative: genMs },
        reply: gen.choices[0]?.message.content ?? "",
      };
    }
  }
}

// Re-export so the HTTP layer can branch on the same typed error class as
// in Exercise 1.
export { APIError };
