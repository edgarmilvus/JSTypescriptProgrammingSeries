/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// src/triage.ts
import { choice, noul, score, TypeSafeClient } from "@typesafe-ai/sdk";

const client = new TypeSafeClient({
  // read the key from env; the SDK will do this for you by default,
  // but be explicit so the intent is visible in code review
  apiKey: process.env.TYPESAFE_API_KEY,
  // pin the model so your latency numbers are comparable across runs
  defaultModel: "jev-latest",
});

// You choose the question IDs. They are not sent to the model.
// They are echoed back as the keys of `answers`.
const triageQuestions = {
  team: choice(/* instructions */, {
    billing: null,
    technical: null,
    account: null,
  }),
  urgent: noul(/* instructions */),
  frustration: score(
    /* instructions */,
    [
      /* level 0 */,
      /* level 1 */,
      /* level 2 */,
    ],
  ),
  resolution: choice(/* instructions */, {
    information: null,
    refund: null,
    fix: null,
    other: null,
  }),
};

export async function triage(ticketId: string, message: string): Promise<TriageResponse> {
  // your implementation
}
