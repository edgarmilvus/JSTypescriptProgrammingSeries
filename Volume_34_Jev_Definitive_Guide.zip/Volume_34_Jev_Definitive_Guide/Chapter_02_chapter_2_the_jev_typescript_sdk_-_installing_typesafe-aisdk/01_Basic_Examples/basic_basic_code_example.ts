/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/triage/route.ts
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type ChoiceResponse,
  type NoulResponse,
  type ScoreResponse,
} from "@typesafe-ai/sdk";

/**
 * A single, module-scope client. The SDK reads TYPESAFE_API_KEY from the
 * environment when `apiKey` is omitted; passing it explicitly makes the
 * dependency obvious in code review.
 */
const client = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY,
  timeout: 8_000,
});

/** Run on the Edge Runtime so the handler is co-located with the user. */
export const runtime = "edge";

/**
 * Shape of the request body we accept from the client.
 * Keeping it narrow stops a stray `JSON.parse` from widening our types.
 */
interface TriageRequest {
  message: string;
}

/** Shape of the response we hand back to the client. */
interface TriageResponse {
  department: "billing" | "technical" | "sales";
  isUrgent: boolean;
  frustration: number;
  route: "auto" | "human";
}

/**
 * POST /api/triage
 *
 * Evaluate one support message against three Jev primitives in a single
 * round trip, then decide — in code — whether to auto-route or escalate.
 */
export async function POST(request: Request): Promise<Response> {
  // 1. Parse and validate the inbound request.
  const body = (await request.json()) as TriageRequest;
  if (typeof body?.message !== "string" || body.message.length === 0) {
    return Response.json({ error: "message is required" }, { status: 400 });
  }

  // 2. Ask Jev three independent questions about the same state.
  const response = await client.systemOne({
    state: { ticket: { text: body.message } },
    questions: {
      department: choice("Which team should handle this ticket?", {
        billing: "Payments, invoices, refunds, subscriptions.",
        technical: "Bugs, integrations, outages, account access.",
        sales: "Pricing, upgrades, plan changes, trials.",
      }),
      is_urgent: noul("Does this message convey urgency or time-sensitivity?"),
      frustration: score("How frustrated is the customer?", [
        "Calm; just stating facts.",
        "Frustrated but civil.",
        "Very angry, strong language, or threats to churn.",
      ]),
    },
  });

  // 3. Narrow each answer using the discriminated `type` field.
  const department = response.answers.department; // ChoiceResponse<...>
  const isUrgent = response.answers.is_urgent;     // NoulResponse
  const frustration = response.answers.frustration; // ScoreResponse

  // 4. Composite decision: route to a human if the model is unsure,
  //    the message is urgent, or the customer is visibly angry.
  const lowConfidence = department.confidence < 0.75;
  const shouldEscalate =
    lowConfidence || isUrgent.noul > 0.8 || frustration.score > 1.5;

  const payload: TriageResponse = {
    department: department.choice,
    isUrgent: isUrgent.noul > 0.5,
    frustration: frustration.score,
    route: shouldEscalate ? "human" : "auto",
  };

  return Response.json(payload);
}
