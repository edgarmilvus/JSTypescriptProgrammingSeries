/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ═══════════════════════════════════════════════════════════════════════
// FILE 1 — lib/jev.ts  (server-only)
// ═══════════════════════════════════════════════════════════════════════
// Three decisions live in this file:
//   1. One TypeSafeClient per Node process (module-scoped singleton).
//   2. Fail fast when TYPESAFE_API_KEY is absent, not on first user request.
//   3. Pin the model via env var so a version bump is a config change, not a
//      code change.
import "server-only"; // hard-stops this module from entering a client bundle
import { TypeSafeClient } from "@typesafe-ai/sdk";

let _client: TypeSafeClient | null = null;

export function getJev(): TypeSafeClient {
  if (_client) return _client;

  const apiKey = process.env.TYPESAFE_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      "TYPESAFE_API_KEY is not set. Jev cannot start without credentials.",
    );
  }

  _client = new TypeSafeClient({
    apiKey,
    // A UI-safety ceiling, not a latency budget. Jev's typical round trip is
    // ~100 ms; anything approaching 2.5 s is an upstream problem we want to
    // surface as an error we can classify, not a promise that hangs.
    timeout: 2_500,
    // Pinning the model by env var lets ops roll the version forward by
    // deploying an env change instead of a code change.
    defaultModel: process.env.JEV_MODEL ?? "jev-latest",
    // The SDK retries 408/429/5xx by default. Spelling the policy out keeps
    // the sub-100 ms budget honest: we cap backoff so a single 429 can never
    // dominate a real-time decision path.
    retry: {
      maxRetries: 2,
      backoffInitialMs: 80,
      backoffMaxMs: 640,
      backoffJitter: 0.2,
      respectRetryAfter: true,
    },
  });

  return _client;
}
