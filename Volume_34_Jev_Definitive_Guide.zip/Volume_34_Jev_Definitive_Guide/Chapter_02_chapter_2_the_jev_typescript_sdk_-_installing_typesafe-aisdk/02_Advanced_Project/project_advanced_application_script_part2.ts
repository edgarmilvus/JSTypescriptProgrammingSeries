/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// ═══════════════════════════════════════════════════════════════════════
// FILE 2 — app/actions/triage.ts  (Server Action)
// ═══════════════════════════════════════════════════════════════════════
"use server";

import { createStreamableUI, createStreamableValue } from "ai/rsc";
import { choice, noul, score } from "@typesafe-ai/sdk";
import { getJev } from "@/lib/jev";
import { PendingCard, ResolvedCard } from "@/components/TriageCard";

/** The payload that flows down the RSC data-stream to the Client Component. */
export type TriageResult = {
  department: "billing" | "technical" | "account";
  departmentConfidence: number;
  urgencyLevel: number;         // 0–3, can be fractional
  urgencyConfidence: number;
  refundProbability: number;    // 0–1
  elapsedMs: number;            // server-measured Jev round trip
};

export async function triageTicket(ticket: string) {
  // Two independent streams: one for *React nodes*, one for *typed values*.
  // The node stream renders the progressive UI; the value stream lets the
  // Client Component own its own state without walking the RSC tree.
  const ui = createStreamableUI(<PendingCard />);
  const data = createStreamableValue<TriageResult>();

  // Deliberately not awaited. The Server Action returns the streams to
  // Next.js immediately so the initial HTML hits the browser without waiting
  // on the Jev round trip.
  (async () => {
    const t0 = performance.now();

    const { answers } = await getJev().systemOne({
      state: ticket,
      // One request, three questions, evaluated in parallel against the same
      // state. Adding questions barely moves the response time.
      questions: {
        department: choice("Which team should handle this ticket?", {
          billing: "Charges, invoices, refunds, or subscription issues",
          technical: "Bugs, integrations, or product behaviour",
          account: "Login, profile, permissions, or security",
        }),
        urgency: score("How urgent is this ticket?", [
          "Low — no time pressure",
          "Medium — standard SLA applies",
          "High — user is blocked but not in production",
          "Critical — production outage or data loss",
        ]),
        requests_refund: noul(
          "Does the customer explicitly request a refund or credit?",
          {
            true: "Asks directly for money back or an account credit",
            false: "Does not ask for a refund or credit",
          },
        ),
      },
    });

    const elapsedMs = performance.now() - t0;

    const payload: TriageResult = {
      department: answers.department.choice as TriageResult["department"],
      departmentConfidence: answers.department.confidence,
      urgencyLevel: answers.urgency.score,
      urgencyConfidence: answers.urgency.confidence,
      refundProbability: answers.requests_refund.noul,
      elapsedMs,
    };

    // Closing the streams turns the skeleton into a resolved card and hands
    // the client the final typed payload in one tick.
    data.done(payload);
    ui.done(<ResolvedCard {...payload} />);
  })();

  return { ui: ui.value, data: data.value };
}
