/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// ═══════════════════════════════════════════════════════════════════════
// FILE 3 — components/TicketPanel.tsx  (Client Component)
// ═══════════════════════════════════════════════════════════════════════
"use client";

import { useState, useTransition, type ReactNode } from "react";
import { readStreamableValue } from "ai/rsc";
import { triageTicket, type TriageResult } from "@/app/actions/triage";

export function TicketPanel() {
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<TriageResult | null>(null);
  const [streamedUi, setStreamedUi] = useState<ReactNode>(null);

  function onSubmit(formData: FormData) {
    const ticket = String(formData.get("ticket") ?? "");

    startTransition(async () => {
      const { ui, data } = await triageTicket(ticket);

      // Reading the UI stream: React reconciles the skeleton, then the card.
      // This iteration is what makes the "instant" feel real — the browser
      // receives the pending card before Jev has answered.
      (async () => {
        for await (const node of readStreamableValue(ui)) {
          setStreamedUi(node);
        }
      })();

      // Reading the data stream: gives us the raw payload for charts, audit
      // logs, or downstream calls that need the numeric values.
      (async () => {
        for await (const value of readStreamableValue(data)) {
          if (value) setResult(value);
        }
      })();
    });
  }

  return (
    <form action={onSubmit} className="space-y-4">
      <textarea
        name="ticket"
        rows={4}
        className="w-full rounded-md border-neutral-300 p-3 text-sm"
        placeholder="Paste a customer ticket…"
      />
      <button
        type="submit"
        disabled={pending}
        className="rounded-md bg-neutral-900 px-3 py-2 text-sm text-white disabled:opacity-50"
      >
        {pending ? "Triaging…" : "Triage"}
      </button>
      {streamedUi}
      {result && (
        <pre className="overflow-x-auto rounded bg-neutral-50 p-3 text-xs">
          {JSON.stringify(result, null, 2)}
        </pre>
      )}
    </form>
  );
}
