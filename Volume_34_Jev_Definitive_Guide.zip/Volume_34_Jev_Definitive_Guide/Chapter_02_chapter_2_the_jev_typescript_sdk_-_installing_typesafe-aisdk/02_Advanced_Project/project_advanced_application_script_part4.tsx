/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.tsx
// Description: Advanced Application Script
// ==========================================

// ═══════════════════════════════════════════════════════════════════════
// FILE 4 — components/TriageCard.tsx
// ═══════════════════════════════════════════════════════════════════════
// Two presentations of the same ticket: the skeleton shown before Jev's
// response arrives, and the resolved card that replaces it.
import type { TriageResult } from "@/app/actions/triage";

export function PendingCard() {
  return (
    <div className="rounded-lg border border-neutral-200 p-4 animate-pulse">
      <div className="h-4 w-24 rounded bg-neutral-200" />
      <div className="mt-3 h-3 w-48 rounded bg-neutral-100" />
      <div className="mt-2 h-3 w-40 rounded bg-neutral-100" />
    </div>
  );
}

export function ResolvedCard(r: TriageResult) {
  // Confidence bands are computed here, on the client, from Jev's calibrated
  // confidence — so a per-tenant SLA can re-tune routing without touching
  // the server action.
  const route =
    r.departmentConfidence >= 0.75 && r.urgencyConfidence >= 0.7
      ? "auto"
      : r.departmentConfidence >= 0.5
        ? "review"
        : "human";

  return (
    <div className="rounded-lg border border-neutral-200 p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-neutral-500">
          {r.department}
        </span>
        <span className="text-xs text-neutral-400">
          {r.elapsedMs.toFixed(0)} ms
        </span>
      </div>
      <p className="mt-2 text-sm text-neutral-700">
        Urgency {r.urgencyLevel.toFixed(2)} · confidence{" "}
        {(r.urgencyConfidence * 100).toFixed(0)}%
      </p>
      {r.refundProbability > 0.7 && (
        <p className="mt-1 text-xs text-amber-700">
          Refund likely (p={r.refundProbability.toFixed(2)})
        </p>
      )}
      <p className="mt-3 text-[11px] uppercase tracking-wider text-neutral-400">
        route: {route}
      </p>
    </div>
  );
}
