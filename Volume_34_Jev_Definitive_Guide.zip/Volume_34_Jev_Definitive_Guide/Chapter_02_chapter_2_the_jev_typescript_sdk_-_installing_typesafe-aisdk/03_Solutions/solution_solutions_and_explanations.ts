/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/client.ts
//
// Four decisions freeze the configuration boundary for a Jev-powered service.
//
// 1. WHY A SINGLETON. A TypeSafeClient owns an HTTP transport and retry state.
//    Constructing one per call throws away connection reuse, resets retry
//    accounting mid-flight, and multiplies any per-client overhead by your
//    request rate. One instance per process is the shape the SDK is built for.
//
// 2. WHY FAIL-FAST. Config errors — an unset API key, a staging URL promoted
//    to prod, an alias that moved — are the leading cause of 3 a.m. pages that
//    have nothing to do with the model. Validating at construction time means
//    a bad deploy crashes at boot, with a message an on-call engineer can act
//    on, instead of degrading silently at the first user request.
//
// 3. WHY A NAMED ERROR CLASS. Callers must distinguish "the deployment is
//    broken" from "the dependency is having a bad minute." A JevConfigError is
//    retry-toxic: it should page the deploy engineer, not trigger backoff. A
//    RateLimitError is the opposite policy. Matching on `err.message.includes`
//    is brittle (messages change) and invisible to the type system.
//
// 4. WHY models.list() IS THE HEALTH CHECK. The SDK's models list exercises
//    exactly the two things that can be wrong at boot — authentication and
//    endpoint reachability — without spending model tokens, without consuming
//    rate-limit budget, and without occupying queue capacity a real request
//    could use. A synthetic systemOne call would work, but its output is
//    discarded and it creates a "hello world" question that becomes a
//    permanent artifact of the health check.

import { TypeSafeClient, type ModelCard } from "@typesafe-ai/sdk";

/**
 * Thrown when the process cannot be started because its Jev configuration is
 * invalid. Never thrown for operational failures (network, rate limit, 5xx).
 *
 * Callers should catch this separately from SDK errors: a config failure is
 * fixable by rolling a deployment; a rate limit is not.
 */
export class JevConfigError extends Error {
  constructor(message: string) {
    super(message);
    // `name` survives JSON.stringify, log aggregation, and `instanceof`
    // post-serialization; a bare subclass does not.
    this.name = "JevConfigError";
  }
}

const KEY_CONSOLE_URL = "https://console.typesafe.ai/settings/keys";

/**
 * Lazy singleton. The `client` variable is assigned once, on the first call,
 * and read on every subsequent call. We use a three-state check
 * (`undefined | TypeSafeClient`) rather than a boolean flag so the TS types
 * narrow cleanly.
 */
let client: TypeSafeClient | undefined;

/**
 * Read a required environment variable and throw a domain-specific error with
 * remediation text. The SDK would surface a missing key on its own, but its
 * message cannot know where *your* keys are minted — this one can.
 */
function requireEnv(name: string): string {
  const raw = process.env[name];
  // The SDK treats an empty or whitespace-only value as absent. We mirror that
  // here so a `TYPESAFE_API_KEY=` line in a dotenv file fails loudly rather
  // than sending an empty Bearer token and earning a confusing 401.
  if (raw === undefined || raw.trim() === "") {
    throw new JevConfigError(
      `Missing required environment variable ${name}. ` +
        `Mint a key at ${KEY_CONSOLE_URL}, then inject it into this ` +
        `environment (for local dev, add ${name}=... to .env.local).`,
    );
  }
  return raw.trim();
}

/**
 * The one and only entry point to the Jev client. Returns the same instance
 * for the lifetime of the process.
 *
 * We read TYPESAFE_API_KEY explicitly (so we can attach a URL to the error);
 * we leave TYPESAFE_BASE_URL, TYPESAFE_DEFAULT_MODEL, and TYPESAFE_LOG_LEVEL
 * to the SDK's own environment resolution, because passing explicit
 * `undefined` for those fields can defeat the SDK's fallback depending on how
 * it distinguishes "omitted" from "present with value undefined." The safest
 * policy is: resolve only the values we intend to validate; let the SDK
 * resolve the rest.
 */
export function getClient(): TypeSafeClient {
  if (client !== undefined) return client;

  // Validate BEFORE constructing. Nothing below this line needs to know that
  // TYPESAFE_API_KEY exists.
  const apiKey = requireEnv("TYPESAFE_API_KEY");

  // The SDK's documented defaults, when these environment variables are unset:
  //   TYPESAFE_BASE_URL      -> "https://api.typesafe.ai"
  //   TYPESAFE_DEFAULT_MODEL -> "jev-latest"
  //   TYPESAFE_LOG_LEVEL     -> "warn"
  client = new TypeSafeClient({ apiKey });
  return client;
}

export interface ResolvedConfig {
  baseURL: string;
  defaultModel: string;
  logLevel: string;
  /**
   * A redacted fingerprint of the resolved API key. Even this is a debatable
   * choice: a four-and-four display leaks ~8 bits of a 48-character key, which
   * only matters if an attacker already holds most of the key. The pragmatic
   * case for showing it is that support can match a log line to a console
   * entry without anyone handling the secret itself. If your threat model
   * disagrees, print `null`.
   */
  apiKeyFingerprint: string | null;
}

/**
 * Non-secret configuration snapshot for the startup log. Resolves the same
 * defaults the SDK would, so the log reflects reality.
 */
export function describeConfig(): ResolvedConfig {
  const rawKey = process.env.TYPESAFE_API_KEY ?? "";
  const fingerprint =
    rawKey.length >= 12 ? `${rawKey.slice(0, 4)}…${rawKey.slice(-4)}` : null;

  return {
    baseURL: process.env.TYPESAFE_BASE_URL?.trim() || "https://api.typesafe.ai",
    defaultModel: process.env.TYPESAFE_DEFAULT_MODEL?.trim() || "jev-latest",
    logLevel: process.env.TYPESAFE_LOG_LEVEL?.trim() || "warn",
    apiKeyFingerprint: fingerprint,
  };
}

/**
 * One-shot startup probe. Calls the smallest authenticated endpoint the SDK
 * exposes. Silent on success; rethrows the original SDK error untouched on
 * failure so the caller can decide whether to crash, alert, or degrade.
 */
export async function assertJevReachable(): Promise<ModelCard[]> {
  const c = getClient();
  // `models.list()` authenticates and confirms the endpoint resolves. It costs
  // no model tokens and consumes no rate-limit budget that a real request
  // would need. On failure, the SDK's own error (AuthenticationError,
  // APIConnectionError, APITimeoutError) propagates.
  return await c.models.list();
}
