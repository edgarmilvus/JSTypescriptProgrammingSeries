/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/decide.test.ts
//
// All tests use the SDK's `fetch` config field, which exists precisely so you
// can substitute the transport. No test hits the real network.
import { describe, expect, it, vi } from "vitest";
import { RateLimitError, TypeSafeClient } from "@typesafe-ai/sdk";
import { JevConfigError } from "./client";
import { decideWithFallback, keywordFallback } from "./decide";

function json(body: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", ...headers },
  });
}

const HAPPY = {
  model: "jev-latest",
  answers: {
    department: { type: "choice", choice: "billing", probabilities: { billing: 1 }, confidence: 1 },
    urgency: {
      type: "score",
      score: 1.2,
      confidence: 0.9,
      legend: { "0": "a", "1": "b", "2": "c" },
      probabilities: { "0": 0, "1": 0.8, "2": 0.2 },
    },
    requestsRefund: { type: "noul", noul: 0.95 },
    containsSensitiveRequest: { type: "noul", noul: 0.1 },
    mentionsOpenOrder: { type: "noul", noul: 0.8 },
  },
  usage: { input_tokens: 100, output_tokens: 10 },
};

const INPUT = {
  message: "Please refund the duplicate charge on order A-104.",
  openOrders: [{ id: "A-104", status: "processing" }],
};

describe("decideWithFallback", () => {
  it("returns source 'jev' when the initial attempt succeeds", async () => {
    const fetchFn = vi.fn(async () => json(HAPPY));
    const client = new TypeSafeClient({ apiKey: "test", fetch: fetchFn });
    // In a real project, inject `client` into triage via vi.mock("./client")
    // returning it from `getClient`. The point of the test is that no real
    // network is touched.
    const events: { outcome: string }[] = [];
    const { source } = await decideWithFallback(INPUT, keywordFallback, (e) =>
      events.push(e as never),
    );
    expect(source).toBe("jev");
    expect(events.at(-1)?.outcome).toBe("jev");
    expect(fetchFn).toHaveBeenCalledTimes(1);
  });

  it("retries once on 429 with Retry-After and then succeeds", async () => {
    let calls = 0;
    const fetchFn = vi.fn(async () => {
      calls += 1;
      if (calls === 1) {
        return new Response("", {
          status: 429,
          headers: { "retry-after": "0" },
        });
      }
      return json(HAPPY);
    });
    const client = new TypeSafeClient({
      apiKey: "test",
      fetch: fetchFn,
      retry: { maxRetries: 1, backoffInitialMs: 1, backoffJitter: 0, respectRetryAfter: true },
    });
    // ... drive triage through this client; assert calls === 2.
    expect(calls).toBe(2);
  });

  it("falls back when every attempt returns 500", async () => {
    const fetchFn = vi.fn(async () => new Response("", { status: 500 }));
    const client = new TypeSafeClient({
      apiKey: "test",
      fetch: fetchFn,
      // Turn off retries to keep the test fast and deterministic.
      retry: { maxRetries: 0 },
    });
    const events: { outcome: string }[] = [];
    const { source } = await decideWithFallback(INPUT, keywordFallback, (e) =>
      events.push(e as never),
    );
    expect(source).toBe("fallback");
    expect(events.at(-1)?.outcome).toBe("fallback");
    // The 500 body was returned for the single attempt; no retry.
    expect(fetchFn).toHaveBeenCalledTimes(1);
  });

  it("rethrows JevConfigError and does NOT fall back", async () => {
    // Arrange a getClient() that throws JevConfigError (missing env var, or
    // vi.mock("./client") to force the throw). The important assertion is that
    // decideWithFallback propagates the error and does not silently succeed.
    await expect(
      decideWithFallback(INPUT, keywordFallback, () => {}),
    ).rejects.toBeInstanceOf(JevConfigError);
  });

  it("emits retryAfterMs when the underlying failure is a RateLimitError", async () => {
    const events: { retryAfterMs?: number | null }[] = [];
    const fetchFn = vi.fn(
      async () =>
        new Response("", {
          status: 429,
          headers: { "retry-after": "2" },
        }),
    );
    const client = new TypeSafeClient({
      apiKey: "test",
      fetch: fetchFn,
      retry: { maxRetries: 0, respectRetryAfter: false },
    });
    // ... drive triage through this client; assert the sink saw retryAfterMs=2000.
    // (In production, this is exactly how you decide whether to fall back
    // immediately or wait: a small retryAfterMs is a wait, a large one is a fallback.)
  });
});
