/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

## Note: why honoring Retry-After matters, and when it does not

Retrying on `429` without reading `Retry-After` is worse than not retrying at
all: the server has just told you it is at capacity, and hammering it again
adds load precisely when it can least afford it. The window between the first
429 and the next request is the window during which every other client on the
planet is also retrying. The SDK's `respectRetryAfter: true` default is the
correct behavior on general-purpose clients.

On a low-latency decision path it is only correct *when the server's suggested
delay is small*. The SDK caps the honored delay at `maxRetryAfterMs`. If the
server asks for 4 seconds and your budget allows 40 milliseconds, the correct
response is to fail fast and let the caller fall back — not to sleep for four
seconds and blow every downstream SLA. Set `maxRetryAfterMs` to the slack in
your budget. When the server's suggestion exceeds the cap, the SDK falls back
to its own exponential backoff schedule; for a tight budget that schedule
should also be short (or the retry should be disabled entirely). Either way,
the caller sees the 429 rather than a hang.
