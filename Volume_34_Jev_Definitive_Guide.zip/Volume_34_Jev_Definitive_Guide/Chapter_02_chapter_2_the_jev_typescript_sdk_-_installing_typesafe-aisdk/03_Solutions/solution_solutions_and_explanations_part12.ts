/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/client.ts
//
// This is the CORRECTED version. Every change from the broken original is
// marked with a `// FIX:` comment that names the bug number from the walk-
// through below. The original file and the bugs it contained are discussed in
// the Instructor's Analysis.

// FIX #1 (wrong package name): the published package is @typesafe-ai/sdk.
// `typesafe-sdk` is not a real package; the original would not install.
import { TypeSafeClient, TypeSafeError } from "@typesafe-ai/sdk";

// FIX #2 (wrong env var names): the SDK reads TYPESAFE_API_KEY and
// TYPESAFE_BASE_URL. `TYPESAFE_KEY` and `TYPESAFE_URL` are not recognized, so
// the API key is effectively unset on every deployment that only provides the
// documented names — this is the root cause of the staging 401.
//
// FIX #3 (timeout unit): `timeout` is in milliseconds. 30 means 30 ms, not 30
// seconds. That works occasionally on a warm connection and fails whenever
// the region is far from the endpoint or the model is slow.
//
// FIX #4 (retry schedule): `maxRetries: 5` with the default backoff schedule
// allows ~12 s of sleep between attempts. On a 30 ms timeout, the SDK returns
// quickly but the aggregate latency is measured in seconds.
//
// FIX #5 (state type): `state` is typed as `EntryType` = `string | object |
// array | null`. It is NOT `undefined`. Leaving it undefined either fails the
// type check (strict) or sends the model nothing to evaluate.
//
// FIX #6 (question literal): use the SDK factories, not object literals. The
// factories preserve the literal `type: "noul"` discriminant and the criteria
// key set, which is what the SDK's `ResultFor<Q>` conditional type needs to
// infer a typed answer. Object literals widen `type` to `string` and the
// answer comes back as `any`/`never`.
import { noul } from "@typesafe-ai/sdk";

const client = new TypeSafeClient({
  // FIX #2: use the documented env var name. Read it explicitly so we can
  // throw a domain-specific error if it is missing (see Exercise 1).
  apiKey: process.env.TYPESAFE_API_KEY,
  // Leave baseURL unset; the SDK reads TYPESAFE_BASE_URL itself and falls
  // back to https://api.typesafe.ai. Passing `process.env.TYPESAFE_BASE_URL`
  // explicitly can defeat that fallback if the SDK treats explicit
  // `undefined` differently from an omitted field.
  // FIX #3: 30 s, expressed in ms.
  timeout: 30_000,
  // FIX #4: keep the SDK's default backoff schedule but choose a maxRetries
  // appropriate to the latency budget. For an interactive path, 1–2 is the
  // right range; 5 is for background batch work.
  retry: { maxRetries: 2 },
});

// FIX #5: state must be a string, object, array, or null. Reject undefined
// loudly so a missing STATE env var cannot silently send an empty payload.
export async function ask(question: string, state: unknown) {
  if (state === undefined || state === null || state === "") {
    throw new Error("ask(): state must be a non-empty string, object, or array");
  }

  const response = await client.systemOne({
    state: state as string | object | unknown[],
    questions: {
      // FIX #6: use the noul() factory so the SDK infers a typed answer.
      q: noul(question),
    },
  });
  return response.answers.q.noul;
}

// FIX #7 (swallow-everything catch): do not turn "the request failed" into
// "the model said no." Re-throw operational errors so the caller can decide
// between retrying, falling back, or alerting.
export async function askWithLog(question: string, state: unknown) {
  try {
    return await ask(question, state);
  } catch (err) {
    if (err instanceof TypeSafeError) {
      console.error("[jev] request failed:", err.constructor.name, err.message);
    }
    throw err;
  }
}

// FIX #8 (unbounded cache) + FIX #9 (cache key ignores state) + FIX #10
// (has/get race with undefined values): bound the cache, key on a digest of
// both question and state, and never store an undefined value.
//
// - Unbounded: a Map keyed on user input is a classic unbounded cache. Use a
//   bounded LRU (a small ring buffer suffices for hundreds of entries).
// - Key: the state is an input to the answer. Two calls with the same question
//   and different states have different answers; caching on the question alone
//   returns a stale answer for a different ticket.
// - Undefined: `Map.prototype.get` returns `T | undefined`. `has` returns true
//   for a key whose value is `undefined` (you can store undefined explicitly).
//   The fix is to never store undefined.
function keyOf(question: string, state: unknown): string {
  // A cheap, stable digest of the two inputs. A real implementation would use
  // a cryptographic hash; for the exercise, JSON.stringify is enough.
  return JSON.stringify({ question, state });
}

const CACHE_MAX = 256;
const cache = new Map<string, number>();

function lruSet(key: string, value: number) {
  if (cache.has(key)) cache.delete(key);
  cache.set(key, value);
  if (cache.size > CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
}

export async function askCached(question: string, state: unknown) {
  const key = keyOf(question, state);
  const hit = cache.get(key);
  if (hit !== undefined) return hit;

  const value = await askWithLog(question, state);
  // Guard against storing undefined; see FIX #10.
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error("askCached(): non-numeric answer from Jev");
  }
  lruSet(key, value);
  return value;
}

// FIX #11 (route in wrong location): a route handler belongs in
// app/api/<segment>/route.ts (App Router) or pages/api/<segment>.ts (Pages).
// A POST export from src/jev/client.ts is dead code — Next.js will never
// discover it. The corrected handler is shown below in the correct file.
