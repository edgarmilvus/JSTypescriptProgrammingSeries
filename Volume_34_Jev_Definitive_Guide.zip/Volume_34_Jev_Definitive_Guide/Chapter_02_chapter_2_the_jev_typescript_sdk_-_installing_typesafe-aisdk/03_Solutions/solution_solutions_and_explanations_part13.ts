/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/ask/route.ts  (the correct location for the handler)
//
// FIX #12 (no input validation): validate the body shape and length before
// touching the model, so a malformed request fails fast with a clean 400
// instead of an unhandled exception or a huge prompt.
import { NextResponse } from "next/server";
import { askCached } from "@/jev/client";

export async function POST(req: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  if (
    typeof body !== "object" ||
    body === null ||
    typeof (body as { question?: unknown }).question !== "string" ||
    typeof (body as { state?: unknown }).state !== "string" ||
    (body as { question: string }).question.length === 0 ||
    (body as { question: string }).question.length > 1024 ||
    (body as { state: string }).state.length > 32_768
  ) {
    return NextResponse.json(
      { error: "expected { question: string(1..1024), state: string(1..32768) }" },
      { status: 400 },
    );
  }

  const { question, state } = body as { question: string; state: string };

  try {
    const value = await askCached(question, state);
    return NextResponse.json({ value });
  } catch (err) {
    return NextResponse.json(
      { error: "upstream_error", detail: (err as Error).message },
      { status: 502 },
    );
  }
}
