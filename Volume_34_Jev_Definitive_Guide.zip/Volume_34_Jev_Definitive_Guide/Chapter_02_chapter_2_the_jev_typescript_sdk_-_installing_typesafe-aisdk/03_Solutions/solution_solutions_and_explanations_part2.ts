/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/server.ts
import {
  assertJevReachable,
  describeConfig,
  getClient,
  JevConfigError,
} from "./jev/client";

async function main(): Promise<void> {
  try {
    // Touch the client once so any config error surfaces before we probe the
    // network. This means a missing API key fails at boot with the console URL
    // in the message, not as a network error from the probe below.
    getClient();

    await assertJevReachable();

    // Non-secret snapshot, safe to log.
    console.log(
      JSON.stringify(
        { event: "jev_startup_ok", config: describeConfig() },
        null,
        2,
      ),
    );
  } catch (err) {
    if (err instanceof JevConfigError) {
      // A deployment mistake: fail loudly so the orchestrator rolls back.
      console.error("[jev] configuration error:", err.message);
      // Use process.exitCode, not process.exit(). The event loop drains,
      // stdout flushes, and any pending logs land before the process ends.
      process.exitCode = 1;
      return;
    }
    // Operational failure (network, 401, 5xx). Report and exit non-zero; the
    // deployment may be fine and the dependency may be having a bad minute.
    console.error("[jev] startup probe failed:", err);
    process.exitCode = 1;
  }
}

main();
