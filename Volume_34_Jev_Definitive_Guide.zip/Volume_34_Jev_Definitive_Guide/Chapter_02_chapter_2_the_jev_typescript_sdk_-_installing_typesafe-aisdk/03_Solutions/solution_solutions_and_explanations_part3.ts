/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/triage.ts
import {
  choice,
  noul,
  score,
  type ChoiceResponse,
  type NoulResponse,
  type ScoreResponse,
  type SystemOneResult,
  TypeSafeError,
  RateLimitError,
} from "@typesafe-ai/sdk";
import { getClient } from "./client";

// We do NOT annotate with `as const`. The `choice()` factory preserves the
// criteria's key set as a literal type via its generic parameter; the object
// literal already infers those keys as string literals. Wrapping the whole map
// in `as const` would over-narrow each question object (readonly tuples for
// score criteria) without improving answer inference, and would freeze a shape
// that the SDK is deliberately flexible about.
export const TriageQuestions = {
  department: choice("Which team should handle `ticket.message`?", {
    billing: "Payments, invoicing, refunds, subscriptions.",
    orders: "Order status, shipping, delivery, cancellations.",
    account: "Login, profile, permissions, security, credentials.",
  }),

  urgency: score("How urgent is the request in `ticket.message`?", [
    "Not time-sensitive: no deadline or escalation language.",
    "Time-sensitive: mentions a deadline, a delay, or an SLA.",
    "Critical: blocking the customer's business right now.",
  ]),

  // Framed so `true` means "the customer asked for money back." A Noul's
  // probability is P(true); the direction of the question determines which
  // side of 0.5 is the "act" side.
  requestsRefund: noul(
    "Does `ticket.message` explicitly ask for a refund or an account credit?",
    {
      true: "Directly requests money back or an account credit.",
      false: "Complains or asks about billing without requesting a remedy.",
    },
  ),

  // Guardrail-style question. Framed so `true` = "the customer is asking us
  // to reveal a credential," so a high probability means route to the
  // sensitive-detail queue.
  containsSensitiveRequest: noul(
    "Does `ticket.message` ask the recipient to disclose a credential such as " +
      "a password, API key, or security code?",
    {
      true: "Asks the recipient to send a credential.",
      false: "Does not ask anyone to disclose a credential.",
    },
  ),

  // Points at both the message and the structured orders list by backticked
  // dot-and-index path, so the model knows which fields to compare.
  mentionsOpenOrder: noul(
    "Does `ticket.message` refer to one of the orders listed under " +
      "`customer.open_orders`?",
    {
      true: "Matches an open order by id or by identifying details.",
      false: "Refers to no supplied open order.",
    },
  ),
};

/** Inferred answer key set — callers cannot drift from the questions. */
export type TriageAnswers = SystemOneResult<typeof TriageQuestions>["answers"];

// ---- Domain types ------------------------------------------------------

export interface TriageInput {
  /** The full support message to triage. */
  message: string;
  /** Orders the customer currently has open, passed into the model's state. */
  openOrders: ReadonlyArray<{ id: string; status: string }>;
  /** Optional per-call timeout in milliseconds. */
  budgetMs?: number;
}

export type Department = "billing" | "orders" | "account";

export interface TriageDecision {
  /** The winning option, validated against our union at runtime. */
  department: Department;
  /** Fractional score across the rubric. Rounded by the caller if needed. */
  urgency: number;
  flags: {
    refundRequested: boolean;
    sensitiveRequest: boolean;
    mentionsOpenOrder: boolean;
  };
  /**
   * The untouched SDK result, kept so downstream logging and offline
   * evaluation can see exactly what the model returned — probabilities,
   * confidence, usage — without this module committing to a logging schema.
   */
  raw: SystemOneResult<typeof TriageQuestions>;
}

/**
 * Domain-specific failure. Callers catch this without importing anything from
 * @typesafe-ai/sdk.
 */
export class TriageError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "TriageError";
  }
}

// ---- Translation helpers ----------------------------------------------
//
// Every helper below is a *total, faithful* function from an SDK answer to a
// domain value. It does not consult confidence, does not gate, and does not
// route — those decisions live in the caller (or in a separate `route()`
// function). This keeps each helper unit-testable in isolation and prevents
// the translation layer from silently becoming a second decision layer.

const KNOWN_DEPARTMENTS = ["billing", "orders", "account"] as const;
type DepartmentCriteria = {
  billing: string;
  orders: string;
  account: string;
};

function toDepartment(answer: ChoiceResponse<DepartmentCriteria>): Department {
  const c = answer.choice;
  // The SDK types `choice` as `keyof T & string`. If the criteria object ever
  // loses its literal keying, this runtime guard catches a value that is not
  // one of ours before it reaches business logic.
  if (!(KNOWN_DEPARTMENTS as readonly string[]).includes(c)) {
    throw new TriageError(`Unknown department from model: ${String(c)}`);
  }
  return c as Department;
}

function toUrgency(answer: ScoreResponse<readonly string[]>): number {
  // We keep the fractional score. Rounding to a level throws away the
  // calibrated uncertainty the SDK goes out of its way to provide; the
  // fractional value is the honest representation, and the caller can round
  // if it needs a single level.
  return answer.score;
}

/**
 * Single exported threshold, reviewable in one place. Tune against labeled
 * examples; 0.7 is a conservative default for guardrail questions.
 */
export const NOUL_THRESHOLD = 0.7;

function toFlag(answer: NoulResponse): boolean {
  // `NoulResponse` has no `confidence` field by design: the probability IS the
  // confidence. Do not read one; there isn't one to read.
  return answer.noul >= NOUL_THRESHOLD;
}

// ---- The decision engine -----------------------------------------------

export async function triage(input: TriageInput): Promise<TriageDecision> {
  // Structured state, not a string. Named keys let the questions point at
  // exactly the field they need via backticked paths; a flattened string would
  // force the model to discover which part of the text is which, and the SDK's
  // jaggedness docs are explicit that a large state full of irrelevant detail
  // degrades accuracy.
  const state = {
    ticket: { message: input.message },
    customer: {
      open_orders: input.openOrders.map((o) => ({ id: o.id, status: o.status })),
    },
  };

  const client = getClient();

  // Per-call overrides exist so one decision path can tighten its own latency
  // without reconfiguring the shared client. Mutating `client.timeout` would
  // leak the budget into every other concurrent caller.
  const options =
    input.budgetMs !== undefined ? { timeout: input.budgetMs } : undefined;

  try {
    const response = await client.systemOne(
      { state, questions: TriageQuestions },
      options,
    );

    const answers = response.answers;

    return {
      department: toDepartment(answers.department),
      urgency: toUrgency(answers.urgency),
      flags: {
        refundRequested: toFlag(answers.requestsRefund),
        sensitiveRequest: toFlag(answers.containsSensitiveRequest),
        mentionsOpenOrder: toFlag(answers.mentionsOpenOrder),
      },
      raw: response,
    };
  } catch (err) {
    if (err instanceof TypeSafeError) {
      // Preserving the cause matters most when the underlying error is a
      // RateLimitError: its `retryAfterMs` is only available on the original
      // object, and callers that want to honor the server's suggestion need
      // to reach it via `err.cause`.
      throw new TriageError("Jev triage call failed", { cause: err });
    }
    // A non-SDK error (a bug in our translation helper, a TypeError) is not
    // ours to swallow: rethrow unchanged so it surfaces with its real stack.
    throw err;
  }
}

// A convenience re-export so callers that need to inspect the retry-after
// header do not have to know the SDK's module path.
export { RateLimitError };
