/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/triage/route.ts
//
// RUNTIME CHOICE: Node.js (the default). Justification: the only today-relevant
// node-only dependency is our `server/getTicket.ts` mock, which we expect to
// replace with a database client (pg, mysql2, @planetscale/database) that
// requires Node APIs. The route body itself is runtime-agnostic — @typesafe-ai/
// sdk's default fetch runs on both — so revisiting this decision is a one-line
// change if the data layer ever becomes Edge-compatible.
//
// Do NOT import `@typesafe-ai/sdk` in this file. The route's job is transport.
// If you find yourself wanting SystemOneResult here, your TriageDecision type
// from Exercise 2 is under-specified and should be extended instead.

import { getTicket } from "@/server/getTicket";
import { triage, TriageError } from "@/jev/triage";
import { JevConfigError } from "@/jev/client";
import { RateLimitError } from "@typesafe-ai/sdk";

interface TriageRequestBody {
  ticketId: string;
}

export async function POST(req: Request): Promise<Response> {
  // ---- Input validation -------------------------------------------------
  // Never trust the body. A raw `await req.json()` throws on an empty body and
  // buffers the entire payload in memory for a large one. Validate the shape
  // and reject early; the framework's body-size limit is a second line of
  // defense, but the shape check is ours.
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return Response.json({ error: "invalid_json" }, { status: 400 });
  }

  if (
    typeof raw !== "object" ||
    raw === null ||
    typeof (raw as { ticketId?: unknown }).ticketId !== "string" ||
    (raw as TriageRequestBody).ticketId.length === 0 ||
    (raw as TriageRequestBody).ticketId.length > 128
  ) {
    return Response.json(
      { error: "ticketId (string, 1..128 chars) required" },
      { status: 400 },
    );
  }

  const { ticketId } = raw as TriageRequestBody;

  try {
    // Deterministic mock: same id -> same text, so a UI refresh does not
    // produce a different decision from the same ticket.
    const ticket = await getTicket(ticketId);

    const decision = await triage({
      message: ticket.message,
      openOrders: ticket.openOrders,
    });

    // Return only the domain decision. `raw` is included deliberately; strip
    // it here if you would rather not ship the model's full answer to the
    // browser.
    return Response.json(decision, { status: 200 });
  } catch (err) {
    if (err instanceof JevConfigError) {
      // Deployment mistake. 500 because it is our fault and no retry helps.
      return Response.json({ error: "configuration_error" }, { status: 500 });
    }
    if (
      err instanceof TriageError &&
      (err.cause as unknown) instanceof RateLimitError
    ) {
      const cause = err.cause as RateLimitError;
      return Response.json(
        { error: "rate_limited", retryAfterMs: cause.retryAfterMs ?? null },
        { status: 429 },
      );
    }
    // Unknown failure: report honestly and let the client retry.
    return Response.json({ error: "upstream_error" }, { status: 502 });
  }
}
