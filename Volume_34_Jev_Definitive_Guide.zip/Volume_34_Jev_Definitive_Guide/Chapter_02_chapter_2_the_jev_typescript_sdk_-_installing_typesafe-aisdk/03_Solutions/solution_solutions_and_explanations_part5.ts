/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// server/getTicket.ts
//
// Deterministic mocked ticket store. The badge fetches a decision for a given
// ticketId; if the underlying ticket text changed between fetch and render, the
// badge would describe a different ticket than the one on screen.
//
// Jev's answers are stable across repeats. Your *inputs* must be stable too.
// This mock guarantees that for a fixed id, the same ticket is returned on
// every call, in every process, forever. Replace it with a real data layer
// when you have one, but keep the contract.

export interface Ticket {
  id: string;
  subject: string;
  message: string;
  openOrders: ReadonlyArray<{ id: string; status: string }>;
}

const TICKETS: Record<string, Omit<Ticket, "id">> = {
  "T-1001": {
    subject: "Charged twice for order A-104",
    message:
      "I was charged twice for order A-104. Please refund the duplicate. " +
      "I've been a customer for years and this is the second time this has happened.",
    openOrders: [{ id: "A-104", status: "processing" }],
  },
  "T-1002": {
    subject: "Cannot log in after password reset",
    message:
      "I reset my password this morning and now I can't sign in. The reset link " +
      "worked but the new password is rejected. Please help — I have a deadline today.",
    openOrders: [{ id: "B-217", status: "shipped" }],
  },
};

export async function getTicket(ticketId: string): Promise<Ticket> {
  const entry = TICKETS[ticketId];
  if (!entry) {
    throw Object.assign(new Error(`no such ticket: ${ticketId}`), {
      status: 404,
    });
  }
  // Return a fresh copy so callers cannot mutate the source of truth.
  return { id: ticketId, ...entry, openOrders: [...entry.openOrders] };
}
