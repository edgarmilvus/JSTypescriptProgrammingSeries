/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// components/TriageBadge.tsx
"use client";

import { useEffect, useState } from "react";

// Local mirror of the server's TriageDecision. Keeping this duplicated on the
// client side (rather than importing from the server module) preserves the
// client/server boundary: the server module imports @typesafe-ai/sdk, and the
// SDK must never appear in a client bundle.
interface TriageDecision {
  department: "billing" | "orders" | "account";
  urgency: number;
  flags: {
    refundRequested: boolean;
    sensitiveRequest: boolean;
    mentionsOpenOrder: boolean;
  };
  raw: unknown;
}

type Status =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; decision: TriageDecision };

const DEPT_COLOR: Record<TriageDecision["department"], string> = {
  billing: "#dbeafe",
  orders: "#dcfce7",
  account: "#fef3c7",
};

export function TriageBadge({
  ticketId,
  refreshKey = 0,
}: {
  ticketId: string;
  refreshKey?: number;
}) {
  const [status, setStatus] = useState<Status>({ kind: "loading" });

  useEffect(() => {
    // The effect's dependency array is [ticketId, refreshKey]. React compares
    // dependency *values*, not the parent's render identity, so a parent
    // re-render with the same `ticketId` and `refreshKey` does NOT re-fire
    // this effect. This is exactly the guarantee we want: a badge should
    // re-fetch when the ticket changes, or when the caller explicitly asks
    // for a refresh.
    let cancelled = false;
    const controller = new AbortController();

    setStatus({ kind: "loading" });

    (async () => {
      try {
        const res = await fetch("/api/triage", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ticketId }),
          signal: controller.signal,
        });

        if (!res.ok) {
          if (!cancelled) setStatus({ kind: "error", message: `HTTP ${res.status}` });
          return;
        }
        const decision = (await res.json()) as TriageDecision;
        if (!cancelled) setStatus({ kind: "ready", decision });
      } catch (err) {
        // Aborts are expected on unmount or rapid ticket changes.
        if ((err as { name?: string }).name === "AbortError") return;
        if (!cancelled) setStatus({ kind: "error", message: "network error" });
      }
    })();

    return () => {
      // Cleanup: mark this run stale and abort the in-flight request, so we
      // never call setState on an unmounted component.
      cancelled = true;
      controller.abort();
    };
    // `refreshKey` is a crude but effective cache-busting signal: changing it
    // forces a fresh fetch even though `ticketId` is unchanged. A finer-grained
    // alternative is a server-computed `ticketVersion` hash included in the
    // dependency array — this badge should show advice for the ticket as it
    // stood when the decision was made, and a hash makes that explicit.
  }, [ticketId, refreshKey]);

  if (status.kind === "loading") {
    return <span style={{ opacity: 0.4 }}>triaging…</span>;
  }
  if (status.kind === "error") {
    return <span style={{ color: "#b91c1c" }}>triage unavailable</span>;
  }

  const { decision } = status;

  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      <span
        style={{
          background: DEPT_COLOR[decision.department],
          padding: "1px 6px",
          borderRadius: 10,
          fontSize: 12,
        }}
      >
        {decision.department}
      </span>
      <span title="urgency">{decision.urgency.toFixed(1)}</span>
      {decision.flags.sensitiveRequest && <span title="sensitive request">🔒</span>}
      {decision.flags.refundRequested && <span title="refund requested">↩</span>}
      {decision.flags.mentionsOpenOrder && <span title="mentions open order">📦</span>}

      {/* Raw model output behind a disclosure. Two reasons this matters:
          - Debugging disagreement: an agent who thinks the badge is wrong can
            see the probability distribution and confidence the model returned.
          - Security: `raw` may echo ticket text (because the model's state
            included it). Treat everything inside as untrusted user content —
            render as text, never as HTML or clickable links. */}
      <details style={{ fontSize: 11 }}>
        <summary>raw</summary>
        <pre style={{ whiteSpace: "pre-wrap", maxWidth: 480 }}>
          {JSON.stringify(decision.raw, null, 2)}
        </pre>
      </details>
    </span>
  );
}
