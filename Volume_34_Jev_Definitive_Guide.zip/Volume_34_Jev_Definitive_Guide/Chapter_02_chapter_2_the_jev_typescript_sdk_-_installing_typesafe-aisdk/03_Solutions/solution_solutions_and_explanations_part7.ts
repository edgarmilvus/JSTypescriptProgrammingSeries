/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

<!-- README.md in the feature directory -->

# TriageBadge

A small inline badge showing Jev's triage recommendation for a support ticket.

## (a) Why does this call happen on the server?

The TypeSafe API key must never reach the browser. The SDK is explicit that
`dangerouslyAllowBrowser: true` "exposes the API key to page users," which is
unacceptable for anything but single-user demos. The badge therefore calls a
Next.js route handler at `/api/triage`, which loads the ticket server-side,
calls the decision engine (which holds the SDK client), and returns only a
domain `TriageDecision` to the client. The client bundle contains no reference
to `@typesafe-ai/sdk`, no API key, and no knowledge of the SDK's request shape.

## (b) What happens if Jev is down?

The route returns a 5xx and the badge renders "triage unavailable." The console
stays usable; the agent sees a plain ticket with no badge. This is intentional —
the badge is an aid, not a gate. If you later want a "try again" affordance, add
it to the error state; do not silently fall back to a heuristic, because a wrong
badge is worse than no badge.

## (c) What happens if an agent disagrees with the badge?

The badge exposes a `<details>` disclosure containing the raw SDK result —
probabilities, confidence, usage. The agent can inspect what the model returned
and compare it against the ticket. This turns a disagreement into a reviewable
artifact rather than a complaint. The raw output is untrusted; render it as
text, never as HTML or links.

## (d) Recompute with a different question set

The question set lives in `src/jev/triage.ts` as `TriageQuestions`. A
"recompute" button that swaps questions would require a *server-side* variant
of the route that accepts a named question set. Do not accept raw question
definitions from the client: that would let any user prompt the model on any
input and bill your account. The right shape is (1) register named question
sets on the server, (2) let the client send an enum like
`{ questionSet: "default" | "strict" }`, (3) resolve the enum server-side.
