/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/client.ts (additions)
import { TypeSafeClient, type RetryPolicy } from "@typesafe-ai/sdk";

export interface LatencyBudget {
  /** Total wall-clock budget for the decision path, in milliseconds. */
  totalMs: number;
}

export interface FastClientOverrides {
  timeout: number;
  retry: Partial<RetryPolicy>;
}

/**
 * Derive SDK overrides from a latency budget.
 *
 * Arithmetic for a 200 ms budget:
 *   - timeout       = floor(0.8 * 200) = 160 ms. The 20% headroom covers
 *                     transport overhead, JSON parsing, and our own
 *                     serialization, so we do not burn the entire budget on
 *                     the HTTP call and then overrun anyway.
 *   - slack         = 200 - 160 = 40 ms available for a single retry.
 *   - A single retry must fit inside that slack. With backoffInitialMs = 20
 *     and backoffJitter = 0.25 the expected sleep is 15–20 ms, which fits.
 *   - maxRetries = 1 is the only safe value.
 *
 * For a 150 ms budget or less: disable retries entirely. There is no room for a
 * second round trip, and a retry that cannot complete inside the budget is
 * worse than a clean failure that lets the caller fall back immediately.
 *
 * The SDK's documented default timeout is 10,000 ms; we are *lowering*, not
 * raising it.
 */
export function deriveOverrides(budget: LatencyBudget): FastClientOverrides {
  const { totalMs } = budget;
  const timeout = Math.max(50, Math.floor(totalMs * 0.8));

  if (totalMs < 150) {
    return {
      timeout,
      retry: { maxRetries: 0, respectRetryAfter: false },
    };
  }

  const slack = totalMs - timeout;
  const backoffInitialMs = Math.max(20, Math.floor(slack / 3));
  const maxRetries = slack >= 2 * backoffInitialMs ? 1 : 0;

  return {
    timeout,
    retry: {
      maxRetries,
      backoffInitialMs,
      backoffMaxMs: backoffInitialMs * 2,
      backoffJitter: 0.25,
      // Honor the server's Retry-After, but only up to the slack that remains.
      // If the server asks for more than the budget can wait, the SDK falls
      // back to its own (short) exponential schedule; for a tight budget that
      // is also bounded, so no path blows the budget.
      respectRetryAfter: true,
      maxRetryAfterMs: Math.max(0, slack),
    },
  };
}

/**
 * A SECOND client, tuned for the low-latency triage path.
 *
 * WHY A SECOND CLIENT, NOT A PER-CALL OVERRIDE.
 * A per-call timeout is straightforward — pass it in RequestOptions. But a
 * per-call *retry policy* is not: the SDK shares retry state inside the client,
 * and the backoff schedule is computed per request. Building a second client
 * with these settings frozen in gives the fast path its own retry timeline and
 * its own connection pool, while the default client keeps the SDK's defaults
 * for background and batch work. Per-call overrides would have to be threaded
 * through every call site, scattering the latency policy across the codebase.
 *
 * THE TRADE-OFF.
 * (1) Connection reuse: two clients means two HTTP/2 sessions. On a TLS-
 *     terminated endpoint this costs one extra handshake at boot and about one
 *     socket's worth of memory per client — negligible next to the model
 *     latency the fast client protects.
 * (2) Memory: an extra client is a small heap cost, mostly closures. Trivially
 *     small.
 * (3) Clarity: two clients mean "what is our retry behavior on the fast path?"
 *     is answered by reading one file. A per-call approach makes it a grep.
 */
export function getFastClient(budget: LatencyBudget): TypeSafeClient {
  const apiKey = requireEnv("TYPESAFE_API_KEY");
  const overrides = deriveOverrides(budget);
  return new TypeSafeClient({
    apiKey,
    timeout: overrides.timeout,
    retry: overrides.retry,
  });
}
