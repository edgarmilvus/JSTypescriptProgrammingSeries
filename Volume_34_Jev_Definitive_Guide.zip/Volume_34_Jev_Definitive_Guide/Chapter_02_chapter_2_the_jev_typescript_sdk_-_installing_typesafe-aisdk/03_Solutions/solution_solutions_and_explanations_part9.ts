/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// src/jev/decide.ts
import { RateLimitError, TypeSafeError } from "@typesafe-ai/sdk";
import { JevConfigError } from "./client";
import {
  triage,
  TriageError,
  type TriageDecision,
  type TriageInput,
} from "./triage";

export type Decision = TriageDecision;
export type DecisionInput = TriageInput;

export interface DecisionEvent {
  outcome: "jev" | "fallback" | "degraded";
  jevMs: number;
  fallbackRan: boolean;
  retryAfterMs?: number | null;
  errorClass?: string;
}

/**
 * Injected so the decision module carries no infrastructure dependency. You
 * can pass a Prometheus-like timer, a Datadog client, a plain array of events
 * for tests, or a no-op. Swapping sinks never touches business logic.
 */
export type MetricsSink = (event: DecisionEvent) => void;

/**
 * Deterministic, total, documented fallback. Allowed to be WORSE than the
 * model. Not allowed to be nondeterministic, and not allowed to throw on
 * well-formed input.
 */
export function keywordFallback(input: DecisionInput): Decision {
  const text = input.message.toLowerCase();

  let department: Decision["department"] = "account";
  if (/(refund|charge|invoice|billing|subscription)/.test(text)) {
    department = "billing";
  } else if (/(order|ship|deliver|track|return)/.test(text)) {
    department = "orders";
  }

  // 0..2 to match the rubric range. One urgency keyword is "time-sensitive";
  // an additional escalation cue is "critical."
  let urgency = 0;
  if (/(asap|urgent|today|deadline|immediately)/.test(text)) urgency = 1;
  if (/(still|again|third time|unacceptable)/.test(text)) {
    urgency = Math.min(2, urgency + 1);
  }

  const hasOrderRef = input.openOrders.some((o) =>
    text.includes(o.id.toLowerCase()),
  );

  return {
    department,
    urgency,
    flags: {
      refundRequested: /(refund|credit)/.test(text),
      // Conservative: any credential-ish word marks it sensitive. Better to
      // over-flag on the fallback than to under-flag; the human decides.
      sensitiveRequest:
        /(password|api key|credential|security code|2fa|otp)/.test(text),
      mentionsOpenOrder: hasOrderRef,
    },
    // The fallback did not call the model, so there is no real raw result.
    // We synthesize a shape-compatible empty object and rely on consumers
    // treating `raw` as optional metadata whenever `source !== "jev"`.
    raw: {
      model: "fallback",
      answers: {},
      usage: { input_tokens: 0, output_tokens: 0 },
    } as TriageDecision["raw"],
  };
}

/**
 * The canned "degraded" decision. Honest, not clever: route to a human. The
 * correct answer for "the machine could not decide" is exactly the situation
 * a human reviewer exists for — do not fabricate a specific department.
 */
function degradedDecision(): Decision {
  return {
    department: "account", // a placeholder; the caller must gate on `source`
    urgency: 2,
    flags: {
      refundRequested: false,
      sensitiveRequest: false,
      mentionsOpenOrder: false,
    },
    raw: {
      model: "degraded",
      answers: {},
      usage: { input_tokens: 0, output_tokens: 0 },
    } as TriageDecision["raw"],
  };
}

export async function decideWithFallback(
  input: DecisionInput,
  fallback: (input: DecisionInput) => Decision,
  record: MetricsSink,
): Promise<{ decision: Decision; source: "jev" | "fallback" | "degraded" }> {
  const started = Date.now();
  let jevMs = 0;
  let errorClass: string | undefined;
  let retryAfterMs: number | null | undefined;

  try {
    const decision = await triage(input);
    jevMs = Date.now() - started;
    record({ outcome: "jev", jevMs, fallbackRan: false });
    return { decision, source: "jev" };
  } catch (err) {
    jevMs = Date.now() - started;

    // Never let a fallback mask a bug a human needs to fix. A config error
    // means the deployment is broken; falling back would hide it for weeks
    // (metrics would show "fallback rate: 100%, since deploy #1847").
    if (err instanceof JevConfigError) {
      record({
        outcome: "degraded",
        jevMs,
        fallbackRan: false,
        errorClass: "JevConfigError",
      });
      throw err;
    }

    // Classify the operational failure for the metrics sink.
    if (err instanceof TriageError) {
      const cause = err.cause;
      errorClass = cause?.constructor.name ?? "unknown";
      if (cause instanceof RateLimitError) {
        retryAfterMs = cause.retryAfterMs ?? null;
      }
    } else if (err instanceof TypeSafeError) {
      errorClass = err.constructor.name;
    } else {
      errorClass = "unknown";
    }

    try {
      const decision = fallback(input);
      record({
        outcome: "fallback",
        jevMs,
        fallbackRan: true,
        errorClass,
        retryAfterMs,
      });
      return { decision, source: "fallback" };
    } catch {
      // The fallback itself failed (a bug in the heuristic, a weird input).
      // Return the honest canned answer: route to a human.
      record({
        outcome: "degraded",
        jevMs,
        fallbackRan: true,
        errorClass,
        retryAfterMs,
      });
      return { decision: degradedDecision(), source: "degraded" };
    }
  }
}
