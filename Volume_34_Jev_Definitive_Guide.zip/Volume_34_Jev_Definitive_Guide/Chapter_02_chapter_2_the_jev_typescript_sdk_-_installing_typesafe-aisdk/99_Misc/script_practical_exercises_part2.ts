/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// src/jev/client.ts

// (1) import
import { TypeSafeClient } from "typesafe-sdk";

// (2) client construction
const client = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_KEY,
  baseURL: process.env.TYPESAFE_URL,
  timeout: 30,
  retry: { maxRetries: 5 },
});

// (3) a helper that "just runs a question"
export async function ask(question: string) {
  const response = await client.systemOne({
    state: process.env.STATE,
    questions: {
      q: { type: "noul", instructions: question },
    },
  });
  // (4) return
  return response.answers.q.noul;
}

// (5) a wrapper that logs every call
export async function askWithLog(question: string) {
  try {
    return await ask(question);
  } catch (e: any) {
    console.error("jev failed", e.message);
    return 0;
  }
}

// (6) a "warm cache" the developer added to speed up repeated calls
const cache = new Map<string, number>();
export async function askCached(question: string) {
  if (cache.has(question)) return cache.get(question);
  const value = await askWithLog(question);
  cache.set(question, value);
  return value;
}

// (7) a route handler
export async function POST(req: Request) {
  const { question } = await req.json();
  const value = await askCached(question);
  return Response.json({ value });
}
