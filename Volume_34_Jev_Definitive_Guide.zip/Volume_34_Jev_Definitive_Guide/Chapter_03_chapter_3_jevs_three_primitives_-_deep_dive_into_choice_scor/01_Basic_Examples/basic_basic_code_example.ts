/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// lib/jev/triage.ts
import {
  choice,
  noul,
  score,
  TypeSafeClient,
  type ChoiceResponse,
  type NoulResponse,
  type ScoreResponse,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

/**
 * Local aliases so the rest of the codebase reads in the vocabulary of the
 * three primitives rather than the SDK's Response naming. `ChoiceResponse`
 * and friends are the authoritative types; the aliases just rename them.
 */
export type ChoiceAnswer<T extends Record<string, unknown>> = ChoiceResponse<T>;
export type ScoreAnswer = ScoreResponse<readonly string[]>;
export type NoulAnswer = NoulResponse;

/**
 * The SDK reads `TYPESAFE_API_KEY` from the environment by default, but
 * passing it explicitly makes the wiring visible and lets you swap the key
 * per environment (dev, staging, prod) without touching process state.
 */
const client = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY!,
});

/**
 * The questions are declared once, as a plain object. The keys of this object
 * become the keys of `response.answers`, and the values' shapes are inferred
 * by the SDK, so `answers.department.choice` is typed as the union of the
 * option names below.
 */
export const TRIAGE_QUESTIONS = {
  // Choice: pick one option from a fixed set. Returns a `choice` string,
  // a full `probabilities` map, and a `confidence` number from 0 to 1.
  department: choice("Which team should handle this ticket?", {
    billing: "Payment, invoicing, refunds, or subscription issues.",
    technical: "Bugs, outages, integrations, or API errors.",
    sales: "Pricing, plan upgrades, or new account questions.",
  }),

  // Score: rate the state along an ordered rubric. Returns a `score`
  // (which can land between levels), a `legend`, a `probabilities` map,
  // and a `confidence` number from 0 to 1.
  frustration: score("How frustrated does the customer appear?", [
    "Calm; stating facts without complaint.",
    "Frustrated but civil; expresses annoyance.",
    "Very angry; strong language or threatens to leave.",
  ] as const),

  // Noul: yes/no judgment. Returns a single `noul` number from 0 to 1,
  // the probability that the answer is yes. No `confidence` field.
  refund_requested: noul("Does the customer request a refund?", {
    true: "The customer explicitly asks for money back.",
    false: "No refund is requested.",
  }),
};

/**
 * The full typed result. `SystemOneResult<typeof TRIAGE_QUESTIONS>` infers
 * the answer type for each question key and threads it through.
 */
export type TriageResult = SystemOneResult<typeof TRIAGE_QUESTIONS>;

/**
 * One API call. State is a plain object with a single `message` field here,
 * but the shape is whatever the three questions need context from.
 */
export async function triageTicket(message: string): Promise<TriageResult> {
  return client.systemOne({
    state: { message },
    questions: TRIAGE_QUESTIONS,
  });
}
