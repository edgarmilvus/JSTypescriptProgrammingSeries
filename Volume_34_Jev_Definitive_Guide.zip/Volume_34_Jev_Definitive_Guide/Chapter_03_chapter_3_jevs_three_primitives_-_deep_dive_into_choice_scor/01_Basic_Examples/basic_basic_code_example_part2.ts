/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/api/triage/route.ts
import { NextResponse } from "next/server";
import { triageTicket } from "@/lib/jev/triage";

/**
 * A thin route handler. Everything AI-shaped happened in one call; the rest
 * is ordinary `if` statements that a code reviewer can read in ten seconds.
 */
export async function POST(request: Request) {
  const { message } = await request.json();

  // One request. All three questions run in parallel against the same state.
  const response = await triageTicket(message);

  const { department, frustration, refund_requested } = response.answers;

  // Confidence gate. Low confidence on the classification routes the ticket
  // to a human instead of guessing a department.
  const owned = department.confidence < 0.5;
  const route = owned ? "human_review" : department.choice;

  // Noul answers are probabilities. Threshold them yourself when the code
  // needs a hard decision.
  const wantsRefund = refund_requested.noul > 0.7;

  // Score answers are positions on the rubric. Compare against thresholds
  // that fit your domain; the score can be fractional.
  const needsPriority = frustration.score > 1.5;

  return NextResponse.json({
    route,
    department: department.choice,
    departmentConfidence: department.confidence,
    frustrationScore: frustration.score,
    needsPriority,
    wantsRefund,
    // Free-form fields are kept for logging and dashboards.
    probabilities: department.probabilities,
    model: response.model,
    usage: response.usage,
  });
}
