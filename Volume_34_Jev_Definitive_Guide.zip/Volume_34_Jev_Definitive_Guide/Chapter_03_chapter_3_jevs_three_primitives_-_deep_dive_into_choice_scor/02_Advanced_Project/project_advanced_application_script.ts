/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/tickets/triage/route.ts
 *
 * LedgerLite support triage. ONE Jev request turns a raw ticket into a typed
 * routing decision: a Choice picks the owning team, two Scores rate the utility
 * dimensions, and two Nouls stand guard over the whole flow.
 *
 * The model supplies calibrated judgments. This file supplies the policy:
 * every threshold, every weight, and every branch lives in code.
 *
 * @see https://docs.typesafe.ai/primitives
 */

import { NextResponse } from "next/server";
import {
  RateLimitError,
  TypeSafeClient,
  choice,
  noul,
  score,
  type SystemOneResult,
  type ScoreResponse,
} from "@typesafe-ai/sdk";

/* ───────────────────────────── Domain types ───────────────────────────── */

export type Ticket = {
  id: string;
  subject: string;
  body: string;
  plan: "free" | "pro" | "enterprise";
  priorTickets: number;
  status: "open" | "pending" | "closed";
};

export type Team = "billing" | "technical" | "account";

export type Decision =
  | { action: "route"; team: Team; priority: "high" | "normal" }
  | {
      action: "quarantine" | "escalate_risk" | "human_review" | "no_action";
      reason: string;
    };

/* ─────────── 1. POLICY — every question and threshold, one place ──────── */

const TRIAGE_QUESTIONS = {
  /** CHOICE — one option out of a closed set; returns the full distribution. */
  topic: choice("Which team should handle `ticket.message`?", {
    billing: {
      what: "Charges, invoices, refunds, plan changes, failed payments",
      not_for: "Login problems or product bugs",
      examples: ["I was charged twice", "Where is my refund?"],
    },
    technical: {
      what: "Bugs, outages, integrations, API errors",
      not_for: "Billing questions or account access",
      examples: ["The webhook keeps returning 500"],
    },
    account: {
      what: "Login, profile, permissions, security settings",
      not_for: "Charges or product bugs",
      examples: ["I cannot sign in", "Reset my password"],
    },
  }),

  /** NOUL — P(true), framed so a HIGH value means "stop and look". */
  requestsCredentials: noul(
    "Does `ticket.message` ask the recipient to disclose a password, a one-time code, or an API key?",
    {
      true: "It asks for the credential itself",
      false: "It does not, or it tells the reader to reset one",
    },
  ),
  mentionsChargeback: noul(
    "Does `ticket.message` say the customer has disputed, or will dispute, the charge with their bank?",
  ),

  /** SCORE — a position on an ordered rubric; may land between two levels. */
  frustration: score("How frustrated does the customer appear in `ticket.message`?", [
    "Calm and matter-of-fact",
    "Frustrated but civil",
    "Very angry, or threatening to leave",
  ] as const),
  impact: score("How much of the customer's work does this block?", [
    "No impact — a question or a preference",
    "Degraded — a workaround exists",
    "Blocked — a core feature is unusable",
    "Revenue impact — the customer is losing money now",
  ] as const),
} as const;

/** Every tunable number in the system. Change a policy here, nowhere else. */
const POLICY = {
  credentialVeto: 0.85, // Noul  → hard stop
  chargebackVeto: 0.75, // Noul  → hard stop
  topicConfidenceFloor: 0.75, // Choice confidence → human review
  weights: { impact: 0.55, frustration: 0.3, chargeback: 0.15 },
} as const;

const HIGH_PRIORITY = 0.6;
const jev = new TypeSafeClient(); // reads TYPESAFE_API_KEY, defaults to jev-latest

/* ───────── 2. Deterministic pre-filter — no model call needed ─────────── */

function preflight(t: Ticket): Decision | null {
  if (t.status === "closed")
    return { action: "no_action", reason: "ticket already closed" };
  if (t.body.trim().length < 8)
    return { action: "human_review", reason: "body too short to judge" };
  return null;
}

/* ───────── 3. ONE request; every question evaluated in parallel ───────── */

type TriageAnswers = SystemOneResult<typeof TRIAGE_QUESTIONS>["answers"];

async function askJev(t: Ticket): Promise<TriageAnswers> {
  const { answers } = await jev.systemOne({
    state: {
      ticket: {
        message: t.body,
        subject: t.subject,
        plan: t.plan,
        priorTickets: t.priorTickets,
      },
      policy: { sensitiveCredentials: ["password", "one-time code", "API key"] },
    },
    questions: TRIAGE_QUESTIONS,
  });
  return answers;
}

/* ───────── 4. Compose the answers in code — the real decision ────────── */

/** A Score is a position on the rubric. Normalize every dimension to 0–1. */
const normalize = (s: ScoreResponse<readonly string[]>): number =>
  s.score / Math.max(Object.keys(s.legend).length - 1, 1);

function compose(a: TriageAnswers): Decision {
  // 4a. Vetoes first — a guardrail outranks every downstream preference.
  if (a.requestsCredentials.noul >= POLICY.credentialVeto)
    return {
      action: "quarantine",
      reason: `credential request p=${a.requestsCredentials.noul.toFixed(2)}`,
    };
  if (a.mentionsChargeback.noul >= POLICY.chargebackVeto)
    return {
      action: "escalate_risk",
      reason: `chargeback p=${a.mentionsChargeback.noul.toFixed(2)}`,
    };

  // 4b. Uncertainty gate on the router itself: never act on a coin flip.
  if (a.topic.confidence < POLICY.topicConfidenceFloor)
    return {
      action: "human_review",
      reason: `topic unclear, confidence ${a.topic.confidence.toFixed(2)}`,
    };

  // 4c. Composite utility: independent dimensions, weighted by us.
  const priority =
    POLICY.weights.impact * normalize(a.impact) +
    POLICY.weights.frustration * normalize(a.frustration) +
    POLICY.weights.chargeback * a.mentionsChargeback.noul;

  return {
    action: "route",
    team: a.topic.choice as Team,
    priority: priority >= HIGH_PRIORITY ? "high" : "normal",
  };
}

/* ─────────────────────── 5. Next.js Route Handler ─────────────────────── */

export async function POST(req: Request): Promise<NextResponse<Decision>> {
  const ticket = (await req.json()) as Ticket;

  const pre = preflight(ticket);
  if (pre) return NextResponse.json(pre);

  try {
    return NextResponse.json(compose(await askJev(ticket)));
  } catch (err) {
    // 429 / 529 after the SDK's own retries — never guess. Send it to a human.
    const reason = err instanceof RateLimitError ? "rate limited" : "upstream unavailable";
    return NextResponse.json({ action: "human_review", reason }, { status: 202 });
  }
}
