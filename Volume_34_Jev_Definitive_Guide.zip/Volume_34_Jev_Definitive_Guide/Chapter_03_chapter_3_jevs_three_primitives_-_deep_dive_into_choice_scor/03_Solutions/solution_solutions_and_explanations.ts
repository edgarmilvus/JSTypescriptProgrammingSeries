/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/router/intentRouter.ts
import {
  choice,
  TypeSafeClient,
  type ResultFor,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

/* ------------------------------------------------------------------ */
/* 1. The criteria map is the single source of truth.                  */
/* ------------------------------------------------------------------ */

/**
 * This one object derives three separate things:
 *   - the option labels the model is allowed to return,
 *   - the `criteria` payload the SDK ships to the API,
 *   - the `Department` union every `switch` in this file is checked against.
 *
 * Every option is an object rather than a string so that neighbouring options
 * are explicitly separated. The model receives the keys *and* the values.
 */
export const DEPARTMENT_CRITERIA = {
  billing: {
    what: "Charges, invoices, refunds, and subscription or plan changes.",
    not_for: "Order tracking, delivery, or account access.",
    examples: ["I was charged twice", "Where is my refund?", "Cancel my plan"],
  },
  technical: {
    what: "Bugs, outages, broken integrations, and error messages from the product.",
    not_for: "Billing questions with no technical component.",
    examples: ["The export button throws a 500", "Webhooks stopped firing"],
  },
  sales: {
    what: "Pricing, plans, trials, and what a prospective customer asks before buying.",
    not_for: "Existing customers with a live problem.",
    examples: ["Do you offer annual billing?", "Can I get a demo?"],
  },
  returns: {
    what: "Exchanges, refunds for goods, wrong or damaged items, shipping disputes.",
    not_for: "Subscription refunds, which belong to billing.",
    examples: ["My order arrived broken", "I want to return the wrong size"],
  },
  account: {
    what: "Sign-in, password reset, permissions, two-factor, and profile changes.",
    not_for: "Charges or order tracking.",
    examples: ["I cannot log in", "Reset my password", "Remove a teammate"],
  },
} as const;

export type Department = keyof typeof DEPARTMENT_CRITERIA;

/* ------------------------------------------------------------------ */
/* 2. The domain types.                                                */
/* ------------------------------------------------------------------ */

export interface SupportTicket {
  readonly ticketId: string;
  readonly customerId: string;
  readonly subject: string;
  readonly body: string;
  readonly channel: "email" | "chat" | "web";
  readonly createdAt: string; // ISO 8601
}

export type ProbabilityMap = Readonly<Record<Department, number>>;

/**
 * A routed variant is defined by mapping over `Department`, so adding a label
 * to DEPARTMENT_CRITERIA widens the union by one variant. There is no second
 * place to edit.
 */
type RoutedVariant<D extends Department> = {
  readonly kind: D;
  readonly ticketId: string;
  readonly confidence: number;
  readonly probabilities: ProbabilityMap;
};

export type RouteOutcome =
  | { [D in Department]: RoutedVariant<D> }[Department]
  | {
      readonly kind: "needsHumanReview";
      readonly ticketId: string;
      readonly confidence: number;
      readonly probabilities: ProbabilityMap;
      readonly reason: "lowConfidence";
    };

/* ------------------------------------------------------------------ */
/* 3. The question set.                                                */
/* ------------------------------------------------------------------ */

export const QUESTIONS = {
  department: choice<typeof DEPARTMENT_CRITERIA>(
    "Which team should handle `ticket.subject` and `ticket.body`?",
    DEPARTMENT_CRITERIA,
  ),
} as const;

/**
 * The answer type the SDK produces for `department`. `ResultFor` unwraps the
 * question variant to its response variant; `ChoiceResponse<T>["choice"]` is
 * `keyof T & string`, which here is exactly `Department`.
 */
type DepartmentAnswer = ResultFor<(typeof QUESTIONS)["department"]>;
type ChoiceIsDepartment =
  DepartmentAnswer["choice"] extends Department
    ? Department extends DepartmentAnswer["choice"]
      ? true
      : false
    : false;

// If this assignment ever fails, the `choice` field has been widened to
// `string` somewhere and every downstream exhaustive switch is a lie.
const _choiceIsDepartment: ChoiceIsDepartment = true;
void _choiceIsDepartment;

/* ------------------------------------------------------------------ */
/* 4. The guard.                                                       */
/* ------------------------------------------------------------------ */

export class InvalidTicketError extends Error {
  readonly field: keyof SupportTicket | "<self>";
  constructor(message: string, field: keyof SupportTicket | "<self>") {
    super(message);
    this.name = "InvalidTicketError";
    this.field = field;
  }
}

/**
 * Narrows `SupportTicket | null` to `SupportTicket`. Written as an `asserts`
 * predicate so that callers need neither `!` nor `as`. Every branch is a real
 * runtime check; there is no type assertion anywhere in this function.
 */
export function assertUsableTicket(
  ticket: SupportTicket | null,
): asserts ticket is SupportTicket {
  if (ticket === null || ticket === undefined) {
    throw new InvalidTicketError("No ticket supplied.", "<self>");
  }
  if (typeof ticket.ticketId !== "string" || ticket.ticketId.length === 0) {
    throw new InvalidTicketError("ticketId is missing.", "ticketId");
  }
  if (typeof ticket.customerId !== "string" || ticket.customerId.length === 0) {
    throw new InvalidTicketError("customerId is missing.", "customerId");
  }
  if (typeof ticket.body !== "string" || ticket.body.trim().length === 0) {
    throw new InvalidTicketError("body is empty.", "body");
  }
}

/* ------------------------------------------------------------------ */
/* 5. The router.                                                      */
/* ------------------------------------------------------------------ */

/** Above this, the router acts on the model's answer without a human. */
export const AUTO_ROUTE_CONFIDENCE = 0.75;

let _client: TypeSafeClient | null = null;
function defaultClient(): TypeSafeClient {
  if (_client === null) _client = new TypeSafeClient();
  return _client;
}

export async function routeTicket(
  ticket: SupportTicket | null,
  client: TypeSafeClient = defaultClient(),
): Promise<RouteOutcome> {
  assertUsableTicket(ticket);

  // Projection, not transcription. We send only the fields the classifier
  // reads, because unrelated context is a known distractor: a request that
  // carries the whole CRM record alongside the subject does worse than one
  // that carries just the two fields the question is about.
  const state = {
    ticket: {
      subject: ticket.subject,
      body: ticket.body,
      channel: ticket.channel,
    },
  };

  const result: SystemOneResult<typeof QUESTIONS> = await client.systemOne({
    state,
    questions: QUESTIONS,
  });

  const answer = result.answers.department;

  // `answer.choice` is `Department`, not `string`; proven above by
  // `_choiceIsDepartment`. No widening, no narrowing, no assertion.
  const department: Department = answer.choice;

  // The SDK declares `probabilities` as a read-through index signature over
  // every key, so `answer.probabilities[x]` for any Department is a `number`
  // and never `number | undefined`. Assigning it to `ProbabilityMap` is a
  // structural check the compiler performs for us.
  const probabilities: ProbabilityMap = answer.probabilities;

  if (answer.confidence < AUTO_ROUTE_CONFIDENCE) {
    return {
      kind: "needsHumanReview",
      ticketId: ticket.ticketId,
      confidence: answer.confidence,
      probabilities,
      reason: "lowConfidence",
    };
  }

  // The switch is where exhaustiveness lives. Add a sixth option to
  // DEPARTMENT_CRITERIA and this function stops compiling because not every
  // code path returns a value.
  switch (department) {
    case "billing":
      return { kind: "billing", ticketId: ticket.ticketId, confidence: answer.confidence, probabilities };
    case "technical":
      return { kind: "technical", ticketId: ticket.ticketId, confidence: answer.confidence, probabilities };
    case "sales":
      return { kind: "sales", ticketId: ticket.ticketId, confidence: answer.confidence, probabilities };
    case "returns":
      return { kind: "returns", ticketId: ticket.ticketId, confidence: answer.confidence, probabilities };
    case "account":
      return { kind: "account", ticketId: ticket.ticketId, confidence: answer.confidence, probabilities };
  }
}

/* ------------------------------------------------------------------ */
/* 6. The summarizer.                                                  */
/* ------------------------------------------------------------------ */

const DEPARTMENT_LABEL: Record<Department, string> = {
  billing: "Billing",
  technical: "Technical",
  sales: "Sales",
  returns: "Returns",
  account: "Account",
};

export function summarize(outcome: RouteOutcome): string {
  switch (outcome.kind) {
    case "billing":
    case "technical":
    case "sales":
    case "returns":
    case "account":
      return `Ticket ${outcome.ticketId} -> ${DEPARTMENT_LABEL[outcome.kind]} (confidence ${outcome.confidence.toFixed(2)})`;
    case "needsHumanReview":
      return `Ticket ${outcome.ticketId} -> human review (confidence ${outcome.confidence.toFixed(2)}, reason ${outcome.reason})`;
    default: {
      // Exhaustiveness: if RouteOutcome gains a variant and this switch does
      // not handle it, `outcome` is not `never` here and the assignment fails.
      // That is strictly stronger than a runtime `throw` alone: the failure is
      // reported at build time, rather than the first time the new variant
      // reaches production.
      const unreachable: never = outcome;
      throw new Error(`Unhandled RouteOutcome ${JSON.stringify(unreachable)}`);
    }
  }
}
