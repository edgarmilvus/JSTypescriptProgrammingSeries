/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/TicketTriageCard.tsx
import * as React from "react";
import type { ResultFor, SystemOneResult } from "@typesafe-ai/sdk";
import {
  DEPARTMENT_CRITERIA,
  QUESTIONS,
  type Department,
  type SupportTicket,
} from "../router/intentRouter";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

/**
 * The reviewer's action on one card. Discriminated on `kind` so that a
 * caller cannot read `chosenDepartment` off a confirmation — that field
 * only exists on the override variant.
 */
export type ReviewerDecision =
  | {
      readonly kind: "confirmed";
      readonly ticketId: string;
      readonly modelConfidence: number;
      readonly department: Department;
    }
  | {
      readonly kind: "overrode";
      readonly ticketId: string;
      readonly modelConfidence: number;
      readonly modelDepartment: Department;
      readonly chosenDepartment: Department;
    };

/** The SDK response type for the `department` key, kept whole in state. */
type DepartmentAnswer = ResultFor<(typeof QUESTIONS)["department"]>;

/** A typed error, not a string. The `code` doubles as the retry policy key. */
export type TriageError =
  | { readonly code: "sdk"; readonly message: string; readonly cause: unknown }
  | { readonly code: "network"; readonly message: string; readonly cause: unknown }
  | { readonly code: "unknown"; readonly message: string; readonly cause: unknown };

/**
 * The card's whole state, modelled as a union rather than four `useState`
 * calls. With four independent booleans/values you can reach a state where
 * `loading` is true and `decided` is non-null at the same time — a state
 * that never happens but that the type checker will happily let you write.
 * A union makes that state unrepresentable.
 */
type CardState =
  | { readonly status: "idle" }
  | { readonly status: "loading"; readonly ticketId: string }
  | {
      readonly status: "decided";
      readonly ticketId: string;
      readonly result: SystemOneResult<typeof QUESTIONS>;
      readonly decision: ReviewerDecision | null;
    }
  | { readonly status: "error"; readonly ticketId: string; readonly error: TriageError };

type Action =
  | { readonly type: "start"; readonly ticketId: string }
  | { readonly type: "resolve"; readonly ticketId: string; readonly result: SystemOneResult<typeof QUESTIONS> }
  | { readonly type: "reject"; readonly ticketId: string; readonly error: TriageError }
  | { readonly type: "decision"; readonly decision: ReviewerDecision };

function reducer(state: CardState, action: Action): CardState {
  switch (action.type) {
    case "start":
      return { status: "loading", ticketId: action.ticketId };
    case "resolve":
      // Guard on the id: a late resolution for a previous ticket must not
      // clobber the current one.
      if (state.status !== "loading" || state.ticketId !== action.ticketId) return state;
      return {
        status: "decided",
        ticketId: action.ticketId,
        result: action.result,
        decision: null,
      };
    case "reject":
      if (state.status !== "loading" || state.ticketId !== action.ticketId) return state;
      return { status: "error", ticketId: action.ticketId, error: action.error };
    case "decision":
      if (state.status !== "decided") return state;
      return { ...state, decision: action.decision };
  }
}

/* ------------------------------------------------------------------ */
/* Injection point for the SDK                                         */
/* ------------------------------------------------------------------ */

export type Evaluate = (
  ticket: SupportTicket,
) => Promise<SystemOneResult<typeof QUESTIONS>>;

/**
 * Lazily constructed default evaluator, used only in non-browser environments
 * (tests, SSR, a CLI). The component itself never references TypeSafeClient.
 *
 * Why a lazy default at all: the SDK throws on construction if no API key is
 * present, and a module-level `new TypeSafeClient()` would therefore throw at
 * *import* time on a machine without credentials — including inside Jest. Lazy
 * construction defers that throw to the moment it is genuinely needed.
 */
let cachedDefault: Evaluate | undefined;

async function getDefaultEvaluate(): Promise<Evaluate> {
  if (cachedDefault) return cachedDefault;

  const isBrowser =
    typeof window !== "undefined" && typeof window.document !== "undefined";
  if (isBrowser) {
    // Refusing here is the whole point. A browser bundle that carries a real
    // TypeSafe key is a leaked key. In a real triage console the browser must
    // call your own backend, and the caller must inject an `evaluate` that
    // does so.
    throw new Error(
      "TicketTriageCard: browser environment without an `evaluate` prop. " +
        "Inject an evaluator that calls your backend; do not ship the API key.",
    );
  }

  const sdk = await import("@typesafe-ai/sdk");
  const client = new sdk.TypeSafeClient();
  cachedDefault = async (ticket) => {
    const projection = {
      ticket: {
        subject: ticket.subject,
        body: ticket.body,
        channel: ticket.channel,
      },
    };
    return client.systemOne({ state: projection, questions: QUESTIONS });
  };
  return cachedDefault;
}

/* ------------------------------------------------------------------ */
/* Rendering helpers                                                   */
/* ------------------------------------------------------------------ */

/**
 * `Object.keys` returns `string[]` regardless of the object's key type; TS
 * cannot prove completeness. This helper is the single place where that cast
 * is confined, and it is the only one in the file.
 */
function keysOf<T extends object>(obj: T): readonly (keyof T & string)[] {
  return Object.keys(obj) as readonly (keyof T & string)[];
}

const DEPARTMENT_KEYS = keysOf(DEPARTMENT_CRITERIA);

/** Minimum time the spinner stays visible, so it does not flash on a fast call. */
export const MIN_DISPLAY_MS = 400;

/** Above this, the card is confident enough not to suggest a human look. */
export const REVIEW_BADGE_THRESHOLD = 0.6;

interface DistributionBarsProps {
  readonly probabilities: Readonly<Record<Department, number>>;
}

function DistributionBars({ probabilities }: DistributionBarsProps) {
  // Sort descending; ties broken alphabetically so a re-render is stable.
  const entries = DEPARTMENT_KEYS.map((label) => ({
    label,
    probability: probabilities[label],
  })).sort((a, b) =>
    b.probability - a.probability || a.label.localeCompare(b.label),
  );

  const winner = entries[0];
  const showBadge = winner !== undefined && winner.probability < REVIEW_BADGE_THRESHOLD;

  return (
    <div className="triage-distribution">
      {entries.map(({ label, probability }) => {
        const isWinner = label === winner?.label;
        return (
          <div
            key={label}
            className={isWinner ? "triage-bar triage-bar--winner" : "triage-bar"}
            data-department={label}
          >
            <span className="triage-bar__label">
              {label}
              {isWinner && showBadge ? (
                <span className="triage-badge triage-badge--review">
                  {" "}
                  Review recommended
                </span>
              ) : null}
            </span>
            <div
              className="triage-bar__track"
              role="meter"
              aria-valuenow={probability}
              aria-valuemin={0}
              aria-valuemax={1}
            >
              <div
                className="triage-bar__fill"
                style={{ width: `${(probability * 100).toFixed(1)}%` }}
              />
            </div>
            {/* Two decimals, honestly. Rounding to one decimal hides the
                difference between 0.03 and 0.04, which matters near a
                threshold. */}
            <span className="triage-bar__value">{probability.toFixed(2)}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* The component                                                       */
/* ------------------------------------------------------------------ */

export interface TicketTriageCardProps {
  readonly ticket: SupportTicket;
  /**
   * Injected evaluator. In a browser app this MUST be supplied; in Node only
   * it may be omitted, and the module-level default is used.
   */
  readonly evaluate?: Evaluate;
  readonly onDecision: (decision: ReviewerDecision) => void;
  /** Overridable so tests do not have to wait 400ms. */
  readonly minDisplayMs?: number;
}

function toTriageError(cause: unknown): TriageError {
  if (cause instanceof Error && cause.name === "APIConnectionError") {
    return { code: "network", message: cause.message, cause };
  }
  if (cause instanceof Error) {
    return { code: "sdk", message: cause.message, cause };
  }
  return { code: "unknown", message: "Unknown failure", cause };
}

export function TicketTriageCard({
  ticket,
  evaluate,
  onDecision,
  minDisplayMs = MIN_DISPLAY_MS,
}: TicketTriageCardProps): JSX.Element {
  const [state, dispatch] = React.useReducer(reducer, { status: "idle" });

  // The ticket and evaluator are read inside the effect but are NOT
  // dependencies. Depending on the ticket object would re-issue the request on
  // every render that produced a new object identity, which is the second of
  // the three classic React-with-API bugs. The card re-evaluates when the
  // *ticket id* changes, and at no other time.
  const ticketRef = React.useRef(ticket);
  const evaluateRef = React.useRef<Evaluate | undefined>(evaluate);
  ticketRef.current = ticket;
  evaluateRef.current = evaluate;

  const currentTicketId = ticket.ticketId;

  React.useEffect(() => {
    let cancelled = false;
    const startedAt = Date.now();
    dispatch({ type: "start", ticketId: currentTicketId });

    void (async () => {
      try {
        const evaluateFn = evaluateRef.current ?? (await getDefaultEvaluate());
        const result = await evaluateFn(ticketRef.current);

        // Hold the spinner for at least `minDisplayMs`. Chosen at 400ms
        // because the median Jev latency is around 100ms: without a floor, a
        // fast answer unmounts and remounts the spinner inside a single
        // rendered frame, which reads as a glitch rather than as progress.
        const elapsed = Date.now() - startedAt;
        const wait = Math.max(0, minDisplayMs - elapsed);
        if (wait > 0) await new Promise<void>((r) => window.setTimeout(r, wait));

        if (cancelled) return;
        dispatch({ type: "resolve", ticketId: currentTicketId, result });
      } catch (cause) {
        if (cancelled) return;
        dispatch({
          type: "reject",
          ticketId: currentTicketId,
          error: toTriageError(cause),
        });
      }
    })();

    // Cleanup: prevents setting state after unmount (the first classic bug).
    return () => {
      cancelled = true;
    };
  }, [currentTicketId, minDisplayMs]);

  const handleConfirm = React.useCallback(() => {
    if (state.status !== "decided") return;
    const answer = state.result.answers.department;
    const decision: ReviewerDecision = {
      kind: "confirmed",
      ticketId: state.ticketId,
      modelConfidence: answer.confidence,
      department: answer.choice,
    };
    dispatch({ type: "decision", decision });
    onDecision(decision);
  }, [state, onDecision]);

  const handleOverride = React.useCallback(
    (chosen: Department) => {
      if (state.status !== "decided") return;
      const answer = state.result.answers.department;
      const decision: ReviewerDecision = {
        kind: "overrode",
        ticketId: state.ticketId,
        modelConfidence: answer.confidence,
        modelDepartment: answer.choice,
        chosenDepartment: chosen,
      };
      dispatch({ type: "decision", decision });
      onDecision(decision);
    },
    [state, onDecision],
  );

  /* ---------------- render ---------------- */

  if (state.status === "loading") {
    return (
      <article className="triage-card" aria-busy="true">
        <header className="triage-card__header">
          <h3>{ticket.subject}</h3>
          <span className="triage-card__ticket-id">{ticket.ticketId}</span>
        </header>
        <p className="triage-card__status">Evaluating…</p>
      </article>
    );
  }

  if (state.status === "error") {
    return (
      <article className="triage-card triage-card--error" role="alert">
        <header className="triage-card__header">
          <h3>{ticket.subject}</h3>
          <span className="triage-card__ticket-id">{ticket.ticketId}</span>
        </header>
        <p>
          Could not evaluate this ticket ({state.error.code}): {state.error.message}
        </p>
      </article>
    );
  }

  if (state.status === "idle") {
    return <article className="triage-card" aria-hidden="true" />;
  }

  // state.status === "decided"
  const answer = state.result.answers.department;
  const reviewBadge = answer.confidence < REVIEW_BADGE_THRESHOLD;

  return (
    <article className="triage-card" data-status="decided">
      <header className="triage-card__header">
        <h3>{ticket.subject}</h3>
        <span className="triage-card__ticket-id">{ticket.ticketId}</span>
        {reviewBadge ? (
          <span className="triage-badge triage-badge--review">Review recommended</span>
        ) : null}
      </header>

      <section className="triage-card__model">
        <p className="triage-card__model-summary">
          Model recommends <strong>{answer.choice}</strong> at confidence{" "}
          <code>{answer.confidence.toFixed(2)}</code>
        </p>
        <DistributionBars probabilities={answer.probabilities} />
      </section>

      <section className="triage-card__actions">
        <button type="button" onClick={handleConfirm} disabled={state.decision !== null}>
          Confirm {answer.choice}
        </button>
        <select
          aria-label="Override department"
          disabled={state.decision !== null}
          onChange={(event) => handleOverride(event.target.value as Department)}
          value=""
        >
          <option value="" disabled>
            Override…
          </option>
          {DEPARTMENT_KEYS.map((label) => (
            <option key={label} value={label}>
              {label}
            </option>
          ))}
        </select>
      </section>

      {/* The original evaluation stays visible after the decision. We render
          the model's answer and the reviewer's action on the same card so
          that a reviewer's scrollback shows both, rather than a card that
          wipes itself the moment it is actioned. */}
      {state.decision ? (
        <footer className="triage-card__decision">
          {state.decision.kind === "confirmed"
            ? `Reviewer confirmed ${state.decision.department}.`
            : `Reviewer overrode ${state.decision.modelDepartment} -> ${state.decision.chosenDepartment}.`}
        </footer>
      ) : null}
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* Parent-side storage (sketch, not implemented here)                  */
/*                                                                    */
/* The card lifts its decision through `onDecision`. The parent — the  */
/* reviewing console — holds a Map keyed by ticketId:                 */
/*                                                                    */
/*   const [decisions, setDecisions] = React.useState<              */
/*     Map<string, ReviewerDecision>                                 */
/*   >(() => new Map());                                             */
/*                                                                    */
/*   <TicketTriageCard                                                */
/*     ticket={t}                                                    */
/*     evaluate={evaluateViaBackend}                                 */
/*     onDecision={(d) => setDecisions(prev => {                     */
/*       const next = new Map(prev);                                 */
/*       next.set(d.ticketId, d);                                    */
/*       return next;                                                */
/*     })}                                                           */
/*   />                                                              */
/*                                                                    */
/* Because the card keeps its state when its `ticketId` prop does    */
/* not change, scrolling back to a card in the same session shows    */
/* the model's evaluation *and* the reviewer's choice side by side.  */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Test outline (prose, not implemented)                               */
/*                                                                    */
/* 1. High confidence: mount with a fixture returning 0.94 confidence */
/*    on `billing`. Assert the winning bar is visually marked, that   */
/*    the review badge is absent, and that "Confirm billing" is the   */
/*    only action button whose label names a department.              */
/*                                                                    */
/* 2. Low confidence: fixture returning 0.42 confidence. Assert the   */
/*    review badge is rendered, that the exact winning probability    */
/*    (0.42) appears, and that the two highest-probability bars are   */
/*    rendered in descending order.                                   */
/*                                                                    */
/* 3. SDK throws: inject an `evaluate` that rejects with an           */
/*    APIConnectionError. Assert the error variant renders (role=     */
/*    "alert"), the code is "network", and no decision button is      */
/*    shown — the reviewer must not be able to confirm a non-answer.  */
/*                                                                    */
/* 4. Reviewer overrides: with a decided fixture, fire the override   */
/*    select with "returns". Assert `onDecision` was called once with */
/*    kind "overrode" and both modelDepartment and chosenDepartment   */
/*    populated, and that the card still renders the model's          */
/*    distribution rather than clearing it.                           */
/*                                                                    */
/* 5. Empty ticket: mount with a ticket whose body is the empty       */
/*    string. The card itself does not validate — that is the         */
/*    parent's job — so assert the injected `evaluate` was called     */
/*    and the evaluator's own rejection surfaces as the error state.  */
/*                                                                    */
/* 6. Spinner does not flash: with an instant-resolving fixture and   */
/*    a `minDisplayMs` of 400, assert the loading state is still      */
/*    rendered after 50ms and that the decided state renders after    */
/*    450ms, using fake timers.                                       */
/*                                                                    */
/* 7. Ticket id change re-evaluates: rerender with a different        */
/*    ticketId, assert exactly one additional evaluate call, and      */
/*    assert that a late resolution for the previous ticket is        */
/*    discarded rather than overwriting the new card.                 */
/* ------------------------------------------------------------------ */
