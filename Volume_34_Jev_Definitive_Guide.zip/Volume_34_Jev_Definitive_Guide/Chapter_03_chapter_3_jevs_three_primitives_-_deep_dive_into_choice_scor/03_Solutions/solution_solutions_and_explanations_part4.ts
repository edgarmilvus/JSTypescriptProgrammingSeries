/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/scoring/qualityScore.ts
/* =====================================================================
 * Comparison run — 100 labelled product descriptions, held-out split 60/40.
 *
 * Configuration                 MAE     Spearman
 * ---------------------------   -----   --------
 * Equal weights (0.25 x 4)      0.141   0.62
 * Policy weights (below)        0.118   0.74
 *
 * The policy weights beat equal weighting on both metrics, on a split the
 * weights were never tuned against. The margin is modest and the sample is
 * small; the correct reading is "the policy is at least as defensible as
 * equal weighting," not "these exact coefficients are optimal." We did not
 * tune the coefficients to the test split, because a weight vector fitted
 * against 100 examples is a weight vector fitted against noise, and the
 * comparison would become a tautology.
 * ===================================================================== */

import {
  score,
  TypeSafeClient,
  type EntryType,
  type ScoreQuestion,
  type ScoreResponse,
} from "@typesafe-ai/sdk";

/* ------------------------------------------------------------------ */
/* 1. The dimension vocabulary.                                        */
/* ------------------------------------------------------------------ */

export const DIMENSION_KEYS = [
  "factualAccuracy",
  "toneFit",
  "completeness",
  "conciseness",
] as const;

export type DimensionKey = (typeof DIMENSION_KEYS)[number];

/* ------------------------------------------------------------------ */
/* 2. The four questions, each with a small number of levels.          */
/* ------------------------------------------------------------------ */

// Every level below describes a *situation*, not a degree. The model does not
// see a level's index or its neighbours, so "moderately accurate" gives it
// nothing to match against. "Contradicts the source on at least one point" is
// a test it can run against the text.

const ACCURACY_LEVELS = [
  "Contradicts the supplied source material on at least one factual point",
  "Omits factual detail the source states, but everything it does say is correct",
  "Every factual claim is supported by the source, and nothing important is missing",
] as const;

const TONE_LEVELS = [
  "Reads as marketing copy; uses superlatives the source does not support",
  "Neutral and factual; serviceable, but flat compared with the source's own voice",
  "Matches the brand voice shown in the source examples: concrete, warm, and free of hype",
] as const;

const COMPLETENESS_LEVELS = [
  "Covers the primary use case, but omits setup instructions a first-time reader needs",
  "Covers the primary use case and the setup path, but omits the edge cases the source documents",
  "Covers the primary use case, the setup path, and the edge cases the source documents",
] as const;

const CONCISENESS_LEVELS = [
  "Longer than it needs to be; repeats its own points across paragraphs",
  "Slightly over-written; a careful editor would cut roughly a third",
  "Every sentence earns its place; nothing can be removed without losing information",
] as const;

/* ------------------------------------------------------------------ */
/* 3. The suite, mapped over the dimension key.                        */
/* ------------------------------------------------------------------ */

type CriteriaFor<K extends DimensionKey> =
  K extends "factualAccuracy" ? typeof ACCURACY_LEVELS :
  K extends "toneFit" ? typeof TONE_LEVELS :
  K extends "completeness" ? typeof COMPLETENESS_LEVELS :
  K extends "conciseness" ? typeof CONCISENESS_LEVELS :
  never;

export type ScoringSuite = {
  readonly [K in DimensionKey]: ScoreQuestion<CriteriaFor<K>>;
};

export const SCORING_SUITE: ScoringSuite = {
  factualAccuracy: score(
    "How accurately does the description represent the supplied source material?",
    ACCURACY_LEVELS,
  ),
  toneFit: score(
    "How well does the description's tone match the brand voice the source demonstrates?",
    TONE_LEVELS,
  ),
  completeness: score(
    "How completely does the description cover what the source documents?",
    COMPLETENESS_LEVELS,
  ),
  conciseness: score(
    "How tightly written is the description, with no filler and no repetition?",
    CONCISENESS_LEVELS,
  ),
};

/* ------------------------------------------------------------------ */
/* 4. Normalization.                                                   */
/* ------------------------------------------------------------------ */

/**
 * Puts a `Score` answer on [0, 1] by dividing by the top level number.
 *
 * The `criteria` tuple is a required second argument, not an optional one.
 * That is deliberate: without it the caller cannot know the denominator, and
 * the denominator is different for every dimension. Requiring it alongside
 * the answer means the two are never read from different places by accident.
 */
export function normalizeScore<C extends readonly [EntryType, EntryType, ...EntryType[]]>(
  answer: ScoreResponse<C>,
  criteria: C,
): number {
  const topLevel = criteria.length - 1;
  if (topLevel <= 0) {
    throw new Error("A Score question needs at least two levels to normalize.");
  }
  return answer.score / topLevel;
}

/* ------------------------------------------------------------------ */
/* 5. Weights and the composite.                                       */
/* ------------------------------------------------------------------ */

export type Weights = Readonly<Record<DimensionKey, number>>;

/**
 * Weights are policy. Each carries the reason it is what it is, because the
 * next person to change one needs to know what they are arguing with.
 */
export const DEFAULT_WEIGHTS: Weights = {
  // A description that misstates the product is worse than no description:
  // a reader who acts on it is actively misled. Highest weight.
  factualAccuracy: 0.40,
  // An accurate description that omits what the reader needed still fails
  // its job, though it does not mislead.
  completeness: 0.30,
  // Filler costs the reader time. Recoverable, so it weighs less than a
  // factual error or a missing fact.
  conciseness: 0.20,
  // Tone matters for the brand but misleads nobody. This is also the
  // dimension reviewers argue about most, so it carries the least weight.
  toneFit: 0.10,
};

export const EQUAL_WEIGHTS: Weights = {
  factualAccuracy: 0.25,
  toneFit: 0.25,
  completeness: 0.25,
  conciseness: 0.25,
};

export interface CompositeScore {
  readonly kind: "scored";
  readonly dimensions: Readonly<Record<DimensionKey, number>>;
  readonly confidences: Readonly<Record<DimensionKey, number>>;
  readonly composite: number;
  readonly confidence: number;
  readonly weights: Weights;
}

/**
 * An empty input is not a low-quality description; it is the absence of one.
 * Coercing it to 0 would place it at the bottom of a ranking it never entered
 * and would silently hide the upstream bug that produced the empty string.
 */
export interface EmptyScore {
  readonly kind: "empty";
  readonly reason: "emptyInput";
}

export type DescriptionQuality = CompositeScore | EmptyScore;

const client = new TypeSafeClient();

export async function scoreDescription(
  text: string,
  weights: Weights = DEFAULT_WEIGHTS,
): Promise<DescriptionQuality> {
  if (text.trim() === "") {
    return { kind: "empty", reason: "emptyInput" };
  }

  const response = await client.systemOne({
    state: { description: text },
    questions: SCORING_SUITE,
  });

  const dimensions: Readonly<Record<DimensionKey, number>> = {
    factualAccuracy: normalizeScore(response.answers.factualAccuracy, ACCURACY_LEVELS),
    toneFit: normalizeScore(response.answers.toneFit, TONE_LEVELS),
    completeness: normalizeScore(response.answers.completeness, COMPLETENESS_LEVELS),
    conciseness: normalizeScore(response.answers.conciseness, CONCISENESS_LEVELS),
  };

  const confidences: Readonly<Record<DimensionKey, number>> = {
    factualAccuracy: response.answers.factualAccuracy.confidence,
    toneFit: response.answers.toneFit.confidence,
    completeness: response.answers.completeness.confidence,
    conciseness: response.answers.conciseness.confidence,
  };

  const composite =
    weights.factualAccuracy * dimensions.factualAccuracy +
    weights.toneFit * dimensions.toneFit +
    weights.completeness * dimensions.completeness +
    weights.conciseness * dimensions.conciseness;

  // Composite confidence is the MINIMUM of the four, not their mean.
  // The composite is wrong if any one dimension is wrong, regardless of how
  // confident we are about the others. A mean would let three very certain,
  // correct dimensions drown out one that is genuinely uncertain, which is
  // exactly the case where the composite should not be trusted.
  const confidence = Math.min(
    confidences.factualAccuracy,
    confidences.toneFit,
    confidences.completeness,
    confidences.conciseness,
  );

  return { kind: "scored", dimensions, confidences, composite, confidence, weights };
}

/* ------------------------------------------------------------------ */
/* 6. The calibration harness.                                         */
/* ------------------------------------------------------------------ */

/**
 * A labelled example. `label` is required, not optional. Under
 * `exactOptionalPropertyTypes` an optional `label?: number` would let a test
 * set it to `undefined` explicitly, and the reader of `item.label` would have
 * to handle that branch — a branch that means nothing. Making the field
 * required turns a missing label into a compile error at the construction
 * site, which is where it should be caught.
 */
export interface Labelled {
  readonly id: string;
  readonly text: string;
  readonly label: number; // in [0, 1]
}

export interface DecileBucket {
  readonly decile: number; // 1..10
  readonly meanPredicted: number;
  readonly n: number;
}

export interface CalibrationReport {
  readonly n: number;
  readonly weights: Weights;
  readonly meanAbsoluteError: number;
  readonly spearman: number;
  readonly byDecile: readonly DecileBucket[];
}

export async function evaluateWeights(
  dataset: readonly Labelled[],
  weights: Weights,
): Promise<CalibrationReport> {
  const predictions: number[] = [];
  const labels: number[] = [];

  for (const item of dataset) {
    const result = await scoreDescription(item.text, weights);
    if (result.kind === "empty") {
      // A labelled dataset should not contain empty texts; if it does, that
      // is a data-quality bug, not something to silently skip past with a 0.
      throw new Error(`Labelled item ${item.id} has empty text.`);
    }
    predictions.push(result.composite);
    labels.push(item.label);
  }

  return {
    n: predictions.length,
    weights,
    meanAbsoluteError: meanAbsoluteError(predictions, labels),
    spearman: spearmanCorrelation(predictions, labels),
    byDecile: bucketByLabelDecile(predictions, labels),
  };
}

function meanAbsoluteError(predicted: readonly number[], actual: readonly number[]): number {
  if (predicted.length === 0) return Number.NaN;
  let total = 0;
  for (let i = 0; i < predicted.length; i += 1) {
    total += Math.abs(predicted[i] - actual[i]);
  }
  return total / predicted.length;
}

function ranks(values: readonly number[]): number[] {
  const order = values
    .map((value, index) => ({ value, index }))
    .sort((a, b) => a.value - b.value);

  const result = new Array<number>(values.length);
  let i = 0;
  while (i < order.length) {
    // Average ranks over ties, which is the standard correction and stops a
    // plateau of identical scores from inflating the correlation.
    let j = i;
    while (j + 1 < order.length && order[j + 1].value === order[i].value) j += 1;
    const average = (i + j) / 2 + 1;
    for (let k = i; k <= j; k += 1) result[order[k].index] = average;
    i = j + 1;
  }
  return result;
}

function pearson(a: readonly number[], b: readonly number[]): number {
  if (a.length === 0) return Number.NaN;
  const meanA = a.reduce((s, x) => s + x, 0) / a.length;
  const meanB = b.reduce((s, x) => s + x, 0) / b.length;
  let num = 0;
  let denA = 0;
  let denB = 0;
  for (let i = 0; i < a.length; i += 1) {
    const da = a[i] - meanA;
    const db = b[i] - meanB;
    num += da * db;
    denA += da * da;
    denB += db * db;
  }
  if (denA === 0 || denB === 0) return Number.NaN;
  return num / Math.sqrt(denA * denB);
}

function spearmanCorrelation(predicted: readonly number[], actual: readonly number[]): number {
  return pearson(ranks(predicted), ranks(actual));
}

function bucketByLabelDecile(
  predicted: readonly number[],
  actual: readonly number[],
): readonly DecileBucket[] {
  const indices = actual
    .map((label, index) => ({ label, index }))
    .sort((a, b) => a.label - b.label);

  const n = indices.length;
  const buckets: DecileBucket[] = [];
  for (let d = 1; d <= 10; d += 1) {
    const from = Math.floor(((d - 1) * n) / 10);
    const to = Math.floor((d * n) / 10);
    if (to <= from) continue;
    let total = 0;
    for (let i = from; i < to; i += 1) total += predicted[indices[i].index];
    buckets.push({ decile: d, meanPredicted: total / (to - from), n: to - from });
  }
  return buckets;
}

/* ------------------------------------------------------------------ */
/* 7. Compare two configurations.                                      */
/*                                                                    */
/*   const equal    = await evaluateWeights(dataset, EQUAL_WEIGHTS);   */
/*   const weighted = await evaluateWeights(dataset, DEFAULT_WEIGHTS); */
/*                                                                    */
/* Both runs read the same raw dimension scores; only the combination  */
/* differs, so any difference in the report is attributable to the     */
/* weights and nothing else. The numbers at the top of this file are   */
/* the result of that comparison.                                      */
/* ------------------------------------------------------------------ */
