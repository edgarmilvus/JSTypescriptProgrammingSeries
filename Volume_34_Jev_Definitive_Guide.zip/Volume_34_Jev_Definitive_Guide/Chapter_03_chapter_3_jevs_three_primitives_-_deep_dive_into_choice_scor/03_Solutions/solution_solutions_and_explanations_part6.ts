/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// src/engine/types.ts
import type { SystemOneResult } from "@typesafe-ai/sdk";
import type { Topic, Urgency, QuestionSet } from "./questions";

/* ------------------------------------------------------------------ */
/* Thresholds — policy, not facts. All live here, none in questions.   */
/* ------------------------------------------------------------------ */

/** Below this, the fast path is genuinely unsure of the topic. */
export const MIN_TOPIC_CONFIDENCE = 0.75;

/** Above this, a hazard Noul escalates even when the topic is clear. */
export const HAZARD_ESCALATION_THRESHOLD = 0.70;

/** If the top two options in a Choice are this close, treat it as ambiguous. */
export const AMBIGUITY_MARGIN = 0.20;

/** The slow path must finish inside this, or the engine gives up and routes to review. */
export const SLOW_PATH_BUDGET_MS = 8_000;

/* ------------------------------------------------------------------ */
/* The two Nouls whose fire is a hazard, not a routing hint.           */
/* ------------------------------------------------------------------ */

export const HAZARD_NOUL_KEYS = ["containsPii", "attemptsToInstruct"] as const;
export type HazardQuestionKey = (typeof HAZARD_NOUL_KEYS)[number];

export type QuestionKey = keyof QuestionSet;

/* ------------------------------------------------------------------ */
/* Verdicts and traces                                                 */
/* ------------------------------------------------------------------ */

export type EscalationSignal =
  | { readonly reason: "lowTopicConfidence"; readonly confidence: number }
  | {
      readonly reason: "hazard";
      readonly question: HazardQuestionKey;
      readonly probability: number;
    }
  | {
      readonly reason: "ambiguousChoice";
      readonly question: QuestionKey;
      readonly topProbability: number;
      readonly runnerUpProbability: number;
    };

export interface FastVerdict {
  readonly topic: Topic;
  readonly topicConfidence: number;
  readonly urgency: Urgency;
  readonly severity: number;
  readonly frustration: number;
  readonly clarity: number;
  readonly selfServicePotential: number;
  readonly requestsRefund: number;
  readonly mentionsAccountId: number;
  readonly repeatContact: number;
  readonly hazards: Readonly<Record<HazardQuestionKey, number>>;
  readonly read: readonly QuestionKey[];
  readonly ignored: readonly QuestionKey[];
  readonly escalation: EscalationSignal | null;
}

export interface DecisionTrace {
  /** The model name the *response* reports, not the alias we asked for. */
  readonly model: string;
  readonly inputTokens: number;
  readonly outputTokens: number;
  /** Wall-clock time of the call(s) that produced this trace. */
  readonly durationMs: number;
  /** Every question that was evaluated in this request. */
  readonly evaluated: readonly QuestionKey[];
  /** The subset whose answers this decision actually consumed. */
  readonly read: readonly QuestionKey[];
  readonly escalation: EscalationSignal | null;
}

export interface EngineContext {
  readonly userId: string;
  readonly now: Date;
}

/**
 * `previousTrace` is `DecisionTrace | null`, not an optional property.
 * Under `exactOptionalPropertyTypes: true` an optional `previousTrace?:
 * DecisionTrace` means "the key may be absent", which is a subtly different
 * thing from "the key is present and its value is null". Modelling the
 * absence explicitly from the start avoids the distinction entirely: there
 * is always a key, and it is either a trace or `null`.
 */
export type Decision =
  | {
      readonly source: "fast";
      readonly ticketId: string;
      readonly verdict: FastVerdict;
      readonly trace: DecisionTrace;
      readonly previousTrace: DecisionTrace | null;
    }
  | {
      readonly source: "slow";
      readonly ticketId: string;
      readonly reason: EscalationSignal["reason"];
      readonly answer: string;
      readonly fastVerdict: FastVerdict;
      readonly trace: DecisionTrace;
      readonly fastTrace: DecisionTrace;
      readonly previousTrace: DecisionTrace | null;
    }
  | {
      readonly source: "review";
      readonly ticketId: string;
      readonly reason: "budget_exceeded" | "no_slow_path" | "escalation_failed";
      readonly trace: DecisionTrace;
      readonly fastTrace: DecisionTrace | null;
      readonly previousTrace: DecisionTrace | null;
    };
