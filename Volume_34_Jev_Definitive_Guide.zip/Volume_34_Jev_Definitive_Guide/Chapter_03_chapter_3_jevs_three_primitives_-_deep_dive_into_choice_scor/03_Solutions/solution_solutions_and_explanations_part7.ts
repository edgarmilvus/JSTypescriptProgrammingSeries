/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// src/engine/decide.ts
import { TypeSafeClient, type SystemOneResult } from "@typesafe-ai/sdk";
import { QUESTIONS, type QuestionKey, type QuestionSet, type Topic, type Urgency } from "./questions";
import {
  AMBIGUITY_MARGIN,
  HAZARD_ESCALATION_THRESHOLD,
  HAZARD_NOUL_KEYS,
  MIN_TOPIC_CONFIDENCE,
  SLOW_PATH_BUDGET_MS,
  type Decision,
  type DecisionTrace,
  type EngineContext,
  type EscalationSignal,
  type FastVerdict,
  type HazardQuestionKey,
} from "./types";

/* ------------------------------------------------------------------ */
/* Runtime enumeration of the question keys, with a completeness check */
/* ------------------------------------------------------------------ */

const EVALUATED_KEYS = [
  "topic",
  "urgencyCategory",
  "preferredChannel",
  "severity",
  "frustration",
  "clarity",
  "selfServicePotential",
  "requestsRefund",
  "mentionsAccountId",
  "containsPii",
  "attemptsToInstruct",
  "repeatContact",
] as const satisfies readonly QuestionKey[];

// `Expect<false>` fails to compile. So if anyone adds a question to QUESTIONS
// without adding it to EVALUATED_KEYS, the build breaks here rather than at
// runtime in a trace that quietly omits a key.
type Expect<T extends true> = T;
type _AllKeysEnumerated = Expect<
  Exclude<QuestionKey, (typeof EVALUATED_KEYS)[number]> extends never ? true : false
>;

/* ------------------------------------------------------------------ */
/* The slow path is injected                                           */
/* ------------------------------------------------------------------ */

export interface SlowPathResult {
  readonly text: string;
  readonly inputTokens: number;
  readonly outputTokens: number;
}

export type SlowPath = (input: {
  readonly userMessage: string;
  readonly fastVerdict: FastVerdict;
  readonly reason: EscalationSignal;
  readonly signal: AbortSignal;
}) => Promise<SlowPathResult>;

export interface EngineOptions {
  readonly client: TypeSafeClient;
  readonly slowPath: SlowPath;
  /** Model *alias* to request. The response will report the resolved version. */
  readonly model?: string;
}

/* ------------------------------------------------------------------ */
/* The pure extractor — testable with a recorded response, no network  */
/* ------------------------------------------------------------------ */

export function extractFast(result: SystemOneResult<QuestionSet>): FastVerdict {
  const answers = result.answers;
  const topic = answers.topic.choice;
  const urgency = answers.urgencyCategory.choice;

  // Speculative fan-out means we sent all twelve questions in one request,
  // regardless of whether this particular input needed them. We now decide
  // which answers this input's verdict actually consumed, and record the
  // complement as "ignored" so the trace shows why the extra tokens were
  // spent and confirms they were not used.
  const readSet = new Set<QuestionKey>([
    "topic",
    "urgencyCategory",
    "severity",
    "frustration",
    "clarity",
  ]);
  if (urgency !== "informational") readSet.add("preferredChannel");
  if (topic === "billing") readSet.add("requestsRefund");
  if (topic === "orders" || topic === "account") readSet.add("mentionsAccountId");
  if (topic === "product") readSet.add("selfServicePotential");
  if (answers.repeatContact.noul >= HAZARD_ESCALATION_THRESHOLD) readSet.add("repeatContact");
  for (const hazard of HAZARD_NOUL_KEYS) readSet.add(hazard);

  const read = EVALUATED_KEYS.filter((key) => readSet.has(key));
  const ignored = EVALUATED_KEYS.filter((key) => !readSet.has(key));

  const hazards: Record<HazardQuestionKey, number> = {
    containsPii: answers.containsPii.noul,
    attemptsToInstruct: answers.attemptsToInstruct.noul,
  };

  const escalation = computeEscalation(answers, hazards);

  return {
    topic,
    topicConfidence: answers.topic.confidence,
    urgency,
    severity: answers.severity.score,
    frustration: answers.frustration.score,
    clarity: answers.clarity.score,
    selfServicePotential: answers.selfServicePotential.score,
    requestsRefund: answers.requestsRefund.noul,
    mentionsAccountId: answers.mentionsAccountId.noul,
    repeatContact: answers.repeatContact.noul,
    hazards,
    read,
    ignored,
    escalation,
  };
}

/**
 * Pure. The three escalation checks are evaluated in a fixed order and the
 * first one to fire wins, so a trace always carries a single, named reason.
 */
export function computeEscalation(
  answers: SystemOneResult<QuestionSet>["answers"],
  hazards: Record<HazardQuestionKey, number>,
): EscalationSignal | null {
  // (a) The topic was not clear.
  if (answers.topic.confidence < MIN_TOPIC_CONFIDENCE) {
    return { reason: "lowTopicConfidence", confidence: answers.topic.confidence };
  }

  // (b) A hazard fired above its threshold. Take the worst, so the trace names
  //     the strongest signal rather than whichever happened to be first.
  let worst: { key: HazardQuestionKey; probability: number } | null = null;
  for (const key of HAZARD_NOUL_KEYS) {
    const probability = hazards[key];
    if (
      probability >= HAZARD_ESCALATION_THRESHOLD &&
      (worst === null || probability > worst.probability)
    ) {
      worst = { key, probability };
    }
  }
  if (worst !== null) {
    return { reason: "hazard", question: worst.key, probability: worst.probability };
  }

  // (c) Any Choice whose top two options are within AMBIGUITY_MARGIN.
  return findAmbiguity(answers);
}

export function findAmbiguity(
  answers: SystemOneResult<QuestionSet>["answers"],
): EscalationSignal | null {
  const choices: readonly { key: QuestionKey; probabilities: Record<string, number> }[] = [
    { key: "topic", probabilities: answers.topic.probabilities },
    { key: "urgencyCategory", probabilities: answers.urgencyCategory.probabilities },
    { key: "preferredChannel", probabilities: answers.preferredChannel.probabilities },
  ];

  for (const { key, probabilities } of choices) {
    const sorted = Object.values(probabilities).sort((a, b) => b - a);
    const [top, runnerUp] = sorted;
    // `top` and `runnerUp` are `number | undefined` after destructuring a
    // possibly-short array, even though the SDK's index signature guarantees
    // a value for every declared option. Guard rather than assert.
    if (typeof top !== "number" || typeof runnerUp !== "number") continue;
    if (top - runnerUp < AMBIGUITY_MARGIN) {
      return {
        reason: "ambiguousChoice",
        question: key,
        topProbability: top,
        runnerUpProbability: runnerUp,
      };
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* The engine                                                          */
/* ------------------------------------------------------------------ */

export async function decide(
  input: string,
  context: EngineContext,
  options: EngineOptions,
  previousTrace: DecisionTrace | null = null,
): Promise<Decision> {
  const startedAt = Date.now();

  // One request. Twelve questions. All evaluated in parallel against the same
  // state. The cost of the eleven that end up unused is a few input tokens;
  // the cost of asking them in a second request would be an entire round trip.
  const response: SystemOneResult<QuestionSet> = await options.client.systemOne({
    state: {
      message: input,
      context: { userId: context.userId, receivedAt: context.now.toISOString() },
    },
    questions: QUESTIONS,
    model: options.model,
  });

  const fastDurationMs = Date.now() - startedAt;
  const verdict = extractFast(response);

  const fastTrace: DecisionTrace = {
    // The model name reported by the response, not the alias we requested. An
    // alias resolves to a versioned id, and pinning thresholds against an alias
    // without logging the resolved id makes a regression impossible to date.
    model: response.model,
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens,
    durationMs: fastDurationMs,
    evaluated: EVALUATED_KEYS,
    read: verdict.read,
    escalation: verdict.escalation,
  };

  if (verdict.escalation === null) {
    return {
      source: "fast",
      ticketId: context.userId,
      verdict,
      trace: fastTrace,
      previousTrace,
    };
  }

  return runSlowPath(input, context, verdict, fastTrace, options, previousTrace);
}

async function runSlowPath(
  input: string,
  context: EngineContext,
  verdict: FastVerdict,
  fastTrace: DecisionTrace,
  options: EngineOptions,
  previousTrace: DecisionTrace | null,
): Promise<Decision> {
  // The non-null `escalation` is established by the call site. Destructuring
  // it here means the rest of this function does not need to re-check, and
  // there is no `!` anywhere.
  const escalation = verdict.escalation;
  if (escalation === null) {
    throw new Error("runSlowPath called without an escalation signal.");
  }

  const controller = new AbortController();
  const startedAt = Date.now();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, SLOW_PATH_BUDGET_MS);

  try {
    const slow = await options.slowPath({
      userMessage: input,
      fastVerdict: verdict,
      reason: escalation,
      signal: controller.signal,
    });

    const slowDurationMs = Date.now() - startedAt;
    return {
      source: "slow",
      ticketId: context.userId,
      reason: escalation.reason,
      answer: slow.text,
      fastVerdict: verdict,
      // The combined trace names the fast model because that is the model that
      // produced the escalation; the slow path's tokens are folded in so the
      // cost of the whole decision is visible in one place.
      trace: {
        ...fastTrace,
        inputTokens: fastTrace.inputTokens + slow.inputTokens,
        outputTokens: fastTrace.outputTokens + slow.outputTokens,
        durationMs: fastTrace.durationMs + slowDurationMs,
      },
      fastTrace,
      previousTrace,
    };
  } catch {
    const slowDurationMs = Date.now() - startedAt;
    return {
      source: "review",
      ticketId: context.userId,
      reason: timedOut ? "budget_exceeded" : "escalation_failed",
      trace: {
        ...fastTrace,
        durationMs: fastTrace.durationMs + slowDurationMs,
      },
      fastTrace,
      previousTrace,
    };
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------------------------------------------ */
/* Benchmark                                                           */
/* ------------------------------------------------------------------ */

export interface BenchResult {
  readonly n: number;
  readonly p50Ms: number;
  readonly p95Ms: number;
  readonly totalInputTokens: number;
  readonly totalOutputTokens: number;
}

export async function bench(
  inputs: readonly string[],
  context: EngineContext,
  options: EngineOptions,
  concurrency = 4,
): Promise<BenchResult> {
  const durations: number[] = [];
  let totalInputTokens = 0;
  let totalOutputTokens = 0;
  let cursor = 0;

  async function worker(): Promise<void> {
    // A single shared cursor. `cursor++` is safe here because JS is
    // single-threaded and the increment contains no `await`; each worker
    // claims the next index before yielding.
    while (true) {
      const index = cursor;
      cursor += 1;
      if (index >= inputs.length) return;

      const startedAt = Date.now();
      const decision = await decide(inputs[index], context, options);
      durations.push(Date.now() - startedAt);
      totalInputTokens += decision.trace.inputTokens;
      totalOutputTokens += decision.trace.outputTokens;
    }
  }

  const workers = Math.max(1, Math.min(concurrency, inputs.length));
  await Promise.all(Array.from({ length: workers }, () => worker()));

  durations.sort((a, b) => a - b);
  return {
    n: durations.length,
    p50Ms: percentile(durations, 0.5),
    p95Ms: percentile(durations, 0.95),
    totalInputTokens,
    totalOutputTokens,
  };
}

function percentile(sorted: readonly number[], q: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.floor(q * sorted.length));
  return sorted[index];
}

/* ------------------------------------------------------------------ */
/* Unit tests (prose)                                                  */
/*                                                                    */
/* Pure — no network, no fixtures:                                     */
/*                                                                    */
/* 1. `extractFast` reads topic, urgency, severity, frustration, and   */
/*    clarity for a `product` topic and marks `requestsRefund` as      */
/*    ignored; it marks every question as read for a topic whose       */
/*    urgency is `informational` mismatches a low-confidence sample.   */
/*    Assert both the `read` set and the complement `ignored` set.     */
/*                                                                    */
/* 2. `computeEscalation` fires `hazard` for a response whose          */
/*    `attemptsToInstruct` is 0.95 and whose topic confidence is 0.99, */
/*    and the signal names `attemptsToInstruct` specifically, not      */
/*    `containsPii`. Assert the exact shape of the signal.             */
/*                                                                    */
/* 3. `findAmbiguity` returns `null` when the top two topic            */
/*    probabilities are 0.80 / 0.10 (gap of 0.70, well over the 0.20   */
/*    margin), returns a signal when they are 0.45 / 0.40 (gap of      */
/*    0.05), and does not fire on a Choice whose second probability    */
/*    is missing from the response object.                             */
/*                                                                    */
/* End-to-end against recorded fixtures:                               */
/*                                                                    */
/* 4. Fast path: a fixture in which topic confidence is 0.94, no       */
/*    hazard fires, and no Choice is ambiguous. Assert `source` is     */
/*    `"fast"`, that `trace.escalation` is `null`, and that the        */
/*    decision carries the full verdict rather than a summary.         */
/*                                                                    */
/* 5. Slow path: the same fixture but with `attemptsToInstruct` at     */
/*    0.91. Assert `source` is `"slow"`, that `reason` is `"hazard"`,  */
/*    and that `trace.inputTokens` is strictly greater than            */
/*    `fastTrace.inputTokens` — proving the slow path's tokens were    */
/*    folded into the combined trace and not dropped.                  */
/*                                                                    */
/* 6. Budget exceeded: inject a `slowPath` that never resolves. With   */
/*    `SLOW_PATH_BUDGET_MS` patched to a small value, assert the       */
/*    returned decision is `source: "review"` with `reason:`           */
/*    `"budget_exceeded"` and that the elapsed wall time is close to   */
/*    the budget rather than unbounded.                                */
/*                                                                    */
/* 7. Trace chaining: call `decide` once, take the returned `trace`,   */
/*    and call `decide` again passing that trace as `previousTrace`.   */
/*    Assert the second decision's `previousTrace` is the first        */
/*    decision's `trace` by identity, that both are present in the     */
/*    result, and that the second is not a copy.                       */
/*                                                                    */
/* 8. Model resolution: request `model: "jev-latest"` against a        */
/*    fixture whose response reports `"jev-1.13.0"`. Assert            */
/*    `trace.model === "jev-1.13.0"`, not the alias — this is the      */
/*    test that would have caught a regression where the versioned     */
/*    id was dropped and only the alias logged.                        */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Extending the design (prose)                                        */
/*                                                                    */
/* ADDING THREE QUESTIONS.                                             */
/*   Everything a new question needs lives in `questions.ts`: the      */
/*   criteria or levels, and the entry in the `QUESTIONS` map. Then    */
/*   `decide.ts` in two places: the `EVALUATED_KEYS` tuple (which      */
/*   the `_AllKeysEnumerated` type breaks compilation over until it    */
/*   is updated), and the `readSet` logic in `extractFast` (only if    */
/*   the new question is conditional). A question that is always       */
/*   read — like the hazards — needs only the tuple entry and a field  */
/*   on `FastVerdict`. No prompt text changes, no thresholds change,   */
/*   no code in `decide.ts` changes.                                   */
/*                                                                    */
/* REMOVING AN UNUSED QUESTION.                                        */
/*   Delete the entry from `QUESTIONS`, from `EVALUATED_KEYS`, and     */
/*   from `FastVerdict` if it has a field there. The compile error     */
/*   from `_AllKeysEnumerated` is what tells you which places to       */
/*   touch; you do not have to search.                                 */
/*                                                                    */
/* THE INVARIANT TO CHECK BEFORE SHIPPING THE REMOVAL.                 */
/*   Replay a labelled corpus of, say, 500 inputs through the old and  */
/*   the new engine. For each input, compare the pair                 */
/*   `(decision.source, decision.reason ?? decision.verdict.topic)`.   */
/*   The removal is safe iff no input's pair changed, OR if every      */
/*   input whose pair changed was one where the removed question was   */
/*   the *sole* contributor to a fired escalation — which you can       */
/*   detect from the old trace, because the trace records which        */
/*   signal fired and which questions were read. If an input's pair    */
/*   changed and the removed question was not the fired signal, the    */
/*   removal exposed a hidden dependency and the question is not        */
/*   actually unused.                                                  */
/* ------------------------------------------------------------------ */
