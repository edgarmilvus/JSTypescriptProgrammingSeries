/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/lib/triage.ts
import { TypeSafeClient, choice, noul, score } from "@typesafe-ai/sdk";

/**
 * One per-process client. Reads `TYPESAFE_API_KEY` from the environment
 * and defaults to `jev-latest`. Reuse this object across requests so
 * the connection pool and retry policy stay warm.
 */
const client = new TypeSafeClient();

/**
 * The `state` is the single blob of evidence the model reads to answer
 * every question. Paths *inside* this object are the addressing surface
 * that the questions point at, using backticked dot-and-index
 * expressions such as `ticket.messages[0].text`.
 *
 * Shape matters: keep content under stable, named keys so paths never
 * depend on iteration order or implicit positions.
 */
const state = {
  ticket: {
    id: "T-1042",
    messages: [
      {
        from: "customer",
        text: "I was charged twice for order A-104. Please refund the duplicate.",
      },
      {
        from: "support",
        text: "We are checking the charges.",
      },
    ],
  },
  order: {
    id: "A-104",
    charges: [
      { amount_usd: 49, status: "captured" },
      { amount_usd: 49, status: "captured" },
    ],
  },
  refund_policy: "Duplicate charges are eligible for a refund.",
};

/**
 * Every question is defined once, statically. The ids you choose
 * (`refund_requested`, `department`, ...) are what the answers are
 * keyed by in the response — the model never sees them.
 */
const questions = {
  refund_requested: noul(
    "Does `ticket.messages[0].text` request a refund?",
  ),
  duplicate_charge: noul(
    "Do `order.charges[0].amount_usd` and `order.charges[1].amount_usd` match?",
  ),
  policy_supports_refund: noul(
    "Given `refund_policy`, does it support the request in `ticket.messages[0].text`?",
  ),
  department: choice("Which team should handle `ticket.messages[0].text`?", {
    billing: "Payment or subscription issues",
    technical: "Bugs or integration problems",
    sales: "Pricing or account questions",
  }),
  frustration: score(
    "How frustrated is the customer in `ticket.messages[0].text`?",
    [
      "Calm and factual",
      "Frustrated but civil",
      "Very angry, strong language",
    ],
  ),
};

/**
 * Orchestrates one triage pass.
 *
 * The entire decision tree fits in a single `systemOne` call: all
 * five questions are evaluated in parallel against the same state.
 * No follow-up request is needed to "look up" a value; the paths in
 * the question instructions *are* the lookup.
 */
export async function triage(): Promise<void> {
  const result = await client.systemOne({ state, questions });

  // Each `.answers.<id>` is typed by the primitive you sent:
  //   - noul(...)  -> NoulAnswer   -> `.noul: number`
  //   - choice(...) -> ChoiceAnswer -> `.choice: keyof T`, `.probabilities`, `.confidence`
  //   - score(...)  -> ScoreAnswer  -> `.score: number`, `.legend`, `.probabilities`
  const refund = result.answers.refund_requested.noul;
  const duplicate = result.answers.duplicate_charge.noul;
  const policy = result.answers.policy_supports_refund.noul;
  const department = result.answers.department.choice;
  const frustration = result.answers.frustration.score;

  // Compose independent judgments into one business rule. The rule
  // lives here, in code, not in a prompt.
  const shouldAutoRefund =
    refund >= 0.8 && duplicate >= 0.8 && policy >= 0.8;

  console.log({
    department,
    frustration,
    shouldAutoRefund,
    probabilities: result.answers.department.probabilities,
    confidence: result.answers.department.confidence,
  });
}

// Self-contained entrypoint for the example.
triage().catch(console.error);
