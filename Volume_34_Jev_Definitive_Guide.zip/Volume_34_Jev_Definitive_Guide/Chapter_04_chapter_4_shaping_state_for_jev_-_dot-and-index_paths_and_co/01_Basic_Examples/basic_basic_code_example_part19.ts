/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part19.ts
// Description: Basic Code Example
// ==========================================

{
  model: "jev-latest",
  answers: {
    refund_requested:     { type: "noul",   noul: 0.98 },
    duplicate_charge:     { type: "noul",   noul: 0.99 },
    policy_supports_refund: { type: "noul", noul: 0.95 },
    department: {
      type: "choice",
      choice: "billing",
      probabilities: { billing: 0.93, technical: 0.06, sales: 0.01 },
      confidence: 0.89,
    },
    frustration: {
      type: "score",
      score: 1.42,
      legend: {
        "0": "Calm and factual",
        "1": "Frustrated but civil",
        "2": "Very angry, strong language",
      },
      probabilities: { "0": 0.02, "1": 0.54, "2": 0.44 },
      confidence: 0.61,
    },
  },
  usage: { input_tokens: 412, output_tokens: 63 },
}
