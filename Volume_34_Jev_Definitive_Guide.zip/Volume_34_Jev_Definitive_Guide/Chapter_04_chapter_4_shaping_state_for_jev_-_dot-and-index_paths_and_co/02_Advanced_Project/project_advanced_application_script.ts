/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Path-addressed state shaping for Jev.
 *
 * The shaped state is deliberately shallow: four levels maximum, every leaf a scalar or a
 * short string. Depth is the only thing `setAt` costs, and depth is the only thing a
 * dot-and-index path can get wrong, so the two constraints are the same constraint.
 */

/** One segment of a state path: a named key, or an array index. */
export type PathSeg = string | number;

/** A fully-qualified path from the state root to exactly one addressable value. */
export type StatePath = readonly PathSeg[];

/**
 * Render a path in the dot-and-index notation Jev reads inside `instructions`.
 * @example renderPath(["evidence", "candidates", 0, "passage"]) // "evidence.candidates[0].passage"
 */
export function renderPath(path: StatePath): string {
  return path.reduce<string>(
    (acc, seg) => (typeof seg === "number" ? `${acc}[${seg}]` : acc ? `${acc}.${seg}` : seg),
    "",
  );
}

/** Backticked form — the exact shape the docs tell you to write in a question. */
export const cite = (path: StatePath): string => `\`${renderPath(path)}\``;

/** Immutable read. Absence returns `undefined`; callers decide what absence means. */
export function getAt(root: unknown, path: StatePath): unknown {
  let node: unknown = root;
  for (const seg of path) {
    if (node === null || node === undefined) return undefined;
    node = (node as Record<PathSeg, unknown>)[seg];
  }
  return node;
}

/**
 * Immutable write with structural sharing — only the nodes along `path` are copied.
 * Writing one candidate out of twelve copies four objects, not the whole tree, which is
 * what keeps a re-shape inside a sub-100ms request budget.
 */
export function setAt<T>(root: T, path: StatePath, value: unknown): T {
  if (path.length === 0) return value as T;
  const [head, ...rest] = path;
  if (Array.isArray(root)) {
    const copy = root.slice();
    copy[head as number] = setAt(copy[head as number], rest, value);
    return copy as unknown as T;
  }
  const base = (root ?? {}) as Record<PathSeg, unknown>;
  return { ...base, [head]: setAt(base[head], rest, value) } as T;
}

export type SourceType = "policy" | "contract" | "kb" | "forum";

/** One retrieved passage. Flat by design: no nested `meta`, no union branches. */
export interface Candidate {
  rank: number;
  id: string;
  similarity: number; // computed by the vector index, not by Jev
  ageDays: number;    // computed in code, not by Jev
  sourceType: SourceType;
  title: string;
  passage: string;    // the only untrusted free text in the whole projection
}

/** Deterministic facts the router reads. This namespace is never projected to Jev. */
export interface FastPath {
  entitlements: { plan: "free" | "pro" | "enterprise"; allowsAutoReply: boolean };
  routing: { autoReplyFloor: number; escalateBelow: number; injectionCeiling: number };
}

/** Untrusted text plus the retrieval provenance needed to explain a decision later. */
export interface EvidenceNamespace {
  index: string;
  namespace: string;
  topK: number;
  candidates: Candidate[];
}

/** Scalars code already computed. Sent so the model never has to do arithmetic. */
export interface DerivedNamespace {
  candidateCount: number;
  maxSimilarity: number;
  totalPassageChars: number;
  hasPolicySource: boolean;
}

/** The whole shaped state. Fast-path facts are ours; everything else is shared with Jev. */
export interface ShapedState {
  fastPath: FastPath;
  task: { question: string; locale: string; channel: "email" | "chat" | "api" };
  evidence: EvidenceNamespace;
  derived: DerivedNamespace;
}

/* ---------- selectors: paths as first-class values ---------- */

export const candidatePath = (i: number): StatePath => ["evidence", "candidates", i];
export const passagePath = (i: number): StatePath => [...candidatePath(i), "passage"];
export const TASK_QUESTION: StatePath = ["task", "question"];
export const ALL_CANDIDATES: StatePath = ["evidence", "candidates"];

/**
 * The single choke point between internal state and the model. If a field is not named
 * here, Jev cannot see it — which is how `fastPath` and any future tenant secret stay out
 * of the prompt by construction rather than by discipline.
 */
export function project(state: ShapedState): Record<string, unknown> {
  return {
    task: state.task,
    evidence: state.evidence,
    derived: state.derived,
  };
}
