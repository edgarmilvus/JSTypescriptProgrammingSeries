/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

import { AsyncLocalStorage } from "node:async_hooks";
import { setAt, getAt, type ShapedState, type StatePath } from "./state-shape";

/**
 * Retrieval isolation is physical, not filtered. A Pinecone namespace cannot be crossed by
 * a mis-built filter expression, so tenant separation survives a bad query string.
 */
export const vectorNamespace = (tenantId: string): string => `tenant:${tenantId}`;

export interface ScopeHandle {
  readonly tenantId: string;
  readonly requestId: string;
  readonly state: ShapedState;
  /** Immutable replace with structural sharing. The scope object mutates; the state never does. */
  commit(path: StatePath, value: unknown): void;
  at<T>(path: StatePath): T;
}

const storage = new AsyncLocalStorage<ScopeHandle>();

/**
 * Open a scope for one request. Module-level mutable stores are the classic cross-talk bug:
 * two tenants' requests interleave across `await` points and one reads the other's state.
 * AsyncLocalStorage makes the store follow the async context instead of the module.
 */
export function withScope<T>(
  init: { tenantId: string; requestId: string; fastPath: ShapedState["fastPath"] },
  fn: (scope: ScopeHandle) => Promise<T>,
): Promise<T> {
  let state: ShapedState = {
    fastPath: init.fastPath,
    task: { question: "", locale: "en", channel: "api" },
    evidence: { index: "", namespace: vectorNamespace(init.tenantId), topK: 0, candidates: [] },
    derived: { candidateCount: 0, maxSimilarity: 0, totalPassageChars: 0, hasPolicySource: false },
  } as ShapedState;

  const handle: ScopeHandle = {
    tenantId: init.tenantId,
    requestId: init.requestId,
    get state() {
      return state;
    },
    commit(path, value) {
      state = setAt(state, path, value);
    },
    at<T>(path: StatePath) {
      return getAt(state, path) as T;
    },
  };

  return storage.run(handle, () => fn(handle));
}

/** Read the ambient scope. Throws rather than guessing a default tenant. */
export function currentScope(): ScopeHandle {
  const scope = storage.getStore();
  if (!scope) throw new Error("No Jev scope open: call withScope() at the request boundary.");
  return scope;
}
