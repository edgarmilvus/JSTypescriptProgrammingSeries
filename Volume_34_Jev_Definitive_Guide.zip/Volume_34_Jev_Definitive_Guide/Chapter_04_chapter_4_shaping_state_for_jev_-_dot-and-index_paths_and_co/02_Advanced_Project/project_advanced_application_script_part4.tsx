/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.tsx
// Description: Advanced Application Script
// ==========================================

"use client";

import { useState, useTransition } from "react";
import { answerFromEvidence, type AnswerRoute } from "@/app/actions/answer-from-evidence";

export function EvidencePanel(props: { tenantId: string; plan: "free" | "pro" | "enterprise" }) {
  const [question, setQuestion] = useState("");
  const [route, setRoute] = useState<AnswerRoute | null>(null);
  const [pending, startTransition] = useTransition();

  // `startTransition` keeps the input responsive while the server action runs. The decision
  // itself never runs here, and no fast-path state is shipped to the browser.
  function submit() {
    startTransition(async () => {
      const next = await answerFromEvidence({
        tenantId: props.tenantId,
        requestId: crypto.randomUUID(),
        question,
        locale: navigator.language.slice(0, 2),
        channel: "chat",
        plan: props.plan,
      });
      setRoute(next);
    });
  }

  return (
    <section className="space-y-3">
      <input
        value={question}
        onChange={(event) => setQuestion(event.target.value)}
        placeholder="Ask about your contract or invoice"
        className="w-full rounded border px-3 py-2"
      />
      <button onClick={submit} disabled={pending} className="rounded bg-indigo-600 px-4 py-2 text-white">
        {pending ? "Checking evidence…" : "Ask"}
      </button>

      {route?.kind === "answer" && (
        <p>
          Grounded in <code>{route.passageId}</code> · confidence {route.confidence.toFixed(2)}
          {route.auto ? " · answered automatically" : " · needs a human before it is sent"}
        </p>
      )}
      {route && route.kind !== "answer" && <p>{route.kind}: {route.reason}</p>}
    </section>
  );
}
