/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// ---------- Path type ----------
// A discriminated union is chosen over `string | number` because an object's key "0"
// and an array's index 0 must resolve to different containers. `string | number` cannot
// tell `{ "0": x }` from `[x]` at a path segment; the union can.
export type PathSegment =
  | { readonly kind: "key";   readonly value: string }
  | { readonly kind: "index"; readonly value: number };

export type JevPath = readonly PathSegment[];

// ---------- Errors ----------
export class PathSyntaxError extends Error {
  constructor(message: string, public readonly input: string, public readonly position: number) {
    super(`${message} (at position ${position} in "${input}")`);
    this.name = "PathSyntaxError";
  }
}
export class PathTypeError extends Error {
  constructor(message: string, public readonly path: JevPath, public readonly actual: unknown) {
    super(message);
    this.name = "PathTypeError";
  }
}

// ---------- parsePath ----------
export function parsePath(input: string): JevPath {
  if (input.length === 0) throw new PathSyntaxError("Empty path", input, 0);

  const segments: PathSegment[] = [];
  let i = 0;

  while (i < input.length) {
    // The first character of every iteration must begin a key segment.
    if (input[i] === ".") throw new PathSyntaxError("Leading or double dot", input, i);
    if (input[i] === "[") throw new PathSyntaxError("Bare index with no preceding key", input, i);
    if (input[i] === "]") throw new PathSyntaxError("Unexpected ']'", input, i);

    const keyStart = i;
    while (i < input.length && input[i] !== "." && input[i] !== "[" && input[i] !== "]") i++;
    if (i === keyStart) throw new PathSyntaxError("Expected key", input, i);

    const key = input.slice(keyStart, i);
    if (/^\s|\s$/.test(key)) throw new PathSyntaxError("Key has whitespace at a boundary", input, keyStart);
    segments.push({ kind: "key", value: key });

    // Consume any number of [index] suffixes.
    while (i < input.length && input[i] === "[") {
      const open = i;
      i++; // skip '['
      const digitStart = i;
      while (i < input.length && input[i] !== "]") i++;
      if (i >= input.length) throw new PathSyntaxError("Unterminated bracket", input, open);
      const digits = input.slice(digitStart, i);
      if (!/^\d+$/.test(digits)) {
        throw new PathSyntaxError("Bracket must contain a non-negative integer", input, digitStart);
      }
      i++; // skip ']'
      segments.push({ kind: "index", value: Number(digits) });
    }

    if (i === input.length) break;

    if (input[i] === ".") {
      i++; // skip '.'
      if (i === input.length) throw new PathSyntaxError("Trailing dot", input, i - 1);
    } else if (input[i] === "]") {
      throw new PathSyntaxError("Unexpected ']'", input, i);
    } else {
      // e.g. "foo[0]bar": a key immediately follows an index without a dot.
      throw new PathSyntaxError("Expected '.' or '[' between segments", input, i);
    }
  }

  return segments;
}

// ---------- stringifyPath ----------
export function stringifyPath(path: JevPath): string {
  if (path.length === 0) throw new PathSyntaxError("Cannot stringify empty path", "", 0);
  if (path[0].kind !== "key") {
    throw new PathSyntaxError("Path must begin with a key", "", 0);
  }

  let out = "";
  for (let i = 0; i < path.length; i++) {
    const seg = path[i];
    if (seg.kind === "key") {
      if (seg.value.length === 0 || /[.\[\]\s]/.test(seg.value)) {
        throw new PathSyntaxError(
          `Key ${JSON.stringify(seg.value)} cannot be represented in dot-and-index syntax`,
          "", 0,
        );
      }
      out += i === 0 ? seg.value : "." + seg.value;
    } else {
      if (!Number.isInteger(seg.value) || seg.value < 0) {
        throw new PathSyntaxError("Index must be a non-negative integer", "", 0);
      }
      out += `[${seg.value}]`;
    }
  }
  return out;
}

// ---------- getAtPath ----------
// `Object.hasOwn` distinguishes "property exists with value undefined" from "property missing";
// `in` and `state?.foo?.bar` cannot. `state?.foo?.bar` also stops at falsy values (0, ""),
// skipping a legitimate key on a nested object; the explicit walk below does not.
export function getAtPath(state: unknown, path: JevPath): { found: boolean; value: unknown } {
  let current: unknown = state;
  for (const seg of path) {
    if (current === null || current === undefined) return { found: false, value: undefined };

    if (seg.kind === "key") {
      if (typeof current !== "object" || Array.isArray(current)) {
        return { found: false, value: undefined };
      }
      if (!Object.hasOwn(current, seg.value)) return { found: false, value: undefined };
      current = (current as Record<string, unknown>)[seg.value];
    } else {
      if (!Array.isArray(current)) return { found: false, value: undefined };
      if (seg.value >= current.length) return { found: false, value: undefined };
      current = current[seg.value];
    }
  }
  // A resolved `null` is a real leaf; a resolved `undefined` is reported as not found.
  // Callers that need to distinguish "present-undefined" from "missing" re-walk with hasOwn.
  if (current === undefined) return { found: false, value: undefined };
  return { found: true, value: current };
}

// ---------- setAtPath ----------
function setAt(current: unknown, path: JevPath, index: number, value: unknown): unknown {
  const seg = path[index];
  const isLast = index === path.length - 1;

  if (seg.kind === "key") {
    if (current === undefined) {
      // Auto-create: the recursion below picks object/array based on the NEXT segment's kind.
      return isLast ? { [seg.value]: value } : { [seg.value]: setAt(undefined, path, index + 1, value) };
    }
    if (current === null || typeof current !== "object" || Array.isArray(current)) {
      throw new PathTypeError(
        `Expected object at position ${index}, found ${describe(current)}`,
        path.slice(0, index + 1), current,
      );
    }
    const obj = current as Record<string, unknown>;
    const child = obj[seg.value];
    const next = isLast ? value : setAt(child, path, index + 1, value);
    if (!isLast && next === child && Object.hasOwn(obj, seg.value)) return current;
    return { ...obj, [seg.value]: next };
  }

  if (current === undefined) {
    const arr: unknown[] = [];
    arr[seg.value] = isLast ? value : setAt(undefined, path, index + 1, value);
    return arr;
  }
  if (current === null || !Array.isArray(current)) {
    throw new PathTypeError(
      `Expected array at position ${index}, found ${describe(current)}`,
      path.slice(0, index + 1), current,
    );
  }
  const child = current[seg.value];
  const next = isLast ? value : setAt(child, path, index + 1, value);
  if (!isLast && next === child) return current;
  const copy = current.slice();
  copy[seg.value] = next;
  return copy;
}

export function setAtPath<T>(state: T, path: JevPath, value: unknown): T {
  if (path.length === 0) throw new PathSyntaxError("Cannot set empty path", "", 0);
  return setAt(state, path, 0, value) as T;
}

// ---------- deleteAtPath ----------
function deleteAt(current: unknown, path: JevPath, index: number): unknown {
  if (current === null || current === undefined) return current;
  const seg = path[index];
  const isLast = index === path.length - 1;

  if (seg.kind === "key") {
    if (typeof current !== "object" || Array.isArray(current)) return current;
    const obj = current as Record<string, unknown>;
    if (!Object.hasOwn(obj, seg.value)) return current;
    if (isLast) {
      const { [seg.value]: _removed, ...rest } = obj;
      return rest;
    }
    const child = obj[seg.value];
    const next = deleteAt(child, path, index + 1);
    if (next === child) return current;
    return { ...obj, [seg.value]: next };
  }

  if (!Array.isArray(current) || seg.value >= current.length) return current;
  if (isLast) {
    // `delete arr[i]` would leave a hole (length unchanged, element undefined).
    // `splice` removes and shifts, which is what "delete an index" means here.
    const copy = current.slice();
    copy.splice(seg.value, 1);
    return copy;
  }
  const child = current[seg.value];
  const next = deleteAt(child, path, index + 1);
  if (next === child) return current;
  const copy = current.slice();
  copy[seg.value] = next;
  return copy;
}

export function deleteAtPath<T>(state: T, path: JevPath): T {
  if (path.length === 0) throw new PathSyntaxError("Cannot delete empty path", "", 0);
  return deleteAt(state, path, 0) as T;
}

// ---------- round-trip ----------
// Uses Object.is because `NaN !== NaN` yet two NaNs are the same leaf, and because
// `Object.is(-0, 0) === false` while `-0 === 0`, so signed-zero drift is not silently equal.
export function assertRoundTrips(root: unknown, path: JevPath = []): void {
  walkLeaves(root, root, path);
}

function walkLeaves(root: unknown, current: unknown, path: JevPath): void {
  if (current === null || typeof current !== "object") {
    if (path.length === 0) return;
    const s = stringifyPath(path);
    const parsed = parsePath(s);
    const { found, value } = getAtPath(root, parsed);
    if (!found) throw new Error(`Round-trip: ${s} did not resolve`);
    if (!Object.is(value, current)) throw new Error(`Round-trip: ${s} resolved to a different value`);
    return;
  }
  if (Array.isArray(current)) {
    current.forEach((child, i) => walkLeaves(root, child, [...path, { kind: "index", value: i }]));
  } else {
    for (const key of Object.keys(current as object)) {
      walkLeaves(root, (current as Record<string, unknown>)[key], [...path, { kind: "key", value: key }]);
    }
  }
}

const describe = (v: unknown): string =>
  v === null ? "null" : Array.isArray(v) ? "an array" : typeof v;
