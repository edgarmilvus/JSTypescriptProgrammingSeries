/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { getAtPath, setAtPath, stringifyPath, type JevPath } from "./path";

// ---------- Branded scopes ----------
declare const FAST_BRAND: unique symbol;
declare const GEN_BRAND:  unique symbol;

export type FastState       = Record<string, unknown> & { readonly [FAST_BRAND]: never };
export type GenerativeState = Record<string, unknown> & { readonly [GEN_BRAND]:  never };

export type Scope = "fast" | "generative";
export type StateFor<S extends Scope> = S extends "fast" ? FastState : GenerativeState;

export type DeepReadonly<T> =
  T extends (infer U)[] ? readonly DeepReadonly<U>[]
  : T extends object       ? { readonly [K in keyof T]: DeepReadonly<T[K]> }
  : T;

// A one-way brander. It selects the exact scope-shaped alias, so nothing else is assignable.
const asFast = (v: Record<string, unknown>): FastState => v as FastState;
const asGen  = (v: Record<string, unknown>): GenerativeState => v as GenerativeState;

// ---------- deepFreeze ----------
// Freezing at write time (not read time) is the correct side of the boundary: once the
// listeners have been notified, a subsequent writer could mutate a shared object before
// the listener finishes reading it. Freezing before notifying guarantees that any
// reference a listener holds remains valid for its lifetime.
export function deepFreeze<T>(value: T, seen: Set<object> = new Set()): DeepReadonly<T> {
  if (value === null || typeof value !== "object") return value as DeepReadonly<T>;
  if (seen.has(value as object)) return value as DeepReadonly<T>;
  seen.add(value as object);
  for (const k of Reflect.ownKeys(value as object)) {
    deepFreeze((value as Record<PropertyKey, unknown>)[k], seen);
  }
  return Object.freeze(value) as DeepReadonly<T>;
}

// ---------- ScopedStore ----------
type FastListener = (next: DeepReadonly<FastState>,       prev: DeepReadonly<FastState>)       => void;
type GenListener  = (next: DeepReadonly<GenerativeState>, prev: DeepReadonly<GenerativeState>) => void;

export class ScopedStore {
  private fast: FastState;
  private generative: GenerativeState;

  private readonly listeners = {
    fast: new Set<FastListener>(),
    generative: new Set<GenListener>(),
  };

  constructor(initial: { fast?: FastState; generative?: GenerativeState } = {}) {
    this.fast = deepFreeze(structuredClone(initial.fast ?? {})) as FastState;
    this.generative = deepFreeze(structuredClone(initial.generative ?? {})) as GenerativeState;
  }

  // ---------- read / write ----------
  read<S extends Scope>(scope: S): DeepReadonly<StateFor<S>> {
    return (scope === "fast" ? this.fast : this.generative) as DeepReadonly<StateFor<S>>;
  }

  write<S extends Scope>(
    scope: S,
    updater: (previous: DeepReadonly<StateFor<S>>) => StateFor<S>,
  ): void {
    const current = this.read(scope);
    const next = updater(current);
    const frozen = deepFreeze(next) as StateFor<S>;

    if (scope === "fast") {
      const before = this.fast;
      this.fast = frozen as FastState;
      for (const listener of this.listeners.fast) listener(this.fast, before);
    } else {
      const before = this.generative;
      this.generative = frozen as GenerativeState;
      for (const listener of this.listeners.generative) listener(this.generative, before);
    }
  }

  subscribe<S extends Scope>(scope: S, listener:
    S extends "fast" ? FastListener : GenListener
  ): () => void {
    const set = (scope === "fast" ? this.listeners.fast : this.listeners.generative) as Set<unknown>;
    set.add(listener);
    return () => set.delete(listener);
  }

  // ---------- cross-scope mirroring ----------
  // structuredClone deep-copies plain objects, arrays, Map/Set, Date, RegExp, ArrayBuffer,
  // cycles — but NOT functions, DOM nodes, WeakMap/WeakSet, class prototypes, or own
  // symbol-keyed properties. That last limit is why `mirror` must be called for values
  // that are pure data; anything with methods or symbol keys must be copied by hand.
  mirror(source: Scope, target: Scope, path: JevPath): void {
    const { found, value } = getAtPath(this.read(source), path);
    if (!found) throw new Error(`mirror: no value at ${stringifyPath(path)}`);
    const copy = structuredClone(value);
    this.write(target, (prev) => setAtPath(prev, path, copy));
  }

  // ---------- namespaces ----------
  readNamespace<S extends Scope, N extends keyof StateFor<S> & string>(
    scope: S, namespace: N,
  ): DeepReadonly<StateFor<S>[N]> {
    return (this.read(scope) as DeepReadonly<Record<string, unknown>>)[namespace] as DeepReadonly<StateFor<S>[N]>;
  }

  writeNamespace<S extends Scope, N extends keyof StateFor<S> & string>(
    scope: S, namespace: N,
    updater: (previous: DeepReadonly<StateFor<S>[N]>) => StateFor<S>[N],
  ): void {
    this.write(scope, (prev) => ({
      ...(prev as unknown as Record<string, unknown>),
      [namespace]: updater((prev as unknown as Record<string, unknown>)[namespace] as DeepReadonly<StateFor<S>[N]>),
    }) as StateFor<S>);
  }

  // ---------- session / request boundaries ----------
  fork(): ScopedStore {
    return new ScopedStore({
      fast:       structuredClone(this.fast) as FastState,
      generative: structuredClone(this.generative) as GenerativeState,
    });
  }

  snapshot(scope: Scope): { fast?: DeepReadonly<FastState>; generative?: DeepReadonly<GenerativeState> } {
    return scope === "fast"
      ? { fast: this.read("fast") }
      : { generative: this.read("generative") };
  }

  // ---------- dev-only leak assertion ----------
  // O(n) in reachable objects across the two scopes; the `seen` set makes it safe under
  // cycles and prevents quadratic traversal of shared subtrees *within* one scope.
  assertNoLeaks(): void {
    const fromFast = new Set<object>();
    const fromGen  = new Set<object>();
    collect(this.fast, fromFast);
    collect(this.generative, fromGen);
    for (const obj of fromFast) {
      if (fromGen.has(obj)) {
        throw new Error("ScopedStore leak: object reachable from both `fast` and `generative`");
      }
    }
  }
}

function collect(value: unknown, out: Set<object>): void {
  if (value === null || typeof value !== "object") return;
  if (out.has(value as object)) return;
  out.add(value as object);
  for (const k of Reflect.ownKeys(value as object)) {
    collect((value as Record<PropertyKey, unknown>)[k], out);
  }
}
