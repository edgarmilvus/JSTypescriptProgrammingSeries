/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

"use server";

/**
 * triage.server.ts — Jev-driven inbound triage for a multi-tenant SaaS help desk.
 *
 * One POST to /v1/systemone answers five orthogonal questions:
 *   - department     (Choice) — which team owns the message
 *   - severity       (Score)  — how bad the reported problem is
 *   - is_urgent      (Noul)   — does the message convey time pressure
 *   - contains_pii   (Noul)   — should we refuse to process it at all
 *   - is_threatening (Noul)   — should we short-circuit to safety
 *
 * The platform consumes those five answers — and only those five — by
 * narrowing a five-case discriminated union, `TriageOutcome`. There is no
 * `any`, no optional chaining on untyped response objects, and no shape
 * re-derivation at the call site: the answer type is a mapped type over
 * the question contract, `ResultFor<TriageSpec>`.
 */

import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type ResultFor,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

/* ────────────────────────────────────────────────────────────────────
   §1  Client construction
   ──────────────────────────────────────────────────────────────────── */

/**
 * A single long-lived client. Triage runs on the request path of every
 * inbound message, so the timeout budget is UI-sized, not batch-sized:
 * 1.5 s end-to-end, one retry, and a 75 ms initial backoff.
 */
export const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY!,
  baseURL: process.env.TYPESAFE_BASE_URL,
  defaultModel: "jev-latest",
  timeout: 1_500,
  retry: { maxRetries: 1, backoffInitialMs: 75, respectRetryAfter: true },
});

/* ────────────────────────────────────────────────────────────────────
   §2  Question contract — the single source of truth
   ──────────────────────────────────────────────────────────────────── */

/**
 * The contract we send to Jev. Every key here becomes a key on the
 * response's `answers` map, and every criteria entry becomes a member
 * of a literal union on the corresponding answer.
 */
export const TRIAGE = {
  department: choice("Which team should own this message?", {
    billing: "Charges, invoices, refunds, subscription changes",
    technical: "Bugs, outages, integrations, API or SDK errors",
    account: "Login, password, permissions, profile, security",
    abuse: "Harassment, spam, policy violations, threats",
  }),
  severity: score("How severe is the reported problem?", [
    "Cosmetic — inconvenience only, no user is blocked",
    "Degraded — some users blocked, a workaround exists",
    "Critical — total outage, data loss, or security incident",
  ]),
  is_urgent: noul(
    "Does the message convey time pressure or an active outage?",
    {
      true: "Explicit urgency, deadline, or ongoing incident",
      false: "No time pressure conveyed",
    },
  ),
  contains_pii: noul(
    "Does the message contain unredacted personally identifiable information?",
    {
      true: "Names, emails, payment cards, national IDs, or credentials",
      false: "No PII present",
    },
  ),
  is_threatening: noul(
    "Does the message contain a credible threat or targeted abuse against a person?",
    {
      true: "Credible threat of harm or sustained targeted abuse",
      false: "Critical feedback without threat of harm",
    },
  ),
} as const;

/* ────────────────────────────────────────────────────────────────────
   §3  Answer type — derived, never declared
   ──────────────────────────────────────────────────────────────────── */

/** `typeof TRIAGE`, captured as a named type for readability. */
export type TriageSpec = typeof TRIAGE;

/**
 * The response shape. `ResultFor<Q>` is a conditional type that resolves
 * NoulQuestion → NoulResponse, ScoreQuestion<S> → ScoreResponse<S>, and
 * ChoiceQuestion<E> → ChoiceResponse<E>, preserving every literal key.
 */
export type TriageAnswers = {
  [K in keyof TriageSpec]: ResultFor<TriageSpec[K]>;
};

/** The set of labels Jev may return for `department`. */
export type Department = TriageAnswers["department"]["choice"];

/* ────────────────────────────────────────────────────────────────────
   §4  Outcome union — the four faces of a Jev answer
   ──────────────────────────────────────────────────────────────────── */

/**
 * What the platform actually acts on. Every branch carries a unique
 * `kind`, so downstream code narrows on `kind` with no casts.
 */
export type TriageOutcome =
  | {
      kind: "routed";
      department: Department;
      severity: number;
      urgent: boolean;
      confidence: number;
    }
  | {
      kind: "escalated";
      reason: "threat" | "critical-severity";
      department: Department;
      evidence: number;
    }
  | {
      kind: "abstained";
      reason: "low-confidence";
      department: Department;
      confidence: number;
      clarify: string;
    }
  | { kind: "denied"; reason: "pii-detected"; piiFlag: number }
  | {
      kind: "failed";
      reason: "transport" | "invariant";
      error: string;
    };

/* ────────────────────────────────────────────────────────────────────
   §5  User-defined type guards — for call sites that prefer predicates
   ──────────────────────────────────────────────────────────────────── */

export function isRouted(
  o: TriageOutcome,
): o is Extract<TriageOutcome, { kind: "routed" }> {
  return o.kind === "routed";
}

export function isEscalated(
  o: TriageOutcome,
): o is Extract<TriageOutcome, { kind: "escalated" }> {
  return o.kind === "escalated";
}

export function isActionable(
  o: TriageOutcome,
): o is
  | Extract<TriageOutcome, { kind: "routed" }>
  | Extract<TriageOutcome, { kind: "escalated" }> {
  return isRouted(o) || isEscalated(o);
}

/* ────────────────────────────────────────────────────────────────────
   §6  Narrowing pipeline — reduce five answers to one outcome
   ──────────────────────────────────────────────────────────────────── */

/**
 * The only tunable in the file. Ordering in `classify` is deliberate:
 * safety first, severity second, confidence last. Adding a new gate
 * means adding a branch here, never patching the model call.
 */
const THRESHOLDS = {
  pii: 0.7,
  threat: 0.6,
  severityCritical: 2.0,
  routeMin: 0.55,
} as const;

export function classify(
  result: SystemOneResult<TriageSpec>,
): TriageOutcome {
  const a: TriageAnswers = result.answers;

  // 1. PII sentinel: refuse to touch the payload.
  if (a.contains_pii.noul >= THRESHOLDS.pii) {
    return {
      kind: "denied",
      reason: "pii-detected",
      piiFlag: a.contains_pii.noul,
    };
  }

  // 2. Threat sentinel: page a human before any automated handling.
  if (a.is_threatening.noul >= THRESHOLDS.threat) {
    return {
      kind: "escalated",
      reason: "threat",
      department: a.department.choice,
      evidence: a.is_threatening.noul,
    };
  }

  // 3. Severity gate: everything at "Critical" escalates.
  if (a.severity.score >= THRESHOLDS.severityCritical) {
    return {
      kind: "escalated",
      reason: "critical-severity",
      department: a.department.choice,
      evidence: a.severity.score,
    };
  }

  // 4. Confidence gate: a spread-out distribution abstains.
  if (a.department.confidence < THRESHOLDS.routeMin) {
    return {
      kind: "abstained",
      reason: "low-confidence",
      department: a.department.choice,
      confidence: a.department.confidence,
      clarify: `Confirm routing: "${a.department.choice}"?`,
    };
  }

  // 5. Default: route with full context.
  return {
    kind: "routed",
    department: a.department.choice,
    severity: a.severity.score,
    urgent: a.is_urgent.noul >= THRESHOLDS.threat,
    confidence: a.department.confidence,
  };
}

/* ────────────────────────────────────────────────────────────────────
   §7  Server action — the platform's public entrypoint
   ──────────────────────────────────────────────────────────────────── */

/** The one function a Next.js route handler calls. */
export async function triage(
  message: string,
  tenantId: string,
): Promise<TriageOutcome> {
  try {
    const result = await jev.systemOne({
      state: { message, tenant: tenantId },
      questions: TRIAGE,
      model: "jev-latest",
    });
    return classify(result);
  } catch (err) {
    return {
      kind: "failed",
      reason: "transport",
      error: (err as Error).message,
    };
  }
}
