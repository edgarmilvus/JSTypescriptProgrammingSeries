/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

/* app/api/triage/route.ts — the consuming endpoint */

import { NextResponse } from "next/server";
import { triage } from "@/lib/triage.server";

export async function POST(req: Request) {
  const { message, tenantId } = await req.json();
  const outcome = await triage(message, tenantId);

  // Exhaustive switch: adding a variant to TriageOutcome breaks
  // compilation here unless every case below is updated.
  switch (outcome.kind) {
    case "routed":
      return NextResponse.json({ action: "enqueue", ...outcome });

    case "escalated":
      return NextResponse.json(
        { action: "page_oncall", ...outcome },
        { status: 202 },
      );

    case "abstained":
      return NextResponse.json(
        { action: "clarify", question: outcome.clarify, ...outcome },
        { status: 409 },
      );

    case "denied":
      return NextResponse.json(
        { action: "redact", pii: outcome.piiFlag },
        { status: 403 },
      );

    case "failed":
      return NextResponse.json(
        { action: "replay", error: outcome.error },
        { status: 503 },
      );

    default: {
      // Compile-time exhaustiveness assertion. If `outcome` is not
      // `never` here, the switch is missing a case and TS 5.x rejects
      // the assignment.
      const _exhaustive: never = outcome;
      return _exhaustive;
    }
  }
}
