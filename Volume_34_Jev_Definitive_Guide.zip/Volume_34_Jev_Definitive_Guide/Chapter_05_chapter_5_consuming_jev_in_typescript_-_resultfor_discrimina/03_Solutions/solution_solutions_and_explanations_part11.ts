/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

import { assertNever } from "./assert";
import type { Verdict } from "./types";

// A total map: one handler per discriminant, and each handler sees the narrowed
// variant. The key type comes from the union, and the value type comes from the
// union too. Neither can be widened without a compile error at this declaration.
export type Registry<R> = {
  [K in Verdict["kind"]]: (verdict: Extract<Verdict, { kind: K }>) => R;
};

export const handlers: Registry<string> = {
  allow: (v) => `allow:${v.signal}`,
  review: (v) => `review:${v.queue}`,
  deny: (v) => `deny:${v.policy}`,
  abstain: (v) => `abstain:${v.reason}`,
  error: (v) => `error:${v.message}`,
};

// dispatch narrows the argument once, then calls the corresponding handler.
// The switch is exhaustive over `Verdict["kind"]`, so TypeScript treats the end
// of the function as unreachable and no `default` is required.
export function dispatch(v: Verdict): string {
  switch (v.kind) {
    case "allow":
      return handlers.allow(v);
    case "review":
      return handlers.review(v);
    case "deny":
      return handlers.deny(v);
    case "abstain":
      return handlers.abstain(v);
    case "error":
      return handlers.error(v);
    default:
      return assertNever(v);
  }
}

// The runtime guard runs in the caller's deserialization layer, not inside dispatch.
const VERDICT_KINDS = ["allow", "review", "deny", "abstain", "error"] as const;

// A single, contained `as` narrows `unknown` to the shape we probe. Everything
// outside this helper operates on the fully-typed `Verdict`.
export function isVerdict(x: unknown): x is Verdict {
  if (typeof x !== "object" || x === null) return false;
  if (!("kind" in x)) return false;
  const kind = (x as { kind: unknown }).kind;
  return (VERDICT_KINDS as readonly unknown[]).includes(kind);
}
