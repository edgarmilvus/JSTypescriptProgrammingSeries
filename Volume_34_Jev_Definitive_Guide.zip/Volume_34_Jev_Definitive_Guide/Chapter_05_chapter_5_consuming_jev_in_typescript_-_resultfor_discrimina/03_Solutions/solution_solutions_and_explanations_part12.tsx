/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.tsx
// Description: Solutions and Explanations
// ==========================================

import type { ResultFor, Question } from "@typesafe-ai/sdk";
import * as React from "react";

// The three concrete answer types, hoisted once so the switch body can narrow on them.
export type AnyAnswer = ResultFor<Question>;

export type AnswerViewProps = {
  questionId: string;
  answer: AnyAnswer;
};

export function AnswerView({
  questionId,
  answer,
}: AnswerViewProps): React.ReactElement {
  switch (answer.type) {
    case "noul": {
      // The only `as` in the component, and it is on a style value, not on a field.
      const pct = Math.min(Math.max(answer.noul, 0), 1) * 100;
      return (
        <div data-testid={`answer-${questionId}-noul`}>
          <div
            style={{
              display: "flex",
              height: 8,
              borderRadius: 4,
              overflow: "hidden",
            }}
          >
            <div style={{ width: `${pct}%`, background: "#3b6ea5" }} />
            <div style={{ width: `${100 - pct}%`, background: "#e1e0d9" }} />
          </div>
          <span>{answer.noul.toFixed(2)}</span>
        </div>
      );
    }
    case "choice": {
      const top = Object.entries(answer.probabilities)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 2);
      return (
        <div data-testid={`answer-${questionId}-choice`}>
          <strong>{answer.choice}</strong>
          <ul>
            {top.map(([label, probability]) => (
              <li key={label}>
                {label}: {probability.toFixed(2)}
              </li>
            ))}
          </ul>
        </div>
      );
    }
    case "score": {
      const levels = Object.keys(answer.legend);
      const topLevel = levels.length - 1;
      const nearest = Math.round(answer.score);
      const legendEntry = answer.legend[nearest];
      return (
        <div data-testid={`answer-${questionId}-score`}>
          <strong>{answer.score.toFixed(2)}</strong>
          <span> / {topLevel}</span>
          {typeof legendEntry === "string" ? <div>{legendEntry}</div> : null}
        </div>
      );
    }
    default: {
      const unreachable: never = answer;
      throw new Error(`Unhandled answer type: ${JSON.stringify(unreachable)}`);
    }
  }
}
