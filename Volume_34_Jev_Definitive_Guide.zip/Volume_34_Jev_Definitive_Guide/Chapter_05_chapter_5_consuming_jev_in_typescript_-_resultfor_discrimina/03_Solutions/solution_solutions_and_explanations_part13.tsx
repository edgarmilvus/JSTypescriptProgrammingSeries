/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.tsx
// Description: Solutions and Explanations
// ==========================================

import type { Questions, SystemOneResult } from "@typesafe-ai/sdk";
import * as React from "react";
import { AnswerView, type AnyAnswer } from "./AnswerView";

export type DecisionCardProps<Q extends Questions> = {
  result: SystemOneResult<Q> | null;
  error: Error | null;
  pending: boolean;
  threshold: number;
  onRetry: () => void;
  onAbstain?: (questionId: keyof Q & string, confidence: number) => void;
};

type AbstainHit<Q extends Questions> = { key: keyof Q & string; signal: number };

// Noul answers do not participate in the abstain path; see notes.md.
function confidenceSignal(answer: AnyAnswer): number | null {
  switch (answer.type) {
    case "noul":
      return null;
    case "choice":
    case "score":
      return answer.confidence;
    default: {
      const unreachable: never = answer;
      throw new Error(`Unhandled answer type: ${JSON.stringify(unreachable)}`);
    }
  }
}

// Object.keys widens to `string[]`; this is the one documented cast needed to
// bring the key back to a `keyof Q` for indexed access. See notes.md.
function typedKeys<Q extends Questions>(
  answers: SystemOneResult<Q>["answers"],
): Array<keyof Q & string> {
  return Object.keys(answers) as Array<keyof Q & string>;
}

function findAbstain<Q extends Questions>(
  result: SystemOneResult<Q>,
  threshold: number,
): AbstainHit<Q> | null {
  for (const key of typedKeys(result.answers)) {
    const signal = confidenceSignal(result.answers[key]);
    if (signal !== null && signal < threshold) return { key, signal };
  }
  return null;
}

export function DecisionCard<Q extends Questions>({
  result,
  error,
  pending,
  threshold,
  onRetry,
  onAbstain,
}: DecisionCardProps<Q>): React.ReactElement {
  const abstain = result ? findAbstain(result, threshold) : null;
  const abstainKey = abstain?.key;
  const abstainSignal = abstain?.signal;

  React.useEffect(() => {
    if (abstainKey !== undefined && abstainSignal !== undefined) {
      onAbstain?.(abstainKey, abstainSignal);
    }
    // Keyed on the abstain identity, not on `onAbstain` — see notes.md.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [abstainKey, abstainSignal]);

  if (pending) {
    return (
      <div data-testid="decision-card-pending">
        <div style={{ height: 80, background: "#eee", borderRadius: 8 }} />
      </div>
    );
  }

  if (error) {
    return (
      <div data-testid="decision-card-error">
        <p>{error.message}</p>
        <button type="button" onClick={onRetry}>
          Retry
        </button>
      </div>
    );
  }

  if (!result) {
    return <div data-testid="decision-card-empty" />;
  }

  if (abstain) {
    return (
      <div data-testid="decision-card-abstain">
        <h3>Sent to human review</h3>
        <p>
          Question <code>{String(abstain.key)}</code> fell below the review
          threshold (signal {abstain.signal.toFixed(2)} &lt; {threshold.toFixed(2)}).
        </p>
        <div style={{ opacity: 0.6 }}>
          Best guess:{" "}
          <AnswerView
            questionId={String(abstain.key)}
            answer={result.answers[abstain.key]}
          />
        </div>
      </div>
    );
  }

  return (
    <div data-testid="decision-card">
      {typedKeys(result.answers).map((key) => (
        <div key={String(key)} style={{ marginBottom: 12 }}>
          <label>{String(key)}</label>
          <AnswerView questionId={String(key)} answer={result.answers[key]} />
        </div>
      ))}
    </div>
  );
}
