/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.tsx
// Description: Solutions and Explanations
// ==========================================

import type { Questions, SystemOneResult } from "@typesafe-ai/sdk";
import { render, screen, fireEvent } from "@testing-library/react";
import * as React from "react";
import { describe, expect, it, vi } from "vitest";
import { DecisionCard } from "./DecisionCard";

// Synthetic question set: one of each answer type.
const QUESTIONS = {
  urgency: { type: "noul" } as const,
  department: { type: "choice" } as const,
  frustration: { type: "score" } as const,
} satisfies Questions;

type Q = typeof QUESTIONS;

const resultWith = (
  overrides: Partial<Record<keyof Q, unknown>> = {},
): SystemOneResult<Q> =>
  ({
    model: "test",
    usage: { input_tokens: 0, output_tokens: 0 },
    answers: {
      urgency: { type: "noul", noul: 0.87, ...overrides.urgency },
      department: {
        type: "choice",
        choice: "billing",
        confidence: 0.9,
        probabilities: { billing: 0.9, technical: 0.1 },
        ...overrides.department,
      },
      frustration: {
        type: "score",
        score: 1.3,
        confidence: 0.8,
        legend: { "0": "Calm", "1": "Frustrated", "2": "Very angry" },
        probabilities: { "0": 0, "1": 0.7, "2": 0.3 },
        ...overrides.frustration,
      },
    },
  }) as SystemOneResult<Q>;

describe("<DecisionCard/>", () => {
  it("renders the pending skeleton", () => {
    render(
      <DecisionCard
        result={null}
        error={null}
        pending
        threshold={0.6}
        onRetry={() => {}}
      />,
    );
    expect(screen.getByTestId("decision-card-pending")).toBeDefined();
  });

  it("renders the error banner and fires onRetry", () => {
    const onRetry = vi.fn();
    render(
      <DecisionCard
        result={null}
        error={new Error("boom")}
        pending={false}
        threshold={0.6}
        onRetry={onRetry}
      />,
    );
    expect(screen.getByTestId("decision-card-error").textContent).toContain("boom");
    fireEvent.click(screen.getByRole("button", { name: "Retry" }));
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it("renders each answer on the fast path", () => {
    render(
      <DecisionCard
        result={resultWith()}
        error={null}
        pending={false}
        threshold={0.6}
        onRetry={() => {}}
      />,
    );
    expect(screen.getByTestId("answer-urgency-noul")).toBeDefined();
    expect(screen.getByTestId("answer-department-choice")).toBeDefined();
    expect(screen.getByTestId("answer-frustration-score")).toBeDefined();
  });

  it("flips into abstain when a confidence signal falls below threshold", () => {
    const { rerender } = render(
      <DecisionCard
        result={resultWith({ department: { confidence: 0.55 } })}
        error={null}
        pending={false}
        threshold={0.6}
        onRetry={() => {}}
      />,
    );
    expect(screen.getByTestId("decision-card-abstain")).toBeDefined();

    rerender(
      <DecisionCard
        result={resultWith({ department: { confidence: 0.55 } })}
        error={null}
        pending={false}
        threshold={0.4}
        onRetry={() => {}}
      />,
    );
    expect(screen.getByTestId("decision-card")).toBeDefined();
  });

  it("fires onAbstain once per abstain mount", () => {
    const onAbstain = vi.fn();
    const { rerender } = render(
      <DecisionCard
        result={resultWith({ department: { confidence: 0.55 } })}
        error={null}
        pending={false}
        threshold={0.6}
        onRetry={() => {}}
        onAbstain={onAbstain}
      />,
    );
    rerender(
      <DecisionCard
        result={resultWith({ department: { confidence: 0.55 } })}
        error={null}
        pending={false}
        threshold={0.6}
        onRetry={() => {}}
        onAbstain={onAbstain}
      />,
    );
    expect(onAbstain).toHaveBeenCalledTimes(1);
  });

  it("exposes answer fields to callers without a cast", () => {
    const result = resultWith();
    // Type-only: this must type-check with no `as`.
    const noul: number = result.answers.urgency.noul;
    const choice: string = result.answers.department.choice;
    const score: number = result.answers.frustration.score;
    expect([noul, choice, score].every((v) => v !== undefined)).toBe(true);
  });
});
