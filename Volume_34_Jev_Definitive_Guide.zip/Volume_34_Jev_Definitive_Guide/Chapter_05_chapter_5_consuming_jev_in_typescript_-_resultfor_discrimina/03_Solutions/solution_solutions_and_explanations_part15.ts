/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part15.ts
// Description: Solutions and Explanations
// ==========================================

import type { SystemOneResult } from "@typesafe-ai/sdk";
import { choice, noul, score } from "@typesafe-ai/sdk";

export const TRIAGE_QUESTIONS = {
  intent: choice("What is the user trying to do?", {
    check_balance: "View account balance.",
    approve_transfer: "Approve the pending withdrawal request.",
    product_question: "Ask about a product or its documentation.",
    order_status: "Ask about the status of an existing order.",
    support: "Get help with an issue that does not fit the others.",
  }),
  complexity: score("How complex is this request?", [
    "Trivial: a single lookup answers it.",
    "Moderate: one product specialist can handle it.",
    "Complex: requires multiple specialists.",
    "Escalation: requires a senior or human decision.",
  ]),
  urgently_frustrated: noul(
    "Does the user express urgency or frustration?",
    { true: "The wording carries urgency, frustration, or churn risk.", false: "The wording is calm and non-urgent." },
  ),
} as const;

export type TriageQuestions = typeof TRIAGE_QUESTIONS;
export type TriageResult = SystemOneResult<TriageQuestions>;
export type TriageKeys = keyof TriageQuestions;

// The union downstream handlers narrow over. Each variant carries the payload
// its handler needs; nothing extra, nothing missing.
export type RouteDecision =
  | { kind: "deterministic"; intent: "check_balance" | "order_status" }
  | { kind: "specialist"; intent: "product_question"; specialist: string }
  | {
      kind: "human";
      reason: "low_confidence" | "escalation_score";
      detail: TriageKeys | string;
    }
  | { kind: "support"; intent: "support"; urgency: number };

export type ThresholdMap<A extends Record<string, unknown>> = {
  readonly [K in keyof A]: { readonly review: number; readonly action: number };
};
