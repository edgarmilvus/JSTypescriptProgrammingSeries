/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part17.ts
// Description: Solutions and Explanations
// ==========================================

import type {
  ChoiceResponse,
  NoulResponse,
  ScoreResponse,
} from "@typesafe-ai/sdk";
import { assertExhaustive } from "./assert";
import type {
  RouteDecision,
  ThresholdMap,
  TriageResult,
  TriageQuestions,
} from "./types";

// The three concrete answer types, hoisted once for the signal computation.
type AnyAnswer = NoulResponse | ChoiceResponse | ScoreResponse;

// The documented convention: for a Noul, the signal is the noul probability itself.
// This treats the noul as if it were a confidence; see notes.md for why this is a
// choice and not an equivalence.
function signalOf(answer: AnyAnswer): number {
  switch (answer.type) {
    case "noul":
      return answer.noul;
    case "choice":
    case "score":
      return answer.confidence;
    default: {
      const unreachable: never = answer;
      throw new Error(`Unhandled answer type: ${JSON.stringify(unreachable)}`);
    }
  }
}

const KEYS = ["intent", "complexity", "urgently_frustrated"] as const;
type Key = (typeof KEYS)[number];

export function routeTicket(
  result: TriageResult,
  thresholds: ThresholdMap<TriageQuestions>,
): RouteDecision {
  // 1. Confidence gate: any answer below its action threshold routes to a human.
  for (const key of KEYS) {
    const answer = result.answers[key];
    if (signalOf(answer) < thresholds[key].action) {
      return { kind: "human", reason: "low_confidence", detail: key };
    }
  }

  // 2. Escalation check runs BEFORE the specialist branch. A top-level complexity
  //    score overrides every downstream route, including product_question.
  const complexity = result.answers.complexity;
  if (complexity.score >= 3) {
    return {
      kind: "human",
      reason: "escalation_score",
      detail: "complexity score at top level",
    };
  }

  // 3. Intent narrowing. The choice field is a literal union; the compiler proves
  //    the branch set is total.
  const intent = result.answers.intent;
  switch (intent.choice) {
    case "check_balance":
    case "order_status":
      return { kind: "deterministic", intent: intent.choice };
    case "product_question":
      return {
        kind: "specialist",
        intent: "product_question",
        specialist: "PRODUCT_SPECIALIST",
      };
    case "support":
      return {
        kind: "support",
        intent: "support",
        urgency: result.answers.urgently_frustrated.noul,
      };
    case "approve_transfer":
      // Account actions are a human decision by policy, not a model decision.
      return {
        kind: "human",
        reason: "escalation_score",
        detail: "account action requires human approval",
      };
    default:
      return assertExhaustive(intent.choice);
  }
}
