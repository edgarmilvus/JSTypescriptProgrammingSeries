/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part19.ts
// Description: Solutions and Explanations
// ==========================================

import type { SystemOneResult } from "@typesafe-ai/sdk";
import { describe, expect, it } from "vitest";
import { dispatch } from "./dispatch";
import { routeTicket } from "./routeTicket";
import type { ThresholdMap, TriageQuestions, TriageResult } from "./types";
import { TRIAGE_QUESTIONS } from "./types";

const thresholds: ThresholdMap<TriageQuestions> = {
  intent: { review: 0.6, action: 0.5 },
  complexity: { review: 0.6, action: 0.5 },
  urgently_frustrated: { review: 0.6, action: 0.5 },
};

type Intent = keyof (typeof TRIAGE_QUESTIONS)["intent"]["criteria"];

function makeResult(
  intent: Intent,
  complexityScore: number,
  urgencies: { complexity: number; intent: number; noul: number },
  noulValue = 0.5,
): TriageResult {
  return {
    model: "jev-latest",
    usage: { input_tokens: 0, output_tokens: 0 },
    answers: {
      intent: {
        type: "choice",
        choice: intent,
        confidence: urgencies.intent,
        probabilities: { [intent]: urgencies.intent },
      },
      complexity: {
        type: "score",
        score: complexityScore,
        confidence: urgencies.complexity,
        legend: { "0": "Trivial", "1": "Moderate", "2": "Complex", "3": "Escalation" },
        probabilities: { [String(Math.round(complexityScore))]: urgencies.complexity },
      },
      urgently_frustrated: {
        type: "noul",
        noul: noulValue,
      },
    },
  } as SystemOneResult<TriageQuestions>;
}

describe("routeTicket", () => {
  const high = { intent: 0.9, complexity: 0.9, noul: 0.9 };

  it("routes check_balance to deterministic", () => {
    expect(routeTicket(makeResult("check_balance", 0.2, high), thresholds)).toEqual({
      kind: "deterministic",
      intent: "check_balance",
    });
  });

  it("routes product_question to specialist", () => {
    expect(routeTicket(makeResult("product_question", 1.5, high), thresholds)).toEqual({
      kind: "specialist",
      intent: "product_question",
      specialist: "PRODUCT_SPECIALIST",
    });
  });

  it("escalates a top-level complexity score before the specialist branch", () => {
    expect(routeTicket(makeResult("product_question", 3.0, high), thresholds)).toEqual({
      kind: "human",
      reason: "escalation_score",
      detail: "complexity score at top level",
    });
  });

  it("routes low-confidence answers to a human with the correct detail key", () => {
    const result = makeResult("check_balance", 0.2, {
      intent: 0.2,
      complexity: 0.9,
      noul: 0.9,
    });
    expect(routeTicket(result, thresholds)).toEqual({
      kind: "human",
      reason: "low_confidence",
      detail: "intent",
    });
  });

  it("carries urgency as the raw noul value on the support route", () => {
    const result = makeResult("support", 1.0, high, 0.82);
    expect(routeTicket(result, thresholds)).toEqual({
      kind: "support",
      intent: "support",
      urgency: 0.82,
    });
  });

  // Compile-only test: to verify exhaustiveness of `dispatch`, temporarily write
  // a helper `function exhaustive(d: RouteDecision): never { switch (d.kind) {...} }`
  // and omit one case. The compiler must refuse the missing return; the error goes
  // away the moment the case is restored. This test file does not commit the broken
  // version.
});

describe("dispatch", () => {
  it("resolves for every route", async () => {
    await expect(
      dispatch({ kind: "deterministic", intent: "check_balance" }),
    ).resolves.toBeUndefined();
    await expect(
      dispatch({ kind: "human", reason: "low_confidence", detail: "intent" }),
    ).resolves.toBeUndefined();
  });
});
