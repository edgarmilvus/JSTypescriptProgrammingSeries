/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import type { AnyAnswer } from "./keys";

// Pure: no logging, no I/O, no dependency on the SDK beyond shapes.
export function describeAnswer(answer: AnyAnswer): string {
  switch (answer.type) {
    case "noul":
      return `noul:${answer.noul.toFixed(3)}`;
    case "choice":
      return `choice:${answer.choice}@${answer.confidence.toFixed(2)}`;
    case "score": {
      const top = Object.keys(answer.legend).length - 1;
      // `legend` is keyed by number, so the arithmetic is safe here.
      return `score:${answer.score}/${top}/${answer.confidence.toFixed(2)}`;
    }
    default: {
      // Assignment to `never` is the check; no `as never` needed.
      const unreachable: never = answer;
      throw new Error(`Unhandled answer type: ${JSON.stringify(unreachable)}`);
    }
  }
}

// --- The map form. A total map keyed by the answer's discriminant, with each
// --- entry narrowed to the variant it handles. Adding a fourth variant to the
// --- union breaks the map at compile time.
type DescribeFns = {
  [K in AnyAnswer["type"]]: (answer: Extract<AnyAnswer, { type: K }>) => string;
};

const DESCRIBERS: DescribeFns = {
  noul: (a) => `noul:${a.noul.toFixed(3)}`,
  choice: (a) => `choice:${a.choice}@${a.confidence.toFixed(2)}`,
  score: (a) => {
    const top = Object.keys(a.legend).length - 1;
    return `score:${a.score}/${top}/${a.confidence.toFixed(2)}`;
  },
};

// Switch-free dispatch: the map holds the behaviour, the ladder holds the narrowing.
export function describeAnswerDispatch(answer: AnyAnswer): string {
  const { type } = answer;
  if (type === "noul") return DESCRIBERS.noul(answer);
  if (type === "choice") return DESCRIBERS.choice(answer);
  if (type === "score") return DESCRIBERS.score(answer);
  const unreachable: never = answer;
  throw new Error(`Unhandled answer type: ${JSON.stringify(unreachable)}`);
}
