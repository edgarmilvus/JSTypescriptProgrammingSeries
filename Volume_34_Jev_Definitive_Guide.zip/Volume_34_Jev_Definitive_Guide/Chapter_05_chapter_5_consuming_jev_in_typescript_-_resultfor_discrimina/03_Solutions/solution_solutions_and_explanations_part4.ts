/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { describe, expect, expectTypeOf, it } from "vitest";
import type { AnyAnswer, ChoiceAnswer, NoulAnswer, ScoreAnswer } from "./keys";
import { describeAnswer, describeAnswerDispatch } from "./describe";
import { hasConfidence } from "./guards";

describe("AnyAnswer resolution", () => {
  it("is exactly the union of the three response types", () => {
    expectTypeOf<AnyAnswer>().toEqualTypeOf<
      NoulAnswer | ChoiceAnswer | ScoreAnswer
    >();
  });
});

const noul: NoulAnswer = { type: "noul", noul: 0.8765 };
const choice: ChoiceAnswer = {
  type: "choice",
  choice: "billing",
  confidence: 0.8234,
  probabilities: { billing: 0.82, technical: 0.18 },
};
const score: ScoreAnswer = {
  type: "score",
  score: 1.3,
  confidence: 0.5412,
  legend: { "0": "Calm", "1": "Frustrated", "2": "Very angry" },
  probabilities: { "0": 0, "1": 0.7, "2": 0.3 },
};

describe.each([
  ["describeAnswer", describeAnswer],
  ["describeAnswerDispatch", describeAnswerDispatch],
])("%s", (_name, fn) => {
  it("renders a noul answer", () => expect(fn(noul)).toBe("noul:0.877"));
  it("renders a choice answer", () =>
    expect(fn(choice)).toBe("choice:billing@0.82"));
  it("renders a score answer", () => expect(fn(score)).toBe("score:1.3/2/0.54"));
});

describe("hasConfidence", () => {
  it("narrows to ChoiceAnswer | ScoreAnswer", () => {
    const answer: AnyAnswer = noul;
    if (hasConfidence(answer)) {
      // Post-narrowing: `.confidence` is a number, not `number | undefined`.
      expectTypeOf(answer.confidence).toEqualTypeOf<number>();
    } else {
      // Negative branch: the compiler knows this can only be a NoulAnswer.
      expectTypeOf(answer.noul).toEqualTypeOf<number>();
    }
  });
});
