/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

import { assertNever } from "./assert";
import type {
  Allow,
  AnyAnswer,
  Deny,
  Review,
  ThresholdConfig,
  Verdict,
} from "./types";

export function isActionable(v: Verdict): v is Allow | Review | Deny {
  switch (v.kind) {
    case "allow":
    case "review":
    case "deny":
      return true;
    case "abstain":
    case "error":
      return false;
    default:
      return assertNever(v);
  }
}

export function isDenial(v: Verdict): v is Deny {
  switch (v.kind) {
    case "deny":
      return true;
    case "allow":
    case "review":
    case "abstain":
    case "error":
      return false;
    default:
      return assertNever(v);
  }
}

export function verdictFromAnswer(
  answer: AnyAnswer,
  thresholds: ThresholdConfig,
): Verdict {
  switch (answer.type) {
    case "noul": {
      // Noul has no `confidence`; its own probability is the only signal available.
      const signal = answer.noul;
      if (signal <= thresholds.noulAllowMax) {
        return { kind: "allow", reason: "noul-below-allow", signal };
      }
      if (signal >= thresholds.noulDenyMin) {
        return {
          kind: "deny",
          reason: thresholds.denyReason,
          policy: thresholds.denyPolicy,
        };
      }
      return {
        kind: "review",
        reason: "noul-in-review-band",
        signal,
        queue: "general",
      };
    }
    case "choice": {
      const signal = answer.confidence;
      if (signal >= thresholds.choiceAbstainMin) {
        return { kind: "allow", reason: "choice-confident", signal };
      }
      return { kind: "abstain", reason: "choice-below-abstain-threshold" };
    }
    case "score": {
      const signal = answer.confidence;
      if (signal >= thresholds.scoreAbstainMin) {
        return { kind: "allow", reason: "score-confident", signal };
      }
      return { kind: "abstain", reason: "score-below-abstain-threshold" };
    }
    default:
      return assertNever(answer);
  }
}

export function severityScore(v: Verdict): number {
  switch (v.kind) {
    case "allow":
      return 0;
    case "abstain":
      return 1;
    case "error":
      return 2;
    case "review":
      return 3;
    case "deny":
      return 4;
    default:
      return assertNever(v);
  }
}
