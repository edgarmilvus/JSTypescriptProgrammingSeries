/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

import { describe, expect, it } from "vitest";
import type { NoulResponse, ChoiceResponse, ScoreResponse } from "@typesafe-ai/sdk";
import { planRoute } from "./route";
import type { ThresholdConfig, Verdict } from "./types";
import { isActionable, isDenial, severityScore, verdictFromAnswer } from "./verdict";

const thresholds: ThresholdConfig = {
  noulAllowMax: 0.2,
  noulDenyMin: 0.8,
  choiceAbstainMin: 0.6,
  scoreAbstainMin: 0.5,
  denyPolicy: "policy-42",
  denyReason: "high-risk",
};

const noul = (n: number): NoulResponse => ({ type: "noul", noul: n });
const choice = (c: number): ChoiceResponse => ({
  type: "choice",
  choice: "x",
  confidence: c,
  probabilities: { x: c, y: 1 - c },
});
const score = (c: number): ScoreResponse => ({
  type: "score",
  score: 1,
  confidence: c,
  legend: { "0": "a", "1": "b" },
  probabilities: { "0": 1 - c, "1": c },
});

it.each([
  [noul(0.1), "allow"],
  [noul(0.9), "deny"],
  [noul(0.5), "review"],
  [choice(0.7), "allow"],
  [choice(0.3), "abstain"],
  [score(0.8), "allow"],
  [score(0.2), "abstain"],
] as const)("verdictFromAnswer(%j) -> %s", (answer, expected) => {
  expect(verdictFromAnswer(answer, thresholds).kind).toBe(expected);
});

it.each([
  ["allow", 0], ["abstain", 1], ["error", 2], ["review", 3], ["deny", 4],
] as const)("severityScore(%s) -> %d", (kind, expected) => {
  const v = {
    allow: { kind: "allow", reason: "r", signal: 0 },
    abstain: { kind: "abstain", reason: "r" },
    error: { kind: "error", message: "m" },
    review: { kind: "review", reason: "r", signal: 0, queue: "general" },
    deny: { kind: "deny", reason: "r", policy: "p" },
  }[kind] as Verdict;
  expect(severityScore(v)).toBe(expected);
});

describe("planRoute", () => {
  it("uses isDenial for the block path", () => {
    expect(
      planRoute({ kind: "deny", reason: "r", policy: "p" }),
    ).toEqual({ kind: "block", policy: "p" });
  });
  it("uses isActionable to keep abstentions and errors off the auto path", () => {
    expect(planRoute({ kind: "abstain", reason: "r" })).toEqual({ kind: "manual" });
    expect(planRoute({ kind: "error", message: "m" })).toEqual({ kind: "manual" });
  });
});

// --- Compile-only check: temporarily edit types.ts to add a sixth variant
// --- `export type Warn = { kind: "warn"; reason: string }` and add it to the
// --- Verdict union. Save. `severityScore` must fail with
// --- "Argument of type 'Warn' is not assignable to parameter of type 'never'"
// --- at the `assertNever(v)` line. Remove the sixth variant when done.

describe("guards narrow", () => {
  it("isActionable narrows Verdict to Allow | Review | Deny", () => {
    const v: Verdict = { kind: "review", reason: "", signal: 0, queue: "general" };
    if (isActionable(v)) {
      // In this branch, consumer code may read v.queue with no further narrowing.
      expect(typeof v.queue).toBe("string");
    }
  });
  it("isDenial narrows Verdict to Deny", () => {
    const v: Verdict = { kind: "deny", reason: "r", policy: "p" };
    if (isDenial(v)) expect(v.policy).toBe("p");
  });
});
