/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part8.ts
// Description: Practical Exercises
// ==========================================

import {
  choice,
  noul,
  score,
  TypeSafeClient,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

const client = new TypeSafeClient();

export const TRIAGE_QUESTIONS = {
  intent: choice("What is the user trying to do?", {
    check_balance: "View account balance.",
    approve_transfer: "Approve the pending withdrawal request.",
    product_question: "Ask about a product or its documentation.",
    order_status: "Ask about the status of an existing order.",
    support: "Get help with an issue that does not fit the others.",
  }),
  complexity: score("How complex is this request?", [
    "Trivial: a single lookup answers it.",
    "Moderate: one product specialist can handle it.",
    "Complex: requires multiple specialists.",
    "Escalation: requires a senior or human decision.",
  ]),
  urgently_frustrated: noul(
    "Does the user express urgency or frustration?",
    {
      true: "The wording carries urgency, frustration, or churn risk.",
      false: "The wording is calm and non-urgent.",
    },
  ),
} as const;
