/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * triage.ts — Chapter 6, Basic Code Example.
 *
 * One incoming support ticket is classified by Jev in a single request.
 * The application reads the calibrated `confidence` on the routing question
 * and picks one of three actions from it. No prompt engineering, no JSON
 * parsing, no hand-rolled retries.
 *
 * Requirements
 *   npm install @typesafe-ai/sdk
 *   export TYPESAFE_API_KEY=...
 *   Node 20+ (uses top-level `await` inside `main`).
 */

import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type ChoiceResponse,
  type NoulResponse,
  type ScoreResponse,
} from "@typesafe-ai/sdk";

/* ------------------------------------------------------------------ *
 * 1. The client                                                       *
 * ------------------------------------------------------------------ */

/**
 * One client for the lifetime of the process. The constructor reads
 * `TYPESAFE_API_KEY` from the environment and defaults to `jev-latest`.
 * The SDK retries 429s and 5xx responses with exponential backoff using
 * each response's `Retry-After` header, so this file never has to think
 * about rate limits or flaky networks.
 */
const typesafe = new TypeSafeClient();

/* ------------------------------------------------------------------ *
 * 2. The question definitions                                         *
 * ------------------------------------------------------------------ */

/**
 * The `criteria` map is the *entire* answer space for a Choice question.
 * The keys become the returned `choice` value and the values are short
 * rubrics Jev reads when deciding between them. Keep them contrastive:
 * state what each option is, and where useful, what it is *not*.
 */
const TOPIC_CRITERIA = {
  billing:
    "Payment, invoicing, subscription, refund, or charge questions.",
  technical:
    "Bugs, integration errors, outages, or unexpected behavior.",
  account:
    "Login, password, permissions, or profile changes.",
} as const;

/**
 * A Score rubric is an *ordered* array of levels from low to high. Jev
 * returns a probability over each level, and `score` is the probability-
 * weighted position on the 0..len-1 scale. The level descriptions
 * describe *situations*, not degrees — Jev reads them one at a time, so
 * "moderately frustrated" means nothing to it.
 */
const FRUSTRATION_LEVELS = [
  "Calm and matter-of-fact.",
  "Frustrated but civil.",
  "Very angry, using strong language or threatening to leave.",
] as const;

/* ------------------------------------------------------------------ *
 * 3. The state                                                        *
 * ------------------------------------------------------------------ */

/**
 * The state is whatever the questions are about. Use an object with
 * named fields whenever the ticket has more than one part worth pointing
 * at. Questions can then reference a field by path (`customer.plan`)
 * instead of re-describing it in prose, and you get structured input
 * without writing a template string.
 */
interface Ticket {
  message: string;
  customer: {
    plan: "free" | "growth" | "enterprise";
    account_age_days: number;
  };
}

const sampleTicket: Ticket = {
  message:
    "I've been trying to connect my Stripe account for 3 days and it " +
    "keeps failing. I'm losing sales. This is unacceptable, please fix " +
    "this ASAP.",
  customer: {
    plan: "growth",
    account_age_days: 412,
  },
};

/* ------------------------------------------------------------------ *
 * 4. The request                                                      *
 * ------------------------------------------------------------------ */

/**
 * The answers object is typed from the questions object. `topic` comes
 * back as a `ChoiceResponse`, `frustration` as a `ScoreResponse`, and
 * `is_urgent` as a `NoulResponse`. We name the shape explicitly so the
 * downstream decision code has a stable interface to depend on.
 */
type TriageAnswers = {
  topic: ChoiceResponse<typeof TOPIC_CRITERIA>;
  is_urgent: NoulResponse;
  frustration: ScoreResponse<typeof FRUSTRATION_LEVELS>;
};

async function askJev(ticket: Ticket): Promise<TriageAnswers> {
  /**
   * One `systemOne` call. Every question in the map is evaluated in
   * parallel against the same state; the three questions cost roughly
   * what one question costs.
   */
  const response = await typesafe.systemOne({
    state: ticket,
    questions: {
      topic: choice(
        "Which team should handle this ticket?",
        TOPIC_CRITERIA,
      ),
      is_urgent: noul(
        "Does this message convey urgency or time-sensitivity?",
      ),
      frustration: score(
        "How frustrated does the customer appear?",
        FRUSTRATION_LEVELS,
      ),
    },
  });

  return response.answers;
}

/* ------------------------------------------------------------------ *
 * 5. The action                                                       *
 * ------------------------------------------------------------------ */

/**
 * These constants encode *policy*, not model behavior. They say how much
 * certainty the application demands before it is willing to act on a Jev
 * answer. They can be changed without touching the model or the
 * questions — that separation is the whole point of this chapter.
 */
const AUTO_ACCEPT = 0.85; // at or above this, act with no human in the loop
const HUMAN_REVIEW = 0.55; // below this, do not act at all — hand off

type Queue = keyof typeof TOPIC_CRITERIA;

type Routing =
  | { action: "auto_route"; queue: Queue; confidence: number }
  | { action: "review"; queue: Queue; confidence: number }
  | { action: "escalate"; confidence: number };

/**
 * Turn one Jev answer set into one action. This function is pure: given
 * the same answers and the same thresholds, it always returns the same
 * routing. There is no hidden state and no second model call — the
 * application owns the last word.
 */
function decide(answers: TriageAnswers): Routing {
  const confidence = answers.topic.confidence;

  // Low confidence: Jev does not have a clear read on the topic. Do not
  // guess. Hand the ticket off entirely — to a human reviewer, or to a
  // slower, reasoning-flavored LLM if this application has one.
  if (confidence < HUMAN_REVIEW) {
    return { action: "escalate", confidence };
  }

  // High confidence and a calm customer: safe to act automatically. The
  // frustration bar is a second gate — being sure about the topic is not
  // the same as being sure a human should not see the ticket first.
  if (confidence >= AUTO_ACCEPT && answers.frustration.score < 1.5) {
    return { action: "auto_route", queue: answers.topic.choice, confidence };
  }

  // The middle band: route the ticket, but flag it for a human to
  // confirm before anything irreversible happens.
  return { action: "review", queue: answers.topic.choice, confidence };
}

/* ------------------------------------------------------------------ *
 * 6. Run it                                                           *
 * ------------------------------------------------------------------ */

async function main(): Promise<void> {
  const answers = await askJev(sampleTicket);
  const routing = decide(answers);

  console.log("── Jev's answers ─────────────────────────────");
  console.log(
    "topic:      ",
    answers.topic.choice,
    `(p=${answers.topic.probabilities[answers.topic.choice]?.toFixed(3)},`,
    `conf=${answers.topic.confidence.toFixed(3)})`,
  );
  console.log("is_urgent:  ", answers.is_urgent.noul.toFixed(3));
  console.log(
    "frustration:",
    answers.frustration.score.toFixed(3),
    `(conf=${answers.frustration.confidence.toFixed(3)})`,
  );
  console.log("── Routing decision ──────────────────────────");
  console.log(routing);
}

main().catch((err: unknown) => {
  console.error("triage failed:", err);
  process.exit(1);
});
