/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

"use server";

import {
  TypeSafeClient,
  choice,
  noul,
  score,
  APIError,
  type SystemOneResult,
  type ChoiceAnswer,
  type NoulAnswer,
  type ScoreAnswer,
} from "@typesafe-ai/sdk";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";

/**
 * Single process-wide client. The SDK retries 429/5xx with backoff by default
 * (maxRetries: 2, backoffInitialMs: 500, backoffMaxMs: 5000, jitter 0.25), so
 * no retry logic belongs in callers.
 */
const jev = new TypeSafeClient({ defaultModel: "jev-latest" });

/**
 * One question per atomic judgment. Jev evaluates them in parallel against
 * the same `state`; adding questions costs tokens, not latency.
 */
const TRIAGE_QUESTIONS = {
  topic: choice("Which team should handle `ticket.message`?", {
    billing: { what: "Charges, refunds, subscription changes", not_for: "Order tracking" },
    orders: { what: "Order status, delivery, cancellation", not_for: "Charges or refunds" },
    account: { what: "Login, profile, permissions, security", not_for: "Orders or charges" },
  }),
  refund_requested: noul(
    "Does `ticket.message` explicitly request a refund or credit?",
    { true: "Directly asks for money back or an account credit", false: "No refund requested" }
  ),
  frustration: score("How frustrated does the customer appear?", [
    { what: "Calm and matter-of-fact", signals: ["Neutral wording"] },
    { what: "Frustrated but civil", signals: ["Annoyance", "Still constructive"] },
    { what: "Very angry or threatening to leave", signals: ["Hostile language", "Threatens cancellation"] },
  ]),
};

/**
 * Cost-sensitive policy. Each action has its own gate; the thresholds do not
 * derive from the model, they derive from the cost of getting the action wrong.
 * Keep this table reviewable — finance and support leads should be able to read it.
 */
export const POLICY = {
  autoRefund: { minNoul: 0.92, minTopicConfidence: 0.85, maxAmountUsd: 50 },
  autoRoute: { minTopicConfidence: 0.80, maxFrustration: 1.5 },
  llmFallback: { minTopicConfidence: 0.65 },
  humanReviewFloor: { maxTopicConfidence: 0.60 },
} as const;

type TicketInput = {
  ticketId: string;
  message: string;
  customer: { plan: "free" | "pro" | "enterprise"; lifetimeValueUsd: number };
};

export type RouteDecision =
  | { kind: "auto_refund"; amountUsd: number; rationale: string }
  | { kind: "auto_route"; team: "billing" | "orders" | "account" }
  | { kind: "llm_fallback"; reason: string }
  | { kind: "human_review"; reason: string; confidence: number };

/**
 * Server Action: score a ticket with Jev, then pick one of four actions under
 * an explicit, cost-sensitive policy. Runs on the server only, invoked from a
 * Server Component form or a client `fetch` to the action endpoint.
 */
export async function triageTicket(input: TicketInput): Promise<RouteDecision> {
  await requireSession();

  const state = {
    ticket: { message: input.message, id: input.ticketId },
    customer: { plan: input.customer.plan, lifetime_value_usd: input.customer.lifetimeValueUsd },
  };

  let result: SystemOneResult<typeof TRIAGE_QUESTIONS>;
  try {
    result = await jev.systemOne({ state, questions: TRIAGE_QUESTIONS });
  } catch (err) {
    // 401/403/422 are not retryable; anything 5xx has already been retried by the SDK.
    if (err instanceof APIError) {
      return { kind: "human_review", reason: `jev_${err.status}`, confidence: 0 };
    }
    throw err;
  }

  const topic = result.answers.topic as ChoiceAnswer<typeof TRIAGE_QUESTIONS.topic.criteria>;
  const refund = result.answers.refund_requested as NoulAnswer;
  const frustration = result.answers.frustration as ScoreAnswer<typeof TRIAGE_QUESTIONS.frustration.criteria>;

  const confidence = topic.confidence;
  const topProb = topic.probabilities[topic.choice];
  const rationale = `topic=${topic.choice} p=${topProb.toFixed(3)} conf=${confidence.toFixed(3)}`;

  // 1. Cheapest win: a small, unambiguous refund request.
  //    Three independent signals must all clear their bars — refund intent, topic,
  //    and a bounded dollar amount on the account.
  if (
    refund.noul >= POLICY.autoRefund.minNoul &&
    topic.choice === "billing" &&
    confidence >= POLICY.autoRefund.minTopicConfidence &&
    input.customer.lifetimeValueUsd < POLICY.autoRefund.maxAmountUsd
  ) {
    const amountUsd = Math.min(input.customer.lifetimeValueUsd, POLICY.autoRefund.maxAmountUsd);
    await logOutcome(input.ticketId, result, "auto_refund", true);
    return {
      kind: "auto_refund",
      amountUsd,
      rationale: `${rationale} refund_noul=${refund.noul.toFixed(3)}`,
    };
  }

  // 2. Clear routing: topic is confident and the customer is not angry.
  if (
    confidence >= POLICY.autoRoute.minTopicConfidence &&
    frustration.score <= POLICY.autoRoute.maxFrustration
  ) {
    await logOutcome(input.ticketId, result, "auto_route", true);
    return { kind: "auto_route", team: topic.choice as "billing" | "orders" | "account" };
  }

  // 3. Middle band: not sure enough to act, but sure enough to hand a well-formed
  //    state to an LLM. This is where a reasoning model can ask a clarifying question
  //    at a fraction of the cost of a human reviewer, on traffic the policy expects.
  if (confidence >= POLICY.llmFallback.minTopicConfidence) {
    await logOutcome(input.ticketId, result, "llm_fallback", false);
    return { kind: "llm_fallback", reason: `topic_confidence=${confidence.toFixed(3)}` };
  }

  // 4. Bottom band: no signal. A human decides, with the full probability vector attached
  //    so the reviewer sees *why* the model hesitated.
  await logOutcome(input.ticketId, result, "human_review", false);
  return {
    kind: "human_review",
    reason: `topic_confidence=${confidence.toFixed(3)}`,
    confidence,
  };
}

/**
 * Persist raw probabilities and the routing action so calibration can be measured
 * offline against real human resolutions. Storing the full distribution (not just
 * the argmax) is what makes reliability diagrams and Brier scores computable later.
 */
async function logOutcome(
  ticketId: string,
  result: SystemOneResult<typeof TRIAGE_QUESTIONS>,
  action: RouteDecision["kind"],
  auto: boolean,
): Promise<void> {
  await db.jevDecisions.insert({
    ticketId,
    model: result.model,
    action,
    auto,
    inputTokens: result.usage.input_tokens,
    outputTokens: result.usage.output_tokens,
    topicProbs: result.answers.topic.probabilities,
    topicConfidence: result.answers.topic.confidence,
    refundNoul: result.answers.refund_requested.noul,
    frustrationScore: result.answers.frustration.score,
    frustrationConfidence: result.answers.frustration.confidence,
    createdAt: new Date(),
  });
}

/**
 * Offline helper (call from a cron job or an ops endpoint): Brier score and
 * reliability statistics over stored predictions whose outcome is now known.
 * The gap between meanConfidence and meanAccuracy in each bucket tells you whether
 * the model is over- or under-confident on that slice of traffic, which is the
 * input to temperature or Platt-style recalibration.
 */
export function brierByBucket(
  rows: ReadonlyArray<{ confidence: number; correct: boolean }>,
  bins = 10,
): Array<{
  bucket: string;
  n: number;
  brier: number;
  meanConfidence: number;
  meanAccuracy: number;
}> {
  return Array.from({ length: bins }, (_, i) => {
    const lo = i / bins;
    const hi = (i + 1) / bins;
    const inBucket = rows.filter((r) => r.confidence >= lo && r.confidence < hi);
    const bucket = `${lo.toFixed(2)}-${hi.toFixed(2)}`;
    if (inBucket.length === 0) {
      return { bucket, n: 0, brier: 0, meanConfidence: 0, meanAccuracy: 0 };
    }
    const meanConfidence = inBucket.reduce((s, r) => s + r.confidence, 0) / inBucket.length;
    const meanAccuracy = inBucket.filter((r) => r.correct).length / inBucket.length;
    const brier =
      inBucket.reduce((s, r) => s + (r.confidence - (r.correct ? 1 : 0)) ** 2, 0) /
      inBucket.length;
    return { bucket, n: inBucket.length, brier, meanConfidence, meanAccuracy };
  });
}
