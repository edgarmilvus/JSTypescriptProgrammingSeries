/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import {
  TypeSafeClient, choice, score, noul,
  ChoiceResponse, ScoreResponse, NoulResponse,
} from "@typesafe-ai/sdk";

type Department = "billing" | "returns" | "shipping" | "technical" | "sales";

type LabeledTicket = {
  ticketId: string;
  text: string;
  goldDepartment: Department;
};

type ReliabilityBin = {
  lower: number;
  upper: number;
  n: number;
  meanConfidence: number;      // mean of the *top probability*, not Jev's `confidence`
  empiricalAccuracy: number;   // fraction of samples whose prediction was correct
};

type ReliabilityReport = {
  questionKind: "choice" | "score" | "noul";
  n: number;
  bins: ReliabilityBin[];
  brierScore: number;
  logLoss: number;
  expectedCalibrationError: number;
  maximumCalibrationError: number;
};

// One row per ticket: what we bin on, what we compare against, and (tracked separately)
// Jev's `confidence` so we can audit the two numbers' divergence later.
type Observation = {
  predictedProbability: number; // top probability of the prediction
  correct: 0 | 1;               // 1 if the prediction was correct
  confidence: number;           // Jev's `confidence` field, for the divergence table only
};

const NUM_BINS = 15;
const MAX_CONCURRENT = 4;

// ---- Report builder (pure; no Jev calls) ----

function buildReport(
  kind: ReliabilityReport["questionKind"],
  obs: Observation[],
): ReliabilityReport {
  const bins: ReliabilityBin[] = [];
  for (let i = 0; i < NUM_BINS; i++) {
    const lower = i / NUM_BINS;
    const upper = (i + 1) / NUM_BINS;
    const inBin = obs.filter(
      (o) => o.predictedProbability >= lower && o.predictedProbability < upper,
    );
    const n = inBin.length;
    if (n === 0) {
      bins.push({ lower, upper, n: 0, meanConfidence: 0, empiricalAccuracy: 0 });
      continue;
    }
    const meanConfidence =
      inBin.reduce((s, o) => s + o.predictedProbability, 0) / n;
    const empiricalAccuracy = inBin.reduce((s, o) => s + o.correct, 0) / n;
    bins.push({ lower, upper, n, meanConfidence, empiricalAccuracy });
  }

  const N = obs.length;
  const brierScore =
    obs.reduce((s, o) => s + (o.predictedProbability - o.correct) ** 2, 0) / N;

  // Clip inside the log to keep log(0) from poisoning the sum.
  const eps = 1e-12;
  const logLoss =
    -obs.reduce((s, o) => {
      const p = Math.min(1 - eps, Math.max(eps, o.predictedProbability));
      return s + (o.correct * Math.log(p) + (1 - o.correct) * Math.log(1 - p));
    }, 0) / N;

  const ece = bins.reduce(
    (s, b) => s + (b.n / N) * Math.abs(b.meanConfidence - b.empiricalAccuracy),
    0,
  );
  const mce = bins.reduce(
    (s, b) =>
      b.n > 0
        ? Math.max(s, Math.abs(b.meanConfidence - b.empiricalAccuracy))
        : s,
    0,
  );

  return { questionKind: kind, n: N, bins, brierScore, logLoss, expectedCalibrationError: ece, maximumCalibrationError: mce };
}

// ---- Per-kind observation extraction ----

function obsFromChoice(ans: ChoiceResponse, gold: Department): Observation {
  // Bin on the top probability, NOT on `confidence`. These are different numbers.
  const topProb = ans.probabilities[ans.choice] as number;
  return {
    predictedProbability: topProb,
    correct: (ans.choice === gold ? 1 : 0) as 0 | 1,
    confidence: ans.confidence,
  };
}

function obsFromNoul(ans: NoulResponse, gold: 0 | 1): Observation {
  // For a Noul, the prediction is yes when noul >= 0.5. The probability of *that*
  // prediction is max(noul, 1 - noul) — the analog of a top-probability for a binary.
  const predicted = ans.noul >= 0.5 ? 1 : 0;
  const topProb = Math.max(ans.noul, 1 - ans.noul);
  return {
    predictedProbability: topProb,
    correct: (predicted === gold ? 1 : 0) as 0 | 1,
    // Noul has no separate confidence field; we report the top probability as a proxy.
    confidence: topProb,
  };
}

// Score reduction: we considered three options:
//   (a) max(probabilities) — the height of the tallest level bar. Cheap, but ignores
//       whether the tallest bar is adjacent to the gold level.
//   (b) probability mass on the rounded-to-nearest level, paired with "did the rounded
//       score match gold?". This parallels Choice (predicted class + its probability).
//   (c) Jev's `confidence` field. Rejected: that is the trap, not the answer.
// We pick (b), because it is the only reduction whose equality with Choice is meaningful.
function obsFromScore(ans: ScoreResponse, gold: number): Observation {
  const rounded = Math.round(ans.score);
  const pTop = (ans.probabilities[String(rounded) as keyof typeof ans.probabilities] ?? 0) as number;
  return {
    predictedProbability: pTop,
    correct: (rounded === gold ? 1 : 0) as 0 | 1,
    confidence: ans.confidence,
  };
}

// ---- Concurrency pool (no external deps) ----

async function withConcurrency<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>,
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let cursor = 0;
  const workers = Array.from({ length: limit }, async () => {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}

// ---- The harness ----

const client = new TypeSafeClient();

// Batch every question we will audit for a ticket into one request; the state is
// then sent once per ticket rather than once per question, which is the whole point
// of Speculative Fan-Out.
async function runJevBatch(tickets: LabeledTicket[]) {
  const departmentQ = choice("Which team should handle this ticket?", {
    billing: null, returns: null, shipping: null, technical: null, sales: null,
  });
  const severityQ = score("How severe is the reported issue?", [
    "Cosmetic", "Degraded", "Blocking",
  ]);
  const humanQ = noul("Does this ticket need human review rather than auto-routing?");

  return withConcurrency(tickets, MAX_CONCURRENT, async (t) => {
    const res = await client.systemOne({
      state: t.text,
      questions: { department: departmentQ, severity: severityQ, needsHuman: humanQ },
    });
    return { ticket: t, answers: res.answers };
  });
}

// Ground truth for the auxiliary questions. In a real audit, these come from labels;
// here we derive them so the harness has something to compare against.
function goldForScore(t: LabeledTicket): number {
  return t.goldDepartment === "technical" ? 2 : t.goldDepartment === "returns" ? 1 : 0;
}
function goldForNoul(t: LabeledTicket): 0 | 1 {
  return (parseInt(t.ticketId, 10) % 2) as 0 | 1;
}

export async function auditHarness(tickets: LabeledTicket[]) {
  const raw = await runJevBatch(tickets);

  // Per-question observations. We do NOT pool across questions: pooling would let a
  // systematically over-confident Score question cancel out a well-calibrated Choice
  // question and hide both errors inside a single "good" ECE number.
  const choiceObs: Observation[] = [];
  const scoreObs: Observation[] = [];
  const noulObs: Observation[] = [];

  for (const { ticket, answers } of raw) {
    choiceObs.push(obsFromChoice(answers.department as ChoiceResponse, ticket.goldDepartment));
    scoreObs.push(obsFromScore(answers.severity as ScoreResponse, goldForScore(ticket)));
    noulObs.push(obsFromNoul(answers.needsHuman as NoulResponse, goldForNoul(ticket)));
  }

  const reports: Record<string, ReliabilityReport> = {
    department: buildReport("choice", choiceObs),
    severity: buildReport("score", scoreObs),
    needsHuman: buildReport("noul", noulObs),
  };

  // Divergence table between `confidence` and `topProbability`. These are NOT
  // the same number: confidence collapses the shape of the distribution; top
  // probability is the height of the tallest bar. They coincide only when the
  // distribution is a single spike or a uniform spread — which is exactly when
  // the distinction does not matter.
  const sorted = [...choiceObs].sort((a, b) => a.predictedProbability - b.predictedProbability);
  let inversions = 0;
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i].confidence < sorted[i - 1].confidence) inversions++;
  }
  const inversionRate = inversions / Math.max(1, sorted.length - 1);

  return { reports, inversionRate };
}
