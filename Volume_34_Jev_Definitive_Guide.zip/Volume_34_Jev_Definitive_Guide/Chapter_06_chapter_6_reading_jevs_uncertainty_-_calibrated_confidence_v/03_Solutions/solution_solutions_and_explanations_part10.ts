/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// =====================================================================
// routing/state.ts — the state machine's shape
// =====================================================================
export type JevAnswer = {
  choice: string;
  probabilities: Record<string, number>;
  confidence: number;
  topProbability: number;
  latencyMs: number;
};

export type ReActStep =
  | { type: "thought"; text: string }
  | { type: "action"; tool: string; input: unknown }
  | { type: "observation"; output: unknown };

export type RoutingEvent = {
  messageId: string;
  receivedAt: string;
  jevAnswer?: { choice: string; probabilities: Record<string, number>; confidence: number };
  jevLatencyMs?: number;
  thresholds: { autoRoute: number; humanReview: number };
  branch: "auto_route" | "llm" | "human";
  reasoningTokens?: { input: number; output: number };
  reasoningIterations?: number;
  resolvedBy?: "auto_route" | "llm" | "human";
};

export type Thresholds = { autoRoute: number; humanReview: number };

// =====================================================================
// routing/classify.ts — the Jev call site
// =====================================================================
import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

const client = new TypeSafeClient();

// The `handoff` option is an in-band refusal. It is a distinct signal from a low
// top probability on the ordinary options. Reconciliation decision: (a) if the
// model *chooses* `handoff`, we treat that as an explicit "I don't know how to
// route this" and go to the LLM regardless of top probability; (b) if it chooses
// an ordinary option with low top probability, we also go to the LLM, but pass
// the picked option as a hint; (c) if top probability is below `humanReview`, we
// skip the LLM entirely -- the classifier is telling us it does not even know
// what kind of message this is, and the LLM would only compound that.
const CLASSIFY_QUESTION = choice("What is this message about?", {
  billing: null,
  returns: null,
  shipping: null,
  technical: null,
  sales: null,
  handoff: "The model does not trust itself to route this; hand off.",
});

export async function classify(message: string): Promise<JevAnswer> {
  const t0 = performance.now();
  const res = await client.systemOne({
    state: message,
    questions: { q: CLASSIFY_QUESTION },
  });
  const a = res.answers.q as { choice: string; probabilities: Record<string, number>; confidence: number };
  const top = Math.max(...Object.values(a.probabilities));
  return {
    choice: a.choice,
    probabilities: a.probabilities,
    confidence: a.confidence,
    topProbability: top,
    latencyMs: performance.now() - t0,
  };
}

export function decide(
  jev: JevAnswer,
  t: Thresholds,
): "auto_route" | "escalated_llm" | "escalated_human" {
  if (jev.choice === "handoff") return "escalated_llm";
  if (jev.topProbability >= t.autoRoute) return "auto_route";
  if (jev.topProbability >= t.humanReview) return "escalated_llm";
  return "escalated_human";
}

// =====================================================================
// routing/react.ts — bounded ReAct fallback
// =====================================================================
const MAX_ITERATIONS = 5;

// Context policy: the prompt contains (1) the original message, (2) the Jev
// classification as DATA (never as an instruction -- re-classification is the LLM
// overstepping its scope), (3) a rolling natural-language summary of everything
// older than the last two observations, (4) the last two observations in full.
// Rationale: observations are the fastest-growing part of the prompt; keeping
// only the last two plus a summary keeps prompt size roughly constant with
// iteration count, so iteration 5 costs about the same as iteration 1.
export async function react(
  message: string,
  jev: JevAnswer,
  tools: Record<string, (input: unknown) => Promise<unknown>>,
  callLLM: (prompt: string) => Promise<{ text: string; tokens: { input: number; output: number } }>,
): Promise<{
  resolved: boolean;
  trace: ReActStep[];
  tokens: { input: number; output: number };
  iterations: number;
}> {
  const trace: ReActStep[] = [];
  let rollingSummary = "";
  const tokens = { input: 0, output: 0 };

  for (let i = 0; i < MAX_ITERATIONS; i++) {
    const recentObs = trace
      .filter((s): s is Extract<ReActStep, { type: "observation" }> => s.type === "observation")
      .slice(-2);

    const prompt = buildPrompt({ message, jev, rollingSummary, recentObs });
    const out = await callLLM(prompt);
    tokens.input += out.tokens.input;
    tokens.output += out.tokens.output;
    trace.push({ type: "thought", text: out.text });

    const parsed = parseAction(out.text);
    if ("done" in parsed) {
      return { resolved: true, trace, tokens, iterations: i + 1 };
    }

    const result = await tools[parsed.tool](parsed.input);
    trace.push({ type: "action", tool: parsed.tool, input: parsed.input });
    trace.push({ type: "observation", output: result });

    // Fold everything but the last two observations into the rolling summary.
    const allObs = trace.filter(
      (s): s is Extract<ReActStep, { type: "observation" }> => s.type === "observation",
    );
    rollingSummary = summarize(rollingSummary, allObs.slice(0, -2));
  }

  return { resolved: false, trace, tokens, iterations: MAX_ITERATIONS };
}

function buildPrompt({ message, jev, rollingSummary, recentObs }: {
  message: string;
  jev: JevAnswer;
  rollingSummary: string;
  recentObs: Extract<ReActStep, { type: "observation" }>[];
}): string {
  return [
    `Message: ${message}`,
    // Pass the classifier's belief, but label it explicitly as data. The LLM handles
    // the message; it does not re-route it.
    `Classifier's belief (do not re-classify; you are here to handle, not to route):\n` +
      JSON.stringify({ choice: jev.choice, top: jev.topProbability, dist: jev.probabilities }),
    rollingSummary ? `Earlier observations (summarized): ${rollingSummary}` : "",
    recentObs.length
      ? `Recent observations:\n${recentObs.map((o) => JSON.stringify(o.output)).join("\n")}`
      : "",
    `Think step by step. To call a tool, output JSON {"tool": "...", "input": {...}}. ` +
      `When done, output {"done": true, "answer": "..."}.`,
  ].filter(Boolean).join("\n\n");
}

function parseAction(text: string): { done: true; answer: string } | { tool: string; input: unknown } {
  // Extremely small parser; the real system uses structured decoding.
  const obj = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1));
  return "done" in obj ? { done: true, answer: obj.answer } : { tool: obj.tool, input: obj.input };
}

function summarize(prev: string, oldObs: Extract<ReActStep, { type: "observation" }>[]): string {
  if (!oldObs.length) return prev;
  return [prev, ...oldObs.map((o) => JSON.stringify(o.output))].filter(Boolean).join(" | ");
}

// =====================================================================
// routing/observability.ts — the replayable log
// =====================================================================
export const routingLog: RoutingEvent[] = [];

export function emit(ev: RoutingEvent) {
  routingLog.push(ev);
}

// Replay: fold the flat log back into per-message state. This is the property
// that makes the router debuggable: given the sequence of events, we can rebuild
// what the router "saw" for any message at any point in time.
export function replay(log: RoutingEvent[]): Map<string, RoutingEvent> {
  const byId = new Map<string, RoutingEvent>();
  for (const ev of log) {
    byId.set(ev.messageId, { ...(byId.get(ev.messageId) ?? {}), ...ev } as RoutingEvent);
  }
  return byId;
}

// =====================================================================
// routing/orchestrator.ts — the only place the three branches are wired
// =====================================================================
export async function handleMessage(opts: {
  messageId: string;
  message: string;
  thresholds: Thresholds;
  tools: Record<string, (input: unknown) => Promise<unknown>>;
  callLLM: (prompt: string) => Promise<{ text: string; tokens: { input: number; output: number } }>;
}): Promise<RoutingEvent> {
  const { messageId, message, thresholds, tools, callLLM } = opts;
  emit({ messageId, receivedAt: new Date().toISOString(), thresholds, branch: "auto_route" });

  // Every message goes through Jev. No heuristic bypass: the fast path is also
  // the source of the routing signal, and bypassing it throws away the very
  // observability ("the fast path was confident") that justifies the fast path.
  const jev = await classify(message);
  const decision = decide(jev, thresholds);

  const branch: RoutingEvent["branch"] =
    decision === "auto_route" ? "auto_route"
    : decision === "escalated_llm" ? "llm"
    : "human";

  emit({
    messageId,
    receivedAt: new Date().toISOString(),
    jevAnswer: { choice: jev.choice, probabilities: jev.probabilities, confidence: jev.confidence },
    jevLatencyMs: jev.latencyMs,
    thresholds,
    branch,
  });

  if (decision === "auto_route" || decision === "escalated_human") {
    const ev = routingLog[routingLog.length - 1];
    ev.resolvedBy = decision === "auto_route" ? "auto_route" : "human";
    return ev;
  }

  // LLM branch.
  const result = await react(message, jev, tools, callLLM);
  const ev = routingLog[routingLog.length - 1];
  ev.reasoningTokens = result.tokens;
  ev.reasoningIterations = result.iterations;
  ev.resolvedBy = result.resolved ? "llm" : "human";
  return ev;
}
