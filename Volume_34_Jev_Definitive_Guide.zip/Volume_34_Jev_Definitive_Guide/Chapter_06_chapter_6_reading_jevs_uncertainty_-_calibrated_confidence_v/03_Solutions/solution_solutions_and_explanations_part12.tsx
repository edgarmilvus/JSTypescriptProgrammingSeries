/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.tsx
// Description: Solutions and Explanations
// ==========================================

// =====================================================================
// app/live-feed/LiveFeed.tsx — client island for the live stream
// =====================================================================
"use client";
import { useEffect, useState } from "react";
import type { RoutingEvent } from "../../routing/observability";

export function LiveFeed() {
  const [events, setEvents] = useState<RoutingEvent[]>([]);
  useEffect(() => {
    const ws = new WebSocket(process.env.NEXT_PUBLIC_WS_URL!);
    ws.onmessage = (m) => {
      const ev = JSON.parse(m.data) as RoutingEvent;
      setEvents((prev) => [ev, ...prev].slice(0, 200));
    };
    return () => ws.close();
  }, []);

  return (
    <ul>
      {events.map((ev) => (
        <li key={ev.messageId + ev.receivedAt}>
          <strong>{ev.branch}</strong>{" "}
          {ev.jevAnswer && (
            <InlineBars
              dist={ev.jevAnswer.probabilities}
              thresholds={ev.thresholds}
            />
          )}
          {ev.reasoningIterations != null && (
            <>
              {" "}· {ev.reasoningIterations} iters ·{" "}
              {ev.reasoningTokens?.input ?? 0} in / {ev.reasoningTokens?.output ?? 0} out
            </>
          )}
        </li>
      ))}
    </ul>
  );
}

function InlineBars({
  dist, thresholds,
}: {
  dist: Record<string, number>;
  thresholds: { autoRoute: number; humanReview: number };
}) {
  const sorted = Object.entries(dist).sort((a, b) => b[1] - a[1]);
  const top = sorted[0]?.[1] ?? 0;
  // Colour by which band the top probability landed in. This is the whole
  // reason the router is instrumented: the colour IS the branch decision.
  const color =
    top >= thresholds.autoRoute ? "green"
    : top >= thresholds.humanReview ? "orange"
    : "red";
  return (
    <span
      style={{ display: "inline-flex", gap: 2, alignItems: "flex-end", height: 14 }}
    >
      {sorted.map(([k, v]) => (
        <span
          key={k}
          title={`${k}: ${v.toFixed(3)}`}
          style={{
            display: "inline-block", width: 6, height: `${v * 14}px`, background: color,
          }}
        />
      ))}
    </span>
  );
}
