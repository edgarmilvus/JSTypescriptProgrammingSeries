/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// =====================================================================
// routing/instrumentation.ts — the six-metric report
// =====================================================================
export function instrumentationReport(events: RoutingEvent[]) {
  const total = events.length;
  const branchCount: Record<string, number> = { auto_route: 0, llm: 0, human: 0 };
  const topProbs: Record<string, number[]> = { auto_route: [], llm: [], human: [] };
  const llmTokens: number[] = [];
  const llmLatencies: number[] = [];

  for (const ev of events) {
    branchCount[ev.branch]++;
    if (ev.jevAnswer) {
      const top = Math.max(...Object.values(ev.jevAnswer.probabilities));
      topProbs[ev.branch].push(top);
    }
    if (ev.branch === "llm") {
      if (ev.reasoningTokens) {
        llmTokens.push(ev.reasoningTokens.input + ev.reasoningTokens.output);
      }
      if (ev.jevLatencyMs != null) llmLatencies.push(ev.jevLatencyMs);
    }
  }

  const mean = (xs: number[]) =>
    xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0;

  return {
    fractionAutoRouted: branchCount.auto_route / total,
    fractionLlm: branchCount.llm / total,
    fractionHuman: branchCount.human / total,
    meanTokensPerLlmBranch: mean(llmTokens),
    meanJevLatencyMs: { auto_route: mean(llmLatencies.filter(() => true)), llm: mean(llmLatencies) },
    topProbDistributionByBranch: {
      auto_route: describe(topProbs.auto_route),
      llm: describe(topProbs.llm),
      human: describe(topProbs.human),
    },
    // The interesting check: is the auto_route distribution shifted clearly higher
    // than the LLM branch's? If not, the thresholds are mis-set (they are cutting
    // into the same distribution that the LLM branch covers, rather than separating
    // a confident head from an uncertain tail).
    autoVsLlmShift: mean(topProbs.auto_route) - mean(topProbs.llm),
  };
}

function describe(xs: number[]) {
  if (!xs.length) return { n: 0, mean: 0, p25: 0, p50: 0, p75: 0 };
  const s = [...xs].sort((a, b) => a - b);
  return {
    n: s.length,
    mean: s.reduce((a, b) => a + b, 0) / s.length,
    p25: s[Math.floor(0.25 * s.length)],
    p50: s[Math.floor(0.5 * s.length)],
    p75: s[Math.floor(0.75 * s.length)],
  };
}
