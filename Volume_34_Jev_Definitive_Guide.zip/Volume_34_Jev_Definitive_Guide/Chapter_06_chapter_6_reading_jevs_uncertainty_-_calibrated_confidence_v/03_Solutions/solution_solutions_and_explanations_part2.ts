/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

type Action = "auto_route" | "human_review" | "defer";
type Truth = "correct" | "incorrect";

type CostMatrix = {
  auto_route: { correct: number; incorrect: number };
  human_review: { correct: number; incorrect: number };
  defer: { correct: number; incorrect: number };
};

type ThresholdRange = { min: number; max: number; step: number };

type SweepPoint = {
  threshold: number;
  expectedCost: number;
  coverage: number;    // fraction of tickets acted on automatically
  precision: number;   // fraction of auto-acted tickets that were correct
};

type SweepResult = {
  points: SweepPoint[];
  optimum: SweepPoint;
  flatRegion: { start: number; end: number }; // thresholds within 1% of the min cost
};

type Observation = { predictedProbability: number; correct: 0 | 1 };

// Task-level costs the business gave us.
export const DEFAULT_COSTS: CostMatrix = {
  auto_route:   { correct: 0.05, incorrect: 4.20 },
  human_review: { correct: 1.10, incorrect: 1.10 },
  defer:        { correct: 1.10, incorrect: 1.10 },
};

function costOf(action: Action, correct: 0 | 1, costs: CostMatrix): number {
  const t: Truth = correct ? "correct" : "incorrect";
  return costs[action][t];
}

// Evaluate one threshold over the empirical observations. Pure function: no Jev calls,
// no probabilistic sampling. The threshold is a code-side decision we can retune
// without a single API request or a model change.
function evaluateThreshold(obs: Observation[], t: number, costs: CostMatrix): SweepPoint {
  let total = 0;
  let autoN = 0;
  let autoCorrect = 0;
  for (const o of obs) {
    if (o.predictedProbability >= t) {
      total += costOf("auto_route", o.correct, costs);
      autoN++;
      autoCorrect += o.correct;
    } else {
      total += costOf("human_review", o.correct, costs);
    }
  }
  const N = obs.length;
  return {
    threshold: t,
    expectedCost: total / N,
    coverage: autoN / N,
    precision: autoN > 0 ? autoCorrect / autoN : 0,
  };
}

export function sweepThresholds(
  obs: Observation[],
  costs: CostMatrix,
  range: ThresholdRange,
): SweepResult {
  // We take raw per-ticket observations rather than a ReliabilityReport: cost is a
  // function of the *joint* (probability, truth) distribution, not of the calibration
  // bins. Re-binning would lose exactly the joint structure that cost operates on.
  const points: SweepPoint[] = [];
  for (let t = range.min; t <= range.max + 1e-9; t += range.step) {
    points.push(evaluateThreshold(obs, Number(t.toFixed(6)), costs));
  }

  const optimum = points.reduce(
    (best, p) => (p.expectedCost < best.expectedCost ? p : best),
    points[0],
  );

  // Flat region: every threshold whose cost is within 1% of the optimum.
  // A single "optimal" threshold is misleading; the flat region is what the ops
  // team can actually tune against without losing money.
  const cutoff = optimum.expectedCost * 1.01;
  const inFlat = points.filter((p) => p.expectedCost <= cutoff);
  const flatRegion = {
    start: Math.min(...inFlat.map((p) => p.threshold)),
    end: Math.max(...inFlat.map((p) => p.threshold)),
  };

  return { points, optimum, flatRegion };
}

// ---- Two-axis case ----

function evaluateTwoAxis(
  obs: Observation[],
  tAuto: number,
  tHuman: number,
  costs: CostMatrix,
): SweepPoint {
  let total = 0, autoN = 0, autoCorrect = 0;
  for (const o of obs) {
    let action: Action;
    if (o.predictedProbability >= tAuto) action = "auto_route";
    else if (o.predictedProbability >= tHuman) action = "human_review";
    else action = "defer";
    total += costOf(action, o.correct, costs);
    if (action === "auto_route") { autoN++; autoCorrect += o.correct; }
  }
  const N = obs.length;
  return {
    threshold: tAuto,
    expectedCost: total / N,
    coverage: autoN / N,
    precision: autoN > 0 ? autoCorrect / autoN : 0,
  };
}

export function sweepTwoAxis(
  obs: Observation[],
  costs: CostMatrix,
  range: ThresholdRange,
) {
  const steps = Math.round((range.max - range.min) / range.step) + 1;
  const heatmap: (SweepPoint | null)[][] = [];
  let best = {
    tAuto: range.min, tHuman: range.min,
    point: { threshold: 0, expectedCost: Infinity, coverage: 0, precision: 0 },
  };
  for (let i = 0; i < steps; i++) {
    const tAuto = Number((range.min + i * range.step).toFixed(6));
    const row: (SweepPoint | null)[] = [];
    for (let j = 0; j < steps; j++) {
      const tHuman = Number((range.min + j * range.step).toFixed(6));
      if (tHuman > tAuto) { row.push(null); continue; }
      const p = evaluateTwoAxis(obs, tAuto, tHuman, costs);
      row.push(p);
      if (p.expectedCost < best.point.expectedCost) {
        best = { tAuto, tHuman, point: p };
      }
    }
    heatmap.push(row);
  }
  return { heatmap, optimum: best };
}

// ---- Cost sensitivity ----

export function costSensitivity(
  obs: Observation[],
  costs: CostMatrix,
  range: ThresholdRange,
) {
  const scale = (factor: number): CostMatrix => ({
    ...costs,
    auto_route: { ...costs.auto_route, incorrect: costs.auto_route.incorrect * factor },
  });
  return {
    baseline:        sweepThresholds(obs, costs,   range).optimum,
    doubleIncorrect: sweepThresholds(obs, scale(2), range).optimum,
    halfIncorrect:   sweepThresholds(obs, scale(0.5), range).optimum,
  };
}
