/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ---- app/answer-gate/AnswerGate.tsx (SERVER COMPONENT) ----
import "server-only";
import {
  TypeSafeClient, ChoiceQuestion, ChoiceCriteria, EntryType,
} from "@typesafe-ai/sdk";
import { AnswerGateClient } from "./AnswerGateClient";

// Reads TYPESAFE_API_KEY from the server process env. It is never imported by
// any file that gets bundled into the client.
const client = new TypeSafeClient();

export type AnswerGateProps<T extends ChoiceCriteria> = {
  state: EntryType;
  question: ChoiceQuestion<T>;
  threshold?: number;
  onOverride: (choice: keyof T & string, note: string) => Promise<void>;
  label?: string;
  defaultExpanded?: boolean;
};

export async function AnswerGate<T extends ChoiceCriteria>({
  state,
  question,
  threshold = 0.8,
  onOverride,
  label,
  defaultExpanded = false,
}: AnswerGateProps<T>) {
  // The Jev call runs on the server. Nothing about the client or key crosses the boundary.
  const res = await client.systemOne({
    state,
    questions: { q: question },
  });
  const ans = res.answers.q;

  // Only plain JSON crosses the RSC boundary. No client instances, no closures that
  // capture the key, no hidden state.
  const data = {
    choice: String(ans.choice),
    probabilities: { ...ans.probabilities } as Record<string, number>,
    confidence: ans.confidence,
    model: res.model,
  };

  return (
    <AnswerGateClient
      data={data}
      threshold={threshold}
      onOverride={onOverride as (c: string, n: string) => Promise<void>}
      label={label}
      defaultExpanded={defaultExpanded}
    />
  );
}
