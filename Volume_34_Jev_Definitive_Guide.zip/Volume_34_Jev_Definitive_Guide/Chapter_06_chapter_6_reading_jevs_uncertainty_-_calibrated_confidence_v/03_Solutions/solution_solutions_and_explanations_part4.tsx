/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// ---- app/answer-gate/AnswerGateClient.tsx (CLIENT ISLAND) ----
"use client";
import { useOptimistic, useState, useTransition } from "react";

type Data = {
  choice: string;
  probabilities: Record<string, number>;
  confidence: number;
  model: string;
};

type Props = {
  data: Data;
  threshold: number;
  onOverride: (choice: string, note: string) => Promise<void>;
  label?: string;
  defaultExpanded?: boolean;
};

export function AnswerGateClient({
  data, threshold, onOverride, label, defaultExpanded,
}: Props) {
  // Insertion order of `probabilities` is meaningless. Sort descending so a
  // bimodal or flat distribution is visible to the reviewer at a glance.
  const sorted = Object.entries(data.probabilities).sort((a, b) => b[1] - a[1]);
  const topProb = sorted[0]?.[1] ?? 0;
  const needsOverride = topProb < threshold;

  // Optimistic override: the UI reflects the reviewer's choice immediately; the
  // server action catches up in the background. On rejection, `useOptimistic`
  // reverts to `data.choice` on the next render.
  const [optimisticChoice, setOptimisticChoice] = useOptimistic<string>(data.choice);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [manualChoice, setManualChoice] = useState<string>(data.choice);
  const [note, setNote] = useState("");

  function submit() {
    setError(null);
    startTransition(async () => {
      setOptimisticChoice(manualChoice);
      try {
        await onOverride(manualChoice, note);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Override failed");
      }
    });
  }

  return (
    <div className="answer-gate" aria-live="polite">
      {label && <div className="answer-gate__label">{label}</div>}

      {/* Headline choice + two separate badges so the two numbers are not confused. */}
      <div className="answer-gate__headline" tabIndex={0}>
        <span className="answer-gate__choice">{optimisticChoice}</span>
        <span
          className="answer-gate__badge"
          title="Shape statistic derived from the full distribution"
        >
          confidence {data.confidence.toFixed(2)}
        </span>
        <span
          className="answer-gate__badge"
          title="Height of the tallest bar — the number thresholds act on"
        >
          p(top) {topProb.toFixed(2)}
        </span>
      </div>

      <ProbabilityBars sorted={sorted} threshold={threshold} />

      {/* Override control appears only when the model did not clear the gate. */}
      {needsOverride && (
        <fieldset className="answer-gate__override" disabled={pending}>
          <legend>Model is below the {threshold.toFixed(2)} gate. Override?</legend>
          <label>
            Correct label
            <select
              value={manualChoice}
              onChange={(e) => setManualChoice(e.target.value)}
              aria-label="Choose the correct label"
            >
              {sorted.map(([l]) => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </label>
          <label>
            Note
            <textarea
              aria-label="Note explaining the override"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Why is the model wrong?"
            />
          </label>
          <button onClick={submit} disabled={pending}>
            {pending ? "Saving…" : "Save override"}
          </button>
          {error && (
            <div role="alert" className="answer-gate__error">
              {error} <button onClick={submit}>Retry</button>
            </div>
          )}
        </fieldset>
      )}

      <details className="answer-gate__why" open={defaultExpanded}>
        <summary>Why this answer?</summary>
        <table>
          <thead>
            <tr><th>Label</th><th>Probability</th></tr>
          </thead>
          <tbody>
            {sorted.map(([l, p]) => (
              <tr key={l}><td>{l}</td><td>{p.toFixed(4)}</td></tr>
            ))}
          </tbody>
        </table>
        <div className="answer-gate__meta">model: {data.model}</div>
      </details>
    </div>
  );
}

function ProbabilityBars({
  sorted, threshold,
}: { sorted: [string, number][]; threshold: number }) {
  // Scale bars to the tallest bar, so a 0.18/0.17/0.16 spread has visible structure
  // even though none of the bars crosses the threshold on its own.
  const maxProbability = Math.max(...sorted.map(([, p]) => p), 0.0001);
  return (
    <div className="answer-gate__bars" role="img" aria-label="Probability distribution">
      {sorted.map(([label, p]) => (
        <div key={label} className="answer-gate__bar">
          <span className="answer-gate__bar-label">{label}</span>
          <div
            className="answer-gate__bar-fill"
            style={{ width: `${(p / maxProbability) * 100}%` }}
          />
          <span className="answer-gate__bar-num">{p.toFixed(3)}</span>
        </div>
      ))}
      <div
        className="answer-gate__threshold-marker"
        style={{ left: `${(threshold / maxProbability) * 100}%` }}
        aria-label={`Threshold at ${threshold.toFixed(2)}`}
      />
    </div>
  );
}
