/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

type Obs = { p: number; correct: 0 | 1 };

// ---- Data split ----
// 400 samples: calibration (150) fits the parameters; test (150) is scored once.
// The remaining 100 are unused (the question is already authored; we do not build it here).
export function splitThreeWay<T>(xs: T[]): { cal: T[]; test: T[] } {
  // Deterministic Fisher–Yates with a fixed seed for reproducibility.
  const shuffled = [...xs];
  let seed = 0x9e3779b9;
  for (let i = shuffled.length - 1; i > 0; i--) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const j = seed % (i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return { cal: shuffled.slice(0, 150), test: shuffled.slice(150, 300) };
}

const clampP = (p: number) => Math.min(1 - 1e-6, Math.max(1e-6, p));
const logit = (p: number) => Math.log(clampP(p) / (1 - clampP(p)));
const sigmoid = (z: number) => 1 / (1 + Math.exp(-z));

// ---- Platt scaling ----
// p_cal = 1 / (1 + exp(A * f + B)), where f = logit(p_raw).
// A = -1, B = 0 is the identity. Fitting A, B by gradient descent on log loss
// over the calibration set.
export function fitPlatt(cal: Obs[], lr = 0.05, iters = 5000): { A: number; B: number } {
  let A = -1, B = 0;
  for (let iter = 0; iter < iters; iter++) {
    let gA = 0, gB = 0;
    for (const o of cal) {
      const f = logit(o.p);
      const q = 1 / (1 + Math.exp(A * f + B)); // current prediction
      // dL/dA = (q - y) * f ; dL/dB = (q - y). Derived from the chain rule on
      // dL/dq = -(y/q) + (1-y)/(1-q), and dq/dA = -q(1-q) f.
      gA += (q - o.correct) * f;
      gB += (q - o.correct);
    }
    gA /= cal.length;
    gB /= cal.length;
    A -= lr * gA;
    B -= lr * gB;
    if (Math.abs(gA) < 1e-7 && Math.abs(gB) < 1e-7) break;
  }
  return { A, B };
}

export function plattCalibrate(p: number, { A, B }: { A: number; B: number }): number {
  return 1 / (1 + Math.exp(A * logit(p) + B));
}

// ---- Temperature scaling ----
// Binary analog: p_cal = sigmoid(logit(p) / T). One parameter, no B.
// Fitting by a scalar search on a fine log grid.
export function fitTemperature(cal: Obs[]): number {
  let bestT = 1, bestLoss = Infinity;
  for (let t = 0.2; t <= 5; t += 0.005) {
    const loss = logLoss(cal, (p) => sigmoid(logit(p) / t));
    if (loss < bestLoss) { bestLoss = loss; bestT = t; }
  }
  return bestT;
}

export function temperatureCalibrate(p: number, T: number): number {
  return sigmoid(logit(p) / T);
}

// ---- Metrics ----
function logLoss(obs: Obs[], predict: (p: number) => number): number {
  const eps = 1e-12;
  let total = 0;
  for (const o of obs) {
    const q = Math.min(1 - eps, Math.max(eps, predict(o.p)));
    total += -(o.correct * Math.log(q) + (1 - o.correct) * Math.log(1 - q));
  }
  return total / obs.length;
}

function brier(obs: Obs[], predict: (p: number) => number): number {
  return obs.reduce((s, o) => s + (predict(o.p) - o.correct) ** 2, 0) / obs.length;
}

function ece(obs: Obs[], predict: (p: number) => number, bins = 15): number {
  const N = obs.length;
  let total = 0;
  for (let i = 0; i < bins; i++) {
    const lo = i / bins, hi = (i + 1) / bins;
    const inBin = obs.filter((o) => predict(o.p) >= lo && predict(o.p) < hi);
    if (!inBin.length) continue;
    const meanP = inBin.reduce((s, o) => s + predict(o.p), 0) / inBin.length;
    const acc = inBin.reduce((s, o) => s + o.correct, 0) / inBin.length;
    total += (inBin.length / N) * Math.abs(meanP - acc);
  }
  return total;
}

// ---- Bootstrap CI on the Brier score delta ----
function bootstrapDelta(
  test: Obs[],
  calibrated: (p: number) => number,
  raw: (p: number) => number,
  n = 500,
): { lo: number; hi: number; mean: number } {
  const deltas: number[] = [];
  let seed = 42;
  for (let k = 0; k < n; k++) {
    const sample: Obs[] = [];
    for (let i = 0; i < test.length; i++) {
      seed = (seed * 1103515245 + 12345) >>> 0;
      sample.push(test[seed % test.length]);
    }
    deltas.push(brier(sample, calibrated) - brier(sample, raw));
  }
  deltas.sort((a, b) => a - b);
  return {
    lo: deltas[Math.floor(0.025 * n)],
    hi: deltas[Math.floor(0.975 * n)],
    mean: deltas.reduce((a, b) => a + b, 0) / n,
  };
}

// ---- Monotonicity check ----
// A usable calibration map must be monotone on (0, 1): higher raw probability cannot
// mean lower calibrated probability. We sample the map and check for inversions.
function isMonotone(f: (p: number) => number, steps = 200): boolean {
  let prev = -Infinity;
  for (let i = 0; i <= steps; i++) {
    const v = f(i / steps);
    if (v < prev - 1e-9) return false;
    prev = v;
  }
  return true;
}

// ---- The full evaluation ----
export function evaluateCalibrationSplit(cal: Obs[], test: Obs[]) {
  const platt = fitPlatt(cal);
  const T = fitTemperature(cal);

  const raw    = (p: number) => p;
  const plattF = (p: number) => plattCalibrate(p, platt);
  const tempF  = (p: number) => temperatureCalibrate(p, T);

  const report = (predict: (p: number) => number) => ({
    brier: brier(test, predict),
    logLoss: logLoss(test, predict),
    ece: ece(test, predict),
  });

  // The deltas must be measured on the test set, which neither fit has ever seen.
  const deltaPlatt = bootstrapDelta(test, plattF, raw);
  const deltaTemp  = bootstrapDelta(test, tempF,  raw);

  const recommendation: "ship_platt" | "ship_temp" | "do_not_ship" =
    deltaPlatt.hi < 0 ? "ship_platt"
    : deltaTemp.hi < 0 ? "ship_temp"
    : "do_not_ship";

  // Shape table: what does the correction actually do at ten points across [0, 1]?
  // If it shrinks toward 0.5 the model was over-confident; if it pushes away, under.
  const shapeTable = [0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95].map(
    (p) => ({ pRaw: p, pPlatt: plattF(p), pTemp: tempF(p) }),
  );

  return {
    fitted: { platt, T },
    test: { raw: report(raw), platt: report(plattF), temp: report(tempF) },
    delta95: { platt: deltaPlatt, temp: deltaTemp },
    monotone: { platt: isMonotone(plattF), temp: isMonotone(tempF) },
    recommendation,
    shapeTable,
  };
}
