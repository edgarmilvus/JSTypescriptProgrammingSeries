/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/triage/fanout.ts
// ---------------------------------------------------------------------------
// Jev Speculative Fan-Out — Hello World
//
// A SaaS support platform receives a ticket. We ask every question that our
// routing tree *might* need in a single Jev request, then decide in code
// which of those answers we actually act on. Speculative branches cost
// nothing extra in latency because Jev evaluates all questions in parallel
// against the same state.
// ---------------------------------------------------------------------------

import {
  TypeSafeClient,
  choice,
  noul,
  score,
} from "@typesafe-ai/sdk";

/** The support ticket as it arrives from our inbound webhook. */
export interface SupportTicket {
  subject: string;
  body: string;
  plan: "free" | "pro" | "enterprise";
  accountAgeDays: number;
}

/** What the router downstream of this function consumes. */
export interface Triage {
  team: "billing" | "technical" | "sales";
  priority: "low" | "normal" | "high";
  signals: {
    refundRequested: boolean;
    isBugReport: boolean;
    bugSeverity: number | null;
    churnRisk: boolean;
  };
}

/**
 * One client for the whole process. The constructor reads
 * `TYPESAFE_API_KEY` from `process.env`, defaults to `jev-latest`, and
 * installs a default retry policy. Creating it at module scope lets Node
 * reuse its connection pool across requests.
 */
const client = new TypeSafeClient();

/**
 * Build the state once. Jev ingests this object a single time and every
 * question in the fan-out is evaluated against the same material, in
 * parallel. Named fields keep the model from confusing the ticket body
 * with customer metadata.
 */
const toState = (t: SupportTicket) => ({
  ticket: { subject: t.subject, body: t.body },
  customer: { plan: t.plan, account_age_days: t.accountAgeDays },
});

/**
 * The complete fan-out. Non-speculative questions are the ones that every
 * ticket is routed on. Speculative questions are the ones that only matter
 * on *some* downstream branches — but they still go in the same request,
 * because Jev evaluates every question in parallel and the added latency
 * is effectively zero.
 */
const QUESTIONS = {
  // ── Primary axis: every ticket gets routed on these. ─────────────────────
  team: choice("Which team should handle `ticket`?", {
    billing: "Charges, invoices, refunds, subscription changes",
    technical: "Bugs, outages, integration failures, API errors",
    sales: "Pricing, plan upgrades, enterprise procurement",
  }),

  urgency: noul("Does `ticket.body` convey urgency or time pressure?"),

  frustration: score(
    "How frustrated does the customer sound in `ticket.body`?",
    [
      "Calm: states facts without complaint",
      "Annoyed: clearly bothered but still constructive",
      "Very upset: hostile or threatening to leave",
    ],
  ),

  // ── Speculative: only consulted on some code branches. ───────────────────
  refund_requested: noul(
    "Does `ticket.body` explicitly ask for a refund or account credit?",
    {
      true: "Directly asks for money back or a credit",
      false: "Complains or asks a question without requesting a remedy",
    },
  ),

  is_bug_report: noul(
    "Does `ticket.body` describe a malfunction, error, or unexpected behaviour?",
  ),

  bug_severity: score(
    "If `ticket` is a bug report, how severe is the reported bug?",
    [
      "Cosmetic: no impact on functionality",
      "Degraded: a feature is broken, but a workaround exists",
      "Blocking: no workaround, the customer cannot proceed",
    ],
  ),

  churn_risk: noul(
    "Does `ticket.body` hint that the customer is considering cancelling?",
  ),
} as const;

/**
 * ONE request. Every answer arrives in a single response. Code decides
 * what to do with them. Adding questions here does not add round trips.
 */
export async function triage(ticket: SupportTicket): Promise<Triage> {
  const { answers } = await client.systemOne({
    state: toState(ticket),
    questions: QUESTIONS,
    model: "jev-latest",
  });

  // ---- Late binding: the answers that always apply. ----------------------
  const team = answers.team.choice;
  const urgency = answers.urgency.noul;
  const frustration = answers.frustration.score;

  // Compose priority in code. The weights and thresholds live here in
  // TypeScript — not in a prompt — so they are reviewable, versioned, and
  // adjustable without touching a single Jev question.
  let priority: Triage["priority"] = "normal";
  if (urgency >= 0.85 || frustration >= 1.5) {
    priority = "high";
  } else if (urgency < 0.15 && frustration < 0.5) {
    priority = "low";
  }

  // ---- Speculative reads: only touch an answer if its branch fires. ------
  const refundRequested =
    team === "billing" && answers.refund_requested.noul >= 0.65;

  const isBugReport =
    team === "technical" && answers.is_bug_report.noul >= 0.6;

  // The bug_severity answer was already sitting in memory. Reading it here
  // costs nothing more than a property access.
  const bugSeverity = isBugReport ? answers.bug_severity.score : null;

  // Churn is cross-cutting: checked regardless of the team routing, but
  // suppressed for free-tier accounts where cancellation has no MRR impact.
  const churnRisk =
    answers.churn_risk.noul >= 0.7 && ticket.plan !== "free";

  // A blocking bug escalates even without urgency language in the ticket.
  if (bugSeverity !== null && bugSeverity >= 1.75 && priority !== "high") {
    priority = "high";
  }

  return {
    team,
    priority,
    signals: { refundRequested, isBugReport, bugSeverity, churnRisk },
  };
}
