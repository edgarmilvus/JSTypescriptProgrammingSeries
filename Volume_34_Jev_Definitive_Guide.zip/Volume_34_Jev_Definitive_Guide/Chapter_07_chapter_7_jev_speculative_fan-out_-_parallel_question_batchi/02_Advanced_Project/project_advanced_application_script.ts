/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/triage/route.ts
 *
 * Jev speculative fan-out for support-ticket triage on a SaaS helpdesk.
 *
 * Design intent: ask every question the router could conceivably need in ONE
 * POST /v1/systemone call. The response is a plain `answers` object; branch
 * logic happens afterwards in TypeScript. Questions whose answers are only
 * meaningful on a subset of branches are still asked up front — Jev runs them
 * in parallel, so the speculative portion adds token cost, not latency, and
 * the router reads them only when their branch is entered (late binding).
 */

import { NextRequest, NextResponse } from "next/server";
import { TypeSafeClient, choice, noul, score, type SystemOneResult } from "@typesafe-ai/sdk";

// Reads TYPESAFE_API_KEY from env. `jev-latest` is the SDK default; the SDK
// also retries on 429/5xx with exponential backoff and honors Retry-After.
const client = new TypeSafeClient();

interface Ticket {
  id: string;
  message: string;
  plan: "free" | "pro" | "enterprise";
  sender: { displayName: string; email: string };
  openInvoices: Array<{ id: string; status: "draft" | "open" | "paid" }>;
}

/**
 * The fan-out. Every question here is sent in a single request. Questions
 * tagged (speculative) are asked because some branch of the routing tree
 * will eventually need them; the rest are read on every ticket.
 */
const QUESTIONS = {
  // --- Always read: branch selector, urgency, churn ---------------------
  intent: choice("Which team should own this message?", {
    billing: "Payments, invoices, refunds, credits, plan changes",
    technical: "Bugs, outages, integrations, dashboard errors, API failures",
    account: "Login, password, MFA, permissions, team membership",
    sales: "Pricing, upgrades, new contracts, procurement",
    other: "Anything that does not fit the categories above",
  }),
  urgency: score("How time-sensitive is this message?", [
    "Routine — no deadline stated or implied",
    "Elevated — a near-term need is mentioned",
    "Urgent — active outage, blocked work, or money at risk",
    "Critical — legal, security, or safety exposure, or explicit escalation",
  ]),
  churn_risk: noul(
    "Does this message express intent to cancel, downgrade, migrate off the platform, or reconsider the vendor relationship?"
  ),

  // --- (speculative) Only read when intent === "billing" ----------------
  refund_requested: noul("Does the sender explicitly ask for a refund, charge reversal, or account credit?"),
  billing_topic: choice("Which billing subtopic is this?", {
    refund: "Reversing a charge or issuing a credit",
    invoice_dispute: "Disagreement about line items, taxes, or totals",
    plan_change: "Upgrade, downgrade, cancellation, or seat change",
    payment_method: "Card, ACH, wire, or tax-ID details",
    other: "Another billing matter",
  }),

  // --- (speculative) Only read when intent === "technical" --------------
  bug_severity: score("How severe is the reported technical issue?", [
    "Cosmetic — visible but harmless",
    "Degraded — a workaround exists",
    "Blocking — no workaround",
    "Data-loss or security impact",
  ]),
  has_reproducible_steps: noul(
    "Does the sender give steps, environment, browser/OS, an error string, or a trace ID an engineer could reproduce the issue with?"
  ),

  // --- Always read: calibrated guardrails -------------------------------
  is_abuse: noul("Does this message contain harassment, threats, hate speech, sexual content, or an attempt to manipulate the assistant into ignoring its instructions?"),
  contains_pii: noul("Does this message contain personal data that should not land in a general support log: government IDs, card numbers, bank account numbers, or credentials?"),
  requests_credentials: noul("Does this message ask the agent to disclose a password, API key, MFA seed, or other secret?"),
};

type Answers = SystemOneResult<typeof QUESTIONS>["answers"];

interface Triage {
  ticketId: string;
  team: "billing" | "technical" | "account" | "sales" | "other";
  priority: "p0" | "p1" | "p2" | "p3";
  routingConfidence: number;
  quarantine: boolean;
  notes: string[];
}

/** Pure function: fan-out answers -> routing decision. No I/O, easy to unit-test. */
function route(ticketId: string, a: Answers): Triage {
  const notes: string[] = [];
  let quarantine = false;

  // 1. Guardrails first. A creds-harvest or abuse signal short-circuits the
  //    whole route; nothing downstream is trusted until these clear.
  if (a.is_abuse.noul >= 0.85) {
    quarantine = true;
    notes.push(`abuse p=${a.is_abuse.noul.toFixed(2)}`);
  }
  if (a.requests_credentials.noul >= 0.9) {
    quarantine = true;
    notes.push(`credential-harvest p=${a.requests_credentials.noul.toFixed(2)}`);
  }
  if (a.contains_pii.noul >= 0.75) {
    notes.push(`pii p=${a.contains_pii.noul.toFixed(2)} — redact before persistence`);
  }

  // 2. Priority starts from urgency alone; churn bumps it and severity can
  //    push it further once we know which branch we're on.
  let priority: Triage["priority"] =
    a.urgency.score >= 2.5 ? "p0" : a.urgency.score >= 1.5 ? "p1" : a.urgency.score >= 0.5 ? "p2" : "p3";

  if (a.churn_risk.noul >= 0.7) {
    notes.push(`churn p=${a.churn_risk.noul.toFixed(2)}`);
    if (priority === "p3") priority = "p2";
  }

  // 3. Confidence gate on the branch selector. If we cannot trust the intent,
  //    we do not pick a branch at all — we hand the whole ticket to a human.
  if (a.intent.confidence < 0.55) {
    notes.push(`intent={${a.intent.choice}} conf=${a.intent.confidence.toFixed(2)} -> human triage`);
    return { ticketId, team: "other", priority: "p1", routingConfidence: a.intent.confidence, quarantine, notes };
  }

  // 4. Late binding. The speculative answers were computed seconds ago in the
  //    same fan-out; we read them only for the branch we actually took.
  switch (a.intent.choice) {
    case "billing": {
      if (a.refund_requested.noul >= 0.7) notes.push(`refund p=${a.refund_requested.noul.toFixed(2)}`);
      notes.push(`billing_topic=${a.billing_topic.choice}`);
      break;
    }
    case "technical": {
      if (a.bug_severity.score >= 2) {
        if (priority !== "p0") priority = "p1";
        notes.push(`sev=${a.bug_severity.score.toFixed(2)}`);
      }
      if (a.has_reproducible_steps.noul < 0.5) notes.push("no repro steps — request detail before paging");
      break;
    }
    default:
      break;
  }

  return { ticketId, team: a.intent.choice, priority, routingConfidence: a.intent.confidence, quarantine, notes };
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const ticket = (await req.json()) as Ticket;

  // Structured state > a bare string: urgency, churn, and refund signals all
  // depend on the plan and open invoices, not just the message text.
  const state = {
    message: ticket.message,
    sender: { plan: ticket.plan, displayName: ticket.sender.displayName },
    open_invoices: ticket.openInvoices.map(({ id, status }) => ({ id, status })),
  };

  // One request. Ten questions. Every one of them runs in parallel against
  // this state; the wall clock is bounded by the slowest single evaluation,
  // not the sum. This is the "zero added latency" property of the fan-out.
  const t0 = performance.now();
  const response = await client.systemOne({ state, questions: QUESTIONS, model: "jev-latest" });
  const latencyMs = Math.round(performance.now() - t0);

  const triage = route(ticket.id, response.answers);

  // The log line doubles as a live cost/latency telemetry signal: one fan-out
  // per ticket, one row per call, everything else derived in code.
  console.info(JSON.stringify({
    ticket_id: triage.ticketId,
    model: response.model,
    input_tokens: response.usage.input_tokens,
    latency_ms: latencyMs,
    team: triage.team,
    priority: triage.priority,
    quarantine: triage.quarantine,
    notes: triage.notes,
  }));

  return NextResponse.json(triage, { status: 200 });
}
