/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// ---------- plan.worker.ts : the pure planning worker ----------
import type { Question, ChoiceQuestion, ScoreQuestion, NoulQuestion } from "@typesafe-ai/sdk";

interface QuestionSpec {
  id: string;
  kind: "choice" | "score" | "noul";
  instructions: unknown;
  criteria: unknown;
}
interface PlanRequest {
  jobId: number;
  state: string;
  specs: QuestionSpec[];
  sab: SharedArrayBuffer;
}
interface PlanOk {
  jobId: number;
  fingerprint: string;
  bytesWritten: number;
  plannedAt: number;
}
interface PlanErr {
  jobId: number;
  error: "too_large";
  bytes: number;
  capacity: number;
}

const SLOT_BYTES = 64 * 1024;
const HEADER = 4; // uint32 length prefix at byte 0

// Deterministic normalization: collapse whitespace, strip leading/trailing, fold case.
// Two inputs that differ only in "insignificant" whitespace must collide on the fingerprint.
function normalize(text: string): string {
  return text.replace(/\s+/g, " ").trim().toLowerCase();
}

async function sha256Hex(input: string): Promise<string> {
  const buf = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// Reconstruct the exact `Questions` object the SDK expects. Everything is plain data,
// so a worker can build the map without ever seeing a function reference.
function buildQuestions(specs: QuestionSpec[]): Record<string, Question> {
  const out: Record<string, Question> = {};
  for (const s of specs) {
    if (s.kind === "choice") {
      out[s.id] = {
        type: "choice",
        instructions: s.instructions,
        criteria: s.criteria,
      } as ChoiceQuestion;
    } else if (s.kind === "score") {
      out[s.id] = {
        type: "score",
        instructions: s.instructions,
        criteria: s.criteria,
      } as ScoreQuestion;
    } else {
      out[s.id] = {
        type: "noul",
        instructions: s.instructions,
        criteria: s.criteria,
      } as NoulQuestion;
    }
  }
  return out;
}

// Fingerprint is stable across runs: normalized state, then a sorted "id:kind" list.
// Sorting makes the fingerprint independent of insertion order in the map.
async function fingerprint(normalized: string, specs: QuestionSpec[]): Promise<string> {
  const shape = specs.map((s) => `${s.id}:${s.kind}`).sort().join(",");
  return sha256Hex(`${normalized}|${shape}`);
}

// The worker is a pure function: same (state, specs) => byte-identical fingerprint
// and byte-identical serialized plan.
self.onmessage = async (e: MessageEvent<PlanRequest>) => {
  const { jobId, state, specs, sab } = e.data;
  const normalized = normalize(state);
  const questions = buildQuestions(specs);
  const fp = await fingerprint(normalized, specs);

  const payload = new TextEncoder().encode(JSON.stringify({ state: normalized, questions }));
  const capacity = sab.byteLength - HEADER;
  if (payload.byteLength > capacity) {
    const err: PlanErr = { jobId, error: "too_large", bytes: payload.byteLength, capacity };
    (self as unknown as Worker).postMessage(err);
    return;
  }

  // Write the length prefix, then the payload. Worker side is the only writer.
  new DataView(sab).setUint32(0, payload.byteLength, false);
  new Uint8Array(sab, HEADER, payload.byteLength).set(payload);

  const ok: PlanOk = {
    jobId,
    fingerprint: fp,
    bytesWritten: payload.byteLength,
    plannedAt: performance.now(),
  };
  (self as unknown as Worker).postMessage(ok);
};

// ---------- fan-out.ts : the pool on the main thread ----------
import {
  TypeSafeClient,
  type EntryType,
  type Questions,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

export interface FanOutPlan<Q extends Questions> {
  state: EntryType;
  questions: Q;
  fingerprint: string;
  plannedAt: number;
}

export class PlanTooLargeError extends Error {
  constructor(public readonly bytes: number, public readonly capacity: number) {
    super(`Plan exceeds shared buffer: ${bytes} > ${capacity}`);
    this.name = "PlanTooLargeError";
  }
}

export class TooManyQuestionsError extends Error {
  constructor(public readonly count: number, public readonly limit: number) {
    super(`Too many questions: ${count} > ${limit}`);
    this.name = "TooManyQuestionsError";
  }
}

type Pending = { resolve: (p: unknown) => void; reject: (e: Error) => void };

export class WorkerPool {
  private readonly workers: Worker[] = [];
  private readonly sabs: SharedArrayBuffer[] = [];
  private readonly pending = new Map<number, Pending>();
  private nextWorker = 0;
  private nextJobId = 0;

  constructor(
    private readonly client: TypeSafeClient,
    private readonly workerCount: number,
    private readonly bufferCapacityBytes: number,
    private readonly maxQuestions: number,
    private readonly workerUrl = new URL("./plan.worker.js", import.meta.url),
  ) {
    for (let i = 0; i < workerCount; i++) {
      const worker = new Worker(workerUrl, { type: "module" });
      // One SAB per worker => no cross-worker synchronization needed.
      const sab = new SharedArrayBuffer(bufferCapacityBytes);
      worker.onmessage = (event) => this.onWorkerMessage(i, event);
      this.workers.push(worker);
      this.sabs.push(sab);
    }
  }

  private onWorkerMessage(workerIndex: number, event: MessageEvent<any>): void {
    const data = event.data;
    const pending = this.pending.get(data.jobId);
    if (!pending) return;
    this.pending.delete(data.jobId);

    if (data.error === "too_large") {
      pending.reject(new PlanTooLargeError(data.bytes, data.capacity));
      return;
    }

    // Read the plan back out of the shared buffer. Main thread is a reader only.
    const sab = this.sabs[workerIndex];
    const length = new DataView(sab).getUint32(0, false);
    const payload = new Uint8Array(sab, 4, length);
    const decoded = JSON.parse(new TextDecoder().decode(payload)) as {
      state: EntryType;
      questions: Questions;
    };
    pending.resolve({
      state: decoded.state,
      questions: decoded.questions,
      fingerprint: data.fingerprint as string,
      plannedAt: data.plannedAt as number,
    });
  }

  plan<Q extends Questions>(
    state: EntryType,
    build: () => Q,
  ): Promise<FanOutPlan<Q>> {
    const questions = build();
    const count = Object.keys(questions).length;
    if (count > this.maxQuestions) {
      return Promise.reject(new TooManyQuestionsError(count, this.maxQuestions));
    }

    const specs = Object.entries(questions).map(([id, q]) => ({
      id,
      kind: q.type,
      instructions: (q as { instructions?: unknown }).instructions ?? null,
      criteria: (q as { criteria?: unknown }).criteria ?? null,
    }));

    const workerIndex = this.nextWorker++ % this.workers.length;
    const jobId = this.nextJobId++;

    return new Promise<FanOutPlan<Q>>((resolve, reject) => {
      this.pending.set(jobId, { resolve: resolve as (p: unknown) => void, reject });
      this.workers[workerIndex].postMessage({
        jobId,
        state: typeof state === "string" ? state : JSON.stringify(state),
        specs,
        sab: this.sabs[workerIndex],
      });
    });
  }

  async dispatch<Q extends Questions>(plan: FanOutPlan<Q>): Promise<SystemOneResult<Q>> {
    const result = await this.client.systemOne({
      state: plan.state,
      questions: plan.questions,
    });
    // Attach plan metadata as non-enumerable so nothing downstream is tempted
    // to serialize it, but observability code can still read it.
    Object.defineProperties(result, {
      fingerprint: { value: plan.fingerprint, enumerable: false, configurable: true },
      plannedAt: { value: plan.plannedAt, enumerable: false, configurable: true },
    });
    return result;
  }

  async close(): Promise<void> {
    for (const w of this.workers) w.terminate();
    this.workers.length = 0;
    this.sabs.length = 0;
    this.pending.clear();
  }
}

// ---------- __tests__/latency.test.ts : the load test ----------
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { hrtime } from "node:process";

describe("WorkerPool planning latency", () => {
  let pool: WorkerPool;
  let client: TypeSafeClient;

  beforeAll(() => {
    client = new TypeSafeClient();
    pool = new WorkerPool(client, /* workers */ 4, /* 64 KiB */ 65_536, /* maxQ */ 64);
  });
  afterAll(async () => pool.close());

  function percentile(samples: number[], p: number): number {
    const sorted = [...samples].sort((a, b) => a - b);
    return sorted[Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length))];
  }

  it("planning p99 is strictly lower than total p99 by at least one round trip", async () => {
    const planLatencies: number[] = [];
    const totalLatencies: number[] = [];
    const build = () => ({ q1: noul("is urgent?"), q2: choice("topic", { a: null, b: null }) });

    for (let i = 0; i < 200; i++) {
      const text = `synthetic ticket #${i} - some body text - please help`;
      const t0 = hrtime.bigint();
      const plan = await pool.plan(text, build);
      const t1 = hrtime.bigint();
      await pool.dispatch(plan);
      const t2 = hrtime.bigint();
      planLatencies.push(Number(t1 - t0) / 1e6);
      totalLatencies.push(Number(t2 - t0) / 1e6);
    }

    const planP99 = percentile(planLatencies, 99);
    const totalP99 = percentile(totalLatencies, 99);
    expect(planP99).toBeLessThan(totalP99);
    expect(totalP99 - planP99).toBeGreaterThan(50); // >= 50 ms slack from one inference RT
  });
});
