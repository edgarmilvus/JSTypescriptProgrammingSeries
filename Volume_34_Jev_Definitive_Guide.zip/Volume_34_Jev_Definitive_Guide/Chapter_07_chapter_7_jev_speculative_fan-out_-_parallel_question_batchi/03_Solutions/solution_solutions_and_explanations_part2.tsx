/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useMemo, useRef, useState } from "react";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  RateLimitError,
  type SystemOneResult,
  type ChoiceAnswer,
  type ScoreAnswer,
  type NoulAnswer,
} from "@typesafe-ai/sdk";

// The question set is a module-level constant: built once, identical across renders,
// so the runtime can safely memoize anything derived from it.
const questions = {
  intent: choice("What is the customer primarily asking for?", {
    billing: "Payment, invoice, refund, or subscription issues",
    shipping: "Delivery, tracking, delay, or lost package",
    returns: "Exchange, defect, or wrong-item complaint",
    account: "Login, permissions, or security concerns",
    other: "Anything that does not fit the above",
  }),
  queue: choice("Which team should own this ticket?", {
    frontline: null,
    billing_ops: null,
    logistics: null,
    fraud_billing: null,
    engineering: null,
  }),
  severity: score("How severe is the underlying issue?", [
    "Cosmetic or ignore-able",
    "Minor inconvenience, workaround exists",
    "Material disruption to the customer",
    "Blocking; no workaround",
  ]),
  frustration: score("How frustrated does the customer sound?", [
    "Calm",
    "Frustrated but civil",
    "Visibly angry",
    "Threatening to leave",
  ]),
  refund_requested: noul("Is the customer explicitly requesting a refund?"),
  urgency: noul("Does the message convey time-sensitivity?"),
  screenshot_attached: noul("Does the message refer to an attached screenshot or image?"),
} as const;

type Q = typeof questions;
type Answers = SystemOneResult<Q>["answers"];

export interface SpeculativeTriagePreviewProps {
  text: string;
  client: TypeSafeClient;
  minChars?: number;
  settleMs?: number;
  confidenceFloor?: number;
  onError?: (e: Error) => void;
}

interface PreviewState {
  answers: Answers | null;
  durationMs: number;
  fingerprint: string;
  questionCount: number;
  status: "idle" | "loading" | "ready" | "paused" | "unavailable";
}

// Stable string hash for the fingerprint (djb2). Not cryptographic; fine for a UI badge.
function fingerprint(text: string, ids: readonly string[]): string {
  const payload = `${text.trim().replace(/\s+/g, " ").toLowerCase()}|${[...ids].sort().join(",")}`;
  let h = 5381;
  for (let i = 0; i < payload.length; i++) h = ((h << 5) + h + payload.charCodeAt(i)) | 0;
  return (h >>> 0).toString(16).padStart(8, "0");
}

// Discriminated branch reporter. Reads all three answer shapes correctly;
// never calls `.score` on a Choice or `.choice` on a Score.
function renderBranch(
  key: keyof Q,
  answer: Answers[keyof Q],
  floor: number,
): { label: string; detail: string; belowFloor: boolean } {
  switch (answer.type) {
    case "choice": {
      const a = answer as ChoiceAnswer;
      return {
        label: String(a.choice),
        detail: `choice conf ${a.confidence.toFixed(2)}`,
        belowFloor: a.confidence < floor,
      };
    }
    case "score": {
      const a = answer as ScoreAnswer;
      return {
        label: `${(key as string)} = ${a.score.toFixed(2)}`,
        detail: `score conf ${a.confidence.toFixed(2)}`,
        belowFloor: a.confidence < floor,
      };
    }
    case "noul": {
      const a = answer as NoulAnswer;
      return {
        label: `${(key as string)}: ${a.noul.toFixed(2)}`,
        detail: "noul (0–1)",
        belowFloor: a.noul > 0.35 && a.noul < 0.65,
      };
    }
  }
}

export function SpeculativeTriagePreview(props: SpeculativeTriagePreviewProps) {
  const {
    text,
    client,
    minChars = 24,
    settleMs = 350,
    confidenceFloor = 0.55,
    onError,
  } = props;

  const [state, setState] = useState<PreviewState>({
    answers: null,
    durationMs: 0,
    fingerprint: "",
    questionCount: Object.keys(questions).length,
    status: "idle",
  });

  const inflight = useRef<AbortController | null>(null);
  const questionIds = useMemo(() => Object.keys(questions), []);

  useEffect(() => {
    // Below the threshold: do nothing at all. Also cancel any in-flight call
    // so a trailing request cannot land after the user cleared the field.
    if (text.trim().length < minChars) {
      inflight.current?.abort();
      inflight.current = null;
      setState((s) => ({ ...s, status: "idle", answers: null }));
      return;
    }

    const handle = setTimeout(async () => {
      // Cancel any previous request before starting the new one.
      inflight.current?.abort();
      const controller = new AbortController();
      inflight.current = controller;

      const started = performance.now();
      setState((s) => ({ ...s, status: "loading" }));

      try {
        const response = await client.systemOne(
          { state: text, questions },
          { signal: controller.signal },
        );
        const elapsed = performance.now() - started;
        setState({
          answers: response.answers,
          durationMs: elapsed,
          fingerprint: fingerprint(text, questionIds),
          questionCount: questionIds.length,
          status: "ready",
        });
      } catch (err) {
        if (controller.signal.aborted) return; // user edit; not an error
        if (err instanceof RateLimitError) {
          setState((s) => ({ ...s, status: "paused" }));
          return;
        }
        setState((s) => ({ ...s, status: "unavailable" }));
        onError?.(err instanceof Error ? err : new Error(String(err)));
      } finally {
        if (inflight.current === controller) inflight.current = null;
      }
    }, settleMs);

    return () => {
      clearTimeout(handle);
      // Do not abort here — the next effect run aborts the right controller,
      // and aborting in the cleanup would kill legitimate in-flight work
      // whenever `settleMs` or `client` identity changes.
    };
  }, [text, client, minChars, settleMs, questionIds, onError]);

  // Unmount: make sure no request is left dangling.
  useEffect(() => () => inflight.current?.abort(), []);

  const { answers, status, durationMs, fingerprint: fp, questionCount } = state;

  if (status === "idle") return <div className="preview preview--idle">Type a message to preview triage.</div>;
  if (status === "loading") return <div className="preview preview--loading">Analyzing…</div>;
  if (status === "paused") return <div className="preview preview--paused">Preview paused — retrying soon.</div>;
  if (status === "unavailable" || !answers) return <div className="preview preview--unavailable">Preview unavailable.</div>;

  const intent = answers.intent as ChoiceAnswer;
  const queue = answers.queue as ChoiceAnswer;
  const probs = Object.entries(intent.probabilities).sort((a, b) => b[1] - a[1]);
  const [topLabel, topP] = probs[0];
  const [secondLabel, secondP] = probs[1] ?? ["", 0];
  const closeCall = topP - secondP <= 0.1;

  // Every branch except the headline. Rendered even when below the floor.
  const speculative: Array<keyof Q> = [
    "queue",
    "severity",
    "frustration",
    "refund_requested",
    "urgency",
    "screenshot_attached",
  ];

  return (
    <div className="preview preview--ready">
      <header className="preview__headline">
        <span className="preview__label">Intent:</span>
        <strong>{String(intent.choice)}</strong>
        <span className="preview__conf">({intent.confidence.toFixed(2)})</span>
        {closeCall && <span className="preview__warn" title={`Second: ${secondLabel} @ ${secondP.toFixed(2)}`}>⚠ close call</span>}
      </header>

      {/* The queue Choice is shown as a branch too, but referenced here so the analyst
          sees what team would own the ticket if committed. */}
      <div className="preview__queue">
        queue → <code>{String(queue.choice)}</code> ({queue.confidence.toFixed(2)})
      </div>

      <ul className="preview__branches">
        {speculative.map((key) => {
          const answer = answers[key];
          const { label, detail, belowFloor } = renderBranch(key, answer, confidenceFloor);
          return (
            <li
              key={key as string}
              className={belowFloor ? "branch branch--below" : "branch branch--speculative"}
            >
              <span className="branch__id">{key as string}</span>
              <span className="branch__value">{label}</span>
              <span className="branch__detail">{detail}</span>
              {belowFloor && <span className="branch__floor">below floor</span>}
            </li>
          );
        })}
      </ul>

      <footer className="preview__footer">
        <span>fp {fp}</span>
        <span>{durationMs.toFixed(0)} ms</span>
        <span>{questionCount} questions</span>
      </footer>
    </div>
  );
}
