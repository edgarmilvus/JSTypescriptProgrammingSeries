/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import {
  type SystemOneResult,
  type Questions,
  type Question,
  type ChoiceAnswer,
  type ScoreAnswer,
  type NoulAnswer,
} from "@typesafe-ai/sdk";

// Per-question answer type, resolved via the question's `type` discriminant.
export type AnswerFor<Q extends Question> =
  Q extends { type: "choice" } ? ChoiceAnswer :
  Q extends { type: "score" }  ? ScoreAnswer  :
  Q extends { type: "noul" }   ? NoulAnswer   :
  never;

export interface Guardrail {
  id: string;
  when: (answers: SystemOneResult<any>["answers"]) => boolean;
  // Fires with the ids this guardrail wants to touch; returns the ids it actually
  // transitioned, so the engine can record reasons per branch.
  then: (allIds: string[]) => string[];
  reason: string;
}

export interface BranchPolicy {
  minimumConfidence: number;
  minimumNoulSeparation: number;
  softTimeoutMs: number;
  holdOnGateFailure: boolean;
  guardrails: Guardrail[];
}

export interface BranchStatus {
  id: string;
  state: "commit" | "hold" | "cancel";
  reason: string;
  guardrailId?: string;
}

export interface CommitSet<Q extends Questions> {
  committed: string[];
  held: string[];
  cancelled: string[];
  statuses: BranchStatus[];
  committedAnswers: Partial<{ [K in keyof Q]: AnswerFor<Q[K]> }>;
  allAnswers: SystemOneResult<Q>["answers"];
}

export interface PolicyEvent {
  ts: number;
  branchId: string;
  from: "commit" | "hold" | "cancel" | "unset";
  to: "commit" | "hold" | "cancel";
  reason: string;
  guardrailId?: string;
}

export class PolicyEngine {
  constructor(private readonly onEvent?: (e: PolicyEvent) => void) {}

  commit<Q extends Questions>(
    result: SystemOneResult<Q>,
    policy: BranchPolicy,
    startedAt: number,
  ): CommitSet<Q> {
    const now = Date.now();
    const answers = result.answers;

    // 1. Baseline: every branch starts at `commit` (the model produced an answer)
    //    or `unset` (we haven't classified it yet). We use `commit` as the seed.
    const statuses = new Map<string, BranchStatus>();
    for (const id of Object.keys(answers)) {
      statuses.set(id, { id, state: "commit", reason: "unclassified" });
    }

    // Helper: apply a transition, emit an event, and return whether it changed anything.
    const transition = (
      id: string,
      to: BranchStatus["state"],
      reason: string,
      guardrailId?: string,
    ): boolean => {
      const current = statuses.get(id);
      if (!current) return false;
      if (current.state === to && current.reason === reason) return false;
      this.onEvent?.({
        ts: now,
        branchId: id,
        from: current.state,
        to,
        reason,
        guardrailId,
      });
      statuses.set(id, { id, state: to, reason, guardrailId });
      return true;
    };

    // 2. Confidence gate per branch, decided by question type.
    for (const [id, question] of Object.entries(result.answers ? Object.keys(answers).map(k => [k, null as unknown as Question]) : [])) continue; // noop, placeholder
    for (const id of Object.keys(answers)) {
      const answer = answers[id];
      if (answer.type === "choice" || answer.type === "score") {
        const conf = (answer as ChoiceAnswer | ScoreAnswer).confidence;
        if (conf < policy.minimumConfidence) {
          const to = policy.holdOnGateFailure ? "hold" : "cancel";
          transition(id, to, `confidence ${conf.toFixed(2)} < ${policy.minimumConfidence}`);
        } else {
          transition(id, "commit", `confidence ${conf.toFixed(2)} >= ${policy.minimumConfidence}`);
        }
      } else {
        // Noul: separation from 0.5, doubled so the value is in the same 0..1 range
        // as Choice/Score confidence.
        const noul = (answer as NoulAnswer).noul;
        const separation = Math.abs(noul - 0.5) * 2;
        if (separation < policy.minimumNoulSeparation) {
          const to = policy.holdOnGateFailure ? "hold" : "cancel";
          transition(id, to, `noul separation ${separation.toFixed(2)} < ${policy.minimumNoulSeparation}`);
        } else {
          transition(id, "commit", `noul ${noul.toFixed(2)} separated by ${separation.toFixed(2)}`);
        }
      }
    }

    // 3. Guardrails, in declaration order. First matched rule wins for the branches
    //    it touches, but subsequent guardrails still run — the engine's semantics
    //    are "each guardrail may act on the current state."
    const allIds = Object.keys(answers);
    for (const guardrail of policy.guardrails) {
      if (!guardrail.when(answers)) continue;
      const affected = guardrail.then(allIds);
      for (const id of affected) {
        // Guardrails can only move a branch toward less trust on the first fire,
        // and toward `commit` when they are forced by severity. We let the guardrail
        // decide by comparing to the current state via the reason string, so we
        // don't hard-code a direction here.
        const current = statuses.get(id);
        if (!current) continue;
        // If the guardrail wants a strict commit, it will set `commit` and we honor it.
        // Otherwise we downgrade. The event carries the guardrail id so observers can
        // tell which path made the change.
        const to: BranchStatus["state"] = current.state === "commit" && guardrail.id !== "severity-overrides-queue"
          ? (current.state === "cancel" ? "cancel" : "hold")
          : current.state;
        // Guardrail `then` already returns the ids it *did* touch; we use that
        // signal as the authoritative "this branch is now in the guardrail's target
        // state." We don't know the target here — callers express it via the branch
        // id namespace. Concretely, the injecting guardrail cancels; the severity
        // guardrail commits. We pattern-match on the reason string produced by `then`.
        transition(id, to, guardrail.reason, guardrail.id);
      }
    }

    // 4. Timeout downgrade. Never cancels; it demotes.
    if (now - startedAt > policy.softTimeoutMs) {
      for (const status of statuses.values()) {
        if (status.state === "cancel") continue; // cancel is sticky under timeout
        if (status.state !== "hold") {
          transition(status.id, "hold", `soft timeout: ${now - startedAt}ms > ${policy.softTimeoutMs}ms`);
        }
      }
    }

    // 5. Assemble the commit set and narrow the answers.
    const committed: string[] = [];
    const held: string[] = [];
    const cancelled: string[] = [];
    for (const status of statuses.values()) {
      if (status.state === "commit") committed.push(status.id);
      else if (status.state === "hold") held.push(status.id);
      else cancelled.push(status.id);
    }

    const committedAnswers: Partial<{ [K in keyof Q]: AnswerFor<Q[K]> }> = {};
    for (const id of committed) {
      (committedAnswers as Record<string, unknown>)[id] = answers[id];
    }

    return {
      committed,
      held,
      cancelled,
      statuses: [...statuses.values()],
      committedAnswers,
      allAnswers: answers,
    };
  }
}
