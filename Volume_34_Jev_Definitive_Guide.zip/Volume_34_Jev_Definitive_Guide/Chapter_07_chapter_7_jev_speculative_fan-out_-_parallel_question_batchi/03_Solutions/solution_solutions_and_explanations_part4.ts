/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { type NoulAnswer, type ChoiceAnswer, type ScoreAnswer } from "@typesafe-ai/sdk";

// A test fixture result the engine can be run against without the network.
export const fixture = (over: Record<string, unknown> = {}): SystemOneResult<any> => ({
  model: "jev-latest",
  usage: { input_tokens: 100, output_tokens: 20 },
  answers: {
    intent: { type: "choice", choice: "billing", probabilities: { billing: 0.55, refund: 0.4, other: 0.05 }, confidence: 0.42 },
    queue: { type: "choice", choice: "frontline", probabilities: { frontline: 0.7, fraud_billing: 0.3 }, confidence: 0.62 },
    severity: { type: "score", score: 3.2, legend: {}, probabilities: {}, confidence: 0.85 },
    injection_scan: { type: "noul", noul: 0.05 },
    ...over,
  },
});

// --- Guardrail 1: injection-suspect ---
export const injectionSuspect: Guardrail = {
  id: "injection-suspect",
  reason: "injection signal high: cancelled downstream severity/queue/intent branches",
  when: (a) =>
    Object.entries(a).some(
      ([id, ans]) => id.includes("injection") && ans.type === "noul" && (ans as NoulAnswer).noul > 0.8,
    ),
  then: (ids) => ids.filter((id) => /severity|queue|intent/.test(id)),
};

// --- Guardrail 2: confidence-gated ---
export const confidenceGated = (min: number): Guardrail => ({
  id: "confidence-gated",
  reason: `primary intent confidence below ${min}`,
  when: (a) => {
    const intent = a.intent as ChoiceAnswer | undefined;
    return !!intent && intent.type === "choice" && intent.confidence < min;
  },
  then: (ids) => ids.filter((id) => id !== "intent"), // downgrade everything downstream of intent
});

// --- Guardrail 3: severity-overrides-queue ---
export const severityOverridesQueue: Guardrail = {
  id: "severity-overrides-queue",
  reason: "blocking severity forces queue commit",
  when: (a) => {
    const sev = a.severity as ScoreAnswer | undefined;
    return !!sev && sev.type === "score" && sev.score >= 3;
  },
  then: (ids) => ids.filter((id) => id === "queue"),
};
