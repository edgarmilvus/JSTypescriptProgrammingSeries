/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import {
  TypeSafeClient,
  type Questions,
  type SystemOneResult,
  type NoulQuestion,
  type NoulAnswer,
} from "@typesafe-ai/sdk";

export interface CacheEntry<Q extends Questions> {
  result: SystemOneResult<Q>;
  cachedAt: number;
  /** Last time this entry was touched; drives LRU eviction. */
  lastTouched: number;
}

export class BranchCache<Q extends Questions> {
  private readonly entries = new Map<string, CacheEntry<Q>>();

  constructor(
    private readonly opts: {
      ttlMs: number;
      maxEntries: number;
      client: TypeSafeClient;
      guardrailQuestion: NoulQuestion;
      onEvict?: (fingerprint: string) => void;
    },
  ) {}

  // Sorted question ids + normalized state -> deterministic key. Case and internal
  // whitespace are folded, because the same ticket re-typed should collide.
  private fingerprint(state: string, questions: Q): string {
    const normalized = state.replace(/\s+/g, " ").trim().toLowerCase();
    const shape = Object.keys(questions).sort().join(",");
    const payload = `${normalized}|${shape}`;
    // FNV-1a 32-bit; fast, uniform enough for a few hundred entries.
    let h = 0x811c9dc5;
    for (let i = 0; i < payload.length; i++) {
      h ^= payload.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16).padStart(8, "0");
  }

  private isFresh(entry: CacheEntry<Q>): boolean {
    return Date.now() - entry.cachedAt <= this.opts.ttlMs;
  }

  private touch(key: string, entry: CacheEntry<Q>): void {
    entry.lastTouched = Date.now();
    // Re-insert to move it to the end of the Map's insertion order, which is
    // how LRU is tracked here: oldest touched is first.
    this.entries.delete(key);
    this.entries.set(key, entry);
  }

  private evictOldest(): void {
    const first = this.entries.keys().next();
    if (first.done) return;
    const key = first.value;
    this.entries.delete(key);
    this.opts.onEvict?.(key);
  }

  private enforceCeiling(): void {
    while (this.entries.size > this.opts.maxEntries) this.evictOldest();
  }

  async get(
    state: string,
    questions: Q,
  ): Promise<{ result: SystemOneResult<Q>; source: "cache" | "fresh"; fingerprint: string }> {
    const key = this.fingerprint(state, questions);
    const hit = this.entries.get(key);

    if (hit && this.isFresh(hit)) {
      // Guardrail: one Noul call asking whether the cached analysis still applies
      // to the exact text below. This is the only bound on trusting a cache entry.
      const guard = await this.opts.client.systemOne({
        state,
        questions: { still_valid: this.opts.guardrailQuestion },
      });
      const noul = (guard.answers.still_valid as NoulAnswer).noul;
      if (noul >= 0.7) {
        this.touch(key, hit);
        return { result: hit.result, source: "cache", fingerprint: key };
      }
      // Guardrail failed -> invalidate and fall through to fresh.
      this.entries.delete(key);
    } else if (hit) {
      // Expired: remove silently (not capacity-driven), fall through.
      this.entries.delete(key);
    }

    const fresh = await this.opts.client.systemOne({ state, questions });
    const entry: CacheEntry<Q> = {
      result: fresh,
      cachedAt: Date.now(),
      lastTouched: Date.now(),
    };
    this.entries.set(key, entry);
    this.enforceCeiling();
    return { result: fresh, source: "fresh", fingerprint: key };
  }

  invalidate(fingerprint: string): void {
    // Explicit invalidation is a distinct event path from capacity-driven eviction
    // and therefore does NOT fire onEvict.
    this.entries.delete(fingerprint);
  }

  size(): number {
    return this.entries.size;
  }

  // Warm the cache without blocking an interactive path.
  async warmup(states: string[], questions: Q): Promise<void> {
    const pending = states.map(async (state) => {
      const key = this.fingerprint(state, questions);
      const entry = this.entries.get(key);
      if (entry && this.isFresh(entry)) return; // no-op for warm, unexpired entries
      const fresh = await this.opts.client.systemOne({ state, questions });
      this.entries.set(key, {
        result: fresh,
        cachedAt: Date.now(),
        lastTouched: Date.now(),
      });
      this.enforceCeiling();
    });
    await Promise.all(pending);
  }
}

// ---------- Late binding: always run the policy against cached answers ----------
import { PolicyEngine, type BranchPolicy } from "./policy";
import { type Questions as SDKQuestions } from "@typesafe-ai/sdk";

export class HydratingRouter<Q extends SDKQuestions> {
  constructor(
    private readonly cache: BranchCache<Q>,
    private readonly engine: PolicyEngine,
    private readonly policy: BranchPolicy,
  ) {}

  async route(state: string, questions: Q) {
    const { result, source, fingerprint } = await this.cache.get(state, questions);
    // Fresh timestamp: the answers are as old as the cache entry, but the
    // decision to act on them is made now, against now's timeouts and guardrails.
    const startedAt = Date.now();
    const commit = this.engine.commit(result, this.policy, startedAt);
    return { commit, source, fingerprint };
  }
}
