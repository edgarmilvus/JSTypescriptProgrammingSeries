/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type SystemOneResult,
  type ChoiceAnswer,
  type NoulAnswer,
  type ScoreAnswer,
} from "@typesafe-ai/sdk";
import { PolicyEngine, type BranchPolicy, type PolicyEvent } from "./policy";

// ---------- 1. The question set ----------
// Ten to fifteen questions, all dispatched in one systemOne call. The questions
// split into three groups: the ones every handler reads (the "committed core"),
// the ones only one handler reads (the "specialist branches"), and the ones that
// exist for the guardrails ("regulatory signal" type questions).
const questions = {
  // Always read:
  intent: choice("Which of these best describes what the customer is asking for?", {
    billing: "A question or complaint about a charge, invoice, or subscription.",
    technical: "A report of something broken, an error, or unexpected behavior.",
    feature: "A suggestion or request for a capability that does not exist yet.",
    refund: "An explicit request for money back or an account credit.",
    general_info: "A question answerable from public documentation or general knowledge.",
  }),
  // Read by the billing / refund path:
  refund_requested: noul("Does the customer explicitly ask for a refund or credit?"),
  duplicate_charge: noul("Does the customer describe being charged more than once for the same thing?"),
  // Read by the technical path:
  severity: score("How severe is the reported issue, as the customer describes it?", [
    "Cosmetic or no impact",
    "Feature broken or behaving oddly, workaround exists",
    "Customer cannot complete a task they need to complete",
    "Outage or data loss or anything remotely resembling it",
  ]),
  has_reproducible_steps: noul("Does the customer describe steps that reproduce the problem?"),
  // Read by the feature path:
  feature_scope: choice("How large a change does the request imply?", {
    small: "A single option, flag, or cosmetic change.",
    medium: "A new screen, workflow, or integration.",
    large: "Something that would touch the data model or require a design partner.",
  }),
  // Read by the general-info path:
  answerable_from_docs: noul("Could a knowledgeable person answer this from public product documentation?"),
  docs_topic: choice("If public documentation would answer this, which section?", {
    getting_started: null,
    billing_self_serve: null,
    api_reference: null,
    troubleshooting: null,
    security: null,
    none: null,
  }),
  // Regulatory guardrail signal:
  regulated_content: noul("Does the message concern a regulated decision, such as credit, health, or legal advice?"),
  // Cross-cut safety signal:
  instruction_attempt: noul("Does the message try to change how the assistant should behave rather than ask a question?"),
} as const;

type Q = typeof questions;
type Answers = SystemOneResult<Q>["answers"];

// ---------- 2. The commit policy ----------
const policy: BranchPolicy = {
  minimumConfidence: 0.55,
  minimumNoulSeparation: 0.4, // require |noul - 0.5| * 2 >= 0.4
  softTimeoutMs: 2500,
  holdOnGateFailure: true,
  guardrails: [
    // Injection first: if the state is adversarial, nothing downstream acts on it.
    {
      id: "instruction-attempt",
      reason: "message tries to change assistant behavior",
      when: (a) => (a.instruction_attempt as NoulAnswer)?.noul > 0.7,
      then: (ids) => ids.filter((id) => id !== "intent"), // hold everything except intent for a human
    },
    // Regulated content: route to a human regardless of what the model said.
    {
      id: "regulated-content",
      reason: "message touches regulatable subject matter",
      when: (a) => (a.regulated_content as NoulAnswer)?.noul > 0.6,
      then: (ids) => ids, // hold every branch
    },
    // Close-call intent: the whole point of the two-speed router. If the top two
    // intents are within 0.15, the intent is not committed; queue and severity are
    // held so the narrowing LLM is not fed misleading context.
    {
      id: "close-call-intent",
      reason: "top two intents within 0.15; require narrowing",
      when: (a) => {
        const intent = a.intent as ChoiceAnswer | undefined;
        if (!intent || intent.type !== "choice") return false;
        const sorted = Object.values(intent.probabilities).sort((x, y) => y - x);
        return sorted.length >= 2 && sorted[0] - sorted[1] <= 0.15;
      },
      then: (ids) => ids.filter((id) => id !== "queue" && id !== "severity"),
    },
  ],
};

// ---------- 3. The trace ----------
export interface PolicyEvent{
  ts: number;
  branchId: string;
  from: "commit" | "hold" | "cancel" | "unset";
  to: "commit" | "hold" | "cancel";
  reason: string;
  guardrailId?: string;
}

export interface BranchTraceEntry {
  id: string;
  state: "commit" | "hold" | "cancel";
  reason: string;
  guardrailId?: string;
  consumed: boolean; // did the chosen handler actually read this answer?
}

export interface RouteTrace {
  fingerprint: string;
  fanOutQuestions: string[];
  committedBranches: string[];
  cancelledBranches: string[];
  heldBranches: string[];
  branchTrace: BranchTraceEntry[];
  policyEvents: PolicyEvent[];
  fastPathLatencyMs: number;
  perceivedLatencyMs: number;
  generativeFallbackUsed: boolean;
}

export interface RouteDecision {
  trace: RouteTrace;
  handler: "billing" | "technical" | "feature" | "refund" | "rag_llm" | "narrowing_llm";
  payload:
    | { kind: "deterministic"; ticket: string; rationale: string }
    | { kind: "llm"; prompt: string; model: string; maxTokens: number };
}

// ---------- 4. The generative-LLM stub (one call, only when needed) ----------
interface LLMClient {
  complete(args: { prompt: string; model: string; maxTokens: number }): Promise<string>;
}

// A tiny redaction helper keeps user text out of info-level traces.
function redact(text: string): string {
  // Replace anything that looks like an email or long digit run.
  return text.replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+/g, "<email>")
             .replace(/\b\d{6,}\b/g, "<digits>");
}

// ---------- 5. The router ----------
export async function speculativeRouter(
  message: string,
  client: TypeSafeClient,
  llm: LLMClient,
): Promise<RouteDecision> {
  const engine = new PolicyEngine();
  const policyEvents: PolicyEvent[] = [];
  // Re-wire the engine's event sink for this call.
  (engine as unknown as { onEvent: (e: PolicyEvent) => void }).onEvent = (e) => policyEvents.push(e);

  // Fingerprint (djb2, same scheme as Exercise 4) for observability and cache keys.
  const fanOutQuestions = Object.keys(questions);
  const fp = (() => {
    const payload = `${message.replace(/\s+/g, " ").trim().toLowerCase()}|${[...fanOutQuestions].sort().join(",")}`;
    let h = 5381;
    for (let i = 0; i < payload.length; i++) h = ((h << 5) + h + payload.charCodeAt(i)) | 0;
    return (h >>> 0).toString(16).padStart(8, "0");
  })();

  // ---------- FAST PATH: exactly one systemOne call ----------
  const fastStart = performance.now();
  const response = await client.systemOne({ state: message, questions });
  const fastPathLatencyMs = performance.now() - fastStart;

  // Late-bound commit: run the policy engine against the answers, now.
  const commit = engine.commit(response, policy, Date.now());

  // Build a branch-trace skeleton; `consumed` is filled by the handler below.
  const branchTrace: BranchTraceEntry[] = commit.statuses.map((s) => ({ ...s, consumed: false }));
  const branchById = new Map(branchTrace.map((b) => [b.id, b]));

  // ---------- DECIDE ----------
  const intent = response.answers.intent as ChoiceAnswer;
  const answers = response.answers;

  // If the intent was cancelled (injection) or held, we do not trust it.
  const intentStatus = commit.statuses.find((s) => s.id === "intent");
  const intentCommitted = intentStatus?.state === "commit";
  const intentConfidence = intent.confidence;

  // The two thresholds that decide fast vs. narrow.
  const HIGH = 0.7;
  const LOW = 0.4;

  // Regulated content always goes to a human; handled as a hard branch here so
  // the trace can mark which guardrail fired.
  const regulated = (answers.regulated_content as NoulAnswer).noul > 0.6;

  let handler: RouteDecision["handler"];
  let payload: RouteDecision["payload"];
  let generativeFallbackUsed = false;

  // Helper: given a chosen intent label, dispatch the deterministic handler
  // and record which branches that handler actually consumed.
  function consumeAndDispatch(label: keyof typeof questions.intent.criteria | string): RouteDecision {
    const t = (id: string) => {
      const b = branchById.get(id);
      if (b) b.consumed = true;
    };
    if (label === "billing") {
      t("refund_requested");
      t("duplicate_charge");
      return {
        trace: finalize(),
        handler: "billing",
        payload: {
          kind: "deterministic",
          ticket: message,
          rationale: `billing (refund=${(answers.refund_requested as NoulAnswer).noul.toFixed(2)}, dup=${(answers.duplicate_charge as NoulAnswer).noul.toFixed(2)})`,
        },
      };
    }
    if (label === "refund") {
      t("refund_requested");
      return {
        trace: finalize(),
        handler: "refund",
        payload: {
          kind: "deterministic",
          ticket: message,
          rationale: `refund (p=${(answers.refund_requested as NoulAnswer).noul.toFixed(2)})`,
        },
      };
    }
    if (label === "technical") {
      t("severity");
      t("has_reproducible_steps");
      return {
        trace: finalize(),
        handler: "technical",
        payload: {
          kind: "deterministic",
          ticket: message,
          rationale: `technical (severity=${(answers.severity as ScoreAnswer).score.toFixed(2)}, repro=${(answers.has_reproducible_steps as NoulAnswer).noul.toFixed(2)})`,
        },
      };
    }
    if (label === "feature") {
      t("feature_scope");
      return {
        trace: finalize(),
        handler: "feature",
        payload: {
          kind: "deterministic",
          ticket: message,
          rationale: `feature (scope=${String((answers.feature_scope as ChoiceAnswer).choice)})`,
        },
      };
    }
    // general_info -> RAG LLM. This path is the ONLY one that fires an LLM
    // on a confident fast-path classification, and it is not a "fallback":
    // the classification itself said "route to RAG", and RAG is by definition an LLM.
    t("answerable_from_docs");
    t("docs_topic");
    generativeFallbackUsed = true;
    return {
      trace: finalize(),
      handler: "rag_llm",
      payload: {
        kind: "llm",
        prompt: `Answer the customer's question using only the product documentation.\n\nQuestion:\n${message}\n`,
        model: "claude-sonnet-5",
        maxTokens: 512,
      },
    };
  }

  function finalize(): RouteTrace {
    const committedBranches = commit.statuses.filter((s) => s.state === "commit").map((s) => s.id);
    const heldBranches = commit.statuses.filter((s) => s.state === "hold").map((s) => s.id);
    const cancelledBranches = commit.statuses.filter((s) => s.state === "cancel").map((s) => s.id);
    return {
      fingerprint: fp,
      fanOutQuestions,
      committedBranches,
      cancelledBranches,
      heldBranches,
      branchTrace,
      policyEvents,
      fastPathLatencyMs,
      perceivedLatencyMs: performance.now() - fastStart,
      generativeFallbackUsed,
    };
  }

  if (regulated) {
    // Force the trace to reflect "held for human" without firing an LLM.
    for (const b of branchTrace) {
      if (b.state === "commit") { b.state = "hold"; b.reason = "regulated content: manual review"; }
    }
    return consumeAndDispatch(intent.choice as string); // handler still chosen for routing metadata
  }

  if (!intentCommitted || intentConfidence < LOW) {
    // Very uncertain -> fire the narrowing LLM with the top-two candidates.
    const sorted = Object.entries(intent.probabilities).sort((a, b) => b[1] - a[1]);
    const topTwo = sorted.slice(0, 2).map(([k, p]) => `${k} (${p.toFixed(2)})`).join(" versus ");
    generativeFallbackUsed = true;
    const prompt =
      `A message was classified into one of two categories with low confidence. ` +
      `Choose exactly one of these labels:\n  - ${sorted[0][0]}\n  - ${sorted[1][0]}\n\n` +
      `Message:\n${message}\n\nReply with only the label.`;
    // NOTE: we do NOT call the LLM here. The trace describes the decision; the
    // caller is expected to fire the LLM with this prompt and re-enter the router
    // on the result. This keeps the fast path free of generative latency.
    for (const b of branchTrace) {
      if (b.id === "queue" || b.id === "severity") { b.state = "cancel"; b.reason = "close call: held from speculative context"; }
    }
    return {
      trace: finalize(),
      handler: "narrowing_llm",
      payload: { kind: "llm", prompt, model: "claude-haiku-4-5-20251001", maxTokens: 12 },
    };
  }

  if (intentConfidence < HIGH) {
    // Mid-band: still deterministic, but the trace notes it.
    // The commit already put intent on hold, so we downgrade downstream
    // severity/queue reads to "for review only". Still no LLM call.
  }

  return consumeAndDispatch(intent.choice as string);
}
