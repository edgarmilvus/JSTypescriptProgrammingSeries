/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// ---------- 6. Two-line log format ----------
export function logRoute(message: string, decision: RouteDecision): void {
  const t = decision.trace;
  const primary = t.branchTrace.find((b) => b.id === "intent");
  // Line 1: fan-out summary. State is redacted; the fingerprint is the join key.
  console.info(
    `[router/fanout] fp=${t.fingerprint} q=${t.fanOutQuestions.length} ` +
    `latency=${t.fastPathLatencyMs.toFixed(0)}ms text="${redact(message.slice(0, 80))}"`,
  );
  // Line 2: routing decision. Committed branches, handler, and consumed flags.
  const consumed = t.branchTrace.filter((b) => b.consumed).map((b) => b.id).join(",");
  console.info(
    `[router/decide] fp=${t.fingerprint} primary=${primary?.state ?? "unset"} ` +
    `committed=[${t.committedBranches.join(",")}] held=[${t.heldBranches.join(",")}] ` +
    `cancelled=[${t.cancelledBranches.join(",")}] consumed=[${consumed}] ` +
    `handler=${decision.handler} perceived=${t.perceivedLatencyMs.toFixed(0)}ms ` +
    `fallback=${t.generativeFallbackUsed}`,
  );
}

// ---------- 7. Adversarial test ----------
import { describe, it, expect } from "vitest";

describe("speculativeRouter adversarial case", () => {
  it("catches a polite feature request that reads as a bug report", async () => {
    const message =
      "It would be amazing if — and I know this is a long shot — you could make the export " +
      "button also run the report as a PDF. Not a bug report, everything works, it just " +
      "doesn’t exist yet. Thanks!";
    const decision = await speculativeRouter(message, client, llmStub);
    const trace = decision.trace;
    // The close-call guardrail should have cancelled queue and severity.
    assertCancelled(trace, "queue");
    assertCancelled(trace, "severity");
    // If intent was confident enough, we route to feature.
    if (decision.handler === "feature") {
      expect(trace.branchTrace.find((b) => b.id === "feature_scope")?.consumed).toBe(true);
    }
    // In no case does a "technical" handler fire on a feature request.
    expect(decision.handler).not.toBe("technical");
  });
});

function assertCancelled(trace: RouteTrace, id: string) {
  const b = trace.branchTrace.find((x) => x.id === id);
  if (!b) throw new Error(`branch ${id} not in trace`);
  if (b.state !== "cancel" && b.state !== "hold") {
    throw new Error(`expected ${id} cancelled/held, got ${b.state}`);
  }
}
