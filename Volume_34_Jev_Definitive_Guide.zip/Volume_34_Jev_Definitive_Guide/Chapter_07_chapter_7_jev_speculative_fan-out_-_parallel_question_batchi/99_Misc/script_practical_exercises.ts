/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import {
  TypeSafeClient,
  type EntryType,
  type Questions,
  type SystemOneResult,
  type Question,
} from "@typesafe-ai/sdk";

export interface FanOutPlan<Q extends Questions> {
  state: EntryType;
  questions: Q;
  fingerprint: string;
  plannedAt: number;
}

export class PlanTooLargeError extends Error {
  constructor(public readonly bytes: number, public readonly capacity: number) {
    super(`Plan exceeds shared buffer: ${bytes} > ${capacity}`);
  }
}

export class TooManyQuestionsError extends Error {
  constructor(public readonly count: number, public readonly limit: number) {
    super(`Too many questions: ${count} > ${limit}`);
  }
}

export class WorkerPool {
  constructor(
    private readonly client: TypeSafeClient,
    private readonly workers: number,
    private readonly bufferCapacityBytes: number,
    private readonly maxQuestions: number,
  ) {
    // your job: spawn workers, allocate SharedArrayBuffers
  }

  plan<Q extends Questions>(state: EntryType, build: () => Q): Promise<FanOutPlan<Q>> {
    // your job: hash, normalize, validate, serialize into shared memory
    throw new Error("not implemented");
  }

  dispatch<Q extends Questions>(
    plan: FanOutPlan<Q>,
  ): Promise<SystemOneResult<Q>> {
    // your job: systemOne call, attach plan metadata
    throw new Error("not implemented");
  }
}
