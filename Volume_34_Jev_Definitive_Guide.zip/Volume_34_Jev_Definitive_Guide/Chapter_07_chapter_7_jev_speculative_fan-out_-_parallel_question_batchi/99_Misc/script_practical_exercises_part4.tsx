/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import { useEffect, useMemo, useRef, useState } from "react";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  RateLimitError,
  type SystemOneResult,
  type ChoiceAnswer,
  type ScoreAnswer,
  type NoulAnswer,
} from "@typesafe-ai/sdk";

const questions = {
  intent: choice("What is the customer primarily asking for?", {
    billing: "Payment, invoice, refund, or subscription issues",
    shipping: "Delivery, tracking, delay, or lost package",
    returns: "Exchange, defect, or wrong-item complaint",
    account: "Login, permissions, or security concerns",
    other: "Anything that does not fit the above",
  }),
  queue: choice("Which team should own this ticket?", {
    frontline: null,
    billing_ops: null,
    logistics: null,
    fraud_billing: null,
    engineering: null,
  }),
  severity: score("How severe is the underlying issue?", [
    "Cosmetic or ignore-able",
    "Minor inconvenience, workaround exists",
    "Material disruption to the customer",
    "Blocking; no workaround",
  ]),
  frustration: score("How frustrated does the customer sound?", [
    "Calm",
    "Frustrated but civil",
    "Visibly angry",
    "Threatening to leave",
  ]),
  refund_requested: noul("Is the customer explicitly requesting a refund?"),
  urgency: noul("Does the message convey time-sensitivity?"),
  screenshot_attached: noul("Does the message refer to an attached screenshot or image?"),
} as const;

type Q = typeof questions;

export interface SpeculativeTriagePreviewProps {
  text: string;
  client: TypeSafeClient;
  minChars?: number;
  settleMs?: number;
  confidenceFloor?: number;
  onError?: (e: Error) => void;
}

export function SpeculativeTriagePreview(props: SpeculativeTriagePreviewProps) {
  // your job: debounce, abort, dispatch, render
  return null;
}
