/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

export interface BranchPolicy {
  /** For Choice and Score answers: minimum confidence required to commit. */
  minimumConfidence: number;
  /** For Noul answers: minimum |p - 0.5| * 2 required to commit on either side. */
  minimumNoulSeparation: number;
  /** Maximum allowed round-trip time before every branch is downgraded to hold. */
  softTimeoutMs: number;
  /** Answers from branches whose primary gate is violated may still be held if this is true. */
  holdOnGateFailure: boolean;
  /** Cross-question guardrails, evaluated in order. First matched rule wins. */
  guardrails: Guardrail[];
}

export interface Guardrail {
  id: string;
  /** If this returns true, `then` is applied to the named branches. */
  when: (answers: SystemOneResult<any>["answers"]) => boolean;
  then: (branchIds: string[]) => void;
  reason: string;
}
