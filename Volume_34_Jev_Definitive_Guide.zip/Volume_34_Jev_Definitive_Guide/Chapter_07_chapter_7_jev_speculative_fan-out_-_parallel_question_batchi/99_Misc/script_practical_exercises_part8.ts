/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part8.ts
// Description: Practical Exercises
// ==========================================

import {
  type SystemOneResult,
  type Questions,
  type Question,
  type ChoiceAnswer,
  type ScoreAnswer,
  type NoulAnswer,
} from "@typesafe-ai/sdk";

export type AnswerFor<Q extends Question> =
  Q extends { type: "choice" } ? ChoiceAnswer :
  Q extends { type: "score" }  ? ScoreAnswer  :
  Q extends { type: "noul" }   ? NoulAnswer   :
  never;

export interface BranchPolicy { /* as above */ }
export interface Guardrail { /* as above */ }
export interface BranchStatus { /* as above */ }
export interface CommitSet<Q extends Questions> { /* as above */ }
export interface PolicyEvent { /* as above */ }

export class PolicyEngine {
  constructor(private readonly onEvent?: (e: PolicyEvent) => void) {}

  commit<Q extends Questions>(
    result: SystemOneResult<Q>,
    policy: BranchPolicy,
    startedAt: number,
  ): CommitSet<Q> {
    // your job
    throw new Error("not implemented");
  }
}
