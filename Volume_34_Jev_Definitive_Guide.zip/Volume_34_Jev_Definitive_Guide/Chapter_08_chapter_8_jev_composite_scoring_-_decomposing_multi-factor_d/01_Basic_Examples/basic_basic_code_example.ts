/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * lead-scoring.ts
 *
 * Composite scoring with Jev — the minimal working example.
 *
 * Scenario: a B2B SaaS app receives inbound leads and needs to decide, on
 * every new lead, whether to route it to sales (qualified), put it in a
 * nurture sequence, or drop it. Instead of one big prompt that asks an LLM
 * to "rate this lead from 0 to 1", we ask Jev four narrow questions, convert
 * each answer into a number in [0, 1], and combine them with weights that
 * live in our code.
 *
 * Run with:   TYPESAFE_API_KEY=... npx tsx lead-scoring.ts
 */

import {
  TypeSafeClient,
  score,
  noul,
  choice,
} from "@typesafe-ai/sdk";
import type {
  ScoreResponse,
  NoulResponse,
  ChoiceResponse,
} from "@typesafe-ai/sdk";

// -----------------------------------------------------------------------------
// 1. The client. Reads TYPESAFE_API_KEY from the environment.
// -----------------------------------------------------------------------------
const client = new TypeSafeClient();

// -----------------------------------------------------------------------------
// 2. The state: the data Jev will judge. In a real app this comes from your
//    form, CRM webhook, or inbound email pipeline.
// -----------------------------------------------------------------------------
const leadState = {
  company: "Northwind Logistics",
  employees: 480,
  industry: "freight & logistics",
  message:
    "We need to consolidate our dispatch tooling before Q3. Our current vendor's contract ends August 1st and we're actively evaluating replacements now.",
  source: "inbound demo request",
};

// -----------------------------------------------------------------------------
// 3. The weights. These are the coefficients that make the score *composite*.
//    They must sum to 1.0 if you want the final number to stay on a 0–1 scale.
//    Change one, rerun, and the ranking shifts — no prompt engineering.
// -----------------------------------------------------------------------------
const WEIGHTS = {
  companySize: 0.20,
  urgency: 0.35,
  budget: 0.25,
  icpFit: 0.20,
} as const;

// -----------------------------------------------------------------------------
// 4. The questions. Four atomic judgments, one per factor. All three Jev
//    question types appear: two Score, one Noul, one Choice.
// -----------------------------------------------------------------------------
const questions = {
  companySize: score(
    "How large is this company, judged by the employee count and any scale cues in the message?",
    [
      "Under 10 employees — sole trader or hobby scale",
      "10–49 employees — small team",
      "50–199 employees — growing company",
      "200–999 employees — mid-market",
      "1,000+ employees — enterprise",
    ],
  ),
  urgency: score(
    "How urgent is this lead's stated timeline?",
    [
      "No timeline mentioned at all",
      "Vague future interest — 'someday', 'next year'",
      "Named quarter or season, but not imminent",
      "Specific near-term deadline measured in weeks",
      "Immediate need — deadline this week or explicit crisis",
    ],
  ),
  budget: noul(
    "Does the message contain a concrete budget signal — a stated amount, an approved budget, or a live procurement event such as a vendor contract ending?",
    {
      true: "A specific budget, allocation, or procurement event is named",
      false: "No budget information is present in the message",
    },
  ),
  icpFit: choice(
    "How well does this lead match our ideal customer profile (mid-market B2B SaaS or logistics companies buying operational tooling)?",
    {
      strong: "Clear match — right size, right industry, right problem",
      moderate: "Adjacent fit — one dimension is off, the rest line up",
      weak: "Poor fit — wrong segment, wrong industry, or off-topic",
    },
  ),
};

// -----------------------------------------------------------------------------
// 5. Normalization. Every answer type lands on 0–1 before it is weighted.
//    This is what lets a Score, a Noul, and a Choice sit inside the same sum.
// -----------------------------------------------------------------------------
const SCORE_TOP = 4; // both score rubrics have 5 levels: 0..4
const CHOICE_MAP: Record<string, number> = {
  strong: 1.0,
  moderate: 0.55,
  weak: 0.1,
};

function normalizeScore(answer: ScoreResponse<any>): number {
  return answer.score / SCORE_TOP;
}

function normalizeNoul(answer: NoulResponse): number {
  return answer.noul;
}

function normalizeChoice(
  answer: ChoiceResponse<any>,
  map: Record<string, number>,
): number {
  return map[answer.choice] ?? 0;
}

// -----------------------------------------------------------------------------
// 6. Types for the result of scoring one lead.
// -----------------------------------------------------------------------------
type FactorValues = {
  companySize: number;
  urgency: number;
  budget: number;
  icpFit: number;
};

type LeadScore = {
  total: number;
  factors: FactorValues;
  decision: "qualified" | "nurture" | "disqualify";
  raw: {
    companySize: ScoreResponse<any>;
    urgency: ScoreResponse<any>;
    budget: NoulResponse;
    icpFit: ChoiceResponse<any>;
  };
};

// -----------------------------------------------------------------------------
// 7. The composite scorer. One Jev request in, one weighted number out.
// -----------------------------------------------------------------------------
async function scoreLead(lead: typeof leadState): Promise<LeadScore> {
  const response = await client.systemOne({
    state: lead,
    questions,
  });

  const a = response.answers;

  const factors: FactorValues = {
    companySize: normalizeScore(a.companySize),
    urgency: normalizeScore(a.urgency),
    budget: normalizeNoul(a.budget),
    icpFit: normalizeChoice(a.icpFit, CHOICE_MAP),
  };

  const total =
    factors.companySize * WEIGHTS.companySize +
    factors.urgency * WEIGHTS.urgency +
    factors.budget * WEIGHTS.budget +
    factors.icpFit * WEIGHTS.icpFit;

  const decision: LeadScore["decision"] =
    total >= 0.7 ? "qualified" : total >= 0.5 ? "nurture" : "disqualify";

  return { total, factors, decision, raw: a };
}

// -----------------------------------------------------------------------------
// 8. Run it.
// -----------------------------------------------------------------------------
const result = await scoreLead(leadState);

console.log(`Total score: ${result.total.toFixed(3)}`);
console.log("Factor contributions:");
for (const [name, value] of Object.entries(result.factors)) {
  const weight = WEIGHTS[name as keyof typeof WEIGHTS];
  const contribution = value * weight;
  console.log(
    `  ${name.padEnd(12)} ${value.toFixed(3)}  × ${weight.toFixed(2)}  =  ${contribution.toFixed(3)}`,
  );
}
console.log(`Decision: ${result.decision}`);
