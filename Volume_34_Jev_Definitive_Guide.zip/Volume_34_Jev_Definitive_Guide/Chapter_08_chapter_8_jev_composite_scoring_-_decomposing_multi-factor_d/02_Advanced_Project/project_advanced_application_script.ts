/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @file    app/api/rfp/triage/route.ts
 * @summary Composite bid/no-bid scorecard for inbound RFPs.
 *
 * Pipeline: deterministic gates (code) -> one Jev call over six typed questions ->
 * normalize each factor to 0..1 -> weighted sum -> confidence-gated routing.
 * Added latency on top of the tenant's database read: ~110 ms.
 */

import { NextResponse } from "next/server";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type Questions,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

/* ─────────────────────────── 1. POLICY AND WEIGHTS ─────────────────────────── */

/** Every tunable number lives here, and only here. Reviewers read this block first. */
const POLICY = {
  minDealSizeUsd: 25_000,
  onboardingLeadDays: 45,
  bidThreshold: 0.62,
  reviewThreshold: 0.47,
  minDecisiveConfidence: 0.55,
} as const;

/** Factor weights. Must sum to 1.0 over the six semantic factors. */
const WEIGHTS = {
  technicalFit: 0.26,
  budgetCredibility: 0.18,
  incumbentPain: 0.16,
  procurementEase: 0.14,
  verticalFit: 0.14,
  budgetAuthority: 0.12,
} as const;

/** Maps the *full* Choice distribution onto a 0..1 vertical-fit value. */
const VERTICAL_FIT: Record<string, number> = {
  fintech: 1.0,
  developer_tools: 1.0,
  healthcare: 0.85,
  logistics: 0.7,
  public_sector: 0.3,
  other: 0.55,
};

/* ─────────────────────────── 2. THE SIX QUESTIONS ─────────────────────────── */

/**
 * One Jev request, six questions, evaluated in parallel against the same state.
 * Rubrics describe *situations*, never degrees: "About half: meaningful overlap"
 * beats "moderately good" because the model has something to match against.
 */
const RFP_QUESTIONS = {
  technical_fit: score(
    "How much of what this RFP asks for does the product already do today, with configuration rather than bespoke engineering?",
    [
      "Almost none of it: the ask sits adjacent to what the product does",
      "A minority: a few relevant capabilities, major gaps remain",
      "About half: meaningful overlap, but real gaps that need building",
      "Most of it: standard configuration covers nearly everything asked",
      "Essentially all of it: a near out-of-the-box fit",
    ],
  ),
  budget_credibility: score(
    "How committed does the funding behind this RFP appear, judging only from what `rfp.body_excerpt` says about budget?",
    [
      "Speculative: a wish list, no funding referenced anywhere",
      "Exploring: cost being researched, no approval in flight",
      "Plausible: a figure or range is named and an owner is implied",
      "Committed: an approved figure or signed budget line is referenced",
    ],
  ),
  procurement_friction: score(
    "How heavy will procurement, legal, and security review be before a signature, judging from the process this RFP describes?",
    [
      "Light: a direct purchase path with no formal review described",
      "Moderate: standard vendor paperwork plus a security questionnaire",
      "Heavy: multi-stage review, several approvers, a long cycle implied",
      "Extreme: formal tender, public procurement rules, or an open RFP pool",
    ],
  ),
  incumbent_pain: noul(
    "Does `rfp.body_excerpt` describe a concrete, current failure of an existing tool that this product is specifically built to fix?",
    {
      true: "It names a specific broken workflow, cost overrun, or outage tied to an incumbent",
      false: "It describes a greenfield need, or general dissatisfaction with no named failure",
    },
  ),
  budget_authority: noul(
    "Does the RFP indicate that its author, or the person they report to, holds authority to commit budget?",
    {
      true: "The sender is an executive, owner, or explicitly delegated budget holder",
      false: "The sender is gathering information, or their role implies no budget authority",
    },
  ),
  vertical: choice(
    "Which industry does the requesting organisation primarily operate in?",
    {
      fintech: "Banking, payments, lending, insurance, or crypto infrastructure",
      healthcare: "Providers, payers, clinical software, or life sciences",
      developer_tools: "Software companies whose product is used by engineers",
      logistics: "Freight, warehousing, fleet, or supply-chain operations",
      public_sector: "Government, municipal, education, or publicly funded bodies",
      other: "An industry that fits none of the above",
    },
  ),
} satisfies Questions;

/** Answer types are inferred from the questions map; no hand-written interfaces. */
type RfpAnswers = SystemOneResult<typeof RFP_QUESTIONS>["answers"];

const client = new TypeSafeClient();

/* ─────────────────────────── 3. PURE HELPERS ─────────────────────────── */

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));
const daysBetween = (from: Date, to: Date) => Math.round((+to - +from) / 86_400_000);
/** Normalize a Score answer by its own top level: a 4-level rubric tops out at 3. */
const normScore = (raw: number, levels: number) => clamp01(raw / (levels - 1));
/** Expectation over the full Choice distribution, not just the winning label. */
const expectedChoice = (
  probs: Readonly<Record<string, number>>,
  table: Record<string, number>,
) =>
  Object.entries(probs).reduce((sum, [label, p]) => sum + (table[label] ?? 0) * p, 0);

/** Shape of the state Jev sees. Only the fields the six questions actually need. */
function buildState(rfp: RfpInput, account: AccountInput) {
  return {
    rfp: {
      subject: rfp.subject,
      body_excerpt: rfp.bodyExcerpt,
      stated_budget_usd: rfp.statedBudgetUsd,
      required_go_live: rfp.requiredGoLive,
      named_incumbent: rfp.namedIncumbent ?? "none stated",
      security_review_pages: rfp.securityReviewPages,
    },
    account: { segment: account.segment, prior_touchpoints: account.priorTouchpoints },
    policy: {
      minimum_deal_size_usd: POLICY.minDealSizeUsd,
      typical_onboarding_lead_days: POLICY.onboardingLeadDays,
    },
  };
}

/* ─────────────────────────── 4. THE HANDLER ─────────────────────────── */

export async function POST(request: Request) {
  const { rfp, account, tenantNamespace } = (await request.json()) as {
    rfp: RfpInput;
    account: AccountInput;
    tenantNamespace: string;
  };

  /* Gate A — arithmetic. A dead timeline or a budget under the floor never
     reaches the model: no tokens spent, no latency added, no ambiguity. */
  const leadDays = daysBetween(new Date(), new Date(rfp.requiredGoLive));
  const budgetMeetsFloor = rfp.statedBudgetUsd >= POLICY.minDealSizeUsd;
  if (!budgetMeetsFloor || leadDays < 0) {
    return NextResponse.json({
      decision: "decline",
      reason: !budgetMeetsFloor ? "below_budget_floor" : "go_live_already_passed",
      composite: null,
    });
  }

  /* Gate B — one Jev call, six factors. The model id is pinned rather than
     `jev-latest` so a threshold tuned today keeps its meaning next month. */
  const { answers } = await client.systemOne({
    state: buildState(rfp, account),
    questions: RFP_QUESTIONS,
    model: "jev-1.13.0",
  });

  /* Gate C — normalize every factor onto the same 0..1 axis. A Score lands
     between levels, so it is divided by its own top level; a Choice expectation
     is already a weighted average of 0..1 values; a Noul is a probability. */
  const factors = {
    technicalFit: normScore(answers.technical_fit.score, 5),
    budgetCredibility: normScore(answers.budget_credibility.score, 4),
    incumbentPain: answers.incumbent_pain.noul,
    procurementEase: 1 - normScore(answers.procurement_friction.score, 4),
    verticalFit: expectedChoice(answers.vertical.probabilities, VERTICAL_FIT),
    budgetAuthority: answers.budget_authority.noul,
  } satisfies Record<keyof typeof WEIGHTS, number>;

  /* Gate D — the weighted sum, with per-factor contributions retained so the
     response can explain itself without a second pass over the numbers. */
  const contributions = (Object.keys(WEIGHTS) as (keyof typeof WEIGHTS)[]).map((f) => ({
    factor: f,
    weight: WEIGHTS[f],
    value: Number(factors[f].toFixed(3)),
    points: Number((WEIGHTS[f] * factors[f]).toFixed(4)),
  }));
  const composite = Number(
    contributions.reduce((sum, c) => sum + c.points, 0).toFixed(4),
  );

  /* Gate E — how decisive was the judgement? Choice and Score answers carry a
     confidence; Noul answers do not, so a Noul near 0.5 is treated as its own
     kind of hedge rather than being silently folded into the average. */
  const decisiveConfidence = Math.min(
    answers.technical_fit.confidence,
    answers.budget_credibility.confidence,
    answers.procurement_friction.confidence,
    answers.vertical.confidence,
  );
  const ambiguousBinaries = [answers.incumbent_pain.noul, answers.budget_authority.noul]
    .filter((p) => p > 0.35 && p < 0.65).length;

  /* Gate F — route. The composite picks the band; confidence and the deterministic
     timeline check decide whether we may act on it without a human. */
  const timelineFeasible = leadDays >= POLICY.onboardingLeadDays;
  const decisive = decisiveConfidence >= POLICY.minDecisiveConfidence && ambiguousBinaries === 0;
  let decision: "bid" | "bid_with_review" | "decline";
  if (composite < POLICY.reviewThreshold) decision = "decline";
  else if (composite >= POLICY.bidThreshold && decisive && timelineFeasible) decision = "bid";
  else decision = "bid_with_review";

  /* Persist the six-factor vector into the tenant's calibration namespace so that
     closed-won outcomes can later be joined back onto it and the weights refit. */
  await calibrationStore?.upsert({
    namespace: tenantNamespace,
    id: `rfp:${rfp.id}`,
    values: Object.values(factors),
    metadata: { decision, composite, decisiveConfidence, vectorOrder: Object.keys(factors) },
  });

  return NextResponse.json({
    decision,
    composite,
    decisiveConfidence: Number(decisiveConfidence.toFixed(3)),
    timelineFeasible,
    leadDays,
    contributions: contributions.sort((a, b) => b.points - a.points),
  });
}

/* ─────────────────────── 5. TYPES AND CALIBRATION STORE ─────────────────────── */

interface RfpInput {
  id: string;
  subject: string;
  bodyExcerpt: string;
  statedBudgetUsd: number;
  requiredGoLive: string;
  namedIncumbent?: string;
  securityReviewPages: number;
}
interface AccountInput { segment: string; priorTouchpoints: number }

/**
 * Pinecone namespaces are logical partitions inside a single index. One tenant's
 * threshold-tuning corpus stays isolated from every other tenant's without the
 * cost of provisioning a separate index per customer.
 */
interface CalibrationStore {
  upsert(args: {
    namespace: string;
    id: string;
    values: number[];
    metadata: Record<string, unknown>;
  }): Promise<void>;
}

let calibrationStore: CalibrationStore | null = null;
/** Injected at bootstrap so the handler stays testable without a network. */
export function setCalibrationStore(store: CalibrationStore) {
  calibrationStore = store;
}
