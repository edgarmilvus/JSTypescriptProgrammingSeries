/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 1: recruiting composite scorecard
import {
  noul,
  score,
  TypeSafeClient,
  type NoulResponse,
  type Questions,
  type ScoreResponse,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

/**
 * Dimension justifications:
 * - backend_depth: years alone hide whether someone has owned production systems.
 * - systems_design: senior backend work lives or dies on architecture and tradeoff judgment.
 * - coding_quality: production code quality is distinct from system-design ability.
 * - communication: senior engineers write docs, reviews, and cross-team proposals.
 * - ownership_scope: on-call, incidents, and end-to-end delivery are separate from raw coding.
 * - stack_fit: useful signal, but not a proxy for engineering strength.
 * - red_flag: yes/no concern; P(red flag) is itself the signal, so Noul is correct.
 *
 * Calibration note:
 * If a résumé is borderline on systems_design, e.g. has designed one service but not scaled
 * it, the Score answer may spread probability across two adjacent levels. Confidence should
 * be low there. That is correct behavior: the model is saying the evidence does not clearly
 * place the candidate. We should route that uncertainty, not pretend it is a precise score.
 */
export const questionnaire = {
  backend_depth: score(
    "How deep is the candidate's backend engineering experience?",
    [
      "No production backend work; only coursework, toy projects, or unrelated experience.",
      "Has shipped small backend services, but with heavy supervision or narrow ownership.",
      "Has owned production backend services, including on-call or incident response.",
      "Has designed and operated high-scale backend systems and owned reliability outcomes.",
    ] as const,
  ),

  systems_design: score(
    "How strong is the candidate's systems-design judgment for senior backend work?",
    [
      "No evidence of designing systems beyond small features.",
      "Can describe components, but not tradeoffs around scaling, consistency, or failure.",
      "Has designed a production service with explicit tradeoffs and failure handling.",
      "Has led architecture for multi-service systems with scaling, migration, and reliability concerns.",
    ] as const,
  ),

  coding_quality: score(
    "How strong is the candidate's evidence of production code quality?",
    [
      "No evidence of tests, reviews, or maintainable production code.",
      "Has written production code, but little evidence of testing or review discipline.",
      "Has owned code with tests, reviews, and maintainability expectations.",
      "Has set code-quality standards: test strategy, review culture, or maintainability programs.",
    ] as const,
  ),

  communication: score(
    "How strong is the candidate's written and cross-team communication?",
    [
      "No evidence of design docs, reviews, or cross-team communication.",
      "Has communicated within a small team, but little evidence of cross-team influence.",
      "Has written design docs or reviews that shaped a team's work.",
      "Has driven cross-team technical decisions through written proposals and alignment.",
    ] as const,
  ),

  ownership_scope: score(
    "How broad is the candidate's ownership scope?",
    [
      "Completes assigned tasks; no evidence of end-to-end ownership.",
      "Owns a feature or component through delivery.",
      "Owns a service or subsystem, including deployment, monitoring, and incidents.",
      "Owns outcomes across multiple services, teams, or reliability domains.",
    ] as const,
  ),

  stack_fit: score(
    "How closely does the candidate's stack experience match our environment?",
    [
      "No meaningful overlap with our backend stack.",
      "Adjacent language or framework experience; would need ramp-up.",
      "Has used several parts of our stack in production.",
      "Has deep production experience with our core stack and its operational tradeoffs.",
    ] as const,
  ),

  red_flag: noul(
    "Does the résumé contain a material red flag for a senior backend hire?",
    {
      true: "A serious concern: repeated short stints, unverifiable claims, or evidence of harmful team behavior.",
      false: "No material red flag appears in the résumé.",
    },
  ),
} satisfies Questions;

export type Questionnaire = typeof questionnaire;
export type CandidateAnswers = SystemOneResult<Questionnaire>["answers"];
export type Weights = Record<keyof Questionnaire, number>;

export async function scoreCandidate(
  client: TypeSafeClient,
  resume: string,
): Promise<SystemOneResult<Questionnaire>> {
  const state = {
    role: "senior_backend_engineer",
    company_stage: "series_b",
    resume,
  };

  return client.systemOne({
    state,
    questions: questionnaire,
  });
}
