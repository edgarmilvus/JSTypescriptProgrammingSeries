/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 2: composite aggregation
import type {
  NoulResponse,
  Questions,
  ScoreCriteria,
  ScoreResponse,
  SystemOneResult,
} from "@typesafe-ai/sdk";

const EPSILON = 1e-9;

export type NormalizedScore = number & { readonly __brand: "NormalizedScore" };

function clamp01(value: number): NormalizedScore {
  return Math.min(1, Math.max(0, value)) as NormalizedScore;
}

export function normalizeScore(
  answer: ScoreResponse,
  criteria: ScoreCriteria,
): NormalizedScore {
  const topLevel = criteria.length - 1;
  if (topLevel < 1) {
    throw new Error("Score criteria must contain at least two levels.");
  }

  return clamp01(answer.score / topLevel);
}

export function normalizeNoul(answer: NoulResponse): NormalizedScore {
  return clamp01(answer.noul);
}

export function normalizeNoulInverted(answer: NoulResponse): NormalizedScore {
  return clamp01(1 - answer.noul);
}

export type FactorContribution = {
  raw: number;
  normalized: NormalizedScore;
  weighted: number;
  weight: number;
  confidence: number;
};

export type CompositeResult<Q extends Questions> = {
  composite: number;
  contributions: Record<keyof Q, FactorContribution>;
  lowestConfidence: number;
  weightedConfidence: number;
};

export function validateWeights<Q extends Questions>(
  weights: Record<keyof Q, number>,
  questions: Q,
): void {
  const keys = Object.keys(questions) as (keyof Q)[];

  for (const key of keys) {
    const weight = weights[key];
    if (typeof weight !== "number" || Number.isNaN(weight)) {
      throw new Error(`Missing or invalid weight for factor "${String(key)}".`);
    }
  }

  const sum = keys.reduce((total, key) => total + weights[key], 0);
  if (Math.abs(sum - 1) > 1e-9) {
    const message = `Weights must sum to 1.0, got ${sum}.`;
    if (process.env.NODE_ENV !== "production") {
      throw new Error(message);
    }
    console.warn(message);
  }
}

export function compositeFactorScores<Q extends Questions>(
  answers: SystemOneResult<Q>["answers"],
  questions: Q,
  weights: Record<keyof Q, number>,
  options: {
    normalize?: boolean;
    invert?: ReadonlySet<keyof Q>;
    weighting?: "linear" | "geometric";
  } = {},
): CompositeResult<Q> {
  validateWeights(weights, questions);

  const weighting = options.weighting ?? "linear";
  const contributions = {} as Record<keyof Q, FactorContribution>;

  let linearSum = 0;
  let geometricLogSum = 0;
  let lowestConfidence = Number.POSITIVE_INFINITY;
  let weightedConfidenceSum = 0;
  let weightSum = 0;

  for (const key of Object.keys(questions) as (keyof Q)[]) {
    const question = questions[key];
    const answer = answers[key] as unknown;
    const weight = weights[key];

    let raw: number;
    let normalized: NormalizedScore;
    let confidence: number;

    if (question.type === "score") {
      const scoreAnswer = answer as ScoreResponse;
      raw = scoreAnswer.score;
      normalized = normalizeScore(scoreAnswer, question.criteria as ScoreCriteria);
      confidence = scoreAnswer.confidence;
    } else if (question.type === "noul") {
      const noulAnswer = answer as NoulResponse;
      raw = noulAnswer.noul;
      normalized = options.invert?.has(key)
        ? normalizeNoulInverted(noulAnswer)
        : normalizeNoul(noulAnswer);

      // Noul has no separate confidence field. Use distance from 0.5 as a proxy.
      confidence = Math.max(noulAnswer.noul, 1 - noulAnswer.noul);
    } else {
      throw new Error(`Unsupported question type for key "${String(key)}".`);
    }

    const weighted = normalized * weight;

    contributions[key] = {
      raw,
      normalized,
      weighted,
      weight,
      confidence,
    };

    linearSum += weighted;
    geometricLogSum += weight * Math.log(Math.max(normalized, EPSILON));
    lowestConfidence = Math.min(lowestConfidence, confidence);
    weightedConfidenceSum += confidence * weight;
    weightSum += weight;
  }

  const composite =
    weighting === "linear" ? linearSum : Math.exp(geometricLogSum);

  return {
    composite,
    contributions,
    lowestConfidence: Number.isFinite(lowestConfidence) ? lowestConfidence : 0,
    weightedConfidence: weightSum > 0 ? weightedConfidenceSum / weightSum : 0,
  };
}

// ---------------------------------------------------------------------------
// Test harness
// ---------------------------------------------------------------------------

if (process.env.NODE_ENV !== "production") {
  const criteria = ["low", "mid", "high"] as const;

  const peaked: ScoreResponse = {
    type: "score",
    score: 2,
    confidence: 0.95,
    legend: { 0: "low", 1: "mid", 2: "high" },
    probabilities: { 0: 0.02, 1: 0.03, 2: 0.95 },
  };

  const flat: ScoreResponse = {
    type: "score",
    score: 1.5,
    confidence: 0.3,
    legend: { 0: "low", 1: "mid", 2: "high" },
    probabilities: { 0: 0.1, 1: 0.45, 2: 0.45 },
  };

  console.log("Peaked normalized:", normalizeScore(peaked, criteria));
  console.log("Flat normalized:", normalizeScore(flat, criteria));

  // The flat distribution should normalize closer to the midpoint because probability
  // is spread across levels 1 and 2. Its confidence is much lower, which is the signal
  // that the candidate should be reviewed rather than ranked as if the score were precise.
}
