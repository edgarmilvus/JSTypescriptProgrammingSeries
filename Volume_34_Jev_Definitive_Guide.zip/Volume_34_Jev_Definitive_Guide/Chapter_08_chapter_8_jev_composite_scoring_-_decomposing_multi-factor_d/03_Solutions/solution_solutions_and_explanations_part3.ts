/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { SystemOneResult } from "@typesafe-ai/sdk";
import {
  questionnaire,
  type Questionnaire,
  type Weights,
} from "../scoring/questionnaire";
import {
  compositeFactorScores,
  type FactorContribution as CoreContribution,
} from "../scoring/composite";

const WEIGHTS: Weights = {
  backend_depth: 0.2,
  systems_design: 0.25,
  coding_quality: 0.15,
  communication: 0.15,
  ownership_scope: 0.15,
  stack_fit: 0.05,
  red_flag: 0.05,
};

const THRESHOLDS = {
  reviewBelow: 0.6,
  highConfidence: 0.85,
} as const;

const FACTOR_META: Record<keyof Questionnaire, { label: string }> = {
  backend_depth: { label: "Backend depth" },
  systems_design: { label: "Systems design" },
  coding_quality: { label: "Code quality" },
  communication: { label: "Communication" },
  ownership_scope: { label: "Ownership" },
  stack_fit: { label: "Stack fit" },
  red_flag: { label: "Red flag" },
};

type FactorContribution = {
  key: keyof Questionnaire;
  label: string;
  questionText: string;
  raw: number;
  normalized: number;
  weighted: number;
  percent: number;
  confidence: number;
};

type ScorecardData = {
  composite: number;
  lowestConfidence: number;
  weightedConfidence: number;
  factors: FactorContribution[];
};

type Props = {
  candidateId: string;
  onRequestReview?: (candidateId: string) => void;
};

type LoadState =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; raw: SystemOneResult<Questionnaire> };

function questionTextOf(question: Questionnaire[keyof Questionnaire]): string {
  const instructions = question.instructions;
  if (typeof instructions === "string") return instructions;
  if (instructions == null) return "";
  if (Array.isArray(instructions)) return instructions.join(" ");
  return JSON.stringify(instructions);
}

function extractScorecardData(
  answers: SystemOneResult<Questionnaire>["answers"],
  weights: Weights,
): ScorecardData {
  const result = compositeFactorScores(answers, questionnaire, weights, {
    weighting: "linear",
    invert: new Set(["red_flag"]),
  });

  const factors = (Object.keys(result.contributions) as (keyof Questionnaire)[])
    .map((key): FactorContribution => {
      const contribution = result.contributions[key];
      return {
        key,
        label: FACTOR_META[key].label,
        questionText: questionTextOf(questionnaire[key]),
        raw: contribution.raw,
        normalized: contribution.normalized,
        weighted: contribution.weighted,
        percent:
          result.composite > 0 ? contribution.weighted / result.composite : 0,
        confidence: contribution.confidence,
      };
    })
    .sort((a, b) => b.weighted - a.weighted);

  return {
    composite: result.composite,
    lowestConfidence: result.lowestConfidence,
    weightedConfidence: result.weightedConfidence,
    factors,
  };
}

async function fetchScorecard(
  candidateId: string,
  signal: AbortSignal,
): Promise<SystemOneResult<Questionnaire>> {
  const response = await fetch(
    `/api/candidates/${encodeURIComponent(candidateId)}/score`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal,
    },
  );

  if (!response.ok) {
    throw new Error(`Score request failed with ${response.status}.`);
  }

  return (await response.json()) as SystemOneResult<Questionnaire>;
}

export function CandidateScorecard({ candidateId, onRequestReview }: Props) {
  const [state, setState] = useState<LoadState>({ kind: "loading" });
  const [reloadKey, setReloadKey] = useState(0);

  // One source of truth for weights. If weights become props later, thread them here.
  // The header composite and the factor bars must both come from this same object.
  const weights = useMemo(() => WEIGHTS, []);

  useEffect(() => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15_000);

    setState({ kind: "loading" });

    fetchScorecard(candidateId, controller.signal)
      .then((raw) => setState({ kind: "ready", raw }))
      .catch((error: unknown) => {
        const message =
          error instanceof Error ? error.message : "Unknown scorecard error.";
        setState({ kind: "error", message });
      })
      .finally(() => window.clearTimeout(timeout));

    return () => {
      window.clearTimeout(timeout);
      controller.abort();
    };
  }, [candidateId, reloadKey]);

  const data = useMemo(() => {
    if (state.kind !== "ready") return null;
    return extractScorecardData(state.raw.answers, weights);
  }, [state, weights]);

  if (state.kind === "loading") return <ScorecardSkeleton />;
  if (state.kind === "error") {
    return (
      <ErrorState
        message={state.message}
        onRetry={() => setReloadKey((key) => key + 1)}
      />
    );
  }
  if (!data) {
    return (
      <ErrorState
        message="No scorecard data was produced."
        onRetry={() => setReloadKey((key) => key + 1)}
      />
    );
  }

  const needsReview = data.lowestConfidence < THRESHOLDS.reviewBelow;

  return (
    <section aria-label="Candidate scorecard">
      {needsReview && (
        <WarningBanner
          candidateId={candidateId}
          onRequestReview={onRequestReview}
        />
      )}

      <header>
        <div>
          <span>Composite score</span>
          <strong>{data.composite.toFixed(2)}</strong>
        </div>
        <ConfidenceBadge confidence={data.lowestConfidence} />
      </header>

      <div>
        {data.factors.map((factor) => (
          <FactorBar key={factor.key} factor={factor} />
        ))}
      </div>
    </section>
  );
}

function FactorBar({ factor }: { factor: FactorContribution }) {
  const width = `${Math.max(0, Math.min(100, factor.percent * 100)).toFixed(1)}%`;

  return (
    <div
      title={`${factor.questionText}\nRaw: ${factor.raw}\nConfidence: ${factor.confidence.toFixed(2)}`}
    >
      <div>{factor.label}</div>
      <div>
        <div style={{ width }} />
        <span>{(factor.percent * 100).toFixed(1)}%</span>
      </div>
    </div>
  );
}

function ConfidenceBadge({ confidence }: { confidence: number }) {
  const label =
    confidence >= THRESHOLDS.highConfidence
      ? "High confidence"
      : confidence >= THRESHOLDS.reviewBelow
        ? "Review recommended"
        : "Unreliable";

  return <span aria-label={`Confidence ${confidence.toFixed(2)}`}>{label}</span>;
}

function WarningBanner({
  candidateId,
  onRequestReview,
}: {
  candidateId: string;
  onRequestReview?: (candidateId: string) => void;
}) {
  const disabled = !onRequestReview;

  return (
    <div role="alert">
      <p>Score may be unreliable. A human should review this candidate.</p>
      <button
        disabled={disabled}
        title={disabled ? "No review handler was provided." : undefined}
        onClick={() => onRequestReview?.(candidateId)}
      >
        Send for review
      </button>
    </div>
  );
}

function ScorecardSkeleton() {
  return (
    <section aria-label="Loading candidate scorecard">
      <div>Loading composite score…</div>
      <div>Loading factor breakdown…</div>
    </section>
  );
}

function ErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <section role="alert">
      <p>{message}</p>
      <button onClick={onRetry}>Retry</button>
    </section>
  );
}
