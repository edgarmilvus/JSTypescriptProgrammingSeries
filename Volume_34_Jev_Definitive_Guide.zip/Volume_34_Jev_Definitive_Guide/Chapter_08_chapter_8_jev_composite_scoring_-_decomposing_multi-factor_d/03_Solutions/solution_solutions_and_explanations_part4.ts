/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 4: confidence-gated composite routing
import {
  noul,
  score,
  TypeSafeClient,
  type NoulResponse,
  type Questions,
  type SystemOneResult,
} from "@typesafe-ai/sdk";
import {
  compositeFactorScores,
  type FactorContribution,
  type NormalizedScore,
} from "../scoring/composite";

// For this assignment-review domain we keep the same aggregation and routing shape.
// The questionnaire is domain-specific: structure, argumentation, originality, evidence,
// clarity, and a red-flag Noul.
const reviewQuestionnaire = {
  structure: score(
    "How clear and well-organized is the essay's structure?",
    [
      "No discernible structure; ideas appear in random order.",
      "Some organization, but transitions and paragraph roles are weak.",
      "Clear introduction, body, and conclusion with mostly coherent flow.",
      "Structure actively supports the argument; each section has a clear job.",
    ] as const,
  ),
  argumentation: score(
    "How strong is the essay's argumentation?",
    [
      "No central claim or reasoning.",
      "A claim exists, but support is thin or contradictory.",
      "A clear claim with relevant evidence and reasoning.",
      "A nuanced claim, counterarguments, and strong synthesis.",
    ] as const,
  ),
  originality: score(
    "How original is the essay's thinking?",
    [
      "Purely generic or copied ideas.",
      "Mostly familiar ideas with little original synthesis.",
      "Some independent insight or unusual angle.",
      "Substantially original framing or insight that advances the discussion.",
    ] as const,
  ),
  evidence: score(
    "How well does the essay use evidence?",
    [
      "No evidence or unsupported assertions throughout.",
      "Evidence is present but weak, misread, or poorly connected.",
      "Relevant evidence supports most claims.",
      "Evidence is precise, well-integrated, and anticipates objections.",
    ] as const,
  ),
  clarity: score(
    "How clear is the prose?",
    [
      "Frequent errors make the essay hard to follow.",
      "Understandable, but wordy, vague, or error-prone.",
      "Clear prose with minor issues.",
      "Precise, economical, and pleasant to read.",
    ] as const,
  ),
  red_flag: noul(
    "Does the essay contain a red flag requiring human attention?",
    {
      true: "Plagiarism, hateful content, threats, or another serious integrity/safety concern.",
      false: "No serious red flag appears.",
    },
  ),
} satisfies Questions;

type ReviewQuestionnaire = typeof reviewQuestionnaire;
type Answers = SystemOneResult<ReviewQuestionnaire>["answers"];
type Weights = Record<keyof ReviewQuestionnaire, number>;

const DEFAULT_WEIGHTS: Weights = {
  structure: 0.15,
  argumentation: 0.3,
  originality: 0.2,
  evidence: 0.2,
  clarity: 0.1,
  red_flag: 0.05,
};

export type RoutingAction = "auto" | "human_signoff" | "human_only";

export type RoutingPolicy = {
  name: string;
  dispatcher: {
    lowConfidenceFloor: number;
    lowFactorThreshold: number;
    lowFactorCountCap: number;
    dispersionFloor: number;
    redFlagCeiling: number;
  };
  actions: {
    onComfortable: RoutingAction;
    onBorderline: RoutingAction;
    onUncertain: RoutingAction;
  };
};

export const policies: Record<"permissive" | "strict", RoutingPolicy> = {
  permissive: {
    name: "permissive",
    dispatcher: {
      lowConfidenceFloor: 0.35,
      lowFactorThreshold: 0.5,
      lowFactorCountCap: 3,
      dispersionFloor: 0.28,
      redFlagCeiling: 0.85,
    },
    actions: {
      onComfortable: "auto",
      onBorderline: "auto",
      onUncertain: "human_signoff",
    },
  },
  strict: {
    name: "strict",
    dispatcher: {
      lowConfidenceFloor: 0.6,
      lowFactorThreshold: 0.7,
      lowFactorCountCap: 1,
      dispersionFloor: 0.22,
      redFlagCeiling: 0.7,
    },
    actions: {
      onComfortable: "auto",
      onBorderline: "human_signoff",
      onUncertain: "human_only",
    },
  },
};

export type RoutingProfile = {
  composite: number;
  lowestConfidence: number;
  lowFactorCount: number;
  dispersion: number;
  redFlag: number;
};

export function compositeDispersion(
  contributions: Record<string, { normalized: NormalizedScore; weight: number }>,
): number {
  const entries = Object.values(contributions);
  const composite = entries.reduce(
    (sum, contribution) => sum + contribution.normalized * contribution.weight,
    0,
  );

  const variance = entries.reduce(
    (sum, contribution) =>
      sum +
      contribution.weight *
        Math.pow(contribution.normalized - composite, 2),
    0,
  );

  return Math.sqrt(variance);
}

export function routeSubmission(
  profile: RoutingProfile,
  policy: RoutingPolicy,
): { action: RoutingAction; reason: string } {
  const d = policy.dispatcher;

  if (profile.redFlag >= d.redFlagCeiling) {
    return {
      action: policy.actions.onUncertain,
      reason: "red flag fired above ceiling",
    };
  }

  if (profile.lowestConfidence < d.lowConfidenceFloor) {
    return {
      action: policy.actions.onUncertain,
      reason: "lowest confidence below floor",
    };
  }

  if (profile.lowFactorCount >= d.lowFactorCountCap) {
    return {
      action: policy.actions.onUncertain,
      reason: `${profile.lowFactorCount} factors below confidence threshold`,
    };
  }

  if (profile.dispersion >= d.dispersionFloor) {
    return {
      action: policy.actions.onBorderline,
      reason: "factor dispersion indicates disagreement",
    };
  }

  return {
    action: policy.actions.onComfortable,
    reason: "composite is stable and factors agree",
  };
}

export type RoutingResult = {
  composite: number;
  action: RoutingAction;
  reason: string;
  factors: Array<{ key: string } & FactorContribution>;
};

export async function scoreAndRoute(
  client: TypeSafeClient,
  submission: { candidateId: string; essay: string },
  policy: RoutingPolicy,
  weights: Weights = DEFAULT_WEIGHTS,
): Promise<RoutingResult> {
  try {
    const response = await client.systemOne({
      state: { essay: submission.essay },
      questions: reviewQuestionnaire,
    });

    const answers = response.answers;

    const aggregated = compositeFactorScores(
      answers,
      reviewQuestionnaire,
      weights,
      {
        weighting: "linear",
        invert: new Set(["red_flag"]),
      },
    );

    const redFlagAnswer = answers.red_flag as NoulResponse;

    const lowFactorCount = Object.values(aggregated.contributions).filter(
      (contribution) =>
        contribution.confidence < policy.dispatcher.lowFactorThreshold,
    ).length;

    const profile: RoutingProfile = {
      composite: aggregated.composite,
      lowestConfidence: aggregated.lowestConfidence,
      lowFactorCount,
      dispersion: compositeDispersion(aggregated.contributions),
      redFlag: redFlagAnswer.noul,
    };

    const { action, reason } = routeSubmission(profile, policy);

    // Structured, single-line log. Do not log the essay itself.
    console.info(
      JSON.stringify({
        candidateId: submission.candidateId,
        action,
        composite: profile.composite,
        lowestConfidence: profile.lowestConfidence,
        lowFactorCount: profile.lowFactorCount,
        dispersion: profile.dispersion,
        redFlag: profile.redFlag,
      }),
    );

    return {
      composite: profile.composite,
      action,
      reason,
      factors: Object.entries(aggregated.contributions).map(([key, value]) => ({
        key,
        ...value,
      })),
    };
  } catch (error: unknown) {
    const reason =
      error instanceof Error
        ? `model layer unavailable: ${error.message}`
        : "model layer unavailable";

    return {
      composite: 0,
      action: "human_only",
      reason,
      factors: [],
    };
  }
}

/*
Failure-mode invariant:
If the composite were computed against one weight vector and the routing profile
against another, the returned action could contradict the returned score. A submission
could show a high composite but route to human_only, or a low composite but route to auto.
Here, scoreAndRoute takes a single weights argument, passes it to compositeFactorScores,
and derives every routing signal from that same aggregation result. The single systemOne
call also means all factor answers, confidence values, and the red-flag probability come
from the same evaluation pass.
*/
