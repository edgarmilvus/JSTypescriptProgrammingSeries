/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// calibration/harness.ts
import { createHash } from "crypto";
import { mkdirSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

type Label = "strong" | "acceptable" | "needs_review";

type FactorKey =
  | "structure"
  | "argumentation"
  | "originality"
  | "evidence"
  | "clarity";

type Weights = Record<FactorKey, number>;

type Example = {
  id: string;
  factors: Record<FactorKey, { score: number; max: number; confidence: number }>;
  label: Label;
};

type Metrics = {
  spearman: number;
  pairwise: number;
  calibrationError: number;
};

const FACTOR_KEYS: FactorKey[] = [
  "structure",
  "argumentation",
  "originality",
  "evidence",
  "clarity",
];

// Hidden weights used only to generate labels. The harness must recover these blindly.
const HIDDEN_WEIGHTS: Weights = {
  structure: 0.15,
  argumentation: 0.3,
  originality: 0.2,
  evidence: 0.25,
  clarity: 0.1,
};

function mulberry32(seed: number) {
  return function random() {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function normalizeFactor(score: number, max: number): number {
  return max <= 0 ? 0 : Math.min(1, Math.max(0, score / max));
}

function compositeFromFactors(
  factors: Example["factors"],
  weights: Weights,
): number {
  return FACTOR_KEYS.reduce(
    (sum, key) =>
      sum + weights[key] * normalizeFactor(factors[key].score, factors[key].max),
    0,
  );
}

function hiddenLabel(factors: Example["factors"]): Label {
  const value = compositeFromFactors(factors, HIDDEN_WEIGHTS);
  if (value >= 0.75) return "strong";
  if (value >= 0.45) return "acceptable";
  return "needs_review";
}

function makeDataset(count = 50, seed = 42): Example[] {
  const random = mulberry32(seed);
  const examples: Example[] = [];

  for (let i = 0; i < count; i++) {
    const factors = {} as Example["factors"];

    for (const key of FACTOR_KEYS) {
      const max = key === "clarity" ? 3 : 4;
      const raw = random() * max;
      factors[key] = {
        score: raw,
        max,
        confidence: 0.55 + random() * 0.45,
      };
    }

    examples.push({
      id: `example-${i}`,
      factors,
      label: hiddenLabel(factors),
    });
  }

  return examples;
}

function scalarizeLabel(label: Label): number {
  if (label === "strong") return 2;
  if (label === "acceptable") return 1;
  return 0;
}

function rank(values: number[]): number[] {
  const order = values
    .map((value, index) => ({ value, index }))
    .sort((a, b) => a.value - b.value);

  const ranks = new Array(values.length).fill(0);
  for (let i = 0; i < order.length; i++) {
    ranks[order[i].index] = i;
  }
  return ranks;
}

function spearman(a: number[], b: number[]): number {
  const ra = rank(a);
  const rb = rank(b);
  const n = a.length;
  const meanA = ra.reduce((s, v) => s + v, 0) / n;
  const meanB = rb.reduce((s, v) => s + v, 0) / n;

  let numerator = 0;
  let denomA = 0;
  let denomB = 0;

  for (let i = 0; i < n; i++) {
    const da = ra[i] - meanA;
    const db = rb[i] - meanB;
    numerator += da * db;
    denomA += da * da;
    denomB += db * db;
  }

  return denomA === 0 || denomB === 0
    ? 0
    : numerator / Math.sqrt(denomA * denomB);
}

function pairwiseAccuracy(
  composites: number[],
  labels: number[],
): number {
  let correct = 0;
  let total = 0;

  for (let i = 0; i < composites.length; i++) {
    for (let j = i + 1; j < composites.length; j++) {
      if (labels[i] === labels[j]) continue;
      total++;
      const expected = labels[i] > labels[j] ? 1 : -1;
      const actual = composites[i] > composites[j] ? 1 : -1;
      if (expected === actual) correct++;
    }
  }

  return total === 0 ? 0 : correct / total;
}

function calibrationError(
  composites: number[],
  labels: number[],
): number {
  // Asymmetric cost: needs_review misclassified as strong is worst.
  const scalarized = labels.map((label) => label / 2);
  let total = 0;

  for (let i = 0; i < composites.length; i++) {
    const diff = Math.abs(composites[i] - scalarized[i]);
    const dangerous =
      labels[i] === 0 && composites[i] >= 0.75
        ? 3
        : labels[i] === 0 && composites[i] >= 0.45
          ? 2
          : 1;
    total += diff * dangerous;
  }

  return total / composites.length;
}

function computeMetrics(
  examples: Example[],
  weights: Weights,
): Metrics {
  const composites = examples.map((example) =>
    compositeFromFactors(example.factors, weights),
  );
  const labels = examples.map((example) => scalarizeLabel(example.label));

  return {
    spearman: spearman(composites, labels),
    pairwise: pairwiseAccuracy(composites, labels),
    calibrationError: calibrationError(composites, labels),
  };
}

function* simplex(
  dimensions: number,
  step = 0.05,
  prefix: number[] = [],
): Generator<number[]> {
  if (dimensions === 1) {
    const last = 1 - prefix.reduce((s, v) => s + v, 0);
    if (last >= -1e-9 && last <= 1 + 1e-9) {
      yield [...prefix, Math.max(0, last)];
    }
    return;
  }

  for (let value = 0; value <= 1.0001; value += step) {
    const remaining = 1 - prefix.reduce((s, v) => s + v, 0) - value;
    if (remaining < -1e-9) continue;
    yield* simplex(dimensions - 1, step, [...prefix, value]);
  }
}

function weightsFromVector(vector: number[]): Weights {
  return FACTOR_KEYS.reduce((weights, key, index) => {
    weights[key] = vector[index];
    return weights;
  }, {} as Weights);
}

function l1Distance(a: Weights, b: Weights): number {
  return FACTOR_KEYS.reduce((sum, key) => sum + Math.abs(a[key] - b[key]), 0);
}

function lInfinityDistance(a: Weights, b: Weights): number {
  return Math.max(...FACTOR_KEYS.map((key) => Math.abs(a[key] - b[key])));
}

function isConcentrated(weights: Weights): boolean {
  return Math.max(...Object.values(weights)) > 0.6;
}

function classCounts(examples: Example[]): Record<Label, number> {
  const counts: Record<Label, number> = {
    strong: 0,
    acceptable: 0,
    needs_review: 0,
  };
  for (const example of examples) counts[example.label]++;
  return counts;
}

function assertEnoughLabels(examples: Example[], minimum = 8): void {
  const counts = classCounts(examples);
  for (const [label, count] of Object.entries(counts) as [Label, number][]) {
    if (count < minimum) {
      throw new Error(
        `Not enough labels for "${label}": have ${count}, need ${minimum}.`,
      );
    }
  }
}

type Candidate = {
  weights: Weights;
  metrics: Metrics;
  l1ToHidden: number;
  lInfinityToHidden: number;
  concentrated: boolean;
};

function sweep(
  examples: Example[],
  topK = 5,
): { best: Candidate[]; all: Candidate[] } {
  assertEnoughLabels(examples);

  const all: Candidate[] = [];

  for (const vector of simplex(FACTOR_KEYS.length, 0.05)) {
    const weights = weightsFromVector(vector);
    const metrics = computeMetrics(examples, weights);

    all.push({
      weights,
      metrics,
      l1ToHidden: l1Distance(weights, HIDDEN_WEIGHTS),
      lInfinityToHidden: lInfinityDistance(weights, HIDDEN_WEIGHTS),
      concentrated: isConcentrated(weights),
    });
  }

  const sorted = [...all].sort(
    (a, b) => b.metrics.spearman - a.metrics.spearman,
  );

  // Detect ambiguous ties by identical primary metric.
  const ambiguous: string[] = [];
  for (let i = 0; i < sorted.length - 1; i++) {
    if (sorted[i].metrics.spearman === sorted[i + 1].metrics.spearman) {
      ambiguous.push(
        `tie: ${JSON.stringify(sorted[i].weights)} vs ${JSON.stringify(
          sorted[i + 1].weights,
        )}`,
      );
    }
  }

  if (ambiguous.length > 0) {
    console.warn("Ambiguous weight pairs detected:", ambiguous);
  }

  return {
    best: sorted.slice(0, topK),
    all,
  };
}

function datasetFingerprint(examples: Example[]): string {
  const payload = JSON.stringify(examples, Object.keys(examples[0]).sort());
  return createHash("sha256").update(payload).digest("hex").slice(0, 16);
}

function freeze(
  best: Candidate,
  examples: Example[],
  harnessVersion: string,
  outputDir: string,
): string {
  if (best.concentrated) {
    throw new Error(
      "Refusing to freeze concentrated weights without explicit override.",
    );
  }

  mkdirSync(outputDir, { recursive: true });

  const payload = {
    weights: best.weights,
    metrics: best.metrics,
    datasetFingerprint: datasetFingerprint(examples),
    harnessVersion,
    frozenAt: new Date().toISOString(),
  };

  const json = JSON.stringify(payload, null, 2);
  const hash = createHash("sha256").update(json).digest("hex").slice(0, 12);
  const date = new Date().toISOString().slice(0, 10);
  const filename = `${date}-${hash}.json`;
  const path = join(outputDir, filename);

  writeFileSync(path, json, "utf8");
  writeFileSync(
    join(outputDir, `${date}-${hash}.d.ts`),
    `export const weights: Record<"${FACTOR_KEYS.join('" | "')}", number>;\n`,
    "utf8",
  );

  return path;
}

function replay(
  weightsPath: string,
  examples: Example[],
): Metrics {
  const frozen = JSON.parse(readFileSync(weightsPath, "utf8")) as {
    weights: Weights;
  };
  return computeMetrics(examples, frozen.weights);
}

// ---------------------------------------------------------------------------
// Script entry point
// ---------------------------------------------------------------------------

if (require.main === module) {
  const examples = makeDataset(50, 42);
  const { best, all } = sweep(examples, 5);

  console.table(
    best.map((candidate) => ({
      spearman: candidate.metrics.spearman.toFixed(3),
      pairwise: candidate.metrics.pairwise.toFixed(3),
      calibrationError: candidate.metrics.calibrationError.toFixed(3),
      l1: candidate.l1ToHidden.toFixed(3),
      lInf: candidate.lInfinityToHidden.toFixed(3),
      concentrated: candidate.concentrated,
      weights: JSON.stringify(candidate.weights),
    })),
  );

  console.log("Hidden weights:", HIDDEN_WEIGHTS);
  console.log("Best L1 distance:", best[0].l1ToHidden);
  console.log("All candidates evaluated:", all.length);

  const frozenPath = freeze(best[0], examples, "1.0.0", "calibration/weights");
  console.log("Frozen weights:", frozenPath);

  const replayed = replay(frozenPath, examples);
  console.log("Replay metrics:", replayed);
}
