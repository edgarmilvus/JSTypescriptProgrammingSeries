/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type {
  NoulAnswer,
  Questions,
  ScoreAnswer,
  SystemOneResult,
  TypeSafeClient,
} from "@typesafe-ai/sdk";
import { questionnaire } from "../scoring/questionnaire";
import { compositeFactorScores } from "../scoring/composite";
import type { NormalizedScore } from "../scoring/normalize";

const WEIGHTS: Record<keyof typeof questionnaire, number> = {
  // you fill this in during Exercise 1's design
};

const THRESHOLDS = {
  reviewBelow: 0.6,
  highConfidence: 0.85,
} as const;

type FactorContribution = {
  key: string;
  label: string;
  questionText: string;
  raw: number;
  normalized: NormalizedScore;
  weighted: number;
  percent: number;
  confidence: number;
};

type ScorecardData = {
  composite: number;
  lowestConfidence: number;
  weightedConfidence: number;
  factors: FactorContribution[];
};

type Props = {
  candidateId: string;
  onRequestReview?: (candidateId: string) => void;
};

type LoadState =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; data: ScorecardData };

// TODO: implement
function extractScorecardData(
  answers: SystemOneResult<typeof questionnaire>["answers"],
  weights: typeof WEIGHTS,
): ScorecardData {
  throw new Error("not implemented");
}

export function CandidateScorecard({ candidateId, onRequestReview }: Props) {
  // TODO: implement the fetch + states
  return null;
}

function FactorBar({ factor }: { factor: FactorContribution }) {
  // TODO: implement the bar
  return null;
}

function ConfidenceBadge({ confidence }: { confidence: number }) {
  // TODO: implement
  return null;
}
