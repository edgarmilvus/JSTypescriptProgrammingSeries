/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * triage.ts
 * ----------------------------------
 * A single-file, two-speed expense triage service.
 *
 * Jev 1.13 answers the fuzzy questions (category, receipt plausibility,
 * anomaly). TypeScript answers everything else: arithmetic, thresholds,
 * policy enforcement, and every side effect.
 *
 * Drop this file into a Next.js app at `app/api/triage/route.ts` and
 * export `POST` as the handler. Nothing else is required.
 */

import { TypeSafeClient, choice, noul, score } from "@typesafe-ai/sdk";

// ============================================================
// Section 1 — Domain types. Code owns these, not Jev.
// ============================================================

/** One line on the receipt the employee is claiming. */
export interface LineItem {
  description: string;
  amountUSD: number;
}

/** The submission as it arrives from the frontend. */
export interface ExpenseSubmission {
  id: string;
  employeeId: string;
  claimedAmountUSD: number;
  lineItems: LineItem[];
  receiptText: string;
  policy: {
    maxAutoApproveUSD: number;
    requiresReceiptOverUSD: number;
    forbiddenCategories: readonly string[];
  };
}

/** The only three outcomes this service can return. */
export type Decision =
  | { kind: "auto_approve"; reason: string }
  | { kind: "human_review"; reason: string }
  | { kind: "reject"; reason: string };

// ============================================================
// Section 2 — The Jev client. Created once at module scope so it is
// reused across requests (env-var read once, retry policy reused).
// ============================================================

const jev = new TypeSafeClient(); // reads TYPESAFE_API_KEY from the environment.

// ============================================================
// Section 3 — The triage entry point.
// ============================================================

/**
 * Decide what to do with an expense submission.
 *
 * Three phases, and the ordering matters:
 *   1. Code prechecks (free, deterministic, runs first).
 *   2. Jev judgements (one API call, all fuzzy questions batched).
 *   3. Code policy + thresholds + side effects (deterministic, runs last).
 */
export async function triageExpense(
  expense: ExpenseSubmission,
): Promise<Decision> {
  // ----------------------------------------------------------
  // Phase 1 — deterministic prechecks. No network call yet.
  // ----------------------------------------------------------

  const claimedSum = sumLineItems(expense.lineItems);
  const arithmeticOk = Math.abs(claimedSum - expense.claimedAmountUSD) < 0.01;
  const receiptRequired =
    expense.claimedAmountUSD >= expense.policy.requiresReceiptOverUSD;
  const receiptPresent = expense.receiptText.trim().length > 0;

  if (!arithmeticOk) {
    return {
      kind: "reject",
      reason:
        `Line items sum to ${claimedSum.toFixed(2)} USD but the claim ` +
        `says ${expense.claimedAmountUSD.toFixed(2)} USD.`,
    };
  }
  if (receiptRequired && !receiptPresent) {
    return {
      kind: "human_review",
      reason: "Receipt is required above the policy threshold but was not attached.",
    };
  }

  // ----------------------------------------------------------
  // Phase 2 — Jev judgements. One request, four questions.
  // ----------------------------------------------------------

  const result = await jev.systemOne({
    state: expense,
    questions: {
      category: choice("Which category best describes this expense?", {
        travel: "Airfare, lodging, ground transport on business travel.",
        meals: "Client meals, team meals, or per-diem food.",
        software: "SaaS subscriptions, licenses, developer tools.",
        hardware: "Laptops, monitors, peripherals, accessories.",
        other: "Anything that does not clearly fit the other categories.",
      }),
      receipt_matches_claim: noul(
        "Does the receipt text support the claimed amount and line-item descriptions?",
        {
          true: "The receipt covers the same items and amounts the employee claimed.",
          false: "The receipt is missing, partial, or describes different items.",
        },
      ),
      mentions_forbidden_activity: noul(
        "Does any text in the receipt or line items mention gambling, crypto " +
          "speculation, or personal entertainment?",
      ),
      anomaly: score(
        "How unusual would a finance reviewer find this expense, given its category?",
        ["Routine.", "Slightly unusual.", "Unusual.", "Highly anomalous."],
      ),
    },
  });

  // ----------------------------------------------------------
  // Phase 3 — Deterministic policy, thresholds, and routing.
  // ----------------------------------------------------------

  const THRESHOLDS = {
    receiptMatch: 0.6,
    forbiddenSignal: 0.5,
    anomalyHigh: 2.0,
    confidenceFloor: 0.5,
  } as const;

  const category = result.answers.category.choice;
  const confidence = result.answers.category.confidence;
  const receiptMatch = result.answers.receipt_matches_claim.noul;
  const forbiddenSignal = result.answers.mentions_forbidden_activity.noul;
  const anomalyScore = result.answers.anomaly.score;

  const forbidden = expense.policy.forbiddenCategories.some(
    (f) => f.toLowerCase() === category.toLowerCase(),
  );
  const overAutoApproveLimit =
    expense.claimedAmountUSD > expense.policy.maxAutoApproveUSD;

  if (forbidden) {
    return {
      kind: "reject",
      reason: `Category "${category}" is forbidden by company policy.`,
    };
  }
  if (forbiddenSignal >= THRESHOLDS.forbiddenSignal) {
    return {
      kind: "human_review",
      reason: "Text may reference a forbidden activity; escalating.",
    };
  }
  if (confidence < THRESHOLDS.confidenceFloor) {
    return {
      kind: "human_review",
      reason: "Category classification is uncertain.",
    };
  }
  if (receiptMatch < THRESHOLDS.receiptMatch) {
    return {
      kind: "human_review",
      reason: "Receipt does not clearly support the claimed amount.",
    };
  }
  if (anomalyScore >= THRESHOLDS.anomalyHigh) {
    return {
      kind: "human_review",
      reason: "Anomaly score crossed the review threshold.",
    };
  }
  if (overAutoApproveLimit) {
    return {
      kind: "human_review",
      reason:
        `Amount ${expense.claimedAmountUSD.toFixed(2)} USD exceeds the ` +
        `auto-approve limit of ${expense.policy.maxAutoApproveUSD.toFixed(2)} USD.`,
    };
  }

  // ----------------------------------------------------------
  // Phase 4 — Side effects. Only code runs these.
  // ----------------------------------------------------------
  // In a real service, this is where you would call `db.expenses.update(...)`,
  // emit an audit event, and post to the payroll system. Jev never touches
  // these systems.

  return {
    kind: "auto_approve",
    reason: "Passed every deterministic and Jev check.",
  };
}

// ============================================================
// Section 4 — Pure helpers. No model. No network. Trivially testable.
// ============================================================

/** Sum the line items. This is the arithmetic Jev must never do. */
function sumLineItems(items: readonly LineItem[]): number {
  let total = 0;
  for (const item of items) total += item.amountUSD;
  return total;
}

// ============================================================
// Section 5 — The route handler. Wire this into your web app.
// ============================================================

export async function POST(req: Request): Promise<Response> {
  const expense = (await req.json()) as ExpenseSubmission;
  const decision = await triageExpense(expense);
  return Response.json(decision, {
    status: decision.kind === "reject" ? 422 : 200,
  });
}
