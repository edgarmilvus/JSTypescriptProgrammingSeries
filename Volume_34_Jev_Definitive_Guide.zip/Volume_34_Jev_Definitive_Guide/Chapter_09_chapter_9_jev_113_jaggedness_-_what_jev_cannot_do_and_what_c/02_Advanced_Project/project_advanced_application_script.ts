/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/lib/expense-gate.ts
//
// Two-speed expense approval. Jev judges; code decides, validates, and pays.
// Every place Jev is structurally unreliable (arithmetic, dates, adversarial
// state, structural invariants) is walled off behind a code-owned contract.
//
// Reference: Jev 1.13 jaggedness — literal reading, math, dates, indirection,
// state rot, adversarial content, structural invariants, generation.

import { TypeSafeClient, choice, noul, score } from "@typesafe-ai/sdk";
import { createHash } from "node:crypto";

/* -------------------------------------------------------------------------- */
/*  TYPES — interfaces first, per the chapter's "public contracts" principle. */
/* -------------------------------------------------------------------------- */

/** Spend tier sourced from HRIS. Code-owned state, never inferred by Jev. */
export type ExpenseTier = "intern" | "ic" | "manager" | "executive";

/** One line on the receipt. `rawAmountCents` is authoritative — never Jev. */
export interface ExpenseLineItem {
  description: string;
  rawAmountCents: number;   // integer cents; never a float of dollars
  receiptDate: string;      // ISO 8601 date
}

/** The submitted report. All numeric and date fields are code-owned. */
export interface ExpenseReport {
  reportId: string;
  employeeId: string;
  tier: ExpenseTier;
  submittedAt: string;               // ISO 8601
  lineItems: ExpenseLineItem[];
  claimedTotalCents: number;         // the employee's number, to be validated
}

/** The record we commit (or refuse to commit) after a decision. */
export interface ApprovalRecord {
  reportId: string;
  idempotencyKey: string;   // content hash: retrying cannot double-pay
  decision: Decision;
  rationale: string[];      // human-readable, code-generated
  decidedAt: string;
}

export type Decision = "auto_approve" | "human_review" | "auto_reject";

/* -------------------------------------------------------------------------- */
/*  CONSTANTS — business rules live in code, in reviewable tables.            */
/* -------------------------------------------------------------------------- */

const TIER_MONTHLY_LIMIT_CENTS: Readonly<Record<ExpenseTier, number>> = {
  intern:     50_000,     //  $500
  ic:        250_000,     // $2,500
  manager:   750_000,     // $7,500
  executive:5_000_000,    // $50,000
};

const RECEIPT_WINDOW_DAYS = 45;
const CONFIDENCE_FLOOR   = 0.75;    // see Chapter 8 (Confidence-Gated Routing)
const HAZARD_THRESHOLD   = 0.5;     // any hazard at/above → human review

const client = new TypeSafeClient(); // reads TYPESAFE_API_KEY from env

/* -------------------------------------------------------------------------- */
/*  JEV QUESTIONS — atomic, literal, no arithmetic, no date math, no indirection. */
/* -------------------------------------------------------------------------- */

/**
 * Four questions. Note the phrasing discipline:
 *
 *  - `category` is a Choice over a bounded taxonomy. Jev is excellent here.
 *  - `likelyPersonal` is a Noul — a *semantic* property, not a numeric one.
 *  - `receiptCoherence` is a Score — a graded judgment, not a count.
 *  - `needsHumanReview` is the fail-closed catch-all: if Jev sees *any*
 *    textual reason to doubt, we escalate.
 *
 * Crucially, we never ask Jev: "do the line items sum to the claim?" That is
 * a counting question and Jev 1.13 will not answer it reliably. We never ask
 * "is this receipt within the fiscal window?" That is date arithmetic. We
 * never ask "is this under the tier limit?" That is a numeric comparison
 * against code-owned state.
 */
const questions = {
  category: choice(
    "What is the single best category for this expense?",
    {
      travel:    "Airfare, lodging, ground transport between cities.",
      meals:     "Individual or team meals during work.",
      software:  "Recurring SaaS, licenses, developer tools.",
      equipment: "Durable goods: laptops, monitors, peripherals.",
      training:  "Courses, books, conference tickets.",
      other:     "Anything that does not fit the above.",
    },
  ),
  likelyPersonal: noul(
    "Does this expense appear personal rather than business-related?",
    {
      true:  "Unrelated to work: personal subscriptions, gifts, entertainment.",
      false: "Clearly tied to a business purpose.",
    },
  ),
  receiptCoherence: score(
    "How coherent are the descriptions on the receipt, as a group?",
    [
      "Nonsense or obviously fabricated.",
      "Vague enough that a human should look.",
      "Plausible for a single legitimate purchase.",
      "Clearly a single, coherent business expense.",
    ],
  ),
  needsHumanReview: noul(
    "Given only the text above, should a human review this report before payment?",
    {
      true:  "There is a textual reason to look before paying.",
      false: "No textual reason to doubt this report.",
    },
  ),
} as const;

/* -------------------------------------------------------------------------- */
/*  CODE-OWNED PRIMITIVES                                                     */
/* -------------------------------------------------------------------------- */

/**
 * CODE OWNS: arithmetic. Jev is not a calculator (chapter §Math and Numbers).
 * Whether or not Jev "seems to count" on a small example, the error grows
 * with size and there is no calibration guarantee on a sum. We reduce here.
 */
function sumLineItemsCents(items: readonly ExpenseLineItem[]): number {
  return items.reduce((total, li) => total + li.rawAmountCents, 0);
}

/**
 * CODE OWNS: date arithmetic. Jev reads dates as text, not ordered quantities
 * (chapter §Date and time comparison). If Jev must extract *parts* of a date,
 * it does so via a Choice over enumerated options — never by reasoning about
 * which of two dates came first.
 */
function daysBetween(isoFrom: string, isoTo: string): number {
  return Math.floor((Date.parse(isoTo) - Date.parse(isoFrom)) / 86_400_000);
}

function isFutureDate(iso: string): boolean {
  return Date.parse(iso) > Date.now();
}

/**
 * CODE OWNS: side-effect safety. Jev cannot know whether an action has
 * already happened, and it never executes a side effect. We derive a
 * deterministic idempotency key from report contents so a retried pipeline
 * (network flake, redeploy, duplicate webhook) cannot double-pay.
 */
function contentHash(report: ExpenseReport): string {
  const { submittedAt: _drop, ...canonical } = report; // timestamp is metadata
  return createHash("sha256")
    .update(JSON.stringify(canonical, Object.keys(canonical).sort()))
    .digest("hex");
}

/* -------------------------------------------------------------------------- */
/*  PHASE 1 — deterministic preflight. Runs before Jev. Fails closed.         */
/* -------------------------------------------------------------------------- */

interface PreflightResult {
  ok: boolean;
  reasons: string[];
  computedTotalCents: number;
  tierLimitCents: number;
  receiptWindowViolation: boolean;
}

function preflight(report: ExpenseReport): PreflightResult {
  const reasons: string[] = [];
  const computedTotalCents = sumLineItemsCents(report.lineItems);
  const tierLimitCents = TIER_MONTHLY_LIMIT_CENTS[report.tier];

  // Arithmetic: the claim must equal the sum of its parts, to the cent.
  if (computedTotalCents !== report.claimedTotalCents) {
    reasons.push(
      `line items sum to ${computedTotalCents} but claim is ${report.claimedTotalCents}`,
    );
  }

  // Business rule: tier limit, evaluated in code, in cents.
  if (computedTotalCents > tierLimitCents) {
    reasons.push(`total exceeds tier "${report.tier}" limit of ${tierLimitCents}`);
  }

  // Date windows: monotonic, exact, and immune to "next Thursday" phrasing.
  let receiptWindowViolation = false;
  for (const li of report.lineItems) {
    if (isFutureDate(li.receiptDate)) {
      reasons.push(`receipt date ${li.receiptDate} is in the future`);
      receiptWindowViolation = true;
      break;
    }
    if (daysBetween(li.receiptDate, report.submittedAt) > RECEIPT_WINDOW_DAYS) {
      reasons.push(
        `receipt ${li.receiptDate} is outside the ${RECEIPT_WINDOW_DAYS}-day window`,
      );
      receiptWindowViolation = true;
      break;
    }
  }

  return {
    ok: reasons.length === 0,
    reasons,
    computedTotalCents,
    tierLimitCents,
    receiptWindowViolation,
  };
}

/* -------------------------------------------------------------------------- */
/*  PHASE 2 — Jev judgment. One request, four questions, parallel.             */
/* -------------------------------------------------------------------------- */

type JevAnswers = Awaited<ReturnType<typeof askJev>>;

/**
 * The state we send Jev is deliberately narrow: only the natural-language
 * description of each line item. We do NOT send cents, tier limits, or dates
 * as code-comparable values. Jev is not being asked to reason about numbers;
 * it is being asked to read prose and produce a taxonomy + a hazard signal.
 *
 * Note also: line-item descriptions can contain adversarial text. Jev 1.13
 * does not treat state as hostile by default (chapter §Adversarial content),
 * so we (a) ask questions whose criteria already assume hostile input, and
 * (b) never let Jev alone trigger a side effect. Even a perfectly hijacked
 * answer still has to pass the preflight and the code-owned composition.
 */
async function askJev(report: ExpenseReport) {
  const { answers } = await client.systemOne({
    state: {
      line_items: report.lineItems.map((li) => ({
        description: li.description,
      })),
    },
    questions,
    model: "jev-latest",
  });
  return answers;
}

/* -------------------------------------------------------------------------- */
/*  PHASE 3 — composition. The decision tree lives in code, in one place.     */
/* -------------------------------------------------------------------------- */

interface CompositionResult {
  decision: Decision;
  rationale: string[];
}

/**
 * Fail-closed composition. Each gate is either a code-owned invariant or a
 * thresholded Jev answer. If anything is off — a nonsensical sum, a future
 * date, a hazard signal, low confidence — we escalate. We do not "average"
 * hazards together (that is how a single confident red flag gets silently
 * diluted); any hazard at or above its threshold wins.
 */
function compose(
  pf: PreflightResult,
  a: JevAnswers,
): CompositionResult {
  // Deterministic failure: never auto-approve. Route to a human with reasons.
  if (!pf.ok) {
    return { decision: "human_review", rationale: [...pf.reasons] };
  }

  // Semantic hazard: Jev says the expense looks personal.
  if (a.likelyPersonal.noul >= HAZARD_THRESHOLD) {
    return {
      decision: "human_review",
      rationale: [`likelyPersonal noul=${a.likelyPersonal.noul.toFixed(2)}`],
    };
  }

  // Open-ended hazard: Jev volunteered that a person should look.
  if (a.needsHumanReview.noul >= HAZARD_THRESHOLD) {
    return {
      decision: "human_review",
      rationale: [`needsHumanReview noul=${a.needsHumanReview.noul.toFixed(2)}`],
    };
  }

  // Confidence gate: act only when both classifications are decisive.
  if (
    a.category.confidence < CONFIDENCE_FLOOR ||
    a.receiptCoherence.confidence < CONFIDENCE_FLOOR
  ) {
    return {
      decision: "human_review",
      rationale: [
        `low confidence: category=${a.category.confidence.toFixed(2)} ` +
          `coherence=${a.receiptCoherence.confidence.toFixed(2)}`,
      ],
    };
  }

  // Coherence must clear the "plausible, single purchase" level.
  if (a.receiptCoherence.score < 2) {
    return {
      decision: "human_review",
      rationale: [`receiptCoherence score=${a.receiptCoherence.score.toFixed(2)}`],
    };
  }

  return {
    decision: "auto_approve",
    rationale: [
      `category=${a.category.choice}`,
      `coherence=${a.receiptCoherence.score.toFixed(2)}`,
    ],
  };
}

/* -------------------------------------------------------------------------- */
/*  PHASE 4 — commit. Idempotent side effect, owned entirely by code.         */
/* -------------------------------------------------------------------------- */

const ledger = new Map<string, ApprovalRecord>();

/**
 * CODE OWNS: the side effect. Jev never runs one; it cannot know whether one
 * has already happened. The idempotency key is derived from content, so a
 * crash between decision and commit — or a duplicate webhook — collapses to
 * a single ledger entry.
 */
async function commit(
  report: ExpenseReport,
  decision: Decision,
  rationale: string[],
): Promise<ApprovalRecord> {
  const idempotencyKey = contentHash(report);
  const existing = ledger.get(idempotencyKey);
  if (existing) return existing;

  const record: ApprovalRecord = {
    reportId: report.reportId,
    idempotencyKey,
    decision,
    rationale,
    decidedAt: new Date().toISOString(),
  };
  ledger.set(idempotencyKey, record);

  // In production: enqueue a payment job keyed on `idempotencyKey`, write an
  // audit row, and publish a domain event. All code-owned. Never Jev.
  return record;
}

/* -------------------------------------------------------------------------- */
/*  ENTRY POINT — the boundary that callers actually use.                     */
/* -------------------------------------------------------------------------- */

export async function processExpenseReport(
  report: ExpenseReport,
): Promise<ApprovalRecord> {
  const pf = preflight(report);      // deterministic, code-owned
  const a  = await askJev(report);   // probabilistic, Jev-owned
  const { decision, rationale } = compose(pf, a); // code-owned composition
  return commit(report, decision, rationale);     // idempotent side effect
}
