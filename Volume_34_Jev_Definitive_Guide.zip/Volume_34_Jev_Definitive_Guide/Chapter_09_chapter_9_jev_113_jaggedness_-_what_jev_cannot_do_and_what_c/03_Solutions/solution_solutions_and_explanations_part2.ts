/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// harness.ts — transport abstraction, probe execution, classification, contract.
// ─────────────────────────────────────────────────────────────────────────────
import {
  choice,
  noul,
  score as scoreQuestion,
  type ChoiceResponse,
  type EntryType,
  type NoulResponse,
  type Question,
  type Questions,
  type RequestOptions,
  type ScoreCriteria,
  type ScoreResponse,
  type SystemOneRequest,
  type SystemOneResult,
} from "@typesafe-ai/sdk";
import { PROBES, type FailureMode, type Probe } from "./probes";

/**
 * The only thing the harness is allowed to know about Jev. `TypeSafeClient`
 * satisfies this structurally (its `systemOne` returns an `APIPromise`, which
 * extends `Promise`), so production uses the real client and CI injects a fake.
 * Nothing in this file imports `TypeSafeClient`.
 */
export interface JevTransport {
  systemOne<Q extends Questions>(
    request: SystemOneRequest<Q>,
    options?: RequestOptions,
  ): Promise<SystemOneResult<Q>>;
}

// ── Classification constants ─────────────────────────────────────────────────
/**
 * Why 0.85 / 0.15 rather than a single 0.5 cut.
 *
 * A 0.5 cut pretends the model is a coin and the answer is a bit. Jev's noul is
 * a calibrated probability, so 0.5 is the point of *maximum ignorance*, not the
 * point of *decision*. Treating 0.51 as a confident "yes" throws away the one
 * thing a System One model gives you that a classifier does not.
 *
 * 0.85 / 0.15 carve a 0.70-wide band where the honest answer is "the harness
 * cannot classify this". Those probes are reported as `escalate`, not coerced
 * into pass or fail, because an inconclusive probe is itself a finding about
 * the capability's boundary — and silently rounding it to "pass" would erase
 * exactly the signal the contract exists to capture.
 */
const NOUL_CONFIRM_AT = 0.85;
const NOUL_REFUTE_AT = 0.15;

/** Score levels are close together, so ±0.4 accepts "on the intended level". */
const SCORE_TOLERANCE_DEFAULT = 0.4;
/** Within one whole level is "adjacent"; anything further is a miss. */
const SCORE_ADJACENT_AT = 1.0;

/** A runner-up carrying at least this much mass is a *near* miss, not noise. */
const CHOICE_NEARMISS_FLOOR = 0.15;

// ── Outcome shapes ───────────────────────────────────────────────────────────
export type ProbeVerdict = "pass" | "fail" | "escalate";

export interface ProbeOutcome {
  readonly id: string;
  readonly failureMode: FailureMode;
  readonly negativeControl: boolean;
  readonly verdict: ProbeVerdict;
  /** Human-readable band: "confirmed" | "refuted" | "inconclusive" | "match" | ... */
  readonly detail: string;
  /** noul value, top-label probability, or score — whichever is native to the probe. */
  readonly metric: number;
  readonly probabilities?: Readonly<Record<string, number>>;
  readonly legend?: Readonly<Record<string, EntryType>>;
  /** Kept verbatim so downstream analysis never re-guesses what Jev said. */
  readonly raw: SystemOneResult<Questions> | { readonly error: string };
  /** Smallest reproduction, carried through to the contract. */
  readonly state: EntryType;
  readonly instructions: string;
  readonly expected: string;
}

type AnyAnswer = NoulResponse | ChoiceResponse<Record<string, EntryType>> | ScoreResponse<ScoreCriteria>;

// ── Band classifiers ─────────────────────────────────────────────────────────
type NoulBand = "confirmed" | "refuted" | "inconclusive";

function bandNoul(value: number): NoulBand {
  if (value >= NOUL_CONFIRM_AT) return "confirmed";
  if (value <= NOUL_REFUTE_AT) return "refuted";
  return "inconclusive";
}

function verdictForTruth(expected: "yes" | "no", band: NoulBand): ProbeVerdict {
  if (band === "inconclusive") return "escalate";
  const gotYes = band === "confirmed";
  return gotYes === (expected === "yes") ? "pass" : "fail";
}

/**
 * Choice classification reasons from the DISTRIBUTION, never from the summary
 * `confidence` field. `confidence` is a scalar digest of the same distribution;
 * using it here would double-count and would hide which alternative the model
 * actually preferred — the thing the contract needs to record.
 */
function classifyChoice(
  answer: ChoiceResponse<Record<string, EntryType>>,
  expected: string,
): { detail: "match" | "nearMiss" | "miss"; verdict: ProbeVerdict } {
  const labels = Object.keys(answer.probabilities);
  const uniform = labels.length > 0 ? 1 / labels.length : 1;
  // "Non-trivial mass" = at least the uniform baseline (the model is not ignoring
  // the expected answer) with a floor for very large option sets, where uniform
  // is already tiny and would make every runner-up a near miss.
  const nearMissFloor = Math.max(CHOICE_NEARMISS_FLOOR, uniform);

  if (answer.choice === expected) return { detail: "match", verdict: "pass" };
  const mass = answer.probabilities[expected] ?? 0;
  if (mass >= nearMissFloor) return { detail: "nearMiss", verdict: "fail" };
  return { detail: "miss", verdict: "fail" };
}

function classifyScore(
  answer: ScoreResponse<ScoreCriteria>,
  expected: number,
  tolerance: number,
): { detail: "match" | "adjacent" | "miss"; verdict: ProbeVerdict } {
  const delta = Math.abs(answer.score - expected);
  if (delta <= tolerance) return { detail: "match", verdict: "pass" };
  if (delta <= SCORE_ADJACENT_AT) return { detail: "adjacent", verdict: "fail" };
  return { detail: "miss", verdict: "fail" };
}

// ── Question construction ────────────────────────────────────────────────────
function buildQuestion(probe: Probe): Question {
  switch (probe.kind) {
    case "noul":
    case "deterministic":
      return noul(probe.instructions);
    case "choice":
      return choice(probe.instructions, probe.criteria);
    case "score":
      return scoreQuestion(probe.instructions, probe.criteria);
  }
}

function classify(probe: Probe, answer: AnyAnswer): Omit<ProbeOutcome, "raw" | "state" | "instructions"> {
  const base = {
    id: probe.id,
    failureMode: probe.failureMode,
    negativeControl: probe.negativeControl ?? false,
  };

  switch (probe.kind) {
    case "noul":
    case "deterministic": {
      if (answer.type !== "noul") throw new Error(`${probe.id}: expected a noul answer, got ${answer.type}`);
      const value = (answer as NoulResponse).noul;
      const band = bandNoul(value);
      return { ...base, detail: band, verdict: verdictForTruth(probe.expected, band), metric: value, expected: probe.expected };
    }
    case "choice": {
      if (answer.type !== "choice") throw new Error(`${probe.id}: expected a choice answer, got ${answer.type}`);
      const typed = answer as ChoiceResponse<Record<string, EntryType>>;
      const { detail, verdict } = classifyChoice(typed, probe.expected);
      return {
        ...base,
        detail,
        verdict,
        metric: Math.max(...Object.values(typed.probabilities)),
        probabilities: typed.probabilities,
        expected: probe.expected,
      };
    }
    case "score": {
      if (answer.type !== "score") throw new Error(`${probe.id}: expected a score answer, got ${answer.type}`);
      const typed = answer as ScoreResponse<ScoreCriteria>;
      const { detail, verdict } = classifyScore(typed, probe.expected, probe.tolerance ?? SCORE_TOLERANCE_DEFAULT);
      return {
        ...base,
        detail,
        verdict,
        metric: typed.score,
        probabilities: typed.probabilities,
        legend: typed.legend,
        expected: String(probe.expected),
      };
    }
  }
}

// ── Execution ────────────────────────────────────────────────────────────────
const CONCURRENCY = 4; // small pool: the public endpoint rate-limits above ~8

async function mapWithConcurrency<T, R>(items: readonly T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await fn(items[index]);
    }
  });
  await Promise.all(workers);
  return results;
}

/**
 * One probe → one `systemOne` call. Unrelated probes are NEVER batched: a shared
 * request would let one probe's instructions become context for another, which
 * is precisely the "contradictory instructions" failure mode under test.
 */
export async function runProbes(
  transport: JevTransport,
  probes: readonly Probe[] = PROBES,
  model = "jev-1.13.0",
): Promise<ProbeOutcome[]> {
  return mapWithConcurrency(probes, CONCURRENCY, async (probe) => {
    const questions: Questions = { [probe.id]: buildQuestion(probe) };
    try {
      const raw = await transport.systemOne({ state: probe.state, questions, model });
      const answer = raw.answers[probe.id] as AnyAnswer;
      if (answer === undefined) throw new Error(`no answer under key '${probe.id}'`);
      return {
        ...classify(probe, answer),
        raw,
        state: probe.state,
        instructions: probe.instructions,
      } satisfies ProbeOutcome;
    } catch (error) {
      // A thrown call is itself data about the capability's edge. Record it as an
      // escalation rather than aborting the run: one bad probe must not void the map.
      return {
        id: probe.id,
        failureMode: probe.failureMode,
        negativeControl: probe.negativeControl ?? false,
        verdict: "escalate" as const,
        detail: "error",
        metric: Number.NaN,
        raw: { error: error instanceof Error ? error.message : String(error) },
        state: probe.state,
        instructions: probe.instructions,
        expected: "yes" in probe ? probe.expected : String((probe as { expected: unknown }).expected),
      } satisfies ProbeOutcome;
    }
  });
}

// ── Contract assembly ────────────────────────────────────────────────────────
export interface ModeSummary {
  readonly failureMode: FailureMode;
  readonly probes: number;
  readonly pass: number;
  readonly fail: number;
  readonly escalate: number;
  /** Split out so a reader can see whether the boundary is inside the control. */
  readonly negativeControls: { readonly pass: number; readonly fail: number; readonly escalate: number };
  /** Median and interquartile range of the mode's native metric. */
  readonly metric: { readonly median: number; readonly p25: number; readonly p75: number; readonly iqr: number };
}

export interface InvariantCheck {
  readonly group: string;
  readonly a: string;
  readonly b: string;
  /** P(A) + P(¬A). 1.0 under the invariant; the deviation is the finding. */
  readonly sum: number;
  readonly deviation: number;
  readonly withinTolerance: boolean;
}

export interface SmallestReproduction {
  readonly id: string;
  readonly failureMode: FailureMode;
  readonly observed: string;
  readonly expected: string;
  readonly state: EntryType;
  readonly instructions: string;
}

export interface CapabilityContract {
  readonly model: string;
  readonly generatedAt: string;
  readonly probeCount: number;
  readonly modes: readonly ModeSummary[];
  readonly invariantChecks: readonly InvariantCheck[];
  readonly failures: readonly SmallestReproduction[];
  /** Contract clauses: falsifiable promises the code makes given what was observed. */
  readonly clauses: readonly string[];
}

/** The invariant tolerance. 0.10 is generous; the documentation implies larger gaps. */
export const INVARIANT_TOLERANCE = 0.1;

function quantile(sorted: readonly number[], q: number): number {
  const clean = sorted.filter((v) => Number.isFinite(v));
  if (clean.length === 0) return Number.NaN;
  const pos = (clean.length - 1) * q;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return clean[lo] + (clean[hi] - clean[lo]) * (pos - lo);
}

export function buildContract(outcomes: readonly ProbeOutcome[], resolvedModel: string): CapabilityContract {
  const modes: ModeSummary[] = [];
  const seen = new Set<FailureMode>();

  for (const outcome of outcomes) {
    if (seen.has(outcome.failureMode)) continue;
    seen.add(outcome.failureMode);

    const group = outcomes.filter((o) => o.failureMode === outcome.failureMode);
    const controls = group.filter((o) => o.negativeControl);
    const metrics = group.map((o) => o.metric).sort((a, b) => a - b);
    const p25 = quantile(metrics, 0.25);
    const p75 = quantile(metrics, 0.75);

    modes.push({
      failureMode: outcome.failureMode,
      probes: group.length,
      pass: group.filter((o) => o.verdict === "pass").length,
      fail: group.filter((o) => o.verdict === "fail").length,
      escalate: group.filter((o) => o.verdict === "escalate").length,
      negativeControls: {
        pass: controls.filter((o) => o.verdict === "pass").length,
        fail: controls.filter((o) => o.verdict === "fail").length,
        escalate: controls.filter((o) => o.verdict === "escalate").length,
      },
      metric: { median: quantile(metrics, 0.5), p25, p75, iqr: p75 - p25 },
    });
  }

  // Invariant checks are computed ACROSS probes, which is why each probe is its
  // own request: pairing inside one request would contaminate both answers.
  const byId = new Map(outcomes.map((o) => [o.id, o]));
  const invariantChecks: InvariantCheck[] = [];
  for (const outcome of outcomes) {
    const partnerId = (PROBES.find((p) => p.id === outcome.id) as { pairedWith?: string } | undefined)?.pairedWith;
    if (!partnerId) continue;
    const partner = byId.get(partnerId);
    if (!partner || partnerId < outcome.id) continue; // count each pair once
    const sum = outcome.metric + partner.metric;
    invariantChecks.push({
      group: `${outcome.id}+${partnerId}`,
      a: outcome.id,
      b: partnerId,
      sum,
      deviation: Math.abs(sum - 1),
      withinTolerance: Math.abs(sum - 1) <= INVARIANT_TOLERANCE,
    });
  }

  const failures: SmallestReproduction[] = outcomes
    .filter((o) => o.verdict === "fail" || o.verdict === "escalate")
    .map((o) => ({
      id: o.id,
      failureMode: o.failureMode,
      observed: `${o.detail} (metric ${Number.isNaN(o.metric) ? "n/a" : o.metric.toFixed(3)})`,
      expected: o.expected,
      state: o.state,
      instructions: o.instructions,
    }));

  const clauses = deriveClauses(modes, invariantChecks);

  return {
    model: resolvedModel,
    generatedAt: new Date().toISOString(),
    probeCount: outcomes.length,
    modes,
    invariantChecks,
    failures,
    clauses,
  };
}

/**
 * Clauses are written as FALSIFIABLE statements. "Jev is unreliable at dates"
 * is a description; "the pipeline escalates any date judgment to code" is a
 * clause a tester can write a failing test against.
 */
function deriveClauses(modes: readonly ModeSummary[], invariants: readonly InvariantCheck[]): string[] {
  const clauses: string[] = [];
  const byMode = new Map(modes.map((m) => [m.failureMode, m]));

  for (const [mode, summary] of byMode) {
    const controlFails = summary.negativeControls.fail;
    const positiveFails = summary.fail - controlFails;
    if (controlFails > 0) {
      clauses.push(
        `CODE OWNS ${mode}: ${controlFails} control probe(s) failed, meaning the boundary is INSIDE the trivially-computable region. No ${mode} judgment may be delegated to Jev without a code-side check.`,
      );
    } else if (positiveFails > 0) {
      clauses.push(
        `CODE OWNS ${mode}: ${positiveFails} of ${summary.probes - summary.negativeControls.fail - summary.negativeControls.pass} non-control probes failed while all controls passed. Delegate only above the observed boundary and always cross-check in code.`,
      );
    } else if (summary.escalate > 0) {
      clauses.push(
        `ESCALATE ON ${mode}: no probe failed, but ${summary.escalate} landed in the inconclusive band. The pipeline must treat any ${mode} answer inside the band as "ask a human", not as a pass.`,
      );
    } else {
      clauses.push(`DELEGATE ${mode} (bounded): all probes passed at this size and shape. This clause is void outside the probed range.`);
    }
  }

  for (const check of invariants) {
    if (!check.withinTolerance) {
      clauses.push(
        `CODE MUST NOT CONVERT: P(${check.a}) + P(${check.b}) = ${check.sum.toFixed(3)}, a deviation of ${check.deviation.toFixed(3)} from 1. A threshold tuned on one primitive may not be reused on the other.`,
      );
    }
  }

  return clauses;
}

// ── CLI entry ────────────────────────────────────────────────────────────────
export async function generateContract(transport: JevTransport, model = "jev-1.13.0"): Promise<CapabilityContract> {
  const outcomes = await runProbes(transport, PROBES, model);
  // The alias can move; log the ID the server actually answered with.
  const resolved = outcomes.find((o) => "model" in o.raw) ? (outcomes.find((o) => "model" in o.raw)!.raw as SystemOneResult<Questions>).model : model;
  return buildContract(outcomes, resolved);
}
