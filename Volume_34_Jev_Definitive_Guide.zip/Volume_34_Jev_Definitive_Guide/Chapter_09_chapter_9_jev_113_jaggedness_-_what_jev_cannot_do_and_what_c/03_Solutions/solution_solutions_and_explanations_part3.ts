/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// probes.test.ts — the harness runs against a fake transport in CI.
// ─────────────────────────────────────────────────────────────────────────────
import { describe, expect, it } from "vitest";
import { buildContract, runProbes, type JevTransport } from "./harness";
import { PROBES, type Probe } from "./probes";
import type { Questions, RequestOptions, SystemOneRequest, SystemOneResult } from "@typesafe-ai/sdk";

/** Canned answers, keyed by probe id. `undefined` means "omit the key entirely". */
type Script = Record<string, unknown>;

class FakeTransport implements JevTransport {
  public readonly calls: SystemOneRequest<Questions>[] = [];
  constructor(
    private readonly script: Script,
    private readonly behaviour: { throwOn?: string; model?: string } = {},
  ) {}

  async systemOne<Q extends Questions>(
    request: SystemOneRequest<Q>,
    _options?: RequestOptions,
  ): Promise<SystemOneResult<Q>> {
    this.calls.push(request as SystemOneRequest<Questions>);
    const id = Object.keys(request.questions)[0];
    if (this.behaviour.throwOn === id) throw new Error("transport exploded");
    const answer = this.script[id];
    return {
      model: this.behaviour.model ?? "jev-1.13.0",
      answers: (answer === undefined ? {} : { [id]: answer }) as SystemOneResult<Q>["answers"],
      usage: { input_tokens: 10, output_tokens: 2 },
    };
  }
}

/** Build a fake script that answers every probe "perfectly". */
function perfectScript(probes: readonly Probe[]): Script {
  const script: Script = {};
  for (const probe of probes) {
    switch (probe.kind) {
      case "noul":
      case "deterministic":
        script[probe.id] = { type: "noul", noul: probe.expected === "yes" ? 0.99 : 0.01 };
        break;
      case "choice": {
        const probabilities = Object.fromEntries(Object.keys(probe.criteria).map((k) => [k, k === probe.expected ? 0.95 : 0.05 / Math.max(1, Object.keys(probe.criteria).length - 1)]));
        script[probe.id] = { type: "choice", choice: probe.expected, probabilities, confidence: 0.95 };
        break;
      }
      case "score": {
        const probabilities = Object.fromEntries(probe.criteria.map((_, i) => [String(i), i === probe.expected ? 1 : 0]));
        script[probe.id] = { type: "score", score: probe.expected, legend: Object.fromEntries(probe.criteria.map((c, i) => [String(i), c])), probabilities, confidence: 1 };
        break;
      }
    }
  }
  return script;
}

describe("probe suite shape", () => {
  it("covers all nine documented failure modes", () => {
    const modes = new Set(PROBES.map((p) => p.failureMode));
    expect(modes.size).toBe(9);
  });

  it("gives the first five modes at least three probes and the last four at least two", () => {
    const firstFive = ["literal_reading", "arithmetic", "date_comparison", "indirection", "large_irrelevant_state"] as const;
    for (const mode of firstFive) {
      expect(PROBES.filter((p) => p.failureMode === mode).length).toBeGreaterThanOrEqual(3);
    }
    const lastFour = ["adversarial_content", "contradictory_instructions", "structural_invariants", "generation"] as const;
    for (const mode of lastFour) {
      expect(PROBES.filter((p) => p.failureMode === mode).length).toBeGreaterThanOrEqual(2);
    }
  });

  it("has exactly one negative control per failure mode", () => {
    const modes = new Set(PROBES.map((p) => p.failureMode));
    for (const mode of modes) {
      const controls = PROBES.filter((p) => p.failureMode === mode && p.negativeControl);
      expect(controls.length, `mode ${mode}`).toBe(1);
    }
  });
});

describe("harness against a fake transport", () => {
  it("issues exactly one systemOne call per probe", async () => {
    const transport = new FakeTransport(perfectScript(PROBES));
    await runProbes(transport, PROBES);
    expect(transport.calls.length).toBe(PROBES.length);
  });

  it("passes every probe when the fake answers perfectly", async () => {
    const transport = new FakeTransport(perfectScript(PROBES));
    const contract = buildContract(await runProbes(transport, PROBES), "jev-1.13.0");
    expect(contract.failures).toHaveLength(0);
    expect(contract.modes.every((m) => m.fail === 0)).toBe(true);
  });

  it("flags a known-bad arithmetic fake as a failure with the right reproduction", async () => {
    const script = perfectScript(PROBES);
    // Sabotage exactly one probe: Jev confidently gets the three-line sum wrong.
    script["arith-three-line-sum"] = { type: "noul", noul: 0.97 };
    const transport = new FakeTransport(script);
    const contract = buildContract(await runProbes(transport, PROBES), "jev-1.13.0");

    const reproduction = contract.failures.find((f) => f.id === "arith-three-line-sum");
    expect(reproduction).toBeDefined();
    expect(reproduction!.expected).toBe("yes");
    expect(reproduction!.observed).toContain("confirmed");

    const arithmetic = contract.modes.find((m) => m.failureMode === "arithmetic")!;
    expect(arithmetic.fail).toBe(1);
    // The control passed, so the boundary is above trivial addition.
    expect(arithmetic.negativeControls.pass).toBe(1);
    expect(contract.clauses.some((c) => c.startsWith("CODE OWNS arithmetic"))).toBe(true);
  });

  it("records an inconclusive answer as escalate rather than coercing it", async () => {
    const script = perfectScript(PROBES);
    script["lit-negation"] = { type: "noul", noul: 0.5 };
    const transport = new FakeTransport(script);
    const contract = buildContract(await runProbes(transport, PROBES), "jev-1.13.0");

    const literal = contract.modes.find((m) => m.failureMode === "literal_reading")!;
    expect(literal.escalate).toBe(1);
    expect(literal.fail).toBe(0);
    expect(contract.clauses.some((c) => c.startsWith("ESCALATE ON literal_reading"))).toBe(true);
  });

  it("emits a CODE MUST NOT CONVERT clause when a paired complement does not sum to 1", async () => {
    const script = perfectScript(PROBES);
    script["inv-refund-positive"] = { type: "noul", noul: 0.72 };
    script["inv-refund-negative"] = { type: "noul", noul: 0.47 };
    const transport = new FakeTransport(script);
    const contract = buildContract(await runProbes(transport, PROBES), "jev-1.13.0");

    const check = contract.invariantChecks[0];
    expect(check.sum).toBeCloseTo(1.19, 2);
    expect(check.withinTolerance).toBe(false);
    expect(contract.clauses.some((c) => c.includes("CODE MUST NOT CONVERT"))).toBe(true);
  });

  it("turns a transport throw into an escalate, not a crash", async () => {
    const transport = new FakeTransport(perfectScript(PROBES), { throwOn: "date-order" });
    const outcomes = await runProbes(transport, PROBES);
    const failed = outcomes.find((o) => o.id === "date-order")!;
    expect(failed.verdict).toBe("escalate");
    expect(failed.detail).toBe("error");
  });

  it("resolves the model id from the response, not from the requested alias", async () => {
    const transport = new FakeTransport(perfectScript(PROBES), { model: "jev-1.13.0" });
    const contract = buildContract(await runProbes(transport, PROBES, "jev-latest"), "jev-1.13.0");
    expect(contract.model).toBe("jev-1.13.0");
    // The resolved id is what gets committed, never the alias that was requested.
    expect(contract.model).not.toBe("jev-latest");
  });
});
