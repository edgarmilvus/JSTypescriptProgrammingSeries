/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Hello World: Jev + LLM Two-Speed Architecture.
 *
 * A customer support triage endpoint built around two decision engines:
 *   1. Jev (System One) — a sub-100ms calibrated classifier.
 *   2. An LLM — a slower, more expensive fallback for uncertain cases.
 *
 * The seam between them is a single confidence check.
 */

import { TypeSafeClient, choice, noul } from "@typesafe-ai/sdk";

// ─── 1. Client configuration ────────────────────────────────────────────────

/** The Jev client. Reads TYPESAFE_API_KEY from the environment. */
const jev = new TypeSafeClient();

// ─── 2. Domain types ────────────────────────────────────────────────────────

/** The three routing labels the queue understands, plus a human-escalation hatch. */
type Route = "billing" | "technical" | "account" | "escalate";

/** Which engine produced the final answer. */
type Path = "fast" | "slow";

/** What the triage endpoint hands back to its caller. */
interface TriageOutcome {
  route: Route;           // Where the message should go.
  path: Path;             // Which engine produced the final answer.
  jevConfidence: number;  // What Jev thought of its own read, even on the slow path.
  latencyMs: number;      // Wall-clock duration of the entire call.
}

// ─── 3. The one number that decides everything ──────────────────────────────

/**
 * The confidence floor. Jev's fast-path answer is trusted only at or above
 * this value. 0.85 is a conservative starting point for a four-way
 * classification; tune it against your own labelled data, not your intuition.
 */
const CONFIDENCE_FLOOR = 0.85;

// ─── 4. The public entry point ──────────────────────────────────────────────

/**
 * Triage a customer message.
 *
 * Runs Jev on the fast path. Escalates to an LLM when Jev's confidence
 * is below the floor, or when Jev picks the escape hatch label `other`.
 */
async function triage(message: string): Promise<TriageOutcome> {
  const start = performance.now();

  // ── Step A: ask Jev. One request, two questions, one round trip. ──
  const { answers } = await jev.systemOne({
    state: message,
    questions: {
      intent: choice("What is the customer's primary intent?", {
        billing: "Payment, invoice, refund, or subscription",
        technical: "Bug, outage, integration, or error",
        account: "Login, password, profile, or permissions",
        other: "Anything that does not fit the above categories",
      }),
      urgency: noul("Does the message express urgency?"),
    },
  });

  const { intent } = answers;

  // ── Step B: the seam. High confidence and a real label → fast path. ──
  if (intent.confidence >= CONFIDENCE_FLOOR && intent.choice !== "other") {
    return {
      route: intent.choice,
      path: "fast",
      jevConfidence: intent.confidence,
      latencyMs: performance.now() - start,
    };
  }

  // ── Step C: the slow path. Hand Jev's tentative read to the LLM. ──
  const route = await slowReason(message, {
    choice: intent.choice,
    confidence: intent.confidence,
  });

  return {
    route,
    path: "slow",
    jevConfidence: intent.confidence,
    latencyMs: performance.now() - start,
  };
}

// ─── 5. The slow engine (stubbed) ───────────────────────────────────────────

/**
 * Ask a generative LLM to decide what Jev could not.
 *
 * In production this calls the reasoning model of your choice — GPT, Claude,
 * Gemini — with a prompt carrying both the message and Jev's tentative read.
 * The hint matters: it lets the LLM spend its budget resolving the ambiguity
 * rather than re-deriving the obvious.
 */
async function slowReason(
  _message: string,
  _jevHint: { choice: string; confidence: number },
): Promise<Route> {
  // In the real system: an LLM call with a JSON-mode response format, a
  // timeout, a retry, and a schema validator. Here we return the safest
  // possible answer so the example runs offline.
  return "escalate";
}

// ─── 6. A tiny driver so the example runs end-to-end ────────────────────────

(async () => {
  const messages = [
    "I was charged twice for order A-104. Please refund the duplicate.",
    "The export button crashes on Safari when I click it.",
    "Hey, just wondering about your pricing.",
  ];

  const outcomes = await Promise.all(messages.map(triage));

  for (const [i, outcome] of outcomes.entries()) {
    console.log({
      message: messages[i].slice(0, 44) + "…",
      ...outcome,
    });
  }
})();
