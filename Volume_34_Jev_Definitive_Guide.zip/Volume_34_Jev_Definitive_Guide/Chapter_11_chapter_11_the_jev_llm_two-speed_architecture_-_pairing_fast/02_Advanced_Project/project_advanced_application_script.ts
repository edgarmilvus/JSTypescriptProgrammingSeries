/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/triage/route.ts
 * ─────────────────────────────────────────────────────────────────────────
 * Two-Speed Support Triage
 *
 *   1. Jev (System One) answers four parallel questions in <100ms.
 *   2. A deterministic gate decides: accept Jev, or escalate to an LLM.
 *   3. The LLM slow path fires all requested tools concurrently.
 *
 * Both paths share the same typed ticket envelope, so downstream code
 * cannot tell which path produced a given verdict unless it asks.
 * ─────────────────────────────────────────────────────────────────────────
 */
import { NextRequest, NextResponse } from "next/server";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type SystemOneResult,
} from "@typesafe-ai/sdk";
import Anthropic from "@anthropic-ai/sdk";

/* ─────────── 1. Domain types + TypeScript utility types ─────────── */

/** Raw payload as it arrives from the ticketing webhook. */
interface IncomingTicket {
  id: string;
  customerId: string;
  plan: "free" | "pro" | "enterprise";
  body: string;
}

/** A single order attached to a customer. */
interface Order {
  id: string;
  amountCents: number;
  status: "captured" | "refunded" | "pending";
}

/** Utility type: freeze the ticket so no path can mutate it mid-flight. */
type FrozenTicket = Readonly<IncomingTicket>;

/** Utility type: the projection of the ticket the LLM is allowed to see. */
type LlmVisibleTicket = Pick<IncomingTicket, "body" | "plan">;

/** Utility type: enrichment values are optional; not every ticket has them. */
type Enrichment = Partial<{ orderHistory: Order[]; kbSnippets: string[] }>;

/** Compose the frozen ticket with optional enrichment in one alias. */
type TicketContext = FrozenTicket & Enrichment;

/* ─────────── 2. Clients ─────────── */

/** Jev client for the fast path; reads TYPESAFE_API_KEY from env. */
const jev = new TypeSafeClient();

/** Anthropic client for the slow path. */
const anthropic = new Anthropic();

/* ─────────── 3. Fast path — Jev parallel questions ─────────── */

/**
 * The four typed questions Jev answers in one request. Each is atomic,
 * so each fits Jev's "snap judgment" contract and runs in parallel.
 */
const TRIAGE = {
  department: choice("Which team should handle `ticket.body`?", {
    billing: "Payment, charge, invoice, or refund concerns",
    technical: "Bugs, outages, integrations, or API problems",
    account: "Login, profile, permissions, or security",
    shipping: "Delivery, tracking, or wrong-item issues",
  }),
  urgency: score("How time-sensitive is the request in `ticket.body`?", [
    "Not time-sensitive; a general question",
    "Somewhat urgent; the user mentions a deadline",
    "Urgent; production impact or a blocked user",
  ]),
  frustration: score("How frustrated does the customer appear?", [
    "Calm and matter-of-fact",
    "Frustrated but civil",
    "Very angry; hostile or threatening language",
  ]),
  refundRequested: noul(
    "Does the customer explicitly ask for a refund or account credit?"
  ),
};

/** Fully typed fast verdict; SystemOneResult infers each answer's shape. */
type FastVerdict = SystemOneResult<typeof TRIAGE>;

/** Send all four questions in one Jev call. */
async function fastPath(ticket: FrozenTicket): Promise<FastVerdict> {
  return jev.systemOne({
    state: { ticket: { body: ticket.body }, plan: ticket.plan },
    questions: TRIAGE,
  });
}

/* ─────────── 4. Confidence gate — deterministic routing ─────────── */

/** Departments where refund stakes justify the slow path. */
const HIGH_STAKES_DEPARTMENTS = new Set(["billing", "shipping"]);

/** Plans that always deserve the slow path regardless of confidence. */
const HIGH_VALUE_PLANS = new Set<IncomingTicket["plan"]>(["enterprise"]);

/**
 * Decide between the two speeds. Returns `"auto"` when the fast verdict
 * is trustworthy at the current risk tier, `"slow"` otherwise.
 */
function routeFastPath(
  verdict: FastVerdict,
  ticket: FrozenTicket
): "auto" | "slow" {
  const { department, urgency, frustration, refundRequested } = verdict.answers;

  /** Weakest link across every confident answer. */
  const minConfidence = Math.min(
    department.confidence,
    urgency.confidence,
    frustration.confidence
  );

  if (minConfidence < 0.75) return "slow"; // Jev is not sure enough.
  if (HIGH_VALUE_PLANS.has(ticket.plan)) return "slow"; // Enterprise always reasons.
  if (
    refundRequested.noul > 0.7 &&
    HIGH_STAKES_DEPARTMENTS.has(department.choice)
  ) {
    return "slow"; // Money is moving; the slow path audits it.
  }
  return "auto";
}

/* ─────────── 5. Slow path — tool definitions + registry ─────────── */

/** Tool schemas the LLM may invoke; all are read-only lookups. */
const TOOLS = [
  {
    name: "fetch_order_history",
    description: "Return the customer's orders from the last 90 days.",
    input_schema: {
      type: "object" as const,
      properties: { customerId: { type: "string" } },
      required: ["customerId"],
    },
  },
  {
    name: "search_knowledge_base",
    description: "Search internal documentation for a given query.",
    input_schema: {
      type: "object" as const,
      properties: { query: { type: "string" } },
      required: ["query"],
    },
  },
  {
    name: "check_refund_policy",
    description: "Return the refund policy that applies to a specific order.",
    input_schema: {
      type: "object" as const,
      properties: { orderId: { type: "string" } },
      required: ["orderId"],
    },
  },
] as const;

/** Union of every tool's name, inferred from TOOLS. */
type ToolName = (typeof TOOLS)[number]["name"];

/**
 * Utility type: a total registry from ToolName → async handler.
 * If you add a tool to TOOLS and forget an implementation, TS errors.
 */
const TOOL_IMPL: Record<
  ToolName,
  (input: Record<string, string>) => Promise<string>
> = {
  fetch_order_history: async ({ customerId }) =>
    JSON.stringify(await db.orders.findByCustomer(customerId, 90)),
  search_knowledge_base: async ({ query }) =>
    JSON.stringify(await kb.search(query, { topK: 5 })),
  check_refund_policy: async ({ orderId }) =>
    JSON.stringify(await policy.lookupForOrder(orderId)),
};

/**
 * Parallel tool execution. Every tool_use block the model emits in one
 * turn runs concurrently; we await the whole batch as one Promise.
 */
async function runToolsParallel(
  blocks: Anthropic.ToolUseBlock[]
): Promise<Anthropic.ToolResultBlockParam[]> {
  return Promise.all(
    blocks.map(async (block) => {
      const name = block.name as ToolName;
      const handler = TOOL_IMPL[name];
      const content = handler
        ? await handler(block.input as Record<string, string>)
        : `Unknown tool: ${name}`;
      return {
        type: "tool_result" as const,
        tool_use_id: block.id,
        content,
      };
    })
  );
}

/* ─────────── 6. Slow path — orchestrator loop ─────────── */

/**
 * Drive the LLM through up to four tool-using turns.
 * On the first turn where it stops asking for tools, we return its text.
 */
async function slowPath(
  ticket: FrozenTicket,
  verdict: FastVerdict
): Promise<{ reply: string; toolsUsed: string[] }> {
  const visible: LlmVisibleTicket = { body: ticket.body, plan: ticket.plan };

  const messages: Anthropic.MessageParam[] = [
    {
      role: "user",
      content: [
        "A Jev triage pass just ran on this support ticket and was not",
        "confident enough to auto-route. Use the tools you need, then",
        "produce the final customer-facing reply.",
        "",
        `Jev's read: department=${verdict.answers.department.choice}` +
          ` (p=${verdict.answers.department.confidence.toFixed(2)}), ` +
          `urgency=${verdict.answers.urgency.score.toFixed(2)}, ` +
          `frustration=${verdict.answers.frustration.score.toFixed(2)}, ` +
          `refund_requested=${verdict.answers.refundRequested.noul.toFixed(2)}.`,
        "",
        `Ticket: ${JSON.stringify(visible)}`,
      ].join("\n"),
    },
  ];

  const toolsUsed: string[] = [];

  for (let turn = 0; turn < 4; turn++) {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      tools: [...TOOLS],
      messages,
    });

    if (response.stop_reason !== "tool_use") {
      const reply = response.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("\n");
      return { reply, toolsUsed };
    }

    const toolUses = response.content.filter(
      (b): b is Anthropic.ToolUseBlock => b.type === "tool_use"
    );
    toolsUsed.push(...toolUses.map((t) => t.name));

    // Async tool handling: await the whole parallel batch before continuing.
    const results = await runToolsParallel(toolUses);

    // Thread the assistant turn and the tool results back into the loop.
    messages.push({ role: "assistant", content: response.content });
    messages.push({ role: "user", content: results });
  }

  return { reply: "Escalation required: tool budget exhausted.", toolsUsed };
}

/* ─────────── 7. Route handler — the entry point ─────────── */

/**
 * POST /api/triage
 *
 * 1. Fast path: Jev answers four questions in one call.
 * 2. Gate: accept if confident & low stakes, else fall through.
 * 3. Slow path: LLM reasons with parallel tools, returns a reply.
 */
export async function POST(req: NextRequest) {
  const raw = (await req.json()) as IncomingTicket;
  const ticket: FrozenTicket = raw;

  const verdict = await fastPath(ticket);

  if (routeFastPath(verdict, ticket) === "auto") {
    return NextResponse.json({
      path: "fast",
      department: verdict.answers.department.choice,
      confidence: verdict.answers.department.confidence,
      urgency: verdict.answers.urgency.score,
      frustration: verdict.answers.frustration.score,
      refundRequested: verdict.answers.refundRequested.noul,
    });
  }

  const { reply, toolsUsed } = await slowPath(ticket, verdict);
  return NextResponse.json({ path: "slow", toolsUsed, reply });
}
