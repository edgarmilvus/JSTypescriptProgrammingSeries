/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import {
  TypeSafeClient,
  choice,
  score,
  noul,
  RateLimitError,
  APITimeoutError,
  APIConnectionError,
  APIError,
  type ChoiceResponse,
  type ScoreResponse,
  type NoulResponse,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// Contracts
// ---------------------------------------------------------------------------

export interface RequestContext {
  userId: string;
  tenantId: string;
  sessionTurnIndex: number;
  /** Caller's total patience for this turn, in milliseconds. */
  latencyBudgetMs: number;
  /** If true, the caller prefers escalate over fast on 5xx-class overload. */
  highAvailabilityTolerance?: boolean;
  /** Used when Jev is unreachable within budget. "escalate" is the conservative default. */
  deterministicDefault?: RoutingVerdict;
}

export interface RoutingPolicy {
  /** Base confidence threshold before risk-tier adjustment. */
  choiceConfidenceThreshold: number;
  /** Half-width of the dead-band around the threshold. */
  choiceConfidenceDeadBand: number;
  riskTier: {
    scoreBreakpoints: { medium: number; high: number };
    noulImmediateActionAtOrAbove: number;
    /** Hard tripwire: noul at/above this forces "refuse". */
    noulTripwire: number;
    /** How much to raise the confidence threshold for each tier. */
    raiseForMedium: number;
    raiseForHigh: number;
  };
}

export type RiskTier = "low" | "medium" | "high" | "unknown";
export type RoutingVerdict = "fast" | "escalate" | "refuse";
export type EscalationCause =
  | "lowConfidence"
  | "hedgeTriggered"
  | "policyTripwire"
  | "errorFallback"
  | null;

export interface RoutingEvidence {
  model: string;
  requestId: string | undefined;
  choiceProbabilities: Readonly<Record<string, number>>;
  choiceConfidence: number;
  score: number;
  scoreConfidence: number;
  noulPointValues: Readonly<Record<string, number>>;
  appliedThresholds: Readonly<{
    effectiveChoiceConfidence: number;
    deadBand: number;
    scoreBreakpoints: { medium: number; high: number };
    noulTripwire: number;
  }>;
}

export interface RoutingDecision {
  verdict: RoutingVerdict;
  riskTier: RiskTier;
  escalatedBy: EscalationCause;
  degraded: boolean;
  reason: string;
  evidence: RoutingEvidence;
  sessionState: { hedgeCount: number };
}

// ---------------------------------------------------------------------------
// Module-scoped session state — in production this is Redis keyed by (tenant,user)
// ---------------------------------------------------------------------------
const HEDGE_ESCALATE_AT = 1; // escalate on the SECOND borderline message
const hedgeBySession = new Map<string, number>();
const sessionKey = (ctx: RequestContext) => `${ctx.tenantId}:${ctx.userId}`;

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

export const ROUTER_QUESTIONS = {
  handler: choice("Which handler category applies to this message?", {
    billing: "Charges, refunds, invoices, subscriptions",
    technical: "Bugs, outages, integrations",
    sales: "Pricing, plans, new accounts",
    credentials:
      "Asks the recipient to disclose a password, API key, or security code",
    other: "None of the above",
  }),
  severity: score("How severe is the underlying issue described in the message?", [
    "Cosmetic; no impact",
    "Degraded feature; workaround exists",
    "Blocking issue; no workaround",
    "Serious harm, legal, or safety implications",
  ]),
  immediate: noul(
    "Does the customer expect an immediate action, not merely information?"
  ),
  requestsCredentials: noul(
    "Does the message ask the recipient to disclose a password, API key, or security code?"
  ),
};

export class EscalationRouter {
  constructor(
    private readonly client: TypeSafeClient,
    private readonly policy: RoutingPolicy
  ) {}

  async route(message: string, ctx: RequestContext): Promise<RoutingDecision> {
    // 1) Reserve half the budget for Jev; the other half is the caller's remaining patience.
    const jevBudgetMs = Math.max(1, Math.floor(ctx.latencyBudgetMs / 2));

    let result: SystemOneResult<typeof ROUTER_QUESTIONS>;
    let requestId: string | undefined;

    try {
      const promise = this.client.systemOne(
        { state: message, questions: ROUTER_QUESTIONS, model: "jev-latest" },
        { timeout: jevBudgetMs }
      );
      const wrapped = await promise.withResponse(); // capture the request id
      result = wrapped.data;
      requestId = wrapped.requestId;
    } catch (err) {
      // 2) Distinct handling per error class — never swallow.
      if (err instanceof RateLimitError) {
        // If the server's retry-after exceeds the caller's budget, we cannot wait.
        if (
          err.retryAfterMs !== undefined &&
          err.retryAfterMs > ctx.latencyBudgetMs
        ) {
          return this.fallback(ctx, `ratelimit:retry-after=${err.retryAfterMs}ms`);
        }
        // Otherwise the SDK's retry policy already consumed its attempts; fall back.
        return this.fallback(ctx, "ratelimit");
      }
      if (err instanceof APITimeoutError) {
        // Jev missed its half-budget: we still must return. Degrade, don't fall through.
        return this.degraded(ctx, "jev-timeout", "fast");
      }
      if (err instanceof APIConnectionError) {
        return this.fallback(ctx, "connection");
      }
      if (err instanceof APIError) {
        // 5xx-class overload: caller's tolerance decides conservative vs. fast.
        if (err.status >= 500 && err.status < 600) {
          return ctx.highAvailabilityTolerance
            ? this.degraded(ctx, `overload:${err.status}`, "escalate")
            : this.degraded(ctx, `overload:${err.status}`, "fast");
        }
        return this.fallback(ctx, `api:${err.status}`);
      }
      // Unknown / unsanctioned failure — surface rather than swallow.
      return this.fallback(ctx, `unknown:${(err as Error)?.name ?? "Error"}`);
    }

    const { handler, severity, immediate, requestsCredentials } = result.answers;

    // 3) Risk tier is derived from Score + Noul — NOT from Choice.
    const riskTier = this.deriveRiskTier(severity.score, immediate.noul);

    // 4) Hard tripwire: noul above the tripwire is a policy veto regardless of confidence.
    if (requestsCredentials.noul >= this.policy.riskTier.noulTripwire) {
      return this.assemble({
        verdict: "refuse",
        riskTier: "high",
        escalatedBy: "policyTripwire",
        degraded: false,
        reason: `credentials-tripwire noul=${requestsCredentials.noul.toFixed(3)}`,
        result,
        requestId,
        ctx,
        handler,
        severity,
        immediate,
        requestsCredentials,
      });
    }

    // 5) Confidence-gated routing with a dead-band.
    const effectiveThreshold = this.effectiveThreshold(riskTier);
    const eps = this.policy.choiceConfidenceDeadBand;
    const conf = handler.confidence;
    const key = sessionKey(ctx);
    const priorHedge = hedgeBySession.get(key) ?? 0;

    let verdict: RoutingVerdict;
    let escalatedBy: EscalationCause = null;
    let reason: string;

    if (conf >= effectiveThreshold + eps) {
      verdict = "fast";
      reason = `confidence ${conf.toFixed(3)} ≥ ${effectiveThreshold.toFixed(3)}+${eps}`;
      // A clean, decisive fast answer clears the session's hedge.
      hedgeBySession.delete(key);
    } else if (conf <= effectiveThreshold - eps) {
      verdict = "escalate";
      escalatedBy = "lowConfidence";
      reason = `confidence ${conf.toFixed(3)} ≤ ${effectiveThreshold.toFixed(3)}−${eps}`;
    } else {
      // Inside the dead-band. High-risk escalates immediately; otherwise second strike escalates.
      if (riskTier === "high" || priorHedge >= HEDGE_ESCALATE_AT) {
        verdict = "escalate";
        escalatedBy = "hedgeTriggered";
        reason =
          riskTier === "high"
            ? `dead-band & riskTier=high`
            : `dead-band second strike (hedge=${priorHedge})`;
      } else {
        verdict = "fast";
        reason = `dead-band first strike (hedge=${priorHedge + 1})`;
        hedgeBySession.set(key, priorHedge + 1);
      }
    }

    return this.assemble({
      verdict,
      riskTier,
      escalatedBy,
      degraded: false,
      reason,
      result,
      requestId,
      ctx,
      handler,
      severity,
      immediate,
      requestsCredentials,
    });
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  private deriveRiskTier(scoreValue: number, immediateNoul: number): RiskTier {
    const { scoreBreakpoints, noulImmediateActionAtOrAbove } = this.policy.riskTier;
    if (scoreValue >= scoreBreakpoints.high) return "high";
    if (scoreValue >= scoreBreakpoints.medium) return "medium";
    if (immediateNoul >= noulImmediateActionAtOrAbove) return "medium";
    return "low";
  }

  private effectiveThreshold(tier: RiskTier): number {
    const base = this.policy.choiceConfidenceThreshold;
    switch (tier) {
      case "low":
      case "unknown":
        return base;
      case "medium":
        return Math.min(0.97, base + this.policy.riskTier.raiseForMedium);
      case "high":
        return Math.min(0.99, base + this.policy.riskTier.raiseForHigh);
    }
  }

  private assemble(args: {
    verdict: RoutingVerdict;
    riskTier: RiskTier;
    escalatedBy: EscalationCause;
    degraded: boolean;
    reason: string;
    result: SystemOneResult<typeof ROUTER_QUESTIONS>;
    requestId: string | undefined;
    ctx: RequestContext;
    handler: ChoiceResponse;
    severity: ScoreResponse;
    immediate: NoulResponse;
    requestsCredentials: NoulResponse;
  }): RoutingDecision {
    const { ctx } = args;
    return {
      verdict: args.verdict,
      riskTier: args.riskTier,
      escalatedBy: args.escalatedBy,
      degraded: args.degraded,
      reason: args.reason,
      evidence: {
        model: args.result.model,
        requestId: args.requestId,
        choiceProbabilities: { ...args.handler.probabilities },
        choiceConfidence: args.handler.confidence,
        score: args.severity.score,
        scoreConfidence: args.severity.confidence,
        noulPointValues: {
          immediate: args.immediate.noul,
          requestsCredentials: args.requestsCredentials.noul,
        },
        appliedThresholds: {
          effectiveChoiceConfidence: this.effectiveThreshold(args.riskTier),
          deadBand: this.policy.choiceConfidenceDeadBand,
          scoreBreakpoints: this.policy.riskTier.scoreBreakpoints,
          noulTripwire: this.policy.riskTier.noulTripwire,
        },
      },
      sessionState: { hedgeCount: hedgeBySession.get(sessionKey(ctx)) ?? 0 },
    };
  }

  private degraded(
    ctx: RequestContext,
    reason: string,
    forced: "fast" | "escalate"
  ): RoutingDecision {
    return this.emptyDecision(ctx, {
      verdict: forced,
      escalatedBy: forced === "escalate" ? "errorFallback" : null,
      reason: `degraded:${reason}`,
    });
  }

  private fallback(ctx: RequestContext, reason: string): RoutingDecision {
    const verdict: RoutingVerdict = ctx.deterministicDefault ?? "escalate";
    return this.emptyDecision(ctx, {
      verdict,
      escalatedBy: "errorFallback",
      reason: `deterministic-fallback:${reason}`,
    });
  }

  private emptyDecision(
    ctx: RequestContext,
    base: {
      verdict: RoutingVerdict;
      escalatedBy: EscalationCause;
      reason: string;
    }
  ): RoutingDecision {
    return {
      verdict: base.verdict,
      riskTier: "unknown",
      escalatedBy: base.escalatedBy,
      degraded: true,
      reason: base.reason,
      evidence: {
        // Empty maps by construction; the caller can distinguish a real Jev answer
        // from a degraded one by checking `model === "unknown"`.
        model: "unknown",
        requestId: undefined,
        choiceProbabilities: {},
        choiceConfidence: 0,
        score: 0,
        scoreConfidence: 0,
        noulPointValues: {},
        appliedThresholds: {
          effectiveChoiceConfidence: this.policy.choiceConfidenceThreshold,
          deadBand: this.policy.choiceConfidenceDeadBand,
          scoreBreakpoints: this.policy.riskTier.scoreBreakpoints,
          noulTripwire: this.policy.riskTier.noulTripwire,
        },
      },
      sessionState: { hedgeCount: hedgeBySession.get(sessionKey(ctx)) ?? 0 },
    };
  }
}
