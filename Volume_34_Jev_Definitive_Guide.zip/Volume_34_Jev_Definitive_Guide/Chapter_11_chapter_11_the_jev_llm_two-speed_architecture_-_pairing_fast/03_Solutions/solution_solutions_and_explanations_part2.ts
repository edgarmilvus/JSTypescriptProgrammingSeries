/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import {
  TypeSafeClient,
  noul,
  NoulCriteria,
  type SystemOneResult,
  type Questions,
} from "@typesafe-ai/sdk";
import type { RequestContext, RiskTier, RoutingPolicy } from "./router"; // Exercise 1

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FastPathKind = "choice" | "score" | "noul";

export interface FastPathClaim {
  questionId: string;
  kind: FastPathKind;
  /** Point answer: the selected label, the score, or the noul probability. */
  point: string | number;
  /** Only present on choice and score answers. */
  confidence?: number;
  /** Only present on choice and score answers. */
  probabilities?: Readonly<Record<string, number>>;
  /** Only present on score answers. */
  legend?: Readonly<Record<string, string>>;
}

export interface Divergence {
  questionIds: string[];
  kind:
    | "closeChoice"
    | "lowScoreConfidence"
    | "noulDeadBand";
  reason: string;
}

export interface ThresholdsApplied {
  choiceConfidenceThreshold: number;
  deadBand: number;
  scoreBreakpoints: { medium: number; high: number };
  noulTripwire: number;
  noulImmediateActionAtOrAbove: number;
}

export interface EscalationBrief {
  verbatimState: string | object;
  routeReason: string;
  riskTier: RiskTier;
  fastPathClaims: FastPathClaim[];
  divergences: Divergence[];
  thresholdsApplied: ThresholdsApplied;
}

export type Disposition = "accept" | "acceptWithFlag" | "sendForReview";

export interface ReconciledOutcome {
  llmReply: string;
  brief: EscalationBrief;
  divergenceSignals: Readonly<Record<string, number>>;
  disposition: Disposition;
  degraded: boolean;
}

// ---------------------------------------------------------------------------
// Part A — buildEscalationBrief
// ---------------------------------------------------------------------------

const CLOSE_CHOICE_GAP = 0.15;
const LOW_SCORE_CONFIDENCE = 0.5;
const NOUL_DEAD_BAND: readonly [number, number] = [0.35, 0.65];

/**
 * Builds the structured handoff from Jev to the LLM. Never re-serializes the state:
 * the LLM must see the same bytes Jev saw, otherwise a divergence between the two
 * paths could be an artifact of preprocessing.
 */
export function buildEscalationBrief<Q extends Questions>(
  result: SystemOneResult<Q>,
  routeReason: string,
  riskTier: RiskTier,
  state: string | object,
  thresholds: ThresholdsApplied
): EscalationBrief {
  const claims: FastPathClaim[] = [];
  const divergences: Divergence[] = [];

  for (const [questionId, answer] of Object.entries(result.answers)) {
    switch (answer.type) {
      case "choice": {
        claims.push({
          questionId,
          kind: "choice",
          point: answer.choice,
          confidence: answer.confidence,
          probabilities: { ...answer.probabilities },
        });
        // Close-race detection: sort the distribution and check the gap.
        const sorted = Object.entries(answer.probabilities).sort(
          (a, b) => b[1] - a[1]
        );
        if (sorted.length >= 2 && sorted[0][1] - sorted[1][1] < CLOSE_CHOICE_GAP) {
          divergences.push({
            questionIds: [questionId],
            kind: "closeChoice",
            reason: `${questionId}: top two options (${sorted[0][0]}=${sorted[0][1].toFixed(
              2
            )}, ${sorted[1][0]}=${sorted[1][1].toFixed(2)}) are within ${CLOSE_CHOICE_GAP}`,
          });
        }
        break;
      }
      case "score": {
        claims.push({
          questionId,
          kind: "score",
          point: answer.score,
          confidence: answer.confidence,
          probabilities: { ...answer.probabilities },
          // Preserve the legend: 1.7 is meaningless to an LLM without the words.
          legend: { ...answer.legend },
        });
        if (answer.confidence < LOW_SCORE_CONFIDENCE) {
          divergences.push({
            questionIds: [questionId],
            kind: "lowScoreConfidence",
            reason: `${questionId}: score confidence ${answer.confidence.toFixed(
              2
            )} below ${LOW_SCORE_CONFIDENCE}`,
          });
        }
        break;
      }
      case "noul": {
        claims.push({
          questionId,
          kind: "noul",
          point: answer.noul,
        });
        if (
          answer.noul >= NOUL_DEAD_BAND[0] &&
          answer.noul <= NOUL_DEAD_BAND[1]
        ) {
          divergences.push({
            questionIds: [questionId],
            kind: "noulDeadBand",
            reason: `${questionId}: noul ${answer.noul.toFixed(
              2
            )} inside dead-band [${NOUL_DEAD_BAND[0]}, ${NOUL_DEAD_BAND[1]}]`,
          });
        }
        break;
      }
    }
  }

  return {
    // Identity pass-through; do NOT JSON-encode here.
    verbatimState: state,
    routeReason,
    riskTier,
    fastPathClaims: claims,
    divergences,
    thresholdsApplied: thresholds,
  };
}

// ---------------------------------------------------------------------------
// Part B — reconcile
// ---------------------------------------------------------------------------

const RECONCILE_QUESTIONS = {
  contradictsStrongClaim: noul(
    "Does the reply at `llm_reply` assert a fact that contradicts a threshold-confidence claim in `fast_path_evidence`? A claim is threshold-confidence when `confidence` is present and ≥ 0.8.",
    NoulCriteria({
      true: "The reply asserts something that the high-confidence evidence denies, or vice versa.",
      false: "The reply is consistent with the high-confidence evidence.",
    })
  ),
  citesAbsentInformation: noul(
    "Does the reply at `llm_reply` cite or rely on information that is not present in `verbatim_state`?",
    NoulCriteria({
      true: "The reply introduces specific facts, numbers, or entities that do not appear in the state.",
      false: "Everything the reply asserts is traceable to the state.",
    })
  ),
  actionInconsistent: noul(
    "Is the action the reply at `llm_reply` recommends inconsistent with the `choice` selected in `fast_path_evidence`?",
    NoulCriteria({
      true: "The reply steers toward a different handler, department, or decision than the fast path selected.",
      false: "The reply's implied action agrees with the fast-path choice.",
    })
  ),
} as const;

const RECONCILE_STRONG_CONFIDENCE = 0.8;

export async function reconcile(
  llmReply: string,
  brief: EscalationBrief,
  client: TypeSafeClient,
  remainingBudgetMs: number
): Promise<ReconciledOutcome> {
  try {
    const promise = client.systemOne(
      {
        state: {
          // Every field is explicitly named so each question can reference it by path.
          verbatim_state: brief.verbatimState,
          fast_path_evidence: brief.fastPathClaims.map((c) => ({
            question: c.questionId,
            kind: c.kind,
            answer: c.point,
            confidence: c.confidence,
            probabilities: c.probabilities,
            legend: c.legend,
          })),
          // The LLM's output is a first-class field, not buried in the input state.
          llm_reply: llmReply,
        },
        questions: RECONCILE_QUESTIONS,
        model: "jev-latest",
      },
      // The reconciler cannot starve a slow downstream consumer.
      { timeout: Math.max(1, remainingBudgetMs), retry: { maxRetries: 0 } }
    );

    const result = await promise;
    const signals: Record<string, number> = {
      contradictsStrongClaim: result.answers.contradictsStrongClaim.noul,
      citesAbsentInformation: result.answers.citesAbsentInformation.noul,
      actionInconsistent: result.answers.actionInconsistent.noul,
    };

    const disposition = chooseDisposition(signals, brief.riskTier);
    return {
      llmReply,
      brief,
      divergenceSignals: signals,
      disposition,
      degraded: false,
    };
  } catch {
    // A failed reconciliation must not throw past its own boundary.
    return {
      llmReply,
      brief,
      divergenceSignals: {},
      disposition: "sendForReview",
      degraded: true,
    };
  }
}

function chooseDisposition(
  signals: Record<string, number>,
  riskTier: RiskTier
): Disposition {
  const anyHigh = Object.values(signals).some((v) => v >= 0.75);
  const anyMedium = Object.values(signals).some((v) => v >= 0.45);
  if (anyHigh) return "sendForReview";
  if (anyMedium || riskTier === "high") return "acceptWithFlag";
  return "accept";
}
