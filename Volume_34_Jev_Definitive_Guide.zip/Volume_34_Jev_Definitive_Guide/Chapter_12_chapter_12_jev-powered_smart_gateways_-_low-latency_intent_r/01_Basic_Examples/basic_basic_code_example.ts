/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * gateway.ts
 * A minimal Jev-powered smart gateway.
 * ---------------------------------------------------------------------
 * One TypeSafe call classifies the intent and reports a calibrated
 * confidence. Code branches on that confidence and routes the request
 * to the cheapest downstream handler that can answer it safely.
 *
 * Run with:   npx tsx gateway.ts
 * Requires:   TYPESAFE_API_KEY in the environment
 */

import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

// ─── 1. Routing-policy constants ────────────────────────────────────
// These are the only tunables. They live in code, not in a prompt, so
// changing product behaviour is a pull request — not an LLM whisper.
const REVIEW_THRESHOLD = 0.55;    // below this: no answer, escalate to a human
const CONFIDENT_THRESHOLD = 0.85; // at or above: unlock the cheapest path

// ─── 2. Intent taxonomy ─────────────────────────────────────────────
// The union is the contract between Jev's answer and the routing table.
// Every handler below must be reachable, and no intent may be left out.
type Intent =
  | "billing_question"
  | "technical_issue"
  | "account_request"
  | "greeting"
  | "human_handoff";

// ─── 3. The Jev question ────────────────────────────────────────────
// One Choice question. `criteria` maps each option label to a short
// description; those labels are exactly what `.choice` will return.
const intentQuestion = choice(
  "What is the user trying to accomplish in this message?",
  {
    billing_question: "Asking about pricing, invoices, refunds, or their subscription plan.",
    technical_issue: "Reporting a bug, an outage, or an integration problem.",
    account_request: "Requesting a password reset, a plan change, or an account settings update.",
    greeting: "Small talk, a hello, or an off-topic comment that needs no account context.",
    human_handoff: "Explicitly asking for a human, or a complaint that must be handled by a person.",
  },
);

// ─── 4. Handlers ────────────────────────────────────────────────────
// Each handler stands in for a real downstream step: a canned FAQ
// lookup, a single SQL query, a cheap-LLM call, a frontier-LLM call,
// or a routing hop to a human agent. They are stubs here so that the
// whole demo is self-contained, deterministic, and free to run.
async function cannedAnswer(_m: string): Promise<string> {
  return "See our pricing at https://example.com/pricing.";
}
async function runAccountTool(_m: string): Promise<string> {
  return "Password reset link sent to the address on file.";
}
async function callCheapLLM(_m: string): Promise<string> {
  return "[reply from a 7B-class model]";
}
async function callFrontierLLM(_m: string): Promise<string> {
  return "[reply from a frontier generative LLM]";
}
async function escalateToHuman(_m: string): Promise<string> {
  return "Connecting you to a human agent…";
}

// ─── 5. Routing table ───────────────────────────────────────────────
// The intent → handler mapping is ordinary code. Which LLM to spend
// money on is a product decision and belongs in version control, not
// inside a system prompt where nobody can review a diff.
type Certainty = "high" | "low";
type Handler = (message: string, certainty: Certainty) => Promise<string>;

const ROUTES: Record<Intent, Handler> = {
  // Pricing questions are almost always safe to answer from a canned
  // page when Jev is confident; when it is not, upgrade the call.
  billing_question: (m, c) => (c === "high" ? cannedAnswer(m) : callFrontierLLM(m)),

  // Debug help benefits from a cheap LLM; low certainty bumps it up.
  technical_issue: (m, c) => (c === "high" ? callCheapLLM(m) : callFrontierLLM(m)),

  // Account actions are deterministic tools — no LLM in the loop at all.
  account_request: (m) => runAccountTool(m),

  // Greetings never need account context. A cheap LLM suffices.
  greeting: (m) => callCheapLLM(m),

  // Explicit handoffs (complaints, "get me a manager") always go to a
  // human regardless of confidence. This is a product commitment.
  human_handoff: (m) => escalateToHuman(m),
};

// ─── 6. The gateway ─────────────────────────────────────────────────
// A single shared client. Constructed once, reused for every request.
const client = new TypeSafeClient();

/**
 * Classify and route one user message.
 * @param userMessage  The raw text the user typed into the chat widget.
 * @returns            The reply string the UI should render.
 */
export async function gateway(userMessage: string): Promise<string> {
  const started = Date.now();

  // One network round-trip. Jev evaluates the choice question against
  // the message and returns { choice, confidence, probabilities }.
  const { answers } = await client.systemOne({
    state: { message: userMessage },
    questions: { intent: intentQuestion },
  });

  const { choice, confidence } = answers.intent;
  const intent = choice as Intent;

  console.log(
    `[gateway] intent=${intent} conf=${confidence.toFixed(2)} ` +
      `t=${Date.now() - started}ms`,
  );

  // Gate 1 — trust floor. Below this we refuse to act on the classification.
  if (confidence < REVIEW_THRESHOLD) {
    return escalateToHuman(userMessage);
  }

  // Gate 2 — certainty bucket. High certainty unlocks the cheap path;
  // anything in between is bumped to a stronger, more expensive model.
  const certainty: Certainty = confidence >= CONFIDENT_THRESHOLD ? "high" : "low";

  // Code — not the model — decides which handler runs.
  return ROUTES[intent](userMessage, certainty);
}

// ─── 7. Demo ────────────────────────────────────────────────────────
// Run `npx tsx gateway.ts` (or ts-node) to see the routing in action.
if (require.main === module) {
  const samples = [
    "How much does the Pro plan cost?",
    "Our webhook has been returning 500s for an hour.",
    "I need to reset my password.",
    "Hey, nice weather today.",
    "I want to speak to a manager right now.",
  ];

  (async () => {
    for (const msg of samples) {
      const reply = await gateway(msg);
      console.log(`  "${msg}"\n  → ${reply}\n`);
    }
  })();
}
