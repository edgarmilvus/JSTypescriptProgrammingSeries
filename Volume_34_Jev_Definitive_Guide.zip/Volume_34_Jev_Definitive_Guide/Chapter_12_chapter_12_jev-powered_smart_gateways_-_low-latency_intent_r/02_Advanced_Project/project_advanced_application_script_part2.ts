/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// lib/gateway-runtime.ts
//
// The runtime half. It takes a Lane and executes it. It owns the three things
// the classifier must never own: the semantic cache, the lane executors, and
// the turn metrics.
// ─────────────────────────────────────────────────────────────────────────────

import { streamChat } from "./llm";
import {
  classify,
  decide,
  POLICY,
  type Classification,
  type IntentKey,
  type Lane,
} from "./gateway";

/* ───────────────────────────────────────────────────────────────────────────
 * 1. THE SEMANTIC CACHE
 *
 * Key point, and the reason this is called semantic: the key is the DECISION,
 * not the string. Two turns worded completely differently — "how many seats am
 * I paying for" and "what's my seat count" — produce the same intent label and
 * the same fingerprint, so they share an entry.
 *
 * The fingerprint is word-order-insensitive and stopword-stripped. That is a
 * cheap approximation of semantic equivalence. It is not an embedding, and it
 * will miss paraphrases with different vocabulary. A production system that
 * needs real recall should key on an embedding of the message bucketed by
 * intent; the Jev label is what makes that bucketing safe, because you never
 * compare an account question against a drafting question.
 * ─────────────────────────────────────────────────────────────────────────── */

const CACHE_TTL_MS = 10 * 60 * 1_000;
const CACHE_MAX_ENTRIES = 2_000;

const STOPWORDS = new Set([
  "the", "a", "an", "is", "are", "was", "were", "do", "does", "did", "how",
  "what", "when", "where", "which", "can", "could", "would", "should", "please",
  "and", "or", "for", "to", "of", "in", "on", "at", "it", "my", "me", "i",
]);

/** Normalise a turn into a stable, word-order-insensitive cache key. */
function fingerprint(message: string): string {
  return [
    ...new Set(
      message
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter((word) => word.length > 2 && !STOPWORDS.has(word)),
    ),
  ]
    .sort()
    .join(" ");
}

interface CacheEntry {
  readonly chunks: string[];
  readonly expiresAt: number;
}

/** Swap for Redis or your KV of choice; the interface is intentionally tiny. */
const CACHE = new Map<string, CacheEntry>();

function cacheGet(key: string): string[] | undefined {
  const hit = CACHE.get(key);
  if (!hit) return undefined;
  if (hit.expiresAt < Date.now()) {
    CACHE.delete(key);
    return undefined;
  }
  CACHE.delete(key); // reinsert to refresh LRU position
  CACHE.set(key, hit);
  return hit.chunks;
}

function cacheSet(key: string, chunks: string[]): void {
  if (CACHE.size >= CACHE_MAX_ENTRIES) {
    const oldest = CACHE.keys().next().value;
    if (oldest !== undefined) CACHE.delete(oldest);
  }
  CACHE.set(key, { chunks, expiresAt: Date.now() + CACHE_TTL_MS });
}

/**
 * Buffer a stream as it is consumed, so the NEXT identical turn is a hit.
 *
 * Caching a stream means deciding when the response is "final". Buffering as a
 * side effect of yielding means the entry is written exactly once, on the last
 * chunk, and a stream that errors partway through is never cached at all.
 */
async function* tapAndCache(
  source: AsyncGenerator<string>,
  key: string,
): AsyncGenerator<string> {
  const buffered: string[] = [];
  for await (const chunk of source) {
    buffered.push(chunk);
    yield chunk;
  }
  cacheSet(key, buffered);
}

async function* replay(chunks: string[]): AsyncGenerator<string> {
  for (const chunk of chunks) yield chunk;
}

/* ───────────────────────────────────────────────────────────────────────────
 * 2. THE LANE EXECUTORS
 * ─────────────────────────────────────────────────────────────────────────── */

/** Stand-ins for the real handlers: a database read, a template, a docs lookup. */
const ACCOUNT = { plan: "Scale", seats: 24, renewsOn: "2026-11-01" };

const DETERMINISTIC: Record<IntentKey, () => string> = {
  small_talk: () => "Hey — what can I help you with?",
  account_lookup: () =>
    `You're on the ${ACCOUNT.plan} plan with ${ACCOUNT.seats} seats, renewing ${ACCOUNT.renewsOn}.`,
  how_to: () =>
    "That page moved in the last release — here's where it lives now.",
  draft_content: () => "",
  complex_analysis: () => "",
};

interface ModelBudget {
  readonly maxTokens: number;
  readonly tier: "economy" | "frontier";
}

const MODEL_BUDGET: Record<string, ModelBudget> = {
  [POLICY.economyModel]: { maxTokens: 512, tier: "economy" },
  [POLICY.frontierModel]: { maxTokens: 2_048, tier: "frontier" },
};

/**
 * Stream from a generative model.
 *
 * The Jev decision travels with the request as system context. The generative
 * model therefore does not have to re-derive what kind of turn it is looking
 * at — that work has already been paid for, once, for a fraction of a cent.
 * This is the compounding return on the classification: it is not only a
 * router input, it is also prompt scaffolding.
 */
async function* streamGenerative(
  model: string,
  message: string,
  classification: Classification,
): AsyncGenerator<string> {
  const budget = MODEL_BUDGET[model];
  const system = [
    "You are a support copilot embedded in a SaaS product.",
    `A classifier has already determined this turn is "${classification.intent.choice}"`,
    `with complexity ${classification.complexity.score.toFixed(2)} on a 0–3 scale.`,
    "Answer the user directly. Do not restate the classification.",
  ].join(" ");

  for await (const delta of streamChat({
    model,
    system,
    maxTokens: budget.maxTokens,
    messages: [{ role: "user", content: message }],
  })) {
    yield delta;
  }
}

/** Dispatch into the chosen lane and produce a token stream. */
async function* runLane(
  lane: Lane,
  message: string,
  classification: Classification,
): AsyncGenerator<string> {
  switch (lane.lane) {
    case "deterministic":
      yield DETERMINISTIC[lane.handler]();
      return;
    case "economy":
    case "frontier":
      yield* streamGenerative(lane.model, message, classification);
      return;
    case "block":
      yield "I can't help with that request.";
      return;
    case "human":
      yield "I want to get this right — a teammate will pick this up in a moment.";
      return;
  }
}

/* ───────────────────────────────────────────────────────────────────────────
 * 3. THE TURN
 * ─────────────────────────────────────────────────────────────────────────── */

export interface TurnResult {
  readonly classification: Classification;
  readonly lane: Lane;
  readonly cached: boolean;
  /** An async generator, so the transport can start forwarding before the end. */
  readonly stream: AsyncGenerator<string>;
  /** Time spent in the gate only. The full turn time is measured at the edge. */
  readonly gateLatencyMs: number;
}

/**
 * Handle one turn end to end.
 *
 * The ordering here matters and is worth stating plainly: classify, then gate,
 * then cache, then execute. Caching before classifying would require a cache
 * key derived from raw text, which is exactly the brittle lookup this design
 * exists to avoid.
 */
export async function handleTurn(
  message: string,
  recentContext: string[] = [],
): Promise<TurnResult> {
  const classification = await classify(message, recentContext);
  const lane = decide(classification);

  const cacheable =
    lane.lane === "deterministic" ||
    lane.lane === "economy" ||
    lane.lane === "frontier";

  const key = `${classification.intent.choice}:${fingerprint(message)}`;

  if (cacheable) {
    const hit = cacheGet(key);
    if (hit) {
      return {
        classification,
        lane,
        cached: true,
        stream: replay(hit),
        gateLatencyMs: classification.jevLatencyMs,
      };
    }
  }

  const source = runLane(lane, message, classification);

  return {
    classification,
    lane,
    cached: false,
    stream: cacheable ? tapAndCache(source, key) : source,
    gateLatencyMs: classification.jevLatencyMs,
  };
}
