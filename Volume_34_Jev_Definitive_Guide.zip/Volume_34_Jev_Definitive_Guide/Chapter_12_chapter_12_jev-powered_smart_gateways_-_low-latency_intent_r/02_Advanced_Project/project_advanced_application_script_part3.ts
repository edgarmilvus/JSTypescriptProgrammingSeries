/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// app/api/gateway/route.ts
//
// The transport. Streams the routing decision first, then tokens, then the
// turn metric. The decision frame arriving before the first token is what makes
// the optimistic UI honest rather than hopeful.
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest } from "next/server";
import { handleTurn } from "@/lib/gateway-runtime";

export const runtime = "nodejs"; // the SDK needs Node APIs, not the Edge runtime
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const { message, recentContext = [] } = (await req.json()) as {
    message: string;
    recentContext?: string[];
  };

  const encoder = new TextEncoder();
  const startedAt = performance.now();

  const stream = new ReadableStream({
    async start(controller) {
      /** One SSE frame. `event:` lets the client route frames without parsing. */
      const send = (event: string, data: unknown) =>
        controller.enqueue(
          encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
        );

      try {
        const turn = await handleTurn(message, recentContext);

        // Frame 1: the decision, available at ~100 ms, long before any token.
        send("decision", {
          lane: turn.lane.lane,
          intent: turn.classification.intent.choice,
          confidence: turn.classification.intent.confidence,
          complexity: turn.classification.complexity.score,
          cached: turn.cached,
          gateLatencyMs: Math.round(turn.gateLatencyMs),
          answeredBy: turn.classification.answeredBy,
        });

        // Frames 2..N: tokens, forwarded as they arrive.
        for await (const chunk of turn.stream) {
          send("token", { text: chunk });
        }

        // Frame N+1: the turn metric, for the client and for your dashboards.
        send("done", {
          totalLatencyMs: Math.round(performance.now() - startedAt),
          timeToFirstTokenMs: Math.round(performance.now() - startedAt),
        });
      } catch (error) {
        send("error", { message: "The gateway could not complete this turn." });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      // Prevents nginx and similar proxies from buffering the stream.
      "X-Accel-Buffering": "no",
    },
  });
}
