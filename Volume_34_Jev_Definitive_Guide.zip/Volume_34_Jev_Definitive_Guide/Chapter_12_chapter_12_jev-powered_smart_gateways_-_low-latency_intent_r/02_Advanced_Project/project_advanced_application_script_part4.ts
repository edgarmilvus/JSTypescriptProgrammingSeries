/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// lib/useGatewayTurn.ts
//
// Client-side hook. Three render phases, each driven by an SSE frame:
//   1. optimistic  — user hits send, UI shows their message immediately
//   2. decision    — gateway reports what it understood (lane, intent, confidence)
//   3. streaming   — tokens append as they arrive
// ─────────────────────────────────────────────────────────────────────────────

"use client";

import { useCallback, useRef, useState } from "react";

export interface GatewayDecision {
  lane: string;
  intent: string;
  confidence: number;
  complexity: number;
  cached: boolean;
  gateLatencyMs: number;
  answeredBy: string;
}

export function useGatewayTurn() {
  const [answer, setAnswer] = useState("");
  const [decision, setDecision] = useState<GatewayDecision | null>(null);
  const [busy, setBusy] = useState(false);
  const sourceRef = useRef<EventSource | null>(null);

  const send = useCallback(async (message: string, recentContext: string[] = []) => {
    setBusy(true);
    setAnswer("");      // optimistic: clear the pane immediately
    setDecision(null);

    const response = await fetch("/api/gateway", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, recentContext }),
    });

    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by a blank line.
      const frames = buffer.split("\n\n");
      buffer = frames.pop() ?? "";

      for (const frame of frames) {
        const event = /^event: (.+)$/m.exec(frame)?.[1];
        const raw = /^data: (.+)$/m.exec(frame)?.[1];
        if (!event || !raw) continue;
        const data = JSON.parse(raw);

        if (event === "decision") setDecision(data as GatewayDecision);
        else if (event === "token") setAnswer((prev) => prev + data.text);
        else if (event === "done") setBusy(false);
      }
    }
    setBusy(false);
  }, []);

  return { answer, decision, busy, send, sourceRef };
}
