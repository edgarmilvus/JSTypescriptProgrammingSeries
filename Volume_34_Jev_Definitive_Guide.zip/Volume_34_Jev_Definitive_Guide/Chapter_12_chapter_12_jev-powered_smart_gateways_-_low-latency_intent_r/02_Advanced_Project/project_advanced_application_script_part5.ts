/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.ts
// Description: Advanced Application Script
// ==========================================

// Turn A: the mass is split between how_to and complex_analysis.
// Both are generative lanes, so the ambiguity is cheap.
{
  choice: "how_to",
  confidence: 0.42,
  probabilities: { how_to: 0.46, complex_analysis: 0.41, draft_content: 0.08, /* … */ },
}

// Turn B: the mass is split between account_lookup and small_talk.
// One is a database read, the other is a canned string. The ambiguity is expensive.
{
  choice: "account_lookup",
  confidence: 0.42,
  probabilities: { account_lookup: 0.44, small_talk: 0.39, how_to: 0.12, /* … */ },
}
