/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part6.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Confidence alone is not enough to decide whether ambiguity is expensive.
 * Look at where the probability mass actually went, and whether the top two
 * options would route to materially different executors.
 */
export function ambiguityIsExpensive(classification: Classification): boolean {
  const { probabilities, choice } = classification.intent;
  const [runnerUp, runnerUpProbability] = Object.entries(probabilities)
    .filter(([label]) => label !== choice)
    .sort(([, a], [, b]) => b - a)[0] ?? ["", 0];

  // If the runner-up is close AND it lives in a different cost tier, pay up.
  const costTier = (label: string): 0 | 1 | 2 => {
    if (label === "small_talk" || label === "account_lookup") return 0;
    if (label === "how_to") return 1;
    return 2;
  };

  return (
    runnerUpProbability > 0.25 &&
    costTier(runnerUp) !== costTier(choice)
  );
}
