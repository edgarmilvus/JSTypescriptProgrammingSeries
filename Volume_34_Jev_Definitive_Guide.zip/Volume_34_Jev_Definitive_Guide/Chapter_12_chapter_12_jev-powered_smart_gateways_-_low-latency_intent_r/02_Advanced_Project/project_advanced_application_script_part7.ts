/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part7.ts
// Description: Advanced Application Script
// ==========================================

export interface TurnTelemetry {
  /** Identity and versioning */
  readonly turnId: string;
  readonly userId: string;

  /** The decision */
  readonly intent: IntentKey;
  readonly intentConfidence: number;
  readonly intentRunnerUp: string;
  readonly intentRunnerUpProbability: number;
  readonly injectionProbability: number;
  readonly complexityScore: number;
  readonly lane: Lane["lane"];
  readonly model: string | null;
  readonly cached: boolean;

  /** Latency, split so you can see where the time goes */
  readonly gateLatencyMs: number;
  readonly dispatchLatencyMs: number;
  readonly firstTokenLatencyMs: number;
  readonly totalLatencyMs: number;

  /** Cost */
  readonly gateInputTokens: number;
  readonly generationInputTokens: number;
  readonly generationOutputTokens: number;

  /** The model that actually answered, not the alias you asked for */
  readonly answeredBy: string;
}

export function recordTurn(telemetry: TurnTelemetry): void {
  // In production: emit to your metrics pipeline (OpenTelemetry, Datadog, etc.).
  // The fields above are chosen so that three charts become possible:
  //
  //   1. Lane distribution over time — is the gate finding cheap paths?
  //   2. Confidence histogram per intent — is the taxonomy too coarse?
  //   3. Cost per lane × lane volume — where is the bill actually coming from?
  console.log(JSON.stringify({ event: "gateway.turn", ...telemetry }));
}
