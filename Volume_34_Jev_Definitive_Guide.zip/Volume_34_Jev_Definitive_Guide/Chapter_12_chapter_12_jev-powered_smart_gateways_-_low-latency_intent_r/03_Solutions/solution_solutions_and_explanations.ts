/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// two-speed-gateway.ts
import { randomUUID } from "node:crypto";
import {
  TypeSafeClient,
  choice,
  noul,
  type NoulCriteria,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// 1.1  The intent question.
//
// Six options, split into three "rigidity classes":
//   RIGID-LOCAL  : check_balance, order_status — the answer comes from a DB row,
//                  no generative step adds value at any confidence.
//   RIGID-FRONTIER: legal_advice — answering at all is a liability; never let a
//                  cheap tier construct a sentence about it.
//   ELASTIC      : refund_request, password_reset, technical_support — the right
//                  handler depends on how sure we are and on the customer's risk
//                  tolerance, so these are the intents the policy actually moves.
// ---------------------------------------------------------------------------
export const INTENT_QUESTION = choice(
  "Which single intent best describes what the user wants? Classify the dominant " +
    "request, not every topic that appears.",
  {
    check_balance:
      "Read-only account lookup: balance, statements, recent transactions.",
    order_status: "Where an existing order or shipment is, in its delivery flow.",
    refund_request:
      "Money back for a charge, a billing dispute, or a duplicate charge.",
    password_reset: "Sign-in failure or credential recovery.",
    technical_support: "A bug, outage, or integration problem.",
    legal_advice:
      "Legal, tax, or regulatory interpretation; questions about liability or compliance.",
  }
);

// ---------------------------------------------------------------------------
// 1.2  Safety Nouls.
//
// These are worth their tokens because each one flips a decision that would
// otherwise be made on confidence alone — and confidence alone gets those
// decisions wrong often enough to matter:
//
//   demands_human  — baseline rate on our traffic: ~4-6%. It changes a
//                    LOCAL-eligible intent to FRONTIER (or a hand-off) every
//                    time it fires. Without it, ~5% of "check_balance" calls
//                    would return a bare number to a user who just told us
//                    they were done with bots. Cheap insurance on trust.
//
//   prior_failure  — baseline rate: ~9% of support traffic. It escalates one
//                    tier. Every one of those messages is a case where a cheap
//                    answer already failed; re-running the same tier is a
//                    guaranteed waste of that user's time.
//
//   legal_assertion — baseline rate: ~1%. Rare, high stakes. It is a hard
//                    override to FRONTIER for any intent, because an automated
//                    response to a liability claim is a company-level risk.
// ---------------------------------------------------------------------------
const SAFETY_N = noul(
  "Does the message demand a human, or state that the user has already asked " +
    "and been given an unsatisfying answer?",
  {
    true: "The user explicitly asks for a person, or says a prior attempt failed.",
    false: "No demand for a human and no indication of a prior failed attempt.",
  } satisfies NoulCriteria
);

const SAFETY_LEGAL = noul(
  "Does the message make a legal, tax, or regulatory assertion, or threaten a " +
    "formal complaint, chargeback, or legal action?",
  {
    true: "Contains a liability-bearing assertion or an escalation to a legal channel.",
    false: "Ordinary product or billing language with no legal framing.",
  } satisfies NoulCriteria
);

// ---------------------------------------------------------------------------
// 1.3  The pure decision function.
//
// No API call, no mutation. Unit-testable against the table below.
//
// * | intent            | conf | policy        | safety                    | → handler    | reason
// * | check_balance     | 0.97 | any           | clean                     | LOCAL        | balance is DB-only at any confidence
// * | check_balance     | 0.42 | any           | clean                     | FRONTIER     | below the 0.5 floor
// * | check_balance     | 0.99 | any           | demands_human             | FRONTIER     | safety beats confidence
// * | refund_request    | 0.95 | cost-first    | clean                     | LOCAL        | very high conf on a local-capable intent
// * | refund_request    | 0.95 | balanced      | clean                     | SMALL_MODEL  | money = mid tier by default
// * | refund_request    | 0.95 | quality-first | clean                     | FRONTIER     | quality-first never downgrades money
// * | refund_request    | 0.62 | balanced      | clean                     | FRONTIER     | mid conf on a money intent
// * | refund_request    | 0.99 | balanced      | legal_assertion           | FRONTIER     | liability override
// * | order_status      | 0.88 | balanced      | clean                     | LOCAL        | order DB is authoritative
// * | order_status      | 0.93 | cost-first    | demands_human             | SMALL_MODEL  | safety escalates exactly one tier
// * | technical_support | 0.91 | balanced      | clean                     | SMALL_MODEL  | high conf, generative answer
// * | technical_support | 0.45 | balanced      | clean                     | FRONTIER     | below the floor
// * | legal_advice      | 0.99 | any           | clean                     | FRONTIER     | rigid: always frontier
// * | legal_advice      | 0.30 | any           | clean                     | FRONTIER     | rigid + low conf
// ---------------------------------------------------------------------------
export type Handler = "LOCAL" | "SMALL_MODEL" | "FRONTIER";
export type PolicyName = "cost-first" | "balanced" | "quality-first";

export type Safety = {
  demandsHuman: number;
  legalAssertion: number;
};

export type RoutingDecision = {
  intent: string;
  confidence: number;
  handler: Handler;
  reason: string;
  policy: PolicyName;
  gatewayMs: number;
  estimatedCostUsd: number;
  estimatedDownstreamMs: number;
};

// Intent rigidity: rigid intents ignore confidence and policy.
const RIGID: Record<string, Handler> = {
  check_balance: "LOCAL",
  order_status: "LOCAL",
  legal_advice: "FRONTIER",
};

// Confidence floors per policy, in the order [local, small, frontier].
// A confidence below `local` cannot go to LOCAL; below `small` cannot go to
// SMALL_MODEL. These are the numbers the three policies actually move.
const FLOORS: Record<PolicyName, { local: number; small: number; global: number }> = {
  "cost-first": { local: 0.70, small: 0.40, global: 0.40 },
  balanced: { local: 0.85, small: 0.60, global: 0.50 },
  "quality-first": { local: 0.95, small: 0.80, global: 0.60 },
};

// Which handler an elastic intent prefers when confidence is high.
const ELASTIC_PREFERENCE: Record<PolicyName, Handler> = {
  "cost-first": "LOCAL",
  balanced: "SMALL_MODEL",
  "quality-first": "FRONTIER",
};

// Precedence between the two safety Nouls. Written down before the code,
// as the exercise requires: legal assertion beats a human demand, because
// a liability claim must reach the frontier regardless of what the user
// asked for. A human demand is then allowed to escalate but never to
// downgrade.
const SAFETY_PRECEDENCE: Array<keyof Safety> = ["legalAssertion", "demandsHuman"];
const SAFETY_THRESHOLD = 0.6;

export function decide(
  intent: string,
  confidence: number,
  safety: Safety,
  policy: PolicyName
): { handler: Handler; reason: string } {
  const floors = FLOORS[policy];

  // 3a. Absolute confidence floor. Below this, we never guess.
  if (confidence < floors.global) {
    return {
      handler: "FRONTIER",
      reason: `intent=${intent} conf=${confidence.toFixed(2)} policy=${policy} → FRONTIER (below ${floors.global} floor)`,
    };
  }

  // 3b. Safety overrides, applied in stated precedence order.
  const override = SAFETY_PRECEDENCE.find((k) => safety[k] >= SAFETY_THRESHOLD);
  if (override === "legalAssertion") {
    return {
      handler: "FRONTIER",
      reason: `intent=${intent} conf=${confidence.toFixed(2)} policy=${policy} → FRONTIER (legal assertion override)`,
    };
  }

  // 3c. Rigid intents: nobody moves them.
  const rigid = RIGID[intent];
  if (rigid) {
    // A human demand can only escalate a rigid-LOCAL intent, never downgrade
    // a rigid-FRONTIER one.
    if (override === "demandsHuman" && rigid !== "FRONTIER") {
      return {
        handler: "FRONTIER",
        reason: `intent=${intent} conf=${confidence.toFixed(2)} policy=${policy} → FRONTIER (human demand escalates rigid-LOCAL)`,
      };
    }
    return {
      handler: rigid,
      reason: `intent=${intent} conf=${confidence.toFixed(2)} policy=${policy} → ${rigid} (rigid intent)`,
    };
  }

  // 3d. Elastic intents: apply floors, then preference, then safety escalation.
  let handler: Handler;
  if (confidence >= floors.local) handler = ELASTIC_PREFERENCE[policy];
  else if (confidence >= floors.small) handler = "SMALL_MODEL";
  else handler = "FRONTIER";

  // A human demand escalates one tier, but never past FRONTIER.
  if (override === "demandsHuman") {
    handler = handler === "LOCAL" ? "SMALL_MODEL" : "FRONTIER";
  }

  return {
    handler,
    reason: `intent=${intent} conf=${confidence.toFixed(2)} policy=${policy} → ${handler} (elastic intent, ${handler === "FRONTIER" ? "high" : "mid"}-tier handler)`,
  };
}

// ---------------------------------------------------------------------------
// 1.5  Result validation.
// ---------------------------------------------------------------------------
import type { SystemOneResult, Questions } from "@typesafe-ai/sdk";

export class MalformedResultError extends Error {}

export function validateResult<Q extends Questions>(
  result: SystemOneResult<Q>,
  intentKey: keyof Q
): void {
  if (!result || typeof result !== "object") {
    throw new MalformedResultError("result is not an object");
  }
  const answers = (result as { answers?: unknown }).answers;
  if (!answers || typeof answers !== "object") {
    throw new MalformedResultError("answers is missing or not an object");
  }
  const intent = (answers as Record<string, unknown>)[intentKey as string] as
    | { type?: string; choice?: unknown; confidence?: unknown; probabilities?: unknown }
    | undefined;

  // Fields we check, in order:
  //   type         — must be "choice" (guards against a wrong question shape)
  //   choice       — must be a non-empty string
  //   confidence   — must be a finite number in [0, 1]
  //   probabilities— must be a non-empty object
  if (!intent) throw new MalformedResultError(`missing answer for ${String(intentKey)}`);
  if (intent.type !== "choice") throw new MalformedResultError("intent answer is not a Choice");
  if (typeof intent.choice !== "string" || intent.choice.length === 0) {
    throw new MalformedResultError("intent.choice is not a non-empty string");
  }
  if (
    typeof intent.confidence !== "number" ||
    !Number.isFinite(intent.confidence) ||
    intent.confidence < 0 ||
    intent.confidence > 1
  ) {
    throw new MalformedResultError("intent.confidence is not a probability");
  }
  if (
    !intent.probabilities ||
    typeof intent.probabilities !== "object" ||
    Object.keys(intent.probabilities as object).length === 0
  ) {
    throw new MalformedResultError("intent.probabilities is empty");
  }
}

// ---------------------------------------------------------------------------
// 1.4 + 1.5 + 1.6  The gateway.
// ---------------------------------------------------------------------------
const MODEL = "jev-latest";

// Approximate downstream cost/latency for the two generative tiers plus the
// deterministic one. Numbers are per-request averages, tuned to our traffic.
const HANDLER_PROFILE: Record<Handler, { costUsd: number; ms: number }> = {
  LOCAL: { costUsd: 0, ms: 40 },
  SMALL_MODEL: { costUsd: 0.0009, ms: 900 },
  FRONTIER: { costUsd: 0.014, ms: 2800 },
};

export type GatewayLogger = (line: Record<string, unknown>) => void;

export class TwoSpeedGateway {
  private readonly client: TypeSafeClient;
  private readonly logger: GatewayLogger;

  constructor(opts: { client?: TypeSafeClient; logger?: GatewayLogger } = {}) {
    this.client = opts.client ?? new TypeSafeClient();
    this.logger =
      opts.logger ??
      ((line) =>
        // Rule: the log line is assembled from scratch inside this class.
        // The state string is never in scope here, so it cannot leak.
        console.log(JSON.stringify(line)));
  }

  async route(message: string, policy: PolicyName = "balanced"): Promise<RoutingDecision> {
    const requestId = randomUUID();
    const startedAt = performance.now();

    let intent: string;
    let confidence: number;
    let safety: Safety;
    let degraded = false;

    try {
      const response = await this.client.systemOne({
        state: message,
        model: MODEL,
        questions: {
          intent: INTENT_QUESTION,
          safety_n: SAFETY_N,
          safety_legal: SAFETY_LEGAL,
        },
      });

      validateResult(response, "intent");

      intent = response.answers.intent.choice;
      confidence = response.answers.intent.confidence;
      safety = {
        demandsHuman: response.answers.safety_n.noul,
        legalAssertion: response.answers.safety_legal.noul,
      };
    } catch (err) {
      // Fallback: on any failure (network, 429, 422, malformed shape), route
      // to FRONTIER. Justification: the frontier model is the only tier that
      // preserves the current behavior of the system for every intent; a
      // silent downgrade to LOCAL on error would change what the customer
      // gets, which is the one thing the gateway must never do by accident.
      degraded = true;
      intent = "unknown";
      confidence = 0;
      safety = { demandsHuman: 0, legalAssertion: 0 };
      this.logger({
        level: "warn",
        requestId,
        event: "gateway_degraded",
        error: err instanceof Error ? err.message : String(err),
      });
    }

    const gatewayMs = Math.round((performance.now() - startedAt) * 100) / 100;

    const { handler, reason } = degraded
      ? { handler: "FRONTIER" as Handler, reason: "gateway degraded: Jev unavailable" }
      : decide(intent, confidence, safety, policy);

    const profile = HANDLER_PROFILE[handler];

    // 1.6 — structured log. The field list is explicit and contains no
    // field that could hold the raw message. `state` is never passed in.
    this.logger({
      requestId,
      event: "route",
      intent,
      confidence: Number(confidence.toFixed(4)),
      handler,
      reason,
      gatewayMs,
      policy,
      degraded,
    });

    return {
      intent,
      confidence,
      handler,
      reason,
      policy,
      gatewayMs,
      estimatedCostUsd: profile.costUsd,
      estimatedDownstreamMs: profile.ms,
    };
  }
}

// ---------------------------------------------------------------------------
// 1.4 — Handler stub so the gateway can be exercised end-to-end.
// ---------------------------------------------------------------------------
export async function simulateHandler(
  handler: Handler,
  _message: string
): Promise<{ text: string; costUsd: number; ms: number }> {
  const profile = HANDLER_PROFILE[handler];
  await new Promise((r) => setTimeout(r, Math.min(profile.ms, 25))); // don't hang tests
  return {
    text: `[${handler}] simulated answer`,
    costUsd: profile.costUsd,
    ms: profile.ms,
  };
}
