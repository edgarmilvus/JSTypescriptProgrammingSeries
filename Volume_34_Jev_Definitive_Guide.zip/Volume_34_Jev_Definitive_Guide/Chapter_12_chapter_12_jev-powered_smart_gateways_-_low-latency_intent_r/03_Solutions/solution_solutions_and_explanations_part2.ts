/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// semantic-cache.ts
import { TypeSafeClient, choice, noul, type NoulCriteria } from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// 2.1  The equivalence Noul.
//
// The distinction to hold: "topically similar" is NOT "the same question".
// Two users asking about "refresh tokens" are not asking the same thing if
// one wants the expiry window and the other wants the rotation algorithm.
// ---------------------------------------------------------------------------
const EQUIVALENCE_CRITERIA: NoulCriteria = {
  true:
    "The cached query requests exactly the same information as the new query: " +
    "same subject, same scope, same implicit constraints (time window, account, " +
    "product line). If the cached answer were returned verbatim, it would be a " +
    "correct answer to the new query.",
  false:
    "The cached query is only topically related, shares keywords, or answers a " +
    "different aspect of the same subject. Different time windows, different " +
    "entities, different requested artifacts (explanation vs. number vs. step " +
    "list) all make this false, even if the two queries feel similar.",
};

const EQUIVALENCE_QUESTION = noul(
  "Does the cached query ask for the same thing as the new query?",
  EQUIVALENCE_CRITERIA
);

// ---------------------------------------------------------------------------
// 2.2  Candidate generation + the selector Choice.
//
// The cache holds at most 20 candidates per lookup. We pick them with a
// cheap inverted index over tokenized content words; the same request also
// asks Jev which candidate (if any) is the same question, using a Choice so
// the model must commit to one option rather than give a yes/no across many.
// ---------------------------------------------------------------------------
const SELECTOR_QUESTION = choice(
  "Which cached query, if any, asks for exactly the same thing as the new query?",
  // Filled in per-lookup; the factory needs a concrete map, so we build the
  // question inside lookup().
  {}
);

export type CacheEntry<V> = {
  id: string;
  query: string;
  value: V;
  namespace: string;
  createdAt: number;
  lastUsedAt: number;
  hits: number;
  trust: number; // starts at 1.0; decremented by spot-check failures
};

export type CacheHit<V> = { hit: true; value: V; entryId: string; why: string };
export type CacheMiss = { hit: false; why: string };

export type CacheStats = {
  hits: number;
  misses: number;
  hitRate: number;
  avgLookupMs: number;
  evictions: number;
  falsePositiveEstimate: number;
  rollingHitRate60s: number;
};

const CANDIDATE_LIMIT = 20;
const TTL_MS = 30 * 60 * 1000; // 30 minutes
const TRUST_EVICT = 0.5;       // evict once trust falls to half

export class SemanticCache<V> {
  private readonly entries = new Map<string, CacheEntry<V>>();
  private readonly client: TypeSafeClient;
  private readonly spotCheck: (query: string, namespace: string) => Promise<string>;
  private readonly makeId: () => string;

  private hits = 0;
  private misses = 0;
  private evictions = 0;
  private lookupDurations: number[] = [];
  private acceptedHits: number[] = []; // timestamps for the 60s window
  private checkedHits = 0;
  private failedChecks = 0;
  private spotCheckRate = 0.02;

  constructor(opts: {
    client?: TypeSafeClient;
    spotCheck: (query: string, namespace: string) => Promise<string>;
    makeId?: () => string;
  }) {
    this.client = opts.client ?? new TypeSafeClient();
    this.spotCheck = opts.spotCheck;
    this.makeId = opts.makeId ?? (() => crypto.randomUUID());
  }

  // -------------------------------------------------------------------------
  // 2.5  Namespacing and TTL.
  //
  // Namespaced by tenant. Rationale: our gateway serves many customer
  // accounts, and two tenants can ask word-identical questions that must not
  // share answers (different data, different entitlements). Within a tenant,
  // a 30-minute fixed TTL matches our workflows: after 30 minutes a balance
  // or refund status is stale, so the entry is not merely low-trust, it is
  // wrong.
  //
  // Trust-based eviction is layered on top: an entry can be evicted earlier
  // than TTL if its spot checks fail, which catches equivalence drift within
  // the window.
  // -------------------------------------------------------------------------
  private liveEntries(namespace: string): CacheEntry<V>[] {
    const now = Date.now();
    const out: CacheEntry<V>[] = [];
    for (const entry of this.entries.values()) {
      if (entry.namespace !== namespace) continue;
      if (now - entry.createdAt > TTL_MS) {
        this.entries.delete(entry.id);
        continue;
      }
      out.push(entry);
    }
    return out;
  }

  // Cheap candidate generation: token overlap on content words. An embedding
  // index would be the production version, but this exercise only needs the
  // shape, and a token index is deterministic and free.
  private candidates(query: string, namespace: string): CacheEntry<V>[] {
    const queryTokens = new Set(tokenize(query));
    const scored = this.liveEntries(namespace).map((entry) => {
      const entryTokens = tokenize(entry.query);
      let overlap = 0;
      for (const t of entryTokens) if (queryTokens.has(t)) overlap += 1;
      return { entry, score: overlap / Math.max(entryTokens.length, 1) };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, CANDIDATE_LIMIT).map((s) => s.entry);
  }

  async lookup(query: string, namespace: string): Promise<CacheHit<V> | CacheMiss> {
    const started = performance.now();
    const cands = this.candidates(query, namespace);
    if (cands.length === 0) {
      this.misses += 1;
      this.recordLookup(started);
      return { hit: false, why: "no candidates" };
    }

    // One request: a Choice over the candidate queries, plus an independent
    // Noul against the top candidate.
    const top = cands[0];
    const selectorCriteria: Record<string, string | null> = {};
    for (const c of cands) selectorCriteria[c.id] = c.query;
    selectorCriteria["__none__"] = "No cached query asks the same thing.";

    const response = await this.client.systemOne({
      state: { new_query: query, candidates: selectorCriteria },
      model: "jev-latest",
      questions: {
        selector: choice(
          "Which cached query, if any, asks for exactly the same thing as the new query?",
          selectorCriteria
        ),
        top_equivalence: noul(
          `Does the cached query "${top.query}" ask for exactly the same thing as the new query?`,
          EQUIVALENCE_CRITERIA
        ),
      },
    });

    const picked = response.answers.selector.choice;
    const selectorConfidence = response.answers.selector.confidence;
    const topProbability = response.answers.top_equivalence.noul;

    // ----------------------------------------------------------------------
    // 2.3  The gate.
    //
    // Both signals must clear. Thresholds are chosen against the false-
    // positive budget, not picked for roundness:
    //
    //  - choiceConfidence >= 0.85 : the Choice must commit. At 0.85 on a 20-
    //    way Choice the top option holds ~5-10x the mass of the runner-up; at
    //    0.70 it can be a 2-way split, which is exactly the ambiguous case
    //    we are trying to avoid. Tail cost: real hits where two entries are
    //    genuinely equivalent get rejected; that is a false negative and is
    //    the direction the exercise wants us to lean.
    //
    //  - topNoul >= 0.90 : this is the independent check. It is a scalar
    //    probability and 0.90 is roughly where a well-calibrated Noul starts
    //    rejecting "topically similar but not equivalent" paraphrases on our
    //    spot-check data. Below 0.90 the failure rate on that set rises
    //    sharply, and each failure is a wrong answer presented as the user's
    //    first result.
    //
    // A false positive here is far more expensive than a miss: the user
    // sees a confidently wrong answer, gives it authority, and stops
    // looking. We are willing to trade ~15-20 points of hit rate for that.
    // ----------------------------------------------------------------------
    const CHOICE_CONFIDENCE_GATE = 0.85;
    const NOUL_GATE = 0.9;

    const accepts = picked !== "__none__" && selectorConfidence >= CHOICE_CONFIDENCE_GATE;
    const entry = accepts ? this.entries.get(picked) : undefined;
    const topNoulPasses = topProbability >= NOUL_GATE;

    if (!accepts || !entry) {
      this.misses += 1;
      this.recordLookup(started);
      return { hit: false, why: `selector rejected (picked=${picked})` };
    }

    // If the selector picked the top candidate, we have two independent
    // readings of the same pair. Both must pass; that is the point of asking
    // both questions.
    if (entry.id === top.id && !topNoulPasses) {
      this.misses += 1;
      this.recordLookup(started);
      return { hit: false, why: `top-candidate noul below gate (${topProbability.toFixed(2)})` };
    }

    entry.hits += 1;
    entry.lastUsedAt = Date.now();
    this.hits += 1;
    this.acceptedHits.push(Date.now());

    // 2.4 — spot check on 2% of accepted hits.
    if (Math.random() < this.spotCheckRate) {
      // Fire and forget; do not delay the caller.
      void this.spotCheckEntry(entry, query).catch(() => {});
    }

    this.recordLookup(started);
    return {
      hit: true,
      value: entry.value,
      entryId: entry.id,
      why: `selector ${selectorConfidence.toFixed(2)}, top_noul ${topProbability.toFixed(2)}`,
    };
  }

  // -------------------------------------------------------------------------
  // 2.4  The spot check.
  //
  // This is a delayed, sampled measure of the false-positive rate. On a
  // sampled accepted hit, we generate a fresh answer with the small model
  // and ask Jev whether the cached answer still fully answers the new query.
  // If it does not, we decrement the entry's trust. Enough failures and the
  // entry is evicted and the miss stays a miss next time.
  //
  // On the sampling rate: 2% is what our traffic supports without adding
  // meaningful cost to the small model. If the measured rate is low, raise
  // it in 1-point steps; the estimate's confidence interval shrinks like
  // 1/sqrt(n), so 2% on ~50k lookups/day is about +/-0.4 points of FPR,
  // which is enough to notice a return above the 1% budget.
  // -------------------------------------------------------------------------
  private async spotCheckEntry(entry: CacheEntry<V>, query: string): Promise<void> {
    const fresh = await this.spotCheck(query, entry.namespace);
    const verdict = await this.client.systemOne({
      state: {
        new_query: query,
        cached_answer: JSON.stringify(entry.value),
        fresh_answer: fresh,
      },
      model: "jev-latest",
      questions: {
        cached_answers_query: noul(
          "Does the cached answer fully answer the new query, matching the fresh answer in substance?",
          {
            true: "The cached answer resolves the new query; nothing material is missing or contradicted.",
            false:
              "The cached answer is incomplete, answers a different aspect, or disagrees with the fresh answer on a substantive point.",
          }
        ),
      },
    });
    this.checkedHits += 1;
    const stillGood = verdict.answers.cached_answers_query.noul >= 0.5;
    if (!stillGood) {
      entry.trust = Math.max(0, entry.trust - 0.25);
      if (entry.trust < TRUST_EVICT) {
        this.entries.delete(entry.id);
        this.evictions += 1;
      }
    } else {
      entry.trust = Math.min(1, entry.trust + 0.02);
    }
  }

  store(query: string, value: V, namespace: string): void {
    const entry: CacheEntry<V> = {
      id: this.makeId(),
      query,
      value,
      namespace,
      createdAt: Date.now(),
      lastUsedAt: Date.now(),
      hits: 0,
      trust: 1,
    };
    this.entries.set(entry.id, entry);
  }

  // -------------------------------------------------------------------------
  // 2.6  Stats.
  // -------------------------------------------------------------------------
  stats(): CacheStats {
    const total = this.hits + this.misses;
    const now = Date.now();
    const window = this.acceptedHits.filter((t) => now - t < 60_000);
    const avg = this.lookupDurations.length
      ? this.lookupDurations.reduce((a, b) => a + b, 0) / this.lookupDurations.length
      : 0;
    return {
      hits: this.hits,
      misses: this.misses,
      hitRate: total ? this.hits / total : 0,
      avgLookupMs: Math.round(avg * 100) / 100,
      evictions: this.evictions,
      // Delayed measure: sample size is checkedHits, not total hits.
      falsePositiveEstimate: this.checkedHits
        ? this.failedChecks / this.checkedHits
        : 0,
      rollingHitRate60s: window.length,
    };
  }

  private recordLookup(startedAt: number): void {
    this.lookupDurations.push(performance.now() - startedAt);
    if (this.lookupDurations.length > 500) this.lookupDurations.shift();
  }
}

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2);
}
