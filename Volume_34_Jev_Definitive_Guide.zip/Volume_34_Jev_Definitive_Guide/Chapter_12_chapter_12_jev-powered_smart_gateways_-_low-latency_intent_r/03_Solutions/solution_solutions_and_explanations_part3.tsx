/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// gateway-observability-panel.tsx
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type JSX,
} from "react";

// ---------------------------------------------------------------------------
// 3.1  Types.
//
// These are the same field names the RoutingDecision from Exercise 1 uses,
// with two additions the panel needs: `estimatedFrontierCostUsd` (the cost
// the request WOULD have had if routed to FRONTIER) and `requestId` (the
// React key). The `message` field is deliberately absent. See 3.6.
// ---------------------------------------------------------------------------
export type PolicyName = "cost-first" | "balanced" | "quality-first";
export type RoutingHandler = "LOCAL" | "SMALL_MODEL" | "FRONTIER";

export type GatewayEvent = {
  requestId: string;
  intent: string;
  confidence: number;
  handler: RoutingHandler;
  reason: string;
  gatewayMs: number;
  policy: PolicyName;
  estimatedCostUsd: number;
  estimatedFrontierCostUsd: number;
  at: number; // epoch ms, for the 5-minute window
};

export type GatewayStats = {
  totalRequests: number;
  savedUsd: number;
  p50GatewayMs: number;
  p95GatewayMs: number;
  p99GatewayMs: number;
  confidenceBuckets: [number, number, number, number]; // [0-0.5, 0.5-0.7, 0.7-0.9, 0.9-1.0]
};

export type StreamStatus = "connecting" | "open" | "error";

export type UseGatewayStreamResult = {
  status: StreamStatus;
  events: GatewayEvent[];
  stats: GatewayStats;
  lastError: string | null;
};

// The server never sends `message`. This is enforced at the transport layer:
// the SSE endpoint or Server Action serializes only the fields above, and
// the panel's type does not include the field even as an optional. A future
// developer who tries to render a raw message will get a compile error, and
// there is no runtime filter that could accidentally be turned off.
export type PanelProps = {
  hook?: () => UseGatewayStreamResult;
  onKillSwitch: (durationMinutes: number) => Promise<void>;
};

// ---------------------------------------------------------------------------
// 3.2  The stream hook.
//
// The interface is fixed here; the implementation is stubbed with mock data.
// The signature is what makes the panel testable: the panel takes the hook
// as a prop and defaults it to the real one.
// ---------------------------------------------------------------------------
export function useGatewayStream(): UseGatewayStreamResult {
  const [status, setStatus] = useState<StreamStatus>("connecting");
  const [events, setEvents] = useState<GatewayEvent[]>([]);
  const [lastError, setLastError] = useState<string | null>(null);

  useEffect(() => {
    const source = new EventSource("/api/gateway/stream");
    source.onopen = () => setStatus("open");
    source.onerror = (e) => {
      setStatus("error");
      setLastError((e as unknown as { message?: string }).message ?? "stream error");
      // Keep the last events; the panel renders them under the error banner.
    };
    source.onmessage = (msg) => {
      const next = JSON.parse(msg.data) as GatewayEvent;
      // 3.6 — batching story: on the server side, the endpoint coalesces at
      // 100ms. Here we cap and dedupe defensively. If 500 events arrive in
      // one second, the setState call below still fires 500 times, so the
      // production version wraps this in a scheduler that batches on
      // requestAnimationFrame and flushes at most once per frame.
      setEvents((prev) => [next, ...prev].slice(0, 50));
    };
    return () => source.close();
  }, []);

  return { status, events, stats: computeStats(events), lastError };
}

// ---------------------------------------------------------------------------
// 3.4  Percentiles.
//
// We use linear interpolation between adjacent order statistics (the R-7
// method, which is what NumPy and most stats libraries default to). The
// naive "sort and index" method returns a data point that was actually
// observed; interpolation returns a value between two observations, which
// is closer to what a percentile means for a small sample.
//
// This distinction matters at n=50. For a p99 with 50 points, sorted
// indexing picks element index 49 (the max), while interpolation picks a
// value very close to the max but not equal to it. Neither is "right", but
// interpolated percentiles are stable as n changes, which matters because
// the panel's window is a rolling 50 that keeps shifting as events arrive.
// ---------------------------------------------------------------------------
export function percentiles(values: number[], ps: number[]): number[] {
  if (values.length === 0) return ps.map(() => 0);
  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;
  return ps.map((p) => {
    if (n === 1) return sorted[0];
    const rank = (p / 100) * (n - 1);
    const lo = Math.floor(rank);
    const hi = Math.ceil(rank);
    if (lo === hi) return sorted[lo];
    const frac = rank - lo;
    return sorted[lo] * (1 - frac) + sorted[hi] * frac;
  });
}

function computeStats(events: GatewayEvent[]): GatewayStats {
  const now = Date.now();
  const window = events.filter((e) => now - e.at <= 5 * 60 * 1000);
  const [p50, p95, p99] = percentiles(
    window.map((e) => e.gatewayMs),
    [50, 95, 99]
  );
  const buckets: [number, number, number, number] = [0, 0, 0, 0];
  for (const e of window) {
    if (e.confidence < 0.5) buckets[0] += 1;
    else if (e.confidence < 0.7) buckets[1] += 1;
    else if (e.confidence < 0.9) buckets[2] += 1;
    else buckets[3] += 1;
  }
  const savedUsd = events.reduce(
    (acc, e) => acc + (e.estimatedFrontierCostUsd - e.estimatedCostUsd),
    0
  );
  return {
    totalRequests: events.length,
    savedUsd,
    p50GatewayMs: Math.round(p50 * 100) / 100,
    p95GatewayMs: Math.round(p95 * 100) / 100,
    p99GatewayMs: Math.round(p99 * 100) / 100,
    confidenceBuckets: buckets,
  };
}

// ---------------------------------------------------------------------------
// 3.3 + 3.5 + 3.6  The component.
// ---------------------------------------------------------------------------
const HANDLER_COLOR: Record<RoutingHandler, string> = {
  LOCAL: "#1a7f37",
  SMALL_MODEL: "#8a6d00",
  FRONTIER: "#8b1a1a",
};

export function GatewayObservabilityPanel({
  hook = useGatewayStream,
  onKillSwitch,
}: PanelProps): JSX.Element {
  const { status, events, stats, lastError } = hook();

  // Kill-switch countdown. Held in state so a re-render shows the current
  // second, and the target time in a ref so a re-render does not reset it.
  const killTargetRef = useRef<number | null>(null);
  const [remainingSec, setRemainingSec] = useState(0);
  const [killBusy, setKillBusy] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => {
      const target = killTargetRef.current;
      if (target === null) return;
      const left = Math.max(0, Math.ceil((target - Date.now()) / 1000));
      setRemainingSec(left);
      if (left === 0) killTargetRef.current = null;
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const savedUsd = stats.savedUsd;
  const savedIsNegative = savedUsd < 0;

  return (
    <div
      style={{
        fontFamily: "ui-monospace, Menlo, monospace",
        padding: 16,
        background: "#0f1115",
        color: "#e6e6e6",
        minHeight: "100vh",
      }}
      data-status={status}
    >
      {/* Status banner — always visible, changes color by state. */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "1px solid #2a2f3a",
          paddingBottom: 8,
          marginBottom: 16,
        }}
      >
        <span
          style={{
            padding: "4px 10px",
            borderRadius: 4,
            background:
              status === "open"
                ? "#1a7f37"
                : status === "connecting"
                ? "#4a5c8a"
                : "#8b1a1a",
            color: "white",
            fontWeight: 600,
          }}
        >
          {status.toUpperCase()}
        </span>
        <div
          style={{
            fontSize: 28,
            fontWeight: 700,
            color: savedIsNegative ? "#ff5a5a" : "#7ee787",
          }}
          title="Saved vs. always-frontier baseline, since page opened"
        >
          {savedIsNegative ? "-" : "+"}${Math.abs(savedUsd).toFixed(2)}
          <span style={{ fontSize: 12, marginLeft: 8, opacity: 0.7 }}>
            saved vs. always-frontier
          </span>
        </div>
      </div>

      {status === "error" && (
        <div
          style={{
            background: "#3a0f14",
            border: "1px solid #8b1a1a",
            color: "#ffb4b4",
            padding: "8px 12px",
            marginBottom: 16,
            borderRadius: 4,
          }}
          role="alert"
        >
          Stream error: {lastError ?? "unknown"} — showing last known metrics.
        </div>
      )}

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 16,
        }}
      >
        {/* Latency percentiles (gateway only). */}
        <section aria-label="Gateway latency">
          <h3 style={{ margin: "0 0 8px 0", fontSize: 12, letterSpacing: 1 }}>
            GATEWAY LATENCY (last 5m)
          </h3>
          <LatencyBar label="p50" value={stats.p50GatewayMs} />
          <LatencyBar label="p95" value={stats.p95GatewayMs} />
          <LatencyBar label="p99" value={stats.p99GatewayMs} />
          <p style={{ fontSize: 11, opacity: 0.6 }}>
            Window is n≤50 events; the p99 in particular is noisy on this
            sample size. Treat movements under ~15ms as noise.
          </p>
        </section>

        {/* Confidence histogram. */}
        <section aria-label="Confidence distribution">
          <h3 style={{ margin: "0 0 8px 0", fontSize: 12, letterSpacing: 1 }}>
            CONFIDENCE DISTRIBUTION
          </h3>
          <ConfidenceHistogram buckets={stats.confidenceBuckets} />
        </section>
      </div>

      {/* Event list. */}
      <section aria-label="Recent routing decisions" style={{ marginTop: 16 }}>
        <h3 style={{ margin: "0 0 8px 0", fontSize: 12, letterSpacing: 1 }}>
          RECENT DECISIONS
        </h3>
        <div
          style={{
            maxHeight: 320,
            overflowY: "auto",
            border: "1px solid #2a2f3a",
            borderRadius: 4,
          }}
        >
          {events.map((e) => (
            <div
              key={e.requestId}
              style={{
                display: "grid",
                gridTemplateColumns: "160px 120px 100px 90px",
                gap: 8,
                padding: "6px 10px",
                borderBottom: "1px solid #1a1d23",
                fontSize: 12,
              }}
            >
              <span>{e.intent}</span>
              <span style={{ opacity: 0.7 }}>
                conf {e.confidence.toFixed(2)}
              </span>
              <span style={{ color: HANDLER_COLOR[e.handler], fontWeight: 700 }}>
                {e.handler}
              </span>
              <span style={{ opacity: 0.7 }}>{e.gatewayMs}ms</span>
            </div>
          ))}
          {events.length === 0 && (
            <div style={{ padding: 12, opacity: 0.5, fontSize: 12 }}>
              waiting for events…
            </div>
          )}
        </div>
      </section>

      {/* Kill switch. Big, red, unmistakable. */}
      <button
        onClick={async () => {
          if (killBusy) return;
          setKillBusy(true);
          try {
            await onKillSwitch(15);
            killTargetRef.current = Date.now() + 15 * 60 * 1000;
            setRemainingSec(15 * 60);
          } finally {
            setKillBusy(false);
          }
        }}
        disabled={killBusy && remainingSec === 0}
        aria-label={
          remainingSec > 0
            ? `Quality-first policy active, ${remainingSec} seconds remaining`
            : "Send all traffic to the frontier model for 15 minutes"
        }
        style={{
          marginTop: 24,
          width: "100%",
          padding: "24px 16px",
          fontSize: 22,
          fontWeight: 800,
          letterSpacing: 2,
          background: remainingSec > 0 ? "#3a0f14" : "#b71c1c",
          color: "white",
          border: "2px solid #ff5a5a",
          borderRadius: 8,
          cursor: "pointer",
        }}
      >
        {remainingSec > 0
          ? `QUALITY-FIRST ACTIVE — ${formatCountdown(remainingSec)}`
          : "KILL SWITCH: send everything to FRONTIER for 15 min"}
      </button>
    </div>
  );
}

function LatencyBar({ label, value }: { label: string; value: number }): JSX.Element {
  const width = Math.min(100, (value / 300) * 100); // 300ms = full bar
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
      <span style={{ width: 32, opacity: 0.7, fontSize: 12 }}>{label}</span>
      <div style={{ flex: 1, height: 10, background: "#1a1d23", borderRadius: 3 }}>
        <div
          style={{
            width: `${width}%`,
            height: "100%",
            background: "#4a9eff",
            borderRadius: 3,
          }}
        />
      </div>
      <span style={{ width: 64, textAlign: "right", fontSize: 12 }}>
        {value.toFixed(1)}ms
      </span>
    </div>
  );
}

function ConfidenceHistogram({
  buckets,
}: {
  buckets: [number, number, number, number];
}): JSX.Element {
  const labels = ["0-.5", ".5-.7", ".7-.9", ".9-1"];
  const total = buckets.reduce((a, b) => a + b, 0) || 1;
  const max = Math.max(...buckets, 1);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 100 }}>
      {buckets.map((count, i) => (
        <div key={labels[i]} style={{ flex: 1, textAlign: "center" }}>
          <div
            style={{
              height: `${(count / max) * 72}px`,
              background: i === 0 ? "#8b1a1a" : "#4a9eff",
              borderRadius: "3px 3px 0 0",
            }}
          />
          <div style={{ fontSize: 11, opacity: 0.7, marginTop: 4 }}>
            {labels[i]}
          </div>
          <div style={{ fontSize: 11 }}>
            {((count / total) * 100).toFixed(0)}%
          </div>
        </div>
      ))}
    </div>
  );
}

function formatCountdown(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}
