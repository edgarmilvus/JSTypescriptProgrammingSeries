/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// guardrails.ts
import {
  TypeSafeClient,
  noul,
  type NoulQuestion,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// 4.1  The hazard spec.
// ---------------------------------------------------------------------------
export type HazardAction = "allow" | "scrub" | "review" | "block" | "support";

export type HazardSpec = {
  id: string;
  question: NoulQuestion;
  action: HazardAction;
  weight: number;      // contribution to the weighted risk score
  hardBlock?: number;  // absolute threshold; overrides weight entirely
  reviewOnly?: number; // threshold above which the verdict escalates to review
};

export type GuardrailVerdict = {
  verdict: HazardAction;
  triggered: Array<{ id: string; probability: number; action: HazardAction }>;
  weightedRisk: number;
};

// Precedence for hard blocks and for the final verdict selection. Written
// down separately from the code so a reviewer can argue with the order
// without reading the loop. `support` first because blocking a user in
// crisis is the worst outcome.
export const ACTION_PRECEDENCE: HazardAction[] = [
  "support",
  "block",
  "review",
  "scrub",
  "allow",
];

const supportHazard = (id: string): HazardSpec => ({
  id,
  action: "support",
  weight: 0,
  hardBlock: 0.75,
  reviewOnly: 0.4,
  question: noul(
    "Does this content suggest the user may be in crisis or considering harm to themselves?",
    {
      true: "Signals self-harm intent, or an acute personal crisis that needs human support.",
      false: "No such signal.",
    }
  ),
});

// ---------------------------------------------------------------------------
// 4.1  The namespace map. Three namespaces, four-plus hazards each, each with
// at least one hard block and at least one soft signal.
// ---------------------------------------------------------------------------
export const NAMESPACE_GUARDRAILS: Record<string, HazardSpec[]> = {
  support: [
    {
      id: "credential_theft",
      action: "block",
      weight: 0,
      hardBlock: 0.8,
      reviewOnly: 0.4,
      question: noul(
        "Is the user trying to obtain another account's credentials, or to defeat authentication?",
        {
          true: "Requests credentials, session tokens, or a way past authentication.",
          false: "No such request.",
        }
      ),
    },
    {
      id: "prompt_injection",
      action: "block",
      weight: 0,
      hardBlock: 0.85,
      reviewOnly: 0.4,
      question: noul(
        "Does the message attempt to control the assistant rather than request something from it?",
        {
          true: "Contains instructions to override, reveal, or bypass the system's rules.",
          false: "It is an ordinary support request.",
        }
      ),
    },
    {
      id: "refund_fraud",
      action: "review",
      weight: 1.0,
      reviewOnly: 0.6,
      question: noul(
        "Does the refund request show indicators of fraud: improbable history, repeated refunds, third-party accounts?",
        { true: "Fraud indicators present.", false: "Looks like a normal refund." }
      ),
    },
    supportHazard("self_harm"),
  ],

  code: [
    {
      id: "malware_assistance",
      action: "block",
      weight: 0,
      hardBlock: 0.8,
      reviewOnly: 0.4,
      question: noul(
        "Is the request asking for help building, deploying, or evading detection for malware?",
        {
          true: "Requests code or instructions whose primary use is malicious.",
          false: "Legitimate software work, even if security-adjacent.",
        }
      ),
    },
    {
      id: "jailbreak",
      action: "block",
      weight: 0,
      hardBlock: 0.85,
      reviewOnly: 0.4,
      question: noul(
        "Is the user trying to lift or bypass the assistant's operating constraints?",
        { true: "Attempts to make the assistant ignore its rules.", false: "No such attempt." }
      ),
    },
    {
      id: "credential_leak_in_paste",
      action: "scrub",
      weight: 0.8,
      reviewOnly: 0.5,
      question: noul(
        "Does the pasted code contain live secrets, tokens, or private keys?",
        { true: "Contains credentials or keys.", false: "No secrets visible." }
      ),
    },
    {
      id: "license_violation",
      action: "review",
      weight: 0.6,
      reviewOnly: 0.7,
      question: noul(
        "Is the request to reproduce or deobfuscate code under a restrictive license?",
        { true: "Would reproduce licensed code.", false: "No license concern." }
      ),
    },
  ],

  docs: [
    {
      id: "pii_extraction",
      action: "scrub",
      weight: 0,
      hardBlock: 0.8,
      reviewOnly: 0.5,
      question: noul(
        "Is the user asking the assistant to extract personal data about named individuals?",
        {
          true: "Requests names, addresses, or identifiers of specific people.",
          false: "No such extraction requested.",
        }
      ),
    },
    {
      id: "legal_advice",
      action: "review",
      weight: 1.0,
      reviewOnly: 0.6,
      question: noul(
        "Does answering this question require legal interpretation the assistant should not give?",
        { true: "Legal advice required.", false: "Ordinary documentation question." }
      ),
    },
    {
      id: "financial_advice",
      action: "review",
      weight: 0.8,
      reviewOnly: 0.65,
      question: noul(
        "Does answering require recommending a specific financial or investment action?",
        { true: "Specific recommendation requested.", false: "General explanation." }
      ),
    },
    {
      id: "confidential_leak",
      action: "block",
      weight: 0,
      hardBlock: 0.85,
      reviewOnly: 0.4,
      question: noul(
        "Does answering require stating confidential information the user is not entitled to?",
        { true: "Reply would include restricted content.", false: "Public content only." }
      ),
    },
  ],
};

// ---------------------------------------------------------------------------
// 4.2  The reduction.
// ---------------------------------------------------------------------------
export type GuardrailPolicy = {
  name: string;
  thresholds: Partial<Record<string, number>>; // per-hazard reviewOnly override
  weightedRiskCeiling: number;                 // weighted score at which we escalate
};

export const POLICIES: Record<string, GuardrailPolicy> = {
  strict: { name: "strict", thresholds: {}, weightedRiskCeiling: 0.8 },
  balanced: { name: "balanced", thresholds: {}, weightedRiskCeiling: 1.4 },
  permissive: { name: "permissive", thresholds: {}, weightedRiskCeiling: 2.0 },
};

export function evaluate(
  answers: Record<string, number>,
  spec: HazardSpec[],
  policy: GuardrailPolicy
): GuardrailVerdict {
  const triggered: GuardrailVerdict["triggered"] = [];

  // Hard blocks first, in ACTION_PRECEDENCE order.
  const hardBlocks = spec.filter((h) => h.hardBlock !== undefined);
  for (const action of ACTION_PRECEDENCE) {
    const hit = hardBlocks.find(
      (h) => h.action === action && (answers[h.id] ?? 0) >= (h.hardBlock as number)
    );
    if (hit) {
      triggered.push({
        id: hit.id,
        probability: answers[hit.id] ?? 0,
        action: hit.action,
      });
      return { verdict: hit.action, triggered, weightedRisk: Infinity };
    }
  }

  // Weighted risk from the soft signals.
  let weightedRisk = 0;
  for (const hazard of spec) {
    if (hazard.hardBlock !== undefined) continue;
    const p = answers[hazard.id] ?? 0;
    weightedRisk += hazard.weight * p;
  }

  // Review-only escalation: the highest-precedence soft action whose per-
  // hazard threshold was crossed.
  const softHits: HazardSpec[] = [];
  for (const hazard of spec) {
    if (hazard.hardBlock !== undefined) continue;
    const threshold = policy.thresholds[hazard.id] ?? hazard.reviewOnly;
    if (threshold === undefined) continue;
    if ((answers[hazard.id] ?? 0) >= threshold) softHits.push(hazard);
  }
  for (const hazard of softHits) {
    triggered.push({
      id: hazard.id,
      probability: answers[hazard.id] ?? 0,
      action: hazard.action,
    });
  }

  const softVerdict: HazardAction =
    softHits.length === 0
      ? "allow"
      : [...softHits]
          .sort(
            (a, b) =>
              ACTION_PRECEDENCE.indexOf(a.action) -
              ACTION_PRECEDENCE.indexOf(b.action)
          )[0].action;

  // The aggregate weighted score can lift a soft verdict one step. It never
  // produces a hard block on its own.
  const escalated: HazardAction =
    weightedRisk >= policy.weightedRiskCeiling && softVerdict === "allow"
      ? "review"
      : softVerdict;

  return { verdict: escalated, triggered, weightedRisk };
}

// ---------------------------------------------------------------------------
// 4.3  The single Jev request.
// ---------------------------------------------------------------------------
const client = new TypeSafeClient();

export type GuardrailEvent = {
  requestId: string;
  namespace: string;
  policy: string;
  // Raw probabilities per hazard, so replay() can re-derive a verdict under
  // a different policy without re-calling Jev.
  probabilities: Record<string, number>;
  at: number;
};

export async function guardedEvaluate(
  message: string,
  namespace: string,
  policyName: keyof typeof POLICIES = "balanced"
): Promise<{ verdict: GuardrailVerdict; event: GuardrailEvent; scrubbed?: string }> {
  const spec = NAMESPACE_GUARDRAILS[namespace];
  if (!spec) {
    // Fail closed. Rationale: a namespace with no declared hazards is a
    // deployment bug, and the safe default for an unconfigured guardrail is
    // to route every request to review rather than to admit it untested.
    return {
      verdict: { verdict: "review", triggered: [], weightedRisk: 0 },
      event: {
        requestId: crypto.randomUUID(),
        namespace,
        policy: policyName,
        probabilities: {},
        at: Date.now(),
      },
    };
  }

  const questions: Record<string, NoulQuestion> = {};
  for (const hazard of spec) questions[hazard.id] = hazard.question;

  const response = await client.systemOne({
    state: message,
    model: "jev-latest",
    questions,
  });

  const probabilities: Record<string, number> = {};
  for (const hazard of spec) {
    const answer = response.answers[hazard.id];
    probabilities[hazard.id] = answer?.noul ?? 0; // missing → 0 (documented below)
  }

  const verdict = evaluate(probabilities, spec, POLICIES[policyName]);
  const event: GuardrailEvent = {
    requestId: crypto.randomUUID(),
    namespace,
    policy: policyName,
    probabilities,
    at: Date.now(),
  };

  if (verdict.verdict === "scrub") {
    return { verdict, event, scrubbed: scrub(message) };
  }
  return { verdict, event };
}

// ---------------------------------------------------------------------------
// 4.4  Scrub.
//
// Scrub earns its own action because "harmful" and "sensitive" are different
// categories. A user pasting a stack trace with their own API key in it is
// not a hazard — they need help with the trace, and the key is incidental.
// Blocking them kills the session for something that costs one regex pass to
// remove. Scrubbing the PII out and proceeding is a strictly better product
// outcome, and it is only possible because the guardrail is a set of narrow
// Nouls rather than a single "is this bad" classifier.
// ---------------------------------------------------------------------------
const SCRUB_PATTERNS: RegExp[] = [
  /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,                 // email
  /\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g,             // US phone
  /\b(?:\d[ -]?){13,16}\b/g,                                              // card-ish
  /\b(?:sk|pk|ghp|gho)_[A-Za-z0-9]{16,}\b/g,                              // common key shapes
];

export function scrub(text: string): string {
  let out = text;
  for (const pattern of SCRUB_PATTERNS) out = out.replace(pattern, "[REDACTED]");
  return out;
}

// ---------------------------------------------------------------------------
// 4.5  Replay.
// ---------------------------------------------------------------------------
export function replay(
  events: GuardrailEvent[],
  policyName: keyof typeof POLICIES
): GuardrailVerdict[] {
  const policy = POLICIES[policyName];
  return events.map((e) =>
    evaluate(e.probabilities, NAMESPACE_GUARDRAILS[e.namespace] ?? [], policy)
  );
}

// ---------------------------------------------------------------------------
// 4.6  Composing with the intent call from Exercise 1.
//
// Both question maps go in a single request; the answer split is a plain
// property read because the request and response are keyed by the same ids.
// The intent question is namespaced under "__intent::" so it cannot collide
// with a hazard id.
// ---------------------------------------------------------------------------
export function composeIntentsAndGuardrails<
  T extends Record<string, NoulQuestion>,
>(intentQuestion: import("@typesafe-ai/sdk").ChoiceQuestion, hazards: T): {
  questions: { intent: unknown } & T;
} {
  return { questions: { intent: intentQuestion, ...hazards } } as never;
}
