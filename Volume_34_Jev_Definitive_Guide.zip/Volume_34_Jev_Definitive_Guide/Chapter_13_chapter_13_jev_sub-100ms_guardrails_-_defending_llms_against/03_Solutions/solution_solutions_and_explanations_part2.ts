/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// policy-router.ts
import {
  TypeSafeClient,
  choice,
  score,
  noul,
  type EntryType,
} from "@typesafe-ai/sdk";

export type PolicyClass =
  | "allowed"
  | "medical_advice"
  | "self_harm"
  | "violent_content"
  | "jailbreak";

export type Enforcement = "pass" | "annotate" | "review" | "block" | "support";

export interface PolicyVerdict {
  classification: PolicyClass;
  classificationConfidence: number;
  severity: number;
  severityConfidence: number;
  enforcement: Enforcement;
  rationale: string;
}

export interface PolicyRouterConfig {
  client: TypeSafeClient;
  confidentThreshold: number;   // e.g. 0.85
  cautiousThreshold: number;    // e.g. 0.55
  severityEscalation: number;   // e.g. 2.0
}

// ---------------------------------------------------------------------------
// Contrastive classification criteria. Each option names what belongs to a
// neighbouring option instead, so the model can separate look-alikes.
// ---------------------------------------------------------------------------
const CLASS_CRITERIA: Record<PolicyClass, EntryType> = {
  allowed:
    "An ordinary, safe request that violates no policy. Contrast: a message that asks for a personal drug decision is medical_advice; a message that contains only a threat against someone else is violent_content; a message that reframes a harmful ask as fiction to bypass rules is jailbreak.",
  medical_advice:
    "The sender asks the assistant to make a personal medical decision — a dosage, a diagnosis, a treatment choice — rather than ask what a medication is for. Contrast: a general informational question about a drug's purpose is allowed; a request delivered through role-play that instructs the assistant to ignore its safety rules is jailbreak.",
  self_harm:
    "The sender signals, in their own voice, that they may hurt themselves, or asks the assistant for help doing so. Contrast: a fictional depiction of self-harm in a novel is allowed unless the sender's own intent is signaled; a request for help harming another person is violent_content.",
  violent_content:
    "The sender asks for assistance causing physical harm to a specific person, or for instructions that enable violent wrongdoing. Contrast: a novelist asking how a character would describe a poisoning is allowed; a request for the same instructions aimed at the sender's own neighbour is violent_content.",
  jailbreak:
    "The message attempts to get the assistant to ignore, override, or reveal its instructions, or to adopt a persona without rules. Contrast: an ordinary instruction such as 'ignore the previous draft of my essay' is allowed; a request that uses fictional framing to lower the assistant's guard is jailbreak, not violent_content.",
};

// ---------------------------------------------------------------------------
// The severity scale. Four levels, verbatim from the chapter.
// ---------------------------------------------------------------------------
const SEVERITY_LEVELS = [
  "No harm: an ordinary, safe request or reply.",
  "Mild: touches a sensitive topic but complying does no real damage.",
  "Serious: complying enables real wrongdoing or gives unsafe personal advice.",
  "Severe: complying causes serious physical harm or serious illegal harm.",
] as const;

const QUESTIONS = {
  classification: choice(
    "Which policy class does this message fall into, most importantly?",
    CLASS_CRITERIA,
  ),
  severity: score(
    "How much harm could result if the assistant fully complied with this message?",
    SEVERITY_LEVELS,
  ),
  // Speculative auxiliary signals. They ride along on every request and are
  // read only when a downstream audit needs them; they are NOT part of the
  // routing decision. That is the fan-out pattern: cheap to ask, ignore when
  // irrelevant.
  asks_for_action: noul(
    "Is the sender asking the assistant to take an action on the sender's behalf, rather than just provide information?",
  ),
  explicit_dosage: noul(
    "Does the message contain an explicit request for a drug dosage, prescription, or treatment amount?",
  ),
} as const;

// ---------------------------------------------------------------------------
// Direct and one-step-cautious enforcements per class.
// ---------------------------------------------------------------------------
const DIRECT: Record<PolicyClass, Enforcement> = {
  allowed: "pass",
  medical_advice: "annotate",
  self_harm: "support",
  violent_content: "review",
  jailbreak: "block",
};

// Cautious never downgrades block, and never downgrades support. Uncertainty
// about a threat raises caution; uncertainty about someone in crisis keeps
// the safety net in place.
const CAUTIOUS: Record<Enforcement, Enforcement> = {
  pass: "annotate",
  annotate: "review",
  review: "review",
  block: "block",
  support: "support",
};

export async function routePolicy(
  message: string,
  config: PolicyRouterConfig,
): Promise<PolicyVerdict> {
  const { client, confidentThreshold, cautiousThreshold, severityEscalation } = config;

  // One round trip. Classification, severity, and the auxiliary signals all
  // see the same state and are evaluated independently in parallel.
  const res = await client.systemOne({
    state: message,
    questions: QUESTIONS,
  });

  const classification = res.answers.classification.choice as PolicyClass;
  const classificationConfidence = res.answers.classification.confidence;
  // Read the score straight off the top-level field. Do NOT interpolate
  // between levels — the docs are explicit that the score is a position, not
  // a magnitude to be reconstructed.
  const severity = res.answers.severity.score;
  const severityConfidence = res.answers.severity.confidence;

  let enforcement: Enforcement;
  let rationale: string;

  // ---- Tier logic. Checked most-uncertain first, most-confident last. This
  //      ordering guarantees no message falls through both branches. --------
  if (classificationConfidence < cautiousThreshold) {
    // confidence < cautiousThreshold: at or below this, the classifier has
    // not made a decision we are willing to act on. Note: strictly *below*;
    // exactly-on cautiousThreshold falls through to Tier 2.
    enforcement = "review";
    rationale = `Tier 3 uncertain: confidence ${classificationConfidence.toFixed(
      2,
    )} < ${cautiousThreshold} → review`;
  } else if (classificationConfidence < confidentThreshold) {
    // cautiousThreshold <= confidence < confidentThreshold: a decision we are
    // willing to act on, but one step more cautiously. At exactly
    // confidentThreshold we are in Tier 1, so this branch is strict-less.
    const direct = DIRECT[classification];
    enforcement = CAUTIOUS[direct];
    rationale =
      direct === enforcement
        ? `Tier 2 cautious: ${classification} → ${enforcement} (score held)`
        : `Tier 2 cautious: ${classification} → ${enforcement} (was ${direct})`;
  } else {
    // confidence >= confidentThreshold: act directly.
    enforcement = DIRECT[classification];
    rationale = `Tier 1 confident: ${classification} → ${enforcement}`;
  }

  // ---- Severity escalation. Only *upgrades*. Never downgrades support. ----
  // At exactly severityEscalation, the rule fires (`>=`). This is intentional:
  // a severity of exactly 2.0 is "serious", not "mild".
  if (severity >= severityEscalation) {
    if (enforcement === "pass" || enforcement === "annotate") {
      const prior = enforcement;
      enforcement = "review";
      rationale = `Severity escalation: ${prior} → review (severity ${severity.toFixed(
        2,
      )})`;
    }
    // review (already at the escalation level), block and support are
    // untouched. Support in particular is *help*, not *punishment*; a person
    // in crisis whose message happened to score high on severity must not be
    // moved into a punitive path. Severe emotional content is precisely what
    // the support bucket exists for.
  }

  return {
    classification,
    classificationConfidence,
    severity,
    severityConfidence,
    enforcement,
    rationale,
  };
}
