/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// streaming-guard.ts
import { TypeSafeClient, noul, choice } from "@typesafe-ai/sdk";

export interface StreamingGuardOptions {
  client: TypeSafeClient;
  chunkMinChars: number;
  violationAbove: number;
  checkTimeoutMs: number;
  onViolation?: (info: { chunk: string; probability: number; reason: string }) => void;
}

export interface StreamingGuardResult {
  delivered: string;
  aborted: boolean;
  abortReason?: string;
  unverifiedChunks: number;
}

const REPLACEMENT =
  "\n\n[Response withheld due to a policy concern. A human will review the request.]\n\n";

const SENTENCE_END = /[.!?\n]/;

const QUESTIONS = {
  // Three independent hazards per chunk. The Choice collapses them into a
  // single reason label for the abort message.
  broke_policy: noul(
    "Does this passage comply with a request the assistant should have refused?",
  ),
  gives_medical_decision: noul(
    "Does this passage give a specific drug dosage, a diagnosis, or a treatment decision beyond general health information?",
  ),
  encourages_self_harm: noul(
    "Does this passage encourage or assist the reader in harming themselves?",
  ),
  hazard_label: choice("Which hazard, if any, does this passage exhibit most clearly?", {
    none: "The passage does not exhibit any of the listed hazards.",
    policy_bypass:
      "It goes along with a request that should have been refused, such as role-playing as an AI with no rules.",
    medical: "It makes a personal medical decision for the reader.",
    self_harm: "It encourages or assists self-harm.",
  }),
} as const;

type ChunkCheck =
  | { outcome: "ok" }
  | { outcome: "timeout" }
  | { outcome: "violation"; probability: number; reason: string };

async function checkChunk(client: TypeSafeClient, chunk: string): Promise<ChunkCheck> {
  const res = await client.systemOne({ state: chunk, questions: QUESTIONS });
  const p = Math.max(
    res.answers.broke_policy.noul,
    res.answers.gives_medical_decision.noul,
    res.answers.encourages_self_harm.noul,
  );
  if (p <= 0) return { outcome: "ok" };
  return {
    outcome: "violation",
    probability: p,
    reason: res.answers.hazard_label.choice,
  };
}

function truncate(s: string, n: number): string {
  const flat = s.replace(/\s+/g, " ").trim();
  return flat.length <= n ? flat : flat.slice(0, n - 1) + "…";
}

/**
 * Buffers tokens into sentence-bounded chunks and enforces on each one.
 *
 * Pipelining model: when chunk N is flushed to the caller, its check is
 * *started* but not awaited. Before chunk N+1 is yielded, we await N's check
 * (with checkTimeoutMs budget). Thus each chunk's check overlaps with the
 * caller's reading time of the chunk *before* it, and added wall-clock
 * latency is bounded by one check, not by N checks.
 */
export async function* guardedStream(
  source: AsyncIterable<string>,
  options: StreamingGuardOptions,
): AsyncGenerator<string, StreamingGuardResult, void> {
  const { client, chunkMinChars, violationAbove, checkTimeoutMs, onViolation } = options;

  const deliveredParts: string[] = [];
  let aborted = false;
  let abortReason: string | undefined;
  let unverifiedChunks = 0;

  let buffer = "";
  // The check for the previously flushed chunk, if any is in flight.
  let pendingCheck: { promise: Promise<ChunkCheck>; chunk: string } | null = null;

  /**
   * Await the previous chunk's check. Returns "ok" or "abort". Called before
   * every yield of a *new* chunk, and once at the end.
   */
  const settlePrior = async (): Promise<"ok" | "abort"> => {
    if (pendingCheck === null) return "ok";
    const { promise, chunk } = pendingCheck;
    pendingCheck = null;

    // Timeout is a race, not a cancellation of the underlying call. The SDK's
    // request continues in the background; we stop waiting on it. This is
    // the fail-open path — see the comment block marking where verifyChunk
    // chose it.
    let result: ChunkCheck;
    try {
      result = await Promise.race([
        promise,
        new Promise<ChunkCheck>((resolve) =>
          setTimeout(() => resolve({ outcome: "timeout" }), checkTimeoutMs),
        ),
      ]);
    } catch {
      // A network/parse error is treated identically to a timeout: fail open
      // for this chunk, but count it.
      result = { outcome: "timeout" };
    }

    if (result.outcome === "violation" && result.probability > violationAbove) {
      aborted = true;
      abortReason = `chunk "${truncate(chunk, 80)}" flagged at p=${result.probability.toFixed(
        2,
      )} as ${result.reason}`;
      onViolation?.({
        chunk,
        probability: result.probability,
        reason: result.reason,
      });
      return "abort";
    }
    if (result.outcome === "timeout") unverifiedChunks++;
    return "ok";
  };

  // Extract the first complete sentence-bounded chunk from the buffer if one
  // exists at or beyond the minimum size. Returns null if the buffer does not
  // yet contain a chunk boundary past chunkMinChars.
  const takeChunk = (): string | null => {
    if (buffer.length < chunkMinChars) return null;
    // Scan from chunkMinChars onward for the first sentence boundary.
    for (let i = chunkMinChars - 1; i < buffer.length; i++) {
      if (SENTENCE_END.test(buffer[i])) {
        const chunk = buffer.slice(0, i + 1);
        buffer = buffer.slice(i + 1);
        return chunk;
      }
    }
    return null;
  };

  for await (const token of source) {
    buffer += token;
    let chunk: string | null;
    while ((chunk = takeChunk()) !== null) {
      // Before we release this chunk, the previous one's verdict must land.
      if ((await settlePrior()) === "abort") {
        deliveredParts.push(REPLACEMENT);
        yield REPLACEMENT;
        return { delivered: deliveredParts.join(""), aborted, abortReason, unverifiedChunks };
      }
      // Start the current chunk's check but do not block on it.
      pendingCheck = { promise: checkChunk(client, chunk), chunk };
      deliveredParts.push(chunk);
      yield chunk;
    }
  }

  // Final flush: any residual buffer is one last chunk.
  if (buffer.length > 0) {
    if ((await settlePrior()) === "abort") {
      deliveredParts.push(REPLACEMENT);
      yield REPLACEMENT;
      return { delivered: deliveredParts.join(""), aborted, abortReason, unverifiedChunks };
    }
    const finalChunk = buffer;
    buffer = "";
    pendingCheck = { promise: checkChunk(client, finalChunk), chunk: finalChunk };
    deliveredParts.push(finalChunk);
    yield finalChunk;
  }

  // The final chunk must still be adjudicated. If it violates, we emit the
  // replacement *after* the offending chunk, which is the same behaviour as
  // any other chunk.
  if ((await settlePrior()) === "abort") {
    deliveredParts.push(REPLACEMENT);
    yield REPLACEMENT;
  }

  return { delivered: deliveredParts.join(""), aborted, abortReason, unverifiedChunks };
}
