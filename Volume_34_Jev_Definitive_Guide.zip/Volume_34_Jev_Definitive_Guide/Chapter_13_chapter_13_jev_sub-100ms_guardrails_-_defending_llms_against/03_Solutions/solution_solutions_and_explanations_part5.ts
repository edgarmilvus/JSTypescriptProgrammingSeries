/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// guardrail-badge.styles.ts — exhaustive mapping, no JSX
import type { GuardrailAction } from "./guardrail-event";

// Exhaustive by construction: adding a new GuardrailAction is a compile error
// until it is added here.
export const ACTION_STYLE = {
  pass: {
    label: "Pass",
    icon: "•",
    badgeVar: "--g-pass-bg",
    textVar: "--g-pass-fg",
    weight: 1,
  },
  annotate: {
    label: "Note",
    icon: "i",
    badgeVar: "--g-annotate-bg",
    textVar: "--g-annotate-fg",
    weight: 2,
  },
  review: {
    label: "Review",
    icon: "?",
    badgeVar: "--g-review-bg",
    textVar: "--g-review-fg",
    weight: 3,
  },
  block: {
    label: "Blocked",
    icon: "✕",
    badgeVar: "--g-block-bg",
    textVar: "--g-block-fg",
    weight: 5,
  },
  support: {
    // Different icon, different shape, and a dotted border read as distinct
    // from "block" in monochrome and high-contrast modes. Colour is a third
    // signal, not the only one.
    label: "Support",
    icon: "♥",
    badgeVar: "--g-support-bg",
    textVar: "--g-support-fg",
    weight: 4,
  },
} satisfies Record<GuardrailAction, { label: string; icon: string; badgeVar: string; textVar: string; weight: number }>;

export const DEFAULT_THEME: Record<string, string> = {
  "--g-pass-bg": "#f4f4f5",
  "--g-pass-fg": "#52525b",
  "--g-annotate-bg": "#eef4ff",
  "--g-annotate-fg": "#1d4ed8",
  "--g-review-bg": "#fef3c7",
  "--g-review-fg": "#92400e",
  "--g-block-bg": "#7f1d1d",
  "--g-block-fg": "#fef2f2",
  "--g-support-bg": "#0f766e",
  "--g-support-fg": "#f0fdfa",
};
