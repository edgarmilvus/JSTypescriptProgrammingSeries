/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// GuardrailBadge.tsx
import * as React from "react";
import { ACTION_STYLE, DEFAULT_THEME } from "./guardrail-badge.styles";
import type { GuardrailEvent, GuardrailAction } from "./guardrail-event";

export interface GuardrailBadgeProps {
  event: GuardrailEvent;
  onInspect?: (event: GuardrailEvent) => void;
}

// Confidence bands. High/medium/low thresholds mirror the guardrail's own
// confidentThreshold / cautiousThreshold constants so an operator reading the
// badge can connect the colour to the router's tier.
const CONF_HIGH = 0.85;
const CONF_MEDIUM = 0.55;

function confidenceBand(c: number): "high" | "medium" | "low" {
  if (c >= CONF_HIGH) return "high";
  if (c >= CONF_MEDIUM) return "medium";
  return "low";
}

const bandify = (c: number): string => `${(c * 100).toFixed(1)}%`;

// Top-three hazards for the evidence panel; pure, called only when the panel
// is open. Not memoized here because it only runs on the inspected badge.
function topThree(evidence: Record<string, number>): Array<[string, number]> {
  return Object.entries(evidence)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);
}

function GuardrailBadgeImpl({ event, onInspect }: GuardrailBadgeProps) {
  const [open, setOpen] = React.useState(false);
  const badgeRef = React.useRef<HTMLButtonElement | null>(null);
  const panelRef = React.useRef<HTMLDivElement | null>(null);

  // Close on Escape from anywhere inside the panel or the badge itself.
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        // Return focus to the badge so keyboard users do not land on the body.
        badgeRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const style = {
    ...DEFAULT_THEME,
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
  } as React.CSSProperties;

  // Fixed-size container reservations. Identical bounding box before and after
  // the pending→assessed transition; the *contents* swap, the outer box does
  // not. This is what guarantees no layout shift.
  const boxStyle: React.CSSProperties = {
    minWidth: 96,
    height: 22,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 11,
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  };

  if (event.stage === "pending") {
    return (
      <span aria-hidden="true" style={{ ...style, ...boxStyle }}>
        <span
          style={{
            width: 8,
            height: 8,
            borderRadius: 4,
            background: "#cbd5e1",
            animation: "g-pulse 1.2s ease-in-out infinite",
          }}
        />
      </span>
    );
  }

  const action = event.action ?? "pass";
  const ast = ACTION_STYLE[action];
  const conf = event.confidence;
  const band = conf !== undefined ? confidenceBand(conf) : null;

  return (
    <span style={style}>
      <button
        ref={badgeRef}
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          onInspect?.(event);
        }}
        aria-expanded={open}
        aria-describedby={event.rationale ? `rat-${event.messageId}` : undefined}
        title={event.rationale}
        style={{
          ...boxStyle,
          background: `var(${ast.badgeVar})`,
          color: `var(${ast.textVar})`,
          border: "none",
          borderRadius: 4,
          padding: "0 8px",
          cursor: "pointer",
          // shape difference beyond colour is in the icon + border style below
          borderStyle: action === "support" ? "dotted" : "solid",
          borderWidth: action === "support" ? 1 : 0,
          borderColor: action === "support" ? "currentColor" : undefined,
        }}
      >
        <span aria-hidden="true">{ast.icon}</span>
        <span>{ast.label}</span>
        {conf !== undefined && (
          <span style={{ opacity: band === "low" ? 0.65 : 1 }}>
            {bandify(conf)}
          </span>
        )}
        {event.fallback && (
          <span
            aria-label="fallback"
            title="Decision produced by fallback path; Jev call did not complete."
            style={{ marginLeft: 2, opacity: 0.75 }}
          >
            *
          </span>
        )}
      </button>

      {event.rationale && (
        <span id={`rat-${event.messageId}`} hidden>
          {event.rationale}
        </span>
      )}

      {open && event.evidence && (
        <div
          ref={panelRef}
          role="dialog"
          aria-label="Guardrail evidence"
          style={{
            position: "absolute",
            background: "white",
            border: "1px solid #e4e4e7",
            borderRadius: 6,
            padding: 8,
            fontSize: 11,
            boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
            zIndex: 20,
          }}
        >
          {topThree(event.evidence).map(([name, p]) => (
            <div key={name} style={{ display: "flex", gap: 8 }}>
              <span style={{ width: 110 }}>{name}</span>
              <span>{p.toFixed(2)}</span>
            </div>
          ))}
        </div>
      )}
    </span>
  );
}

// Memoization compares only fields that change the rendered output. Evidence
// is compared by reference, because the upstream guardrail reuses the object
// unless the decision itself changed — deep comparison would be wasted work
// for every unrelated re-render and would defeat the point of the memo.
//
// onInspect is compared by reference, which is correct: a caller that
// constructs a fresh closure each render either accepts the re-render or
// memoizes the callback with useCallback.
export const GuardrailBadge = React.memo(GuardrailBadgeImpl, (prev, next) => {
  if (prev.onInspect !== next.onInspect) return false;
  const a = prev.event;
  const b = next.event;
  // Fast path: identical reference means nothing changed.
  if (a === b) return true;
  return (
    a.messageId === b.messageId &&
    a.stage === b.stage &&
    a.action === b.action &&
    a.confidence === b.confidence &&
    a.rationale === b.rationale &&
    a.fallback === b.fallback &&
    // Reference-equality on evidence: a new object with identical contents
    // counts as a change, because the upstream code is responsible for
    // holding references stable.
    a.evidence === b.evidence
  );
});
