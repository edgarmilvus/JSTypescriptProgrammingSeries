/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// tune-guardrail.ts
/**
 * Discussion questions (see "Interactive Challenge" README):
 *
 * 1. Calibration plot shape. Bucketed by Jev probability in deciles, the
 *    frequency of `truth: "injection"` should track the diagonal (y ≈ x) with
 *    a confidence band that widens as bucket count shrinks. The deviation
 *    that would concern me most is not a constant offset — that is a bias
 *    the operator can retune against — but a *non-monotonic* reshape in the
 *    mid-band: e.g. bucket 0.5 → 0.7, 0.6 → 0.75, 0.7 → 0.65. That pattern
 *    means the model is not "confidently wrong" but *locally incoherent* in
 *    the region where our thresholds sit, and no threshold shift fixes it.
 *
 * 2. Which boundary matters more. Empirically the `block` boundary has the
 *    larger downstream effect: it decides what is suppressed, while `allow`
 *    decides what is passed without a second look. From the log alone I can
 *    measure how many labeled cases fall within ±0.05 of each boundary. If
 *    that count is uniformly larger near `block`, `block` is the sensitive
 *    boundary. But the raw count is not enough: I want to know whether the
 *    density near `block` is *asymmetric* between benign and injection.
 *    Additional signals that would help: message length, user tenure (new
 *    accounts may be adversarial), and channel (a support inbox is different
 *    from a public comment field).
 *
 * 3. Fallback asymmetry. For `block` I would fail *open*: a 5% false-block
 *    rate on benign traffic is a live product event that sends users to a
 *    competitor, whereas 0.5% of injections slipping through during a
 *    transient failure is priced into the guardrail's normal error budget.
 *    For `allow` I would fail *closed* (i.e., route to review): an `allow`
 *    that fires during a fallback is a classifier saying "yep, safe" without
 *    having seen the message, which is the exact shape of a security hole.
 *    The two are opposite because the two paths are opposites: `block` is a
 *    punitive action; `allow` is a claim of safety.
 *
 * 4. Long-message precision drop. This is the "large state full of
 *    irrelevant detail" failure mode from the Jev jaggedness page. Long
 *    messages dilute the signal: the model's attention is spent on unrelated
 *    paragraphs, and the injection-relevant sentence loses weight. First
 *    change: fix the *state* — retrieve and send only the sentence window
 *    around any suspicious token, and ask the question against a
 *    pre-filtered state. Second change: split the message into chunks and
 *    ask per-chunk, then aggregate (this is the same speculative fan-out
 *    pattern used in Exercise 3). Only after both should the model itself
 *    be reconsidered; the chapter is explicit that state design is the
 *    highest-leverage lever.
 *
 * 5. Should the tool recommend acceptance? No. The chapter's position is
 *    that the tool "proposes; the human decides", and the reasoning is that
 *    a machine-generated recommendation about a threshold change collapses
 *    two distinct judgments (is this statistically justified? is this the
 *    right business trade-off?) into one. A tool that says "accept" invites
 *    rubber-stamping; a tool that says nothing forces the operator to read
 *    the numbers. The strongest counter-argument is operational load — at
 *    scale, an operator cannot read every proposal — but that is solved by
 *    ranking proposals by expected impact, not by automating the decision.
 *    I side with the chapter.
 */

import * as fs from "node:fs";
import * as readline from "node:readline";
import * as path from "node:path";

type DecisionRecord = {
  kind: "decision";
  id: string;
  ts: string;
  messageHash: string;
  probability: number;
  thresholds: { allow: number; block: number };
  action: "allow" | "review" | "block";
  rule: string | null;
  source: "deterministic" | "jev" | "fallback";
};

type LabelRecord = {
  kind: "label";
  id: string;
  ts: string;
  truth: "injection" | "benign";
};

type Record_ = DecisionRecord | LabelRecord;

// Hand-rolled type guards. We deliberately do not use a schema library here;
// the exercise is to make the validation explicit so that the failure mode of
// a new field appearing in the log is debuggable.
function isObject(x: unknown): x is Record<string, unknown> {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}
function isDecision(x: unknown): x is DecisionRecord {
  if (!isObject(x) || x.kind !== "decision") return false;
  return (
    typeof x.id === "string" &&
    typeof x.probability === "number" &&
    x.probability >= 0 &&
    x.probability <= 1 &&
    isObject(x.thresholds) &&
    typeof (x.thresholds as any).allow === "number" &&
    typeof (x.thresholds as any).block === "number" &&
    (x.action === "allow" || x.action === "review" || x.action === "block")
  );
}
function isLabel(x: unknown): x is LabelRecord {
  if (!isObject(x) || x.kind !== "label") return false;
  return (
    typeof x.id === "string" &&
    (x.truth === "injection" || x.truth === "benign")
  );
}

interface Args {
  decisions: string;
  out?: string;
  interactive: boolean;
  minSamples: number;
}

function parseArgs(argv: string[]): Args {
  const out: Partial<Args> = { interactive: false, minSamples: 20 };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--decisions") out.decisions = argv[++i];
    else if (a === "--out") out.out = argv[++i];
    else if (a === "--interactive") out.interactive = true;
    else if (a === "--min-samples") out.minSamples = Number(argv[++i]);
    else throw new Error(`unknown argument: ${a}`);
  }
  if (!out.decisions) throw new Error("--decisions is required");
  return out as Args;
}

// ---------------------------------------------------------------------------
// Streaming ingest. Memory is O(number of decisions + number of labels),
// which is the tightest guarantee we can give: the input format contains no
// way to summarize a decision without holding its id, and no way to join a
// label without holding both sides of the join. What we *can* avoid is
// holding the source file or the parsed JSON of every line at once.
// ---------------------------------------------------------------------------
interface Corpus {
  decisions: Map<string, DecisionRecord>;
  labels: Map<string, "injection" | "benign">;
  total: number;
  malformed: number;
}

async function ingest(file: string): Promise<Corpus> {
  const corpus: Corpus = {
    decisions: new Map(),
    labels: new Map(),
    total: 0,
    malformed: 0,
  };
  const stream = fs.createReadStream(file, { encoding: "utf8" });
  const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });

  let lineNo = 0;
  for await (const line of rl) {
    lineNo++;
    if (!line.trim()) continue;
    corpus.total++;
    let parsed: unknown;
    try {
      parsed = JSON.parse(line);
    } catch {
      console.error(`line ${lineNo}: not valid JSON`);
      corpus.malformed++;
      continue;
    }
    if (isDecision(parsed)) {
      corpus.decisions.set(parsed.id, parsed);
    } else if (isLabel(parsed)) {
      corpus.labels.set(parsed.id, parsed.truth);
    } else {
      console.error(`line ${lineNo}: unrecognized record shape`);
      corpus.malformed++;
    }
  }
  if (corpus.malformed > 0) {
    throw new Error(`${corpus.malformed} malformed lines`);
  }
  return corpus;
}

// ---------------------------------------------------------------------------
// Metrics
// ---------------------------------------------------------------------------
interface Bucket {
  candidate: number;
  precision: number;
  recall: number;
  f1: number;
  density: number;
  tp: number;
  fp: number;
  fn: number;
}

interface Joined {
  p: number;
  truth: "injection" | "benign";
}

function join(corpus: Corpus): { labeled: Joined[]; unlabeled: number } {
  const labeled: Joined[] = [];
  let unlabeled = 0;
  for (const [id, d] of corpus.decisions) {
    const t = corpus.labels.get(id);
    if (!t) {
      unlabeled++;
      continue;
    }
    labeled.push({ p: d.probability, truth: t });
  }
  return { labeled, unlabeled };
}

// The "positive" for the ALLOW threshold is "benign". A false positive at
// this threshold is an *injection that we allow* (bad). A false negative is a
// *benign message we route away from allow* (annoying but safe).
function sweepAllow(labeled: Joined[], minDensity: number, fpCost = 1, fnCost = 1): Bucket[] {
  const buckets: Bucket[] = [];
  for (let t = 0.05; t <= 0.85 + 1e-9; t += 0.05) {
    let tp = 0, fp = 0, fn = 0, density = 0;
    for (const r of labeled) {
      // prediction: allow if p < t
      const pred = r.p < t ? "benign" : "injection";
      if (Math.abs(r.p - t) <= 0.05) density++;
      if (pred === "benign" && r.truth === "benign") tp++;
      else if (pred === "benign" && r.truth === "injection") fp++;
      else if (pred === "injection" && r.truth === "benign") fn++;
    }
    const precision = tp + fp === 0 ? 0 : tp / (tp + fp);
    const recall = tp + fn === 0 ? 0 : tp / (tp + fn);
    const f1 =
      precision + recall === 0
        ? 0
        : (2 * precision * recall) / (precision + recall);
    // Cost-weighted F1: swap tp/fp/fn weights to reflect business tolerance.
    const costF1 =
      fp * fnCost + fn * fpCost === 0
        ? 0
        : (2 * tp) / (2 * tp + fp * (fnCost / fpCost) + fn * (fpCost / fnCost));
    buckets.push({
      candidate: Number(t.toFixed(2)),
      precision,
      recall,
      f1,
      density,
      tp,
      fp,
      fn,
    });
  }
  return buckets;
}

// The "positive" for the BLOCK threshold is "injection". Symmetric sweep.
function sweepBlock(labeled: Joined[], fpCost = 1, fnCost = 1): Bucket[] {
  const buckets: Bucket[] = [];
  for (let t = 0.15; t <= 0.95 + 1e-9; t += 0.05) {
    let tp = 0, fp = 0, fn = 0, density = 0;
    for (const r of labeled) {
      const pred = r.p > t ? "injection" : "benign";
      if (Math.abs(r.p - t) <= 0.05) density++;
      if (pred === "injection" && r.truth === "injection") tp++;
      else if (pred === "injection" && r.truth === "benign") fp++;
      else if (pred === "benign" && r.truth === "injection") fn++;
    }
    const precision = tp + fp === 0 ? 0 : tp / (tp + fp);
    const recall = tp + fn === 0 ? 0 : tp / (tp + fn);
    const f1 =
      precision + recall === 0
        ? 0
        : (2 * precision * recall) / (precision + recall);
    buckets.push({
      candidate: Number(t.toFixed(2)),
      precision,
      recall,
      f1,
      density,
      tp,
      fp,
      fn,
    });
  }
  return buckets;
}

function pickBest(buckets: Bucket[], minSamples: number): Bucket | null {
  const eligible = buckets.filter((b) => b.density >= minSamples);
  if (eligible.length === 0) return null;
  return eligible.reduce((best, b) => (b.f1 > best.f1 ? b : best));
}

function guessCurrent(thresholds: number[]): number {
  // The log carries per-decision thresholds; we take the most common value as
  // "the current operating point".
  const counts = new Map<number, number>();
  for (const t of thresholds) counts.set(t, (counts.get(t) ?? 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
}

interface Proposal {
  allow: {
    current: number;
    proposed: number;
    f1AtCurrent: number;
    f1AtProposed: number;
    sampleDensity: number;
    rationale: string;
  };
  block: {
    current: number;
    proposed: number;
    f1AtCurrent: number;
    f1AtProposed: number;
    sampleDensity: number;
    rationale: string;
  };
  metrics: {
    allowBuckets: Bucket[];
    blockBuckets: Bucket[];
    unlabeledDecisions: number;
    labeledDecisions: number;
    totalDecisions: number;
  };
}

function buildProposal(
  corpus: Corpus,
  labeled: Joined[],
  minSamples: number,
  fpCost = 1,
  fnCost = 1,
): Proposal {
  const currentAllow = guessCurrent(
    [...corpus.decisions.values()].map((d) => d.thresholds.allow),
  );
  const currentBlock = guessCurrent(
    [...corpus.decisions.values()].map((d) => d.thresholds.block),
  );
  const allowBuckets = sweepAllow(labeled, minSamples, fpCost, fnCost);
  const blockBuckets = sweepBlock(labeled, fpCost, fnCost);

  const bestAllow = pickBest(allowBuckets, minSamples);
  const bestBlock = pickBest(blockBuckets, minSamples);

  const atCurrent = (bs: Bucket[], cur: number): Bucket =>
    bs.reduce((closest, b) =>
      Math.abs(b.candidate - cur) < Math.abs(closest.candidate - cur) ? b : closest,
    );

  const curAllow = atCurrent(allowBuckets, currentAllow);
  const curBlock = atCurrent(blockBuckets, currentBlock);

  const unlabeled = corpus.decisions.size - labeled.length;
  const benignCount = labeled.filter((r) => r.truth === "benign").length;
  const injCount = labeled.length - benignCount;

  const makeRationale = (
    name: "allow" | "block",
    cur: Bucket,
    best: Bucket,
    total: number,
    benign: number,
    inj: number,
  ) => {
    if (name === "allow") {
      const benignRoutedAway = cur.fn;
      const rescued = cur.fn - best.fn;
      const newInjections = best.fp - cur.fp;
      return (
        `At the current threshold of ${cur.candidate}, ${benignRoutedAway} of ${benign} benign messages ` +
        `are being routed to review or block. Raising to ${best.candidate} rescues ${rescued} of those ` +
        `but costs ${newInjections} additional labeled injections passing through. ` +
        `Operator should weigh the business's tolerance for missed injections.`
      );
    }
    const newFPs = best.fp - cur.fp;
    const caught = cur.fn - best.fn;
    return (
      `At the current threshold of ${cur.candidate}, ${cur.fn} of ${inj} labeled injections ` +
      `are being allowed past the block boundary. Lowering to ${best.candidate} catches ${caught} more ` +
      `at the cost of ${newFPs} more benign messages blocked. ` +
      `Operator should confirm against the false-block tolerance budget.`
    );
  };

  return {
    allow: bestAllow
      ? {
          current: curAllow.candidate,
          proposed: bestAllow.candidate,
          f1AtCurrent: curAllow.f1,
          f1AtProposed: bestAllow.f1,
          sampleDensity: bestAllow.density,
          rationale: makeRationale(
            "allow",
            curAllow,
            bestAllow,
            labeled.length,
            benignCount,
            injCount,
          ),
        }
      : {
          current: currentAllow,
          proposed: currentAllow,
          f1AtCurrent: curAllow.f1,
          f1AtProposed: curAllow.f1,
          sampleDensity: curAllow.density,
          rationale: `Retained at ${currentAllow}: no candidate threshold met --min-samples ${minSamples}.`,
        },
    block: bestBlock
      ? {
          current: curBlock.candidate,
          proposed: bestBlock.candidate,
          f1AtCurrent: curBlock.f1,
          f1AtProposed: bestBlock.f1,
          sampleDensity: bestBlock.density,
          rationale: makeRationale(
            "block",
            curBlock,
            bestBlock,
            labeled.length,
            benignCount,
            injCount,
          ),
        }
      : {
          current: currentBlock,
          proposed: currentBlock,
          f1AtCurrent: curBlock.f1,
          f1AtProposed: curBlock.f1,
          sampleDensity: curBlock.density,
          rationale: `Retained at ${currentBlock}: no candidate threshold met --min-samples ${minSamples}.`,
        },
    metrics: {
      allowBuckets,
      blockBuckets,
      unlabeledDecisions: unlabeled,
      labeledDecisions: labeled.length,
      totalDecisions: corpus.decisions.size,
    },
  };
}

function printReport(proposal: Proposal): void {
  const { metrics } = proposal;
  const labeledPct = metrics.totalDecisions
    ? ((metrics.labeledDecisions / metrics.totalDecisions) * 100).toFixed(1)
    : "0.0";
  const allowArrow =
    proposal.allow.current === proposal.allow.proposed ? "retained" : "→";
  const blockArrow =
    proposal.block.current === proposal.block.proposed ? "retained" : "→";
  const lines = [
    "Tuning report",
    `  decisions processed: ${metrics.totalDecisions.toLocaleString()}`,
    `  labeled: ${metrics.labeledDecisions.toLocaleString()} (${labeledPct}%)`,
    `  unlabeled: ${metrics.unlabeledDecisions.toLocaleString()}`,
    `  allow:  ${proposal.allow.current} ${allowArrow} ${proposal.allow.proposed}  ` +
      `(F1 ${proposal.allow.f1AtCurrent.toFixed(2)} → ${proposal.allow.f1AtProposed.toFixed(2)}, ` +
      `density ${proposal.allow.sampleDensity})`,
    `  block:  ${proposal.block.current} ${blockArrow} ${proposal.block.proposed}  ` +
      `(F1 ${proposal.block.f1AtCurrent.toFixed(2)} → ${proposal.block.f1AtProposed.toFixed(2)}, ` +
      `density ${proposal.block.sampleDensity})`,
  ];
  console.log(lines.join("\n"));
}

async function repl(
  corpus: Corpus,
  labeled: Joined[],
  proposal: Proposal,
  minSamples: number,
): Promise<void> {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "tune> ",
  });
  const onSigint = () => {
    rl.close();
    process.exit(0);
  };
  process.once("SIGINT", onSigint);

  rl.prompt();
  for await (const line of rl) {
    const [cmd, ...rest] = line.trim().split(/\s+/);
    if (cmd === "quit" || cmd === "") {
      if (cmd === "quit") break;
      rl.prompt();
      continue;
    }
    if (cmd === "show") {
      const which = rest[0] as "allow" | "block";
      const buckets =
        which === "allow" ? proposal.metrics.allowBuckets : proposal.metrics.blockBuckets;
      const proposed =
        which === "allow" ? proposal.allow.proposed : proposal.block.proposed;
      for (const b of buckets) {
        const marker = b.candidate === proposed ? "*" : " ";
        console.log(
          `${marker} t=${b.candidate.toFixed(2)}  precision=${b.precision.toFixed(3)}  ` +
            `recall=${b.recall.toFixed(3)}  F1=${b.f1.toFixed(3)}  n≈${b.density}`,
        );
      }
    } else if (cmd === "cost") {
      const which = rest[0] as "allow" | "block";
      const fpCost = Number(rest[2]);
      const fnCost = Number(rest[3]);
      const buckets = (
        which === "allow"
          ? sweepAllow(labeled, minSamples, fpCost, fnCost)
          : sweepBlock(labeled, fpCost, fnCost)
      );
      const best = pickBest(buckets, minSamples);
      console.log(
        `uniform proposal: ${which === "allow" ? proposal.allow.proposed : proposal.block.proposed}`,
      );
      console.log(`cost-weighted proposal: ${best ? best.candidate : "retained"}`);
    } else {
      console.log(`unknown command: ${cmd}`);
    }
    rl.prompt();
  }
  process.removeListener("SIGINT", onSigint);
}

async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv);
    const corpus = await ingest(args.decisions);
    const { labeled, unlabeled } = join(corpus);
    if (labeled.length === 0) {
      throw new Error("no labeled decisions in the input");
    }
    const proposal = buildProposal(corpus, labeled, args.minSamples);
    if (args.out) {
      fs.writeFileSync(args.out, JSON.stringify(proposal, null, 2));
    }
    printReport(proposal);
    if (args.interactive) {
      await repl(corpus, labeled, proposal, args.minSamples);
    }
    process.exit(0);
  } catch (err) {
    console.error((err as Error).message);
    process.exit(1);
  }
}

if (require.main === module) {
  void main();
}

// Tests asserting the monotonicity property promised by the acceptance
// criteria: with fnCost → ∞, the cost-weighted `block` proposal must be
// at-least-as-low (more conservative catch) as the uniform proposal; with
// fpCost → ∞, it must be at-least-as-high (more permissive).
//
//   const lower = pickBest(sweepBlock(labeled, 1, 1000), minSamples)!.candidate;
//   const upper = pickBest(sweepBlock(labeled, 1000, 1), minSamples)!.candidate;
//   const uniform = pickBest(sweepBlock(labeled, 1, 1), minSamples)!.candidate;
//   expect(lower).toBeLessThanOrEqual(uniform);
//   expect(upper).toBeGreaterThanOrEqual(uniform);
