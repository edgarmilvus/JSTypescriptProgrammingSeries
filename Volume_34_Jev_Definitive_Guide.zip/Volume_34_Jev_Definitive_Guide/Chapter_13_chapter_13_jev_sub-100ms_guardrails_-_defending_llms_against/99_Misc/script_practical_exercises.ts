/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import { TypeSafeClient, noul } from "@typesafe-ai/sdk";

export interface InjectionVerdict {
  /** Final decision for this message. */
  verdict: "allow" | "review" | "block";
  /** Which stage produced the block or the routing decision. */
  source: "deterministic" | "jev" | "fallback";
  /** Probability that this message is an injection attempt, as reported by Jev. */
  injectionProbability?: number;
  /** Wall-clock milliseconds consumed by the Jev stage, if it ran. */
  jevLatencyMs?: number;
  /** The name of the deterministic rule that fired, if any. */
  rule?: string;
}

export interface InjectionGateOptions {
  client: TypeSafeClient;
  /** Messages whose deterministic risk exceeds this threshold bypass Jev and block. */
  hardBlockRuleScore: number;
  /** Below this Jev probability, the message is allowed without further review. */
  allowBelow: number;
  /** Above this Jev probability, the message is blocked. */
  blockAbove: number;
}

export async function gateInjection(
  message: string,
  options: InjectionGateOptions,
): Promise<InjectionVerdict>;
