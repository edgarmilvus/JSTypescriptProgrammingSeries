/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

import { TypeSafeClient, choice, score, noul } from "@typesafe-ai/sdk";

export type PolicyClass =
  | "allowed"
  | "medical_advice"
  | "self_harm"
  | "violent_content"
  | "jailbreak";

export type Enforcement = "pass" | "annotate" | "review" | "block" | "support";

export interface PolicyVerdict {
  classification: PolicyClass;
  /** Jev's reported confidence in the classification, in [0, 1]. */
  classificationConfidence: number;
  /** Severity score for the winning class, in [0, 3]. */
  severity: number;
  /** Jev's confidence in the severity score. */
  severityConfidence: number;
  /** The action chosen by the router. */
  enforcement: Enforcement;
  /** Why the router chose this enforcement, for audit logs. */
  rationale: string;
}

export interface PolicyRouterConfig {
  client: TypeSafeClient;
  /** Tier 1: act automatically when classification confidence is at or above this. */
  confidentThreshold: number;
  /** Tier 2: proceed with a cautionary path when confidence is above this but below Tier 1. */
  cautiousThreshold: number;
  /** Severity at or above which any non-pass class becomes a block regardless of confidence. */
  severityEscalation: number;
}

export async function routePolicy(
  message: string,
  config: PolicyRouterConfig,
): Promise<PolicyVerdict>;
