/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

import * as React from "react";

export type GuardrailStage = "pending" | "assessed";
export type GuardrailAction = "pass" | "annotate" | "review" | "block" | "support";

export interface GuardrailEvent {
  /** Stable identifier for the message this badge is attached to. */
  messageId: string;
  stage: GuardrailStage;
  /** Populated once stage is "assessed". */
  action?: GuardrailAction;
  /** Jev's reported confidence for the winning decision, if assessed. */
  confidence?: number;
  /** Free-form rationale produced by the router (Exercise 2's `rationale`). */
  rationale?: string;
  /** Per-hazard probabilities that fed the decision, if the caller has them. */
  evidence?: Record<string, number>;
  /** True if this decision was produced by the fallback path, not a clean Jev call. */
  fallback?: boolean;
}

export interface GuardrailBadgeProps {
  event: GuardrailEvent;
  /** If provided, invoked when the operator clicks the badge. */
  onInspect?: (event: GuardrailEvent) => void;
}

export const GuardrailBadge: React.FC<GuardrailBadgeProps>;
