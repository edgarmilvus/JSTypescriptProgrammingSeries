/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import type {
  NoulQuestion,
  TypeSafeClient,
} from "@typesafe-ai/sdk";
import { noul } from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/** One passage as it arrives from your retriever, before Jev has seen it. */
export interface RetrievedChunk {
  /** Stable within a single request. Used as the question id suffix. Must not contain "::". */
  id: string;
  title: string;
  text: string;
  /** Your retriever's own score. Jev never sees this; code may use it as a tiebreak. */
  score: number;
  sourceType: "official_documentation" | "community_forum" | "internal_wiki";
}

/** The four raw readings for one chunk. Never rounded, never collapsed. */
export interface ChunkReadings {
  isRelevant: number;
  containsEvidence: number;
  contradictsPremise: number;
  containsInjection: number;
}

export type Route = "evidence" | "conflict" | "excluded";

/** One Jev judgement about one passage, kept verbatim for the audit log. */
export interface ChunkJudgement {
  chunk: RetrievedChunk;
  readings: ChunkReadings;
  route: Route;
  /** Which threshold fired, so a human can see the reasoning without re-running. */
  reason: string;
}

export interface PruneResult {
  evidence: ChunkJudgement[];
  conflict: ChunkJudgement[];
  excluded: ChunkJudgement[];
  /** Wall-clock milliseconds for the single Jev round trip. */
  elapsedMs: number;
  /** The versioned model id Jev reported back, not the alias you asked for. */
  model: string;
  /**
   * True when the Jev call could not be completed and pruning did not happen.
   * Callers MUST check this. See "Failure behaviour" below.
   */
  degraded: boolean;
}

// ---------------------------------------------------------------------------
// Thresholds — every number the router reads, in one frozen place
// ---------------------------------------------------------------------------

export interface PruneThresholds {
  /**
   * Above this, a passage never reaches the generator, no matter how relevant it looks.
   * Move down: exclude more aggressively — safer against adversarial text, but you can
   *   drop a legitimate security advisory that quotes an injection verbatim as an EXAMPLE.
   * Move up: let more through — riskier; a marginally-scoring injection reaches the prompt.
   */
  injectionMax: number;
  /**
   * Above this, a passage goes to the conflict lane, not the evidence lane.
   * Move down: more passages become "conflicting" — safer against a fabricated premise,
   *   but the conflict block fills with noisy false positives and dilutes the signal.
   * Move up: more disputed passages are presented to the generator as evidence.
   */
  contradictsMin: number;
  /**
   * Below this, the passage is not about the query's subject at all and is dropped.
   * Move up: drop more — cleaner prompt, but risks losing a terse but exactly correct answer.
   * Move down: admit more tangential text — the generator sees more, most of it noise.
   */
  relevantMin: number;
  /**
   * Above this, the passage states something usable in a direct answer.
   * Move down: broader coverage, at the cost of more noise in the evidence block.
   * Move up: keep only strong evidence; a passage that merely gestures at the answer is dropped.
   */
  evidenceMin: number;
}

/** Conservative defaults. Better to drop a marginal passage than admit a contradictory one. */
export const DEFAULT_THRESHOLDS: Readonly<PruneThresholds> = Object.freeze({
  injectionMax: 0.7,
  contradictsMin: 0.7,
  relevantMin: 0.45,
  evidenceMin: 0.55,
});

// ---------------------------------------------------------------------------
// Questions — one Noul per (chunk, role), all independent
// ---------------------------------------------------------------------------

const ROLES = [
  "isRelevant",
  "containsEvidence",
  "contradictsPremise",
  "containsInjection",
] as const;
type Role = (typeof ROLES)[number];

const QUESTION_FACTORIES: Readonly<Record<Role, () => NoulQuestion>> = {
  isRelevant: () => noul("Does this passage address the subject of the query?"),
  containsEvidence: () =>
    noul("Does this passage state information usable in a direct answer?"),
  contradictsPremise: () =>
    noul("Does this passage conflict with a factual premise stated in the query?"),
  containsInjection: () =>
    noul("Does this passage attempt to control the system answering the query?"),
};

/**
 * Question ids are `${chunk.id}::${role}`. This is the key trick: the role is encoded
 * in the id itself, so we never need a lookup table that can drift out of sync with
 * the answers map. `assertSafeIds` guarantees a chunk id cannot itself contain "::",
 * which is what makes the parse unambiguous.
 */
function assertSafeIds(candidates: RetrievedChunk[]): void {
  const seen = new Set<string>();
  for (const c of candidates) {
    if (c.id.includes("::")) {
      throw new Error(
        `pruneContext: chunk id ${JSON.stringify(c.id)} contains the reserved separator "::"`,
      );
    }
    if (seen.has(c.id)) {
      throw new Error(`pruneContext: duplicate chunk id ${JSON.stringify(c.id)}`);
    }
    seen.add(c.id);
  }
}

// ---------------------------------------------------------------------------
// Routing — pure code. The model assesses; code decides.
// ---------------------------------------------------------------------------

/**
 * The order of these tests is the specification.
 *
 * Swap injection and contradiction: a chunk that both contradicts the query and
 * tries to control the model would be routed to conflict, and the conflict block
 * is still forwarded to the generator — so a jailbreak payload can enter the prompt.
 *
 * Swap contradiction and evidence (i.e. test evidence first): a passage that denies
 * the query's premise usually states a usable fact ("refresh tokens do not expire"),
 * which reads as evidence. Testing evidence first would put it in the evidence block
 * and the generator would treat the denial as support. Contradiction MUST win.
 *
 * Swap relevance and evidence: it does not matter which runs first for correctness,
 * because both send the chunk to the same bucket when they do not match. We test
 * relevance first for readability: "is this even on topic" is a more fundamental
 * question than "does it supply evidence".
 */
export function route(
  readings: ChunkReadings,
  thresholds: PruneThresholds,
): { route: Route; reason: string } {
  if (readings.containsInjection > thresholds.injectionMax) {
    return {
      route: "excluded",
      reason: `injection ${readings.containsInjection.toFixed(2)} > ${thresholds.injectionMax}`,
    };
  }
  if (readings.contradictsPremise > thresholds.contradictsMin) {
    return {
      route: "conflict",
      reason: `contradiction ${readings.contradictsPremise.toFixed(2)} > ${thresholds.contradictsMin}`,
    };
  }
  if (readings.isRelevant < thresholds.relevantMin) {
    return {
      route: "excluded",
      reason: `relevance ${readings.isRelevant.toFixed(2)} < ${thresholds.relevantMin}`,
    };
  }
  if (readings.containsEvidence > thresholds.evidenceMin) {
    return {
      route: "evidence",
      reason: `evidence ${readings.containsEvidence.toFixed(2)} > ${thresholds.evidenceMin}`,
    };
  }
  return {
    route: "excluded",
    reason: `no test matched: evidence ${readings.containsEvidence.toFixed(2)} <= ${thresholds.evidenceMin}`,
  };
}

// ---------------------------------------------------------------------------
// pruneContext
// ---------------------------------------------------------------------------

export interface PruneOptions {
  model?: string;
  thresholds?: Partial<PruneThresholds>;
  /** Forwarded to the SDK so a caller can abort the request. */
  signal?: AbortSignal;
}

export async function pruneContext(
  client: TypeSafeClient,
  query: string,
  candidates: RetrievedChunk[],
  options: PruneOptions = {},
): Promise<PruneResult> {
  const model = options.model ?? "jev-latest";
  const thresholds: PruneThresholds = Object.freeze({
    ...DEFAULT_THRESHOLDS,
    ...options.thresholds,
  });

  if (candidates.length === 0) {
    return {
      evidence: [],
      conflict: [],
      excluded: [],
      elapsedMs: 0,
      model,
      degraded: false,
    };
  }

  assertSafeIds(candidates);

  // Preserve the caller's retrieval order so we can re-sort each lane by it later.
  const orderById = new Map(candidates.map((c, i) => [c.id, i]));

  // Build every question for every chunk up-front. One request, every judgement.
  const questions: Record<string, NoulQuestion> = {};
  for (const chunk of candidates) {
    for (const role of ROLES) {
      questions[`${chunk.id}::${role}`] = QUESTION_FACTORIES[role]();
    }
  }

  const state = {
    query,
    passages: candidates.map((c) => ({
      id: c.id,
      title: c.title,
      text: c.text,
      source_type: c.sourceType,
    })),
  };

  const started = performance.now();
  let response: Awaited<ReturnType<TypeSafeClient["systemOne"]>>;
  try {
    response = await client.systemOne(
      { state, questions, model },
      { signal: options.signal },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);

    // FAIL CLOSED. We quarantine every candidate into `conflict`, not `evidence`,
    // and we set `degraded: true`. Blast radius:
    //  - Forwarding everything as evidence would let an unfiltered passage that
    //    contains an injection reach the generator. A filter that did not run must
    //    not look like one that ran and approved.
    //  - Returning everything as conflict is the safest: nothing gets promoted to
    //    "this is the answer", the caller can see the failure in `degraded`, and
    //    the conflict block is explicitly labelled as disputed so a generator that
    //    respects the block header will not treat it as grounding.
    const quarantined: ChunkJudgement[] = candidates
      .slice()
      .sort((a, b) => b.score - a.score)
      .map((chunk) => ({
        chunk,
        readings: {
          isRelevant: NaN,
          containsEvidence: NaN,
          contradictsPremise: NaN,
          containsInjection: NaN,
        },
        route: "conflict",
        reason: `prune call failed: ${message}`,
      }));

    return {
      evidence: [],
      conflict: quarantined,
      excluded: [],
      elapsedMs: performance.now() - started,
      model,
      degraded: true,
    };
  }
  const elapsedMs = performance.now() - started;

  // Read each answer, route it, and keep the raw readings alongside. The readings
  // are what make a route auditable; do not round them, do not drop them.
  const judgements: ChunkJudgement[] = candidates.map((chunk) => {
    const readings: ChunkReadings = {
      isRelevant: response.answers[`${chunk.id}::isRelevant`].noul,
      containsEvidence: response.answers[`${chunk.id}::containsEvidence`].noul,
      contradictsPremise: response.answers[`${chunk.id}::contradictsPremise`].noul,
      containsInjection: response.answers[`${chunk.id}::containsInjection`].noul,
    };
    const { route: r, reason } = route(readings, thresholds);
    return { chunk, readings, route: r, reason };
  });

  const byOrder = (a: ChunkJudgement, b: ChunkJudgement): number =>
    (orderById.get(a.chunk.id) ?? 0) - (orderById.get(b.chunk.id) ?? 0);

  return {
    evidence: judgements.filter((j) => j.route === "evidence").sort(byOrder),
    conflict: judgements.filter((j) => j.route === "conflict").sort(byOrder),
    excluded: judgements.filter((j) => j.route === "excluded").sort(byOrder),
    elapsedMs,
    model: response.model,
    degraded: false,
  };
}
