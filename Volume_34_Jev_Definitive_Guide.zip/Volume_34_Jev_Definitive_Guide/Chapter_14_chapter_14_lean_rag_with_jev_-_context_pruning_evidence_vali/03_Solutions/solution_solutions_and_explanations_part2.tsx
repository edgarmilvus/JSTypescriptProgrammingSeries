/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { TypeSafeClient } from "@typesafe-ai/sdk";
import type {
  ChunkJudgement,
  PruneResult,
  PruneThresholds,
  RetrievedChunk,
  Route,
} from "./pruneContext"; // from Exercise 1
import {
  DEFAULT_THRESHOLDS,
  pruneContext,
  route,
} from "./pruneContext";

// ---------------------------------------------------------------------------
// Hook: owns the network call, the AbortController, and the state machine
// ---------------------------------------------------------------------------

export interface UsePruneContextOptions {
  model?: string;
}

export interface UsePruneContextResult {
  result: PruneResult | null;
  status: "idle" | "pruning" | "ready" | "error";
  error: Error | null;
  refresh: () => void;
}

/**
 * Note on `APIPromise`: the SDK returns a thenable that also carries HTTP metadata
 * (`withResponse()`, `asResponse()`). We only need `answers` and `model` — both on
 * the resolved value — so we `await` plainly and never touch the metadata. Using
 * `withResponse()` here would just keep a Response object alive past its usefulness.
 */
export function usePruneContext(
  client: TypeSafeClient,
  query: string,
  candidates: RetrievedChunk[],
  options: UsePruneContextOptions = {},
): UsePruneContextResult {
  const [result, setResult] = useState<PruneResult | null>(null);
  const [status, setStatus] = useState<"idle" | "pruning" | "ready" | "error">(
    "idle",
  );
  const [error, setError] = useState<Error | null>(null);
  const [nonce, setNonce] = useState(0);

  const abortRef = useRef<AbortController | null>(null);

  // A cheap structural key. Re-running the effect when only the array identity
  // changes would cause a re-fetch on every parent render, which is the classic
  // "why is this component making 40 requests per second" bug.
  const candidatesKey = useMemo(
    () => candidates.map((c) => `${c.id}:${c.score}`).join("|"),
    [candidates],
  );
  const model = options.model;

  useEffect(() => {
    // Cancel any in-flight request before starting a new one. Without this, a
    // fast-changing query (an input box, a filter) queues up a dozen parallel
    // requests whose results arrive out of order.
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    if (candidates.length === 0) {
      setStatus("idle");
      setResult(null);
      setError(null);
      return;
    }

    setStatus("pruning");
    setError(null);

    pruneContext(client, query, candidates, { model, signal: controller.signal })
      .then((r) => {
        // A late result from an aborted request must NOT overwrite the newer one.
        if (controller.signal.aborted) return;
        setResult(r);
        setStatus("ready");
      })
      .catch((err: unknown) => {
        // Abort errors are not user-visible. Without this guard a user dragging
        // a filter sees a red error flash on every keystroke — unreproducible
        // because it depends on network timing.
        if (controller.signal.aborted) return;
        if (err instanceof DOMException && err.name === "AbortError") return;
        setError(err instanceof Error ? err : new Error(String(err)));
        setStatus("error");
      });

    return () => controller.abort();
  }, [client, query, candidatesKey, nonce, model]);

  const refresh = useCallback(() => setNonce((n) => n + 1), []);

  return { result, status, error, refresh };
}

// ---------------------------------------------------------------------------
// The presentational panel
// ---------------------------------------------------------------------------

type ReadingsKey = keyof ChunkJudgement["readings"];

export interface EffectiveRouting {
  readonly [chunkId: string]: Route;
}

export interface EvidenceReviewPanelProps {
  result: PruneResult;
  query: string;
  onRoutedChange?: (routed: EffectiveRouting) => void;
  onOverride?: (chunkId: string, route: Route) => void;
  sortExcludedBy?: ReadingsKey;
}

const LANES: readonly Route[] = ["evidence", "conflict", "excluded"];
const LANE_LABEL: Record<Route, string> = {
  evidence: "Evidence",
  conflict: "Conflict",
  excluded: "Excluded",
};
const READING_LABEL: Record<ReadingsKey, string> = {
  isRelevant: "Rel",
  containsEvidence: "Evid",
  contradictsPremise: "Contra",
  containsInjection: "Inj",
};

interface Row {
  judgement: ChunkJudgement;
  /** The route under the SLIDER thresholds, which may differ from `judgement.route`. */
  proposed: Route;
  proposedReason: string;
  /** The route the pruner originally computed. */
  original: Route;
}

function thresholdsEqual(a: PruneThresholds, b: PruneThresholds): boolean {
  return (
    a.injectionMax === b.injectionMax &&
    a.contradictsMin === b.contradictsMin &&
    a.relevantMin === b.relevantMin &&
    a.evidenceMin === b.evidenceMin
  );
}

export function EvidenceReviewPanel({
  result,
  query,
  onRoutedChange,
  onOverride,
  sortExcludedBy = "contradictsPremise",
}: EvidenceReviewPanelProps): React.ReactElement {
  // Sliders start on the actual thresholds the pruner used.
  const [thresholds, setThresholds] = useState<PruneThresholds>(() => ({
    ...DEFAULT_THRESHOLDS,
  }));
  // Overrides are local to THIS review session and keyed by chunk id. They are
  // reset by the caller (via `key={refreshNonce}`) when a new PruneResult arrives,
  // because an override is a statement about the evidence in front of you, and
  // that evidence is gone.
  const [overrides, setOverrides] = useState<Record<string, Route>>({});

  // Recompute every row's proposed route whenever thresholds or overrides change.
  // Sixty chunks, four comparisons each — microseconds. No debounce needed.
  const rows: Row[] = useMemo(() => {
    return [...result.evidence, ...result.conflict, ...result.excluded].map((j) => {
      const { route: proposed, reason } = route(j.readings, thresholds);
      const override = overrides[j.chunk.id];
      return {
        judgement: j,
        proposed: override ?? proposed,
        proposedReason: override ? `override: ${override}` : reason,
        original: j.route,
      };
    });
  }, [result, thresholds, overrides]);

  const proposedByLane = useMemo(() => {
    const buckets: Record<Route, Row[]> = {
      evidence: [],
      conflict: [],
      excluded: [],
    };
    for (const row of rows) buckets[row.proposed].push(row);
    if (sortExcludedBy) {
      buckets.excluded.sort(
        (a, b) =>
          b.judgement.readings[sortExcludedBy] -
          a.judgement.readings[sortExcludedBy],
      );
    }
    return buckets;
  }, [rows, sortExcludedBy]);

  // Notify the parent only when the effective routing actually changes.
  const routing: EffectiveRouting = useMemo(() => {
    const out: Record<string, Route> = {};
    for (const row of rows) out[row.judgement.chunk.id] = row.proposed;
    return out;
  }, [rows]);

  useEffect(() => {
    onRoutedChange?.(routing);
  }, [routing, onRoutedChange]);

  const setThreshold = (key: keyof PruneThresholds, value: number) =>
    setThresholds((t) => ({ ...t, [key]: value }));

  const revert = () => {
    setThresholds({ ...DEFAULT_THRESHOLDS });
    setOverrides({});
  };

  const copyThresholds = () => {
    const serialised = `export const PRUNE_THRESHOLDS: PruneThresholds = ${JSON.stringify(
      thresholds,
      null,
      2,
    )};`;
    void navigator.clipboard.writeText(serialised);
  };

  const pin = (chunkId: string, target: Route) => {
    setOverrides((o) => ({ ...o, [chunkId]: target }));
    onOverride?.(chunkId, target);
  };

  const isCustomised = !thresholdsEqual(thresholds, DEFAULT_THRESHOLDS) ||
    Object.keys(overrides).length > 0;

  return (
    <section aria-label="Evidence review panel" className="erp">
      <header className="erp-header">
        <h2>{query}</h2>
        <p className="erp-meta">
          {result.evidence.length + result.conflict.length + result.excluded.length} chunks ·
          pruned in {result.elapsedMs.toFixed(0)}ms by {result.model}
          {result.degraded ? " · DEGRADED: pruning did not complete" : ""}
        </p>
      </header>

      <div className="erp-sliders" role="group" aria-label="Thresholds">
        {(Object.keys(DEFAULT_THRESHOLDS) as (keyof PruneThresholds)[]).map((key) => (
          <label key={key} className="erp-slider">
            <span>{key} = {thresholds[key].toFixed(2)}</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={thresholds[key]}
              onChange={(e) => setThreshold(key, Number(e.target.value))}
              aria-valuetext={`${key} threshold at ${thresholds[key].toFixed(2)}`}
            />
          </label>
        ))}
      </div>

      <div className="erp-summary" aria-live="polite">
        {LANES.map((lane) => (
          <span key={lane}>
            {LANE_LABEL[lane]}: {proposedByLane[lane].length}
          </span>
        ))}
      </div>

      <div className="erp-actions">
        <button type="button" onClick={revert} disabled={!isCustomised}>
          Revert to pruner thresholds
        </button>
        <button type="button" onClick={copyThresholds}>
          Copy thresholds
        </button>
      </div>

      {LANES.map((lane) => (
        <Lane
          key={lane}
          lane={lane}
          rows={proposedByLane[lane]}
          onPin={pin}
        />
      ))}
    </section>
  );
}

interface LaneProps {
  lane: Route;
  rows: Row[];
  onPin: (chunkId: string, target: Route) => void;
}

function Lane({ lane, rows, onPin }: LaneProps): React.ReactElement {
  return (
    <section aria-label={`${LANE_LABEL[lane]} lane`} className={`erp-lane erp-lane-${lane}`}>
      <h3>
        {LANE_LABEL[lane]} <span className="erp-count">({rows.length})</span>
      </h3>
      <ul>
        {rows.map((row) => (
          <PassageRow key={row.judgement.chunk.id} row={row} onPin={onPin} lane={lane} />
        ))}
      </ul>
    </section>
  );
}

interface PassageRowProps {
  row: Row;
  lane: Route;
  onPin: (chunkId: string, target: Route) => void;
}

function PassageRow({ row, lane, onPin }: PassageRowProps): React.ReactElement {
  const { judgement } = row;
  const moved = row.proposed !== row.original;
  return (
    <li className={`erp-row ${moved ? "erp-row-moved" : ""}`}>
      <div className="erp-row-head">
        <strong>{judgement.chunk.title}</strong>
        {moved ? (
          <span className="erp-moved" aria-label={`moved from ${row.original}`}>
            {" "}moved {row.original} → {row.proposed}
          </span>
        ) : null}
        {judgement.chunk.sourceType === "community_forum" ? (
          <span className="erp-source-low">community forum</span>
        ) : null}
      </div>
      <p className="erp-preview">{judgement.chunk.text.slice(0, 160)}…</p>
      <div className="erp-readings">
        {(Object.keys(judgement.readings) as ReadingsKey[]).map((k) => (
          <span key={k} className="erp-reading">
            {READING_LABEL[k]} {judgement.readings[k].toFixed(2)}
          </span>
        ))}
      </div>
      <div className="erp-reason">{row.proposedReason}</div>
      <div className="erp-pin">
        {(["evidence", "conflict", "excluded"] as Route[]).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => onPin(judgement.chunk.id, t)}
            disabled={t === lane}
            aria-label={`Force ${judgement.chunk.id} into ${t}`}
          >
            → {t}
          </button>
        ))}
      </div>
    </li>
  );
}
