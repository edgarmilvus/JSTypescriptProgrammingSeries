/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import type { ChoiceQuestion, TypeSafeClient } from "@typesafe-ai/sdk";
import { choice } from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// Zod boundary — parse, do not cast
// ---------------------------------------------------------------------------

/**
 * What this schema CANNOT check, and why it matters:
 *  - Section existence. `section: "4.1.99"` passes here. Whether that section is
 *    in the source is a property of the source, not of the citation.
 *  - Quote fidelity. `quote: "the JWT MUST be rejected."` passes here even if the
 *    real RFC says "MUST NOT be accepted". Fidelity is checked in step 1.
 *  - Claim semantics. A grammatically well-formed question ("What time is it?")
 *    passes here; that is a claim about the world, and code cannot catch it.
 * The schema is a shape check, not a correctness check. Every gap above is
 * covered by a different mechanism, none of which is a type.
 */
const SectionRef = z.string().regex(/^\d+(?:\.\d+)*$/, {
  message: "section must be a dotted numeric id (e.g. \"4.1.3\")",
});

export const CitationSchema = z.object({
  id: z.string().min(1),
  claim: z.string().min(8),
  section: SectionRef,
  quote: z.string().min(1).nullable(),
});

export const CitationBatchSchema = z.array(CitationSchema).min(1);

export type Citation = z.infer<typeof CitationSchema>;

// ---------------------------------------------------------------------------
// Step 1: code, not model
// ---------------------------------------------------------------------------

const CURLY_MAP = new Map<string, string>([
  ["\u201C", '"'], // left double quote
  ["\u201D", '"'], // right double quote
  ["\u2018", "'"], // left single quote
  ["\u2019", "'"], // right single quote
]);

/** Collapse whitespace and fold curly quotes so a quote matches across line wraps. */
export function normalize(text: string): string {
  let folded = "";
  for (const ch of text) folded += CURLY_MAP.get(ch) ?? ch;
  return folded.replace(/\s+/g, " ").trim();
}

export interface SectionedSource {
  readonly raw: string;
  readonly sections: ReadonlyMap<string, string>;
}

/**
 * Split a document into numbered sections. Written for RFC/documentation-shaped
 * input. A different document shape needs a different splitter; the rest of the
 * pipeline (findQuote, verifyBatch, verdict assembly) is shape-agnostic.
 */
export function splitSections(source: string): SectionedSource {
  const boundary = /^(?:(\d+(?:\.\d+)*)\.\s+[^\n]*)$/gm;
  const marks: { num: string; start: number }[] = [];
  let m: RegExpExecArray | null;
  while ((m = boundary.exec(source)) !== null) {
    marks.push({ num: m[1], start: m.index });
  }
  const sections = new Map<string, string>();
  for (let i = 0; i < marks.length; i++) {
    const next = marks[i + 1];
    const end = next ? next.start : source.length;
    sections.set(marks[i].num, source.slice(marks[i].start, end).trim());
  }
  return { raw: source, sections };
}

/**
 * Sorted by numeric depth, so the section the reader would first encounter wins
 * when a quote appears in more than one section (e.g. a definition and a later
 * reference to it).
 */
function sectionOrder(a: string, b: string): number {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d;
  }
  return 0;
}

/**
 * Returns the section number containing the quote verbatim (after normalisation),
 * or null.
 *
 * NOTE: this is an EXACT match after normalisation. A quote that is lightly
 * reworded, truncated with "…", or has words dropped will be reported as
 * fabricated. For most downstream uses this is the right failure mode — a
 * shuffled quote is a fabrication regardless of intent — but if your generator
 * routinely emits bounded excerpts, you would replace this with a token-overlap
 * or embedding check, and accept the new failure mode where a paraphrase matches
 * text that means something else.
 */
export function findQuote(
  sectioned: SectionedSource,
  quote: string,
): string | null {
  const needle = normalize(quote);
  const keys = [...sectioned.sections.keys()].sort(sectionOrder);
  for (const num of keys) {
    const body = sectioned.sections.get(num)!;
    if (normalize(body).includes(needle)) return num;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Step 2: one Choice question per citation, batched into one request
// ---------------------------------------------------------------------------

export const RELATIONS = ["supports", "contradicts", "says_nothing"] as const;
export type Relation = (typeof RELATIONS)[number];

const RELATION_TO_VERDICT: Record<Relation, "verified" | "contradicted" | "unsupported"> = {
  supports: "verified",
  contradicts: "contradicted",
  says_nothing: "unsupported",
};

function relationQuestion(citationId: string): ChoiceQuestion {
  return choice(
    // Reference the specific pair by path. Structure, not prose.
    `How does \`pairs.${citationId}.section\` relate to the claim in \`pairs.${citationId}.claim\`?`,
    {
      supports:
        "The section states the claim or directly implies that it is true",
      contradicts:
        "The section states the opposite of the claim or implies it is false",
      says_nothing:
        "The section does not address what the claim asserts, either way",
    },
  );
}

interface RelationAnswer {
  choice: Relation;
  confidence: number;
  probabilities: Record<string, number>;
}

// ---------------------------------------------------------------------------
// Verdict: discriminated union
// ---------------------------------------------------------------------------

/**
 * Discriminate on `kind`. The fabricated branch has NO `confidence` field.
 * A caller who writes `v.confidence` without first checking `v.kind === "fabricated"`
 * gets a compile error — the type system enforces the honest representation.
 */
export type CitationVerdict =
  | {
      readonly kind: "verified" | "unsupported" | "contradicted";
      readonly confidence: number;
      readonly auto: boolean;
      readonly model: string;
      readonly probabilities: Readonly<Record<string, number>>;
    }
  | {
      readonly kind: "fabricated";
      readonly auto: true;
      readonly model: string;
      readonly reason: "quote-not-in-source";
    };

export interface CitationCheckResult {
  readonly id: string;
  readonly status: "found" | "missing" | "section-only";
  readonly verdict: CitationVerdict;
}

// ---------------------------------------------------------------------------
// checkCitations
// ---------------------------------------------------------------------------

export interface CheckCitationsOptions {
  model?: string;
  /**
   * Start high (0.8) and lower as you gain evidence. Too high and every
   * near-miss goes to a human, which is correct but expensive; too low and a
   * "contradicted" verdict on a slightly off passage stops the pipeline.
   * Start high. You can always bring it down once you have data.
   */
  autoAccept?: number;
  signal?: AbortSignal;
}

export async function checkCitations(
  client: TypeSafeClient,
  source: SectionedSource,
  rawCitations: unknown,
  options: CheckCitationsOptions = {},
): Promise<CitationCheckResult[]> {
  const model = options.model ?? "jev-latest";
  const autoAccept = options.autoAccept ?? 0.8;

  // Parse at the boundary. A parse failure is a HARD failure — do not skip the
  // bad record and continue. Skipping means the caller cannot see that
  // validation is broken, and a wrong "verified" is far costlier than a loud
  // 500.
  const parsed = CitationBatchSchema.safeParse(rawCitations);
  if (!parsed.success) {
    throw new Error(
      `checkCitations: citation batch failed schema validation: ${parsed.error.message}`,
    );
  }
  const citations = parsed.data;

  // Step 1: locate every quote and build the set of pairs that still need a model.
  interface Located {
    citation: Citation;
    status: "found" | "missing" | "section-only";
    sectionBody: string | null;
    sectionNumber: string | null;
  }
  const located: Located[] = citations.map((citation) => {
    if (citation.quote === null) {
      const body = source.sections.get(citation.section) ?? null;
      return {
        citation,
        status: "section-only",
        sectionBody: body,
        sectionNumber: citation.section,
      };
    }
    const found = findQuote(source, citation.quote);
    if (found === null) {
      return {
        citation,
        status: "missing",
        sectionBody: null,
        sectionNumber: null,
      };
    }
    return {
      citation,
      status: "found",
      sectionBody: source.sections.get(found) ?? null,
      sectionNumber: found,
    };
  });

  // Build the batched state and questions. Only for rows where a model call is
  // justified; `missing` rows never reach the model at all.
  const toAsk = located.filter(
    (l) => l.status !== "missing" && l.sectionBody !== null,
  );

  // Named-field state, keyed by citation id. The question paths reference
  // `pairs.<id>.claim` and `pairs.<id>.section`, so the model always knows which
  // claim it is comparing against which section even when the shapes look alike.
  const pairs: Record<string, { claim: string; section: string }> = {};
  const questions: Record<string, ChoiceQuestion> = {};
  for (const l of toAsk) {
    pairs[l.citation.id] = {
      claim: l.citation.claim,
      section: l.sectionBody!,
    };
    questions[l.citation.id] = relationQuestion(l.citation.id);
  }

  let relationAnswers = new Map<string, RelationAnswer>();
  let responseModel = model;
  if (toAsk.length > 0) {
    const response = await client.systemOne(
      { state: { pairs }, questions, model },
      { signal: options.signal },
    );
    responseModel = response.model;
    for (const l of toAsk) {
      const a = response.answers[l.citation.id];
      // Exhaustive switch on the chosen option. If a fourth option ever gets
      // added to `relationQuestion`, this switch fails to compile — the whole
      // point of typing the answer.
      switch (a.choice) {
        case "supports":
        case "contradicts":
        case "says_nothing":
          relationAnswers.set(l.citation.id, {
            choice: a.choice,
            confidence: a.confidence,
            probabilities: a.probabilities as Record<string, number>,
          });
          break;
        default: {
          const exhaustive: never = a.choice;
          throw new Error(
            `checkCitations: unexpected relation choice ${String(exhaustive)}`,
          );
        }
      }
    }
  }

  // Fold step 1 and step 2 into one verdict per citation.
  return located.map<CitationCheckResult>((l) => {
    if (l.status === "missing") {
      return {
        id: l.citation.id,
        status: "missing",
        verdict: {
          kind: "fabricated",
          auto: true, // string match is definitive; no human needed
          model: responseModel,
          reason: "quote-not-in-source",
        },
      };
    }
    const answer = relationAnswers.get(l.citation.id);
    if (!answer) {
      // Should be impossible: toAsk contained this row.
      throw new Error(
        `checkCitations: no model answer for ${l.citation.id} despite section being present`,
      );
    }
    return {
      id: l.citation.id,
      status: l.status,
      verdict: {
        kind: RELATION_TO_VERDICT[answer.choice],
        confidence: answer.confidence,
        auto: answer.confidence >= autoAccept,
        model: responseModel,
        probabilities: answer.probabilities,
      },
    };
  });
}
