/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import type { TypeSafeClient } from "@typesafe-ai/sdk";

/** One passage as it arrives from your retriever, before Jev has seen it. */
export interface RetrievedChunk {
  /** Stable within a single request. Use it as the question id suffix. */
  id: string;
  title: string;
  text: string;
  /** Your retriever's own score. Jev never sees this; code may use it as a tiebreak. */
  score: number;
  sourceType: "official_documentation" | "community_forum" | "internal_wiki";
}

/** One Jev judgement about one passage, kept verbatim for the audit log. */
export interface ChunkJudgement {
  chunk: RetrievedChunk;
  /** P(true) for each Noul question, keyed by the question's role, not its id. */
  readings: {
    isRelevant: number;
    containsEvidence: number;
    contradictsPremise: number;
    containsInjection: number;
  };
  route: "evidence" | "conflict" | "excluded";
  /** Which threshold fired, so a human can see the reasoning without re-running. */
  reason: string;
}

export interface PruneResult {
  evidence: ChunkJudgement[];
  conflict: ChunkJudgement[];
  excluded: ChunkJudgement[];
  /** Wall-clock milliseconds for the single Jev round trip. */
  elapsedMs: number;
  /** The versioned model id Jev reported back, not the alias you asked for. */
  model: string;
}

export async function pruneContext(
  client: TypeSafeClient,
  query: string,
  candidates: RetrievedChunk[],
  options?: { model?: string; thresholds?: Partial<PruneThresholds> },
): Promise<PruneResult>;
