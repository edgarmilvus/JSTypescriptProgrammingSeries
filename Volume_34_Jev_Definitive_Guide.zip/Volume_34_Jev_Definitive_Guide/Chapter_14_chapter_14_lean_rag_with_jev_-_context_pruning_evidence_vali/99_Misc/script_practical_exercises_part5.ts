/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

export interface RagGraphState {
  /** The immutable input. */
  readonly request: {
    readonly query: string;
    readonly userId: string;
    readonly receivedAt: string;
  };

  /** Set by the retrieve node. */
  retrieved?: RetrievedChunk[];

  /** Set by the prune node. Exercises 1 and 3 both feed this. */
  pruned?: PruneResult;

  /** Which thresholds were in force, so the routing can be re-derived later. */
  thresholdsUsed?: Readonly<PruneThresholds>;

  /** Set by the assess node: the numbers the gates read. */
  assessment?: {
    /** The highest contradiction reading across all chunks. */
    maxContradiction: number;
    /** The lowest relevance reading among the accepted chunks. */
    minAcceptedRelevance: number;
    /** How many accepted chunks there are, counted in code. */
    acceptedCount: number;
    /** Whether every accepted chunk came back above the auto-accept bar. */
    allHighConfidence: boolean;
  };

  /** Set by whichever answer node ran. */
  answer?: {
    readonly speed: "fast" | "slow";
    readonly text: string;
    readonly model: string;
  };

  /** Append-only. Every node appends; nothing rewrites an earlier entry. */
  trace: TraceEntry[];
}

export interface TraceEntry {
  node: string;
  at: string;
  elapsedMs: number;
  note: string;
}
