/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * hello-cascade.ts
 * -------------------------------------------------------------
 * Hello World: the minimal Jev SDE Cascade for a SaaS invoice intake.
 *
 *   Tier 0  deterministic regex extraction        (fast, cheap, brittle)
 *   Tier 1  Jev Noul verification battery         (sub-100ms, calibrated)
 *   Tier 2  generative repair on a flagged field  (slow, expensive, smart)
 *
 * Only the fields that fail verification pay for Tier 2.
 *
 * Usage:
 *   export TYPESAFE_API_KEY=sk_typesafe_...
 *   npx tsx hello-cascade.ts
 */

import {
  noul,
  TypeSafeClient,
  type NoulResponse,
} from "@typesafe-ai/sdk";

// ============================================================== types

/** The four fields the SaaS invoice-intake endpoint promises to return. */
export interface InvoiceRecord {
  invoiceNumber: string;
  vendorName: string;
  totalAmount: string;
  dueDate: string;
}

export type FieldName = keyof InvoiceRecord;

/**
 * One per-field reason to escalate. Produced only by Tier 1.
 * `metric` mirrors the question id suffix so logs are greppable.
 */
export interface FieldFlag {
  field: FieldName;
  metric: "absence_wrong" | "hallucinated" | "format_violation";
  probability: number;
}

/** What the cascade hands back to the caller. */
export interface CascadeResult {
  record: InvoiceRecord;
  tier: 0 | 2;
  flags: FieldFlag[];
}

/**
 * The shape of the Tier 2 escape hatch. Pulled out as an interface so the
 * demo can inject a mock, and production can inject a real reasoning-model
 * call without touching `cascade`.
 */
export type RepairFn = (
  text: string,
  record: InvoiceRecord,
  flags: FieldFlag[]
) => Promise<InvoiceRecord>;

// ========================================================== constants

/** Any Noul answer above this probability becomes a FieldFlag. */
const FIRE_THRESHOLD = 0.7;

/** The cascade's field order, and the battery's coverage checklist. */
const FIELDS: FieldName[] = [
  "invoiceNumber",
  "vendorName",
  "totalAmount",
  "dueDate",
];

/**
 * Per-field reference material. Every verification question ships one of
 * these on its `instructions` object so the model does not have to infer
 * what "dueDate" means from its name alone.
 */
const FIELD_SPECS: Record<FieldName, { description: string; format: string }> = {
  invoiceNumber: {
    description: "The invoice's own identifier, as printed on the document.",
    format: "A short alphanumeric token such as INV-2201.",
  },
  vendorName: {
    description: "The party who issued the invoice and is owed payment.",
    format: "A company name.",
  },
  totalAmount: {
    description: "The full amount owed, in the document's currency.",
    format: "A currency amount such as 4,200.00 or $4,200.00.",
  },
  dueDate: {
    description: "The calendar date by which the invoice must be paid.",
    format: "A calendar date such as September 15, 2026.",
  },
};

// ================================================== tier 0: extraction

/**
 * Tier 0. Four regexes, no network. This is the fast path; it is expected
 * to miss some inputs and to occasionally capture the wrong span. Tier 1
 * exists to catch exactly that.
 */
function tier0Extract(text: string): InvoiceRecord {
  const invoiceNumber = text.match(/\bINV-\d+\b/)?.[0] ?? "";
  const vendorName = text.split("\n")[0]?.trim() ?? "";
  const totalAmount =
    text.match(/amount due[^\d$]{0,20}\$?([\d,]+\.\d{2})/i)?.[1] ?? "";
  const dueDate =
    text.match(
      /(?:due|payable|settle)[^\d]{0,20}([A-Z][a-z]+ \d{1,2},\s*\d{4})/i
    )?.[1] ?? "";
  return { invoiceNumber, vendorName, totalAmount, dueDate };
}

// ================================================= tier 1: verification

/** True when the tier-0 extractor returned nothing for a field. */
function isEmptyField(value: string): boolean {
  return value.trim().length === 0;
}

/**
 * Build the Noul battery: one or two questions per field, keyed
 * `field::metric` so the answer map can be read back without a lookup table.
 *
 *  - Empty field  -> one `absence_wrong` question (did we miss something the
 *                    source actually contains?).
 *  - Filled field -> one `hallucinated` and one `format_violation` question.
 *
 * Every question carries a structured `instructions` object. The model sees
 * the field's spec, the extracted value, and the exact test in one place,
 * which is what keeps a seven-question battery cheap and unambiguous.
 */
function buildVerificationQuestions(record: InvoiceRecord) {
  const questions: Record<string, ReturnType<typeof noul>> = {};
  for (const field of FIELDS) {
    const value = record[field];
    const field_spec = FIELD_SPECS[field];

    if (isEmptyField(value)) {
      questions[`${field}::absence_wrong`] = noul(
        {
          field_spec,
          extracted_field: value,
          main_question:
            "The extracted field is empty. Does the source text contain " +
            "the information this field describes, making the empty result wrong?",
        },
        {
          true: "A value was wrongly omitted",
          false: "Returning nothing is correct",
        }
      );
      continue;
    }

    questions[`${field}::hallucinated`] = noul(
      {
        field_spec,
        extracted_field: value,
        main_question:
          "Is the `extracted_field` unsupported by, or absent from, the source text?",
      },
      {
        true: "The extracted field is not supported by the source text",
        false: "The extracted field is supported by the source text",
      }
    );

    questions[`${field}::format_violation`] = noul(
      {
        field_spec,
        extracted_field: value,
        main_question:
          "Does the `extracted_field` violate the format the `field_spec` implies?",
      },
      {
        true: "The extracted field violates the implied format",
        false: "The extracted field satisfies the implied format",
      }
    );
  }
  return questions;
}

/**
 * Tier 1. One `systemOne` call answers every field question at once, in
 * parallel, against the same state. Each answer is a `NoulResponse` whose
 * `.noul` is P(true). Anything above FIRE_THRESHOLD becomes a FieldFlag.
 */
async function tier1Verify(
  client: TypeSafeClient,
  text: string,
  record: InvoiceRecord
): Promise<FieldFlag[]> {
  const questions = buildVerificationQuestions(record);
  const response = await client.systemOne({
    state: { source_text: text, extraction: record },
    questions,
  });

  const flags: FieldFlag[] = [];
  for (const [qid, answer] of Object.entries(response.answers)) {
    const [field, metric] = qid.split("::") as [FieldName, FieldFlag["metric"]];
    const probability = (answer as NoulResponse).noul;
    if (probability > FIRE_THRESHOLD) {
      flags.push({ field, metric, probability });
    }
  }
  return flags;
}

// =================================================== the cascade itself

/**
 * The three-tier decision. Returns a Tier 0 record when Jev is happy with
 * every field, and a Tier 2 record when at least one field is flagged.
 *
 * `flags` is always returned — even on a Tier 0 win — so the caller can log
 * what a near-miss looked like and tune FIRE_THRESHOLD against real traffic.
 */
export async function cascade(
  client: TypeSafeClient,
  text: string,
  repair: RepairFn
): Promise<CascadeResult> {
  const tier0Record = tier0Extract(text);
  const flags = await tier1Verify(client, text, tier0Record);

  if (flags.length === 0) {
    return { record: tier0Record, tier: 0, flags };
  }

  const tier2Record = await repair(text, tier0Record, flags);
  return { record: tier2Record, tier: 2, flags };
}

// ============================================================== the demo

const DEMO_TEXT = `ACME Cloud Services
Invoice INV-2201
Amount due: $4,200.00
Please settle by the 15th of September, 2026.
`;

/**
 * A stand-in for an LLM repair call. Tier 0's date regex only matches
 * "Month D, YYYY", so it misses "15th of September, 2026". A real model
 * reading the flag would fix that field and leave the others alone.
 */
const demoRepair: RepairFn = async (text) => {
  const m = text.match(
    /(\d{1,2})(?:st|nd|rd|th)\s+of\s+([A-Z][a-z]+),\s*(\d{4})/
  );
  return {
    invoiceNumber: text.match(/\bINV-\d+\b/)?.[0] ?? "",
    vendorName: text.split("\n")[0]?.trim() ?? "",
    totalAmount:
      text.match(/amount due[^\d$]{0,20}\$?([\d,]+\.\d{2})/i)?.[1] ?? "",
    dueDate: m ? `${m[2]} ${m[1]}, ${m[3]}` : "",
  };
};

/**
 * Runnable entry point. In a real web app, this body is the POST handler
 * for /api/invoices/extract; the only difference is that `Request`/`Response`
 * replace `console.log`.
 */
async function main(): Promise<void> {
  const client = new TypeSafeClient();
  try {
    const result = await cascade(client, DEMO_TEXT, demoRepair);
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error("Cascade failed:", error);
    process.exitCode = 1;
  }
}

main();
