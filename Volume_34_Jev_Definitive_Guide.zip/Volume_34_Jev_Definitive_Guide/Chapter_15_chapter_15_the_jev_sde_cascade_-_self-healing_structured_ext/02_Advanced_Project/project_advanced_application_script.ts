/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/extract-invoice/route.ts
 *
 * A two-speed SDE cascade for invoice extraction.
 *   Rung 0 (regex, isomorphic) -> Rung 1 (cheap LLM) -> Jev verify -> Rung 2 (reasoning)
 *
 * The expensive rung only runs when a Jev Noul battery fires above threshold.
 * Every document writes one row to Supabase so the cascade is observable after the fact.
 */

import { NextRequest, NextResponse } from 'next/server';
import { TypeSafeClient, noul, type NoulQuestion } from '@typesafe-ai/sdk';
import { createClient as createSb } from '@supabase/supabase-js';

/* ------------------------------------------------------------- 1. Public types */

export type ExtractedField = string | number | null;
export type ExtractionRecord = Record<string, ExtractedField>;

export interface FieldSpec {
  path: string;
  type: 'string' | 'number';
  description: string;
  required: boolean;
}

export interface FiredSignal {
  field: string;
  metric: string;
  probability: number;
}

export interface CascadeResult {
  record: ExtractionRecord;
  provenance: { rung: 'regex' | 'cheap' | 'reasoning'; verified: boolean; repaired: boolean };
  fired: FiredSignal[];
  latencyMs: number;
  model: string;
  usage: { inputTokens: number; outputTokens: number };
}

/* ------------------------------------------------------------------ 2. Schema */

const SPEC: FieldSpec[] = [
  { path: 'invoice_number', type: 'string', description: 'The unique invoice identifier, e.g. "INV-2087".', required: true },
  { path: 'total_due',      type: 'number', description: 'The total the customer must pay, in USD, without the currency symbol.', required: true },
  { path: 'currency',       type: 'string', description: 'ISO 4217 currency code, e.g. "USD".', required: true },
  { path: 'due_date',       type: 'string', description: 'The date payment is due, ISO 8601 (YYYY-MM-DD).', required: true },
];

/* ------------------------------------------ 3. Rung 0 — deterministic parser (isomorphic) */

/**
 * Runs in under a millisecond, never touches the network, and returns `null` on any
 * doubt so the LLM rungs can handle the field. Pure TypeScript means the same
 * function ships to the browser for an instant preview.
 */
export function rungZero(source: string, spec: FieldSpec): ExtractedField {
  if (spec.path === 'invoice_number') {
    const m = source.match(/\b(?:INV|INVOICE)[-\s]?([A-Z0-9]{3,})\b/i);
    return m ? `INV-${m[1].toUpperCase()}` : null;
  }
  if (spec.path === 'total_due') {
    const m = source.match(/total\s+due[^$]*\$?\s*([\d,]+\.\d{2})/i);
    return m ? Number(m[1].replace(/,/g, '')) : null;
  }
  if (spec.path === 'currency') {
    return /USD|US\$|\$/.test(source) ? 'USD' : null;
  }
  // due_date formats vary too much to regex with confidence.
  return null;
}

/* ------------------------------------------------ 4. LLM rungs (injected for testability) */

type LlmRung = (source: string, missing: FieldSpec[], hints?: Record<string, string>) => Promise<ExtractionRecord>;

let callCheapLlm: LlmRung = async () => { throw new Error('callCheapLlm not wired'); };
let callReasoningLlm: LlmRung = async () => { throw new Error('callReasoningLlm not wired'); };

/** Wire the two LLM rungs at app bootstrap. Keeps the route decoupled from any one vendor. */
export function wireLlmRungs(cheap: LlmRung, reasoning: LlmRung): void {
  callCheapLlm = cheap;
  callReasoningLlm = reasoning;
}

/* ------------------------------------------------ 5. Jev verification battery */

const VERIFY_THRESHOLD = 0.70;

const METRICS = {
  hallucinated: {
    q: 'Is `extracted_field` a hallucination — absent from `source_text` or unsupported by its context?',
    t: 'The value does not appear in the source or is contradicted by it.',
    f: 'The value is supported by the source text.',
  },
  off_target: {
    q: 'Does `source_text` fail to genuinely report the field `field_spec` describes, so the value was pulled from incidental text?',
    t: 'The source does not genuinely provide this field.',
    f: 'The source genuinely reports this field.',
  },
  format_violation: {
    q: 'Does `extracted_field` violate the format implied by `field_spec` (ISO 8601 date, bare number, ISO currency)?',
    t: 'The value violates the implied format.',
    f: 'The value satisfies the format.',
  },
} as const;

/** One Jev request, all Noul questions, thresholded into a set of fired signals. */
export async function verifyWithJev(
  jev: TypeSafeClient,
  source: string,
  spec: FieldSpec[],
  record: ExtractionRecord,
): Promise<{ fired: FiredSignal[]; model: string; usage: { inputTokens: number; outputTokens: number } }> {
  const questions: Record<string, NoulQuestion> = {};
  for (const field of spec) {
    const value = record[field.path];
    if (value == null || value === '') {
      questions[`${field.path}::absence_wrong`] = noul(
        { field_spec: field, extracted_field: value, main_question: 'The field is empty. Does the source contain a value for it?' },
        { true: 'A required value was wrongly omitted.', false: 'Returning nothing is correct.' },
      );
      continue;
    }
    for (const [metric, def] of Object.entries(METRICS)) {
      questions[`${field.path}::${metric}`] = noul(
        { field_spec: field, extracted_field: value, main_question: def.q },
        { true: def.t, false: def.f },
      );
    }
  }

  const res = await jev.systemOne({
    state: { source_text: source, extraction: record },
    questions,
  });

  const fired: FiredSignal[] = Object.entries(res.answers)
    .filter(([, a]) => a.type === 'noul' && a.noul > VERIFY_THRESHOLD)
    .map(([id, a]) => {
      const [field, metric] = id.split('::');
      return { field, metric, probability: (a as { noul: number }).noul };
    });

  return {
    fired,
    model: res.model,
    usage: { inputTokens: res.usage.input_tokens, outputTokens: res.usage.output_tokens },
  };
}

/* ------------------------------------------------ 6. Circuit breaker for the expensive rung */

class CircuitBreaker {
  private failures = 0;
  private openedAt = 0;
  constructor(private readonly threshold = 5, private readonly cooldownMs = 30_000) {}
  isOpen(): boolean {
    return this.failures >= this.threshold && Date.now() - this.openedAt < this.cooldownMs;
  }
  recordSuccess(): void { this.failures = 0; this.openedAt = 0; }
  recordFailure(): void { this.failures += 1; this.openedAt = Date.now(); }
}
const breaker = new CircuitBreaker();

/* ------------------------------------------------ 7. Repair hints derived from Jev signals */

function hintsFrom(fired: FiredSignal[]): Record<string, string> {
  const hints: Record<string, string> = {};
  for (const f of fired) hints[f.field] = `${f.metric} (p=${f.probability.toFixed(2)})`;
  return hints;
}

/* ------------------------------------------------ 8. Route handler — the cascade itself */

export async function POST(req: NextRequest): Promise<NextResponse> {
  const started = Date.now();
  const jev = new TypeSafeClient({ apiKey: process.env.TYPESAFE_API_KEY! });
  const sb = createSb(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

  let record: ExtractionRecord = {};
  let rung: CascadeResult['provenance']['rung'] = 'regex';
  let fired: FiredSignal[] = [];
  let model = 'none';
  let usage = { inputTokens: 0, outputTokens: 0 };

  try {
    const { source } = (await req.json()) as { source: string };

    // 8a. Rung 0 — free, synchronous, high-precision-only.
    for (const field of SPEC) {
      const v = rungZero(source, field);
      if (v !== null) record[field.path] = v;
    }

    // 8b. Rung 1 — fill only the gaps with the cheap model.
    const missing = SPEC.filter((f) => record[f.path] == null);
    if (missing.length > 0) {
      record = { ...record, ...(await callCheapLlm(source, missing)) };
      rung = 'cheap';
    }

    // 8c. Jev verification — one request, every Noul question, one round trip.
    const verdict = await verifyWithJev(jev, source, SPEC, record);
    fired = verdict.fired;
    model = verdict.model;
    usage = verdict.usage;

    // 8d. Escalation gate — pay for reasoning only if a signal fired and the breaker is closed.
    let repaired = false;
    if (fired.length > 0 && !breaker.isOpen()) {
      try {
        record = await callReasoningLlm(source, SPEC, hintsFrom(fired));
        rung = 'reasoning';
        repaired = true;
        breaker.recordSuccess();
      } catch {
        breaker.recordFailure();
        // Keep the cheap extraction; the caller routes to human review via `fired`.
      }
    }

    // 8e. Telemetry — durable, off the response critical path.
    void sb.from('extraction_traces').insert({
      tenant_id: req.headers.get('x-tenant-id'),
      rung,
      repaired,
      model,
      fired,
      latency_ms: Date.now() - started,
      input_tokens: usage.inputTokens,
      output_tokens: usage.outputTokens,
    });

    return NextResponse.json({
      record,
      provenance: { rung, verified: fired.length === 0, repaired },
      fired,
      latencyMs: Date.now() - started,
      model,
      usage,
    } satisfies CascadeResult);
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  } finally {
    // No pooled handles to release today, but the contract is written in so that adding
    // one later (an Anthropic stream, a Postgres connection) cannot accidentally skip it.
  }
}
