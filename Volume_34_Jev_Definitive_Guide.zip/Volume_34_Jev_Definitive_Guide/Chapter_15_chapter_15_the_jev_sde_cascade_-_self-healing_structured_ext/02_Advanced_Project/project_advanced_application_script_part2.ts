/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

-- Which rung is doing the work, per tenant, this week?
SELECT tenant_id, rung, count(*)
FROM extraction_traces
WHERE created_at > now() - interval '7 days'
GROUP BY tenant_id, rung
ORDER BY tenant_id, count DESC;

-- Which fields fire most, and does firing predict that rung 2 changes the value?
SELECT
  jsonb_array_elements(fired)->>'field' AS field,
  jsonb_array_elements(fired)->>'metric' AS metric,
  count(*)                               AS firings,
  sum(CASE WHEN repaired THEN 1 ELSE 0 END) AS repairs,
  avg(latency_ms)                        AS avg_latency
FROM extraction_traces
WHERE created_at > now() - interval '30 days'
GROUP BY 1, 2
ORDER BY firings DESC;
