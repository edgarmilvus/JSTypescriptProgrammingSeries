/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// cascade/types.ts — the shared contract
import {
  TypeSafeClient,
  choice,
  noul,
  type ChoiceResponse,
  type NoulResponse,
} from "@typesafe-ai/sdk";

export interface IntakeRecord {
  policy_number: string;
  loss_date: string;            // mm/dd/yyyy
  loss_type: string;            // collision | theft | fire | water | wind | vandalism
  estimated_amount_usd: string; // bare number, no currency symbol
  description: string;
}

export type ExtractionTier = "deterministic" | "jev_verified" | "jev_repaired";

export interface FieldVerdict {
  readonly field: keyof IntakeRecord;
  readonly hazards: Readonly<Record<string, number>>;
  readonly worstHazard: string;
  readonly worstProbability: number;
}

export type EscalationReason =
  | { readonly kind: "tier0_incomplete"; readonly missing: ReadonlyArray<string> }
  | { readonly kind: "tier0_out_of_range"; readonly field: string; readonly value: unknown }
  | { readonly kind: "verification_fired"; readonly field: string; readonly hazard: string; readonly probability: number }
  | { readonly kind: "verification_uncertain"; readonly field: string; readonly probability: number };

export interface CascadeOutcome {
  readonly record: IntakeRecord;
  readonly tier: ExtractionTier;
  readonly repairedFields: ReadonlyArray<keyof IntakeRecord>;
  readonly verdicts: ReadonlyArray<FieldVerdict>;
  readonly timingsMs: Readonly<Record<ExtractionTier, number>>;
  readonly escalationReason: EscalationReason | null;
  readonly usage: { readonly inputTokens: number; readonly outputTokens: number };
}

// -------------------------------------------------------------------------
// Constants — the only place thresholds live.
// -------------------------------------------------------------------------
const REQUIRED_FIELDS = [
  "policy_number", "loss_date", "loss_type", "estimated_amount_usd", "description",
] as const satisfies ReadonlyArray<keyof IntakeRecord>;

const FIELD_DESCRIPTIONS: Readonly<Record<keyof IntakeRecord, string>> = {
  policy_number: "the insurance policy number, formatted like POL-1234567",
  loss_date: "the date of loss, formatted mm/dd/yyyy",
  loss_type: "the category of loss: collision, theft, fire, water, wind, or vandalism",
  estimated_amount_usd: "the estimated loss amount in US dollars, as a bare number without a currency symbol",
  description: "a short prose summary of what happened",
};

const LOSS_TYPES = ["collision", "theft", "fire", "water", "wind", "vandalism"] as const;
const MAX_CANDIDATES = 8;
const HAZARD_THRESHOLD = 0.7;
const MAX_AMOUNT_USD = 10_000_000;
const MIN_LOSS_YEAR = 1970;

// -------------------------------------------------------------------------
// Tier 0 — deterministic, pure, synchronous.
// -------------------------------------------------------------------------
interface Tier0Result {
  readonly record: Partial<IntakeRecord>;
  readonly candidates: Partial<Record<keyof IntakeRecord, ReadonlyArray<string>>>;
  readonly missing: ReadonlyArray<keyof IntakeRecord>;
  readonly outOfRange: ReadonlyArray<{ readonly field: keyof IntakeRecord; readonly value: unknown }>;
}

const dedupe = <T,>(xs: readonly T[]): T[] => [...new Set(xs)];

function tier0Parse(document: string, now: () => number): Tier0Result {
  const record: Partial<IntakeRecord> = {};
  const candidates: Partial<Record<keyof IntakeRecord, readonly string[]>> = {};

  // Policy number — bounded pattern; no `[\s\S]*` and no word-boundary games that would
  // let the match run across a sentence and swallow the next field's label.
  const policyMatches = [...document.matchAll(/\b(POL-[A-Z0-9]{4,12})\b/gi)].map(m => m[1]);
  candidates.policy_number = dedupe(policyMatches).slice(0, MAX_CANDIDATES);
  if (candidates.policy_number[0]) record.policy_number = candidates.policy_number[0];

  // Loss date — prefer an explicit mm/dd/yyyy over words; collect every candidate so
  // tier 2 has something to pick between.
  const dateMatches = [...document.matchAll(/\b(\d{2}\/\d{2}\/\d{4})\b/g)].map(m => m[1]);
  candidates.loss_date = dedupe(dateMatches).slice(0, MAX_CANDIDATES);
  if (candidates.loss_date[0]) record.loss_date = candidates.loss_date[0];

  // Loss type — roster terms actually present, in roster order.
  const present = LOSS_TYPES.filter(t => new RegExp(`\\b${t}\\b`, "i").test(document));
  candidates.loss_type = present.map(t => t.toLowerCase());
  if (candidates.loss_type[0]) record.loss_type = candidates.loss_type[0];

  // Amount — capture the digits, drop the symbol at the door.
  const amountMatches = [...document.matchAll(/\$\s?([\d,]+(?:\.\d{2})?)/g)]
    .map(m => m[1].replace(/,/g, ""));
  candidates.estimated_amount_usd = dedupe(amountMatches).slice(0, MAX_CANDIDATES);
  if (candidates.estimated_amount_usd[0]) record.estimated_amount_usd = candidates.estimated_amount_usd[0];

  // Description — the labelled body if the document has one, otherwise the head of the text.
  const labelled = /description[:\s]+([^\n]{20,400})/i.exec(document);
  const body = labelled?.[1]?.trim() ?? document.trim().slice(0, 400);
  if (body) {
    record.description = body;
    candidates.description = [body];
  }

  // Range validation — deterministic, no model involved.
  const outOfRange: Array<{ field: keyof IntakeRecord; value: unknown }> = [];
  if (record.estimated_amount_usd) {
    const n = Number(record.estimated_amount_usd);
    if (!Number.isFinite(n) || n < 0 || n > MAX_AMOUNT_USD) {
      outOfRange.push({ field: "estimated_amount_usd", value: record.estimated_amount_usd });
      delete record.estimated_amount_usd;
    }
  }
  if (record.loss_date) {
    const [mm, dd, yyyy] = record.loss_date.split("/").map(Number);
    const currentYear = new Date(now()).getUTCFullYear();
    const sane = mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31
              && yyyy >= MIN_LOSS_YEAR && yyyy <= currentYear + 1;
    if (!sane) {
      outOfRange.push({ field: "loss_date", value: record.loss_date });
      delete record.loss_date;
    }
  }

  const missing = REQUIRED_FIELDS.filter(f => !record[f]);
  return { record, candidates, missing, outOfRange };
}

// -------------------------------------------------------------------------
// Tier 1 questions — one structured question per field, per hazard.
// -------------------------------------------------------------------------
type NoulQuestion = ReturnType<typeof noul>;
type ChoiceQuestion = ReturnType<typeof choice>;

function hazardQuestions(field: keyof IntakeRecord, value: string): Record<string, NoulQuestion> {
  const field_spec = { path: field, type: "string", description: FIELD_DESCRIPTIONS[field] };
  const build = (main_question: string, yes: string, no: string): NoulQuestion =>
    noul({ field_spec, extracted_field: value, main_question }, { true: yes, false: no });

  return {
    absent_from_source: build(
      "Is the `extracted_field` unsupported by, or absent from, the `source_text`?",
      "The value is unsupported by the source text — a hallucination.",
      "The value is supported by the source text.",
    ),
    name_desc_mismatch: build(
      "Does the `extracted_field` fail to match the field name or its `field_spec.description`?",
      "The value does not match the field's declared meaning.",
      "The value matches the field's declared meaning.",
    ),
    format_violation: build(
      "Does the `extracted_field` violate the format or constraints implied by `field_spec`?",
      "The value violates the implied format.",
      "The value satisfies the implied format.",
    ),
    off_target: build(
      "Was the `extracted_field` pulled from incidental text rather than genuinely reporting what `field_spec` describes?",
      "The value was pulled from incidental text.",
      "The source genuinely reports this field.",
    ),
  };
}

function absenceQuestion(field: keyof IntakeRecord): NoulQuestion {
  return noul(
    {
      field_spec: { path: field, type: "string", description: FIELD_DESCRIPTIONS[field] },
      extracted_field: "",
      main_question:
        "The `extracted_field` is empty. Does the source text contain the information the `field_spec` describes, making the empty result wrong?",
    },
    {
      true: "A value was wrongly omitted.",
      false: "Returning nothing is correct — the source does not contain this information.",
    },
  );
}

interface Verdict {
  readonly field: keyof IntakeRecord;
  readonly hazards: Readonly<Record<string, number>>;
  readonly worstHazard: string;
  readonly worstProbability: number;
  readonly escalate: boolean;
  readonly reason: EscalationReason | null;
}

interface TierUsage { readonly inputTokens: number; readonly outputTokens: number; }

async function tier1Verify(
  client: TypeSafeClient,
  document: string,
  record: Partial<IntakeRecord>,
  signal: AbortSignal | undefined,
): Promise<{ verdicts: Verdict[]; usage: TierUsage }> {
  const questions: Record<string, NoulQuestion> = {};
  for (const field of REQUIRED_FIELDS) {
    const value = record[field];
    if (value) {
      for (const [name, q] of Object.entries(hazardQuestions(field, value))) {
        questions[`${field}::${name}`] = q;
      }
    } else {
      questions[`${field}::absence_wrong`] = absenceQuestion(field);
    }
  }

  const result = await client.systemOne(
    { state: { source_text: document, extraction: record }, questions },
    signal ? { signal } : {},
  );

  const verdicts: Verdict[] = [];
  for (const field of REQUIRED_FIELDS) {
    if (record[field]) {
      const hazards: Record<string, number> = {};
      for (const name of ["absent_from_source", "name_desc_mismatch", "format_violation", "off_target"]) {
        const a = result.answers[`${field}::${name}`];
        if (a?.type === "noul") hazards[name] = (a as NoulResponse).noul;
      }
      // `max`, not `mean`: one confident red flag must escalate. A mean lets a strong
      // signal be averaged into silence by weak ones.
      const [worstHazard, worstProbability] = Object.entries(hazards)
        .reduce<[string, number]>((acc, [k, v]) => (v > acc[1] ? [k, v] : acc), ["", -Infinity]);
      const escalate = worstProbability >= HAZARD_THRESHOLD;
      verdicts.push({
        field, hazards, worstHazard, worstProbability, escalate,
        reason: escalate
          ? { kind: "verification_fired", field, hazard: worstHazard, probability: worstProbability }
          : null,
      });
    } else {
      const a = result.answers[`${field}::absence_wrong`];
      const p = a?.type === "noul" ? (a as NoulResponse).noul : 0;
      const escalate = p >= HAZARD_THRESHOLD;
      verdicts.push({
        field,
        hazards: { absence_wrong: p },
        worstHazard: "absence_wrong",
        worstProbability: p,
        escalate,
        // An empty field that genuinely belongs empty is not a repair target: there is
        // nothing to pick between, so it becomes an uncertainty rather than a fired flag.
        reason: escalate ? { kind: "verification_uncertain", field, probability: p } : null,
      });
    }
  }

  return { verdicts, usage: { inputTokens: result.usage.input_tokens, outputTokens: result.usage.output_tokens } };
}

// -------------------------------------------------------------------------
// Tier 2 — candidate-bound repair. The model chooses; code copies.
// -------------------------------------------------------------------------
function buildCriteria(options: readonly string[]): Record<string, string | null> {
  const criteria: Record<string, string | null> = {};
  for (const o of options) criteria[o] = null;
  criteria["none"] = "None of these is the requested value.";
  return criteria;
}

interface RepairResult {
  readonly repaired: Partial<IntakeRecord>;
  readonly repairedFields: ReadonlyArray<keyof IntakeRecord>;
  readonly uncertain: ReadonlyArray<keyof IntakeRecord>;
  readonly usage: TierUsage;
}

async function tier2Repair(
  client: TypeSafeClient,
  document: string,
  record: Partial<IntakeRecord>,
  escalated: ReadonlyArray<keyof IntakeRecord>,
  candidates: Partial<Record<keyof IntakeRecord, ReadonlyArray<string>>>,
  signal: AbortSignal | undefined,
): Promise<RepairResult> {
  const questions: Record<string, ChoiceQuestion> = {};
  const repairable: Array<keyof IntakeRecord> = [];
  const noCandidates: Array<keyof IntakeRecord> = [];

  for (const field of escalated) {
    const options = candidates[field] ?? [];
    if (options.length === 0) { noCandidates.push(field); continue; }
    repairable.push(field);
    questions[`repair::${field}`] = choice(
      {
        field_spec: { path: field, type: "string", description: FIELD_DESCRIPTIONS[field] },
        main_question: `Which candidate is the correct \`${field}\` for this document?`,
        previous_value: record[field] ?? null,
      },
      buildCriteria(options),
    );
  }

  if (repairable.length === 0) {
    return {
      repaired: { ...record }, repairedFields: [], uncertain: [...noCandidates],
      usage: { inputTokens: 0, outputTokens: 0 },
    };
  }

  const result = await client.systemOne(
    { state: { source_text: document, extraction: record }, questions },
    signal ? { signal } : {},
  );

  const repaired: Partial<IntakeRecord> = { ...record };
  const repairedFields: Array<keyof IntakeRecord> = [];
  const uncertain: Array<keyof IntakeRecord> = [...noCandidates];

  for (const field of repairable) {
    const a = result.answers[`repair::${field}`] as ChoiceResponse<Record<string, null>> | undefined;
    if (a?.type !== "choice") { uncertain.push(field); continue; }
    if (a.choice === "none" || !candidates[field]?.includes(a.choice)) {
      uncertain.push(field);
      // Deliberately do not write back a partial or "best guess". The field stays as
      // it was — a stable failure is better than an unstable repair.
    } else {
      repaired[field] = a.choice; // verbatim copy; no reformatting, no interpolation
      repairedFields.push(field);
    }
  }

  return {
    repaired, repairedFields, uncertain,
    usage: { inputTokens: result.usage.input_tokens, outputTokens: result.usage.output_tokens },
  };
}

// -------------------------------------------------------------------------
// The cascade.
// -------------------------------------------------------------------------
export async function extractWithCascade(
  client: TypeSafeClient,
  document: string,
  options?: { readonly signal?: AbortSignal; readonly now?: () => number },
): Promise<CascadeOutcome> {
  const now = options?.now ?? (() => performance.now());
  const signal = options?.signal;
  const timingsMs: Record<ExtractionTier, number> = { deterministic: 0, jev_verified: 0, jev_repaired: 0 };
  const usage: { inputTokens: number; outputTokens: number } = { inputTokens: 0, outputTokens: 0 };

  // ---- Tier 0 ----
  const t0 = now();
  const parsed = tier0Parse(document, now);
  timingsMs.deterministic = now() - t0;

  const clean = parsed.missing.length === 0 && parsed.outOfRange.length === 0;
  if (clean) {
    return {
      record: parsed.record as IntakeRecord,
      tier: "deterministic",
      repairedFields: [],
      verdicts: [],
      timingsMs,
      escalationReason: null,
      usage,
    };
  }

  // Provisional reason for the audit trail; overwritten by a fired verdict if one exists.
  let escalationReason: EscalationReason | null =
    parsed.outOfRange[0]
      ? { kind: "tier0_out_of_range", field: parsed.outOfRange[0].field, value: parsed.outOfRange[0].value }
      : parsed.missing.length > 0
        ? { kind: "tier0_incomplete", missing: parsed.missing }
        : null;

  // ---- Tier 1 ----
  const t1 = now();
  // `UnprocessableEntityError` and `APIUserAbortError` deliberately propagate uncaught:
  // the former is a bug in our own request shape, the latter is cancellation.
  const verified = await tier1Verify(client, document, parsed.record, signal);
  timingsMs.jev_verified = now() - t1;
  usage.inputTokens += verified.usage.inputTokens;
  usage.outputTokens += verified.usage.outputTokens;

  const fired = verified.verdicts.filter(v => v.escalate);
  if (fired.length === 0) {
    // Nothing fired. Empty required fields whose `absence_wrong` came back low are
    // simply correct: the document does not state them. Reporting `jev_verified` here
    // rather than `jev_repaired` is the design choice the acceptance criteria ask for —
    // tier 2 only earns the name when it actually rewrote a value.
    return {
      record: parsed.record as IntakeRecord,
      tier: "jev_verified",
      repairedFields: [],
      verdicts: verified.verdicts,
      timingsMs,
      escalationReason,
      usage,
    };
  }
  if (!escalationReason && fired[0].reason) escalationReason = fired[0].reason;

  // ---- Tier 2 ----
  const t2 = now();
  const repair = await tier2Repair(
    client, document, parsed.record, fired.map(v => v.field), parsed.candidates, signal,
  );
  timingsMs.jev_repaired = now() - t2;
  usage.inputTokens += repair.usage.inputTokens;
  usage.outputTokens += repair.usage.outputTokens;

  return {
    record: repair.repaired as IntakeRecord,
    tier: "jev_repaired",
    repairedFields: repair.repairedFields,
    verdicts: verified.verdicts,
    timingsMs,
    escalationReason,
    usage,
  };
}
