/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// cascade/failures.ts
import {
  APIUserAbortError,
  APITimeoutError,
  APIConnectionError,
  RateLimitError,
  UnprocessableEntityError,
  APIError,
  TypeSafeClient,
  choice,
  noul,
  type ChoiceResponse,
} from "@typesafe-ai/sdk";
import type { IntakeRecord, ExtractionTier } from "./types";

// -------------------------------------------------------------------------
// The taxonomy. Every variant is separated by *what fixes it*.
// -------------------------------------------------------------------------
export type ExtractionFailure =
  | { kind: "no_candidate"; field: keyof IntakeRecord; reason: "absent" | "ambiguous" }
  | { kind: "parse_failure"; raw: string; offset: number }
  | { kind: "schema_violation"; field: string; expected: string; received: unknown }
  | { kind: "ungrounded"; field: keyof IntakeRecord; probability: number }
  | { kind: "off_target"; field: keyof IntakeRecord; probability: number }
  | { kind: "missing_required"; fields: ReadonlyArray<keyof IntakeRecord> }
  | { kind: "truncated"; raw: string }
  | { kind: "budget_exceeded"; tier: ExtractionTier }
  | { kind: "transport"; retryable: boolean; status?: number; retryAfterMs?: number }
  | { kind: "unclassifiable"; raw: string };

export interface Exemplar {
  readonly field: keyof IntakeRecord;
  readonly sourceSpan: string;
  readonly extractedValue: string;
  readonly similarity: number;
}

/** Defined here; the concrete store (pgvector, in-memory cosine index) is a caller concern. */
export interface ExemplarStore {
  nearest(field: keyof IntakeRecord, context: string, k: number): Promise<readonly Exemplar[]>;
}

export interface RepairPlan {
  readonly field: keyof IntakeRecord;
  readonly strategy:
    | "widen_candidates"
    | "reslice_window"
    | "relax_format"
    | "ask_again_with_exemplars"
    | "escalate_to_generative";
  readonly question: ReturnType<typeof choice> | ReturnType<typeof noul>;
  readonly expectedCost: "cheap" | "moderate" | "expensive";
}

export interface RepairEvent {
  readonly kind: "classified" | "planned" | "attempted" | "succeeded" | "failed" | "terminated";
  readonly field?: keyof IntakeRecord;
  readonly failureKind?: ExtractionFailure["kind"];
  readonly strategy?: RepairPlan["strategy"];
  readonly tier?: ExtractionTier;
  readonly elapsedMs: number;
  readonly attempts: { readonly field: number; readonly total: number };
  readonly usage?: { readonly inputTokens: number; readonly outputTokens: number };
  readonly message?: string;
}

export interface TelemetrySink {
  record(event: RepairEvent): void;
}

export interface RepairBudget {
  readonly maxPerField: number;
  readonly maxPerDocument: number;
  /** Injected so tests do not actually sleep. */
  readonly wait: (ms: number) => Promise<void>;
}

export const DEFAULT_REPAIR_BUDGET: RepairBudget = {
  maxPerField: 2,
  maxPerDocument: 5,
  wait: (ms) => new Promise(resolve => setTimeout(resolve, ms)),
};

// -------------------------------------------------------------------------
// Classify — deterministic first, Jev only as a last resort.
// -------------------------------------------------------------------------
export interface ClassifyContext {
  readonly knownFields: ReadonlyArray<keyof IntakeRecord>;
  readonly documentLength: number;
  readonly maxContextChars: number;
  readonly schema: Readonly<Record<string, { readonly type: string }>>;
}

const MAX_EXCERPT = 240;
const isRecord = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);
const safeStringify = (v: unknown): string => {
  try { return typeof v === "string" ? v : JSON.stringify(v); }
  catch { return String(v); }
};

export function classifyFailure(raw: unknown, ctx: ClassifyContext): ExtractionFailure {
  // --- SDK error classes: exact, zero-cost, definitive. ---
  if (raw instanceof APIUserAbortError) {
    // Cancellation is not a repair signal. Do not classify, do not swallow.
    throw raw;
  }
  if (raw instanceof RateLimitError) {
    return {
      kind: "transport", retryable: true, status: 429,
      ...(raw.retryAfterMs !== undefined ? { retryAfterMs: raw.retryAfterMs } : {}),
    };
  }
  if (raw instanceof APITimeoutError) return { kind: "transport", retryable: true };
  if (raw instanceof APIConnectionError) return { kind: "transport", retryable: true };
  if (raw instanceof UnprocessableEntityError) {
    // Our own request was malformed. Falling back would hide a bug.
    throw raw;
  }
  if (raw instanceof APIError) {
    return raw.status >= 500
      ? { kind: "transport", retryable: true, status: raw.status }
      : { kind: "transport", retryable: false, status: raw.status };
  }

  // --- Shape checks: lengths, JSON parse, truncation. ---
  if (typeof raw === "string") {
    if (raw.length > ctx.maxContextChars) {
      return { kind: "truncated", raw: raw.slice(0, MAX_EXCERPT) };
    }
    try { JSON.parse(raw); }
    catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const at = /position (\d+)/.exec(msg);
      return { kind: "parse_failure", raw: raw.slice(0, MAX_EXCERPT), offset: at ? Number(at[1]) : 0 };
    }
  }

  // --- Structured failure already shaped by an upstream tier. ---
  if (isRecord(raw) && typeof raw.kind === "string" && isFailureKind(raw.kind)) {
    return raw as ExtractionFailure;
  }

  // --- Schema violations — our validator, not Jev's. ---
  if (isRecord(raw)) {
    for (const [field, spec] of Object.entries(ctx.schema)) {
      const received = raw[field];
      if (received !== undefined && typeof received !== spec.type) {
        return { kind: "schema_violation", field, expected: spec.type, received };
      }
    }
    const missing = ctx.knownFields.filter(f => raw[f] === undefined || raw[f] === "");
    if (missing.length > 0) return { kind: "missing_required", fields: missing };
  }

  return { kind: "unclassifiable", raw: safeStringify(raw).slice(0, MAX_EXCERPT) };
}

function isFailureKind(k: string): k is ExtractionFailure["kind"] {
  switch (k) {
    case "no_candidate": case "parse_failure": case "schema_violation":
    case "ungrounded": case "off_target": case "missing_required":
    case "truncated": case "budget_exceeded": case "transport":
    case "unclassifiable":
      return true;
    default:
      return false;
  }
}

// -------------------------------------------------------------------------
// Jev-side classifier, invoked only on `unclassifiable`.
// -------------------------------------------------------------------------
const CLASSIFY_CHOICES = {
  no_candidate: "The document genuinely does not contain a value for the field.",
  parse_failure: "A generative step returned a string that does not parse as JSON at all.",
  schema_violation: "A value violates the declared type or the format the field's description implies.",
  ungrounded: "A value is present in the extraction but is not supported by, or absent from, the source.",
  off_target: "A value is present and supported, but was pulled from incidental text rather than genuinely reporting the field.",
  missing_required: "One or more required fields have no value at all.",
  truncated: "A generative step returned output that ends mid-value or mid-token.",
  budget_exceeded: "A tier was refused because the wall-clock budget was exhausted.",
  transport: "A network or protocol error occurred — the model was never consulted.",
  unclassifiable: "The failure does not fit any of the above.",
} as const;

export async function classifyWithJev(
  client: TypeSafeClient,
  raw: unknown,
  ctx: ClassifyContext,
  signal?: AbortSignal,
): Promise<ExtractionFailure> {
  const answer = (await client.systemOne(
    {
      state: {
        failure_excerpt: safeStringify(raw).slice(0, 1500),
        document_length: ctx.documentLength,
        max_context_chars: ctx.maxContextChars,
      },
      questions: {
        kind: choice(
          "Which failure category does this error belong to? Read the excerpt and pick the single most specific label.",
          CLASSIFY_CHOICES,
        ),
      },
    },
    signal ? { signal } : {},
  )).answers.kind as ChoiceResponse<typeof CLASSIFY_CHOICES>;

  switch (answer.choice) {
    case "transport":        return { kind: "transport", retryable: false };
    case "truncated":        return { kind: "truncated", raw: safeStringify(raw).slice(0, MAX_EXCERPT) };
    case "missing_required": return { kind: "missing_required", fields: [] };
    case "parse_failure":    return { kind: "parse_failure", raw: safeStringify(raw).slice(0, MAX_EXCERPT), offset: 0 };
    case "schema_violation": return { kind: "schema_violation", field: "unknown", expected: "unknown", received: raw };
    case "ungrounded":       return { kind: "ungrounded", field: "description", probability: 0 };
    case "off_target":       return { kind: "off_target", field: "description", probability: 0 };
    case "no_candidate":     return { kind: "no_candidate", field: "description", reason: "absent" };
    case "budget_exceeded":  return { kind: "budget_exceeded", tier: "jev_repaired" };
    case "unclassifiable":   return { kind: "unclassifiable", raw: safeStringify(raw).slice(0, MAX_EXCERPT) };
  }
}

// -------------------------------------------------------------------------
// Repair — bounded, field-scoped, telemetry-emitting.
// -------------------------------------------------------------------------
export interface RepairContext {
  readonly document: string;
  readonly record: Partial<IntakeRecord>;
  readonly candidates: Partial<Record<keyof IntakeRecord, ReadonlyArray<string>>>;
  readonly exemplars: ExemplarStore;
  readonly client: TypeSafeClient;
  readonly signal?: AbortSignal;
  readonly telemetry: TelemetrySink;
  readonly now: () => number;
}

export interface AttemptCounters {
  readonly field: Map<keyof IntakeRecord, number>;
  total: number;
}

interface TerminalOutcome { readonly terminal: true; readonly reason: ExtractionFailure; }

export async function repair(
  failure: ExtractionFailure,
  ctx: RepairContext,
  budget: RepairBudget,
  counters: AttemptCounters,
): Promise<RepairPlan | TerminalOutcome> {
  const startedAt = ctx.now();
  const elapsed = () => ctx.now() - startedAt;

  // Terminal kinds: no amount of repair helps.
  if (
    (failure.kind === "transport" && !failure.retryable) ||
    failure.kind === "budget_exceeded" ||
    failure.kind === "unclassifiable"
  ) {
    ctx.telemetry.record({
      kind: "terminated", failureKind: failure.kind, elapsedMs: elapsed(),
      attempts: { field: counters.total, total: counters.total }, message: "terminal kind",
    });
    return { terminal: true, reason: failure };
  }

  // Retryable transport: the loop's job is to wait, not to rephrase a question.
  if (failure.kind === "transport" && failure.retryable) {
    const waitMs = Math.min(failure.retryAfterMs ?? 0, 30_000);
    if (waitMs > 0) await budget.wait(waitMs);
    ctx.telemetry.record({
      kind: "attempted", failureKind: failure.kind, elapsedMs: elapsed(),
      attempts: { field: counters.total, total: counters.total },
      message: `waited ${waitMs}ms before re-issue`,
    });
    return {
      field: "description",
      strategy: "ask_again_with_exemplars",
      question: noul("Re-issuing the previously failed call.", { true: "yes", false: "no" }),
      expectedCost: "cheap",
    };
  }

  const field = ("field" in failure ? failure.field as keyof IntakeRecord : "description" as keyof IntakeRecord);
  const perField = counters.field.get(field) ?? 0;

  if (perField >= budget.maxPerField || counters.total >= budget.maxPerDocument) {
    ctx.telemetry.record({
      kind: "terminated", field, failureKind: failure.kind, elapsedMs: elapsed(),
      attempts: { field: perField, total: counters.total }, message: "attempt ceiling",
    });
    return { terminal: true, reason: failure };
  }

  // Pick the strategy that matches the failure's fixability.
  let strategy: RepairPlan["strategy"];
  switch (failure.kind) {
    case "no_candidate":    strategy = failure.reason === "absent" ? "reslice_window" : "widen_candidates"; break;
    case "missing_required":strategy = "widen_candidates"; break;
    case "parse_failure":
    case "truncated":       strategy = "ask_again_with_exemplars"; break;
    case "schema_violation":strategy = "relax_format"; break;
    case "ungrounded":
    case "off_target":      strategy = "escalate_to_generative"; break;
    default:                return { terminal: true, reason: failure };
  }

  const exemplars = await ctx.exemplars.nearest(field, ctx.document, 3);
  const candidates = ctx.candidates[field] ?? [];

  const criteria: Record<string, string | null> = {};
  for (const c of candidates) criteria[c] = null;
  criteria["none"] = "None of these is the requested value.";

  const question = choice(
    {
      field_spec: { path: field, type: "string" },
      main_question: `Which candidate is the correct \`${field}\`?`,
      previous_value: ctx.record[field] ?? null,
      failure: { kind: failure.kind },
      // The failure travels with the question; the model is not asked to redo the task.
      precedent: exemplars.map(e => ({
        span: e.sourceSpan,
        value: e.extractedValue,
        similarity: Number(e.similarity.toFixed(3)),
      })),
    },
    criteria,
  );

  const expectedCost: RepairPlan["expectedCost"] =
    strategy === "escalate_to_generative" ? "expensive"
    : strategy === "ask_again_with_exemplars" ? "moderate"
    : "cheap";

  ctx.telemetry.record({
    kind: "planned", field, failureKind: failure.kind, strategy, elapsedMs: elapsed(),
    attempts: { field: perField, total: counters.total },
  });

  return { field, strategy, question, expectedCost };
}

// -------------------------------------------------------------------------
// The loop. Bounded on two axes; the caller drives it.
// -------------------------------------------------------------------------
export interface RepairLoopOutcome {
  readonly record: Partial<IntakeRecord>;
  readonly repairedFields: ReadonlyArray<keyof IntakeRecord>;
  readonly terminal: ExtractionFailure | null;
}

export async function repairLoop(
  initial: ExtractionFailure,
  ctx: RepairContext,
  budget: RepairBudget = DEFAULT_REPAIR_BUDGET,
  classify: (raw: unknown, ctx: ClassifyContext) => ExtractionFailure = classifyFailure,
  classifyCtx: ClassifyContext,
): Promise<RepairLoopOutcome> {
  let failure = initial;
  let working: Partial<IntakeRecord> = { ...ctx.record };
  const repairedFields: Array<keyof IntakeRecord> = [];
  const counters: AttemptCounters = { field: new Map(), total: 0 };

  for (let i = 0; i < budget.maxPerDocument; i++) {
    const plan = await repair(failure, { ...ctx, record: working }, budget, counters);
    if ("terminal" in plan) return { record: working, repairedFields, terminal: plan.reason };

    const field = plan.field;
    const perField = (counters.field.get(field) ?? 0) + 1;
    counters.field.set(field, perField);
    counters.total += 1;

    const before = { ...working };
    ctx.telemetry.record({
      kind: "attempted", field, strategy: plan.strategy, elapsedMs: 0,
      attempts: { field: perField, total: counters.total },
    });

    try {
      const result = await ctx.client.systemOne(
        { state: { source_text: ctx.document, extraction: before }, questions: { repair: plan.question } },
        ctx.signal ? { signal: ctx.signal } : {},
      );
      const answer = result.answers.repair as ChoiceResponse<Record<string, null>> | undefined;

      if (answer?.type === "choice" && answer.choice !== "none") {
        working = { ...before, [field]: answer.choice };
        repairedFields.push(field);
        ctx.telemetry.record({
          kind: "succeeded", field, strategy: plan.strategy, elapsedMs: 0,
          attempts: { field: perField, total: counters.total },
          usage: { inputTokens: result.usage.input_tokens, outputTokens: result.usage.output_tokens },
        });
        return { record: working, repairedFields, terminal: null };
      }
    } catch (err) {
      if (err instanceof APIUserAbortError) throw err; // never retried, never repaired
      const next = classify(err, classifyCtx);
      ctx.telemetry.record({
        kind: "failed", field, strategy: plan.strategy, elapsedMs: 0,
        attempts: { field: perField, total: counters.total }, message: String(err),
      });
      failure = next;
      continue;
    }
  }
  return { record: working, repairedFields, terminal: failure };
}
