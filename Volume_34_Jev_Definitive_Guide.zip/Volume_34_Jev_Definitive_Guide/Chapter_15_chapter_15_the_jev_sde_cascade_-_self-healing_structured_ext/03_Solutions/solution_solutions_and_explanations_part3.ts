/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// cascade/budget.ts
import {
  APIUserAbortError,
  TypeSafeClient,
  type SystemOneRequestPayload,
} from "@typesafe-ai/sdk";
import type { IntakeRecord, ExtractionTier } from "./types";

// -------------------------------------------------------------------------
// Budget — a deadline, not a countdown.
// -------------------------------------------------------------------------
/** Minimum remaining time each tier needs before it will start. */
export const TIER_FLOORS_MS = {
  deterministic: 0,
  jev_verified: 130,
  jev_repaired: 200,
} as const satisfies Readonly<Record<ExtractionTier, number>>;

export class CascadeBudget {
  private readonly deadlineMs: number;
  constructor(totalMs: number, private readonly now: () => number) {
    this.deadlineMs = now() + totalMs;
  }
  remaining(): number { return Math.max(0, this.deadlineMs - this.now()); }
  allows(tier: ExtractionTier): boolean { return this.remaining() >= TIER_FLOORS_MS[tier]; }
}

// -------------------------------------------------------------------------
// Breaker — a state machine, keyed on (tier, field, region).
// -------------------------------------------------------------------------
export type BreakerState =
  | { readonly kind: "closed"; readonly window: ReadonlyArray<"success" | "failure"> }
  | { readonly kind: "open"; readonly openedAtMs: number }
  | { readonly kind: "half-open"; readonly consecutiveSuccesses: number };

export interface BreakerConfig {
  readonly windowSize: number;
  readonly failureRatioToOpen: number;
  readonly minSamplesToOpen: number;
  readonly cooldownMs: number;
  readonly requiredSuccessesToClose: number;
}

export const DEFAULT_BREAKER_CONFIG: BreakerConfig = {
  windowSize: 20,
  failureRatioToOpen: 0.5,
  minSamplesToOpen: 5,
  cooldownMs: 10_000,
  requiredSuccessesToClose: 3,
};

export interface BreakerKey {
  readonly tier: ExtractionTier;
  readonly field: keyof IntakeRecord | "*";
  readonly region: string;
}

export class CircuitBreaker {
  private readonly states = new Map<string, BreakerState>();

  constructor(
    private readonly config: BreakerConfig,
    private readonly now: () => number,
  ) {}

  private key(k: BreakerKey): string { return `${k.tier}::${k.field}::${k.region}`; }

  state(k: BreakerKey): BreakerState {
    return this.states.get(this.key(k)) ?? { kind: "closed", window: [] };
  }

  /** Consulted before issuing a call. Transitions `open → half-open` on cooldown. */
  allows(k: BreakerKey): boolean {
    const state = this.state(k);
    switch (state.kind) {
      case "closed":    return true;
      case "open":
        if (this.now() - state.openedAtMs >= this.config.cooldownMs) {
          this.states.set(this.key(k), { kind: "half-open", consecutiveSuccesses: 0 });
          return true;
        }
        return false;
      case "half-open": return true;
    }
  }

  record(k: BreakerKey, outcome: "success" | "failure"): void {
    const state = this.state(k);
    switch (state.kind) {
      case "closed": {
        const next = [...state.window, outcome].slice(-this.config.windowSize);
        if (next.length < this.config.minSamplesToOpen) {
          this.states.set(this.key(k), { kind: "closed", window: next });
          return;
        }
        const failures = next.filter(x => x === "failure").length;
        if (failures / next.length >= this.config.failureRatioToOpen) {
          this.states.set(this.key(k), { kind: "open", openedAtMs: this.now() });
        } else {
          this.states.set(this.key(k), { kind: "closed", window: next });
        }
        return;
      }
      case "open":
        // Successes while open are ignored; the transition happens in `allows()`.
        return;
      case "half-open": {
        if (outcome === "failure") {
          this.states.set(this.key(k), { kind: "open", openedAtMs: this.now() });
        } else if (state.consecutiveSuccesses + 1 >= this.config.requiredSuccessesToClose) {
          // Require a *run* of successes, not a single sample. A breaker that closes on
          // one lucky request will flap.
          this.states.set(this.key(k), { kind: "closed", window: [] });
        } else {
          this.states.set(this.key(k), {
            kind: "half-open", consecutiveSuccesses: state.consecutiveSuccesses + 1,
          });
        }
        return;
      }
    }
  }
}

// -------------------------------------------------------------------------
// Outcome types — degraded is a variant, not a boolean.
// -------------------------------------------------------------------------
export interface CompleteOutcome {
  readonly status: "complete";
  readonly record: IntakeRecord;
  readonly tier: ExtractionTier;
  readonly repairedFields: ReadonlyArray<keyof IntakeRecord>;
  readonly timingsMs: Readonly<Record<ExtractionTier, number>>;
}

export interface DegradedOutcome {
  readonly status: "degraded";
  readonly record: Partial<IntakeRecord>;
  /** Fields that would have been repaired had the budget or breaker permitted. */
  readonly deferred: ReadonlyArray<keyof IntakeRecord>;
  readonly degradedBecause: "budget_exceeded" | "breaker_open";
  readonly atTier: ExtractionTier;
  readonly timingsMs: Readonly<Record<ExtractionTier, number>>;
}

export type CascadeResult = CompleteOutcome | DegradedOutcome;

// -------------------------------------------------------------------------
// Telemetry surface (no backend implemented here).
// -------------------------------------------------------------------------
export interface MetricsSink {
  histogram(name: string, valueMs: number, tags: Readonly<Record<string, string>>): void;
  counter(name: string, tags: Readonly<Record<string, string>>): void;
  gauge(name: string, value: number, tags: Readonly<Record<string, string>>): void;
}

// -------------------------------------------------------------------------
// The cascade under a budget and a breaker.
// -------------------------------------------------------------------------
export interface CascadeOptions {
  readonly signal?: AbortSignal;
  readonly now?: () => number;
  readonly budgetMs?: number;
  readonly breaker?: CircuitBreaker;
  readonly breakerConfig?: BreakerConfig;
  readonly region?: string;
  readonly metrics?: MetricsSink;
  /** The verifier; injected so the caller owns its `retry` policy. */
  readonly verify: (
    client: TypeSafeClient,
    document: string,
    record: Partial<IntakeRecord>,
    signal: AbortSignal | undefined,
  ) => Promise<{ verdicts: ReadonlyArray<{ field: keyof IntakeRecord; escalate: boolean }>; usage: { inputTokens: number; outputTokens: number } }>;
  /** The reparer; injected for the same reason. */
  readonly repair: (
    client: TypeSafeClient,
    document: string,
    record: Partial<IntakeRecord>,
    fields: ReadonlyArray<keyof IntakeRecord>,
    signal: AbortSignal | undefined,
  ) => Promise<{ repaired: Partial<IntakeRecord>; repairedFields: ReadonlyArray<keyof IntakeRecord> }>;
}

export async function extractWithBudget(
  client: TypeSafeClient,
  document: string,
  parsed: { readonly record: Partial<IntakeRecord>; readonly missing: ReadonlyArray<keyof IntakeRecord> },
  options: CascadeOptions,
): Promise<CascadeResult> {
  const now = options.now ?? (() => performance.now());
  const budget = new CascadeBudget(options.budgetMs ?? 250, now);
  const breaker = options.breaker ?? new CircuitBreaker(options.breakerConfig ?? DEFAULT_BREAKER_CONFIG, now);
  const region = options.region ?? "default";
  const metrics: MetricsSink = options.metrics ?? { histogram: () => {}, counter: () => {}, gauge: () => {} };
  const timings: Record<ExtractionTier, number> = { deterministic: 0, jev_verified: 0, jev_repaired: 0 };

  // --- Tier 1 gate ---
  const key1: BreakerKey = { tier: "jev_verified", field: "*", region };
  if (!budget.allows("jev_verified")) {
    metrics.counter("cascade.budget.refused", { tier: "jev_verified", region });
    return {
      status: "degraded",
      record: parsed.record,
      deferred: parsed.missing,
      degradedBecause: "budget_exceeded",
      atTier: "jev_verified",
      timingsMs: timings,
    };
  }
  if (!breaker.allows(key1)) {
    metrics.gauge("cascade.breaker.state", 1, { key: "jev_verified", region });
    return {
      status: "degraded",
      record: parsed.record,
      deferred: parsed.missing,
      degradedBecause: "breaker_open",
      atTier: "jev_verified",
      timingsMs: timings,
    };
  }

  const t1 = now();
  let verified: Awaited<ReturnType<typeof options.verify>>;
  try {
    verified = await options.verify(client, document, parsed.record, options.signal);
    breaker.record(key1, "success");
  } catch (err) {
    if (err instanceof APIUserAbortError) throw err; // never retried, never a repair event
    breaker.record(key1, "failure");
    metrics.counter("cascade.tier.failed", { tier: "jev_verified", region });
    throw err;
  }
  timings.jev_verified = now() - t1;
  metrics.histogram("cascade.tier.duration", timings.jev_verified, { tier: "jev_verified", region });

  const fired = verified.verdicts.filter(v => v.escalate).map(v => v.field);
  if (fired.length === 0) {
    return {
      status: "complete",
      record: parsed.record as IntakeRecord,
      tier: "jev_verified",
      repairedFields: [],
      timingsMs: timings,
    };
  }

  // --- Tier 2 gate ---
  const key2: BreakerKey = { tier: "jev_repaired", field: "*", region };
  if (!budget.allows("jev_repaired") || !breaker.allows(key2)) {
    metrics.counter("cascade.budget.refused", { tier: "jev_repaired", region });
    return {
      status: "degraded",
      record: parsed.record,
      deferred: fired,
      degradedBecause: budget.allows("jev_repaired") ? "breaker_open" : "budget_exceeded",
      atTier: "jev_repaired",
      timingsMs: timings,
    };
  }

  const t2 = now();
  let repair: Awaited<ReturnType<typeof options.repair>>;
  try {
    repair = await options.repair(client, document, parsed.record, fired, options.signal);
    breaker.record(key2, "success");
  } catch (err) {
    if (err instanceof APIUserAbortError) throw err;
    breaker.record(key2, "failure");
    throw err;
  }
  timings.jev_repaired = now() - t2;
  metrics.histogram("cascade.tier.duration", timings.jev_repaired, { tier: "jev_repaired", region });

  return {
    status: "complete",
    record: repair.repaired as IntakeRecord,
    tier: "jev_repaired",
    repairedFields: repair.repairedFields,
    timingsMs: timings,
  };
}

// -------------------------------------------------------------------------
// Retry-ownership demonstration: exactly one layer owns retries.
// -------------------------------------------------------------------------
export function cascadeOwnedRetries(baseURL: string, apiKey: string): TypeSafeClient {
  // The SDK's own retry policy is disabled; a wrapper above the cascade owns retries.
  return new TypeSafeClient({
    apiKey,
    baseURL,
    retry: { maxRetries: 0 },
  });
}

export function sdkOwnedRetries(baseURL: string, apiKey: string): TypeSafeClient {
  // The SDK keeps its default retry policy; the cascade adds no retries on top.
  return new TypeSafeClient({ apiKey, baseURL });
}
