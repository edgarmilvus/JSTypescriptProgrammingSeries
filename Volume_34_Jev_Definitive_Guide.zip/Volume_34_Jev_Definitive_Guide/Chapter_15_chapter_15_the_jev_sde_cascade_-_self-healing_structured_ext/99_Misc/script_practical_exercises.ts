/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

import {
  TypeSafeClient,
  choice,
  noul,
  type ChoiceResponse,
  type NoulResponse,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

export type ExtractionTier =
  | "deterministic"
  | "jev_verified"
  | "jev_repaired";

export interface FieldVerdict {
  readonly field: keyof IntakeRecord;
  readonly hazards: Readonly<Record<string, number>>; // metric -> P(true)
  readonly worstHazard: string;
  readonly worstProbability: number;
}

export interface CascadeOutcome {
  readonly record: IntakeRecord;
  readonly tier: ExtractionTier;
  /** Fields whose value came from a repair rather than the tier above it. */
  readonly repairedFields: ReadonlyArray<keyof IntakeRecord>;
  /** Every verdict that took part, in the order it was produced. */
  readonly verdicts: ReadonlyArray<FieldVerdict>;
  /** Per-tier wall-clock, monotonic. */
  readonly timingsMs: Readonly<Record<ExtractionTier, number>>;
  /** The final gate decision, exposed so a caller can reverse it. */
  readonly escalationReason: EscalationReason | null;
}

export type EscalationReason =
  | { readonly kind: "tier0_incomplete"; readonly missing: ReadonlyArray<string> }
  | { readonly kind: "tier0_out_of_range"; readonly field: string; readonly value: unknown }
  | { readonly kind: "verification_fired"; readonly field: string; readonly hazard: string; readonly probability: number }
  | { readonly kind: "verification_uncertain"; readonly field: string; readonly probability: number };

export async function extractWithCascade(
  client: TypeSafeClient,
  document: string,
  options?: { readonly signal?: AbortSignal; readonly now?: () => number }
): Promise<CascadeOutcome> {
  // TODO: implement.
  throw new Error("not implemented");
}
