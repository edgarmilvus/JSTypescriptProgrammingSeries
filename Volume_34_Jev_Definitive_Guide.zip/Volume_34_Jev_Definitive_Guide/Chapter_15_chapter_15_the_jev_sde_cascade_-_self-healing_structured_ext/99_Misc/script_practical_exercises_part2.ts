/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

export type ExtractionFailure =
  | { kind: "no_candidate"; field: keyof IntakeRecord; reason: "absent" | "ambiguous" }
  | { kind: "parse_failure"; raw: string; offset: number }
  | { kind: "schema_violation"; field: string; expected: string; received: unknown }
  | { kind: "ungrounded"; field: keyof IntakeRecord; probability: number }
  | { kind: "off_target"; field: keyof IntakeRecord; probability: number }
  | { kind: "missing_required"; fields: ReadonlyArray<keyof IntakeRecord> }
  | { kind: "truncated"; raw: string }
  | { kind: "budget_exceeded"; tier: ExtractionTier }
  | { kind: "transport"; retryable: boolean; status?: number; retryAfterMs?: number }
  | { kind: "unclassifiable"; raw: string };

export interface RepairPlan {
  readonly field: keyof IntakeRecord;
  readonly strategy:
    | "widen_candidates"
    | "reslice_window"
    | "relax_format"
    | "ask_again_with_exemplars"
    | "escalate_to_generative";
  readonly question: ReturnType<typeof choice> | ReturnType<typeof noul>;
  readonly expectedCost: "cheap" | "moderate" | "expensive";
}
