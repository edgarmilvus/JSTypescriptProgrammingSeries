/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * citation-check.ts
 *
 * Runs on a Node.js backend (Express, Next.js API route, or Vercel function).
 * Takes an LLM's cited answer, verifies every citation against the source
 * document, and produces a verdict row per citation for the audit log.
 *
 * Environment:
 *   TYPESAFE_API_KEY — read automatically by the SDK.
 *
 * Run:  npx tsx citation-check.ts
 */

import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

/* ── Domain types ──────────────────────────────────────────────── */

/** The four verdicts a citation can receive. */
type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated";

/** One citation as produced by the upstream LLM. */
interface Citation {
  id: string;
  claim: string;
  /** The quote the LLM says supports the claim, or null when it only named a section. */
  quote: string | null;
  /** The section identifier the LLM claimed supports the claim. */
  section: string;
}

/** One row in the zero-hallucination audit trail. */
interface VerdictRow {
  id: string;
  ts: string;
  verdict: Verdict;
  relation: string | null;
  confidence: number | null;
  autoApproved: boolean;
  model: string;
}

/* ── Source document ───────────────────────────────────────────── */

/**
 * A miniature stand-in for a real docs page or policy file.
 * In production this would be the section of the retrieved document
 * that the answer claimed to quote from.
 */
const SOURCE: Record<string, string> = {
  "1": `1. Data retention.
Nimbus retains customer data for ninety days after account closure.
Backups are purged on a rolling seven-day schedule.`,

  "2": `2. Refund policy.
Subscriptions may be refunded within fourteen days of the initial charge.
Renewal charges are non-refundable.`,

  "3": `3. API rate limits.
The default rate limit is 600 requests per minute per API key.
Enterprise accounts may negotiate a higher ceiling.`,
};

/* ── The LLM's cited answer ────────────────────────────────────── */
/*   Four citations. One is honest. Three are deliberately wrong    */
/*   in the three ways citations go wrong.                          */

const CITATIONS: Citation[] = [
  {
    id: "honest",
    claim:
      "Nimbus keeps customer data for 90 days after an account is closed.",
    quote:
      "Nimbus retains customer data for ninety days after account closure.",
    section: "1",
  },
  {
    id: "fabricated",
    claim: "Nimbus purges backups immediately when an account closes.",
    quote: "Backups are destroyed at the moment an account is closed.",
    section: "1",
  },
  {
    id: "contradicted",
    claim: "Renewal charges can be refunded within fourteen days.",
    quote:
      "Subscriptions may be refunded within fourteen days of the initial charge.",
    section: "2",
  },
  {
    id: "unsupported",
    claim: "Nimbus offers a free trial for enterprise accounts.",
    quote: null,
    section: "3",
  },
];

/* ── Step 1: local string match (no API call) ──────────────────── */

/**
 * Collapse whitespace and fold curly quotes, so a quote typed in an answer
 * still matches the same quote inside a source document that uses
 * typographic characters or different line wrapping.
 */
function normalize(s: string): string {
  return s
    .replace(/\s+/g, " ")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2018\u2019]/g, "'")
    .trim();
}

/**
 * Returns the id of the section that contains the quote verbatim,
 * or null when no section does.
 */
function findQuote(
  sections: Record<string, string>,
  quote: string,
): string | null {
  const needle = normalize(quote);
  for (const [id, text] of Object.entries(sections)) {
    if (normalize(text).includes(needle)) return id;
  }
  return null;
}

/* ── Step 2: the Jev question ──────────────────────────────────── */

/**
 * A single Choice question with exactly three mutually exclusive outcomes.
 * Jev returns a probability distribution over all three, plus a confidence
 * summarising how peaked that distribution is.
 */
const RELATION = choice("How does the section relate to the claim?", {
  supports:
    "The section states the claim or directly implies that it is true",
  contradicts:
    "The section states the opposite of the claim or implies it is false",
  says_nothing:
    "The section does not address what the claim asserts, either way",
});

/** Map Jev's three answers onto the four verdicts this system emits. */
const RELATION_TO_VERDICT: Record<string, Verdict> = {
  supports: "verified",
  contradicts: "contradicted",
  says_nothing: "unsupported",
};

/* ── Client and shared constants ───────────────────────────────── */

const client = new TypeSafeClient();
const MODEL = "jev-latest";
/** Below this confidence, verdicts route to human review instead of auto. */
const AUTO_ACCEPT = 0.8;

/* ── checkCitation: the whole recipe, one citation at a time ───── */

async function checkCitation(citation: Citation): Promise<VerdictRow> {
  // Fields that every row carries, regardless of how it resolves.
  const base = {
    id: citation.id,
    ts: new Date().toISOString(),
  };

  // 1. If the LLM included a quote, it must actually appear in the source.
  let sectionText: string | null = null;
  if (citation.quote !== null) {
    const found = findQuote(SOURCE, citation.quote);
    if (found === null) {
      // Fabricated. No model call needed — the string check is enough.
      return {
        ...base,
        verdict: "fabricated",
        relation: null,
        confidence: null,
        autoApproved: true,
        model: MODEL,
      };
    }
    sectionText = SOURCE[found];
  } else {
    // No quote to check, so fall back to the section the LLM named.
    sectionText = SOURCE[citation.section] ?? null;
  }

  // If neither the quote matched nor the LLM's section exists in the source,
  // there is nothing to check the claim against.
  if (sectionText === null) {
    return {
      ...base,
      verdict: "unsupported",
      relation: null,
      confidence: null,
      autoApproved: false,
      model: MODEL,
    };
  }

  // 2. Ask Jev how the section relates to the claim.
  const { answers, model } = await client.systemOne({
    state: { claim: citation.claim, section: sectionText },
    questions: { relation: RELATION },
    model: MODEL,
  });

  const relation = answers.relation;
  if (relation.type !== "choice") {
    throw new Error(`expected choice, got ${relation.type}`);
  }

  const verdict = RELATION_TO_VERDICT[relation.choice] ?? "unsupported";
  const confidence = relation.confidence;

  return {
    ...base,
    verdict,
    relation: relation.choice,
    confidence,
    autoApproved: confidence >= AUTO_ACCEPT,
    model,
  };
}

/* ── main: verify every citation, print the audit trail ────────── */

async function main(): Promise<void> {
  const audit: VerdictRow[] = [];

  for (const citation of CITATIONS) {
    const row = await checkCitation(citation);
    audit.push(row);

    const conf =
      row.confidence === null ? "  -  " : row.confidence.toFixed(2);
    const gate = row.autoApproved ? "auto" : "review";
    console.log(
      `[${row.verdict.padEnd(13)}] ${row.id.padEnd(13)} ` +
        `relation=${(row.relation ?? "-").padEnd(12)} ` +
        `conf=${conf} gate=${gate}`,
    );
  }

  console.log("\n── audit trail ──");
  console.log(JSON.stringify(audit, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
