/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §1  RUNTIME CONTRACTS
 *
 * Compile-time TypeScript is erased by the bundler. Every value crossing the
 * process boundary — the generator's draft, the retrieval payload, the audit
 * row we persist — is re-validated at runtime with Zod.
 * ──────────────────────────────────────────────────────────────────────────── */

import { NextRequest, NextResponse } from "next/server";
import { createHash, randomUUID } from "node:crypto";
import { z } from "zod";
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

const CitationSchema = z.object({
  docId: z.string().min(1),
  section: z.string().min(1), // anchor inside the document, e.g. "4.1.3"
  quote: z.string().min(12), // the span the claim is said to rest on
});

const ClaimSchema = z.object({
  claimId: z.string().min(1),
  text: z.string().min(1).max(600),
  citations: z.array(CitationSchema).min(1).max(4),
});

const DraftSchema = z.object({
  answerId: z.string().min(1),
  question: z.string().min(1),
  claims: z.array(ClaimSchema).min(1).max(24),
  generatorModel: z.string().min(1),
});

type Citation = z.infer<typeof CitationSchema>;
type Claim = z.infer<typeof ClaimSchema>;
type Draft = z.infer<typeof DraftSchema>;

/* ────────────────────────────────────────────────────────────────────────────
 * §2  EVIDENCE STORE AND SOURCE NORMALIZATION
 *
 * A quote fails a byte comparison for exactly two reasons: typographic
 * substitution and whitespace. Fold both deterministically rather than
 * reaching for fuzzy matching, which re-introduces the very failure the
 * verifier exists to catch.
 * ──────────────────────────────────────────────────────────────────────────── */

export interface EvidenceDoc {
  docId: string;
  title: string;
  version: string; // e.g. "card-policy-2026.04"
  sections: Record<string, string>; // section id -> raw text
}

export const canonicalize = (raw: string): string =>
  raw
    .replace(/[\u2018\u2019\u02BC]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\u00A0/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const SENTENCE_BREAK = /(?<=[.!?])\s+(?=[A-Z("'])/;

/** Sentence-aligned window around a match, so the verifier never reads a claim
 *  against a span that has been detached from the sentence that governs it. */
function contextWindow(haystack: string, at: number, len: number, radius = 2): string {
  const lead = haystack.slice(0, at).split(SENTENCE_BREAK).slice(-radius).join(" ");
  const tail = haystack.slice(at + len).split(SENTENCE_BREAK).slice(0, radius).join(" ");
  return canonicalize(`${lead} ${haystack.slice(at, at + len)} ${tail}`);
}

export interface LocateResult {
  status: "found" | "missing";
  window: string; // empty when the quote is absent
}

/** The code-side gate. No model is consulted: a missing quote is fabricated. */
export function locateQuote(doc: EvidenceDoc, citation: Citation): LocateResult {
  const raw = doc.sections[citation.section];
  if (!raw) return { status: "missing", window: "" };
  const haystack = canonicalize(raw);
  const needle = canonicalize(citation.quote);
  const at = haystack.indexOf(needle);
  if (at === -1) return { status: "missing", window: "" };
  return { status: "found", window: contextWindow(haystack, at, needle.length) };
}
