/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §3  THE JEV VERIFICATION BATTERY
 *
 * Four narrow questions, one request, one claim-to-evidence pair. Independent
 * axes so a failure can be attributed to a specific cause rather than smeared
 * across a single blended verdict.
 * ──────────────────────────────────────────────────────────────────────────── */

const client = new TypeSafeClient({ timeout: 15_000, logLevel: "warn" });
const VERIFIER_MODEL = "jev-latest";

const relationQuestion = choice(
  "How does the passage relate to the claim? Judge only what the passage states or directly implies.",
  {
    supports: "The passage states the claim, or entails it without added inference.",
    contradicts: "The passage asserts the opposite of the claim, or forbids what the claim permits.",
    says_nothing: "The passage is on a related topic but does not address what the claim asserts.",
  },
);

const scopeDriftQuestion = noul(
  "Does the claim assert more than the passage supports?",
  {
    true: "The claim adds a condition, exception, number, deadline, or scope the passage never states.",
    false: "The claim stays within what the passage supports.",
  },
);

const misattributionQuestion = noul(
  "Does the claim attach the passage's rule to the wrong actor, entity, date, or document?",
  {
    true: "The rule applies to someone or something other than what the claim names.",
    false: "The rule is applied to the correct actor, entity, and period.",
  },
);

const coverageQuestion = score(
  "How much of the claim does the passage actually support?",
  [
    "None of it — the passage does not touch what the claim asserts.",
    "Part of it — a fragment is supported, but a material element is missing.",
    "Most of it — everything material is supported; only phrasing differs.",
    "All of it — every element of the claim is stated or entailed.",
  ],
);

const VERIFIER_QUESTIONS = {
  relation: relationQuestion,
  scope_drift: scopeDriftQuestion,
  misattribution: misattributionQuestion,
  coverage: coverageQuestion,
};

type VerifierQuestions = typeof VERIFIER_QUESTIONS;

/** One pair, one request. The state holds only what these questions need —
 *  unrelated context is a distractor and costs accuracy. */
async function askJev(
  claim: Claim,
  citation: Citation,
  passageContext: string,
): Promise<SystemOneResult<VerifierQuestions>> {
  return client.systemOne({
    state: {
      claim: claim.text,
      section_id: citation.section,
      quoted_span: citation.quote,
      passage_context: passageContext,
    },
    questions: VERIFIER_QUESTIONS,
    model: VERIFIER_MODEL,
  });
}
