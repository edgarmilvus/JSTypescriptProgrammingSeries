/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §4  DETERMINISTIC ROUTING
 *
 * Jev supplies probabilities; code supplies the decision. Every threshold is
 * named, reviewable, and re-runnable against cached answers at zero cost.
 * ──────────────────────────────────────────────────────────────────────────── */

const POLICY = {
  contradictsMin: 0.7, // relation probability required to call a pair contradicted
  saysNothingMin: 0.5, // relation probability required to call a pair off-topic
  scopeDriftMax: 0.55, // above this, a nominal "supports" is demoted
  misattributionMax: 0.4,
  coverageMin: 2.0, // on the 0–3 rubric
  autoConfidence: 0.8, // below this, even a verified claim needs a human
} as const;

export interface PairVerdict {
  claimId: string;
  status: "verified" | "unsupported" | "contradicted" | "fabricated";
  auto: boolean;
  confidence: number | null;
  reason: string;
}

function routePair(
  claimId: string,
  located: LocateResult,
  answers: SystemOneResult<VerifierQuestions>["answers"] | null,
): PairVerdict {
  // (1) Code-side gate: a quote that is not in the source is fabricated.
  if (located.status === "missing" || answers === null) {
    return {
      claimId,
      status: "fabricated",
      auto: true,
      confidence: null,
      reason: "quote not found verbatim in the cited section",
    };
  }

  const relation = answers.relation;
  const drift = answers.scope_drift.noul; // P(claim overreaches)
  const misattrib = answers.misattribution.noul; // P(rule applied to wrong entity)
  const coverage = answers.coverage.score; // 0–3, may land between levels

  // (2) Contradiction is never a partial success.
  if (relation.choice === "contradicts" && relation.probabilities.contradicts >= POLICY.contradictsMin) {
    return { claimId, status: "contradicted", auto: true, confidence: relation.confidence,
             reason: "passage asserts the opposite of the claim" };
  }

  // (3) An off-topic citation is a grounding failure, not a safety failure.
  if (relation.choice === "says_nothing" && relation.probabilities.says_nothing >= POLICY.saysNothingMin) {
    return { claimId, status: "unsupported", auto: false, confidence: relation.confidence,
             reason: "passage does not address what the claim asserts" };
  }

  // (4) Overreach, misattribution and thin coverage demote a nominal "supports".
  if (drift >= POLICY.scopeDriftMax || misattrib >= POLICY.misattributionMax || coverage < POLICY.coverageMin) {
    const cause =
      drift >= POLICY.scopeDriftMax ? `claim overreaches passage (P=${drift.toFixed(2)})`
      : misattrib >= POLICY.misattributionMax ? `rule applied to wrong entity (P=${misattrib.toFixed(2)})`
      : `passage covers only ${coverage.toFixed(2)}/3 of the claim`;
    return { claimId, status: "unsupported", auto: false, confidence: relation.confidence, reason: cause };
  }

  // (5) Verified — but only auto-releasable above the confidence floor.
  return {
    claimId,
    status: "verified",
    auto: relation.confidence >= POLICY.autoConfidence,
    confidence: relation.confidence,
    reason: "supported by the cited passage",
  };
}

/** Answer-level aggregation: one fabricated or contradicted claim blocks the
 *  whole draft, because the draft is read as a single utterance. */
export function aggregate(verdicts: PairVerdict[]): {
  action: "release" | "escalate" | "block";
  blocked: string[];
  review: string[];
} {
  const blocked = verdicts
    .filter((v) => v.status === "fabricated" || v.status === "contradicted")
    .map((v) => v.claimId);
  if (blocked.length > 0) return { action: "block", blocked, review: [] };

  const review = verdicts
    .filter((v) => v.status === "unsupported" || !v.auto)
    .map((v) => v.claimId);
  return { action: review.length > 0 ? "escalate" : "release", blocked, review };
}
