/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §5  HASH-CHAINED AUDIT LEDGER
 *
 * Each row commits to its own contents AND to the digest of the row before it.
 * Editing, deleting or reordering any historical row breaks every link after
 * it, so the head digest is a commitment to the whole history.
 * ──────────────────────────────────────────────────────────────────────────── */

export interface AuditRecord {
  seq: number;
  recordedAt: string; // ISO-8601
  answerId: string;
  question: string;
  generatorModel: string;
  verifierModel: string;
  inputHash: string; // sha256 of the canonical (question + draft)
  prevHash: string; // digest of record seq-1, or GENESIS
  verdicts: PairVerdict[];
  decision: "release" | "escalate" | "block";
  hash: string; // digest of everything above
}

const GENESIS = "0".repeat(64);
const sha256 = (v: string): string => createHash("sha256").update(v, "utf8").digest("hex");

/** Single factory with a fixed key order: the digest is only stable if every
 *  record is constructed the same way. */
function seal(record: Omit<AuditRecord, "hash">): AuditRecord {
  return { ...record, hash: sha256(JSON.stringify(record)) };
}

/** Swap for Postgres in production: SELECT ... FOR UPDATE on the head row. */
class Ledger {
  private rows: AuditRecord[] = [];
  private readonly inputHash: string;

  constructor(inputHash: string) {
    this.inputHash = inputHash;
  }

  append(
    draft: Draft,
    verdicts: PairVerdict[],
    decision: AuditRecord["decision"],
  ): AuditRecord {
    const prev = this.rows.at(-1);
    return seal({
      seq: this.rows.length,
      recordedAt: new Date().toISOString(),
      answerId: draft.answerId,
      question: draft.question,
      generatorModel: draft.generatorModel,
      verifierModel: VERIFIER_MODEL,
      inputHash: this.inputHash,
      prevHash: prev ? prev.hash : GENESIS,
      verdicts,
      decision,
    });
  }

  seal(record: Omit<AuditRecord, "hash">): AuditRecord {
    const sealed = seal(record);
    this.rows.push(sealed);
    return sealed;
  }

  /** Walk the chain and recompute every digest. Run nightly, or on read. */
  verifyChain(): { ok: boolean; brokenAt: number | null } {
    let prev = GENESIS;
    for (const row of this.rows) {
      const { hash, ...rest } = row;
      if (rest.prevHash !== prev) return { ok: false, brokenAt: row.seq };
      if (sha256(JSON.stringify(rest)) !== hash) return { ok: false, brokenAt: row.seq };
      prev = hash;
    }
    return { ok: true, brokenAt: null };
  }

  get head(): string {
    return this.rows.at(-1)?.hash ?? GENESIS;
  }
}
