/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §6  THE ENDPOINT
 * ──────────────────────────────────────────────────────────────────────────── */

const RequestSchema = z.object({
  question: z.string().min(3).max(2000),
  draft: DraftSchema,
});

export async function POST(req: NextRequest): Promise<NextResponse> {
  const parsed = RequestSchema.safeParse(await req.json());
  if (!parsed.success) {
    // Fail before spending a single verification token.
    return NextResponse.json(
      { error: "invalid_request", issues: parsed.error.issues },
      { status: 422 },
    );
  }
  const { question, draft } = parsed.data;

  // Bind the ledger to this exact input so a replay is detectable.
  const inputHash = sha256(canonicalize(`${question}\u0000${JSON.stringify(draft)}`));
  const ledger = new Ledger(inputHash);

  // Plan: one verification job per (claim, citation) pair.
  const jobs = draft.claims.flatMap((claim) =>
    claim.citations.map(async (citation) => {
      const doc = await loadEvidenceDoc(citation.docId);
      const located = locateQuote(doc, citation);
      if (located.status === "missing") {
        return routePair(claim.claimId, located, null); // no model call at all
      }
      const answers = (await askJev(claim, citation, located.window)).answers;
      return routePair(claim.claimId, located, answers);
    }),
  );

  // Rejections map to "unsupported" — failing closed, never open.
  const settled = await Promise.allSettled(jobs);
  const verdicts: PairVerdict[] = settled.map((s, i) =>
    s.status === "fulfilled"
      ? s.value
      : {
          claimId: draft.claims[Math.floor(i / draft.claims.length)]?.claimId ?? "unknown",
          status: "unsupported",
          auto: false,
          confidence: null,
          reason: "verification call failed",
        },
  );

  const { action, blocked, review } = aggregate(verdicts);
  const record = ledger.append(draft, verdicts, action);

  return NextResponse.json(
    {
      action,
      answerId: draft.answerId,
      audit: { seq: record.seq, hash: record.hash, prevHash: record.prevHash, head: ledger.head },
      blocked,
      review,
      verdicts,
    },
    { status: action === "block" ? 409 : 200 },
  );
}

/** Backed by the policy corpus. Replace with your retrieval store. */
async function loadEvidenceDoc(docId: string): Promise<EvidenceDoc> {
  const res = await fetch(`${process.env.CORPUS_URL}/docs/${docId}`, { cache: "force-cache" });
  if (!res.ok) throw new Error(`evidence doc ${docId} unavailable`);
  return (await res.json()) as EvidenceDoc;
}
