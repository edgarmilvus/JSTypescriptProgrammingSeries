/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part6.ts
// Description: Advanced Application Script
// ==========================================

/* ────────────────────────────────────────────────────────────────────────────
 * §5  HASH-CHAINED AUDIT LEDGER (final form — one write path)
 * ──────────────────────────────────────────────────────────────────────────── */

export class AuditLedger {
  private rows: AuditRecord[] = [];

  /** The only public mutation. Seals and appends atomically. */
  append(
    draft: Draft,
    inputHash: string,
    verdicts: PairVerdict[],
    decision: AuditRecord["decision"],
  ): AuditRecord {
    const prev = this.rows.at(-1);
    const unsealed: Omit<AuditRecord, "hash"> = {
      seq: this.rows.length,
      recordedAt: new Date().toISOString(),
      answerId: draft.answerId,
      question: draft.question,
      generatorModel: draft.generatorModel,
      verifierModel: VERIFIER_MODEL,
      inputHash,
      prevHash: prev ? prev.hash : GENESIS,
      verdicts,
      decision,
    };
    const sealed: AuditRecord = { ...unsealed, hash: sha256(JSON.stringify(unsealed)) };
    this.rows.push(sealed);
    return sealed;
  }

  /** Recompute every digest from GENESIS forward. Cheap enough to run on read. */
  verifyChain(): { ok: boolean; brokenAt: number | null } {
    let prev = GENESIS;
    for (const row of this.rows) {
      const { hash, ...rest } = row;
      if (rest.prevHash !== prev) return { ok: false, brokenAt: row.seq };
      if (sha256(JSON.stringify(rest)) !== hash) return { ok: false, brokenAt: row.seq };
      prev = hash;
    }
    return { ok: true, brokenAt: null };
  }

  get head(): string {
    return this.rows.at(-1)?.hash ?? GENESIS;
  }
}
