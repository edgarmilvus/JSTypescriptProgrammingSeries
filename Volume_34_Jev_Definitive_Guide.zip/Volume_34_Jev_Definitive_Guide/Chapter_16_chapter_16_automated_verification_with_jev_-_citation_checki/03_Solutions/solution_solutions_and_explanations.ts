/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/verify-citation.ts
"use server";
// The "use server" directive at the top of the file is not incidental: it is what
// tells the Next.js bundler to treat every export in this module as a Server
// Action. Move it below any other statement, or wrap it in a conditional, and
// the module is silently bundled into any client component that imports it —
// which would ship the TYPESAFE_API_KEY path (or its absence) into the browser.

import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface Citation {
  id: string;
  claim: string;
  quote: string | null;
  section: string; // the section number the generator claimed, e.g. "4.1.3"
}

export type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated";
export type Relation = "supports" | "contradicts" | "says_nothing";

export interface VerificationResult {
  citationId: string;
  status: "found" | "missing" | "section-only";
  relation: Relation | null;
  confidence: number | null; // null when no model call was made
  verdict: Verdict;
  autoAccept: boolean;
  probabilities: Record<string, number> | null;
}

// ---------------------------------------------------------------------------
// Threshold
// ---------------------------------------------------------------------------

// Starting high (0.8) routes more borderline cases to human review while we
// build trust in the model on our own corpus. Lower it only after reviewing
// the flagged set for a few weeks and confirming the model's calls matched
// the senior reviewers' on the ones it *was* confident about.
const AUTO_ACCEPT = 0.8;

// ---------------------------------------------------------------------------
// String normalization + exact matching (all in code, never in a prompt)
// ---------------------------------------------------------------------------

// This is done in code, not by Jev, on purpose: the whole point of the string
// layer is that it is deterministic and auditable. If a quote is "missing",
// we want to be able to prove it is missing by re-running this function; the
// audit trail must not depend on a model's paraphrase of "missing".
export function normalize(text: string): string {
  const folded = text
    .replace(/\u201C/g, '"') // left double curly
    .replace(/\u201D/g, '"') // right double curly
    .replace(/\u2018/g, "'") // left single curly
    .replace(/\u2019/g, "'"); // right single curly
  return folded.replace(/\s+/g, " ").trim();
}

// ---------------------------------------------------------------------------
// Section parsing
// ---------------------------------------------------------------------------

// Matches lines that begin with a numbered heading, e.g. "4.1.3.  Audience".
// Nested numbers (4, 4.1, 4.1.1, 4.1.1.1) all match the same group 1.
const SECTION_HEAD = /^(\d+(?:\.\d+)*)\.\s\s(.+)$/gm;

export function splitSections(source: string): Map<string, string> {
  const sections = new Map<string, string>();

  // Collect heading positions so we can slice between them.
  const heads: Array<{ number: string; index: number }> = [];
  for (const match of source.matchAll(SECTION_HEAD)) {
    heads.push({ number: match[1], index: match.index ?? 0 });
  }

  for (let i = 0; i < heads.length; i++) {
    const start = heads[i].index;
    const end = i + 1 < heads.length ? heads[i + 1].index : source.length;
    // Body text is preserved verbatim between this heading and the next; the
    // heading line itself is dropped. Reviewers will read this body via the
    // UI, so we do not strip anything from it.
    const body = source.slice(start, end);
    sections.set(heads[i].number, body.trim());
  }
  return sections;
}

// ---------------------------------------------------------------------------
// Step 1: locate the quote in the source
// ---------------------------------------------------------------------------

export interface LocateResult {
  status: "found" | "missing" | "section-only";
  sectionNumber: string | null;
  sectionBody: string | null;
}

export function locate(
  sections: Map<string, string>,
  citation: Citation,
): LocateResult {
  // No quote at all: nothing to match against. Fall back to the section the
  // generator named. This is the path where the model *must* read the section
  // to make any judgment — there is no span to point at.
  if (citation.quote === null) {
    const body = sections.get(citation.section);
    if (!body) {
      return { status: "missing", sectionNumber: null, sectionBody: null };
    }
    return {
      status: "section-only",
      sectionNumber: citation.section,
      sectionBody: body,
    };
  }

  const needle = normalize(citation.quote);

  // Walk sections in numeric order (4 < 4.1 < 4.1.1 ...) so the tie-break is
  // deterministic: the lowest-numbered section that contains the quote wins.
  const ordered = [...sections.keys()].sort((a, b) => {
    const pa = a.split(".").map(Number);
    const pb = b.split(".").map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const x = pa[i] ?? -1;
      const y = pb[i] ?? -1;
      if (x !== y) return x - y;
    }
    return 0;
  });

  for (const number of ordered) {
    const body = sections.get(number)!;
    if (normalize(body).includes(needle)) {
      return {
        status: "found",
        sectionNumber: number,
        sectionBody: body,
      };
    }
  }

  return { status: "missing", sectionNumber: null, sectionBody: null };
}

// ---------------------------------------------------------------------------
// Step 2: one Jev call to judge relation
// ---------------------------------------------------------------------------

const client = new TypeSafeClient();

const relationQuestion = choice("How does the section relate to the claim?", {
  supports: "The section states the claim or directly implies that it is true",
  contradicts:
    "The section states the opposite of the claim or implies it is false",
  says_nothing:
    "The section does not address what the claim asserts, either way",
});

const RELATION_TO_VERDICT: Record<Relation, Verdict> = {
  supports: "verified",
  contradicts: "contradicted",
  says_nothing: "unsupported",
};

// ---------------------------------------------------------------------------
// Step 3: the Server Action
// ---------------------------------------------------------------------------

export async function checkCitation(
  sections: Map<string, string>,
  citation: Citation,
): Promise<VerificationResult> {
  const located = locate(sections, citation);

  // The "missing" path is a code-level judgment. No Jev call. No confidence.
  // This is the entire point of the four-verdict contract: we can prove a
  // fabricated citation without asking a model anything.
  if (located.status === "missing" || located.sectionBody === null) {
    return {
      citationId: citation.id,
      status: "missing",
      relation: null,
      confidence: null,
      verdict: "fabricated",
      autoAccept: true, // no model to be uncertain about; string match is definitive
      probabilities: null,
    };
  }

  // We send the FULL section body, not just the quoted span. This is the
  // chapter's central design point: a word-for-word quote can come from a
  // section that reverses its meaning three sentences later. The model needs
  // the context to judge whether the quote actually supports the claim.
  const response = await client.systemOne({
    state: {
      claim: citation.claim,
      section: located.sectionBody,
    },
    questions: { relation: relationQuestion },
  });

  const answer = response.answers.relation; // ChoiceResponse<typeof relationQuestion.criteria>
  const relation = answer.choice as Relation;

  return {
    citationId: citation.id,
    status: located.status,
    relation,
    confidence: answer.confidence,
    verdict: RELATION_TO_VERDICT[relation],
    autoAccept: answer.confidence >= AUTO_ACCEPT,
    probabilities: { ...answer.probabilities },
  };
}

// ---------------------------------------------------------------------------
// Step 4: log-friendly one-line formatter
// ---------------------------------------------------------------------------

export function describe(result: VerificationResult): string {
  const relation = result.relation ?? "-";
  const confidence =
    result.confidence === null ? "-" : result.confidence.toFixed(2);
  const action = result.autoAccept ? "auto" : "review";
  return [
    result.citationId,
    result.status,
    relation,
    confidence,
    result.verdict,
    action,
  ].join("\t");
}

// ---------------------------------------------------------------------------
// Extensions
// ---------------------------------------------------------------------------

// Extension (a): tie-break when two sections contain the same quote verbatim.
// locate() sorts keys numerically and returns the lowest-numbered match. This
// is defensible because the RFC's numbered sections are ordered such that a
// general definition (4.1) precedes the usage guidance (4.1.3) that quotes it;
// pointing reviewers at the earliest definition is the more conservative
// choice, and it is deterministic across runs.
//
// Extension (b): the citation names a section that does not exist. This maps
// to "missing" above, which becomes "fabricated". Rationale: the four-verdict
// contract is deliberately closed, and a citation pointing at "4.9.9" in an
// RFC that stops at 4.1.8 is a citation the generator invented. Whether the
// quote is a hallucination or the section number is a hallucination is beside
// the point; either way, nothing was actually cited. Adding a fifth verdict
// would force the UI to explain a distinction the reviewer cannot act on.
