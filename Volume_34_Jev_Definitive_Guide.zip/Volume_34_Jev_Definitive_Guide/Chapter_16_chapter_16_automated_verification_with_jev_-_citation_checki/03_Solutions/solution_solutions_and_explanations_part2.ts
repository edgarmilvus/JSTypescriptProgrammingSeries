/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// app/audit/append-only-audit-log.ts
"use server";

import { createHash } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated";
export type Relation = "supports" | "contradicts" | "says_nothing";

export interface AuditEntry {
  sequence: number;
  timestamp: string; // ISO 8601
  citationId: string;
  stateHash: string;
  modelRequested: string;
  modelReturned: string;
  verdict: Verdict;
  relation: Relation | null;
  confidence: number | null;
  autoAccept: boolean;
  previousHash: string;
  entryHash: string;
}

// The sentinel used on the "fabricated" path, where no Jev call happens.
// It must be a value that cannot collide with a real model id (leading colon,
// not a valid model name), so a compliance reviewer scanning the log sees
// at a glance that no model was consulted for this entry.
export const NO_MODEL = ":none:";

type PendingEntry = Omit<AuditEntry, "entryHash" | "previousHash">;
type ChainedEntry = Omit<AuditEntry, "entryHash">;

// ---------------------------------------------------------------------------
// Canonical serialization and hashing
// ---------------------------------------------------------------------------

// CANONICAL FORM: sorted-key JSON, no whitespace. This exact form is part of
// the audit contract. Any change to it — adding a field, changing the key
// order, switching to a different stringification — breaks every hash in the
// existing chain. If you must extend the schema, add new fields to the END
// of the sorted list, or version the canonicalizer and migrate.
function canonicalize(entry: ChainedEntry): string {
  const keys = [
    "sequence",
    "timestamp",
    "citationId",
    "stateHash",
    "modelRequested",
    "modelReturned",
    "verdict",
    "relation",
    "confidence",
    "autoAccept",
    "previousHash",
  ] as const;
  const ordered: Record<string, unknown> = {};
  for (const key of keys) {
    ordered[key] = (entry as Record<string, unknown>)[key];
  }
  return JSON.stringify(ordered);
}

function sha256Hex(input: string): string {
  return createHash("sha256").update(input, "utf8").digest("hex");
}

// Hash the {claim, section} pair that gets sent to Jev, so the audit entry
// can be used months later to prove exactly what was asked — the section
// body is not stored in the entry (it can be large), but its hash is.
export function hashState(state: { claim: string; section: string }): string {
  return sha256Hex(JSON.stringify({ claim: state.claim, section: state.section }));
}

// Note: previousHash is part of the hashed content, so an adversary cannot
// rewrite entry k and re-chain entry k+1's previousHash to match — that would
// require rewriting k+1's entryHash too, and so on to the tip.
function hashEntry(entry: ChainedEntry): string {
  return sha256Hex(canonicalize(entry));
}

// ---------------------------------------------------------------------------
// Append-only log
// ---------------------------------------------------------------------------

export class AppendOnlyAuditLog {
  private entries: AuditEntry[] = [];

  get size(): number {
    return this.entries.length;
  }

  append(pending: PendingEntry): AuditEntry {
    const tip = this.entries[this.entries.length - 1];
    const previousHash = tip ? tip.entryHash : "GENESIS";

    // Reject out-of-order appends. The caller must record the correct sequence.
    // This is the simplest possible invariant and it is the one that catches
    // the "two writers raced for sequence 17" bug at append time, not at
    // verify time months later.
    if (pending.sequence !== this.entries.length) {
      throw new Error(
        `audit-append: sequence out of order (expected ${this.entries.length}, got ${pending.sequence})`,
      );
    }

    const chained: ChainedEntry = { ...pending, previousHash };
    const entry: AuditEntry = { ...chained, entryHash: hashEntry(chained) };
    this.entries.push(entry);
    return entry;
  }

  /**
   * Walk the chain and RECOMPUTE every entryHash from the entry body.
   * This is the critical part: a verify() that merely checks
   *   entry[i].previousHash === entry[i-1].entryHash
   * will pass even if an adversary edited both the body and the stored
   * entryHash of every entry, because the two halves of the check would
   * still agree. The only way to detect tampering is to re-derive each hash
   * from the fields the tamperer would have had to modify.
   */
  verify():
    | { valid: true }
    | { valid: false; brokenAt: number; reason: string } {
    if (this.entries.length === 0) return { valid: true };

    if (this.entries[0].previousHash !== "GENESIS") {
      return { valid: false, brokenAt: 0, reason: "genesis-chain-broken" };
    }

    for (let i = 0; i < this.entries.length; i++) {
      const entry = this.entries[i];
      const { entryHash, ...rest } = entry;
      const recomputed = hashEntry(rest);
      if (recomputed !== entryHash) {
        return { valid: false, brokenAt: i, reason: "entry-hash-mismatch" };
      }
      if (i > 0) {
        const expectedPrev = this.entries[i - 1].entryHash;
        if (entry.previousHash !== expectedPrev) {
          return { valid: false, brokenAt: i, reason: "previous-hash-mismatch" };
        }
      }
    }
    return { valid: true };
  }

  // Read access for the UI and the reconciliation job.
  readAll(): readonly AuditEntry[] {
    return this.entries;
  }
}

// ---------------------------------------------------------------------------
// Integration into the checkCitation Server Action
// ---------------------------------------------------------------------------

import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

export const MODEL_REQUESTED = "jev-latest"; // pin in production; see Ex. 5

const client = new TypeSafeClient();
const relationQuestion = choice("How does the section relate to the claim?", {
  supports: "The section states the claim or directly implies that it is true",
  contradicts:
    "The section states the opposite of the claim or implies it is false",
  says_nothing:
    "The section does not address what the claim asserts, either way",
});

// One log per process for the exercise. Exercise 5 replaces this with a
// pluggable AuditSink so durability and concurrency are handled properly.
const auditLog = new AppendOnlyAuditLog();

export interface Citation {
  id: string;
  claim: string;
  quote: string | null;
  section: string;
}

export async function checkCitation(
  locateFn: (c: Citation) => {
    status: "found" | "missing" | "section-only";
    sectionBody: string | null;
  },
  citation: Citation,
): Promise<{ result: import("./verify-citation").VerificationResult; entry: AuditEntry }> {
  const located = locateFn(citation);

  // ----- Fabricated path: no model call, but we STILL append one entry. -----
  if (located.status === "missing" || located.sectionBody === null) {
    const entry = auditLog.append({
      sequence: auditLog.size,
      timestamp: new Date().toISOString(),
      citationId: citation.id,
      stateHash: hashState({
        claim: citation.claim,
        section: citation.quote ?? "",
      }),
      modelRequested: NO_MODEL,
      modelReturned: NO_MODEL,
      verdict: "fabricated",
      relation: null,
      confidence: null,
      autoAccept: true,
    });
    return {
      result: {
        citationId: citation.id,
        status: "missing",
        relation: null,
        confidence: null,
        verdict: "fabricated",
        autoAccept: true,
        probabilities: null,
      },
      entry,
    };
  }

  // ----- Verbatim or section-only path: one Jev call, one audit entry. -----
  const response = await client.systemOne({
    state: { claim: citation.claim, section: located.sectionBody },
    questions: { relation: relationQuestion },
    model: MODEL_REQUESTED,
  });

  const answer = response.answers.relation;
  const relation = answer.choice as Relation;

  // The modelReturned field comes from the API's own report of which
  // versioned model answered; if the alias jev-latest moves in the future,
  // this is the field that pins which version was actually used for THIS
  // verification, which is what the reconciliation job re-checks.
  const entry = auditLog.append({
    sequence: auditLog.size,
    timestamp: new Date().toISOString(),
    citationId: citation.id,
    stateHash: hashState({
      claim: citation.claim,
      section: located.sectionBody,
    }),
    modelRequested: MODEL_REQUESTED,
    modelReturned: response.model,
    verdict:
      relation === "supports"
        ? "verified"
        : relation === "contradicts"
          ? "contradicted"
          : "unsupported",
    relation,
    confidence: answer.confidence,
    autoAccept: answer.confidence >= 0.8,
  });

  return {
    result: {
      citationId: citation.id,
      status: located.status,
      relation,
      confidence: answer.confidence,
      verdict:
        relation === "supports"
          ? "verified"
          : relation === "contradicts"
            ? "contradicted"
            : "unsupported",
      autoAccept: answer.confidence >= 0.8,
      probabilities: { ...answer.probabilities },
    },
    entry,
  };
}

// ---------------------------------------------------------------------------
// Tamper-detection scenarios (documented, not run)
// ---------------------------------------------------------------------------

/*
  Scenario A — body edited, entryHash left as-is.
    Tamper: log.entries[3].confidence = 0.99  (was 0.42); entryHash untouched.
    verify() recomputes hashEntry({...entries[3], no entryHash}) from the new
    body, sees it does not equal the stored entryHash → { valid: false,
    brokenAt: 3, reason: "entry-hash-mismatch" }.

  Scenario B — entry deleted.
    Tamper: log.entries.splice(5, 1).
    Now entries[5] is what used to be entries[6], and entries[5].previousHash
    still points at the old entries[4].entryHash's successor (entries[5]'s old
    hash), not at entries[4].entryHash. verify() walks to index 5 and finds
    previousHash !== entries[4].entryHash → { valid: false, brokenAt: 5 }.
    Note: even if the adversary ALSO recomputes entryHash for entry 5, the
    hash is over previousHash, which is the wrongly-pinned old value, and the
    chain is broken immediately.

  Scenario C — entries k and k+1 reordered.
    Tamper: swap log.entries[k] and log.entries[k+1].
    Two failures fire: entry k+1 formerly at index k now has previousHash
    pointing at entry k-1's hash, but the entry now at index k has the old
    entry k+1's hash as its own — the link is wrong. And the entry now at
    index k+1 (old entry k) has previousHash pointing at old entry k-1,
    which does not match the new predecessor's entryHash. verify() reports
    { valid: false, brokenAt: k } on the first failed link.

  Scenario D — the sophisticated attack: rewrite the whole tail.
    Adversary rewrites entry 7, recomputes entry 7's entryHash, rewrites
    entry 8's previousHash to match, recomputes entry 8's entryHash, and so
    on to the tip. The local chain now verifies clean.
    This is why the exercise's extension exists: an external anchor — a
    nightly git commit, an object-storage object with a compliance lock, or
    a notarization service — that records ONLY the tip hash makes a
    whole-tail rewrite detectable, because the anchor still points at the
    pre-tamper tip hash. Without an external anchor, the local chain only
    detects tampering that leaves at least one hash stale.
*/

// ---------------------------------------------------------------------------
// Why timestamping alone is not a substitute for hashing
// ---------------------------------------------------------------------------

/*
  Timestamps are self-asserted. An entry that claims "2026-08-16T14:03:22Z"
  can be written on that date, on a different day, or with a system clock the
  writer controls. A timestamp is a claim about when a decision was made.
  A hash chain is a claim about whether the entry has been touched since.
  They defend against different threats:
    - Timestamp: defends against "the decision was made after we said it was"
      only if the clock itself is trusted (e.g. authenticated by an HSM).
    - Hash chain: defends against "someone edited the decision after the fact"
      unconditionally — any edit invalidates every downstream hash.
  A good audit trail has both, plus an external anchor (Ex. 5 extension) that
  binds the tip hash to an independent witness. Timestamp + local hash alone
  still cannot prove that entries were not all fabricated at 3am by a writer
  who then set every timestamp to 2026-08-16.
*/
