/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/components/citation-inspector.tsx
// NOTE: no "use client" directive. This file is a Server Component.
// Data fetching, the Server Action calls, and the list rendering all
// happen on the server. The only Client Component is the isolated
// <CitationDisclosure /> imported below.

import { verifyMany, type Citation, type VerifiedCitation } from "../actions/verify-many";
import { CitationDisclosure } from "./citation-disclosure";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

// Deliberately minimal: the component receives raw citations, NOT verified
// results. Verification is a Server Action, and pushing its results in as
// props from a parent would mean the parent had already done the fetching —
// which breaks the layering the platform team's convention establishes.
// The component's job is to ask for verification and render what comes back.
export interface CitationInspectorProps {
  documentId: string;
  citations: Citation[];
}

// ---------------------------------------------------------------------------
// Server Component
// ---------------------------------------------------------------------------

export async function CitationInspector({
  documentId,
  citations,
}: CitationInspectorProps) {
  // Single round trip. see verifyMany() for why this is parallel server-side.
  const verified = await verifyMany(citations);

  return (
    <section aria-label={`Citations for document ${documentId}`}>
      <ul className="space-y-1">
        {verified.map((v) => (
          <li key={v.citationId}>
            {/* The disclosure is a Client Component because it holds open/
                closed state. It receives already-verified, JSON-serializable
                data as props — it never talks to TypeSafe directly, and it
                never sees the API key. This is the pattern the platform
                convention calls an "isolated Client Component": interaction
                state lives here, everything else lives on the server. */}
            <CitationDisclosure citation={v} />
          </li>
        ))}
      </ul>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Why Strategy B (isolated Client Component) over Strategy A (URL state)
// ---------------------------------------------------------------------------
//
// Strategy A (URL state) makes every expand a navigation. For a reviewer
// scanning 40 citations in a page, that is 40 navigations and 40 full
// re-renders just to peek at distributions. The Server Component code path
// stays simpler (one renderer, no hydration boundary), but the actual user
// experience — reviewers trying to compare distributions across citations —
// is materially worse.
//
// Strategy B keeps the parent a Server Component (so data fetching and the
// API key stay on the server) and extracts only the *interaction* into a
// small Client Component. The Client Component's props are the already-
// verified citation, which is a plain JSON object; no secrets, no live
// fetch, no dependency on the TypeSafe SDK. The client bundle cost is a
// few kilobytes; the interaction is instant. This is the choice the
// platform convention is really pointing at: "as much Server Component as
// possible" means as much *logic* as possible, not as much *rendering* as
// possible, and interactions are logic.
//
// The one real cost of Strategy B is that expand/collapse state does not
// survive a page refresh or a share-link. For a review workflow that a
// human is actively driving, that is fine. If shared, deep-linked review
// states became a requirement, add a URL-synced effect inside the Client
// Component rather than rewriting it as Strategy A.
