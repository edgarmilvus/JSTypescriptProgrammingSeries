/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/verify-many.ts
"use server";

import { checkCitation, type Citation, type VerificationResult } from "./verify-citation";
import { splitSections } from "./verify-citation";

export interface VerifiedCitation extends VerificationResult {
  claim: string;
  quote: string | null;
  sectionNumber: string;
}

// Runs the citation checks for a page's worth of citations in parallel.
// Jev answers a single request in ~100 ms; firing N in parallel means the
// page is ready in roughly the time a single request used to take, which is
// the whole reason the fast fan-out pattern is worth adopting here.
export async function verifyMany(citations: Citation[]): Promise<VerifiedCitation[]> {
  const sections = splitSections(await loadSourceForSession());
  const results = await Promise.all(
    citations.map((c) => checkCitation(sections, c)),
  );
  return results.map((r, i) => ({
    ...r,
    claim: citations[i].claim,
    quote: citations[i].quote,
    sectionNumber: citations[i].section,
  }));
}

// Placeholder for the real source-loading path; the exercise's infra spec
// puts the source documents in memory as a Map<string, string> keyed by
// document id, and this is where that lookup lives.
async function loadSourceForSession(): Promise<string> {
  throw new Error("wire to your in-memory source map");
}
