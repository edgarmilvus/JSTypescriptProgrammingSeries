/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// app/components/citation-disclosure.tsx
"use client";

import { useState } from "react";
import type { VerifiedCitation } from "../actions/verify-many";

// ---------------------------------------------------------------------------
// Color-vision-deficiency-safe palette
// ---------------------------------------------------------------------------
//
// Red/green is the single most common CVD axis and is the wrong palette for
// a verdict badge. This palette uses hue distances that remain distinguishable
// under deuteranopia and protanopia:
//
//   verified     → teal   (hue ~180)   discriminable from amber under both
//   unsupported  → amber  (hue  ~45)   the "yellow" axis survives both
//   contradicted → magenta(hue ~310)   survives both by value, not hue
//   fabricated   → orange (hue  ~25)   darker than amber; differs in lightness
//
// But color alone is NEVER the sole encoder. Each badge carries a short text
// label ("Verified", "Unsupported", "Contradicted", "Fabricated") and the
// alert/shield/question glyph, so a reviewer with any form of color blindness
// — or a black-and-white printout — reads the verdict unambiguously.
//
// This is a hard requirement, not a stylistic preference, because the
// platform's own accessibility review includes CVD simulation on every
// status-indicating surface, and a verdict badge is the canonical example
// of a status-indicating surface.

const PALETTE: Record<
  VerifiedCitation["verdict"],
  { bg: string; fg: string; label: string; glyph: string }
> = {
  verified:     { bg: "#0E7C86", fg: "#FFFFFF", label: "Verified",     glyph: "✓" },
  unsupported:  { bg: "#D89614", fg: "#241A00", label: "Unsupported",  glyph: "?" },
  contradicted: { bg: "#A3288C", fg: "#FFFFFF", label: "Contradicted", glyph: "✕" },
  fabricated:   { bg: "#C0562A", fg: "#FFFFFF", label: "Fabricated",   glyph: "⊘" },
};

export function CitationDisclosure({ citation }: { citation: VerifiedCitation }) {
  const [open, setOpen] = useState(false);
  const palette = PALETTE[citation.verdict];

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label={`Verification verdict for citation ${citation.citationId}: ${citation.verdict}`}
        className="inline-flex items-center gap-2 rounded px-2 py-1 text-xs font-medium"
        style={{ background: palette.bg, color: palette.fg }}
      >
        <span aria-hidden="true">{palette.glyph}</span>
        <span>{palette.label}</span>
        {!citation.autoAccept && (
          <span
            aria-label="needs review"
            title="needs review"
            className="ml-1 inline-block h-2 w-2 rounded-full bg-amber-300 ring-2 ring-amber-700"
          />
        )}
      </button>

      {open && (
        <div
          role="region"
          aria-labelledby={`citation-${citation.citationId}-heading`}
          className="mt-2 rounded border border-neutral-300 p-3 text-sm"
        >
          <h4
            id={`citation-${citation.citationId}-heading`}
            className="font-semibold"
          >
            Citation {citation.citationId} — {citation.verdict}
          </h4>

          <dl className="mt-2 grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1">
            <dt className="text-neutral-500">Claim</dt>
            <dd>{citation.claim}</dd>

            <dt className="text-neutral-500">Quote</dt>
            <dd>
              {citation.quote ? (
                <q>{citation.quote}</q>
              ) : (
                <em>no quote</em>
              )}
            </dd>

            <dt className="text-neutral-500">Section</dt>
            <dd>{citation.sectionNumber}</dd>
          </dl>

          {citation.verdict === "fabricated" ? (
            <p className="mt-3 text-neutral-600 italic">
              No model call — quote not present in source.
            </p>
          ) : (
            <ProbabilityBars probabilities={citation.probabilities} />
          )}

          {!citation.autoAccept && (
            <button
              type="button"
              className="mt-3 rounded bg-neutral-900 px-2 py-1 text-xs text-white"
            >
              Review
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function ProbabilityBars({
  probabilities,
}: {
  probabilities: Record<string, number> | null;
}) {
  if (!probabilities) return null;
  const order = ["supports", "contradicts", "says_nothing"] as const;
  const colorFor = {
    supports: "#0E7C86",
    contradicts: "#A3288C",
    says_nothing: "#D89614",
  };
  return (
    <div className="mt-3">
      <div className="flex h-4 w-full overflow-hidden rounded">
        {order.map((key) => {
          const p = probabilities[key] ?? 0;
          return (
            <div
              key={key}
              style={{
                width: `${(p * 100).toFixed(2)}%`,
                background: colorFor[key],
              }}
              title={`${key}: ${(p * 100).toFixed(1)}%`}
            />
          );
        })}
      </div>
      <ul className="mt-1 flex gap-3 text-xs text-neutral-600">
        {order.map((key) => (
          <li key={key}>
            {key}: {((probabilities[key] ?? 0) * 100).toFixed(1)}%
          </li>
        ))}
      </ul>
    </div>
  );
}
