/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// app/pipeline/two-speed-verifier.ts
"use server";

import { TypeSafeClient, choice, noul } from "@typesafe-ai/sdk";
import { performance } from "node:perf_hooks";

// ---------------------------------------------------------------------------
// Thresholds
// ---------------------------------------------------------------------------
//
// AUTO_ACCEPT is 0.9 here, not 0.8 as in Exercise 1. The reason is that the
// consequence of a wrong verdict here is user-visible: a citation marked
// "contradicted" suppresses the entire answer to the user, and a citation
// marked "verified" is shown without any warning. Exercise 1 ran on an
// internal corpus where a reviewer was still reading the flagged set. Here,
// the accept bar must be higher, because the cost of a false conviction or
// a false acquittal is paid by the end user.
//
// REVIEW_LOWER is the floor below which an ESCALATED contradict is taken as
// a genuine conflict. Between REVIEW_LOWER and AUTO_ACCEPT, we route to a
// human. Below REVIEW_LOWER, we route to the slow verifier, because a
// near-zero-confidence "contradicted" is the signal that the fast model had
// no real information — the fast reading of a section it cannot parse
// should not be the reading we act on.
const AUTO_ACCEPT = 0.9;
const REVIEW_LOWER = 0.4;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated";

export type PipelineStage =
  | { kind: "fast-verify"; claim: string; section: string }
  | { kind: "slow-verify"; claim: string; section: string; reason: string }
  | { kind: "human-review"; citationId: string; reason: string }
  | { kind: "pass"; verdict: Verdict }
  | { kind: "block"; verdict: "contradicted" | "fabricated"; reason: string };

export interface Citation {
  id: string;
  claim: string;
  quote: string | null;
  section: string;
}

export interface PipelineResult {
  citationId: string;
  verdict: Verdict | "unverified";
  relation: string | null;
  confidence: number | null;
  autoAccept: boolean;
  stage: "fast" | "slow" | "human" | "error";
  reason: string | null;
  fastMs: number;
  slowMs: number;
  totalMs: number;
}

// ---------------------------------------------------------------------------
// Fast verifier (identical shape to Exercise 1)
// ---------------------------------------------------------------------------

const client = new TypeSafeClient();

const relationQuestion = choice("How does the section relate to the claim?", {
  supports: "The section states the claim or directly implies that it is true",
  contradicts:
    "The section states the opposite of the claim or implies it is false",
  says_nothing:
    "The section does not address what the claim asserts, either way",
});

async function fastVerify(
  citation: Citation,
  sectionBody: string,
): Promise<{ stage: PipelineStage; verdict: Verdict; relation: string; confidence: number }> {
  const t0 = performance.now();
  const response = await client.systemOne({
    state: { claim: citation.claim, section: sectionBody },
    questions: { relation: relationQuestion },
  });
  void t0; // timing captured by the caller; kept here for local logging if needed

  const answer = response.answers.relation;
  const relation = answer.choice as "supports" | "contradicts" | "says_nothing";
  const confidence = answer.confidence;

  const verdict: Verdict =
    relation === "supports"
      ? "verified"
      : relation === "contradicts"
        ? "contradicted"
        : "unsupported";

  // --- Confidence-band routing -------------------------------------------
  // Above AUTO_ACCEPT: pass through with the fast verdict.
  if (confidence >= AUTO_ACCEPT) {
    return { stage: { kind: "pass", verdict }, verdict, relation, confidence };
  }

  // Below AUTO_ACCEPT:
  //   - For a "contradicted" verdict, escalate to the slow verifier, because
  //     a false contradiction suppresses the answer for the user.
  //   - For anything else, route to human review.
  if (verdict === "contradicted") {
    return {
      stage: {
        kind: "slow-verify",
        claim: citation.claim,
        section: sectionBody,
        reason: "low-confidence-contradicted",
      },
      verdict,
      relation,
      confidence,
    };
  }
  return {
    stage: {
      kind: "human-review",
      citationId: citation.id,
      reason: "mid-band-uncertain",
    },
    verdict,
    relation,
    confidence,
  };
}

// ---------------------------------------------------------------------------
// Slow verifier: a DECOMPOSITION, not a bigger model
// ---------------------------------------------------------------------------
//
// The chapter is emphatic that Jev is a decision model, not a reasoning
// model, and that the way to get more out of it is not to ask for more
// reasoning but to split the judgment into narrower questions. The slow
// verifier is exactly that: two orthogonal noul questions that together
// disambiguate the case the fast choice question could not settle.
//
// Why two questions and not one? Because "does the section support the
// claim" and "does the section contradict the claim" are genuinely separate
// judgments. A section can be silent on both (irrelevant), assert both
// (contradictory source), or assert exactly one. The two-answer projection
// gives us four response shapes and a case for each.

const slowQuestions = {
  statesProposition: noul(
    "Does the section state the specific proposition the claim relies on?",
  ),
  statesOpposite: noul(
    "Does the section state the opposite of what the claim asserts?",
  ),
};

async function slowVerify(
  citation: Citation,
  sectionBody: string,
): Promise<{ stage: PipelineStage; verdict: Verdict | "unverified"; relation: string | null; confidence: number }> {
  const response = await client.systemOne({
    state: { claim: citation.claim, section: sectionBody },
    questions: slowQuestions,
  });

  const statesProposition = response.answers.statesProposition.noul;
  const statesOpposite = response.answers.statesOpposite.noul;

  // Human-review wins over any automatic verdict when the two answers
  // DISAGREE *or* when both are high — a section that both asserts and
  // denies the proposition is not something a rule can resolve.
  const bothHigh = statesProposition >= 0.5 && statesOpposite >= 0.5;
  const bothLow = statesProposition < 0.5 && statesOpposite < 0.5;
  const disagree = Math.abs(statesProposition - statesOpposite) < 0.2;

  if (bothHigh || disagree) {
    return {
      stage: {
        kind: "human-review",
        citationId: citation.id,
        reason: "slow-verifier-ambiguous",
      },
      verdict: "unverified",
      relation: null,
      confidence: Math.max(statesProposition, statesOpposite),
    };
  }

  if (statesOpposite >= 0.5 && statesProposition < 0.5) {
    return {
      stage: { kind: "block", verdict: "contradicted", reason: "slow-verifier" },
      verdict: "contradicted",
      relation: "contradicts",
      confidence: statesOpposite,
    };
  }

  if (statesProposition >= 0.5 && statesOpposite < 0.5) {
    return {
      stage: { kind: "pass", verdict: "verified" },
      verdict: "verified",
      relation: "supports",
      confidence: statesProposition,
    };
  }

  // bothLow
  return {
    stage: { kind: "pass", verdict: "unsupported" },
    verdict: "unsupported",
    relation: "says_nothing",
    confidence: 1 - Math.max(statesProposition, statesOpposite),
  };
}

// ---------------------------------------------------------------------------
// Orchestrator
// ---------------------------------------------------------------------------

export interface PipelineAggregate {
  results: PipelineResult[];
  fastPathCount: number;
  slowPathCount: number;
  humanReviewCount: number;
  errorCount: number;
}

export async function runPipeline(
  citations: Citation[],
  locateFn: (c: Citation) => { sectionBody: string | null },
): Promise<PipelineAggregate> {
  const totalStart = performance.now();

  // Phase 1: fast verifications in parallel.
  const fastResults = await Promise.all(
    citations.map(async (citation) => {
      const fastStart = performance.now();
      const located = locateFn(citation);

      // The fabricated path skips the model entirely; still counts as "fast".
      if (located.sectionBody === null) {
        return {
          citation,
          stage: { kind: "block", verdict: "fabricated", reason: "quote-missing" } as PipelineStage,
          verdict: "fabricated" as Verdict | "unverified",
          relation: null,
          confidence: null,
          fastMs: performance.now() - fastStart,
          slowMs: 0,
          stageKind: "fast" as const,
          reason: "quote-missing",
        };
      }

      try {
        const r = await fastVerify(citation, located.sectionBody);
        return {
          citation,
          stage: r.stage,
          verdict: r.verdict as Verdict | "unverified",
          relation: r.relation,
          confidence: r.confidence,
          fastMs: performance.now() - fastStart,
          slowMs: 0,
          stageKind: "fast" as const,
          reason: null,
        };
      } catch (err) {
        // A verifier's failure mode is to produce a REVIEW, not a pass.
        // This is the single most important operational rule in the
        // pipeline: a 429 or a 5xx must never look like a confident "yes".
        return {
          citation,
          stage: {
            kind: "human-review",
            citationId: citation.id,
            reason: "upstream-error",
          } as PipelineStage,
          verdict: "unverified" as Verdict | "unverified",
          relation: null,
          confidence: null,
          fastMs: performance.now() - fastStart,
          slowMs: 0,
          stageKind: "error" as const,
          reason: "upstream-error",
        };
      }
    }),
  );

  // Phase 2: slow verifications in parallel, only for the escalated set.
  const toEscalate = fastResults.filter((r) => r.stage.kind === "slow-verify");
  const slowMap = new Map<string, { verdict: Verdict | "unverified"; relation: string | null; confidence: number; slowMs: number }>();

  await Promise.all(
    toEscalate.map(async (r) => {
      const slowStart = performance.now();
      try {
        const located = locateFn(r.citation);
        const result = await slowVerify(r.citation, located.sectionBody!);
        slowMap.set(r.citation.id, {
          verdict: result.verdict,
          relation: result.relation,
          confidence: result.confidence,
          slowMs: performance.now() - slowStart,
        });
      } catch {
        slowMap.set(r.citation.id, {
          verdict: "unverified",
          relation: null,
          confidence: 0,
          slowMs: performance.now() - slowStart,
        });
      }
    }),
  );

  // Phase 3: reconcile into final results.
  const results: PipelineResult[] = fastResults.map((r) => {
    const slow = slowMap.get(r.citation.id);
    const totalMs = performance.now() - totalStart;

    // No escalation: the fast result stands as-is.
    if (!slow) {
      const autoAccept =
        r.stage.kind === "pass" && (r.confidence ?? 0) >= AUTO_ACCEPT;
      return {
        citationId: r.citation.id,
        verdict: r.verdict,
        relation: r.relation,
        confidence: r.confidence,
        autoAccept,
        stage: r.stageKind,
        reason: r.reason,
        fastMs: r.fastMs,
        slowMs: 0,
        totalMs,
      };
    }

    // Slow result resolved the case.
    const resolved = slow.verdict !== "unverified";
    return {
      citationId: r.citation.id,
      verdict: slow.verdict,
      relation: slow.relation,
      confidence: slow.confidence,
      autoAccept: resolved && slow.confidence >= AUTO_ACCEPT,
      stage: resolved ? "slow" : "human",
      reason: resolved ? "escalated-and-resolved" : "slow-verifier-ambiguous",
      fastMs: r.fastMs,
      slowMs: slow.slowMs,
      totalMs,
    };
  });

  const fastPathCount = results.filter((r) => r.stage === "fast").length;
  const slowPathCount = results.filter((r) => r.stage === "slow").length;
  const humanReviewCount = results.filter((r) => r.stage === "human").length;
  const errorCount = results.filter((r) => r.reason === "upstream-error").length;

  // Health check: if the slow path fires more than 20% of the time, we do
  // not have a two-speed pipeline; we have two slow pipelines. Investigate
  // in this order:
  //   1. Fast-verifier specification. Is the question ambiguous? Is the
  //      section too long? Are the criteria distinguishing what they say?
  //   2. Retrieval. If the retrieved sections do not actually support the
  //      claims, the fast verifier's low confidence is a correct reading of
  //      a correctly-bad input, and no amount of prompt work will help.
  //   3. Threshold. Only after 1 and 2 are ruled out.
  // In practice, item 1 is almost always the cause and item 3 is almost
  // never the cause.
  void (fastPathCount / Math.max(results.length, 1));

  return {
    results,
    fastPathCount,
    slowPathCount,
    humanReviewCount,
    errorCount,
  };
}

// ---------------------------------------------------------------------------
// Fallback for the case where the slow verifier ALSO returns human-review
// ---------------------------------------------------------------------------
//
// Requirement 8: mark the citation "unverified" in the output and display
// the answer with a pending badge, rather than suppressing the whole answer.
// Rationale: suppressing an entire answer because one out of forty citations
// could not be resolved punishes the user for a failure mode they cannot
// act on. Showing the answer with a pending marker lets the user read it,
// lets a reviewer see the pending citation in the queue, and keeps the audit
// log faithful to what was actually shown.
//
// The audit entry for such a citation records:
//   verdict: "unverified"
//   stage: "human"
//   reason: "slow-verifier-ambiguous" | "upstream-error"
// so the reconciliation job (Ex. 5) sees the pending state explicitly.

// ---------------------------------------------------------------------------
// Sixteen-cell decision table (fast verdict × confidence) × (slow verdict)
// ---------------------------------------------------------------------------
/*
  Let F = fast verdict, C = fast confidence, S = slow verdict (if any).

  Case 1: C >= 0.9.  S is undefined.
    → autoAccept = true. Verdict is F. This is the fast path entirely.

  Case 2: C < 0.9, F != "contradicted".  S is undefined.
    → human-review. Verdict is F (unverified for display purposes).

  Case 3: C < 0.9, F == "contradicted".  S runs.
    Case 3a: S == "contradicted", conf_s >= 0.9.
      → autoAccept = true. Verdict is "contradicted". This is the whole
        reason we escalated: a low-confidence "contradicted" that survives
        a second look is stronger evidence, not weaker.
    Case 3b: S == "contradicted", conf_s < 0.9.
      → human-review. The slow verifier agrees but is not confident.
    Case 3c: S == "verified".
      → autoAccept = true. Verdict is "verified". The fast verifier was
        wrong. This is the single most valuable outcome of the escalation:
        a false conviction prevented.
    Case 3d: S == "unsupported".
      → autoAccept = true. Verdict is "unsupported".
    Case 3e: S == "unverified" (ambiguous).
      → human-review. Verdict displayed as "unverified"; answer shown with
        a pending badge.

  The genuinely ambiguous cells are 3b and 3e. Every other cell has a
  principled answer. 3b is ambiguous because the slow verifier agrees with
  the fast one, but at a confidence that would normally route to review;
  the reason to prefer human-review over auto-block here is that the
  consequence of a wrong auto-block is a suppressed answer for the user,
  and a both-times-low-confidence contradiction is not enough to justify
  that. 3e is ambiguous by construction — the two slow nouls disagreed.
*/
