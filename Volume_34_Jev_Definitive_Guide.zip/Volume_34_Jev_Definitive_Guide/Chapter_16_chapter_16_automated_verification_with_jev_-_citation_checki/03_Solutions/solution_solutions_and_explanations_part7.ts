/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// app/calibration/self-calibrating-verifier.ts
"use server";

import { createHash } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// The two calibrated numbers, and what they mean to a reviewer
// ---------------------------------------------------------------------------
//
// If I have to explain these two numbers to a product manager in one
// paragraph without saying "F1 score", here is what I say:
//
//   FUZZY_MATCH_RATIO is the boundary between "we consider this quote to be
//   in the source" and "we consider it a fabrication". Below the boundary,
//   a citation never reaches a model — it is provably not in the document
//   and no reviewer will ever see it in the accept path. Above the boundary,
//   the quote is treated as present, and the model judges whether the
//   section it came from supports the claim.
//
//   AUTO_ACCEPT is the confidence below which a model's verdict is routed
//   to a human instead of being acted on automatically. Anything at or
//   above this number goes straight into the user's answer without a
//   review step. Anything below it waits.
//
// The two numbers are the only knobs, and they are calibrated together: a
// lower FUZZY_MATCH_RATIO sends more near-misses to the model, where the
// model may or may not be confident; a higher AUTO_ACCEPT routes more of
// the model's calls to reviewers. The pair defines the boundary between
// "the pipeline decided" and "a person decided."

let FUZZY_MATCH_RATIO = 0.75;
let AUTO_ACCEPT = 0.8;

// ---------------------------------------------------------------------------
// The fuzzy matcher (in code, never in a Jev prompt)
// ---------------------------------------------------------------------------
//
// Rationale for the algorithm: the failure mode we are trying to catch is a
// *light paraphrase* — the generator trimmed a clause or swapped a
// synonymous noun. Edit distance normalized by length handles character-
// level noise but underweights word-level substitutions (a swapped noun is
// a large edit at the character level even when the meaning is preserved).
// Token-set F1 handles word-level substitution well but is blind to word
// order, which is relevant when a paraphrase reverses a clause.
//
// We combine them: Jaccard over the multiset of normalized tokens, which
// is fast, deterministic, and defensible. It ignores order, which means it
// will accept "the cat sat on the mat" and "the mat sat on the cat" as a
// fuzzy match — but that is a *feature* for our purposes, because the whole
// point of the fuzzy stage is to route the citation to the model, where
// the section-vs-claim judgment happens. A quote that appears in the source
// in a different order is still a quote from the source, and the model is
// the right place to judge whether the reordering changed the meaning.
//
// Deterministic across runs: sorting the token sets and hashing the result
// would be the wrong move here, because we need the ratio itself, not a
// hash. Tokenize + Jaccard is stable, integer-counted, and reproducible.

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length > 0);
}

function jaccard(a: Set<string>, b: Set<string>): number {
  let intersection = 0;
  for (const token of a) if (b.has(token)) intersection++;
  const union = a.size + b.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

export function fuzzyMatchRatio(quote: string, section: string): number {
  const q = new Set(tokenize(quote));
  const s = new Set(tokenize(section));
  return jaccard(q, s);
}

// ---------------------------------------------------------------------------
// Core verifier, parameterized on the two thresholds
// ---------------------------------------------------------------------------

export interface Citation {
  id: string;
  claim: string;
  quote: string | null;
  section: string; // section NUMBER as claimed by the generator
}

export interface LabeledExample extends Citation {
  groundTruth: "verified" | "unsupported" | "contradicted" | "fabricated";
}

export type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated" | "unverified";

export interface VerificationOutcome {
  verdict: Verdict;
  confidence: number | null;
  autoAccept: boolean;
  stage: "exact" | "fuzzy" | "missing" | "model" | "human";
}

const client = new TypeSafeClient();
const relationQuestion = choice("How does the section relate to the claim?", {
  supports: "The section states the claim or directly implies that it is true",
  contradicts: "The section states the opposite of the claim or implies it is false",
  says_nothing: "The section does not address what the claim asserts, either way",
});

async function verifyWithThresholds(
  citation: Citation,
  sections: Map<string, string>,
  autoAccept: number,
  fuzzyThreshold: number,
): Promise<VerificationOutcome> {
  const sectionBody = sections.get(citation.section);
  if (!sectionBody) {
    return {
      verdict: "fabricated",
      confidence: null,
      autoAccept: true,
      stage: "missing",
    };
  }

  if (citation.quote !== null) {
    // Exact match: normalize + substring, code-only.
    const normalizedQuote = citation.quote.replace(/\s+/g, " ").trim();
    const normalizedSection = sectionBody.replace(/\s+/g, " ").trim();
    const exact = normalizedSection.includes(normalizedQuote);

    if (!exact) {
      // Fuzzy match: token-set Jaccard over the whole section.
      const ratio = fuzzyMatchRatio(citation.quote, sectionBody);
      if (ratio < fuzzyThreshold) {
        return {
          verdict: "fabricated",
          confidence: null,
          autoAccept: true,
          stage: "missing",
        };
      }
      // Note: even a fuzzy match lands in the model call below. The model
      // is scoped to the specific section code has already identified, so
      // the audit trail can still record the section id.
    }
  }

  // Jev fires only AFTER the string layer decided present-or-absent.
  const response = await client.systemOne({
    state: { claim: citation.claim, section: sectionBody },
    questions: { relation: relationQuestion },
  });
  const answer = response.answers.relation;
  const relation = answer.choice as "supports" | "contradicts" | "says_nothing";
  const verdict: Verdict =
    relation === "supports"
      ? "verified"
      : relation === "contradicts"
        ? "contradicted"
        : "unsupported";

  return {
    verdict,
    confidence: answer.confidence,
    autoAccept: answer.confidence >= autoAccept,
    stage: "model",
  };
}

// ---------------------------------------------------------------------------
// Confusion matrix
// ---------------------------------------------------------------------------

type ConfusionMatrix = Record<Verdict, Record<string, number>>;

function emptyMatrix(): ConfusionMatrix {
  const predictions: Verdict[] = ["verified", "unsupported", "contradicted", "fabricated", "unverified"];
  const truths = ["verified", "unsupported", "contradicted", "fabricated"];
  const m = {} as ConfusionMatrix;
  for (const p of predictions) {
    m[p] = {};
    for (const t of truths) m[p][t] = 0;
  }
  return m;
}

// ---------------------------------------------------------------------------
// Calibration loop
// ---------------------------------------------------------------------------
//
// Bounded, deterministic grid search — no random sampling, no stochastic
// search. A verifier whose thresholds vary between runs reintroduces exactly
// the nondeterminism the rest of the pipeline has been designed to remove.
//
// Grid:
//   AUTO_ACCEPT       in {0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95}
//   FUZZY_MATCH_RATIO in {0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90}
//
// Objective: maximize F1 of the "verified" class subject to
//   contradicted-false-negative-rate == 0.
// A false negative on contradicted means a real contradiction was reported
// as verified, which is the worst possible failure the pipeline can make.

const AUTO_ACCEPT_GRID = [0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95];
const FUZZY_GRID = [0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9];

export interface CalibrationResult {
  autoAccept: number;
  fuzzyMatchRatio: number;
  f1Verified: number;
  contradictedFalseNegativeRate: number;
  confusionMatrix: ConfusionMatrix;
}

export async function calibrate(
  examples: LabeledExample[],
  sections: Map<string, string>,
): Promise<CalibrationResult> {
  const cache = new Map<string, VerificationOutcome>();

  // Cache Jev calls across the grid: the (claim, section) pair is the same
  // for every (autoAccept, fuzzyThreshold) combination, so a cache keyed on
  // (claim, section, fuzzyThreshold-decision) saves an enormous number of
  // calls. The fuzzy threshold affects only the *decision to call*, not the
  // call itself.
  async function outcome(
    example: LabeledExample,
    autoAccept: number,
    fuzzyThreshold: number,
  ): Promise<VerificationOutcome> {
    const key = `${example.id}::${autoAccept}::${fuzzyThreshold}`;
    const hit = cache.get(key);
    if (hit) return hit;
    const r = await verifyWithThresholds(example, sections, autoAccept, fuzzyThreshold);
    cache.set(key, r);
    return r;
  }

  let best: CalibrationResult | null = null;

  for (const autoAccept of AUTO_ACCEPT_GRID) {
    for (const fuzzy of FUZZY_GRID) {
      const matrix = emptyMatrix();

      // Sequential, not parallel: determinism matters more than speed in
      // a calibration run, and the Jev cache in the SDK already dedupes
      // across the grid.
      for (const example of examples) {
        const r = await outcome(example, autoAccept, fuzzy);
        // If not autoAccept, the outcome is "unverified" from the pipeline's
        // point of view, because a human sees it before it ships.
        const predicted: Verdict = r.autoAccept ? r.verdict : "unverified";
        matrix[predicted][example.groundTruth]++;
      }

      // F1 of the "verified" class.
      const tpVerified = matrix.verified.verified;
      const fpVerified = Object.values(matrix.verified).reduce((a, b) => a + b, 0) - tpVerified;
      const fnVerified = Object.values(matrix).reduce((a, row) => a + row.verified, 0) - tpVerified;
      const precision = tpVerified / Math.max(tpVerified + fpVerified, 1);
      const recall = tpVerified / Math.max(tpVerified + fnVerified, 1);
      const f1 = (2 * precision * recall) / Math.max(precision + recall, 1e-9);

      // Contradicted false-negative rate: ground truth is contradicted, but
      // the pipeline reported verified. Any nonzero value disqualifies the
      // configuration outright.
      const contradictedTotal = Object.values(matrix).reduce(
        (a, row) => a + row.contradicted,
        0,
      );
      const contradictedAsVerified = matrix.verified.contradicted;
      const contradictedFnr =
        contradictedTotal === 0 ? 0 : contradictedAsVerified / contradictedTotal;

      if (contradictedFnr > 0) continue;

      if (!best || f1 > best.f1Verified) {
        best = {
          autoAccept,
          fuzzyMatchRatio: fuzzy,
          f1Verified: f1,
          contradictedFalseNegativeRate: contradictedFnr,
          confusionMatrix: matrix,
        };
      }
    }
  }

  if (!best) {
    throw new Error(
      "calibration: no (AUTO_ACCEPT, FUZZY_MATCH_RATIO) pair achieved zero contradicted false-negative rate.",
    );
  }

  // Write the calibration artifact next to the audit log so a reviewer can
  // recover the exact parameters used for the run.
  await writeFile(
    "calibration.json",
    JSON.stringify(
      {
        autoAccept: best.autoAccept,
        fuzzyMatchRatio: best.fuzzyMatchRatio,
        f1Verified: best.f1Verified,
        contradictedFalseNegativeRate: best.contradictedFalseNegativeRate,
        confusionMatrix: best.confusionMatrix,
        calibratedAt: new Date().toISOString(),
        datasetHash: createHash("sha256")
          .update(JSON.stringify(examples.map((e) => e.id).sort()))
          .digest("hex"),
      },
      null,
      2,
    ),
    "utf8",
  );

  FUZZY_MATCH_RATIO = best.fuzzyMatchRatio;
  AUTO_ACCEPT = best.autoAccept;
  return best;
}

// ---------------------------------------------------------------------------
// Why code owns fuzzy matching, not Jev
// ---------------------------------------------------------------------------
//
// If we asked Jev "is this quote approximately in this document?", the answer
// would be a probability, and the audit trail would record a model call for
// what is fundamentally a string-comparison question. That has three costs:
//
//   1. Auditing. "Why was this citation marked fabricated?" would have
//      answer "a model said so, at 0.83". A reviewer cannot re-run a string
//      comparison and check it; they can only trust the recorded probability.
//
//   2. Cost. The overwhelming majority of citations land on the exact-match
//      path, and paying a Jev call for each one would be absurd.
//
//   3. Layer confusion. The string layer decides WHAT is compared; the model
//      layer decides WHAT IT MEANS. Fuzzy matching is a WHAT decision — the
//      matcher's job is to find the span in the source, not to judge it.
