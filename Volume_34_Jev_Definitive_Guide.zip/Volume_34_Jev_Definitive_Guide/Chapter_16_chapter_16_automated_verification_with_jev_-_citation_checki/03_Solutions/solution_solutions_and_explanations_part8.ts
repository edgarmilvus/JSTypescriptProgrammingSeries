/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// app/audit/durable-audit-log.ts
"use server";

import { createHash } from "node:crypto";
import { appendFile, readFile, writeFile } from "node:fs/promises";
import { open, type FileHandle } from "node:fs/promises";

// Reuse the AuditEntry type and canonicalizer from Exercise 2.
import { type AuditEntry, hashState } from "./append-only-audit-log";

type PendingEntry = Omit<AuditEntry, "entryHash" | "previousHash">;
type ChainedEntry = Omit<AuditEntry, "entryHash">;

// ---------------------------------------------------------------------------
// AuditEntry shape extended for retry chains and per-attempt provenance
// ---------------------------------------------------------------------------
//
// The base AuditEntry has one modelRequested / modelReturned pair. That is
// insufficient when the SDK's retry policy fires: the failing attempt and
// the succeeding attempt both produced answers from (potentially) different
// model versions, and we want the audit trail to show both. The extension
// below is a strict superset: the single-attempt fields remain populated
// with the FINAL attempt, and `attempts[]` records every attempt including
// the discarded ones. Existing verify() logic does not need to change,
// because the canonical a form of the entry still hashes the fields that
// were already there.

export interface AuditAttempt {
  requestId: string | null; // from the x-typesafe-request-id header on WithResponse<T>
  modelReturned: string;
  verdict: string; // whatever the attempt produced
  confidence: number | null;
  discarded: boolean; // true for attempts superseded by a later one
  errorKind: string | null; // "rate_limit" | "timeout" | "server_error" | null
}

export interface DurableAuditEntry extends AuditEntry {
  attempts: AuditAttempt[]; // one per SDK attempt, ordered
  pinnedModelId: string; // the versioned model id (jev-1.13.0), not the alias
}

// ---------------------------------------------------------------------------
// Sink interface
// ---------------------------------------------------------------------------

export interface AuditSink {
  // Append one entry and do not return until the write is durable. The
  // word "durable" here has a specific meaning:
  //   InMemorySink: durable until the process dies — that is not durable in
  //     any meaningful production sense, and it exists only for tests.
  //   FileSystemSink: durable once fsync() has returned (the bytes are on
  //     the storage device, not merely in the kernel page cache).
  //   Anything else (a queue, a network service): durable once the sink's
  //     own contract says so. Do NOT treat "the write to stdout returned"
  //     as durable; stdout is buffered, and the log shipper is a separate
  //     process whose failure is invisible to us.
  append(entry: DurableAuditEntry): Promise<void>;
  readAll(): Promise<readonly DurableAuditEntry[]>;
  tip(): Promise<DurableAuditEntry | null>;
}

export class InMemorySink implements AuditSink {
  private entries: DurableAuditEntry[] = [];
  async append(entry: DurableAuditEntry): Promise<void> {
    this.entries.push(entry);
  }
  async readAll(): Promise<readonly DurableAuditEntry[]> {
    return this.entries;
  }
  async tip(): Promise<DurableAuditEntry | null> {
    return this.entries[this.entries.length - 1] ?? null;
  }
}

export class FileSystemSink implements AuditSink {
  private fileHandle: FileHandle | null = null;

  constructor(private readonly path: string) {}

  private async handle(): Promise<FileHandle> {
    if (this.fileHandle) return this.fileHandle;
    // "a" = append mode; the file is created if it does not exist.
    this.fileHandle = await open(this.path, "a");
    return this.fileHandle;
  }

  async append(entry: DurableAuditEntry): Promise<void> {
    const handle = await this.handle();
    // One JSON object per line (JSONL); each line is independently parseable.
    await handle.write(JSON.stringify(entry) + "\n");
    // fsync() is what turns "the kernel accepted the write" into "the
    // storage device has the bytes". Without it, a power loss after this
    // append can leave the file truncated mid-line, which is exactly the
    // failure mode an append-only audit log must not have.
    await handle.sync();
  }

  async readAll(): Promise<readonly DurableAuditEntry[]> {
    try {
      const content = await readFile(this.path, "utf8");
      return content
        .split("\n")
        .filter((line) => line.length > 0)
        .map((line) => JSON.parse(line) as DurableAuditEntry);
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw err;
    }
  }

  async tip(): Promise<DurableAuditEntry | null> {
    const all = await this.readAll();
    return all[all.length - 1] ?? null;
  }
}

// ---------------------------------------------------------------------------
// The log, writing through the sink
// ---------------------------------------------------------------------------

function canonicalizeDurable(entry: Omit<DurableAuditEntry, "entryHash">): string {
  // Extend the canonical form used in Exercise 2 by appending the new fields
  // in a fixed order. This is a schema version bump: existing chains hashed
  // with the old canonicalizer remain verifiable by the old canonicalizer,
  // and new entries use the new one. A migration that rehashes old entries
  // is *wrong* — it would break the "any change to canonical form breaks
  // every hash in the existing chain" rule the exercise establishes.
  const base = {
    sequence: entry.sequence,
    timestamp: entry.timestamp,
    citationId: entry.citationId,
    stateHash: entry.stateHash,
    modelRequested: entry.modelRequested,
    modelReturned: entry.modelReturned,
    verdict: entry.verdict,
    relation: entry.relation,
    confidence: entry.confidence,
    autoAccept: entry.autoAccept,
    previousHash: entry.previousHash,
  };
  return JSON.stringify({
    ...base,
    attempts: entry.attempts,
    pinnedModelId: entry.pinnedModelId,
  });
}

function hashDurable(entry: Omit<DurableAuditEntry, "entryHash">): string {
  return createHash("sha256").update(canonicalizeDurable(entry), "utf8").digest("hex");
}

export class DurableAuditLog {
  private cachedTip: DurableAuditEntry | null = null;
  private cachedSize = 0;

  constructor(private readonly sink: AuditSink) {}

  async init(): Promise<void> {
    const all = await this.sink.readAll();
    this.cachedTip = all[all.length - 1] ?? null;
    this.cachedSize = all.length;
  }

  get size(): number {
    return this.cachedSize;
  }

  async append(pending: PendingEntry & { attempts: AuditAttempt[]; pinnedModelId: string }): Promise<DurableAuditEntry> {
    // Adjust for the extra fields carried by the durable schema.
    const tip = this.cachedTip;
    const previousHash = tip ? tip.entryHash : "GENESIS";

    if (pending.sequence !== this.cachedSize) {
      throw new Error(
        `durable-audit: sequence out of order (expected ${this.cachedSize}, got ${pending.sequence})`,
      );
    }

    const chained: Omit<DurableAuditEntry, "entryHash"> = {
      ...pending,
      previousHash,
    };
    const entry: DurableAuditEntry = { ...chained, entryHash: hashDurable(chained) };

    // Duable write FIRST, then update the in-memory tip. If the process
    // dies between the sink.append() returning and the cachedTip update,
    // the entry is on disk and will be picked up on next init(). If we
    // updated the cache first, a crash could lose the tip while the sink
    // has the entry — a real desync.
    await this.sink.append(entry);
    this.cachedTip = entry;
    this.cachedSize++;
    return entry;
  }

  // Same recompute-from-content verify() as Exercise 2. Order-independent
  // of the retry chain: attempts[] is part of the hashed content.
  async verify(): Promise<
    { valid: true } | { valid: false; brokenAt: number; reason: string }
  > {
    const all = await this.sink.readAll();
    if (all.length === 0) return { valid: true };
    if (all[0].previousHash !== "GENESIS")
      return { valid: false, brokenAt: 0, reason: "genesis-chain-broken" };
    for (let i = 0; i < all.length; i++) {
      const entry = all[i];
      const { entryHash, ...rest } = entry;
      if (hashDurable(rest) !== entryHash) {
        return { valid: false, brokenAt: i, reason: "entry-hash-mismatch" };
      }
      if (i > 0 && entry.previousHash !== all[i - 1].entryHash) {
        return { valid: false, brokenAt: i, reason: "previous-hash-mismatch" };
      }
    }
    return { valid: true };
  }
}

// ---------------------------------------------------------------------------
// Requirement 2: crash mid-request — do we need a write-ahead audit log?
// ---------------------------------------------------------------------------
//
// The scenario: the process dies after the Jev call returns (the model has
// already decided) but before the audit entry is appended. From the pipeline's
// perspective, nothing happened; from the reviewer's, a decision existed and
// left no trace.
//
// Two positions:
//
// (A) Accept it. The audit trail is a record of *decisions that reached a
//     user*, not a record of *model invocations*. If the process died before
//     the entry was written, no user ever saw the verdict, and the citation
//     will be re-verified on the next request. This is fine for a
//     best-effort audit trail, but it is *not* what a compliance officer
//     means by "audit trail".
//
// (B) Write-ahead. Before the Jev call, write an intent entry with a fresh
//     sequence number and a stateHash, marked "in-flight". After the Jev
//     call, write a completion entry with the verdict. A reader that sees
//     an in-flight entry with no completion knows that a decision was
//     underway when the process died, and can either ignore it (if the
//     verdict never reached a user) or flag it (if it did). This is the
//     correct posture for a compliance-critical trail, and it is the one
//     this exercise takes: the whole point of the exercise is a
//     *zero-hallucination audit trail*, and a trail that silently loses
//     entries under crash is exactly the failure the term "zero-hallucination"
//     is meant to rule out.
//
// Implementation note: the write-ahead log does NOT need to block the Jev
// call. The intent entry can be written asynchronously in parallel with the
// call, and the completion entry is written when the call returns. A crash
// between the two produces a trail with an intent and no completion — which
// is exactly the signal a reconciliation job needs.
//
// The exercise's question "must the pipeline be restructured so that
// verification is not permitted to proceed until the audit entry from the
// preceding step has confirmed durable" — the answer is YES if you want the
// strong guarantee, and the write-ahead design is what that guarantee looks
// like.

// ---------------------------------------------------------------------------
// Requirement 3: concurrent appends
// ---------------------------------------------------------------------------
//
// Three families, one from each:
//
// Optimistic concurrency. Two writers both read tip at sequence N. Both
//   construct an entry with sequence N+1 and previousHash = tip.entryHash.
//   Both attempt a conditional write ("write only if the current tip is
//   still X"). One wins; the other retries with the new tip. This is the
//   right shape for a store that offers compare-and-swap (DynamoDB,
//   Postgres with a WHERE clause, etc.). It is the *least coordination*
//   solution, but it requires the sink to expose a compare-and-swap
//   primitive, which a flat file does not.
//
// Serialization. A single-writer goroutine (or a Node async queue) owns
//   the tip. All appends go through a queue; the writer pulls, hashes,
//   writes, and updates the tip. Back-pressure is the queue's max depth;
//   when the queue fills, callers wait. This is the simplest correct
//   design for a single-process service, and it is what we would ship for
//   a Node server with one writer per pod. Its weak point is that
//   horizontal scaling creates multiple writers who now need their own
//   coordination layer, which is back to family one or three.
//
// Partitioning. Each writer (pod, shard, region) writes to its own chain.
//   A background job merges the shard chains into a main chain by
//   appending shard tips as ordinary entries. This scales linearly with
//   the number of writers, at the cost of an eventual-consistency window
//   during which an audit reader sees N parallel chains and no single
//   tip. The merge is itself an audit entry, so the merge is auditable.
//
// PREFERRED: Serialization for a single-process server, Partitioning for a
// distributed deployment, and Optimistic concurrency only when the sink
// already offers compare-and-swap. The reason this order: serialization
// has the fewest moving parts and is trivially correct; partitioning is
// what happens when serialization cannot be relied on; optimistic
// concurrency is what happens when the storage layer forces you into it.
//
// The one design mistake to avoid is a "best-effort" file lock. A lock that
// is not enforced by the filesystem (or by the store's compare-and-swap) is
// a suggestion, and a suggestion is what an adversary will exploit.

// ---------------------------------------------------------------------------
// Requirement 4: retry chains
// ---------------------------------------------------------------------------
//
// DurableAuditEntry.attempts[] carries one AuditAttempt per SDK attempt.
// The shape:
//
//   {
//     sequence: 417,
//     citationId: "c-9931",
//     stateHash: "<sha256>",
//     modelRequested: "jev-latest",
//     modelReturned: "jev-1.13.0",           // FINAL attempt's model version
//     pinnedModelId: "jev-1.13.0",           // pinned version, not the alias
//     verdict: "verified",
//     relation: "supports",
//     confidence: 0.94,
//     autoAccept: true,
//     attempts: [
//       { requestId: null, modelReturned: "",         verdict: "",        confidence: null, discarded: true,  errorKind: "rate_limit" },
//       { requestId: null, modelReturned: "",         verdict: "",        confidence: null, discarded: true,  errorKind: "timeout" },
//       { requestId: "req-abc-123", modelReturned: "jev-1.13.0", verdict: "verified", confidence: 0.94, discarded: false, errorKind: null },
//     ],
//     previousHash: "<hash of 416>",
//     entryHash: "<hash of this entry>",
//   }
//
// A reviewer looking at this entry can see: two attempts failed, the SDK
// retried, and the third succeeded. The discarded attempts carry no verdict
// because they did not produce one; their `errorKind` is what makes the
// entry legible.
//
// Accessing the requestId requires the SDK's withResponse() variant, which
// returns { data, response, requestId }. On the error path, the retry
// policy's retry callback gives access to the failing attempt's request
// metadata. Both need to be threaded into the audit append.

// ---------------------------------------------------------------------------
// Requirement 5: reconciliation job
// ---------------------------------------------------------------------------

export interface ReconciliationReport {
  fromSequence: number;
  toSequence: number;
  hashesIntact: boolean;
  brokenAt: number | null;
  sequenceGaps: number[]; // empty if none
  reverify:
    | { checked: number; matches: number; mismatches: number }
    | { skipped: true; reason: string };
}

export async function reconcile(
  log: DurableAuditLog,
  reVerify: (entry: DurableAuditEntry) => Promise<{ verdict: string; confidence: number | null } | { error: string }>,
  sinceSequence: number,
): Promise<ReconciliationReport> {
  const all = await log.sink.readAll();
  const window = all.filter((e) => e.sequence >= sinceSequence);

  // (a) Hash integrity.
  const integrity = await log.verify();
  const hashesIntact = integrity.valid;
  const brokenAt = integrity.valid ? null : integrity.brokenAt;

  // (b) Sequence gaps.
  const gaps: number[] = [];
  for (let i = 1; i < window.length; i++) {
    if (window[i].sequence !== window[i - 1].sequence + 1) {
      gaps.push(window[i - 1].sequence + 1);
    }
  }

  // (c) Re-verify autoAccepted entries against the pinned model id.
  //
  // The critical distinction: re-verifying against a moving alias like
  // "jev-latest" answers a different question than re-verifying against
  // the pinned version "jev-1.13.0". The alias can move between when the
  // entry was written and when it is reconciled; asking the current
  // jev-latest to reproduce a decision made by last month's jev-latest is
  // asking a different model the same question. The pinned id is what
  // makes the answer reproducible. Without pinning, "the audit trail is
  // verifiable" is a claim about the past that no one can check.
  let checked = 0;
  let matches = 0;
  let mismatches = 0;
  for (const entry of window) {
    if (!entry.autoAccept) continue; // human-reviewed entries are not auto-rechecked
    checked++;
    const result = await reVerify({ ...entry, modelRequested: entry.pinnedModelId });
    if ("error" in result) continue;
    if (result.verdict === entry.verdict) matches++;
    else mismatches++;
  }

  return {
    fromSequence: sinceSequence,
    toSequence: window[window.length - 1]?.sequence ?? sinceSequence,
    hashesIntact,
    brokenAt,
    sequenceGaps: gaps,
    reverify: { checked, matches, mismatches },
  };
}

// ---------------------------------------------------------------------------
// Requirement 6: can we still call the trail "verifiable" if the model is
// deprecated and can no longer be called?
// ---------------------------------------------------------------------------
//
// Yes, but the claim has to be stated carefully. The hash chain proves that
// no entry was altered, inserted, or deleted after the fact — that is a
// property of the *bytes*, and it survives model deprecation completely.
// What does not survive is the ability to re-derive the *decision*: we can
// no longer ask the pinned jev-1.13.0 whether it still believes the same
// thing, because the pinned jev-1.13.0 no longer exists to ask.
//
// The honest posture is to split the audit trail's claims into two
// categories. Category one — "nothing was tampered with" — is unconditionally
// verifiable, forever, because it is a property of the chain itself. Category
// two — "the decision was correct" — is *only* verifiable at the time it was
// made, and becomes a historical claim afterward: the decision was correct
// *according to a model that no longer exists*. A compliance officer reading
// a five-year-old audit trail is reading the first category with full
// assurance and the second category on the faith that nothing else has
// changed the meaning of "jev-1.13.0".
//
// The design implication is that the audit trail should keep, for every
// autoAccepted entry, the *reason* the verdict was reached — the returned
// choice, the probabilities, the section id, the stateHash. With that
// content, a future verifier can be reconstructed and asked the same
// question of the same state, and the resulting agreement or disagreement
// is itself a useful signal about model drift, even if it is not a
// statement about whether the original decision was correct.

// ---------------------------------------------------------------------------
// Extension: external witness
// ---------------------------------------------------------------------------

export async function anchorTip(
  log: DurableAuditLog,
  channel: { publish: (tipHash: string, asOf: string) => Promise<void> },
): Promise<void> {
  // Publish the current tip hash to an immutable external channel. What this
  // buys: a local adversary who rewrites the tail and re-chains it can fool
  // the local chain (as the Exercise 2 scenario D shows), but cannot fool
  // the external anchor, which still points at the pre-tamper tip. The next
  // reconciliation compares the recomputed tip to the anchor and finds the
  // mismatch. The anchor is what converts "tamper-evident to anyone who
  // happened to keep a copy" into "tamper-evident to anyone who trusts the
  // anchor channel".
  const tip = await log.sink.tip();
  if (!tip) return;
  await channel.publish(tip.entryHash, new Date().toISOString());
}

// What an HSM signing key adds over hashing: hashing is a *public* integrity
// primitive — anyone who can compute SHA-256 can verify a chain, and anyone
// who can recompute the whole chain can forge one. Signing the tip with a
// key the adversary cannot extract turns "anyone can verify" into "only
// holders of the private key can author entries", which is what defends
// against an insider rewriting the entire trail rather than an outsider
// tampering with a copy. The two are complementary: hashing gives
// tamper-evidence, signing gives authorship.
