/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * src/lib/extraction/disputed-amount.ts
 *
 * Two-stage, Jev-guided value extraction.
 *
 *   Stage 1 — regex recall    : cheap, deterministic, deliberately over-finds.
 *   Stage 2 — Jev selection   : one `choice` question picks the span the
 *                               customer actually means; one `noul` question
 *                               confirms a refund is even being asked for.
 *   Stage 3 — code decides    : normalize to cents, gate on confidence, and
 *                               return a small, closed status enum.
 *
 * The model never writes text. It only ever returns a probability
 * distribution over spans that were already present in the input.
 */

import {
  TypeSafeClient,
  choice,
  noul,
  type ChoiceQuestion,
  type ChoiceResponse,
  type NoulQuestion,
  type NoulResponse,
} from "@typesafe-ai/sdk";

/* ────────────────────────────────────────────────────────────────────
 * 1. One long-lived client, created once at module scope.
 * ──────────────────────────────────────────────────────────────────── */

/**
 * A single Jev client shared across every request handled by this
 * process. Creating a client per request would re-resolve config,
 * re-allocate the retry timer, and defeat HTTP keep-alive.
 */
export const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY,
  defaultModel: "jev-latest",
  timeout: 8_000, // per attempt, milliseconds
  retry: {
    maxRetries: 2,
    backoffInitialMs: 250,
    backoffMaxMs: 2_000,
  },
});

/* ────────────────────────────────────────────────────────────────────
 * 2. Stage 1 — recall. Over-find on purpose; precision comes later.
 * ──────────────────────────────────────────────────────────────────── */

/**
 * A deliberately permissive money pattern. It is tuned for *recall*:
 * it will match things that are not amounts, and that is fine, because
 * Stage 2 throws them away. It must not, however, miss a real amount.
 */
const MONEY_RE = /(?:\$|USD\b|€|£)\s?\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?/gi;

/** One regex hit, kept in document order. */
export interface Candidate {
  /** Stable, ordered key used only for bookkeeping in code. */
  readonly id: string;
  /** The verbatim substring. Never mutated, never reformatted. */
  readonly span: string;
}

/**
 * Run the pattern over the raw text and return the unique matches
 * in the order they appear.
 */
export function recallCandidates(text: string): Candidate[] {
  const seen = new Set<string>();
  const found: Candidate[] = [];

  for (const match of text.matchAll(MONEY_RE)) {
    const span = match[0].trim();
    if (!span || seen.has(span)) continue;
    seen.add(span);
    found.push({ id: `c${found.length}`, span });
  }

  return found;
}

/* ────────────────────────────────────────────────────────────────────
 * 3. Stage 2 — the Jev questions.
 * ──────────────────────────────────────────────────────────────────── */

/** The literal string used as the escape-hatch option. */
const NONE = "none" as const;

/** Minimum combined confidence before we act automatically. */
const RESOLVE_THRESHOLD = 0.75;

/** Below this, the message is not asking for money back at all. */
const ABSENT_THRESHOLD = 0.35;

/** The two question objects Jev will answer. */
interface DisputeQuestions {
  asks_for_refund: NoulQuestion;
  disputed_amount: ChoiceQuestion<Record<string, string | null>>;
}

/**
 * Build the question set. The `criteria` map for the `choice` question
 * is constructed *from the recalled spans themselves*, so the model can
 * only ever return a substring that already exists in the source text.
 */
function disputeQuestions(
  criteria: Record<string, string | null>,
): DisputeQuestions {
  return {
    asks_for_refund: noul(
      "Does the customer ask for a refund, reversal, or credit for money " +
        "already charged?",
    ),
    disputed_amount: choice(
      "Which candidate amount is the one the customer is disputing or " +
        "asking to be refunded?",
      criteria,
    ),
  };
}

/* ────────────────────────────────────────────────────────────────────
 * 4. The public result type — a closed enum, not a thrown error.
 * ──────────────────────────────────────────────────────────────────── */

export type ExtractionStatus = "resolved" | "absent" | "ambiguous";

export interface Extraction {
  readonly status: ExtractionStatus;
  /** Integer cents. Never a float. Null unless status === "resolved". */
  readonly amountCents: number | null;
  /** The verbatim span Jev selected, before normalization. */
  readonly raw: string | null;
  readonly confidence: number;
  readonly candidates: readonly string[];
  readonly model: string;
  readonly inputTokens: number;
}

/* ────────────────────────────────────────────────────────────────────
 * 5. The entry point.
 * ──────────────────────────────────────────────────────────────────── */

export async function extractDisputedAmount(
  message: string,
): Promise<Extraction> {
  const candidates = recallCandidates(message);

  // Nothing to choose between — skip the model call entirely.
  if (candidates.length === 0) {
    return {
      status: "absent",
      amountCents: null,
      raw: null,
      confidence: 1,
      candidates: [],
      model: "skipped",
      inputTokens: 0,
    };
  }

  // The option map is keyed by the span itself, so `choice` comes back
  // as a verbatim copy of one span (or the `none` hatch).
  const amountCriteria: Record<string, string | null> = {};
  for (const c of candidates) {
    amountCriteria[c.span] = null;
  }
  amountCriteria[NONE] = "None of these amounts is the disputed one.";

  const response = await jev.systemOne({
    state: {
      channel: "billing-support",
      message,
      candidates: candidates.map((c) => c.span),
    },
    questions: disputeQuestions(amountCriteria),
  });

  return decide(
    response.answers.asks_for_refund,
    response.answers.disputed_amount,
    candidates,
    { model: response.model, inputTokens: response.usage.input_tokens },
  );
}

/* ────────────────────────────────────────────────────────────────────
 * 6. Stage 3 — the decision. Pure, synchronous, trivially testable.
 * ──────────────────────────────────────────────────────────────────── */

function decide(
  intent: NoulResponse,
  pick: ChoiceResponse<Record<string, string | null>>,
  candidates: readonly Candidate[],
  meta: { model: string; inputTokens: number },
): Extraction {
  const pool = candidates.map((c) => c.span);
  const chosen = pick.choice;

  const wantsRefund = intent.noul >= ABSENT_THRESHOLD;
  const pickedReal = chosen !== NONE;
  const confidence = Math.min(pick.confidence, intent.noul);

  if (!wantsRefund || !pickedReal) {
    return {
      status: "absent",
      amountCents: null,
      raw: null,
      confidence,
      candidates: pool,
      ...meta,
    };
  }

  // One weak judgement spoils the whole extraction.
  if (confidence < RESOLVE_THRESHOLD) {
    return {
      status: "ambiguous",
      amountCents: null,
      raw: chosen,
      confidence,
      candidates: pool,
      ...meta,
    };
  }

  return {
    status: "resolved",
    amountCents: toCents(chosen),
    raw: chosen,
    confidence,
    candidates: pool,
    ...meta,
  };
}

/**
 * Parse a currency span into integer cents. Assumes US grouping
 * (`,` between thousands, `.` before the fraction) — see pitfalls.
 */
function toCents(span: string): number | null {
  const digits = span.replace(/[^\d.]/g, "");
  if (!digits) return null;
  const value = Number.parseFloat(digits);
  if (!Number.isFinite(value)) return null;
  return Math.round(value * 100);
}

/* ────────────────────────────────────────────────────────────────────
 * 7. Hello world.
 * ──────────────────────────────────────────────────────────────────── */

const SAMPLE_MESSAGE = `
Hi — quick one about my latest invoice.
I signed up for the Team plan at $29.00 a month.
On March 3rd I was charged $49.00, and then again $49.00 a few minutes later.
There's also a $12.00 proration line I don't recognise.
The duplicate is the problem — please refund the extra $49.00 charge. Thanks!
`;

async function main(): Promise<void> {
  const result = await extractDisputedAmount(SAMPLE_MESSAGE);
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
