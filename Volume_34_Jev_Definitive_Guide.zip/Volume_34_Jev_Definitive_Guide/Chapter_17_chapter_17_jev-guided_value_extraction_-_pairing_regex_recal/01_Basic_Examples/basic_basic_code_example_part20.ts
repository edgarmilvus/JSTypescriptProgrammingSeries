/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part20.ts
// Description: Basic Code Example
// ==========================================

"use server";

// src/app/inbox/actions.ts
import { extractDisputedAmount } from "@/lib/extraction/disputed-amount";
import { db } from "@/lib/db";

export async function triageDisputeAction(formData: FormData) {
  const message = String(formData.get("message") ?? "").slice(0, 4_000);

  const extraction = await extractDisputedAmount(message);

  // Only a `resolved` extraction is allowed to create a refund record.
  if (extraction.status === "resolved" && extraction.amountCents !== null) {
    await db.disputes.create({
      data: {
        rawSpan: extraction.raw!,          // "$49.00", verbatim
        amountCents: extraction.amountCents,
        confidence: extraction.confidence,
        model: extraction.model,
      },
    });
  }

  return extraction;
}
