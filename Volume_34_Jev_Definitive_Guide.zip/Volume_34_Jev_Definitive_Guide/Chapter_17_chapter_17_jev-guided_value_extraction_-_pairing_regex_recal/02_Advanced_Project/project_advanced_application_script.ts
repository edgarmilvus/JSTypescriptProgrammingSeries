/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/invoice/extract/route.ts
 *
 * Two-stage field extraction for a B2B accounts-payable SaaS.
 *
 *   Stage 1 (code, ~1ms): regexes over-find candidate values from raw
 *     invoice text. High recall, deliberately imprecise — they hand Jev
 *     a small set of plausible spans.
 *
 *   Stage 2 (Jev, ~100ms): a Choice question whose OPTION KEYS *are* the
 *     candidate strings. Jev's `choice` is therefore a verbatim copy of a
 *     regex match; it cannot invent, reword, or transpose a value. A Noul
 *     question rides the same request to flag sign (charge vs. credit).
 *
 * Every field is routed to one of three lanes based on Jev's confidence:
 * auto-accept, human review, or LLM fallback. Thresholds are per-field —
 * a mis-parsed total costs more than a mis-parsed invoice number.
 */

import { NextRequest, NextResponse } from "next/server";
import { TypeSafeClient, choice, noul } from "@typesafe-ai/sdk";

// ─── Types ────────────────────────────────────────────────────────────────

/** A field the caller wants extracted from one document. */
interface FieldSpec {
  key: string;
  /** Natural-language role. Must name the slot precisely, not the datatype. */
  question: string;
  pattern: RegExp;
  /** Minimum Jev confidence to auto-accept. Higher stake → higher bar. */
  acceptAt: number;
  /** When true, ask Jev whether the picked value is a credit, not a charge. */
  signed?: boolean;
}

type Lane = "auto" | "review" | "escalate";

interface FieldResult {
  key: string;
  value: string | null;   // verbatim regex match, or null
  confidence: number;     // Jev's confidence in the pick
  lane: Lane;
  isCredit?: boolean;
}

// ─── Stage 1: recall-tuned regexes ───────────────────────────────────────

const RECALL = {
  money:    /[$€£¥]\s?\d[\d,]*(?:\.\d{2})?/g,
  date:     /\b(?:\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?)\b/g,
  invoiceNo:/\b(?:INV|Invoice)[-#:\s]*([A-Z0-9][A-Z0-9-]{3,})\b/gi,
  poNo:     /\b(?:PO|P\.O\.|Purchase Order)[-#:\s]*([A-Z0-9][A-Z0-9-]{3,})\b/gi,
} as const;

/** Dedupe matches in document order. Over-finding is fine; duplicates are not. */
function recall(pattern: RegExp, text: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of text.matchAll(pattern)) {
    const v = (m[1] ?? m[0]).trim();
    if (v && !seen.has(v)) { seen.add(v); out.push(v); }
  }
  return out;
}

// ─── Stage 2: Jev semantic chooser ───────────────────────────────────────

const client = new TypeSafeClient();          // reads TYPESAFE_API_KEY
const MODEL = "jev-latest";
const FLOOR = 0.45;                           // below this → escalate
const NONE = "none";                          // explicit "no candidate fits"

/**
 * Ask Jev which candidate plays the role named in `question`. The candidate
 * strings become the *option keys*, so the returned `choice` is one of them
 * or the `none` hatch — never a model-invented value.
 */
async function pick(
  document: string,
  candidates: string[],
  spec: FieldSpec
): Promise<{ value: string | null; confidence: number; isCredit?: boolean }> {
  if (candidates.length === 0) {
    return { value: null, confidence: 0 };
  }

  const criteria: Record<string, string | null> = Object.fromEntries(
    candidates.map((c) => [c, null])
  );
  criteria[NONE] = "None of these candidates is the requested value.";

  const questions: Record<string, unknown> = {
    pick: choice(spec.question, criteria),
  };
  // A second, independent question in the same request. The sign of an
  // amount is a *different* judgement from picking the amount itself.
  if (spec.signed) {
    questions.sign = noul(
      `Is the amount the customer must pay a credit (money returned to them), rather than a charge?`
    );
  }

  const { answers } = await client.systemOne({
    state: document,
    questions: questions as never,            // SDK infers Question<T> per key
    model: MODEL,
  });

  const p = (answers as { pick: { choice: string; confidence: number } }).pick;
  const signNoul = spec.signed
    ? (answers as { sign: { noul: number } }).sign.noul
    : undefined;

  return {
    value: p.choice === NONE ? null : p.choice,
    confidence: p.confidence,
    isCredit: signNoul === undefined ? undefined : signNoul > 0.5,
  };
}

// ─── Orchestrator & routing ─────────────────────────────────────────────

const FIELDS: FieldSpec[] = [
  { key: "invoiceNumber", question: "Which value is the invoice number this invoice is filed under?", pattern: RECALL.invoiceNo, acceptAt: 0.70 },
  { key: "poNumber",      question: "Which value is the purchase order number this invoice is billed against?", pattern: RECALL.poNo, acceptAt: 0.70 },
  { key: "invoiceDate",   question: "Which date is the date the invoice was issued?", pattern: RECALL.date, acceptAt: 0.80 },
  { key: "totalDue",      question: "Which amount is the total the customer must pay, including any tax?", pattern: RECALL.money, acceptAt: 0.90, signed: true },
];

function lane(value: string | null, confidence: number, acceptAt: number): Lane {
  if (value === null) return "escalate";        // Jev said "none"
  if (confidence >= acceptAt) return "auto";
  if (confidence >= FLOOR) return "review";     // a human sees the candidate
  return "escalate";                            // fall through to the LLM
}

/** One Jev call per field, all concurrent. Wall clock ≈ one Jev round trip. */
async function extractAll(document: string): Promise<FieldResult[]> {
  const picks = await Promise.all(
    FIELDS.map(async (spec) => {
      const candidates = recall(spec.pattern, document);
      const r = await pick(document, candidates, spec);
      return { spec, ...r };
    })
  );
  return picks.map(({ spec, value, confidence, isCredit }) => ({
    key: spec.key,
    value,
    confidence,
    lane: lane(value, confidence, spec.acceptAt),
    isCredit,
  }));
}

// ─── HTTP handler ────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  const body = (await req.json()) as { document?: unknown };
  if (typeof body.document !== "string" || !body.document) {
    return NextResponse.json({ error: "body.document: string required" }, { status: 400 });
  }

  const results = await extractAll(body.document);
  const fields: Record<string, unknown> = {};
  const reviewQueue: FieldResult[] = [];
  const escalations: FieldResult[] = [];

  for (const r of results) {
    if (r.lane === "auto") {
      fields[r.key] = r.isCredit !== undefined
        ? { value: r.value, isCredit: r.isCredit }
        : r.value;
    } else if (r.lane === "review") {
      reviewQueue.push(r);
    } else {
      escalations.push(r);
    }
  }

  return NextResponse.json(
    {
      fields,                                 // safe to persist immediately
      reviewQueue,                            // show alongside the source span
      escalations,                            // hand to the LLM fallback stage
      autoAcceptRate: results.filter((r) => r.lane === "auto").length / results.length,
    },
    { headers: { "Cache-Control": "s-maxage=300, stale-while-revalidate=600" } }
  );
}
