/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { TypeSafeClient, choice, noul } from "@typesafe-ai/sdk";
import type { SystemOneResult } from "@typesafe-ai/sdk";
import Decimal from "decimal.js";

// ---------------------------------------------------------------------------
// 1. Recall-first regex. Precision belongs to Jev; the regex's only job is to
//    make sure the correct span is *present* in the candidate set.
//    Alternatives, in order:
//      (a) currency-prefixed amount, possibly signed:   $1,200.00   -$66.00
//      (b) bare thousands-grouped amount:               1,200.00    1 200,50
//      (c) bare decimal with two fractional digits:     1315.50
//    Non-breaking spaces (\u00A0) are treated as normal whitespace.
// ---------------------------------------------------------------------------
export const MONEY_RE =
  /(?:[-+]\s?)?[$€£¥]\s?\u00A0?\d{1,3}(?:[,\u00A0]\d{3})*(?:\.\d{1,2})?|(?:[-+]\s?)?\d{1,3}(?:[,\u00A0]\d{3})+(?:\.\d{1,2})?|(?<![\d.,])\d+\.\d{2}(?![\d])/g;

export function findCandidates(text: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const match of text.matchAll(MONEY_RE)) {
    const span = match[0].trim();
    if (!span || seen.has(span)) continue;
    seen.add(span);
    out.push(span);
  }
  return out;
}

// ---------------------------------------------------------------------------
// 2. Decimal parsing, per convention.
//    US:  1,315.00  -> comma groups, dot is decimal
//    EU:  1.315,00  -> dot groups, comma is decimal
//    We never use parseFloat because it loses the exact decimal representation
//    and cannot distinguish the two conventions.
// ---------------------------------------------------------------------------
export function toDecimal(span: string, locale: "US" | "EU"): Decimal {
  const sign = /^[-+\s]*-/.test(span) ? -1 : 1;
  let digits = span.replace(/[-+$€£¥\s\u00A0]/g, "");
  if (locale === "US") {
    digits = digits.replace(/,/g, "");
  } else {
    digits = digits.replace(/\./g, "").replace(",", ".");
  }
  if (digits === "" || digits === ".") return new Decimal(0);
  return new Decimal(digits).mul(sign);
}

// ---------------------------------------------------------------------------
// 3. The typed record. `verdict` is a discriminated union so callers who see
//    "auto" can act immediately, and callers who see "review" have the exact
//    list of low-confidence sub-answers to show a human.
// ---------------------------------------------------------------------------
export interface InvoiceRecordBase {
  total: Decimal;
  currency: string;
  isCredit: boolean;
  confidence: number;
  /** Verbatim string lifted from the document, never re-serialised. */
  rawSpan: string;
  /** ISO-style locale used to parse the number. */
  locale: "US" | "EU";
}

export type InvoiceRecord =
  | (InvoiceRecordBase & { verdict: "auto" })
  | (InvoiceRecordBase & {
      verdict: "review";
      low: Array<"total" | "currency" | "isCredit" | "locale">;
    });

const AUTO_ACCEPT = 0.8;

// ---------------------------------------------------------------------------
// 4. One request, four questions.
// ---------------------------------------------------------------------------
export async function extractInvoice(text: string): Promise<InvoiceRecord> {
  const candidates = findCandidates(text);

  const totalCriteria: Record<string, string | null> = {};
  for (const span of candidates) totalCriteria[span] = null;
  totalCriteria["none"] = "No amount in the document is the amount the customer must pay.";

  const questions = {
    total: choice(
      "Which amount is the amount the customer must actually pay?",
      totalCriteria
    ),
    currency: choice("Which currency are the amounts in?", {
      USD: "US dollars; $ with a US document context.",
      EUR: "Euros; € or a European document context.",
      GBP: "British pounds; £ or a UK document context.",
      CAD: "Canadian dollars; references Canada, Ontario, CAD, or an RBC wire.",
      JPY: "Japanese yen; ¥ or a Japanese document context.",
    }),
    isCredit: noul(
      "Does this amount represent money returning to the customer, rather than money owed by the customer to the vendor?",
    ),
    localeHint: choice(
      "Which number convention do the amounts use?",
      {
        US: "Comma thousands separator, dot decimal, e.g. 1,315.00",
        EU: "Dot thousands separator, comma decimal, e.g. 1.315,00",
      }
    ),
  };

  const client = new TypeSafeClient();
  const response: SystemOneResult<typeof questions> = await client.systemOne({
    state: text,
    questions,
  });

  const totalAns = response.answers.total;        // ChoiceResponse
  const currencyAns = response.answers.currency;  // ChoiceResponse
  const creditAns = response.answers.isCredit;    // NoulResponse (no confidence field)
  const localeAns = response.answers.localeHint;  // ChoiceResponse

  const rawSpan = totalAns.choice === "none" ? "" : totalAns.choice;
  const locale = localeAns.choice === "EU" ? "EU" : "US";
  const total = rawSpan ? toDecimal(rawSpan, locale) : new Decimal(0);

  // A Noul has no `confidence`; derive one from how far `noul` sits from 0.5.
  // 1.0 means maximally decisive yes, 0.0 maximally decisive no, 0.0 at 0.5.
  const creditConfidence = Math.abs(creditAns.noul - 0.5) * 2;

  // Per-answer confidences, not averaged. The overall confidence is the weakest
  // link, because one bad sub-answer is enough to spoil the record.
  const subConfidences: Record<"total" | "currency" | "isCredit" | "locale", number> = {
    total: rawSpan ? totalAns.confidence : 0,
    currency: currencyAns.confidence,
    isCredit: creditConfidence,
    locale: localeAns.confidence,
  };
  const confidence = Math.min(...Object.values(subConfidences));

  const low = (Object.entries(subConfidences) as Array<
    ["total" | "currency" | "isCredit" | "locale", number]
  >)
    .filter(([, c]) => c < AUTO_ACCEPT)
    .map(([k]) => k);

  const base: InvoiceRecordBase = {
    total,
    currency: currencyAns.choice,
    isCredit: creditAns.noul > 0.5,
    confidence,
    rawSpan,
    locale,
  };

  return low.length === 0 && rawSpan !== ""
    ? { ...base, verdict: "auto" }
    : { ...base, verdict: "review", low };
}

// ---------------------------------------------------------------------------
// 5. Fixture harness.
// ---------------------------------------------------------------------------
const FIXTURES: Array<{ id: string; text: string }> = [
  {
    id: "INV-2087",
    text: `Invoice INV-2087.
Billed to: Aperture Logistics, 41 Danforth Ave, Toronto ON
Issued: 2026-04-02
Subtotal: $1,200.00
Sales tax (Ontario HST 13%): $156.00
Shipping: $25.00
Early-payment discount: -$66.00
Total due: $1,315.00
A $50.00 courtesy credit from March has already been applied.
Wire to: RBC 003-1234567 CAD`,
  },
  // ... four more fixtures omitted for brevity
];

async function main() {
  for (const fixture of FIXTURES) {
    const record = await extractInvoice(fixture.text);
    console.log(
      [
        fixture.id.padEnd(12),
        `span=${record.rawSpan.padEnd(12)}`,
        `dec=${record.total.toFixed(2).padStart(10)}`,
        `cur=${record.currency}`,
        `credit=${record.isCredit}`,
        `conf=${record.confidence.toFixed(2)}`,
        `verdict=${record.verdict}`,
      ].join("  ")
    );
  }
}

if (require.main === module) void main();
