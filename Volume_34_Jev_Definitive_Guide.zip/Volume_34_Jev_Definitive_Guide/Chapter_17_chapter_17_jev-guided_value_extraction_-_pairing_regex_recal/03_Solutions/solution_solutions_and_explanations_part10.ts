/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

<!-- diagnoses.md -->

### 1. `att-014` — "Riverside Holdings" LOI

- The five-level distribution for the *contract* question spreads between
  Level 2 and Level 3 with a small tail on Level 4 (`p(2)=0.38, p(3)=0.44,
  p(4)=0.11`). The *NDA* question concentrates on Level 3 (`p(3)=0.88`).
- The substring that causes the split is: *"…with a target signing within
  the next ninety days subject to board approval…"*.
- Reading the *contract* levels against this in isolation, we cannot tell
  whether "within the next ninety days" is "an action required within the
  week" — because we have not yet defined *whose* action the level refers to.
  Level 3's wording ("the reviewer should calendar it") assumes the reviewer
  is acting; Level 4's wording ("a reply... is expected") assumes the
  reviewer is responding. For an LOI where the counterparty drives the clock,
  both readings are defensible.
- **Proposed rewrite of Level 3:** *"An action by the firm is required within
  the week: the firm owes a response, a signature, or a filing before the
  next weekly cycle closes."* The addition of "by the firm" and "the firm
  owes" pins the level to our side of the exchange, which is the axis the
  contract question is actually asking about.

### 2. `att-027` — "Aperture Supply Agreement" (bimodal)

- Bimodal distribution: `p(0)=0.41, p(4)=0.44, p(1..3) ≈ 0.05`. Both ends
  are populated, nothing in the middle.
- Substring: *"This agreement is effective immediately upon signature and
  contains a clause automatically renewing for successive twelve-month
  terms unless either party gives notice ninety days prior to renewal."* The
  document ties up immediately (Level 0 would be defensible if read only for
  near-term actions) *and* hides a ninety-day trap clause that makes a
  near-term action essential (Level 4).
- This is the case the exercise is designed to surface: the level scale
  encodes *two dimensions* — when an action is required, and how severe the
  consequence of missing it is — and any single ordinal axis will show this
  shape on documents that score high on both.
- **Fix (out of the current exercise's scope, but recorded):** split into two
  Score questions, one per dimension, and combine them in code. Do not try to
  patch the level strings.

### 3. `att-005` — "NDA — mutual, non-standard"

- `p(1)=0.55, p(2)=0.37`. The NDA question is confident; the contract
  question is not. Both see the same text; they differ only in instruction.
- Substring: *"…the parties will negotiate in good faith toward a definitive
  agreement within sixty days…"*. "Negotiate in good faith" is a soft
  obligation and Level 1's wording ("can batch it with other routine work")
  fits it, but "within sixty days" reads as a hard window that pushes toward
  Level 2.
- **Proposed rewrite of Level 1:** *"An action is required but the deadline
  is soft: no external clock is running, and missing the internal target does
  not itself breach an obligation."* This creates a definitional boundary
  ("soft vs. running clock") rather than an intensity one.

### 4. `att-011` — "Employment Contract — senior hire"

- `p(0)=0.31, p(1)=0.35, p(4)=0.20`. Three levels populated.
- Substring: *"The employee's start date is contingent on satisfactory
  reference checks; the firm will issue a formal offer letter within five
  business days of completion."* The five-business-day window reads as
  "within the week" (Level 2) but the contingency structure means no action
  is required until a precondition resolves, which is *closer to* Level 0.
- The level descriptions do not distinguish "conditional action required" from
  "action required." For the next iteration, add the word "unconditional" to
  Level 3 and "the precondition has resolved" to Level 2.

### 5. `att-021` — "Term Sheet — Series A"

- `p(3)=0.51, p(4)=0.39`. Close split between adjacent levels, but not a
  bimodal tail.
- Substring: *"The definitive documents shall be executed on or before
  2026-05-30, and the exclusivity period expires on the same date."* Both a
  hard deadline and an exclusivity lapse fall on one date. Level 3 and Level 4
  both fit; the scale is trying to distinguish *urgency* from *recoverability*
  and this document collapses them.
- **Fix:** add to Level 4 the phrase *"where a right lapses or an external
  party is freed to act at the deadline"*; add to Level 3 *"where the
  consequence of delay is internal to the firm."* The exercise's point is that
  a level-by-level rewrite is often the correct response, and here it is.
