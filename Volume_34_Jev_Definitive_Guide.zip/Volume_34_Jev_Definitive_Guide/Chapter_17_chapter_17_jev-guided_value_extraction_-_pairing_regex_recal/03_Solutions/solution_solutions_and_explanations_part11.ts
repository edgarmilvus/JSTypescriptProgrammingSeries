/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

<!-- METHOD.md -->

# Why `confidence` alone is not enough for question-quality debugging

`ScoreAnswer.confidence` is a single number derived from the shape of the
probability distribution over the levels. That is exactly what you want when
you are *routing a document*: a high-confidence answer can be acted on, a
low-confidence answer goes to review, and the summary is the whole point.

It is not enough for *diagnosing your own question wording*, and the reason is
that two very different distributions can produce similar confidences:

- Level 2 at 0.85, Level 3 at 0.10, Level 1 at 0.05 — concentrated, high
  confidence, and the state genuinely sits near Level 2.
- Level 0 at 0.40, Level 4 at 0.35, Level 1/2/3 at 0.08 each — bimodal,
  medium confidence, and the state is being *read two ways at once*.

The second shape is the one that tells you something about the level wording.
It means the state contains two features and the level scale encodes only
one; the model is picking one feature on some runs and the other on other
runs, and the confidence number, being a summary, cannot tell you *which*.

Shannon entropy over the probability map adds exactly that missing
information: it is a monotone measure of how spread out the distribution is,
and unlike a best-vs-second gap, it does not treat a bimodal 40/35 as "nearly
concentrated." A well-posed question produces a unimodal distribution
regardless of where the mode sits; a mis-posed question produces
disagreement across questions before it produces disagreement within one
question, which is why the harness sorts by *spread across the three
questions*, not by confidence.

The control question — the one with the degree-style level — is the empirical
check. If its entropy is not visibly higher than the well-posed questions,
either the fixture set is degenerate or the "well-posed" questions are not
well-posed after all. This is the same reference-building principle the
consistency cookbook applies to Noul questions: you cannot measure a
question's behaviour without a baseline that is known to be worse.
