/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// fixtures.jsonl  (one line per document; excerpt)
// ---------------------------------------------------------------------------
// {"id":"f01","text":"Hi Sam — happy to get this over by EOD Friday, just tell me where to send it.","candidates":["EOD Friday"],"gold":"EOD Friday"}
// {"id":"f02","text":"Quick recap: our fiscal Q3 closed on June 30, and the invoice goes out in mid-July.","candidates":["June 30","mid-July"],"gold":"none"}
// {"id":"f03","text":"Per our discussion, please deliver the draft no later than 2026-06-01.","candidates":["2026-06-01"],"gold":"2026-06-01"}
// {"id":"f04","text":"Hope you had a great weekend. Let me know if Tuesday works for the call.","candidates":["Tuesday"],"gold":"none"}
// {"id":"f05","text":"I'll get you the figures by Wednesday; the board meets the following Monday.","candidates":["Wednesday","Monday"],"gold":"Wednesday"}
// ... (30 lines total)
