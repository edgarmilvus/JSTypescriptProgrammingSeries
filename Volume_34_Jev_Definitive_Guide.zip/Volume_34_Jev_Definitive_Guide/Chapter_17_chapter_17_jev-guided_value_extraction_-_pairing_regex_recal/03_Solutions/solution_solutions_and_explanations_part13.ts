/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// tune.ts
// ---------------------------------------------------------------------------
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { TypeSafeClient, choice } from "@typesafe-ai/sdk";

// =============================================================================
// THE ONLY THING YOU EDIT BETWEEN ITERATIONS. Everything else is fixed.
// =============================================================================
const INSTRUCTION =
  "Which of these spans is the specific calendar date the sender commits to act on?";

const CRITERIA_GLOSS: Record<string, string | null> = {
  // The key is the candidate span itself; the value is the gloss the model
  // reads on that option. Use structured glosses (what / not_for / examples)
  // for the most impactful options, plain strings for the rest.
  none: {
    what: "date-like text that does NOT commit the sender to act",
    not_for: [
      "fiscal quarter labels",
      "salutation dates (Monday, Tuesday) that only propose a call",
      "boilerplate references to prior or future meetings",
    ],
    examples: [
      "our fiscal Q3 closed on June 30",
      "let me know if Tuesday works",
    ],
  } as unknown as string,
};
// =============================================================================

const AUTO_ACCEPT = 0.8;

interface Fixture {
  id: string;
  text: string;
  candidates: string[];
  gold: string; // candidate span, or the literal string "none"
}

interface Row {
  iter: number;
  configHash: string;
  precision: number;
  recall: number;
  meanConfidence: number;
  numFlat: number;
  notes: string;
}

function configHash(instruction: string, criteriaGloss: Record<string, string | null>): string {
  return createHash("sha256")
    .update(JSON.stringify({ instruction, criteriaGloss }))
    .digest("hex")
    .slice(0, 12);
}

/** Build the criteria map from the fixture candidates plus the "none" gloss. */
function buildCriteria(candidates: string[]): Record<string, string | null> {
  const criteria: Record<string, string | null> = {};
  for (const span of candidates) criteria[span] = CRITERIA_GLOSS[span] ?? null;
  criteria.none = CRITERIA_GLOSS.none ?? null;
  return criteria;
}

async function runFixture(
  client: TypeSafeClient,
  fixture: Fixture
): Promise<{ pick: string; confidence: number }> {
  const question = choice(INSTRUCTION, buildCriteria(fixture.candidates));
  const response = await client.systemOne({
    state: fixture.text,
    questions: { pick: question },
  });
  const ans = response.answers.pick;
  return { pick: ans.choice, confidence: ans.confidence };
}

async function main() {
  const fixtures = readFileSync("fixtures.jsonl", "utf8")
    .split("\n")
    .filter(Boolean)
    .map((line) => JSON.parse(line) as Fixture);

  const client = new TypeSafeClient();
  const hash = configHash(INSTRUCTION, CRITERIA_GLOSS);

  let tp = 0, fp = 0, fn = 0;
  let confSum = 0, flat = 0;
  const picks: Array<{ id: string; pick: string; confidence: number; gold: string }> = [];

  for (const fixture of fixtures) {
    const { pick, confidence } = await runFixture(client, fixture);
    picks.push({ id: fixture.id, pick, confidence, gold: fixture.gold });
    confSum += confidence;
    if (confidence < AUTO_ACCEPT) flat += 1;

    const picked = pick === "none" ? "none" : pick;
    const gold = fixture.gold;
    if (picked === gold && picked !== "none") tp += 1;
    else if (picked !== "none" && picked !== gold) fp += 1;
    else if (picked === "none" && gold !== "none") fn += 1;
    // true negatives (both "none") are not tracked in precision/recall.
  }

  const precision = tp / Math.max(1, tp + fp);
  const recall = tp / Math.max(1, tp + fn);
  const meanConfidence = confSum / fixtures.length;

  const row: Row = {
    iter: Number(process.env.ITER ?? "0"),
    configHash: hash,
    precision,
    recall,
    meanConfidence,
    numFlat: flat,
    notes: process.env.NOTES ?? "",
  };

  const line = `${row.iter}\t${row.configHash}\t${precision.toFixed(3)}\t${recall.toFixed(3)}\t${meanConfidence.toFixed(3)}\t${flat}\t${row.notes}`;
  writeFileSync("last_row.tsv", line + "\n");
  console.log(line);

  // Also dump the per-fixture picks so the Pareto plotter can recompute if needed.
  writeFileSync(`picks.iter${row.iter}.json`, JSON.stringify(picks, null, 2));
}

void main();
