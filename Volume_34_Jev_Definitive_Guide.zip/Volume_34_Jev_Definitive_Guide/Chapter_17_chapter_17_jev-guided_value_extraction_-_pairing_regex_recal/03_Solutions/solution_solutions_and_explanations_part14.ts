/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

<!-- LOG.md -->

| iter | hash       | precision | recall | meanConf | flat | notes |
|------|------------|-----------|--------|----------|------|-------|
| 0    | 7a2c9f10   | 0.712     | 0.583  | 0.71     | 14   | baseline; naive instruction "which date is the committed deadline?" |
| 1    | c1b4e9aa   | 0.800     | 0.583  | 0.78     | 10   | add "sender commits to act on" to instruction; gloss `none` as "date-like text that does not commit the sender" |
| 2    | 04d5a1ff   | 0.857     | 0.667  | 0.81     | 7    | add examples to `none`: `"our fiscal Q3 closed on June 30"`, `"let me know if Tuesday works"` |
| 3    | e9a3c8b2   | 0.857     | 0.708  | 0.82     | 6    | add `not_for` to `none`: `"salutation dates that only propose a call"` |
| 4    | 3f5d2e77   | 0.900     | 0.750  | 0.84     | 4    | add structured gloss to positive spans: `what: "a date the sender commits to act on"` |
| 5    | 81b7cf44   | 0.923     | 0.792  | 0.86     | 3    | add boundary example to positive spans: `"no later than EOD Friday, barring further review"` |
| 6    | a9c1e0d3   | 0.923     | 0.750  | 0.85     | 3    | reword `none` as "date-like text with no commitment"; precision unchanged, recall -1 |
| 7    | 5e0d7c91   | 0.889     | 0.833  | 0.85     | 3    | add `not_for: "prior meetings the sender only recounts"` |
| 8    | b4f1a8c2   | 0.952     | 0.792  | 0.88     | 2    | tighten positive `what` to "a calendar date on which the sender takes on an obligation" |
| R    | 0e6e6f21   | 0.556     | 0.417  | 0.51     | 19   | deliberate regression: replace `none` gloss with `"not applicable"` (degree-free, no contrast) |
| I    | 9d9d3a77   | 0.714     | 0.917  | 0.80     | 5    | **inversion**: rewrite every positive `not_for` to `"no hedge and no qualifier"` — false positives become cheap, false negatives expensive |
