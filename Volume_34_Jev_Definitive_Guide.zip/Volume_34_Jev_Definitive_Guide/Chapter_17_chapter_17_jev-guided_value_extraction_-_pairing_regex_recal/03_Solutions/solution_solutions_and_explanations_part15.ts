/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part15.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// pareto.ts
// ---------------------------------------------------------------------------
import { readFileSync } from "node:fs";
import { writeFileSync } from "node:fs";

interface Row {
  iter: number | "R" | "I";
  hash: string;
  precision: number;
  recall: number;
}

const rows: Row[] = readFileSync("LOG.md", "utf8")
  .split("\n")
  .filter((l) => /^\|\s*\d+|^\|\s*R|^\|\s*I/.test(l))
  .map((line) => {
    const cells = line.split("|").map((c) => c.trim());
    return {
      iter: cells[1] === "R" || cells[1] === "I" ? (cells[1] as "R" | "I") : Number(cells[1]),
      hash: cells[2],
      precision: Number(cells[3]),
      recall: Number(cells[4]),
    };
  });

// A point is on the frontier if no other point dominates it: no point has both
// lower (1 - precision) and lower (1 - recall).
const onFrontier = rows.map((r, i) => {
  return !rows.some((other, j) => {
    if (i === j) return false;
    return (
      other.precision >= r.precision &&
      other.recall >= r.recall &&
      (other.precision > r.precision || other.recall > r.recall)
    );
  });
});

const svg: string[] = [];
const W = 560, H = 420, PAD = 48;
const x = (p: number) => PAD + p * (W - 2 * PAD);
const y = (r: number) => H - PAD - r * (H - 2 * PAD);

svg.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}">`);
svg.push(`<rect width="${W}" height="${H}" fill="#fcfcfb"/>`);
svg.push(`<line x1="${PAD}" y1="${H - PAD}" x2="${W - PAD}" y2="${H - PAD}" stroke="#c3c2b7"/>`);
svg.push(`<line x1="${PAD}" y1="${PAD}" x2="${PAD}" y2="${H - PAD}" stroke="#c3c2b7"/>`);
svg.push(`<text x="${W / 2}" y="${H - 12}" text-anchor="middle" font-family="system-ui" font-size="11" fill="#52514e">1 − precision</text>`);
svg.push(`<text x="14" y="${H / 2}" text-anchor="middle" font-family="system-ui" font-size="11" fill="#52514e" transform="rotate(-90 14 ${H / 2})">1 − recall</text>`);

for (const [i, r] of rows.entries()) {
  const fx = x(1 - r.precision);
  const fy = y(1 - r.recall);
  const frontier = onFrontier[i];
  svg.push(
    `<circle cx="${fx}" cy="${fy}" r="${frontier ? 6 : 4}" fill="${frontier ? "#2a78d6" : "#e1e0d9"}" stroke="#0b0b0b" stroke-width="${frontier ? 0 : 0.5}"/>`
  );
  svg.push(
    `<text x="${fx + 8}" y="${fy - 6}" font-family="ui-monospace" font-size="10" fill="#52514e">${r.iter}</text>`
  );
}
svg.push(`</svg>`);
writeFileSync("pareto.svg", svg.join("\n"));
console.log("frontier:", rows.filter((_, i) => onFrontier[i]).map((r) => r.iter));
