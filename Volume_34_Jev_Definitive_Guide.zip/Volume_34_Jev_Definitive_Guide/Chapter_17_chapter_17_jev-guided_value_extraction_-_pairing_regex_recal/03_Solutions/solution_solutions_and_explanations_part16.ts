/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part16.ts
// Description: Solutions and Explanations
// ==========================================

<!-- SHIP.md -->

# Ship decision

**The workflow we are shipping into:** inbound sales email triage. The
extraction output feeds a downstream "SLA clock" column on a rep's dashboard;
when the model picks a date, the rep is reminded to follow up by that date.
The failure modes of the two errors are not symmetric:

- A **false positive** (model picks a date that was never really committed to)
  produces a reminder the rep ignores, and costs the rep a few seconds of
  attention. Recoverable, cheap.
- A **false negative** (model returns `none` on a document that did commit to
  a date) leaves the SLA clock empty. The deal slips without anyone noticing.
  Unrecoverable for that quarter.

Given that asymmetry, the iteration we ship is **iter 8**, but run with the
inversion's `not_for` fields applied to the positive spans (not the `none`
span). Iter 8 alone has precision 0.95 / recall 0.79 — excellent precision,
but the recall ceiling means one in five committed dates is silently dropped.
The inversion (iter I) inverts the balance too far the other way: recall 0.92
and precision 0.71, which we would not accept in this workflow because the
false-positive reminders are what erode rep trust in the panel over time. The
combination — tight positive glosses from iter 8, `not_for` on the `none`
span from iter 3, hedged-example on positive spans from iter 5 — should land
in the 0.88 / 0.88 region on the frontier.

# Inversion and its business context

The same inversion, deployed unchanged, **is** the right configuration for a
different workflow: pre-signature contract review, where the extractor feeds a
"deadline about to lapse" alert on a legal-ops queue. There, a false negative
means an obligation lapses unnoticed — the same failure we were aggressing
against in the sales case. But a false positive in legal-ops means an attorney
opens a document and, seeing no real deadline, closes it, having spent two
minutes. The cost of the false positive is bounded and small; the cost of the
false negative is lapsed rights. So the inverted configuration — recall 0.92,
precision 0.71 — is the ship configuration *for legal-ops*, and the iter-8
configuration is the ship configuration *for sales triage*. The Pareto plot
makes this visible: both points are on the frontier, and which one you pick is
a function of which error you are willing to pay for.
