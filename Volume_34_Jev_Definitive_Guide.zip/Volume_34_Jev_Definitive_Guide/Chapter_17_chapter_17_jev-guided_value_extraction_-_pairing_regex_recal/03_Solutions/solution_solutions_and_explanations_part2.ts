/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

<!-- README.md -->

# Why the span is copied, not regenerated

The pipeline that produces an `InvoiceRecord` has exactly three stages: a regex finds
every money-like span in the document; a `choice()` question tells us which one plays the
role the caller asked about; and *our* code copies that span into the record.

We copy. We never ask a model to *write* the number.

A generative model, asked to "extract the total", can hallucinate a decimal point, swap
two adjacent digits, or splice a currency symbol from a neighbouring line. It does this
because its job is to produce text that looks right. A regex cannot hallucinate: it can
only fail to match, or match the wrong thing. Jev cannot either: its `ChoiceResponse`
is a probability distribution over a closed set of options we chose, so the value it
hands back is always one of the options, never a new string.

That is the seam the whole pattern sits on. Recall is the regex's job — over-find, accept
false positives. Precision is Jev's job — point at the one span that answers the role
question. Code owns the string: whatever sits at `response.answers.total.choice` is
lifted verbatim into `rawSpan` and parsed by *our* `toDecimal` helper.

If we regenerated the number, we would be re-introducing the very failure mode this
architecture exists to eliminate: a model authoring digits that never appeared in the
source.
