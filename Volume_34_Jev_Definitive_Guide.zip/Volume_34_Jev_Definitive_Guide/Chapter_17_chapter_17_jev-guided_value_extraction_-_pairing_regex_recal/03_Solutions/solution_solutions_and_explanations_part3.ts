/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// app/components/types.ts
// ---------------------------------------------------------------------------
import type { ChoiceResponse } from "@typesafe-ai/sdk";
import { choice } from "@typesafe-ai/sdk";

export type Verdict = "verified" | "unsupported" | "contradicted" | "fabricated";

export type CitationStatus =
  | { kind: "fabricated"; reason: "quote-not-found" }
  | {
      kind: "resolved";
      relation: "supports" | "contradicts" | "says_nothing";
      verdict: Verdict;
      confidence: number;
      section: string;
      quoteSpan: [number, number] | null;
      /** true when the CI gate flagged this as "may need review" */
      auto: boolean;
    };

export interface CitationSource {
  id: string;
  claim: string;
  quote: string | null;
  section: string;
}

export const relation = choice("How does the section relate to the claim?", {
  supports: "The section states the claim or directly implies that it is true",
  contradicts: "The section states the opposite of the claim or implies it is false",
  says_nothing: "The section does not address what the claim asserts, either way",
});

export type RelationResponse = ChoiceResponse<{
  supports: null;
  contradicts: null;
  says_nothing: null;
}>;

const RELATION_TO_VERDICT: Record<
  RelationResponse["choice"],
  Exclude<Verdict, "fabricated">
> = {
  supports: "verified",
  contradicts: "contradicted",
  says_nothing: "unsupported",
};

export const AUTO_ACCEPT = 0.8;

/** Map a model-returned relation into our own application verdict. */
export function verdictFrom(
  response: RelationResponse,
  autoAccept: number = AUTO_ACCEPT
): { verdict: Verdict; auto: boolean } {
  // The mapping below is *our* policy, not the model's. The model produces a
  // relation label; the label-to-verdict bridge is a business decision we own.
  return {
    verdict: RELATION_TO_VERDICT[response.choice],
    auto: response.confidence >= autoAccept,
  };
}

// ---------------------------------------------------------------------------
// app/components/CitationVerifier.tsx   (Server Component — no "use client")
// ---------------------------------------------------------------------------
import { TypeSafeClient, type SystemOneResult } from "@typesafe-ai/sdk";
import { CitationList } from "./CitationList";
import { relation, verdictFrom, type CitationSource, type CitationStatus, type RelationResponse } from "./types";

interface Props {
  source: string;
  citations: CitationSource[];
  /** Injectable only for tests; production callers omit this. */
  clientFactory?: () => TypeSafeClient;
}

export async function CitationVerifier({
  source,
  citations,
  clientFactory,
}: Props) {
  const sections = splitSections(source);

  // Deterministic pass first: find every quote, mark fabricated quotes, collect
  // the survivors so we can send one fan-out request for all of them.
  const fabricated: Record<string, CitationStatus> = {};
  const resolvable: CitationSource[] = [];

  for (const citation of citations) {
    if (citation.quote !== null) {
      const found = findQuote(sections, citation.quote);
      if (found === null) {
        // No network call for this citation, ever. Absence of a substring is a
        // fact about the data, not a probability about the model's judgment.
        fabricated[citation.id] = { kind: "fabricated", reason: "quote-not-found" };
        continue;
      }
      resolvable.push(citation);
    } else {
      resolvable.push(citation);
    }
  }

  let resolved: Record<string, CitationStatus> = {};
  if (resolvable.length > 0) {
    // One state object keyed by citation id, one question per id. Not a wall of
    // text: the model needs the lexical anchor of a labelled field.
    const state = {
      citations: resolvable.map((c) => ({
        id: c.id,
        claim: c.claim,
        section: sections[c.section] ?? "",
      })),
    };
    const questions: Record<string, typeof relation> = {};
    for (const c of resolvable) questions[`rel::${c.id}`] = relation;

    const client = clientFactory ? clientFactory() : new TypeSafeClient();
    const response: SystemOneResult<typeof questions> = await client.systemOne({
      state,
      questions,
    });

    for (const c of resolvable) {
      const ans = response.answers[`rel::${c.id}`] as RelationResponse;
      const { verdict, auto } = verdictFrom(ans);
      const quoteSpan = c.quote ? spanOf(sections[c.section], c.quote) : null;
      resolved[c.id] = {
        kind: "resolved",
        relation: ans.choice,
        verdict,
        confidence: ans.confidence,
        section: c.section,
        quoteSpan,
        auto,
      };
    }
  }

  const statuses: Record<string, CitationStatus> = { ...resolved, ...fabricated };

  return <CitationList source={source} citations={citations} statuses={statuses} />;
}

// ---------------------------------------------------------------------------
// app/components/CitationList.tsx       (Client Component)
// ---------------------------------------------------------------------------
"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import { TypeSafeClient } from "@typesafe-ai/sdk";
import { relation, verdictFrom, type CitationSource, type CitationStatus, type RelationResponse } from "./types";
import { VerdictBadge } from "./VerdictBadge";

const STRICTER_INSTRUCTION =
  "How does the section relate to the claim? Give weight to explicit wording; " +
  "merely discussing the same topic is never 'supports'.";

interface Props {
  source: string;
  citations: CitationSource[];
  statuses: Record<string, CitationStatus>;
}

export function CitationList({ source, citations, statuses }: Props) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [local, setLocal] = useState<Record<string, CitationStatus>>(statuses);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const controllers = useRef(new Map<string, AbortController>());

  const client = useMemo(() => new TypeSafeClient(), []);
  const sections = useMemo(() => splitSections(source), [source]);

  const rerun = useCallback(
    async (citation: CitationSource) => {
      // Cancel any in-flight rerun for this row before starting a new one.
      controllers.current.get(citation.id)?.abort();
      const controller = new AbortController();
      controllers.current.set(citation.id, controller);
      setLoadingId(citation.id);
      try {
        const response = await client.systemOne(
          {
            state: {
              claim: citation.claim,
              section: sections[citation.section] ?? "",
            },
            questions: { rel: relation },
          },
          { signal: controller.signal }
        );
        const ans = response.answers.rel as RelationResponse;
        const { verdict, auto } = verdictFrom(ans);
        setLocal((prev) => {
          const current = prev[citation.id];
          if (current?.kind !== "resolved") return prev;
          // Only swap if the new confidence is higher — otherwise keep the
          // original so the user's re-run is a genuine improvement, not noise.
          if (!auto || ans.confidence <= current.confidence) return prev;
          return {
            ...prev,
            [citation.id]: {
              ...current,
              verdict,
              confidence: ans.confidence,
              auto,
            },
          };
        });
      } catch (err) {
        if ((err as { name?: string }).name !== "APIUserAbortError") throw err;
      } finally {
        controllers.current.delete(citation.id);
        setLoadingId((id) => (id === citation.id ? null : id));
      }
    },
    [client, sections]
  );

  const rows = citations.map((citation) => {
    const status = local[citation.id];
    const isOpen = expanded === citation.id;
    return (
      <li key={citation.id}>
        <div className="row">
          <span className="claim">{citation.claim}</span>
          <VerdictBadge status={status} />
          {status.kind === "resolved" && (
            <button onClick={() => setExpanded(isOpen ? null : citation.id)}>
              {isOpen ? "Collapse" : "Inspect"}
            </button>
          )}
          {status.kind === "resolved" && (
            <button
              disabled={loadingId === citation.id}
              onClick={() => void rerun(citation)}
            >
              {loadingId === citation.id ? "…" : "Re-run with stricter wording"}
            </button>
          )}
        </div>
        {isOpen && status.kind === "resolved" && status.quoteSpan && (
          <SourcePanel
            text={sections[status.section] ?? ""}
            span={status.quoteSpan}
          />
        )}
      </li>
    );
  });

  return <ul className="citation-list">{rows}</ul>;
}

function SourcePanel({ text, span }: { text: string; span: [number, number] }) {
  const [start, end] = span;
  return (
    <pre className="source-panel">
      {text.slice(0, start)}
      <mark>{text.slice(start, end)}</mark>
      {text.slice(end)}
    </pre>
  );
}
