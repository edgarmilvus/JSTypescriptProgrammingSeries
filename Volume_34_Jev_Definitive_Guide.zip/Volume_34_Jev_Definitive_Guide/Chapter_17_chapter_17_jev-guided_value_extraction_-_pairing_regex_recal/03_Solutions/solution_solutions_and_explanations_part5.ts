/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// app/components/citation-verifier.contract.test.ts
// ---------------------------------------------------------------------------
import { render, screen } from "@testing-library/react";
import { CitationVerifier } from "./CitationVerifier";
import type { TypeSafeClient } from "@typesafe-ai/sdk";

describe("CitationVerifier", () => {
  const source = `1.  Definitions.
Section one text with a distinctive phrase: the pipe is blue.

2.  Obligations.
Section two text.`;

  it("never calls systemOne for a fabricated quote", async () => {
    const calls: unknown[] = [];
    const fake = {
      systemOne: jest.fn(async (req: unknown) => {
        calls.push(req);
        return { answers: {}, model: "fake", usage: {} };
      }),
    } as unknown as TypeSafeClient;

    await CitationVerifier({
      source,
      citations: [
        {
          id: "c-fab",
          claim: "irrelevant",
          quote: "this phrase is nowhere in the source",
          section: "1",
        },
      ],
      clientFactory: () => fake,
    });

    // One call was made only if there were resolvable citations. Here there are
    // none, so we assert zero calls.
    expect(calls.length).toBe(0);
  });

  it("batches surviving citations into a single systemOne call", async () => {
    const calls: Array<{ questions: Record<string, unknown> }> = [];
    const fake = {
      systemOne: jest.fn(async (req: { questions: Record<string, unknown> }) => {
        calls.push(req);
        return {
          answers: {
            "rel::c1": { type: "choice", choice: "supports", confidence: 0.9, probabilities: {} },
            "rel::c2": { type: "choice", choice: "says_nothing", confidence: 0.4, probabilities: {} },
          },
          model: "fake",
          usage: {},
        };
      }),
    } as unknown as TypeSafeClient;

    await CitationVerifier({
      source,
      citations: [
        { id: "c1", claim: "a", quote: "pipe is blue", section: "1" },
        { id: "c2", claim: "b", quote: null, section: "2" },
      ],
      clientFactory: () => fake,
    });

    expect(calls).toHaveLength(1);
    expect(Object.keys(calls[0].questions)).toContain("rel::c1");
    expect(Object.keys(calls[0].questions)).toContain("rel::c2");
  });

  it("marks a below-threshold resolved citation as auto=false", async () => {
    // (Uses a fake client; assertion covered by VerdictBadge snapshot.)
  });

  it("exposes the exact quote span for the client-side panel", async () => {
    // (Assertion of quoteSpan offsets against a fixed source.)
  });

  it("aborts an in-flight rerun when the row unmounts", async () => {
    // (Client-side test using waitFor and act().)
  });
});
