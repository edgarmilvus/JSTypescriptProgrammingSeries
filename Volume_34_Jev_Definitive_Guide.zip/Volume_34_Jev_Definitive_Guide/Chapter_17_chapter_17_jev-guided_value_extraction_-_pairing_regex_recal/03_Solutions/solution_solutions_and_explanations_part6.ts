/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// resolver.ts
// ---------------------------------------------------------------------------
import { TypeSafeClient, choice, noul, type SystemOneResult } from "@typesafe-ai/sdk";

// Over-find by design. The regex is a recall layer; the choice() question is
// the precision layer. It will happily match invoice numbers and dates.
export const EmailRE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
export const PhoneRE =
  /(?:\+?\d{1,3}[\s.-]?)?(?:\(\d{2,4}\)|\d{2,4})[\s.-]?\d{3}[\s.-]?\d{3,4}(?:\s?(?:x|ext\.?)\s?\d{1,5})?/g;

// ---------------------------------------------------------------------------
// Normalisation for dedup. Different surface forms of the same value collapse
// to one normalized key; the first-seen raw span is retained as the display
// value so the model sees the exact string from the document.
// ---------------------------------------------------------------------------
function normaliseEmail(s: string): string {
  return s.trim().toLowerCase();
}
function normalisePhone(s: string): string {
  return s.replace(/\D/g, "");
}

export function findEmails(text: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of text.matchAll(EmailRE)) {
    const raw = m[0];
    const key = normaliseEmail(raw);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(raw);
  }
  return out;
}
export function findPhones(text: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of text.matchAll(PhoneRE)) {
    const raw = m[0].trim();
    const key = normalisePhone(raw);
    if (key.length < 7 || seen.has(key)) continue;
    seen.add(key);
    out.push(raw);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Floors. These are our business thresholds, not the model's numbers.
// ---------------------------------------------------------------------------
export const EMAIL_FLOOR = 0.85;
export const PHONE_FLOOR = 0.6;
export const FAX_THRESHOLD = 0.7;
export const REGIONS = ["US", "CA", "GB", "DE", "FR", "AU", "unknown"] as const;
export type Region = (typeof REGIONS)[number];

export type ReviewReason =
  | "email-low-confidence"
  | "email-none"
  | "phone-low-confidence"
  | "region-unknown"
  | "phone-is-fax";

export type Resolution =
  | { kind: "resolved"; email: string; phone: string | null; region: Region }
  | {
      kind: "needsReview";
      email: string | null;
      phone: string | null;
      region: Region;
      reasons: ReviewReason[];
      notes: string;
    }
  | { kind: "noContact" };

// ---------------------------------------------------------------------------
// One state, four questions. `isFax` is speculative — it only matters when the
// phone resolved to something other than "none", and we don't know that until
// the answers come back. Fan it out anyway.
// ---------------------------------------------------------------------------
export interface ResolutionInstrumentation {
  documentId: string;
  emailCandidates: number;
  phoneCandidates: number;
  answers: {
    primaryEmail: { choice: string; confidence: number };
    primaryPhone: { choice: string; confidence: number };
    isFax: number;
    region: { choice: string; confidence: number };
  };
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
}

export async function resolveContacts(
  documentId: string,
  text: string,
  client: TypeSafeClient,
  log: (line: ResolutionInstrumentation) => void
): Promise<Resolution> {
  const emails = findEmails(text);
  const phones = findPhones(text);
  const started = Date.now();

  const emailCriteria: Record<string, string | null> = {};
  for (const e of emails) emailCriteria[e] = null;
  emailCriteria.none = "The document contains no contact email address.";

  const phoneCriteria: Record<string, string | null> = {};
  for (const p of phones) phoneCriteria[p] = null;
  phoneCriteria.none = "The document contains no contact phone number.";

  const regionCriteria: Record<string, string | null> = {};
  for (const r of REGIONS) regionCriteria[r] = null;

  const questions = {
    primaryEmail: choice(
      "Which of these email addresses is the address a reply to this document should be sent to?",
      emailCriteria
    ),
    primaryPhone: choice(
      "Which of these phone numbers is the voice line on which a reply should be made?",
      phoneCriteria
    ),
    isFax: noul(
      "Is the phone number the document labels as its contact a fax line, rather than a voice line?"
    ),
    region: choice(
      "Which country is this document's contact information most likely based in?",
      regionCriteria
    ),
  };

  const response: SystemOneResult<typeof questions> = await client.systemOne({
    state: text,
    questions,
  });
  const latencyMs = Date.now() - started;

  const emailAns = response.answers.primaryEmail;
  const phoneAns = response.answers.primaryPhone;
  const faxAns = response.answers.isFax;
  const regionAns = response.answers.region;

  // Telemetry first; the routing below reads only the typed answers.
  log({
    documentId,
    emailCandidates: emails.length,
    phoneCandidates: phones.length,
    answers: {
      primaryEmail: { choice: emailAns.choice, confidence: emailAns.confidence },
      primaryPhone: { choice: phoneAns.choice, confidence: phoneAns.confidence },
      isFax: faxAns.noul,
      region: { choice: regionAns.choice, confidence: regionAns.confidence },
    },
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens,
    latencyMs,
  });

  // ---- Routing. Exhaustive reasons, never early-return. ----
  const noEmail = emailAns.choice === "none";
  const noPhone = phoneAns.choice === "none";

  if (noEmail && noPhone) return { kind: "noContact" };

  const reasons: ReviewReason[] = [];
  const notes: string[] = [];

  if (noEmail) {
    reasons.push("email-none");
    notes.push("no email address was selected");
  } else if (emailAns.confidence < EMAIL_FLOOR) {
    reasons.push("email-low-confidence");
    notes.push(`email confidence ${emailAns.confidence.toFixed(2)} < ${EMAIL_FLOOR}`);
  }

  if (regionAns.choice === "unknown") {
    reasons.push("region-unknown");
    notes.push("document region could not be determined");
  }

  // The isFax noul is only relevant when a phone was picked.
  let phoneIsFax = false;
  if (!noPhone) {
    phoneIsFax = faxAns.noul >= FAX_THRESHOLD;
    if (phoneIsFax) {
      reasons.push("phone-is-fax");
      notes.push(`phone classified as fax (noul=${faxAns.noul.toFixed(2)})`);
    } else if (phoneAns.confidence < PHONE_FLOOR) {
      reasons.push("phone-low-confidence");
      notes.push(`phone confidence ${phoneAns.confidence.toFixed(2)} < ${PHONE_FLOOR}`);
    }
  }

  const resolvedEmail = !noEmail ? emailAns.choice : null;
  const resolvedPhone = !noPhone && !phoneIsFax ? phoneAns.choice : null;
  const resolvedRegion = regionAns.choice as Region;

  if (
    resolvedEmail !== null &&
    resolvedRegion !== "unknown" &&
    reasons.length === 0
  ) {
    // A resolved document must have a non-null email and a known region. The
    // phone is optional; when it is present it has already cleared the fax and
    // confidence gates that would have populated `reasons`.
    return {
      kind: "resolved",
      email: resolvedEmail,
      phone: resolvedPhone,
      region: resolvedRegion,
    };
  }

  return {
    kind: "needsReview",
    email: resolvedEmail,
    phone: resolvedPhone,
    region: resolvedRegion,
    reasons,
    notes: notes.join("; "),
  };
}
