/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// bench.ts
// ---------------------------------------------------------------------------
import { readFileSync, writeFileSync } from "node:fs";
import { TypeSafeClient } from "@typesafe-ai/sdk";
import { resolveContacts, type ResolutionInstrumentation, type Resolution } from "./resolver";

const INPUT = "corpus.jsonl";
const SUMMARY = "summary.json";
const REGRESSION = "regression.json";

async function mapPool<T, R>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let cursor = 0;
  const runners = Array.from({ length: limit }, async () => {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      out[i] = await worker(items[i], i);
    }
  });
  await Promise.all(runners);
  return out;
}

async function main() {
  const docs = readFileSync(INPUT, "utf8")
    .split("\n")
    .filter(Boolean)
    .map((line) => JSON.parse(line) as { id: string; text: string });

  const client = new TypeSafeClient();
  const instrumentation: ResolutionInstrumentation[] = [];
  const results: Array<{ id: string; resolution: Resolution }> = [];

  await mapPool(docs, 5, async (doc) => {
    const resolution = await resolveContacts(doc.id, doc.text, client, (line) =>
      instrumentation.push(line)
    );
    results.push({ id: doc.id, resolution });
  });

  // Summaries.
  const byKind = results.reduce<Record<string, number>>((acc, r) => {
    acc[r.resolution.kind] = (acc[r.resolution.kind] ?? 0) + 1;
    return acc;
  }, {});
  const tokens = instrumentation.map((i) => i.inputTokens);
  const latencies = instrumentation.map((i) => i.latencyMs);
  const summary = {
    counts: byKind,
    inputTokens: {
      mean: tokens.reduce((a, b) => a + b, 0) / tokens.length,
      p95: [...tokens].sort((a, b) => a - b)[Math.floor(tokens.length * 0.95)],
    },
    latencyMs: {
      mean: latencies.reduce((a, b) => a + b, 0) / latencies.length,
      p95: [...latencies].sort((a, b) => a - b)[Math.floor(latencies.length * 0.95)],
    },
    unknownRegionFraction:
      instrumentation.filter((i) => i.answers.region.choice === "unknown").length /
      instrumentation.length,
  };
  writeFileSync(SUMMARY, JSON.stringify(summary, null, 2));

  // Regression check against a hand-written expectations file.
  const expected = JSON.parse(readFileSync(REGRESSION, "utf8")) as Array<{
    id: string;
    expected: Resolution;
  }>;
  const byId = new Map(results.map((r) => [r.id, r.resolution]));
  for (const e of expected) {
    const got = byId.get(e.id);
    if (JSON.stringify(got) !== JSON.stringify(e.expected)) {
      throw new Error(
        `regression mismatch on ${e.id}:\n  expected ${JSON.stringify(e.expected)}\n  got      ${JSON.stringify(got)}`
      );
    }
  }
  console.log("bench complete", summary);
}

void main();
