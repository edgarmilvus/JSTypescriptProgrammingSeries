/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// levels.ts
// ---------------------------------------------------------------------------
import { score } from "@typesafe-ai/sdk";

// Five levels, written as *situations* not degrees. "Moderately actionable" is
// unscoreable; "an action is required within 24 hours" is scoreable, and
// because every level is judged on its own against the state, this is the only
// form of level description that reliably produces a concentrated distribution.
export const LEVELS = [
  "No action is required; the attachment is a courtesy copy for the file.",
  "An action is required, but not within the week: the reviewer can batch it with other routine work.",
  "An action is required within the week: the reviewer should calendar it and act before the next weekly cycle.",
  "An action is required within 24 hours: a reply, filing, or signature is expected before the next business day closes.",
  "An action is required immediately: an external deadline is already running or a right is at risk of lapsing today.",
] as const;

// Deliberately mis-posed control. One level is a degree ("somewhat actiona-
// ble"), which the model cannot anchor against the state; the others are
// situations. Entropy on this question must exceed the well-posed ones.
export const brokenLevels = [
  "Not actionable at all.",
  "Somewhat actionable.",
  "Actionable.",
  "Very actionable.",
  "Extremely actionable.",
] as const;

export const contractActionability = score(
  "Given the firm's current capacity, how quickly should a human review this contract attachment?",
  LEVELS
);

export const ndaActionability = score(
  "Given that this attachment is an NDA, how quickly should a human review it?",
  LEVELS
);

export const brokenActionability = score(
  "How actionable is this attachment?",
  brokenLevels
);
