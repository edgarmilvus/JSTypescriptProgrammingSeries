/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------------------------
// analyze.ts
// ---------------------------------------------------------------------------
import { readFileSync } from "node:fs";
import { TypeSafeClient } from "@typesafe-ai/sdk";
import {
  contractActionability,
  ndaActionability,
  brokenActionability,
} from "./levels";

/** Shannon entropy over a probability map, in nats. Justification below. */
export function scoreEntropy(p: Record<string, number>): number {
  let h = 0;
  for (const v of Object.values(p)) {
    if (v > 0) h -= v * Math.log(v);
  }
  return h;
}

interface Row {
  id: string;
  type: "contract" | "nda";
  entropyContract: number;
  entropyNda: number;
  entropyBroken: number;
  spread: number;
  confidenceContract: number;
  pickedContract: number;
  levelDist: Record<string, number>;
}

async function main() {
  const attachments = readFileSync("attachments.jsonl", "utf8")
    .split("\n")
    .filter(Boolean)
    .map((line) => JSON.parse(line) as { id: string; type: "contract" | "nda"; text: string });

  const client = new TypeSafeClient();
  const rows: Row[] = [];

  for (const att of attachments) {
    const response = await client.systemOne({
      // State carries the attachment text only. The type is deliberately not in
      // state, so both well-posed questions see the same input and differ only
      // in instruction wording. This is what makes the disagreement table a
      // measurement of the *instructions* rather than of the state.
      state: att.text,
      questions: {
        contract: contractActionability,
        nda: ndaActionability,
        broken: brokenActionability,
      },
    });

    const c = response.answers.contract;
    const n = response.answers.nda;
    const b = response.answers.broken;

    const eC = scoreEntropy(c.probabilities);
    const eN = scoreEntropy(n.probabilities);
    const eB = scoreEntropy(b.probabilities);
    const spread = Math.max(eC, eN, eB) - Math.min(eC, eN, eB);

    rows.push({
      id: att.id,
      type: att.type,
      entropyContract: eC,
      entropyNda: eN,
      entropyBroken: eB,
      spread,
      confidenceContract: c.confidence,
      pickedContract: c.score,
      levelDist: c.probabilities,
    });
  }

  // Sort by spread (not by confidence). A doc with uniformly low confidence
  // everywhere is just ambiguous; a doc where the three questions diverge is
  // one where the *instruction wording* is doing the work, and those are the
  // ones worth diagnosing.
  rows.sort((a, b) => {
    if (b.spread !== a.spread) return b.spread - a.spread;
    return a.id.localeCompare(b.id);
  });

  console.log(
    [
      "id".padEnd(22),
      "type".padEnd(9),
      "H(contract)".padStart(12),
      "H(nda)".padStart(9),
      "H(broken)".padStart(9),
      "spread".padStart(8),
      "picked".padStart(7),
    ].join("  ")
  );
  for (const r of rows) {
    console.log(
      [
        r.id.padEnd(22),
        r.type.padEnd(9),
        r.entropyContract.toFixed(3).padStart(12),
        r.entropyNda.toFixed(3).padStart(9),
        r.entropyBroken.toFixed(3).padStart(9),
        r.spread.toFixed(3).padStart(8),
        r.pickedContract.toFixed(2).padStart(7),
      ].join("  ")
    );
  }

  const meanWell = rows.reduce((s, r) => s + (r.entropyContract + r.entropyNda) / 2, 0) / rows.length;
  const meanBroken = rows.reduce((s, r) => s + r.entropyBroken, 0) / rows.length;
  console.log(
    `\nmean H(well-posed) = ${meanWell.toFixed(3)}  mean H(broken) = ${meanBroken.toFixed(3)}`
  );
  if (meanBroken <= meanWell) {
    console.warn("CONTROL FAILED: broken question is not visibly more entropic.");
  }
}

void main();
