/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  lib/skills.ts — the roster.
//
//  This file is static data plus two derived lookups. It is imported once per
//  process and never mutated. Everything downstream reads from it.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * One row of the *index*. This is the sixty-character surface the agent's
 * system prompt shows today, and the only thing Stage 1's Choice question is
 * allowed to see. Small on purpose: 182 of these is roughly 16 KB of prompt,
 * which is the entire reason the two-stage design exists.
 */
export interface SkillIndexRow {
  readonly name: string;
  readonly category: string;
  /** Truncated to <= 60 characters. This truncation is why Stage 2 exists. */
  readonly brief: string;
}

/** A single property in a skill's argument schema. */
export interface JsonSchemaProperty {
  readonly type: "string" | "number" | "boolean";
  readonly description: string;
  /** Present when the argument is a closed set; becomes a Choice question. */
  readonly enum?: readonly string[];
}

/**
 * The full record. Resolved only for the shortlisted skills, in Stage 2.
 * `descriptionFull` is the untruncated blurb; `body` is the head of the
 * skill's own SKILL.md, which is what actually disambiguates two lookalikes.
 */
export interface SkillRecord extends SkillIndexRow {
  readonly descriptionFull: string;
  readonly body: string;
  readonly argSchema: {
    readonly type: "object";
    readonly properties: Readonly<Record<string, JsonSchemaProperty>>;
    readonly required?: readonly string[];
  };
}

/** How many candidates survive Stage 1 and get their full text shipped to Stage 2. */
export const SHORTLIST_SIZE = 3;

/** How many characters of each candidate's SKILL.md Stage 2 carries. */
export const EXCERPT_CHARS = 700;

/**
 * The roster. Two deliberate lookalike pairs sit in here — the two `.pptx`
 * skills and the two Kubernetes secret skills — because a roster with no
 * ambiguous neighbours would make Stage 2 look like wasted effort.
 */
export const ROSTER = [
  {
    name: "pptx-author",
    category: "office",
    brief: "Build PowerPoint decks headless with python-pptx.",
    descriptionFull:
      "Build PowerPoint decks headless with python-pptx: create slides from a branded template, lay out text and image placeholders, and write speaker notes.",
    body:
      "## When to use\nAuthoring a NEW deck from scratch or from a template. You control slide geometry and placeholder content. Use this when the deliverable does not exist yet.\n\n## Do not use for\nEditing an existing deck a human already wrote, or reading values out of one.",
    argSchema: {
      type: "object",
      properties: {
        template: {
          type: "string",
          description: "Path or slug of the branded template to start from.",
        },
        deck_kind: {
          type: "string",
          description: "Which skeleton to build.",
          enum: ["pitch", "board_update", "postmortem"],
        },
        slide_count: {
          type: "number",
          description: "Target number of slides.",
        },
        include_speaker_notes: {
          type: "boolean",
          description: "Whether to write speaker notes on each slide.",
        },
      },
      required: ["deck_kind"],
    },
  },
  {
    name: "powerpoint",
    category: "office",
    brief: "Create, read, edit .pptx decks, slides, notes, templates.",
    descriptionFull:
      "Create, read, and edit PowerPoint decks: open an existing .pptx, modify slides, notes, and templates in place, and extract text or speaker notes from one.",
    body:
      "## When to use\nEditing or inspecting a deck that already exists. In-place modification of slides, notes, and templates, and extraction of their text.\n\n## Do not use for\nAuthoring a brand-new deck from a template -- use pptx-author for that.",
    argSchema: {
      type: "object",
      properties: {
        deck_path: {
          type: "string",
          description: "Path to the existing .pptx file.",
        },
        operation: {
          type: "string",
          description: "What to do with the deck.",
          enum: ["read_text", "replace_slide", "edit_notes"],
        },
      },
      required: ["deck_path", "operation"],
    },
  },
  {
    name: "apple-notes",
    category: "apple",
    brief: "Manage Apple Notes via memo CLI: create, search, edit.",
    descriptionFull:
      "Create, search, and edit Apple Notes through the memo CLI, including moving notes between folders and syncing to iCloud.",
    body:
      "## When to use\nApple Notes specifically: creating a note, finding one, editing one, or filing one into a folder.\n\n## Do not use for\nOther note systems (Notion, Obsidian, Trello) — this skill shells out to memo and only touches the Apple Notes database.",
    argSchema: {
      type: "object",
      properties: {
        folder: {
          type: "string",
          description: "Destination folder name inside Apple Notes.",
        },
        title: { type: "string", description: "Title for the new note." },
      },
      required: ["title"],
    },
  },
  {
    name: "findmy",
    category: "apple",
    brief: "Track Apple devices/AirTags via FindMy.app on macOS.",
    descriptionFull:
      "Look up the last known location of Apple devices and AirTags through FindMy.app on macOS.",
    body: "## When to use\nLocating a device or tag the user owns.\n",
    argSchema: {
      type: "object",
      properties: {
        device_name: {
          type: "string",
          description: "Name of the device or tag to locate.",
        },
      },
      required: ["device_name"],
    },
  },
  {
    name: "xurl",
    category: "social",
    brief: "X/Twitter via xurl CLI: raw post search, posting, DM, media.",
    descriptionFull:
      "Read and write on X/Twitter through the xurl CLI: search posts, publish a post, send a direct message, or upload media.",
    body:
      "## When to use\nX/Twitter only. Posting, searching, DMing, or uploading media on that one network.\n\n## Do not use for\nOther social networks. There is no Mastodon, Bluesky, or LinkedIn support in this skill.",
    argSchema: {
      type: "object",
      properties: {
        text: { type: "string", description: "Body of the post to publish." },
        action: {
          type: "string",
          description: "What to do on X.",
          enum: ["post", "search", "dm"],
        },
      },
      required: ["action"],
    },
  },
  {
    name: "pg-explain",
    category: "database",
    brief: "Explain and optimize Postgres query plans.",
    descriptionFull:
      "Run EXPLAIN ANALYZE on a Postgres query and interpret the plan: sequential scans, missing indexes, bad row estimates, and nested-loop blowups.",
    body: "## When to use\nA Postgres query is slow and you need to know why.\n",
    argSchema: {
      type: "object",
      properties: {
        sql: {
          type: "string",
          description: "The SQL statement to explain.",
        },
        analyze: {
          type: "boolean",
          description: "Run the query for real rather than planning only.",
        },
      },
      required: ["sql"],
    },
  },
  {
    name: "k8s-secret-rotate",
    category: "infra",
    brief: "Rotate Kubernetes secrets and signing keys safely.",
    descriptionFull:
      "Rotate Kubernetes secrets and signing keys without downtime: generate the new value, roll it out, wait for both old and new to be accepted, then revoke the old one.",
    body:
      "## When to use\nReplacing a credential that is currently in use. This is the skill that changes values.\n\n## Do not use for\nAuditing secrets without changing them — use k8s-secret-audit.",
    argSchema: {
      type: "object",
      properties: {
        namespace: {
          type: "string",
          description: "Kubernetes namespace holding the secret.",
        },
        secret_name: {
          type: "string",
          description: "Name of the secret to rotate.",
        },
        dry_run: {
          type: "boolean",
          description: "Plan the rollout without applying it.",
        },
      },
      required: ["namespace", "secret_name"],
    },
  },
  {
    name: "k8s-secret-audit",
    category: "infra",
    brief: "Audit Kubernetes secrets for stale or leaked values.",
    descriptionFull:
      "Audit Kubernetes secrets without modifying them: find values that are stale, duplicated across namespaces, or committed to a repository.",
    body:
      "## When to use\nInspecting secrets and reporting on them. This skill never writes to the cluster.\n\n## Do not use for\nActually rotating a value — use k8s-secret-rotate.",
    argSchema: {
      type: "object",
      properties: {
        namespace: {
          type: "string",
          description: "Kubernetes namespace to audit.",
        },
        include_historical: {
          type: "boolean",
          description: "Also check previously retired secret versions.",
        },
      },
      required: ["namespace"],
    },
  },
] as const satisfies readonly SkillRecord[];

// ── Derived lookups. Built once, at module load, so no request pays for them.

/**
 * O(1) lookup from a skill name to its full record. The key is deliberately
 * widened to `string`: a skill name arrives as a Jev *answer*, not as a
 * compile-time literal, so the map has to accept arbitrary strings and return
 * `undefined` for the ones that are not real skills.
 */
const byName = new Map<string, SkillRecord>();
for (const skill of ROSTER) {
  byName.set(skill.name, skill);
}
export const SKILL_BY_NAME: ReadonlyMap<string, SkillRecord> = byName;

/** The compact index. Stage 1 never sees anything larger than this. */
export const SKILL_INDEX: readonly SkillIndexRow[] = ROSTER.map(
  ({ name, category, brief }) => ({ name, category, brief }),
);

/**
 * The `criteria` object for Stage 1's Choice question: skill name -> sixty
 * character brief. Frozen and module-scoped so every request reuses the same
 * object identity rather than allocating 182 strings per turn.
 */
const nameCriteria: Record<string, string> = {};
for (const row of SKILL_INDEX) {
  nameCriteria[row.name] = row.brief;
}
export const SKILL_NAME_CRITERIA: Readonly<Record<string, string>> =
  Object.freeze(nameCriteria);
