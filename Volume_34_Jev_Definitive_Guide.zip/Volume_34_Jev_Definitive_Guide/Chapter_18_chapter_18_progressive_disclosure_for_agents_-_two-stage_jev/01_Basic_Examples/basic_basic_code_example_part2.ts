/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  lib/disclosure.ts — Stage 1: the wide, cheap pass.
// ─────────────────────────────────────────────────────────────────────────────

import { choice, noul, TypeSafeClient } from "@typesafe-ai/sdk";
import {
  SHORTLIST_SIZE,
  SKILL_NAME_CRITERIA,
} from "./skills";

/**
 * The model that answers every question in this file. `jev-latest` is the SDK
 * default and currently resolves to a versioned ID the response reports back.
 * Pin the versioned ID once you have tuned thresholds against it, because an
 * alias moves when a new release ships and your constants do not move with it.
 */
export const JEV_MODEL = "jev-latest";

/** Below this mean, the turn does not want a skill; the agent answers in prose. */
export const GATE_THRESHOLD = 0.3;

/** The key under which Stage 1's Choice answer comes back. */
const ROUTE_KEY = "route";

const ROUTE_INSTRUCTIONS =
  "Which of these skills, if any, is the right one to load to help with the " +
  "user's latest request?";

/**
 * Three yes/no questions about the *request*, not about the subject matter.
 * They must be phrased this way. A question about subject matter will not
 * separate "explain what a monad is" from a request that needs a skill,
 * because both are software. These three ask whether an action is wanted.
 */
const GATE_QUESTIONS = {
  acts_on_user_system:
    "Is the assistant being asked to act on the user's files, accounts, " +
    "devices, or online services, rather than only to explain or advise?",
  needs_documented_procedure:
    "Would a careful expert answering this consult a specific documented " +
    "procedure or set of commands, rather than answering from general " +
    "understanding?",
  prose_suffices:
    "Could a knowledgeable generalist fully satisfy this request in prose, " +
    "with no tools, no documentation, and no access to the user's files or " +
    "accounts?",
} as const;

/** Gate questions whose yes points *away* from needing a skill. */
const INVERTED_GATE_KEYS: ReadonlySet<string> = new Set(["prose_suffices"]);

/** What Stage 1 returns. Note that an empty shortlist is a valid, expected result. */
export interface Shortlist {
  /** Ranked best-first; at most SHORTLIST_SIZE entries. Empty means "answer in prose". */
  readonly candidates: readonly string[];
  /** Mean of the three oriented gate questions, 0..1. */
  readonly gate: number;
  /** Probability on the top-ranked skill name, before the gate is applied. */
  readonly topProbability: number;
  /** Jev's reported confidence in the top-ranked name. */
  readonly confidence: number;
  readonly latencyMs: number;
}

/**
 * Stage 1 — wide, cheap, compact.
 *
 * One Choice question over the entire roster (each option's criteria is its
 * sixty-character brief) plus three Noul questions that decide whether the
 * turn wants a skill at all. All four ride in a single request, so the gate
 * costs no extra round trip.
 */
export async function runStageOne(
  client: TypeSafeClient,
  turn: string,
): Promise<Shortlist> {
  const startedAt = performance.now();

  // A single request. Four questions, one state, one round trip.
  const { answers } = await client.systemOne({
    model: JEV_MODEL,
    state: { request: turn, recent_context: "" },
    questions: {
      [ROUTE_KEY]: choice(ROUTE_INSTRUCTIONS, SKILL_NAME_CRITERIA),
      acts_on_user_system: noul(GATE_QUESTIONS.acts_on_user_system),
      needs_documented_procedure: noul(GATE_QUESTIONS.needs_documented_procedure),
      // Explicit true/false criteria matter here: the boundary between "I can
      // just answer this" and "I need the documented procedure" is the one
      // the gate lives or dies on.
      prose_suffices: noul(GATE_QUESTIONS.prose_suffices, {
        true: "A generalist with no tools and no files answers this fully in prose.",
        false: "Prose alone leaves the request unsatisfied.",
      }),
    },
  });

  // The Choice answer carries a full distribution over every option, not just
  // the winner. Sort it. The probabilities always sum to 1, so some name is
  // ranked first even when nothing in the roster fits -- which is precisely
  // why the gate exists and why we never trust the top name alone.
  const route = answers[ROUTE_KEY];
  const ranked: string[] = Object.entries(route.probabilities)
    .sort(([, left], [, right]) => right - left)
    .map(([name]) => name);

  const topName = ranked[0];
  const topProbability =
    topName === undefined ? 0 : (route.probabilities[topName] ?? 0);

  // Orient the three gate answers so that "high" always means "a skill is
  // wanted", then average them. Averaging rather than taking the max is
  // deliberate: the three questions are correlated but not identical, and a
  // mean is far less jumpy than any single one of them.
  const gateAnswers: ReadonlyArray<readonly [string, number]> = [
    ["acts_on_user_system", answers.acts_on_user_system.noul],
    ["needs_documented_procedure", answers.needs_documented_procedure.noul],
    ["prose_suffices", answers.prose_suffices.noul],
  ];
  const oriented = gateAnswers.map(([key, value]) =>
    INVERTED_GATE_KEYS.has(key) ? 1 - value : value,
  );
  const gate = oriented.reduce((sum, value) => sum + value, 0) / oriented.length;

  const latencyMs = Math.round(performance.now() - startedAt);

  // The gate is a hard stop. Under threshold we return zero candidates and the
  // caller answers in prose -- no Stage 2, no skill loaded, no cost beyond
  // this one call.
  if (gate < GATE_THRESHOLD) {
    return {
      candidates: [],
      gate,
      topProbability,
      confidence: route.confidence,
      latencyMs,
    };
  }

  return {
    candidates: ranked.slice(0, SHORTLIST_SIZE),
    gate,
    topProbability,
    confidence: route.confidence,
    latencyMs,
  };
}
