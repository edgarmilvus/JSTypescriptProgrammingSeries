/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  lib/disclosure.ts — Stage 2: the narrow, expensive pass.
// ─────────────────────────────────────────────────────────────────────────────

import type {
  ChoiceResponse,
  NoulResponse,
  Questions,
} from "@typesafe-ai/sdk";
import { SKILL_BY_NAME, EXCERPT_CHARS } from "./skills";

/** Below this "does this skill actually fit" probability, the whole shortlist is rejected. */
export const FITS_THRESHOLD = 0.3;

/** The key under which Stage 2's Choice answer comes back. */
const WINNER_KEY = "winner";

/** Prefix for the per-candidate Noul questions, so they can be read back by name. */
const FITS_PREFIX = "fits::";

const RERANK_INSTRUCTIONS =
  "Exactly one of these skills is the right one to load for the user's latest " +
  "request. Which one? Read what each actually does, not just its name.";

/** What Stage 2 returns. A null winner is a real answer, not a failure. */
export interface Rerank {
  readonly winner: string | null;
  readonly fits: Readonly<Record<string, number>>;
  readonly confidence: number;
  readonly latencyMs: number;
}

/**
 * Stage 2 — the same question, put to better evidence.
 *
 * Each candidate's option criteria is its full description plus the opening of
 * its own SKILL.md, which is where the "do not use this for X, use Y" sentence
 * lives. A companion Noul per candidate asks the *absolute* question -- does
 * this skill do the specific thing the request asks for -- so the shortlist as
 * a whole can come back empty-handed instead of being forced to pick a winner.
 */
export async function runStageTwo(
  client: TypeSafeClient,
  turn: string,
  candidates: readonly string[],
): Promise<Rerank> {
  if (candidates.length === 0) {
    return { winner: null, fits: {}, confidence: 0, latencyMs: 0 };
  }

  const startedAt = performance.now();

  // Build the richer option text. This is context augmentation for a
  // *decision* rather than for a generation -- the retrieved passages are the
  // skills' own documentation, and the "generation" step is a one-of-three
  // choice.
  const criteria: Record<string, string> = {};
  for (const name of candidates) {
    const skill = SKILL_BY_NAME.get(name);
    // Guard rather than assert. If Stage 1 ever hands us a name not in the
    // roster, we would rather skip it than throw inside a request handler.
    if (skill === undefined) continue;
    criteria[name] = `${skill.descriptionFull} — ${skill.body.slice(0, EXCERPT_CHARS)}`;
  }

  // The question map is built from runtime data, so it is typed as the SDK's
  // `Questions` alias rather than inferred from a literal. That costs us
  // narrowing on the answers, which we recover with explicit type guards below.
  const questions: Questions = {
    [WINNER_KEY]: choice(RERANK_INSTRUCTIONS, criteria),
  };

  for (const name of Object.keys(criteria)) {
    const skill = SKILL_BY_NAME.get(name);
    if (skill === undefined) continue;
    questions[`${FITS_PREFIX}${name}`] = noul(
      `Does the skill '${name}' do the specific thing the user's request asks ` +
        `for? It is described as: ${skill.descriptionFull}`,
      {
        true: "The skill does exactly what the request asks for.",
        false: "The skill is adjacent, a lookalike, or does something else.",
      },
    );
  }

  const { answers } = await client.systemOne({
    model: JEV_MODEL,
    state: { request: turn, recent_context: "" },
    questions,
  });

  // Narrow the union back down. `answers` is a Record of the three-way Answer
  // union, so each read needs a discriminant check before the field exists.
  const winnerAnswer = answers[WINNER_KEY] as ChoiceResponse | undefined;
  const winner =
    winnerAnswer !== undefined && winnerAnswer.type === "choice"
      ? winnerAnswer.choice
      : null;
  const confidence =
    winnerAnswer !== undefined && winnerAnswer.type === "choice"
      ? winnerAnswer.confidence
      : 0;

  // One absolute read per candidate. These are independent questions, so they
  // can all come back low -- which is exactly what we want. A relative Choice
  // must pick something; these do not have to.
  const fits: Record<string, number> = {};
  for (const name of Object.keys(criteria)) {
    const answer = answers[`${FITS_PREFIX}${name}`] as NoulResponse | undefined;
    fits[name] = answer !== undefined && answer.type === "noul" ? answer.noul : 0;
  }

  // `Math.max()` with no arguments returns -Infinity, and the spread of an
  // empty object's values is no arguments. The trailing 0 is the floor.
  const bestFit = Math.max(0, ...Object.values(fits));

  const latencyMs = Math.round(performance.now() - startedAt);

  return {
    // The Choice and the Nouls are answering different questions. The Choice
    // settles *which* skill; the Nouls settle *whether* to say anything at
    // all. So we gate on the Nouls and read the winner from the Choice.
    winner: bestFit >= FITS_THRESHOLD ? winner : null,
    fits,
    confidence,
    latencyMs,
  };
}
