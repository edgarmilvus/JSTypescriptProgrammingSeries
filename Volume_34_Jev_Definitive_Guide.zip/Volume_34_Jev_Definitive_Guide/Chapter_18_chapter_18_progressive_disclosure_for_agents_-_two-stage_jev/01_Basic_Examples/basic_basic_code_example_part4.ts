/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  lib/disclosure.ts — the glue.
// ─────────────────────────────────────────────────────────────────────────────

import { SKILL_BY_NAME, type SkillRecord } from "./skills";

/** Why a routing decision came out the way it did. Log this on every turn. */
export type RouteReason =
  | "routed"        // Stage 2 produced a winner above the fits threshold
  | "gate"          // the turn did not want a skill
  | "no-fit"        // the shortlist was real but nothing in it fit
  | "unknown-name"; // a name came back that is not in the roster

export interface RouteDecision {
  readonly winner: SkillRecord | null;
  readonly reason: RouteReason;
  readonly candidateNames: readonly string[];
  readonly gate: number;
  readonly fits: Readonly<Record<string, number>>;
  readonly confidence: number;
  readonly timings: {
    readonly stageOneMs: number;
    readonly stageTwoMs: number;
    readonly totalMs: number;
  };
}

/**
 * The two-stage router.
 *
 * The two awaits are serial because the second one's *arguments* depend on the
 * first one's answer -- this is a genuine data dependency, not a loop. That is
 * the only kind of serial await you should accept in a hot path.
 */
export async function routeSkill(
  client: TypeSafeClient,
  turn: string,
): Promise<RouteDecision> {
  const startedAt = performance.now();

  const stageOne = await runStageOne(client, turn);

  // Reason "gate": the turn did not want a skill. Answer in prose.
  if (stageOne.candidates.length === 0) {
    return {
      winner: null,
      reason: "gate",
      candidateNames: [],
      gate: stageOne.gate,
      fits: {},
      confidence: stageOne.confidence,
      timings: {
        stageOneMs: stageOne.latencyMs,
        stageTwoMs: 0,
        totalMs: Math.round(performance.now() - startedAt),
      },
    };
  }

  const stageTwo = await runStageTwo(client, turn, stageOne.candidates);

  // Reason "no-fit": the shortlist was built and then rejected wholesale. This
  // is the branch that catches "post this to Mastodon" on an X-only roster.
  if (stageTwo.winner === null) {
    return {
      winner: null,
      reason: "no-fit",
      candidateNames: stageOne.candidates,
      gate: stageOne.gate,
      fits: stageTwo.fits,
      confidence: stageTwo.confidence,
      timings: {
        stageOneMs: stageOne.latencyMs,
        stageTwoMs: stageTwo.latencyMs,
        totalMs: Math.round(performance.now() - startedAt),
      },
    };
  }

  const resolved = SKILL_BY_NAME.get(stageTwo.winner);

  // Reason "unknown-name": the name came back but is not in the roster. With
  // Jev this should be unreachable -- the answer space is the criteria map --
  // but the check costs nothing and turns a silent bug into a logged one.
  if (resolved === undefined) {
    return {
      winner: null,
      reason: "unknown-name",
      candidateNames: stageOne.candidates,
      gate: stageOne.gate,
      fits: stageTwo.fits,
      confidence: stageTwo.confidence,
      timings: {
        stageOneMs: stageOne.latencyMs,
        stageTwoMs: stageTwo.latencyMs,
        totalMs: Math.round(performance.now() - startedAt),
      },
    };
  }

  return {
    winner: resolved,
    reason: "routed",
    candidateNames: stageOne.candidates,
    gate: stageOne.gate,
    fits: stageTwo.fits,
    confidence: stageTwo.confidence,
    timings: {
      stageOneMs: stageOne.latencyMs,
      stageTwoMs: stageTwo.latencyMs,
      totalMs: Math.round(performance.now() - startedAt),
    },
  };
}
