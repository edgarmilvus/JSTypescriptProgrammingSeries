/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  app/actions/route-skill.ts — the Next.js entry point.
//
//  Everything above this line is server-only: it reads TYPESAFE_API_KEY and it
//  must never be imported into a Client Component. This module is the boundary.
// ─────────────────────────────────────────────────────────────────────────────

"use server";

import {
  APIConnectionError,
  APITimeoutError,
  RateLimitError,
  TypeSafeClient,
  UnprocessableEntityError,
} from "@typesafe-ai/sdk";
import { routeSkill, type RouteDecision } from "@/lib/disclosure";

/**
 * One client for the whole process.
 *
 * `timeout` is per *attempt*, not per call. With `maxRetries: 2` and a 4 s
 * attempt timeout, the worst case for a single failing request is roughly
 * 4 s + backoff + 4 s + backoff + 4 s -- comfortably inside a 30 s function
 * limit, and comfortably outside a 10 s one. Tune both numbers together.
 */
const client = new TypeSafeClient({
  retry: { maxRetries: 2, backoffInitialMs: 250, backoffMaxMs: 2_000 },
  timeout: 4_000,
});

export type RouteSkillResult =
  | {
      ok: true;
      winner: string | null;
      reason: RouteDecision["reason"];
      candidates: readonly string[];
      gate: number;
      fits: Readonly<Record<string, number>>;
      confidence: number;
      totalMs: number;
    }
  | { ok: false; code: "EMPTY_REQUEST" | "UPSTREAM"; message: string };

/**
 * Server Action: takes a user turn, returns a routing decision.
 * No skill text, no manifest, and no API key ever crosses to the browser.
 */
export async function routeSkillAction(
  formData: FormData,
): Promise<RouteSkillResult> {
  // `FormData.get` returns `string | File | null`. Coercing a File with String()
  // gives you the literal string "[object File]", which then gets routed as a
  // turn. Check the type, do not just coerce.
  const raw = formData.get("turn");
  const turn = typeof raw === "string" ? raw.trim() : "";

  if (turn.length === 0) {
    return { ok: false, code: "EMPTY_REQUEST", message: "No turn supplied." };
  }

  try {
    const decision = await routeSkill(client, turn);
    return {
      ok: true,
      winner: decision.winner?.name ?? null,
      reason: decision.reason,
      candidates: decision.candidateNames,
      gate: decision.gate,
      fits: decision.fits,
      confidence: decision.confidence,
      totalMs: decision.timings.totalMs,
    };
  } catch (error) {
    // Retries are already exhausted by the time we get here; the SDK's default
    // retry policy covers 408, 429, and 500-599, and honors Retry-After.
    if (error instanceof RateLimitError) {
      return {
        ok: false,
        code: "UPSTREAM",
        message: `Rate limited; retry after ${error.retryAfterMs ?? "unknown"} ms.`,
      };
    }
    if (error instanceof APITimeoutError || error instanceof APIConnectionError) {
      return { ok: false, code: "UPSTREAM", message: "TypeSafe unreachable." };
    }
    if (error instanceof UnprocessableEntityError) {
      return {
        ok: false,
        code: "UPSTREAM",
        message: "Request failed validation. Check the question shapes.",
      };
    }
    throw error; // unknown error: let the framework's error boundary handle it
  }
}
