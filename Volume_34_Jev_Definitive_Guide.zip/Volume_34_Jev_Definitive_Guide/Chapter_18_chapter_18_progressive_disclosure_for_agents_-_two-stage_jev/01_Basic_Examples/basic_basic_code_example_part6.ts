/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.ts
// Description: Basic Code Example
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
//  scripts/route-demo.ts — run it:  npx tsx scripts/route-demo.ts
//
//  Five turns against the roster above. No web server, no framework.
// ─────────────────────────────────────────────────────────────────────────────

import { TypeSafeClient } from "@typesafe-ai/sdk";
import { routeSkill } from "../lib/disclosure";

const client = new TypeSafeClient({ timeout: 10_000 });

const TURNS = [
  "Build a pitch deck skeleton as a .pptx using our firm template.",
  "Fix the speaker notes on the Q3 board deck.",
  "Rotate the signing keys in prod and confirm nothing breaks.",
  "Explain what a monad is to me like I'm five.",
  "Add these three cards to our Trello backlog.",
] as const;

for (const turn of TURNS) {
  const decision = await routeSkill(client, turn);

  const shortlist = decision.candidateNames.join(", ") || "(none)";
  const fits = Object.entries(decision.fits)
    .map(([name, p]) => `${name}=${p.toFixed(2)}`)
    .join(" ");

  console.log(`\n"${turn}"`);
  console.log(`  reason      ${decision.reason}`);
  console.log(`  shortlist   ${shortlist}`);
  console.log(`  fits        ${fits || "(not asked)"}`);
  console.log(`  gate        ${decision.gate.toFixed(2)}`);
  console.log(`  winner      ${decision.winner?.name ?? "(none)"}`);
  console.log(
    `  timing      stage1=${decision.timings.stageOneMs}ms ` +
      `stage2=${decision.timings.stageTwoMs}ms ` +
      `total=${decision.timings.totalMs}ms`,
  );
}
