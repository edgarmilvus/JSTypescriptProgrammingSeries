/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// lib/skill-router.ts
//
// Progressive-disclosure routing for the Ops Copilot.
//
//   Stage 1: one Jev call ranks all 182 skills against their 60-char index lines
//            and answers whether any skill should be suggested at all.
//   Stage 2: one Jev call re-reads the top 3 with full descriptions and the head
//            of each SKILL.md, and is free to reject all of them.
//
// The roster's full text never enters the model's context unless a candidate has
// already survived stage 1. That is the whole point of the pattern.
// ─────────────────────────────────────────────────────────────────────────────
import {
  TypeSafeClient,
  choice,
  noul,
  score,
  type NoulResponse,
  type Question,
} from "@typesafe-ai/sdk";
import { ROSTER, BY_NAME } from "@/lib/skills";

/** The client reads TYPESAFE_API_KEY from the environment and defaults to jev-latest. */
const jev = new TypeSafeClient();
const MODEL = "jev-latest";

const SHORTLIST = 3;          // candidates carried from stage 1 into stage 2
const EXCERPT_CHARS = 700;    // bytes of SKILL.md each shortlisted candidate brings
const GATE_THRESHOLD = 0.3;   // below this, suggest nothing at all
const FITS_THRESHOLD = 0.3;   // below this, discard the shortlist outright
const FITS_HIGH_STAKES = 0.45; // …and above this, when the blast radius is large

const ROUTE_INSTRUCTIONS =
  "Which skill, if any, should be loaded to help with the user's latest request?";

/** Everything the questions are allowed to see. Nothing else from the session. */
export interface Turn {
  text: string;
  surface: "chat" | "slash" | "automation";
  scopes: string[]; // OAuth scopes the acting user actually holds
}

/** What the pipeline hands back to the agent harness. */
export interface RouteDecision {
  suggestion: string | null;         // one skill name, or null for "nothing here applies"
  gate: number;                      // stage-1 actionability mean, 0..1
  ranked: Array<[string, number]>;   // stage-1 distribution, top 3 kept
  fits: Record<string, number>;      // stage-2 absolute fit per candidate
  requiredFits: number;              // the threshold this turn was judged against
  latencyMs: { stage1: number; stage2: number; total: number };
}

/**
 * Stage 1. A single Choice over the whole roster — Jev's Choice takes up to 255
 * options, so 182 fits in one question — plus four questions that decide whether
 * the ranking should be acted on at all.
 *
 * The gate asks about *actionability*, not subject matter. "Explain what a monad
 * is" and "rotate my signing key" are both software questions; only one of them
 * wants a skill, and a topic-shaped question cannot separate them.
 */
function stage1Questions(): Record<string, Question> {
  return {
    which: choice(
      ROUTE_INSTRUCTIONS,
      // The exact text the agent's own index shows. Epistemic parity: the router
      // is not cheating with information the agent was never given.
      Object.fromEntries(ROSTER.map((s) => [s.name, s.indexDescription]))
    ),
    acts_on_account: noul(
      "Is the copilot being asked to act on the user's workspace — its data, members, " +
        "billing, or integrations — rather than only to explain or advise?"
    ),
    follows_procedure: noul(
      "Would a careful operator answering this consult a specific documented procedure " +
        "or set of commands, rather than answering from general understanding?"
    ),
    prose_suffices: noul(
      "Could a knowledgeable generalist fully satisfy this request in prose, with no " +
        "tools, no documentation, and no access to the user's workspace?"
    ),
    blast_radius: score(
      "If the copilot loaded the wrong skill for this turn, how much would it cost the user?",
      [
        "Nothing: the wrong skill simply would not help.",
        "Reversible: it would cost one extra turn to recover.",
        "Costly: it would change workspace state or spend money.",
        "Severe: it could delete data, expose it, or act on billing.",
      ]
    ),
  };
}

/**
 * Stage 2. The same Choice, over three candidates instead of 182, now with each
 * skill's full description and the opening of its own SKILL.md as the criterion
 * text. One absolute Noul per candidate asks whether that skill does the
 * specific thing the turn asks for, so the shortlist can be rejected wholesale.
 *
 * Note the verb: *absolute*. A Choice is relative — it settles which of these.
 * The Nouls are absolute — each can come back low. The shortlist can improve the
 * pick and still fail the gate.
 */
function stage2Questions(shortlist: string[]): Record<string, Question> {
  const questions: Record<string, Question> = {
    which: choice(
      "Exactly one of these skills is the right one to load. Which? Read what each " +
        "actually does, not just its name.",
      Object.fromEntries(
        shortlist.map((name) => [
          name,
          `${BY_NAME[name].descriptionFull} — ${BY_NAME[name].body.slice(0, EXCERPT_CHARS)}`,
        ])
      )
    ),
  };
  for (const name of shortlist) {
    questions[`fits_${name}`] = noul(
      `Does the skill '${name}' do the specific thing the user's request asks for? ` +
        `It is described as: ${BY_NAME[name].descriptionFull}`
    );
  }
  return questions;
}

/**
 * Route one turn. Two Jev round trips in the happy path, one in the common case
 * where the gate says "this is just a question".
 */
export async function routeTurn(turn: Turn): Promise<RouteDecision> {
  // Send only what these questions need. Context rot is real: unrelated session
  // material costs accuracy, so the state is built from scratch, not appended to.
  const state = {
    request: turn.text,
    surface: turn.surface,
    granted_scopes: turn.scopes,
  };

  // ── Stage 1: rank everything, then decide whether to speak ────────────────
  const t0 = performance.now();
  const wide = await jev.systemOne({
    state,
    questions: stage1Questions(),
    model: MODEL,
  });
  const stage1Ms = performance.now() - t0;

  // Three Nouls, averaged with the third inverted: it is phrased so that "yes"
  // points away from needing a skill, which is convenient for a human reading
  // the battery but has to be flipped before it enters the mean.
  const gate =
    (wide.answers.acts_on_account.noul +
      wide.answers.follows_procedure.noul +
      (1 - wide.answers.prose_suffices.noul)) /
    3;

  const ranked = Object.entries(wide.answers.which.probabilities).sort(
    ([, a], [, b]) => b - a
  );

  const bail = (stage2 = 0): RouteDecision => ({
    suggestion: null,
    gate,
    ranked: ranked.slice(0, SHORTLIST),
    fits: {},
    requiredFits: FITS_THRESHOLD,
    latencyMs: { stage1: stage1Ms, stage2, total: stage1Ms + stage2 },
  });

  if (gate < GATE_THRESHOLD) return bail();

  // Permission filter *before* the expensive pass: never spend stage-2 tokens on
  // a skill the acting user could not execute anyway.
  const shortlist = ranked
    .filter(([name]) =>
      BY_NAME[name].requiredScopes.every((s) => turn.scopes.includes(s))
    )
    .slice(0, SHORTLIST)
    .map(([name]) => name);

  if (shortlist.length === 0) return bail();

  // ── Stage 2: re-read the shortlist with its own evidence ──────────────────
  const t1 = performance.now();
  const narrow = await jev.systemOne({
    state,
    questions: stage2Questions(shortlist),
    model: MODEL,
  });
  const stage2Ms = performance.now() - t1;

  const fits = Object.fromEntries(
    shortlist.map((name) => [
      name,
      (narrow.answers[`fits_${name}`] as NoulResponse).noul,
    ])
  );
  const winnerFits = Math.max(...Object.values(fits));

  // Risk-scaled acceptance. A read-only skill can be suggested on a moderate
  // signal; a skill that touches billing or deletes data needs a stronger one.
  const requiredFits =
    wide.answers.blast_radius.score >= 2 ? FITS_HIGH_STAKES : FITS_THRESHOLD;

  return {
    // The Choice settles *which* skill; the Nouls settle *whether* to say
    // anything at all. Both must clear before a name goes into the prompt.
    suggestion:
      winnerFits >= requiredFits
        ? (narrow.answers.which.choice as string)
        : null,
    gate,
    ranked: ranked.slice(0, SHORTLIST),
    fits,
    requiredFits,
    latencyMs: {
      stage1: stage1Ms,
      stage2: stage2Ms,
      total: stage1Ms + stage2Ms,
    },
  };
}
