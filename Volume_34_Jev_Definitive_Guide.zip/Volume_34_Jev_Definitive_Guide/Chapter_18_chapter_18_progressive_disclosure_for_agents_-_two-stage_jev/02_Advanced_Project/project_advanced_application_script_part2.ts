/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// ─────────────────────────────────────────────────────────────────────────────
// app/api/copilot/route.ts
//
// One HTTP entry point for the agent harness. Hermes owns the MCP transport;
// this handler owns the sequencing.
// ─────────────────────────────────────────────────────────────────────────────
import { NextResponse } from "next/server";
import { routeTurn, type Turn } from "@/lib/skill-router";
import { hermes } from "@/lib/hermes";

export async function POST(req: Request) {
  const turn = (await req.json()) as Turn;

  // Two Jev round trips. Nothing generative has run yet.
  const decision = await routeTurn(turn);

  // A null suggestion is a real answer, not a failure. The agent keeps its full
  // index and its own judgement; the only thing we ever add is a pointer.
  if (!decision.suggestion) {
    return NextResponse.json({ decision, executed: null });
  }

  const t = performance.now();

  // MCP tools/list — pull the winner's full JSON Schema on demand. This is the
  // third and final piece of progressive disclosure: the schema, like the body
  // text, is fetched only after the skill has earned it.
  const tool = await hermes.resolveTool(decision.suggestion);

  // One more Jev call, but a different shape: the schema is the state and each
  // argument is a question. Closed sets become Choices, booleans become Nouls.
  const args = await hermes.fillArguments(turn.text, tool.schema);

  // Deterministic validation. Jev produced the values; Zod proves they conform.
  // Never skip this — the model is a judgement engine, not a type checker.
  const parsed = tool.zod.safeParse(args);
  if (!parsed.success) {
    return NextResponse.json({
      decision,
      executed: null,
      escalate: "invalid_arguments",
      issues: parsed.error.issues,
      ms: performance.now() - t,
    });
  }

  // MCP tools/call. The result is typed and goes back to the agent as tool output.
  const result = await hermes.callTool(tool.name, parsed.data);

  return NextResponse.json({
    decision,
    executed: { tool: tool.name, args: parsed.data, result },
    ms: performance.now() - t,
  });
}
