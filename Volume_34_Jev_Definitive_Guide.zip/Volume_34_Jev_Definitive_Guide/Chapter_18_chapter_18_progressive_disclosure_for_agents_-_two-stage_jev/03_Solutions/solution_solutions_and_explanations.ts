/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// skillRouter.ts
//
// WHY probabilities (not confidence) is the sort key in stage one:
// `ChoiceResponse` carries both `probabilities` (the full distribution across
// every option) and `confidence` (a scalar derived from how peaked that
// distribution is). When the option space is a 150+ skill roster, `confidence`
// is the wrong sort key: two skills A and B can hold 0.14 and 0.13 while a
// third unrelated skill holds 0.30, and B's confidence is dominated by
// everything that is *not* B. Only `probabilities[A]` and `probabilities[B]`
// carry the ordinal signal we need. `confidence` is used downstream as a gate
// (is any single option clearly the winner?), never as a rank.
//
// WHY two stages at all: stage one options are the roster's *short*
// descriptions (~60 chars). That is enough to rule out 99% of a large roster
// but not enough to separate semantically adjacent skills (e.g. "edit a
// .pptx" vs "author a .pptx"). Stage two re-asks *the same question* with
// each candidate's `description_full` plus the opening of its SKILL.md in the
// criteria — the exact move the skill_suggestion cookbook uses to flip the
// PowerPoint example. A single-stage design would suffice only if the roster
// were uniformly low-overlap and the short descriptions were already
// sufficient to disambiguate; neither holds in practice.

import {
  choice,
  noul,
  TypeSafeClient,
  type NoulCriteria,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

// ---------- frozen, exported knobs ---------------------------------------

export const GATE_THRESHOLD = 0.30;     // mean of action-oriented Nouls
export const FITS_THRESHOLD = 0.30;     // a shortlist whose best `fits` Noul is lower is dropped
export const STAGE_ONE_K = 3;           // candidates carried into stage two
export const CHOICE_CHUNK_SIZE = 255;   // hard architectural limit on Choice options
export const LOW_PROBABILITY_FLOOR = 0.02; // "top candidate is basically noise"

// ---------- domain types -------------------------------------------------

export interface Skill {
  name: string;
  category: string;
  description: string;       // ~60 chars, index-facing
  description_full: string;  // paragraph a human would read
  body: string;              // first ~700 chars of SKILL.md
  version: string;
}

export type MessageSide = "input" | "output";

export interface TurnState {
  request: string;
  recent_context: string;    // deliberate zero-length string on turn 1; see comment in `buildState`
}

export interface StageTelemetry {
  stage: string;
  ms: number;
  inputTokens: number;
  outputTokens: number;
}

export interface Candidate {
  name: string;
  probability: number;
}

export interface SuggestResult {
  skill: string | null;
}

export interface SuggestInternalResult extends SuggestResult {
  candidates: Candidate[];
  telemetry: StageTelemetry[];
  gated: number;             // the aggregate gate score, exported for the harness
}

export class StageTwoWinnerError extends Error {
  readonly name = "StageTwoWinnerError";
  constructor(stageOneWinner: string, stageTwoWinner: string) {
    super(
      `stage-two winner "${stageTwoWinner}" was not among the candidates sent ` +
        `(stage-one winner was "${stageOneWinner}"); refusing to fall back to ` +
        `stage one because that would silently ship an un-reranked answer`,
    );
  }
}

export class EmptyRosterError extends Error {
  readonly name = "EmptyRosterError";
  constructor() {
    super("skill roster is empty; nothing can be routed");
  }
}

// ---------- state builder ------------------------------------------------

/**
 * The state is an object, not a bare string, because the same shape will carry
 * `recent_context` on multi-turn agents. On turn one we ship an empty string
 * rather than omitting the field, so the request shape (and therefore the
 * cache key on our side) is identical across turns and any prompt-eval diffs
 * are attributable to content, not schema. The cost is a handful of tokens.
 */
export function buildState(request: string, recentContext = ""): TurnState {
  return { request, recent_context: recentContext };
}

// ---------- question factories ------------------------------------------

const CHOICE_INSTRUCTIONS =
  "Which of these skills, if any, is the right one to load to help with the " +
  "user's latest request?";

const GATE_QUESTIONS = {
  acts_on_user_system:
    "Is the assistant being asked to act on the user's files, accounts, " +
    "devices, or online services, rather than only to explain or advise?",
  would_follow_documented_procedure:
    "Would a careful expert answering this consult a specific documented " +
    "procedure or set of commands, rather than answering from general understanding?",
  prose_suffices:
    "Could a knowledgeable generalist fully satisfy this request in prose, " +
    "with no tools, no documentation, and no access to the user's files or accounts?",
} as const;

const INVERTED = new Set<keyof typeof GATE_QUESTIONS>(["prose_suffices"]);

const RERANK_INSTRUCTIONS =
  "Exactly one of these skills is the right one to load for the user's latest " +
  "request. Which one? Read what each actually does, not just its name.";

// ---------- timing helper ------------------------------------------------

async function timed<T>(
  stage: string,
  fn: () => Promise<{ result: T; usage: { input_tokens: number; output_tokens: number } }>,
): Promise<{ value: T; telemetry: StageTelemetry }> {
  const start = performance.now();
  const { result, usage } = await fn();
  return {
    value: result,
    telemetry: {
      stage,
      ms: performance.now() - start,
      inputTokens: usage.input_tokens,
      outputTokens: usage.output_tokens,
    },
  };
}

// ---------- stage one ----------------------------------------------------

interface StageOneOutput {
  candidates: Candidate[];
  gate: number;
  telemetry: StageTelemetry;
}

/**
 * Chunked wide ranking.
 *
 * If the roster exceeds the 255-option Choice limit, split it into overlapping-
 * free chunks and issue parallel Choice requests. We merge by summing the raw
 * probabilities per name and renormalizing across the union of options. Summing
 * (rather than averaging) is correct because each chunk's Choice is its own
 * distribution: the mass concentrated on the winner of one chunk is exactly the
 * evidence we want to keep, and the choices in other chunks are independent
 * evidence for *other* names. After merging, take the top K.
 */
export async function stageOne(
  client: TypeSafeClient,
  roster: Skill[],
  state: TurnState,
): Promise<StageOneOutput> {
  if (roster.length === 0) throw new EmptyRosterError();

  const chunks: Skill[][] = [];
  for (let i = 0; i < roster.length; i += CHOICE_CHUNK_SIZE) {
    chunks.push(roster.slice(i, i + CHOICE_CHUNK_SIZE));
  }

  const start = performance.now();
  const merged = new Map<string, number>();
  let inputTokens = 0;
  let outputTokens = 0;

  const perChunk = await Promise.all(
    chunks.map(async (chunk, idx) => {
      const questions = {
        which: choice(
          CHOICE_INSTRUCTIONS,
          Object.fromEntries(chunk.map((s) => [s.name, s.description])),
        ),
        // gate battery rides only on chunk 0; every chunk sees the same state
        ...(idx === 0
          ? Object.fromEntries(
              (Object.keys(GATE_QUESTIONS) as (keyof typeof GATE_QUESTIONS)[]).map(
                (k) => [
                  `gate::${k}`,
                  noul(GATE_QUESTIONS[k], {
                    true: "The condition is present.",
                    false: "The condition is absent.",
                  } satisfies NoulCriteria),
                ],
              ),
            )
          : {}),
      };

      const res = await client.systemOne({ state, questions });
      inputTokens += res.usage.input_tokens;
      outputTokens += res.usage.output_tokens;
      return res as SystemOneResult<typeof questions>;
    }),
  );

  // ---- merge choice probabilities across chunks
  for (const res of perChunk) {
    const which = res.answers.which;
    if (which.type !== "choice") continue; // discriminated narrowing
    for (const [name, p] of Object.entries(which.probabilities)) {
      merged.set(name, (merged.get(name) ?? 0) + p);
    }
  }
  const total = [...merged.values()].reduce((a, b) => a + b, 0) || 1;
  const sorted: Candidate[] = [...merged.entries()]
    .map(([name, p]) => ({ name, probability: p / total }))
    .sort((a, b) => b.probability - a.probability);

  // ---- gate: average of oriented nouls from chunk 0
  const gateRes = perChunk[0];
  const oriented: number[] = [];
  for (const key of Object.keys(GATE_QUESTIONS) as (keyof typeof GATE_QUESTIONS)[]) {
    const a = gateRes.answers[`gate::${key}` as keyof typeof gateRes.answers];
    if (!a || a.type !== "noul") continue;
    oriented.push(INVERTED.has(key) ? 1 - a.noul : a.noul);
  }
  const gate = oriented.length ? oriented.reduce((a, b) => a + b, 0) / oriented.length : 0;

  return {
    candidates: sorted.slice(0, STAGE_ONE_K),
    gate,
    telemetry: {
      stage: "stage1.rank",
      ms: performance.now() - start,
      inputTokens,
      outputTokens,
    },
  };
}

// ---------- stage two ----------------------------------------------------

interface StageTwoOutput {
  winner: string;
  fits: Record<string, number>;
  telemetry: StageTelemetry;
}

export async function stageTwo(
  client: TypeSafeClient,
  roster: Skill[],
  state: TurnState,
  candidates: Candidate[],
): Promise<StageTwoOutput> {
  const byName = new Map(roster.map((s) => [s.name, s]));
  const chosen = candidates.map((c) => byName.get(c.name)!).filter(Boolean);

  const criteria = Object.fromEntries(
    chosen.map((s) => [
      s.name,
      `${s.description_full} — ${s.body.slice(0, 700)}`,
    ]),
  );

  const questions: Record<string, ReturnType<typeof choice> | ReturnType<typeof noul>> = {
    which: choice(RERANK_INSTRUCTIONS, criteria),
  };
  for (const s of chosen) {
    questions[`fits::${s.name}`] = noul(
      `Does the skill '${s.name}' do the specific thing the user's request asks ` +
        `for? It is described as: ${s.description_full}`,
    );
  }

  const start = performance.now();
  const res = await client.systemOne({ state, questions });
  const ms = performance.now() - start;

  const which = res.answers.which;
  if (which.type !== "choice") {
    throw new Error("stage two returned a non-choice answer for `which`");
  }
  const winner = which.choice;

  const fits: Record<string, number> = {};
  for (const s of chosen) {
    const a = res.answers[`fits::${s.name}`];
    if (a && a.type === "noul") fits[s.name] = a.noul;
  }

  return {
    winner,
    fits,
    telemetry: {
      stage: "stage2.rerank",
      ms,
      inputTokens: res.usage.input_tokens,
      outputTokens: res.usage.output_tokens,
    },
  };
}

// ---------- coordinator --------------------------------------------------

export async function suggestInternal(
  client: TypeSafeClient,
  roster: Skill[],
  request: string,
): Promise<SuggestInternalResult> {
  const state = buildState(request);
  const telemetry: StageTelemetry[] = [];

  const one = await stageOne(client, roster, state);
  telemetry.push(one.telemetry);

  if (one.gate < GATE_THRESHOLD) {
    return { skill: null, candidates: one.candidates, telemetry, gated: one.gate };
  }
  const top = one.candidates[0];
  if (!top || top.probability < LOW_PROBABILITY_FLOOR) {
    return { skill: null, candidates: one.candidates, telemetry, gated: one.gate };
  }

  const two = await stageTwo(client, roster, state, one.candidates);
  telemetry.push(two.telemetry);

  // Invariant: the choice in stage two can only be a label we sent.
  const sent = new Set(one.candidates.map((c) => c.name));
  if (!sent.has(two.winner)) {
    throw new StageTwoWinnerError(top.name, two.winner);
  }

  const best = Math.max(0, ...Object.values(two.fits));
  if (best < FITS_THRESHOLD) {
    return { skill: null, candidates: one.candidates, telemetry, gated: one.gate };
  }

  return { skill: two.winner, candidates: one.candidates, telemetry, gated: one.gate };
}

export async function suggest(
  client: TypeSafeClient,
  roster: Skill[],
  request: string,
): Promise<SuggestResult> {
  const r = await suggestInternal(client, roster, request);
  return { skill: r.skill };
}
