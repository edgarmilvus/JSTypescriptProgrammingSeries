/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// guard.test.ts
import { describe, it, expect, vi } from "vitest";
import { guard, route } from "./guard";
import { POLICIES } from "./policies";

type Case = {
  name: string;
  inputs: { hazards: Record<string, number>; severity: number };
  expected: { strict: string; permissive: string };
};

const CASES: Case[] = [
  { name: "clean composition help",
    inputs: { hazards: { jailbreak: 0.02, harmful_request: 0.01, medical_advice: 0.02, self_harm: 0.01 }, severity: 0.0 },
    expected: { strict: "pass", permissive: "pass" } },
  { name: "mild dosage question",
    inputs: { hazards: { jailbreak: 0.05, harmful_request: 0.02, medical_advice: 0.55, self_harm: 0.02 }, severity: 0.3 },
    expected: { strict: "review", permissive: "review" } },
  { name: "explicit lockpick request",
    inputs: { hazards: { jailbreak: 0.10, harmful_request: 0.95, medical_advice: 0.02, self_harm: 0.02 }, severity: 2.4 },
    expected: { strict: "block", permissive: "block" } },
  { name: "self-harm disclosure",
    inputs: { hazards: { jailbreak: 0.03, harmful_request: 0.01, medical_advice: 0.10, self_harm: 0.96 }, severity: 2.4 },
    expected: { strict: "support", permissive: "support" } },
  { name: "ambiguous DAN-style jailbreak",
    inputs: { hazards: { jailbreak: 0.74, harmful_request: 0.05, medical_advice: 0.02, self_harm: 0.04 }, severity: 0.51 },
    expected: { strict: "block", permissive: "review" } },
];

describe("route()", () => {
  it("is deterministic under conflicting triggers (support beats block)", () => {
    const action = route({ jailbreak: 0.9, self_harm: 0.9 }, 2.5, POLICIES.strict);
    expect(action).toBe("support");
  });

  for (const c of CASES) {
    it(`${c.name}: policy is the only difference`, () => {
      const strict = route(c.inputs.hazards, c.inputs.severity, POLICIES.strict);
      const perm = route(c.inputs.hazards, c.inputs.severity, POLICIES.permissive);
      expect({ strict, perm }).toEqual({ strict: c.expected.strict, perm: c.expected.permissive });
    });
  }
});

describe("guard()", () => {
  const silent = { info: () => {} };

  it("fails closed on transport error", async () => {
    const client = { systemOne: vi.fn(async () => { throw new Error("boom"); }) } as unknown as import("@typesafe-ai/sdk").TypeSafeClient;
    const r = await guard({ client, logger: silent }, "hi", "input");
    expect(r.action).toBe("degraded");
    expect(r.degradedReason).toBe("transport");
  });

  it("fails closed when a hazard answer has the wrong discriminant", async () => {
    const client = {
      systemOne: vi.fn(async () => ({
        model: "jev-latest",
        usage: { input_tokens: 1, output_tokens: 1 },
        answers: {
          // type-cast fixture: forcing a choice answer into a noul slot; confined to the test.
          "hazard::jailbreak": { type: "choice" as unknown as "noul", noul: 0.2 },
          "hazard::harmful_request": { type: "noul", noul: 0.1 },
          "hazard::medical_advice": { type: "noul", noul: 0.1 },
          "hazard::self_harm": { type: "noul", noul: 0.1 },
          "severity": { type: "score", score: 0.5, legend: {}, probabilities: {}, confidence: 0.9 },
        },
      })),
    } as unknown as import("@typesafe-ai/sdk").TypeSafeClient;
    const r = await guard({ client, logger: silent }, "hi", "input");
    expect(r.action).toBe("degraded");
  });
});
