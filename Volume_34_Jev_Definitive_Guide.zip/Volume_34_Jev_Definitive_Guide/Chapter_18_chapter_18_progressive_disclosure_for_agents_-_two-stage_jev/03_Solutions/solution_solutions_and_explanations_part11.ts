/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

// turnTrace.ts
export interface StageRecord {
  stage: string;               // "guard" | "stage1.rank" | "stage2.rerank" | "skill.execute.validate" | ...
  ms: number;
  inputTokens: number;
  outputTokens: number;
  failed?: true;
}

export interface TurnTrace {
  request: string;
  side: "input" | "output";
  guard: {
    action: "pass" | "review" | "block" | "support" | "degraded";
    hazards: Record<string, number>;
    severity: number;
    policy: string;
  };
  router: {
    gated: number;
    topCandidates: { name: string; probability: number }[];
    picked: string | null;
  };
  tool: {
    disposition: "auto" | "confirm" | "reject" | "error" | "skipped";
    floorsViolated: string[];
  };
  stages: StageRecord[];       // ordered; sums to ~totalLatencyMs
  totalLatencyMs: number;
  overBudget: boolean;
  degraded: boolean;
}

export const BUDGET_MS = 350;

export function emptyTrace(request: string, side: "input" | "output"): TurnTrace {
  return {
    request,
    side,
    guard: { action: "degraded", hazards: {}, severity: 0, policy: "strict" },
    router: { gated: 0, topCandidates: [], picked: null },
    tool: { disposition: "skipped", floorsViolated: [] },
    stages: [],
    totalLatencyMs: 0,
    overBudget: false,
    degraded: false,
  };
}
