/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

// harness.ts
import { TypeSafeClient } from "@typesafe-ai/sdk";
import { createInterface } from "node:readline";
import { suggestInternal, type Skill } from "./skillRouter";
import { guard, type MessageSide } from "./guard";
import { buildServer, type SkillRecord, type Logger } from "./mcpServer";
import { BUDGET_MS, emptyTrace, type StageRecord, type TurnTrace } from "./turnTrace";
import { POLICIES, type PolicyName } from "./policies";

// ---- composition root: the ONLY module that constructs TypeSafeClient -----

export interface TurnDeps {
  client: TypeSafeClient;
  roster: Skill[];
  logger: Logger;
  policy: PolicyName;
  faultInjector?: { everyNthCall: number; kind: "rate-limit" | "malformed" };
}

async function inside<T>(
  trace: TurnTrace,
  stage: string,
  run: () => Promise<T>,
): Promise<{ value: T | undefined; failed: boolean }> {
  const start = performance.now();
  try {
    const value = await run();
    trace.stages.push({ stage, ms: performance.now() - start, inputTokens: 0, outputTokens: 0 });
    return { value, failed: false };
  } catch {
    trace.stages.push({ stage, ms: performance.now() - start, inputTokens: 0, outputTokens: 0, failed: true });
    return { value: undefined, failed: true };
  }
}

export async function runTurn(deps: TurnDeps, request: string, side: MessageSide): Promise<TurnTrace> {
  const trace = emptyTrace(request, side);
  const outerStart = performance.now();

  // ---- (1) guard --------------------------------------------------------
  const gStart = performance.now();
  const g = await guard({ client: deps.client, logger: deps.logger }, request, side, deps.policy);
  trace.stages.push({ stage: "guard", ms: performance.now() - gStart, inputTokens: 0, outputTokens: 0 });
  trace.guard = { action: g.action, hazards: g.hazards, severity: g.severity, policy: g.policy };

  if (g.action === "degraded") {
    trace.degraded = true;
    trace.totalLatencyMs = performance.now() - outerStart;
    trace.overBudget = trace.totalLatencyMs > BUDGET_MS;
    return trace;
  }

  // ---- (2) router -------------------------------------------------------
  if (g.action === "pass" || g.action === "review") {
    const rStart = performance.now();
    const r = await inside(trace, "stage1.rank+stage2.rerank", async () => {
      return suggestInternal(deps.client, deps.roster, request);
    });
    if (r.failed || !r.value) {
      trace.degraded = true;
      trace.totalLatencyMs = performance.now() - outerStart;
      trace.overBudget = trace.totalLatencyMs > BUDGET_MS;
      return trace;
    }
    trace.router = {
      gated: r.value.gated,
      topCandidates: r.value.candidates,
      picked: r.value.skill,
    };
    trace.stages.push(...r.value.telemetry as StageRecord[]);
    trace.stages[trace.stages.length - r.value.telemetry.length - 1].stage = "router";
    // (Housekeeping: the above re-labels the aggregate router stage; leaving
    // the per-call telemetry pushed after it preserves execution order.)
  }

  // ---- (3) tool execute (only on pass + a picked skill) ------------------
  if (g.action === "pass" && trace.router.picked) {
    const { server } = buildServer({ client: deps.client, roster: deps.roster as SkillRecord[], logger: deps.logger });
    void server; // A full harness would drive the tool over its transport;
                 // the shape below is a direct call for readability.
    const tStart = performance.now();
    try {
      const { validateArguments } = await import("./skillValidation");
      const skill = deps.roster.find((s) => s.name === trace.router.picked)!;
      const outcome = await validateArguments(deps.client, {
        request, skill, arguments: {},
      });
      trace.tool = { disposition: outcome.disposition, floorsViolated: outcome.floorsViolated };
    } catch {
      trace.tool = { disposition: "error", floorsViolated: [] };
      trace.degraded = true;
    }
    trace.stages.push({ stage: "skill.execute.validate", ms: performance.now() - tStart, inputTokens: 0, outputTokens: 0 });
  }

  trace.totalLatencyMs = performance.now() - outerStart;
  trace.overBudget = trace.totalLatencyMs > BUDGET_MS;
  return trace;
}

// ---- REPL ---------------------------------------------------------------

function fmtTrace(t: TurnTrace): string {
  const guardLine = `guard[${t.guard.action}] sev=${t.guard.severity.toFixed(2)}`;
  const topHazard = Object.entries(t.guard.hazards).sort((a, b) => b[1] - a[1])[0];
  const hazardLine = topHazard ? `top=${topHazard[0]}:${topHazard[1].toFixed(2)}` : "top=-";
  const routerLine = t.router.picked
    ? `router[${t.router.picked}] p=${t.router.topCandidates[0]?.probability.toFixed(2) ?? "-"}`
    : `router[-]`;
  const toolLine = `tool[${t.tool.disposition}]${t.tool.floorsViolated.length ? " " + t.tool.floorsViolated.join(",") : ""}`;
  const stageLine = t.stages.map((s) => `${s.stage}:${Math.round(s.ms)}ms`).join(" | ");
  return [
    guardLine, hazardLine, routerLine, toolLine,
    `total=${Math.round(t.totalLatencyMs)}ms${t.overBudget ? " OVER" : ""}`,
    stageLine,
  ].join("  ");
}

function fmtVerbose(t: TurnTrace): string {
  const lines = [fmtTrace(t)];
  lines.push("  stage-one candidates:");
  for (const c of t.router.topCandidates) {
    lines.push(`    ${c.name.padEnd(28)} ${c.probability.toFixed(4)}`);
  }
  lines.push("  guard distribution:");
  for (const [h, p] of Object.entries(t.guard.hazards)) {
    lines.push(`    ${h.padEnd(18)} ${p.toFixed(4)}`);
  }
  return lines.join("\n");
}

function diffTraces(a: TurnTrace, b: TurnTrace): string {
  const stageNames = new Set([...a.stages.map((s) => s.stage), ...b.stages.map((s) => s.stage)]);
  const rows: string[] = ["stage                       A_ms  B_ms   Δ_ms"];
  for (const name of stageNames) {
    const am = a.stages.find((s) => s.stage === name)?.ms ?? 0;
    const bm = b.stages.find((s) => s.stage === name)?.ms ?? 0;
    rows.push(`${name.padEnd(28)}${am.toFixed(0).padStart(5)} ${bm.toFixed(0).padStart(5)} ${(bm - am).toFixed(0).padStart(6)}`);
  }
  rows.push("");
  rows.push(`router pick:  A=${a.router.picked ?? "-"}  B=${b.router.picked ?? "-"}`);
  const a0 = a.router.topCandidates[0]?.probability ?? 0;
  const b0 = b.router.topCandidates[0]?.probability ?? 0;
  rows.push(`router top p: A=${a0.toFixed(3)}  B=${b0.toFixed(3)}  Δ=${(b0 - a0).toFixed(3)}`);
  return rows.join("\n");
}

// ---- fixture client for offline development ----------------------------

export function fixtureClient(fixtures: unknown[], injector = { everyNthCall: 0, kind: "malformed" as const }): TypeSafeClient {
  let n = 0;
  return {
    systemOne: async (req: unknown) => {
      n += 1;
      if (injector.everyNthCall > 0 && n % injector.everyNthCall === 0) {
        if (injector.kind === "rate-limit") {
          const e = Object.assign(new Error("429"), { status: 429 });
          throw e;
        }
        return { model: "x", usage: { input_tokens: 0, output_tokens: 0 }, answers: { broken: { type: "choice" } } };
      }
      const r = fixtures.shift();
      if (!r) throw new Error("fixture exhausted");
      void req;
      return r as never;
    },
  } as unknown as TypeSafeClient;
}

// ---- CLI entry ----------------------------------------------------------

export async function main(argv: string[]) {
  const live = process.env.TYPESAFE_LIVE === "1";
  const fixtures: unknown[] = []; // loaded from fixture file in real code
  const deps: TurnDeps = {
    client: live ? new TypeSafeClient({ apiKey: process.env.TYPESAFE_API_KEY }) : fixtureClient(fixtures),
    roster: [], // loaded from fixture file in real code
    logger: { info: (o) => process.stderr.write(JSON.stringify(o) + "\n") } as unknown as Logger,
    policy: "strict",
  };

  if (argv.includes("--run")) {
    const turns = ["author a pitch deck", "explain what a monad is"]; // fixture set of 20 in real code
    let overBudget = 0, degraded = 0;
    const totMs: number[] = [];
    for (const t of turns) {
      const tr = await runTurn(deps, t, "input");
      if (tr.overBudget) overBudget += 1;
      if (tr.degraded) degraded += 1;
      totMs.push(tr.totalLatencyMs);
      process.stdout.write(fmtTrace(tr) + "\n");
    }
    totMs.sort((a, b) => a - b);
    const p50 = totMs[Math.floor(totMs.length * 0.5)] ?? 0;
    const p95 = totMs[Math.min(totMs.length - 1, Math.floor(totMs.length * 0.95))] ?? 0;
    process.stdout.write(`summary: n=${totMs.length} overBudget=${overBudget} degraded=${degraded} p50=${p50.toFixed(0)}ms p95=${p95.toFixed(0)}ms\n`);
    process.exit(degraded > 0 && !live ? 1 : 0);
  }

  const rl = createInterface({ input: process.stdin, output: process.stdout });
  let verbose = false;
  let lastTrace: TurnTrace | null = null;
  rl.on("line", async (line) => {
    const line_ = line.trim();
    if (line_ === "/verbose") { verbose = !verbose; process.stdout.write(`verbose=${verbose}\n`); return; }
    if (line_.startsWith("/diff ")) {
      const [, a, b] = line_.split(" ", 3);
      const ta = await runTurn(deps, a, "input");
      const tb = await runTurn(deps, b, "input");
      process.stdout.write(diffTraces(ta, tb) + "\n");
      return;
    }
    const t = await runTurn(deps, line_, "input");
    lastTrace = t;
    process.stdout.write((verbose ? fmtVerbose : fmtTrace)(t) + "\n");
    void lastTrace;
  });
}

// Guard the entry point so importing the module in tests does not start a REPL.
if (require.main === module) {
  // eslint-disable-next-line @typescript-eslint/no-floating-promises
  main(process.argv.slice(2));
}
