/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// harness.test.ts — the invariant the exercise cares about most.
import { describe, it, expect } from "vitest";
import { runTurn, fixtureClient, type TurnDeps } from "./harness";
import type { Logger } from "./mcpServer";

const silent: Logger = { info() {}, warn() {}, error() {} };

describe("TurnTrace invariants", () => {
  it("stage ms values sum to within tolerance of totalLatencyMs", async () => {
    const deps: TurnDeps = {
      client: fixtureClient([/* hand-authored guard + stage1 + stage2 payloads */]),
      roster: [],
      logger: silent,
      policy: "strict",
    };
    const t = await runTurn(deps, "author a pitch deck", "input");
    const sum = t.stages.reduce((a, s) => a + s.ms, 0);
    // The tolerance budget covers the small gaps between stages (scheduling
    // and JSON serialization) that the outer boundary includes but no stage
    // times.
    expect(Math.abs(sum - t.totalLatencyMs)).toBeLessThan(50);
  });
});
