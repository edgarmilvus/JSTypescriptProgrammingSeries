/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// skillRouter.test.ts
import { describe, it, expect, vi } from "vitest";
import {
  stageOne, stageTwo, suggestInternal,
  GATE_THRESHOLD, FITS_THRESHOLD,
  EmptyRosterError, StageTwoWinnerError,
  type Skill,
} from "./skillRouter";

const roster: Skill[] = [
  { name: "pptx-author", category: "office",
    description: "Build PowerPoint decks headless with python-pptx.",
    description_full: "Author .pptx files programmatically.",
    body: "from pptx import Presentation ...", version: "1" },
  { name: "powerpoint", category: "office",
    description: "Create, read, edit .pptx decks, slides, notes.",
    description_full: "Edit existing .pptx decks.",
    body: "## Editing an existing deck ...", version: "1" },
  { name: "concept-diagrams", category: "visual",
    description: "Generate flat, minimal educational SVG visuals.",
    description_full: "Diagram generation.",
    body: "<svg>...</svg>", version: "1" },
];

function stubClient(responses: unknown[]) {
  const calls: unknown[] = [];
  return {
    calls,
    systemOne: vi.fn(async (req: unknown) => {
      calls.push(req);
      const r = responses.shift();
      if (!r) throw new Error("stub exhausted");
      return r;
    }),
  } as unknown as import("@typesafe-ai/sdk").TypeSafeClient & { calls: unknown[] };
}

describe("stageOne", () => {
  it("raises EmptyRosterError on empty input", async () => {
    const c = stubClient([]);
    await expect(stageOne(c, [], { request: "hi", recent_context: "" }))
      .rejects.toBeInstanceOf(EmptyRosterError);
  });
});

describe("suggestInternal", () => {
  it("returns null when the gate says nothing fits", async () => {
    const c = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 100, output_tokens: 10 },
        answers: {
          which: { type: "choice", choice: "pptx-author", confidence: 0.9,
            probabilities: { "pptx-author": 0.5, powerpoint: 0.3, "concept-diagrams": 0.2 } },
          "gate::acts_on_user_system": { type: "noul", noul: 0.1 },
          "gate::would_follow_documented_procedure": { type: "noul", noul: 0.2 },
          "gate::prose_suffices": { type: "noul", noul: 0.8 },
        },
      },
    ]);
    const r = await suggestInternal(c, roster, "explain what a monad is");
    expect(r.skill).toBeNull();
    expect(c.calls.length).toBe(1); // coordinator never made a stage-two call
  });

  it("breaks a stage-one tie deterministically and carries the winner into stage two", async () => {
    const c = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 100, output_tokens: 10 },
        answers: {
          which: { type: "choice", choice: "pptx-author", confidence: 0.3,
            probabilities: { "pptx-author": 0.5, powerpoint: 0.5, "concept-diagrams": 0.0 } },
          "gate::acts_on_user_system": { type: "noul", noul: 0.9 },
          "gate::would_follow_documented_procedure": { type: "noul", noul: 0.9 },
          "gate::prose_suffices": { type: "noul", noul: 0.1 },
        },
      },
      {
        model: "jev-latest",
        usage: { input_tokens: 900, output_tokens: 20 },
        answers: {
          which: { type: "choice", choice: "pptx-author", confidence: 0.7,
            probabilities: { "pptx-author": 0.7, powerpoint: 0.3 } },
          "fits::pptx-author": { type: "noul", noul: 0.73 },
          "fits::powerpoint": { type: "noul", noul: 0.38 },
        },
      },
    ]);
    const r = await suggestInternal(c, roster, "author a pitch deck");
    expect(r.skill).toBe("pptx-author");
    expect(c.calls.length).toBe(2);
  });

  it("throws StageTwoWinnerError if stage two returns a name outside the shortlist", async () => {
    const c = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 100, output_tokens: 10 },
        answers: {
          which: { type: "choice", choice: "pptx-author", confidence: 0.9,
            probabilities: { "pptx-author": 0.6, powerpoint: 0.3, "concept-diagrams": 0.1 } },
          "gate::acts_on_user_system": { type: "noul", noul: 0.9 },
          "gate::would_follow_documented_procedure": { type: "noul", noul: 0.9 },
          "gate::prose_suffices": { type: "noul", noul: 0.1 },
        },
      },
      {
        model: "jev-latest",
        usage: { input_tokens: 900, output_tokens: 20 },
        answers: {
          // Hand-authored mis-behaviour: a name that was never offered.
          which: { type: "choice", choice: "concept-diagrams", confidence: 0.9,
            probabilities: { "concept-diagrams": 0.9, "pptx-author": 0.1 } },
          "fits::pptx-author": { type: "noul", noul: 0.7 },
          "fits::powerpoint": { type: "noul", noul: 0.3 },
        },
      },
    ]);
    await expect(suggestInternal(c, roster, "author a pitch deck"))
      .rejects.toBeInstanceOf(StageTwoWinnerError);
  });
});
