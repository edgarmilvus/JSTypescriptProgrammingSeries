/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SkillSuggestionBanner.tsx
//
// Focus contract:
//   - Mount: focus is preserved. The banner is a passive status region; it
//     never calls .focus() on mount, even when transitioning to `error`.
//   - Update to `ready` / `no-fit`: focus preserved. Live-region announcements
//     are handled by role="status".
//   - Update to `error`: focus preserved. The `Try again` button is reachable
//     by tab order; we do not steal focus to it, because the operator may be
//     mid-keystroke in the input box.
//   - Dismiss: focus moves to the previously-focused element (handled by the
//     caller's focus manager, which owns the input box).
//   - Two-step accept: first click arms; second click commits. Focus stays on
//     the accept control between the two clicks — no movement anywhere.
//
// Why two-step accept at low confidence:
//   The router's confidence number is not calibrated per skill family; it is
//   calibrated in aggregate over the training distribution. A 0.42 on a rare
//   skill family may be a coin flip while a 0.42 on a common family may be
//   quite reliable. We therefore treat the number as a *negotiation* signal
//   rather than a *truth* signal: high confidence is a one-click accept, low
//   confidence is a two-step confirm, medium confidence is a single click
//   with a visual caution treatment. The state machine enforces the second
//   click; the number only chooses which state we are in.

import * as React from "react";
import type { ChoiceResponse, SystemOneResult } from "@typesafe-ai/sdk";

// ---------- exported constants -------------------------------------------

export const CONFIDENCE_HIGH = 0.75;
export const CONFIDENCE_LOW = 0.45;

// ---------- wire types ---------------------------------------------------

export interface TopCandidate {
  name: string;
  probability: number;
}

export type Suggestion =
  | { kind: "idle" }
  | { kind: "pending" }
  | {
      kind: "ready";
      skill: string;
      confidence: number;
      topCandidates: TopCandidate[];
      latencyMs: number;
    }
  | { kind: "no-fit"; latencyMs: number }
  | { kind: "error"; message: string };

export interface SkillSuggestionBannerProps {
  suggestion: Suggestion;
  onAccept: (skillName: string) => void;
  onDismiss: () => void;
  onOpenDetail: (skillName: string) => void;
  onRetry: () => void;
}

// ---------- SDK -> wire mapping ------------------------------------------

/**
 * Map a `ChoiceResponse` from stage two into a `Suggestion.ready`.
 *
 * Invariant tolerance: real backends always return a non-empty `probabilities`
 * alongside `choice` and `confidence`, but the wire format treats an empty
 * map as legal so we do not crash on a partially up-migrated deployment. When
 * `probabilities` is empty we synthesize a single-entry map from `choice`
 * with probability 1; the confidence value is preserved as reported.
 */
export function mapChoiceToReady(
  which: ChoiceResponse<Record<string, unknown>>,
  latencyMs: number,
): Extract<Suggestion, { kind: "ready" }> {
  const entries = Object.entries(which.probabilities ?? {});
  const topCandidates: TopCandidate[] =
    entries.length > 0
      ? entries
          .map(([name, probability]) => ({ name, probability }))
          .sort((a, b) => b.probability - a.probability)
          .slice(0, 3)
      : [{ name: which.choice, probability: 1 }];
  return {
    kind: "ready",
    skill: which.choice,
    confidence: which.confidence,
    topCandidates,
    latencyMs,
  };
}

export type StageTwoWire = SystemOneResult<
  Record<string, { type: "choice" } & Record<string, unknown>>
>;

// ---------- component ----------------------------------------------------

type BannerState = { armed: false } | { armed: true; skill: string };

export function SkillSuggestionBanner(
  props: SkillSuggestionBannerProps,
): React.ReactElement {
  const { suggestion, onAccept, onDismiss, onOpenDetail, onRetry } = props;

  // Local optimistic state, reconciled against the authoritative prop.
  const [banner, setBanner] = React.useState<BannerState>({ armed: false });

  // Reconciliation: whenever the authoritative suggestion changes identity,
  // we discard local optimistic state. This is what prevents the
  // "ready(A) -> ready(B) while accept(A) was in flight" bug: the accept(A)
  // request still lands on the server, but the banner repaints as B and does
  // NOT fire onAccept(B) as a side effect of repainting.
  const readySkill =
    suggestion.kind === "ready" ? suggestion.skill : null;
  React.useEffect(() => {
    setBanner({ armed: false });
  }, [readySkill]);

  const isLive = suggestion.kind === "ready" || suggestion.kind === "no-fit";
  const isAlert = suggestion.kind === "error";

  const content = (() => {
    switch (suggestion.kind) {
      case "idle":
        return null;
      case "pending":
        return (
          <div className="banner-row" aria-hidden="true">
            <span className="banner-skeleton banner-skeleton--wide" />
            <span className="banner-skeleton banner-skeleton--narrow" />
          </div>
        );
      case "no-fit":
        return (
          <div className="banner-row">
            <span className="banner-copy">
              No skill in the roster fits this turn.
            </span>
            <button onClick={onDismiss} type="button">
              Dismiss
            </button>
          </div>
        );
      case "error":
        return (
          <div className="banner-row">
            <span className="banner-copy">
              Couldn't load a suggestion.
            </span>
            <button onClick={onRetry} type="button">
              Try again
            </button>
            {/* Visually hidden; readable by support tooling. */}
            <span id="banner-error-msg" className="sr-only">
              {suggestion.message}
            </span>
          </div>
        );
      case "ready": {
        const { skill, confidence, topCandidates, latencyMs } = suggestion;
        const runnerUp = topCandidates[1]?.probability ?? 0;
        const tier =
          confidence >= CONFIDENCE_HIGH
            ? "high"
            : confidence < CONFIDENCE_LOW
              ? "low"
              : "medium";
        const isArmed = banner.armed && banner.skill === skill;

        const handleAccept = () => {
          if (tier === "low" && !isArmed) {
            setBanner({ armed: true, skill });
            return;
          }
          onAccept(skill);
        };

        return (
          <div className="banner-row" data-tier={tier}>
            <span className="banner-skill">{skill}</span>
            <span className="banner-conf" aria-label={`confidence ${confidence.toFixed(2)}`}>
              {confidence.toFixed(2)}
            </span>
            <span className="banner-rivalry" aria-label="runner-up probability">
              runner-up {runnerUp.toFixed(2)}
            </span>
            <span className="banner-latency">{latencyMs}ms</span>
            {tier === "low" && (
              <span className="banner-caveat">
                Confirm this is the right skill before continuing.
              </span>
            )}
            <button onClick={handleAccept} type="button">
              {tier === "low" && !isArmed ? "Choose" : "Accept"}
            </button>
            <button onClick={() => onOpenDetail(skill)} type="button">
              Details
            </button>
            <button onClick={onDismiss} type="button">
              Dismiss
            </button>
          </div>
        );
      }
    }
  })();

  return (
    <div
      role={isAlert ? "alert" : isLive ? "status" : undefined}
      aria-describedby={suggestion.kind === "error" ? "banner-error-msg" : undefined}
      className={`banner banner--${suggestion.kind}`}
    >
      {content}
    </div>
  );
}
