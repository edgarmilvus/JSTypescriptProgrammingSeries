/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// SkillSuggestionBanner.test.tsx
import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, act } from "@testing-library/react";
import {
  SkillSuggestionBanner,
  type Suggestion,
  CONFIDENCE_HIGH,
  CONFIDENCE_LOW,
  mapChoiceToReady,
} from "./SkillSuggestionBanner";

const base = {
  onAccept: vi.fn(),
  onDismiss: vi.fn(),
  onOpenDetail: vi.fn(),
  onRetry: vi.fn(),
};

function show(suggestion: Suggestion) {
  return render(<SkillSuggestionBanner suggestion={suggestion} {...base} />);
}

describe("SkillSuggestionBanner", () => {
  it("renders idle as nothing", () => {
    const { container } = show({ kind: "idle" });
    expect(container.textContent).toBe("");
  });

  it("renders a fixed-height skeleton in pending", () => {
    const { container } = show({ kind: "pending" });
    expect(container.querySelectorAll(".banner-skeleton").length).toBeGreaterThan(0);
  });

  it("does not shift layout beyond the epsilon on pending -> ready", () => {
    const { container, rerender } = show({ kind: "pending" });
    const before = container.firstElementChild!.getBoundingClientRect().height;
    rerender(
      <SkillSuggestionBanner
        suggestion={{
          kind: "ready",
          skill: "pptx-author",
          confidence: 0.9,
          topCandidates: [{ name: "pptx-author", probability: 0.9 }],
          latencyMs: 120,
        }}
        {...base}
      />,
    );
    const after = container.firstElementChild!.getBoundingClientRect().height;
    expect(Math.abs(after - before)).toBeLessThan(4);
  });

  it("fires onAccept after one click at high confidence", () => {
    base.onAccept.mockReset();
    show({
      kind: "ready",
      skill: "pptx-author",
      confidence: CONFIDENCE_HIGH + 0.05,
      topCandidates: [{ name: "pptx-author", probability: 0.9 }],
      latencyMs: 100,
    });
    fireEvent.click(screen.getByRole("button", { name: /accept/i }));
    expect(base.onAccept).toHaveBeenCalledTimes(1);
    expect(base.onAccept).toHaveBeenCalledWith("pptx-author");
  });

  it("requires a second click at low confidence", () => {
    base.onAccept.mockReset();
    show({
      kind: "ready",
      skill: "pptx-author",
      confidence: CONFIDENCE_LOW - 0.05,
      topCandidates: [{ name: "pptx-author", probability: 0.4 }],
      latencyMs: 140,
    });
    fireEvent.click(screen.getByRole("button", { name: /choose/i }));
    expect(base.onAccept).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: /accept/i }));
    expect(base.onAccept).toHaveBeenCalledTimes(1);
  });

  it("reconciles: prop change from A to B repaints B and does not fire accept(B)", () => {
    base.onAccept.mockReset();
    const { rerender } = show({
      kind: "ready",
      skill: "A",
      confidence: CONFIDENCE_LOW - 0.05,
      topCandidates: [{ name: "A", probability: 0.4 }],
      latencyMs: 100,
    });
    fireEvent.click(screen.getByRole("button", { name: /choose/i })); // arm A
    rerender(
      <SkillSuggestionBanner
        suggestion={{
          kind: "ready",
          skill: "B",
          confidence: CONFIDENCE_HIGH + 0.05,
          topCandidates: [{ name: "B", probability: 0.9 }],
          latencyMs: 100,
        }}
        {...base}
      />,
    );
    expect(screen.getByText("B")).toBeTruthy();
    // B is high-confidence, but the reconciliation must not auto-accept.
    fireEvent.click(screen.getByRole("button", { name: /accept/i }));
    expect(base.onAccept).toHaveBeenCalledWith("B");
  });

  it("error state renders Try again and never the raw message visibly", () => {
    base.onRetry.mockReset();
    show({ kind: "error", message: "secret internal S3 key" });
    const btn = screen.getByRole("button", { name: /try again/i });
    fireEvent.click(btn);
    expect(base.onRetry).toHaveBeenCalledTimes(1);
    // The raw message is in a visually hidden node, not the visible copy.
    expect(screen.getByText("secret internal S3 key")).toHaveClass("sr-only");
  });

  it("never calls fetch / systemOne", () => {
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    show({
      kind: "ready",
      skill: "pptx-author",
      confidence: 0.9,
      topCandidates: [{ name: "pptx-author", probability: 0.9 }],
      latencyMs: 100,
    });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("maps an SDK ChoiceResponse into the banner shape, tolerating empty probabilities", () => {
    const ready = mapChoiceToReady(
      {
        type: "choice",
        choice: "pptx-author",
        confidence: 0.73,
        probabilities: {},
      },
      111,
    );
    expect(ready.topCandidates).toEqual([{ name: "pptx-author", probability: 1 }]);
    expect(ready.confidence).toBe(0.73);
  });
});
