/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// skillValidation.ts
import { choice, noul, type TypeSafeClient, type NoulCriteria } from "@typesafe-ai/sdk";
import type { Skill, SkillParameter } from "./rosterTypes";

export const NOUL_FLOOR = 0.55;         // below this a parameter is "inconsistent"
export const NOUL_CONFIRM_FLOOR = 0.85; // below this, but above NOUL_FLOOR, needs confirmation

/**
 * The ONLY function permitted to build these key strings. All other code
 * consumes `response.answers` through the `ParamKey`/`AggregateKey` types
 * below, which are derived from the constant prefixes — so a typo in a call
 * site is a compile error, not a runtime `undefined`.
 */
const PARAM_PREFIX = "param::" as const;
const AGGREGATE_KEY = "disposition::overall" as const;

export type ParamKey<N extends string> = `${typeof PARAM_PREFIX}${N}`;
export type AggregateKey = typeof AGGREGATE_KEY;

export interface ValidationOutcome {
  disposition: "auto" | "confirm" | "reject";
  floorsViolated: string[];
  needsConfirm: string[];
  rawParams: Record<string, number>;
}

export interface ValidationRequest {
  request: string;
  skill: Skill;
  arguments: Record<string, unknown>;
}

export interface ValidationResponse {
  answers: Record<string, { type: "noul"; noul: number } | { type: "choice"; choice: string; probabilities: Record<string, number>; confidence: number }>;
  usage: { input_tokens: number; output_tokens: number };
}

export function buildValidationQuestions(skill: Skill, args: Record<string, unknown>) {
  const params = skill.parameters ?? [];
  const questions: Record<string, ReturnType<typeof noul> | ReturnType<typeof choice>> = {};

  for (const p of params) {
    const value = args[p.name];
    questions[`${PARAM_PREFIX}${p.name}`] = noul(
      `Is the extracted argument value for '${p.name}' consistent with what this ` +
        `parameter means and matches what the user's request asks for? Parameter ` +
        `means: ${p.description}. Extracted value: ${JSON.stringify(value)}.`,
      {
        true: "The value matches the parameter's meaning and the request.",
        false: "The value conflicts with the parameter or the request.",
      } satisfies NoulCriteria,
    );
  }

  questions[AGGREGATE_KEY] = choice(
    "Weighing all the parameter checks, how should this call proceed?",
    {
      auto: "Every parameter is consistent; run the skill without further confirmation.",
      confirm:
        "At least one parameter is plausible but not clearly right; the operator or agent " +
        "should explicitly confirm before the skill runs.",
      reject: "At least one parameter is clearly inconsistent; do not run the skill.",
    },
  );

  return questions;
}

export async function validateArguments(
  client: TypeSafeClient,
  req: ValidationRequest,
): Promise<ValidationOutcome> {
  const questions = buildValidationQuestions(req.skill, req.arguments);

  const state = {
    user_request: req.request,
    skill: {
      name: req.skill.name,
      description_full: req.skill.description_full,
      parameters: req.skill.parameters ?? [],
    },
    extracted_arguments: req.arguments,
  };

  const res = await client.systemOne({ state, questions });

  // ---- per-parameter nouls ---------------------------------------------
  const rawParams: Record<string, number> = {};
  for (const p of req.skill.parameters ?? []) {
    const a = res.answers[`${PARAM_PREFIX}${p.name}` as keyof typeof res.answers];
    if (a && a.type === "noul") rawParams[p.name] = a.noul;
  }

  // ---- aggregate choice -------------------------------------------------
  const agg = res.answers[AGGREGATE_KEY as keyof typeof res.answers];
  if (!agg || agg.type !== "choice") {
    return { disposition: "reject", floorsViolated: [], needsConfirm: [], rawParams };
  }

  const winner = agg.choice;
  if (winner !== "auto" && winner !== "confirm" && winner !== "reject") {
    // A choice outside the criteria we sent is a validation error, never a pass.
    return { disposition: "reject", floorsViolated: [], needsConfirm: [], rawParams };
  }

  const floorsViolated = Object.entries(rawParams)
    .filter(([, p]) => p < NOUL_FLOOR)
    .map(([name]) => name);
  const needsConfirm = Object.entries(rawParams)
    .filter(([, p]) => p >= NOUL_FLOOR && p < NOUL_CONFIRM_FLOOR)
    .map(([name]) => name);

  // The model may say `auto` while the numbers disagree; the numbers win.
  let disposition: ValidationOutcome["disposition"] = winner;
  if (floorsViolated.length > 0) disposition = "reject";
  else if (needConfirm.length > 0 && disposition === "auto") disposition = "confirm";

  return { disposition, floorsViolated, needsConfirm, rawParams };
}
