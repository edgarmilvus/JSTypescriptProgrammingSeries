/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// mcpServer.ts
//
// Tool contract seen by Hermes over stdio:
//   `skill_view`     : { name }                         -> SkillRecord | error result
//   `skill_execute`  : { name, arguments, request, confirm? } ->
//                        { status: "ok", output } |
//                        { status: "needs_confirm", params } |
//                        { status: "rejected", params } |
//                        { status: "error", message }
//
// We return MCP error-style results (`isError: true` with a text block) rather
// than throwing across the transport. A thrown error out of a tool handler
// terminates the turn; a returned error is a message the agent can repair
// against on the next attempt. The one exception is the "unknown skill" case,
// where we still return an error *result* because the agent has a name to fix.
//
// Boot resilience: if the roster file is mid-write, we retry the read up to
// `BOOT_READ_RETRIES` with a small backoff and then fail loudly with a
// message that names the path and the last parse error. A silent "empty
// roster" boot is the worst outcome: every `skill_view` then returns
// "unknown skill," and the operator thinks the agent is broken.

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { validateArguments } from "./skillValidation";
import type { TypeSafeClient } from "@typesafe-ai/sdk";
import type { Skill } from "./rosterTypes";

export interface SkillRecord extends Skill {
  parameters?: { name: string; description: string; type: string }[];
}

export interface Logger {
  info(obj: Record<string, unknown>): void;
  warn(obj: Record<string, unknown>): void;
  error(obj: Record<string, unknown>): void;
}

export interface ServerDeps {
  client: TypeSafeClient;
  roster: SkillRecord[];
  logger: Logger;
}

class LatencyMeter<T extends string> {
  private buckets: Record<T, number[]> = {} as Record<T, number[]>;
  record(bucket: T, ms: number) { (this.buckets[bucket] ??= []).push(ms); }
  percentile(bucket: T, p: number): number {
    const xs = [...(this.buckets[bucket] ?? [])].sort((a, b) => a - b);
    if (xs.length === 0) return 0;
    return xs[Math.min(xs.length - 1, Math.floor(p * xs.length))];
  }
}

const ViewInput = z.object({ name: z.string().min(1) });
const ExecuteInput = z.object({
  name: z.string().min(1),
  arguments: z.record(z.unknown()).default({}),
  request: z.string().min(1),
  confirm: z.boolean().default(false),
});

export function buildServer(deps: ServerDeps) {
  const { client, roster, logger } = deps;
  const byName = new Map(roster.map((s) => [s.name, s]));
  const meter = new LatencyMeter<"view" | "execute.validate" | "execute.body">();

  const server = new Server(
    { name: "skills-server", version: "0.1.0" },
    { capabilities: { tools: {} } },
  );

  server.registerTool(
    "skill_view",
    {
      description: "Load a skill's manifest entry (description_full, body, parameters).",
      inputSchema: ViewInput.shape,
    },
    async (input) => {
      const start = performance.now();
      const skill = byName.get(input.name);
      meter.record("view", performance.now() - start);

      logger.info({
        ts: new Date().toISOString(),
        tool: "skill_view",
        skill: input.name,
        latencyMs: Math.round(performance.now() - start),
        joulFloorsViolated: [],
        disposition: skill ? "auto" : "error",
      });

      if (!skill) {
        return {
          isError: true,
          content: [{ type: "text", text: `unknown skill: ${input.name}` }],
        };
      }
      return {
        content: [{ type: "text", text: JSON.stringify(skill) }],
      };
    },
  );

  server.registerTool(
    "skill_execute",
    {
      description:
        "Validate arguments against the skill's declared parameters and, if consistent, run the skill body.",
      inputSchema: ExecuteInput.shape,
    },
    async (input) => {
      const start = performance.now();
      const skill = byName.get(input.name);
      if (!skill) {
        logger.warn({
          ts: new Date().toISOString(),
          tool: "skill_execute",
          skill: input.name,
          latencyMs: Math.round(performance.now() - start),
          joulFloorsViolated: [],
          disposition: "error",
        });
        return {
          isError: true,
          content: [{ type: "text", text: `unknown skill: ${input.name}` }],
        };
      }

      if (!skill.body || skill.body.trim().length === 0) {
        // Data-integrity case. We choose to reject the call with a clear message
        // rather than no-op, because a no-op risks looking like success to the
        // caller and hiding a broken skill file.
        logger.warn({
          ts: new Date().toISOString(),
          tool: "skill_execute",
          skill: skill.name,
          latencyMs: Math.round(performance.now() - start),
          joulFloorsViolated: [],
          disposition: "error",
        });
        return {
          isError: true,
          content: [
            {
              type: "text",
              text: `skill "${skill.name}" has an empty body; refusing to execute as a no-op`,
            },
          ],
        };
      }

      const validateStart = performance.now();
      const outcome = await validateArguments(client, {
        request: input.request,
        skill,
        arguments: input.arguments,
      });
      meter.record("execute.validate", performance.now() - validateStart);

      logger.info({
        ts: new Date().toISOString(),
        tool: "skill_execute",
        skill: skill.name,
        latencyMs: Math.round(performance.now() - start),
        joulFloorsViolated: outcome.floorsViolated,
        disposition: outcome.disposition,
      });

      if (outcome.disposition === "reject") {
        return {
          isError: true,
          content: [
            {
              type: "text",
              text: JSON.stringify({
                status: "rejected",
                params: outcome.floorsViolated,
                detail: outcome.rawParams,
              }),
            },
          ],
        };
      }
      if (outcome.disposition === "confirm" && !input.confirm) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({
                status: "needs_confirm",
                params: outcome.needsConfirm,
                detail: outcome.rawParams,
              }),
            },
          ],
        };
      }

      // ---- run the body (stubbed; the harness or skill loader owns this) ---
      const bodyStart = performance.now();
      const output = await runSkillBody(skill, input.arguments);
      meter.record("execute.body", performance.now() - bodyStart);

      return { content: [{ type: "text", text: output }] };
    },
  );

  return { server, meter };
}

async function runSkillBody(skill: SkillRecord, args: Record<string, unknown>): Promise<string> {
  // Real implementation shells out or evaluates; a stub suffices for the exercise.
  return JSON.stringify({ ran: skill.name, args });
}

export async function boot(deps: ServerDeps) {
  const { server } = buildServer(deps);
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
