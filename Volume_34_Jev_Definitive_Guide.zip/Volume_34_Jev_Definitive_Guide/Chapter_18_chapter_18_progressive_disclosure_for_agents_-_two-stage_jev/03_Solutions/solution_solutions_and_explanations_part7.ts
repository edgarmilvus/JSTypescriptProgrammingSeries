/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// INTEGRATION.md is prose; here is the corresponding test harness.
// mcpServer.test.ts
import { describe, it, expect, vi } from "vitest";
import { buildServer, type SkillRecord, type Logger } from "./mcpServer";

const roster: SkillRecord[] = [
  {
    name: "pptx-author",
    category: "office",
    description: "Build PPTX decks.",
    description_full: "Author decks with python-pptx.",
    body: "# authoring ...",
    version: "1",
    parameters: [{ name: "template", description: "Path to a template deck.", type: "string" }],
  },
];

const silentLogger: Logger = { info() {}, warn() {}, error() {} };

function stubClient(seq: unknown[]) {
  return { systemOne: vi.fn(async () => seq.shift()) } as unknown as import("@typesafe-ai/sdk").TypeSafeClient;
}

function fakeHermes(server: ReturnType<typeof buildServer>["server"]) {
  // Direct handler invocation; a fuller harness would drive stdio.
  type Handler = (input: unknown) => Promise<unknown>;
  const handlers = new Map<string, Handler>();
  const anyServer = server as unknown as {
    _registeredTools: { name: string; handler: Handler }[];
  };
  for (const t of anyServer._registeredTools ?? []) handlers.set(t.name, t.handler);
  return {
    call: async <T>(name: string, input: unknown): Promise<T> =>
      handlers.get(name)!(input) as Promise<T>,
  };
}

describe("MCP server", () => {
  it("returns an error result (not a throw) for an unknown skill", async () => {
    const { server } = buildServer({ client: stubClient([]), roster, logger: silentLogger });
    const hermes = fakeHermes(server);
    const res = await hermes.call<{ isError?: boolean }>("skill_view", { name: "nope" });
    expect(res.isError).toBe(true);
  });

  it("returns needs_confirm when a parameter is plausible but not certain", async () => {
    const client = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 100, output_tokens: 10 },
        answers: {
          "param::template": { type: "noul", noul: 0.70 },
          "disposition::overall": {
            type: "choice",
            choice: "confirm",
            confidence: 0.7,
            probabilities: { auto: 0.1, confirm: 0.7, reject: 0.2 },
          },
        },
      },
    ]);
    const { server } = buildServer({ client, roster, logger: silentLogger });
    const hermes = fakeHermes(server);
    const res = await hermes.call<{ content: { text: string }[] }>("skill_execute", {
      name: "pptx-author",
      arguments: { template: "/tmp/deck.pptx" },
      request: "make me a deck",
      confirm: false,
    });
    const body = JSON.parse(res.content[0].text);
    expect(body.status).toBe("needs_confirm");
    expect(body.params).toContain("template");
  });

  it("runs the body on the auto path with exactly one validation round trip", async () => {
    const client = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 90, output_tokens: 8 },
        answers: {
          "param::template": { type: "noul", noul: 0.95 },
          "disposition::overall": {
            type: "choice",
            choice: "auto",
            confidence: 0.9,
            probabilities: { auto: 0.9, confirm: 0.05, reject: 0.05 },
          },
        },
      },
    ]);
    const { server } = buildServer({ client, roster, logger: silentLogger });
    const hermes = fakeHermes(server);
    await hermes.call("skill_execute", {
      name: "pptx-author",
      arguments: { template: "a" },
      request: "make me a deck",
      confirm: false,
    });
    expect((client.systemOne as unknown as { mock: { calls: unknown[] } }).mock.calls.length).toBe(1);
  });

  it("rejects when floors are violated even if the aggregate choice said auto", async () => {
    const client = stubClient([
      {
        model: "jev-latest",
        usage: { input_tokens: 90, output_tokens: 8 },
        answers: {
          "param::template": { type: "noul", noul: 0.10 },
          "disposition::overall": {
            type: "choice",
            choice: "auto",
            confidence: 0.8,
            probabilities: { auto: 0.8, confirm: 0.1, reject: 0.1 },
          },
        },
      },
    ]);
    const { server } = buildServer({ client, roster, logger: silentLogger });
    const hermes = fakeHermes(server);
    const res = await hermes.call<{ isError?: boolean; content: { text: string }[] }>(
      "skill_execute",
      { name: "pptx-author", arguments: { template: "a" }, request: "x", confirm: false },
    );
    expect(res.isError).toBe(true);
    expect(JSON.parse(res.content[0].text).status).toBe("rejected");
  });
});
