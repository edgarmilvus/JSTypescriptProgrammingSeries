/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// policies.ts
export type PolicyName = "strict" | "permissive";

export interface GuardPolicy {
  reviewThreshold: number;
  actionThreshold: number;
  severityBlock: number;
}

export const POLICIES: Record<PolicyName, GuardPolicy> = {
  strict: { reviewThreshold: 0.35, actionThreshold: 0.70, severityBlock: 2.0 },
  permissive: { reviewThreshold: 0.35, actionThreshold: 0.85, severityBlock: 2.0 },
};

export const HAZARD_ACTION: Record<string, "block" | "review" | "support"> = {
  jailbreak: "block",
  harmful_request: "block",
  medical_advice: "review",
  self_harm: "support",
};

// Highest precedence first. `support` outranks `block` because a user showing
// self-harm risk is not the same problem as a jailbreak, and refusing to
// respond to them (block) is the worst possible action. `block` outranks
// `review` because a confirmed violation should not be softened by a second
// hazard that would merely have queued it. Everything else is a reviewer's
// turn.
export const PRECEDENCE = ["support", "block", "review", "pass"] as const;
export type Action = (typeof PRECEDENCE)[number] | "degraded";
