/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================
// app/services/reconstruct.ts
//
// A minimal two-pass document reconstruction service for a
// customer-facing ingest pipeline.
//
// Pass 1 (stitch)  : one `noul` question per adjacent line pair.
// Pass 2 (classify): one `choice` question per merged block.
//
// Every character of the output comes from the input. The model
// decides boundaries and types; code does the rendering.
// ============================================================

import {
  TypeSafeClient,
  choice,
  noul,
  type ChoiceQuestion,
  type NoulQuestion,
} from "@typesafe-ai/sdk";

// ------------------------------------------------------------
// 1. Shared client
// ------------------------------------------------------------
// Reads TYPESAFE_API_KEY from the environment. Created once per
// process so connection pooling, retry policy, and timeouts stay
// warm across every request the service makes.
const client = new TypeSafeClient();

// ------------------------------------------------------------
// 2. The demo document
// ------------------------------------------------------------
// Fragmented OCR output: paragraphs hard-wrapped mid-sentence,
// section headings with no markup, list items with no bullets.
const RAW_OCR_TEXT = [
  "Quarterly Engineering Update",
  "",
  "This quarter we shipped the new billing pipeline, migrated the",
  "customer database, and closed out the deprecation of the legacy",
  "PDF renderer that had been in the codebase since 2019.",
  "",
  "Billing pipeline",
  "",
  "The new pipeline cuts invoice generation latency from 8s to",
  "under 400ms. Errors drop to near zero because retries are now",
  "idempotent.",
  "",
  "Database migration",
  "",
  "The migration ran over a weekend window. No customer-visible",
  "downtime. Postmigration validation passed on all 12 shards.",
  "",
  "Remaining work",
  "",
  "Update runbooks for the new pipeline",
  "Archive the PDF renderer repository",
  "Schedule a postmortem for the migration window",
  "",
  "Reminder",
  "",
  "Do not start the archive task until the runbooks are merged; the",
  "archive job deletes the old build artifacts.",
].join("\n");

// ------------------------------------------------------------
// 3. Line tagging
// ------------------------------------------------------------
// Every non-blank line gets a short, stable ID ("L000", "L001").
// These IDs are the only handle the model has on the lines. Every
// question and every answer refers to a line by its ID.

/** Format a zero-padded line identifier, e.g. `L007`. */
function lineId(index: number): string {
  return `L${String(index).padStart(3, "0")}`;
}

interface TaggedLine {
  id: string;
  text: string;
  /** True when a blank line separated this line from the previous one. */
  blankBefore: boolean;
}

/**
 * Normalise the raw text into tagged lines.
 *
 * - Runs of whitespace inside a line collapse to a single space.
 * - Blank lines are consumed; they become a boolean flag on the
 *   next line (`blankBefore`) rather than their own entry, because
 *   the questions we ask in pass 1 are about adjacent non-blank
 *   lines, not about blank lines themselves.
 */
function toTaggedLines(raw: string): TaggedLine[] {
  const lines: TaggedLine[] = [];
  let sawBlank = false;

  for (const rawLine of raw.split("\n")) {
    const text = rawLine.replace(/\s+/g, " ").trim();
    if (text.length === 0) {
      sawBlank = true;
      continue;
    }
    lines.push({
      id: lineId(lines.length),
      text,
      blankBefore: sawBlank,
    });
    sawBlank = false;
  }

  return lines;
}

/**
 * Render the tagged lines into the exact string the model will see
 * as `state`. The `Lxxx|` prefix is the line's ID; the blank line
 * that precedes a line in the input is preserved so the model can
 * see the paragraph structure the author actually left behind.
 */
function renderTagged(lines: TaggedLine[]): string {
  return lines
    .map((l) => `${l.blankBefore ? "\n" : ""}${l.id}| ${l.text}`)
    .join("\n");
}

// ------------------------------------------------------------
// 4. Pass 1: stitch
// ------------------------------------------------------------
// One `noul` question per adjacent line pair. Phrased so a high
// `noul` always means "yes, the break tore a sentence apart".

/** Build the mid-sentence-join question for one line pair. */
function stitchQuestion(
  previousId: string,
  currentId: string,
): NoulQuestion {
  return noul(
    `Does line ${currentId} pick up mid-sentence, continuing a ` +
      `sentence left unfinished at the end of line ${previousId}?`,
    {
      true:
        "The line starts in the middle of a sentence that began on the " +
        "previous line - the line break tore the sentence apart.",
      false:
        "The line begins a new sentence, item, heading, or thought of " +
        "its own.",
    },
  );
}

/**
 * Pass 1.
 *
 * Sends the whole tagged document as `state` and one noul question
 * per eligible adjacent pair, all in a single request. Returns an
 * array indexed by line position: `joins[i]` is P(the break before
 * line `i` was a mid-sentence break).
 */
async function stitch(lines: TaggedLine[]): Promise<number[]> {
  const joins: number[] = new Array(lines.length).fill(0);

  // Never ask about the break across a blank line. A blank line is
  // an explicit paragraph boundary left by the author (or the
  // extractor), and no model is needed to see it.
  const questions: Record<string, NoulQuestion> = {};
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].blankBefore) continue;
    questions[lines[i].id] = stitchQuestion(
      lines[i - 1].id,
      lines[i].id,
    );
  }

  const response = await client.systemOne({
    state: renderTagged(lines),
    questions,
    model: "jev-latest",
  });

  for (let i = 1; i < lines.length; i++) {
    if (lines[i].blankBefore) continue;
    const answer = response.answers[lines[i].id];
    if (answer?.type === "noul") {
      joins[i] = answer.noul;
    }
  }

  return joins;
}

// ------------------------------------------------------------
// 5. Merge
// ------------------------------------------------------------
// Two cutoffs, chosen by how the previous line ends. After a
// dangling line (no terminal punctuation) a small probability is
// enough to join. After a terminal one we demand more, because
// what follows is far more likely to be a new block.

const JOIN_AFTER_DANGLING = 0.2;
const JOIN_AFTER_TERMINAL = 0.5;

/** Does the string end with sentence- or clause-closing punctuation? */
function endsTerminal(text: string): boolean {
  return /[.!?:;]["')\]]*$/.test(text);
}

interface Block {
  id: string;
  text: string;
  /** The line IDs that were folded together into this block. */
  lineIds: string[];
  /** Whether a blank line preceded the first line of the block. */
  blankBefore: boolean;
  // Pass 2 fills these in.
  type?: string;
  confidence?: number;
}

/**
 * Walk the tagged lines and produce blocks, joining adjacent lines
 * whenever pass 1's confidence clears the punctuation-appropriate
 * threshold. Purely deterministic; no model involved.
 */
function merge(lines: TaggedLine[], joins: number[]): Block[] {
  const blocks: Block[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const threshold =
      i > 0 && endsTerminal(lines[i - 1].text)
        ? JOIN_AFTER_TERMINAL
        : JOIN_AFTER_DANGLING;

    const shouldJoin =
      blocks.length > 0 &&
      !line.blankBefore &&
      joins[i] >= threshold;

    if (shouldJoin) {
      const last = blocks[blocks.length - 1];
      last.text += " " + line.text;
      last.lineIds.push(line.id);
      continue;
    }

    blocks.push({
      id: `B${String(blocks.length).padStart(3, "0")}`,
      text: line.text,
      lineIds: [line.id],
      blankBefore: line.blankBefore,
    });
  }

  return blocks;
}

// ------------------------------------------------------------
// 6. Pass 2: classify
// ------------------------------------------------------------
// One choice question per merged block. The options are the block
// vocabulary the renderer understands.

const TYPE_CRITERIA = {
  heading:
    "A short label or title that names the document or the section " +
    "that follows it.",
  paragraph:
    "Running prose: one or more complete sentences of explanatory or " +
    "narrative text.",
  list_item:
    "One entry in a list of parallel items, such as a task, an " +
    "ingredient, or a bullet point.",
  code:
    "Computer code, a shell command, or a config snippet meant to be " +
    "read verbatim.",
  callout:
    "A warning, tip, or important note that interrupts the flow to " +
    "flag something the reader must not miss.",
} as const;

function classifyQuestion(
  blockId: string,
): ChoiceQuestion<typeof TYPE_CRITERIA> {
  return choice(
    `What kind of content is block ${blockId}?`,
    TYPE_CRITERIA,
  );
}

function renderBlocks(blocks: Block[]): string {
  return blocks
    .map((b) => `${b.blankBefore ? "\n" : ""}${b.id}| ${b.text}`)
    .join("\n");
}

/**
 * Pass 2.
 *
 * Sends the merged blocks as `state` and one choice question per
 * block, all in one request. Returns new block objects with `type`
 * and `confidence` populated.
 */
async function classify(blocks: Block[]): Promise<Block[]> {
  const questions: Record<
    string,
    ChoiceQuestion<typeof TYPE_CRITERIA>
  > = {};
  for (const block of blocks) {
    questions[block.id] = classifyQuestion(block.id);
  }

  const response = await client.systemOne({
    state: renderBlocks(blocks),
    questions,
    model: "jev-latest",
  });

  return blocks.map((block) => {
    const answer = response.answers[block.id];
    if (answer?.type !== "choice") return block;
    return {
      ...block,
      type: answer.choice,
      confidence: answer.confidence,
    };
  });
}

// ------------------------------------------------------------
// 7. Render
// ------------------------------------------------------------
// Ordinary code, no model. Consecutive list items collapse into a
// single markdown list; everything else renders in place.

function toMarkdown(blocks: Block[]): string {
  const groups: Array<{ kind: string; items: Block[] }> = [];

  for (const block of blocks) {
    const kind = block.type ?? "paragraph";
    const last = groups[groups.length - 1];
    if (last && last.kind === kind && kind === "list_item") {
      last.items.push(block);
    } else {
      groups.push({ kind, items: [block] });
    }
  }

  return groups
    .map((group) => {
      switch (group.kind) {
        case "list_item":
          return group.items.map((b) => `- ${b.text}`).join("\n");
        case "heading":
          return `## ${group.items[0].text}`;
        case "code":
          return "