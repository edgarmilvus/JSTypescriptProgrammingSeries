/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part7.ts
// Description: Basic Code Example
// ==========================================

async function stitch(lines: TaggedLine[]): Promise<number[]> {
  const joins: number[] = new Array(lines.length).fill(0);

  const questions: Record<string, NoulQuestion> = {};
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].blankBefore) continue;
    questions[lines[i].id] = stitchQuestion(lines[i - 1].id, lines[i].id);
  }

  const response = await client.systemOne({
    state: renderTagged(lines),
    questions,
    model: "jev-latest",
  });

  for (let i = 1; i < lines.length; i++) {
    if (lines[i].blankBefore) continue;
    const answer = response.answers[lines[i].id];
    if (answer?.type === "noul") {
      joins[i] = answer.noul;
    }
  }

  return joins;
}
