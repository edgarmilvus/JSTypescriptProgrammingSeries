/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part9.ts
// Description: Basic Code Example
// ==========================================

function merge(lines: TaggedLine[], joins: number[]): Block[] {
  const blocks: Block[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const threshold =
      i > 0 && endsTerminal(lines[i - 1].text)
        ? JOIN_AFTER_TERMINAL
        : JOIN_AFTER_DANGLING;

    const shouldJoin =
      blocks.length > 0 &&
      !line.blankBefore &&
      joins[i] >= threshold;

    if (shouldJoin) {
      const last = blocks[blocks.length - 1];
      last.text += " " + line.text;
      last.lineIds.push(line.id);
      continue;
    }

    blocks.push({
      id: `B${String(blocks.length).padStart(3, "0")}`,
      text: line.text,
      lineIds: [line.id],
      blankBefore: line.blankBefore,
    });
  }

  return blocks;
}
