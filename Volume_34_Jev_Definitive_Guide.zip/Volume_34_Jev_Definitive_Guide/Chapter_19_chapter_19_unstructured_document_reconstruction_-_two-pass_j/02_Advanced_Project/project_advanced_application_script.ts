/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/reconstruct/route.ts
 *
 * Two-pass Jev reconstruction for the Smart Paste import feature.
 * Pass 1 stitches hard-wrapped lines back into logical blocks.
 * Pass 2 classifies each block using speculative fan-out so every
 * companion question rides the same sub-100 ms request.
 * Blocks below a confidence floor are repaired by a generative model
 * and then re-verified by a Jev grounding Noul before acceptance.
 */

import { NextRequest, NextResponse } from "next/server";
import {
  TypeSafeClient,
  choice,
  noul,
  type ChoiceAnswer,
  type NoulAnswer,
} from "@typesafe-ai/sdk";
import Anthropic from "@anthropic-ai/sdk";

const JEV = "jev-latest";
const FALLBACK = "claude-sonnet-5";

/* ── Graph State ──────────────────────────────────────────────────── */
interface TaggedLine { id: string; text: string; gapBefore: boolean }
interface LogicalBlock {
  id: string; text: string; lineIds: string[];
  kind: ChoiceAnswer<typeof BLOCK_TYPES>;
  level?: ChoiceAnswer<typeof HEADING_LEVELS>;
  step?: NoulAnswer;
  callout?: ChoiceAnswer<typeof CALLOUTS>;
  confidence: number;
  escalated?: boolean;
}

const BLOCK_TYPES = {
  heading: "A short title or section label.",
  paragraph: "Running prose in complete sentences.",
  list_item: "One entry in a list of parallel items.",
  quote: "Words attributed to a person or source.",
  code: "Command, config, or terminal output.",
  callout: "Warning, tip, or important note.",
} as const;
const HEADING_LEVELS = { title: "Document title", section: "Major section", subsection: "Nested minor heading" } as const;
const CALLOUTS = { note: "Neutral extra info", tip: "Helpful shortcut", warning: "Caution about risk" } as const;
const LEVEL_PREFIX = { title: "#", section: "##", subsection: "###" } as const;
const CALLOUT_MARK = { note: "NOTE", tip: "TIP", warning: "WARNING" } as const;

const JOIN_DANGLING = 0.2, JOIN_TERMINAL = 0.5, AUTO_ACCEPT = 0.72, STEP_MIN = 0.5;

/* ── Warm client, reused across invocations ───────────────────────── */
const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY!,
  defaultModel: JEV,
  timeout: 12_000,
  retry: { maxRetries: 3, backoffInitialMs: 250, backoffMaxMs: 4_000 },
});
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

/* ── Pass-1 helpers ───────────────────────────────────────────────── */
const endsTerminal = (t: string) => /[.!?:;…]["')\]]*$/.test(t);
const pad = (i: number) => String(i).padStart(3, "0");

function toLines(raw: string): TaggedLine[] {
  const out: TaggedLine[] = [];
  let gap = false;
  for (const line of raw.split(/\r?\n/)) {
    const text = line.replace(/[\t ]+/g, " ").trim();
    if (!text) { gap = out.length > 0; continue; }
    out.push({ id: `L${pad(out.length)}`, text, gapBefore: gap });
    gap = false;
  }
  return out;
}
const tag = (rows: { id: string; text: string; gapBefore: boolean }[]) =>
  rows.map(r => `${r.gapBefore ? "\n" : ""}${r.id}| ${r.text}`).join("\n");

/* ── Route handler ────────────────────────────────────────────────── */
export async function POST(req: NextRequest) {
  const { text: raw } = (await req.json()) as { text: string };
  const lines = toLines(raw);
  if (!lines.length) return NextResponse.json({ markdown: "", blocks: [] });

  /* ── Pass 1: stitch, one Noul per adjacent pair, single request ── */
  const stitchQs: Record<string, ReturnType<typeof noul>> = {};
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].gapBefore) continue;
    stitchQs[lines[i].id] = noul(
      `Does line ${lines[i].id} pick up mid-sentence left unfinished at ${lines[i - 1].id}?`,
      { true: "Starts mid-sentence — a break tore it apart", false: "Begins a new sentence, item, or heading" },
    );
  }
  const pass1 = await jev.systemOne({ state: tag(lines), questions: stitchQs });
  const joins = lines.map((l, i) =>
    i === 0 || l.gapBefore ? 0 : ((pass1.answers[l.id] as NoulAnswer | undefined)?.noul ?? 0),
  );

  /* Merge with terminal-punctuation-aware bars. */
  type Draft = { text: string; lineIds: string[]; gapBefore: boolean };
  const drafts: Draft[] = [];
  lines.forEach((line, i) => {
    const prior = drafts[drafts.length - 1];
    const bar = i > 0 && endsTerminal(lines[i - 1].text) ? JOIN_TERMINAL : JOIN_DANGLING;
    if (prior && !line.gapBefore && joins[i] >= bar) {
      prior.text += " " + line.text;
      prior.lineIds.push(line.id);
    } else drafts.push({ text: line.text, lineIds: [line.id], gapBefore: line.gapBefore });
  });

  /* ── Pass 2: classify, speculative fan-out per block ──────────── */
  const blockTag = drafts.map((b, i) => `${b.gapBefore ? "\n" : ""}B${pad(i)}| ${b.text}`).join("\n");
  const classQs: Record<string, unknown> = {};
  drafts.forEach((_, i) => {
    const b = `B${pad(i)}`;
    classQs[`type_${b}`] = choice(`What kind of content is ${b}?`, BLOCK_TYPES);
    classQs[`level_${b}`] = choice(`Heading level of ${b}?`, HEADING_LEVELS);
    classQs[`step_${b}`] = noul(`Is ${b} a step in an ordered procedure?`, {
      true: "Yes — order matters", false: "No — order is irrelevant or it is not a list item",
    });
    classQs[`callout_${b}`] = choice(`Callout kind of ${b}?`, CALLOUTS);
  });
  const pass2 = await jev.systemOne({ state: blockTag, questions: classQs as never });

  const blocks: LogicalBlock[] = drafts.map((d, i) => {
    const b = `B${pad(i)}`, a = pass2.answers;
    const kind = a[`type_${b}`] as ChoiceAnswer<typeof BLOCK_TYPES>;
    return {
      id: b, text: d.text, lineIds: d.lineIds, kind, confidence: kind.confidence,
      level: a[`level_${b}`] as ChoiceAnswer<typeof HEADING_LEVELS>,
      step: a[`step_${b}`] as NoulAnswer,
      callout: a[`callout_${b}`] as ChoiceAnswer<typeof CALLOUTS>,
    };
  });

  /* ── Escalation: repair low-confidence blocks, then re-verify ── */
  const escalations: { blockId: string; reason: string }[] = [];
  for (const block of blocks) {
    if (block.confidence >= AUTO_ACCEPT) continue;
    escalations.push({ blockId: block.id, reason: `confidence ${block.confidence.toFixed(2)}` });
    const repair = await anthropic.messages.create({
      model: FALLBACK, max_tokens: 400,
      messages: [{ role: "user", content:
        `Repair this document block. Preserve every word from the source.\nKind: ${block.kind.choice}\nText: ${block.text}` }],
    });
    const repaired = repair.content.filter(c => c.type === "text")
      .map(c => (c as { text: string }).text).join("").trim();
    const verify = await jev.systemOne({
      state: { source: block.text, candidate: repaired },
      questions: { grounded: noul(
        "Does the candidate preserve every word of the source without inventing or dropping content?",
        { true: "Every word preserved verbatim", false: "Words added, removed, or altered" }) },
    });
    const g = (verify.answers.grounded as NoulAnswer).noul;
    if (g >= 0.85) { block.text = repaired; block.escalated = true; }
    else escalations.at(-1)!.reason += ` — rejected (grounded=${g.toFixed(2)})`;
  }

  return NextResponse.json({
    markdown: renderMarkdown(blocks),
    blocks: blocks.map(b => ({
      id: b.id, kind: b.kind.choice, confidence: b.confidence, escalated: !!b.escalated,
    })),
    escalations,
    usage: { pass1: pass1.usage, pass2: pass2.usage },
  });
}

/* ── Renderer (deterministic — no further model calls) ───────────── */
function renderMarkdown(blocks: LogicalBlock[]): string {
  const out: string[] = [];
  let buf: LogicalBlock[] = [];
  let mode: "list_item" | "code" | null = null;
  const flush = () => {
    if (!buf.length || !mode) return;
    if (mode === "list_item") {
      const ordered =
        buf.reduce((s, b) => s + (b.step?.noul ?? 0), 0) / buf.length >= STEP_MIN;
      out.push(buf.map((b, i) => (ordered ? `${i + 1}. ${b.text}` : `- ${b.text}`)).join("\n"));
    } else out.push("