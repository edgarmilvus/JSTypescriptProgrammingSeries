/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import {
  noul,
  TypeSafeClient,
  type NoulQuestion,
  type NoulResponse,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// 1. Line tagging: paper lines -> stable, unambiguous identifiers
// ---------------------------------------------------------------------------
export interface TaggedLine {
  id: string;      // "L000", "L001", ...
  text: string;    // trimmed, whitespace-normalised
  gap: boolean;    // true if a blank line preceded this one
}

const idFor = (i: number) => `L${i.toString().padStart(3, "0")}`;

export function tokenizeOcrDump(raw: string): TaggedLine[] {
  const out: TaggedLine[] = [];
  let gap = false;
  let idx = 0;
  for (const rawLine of raw.split("\n")) {
    const text = rawLine.replace(/[ \t]+/g, " ").trim();
    if (!text) {
      // A blank line only counts as a gap if it separates two real lines.
      if (out.length) gap = true;
      continue;
    }
    out.push({ id: idFor(idx), text, gap });
    idx += 1;
    gap = false;
  }
  return out;
}

export function tagDocument(lines: TaggedLine[]): string {
  // The model sees ids on every line; the questions refer to lines by id,
  // never by position words like "the previous line".
  return lines
    .map((l) => `${l.gap ? "\n" : ""}${l.id}| ${l.text}`)
    .join("\n");
}

// ---------------------------------------------------------------------------
// 2. The Pass 1 continuation question
// ---------------------------------------------------------------------------
// "true" means: MERGE this line upward into the previous sentence.
// We deliberately do NOT ask "are these the same paragraph?" — that question
// over-merges list items, because every list item is topically "the same
// paragraph". We ask the narrowest possible fact: was a sentence torn in two
// by the line break?
export function continuationQuestion(lineIdx: number): NoulQuestion {
  const prev = idFor(lineIdx - 1);
  const cur = idFor(lineIdx);
  return noul(
    `Does line ${cur} pick up mid-sentence, continuing a sentence left ` +
      `unfinished at the end of line ${prev}?`,
    {
      true:
        `${cur} starts in the middle of a sentence that began on ${prev} — ` +
        `the line break tore the sentence apart.`,
      false:
        `${cur} begins a new sentence, list item, heading, or thought of its own; ` +
        `the break is a genuine content boundary.`,
    },
  );
}

// ---------------------------------------------------------------------------
// 3. Two-tier threshold policy, based on the *punctuation class* of the
//    previous line's final character — never its content.
// ---------------------------------------------------------------------------
// Why two thresholds? A single cutoff breaks in both directions:
//   * After a dangling line (no sentence-ending punctuation), a true
//     continuation can legitimately score as low as ~0.39 (e.g. "make the
//     switch for real." continuing a line that ended without punctuation).
//     A 0.5 cutoff would fragment healthy paragraphs.
//   * After a terminal line, a list item that merely shares the topic of an
//     introducing sentence can score ~0.22 (e.g. "The platform team" after a
//     list-introducing colon). A 0.2 cutoff would swallow the whole list into
//     the introducing paragraph.
// Punctuation, not semantics, is the only discriminator we need.
const TERMINAL_RE = /[.!?:;…]["')\]]*$/;
export const JOIN_AFTER_DANGLING = 0.2;
export const JOIN_AFTER_TERMINAL = 0.5;

export function thresholdFor(lines: TaggedLine[], i: number): number {
  if (i === 0) return Number.POSITIVE_INFINITY;
  return TERMINAL_RE.test(lines[i - 1].text)
    ? JOIN_AFTER_TERMINAL
    : JOIN_AFTER_DANGLING;
}

// ---------------------------------------------------------------------------
// 4. Merge and provenance
// ---------------------------------------------------------------------------
export interface Block {
  blockId: string;        // "B000"
  lineIndices: number[];  // document order
  text: string;           // single-spaced concatenation; no character changes
}

export interface MergeDecision {
  blockId: string;
  firstLine: string;         // "L014"
  lastLine: string;          // "L017"
  joinProbabilities: number[];
  thresholdsUsed: number[];
  block: string;
}

export function mergeIntoBlocks(
  lines: TaggedLine[],
  joinProbabilities: number[],
): { blocks: Block[]; decisions: MergeDecision[] } {
  const blocks: Block[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const last = blocks[blocks.length - 1];
    const bar = thresholdFor(lines, i);
    const p = joinProbabilities[i] ?? 0;
    const shouldMerge = last !== undefined && !line.gap && p >= bar;
    if (shouldMerge) {
      last.lineIndices.push(i);
      last.text += " " + line.text;
    } else {
      blocks.push({
        blockId: `B${blocks.length.toString().padStart(3, "0")}`,
        lineIndices: [i],
        text: line.text,
      });
    }
  }

  const decisions: MergeDecision[] = blocks.map((b) => {
    const joins = b.lineIndices.slice(1);
    return {
      blockId: b.blockId,
      firstLine: lines[b.lineIndices[0]].id,
      lastLine: lines[b.lineIndices[b.lineIndices.length - 1]].id,
      joinProbabilities: joins.map((i) => joinProbabilities[i]),
      thresholdsUsed: joins.map((i) => thresholdFor(lines, i)),
      block: b.text,
    };
  });
  return { blocks, decisions };
}

// ---------------------------------------------------------------------------
// 5. The single request
// ---------------------------------------------------------------------------
export async function stitchPass(
  client: TypeSafeClient,
  rawText: string,
): Promise<{
  lines: TaggedLine[];
  blocks: Block[];
  decisions: MergeDecision[];
  joinProbabilities: number[];
}> {
  const lines = tokenizeOcrDump(rawText);
  const state = tagDocument(lines);

  const questions: Record<string, NoulQuestion> = {};
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].gap) continue; // blank-line-separated: never a continuation
    questions[lines[i].id] = continuationQuestion(i);
  }
  if (Object.keys(questions).length === 0) {
    return { lines, blocks: [], decisions: [], joinProbabilities: [] };
  }

  console.log(
    `Pass 1: ${lines.length} lines, ${Object.keys(questions).length} pair questions, 1 request.`,
  );

  const response = await client.systemOne({ state, questions });

  const joinProbabilities: number[] = new Array(lines.length).fill(0);
  for (let i = 1; i < lines.length; i++) {
    const a = response.answers[lines[i].id] as NoulResponse | undefined;
    if (a?.type === "noul") joinProbabilities[i] = a.noul;
  }

  const { blocks, decisions } = mergeIntoBlocks(lines, joinProbabilities);
  return { lines, blocks, decisions, joinProbabilities };
}

// ---------------------------------------------------------------------------
// 6. Failure analysis: pairs sitting within 0.15 of their threshold
// ---------------------------------------------------------------------------
export function inspectNearMisses(
  lines: TaggedLine[],
  joinProbabilities: number[],
  margin = 0.15,
): void {
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].gap) continue;
    const p = joinProbabilities[i];
    const bar = thresholdFor(lines, i);
    if (Math.abs(p - bar) <= margin) {
      console.log(
        `NEAR-MISS ${idFor(i - 1)} -> ${idFor(i)}\n` +
          `  prev ends "${lines[i - 1].text.slice(-24)}"\n` +
          `  curr starts "${lines[i].text.slice(0, 24)}"\n` +
          `  p=${p.toFixed(2)} bar=${bar.toFixed(2)} (${TERMINAL_RE.test(lines[i - 1].text) ? "terminal" : "dangling"})\n` +
          `  prediction: a criteria reword *could* flip this case; a threshold ` +
          `tweak almost certainly would — margins under 0.05 are effectively coin flips.`,
      );
    }
  }
}
