/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import {
  choice,
  noul,
  TypeSafeClient,
  type ChoiceQuestion,
  type NoulQuestion,
  type SystemOneResult,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// 1. Types
// ---------------------------------------------------------------------------
export type BlockKind =
  | "title"
  | "section_heading"
  | "subsection_heading"
  | "paragraph"
  | "list_item_ordered"
  | "list_item_bulleted"
  | "code"
  | "blockquote"
  | "callout";

export type CalloutKind = "note" | "tip" | "warning";

export const BLOCK_KINDS: BlockKind[] = [
  "title",
  "section_heading",
  "subsection_heading",
  "paragraph",
  "list_item_ordered",
  "list_item_bulleted",
  "code",
  "blockquote",
  "callout",
];

export interface ClassifiedBlock {
  blockId: string;
  text: string;
  kind: BlockKind;
  // `kindConfidence` is Jev's summary statistic over the *whole* distribution
  // over all 9 kinds. It is NOT the chosen kind's own probability.
  //   * The chosen-kind probability can be 0.4 with confidence 0.55 when the
  //     remaining mass is spread thinly across 8 alternatives.
  //   * The chosen-kind probability can be 0.4 with confidence 0.15 when the
  //     remaining mass sits on one strong runner-up.
  // Routing (Exercise 4) thresholds on `kindConfidence`, because the shape of
  // the distribution is what tells you whether the model "knows" the answer.
  kindConfidence: number;
  headingLevel?: 1 | 2 | 3;   // populated when kind is any heading
  calloutKind?: CalloutKind;  // populated when kind is callout
  ordered?: boolean;          // populated when kind is a list item
  kindAnswer: any;            // raw ChoiceResponse for audit
  companions: Record<string, any>;
}

// ---------------------------------------------------------------------------
// 2. Primary Choice question
// ---------------------------------------------------------------------------
const BLOCK_KIND_CRITERIA: Record<BlockKind, string> = {
  title:
    "The document's overall title: a short label naming the whole document, not a full sentence of content.",
  section_heading:
    "A major section heading within the document — names a section that follows.",
  subsection_heading:
    "A minor heading nested under a section — names a sub-topic inside a section.",
  paragraph:
    "Running prose: one or more complete sentences of narrative or explanation, not a list entry.",
  list_item_ordered:
    "One entry in an ordered sequence where the order of the items matters (step 1, 2, 3).",
  list_item_bulleted:
    "One entry in an unordered collection — a sibling item whose position is arbitrary.",
  code:
    "A computer command, shell line, terminal output, or config snippet, meant to be read verbatim.",
  blockquote:
    "Words attributed to a person or source — quoted speech, a citation, or an excerpt.",
  callout:
    "A warning, tip, or note set apart from the running prose to flag something the reader must not miss.",
};

export function blockKindQuestion(
  blockId: string,
): ChoiceQuestion<Record<BlockKind, string>> {
  return choice(
    `What kind of content is block ${blockId}?`,
    BLOCK_KIND_CRITERIA,
  );
}

// ---------------------------------------------------------------------------
// 3. Companion questions
// ---------------------------------------------------------------------------
export function headingLevelQuestion(blockId: string) {
  // Choice, not Noul: three mutually exclusive levels must be chosen among.
  // A per-level Noul ("Is this a title?", "Is this a section?") would need
  // three questions and a code-side tiebreaker when two come back high.
  return choice(
    `If block ${blockId} is a heading, what level would it occupy in this document's structure?`,
    {
      title: "The title of the whole document.",
      section: "A major section heading within the document.",
      subsection: "A minor heading nested under a section.",
    },
  );
}

export function orderednessQuestion(blockId: string): NoulQuestion {
  // Noul, not Choice: "does order matter?" is genuinely binary. Two-valued
  // Choice would put a category around a truth condition with no gain.
  return noul(
    `Is block ${blockId} an instruction in a sequence where the order of the items matters?`,
    {
      true: "It is one step of a procedure — the surrounding items must occur in order.",
      false: "Order is irrelevant — it is a loose collection, or not a list item at all.",
    },
  );
}

export function calloutKindQuestion(blockId: string) {
  return choice(
    `If block ${blockId} is a callout, what kind of aside is it?`,
    {
      note: "Neutral extra information the reader should be aware of.",
      tip: "A helpful suggestion or shortcut that makes things easier.",
      warning: "A caution about something that can go wrong or cause harm.",
    },
  );
}

// ---------------------------------------------------------------------------
// 4. Pass 2: speculative fan-out over the whole document
// ---------------------------------------------------------------------------
const HEADING_MAX_CHARS = 90;

export async function classifyPass(
  client: TypeSafeClient,
  blocks: { blockId: string; text: string }[],
): Promise<{
  classified: ClassifiedBlock[];
  questionsSent: number;
  questionsConsumed: number;
}> {
  const questions: Record<string, unknown> = {};
  for (const b of blocks) {
    questions[`kind_${b.blockId}`] = blockKindQuestion(b.blockId);
    // Only ask for heading level if the block could plausibly be a heading.
    // Cheaper than fattening every companion question with a "not a heading"
    // branch, and the gate is a plain length check.
    if (b.text.length <= HEADING_MAX_CHARS) {
      questions[`hlevel_${b.blockId}`] = headingLevelQuestion(b.blockId);
    }
    questions[`orderedness_${b.blockId}`] = orderednessQuestion(b.blockId);
    questions[`callout_${b.blockId}`] = calloutKindQuestion(b.blockId);
  }

  const state = blocks.map((b) => `B| ${b.blockId}: ${b.text}`).join("\n");
  console.log(
    `Pass 2: ${blocks.length} blocks, ${Object.keys(questions).length} questions sent, 1 request.`,
  );

  const response = await client.systemOne({
    state,
    questions: questions as never,
  });

  let consumed = 0;
  const classified: ClassifiedBlock[] = blocks.map((b) => {
    const kindAns = response.answers[`kind_${b.blockId}`] as any;
    const kind: BlockKind = kindAns.choice;
    consumed += 1; // always

    const companions: Record<string, any> = {
      headingLevel: response.answers[`hlevel_${b.blockId}`],
      orderedness: response.answers[`orderedness_${b.blockId}`],
      calloutKind: response.answers[`callout_${b.blockId}`],
    };

    let headingLevel: 1 | 2 | 3 | undefined;
    if (kind === "title") headingLevel = 1;
    else if (kind === "section_heading") headingLevel = 2;
    else if (kind === "subsection_heading") headingLevel = 3;
    else if (companions.headingLevel) {
      const w = companions.headingLevel.choice;
      headingLevel = w === "title" ? 1 : w === "section" ? 2 : 3;
    }
    if (headingLevel !== undefined) consumed += 1;

    let ordered: boolean | undefined;
    if (kind === "list_item_ordered" || kind === "list_item_bulleted") {
      // The dedicated orderedness question beats the two-way label when
      // confident; the Choice collapses two dimensions into one and gets
      // more of the ambiguous cases wrong.
      const n = companions.orderedness;
      if (n?.type === "noul" && n.noul > 0.7) ordered = true;
      else if (n?.type === "noul" && n.noul < 0.3) ordered = false;
      else ordered = kind === "list_item_ordered";
      consumed += 1;
    }

    let calloutKind: CalloutKind | undefined;
    if (kind === "callout") {
      calloutKind = (companions.calloutKind?.choice as CalloutKind) ?? "note";
      consumed += 1;
    }

    return {
      blockId: b.blockId,
      text: b.text,
      kind,
      kindConfidence: kindAns.confidence,
      headingLevel,
      calloutKind,
      ordered,
      kindAnswer: kindAns,
      companions,
    };
  });

  return {
    classified,
    questionsSent: Object.keys(questions).length,
    questionsConsumed: consumed,
  };
}

// ---------------------------------------------------------------------------
// 5. Renderer (no network, pure projection)
// ---------------------------------------------------------------------------
export function renderBlock(c: ClassifiedBlock): string {
  switch (c.kind) {
    case "title":
      return `# ${c.text}`;
    case "section_heading":
      return `${"#".repeat(c.headingLevel ?? 2)} ${c.text}`;
    case "subsection_heading":
      return `${"#".repeat(c.headingLevel ?? 3)} ${c.text}`;
    case "list_item_ordered":
      return `1. ${c.text}`;
    case "list_item_bulleted":
      return `- ${c.text}`;
    case "code":
      return "