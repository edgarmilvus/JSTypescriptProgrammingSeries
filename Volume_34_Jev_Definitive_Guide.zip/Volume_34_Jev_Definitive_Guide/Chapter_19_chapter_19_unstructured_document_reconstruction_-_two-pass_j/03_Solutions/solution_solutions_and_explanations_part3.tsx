/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo, useState } from "react";
import { BLOCK_KINDS, type BlockKind, type CalloutKind, type ClassifiedBlock } from "./pass2";
import type { MergeDecision } from "./pass1";

interface CommittedBlock {
  blockId: string;
  kind: BlockKind;
  text: string;
  override?: { kind: BlockKind; note?: string };
}

interface ReconstructionReviewProps {
  documentId: string;
  decisions: MergeDecision[];
  classified: ClassifiedBlock[];
  reviewThreshold: number;
  onCommit: (edited: CommittedBlock[]) => void;
}

interface OverrideState {
  kind?: BlockKind;
  headingLevel?: 1 | 2 | 3;
  calloutKind?: CalloutKind;
  ordered?: boolean;
  note?: string;
}

export function ReconstructionReview(props: ReconstructionReviewProps): JSX.Element {
  const { documentId, decisions, classified, reviewThreshold, onCommit } = props;

  // All overrides are local; the component is a pure projection of inputs
  // plus this state. No fetch, no effect that calls out.
  const [overrides, setOverrides] = useState<Record<string, OverrideState>>({});
  const [showRaw, setShowRaw] = useState<Record<string, boolean>>({});
  const [showWhy, setShowWhy] = useState<Record<string, boolean>>({});

  // Loud about seams: if decisions and classified disagree on ids, do not
  // silently merge — an operator must see the mismatch.
  const mismatch = useMemo(() => {
    const dIds = new Set(decisions.map((d) => d.blockId));
    const cIds = new Set(classified.map((c) => c.blockId));
    return {
      decisionsOnly: [...dIds].filter((id) => !cIds.has(id)),
      classifiedOnly: [...cIds].filter((id) => !dIds.has(id)),
    };
  }, [decisions, classified]);

  if (mismatch.decisionsOnly.length || mismatch.classifiedOnly.length) {
    return (
      <div role="alert" style={{ background: "#fde2e2", border: "1px solid #a12", padding: 16 }}>
        <strong>Pipeline seam error — reconstruction incomplete.</strong>
        <div>decisions-only block ids: {mismatch.decisionsOnly.join(", ") || "none"}</div>
        <div>classified-only block ids: {mismatch.classifiedOnly.join(", ") || "none"}</div>
      </div>
    );
  }

  const decisionsById = new Map(decisions.map((d) => [d.blockId, d]));

  const commit = () => {
    const out: CommittedBlock[] = classified.map((c) => {
      const ov = overrides[c.blockId] ?? {};
      const kind = ov.kind ?? c.kind;
      const overridden = kind !== c.kind;
      return {
        blockId: c.blockId,
        kind,
        text: c.text,
        override: overridden ? { kind, note: ov.note } : undefined,
      };
    });
    onCommit(out);
  };

  return (
    <div style={{ maxWidth: 1440, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ margin: 0 }}>Review: {documentId}</h2>
        <button onClick={commit} style={{ padding: "6px 14px" }}>
          Commit
        </button>
      </header>

      {classified.map((c) => {
        const decision = decisionsById.get(c.blockId)!;
        const ov = overrides[c.blockId] ?? {};
        const effectiveKind: BlockKind = ov.kind ?? c.kind;
        const flagged = c.kindConfidence < reviewThreshold;

        return (
          <section
            key={c.blockId}
            style={{
              borderBottom: "1px solid #e1e0d9",
              padding: "10px 8px",
              background: flagged ? "#fff7e0" : "transparent",
            }}
          >
            {/* header row */}
            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
              <span style={{ fontFamily: "monospace", color: "#52514e", whiteSpace: "nowrap" }}>
                {decision.firstLine}–{decision.lastLine}
              </span>

              <select
                value={effectiveKind}
                onChange={(e) =>
                  setOverrides((s) => ({
                    ...s,
                    [c.blockId]: { ...s[c.blockId], kind: e.target.value as BlockKind },
                  }))
                }
              >
                {BLOCK_KINDS.map((k) => (
                  <option key={k} value={k}>
                    {k}
                  </option>
                ))}
              </select>

              <span
                style={{
                  fontFamily: "monospace",
                  padding: "0 6px",
                  borderRadius: 4,
                  background: flagged ? "#f6c76a" : "#eee",
                }}
                title={`kindConfidence = ${c.kindConfidence}`}
              >
                {c.kindConfidence.toFixed(2)}
              </span>
              {flagged && (
                <span style={{ color: "#a35", fontWeight: 600, fontSize: 12 }}>review</span>
              )}

              <button onClick={() => setShowRaw((s) => ({ ...s, [c.blockId]: !s[c.blockId] }))}>
                {showRaw[c.blockId] ? "hide raw" : "show raw"}
              </button>
              <button onClick={() => setShowWhy((s) => ({ ...s, [c.blockId]: !s[c.blockId] }))}>
                why
              </button>
            </div>

            {/* companion overrides */}
            {effectiveKind.endsWith("heading") && (
              <div style={{ marginTop: 6 }}>
                <label>
                  level:{" "}
                  <select
                    value={
                      ov.headingLevel ??
                      c.headingLevel ??
                      (effectiveKind === "title" ? 1 : effectiveKind === "section_heading" ? 2 : 3)
                    }
                    onChange={(e) =>
                      setOverrides((s) => ({
                        ...s,
                        [c.blockId]: {
                          ...s[c.blockId],
                          headingLevel: Number(e.target.value) as 1 | 2 | 3,
                        },
                      }))
                    }
                  >
                    <option value={1}># (title)</option>
                    <option value={2}>## (section)</option>
                    <option value={3}>### (subsection)</option>
                  </select>
                </label>
              </div>
            )}
            {effectiveKind === "callout" && (
              <div style={{ marginTop: 6 }}>
                <label>
                  callout kind:{" "}
                  <select
                    value={ov.calloutKind ?? c.calloutKind ?? "note"}
                    onChange={(e) =>
                      setOverrides((s) => ({
                        ...s,
                        [c.blockId]: { ...s[c.blockId], calloutKind: e.target.value as CalloutKind },
                      }))
                    }
                  >
                    <option value="note">note</option>
                    <option value="tip">tip</option>
                    <option value="warning">warning</option>
                  </select>
                </label>
              </div>
            )}
            {(effectiveKind === "list_item_ordered" || effectiveKind === "list_item_bulleted") && (
              <div style={{ marginTop: 6 }}>
                <label>
                  <input
                    type="checkbox"
                    checked={ov.ordered ?? c.ordered ?? effectiveKind === "list_item_ordered"}
                    onChange={(e) =>
                      setOverrides((s) => ({
                        ...s,
                        [c.blockId]: { ...s[c.blockId], ordered: e.target.checked },
                      }))
                    }
                  />{" "}
                  ordered (order matters)
                </label>
              </div>
            )}

            {/* the merged block text */}
            <div style={{ marginTop: 8, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
              {c.text}
            </div>

            {/* raw source lines: recovered from the decisions record
                because the component must show the *fragments*, not the merge */}
            {showRaw[c.blockId] && (
              <pre
                style={{
                  background: "#f8f8f0",
                  padding: 6,
                  fontFamily: "monospace",
                  fontSize: 12,
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                }}
              >
                {decision.joinProbabilities.length === 0
                  ? `(single raw line, no joins)`
                  : decision.joinProbabilities
                      .map(
                        (p, i) =>
                          `join ${i + 1}: p=${p.toFixed(2)} vs threshold ${decision.thresholdsUsed[
                            i
                          ].toFixed(2)} ${p >= decision.thresholdsUsed[i] ? "→ merged" : "→ split"}`,
                      )
                      .join("\n")}
              </pre>
            )}

            {/* the "why" panel: same data, styled as a chain */}
            {showWhy[c.blockId] && (
              <div
                style={{
                  fontFamily: "monospace",
                  fontSize: 12,
                  color: "#52514e",
                  padding: 6,
                  borderLeft: "3px solid #c3c2b7",
                  marginTop: 6,
                }}
              >
                <div>block {c.blockId} — {decision.joinProbabilities.length} joins</div>
                {decision.joinProbabilities.map((p, i) => (
                  <div key={i}>
                    {decision.firstLine}+{i} → p={p.toFixed(3)} / bar={decision.thresholdsUsed[
                        i
                      ].toFixed(3)}{" "}
                    {p >= decision.thresholdsUsed[i] ? "✓" : "✗"}
                  </div>
                ))}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
