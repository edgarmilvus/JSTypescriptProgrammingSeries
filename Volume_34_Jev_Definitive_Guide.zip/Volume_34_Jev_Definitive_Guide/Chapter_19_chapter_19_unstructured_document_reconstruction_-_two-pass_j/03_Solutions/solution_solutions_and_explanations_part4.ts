/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import type { ClassifiedBlock, BlockKind } from "./pass2";

// ---------------------------------------------------------------------------
// 1. Policy
// ---------------------------------------------------------------------------
export interface EscalationPolicy {
  kindConfidenceFloor: number;      // e.g. 0.75
  maxEscalationFraction: number;    // e.g. 0.10
  alwaysEscalateKinds: BlockKind[]; // e.g. ["code"]
}

export function shouldEscalate(
  block: ClassifiedBlock,
  policy: EscalationPolicy,
  escalationsSoFar: number,
  totalBlocks: number,
): boolean {
  // Always-escalate kinds bypass the floor and the budget *on purpose*.
  // Code blocks that get mislabeled as paragraphs corrupt downstream fixtures;
  // a paragraph that gets mislabeled as a quote does not.
  if (policy.alwaysEscalateKinds.includes(block.kind)) return true;

  if (block.kindConfidence >= policy.kindConfidenceFloor) return false;

  const budget = Math.floor(totalBlocks * policy.maxEscalationFraction);
  return escalationsSoFar < budget;
}

// ---------------------------------------------------------------------------
// 2. The repair prompt and result shape
// ---------------------------------------------------------------------------
export interface RepairResult {
  blockId: string;
  kind: BlockKind;
  boundarySplitIndex?: number;
  reason?: string;
  confidence: number;
  reconstructedText?: string;
}

const REPAIR_SYSTEM_PROMPT = `You recover structure that a deterministic classifier could not resolve.
You never invent text. You choose a kind from the allowed set and, optionally, split one block into two at a boundary that already exists between two of its raw lines.

Reply with a single JSON object matching exactly this shape:
{
  "kind": <one of the allowed kinds>,
  "boundarySplitIndex": <integer index into lineIds, optional>,
  "reason": <short string, optional>,
  "confidence": <number in [0,1]>,
  "reconstructedText": <string, optional>
}
Do not emit anything outside the JSON object.`;

function repairUserMessage(block: ClassifiedBlock): string {
  return JSON.stringify(
    {
      block_id: block.blockId,
      raw_lines: block.text.split("\n"),
      classifier_pick: block.kind,
      classifier_confidence: block.kindConfidence,
      classifier_probabilities: block.kindAnswer?.probabilities ?? null,
      allowed_kinds: [
        "title", "section_heading", "subsection_heading",
        "paragraph", "list_item_ordered", "list_item_bulleted",
        "code", "blockquote", "callout",
      ],
    },
    null,
    2,
  );
}

// ---------------------------------------------------------------------------
// 3. Validation and rejection
// ---------------------------------------------------------------------------
const VALID_REASONS = ["schema", "vocabulary", "budget", "unparseable"] as const;
export type RejectReason = (typeof VALID_REASONS)[number];

interface Rejection {
  blockId: string;
  reason: RejectReason;
  detail: string;
}

export type ValidationOutcome =
  | { ok: true; value: RepairResult }
  | { ok: false; reason: RejectReason; detail: string };

function isSubMultiset(replyTokens: string[], sourceTokens: string[]): boolean {
  const source = new Map<string, number>();
  for (const t of sourceTokens) source.set(t, (source.get(t) ?? 0) + 1);
  for (const t of replyTokens) {
    const n = source.get(t) ?? 0;
    if (n <= 0) return false;
    source.set(t, n - 1);
  }
  return true;
}

export function validateRepair(block: ClassifiedBlock, raw: unknown): ValidationOutcome {
  if (typeof raw !== "object" || raw === null) {
    return { ok: false, reason: "unparseable", detail: "reply was not an object" };
  }
  const r = raw as Record<string, unknown>;

  if (typeof r.kind !== "string") {
    return { ok: false, reason: "schema", detail: "kind missing or non-string" };
  }
  const allowed: BlockKind[] = [
    "title", "section_heading", "subsection_heading",
    "paragraph", "list_item_ordered", "list_item_bulleted",
    "code", "blockquote", "callout",
  ];
  if (!allowed.includes(r.kind as BlockKind)) {
    return { ok: false, reason: "schema", detail: `unknown kind: ${String(r.kind)}` };
  }
  if (typeof r.confidence !== "number" || !Number.isFinite(r.confidence) ||
      r.confidence < 0 || r.confidence > 1) {
    return { ok: false, reason: "schema", detail: "confidence out of [0,1]" };
  }

  const lineIds = block.text.split("\n");
  if (r.boundarySplitIndex !== undefined) {
    const idx = r.boundarySplitIndex;
    if (!Number.isInteger(idx) || (idx as number) < 1 || (idx as number) >= lineIds.length) {
      return {
        ok: false,
        reason: "schema",
        detail: `boundarySplitIndex ${String(idx)} does not sit between two raw lines`,
      };
    }
  }

  if (r.reconstructedText !== undefined && typeof r.reconstructedText !== "string") {
    return { ok: false, reason: "schema", detail: "reconstructedText must be a string" };
  }

  const value: RepairResult = {
    blockId: block.blockId,
    kind: r.kind as BlockKind,
    boundarySplitIndex: r.boundarySplitIndex as number | undefined,
    reason: r.reason as string | undefined,
    confidence: r.confidence,
    reconstructedText: r.reconstructedText,
  };

  // Vocabulary tripwire: the model must not have added any token that is not
  // in the raw source. This is the cheap, decisive check against the classic
  // "cleaned up the OCR while answering the structural question" failure.
  if (value.reconstructedText) {
    const sourceTokens = block.text.toLowerCase().split(/\s+/).filter(Boolean);
    const replyTokens = value.reconstructedText.toLowerCase().split(/\s+/).filter(Boolean);
    if (!isSubMultiset(replyTokens, sourceTokens)) {
      return {
        ok: false,
        reason: "vocabulary",
        detail: "reconstructedText contains tokens absent from the source",
      };
    }
  }

  return { ok: true, value };
}

// ---------------------------------------------------------------------------
// 4. Integration
// ---------------------------------------------------------------------------
export interface SupersededRecord {
  blockId: string;
  supersededBy: string[];
  reason: string;
}

export interface Integration {
  classified: ClassifiedBlock[];
  superseded: SupersededRecord[];
  repairsAccepted: number;
  rejections: Rejection[];
}

export function integrateRepairs(
  classified: ClassifiedBlock[],
  repairs: Map<string, RepairResult>,
  rejections: Rejection[],
): Integration {
  const out: ClassifiedBlock[] = [];
  const superseded: SupersededRecord[] = [];
  let accepted = 0;

  for (const block of classified) {
    const repair = repairs.get(block.blockId);
    if (!repair) {
      out.push(block);
      continue;
    }
    accepted += 1;

    if (repair.boundarySplitIndex !== undefined) {
      const lines = block.text.split("\n");
      const aText = lines.slice(0, repair.boundarySplitIndex).join("\n");
      const bText = lines.slice(repair.boundarySplitIndex).join("\n");
      const a: ClassifiedBlock = { ...block, blockId: `${block.blockId}a`, text: aText, kind: repair.kind, kindConfidence: repair.confidence };
      const b: ClassifiedBlock = { ...block, blockId: `${block.blockId}b`, text: bText };
      out.push(a, b);
      superseded.push({ blockId: block.blockId, supersededBy: [a.blockId, b.blockId], reason: "split" });
    } else {
      out.push({
        ...block,
        kind: repair.kind,
        kindConfidence: repair.confidence,
      });
      superseded.push({
        blockId: block.blockId,
        supersededBy: [`${block.blockId}*`],
        reason: "kind-override",
      });
    }
  }
  return { classified: out, superseded, repairsAccepted: accepted, rejections };
}

// ---------------------------------------------------------------------------
// 5. The escalation runner + instrumentation
// ---------------------------------------------------------------------------
export interface PipelineMetrics {
  totalBlocks: number;
  escalatedBlocks: number;
  repairsAccepted: number;
  repairsRejectedByReason: Record<RejectReason, number>;
  fastPathMs: number;
  slowPathMs: number;
}

export interface GenerativeClient {
  repair(system: string, user: string): Promise<unknown>;
}

export async function runEscalations(
  blocks: ClassifiedBlock[],
  policy: EscalationPolicy,
  gen: GenerativeClient,
): Promise<{ integration: Integration; metrics: PipelineMetrics }> {
  const repairs = new Map<string, RepairResult>();
  const rejections: Rejection[] = [];
  const reasons: Record<RejectReason, number> = { schema: 0, vocabulary: 0, budget: 0, unparseable: 0 };

  const fastPathStart = Date.now();
  let escalationsSoFar = 0;
  const slowPathStart: number[] = [];

  for (const b of blocks) {
    if (!shouldEscalate(b, policy, escalationsSoFar, blocks.length)) {
      if (b.kindConfidence < policy.kindConfidenceFloor) {
        // Budget exhausted, not in always-escalate — this is the human-review path.
        rejections.push({ blockId: b.blockId, reason: "budget", detail: "escalation ceiling reached" });
        reasons.budget += 1;
      }
      continue;
    }
    escalationsSoFar += 1;
    slowPathStart.push(Date.now());
    let raw: unknown;
    try {
      raw = await gen.repair(REPAIR_SYSTEM_PROMPT, repairUserMessage(b));
    } catch (e) {
      raw = null;
      rejections.push({ blockId: b.blockId, reason: "unparseable", detail: String(e) });
      reasons.unparseable += 1;
      continue;
    }
    const outcome = validateRepair(b, raw);
    if (outcome.ok) {
      repairs.set(b.blockId, outcome.value);
    } else {
      rejections.push({ blockId: b.blockId, reason: outcome.reason, detail: outcome.detail });
      reasons[outcome.reason] += 1;
    }
  }

  const final = integrateRepairs(blocks, repairs, rejections);
  return {
    integration: final,
    metrics: {
      totalBlocks: blocks.length,
      escalatedBlocks: escalationsSoFar,
      repairsAccepted: final.repairsAccepted,
      repairsRejectedByReason: reasons,
      fastPathMs: slowPathStart.length ? slowPathStart[0] - fastPathStart : Date.now() - fastPathStart,
      slowPathMs: slowPathStart.length ? Date.now() - slowPathStart[0] : 0,
    },
  };
}
