/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useMemo, useState } from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export type BlockKind =
  | "title" | "section_heading" | "subsection_heading"
  | "paragraph" | "list_item_ordered" | "list_item_bulleted"
  | "code" | "blockquote" | "callout";

export interface CachedJoin {
  prob: number;
  terminal: boolean;   // previous line ended with terminal punctuation?
}

export interface CachedBlock {
  blockId: string;
  kind: BlockKind;
  kindConfidence: number;
  // one join per internal boundary; length = lines - 1
  joins: CachedJoin[];
  // cached outputs from the earlier live run
  ifEscalatedMs?: number;
  ifEscalatedTokens?: number;
  ifEscalatedOutcome?: BlockKind; // what the generative model proposed (if any)
  // gold labels, used only for the structural-accuracy metric
  goldBoundaryMatched?: boolean;
  goldKind?: BlockKind;
}

export interface CachedRun {
  documentId: string;
  fastPathMs: number;             // one full pass-1 + pass-2 round trip, cached
  fastPathTokens: number;         // state + all questions for both passes combined
  blocks: CachedBlock[];
}

export interface DashboardConfig {
  pass1Dangling: number;
  pass1Terminal: number;
  kindConfidenceFloor: number;
  maxEscalationFraction: number;
  alwaysEscalate: Partial<Record<BlockKind, boolean>>;
}

// ---------------------------------------------------------------------------
// The evaluator: pure function of (config, cached runs)
// ---------------------------------------------------------------------------
const PER_INPUT_TOKEN = 0.042 / 1e6; // $ per Mtok of input, jev-1.13

export interface Metrics {
  costPerDoc: number;
  p50Ms: number;
  p95Ms: number;
  escalationRate: number;
  humanReviewRate: number;
  boundaryAccuracy: number;
  kindAccuracy: number;
}

function percentile(values: number[], q: number): number {
  if (values.length === 0) return 0;
  const s = [...values].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * q))];
}

export function evaluate(config: DashboardConfig, runs: CachedRun[]): Metrics {
  let totalCostTokens = 0;
  const latencies: number[] = [];
  let totalBlocks = 0;
  let escalated = 0;
  let humanReview = 0;
  let boundaryCorrect = 0;
  let kindCorrect = 0;

  for (const run of runs) {
    // --- Pass 1 under the current thresholds ------------------------------
    let pass1Questions = 1; // even an empty document is one request
    for (const b of run.blocks) {
      for (const j of b.joins) {
        pass1Questions += 1; // one question per join, regardless of bar
        if (j.prob >= (j.terminal ? config.pass1Terminal : config.pass1Dangling)) {
          // Merged — good, this is a fact, not a decision we can re-derive
          // from cached probabilities alone. (In a real log, boundary validity
          // would be recomputed here.)
        }
      }
    }

    // --- Pass 2 escalation under the current policy ------------------------
    let documentLatency = run.fastPathMs;
    let documentTokens = run.fastPathTokens;
    const budget = Math.floor(run.blocks.length * config.maxEscalationFraction);
    let escalationsThisDoc = 0;

    for (const b of run.blocks) {
      totalBlocks += 1;
      const inAlways = !!config.alwaysEscalate[b.kind];
      const belowFloor = b.kindConfidence < config.kindConfidenceFloor;
      const budgetLeft = escalationsThisDoc < budget;
      const escalate = inAlways || (belowFloor && budgetLeft);

      if (escalate && b.ifEscalatedMs !== undefined) {
        escalationsThisDoc += 1;
        escalated += 1;
        documentLatency += b.ifEscalatedMs;
        documentTokens += b.ifEscalatedTokens ?? 0;
        kindCorrect += b.ifEscalatedOutcome && b.ifEscalatedOutcome === b.goldKind ? 1 : 0;
      } else if (belowFloor) {
        humanReview += 1;
        // Human-reviewed blocks are not credited as kind-correct or kind-wrong
        // for the automatic pipeline metric.
      } else {
        kindCorrect += b.kind === b.goldKind ? 1 : 0;
      }
      boundaryCorrect += b.goldBoundaryMatched ? 1 : 0;
    }

    totalCostTokens += documentTokens;
    latencies.push(documentLatency);
  }

  return {
    costPerDoc: (totalCostTokens * PER_INPUT_TOKEN) / runs.length,
    p50Ms: percentile(latencies, 0.5),
    p95Ms: percentile(latencies, 0.95),
    escalationRate: totalBlocks ? escalated / totalBlocks : 0,
    humanReviewRate: totalBlocks ? humanReview / totalBlocks : 0,
    boundaryAccuracy: totalBlocks ? boundaryCorrect / totalBlocks : 0,
    kindAccuracy: totalBlocks ? kindCorrect / totalBlocks : 0,
  };
}

// ---------------------------------------------------------------------------
// The dashboard
// ---------------------------------------------------------------------------
const BUDGET_COST = 0.0004;
const BUDGET_P95_MS = 400;

interface Snapshot {
  revision: number;
  config: DashboardConfig;
  metrics: Metrics;
}

export function CostLatencyDashboard({
  runs,
}: {
  runs: CachedRun[];
}): JSX.Element {
  const [config, setConfig] = useState<DashboardConfig>({
    pass1Dangling: 0.2,
    pass1Terminal: 0.5,
    kindConfidenceFloor: 0.75,
    maxEscalationFraction: 0.10,
    alwaysEscalate: { code: true },
  });
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [revision, setRevision] = useState(0);

  const metrics = useMemo(() => evaluate(config, runs), [config, runs]);

  // Determinism guard: no network in this component. If a future refactor
  // sneaks one in, fail loudly.
  React.useEffect(() => {
    if (typeof window !== "undefined") {
      const original = window.fetch;
      (window as any).fetch = (...args: any[]) => {
        console.error("Dashboard made a network call, which is a bug:", args);
        return original.apply(window, args as any);
      };
      return () => {
        window.fetch = original;
      };
    }
  }, []);

  const withinCost = metrics.costPerDoc <= BUDGET_COST;
  const withinLatency = metrics.p95Ms <= BUDGET_P95_MS;
  const overBudgetMessages: string[] = [];
  if (!withinCost) {
    overBudgetMessages.push(
      `over budget on cost by $${(metrics.costPerDoc - BUDGET_COST).toFixed(6)}/doc`,
    );
  }
  if (!withinLatency) {
    overBudgetMessages.push(
      `over budget on latency by ${(metrics.p95Ms - BUDGET_P95_MS).toFixed(0)} ms`,
    );
  }

  const snapshot = () => {
    const rev = revision + 1;
    setRevision(rev);
    setSnapshots((s) => [...s, { revision: rev, config: { ...config }, metrics }]);
  };

  const copyConfig = () => {
    const blob = JSON.stringify({ revision, config, metrics }, null, 2);
    navigator.clipboard?.writeText(blob);
    console.log("Copied configuration:", blob);
  };

  return (
    <div style={{ maxWidth: 1440, margin: "0 auto", fontFamily: "system-ui" }}>
      <div
        style={{
          padding: 10,
          background: withinCost && withinLatency ? "#e4f5ea" : "#fde2e2",
          borderBottom: "2px solid #ccc",
          fontWeight: 600,
        }}
      >
        {withinCost && withinLatency ? (
          <>WITHIN BUDGET</>
        ) : (
          <>OVER BUDGET — {overBudgetMessages.join("; ")}</>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "360px 1fr", gap: 24, padding: 16 }}>
        {/* left: sliders */}
        <aside>
          <Slider
            label="Pass 1 — post-dangling threshold"
            value={config.pass1Dangling}
            onChange={(v) => setConfig({ ...config, pass1Dangling: v })}
            min={0}
            max={0.6}
            step={0.05}
          />
          <Slider
            label="Pass 1 — post-terminal threshold"
            value={config.pass1Terminal}
            onChange={(v) => setConfig({ ...config, pass1Terminal: v })}
            min={0.2}
            max={0.9}
            step={0.05}
          />
          <Slider
            label="Pass 2 — kind-confidence escalation floor"
            value={config.kindConfidenceFloor}
            onChange={(v) => setConfig({ ...config, kindConfidenceFloor: v })}
            min={0.4}
            max={0.95}
            step={0.01}
          />
          <Slider
            label="Escalation ceiling (fraction)"
            value={config.maxEscalationFraction}
            onChange={(v) => setConfig({ ...config, maxEscalationFraction: v })}
            min={0}
            max={0.5}
            step={0.01}
          />
          <div style={{ marginTop: 12 }}>
            <strong>always-escalate kinds</strong>
            {(["code", "blockquote", "callout"] as BlockKind[]).map((k) => (
              <label key={k} style={{ display: "block" }}>
                <input
                  type="checkbox"
                  checked={!!config.alwaysEscalate[k]}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      alwaysEscalate: { ...config.alwaysEscalate, [k]: e.target.checked },
                    })
                  }
                />{" "}
                {k}
              </label>
            ))}
          </div>
          <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
            <button onClick={snapshot}>Snapshot</button>
            <button onClick={copyConfig}>Copy configuration</button>
          </div>
        </aside>

        {/* right: metrics + Pareto */}
        <main>
          <MetricsPanel metrics={metrics} />
          <ParetoPlot snapshots={snapshots} current={metrics} />
        </main>
      </div>
    </div>
  );
}

function Slider(props: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step: number;
}) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <label>{props.label}</label>
        <span style={{ fontFamily: "monospace" }}>{props.value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        onChange={(e) => props.onChange(Number(e.target.value))}
        style={{ width: "100%" }}
      />
    </div>
  );
}

function MetricsPanel({ metrics }: { metrics: Metrics }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 8,
        marginBottom: 16,
      }}
    >
      <Stat label="cost / doc" value={`$${metrics.costPerDoc.toFixed(6)}`} />
      <Stat label="latency p50" value={`${metrics.p50Ms.toFixed(0)} ms`} />
      <Stat label="latency p95" value={`${metrics.p95Ms.toFixed(0)} ms`} />
      <Stat label="escalation rate" value={`${(metrics.escalationRate * 100).toFixed(1)}%`} />
      <Stat label="human review rate" value={`${(metrics.humanReviewRate * 100).toFixed(1)}%`} />
      <Stat label="kind accuracy" value={`${(metrics.kindAccuracy * 100).toFixed(1)}%`} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ padding: 8, background: "#f4f4f0", borderRadius: 6 }}>
      <div style={{ fontSize: 12, color: "#52514e" }}>{label}</div>
      <div style={{ fontFamily: "monospace", fontSize: 16 }}>{value}</div>
    </div>
  );
}

function ParetoPlot({ snapshots, current }: { snapshots: Snapshot[]; current: Metrics }) {
  const all = [...snapshots.map((s) => s.metrics), current];
  const xs = all.map((m) => m.costPerDoc);
  const ys = all.map((m) => m.kindAccuracy);
  const xMin = Math.min(...xs, 0), xMax = Math.max(...xs, BUDGET_COST);
  const yMin = Math.min(...ys, 0), yMax = Math.max(...ys, 1);
  const sx = (v: number) => 20 + ((v - xMin) / (xMax - xMin || 1)) * 400;
  const sy = (v: number) => 360 - ((v - yMin) / (yMax - yMin || 1)) * 320;

  // Pareto frontier: nondominated points
  const points = all.map((m, i) => ({ x: m.costPerDoc, y: m.kindAccuracy, i }));
  const frontier = points.filter(
    (p) => !points.some((q) => q !== p && q.x <= p.x && q.y >= p.y && (q.x < p.x || q.y > p.y)),
  );
  const frontierSorted = [...frontier].sort((a, b) => a.x - b.x);

  return (
    <svg width="460" height="400" style={{ background: "#fcfcfb", borderRadius: 8 }}>
      <line x1={20} y1={360} x2={420} y2={360} stroke="#c3c2b7" />
      <line x1={20} y1={40} x2={20} y2={360} stroke="#c3c2b7" />
      <text x={230} y={390} fontSize={11} textAnchor="middle">cost / doc ($)</text>
      <text x={10} y={200} fontSize={11} transform="rotate(-90 10 200)" textAnchor="middle">
        kind accuracy
      </text>
      {frontierSorted.length > 1 &&
        frontierSorted.slice(0, -1).map((p, i) => {
          const q = frontierSorted[i + 1];
          return (
            <line
              key={i}
              x1={sx(p.x)}
              y1={sy(p.y)}
              x2={sx(q.x)}
              y2={sy(q.y)}
              stroke="#2a78d6"
              strokeDasharray="4 3"
            />
          );
        })}
      {snapshots.map((s, i) => (
        <circle
          key={i}
          cx={sx(s.metrics.costPerDoc)}
          cy={sy(s.metrics.kindAccuracy)}
          r={4}
          fill="#2a78d6"
          opacity={0.6}
        />
      ))}
      <circle cx={sx(current.costPerDoc)} cy={sy(current.kindAccuracy)} r={7} fill="#eb6834" />
    </svg>
  );
}
