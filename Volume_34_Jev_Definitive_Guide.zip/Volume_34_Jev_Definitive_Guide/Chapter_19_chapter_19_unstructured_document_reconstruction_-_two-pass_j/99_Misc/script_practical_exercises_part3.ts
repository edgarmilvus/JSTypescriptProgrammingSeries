/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

   type BlockKind =
     | "title" | "section_heading" | "subsection_heading"
     | "paragraph" | "list_item_ordered" | "list_item_bulleted"
     | "code" | "blockquote" | "callout";

   type CalloutKind = "note" | "tip" | "warning";

   interface ClassifiedBlock {
     blockId: string;
     text: string;
     kind: BlockKind;
     kindConfidence: number;      // from ChoiceResponse.confidence
     headingLevel?: 1 | 2 | 3;    // only when kind is a heading
     calloutKind?: CalloutKind;   // only when kind is "callout"
     ordered?: boolean;           // only when kind is a list_item
     // The raw answer objects, retained for audit:
     kindAnswer: ChoiceResponse;
     companions: Record<string, ChoiceResponse | NoulResponse>;
   }
   