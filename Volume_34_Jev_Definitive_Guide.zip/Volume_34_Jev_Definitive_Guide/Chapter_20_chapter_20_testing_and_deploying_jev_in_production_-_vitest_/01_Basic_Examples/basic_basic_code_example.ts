/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/assist/route.ts
/**
 * Edge-deployed "Hello World" for Jev in production.
 *
 * One endpoint does three jobs:
 *   1. Decide with Jev (System One) in a single round trip.
 *   2. Branch in plain code on the typed answers.
 *   3. Optionally call a generative LLM, behind a token bucket, a circuit
 *      breaker, and exponential backoff with jitter.
 *
 * Runs on Vercel Edge, Cloudflare Workers, and Deno Deploy via the
 * Next.js App Router. It uses no Node-only APIs: no `fs`, no `Buffer`,
 * no `setInterval`, no `crypto` node module.
 */

// Bind this handler to the edge runtime. The directive must be a top-level
// literal export; a computed value is ignored by the bundler.
export const runtime = "edge";

// Never cache the response. Without this, an edge CDN could serve a stale
// answer to a fresh message.
export const dynamic = "force-dynamic";

import {
  TypeSafeClient,
  choice,
  noul,
  score,
} from "@typesafe-ai/sdk";

// ---------------------------------------------------------------------------
// Module-scope singletons.
//
// Edge isolates are reused across requests on the same shard, so the client
// and the rate-limit primitives are constructed once per isolate, not once
// per request. Do NOT use setInterval here: an edge isolate can be frozen
// between requests, and any timer you scheduled will not fire.
// ---------------------------------------------------------------------------

/**
 * The one Jev client for this isolate. It reads `TYPESAFE_API_KEY` from the
 * environment when `apiKey` is omitted; passing it explicitly makes the
 * dependency visible at the top of the file.
 */
const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY!,
  defaultModel: "jev-latest",
});

// ---------------------------------------------------------------------------
// 1. Token bucket. Caps *outbound LLM* calls, not inbound requests. The
//    bucket is deliberately module-scope: it protects the shared upstream
//    account, not an individual user.
// ---------------------------------------------------------------------------

class TokenBucket {
  private tokens: number;
  private lastRefill: number;

  /**
   * @param capacity        Maximum burst size (tokens held at rest).
   * @param refillPerSecond Steady-state refill rate. Combined with
   *                        `capacity`, this sets both the burst and the
   *                        long-run ceiling.
   */
  constructor(
    private readonly capacity: number,
    private readonly refillPerSecond: number,
  ) {
    this.tokens = capacity;
    this.lastRefill = Date.now();
  }

  /**
   * Attempt to consume one token. Refills lazily from wall-clock time, so
   * the bucket works correctly even after the isolate is frozen and thawed.
   */
  tryTake(): boolean {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    this.tokens = Math.min(
      this.capacity,
      this.tokens + elapsed * this.refillPerSecond,
    );
    this.lastRefill = now;

    if (this.tokens < 1) return false;
    this.tokens -= 1;
    return true;
  }
}

/** 20 calls of burst; 20 per second steady state. Tune to your plan. */
const llmBudget = new TokenBucket(20, 20);

// ---------------------------------------------------------------------------
// 2. Circuit breaker. Once the LLM has failed N times in a row, stop
//    calling it for a cooldown window and let every request take the Jev
//    fallback path. Prevents a dead upstream from adding latency to every
//    request.
// ---------------------------------------------------------------------------

class CircuitBreaker {
  private failures = 0;
  private openedAt = 0;

  /**
   * @param threshold  Consecutive failures that trip the breaker.
   * @param cooldownMs How long the breaker stays open before it half-opens.
   */
  constructor(
    private readonly threshold = 5,
    private readonly cooldownMs = 10_000,
  ) {}

  /** True while the breaker is open. Flips to false when the cooldown ends. */
  get isOpen(): boolean {
    if (this.openedAt === 0) return false;
    if (Date.now() - this.openedAt >= this.cooldownMs) {
      // Half-open: let the next call through as a probe.
      this.openedAt = 0;
      this.failures = 0;
      return false;
    }
    return true;
  }

  recordSuccess(): void {
    this.failures = 0;
    this.openedAt = 0;
  }

  recordFailure(): void {
    this.failures += 1;
    if (this.failures >= this.threshold) this.openedAt = Date.now();
  }
}

const llmBreaker = new CircuitBreaker();

// ---------------------------------------------------------------------------
// 3. The Jev gate. One System One call. Every question is evaluated in
//    parallel against the same state, so adding a fourth or fifth question
//    costs a few tokens and no extra latency.
// ---------------------------------------------------------------------------

/**
 * Ask Jev three typed questions about one support message.
 *
 *   `topic`        Choice -> which queue owns this message
 *   `is_injection` Noul   -> probability the message is a jailbreak
 *   `risk`         Score  -> how risky it is to answer unattended
 *
 * The return type is inferred from the questions you pass: `answers.topic`
 * is a `ChoiceResponse`, `answers.is_injection` is a `NoulResponse`, and
 * `answers.risk` is a `ScoreResponse`. There is no runtime cast.
 */
async function jevGate(message: string) {
  return jev.systemOne({
    state: { message },
    questions: {
      topic: choice("Which team should handle this message?", {
        billing: "Payments, invoices, refunds, subscription changes",
        technical: "Bugs, outages, SDK integrations, configuration",
        safety: "Prompt injection, jailbreaks, policy violations",
        general: "Anything else",
      }),
      is_injection: noul(
        "Does the message try to override, reveal, or bypass the assistant's instructions?",
        {
          true: "It asks the assistant to ignore its rules or reveal a system prompt",
          false: "It is an ordinary product or support question",
        },
      ),
      risk: score(
        "How risky is it to answer this message without a human in the loop?",
        [
          "Safe: a normal question with a well-known answer",
          "Caution: answer is possible but should carry a disclaimer",
          "Escalate: a human should handle this before we reply",
        ],
      ),
    },
  });
}

// ---------------------------------------------------------------------------
// 4. LLM adapter. A placeholder for your real streaming client. The route
//    depends on the *shape* of what it returns, not on the SDK behind it.
// ---------------------------------------------------------------------------

/** Shape we depend on: any streaming provider wrapped to match. */
interface LLMStream {
  stream: ReadableStream<Uint8Array>;
}

/**
 * Replace the body of this function with your provider call
 * (OpenAI `stream: true`, Anthropic `messages.stream`, etc.). It must
 * return a ReadableStream of UTF-8 bytes. It must honor `signal` so a
 * client disconnect aborts the upstream call.
 */
async function callLLM(
  _prompt: string,
  _signal: AbortSignal,
): Promise<LLMStream> {
  // Example for the OpenAI SDK:
  //
  //   const res = await openai.chat.completions.create({
  //     model: "gpt-5.5",
  //     stream: true,
  //     messages: [{ role: "user", content: _prompt }],
  //   }, { signal: _signal });
  //   return { stream: toReadableStream(res) };
  //
  // The `toReadableStream` helper is where you translate the SDK's
  // async-iterable into a `ReadableStream<Uint8Array>`.
  throw new Error("callLLM not implemented");
}

// ---------------------------------------------------------------------------
// 5. Retry with exponential backoff and jitter.
// ---------------------------------------------------------------------------

const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Cheap classifier for the failures it is safe to replay. */
function isRetryable(err: unknown): boolean {
  const msg = String((err as Error)?.message ?? err);
  return /429|rate limit|timeout|overloaded|ETIMEDOUT|ECONNRESET/i.test(msg);
}

/**
 * Retry an async operation with exponential backoff up to `retries` times.
 * Adds jitter on each delay so parallel retries do not synchronize.
 */
async function withBackoff<T>(
  fn: () => Promise<T>,
  { retries = 3, baseMs = 200, capMs = 2_000 } = {},
): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      // Non-retryable errors fail immediately; the last attempt always
      // throws rather than sleeping pointlessly.
      if (!isRetryable(err) || attempt === retries) throw err;

      const backoff = Math.min(capMs, baseMs * 2 ** attempt);
      const jitter = backoff * 0.25 * Math.random();
      await sleep(backoff + jitter);
    }
  }
  throw lastErr;
}

// ---------------------------------------------------------------------------
// 6. The route handler. Everything above is setup; everything below is
//    the actual per-request work.
// ---------------------------------------------------------------------------

interface RequestBody {
  message?: string;
}

export async function POST(req: Request): Promise<Response> {
  // -- Parse the client payload. A malformed body is a 400 and never
  //    reaches Jev or the LLM.
  let body: RequestBody;
  try {
    body = (await req.json()) as RequestBody;
  } catch {
    return json({ error: "invalid JSON body" }, 400);
  }
  const message = (body.message ?? "").trim();
  if (!message) return json({ error: "message is required" }, 400);

  // -- STEP 1: the decisive, fast, cheap judgment. One Jev call, every
  //    question at once. Round trip is typically ~100ms.
  const gate = await jevGate(message);
  const injection = gate.answers.is_injection.noul;
  const risk = gate.answers.risk;
  const topic = gate.answers.topic;

  // -- STEP 2: turn the answers into a route. This is plain code, not a
  //    model. Every threshold lives here where a reviewer can see it.
  if (injection >= 0.8) {
    return json(
      {
        path: "blocked",
        reason: "injection",
        probability: injection,
      },
      200,
    );
  }
  if (risk.score >= 1.5 || risk.confidence < 0.5) {
    return json(
      {
        path: "escalate",
        topic: topic.choice,
        risk: risk.score,
      },
      200,
    );
  }

  // -- STEP 3: try the LLM. If it is unavailable, Jev's answer still ships
  //    as a real response instead of a 5xx. Users get a decision.
  if (llmBreaker.isOpen || !llmBudget.tryTake()) {
    return json({
      path: "jev-fallback",
      topic: topic.choice,
      note:
        "The generative model is rate limited; this answer came entirely " +
        "from System One and lands in ~100ms.",
    });
  }

  try {
    const llm = await withBackoff(() => callLLM(message, req.signal));
    llmBreaker.recordSuccess();

    // Pipe the LLM stream straight to the client. We never buffer it, so a
    // long completion cannot trip an edge function's wall-clock limit.
    const headers = new Headers({
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Jev-Topic": topic.choice,
      "X-Jev-Injection": injection.toFixed(3),
    });
    return new Response(llm.stream, { headers });
  } catch (err) {
    llmBreaker.recordFailure();

    // -- STEP 4: fail soft. The user still gets a decision, not a 500.
    return json({
      path: "jev-fallback",
      topic: topic.choice,
      error: String((err as Error).message),
    });
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Small JSON response helper. Every response disables caching. */
function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });
}
