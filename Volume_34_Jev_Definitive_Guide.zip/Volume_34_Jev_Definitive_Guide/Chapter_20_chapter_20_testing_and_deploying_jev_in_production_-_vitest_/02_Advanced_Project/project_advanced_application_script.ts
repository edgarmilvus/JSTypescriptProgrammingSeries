/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/triage/route.ts
 * ────────────────────────────────────────────────────────────────────────────
 * Edge-deployed support-triage endpoint for a SaaS helpdesk.
 *
 * TWO-SPEED ARCHITECTURE
 *   Speed 1 — Jev returns typed decisions in ~100 ms on every request.
 *   Speed 2 — a generative LLM streams prose, but only when speed 1 says the
 *             ticket is urgent enough to justify the spend.
 *
 * RESILIENCE LAYERS (outermost first)
 *   1. TokenBucket    — per-isolate admission control.
 *   2. CircuitBreaker — stop hammering Jev while it is unhealthy.
 *   3. SDK retry      — jittered backoff honouring `Retry-After`.
 *   4. Degradation    — a routing default that escalates to a human.
 * ────────────────────────────────────────────────────────────────────────────
 */
import { NextRequest, NextResponse } from "next/server";
import { TypeSafeClient, choice, noul, score } from "@typesafe-ai/sdk";

/* ------------------------------------------------------------- edge runtime */
export const runtime = "edge";
export const preferredRegion = ["iad1", "fra1", "sin1"];

/* -------------------------------------------------------- resilience kernels */

/** Token bucket. One instance per edge isolate, so it is per-colo, not global. */
class TokenBucket {
  private tokens: number;
  private last = Date.now();
  constructor(private cap: number, private rps: number) { this.tokens = cap; }
  /** Consume a token, or return the milliseconds the caller should wait. */
  take(): true | number {
    const now = Date.now();
    this.tokens = Math.min(this.cap, this.tokens + ((now - this.last) / 1000) * this.rps);
    this.last = now;
    if (this.tokens >= 1) { this.tokens -= 1; return true; }
    return Math.ceil(((1 - this.tokens) / this.rps) * 1000);
  }
}

/** Circuit breaker: closed → open → half-open probe → closed. */
class CircuitBreaker {
  private fails = 0;
  private openedAt = 0;
  private probing = false;
  constructor(private limit = 5, private cooldownMs = 15_000) {}
  allow(): boolean {
    if (this.fails < this.limit) return true;
    if (Date.now() - this.openedAt < this.cooldownMs) return false;
    this.probing = true;
    return true;
  }
  succeed(): void { this.fails = 0; this.probing = false; }
  fail(): void {
    if (this.probing) { this.probing = false; this.openedAt = Date.now(); return; }
    if (++this.fails >= this.limit) this.openedAt = Date.now();
  }
}

const bucket = new TokenBucket(20, 10);
const breaker = new CircuitBreaker();

/* ----------------------------------------------------------- Jev decision core */

/** The SDK's own retry is jittered, honours `Retry-After`, and covers 408/429/5xx. */
const jev = new TypeSafeClient({
  apiKey: process.env.TYPESAFE_API_KEY,
  defaultModel: "jev-latest",
  timeout: 5_000,
  retry: { maxRetries: 3, backoffInitialMs: 250, backoffMaxMs: 4_000, backoffJitter: 0.35 },
});

/** Three atomic questions. Jev evaluates them in parallel against one state. */
const TRIAGE = {
  queue: choice("Which team should handle `message`?", {
    billing: "Charges, refunds, invoices, subscription changes.",
    technical: "Bugs, outages, integrations, API errors.",
    account: "Login, profile, permissions, security.",
  }),
  urgent: noul("Does `message` convey urgency or time-sensitivity?"),
  frustration: score("How frustrated does the customer appear?", [
    "Calm, matter-of-fact.",
    "Frustrated but civil.",
    "Very angry, strong language, threatening to churn.",
  ]),
};

/** The single shape every downstream consumer sees, resilient path or not. */
interface TriageDecision {
  queue: "billing" | "technical" | "account" | "human";
  urgency: number;
  frustration: number;
  source: "jev" | "degraded";
  model?: string;
}

/** Degradation default. It is a *routing* decision, never a fabricated answer. */
const DEGRADED: TriageDecision = {
  queue: "human", urgency: 0.5, frustration: 1, source: "degraded",
};

/** Run the Jev decision, honouring bucket + breaker, degrading safely. */
async function decide(message: string): Promise<TriageDecision> {
  if (!breaker.allow()) return DEGRADED;
  const gate = bucket.take();
  if (gate !== true) {
    await new Promise((r) => setTimeout(r, Math.min(gate, 500)));
    return DEGRADED;
  }
  try {
    const res = await jev.systemOne({ state: { message }, questions: TRIAGE });
    breaker.succeed();
    return {
      queue: res.answers.queue.choice as TriageDecision["queue"],
      urgency: res.answers.urgent.noul,
      frustration: res.answers.frustration.score,
      source: "jev",
      model: res.model,
    };
  } catch (err) {
    breaker.fail();
    console.error(JSON.stringify({ evt: "jev.degraded", at: Date.now(), err: String(err) }));
    return DEGRADED;
  }
}

/* ------------------------------------------------------ generative speed-2 path */

/** Open an upstream SSE stream. Called only when the Jev decision warrants it. */
async function streamSummary(message: string): Promise<ReadableStream<Uint8Array>> {
  const upstream = await fetch(`${process.env.LLM_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${process.env.LLM_API_KEY}`,
    },
    body: JSON.stringify({
      model: process.env.LLM_MODEL,
      stream: true,
      messages: [{ role: "user", content: `Summarise in one sentence: ${message}` }],
    }),
  });
  if (!upstream.ok || !upstream.body) throw new Error(`upstream ${upstream.status}`);
  return upstream.body;
}

/** Forward a readable stream into a controller, chunk by chunk. */
async function pipe(
  src: ReadableStream<Uint8Array>,
  dst: ReadableStreamDefaultController<Uint8Array>,
): Promise<void> {
  const reader = src.getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) return;
    dst.enqueue(value);
  }
}

/* -------------------------------------------------------------- route handler */

export async function POST(req: NextRequest): Promise<Response> {
  const { message } = (await req.json()) as { message?: string };
  if (!message) return NextResponse.json({ error: "message required" }, { status: 422 });

  const decision = await decide(message);
  const encoder = new TextEncoder();

  const body = new ReadableStream<Uint8Array>({
    async start(ctrl) {
      ctrl.enqueue(encoder.encode(JSON.stringify({ decision }) + "\n"));
      if (decision.urgency >= 0.75) {
        try {
          await pipe(await streamSummary(message), ctrl);
        } catch {
          ctrl.enqueue(encoder.encode(JSON.stringify({ summaryError: true }) + "\n"));
        }
      }
      ctrl.close();
    },
  });

  return new Response(body, {
    headers: {
      "content-type": "application/x-ndjson",
      "cache-control": "no-store",
      "x-triage-source": decision.source,
    },
  });
}
