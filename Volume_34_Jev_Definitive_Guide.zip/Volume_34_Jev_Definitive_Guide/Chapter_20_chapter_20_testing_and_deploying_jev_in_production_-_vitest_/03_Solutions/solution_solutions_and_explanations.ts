/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// triage.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";
import {
  choice,
  noul,
  score,
  RateLimitError,
} from "@typesafe-ai/sdk";
import type {
  SystemOneResult,
  ChoiceResponse,
  ScoreResponse,
  NoulResponse,
} from "@typesafe-ai/sdk";

import { triage, type TriageClient, type TriageDeps } from "../src/triage";

// ---- 1. Build the questions map with the REAL SDK factories, so the mock
//         we build later must satisfy the real inferred types.
const questions = {
  department: choice("Which team should handle this?", {
    billing: "Charges, invoices, refunds",
    technical: "Bugs, outages, integrations",
    account: "Login, profile, permissions",
  }),
  frustration: score("How frustrated is the customer?", [
    "Calm, just stating facts",
    "Frustrated but civil",
    "Very angry, strong language",
  ]),
  refund_requested: noul("Does the customer explicitly request a refund?"),
} as const;

type TriageQuestions = typeof questions;
type TriageResult = SystemOneResult<TriageQuestions>;

// ---- 2. Fixture builders. Each returns a REAL SystemOneResult<TriageQuestions>,
//         so TypeScript refuses to compile any fixture that drifts from the SDK.
function fixture(overrides: {
  departmentChoice?: keyof typeof questions.department.criteria;
  departmentProbs?: Partial<Record<"billing" | "technical" | "account", number>>;
  departmentConfidence?: number;
  frustrationScore?: number;
  frustrationProbs?: Partial<Record<"0" | "1" | "2", number>>;
  frustrationConfidence?: number;
  refundNoul?: number;
}): TriageResult {
  const billing = overrides.departmentProbs?.billing ?? 0.5;
  const technical = overrides.departmentProbs?.technical ?? 0.3;
  const account = overrides.departmentProbs?.account ?? 0.2;

  const fScore = overrides.frustrationScore ?? 0.5;
  const fProbabilities = overrides.frustrationProbs ?? { "0": 0.5, "1": 0.5, "2": 0.0 };

  const department: ChoiceResponse<typeof questions.department.criteria> = {
    type: "choice",
    choice: overrides.departmentChoice ?? "billing",
    probabilities: { billing, technical, account },
    confidence: overrides.departmentConfidence ?? 0.9,
  };

  const frustration: ScoreResponse<readonly [string, string, string]> = {
    type: "score",
    score: fScore,
    legend: {
      0: "Calm, just stating facts",
      1: "Frustrated but civil",
      2: "Very angry, strong language",
    },
    probabilities: fProbabilities,
    confidence: overrides.frustrationConfidence ?? 0.85,
  };

  const refund_requested: NoulResponse = {
    type: "noul",
    noul: overrides.refundNoul ?? 0.1,
  };

  return {
    model: "jev-latest",
    answers: { department, frustration, refund_requested },
    usage: { input_tokens: 312, output_tokens: 48 },
  };
}

// ---- 3. A TriageClient whose systemOne we can script per-test. The point is
//         the fake is small and typed, not that it re-implements the SDK.
function makeFakeClient(
  handler: (req: Parameters<TriageClient["systemOne"]>[0]) => Promise<TriageResult>,
): TriageClient {
  return { systemOne: vi.fn(handler) };
}

// ---- 4. Small, opinionated deps used across tests.
let nowValue: Date;
beforeEach(() => {
  nowValue = new Date("2026-01-01T00:00:00Z");
});
const frozenNow = () => nowValue;

describe("triage()", () => {
  // -------------------------------------------------------------------------
  // (a) Clear case → billing handler is called.
  // -------------------------------------------------------------------------
  it("routes a confident billing ticket to the billing handler", async () => {
    const client = makeFakeClient(async () =>
      fixture({
        departmentChoice: "billing",
        departmentProbs: { billing: 0.92, technical: 0.06, account: 0.02 },
        departmentConfidence: 0.86,
        frustrationScore: 0.2,
        refundNoul: 0.05,
      }),
    );

    // Spy on the downstream routing the module is expected to invoke. If the
    // production module exports callable handlers, we wrap them; otherwise we
    // assert on the returned discriminated union.
    const result = await triage("I was charged twice.", { client, now: frozenNow });

    expect(result).toEqual({ kind: "billing", refundLikely: false });
    expect(client.systemOne).toHaveBeenCalledTimes(1);
  });

  // -------------------------------------------------------------------------
  // (b) Low confidence → review path, and the underlying handler is NOT called.
  //     This is the whole reason ChoiceResponse.confidence exists.
  // -------------------------------------------------------------------------
  it("routes to review when department confidence is below the floor", async () => {
    const client = makeFakeClient(async () =>
      fixture({
        departmentChoice: "billing",
        departmentProbs: { billing: 0.41, technical: 0.38, account: 0.21 },
        departmentConfidence: 0.21,
      }),
    );

    const result = await triage("Something about payments maybe?", {
      client,
      now: frozenNow,
      confidenceFloor: 0.5,
    });

    expect(result.kind).toBe("review");
    if (result.kind === "review") {
      expect(result.reason).toMatch(/confidence/i);
    }
  });

  // -------------------------------------------------------------------------
  // (c) Speculative ignore: refund says .94 but department is technical → the
  //     refund signal must not leak into the technical decision path.
  // -------------------------------------------------------------------------
  it("ignores the refund signal on the technical path", async () => {
    const client = makeFakeClient(async () =>
      fixture({
        departmentChoice: "technical",
        departmentProbs: { billing: 0.05, technical: 0.9, account: 0.05 },
        departmentConfidence: 0.88,
        refundNoul: 0.94, // strongly present, but irrelevant to technical routing
      }),
    );

    // Spy on the refund handler to ensure it is never invoked on this path.
    const refundSpy = vi.fn();
    const result = await triage("Login is broken on Safari.", {
      client,
      now: frozenNow,
      // The production module accepts a deps bag; a `onRefund` hook lets us
      // observe whether the refund signal was consumed.
      // (Add `onRefund` to TriageDeps in triage.ts to make this assertion possible.)
      ...({ onRefund: refundSpy } as Partial<TriageDeps>),
    });

    expect(result.kind).toBe("technical");
    if (result.kind === "technical") {
      // The code contract: technical path always reports refundLikely: false,
      // even though the model returned 0.94.
      expect(result.refundLikely).toBe(false);
    }
    expect(refundSpy).not.toHaveBeenCalled();
  });

  // -------------------------------------------------------------------------
  // (d) Score normalisation: 1.4 on a 3-level rubric must equal 2.8 on a
  //     6-level rubric after division by (len(criteria) - 1).
  // -------------------------------------------------------------------------
  it("normalises score against the rubric length, not a magic number", async () => {
    const threeLevel = makeFakeClient(async () =>
      fixture({
        departmentChoice: "account",
        departmentConfidence: 0.9,
        frustrationScore: 1.4, // 1.4 / 2 = 0.70
      }),
    );
    const sixLevel = makeFakeClient(async () =>
      fixture({
        departmentChoice: "account",
        departmentConfidence: 0.9,
        // For a 6-level rubric, top level is 5; 2.8 / 5 = 0.56 is NOT the same.
        // The correct analogue of 1.4/2 is 3.5/5 = 0.70.
        frustrationScore: 3.5,
      }),
    );

    // Both cases were chosen so that the normalised value matches (0.70).
    const a = await triage("ticket a", { client: threeLevel, now: frozenNow });
    const b = await triage("ticket b", { client: sixLevel, now: frozenNow });

    // We assert on the derived priority band, which must be identical.
    // Adjust the accessor name to match triage.ts's exported surface.
    const aBand = (a as any).priorityBand ?? (a as any).band;
    const bBand = (b as any).priorityBand ?? (b as any).band;

    // If your module doesn't expose a band, expose one — this assertion *is*
    // the reason the exercise asked for this test.
    if (aBand !== undefined) {
      expect(aBand).toBe(bBand);
    }
  });

  // -------------------------------------------------------------------------
  // (e) Error propagation: a typed RateLimitError must be handled explicitly.
  //     The code you own decides whether to retry, surface, or fall back.
  // -------------------------------------------------------------------------
  it("surfaces a typed RateLimitError without swallowing it", async () => {
    const client = makeFakeClient(async () => {
      throw new RateLimitError(
        429,
        { error: "rate_limited" },
        new Headers(),
        "rate limited",
      );
    });

    await expect(
      triage("hello", { client, now: frozenNow }),
    ).rejects.toBeInstanceOf(RateLimitError);
  });

  // -------------------------------------------------------------------------
  // (f) Contract test: a representative SystemOneResult must satisfy the
  //     shapes the code relies on, including probabilities that sum to 1.0.
  // -------------------------------------------------------------------------
  it("locks in the SDK's answer shapes with a runtime validator", () => {
    const result = fixture({
      departmentChoice: "billing",
      departmentProbs: { billing: 0.84, technical: 0.159, account: 0.001 },
      departmentConfidence: 0.82,
      frustrationScore: 1.035,
      frustrationProbs: { "0": 0.05, "1": 0.87, "2": 0.08 },
      frustrationConfidence: 0.84,
      refundNoul: 0.94,
    });

    const approx = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) < eps;

    // The contract we actually depend on: the SDK returns every field named
    // in the docs, and every distribution sums to 1.0.
    const dists = [
      Object.values(result.answers.department.probabilities),
      Object.values(result.answers.frustration.probabilities).map(Number),
    ];
    for (const d of dists) {
      const sum = d.reduce((a, b) => a + b, 0);
      expect(approx(sum, 1.0)).toBe(true);
    }

    // Every Score response carries a legend and a per-level probabilities map
    // whose keys must align.
    const legendKeys = Object.keys(result.answers.frustration.legend).sort();
    const probKeys = Object.keys(result.answers.frustration.probabilities).sort();
    expect(probKeys).toEqual(legendKeys);

    // Noul has no `confidence` field — verify the contract that it does not
    // silently start returning one, which would indicate an SDK drift.
    expect(Object.keys(result.answers.refund_requested).sort()).toEqual([
      "noul",
      "type",
    ]);
  });
});

// -----------------------------------------------------------------------------
// vitest.config.ts (excerpt)
//
// export default defineConfig({
//   test: {
//     environment: "node",
//     coverage: {
//       provider: "v8",
//       include: ["src/triage.ts"],
//       thresholds: { "src/triage.ts": { lines: 90, branches: 90 } },
//     },
//   },
// });
//
// Why branch coverage matters more than line coverage here: two lines reading
// `if (c < 0.5) return "review";` can be fully "line covered" while the
// `review` branch is never executed. Decision engines fail at their *branches*,
// so line coverage alone is a false sense of safety.
// -----------------------------------------------------------------------------
