/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.tsx
// Description: Solutions and Explanations
// ==========================================

// TriageConsole.tsx
import React, { useCallback, useRef, useState } from "react";
import {
  choice,
  score,
  noul,
  RateLimitError,
  UnprocessableEntityError,
  APITimeoutError,
  APIConnectionError,
} from "@typesafe-ai/sdk";
import type {
  TypeSafeClient,
  SystemOneResult,
  ChoiceResponse,
  ScoreResponse,
  NoulResponse,
} from "@typesafe-ai/sdk";

// ---- Your questions map. Same shape as the triage engine's.
const questions = {
  department: choice("Which team should handle this?", {
    billing: "Charges, invoices, refunds",
    technical: "Bugs, outages, integrations",
    account: "Login, profile, permissions",
  }),
  frustration: score("How frustrated is the customer?", [
    "Calm, just stating facts",
    "Frustrated but civil",
    "Very angry, strong language",
  ]),
  refund_requested: noul("Does the customer explicitly request a refund?"),
} as const;

type TriageQuestions = typeof questions;
type TriageAnswers = SystemOneResult<TriageQuestions>["answers"];

export type TriageDegradedReason =
  | "rate-limited"
  | "timeout"
  | "connection"
  | "unavailable";

export type TriageRenderState =
  | { kind: "idle" }
  | { kind: "pending"; startedAtMs: number; abort: () => void }
  | { kind: "decided"; answers: TriageAnswers }
  | {
      kind: "degraded";
      reason: TriageDegradedReason;
      // Only ever populated if a resilience layer returned a cached answer.
      // The UI must not confuse this with a live `decided` state.
      cachedAnswer?: SystemOneResult<unknown>;
      cacheAgeMs?: number;
    };

export interface TriageConsoleProps {
  client: TypeSafeClient;
  model?: string;
  confidenceFloor?: number; // default 0.5
  onDecision?: (decision: TriageRenderState) => void;
}

// ---------------------------------------------------------------------------
// Typed error → copy. Exhaustive switch on the SDK's typed errors. Anything
// that falls off the end renders the generic "unavailable" copy. No string
// matching, no stack traces, no raw error.message.
// ---------------------------------------------------------------------------
function degradedReason(err: unknown): TriageDegradedReason {
  if (err instanceof RateLimitError) return "rate-limited";
  if (err instanceof APITimeoutError) return "timeout";
  if (err instanceof APIConnectionError) return "connection";
  if (err instanceof UnprocessableEntityError) return "unavailable";
  return "unavailable";
}

function degradedCopy(reason: TriageDegradedReason): string {
  switch (reason) {
    case "rate-limited":
      return "We're at capacity right now. You can retry in a moment, or queue this ticket.";
    case "timeout":
      return "The classifier took too long. Your ticket is untouched.";
    case "connection":
      return "We couldn't reach the classifier. Check your connection and try again.";
    case "unavailable":
      return "The form had a problem we couldn't send. Check the message and try again.";
  }
}

// ---------------------------------------------------------------------------
// Component.
// ---------------------------------------------------------------------------
export function TriageConsole({
  client,
  model,
  confidenceFloor = 0.5,
  onDecision,
}: TriageConsoleProps): JSX.Element {
  const [text, setText] = useState("");
  const [state, setState] = useState<TriageRenderState>({ kind: "idle" });

  // A ref guards against the classic abort race: a request whose promise
  // resolves *after* we aborted would otherwise flip state back to "decided".
  const requestIdRef = useRef(0);

  const classify = useCallback(async () => {
    const thisRequestId = ++requestIdRef.current;
    const controller = new AbortController();

    setState({
      kind: "pending",
      startedAtMs: Date.now(),
      abort: () => controller.abort(),
    });

    try {
      const result = await client.systemOne(
        { state: text, questions, model: model as any },
        { signal: controller.signal },
      );

      // A late response after a cancel must NOT overwrite state.
      if (thisRequestId !== requestIdRef.current) return;

      const next: TriageRenderState = {
        kind: "decided",
        answers: result.answers as unknown as TriageAnswers,
      };
      setState(next);
      onDecision?.(next);
    } catch (err) {
      if (thisRequestId !== requestIdRef.current) return;
      const next: TriageRenderState = {
        kind: "degraded",
        reason: degradedReason(err),
      };
      setState(next);
      onDecision?.(next);
    }
  }, [client, model, text, onDecision]);

  const cancel = useCallback(() => {
    if (state.kind === "pending") state.abort();
    // Return to idle regardless: the requestIdRef guard handles late resolves.
    setState({ kind: "idle" });
  }, [state]);

  return (
    <div className="triage-console">
      <label htmlFor="triage-input">Customer message</label>
      <textarea
        id="triage-input"
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={5}
      />

      <div className="triage-actions">
        <button
          onClick={classify}
          disabled={state.kind === "pending" || text.trim().length === 0}
        >
          Classify
        </button>
        {state.kind === "pending" && (
          <button onClick={cancel} aria-label="Cancel classification">
            Cancel
          </button>
        )}
      </div>

      {state.kind === "pending" && (
        <p role="status">Classifying…</p>
      )}

      {state.kind === "degraded" && (
        <div role="status" className="degraded-banner">
          {degradedCopy(state.reason)}
          {state.cacheAgeMs !== undefined && (
            <p className="stale-banner">
              Showing a recent answer from cache (
              {Math.round(state.cacheAgeMs / 1000)}s old) — refresh for the latest.
            </p>
          )}
        </div>
      )}

      {state.kind === "decided" && (
        <DecidedView
          answers={state.answers}
          confidenceFloor={confidenceFloor}
          // If a resilience layer is in play, its wrapper must set fromCache.
          // Here, a decided state is always "live" — cached answers land in
          // the `degraded` arm so that they can never be treated as fresh.
          disabledConfirm={false}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Decided view. Three sub-blocks:
//   1. Department chip + numeric confidence badge + runner-up line.
//   2. Frustration gauge with visible level boundaries and confidence.
//   3. Refund Noul as a probability slider (NOT a confidence chip — Noul
//      responses have no confidence field, and the UI honors that).
// ---------------------------------------------------------------------------
function DecidedView({
  answers,
  confidenceFloor,
  disabledConfirm,
}: {
  answers: TriageAnswers;
  confidenceFloor: number;
  disabledConfirm: boolean;
}) {
  const dept = answers.department as ChoiceResponse<typeof questions.department.criteria>;
  const frustration = answers.frustration as ScoreResponse<
    readonly [string, string, string]
  >;
  const refund = answers.refund_requested as NoulResponse;

  const [runnerUp, runnerUpProb] = topRunnerUp(dept);
  const lowConfidence = dept.confidence < confidenceFloor;
  const topProb = dept.probabilities[dept.choice as keyof typeof dept.probabilities];

  const topLevel = frustration.legend[2] ? 2 : 1; // derive from legend, not magic
  const normalised = frustration.score / topLevel;

  // Distinguish "concentrated on one level" from "split between two".
  const isSplit = Object.values(frustration.probabilities)
    .map(Number)
    .filter((p) => p > 0.2).length > 1;

  return (
    <div className="decided">
      <div className="row">
        <span className="label">Department</span>
        <span className="chip">{dept.choice}</span>
        <span
          className={`badge ${lowConfidence ? "badge-low" : ""}`}
          aria-label={`Department confidence ${(dept.confidence * 100).toFixed(0)} percent${
            lowConfidence ? ", low confidence" : ""
          }`}
        >
          {dept.confidence.toFixed(2)}
        </span>
        {lowConfidence && <span className="text-low-confidence">low confidence</span>}
      </div>
      {lowConfidence && (
        <p className="runner-up">
          Also considered: <strong>{String(runnerUp)}</strong> (
          {(runnerUpProb * 100).toFixed(1)}%)
        </p>
      )}

      <div className="row">
        <span className="label">Frustration</span>
        <div
          className="gauge"
          role="meter"
          aria-valuemin={0}
          aria-valuemax={1}
          aria-valuenow={normalised}
          aria-label={`Frustration gauge, ${(normalised * 100).toFixed(0)} percent of scale`}
        >
          <div className="gauge-fill" style={{ width: `${normalised * 100}%` }} />
          {/* Level boundaries drawn from legend. */}
          {Object.entries(frustration.legend).map(([k, label]) => (
            <div
              key={k}
              className="gauge-tick"
              style={{ left: `${(Number(k) / topLevel) * 100}%` }}
              title={String(label)}
            />
          ))}
        </div>
        <span className="badge" aria-label={`Frustration confidence ${(frustration.confidence * 100).toFixed(0)} percent`}>
          {frustration.confidence.toFixed(2)}
        </span>
      </div>
      <p className="gauge-note">
        {isSplit ? "Model split across two levels" : "Model concentrated on one level"} — score{" "}
        {frustration.score.toFixed(2)} / {topLevel}
      </p>

      <div className="row">
        <span className="label">Refund requested</span>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={refund.noul}
          readOnly
          aria-label={`Probability the customer requested a refund, ${(refund.noul * 100).toFixed(0)} percent`}
        />
        <span>{refund.noul.toFixed(2)}</span>
      </div>

      <button disabled={disabledConfirm}>Confirm decision</button>
    </div>
  );
}

function topRunnerUp(
  dept: ChoiceResponse<typeof questions.department.criteria>,
): [string, number] {
  const entries = Object.entries(dept.probabilities)
    .filter(([k]) => k !== dept.choice)
    .sort(([, a], [, b]) => b - a);
  return [entries[0][0], entries[0][1]];
}
