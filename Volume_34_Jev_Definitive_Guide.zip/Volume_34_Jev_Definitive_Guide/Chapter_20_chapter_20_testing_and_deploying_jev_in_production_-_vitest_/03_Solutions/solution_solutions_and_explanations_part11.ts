/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

// postmortem/metrics.ts — the five metrics from requirement 7, expressed as a
// typed surface. Some are counters, one is a gauge, one is a histogram. The
// shape of the surface is the point: a reviewer can see, at a glance, which
// signals are rate-shaped and which are point-in-time.

import type { Metrics } from "../src/resilience";

export interface PostmortemSurface extends Metrics {
  // 1. COUNTER. Alerts on the *ratio*, not the raw rate.
  //    Alert: rate(upstream_429)/rate(upstream_total) > 0.05 for 60s.
  increment(name: "upstream_429", by?: number): void;
  increment(name: "upstream_total", by?: number): void;

  // 2. GAUGE. Point-in-time queue depth summed across live callers.
  //    Alert: current value > 0.5 * maxQueueDepth for 30s.
  gauge(name: "queue_depth_current", value: number): void;

  // 3. COUNTER, ONE PER TRANSITION (not per poll).
  //    Alert: rate(circuit_state_changes) > 0 for 5m — the breaker should
  //    be stable, not thrashing.
  increment(name: "circuit_state_changes", by?: number): void;

  // 4. HISTOGRAM. Tail latency of the successful path.
  //    Alert: p99 > 500ms for 60s. A *histogram* because the mean hides
  //    exactly the tail that reaches users.
  observe(name: "upstream_latency_ms", value: number): void;

  // 5. COUNTER of "attempts" per logical call. This is the amplification
  //    signal: the field that turned 400/s into 3,600/s at 19:04:30.
  increment(name: "attempts_total", by?: number): void;
}
