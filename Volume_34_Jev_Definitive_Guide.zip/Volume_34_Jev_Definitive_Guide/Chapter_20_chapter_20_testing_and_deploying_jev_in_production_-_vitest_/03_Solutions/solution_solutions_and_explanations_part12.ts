/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

// postmortem/arithmetic.ts — the numbers argued in the write-up, expressed
// as a small, tested calculator so a reviewer can re-run and challenge them.

export function fleetBurst(config: {
  replicas: number;
  tokensPerBurst: number;
  refillPerSecond: number;
  windowSeconds: number;
}): number {
  // Fleet-wide burst over `windowSeconds` = replicas * (burst + refill * window)
  // (per-replica buckets do not share tokens; this is the coordination gap).
  return config.replicas * (config.tokensPerBurst + config.refillPerSecond * config.windowSeconds);
}

export function maxAttemptsPerLogicalCall(maxRetries: number): number {
  return maxRetries + 1; // one initial attempt + maxRetries retries
}

export function aggregateAmplification(args: {
  inboundRps: number;
  attemptsPerLogicalCall: number;
  failureFraction: number;
  durationSeconds: number;
}): number {
  // Every logical call that failed and retried contributes
  // (attemptsPerLogicalCall - 1) * failureFraction extra HTTP calls.
  const logical = args.inboundRps * args.durationSeconds;
  const failing = logical * args.failureFraction;
  const extra = failing * (args.attemptsPerLogicalCall - 1);
  return logical + extra;
}

// Worked numbers used in the postmortem:
//
//   fleetBurst({replicas: 6, tokensPerBurst: 60, refillPerSecond: 20, windowSeconds: 1})
//     = 6 * (60 + 20) = 480 in the first second of the surge.
//     That is 40% of the 1,200 rpm budget burned in one second by six
//     replicas that each think they are the only caller.
//
//   maxAttemptsPerLogicalCall(2) = 3.
//
//   aggregateAmplification({inboundRps: 400, attemptsPerLogicalCall: 3,
//     failureFraction: 1.0, durationSeconds: 1})
//     = 400 + 400*2 = 1,200 attempts/second fleet-wide during the peak.
//     With one retry of that on 429, the second wave is another 1,200,
//     and the third wave is the SDK's terminal failure — three times the
//     offered load, in the exact window the upstream is already saturated.
