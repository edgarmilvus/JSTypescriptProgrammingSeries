/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

// postmortem/future-incident.ts — the fictional amplification story for the
// adversarial review. Kept as a written narrative next to runnable code so
// the counterfactual can be updated when configs change.

export const FICTIONAL_FUTURE_INCIDENT = `
Timeline (hypothetical, if maxRetries=5 & backoffMaxMs=30_000 shipped as-is):

03:00:00  Partner event again. 400/s inbound to 6 replicas.
03:00:02  Upstream returns 429 to every replica simultaneously.
          Each replica's SDK now performs up to 3 initial retries within
          500ms-5s of backoff (with 0.25 jitter), and 2 more within
          5s-30s of backoff.
03:00:10  Six replicas * 400 rps * 3 early retries = ~7,200 attempts/sec.
          The upstream 429s all of them, but the retry hint is 30s.
03:00:40  The 4th and 5th retries fire on all replicas, nearly synchronised
          because a 30s cap compresses the jitter window into ~7.5s.
03:01:00  6 replicas * 400 rps * 2 late retries = another ~4,800 attempts
          stacked on top of still-arriving initial attempts.
03:02:00  The endpoint's own autoscaler is now chasing a rate it cannot
          satisfy because the retry storm is proportional to the *inflight*
          fleet, not to useful work. Its cold start is 90s.
03:03:30  Recovery begins only when the partner event subsides.
`;

export interface ReviewComment {
  verdict: "request-changes";
  prose: string;
  proposedAsymmetricPolicy: {
    httpStatuses: ReadonlySet<number>;
    maxRetriesFor: {
      rateLimited: number; // lower
      serverTransient: number; // higher
    };
    observabilitySignal: string;
  };
}

export const REVIEW: ReviewComment = {
  verdict: "request-changes",
  prose: `I don't want to reject the shape of this — more retries on a
transient single-replica failure or a brief 529 is exactly right, and I agree
we should ride those out. But 429 is a different beast, because our budget is
shared across six replicas: retrying on it multiplies pressure on the layer
that is already telling us to stop. I would take an asymmetric approach:
keep an elevated retry budget for 500/502/503/504/529 (transient, per-replica,
usually resolved by a single backoff), and cap 429 at maxRetries: 1 with
respectRetryAfter: true so the server's own Retry-After is the authority.
The signal I would watch to close the loop is attempts_total / upstream_total
per replica — a ratio, not a rate. If it climbs above ~1.5 while
upstream_429 / upstream_total is above 5%, the retry policy is amplifying,
not absorbing.`,
  proposedAsymmetricPolicy: {
    httpStatuses: new Set([429, 500, 501, 502, 503, 504, 529]),
    maxRetriesFor: { rateLimited: 1, serverTransient: 4 },
    observabilitySignal: "attempts_total / upstream_total, per replica",
  },
};
