/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// edge/adapter.ts — the shared, runtime-neutral module. No node:*, no process.
import { TypeSafeClient } from "@typesafe-ai/sdk";

export interface EdgeEnv {
  readonly apiKey: string;
  readonly baseURL?: string;
  readonly defaultModel?: string;
  readonly fetchImpl?: typeof fetch;
}

export interface JevAdapter {
  readonly client: TypeSafeClient;
  readonly env: EdgeEnv;
  healthcheck(): boolean;
}

export function createJevAdapter(env: EdgeEnv): JevAdapter {
  if (!env.apiKey || env.apiKey.trim().length === 0) {
    throw new Error("JevAdapter: missing apiKey in EdgeEnv");
  }

  // The SDK's own precedence is: explicit config > env var > default. By
  // passing values explicitly here, we never depend on runtime-specific
  // environment lookups inside the SDK.
  const client = new TypeSafeClient({
    apiKey: env.apiKey,
    baseURL: env.baseURL, // undefined → SDK falls back to https://api.typesafe.ai
    // Resolving the alias at call time is deliberate: `jev-latest` tracks
    // upstream version bumps and is the SDK's documented default. If you ever
    // tune confidence thresholds against a specific version (e.g. jev-1.13.0)
    // you must pin the versioned ID instead, because the alias can move under
    // you silently between deploys.
    defaultModel: env.defaultModel ?? "jev-latest",
    // Providing fetch explicitly is cheap insurance on runtimes where the
    // global could be shadowed by a bundler or polyfill.
    fetch: env.fetchImpl,
    // timeout is set here as a *default*; callers can override per call via
    // RequestOptions.timeout.
    timeout: 3_000,
  });

  return {
    client,
    env,
    // The health check is intentionally cheap: it verifies the client is
    // *constructible* with the injected environment, and never calls the API.
    // A health check that hits the API couples your readiness to a
    // third-party's uptime; that coupling is sometimes acceptable, but only
    // when chosen on purpose.
    healthcheck() {
      return client instanceof TypeSafeClient ? true : false;
    },
  };
}

// ---------------------------------------------------------------------------
// edge/factories.ts — one small factory per runtime. This is the ONLY place
// that reads runtime-provided objects. The shared module above knows nothing
// about Cloudflare, Vercel, or Deno.
// ---------------------------------------------------------------------------

export function fromCloudflare(
  env: Record<string, string | undefined>,
): EdgeEnv {
  // Cloudflare Workers provide a global `fetch`; the SDK's default handling
  // is fine, so we do not pass fetchImpl explicitly here. This asymmetry
  // with `fromDeno` is deliberate and documented.
  return {
    apiKey: env.TYPESAFE_API_KEY ?? "",
    baseURL: env.TYPESAFE_BASE_URL,
    defaultModel: env.TYPESAFE_DEFAULT_MODEL,
  };
}

export function fromVercel(env: Record<string, string | undefined>): EdgeEnv {
  // Vercel Edge Functions expose environment variables on `process.env`
  // (polyfilled) and on the `env` object passed to the handler.
  return {
    apiKey: env.TYPESAFE_API_KEY ?? "",
    baseURL: env.TYPESAFE_BASE_URL,
    defaultModel: env.TYPESAFE_DEFAULT_MODEL,
  };
}

export function fromDeno(denoEnv: {
  get(key: string): string | undefined;
}): EdgeEnv {
  // On Deno Deploy we pass `fetch` explicitly, because Deno allows the
  // global to be shadowed (and some libraries do shadow it). Passing it
  // explicitly pins the transport to the runtime's own fetch.
  return {
    apiKey: denoEnv.get("TYPESAFE_API_KEY") ?? "",
    baseURL: denoEnv.get("TYPESAFE_BASE_URL"),
    defaultModel: denoEnv.get("TYPESAFE_DEFAULT_MODEL"),
    fetchImpl: fetch,
  };
}
