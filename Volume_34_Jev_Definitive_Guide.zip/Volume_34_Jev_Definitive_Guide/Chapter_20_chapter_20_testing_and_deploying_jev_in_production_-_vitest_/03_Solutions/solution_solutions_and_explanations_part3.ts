/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// edge/worker.ts — Cloudflare Workers entry point.
import { createJevAdapter, fromCloudflare } from "./adapter";

export default {
  async fetch(
    request: Request,
    env: Record<string, string | undefined>,
  ): Promise<Response> {
    // Cold-start discipline: Workers reuse isolates, and module-scope
    // construction runs on every cold start whether or not that isolate
    // actually serves a Jev call. Construct inside the handler (or behind a
    // lazily-memoised getClient()) so the cost is only paid on the first
    // real request in each isolate.
    const adapter = createJevAdapter(fromCloudflare(env));

    if (!adapter.healthcheck()) {
      return new Response("not ready", { status: 503 });
    }

    // The adapter accepts the JSON body already parsed by the caller. We do
    // not parse inside the adapter: parsing at the boundary would either
    // double-consume the ReadableStream or (worse) leave the caller with an
    // already-used body. Keep parsing exactly once, at the edge, and pass the
    // plain object through.
    const body = (await request.json()) as {
      state: unknown;
      questions: Record<string, unknown>;
    };

    const { answers } = await adapter.client.systemOne({
      state: body.state,
      questions: body.questions as any,
    });

    return Response.json({ answers });
  },
};
