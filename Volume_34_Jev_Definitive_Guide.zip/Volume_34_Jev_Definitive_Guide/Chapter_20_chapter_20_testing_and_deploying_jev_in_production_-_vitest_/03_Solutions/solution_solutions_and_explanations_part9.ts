/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// src/resilience.ts
import {
  TypeSafeClient,
  RateLimitError,
  InternalServerError,
  UnprocessableEntityError,
  APITimeoutError,
  APIConnectionError,
} from "@typesafe-ai/sdk";
import type { SystemOneResult } from "@typesafe-ai/sdk";

export type ResilienceMode = "live" | "queued" | "degraded" | "circuit-open";

export interface ResilienceConfig {
  tokensPerBurst: number;
  refillPerSecond: number;
  maxQueueDepth: number;
  enqueueTimeoutMs: number;
  circuitFailureWindowMs: number;
  circuitTripThreshold: number;
  circuitCooldownMs: number;
  backoffBaseMs: number;
  backoffMaxMs: number;
  cacheTtlMs: number;
}

export const DEFAULT_CONFIG: ResilienceConfig = {
  // Against a documented 1,200 rpm limit (~20 rps), a per-replica burst of 40
  // tokens with a 20 rps refill keeps a single replica inside its share
  // while smoothing short spikes. (See Exercise 5 for the coordination
  // discussion — a per-replica bucket is not a fleet-wide rate limit.)
  tokensPerBurst: 40,
  refillPerSecond: 20,
  maxQueueDepth: 500,
  enqueueTimeoutMs: 2_000, // tail budget: agents click again after ~2s
  circuitFailureWindowMs: 30_000,
  circuitTripThreshold: 5,
  circuitCooldownMs: 10_000,
  backoffBaseMs: 500,
  backoffMaxMs: 5_000,
  cacheTtlMs: 60_000, // moderation: a 60s-old answer is usually still true
};

export interface Metrics {
  increment(name: string, by?: number): void;
  gauge(name: string, value: number): void;
}

export interface Cache<T> {
  get(key: string): { value: T; storedAtMs: number } | undefined;
  set(key: string, value: T, storedAtMs: number): void;
}

export interface Clock {
  now(): number;
  random(): number;
  sleep(ms: number): Promise<void>;
}

export interface ResilientResult<T> {
  value: T;
  mode: ResilienceMode;
  cached: boolean;
  cacheAgeMs?: number;
  attempts: number;
}

// ---------------------------------------------------------------------------
// Token bucket. Refills lazily: no timers, no polling, no drift.
// ---------------------------------------------------------------------------
class TokenBucket {
  private tokens: number;
  private lastRefillMs: number;

  constructor(
    private readonly capacity: number,
    private readonly refillPerSecond: number,
    private readonly clock: Clock,
  ) {
    this.tokens = capacity;
    this.lastRefillMs = clock.now();
  }

  /**
   * Attempt to take one token. Returns the number of ms the caller should
   * wait before trying again, or 0 if a token was taken.
   */
  tryTake(): { ok: true } | { ok: false; waitMs: number } {
    const now = this.clock.now();
    const elapsedSec = (now - this.lastRefillMs) / 1000;
    this.tokens = Math.min(
      this.capacity,
      this.tokens + elapsedSec * this.refillPerSecond,
    );
    this.lastRefillMs = now;

    if (this.tokens >= 1) {
      this.tokens -= 1;
      return { ok: true };
    }
    const missing = 1 - this.tokens;
    return { ok: false, waitMs: Math.ceil((missing / this.refillPerSecond) * 1000) };
  }
}

// ---------------------------------------------------------------------------
// Circuit breaker. Three states: closed, open, half-open.
// ---------------------------------------------------------------------------
type CircuitState = "closed" | "open" | "half-open";

class CircuitBreaker {
  private state: CircuitState = "closed";
  private failures: number[] = []; // timestamps of recent failures
  private openedAtMs = 0;

  constructor(
    private readonly cfg: Pick<
      ResilienceConfig,
      "circuitFailureWindowMs" | "circuitTripThreshold" | "circuitCooldownMs"
    >,
    private readonly clock: Clock,
    private readonly metrics: Metrics,
  ) {}

  private transition(next: CircuitState, reason: string): void {
    if (this.state === next) return;
    this.state = next;
    // Counters are update-once-per-transition, not per-poll. Alert on this
    // counter to catch state changes without a moving-average filter.
    this.metrics.increment("circuit_state_changes", 1);
    this.metrics.gauge("circuit_state_open", next === "open" ? 1 : 0);
  }

  /** Should the caller short-circuit without touching the client? */
  shouldBlock(): { blocked: boolean; retryInMs?: number } {
    const now = this.clock.now();

    if (this.state === "open") {
      if (now - this.openedAtMs >= this.cfg.circuitCooldownMs) {
        // Cooldown elapsed: allow a single probe.
        this.transition("half-open", "cooldown-elapsed");
        return { blocked: false };
      }
      return {
        blocked: true,
        retryInMs: this.cfg.circuitCooldownMs - (now - this.openedAtMs),
      };
    }

    // closed or half-open: allow the attempt.
    return { blocked: false };
  }

  recordSuccess(isProbe: boolean): void {
    if (this.state === "half-open") {
      // A single successful probe returns us to closed. Do NOT count the
      // probe as a normal failure if it had failed.
      this.transition("closed", "probe-succeeded");
      this.failures = [];
    } else if (!isProbe) {
      // Prune failures outside the rolling window on each success.
      const cutoff = this.clock.now() - this.cfg.circuitFailureWindowMs;
      this.failures = this.failures.filter((t) => t >= cutoff);
    }
  }

  recordFailure(isProbe: boolean): void {
    const now = this.clock.now();

    if (this.state === "half-open") {
      // The probe failed. Re-open immediately, and do NOT count the probe
      // as a normal failure for threshold purposes — the breaker is already
      // proven unhealthy when the probe is what is testing it.
      this.openedAtMs = now;
      this.transition("open", "probe-failed");
      return;
    }

    this.failures.push(now);
    const cutoff = now - this.cfg.circuitFailureWindowMs;
    this.failures = this.failures.filter((t) => t >= cutoff);

    if (this.failures.length >= this.cfg.circuitTripThreshold) {
      this.openedAtMs = now;
      this.transition("open", "threshold-reached");
    }
  }

  get current(): CircuitState {
    return this.state;
  }
}

// ---------------------------------------------------------------------------
// Classify the SDK's typed errors. This is the load-bearing part of the
// breaker: string-matching on messages would be brittle and would toggle the
// breaker on a bad request, which is exactly the wrong behaviour.
// ---------------------------------------------------------------------------
function classify(err: unknown): "rate-limited" | "server" | "client" | "network" {
  if (err instanceof RateLimitError) return "rate-limited";
  if (err instanceof InternalServerError) return "server";
  if (err instanceof UnprocessableEntityError) return "client";
  if (err instanceof APITimeoutError) return "network";
  if (err instanceof APIConnectionError) return "network";
  return "server"; // unknown errors: treat as health signal, not client fault
}

// ---------------------------------------------------------------------------
// Full-jitter backoff. Explicitly NOT equal jitter: equal jitter still
// produces synchronised bursts across a fan-out. Full jitter spreads the
// entire [0, base * 2^n] interval.
// ---------------------------------------------------------------------------
function fullJitter(attempt: number, base: number, max: number, rand: number): number {
  const ceiling = Math.min(max, base * 2 ** attempt);
  return Math.floor(rand * ceiling);
}

// ---------------------------------------------------------------------------
// The layered entry point.
// ---------------------------------------------------------------------------
export function createResilientSystemOne<Q extends Record<string, unknown>>(
  client: TypeSafeClient,
  config: ResilienceConfig,
  deps: { clock: Clock; metrics: Metrics; cache: Cache<SystemOneResult<Q>> },
) {
  const bucket = new TokenBucket(
    config.tokensPerBurst,
    config.refillPerSecond,
    deps.clock,
  );
  const breaker = new CircuitBreaker(config, deps.clock, deps.metrics);

  // Queue invariants maintained by `queue`:
  //   1. Bounded depth — never exceeds maxQueueDepth; overflow is degraded.
  //   2. Bounded wait — each waiter has a per-item enqueueTimeoutMs.
  //   3. FIFO fairness — the oldest waiter is admitted first when a token
  //      becomes available.
  //
  // We implement this as a simple promise-chain since the layer is
  // cross-request but single-process; a distributed version would use a
  // shared store and expose head-of-line fairness via a lease.
  let queueDepth = 0;

  async function attempt(
    attemptNo: number,
    isProbe: boolean,
    request: { state: unknown; questions: Q; model?: string },
  ): Promise<SystemOneResult<Q>> {
    try {
      const result = await client.systemOne(request as any);
      breaker.recordSuccess(isProbe);
      return result as unknown as SystemOneResult<Q>;
    } catch (err) {
      const kind = classify(err);

      // A malformed request must NOT count as a breaker failure — retrying
      // will not help and toggling the breaker on a 422 would only hide
      // the real problem (a bug in the caller's question) behind a healthy-
      // looking circuit.
      if (kind === "client") throw err;

      breaker.recordFailure(isProbe);

      // Honour the server's Retry-After hint when present (mirrors the SDK's
      // own logic: prefer the hint, but never trust it blindly).
      let delayMs: number;
      if (err instanceof RateLimitError && typeof err.retryAfterMs === "number") {
        delayMs = Math.min(err.retryAfterMs, config.backoffMaxMs);
      } else {
        delayMs = fullJitter(
          attemptNo,
          config.backoffBaseMs,
          config.backoffMaxMs,
          deps.clock.random(),
        );
      }

      // The SDK owns per-request retries; this layer only handles the
      // cross-request case. We try once more through the queue-drain path;
      // the queue itself is the mechanism for coordinating across callers.
      if (attemptNo >= 2) throw err;
      await deps.clock.sleep(delayMs);
      return attempt(attemptNo + 1, isProbe, request);
    }
  }

  return async function resilientSystemOne(
    request: { state: unknown; questions: Q; model?: string },
  ): Promise<ResilientResult<SystemOneResult<Q>>> {
    const cacheKey = JSON.stringify({ state: request.state, questions: request.questions });
    const cachedEntry = deps.cache.get(cacheKey);
    const now = deps.clock.now();
    const cacheAgeMs = cachedEntry ? now - cachedEntry.storedAtMs : undefined;
    const cacheFresh = cacheAgeMs !== undefined && cacheAgeMs < config.cacheTtlMs;

    // 1. Breaker gate.
    const gate = breaker.shouldBlock();
    if (gate.blocked) {
      deps.metrics.increment("admitted_degraded", 1);
      if (cachedEntry) {
        return {
          value: cachedEntry.value,
          mode: "circuit-open",
          cached: true,
          cacheAgeMs,
          attempts: 0,
        };
      }
      throw new Error(
        `circuit open; retry in ${gate.retryInMs ?? 0}ms; no cached answer`,
      );
    }

    // 2. Token bucket. If we can take a token, go live.
    const take = bucket.tryTake();
    if (take.ok) {
      deps.metrics.increment("admitted_live", 1);
      const value = await attempt(0, false, request);
      // Only store successful, live answers. Storing degraded answers in the
      // cache would make the fallback path feed on its own failures.
      deps.cache.set(cacheKey, value, deps.clock.now());
      return { value, mode: "live", cached: false, attempts: 1 };
    }

    // 3. Queue path. Bounded depth and bounded wait.
    if (queueDepth >= config.maxQueueDepth) {
      deps.metrics.increment("admitted_degraded", 1);
      if (cachedEntry) {
        return {
          value: cachedEntry.value,
          mode: "degraded",
          cached: true,
          cacheAgeMs,
          attempts: 0,
        };
      }
      throw new Error("queue full and no cached answer available");
    }

    queueDepth += 1;
    deps.metrics.gauge("queue_depth_current", queueDepth);

    try {
      const deadline = now + config.enqueueTimeoutMs;
      // Wait for either a token or the enqueue timeout.
      while (deps.clock.now() < deadline) {
        const wait = Math.min(50, deadline - deps.clock.now());
        await deps.clock.sleep(wait);
        const retake = bucket.tryTake();
        if (retake.ok) {
          deps.metrics.increment("admitted_live", 1);
          const value = await attempt(0, false, request);
          deps.cache.set(cacheKey, value, deps.clock.now());
          return { value, mode: "queued", cached: false, attempts: 1 };
        }
      }

      // Timed out waiting in the queue: admit via degraded.
      deps.metrics.increment("admitted_degraded", 1);
      if (cachedEntry) {
        return {
          value: cachedEntry.value,
          mode: "degraded",
          cached: true,
          cacheAgeMs,
          attempts: 0,
        };
      }
      throw new Error("enqueue timeout and no cached answer available");
    } finally {
      queueDepth -= 1;
      deps.metrics.gauge("queue_depth_current", queueDepth);
    }
  };
}
