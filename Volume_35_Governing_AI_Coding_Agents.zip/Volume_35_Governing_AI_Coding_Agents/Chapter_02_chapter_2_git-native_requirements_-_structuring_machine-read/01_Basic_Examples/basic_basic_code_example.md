<!--
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
-->

<!--
Source File: basic_basic_code_example.md
Description: Basic Code Example
==========================================
-->

<!-- docs/spec/chat.md -->

# Chat Stream Specification

This document defines the observable contract of the SaaS chatbot's
streaming endpoint. Every rule below is a commitment the customer can
rely on and that our CI gate must guarantee.

## Streaming

r[chat.stream.token-flow]
The chat endpoint MUST deliver model tokens to the browser incrementally, so
that the first token is visible before the model finishes generation.

r[chat.stream.sse-flush]
The chat endpoint MUST emit `text/event-stream` frames and flush the transport
on every chunk so intermediate proxies do not coalesce tokens.

## Resilience

r[chat.async.guaranteed-cleanup]
Every async model call MUST release its transport connection in a `finally`
block, whether it resolves, rejects, or is aborted by the client.

r[chat.async.try-catch-boundary]
Every call to the model provider MUST be wrapped in `try...catch` that logs the
failure and returns a typed error object to the caller.
