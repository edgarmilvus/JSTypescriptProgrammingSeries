/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part4.ts
Description: Basic Code Example
==========================================
*/

// app/api/chat/route.ts
//
// Streaming SSE handler for the SaaS chatbot. Every function in this file
// that implements an observable rule from docs/spec/chat.md carries a
// `// r[impl <rule-id>]` comment. Every export is intentionally narrow so
// the coverage view can attribute behavior precisely.

import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

/** A discriminated union for every failure the handler can surface. */
type ChatError =
  | { kind: "provider"; message: string; retryable: boolean }
  | { kind: "aborted"; message: string; retryable: false }
  | { kind: "internal"; message: string; retryable: false };

/** Narrow shape of the JSON body the client is allowed to send. */
interface ChatRequestBody {
  prompt: string;
  model?: string;
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Classify an unknown thrown value into our typed error envelope.
 * Extracted so both the streaming path and the fallback path share
 * exactly one implementation of the catch logic.
 */
function classifyError(error: unknown, signal: AbortSignal): ChatError {
  if (signal.aborted) {
    return { kind: "aborted", message: "client disconnected", retryable: false };
  }
  if (error instanceof OpenAI.APIError) {
    return {
      kind: "provider",
      message: `model provider returned ${error.status}`,
      retryable: error.status >= 500 || error.status === 429,
    };
  }
  return {
    kind: "internal",
    message: error instanceof Error ? error.message : "unknown failure",
    retryable: false,
  };
}

/**
 * The route handler. Its responsibilities:
 *   1. Validate the request body (fail fast, typed error).
 *   2. Open a streaming model call.
 *   3. Push each delta into the response stream.
 *   4. Guarantee that the stream is closed in every termination path.
 *
 * Tracey rules satisfied by this function:
 *   - chat.stream.token-flow      (incremental delivery)
 *   - chat.stream.sse-flush       (SSE framing + flush)
 *   - chat.async.try-catch-boundary
 *   - chat.async.guaranteed-cleanup
 */
// r[impl chat.stream.token-flow]
// r[impl chat.stream.sse-flush]
// r[impl chat.async.try-catch-boundary]
// r[impl chat.async.guaranteed-cleanup]
export async function POST(request: NextRequest): Promise<Response> {
  // Parse and validate the body *before* we allocate any streaming resources,
  // so a malformed request never taxes the provider connection pool.
  let body: ChatRequestBody;
  try {
    body = (await request.json()) as ChatRequestBody;
  } catch {
    return NextResponse.json(
      { kind: "internal", message: "invalid JSON body", retryable: false } satisfies ChatError,
      { status: 400 },
    );
  }

  if (typeof body.prompt !== "string" || body.prompt.trim().length === 0) {
    return NextResponse.json(
      { kind: "internal", message: "prompt must be a non-empty string", retryable: false } satisfies ChatError,
      { status: 400 },
    );
  }

  // The abort signal is propagated from the inbound request so a browser
  // disconnect propagates through OpenAI's SDK and cancels upstream billing.
  const upstreamAbort = new AbortController();
  request.signal.addEventListener("abort", () => upstreamAbort.abort());

  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let providerStream: AsyncIterable<OpenAI.Chat.Completions.ChatCompletionChunk> | null = null;

      try {
        // Open the streaming call. Any connection acquired here must be
        // released in the `finally` block below.
        providerStream = await client.chat.completions.create(
          {
            model: body.model ?? "gpt-4o-mini",
            messages: [{ role: "user", content: body.prompt }],
            stream: true,
          },
          { signal: upstreamAbort.signal },
        );

        // Emit each delta as its own SSE frame. The `\n\n` terminator is
        // what makes an intermediate proxy flush rather than coalesce.
        for await (const chunk of providerStream) {
          const delta = chunk.choices[0]?.delta?.content ?? "";
          if (delta.length === 0) {
            continue;
          }
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`),
          );
        }

        // Sentinel frame so the client knows the stream finished cleanly.
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`));
      } catch (error) {
        const classified = classifyError(error, upstreamAbort.signal);
        // Even in the error path we send a well-formed SSE frame, because
        // the browser's EventSource parser is already mid-stream.
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ error: classified })}\n\n`),
        );
      } finally {
        // This block is the *only* place the controller is closed. If we
        // ever move `controller.close()` above the try/catch, a thrown
        // provider error will leave the browser hanging on a half-open
        // EventSource.
        try {
          controller.close();
        } catch {
          // The consumer may have already closed us on abort; that is fine.
        }
        if (providerStream && typeof (providerStream as { return?: Function }).return === "function") {
          // Explicitly drain the async iterator so the SDK releases the
          // underlying TCP connection back to the pool immediately.
          await (providerStream as AsyncIterableIterator<unknown>).return?.();
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
