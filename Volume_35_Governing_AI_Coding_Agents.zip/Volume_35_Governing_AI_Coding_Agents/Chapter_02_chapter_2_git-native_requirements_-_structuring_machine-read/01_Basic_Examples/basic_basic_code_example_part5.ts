/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: basic_basic_code_example_part5.ts
Description: Basic Code Example
==========================================
*/

// tests/chat.test.ts
//
// Every `// r[verify <rule-id>]` here is a machine-checkable claim that
// this test exercises the observable behavior the rule describes. The
// `chat.stream.sse-flush` rule is verified by asserting that the response
// Content-Type and framing match `text/event-stream`.

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { NextRequest } from "next/server";

// Mock the OpenAI SDK so the test never touches the network. The mock must
// expose an async-iterable `create` so the route's `for await` loop drains
// deterministically.
vi.mock("openai", () => {
  class APIError extends Error {
    status: number;
    constructor(status: number, message: string) {
      super(message);
      this.status = status;
    }
  }
  const fakeChunks = [
    { choices: [{ delta: { content: "Hello" } }] },
    { choices: [{ delta: { content: ", " } }] },
    { choices: [{ delta: { content: "world!" } }] },
  ];
  return {
    default: class OpenAI {
      static APIError = APIError;
      chat = {
        completions: {
          create: async () => {
            async function* gen() {
              for (const c of fakeChunks) {
                yield c;
              }
            }
            return gen();
          },
        },
      };
      constructor(_opts: unknown) {}
    },
    APIError,
  };
});

// Import *after* the mock is registered.
import { POST } from "../app/api/chat/route";

describe("POST /api/chat", () => {
  beforeEach(() => {
    vi.stubEnv("OPENAI_API_KEY", "test-key");
  });
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("streams tokens incrementally in SSE frames", async () => {
    // r[verify chat.stream.token-flow]
    // r[verify chat.stream.sse-flush]
    const request = new NextRequest("http://localhost/api/chat", {
      method: "POST",
      body: JSON.stringify({ prompt: "hi" }),
      headers: { "content-type": "application/json" },
    });

    const response = await POST(request);
    expect(response.headers.get("content-type")).toContain("text/event-stream");

    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    const frames: string[] = [];
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      frames.push(decoder.decode(value, { stream: true }));
    }

    const combined = frames.join("");
    expect(combined).toContain('"delta":"Hello"');
    expect(combined).toContain('"delta":"world!"');
    expect(combined).toContain('"done":true');
  });

  it("returns a typed error when the provider fails", async () => {
    // r[verify chat.async.try-catch-boundary]
    // A targeted override of the mock for this single test.
    const openai = await import("openai");
    const originalCreate = (openai.default as any).prototype?.chat;
    // We rely on vi.mocked at the module level in a real suite; this snippet
    // demonstrates the annotation placement rather than the full override.
    expect(openai.APIError).toBeTypeOf("function");
  });

  it("closes the stream after the final frame", async () => {
    // r[verify chat.async.guaranteed-cleanup]
    const request = new NextRequest("http://localhost/api/chat", {
      method: "POST",
      body: JSON.stringify({ prompt: "hi" }),
      headers: { "content-type": "application/json" },
    });
    const response = await POST(request);
    const reader = response.body!.getReader();
    while (true) {
      const { done } = await reader.read();
      if (done) break;
    }
    // If `controller.close()` were skipped, `reader.read()` would never
    // resolve `done: true` and this test would time out — which is exactly
    // the failure mode the rule exists to prevent.
    expect(true).toBe(true);
  });
});
