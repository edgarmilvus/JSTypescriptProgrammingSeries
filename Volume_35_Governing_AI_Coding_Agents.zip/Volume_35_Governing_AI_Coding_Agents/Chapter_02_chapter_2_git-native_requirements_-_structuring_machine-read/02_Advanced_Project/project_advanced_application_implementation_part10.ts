/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part10.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/backpressure/controller.ts

/**
 * Snapshot of the reconcile queue, provided by the queue facade.
 * `depth` is the number of transactions awaiting a worker slot.
 * `drainPerSecond` is the measured consumer throughput.
 */
export interface QueueSnapshot {
  readonly depth: number;
  readonly drainPerSecond: number;
}

export interface BackpressurePolicy {
  readonly highWaterMark: number;
}

export type Admission =
  | { readonly kind: "admit" }
  | { readonly kind: "throttle"; readonly retryAfterSeconds: number };

/**
 * Decide whether an inbound request should be admitted or throttled.
 *
 * The policy is deliberately a pure function of the queue snapshot: no
 * time-based or locality-based heuristics, because `REQ-INGEST-002` demands
 * deterministic behaviour under replay so auditors can reproduce any
 * observed 429 from logs alone.
 */
// r[impl REQ-INGEST-002]
export function admitOrThrottle(
  snapshot: QueueSnapshot,
  policy: BackpressurePolicy,
): Admission {
  if (snapshot.depth <= policy.highWaterMark) {
    return { kind: "admit" };
  }

  // Derive Retry-After from measured drain rate. When the consumer is fully
  // stalled (drainPerSecond === 0) we must still bound the header value,
  // otherwise downstream retry storms would re-flood the queue.
  const secondsOfWork = snapshot.depth / Math.max(snapshot.drainPerSecond, 1);
  const retryAfterSeconds = Math.min(60, Math.max(1, Math.ceil(secondsOfWork)));

  return { kind: "throttle", retryAfterSeconds };
}
