/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part11.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/context/augment.ts

/**
 * A requirement extracted from the living intent graph, ready to be
 * concatenated into an LLM prompt.
 */
export interface RequirementExcerpt {
  readonly uid: string;
  readonly title: string;
  readonly statement: string;
  readonly coverage: "covered" | "uncovered" | "stale";
}

/**
 * The port through which the application reads the Tracey daemon. In
 * production this is backed by the MCP `tracey_rule` call; in tests it is a
 * fixture. Either way, the augmentation layer is decoupled from the MCP
 * transport.
 */
export interface IntentGraphReader {
  // r[depends REQ-INGEST-001]
  // r[depends REQ-INGEST-002]
  // r[depends REQ-INGEST-003]
  fetchExcerpts(uids: readonly string[]): Promise<readonly RequirementExcerpt[]>;
}

/**
 * Assemble a single-string context block from a set of requirement excerpts.
 *
 * The wire format is intentionally boring: `## <uid> — <title>` followed by
 * the verbatim statement. LLMs handle this shape far more reliably than
 * bespoke JSON dialects, and the raw text preserves the normative `shall`
 * clauses that audit trails depend on.
 */
// r[impl REQ-INGEST-001]
export function renderContextBlock(
  excerpts: readonly RequirementExcerpt[],
): string {
  return excerpts
    .map((excerpt) => {
      const badge =
        excerpt.coverage === "covered"
          ? "[covered]"
          : excerpt.coverage === "stale"
            ? "[stale]"
            : "[uncovered]";
      return `## ${excerpt.uid} — ${excerpt.title} ${badge}\n\n${excerpt.statement}`;
    })
    .join("\n\n---\n\n");
}
