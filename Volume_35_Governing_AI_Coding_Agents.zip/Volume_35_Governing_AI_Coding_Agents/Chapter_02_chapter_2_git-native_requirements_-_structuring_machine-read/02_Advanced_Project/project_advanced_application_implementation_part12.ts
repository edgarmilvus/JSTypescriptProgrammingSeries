/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part12.ts
Description: Advanced Application Implementation
==========================================
*/

// app/api/reconcile/route.ts

import { admitOrThrottle, type BackpressurePolicy } from "../../../lib/backpressure/controller";
import { renderContextBlock, type IntentGraphReader } from "../../../lib/context/augment";
import type { IdempotencyStore } from "../../../lib/idempotency/store";
import { merchantUnknownAuditEvent, type MerchantRegistry } from "../../../lib/registry/merchants";
import type { InboundTransaction, ReconcileResult, StreamChunk } from "./types";

// The Edge runtime is the correct deployment target for this route because
// `REQ-INGEST-001`'s single-digit-millisecond p99 for idempotency resolution
// is only achievable when the handler is co-located with the edge cache.
export const runtime = "edge";

/**
 * Dependency bundle. Injecting dependencies rather than importing them
 * directly is what allows the Vitest suite to substitute in-memory stores
 * and deterministic clock stubs without monkey-patching module state.
 */
export interface ReconcileDeps {
  readonly idempotency: IdempotencyStore;
  readonly registry: MerchantRegistry;
  readonly backpressure: BackpressurePolicy;
  readonly queueSnapshot: () => Promise<{ depth: number; drainPerSecond: number }>;
  readonly intentGraph: IntentGraphReader;
  readonly reconcile: (
    tx: InboundTransaction,
  ) => AsyncIterable<ReconcileResult>;
}

// In a real deployment these would be resolved from a request-scoped
// container; the module-level default is fine for the walked-through example.
const wiredDeps: ReconcileDeps = {
  idempotency: new (class {
    private store = new Map<string, ReconcileResult>();
    async resolve(m: string, k: string) {
      return this.store.get(`${m}\u0000${k}`) ?? null;
    }
    async record(m: string, k: string, r: ReconcileResult) {
      this.store.set(`${m}\u0000${k}`, r);
    }
  })(),
  registry: new (class {
    async probe(id: string) {
      return id.startsWith("mch_") ? { kind: "known" as const } : { kind: "unknown" as const };
    }
  })(),
  backpressure: { highWaterMark: 5_000 },
  queueSnapshot: async () => ({ depth: 0, drainPerSecond: 1_000 }),
  intentGraph: {
    async fetchExcerpts(uids) {
      return uids.map((uid) => ({
        uid,
        title: "(resolved via Tracey MCP)",
        statement: "(statement fetched at runtime)",
        coverage: "covered" as const,
      }));
    },
  },
  async *reconcile(tx) {
    yield {
      transactionId: tx.transactionId,
      status: "reconciled",
      replayed: false,
    };
  },
};

/**
 * Build a `Response` whose body is a stream of newline-delimited JSON
 * `StreamChunk` envelopes.
 *
 * The stream is *pull-based*: each `enqueue` corresponds to one logical event
 * from the reconcile generator, and the browser consumes them as the
 * Event Loop schedules microtasks. No chunk is buffered server-side, which
 * is what keeps heap pressure constant regardless of transaction count —
 * a hard prerequisite for the sustained-ingress guarantee of
 * `REQ-INGEST-002`.
 */
// r[impl REQ-INGEST-001]
// r[impl REQ-INGEST-002]
// r[impl REQ-INGEST-003]
export function buildStreamingResponse(
  outcome: { kind: "fresh"; tx: InboundTransaction } | { kind: "replay"; result: ReconcileResult },
  deps: ReconcileDeps,
): Response {
  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const write = (chunk: StreamChunk) => {
        controller.enqueue(encoder.encode(`${JSON.stringify(chunk)}\n`));
      };

      try {
        if (outcome.kind === "replay") {
          write({ type: "result", value: outcome.result });
        } else {
          const touched = new Set<string>([
            "REQ-INGEST-001",
            "REQ-INGEST-002",
            "REQ-INGEST-003",
          ]);

          let last: ReconcileResult | undefined;
          for await (const result of deps.reconcile(outcome.tx)) {
            last = result;
            write({ type: "result", value: result });
          }

          if (last !== undefined) {
            await deps.idempotency.record(
              outcome.tx.merchantId,
              outcome.tx.idempotencyKey,
              last,
            );
          }

          const excerpts = await deps.intentGraph.fetchExcerpts([...touched]);
          write({ type: "context", requirementIds: excerpts.map((e) => e.uid) });
        }

        write({ type: "done" });
        controller.close();
      } catch (err) {
        // Errors are surfaced as a final chunk rather than a thrown
        // exception: the browser already has partial results and must not
        // lose them because the tail failed.
        controller.enqueue(
          encoder.encode(
            `${JSON.stringify({
              type: "error",
              message: err instanceof Error ? err.message : String(err),
            })}\n`,
          ),
        );
        controller.close();
      }
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "content-type": "application/x-ndjson",
      "cache-control": "no-store",
      "x-render-context": renderContextBlock([]).length > 0 ? "on" : "off",
    },
  });
}

/**
 * The Edge POST handler. Ordering matters here and mirrors the
 * normative sequence of `REQ-INGEST-001` → `REQ-INGEST-002` → `REQ-INGEST-003`.
 * Short-circuiting idempotency before backpressure is deliberate: a replay
 * must never be throttled, because a client retrying an already-processed
 * transaction must receive its original 200 rather than a 429.
 */
// r[impl REQ-INGEST-001]
export async function POST(request: Request): Promise<Response> {
  const deps = wiredDeps;
  const idempotencyKey = request.headers.get("idempotency-key");

  if (idempotencyKey === null || idempotencyKey.length === 0) {
    return new Response(
      JSON.stringify({ error: "missing_idempotency_key" }),
      { status: 400, headers: { "content-type": "application/json" } },
    );
  }

  const body = (await request.json()) as Omit<InboundTransaction, "idempotencyKey">;
  const tx: InboundTransaction = { ...body, idempotencyKey };

  // 1. Idempotency replay check — before any other gate so a retry is cheap.
  const replay = await deps.idempotency.resolve(tx.merchantId, idempotencyKey);
  if (replay !== null) {
    return buildStreamingResponse({ kind: "replay", result: replay }, deps);
  }

  // 2. Merchant existence — 422 per `REQ-INGEST-003`, and emit the audit
  //    event *before* returning so the event is never lost on a retry.
  const probe = await deps.registry.probe(tx.merchantId);
  if (probe.kind === "unknown") {
    const event = merchantUnknownAuditEvent(tx);
    console.warn(JSON.stringify(event));
    return new Response(
      JSON.stringify({ error: "unknown_merchant", merchantId: tx.merchantId }),
      { status: 422, headers: { "content-type": "application/json" } },
    );
  }

  // 3. Backpressure — 429 with a Retry-After derived from measured drain rate.
  const snapshot = await deps.queueSnapshot();
  const admission = admitOrThrottle(snapshot, deps.backpressure);
  if (admission.kind === "throttle") {
    return new Response(
      JSON.stringify({ error: "queue_saturated" }),
      {
        status: 429,
        headers: {
          "content-type": "application/json",
          "retry-after": String(admission.retryAfterSeconds),
        },
      },
    );
  }

  // 4. Fresh path. The response is streamed back so the client observes
  //    each reconciled transaction as it is produced.
  return buildStreamingResponse({ kind: "fresh", tx }, deps);
}
