/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part13.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/context/tracey-reader.ts

import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import type { RequirementExcerpt, IntentGraphReader } from "./augment";

interface JsonRpcRequest {
  readonly jsonrpc: "2.0";
  readonly id: number;
  readonly method: string;
  readonly params: unknown;
}

interface JsonRpcResponse {
  readonly jsonrpc: "2.0";
  readonly id: number;
  readonly result?: { readonly content: readonly { readonly text: string }[] };
  readonly error?: { readonly code: number; readonly message: string };
}

/**
 * A minimal MCP client that speaks the stdio transport to `tracey mcp`.
 *
 * The client is deliberately tiny: it speaks only the `tools/call` method
 * against `tracey_rule`, because that is the only Tracey capability the
 * augmentation layer consumes. Everything else is surfaced to agents
 * through the same Tracey MCP server directly.
 */
export class TraceyMcpClient implements IntentGraphReader {
  private nextId = 1;
  private pending = new Map<number, (r: JsonRpcResponse) => void>();
  private version = 0;

  constructor(private readonly command = "tracey", private readonly args: string[] = ["mcp"]) {}

  private async callRule(uid: string): Promise<string> {
    const id = this.nextId++;
    const request: JsonRpcRequest = {
      jsonrpc: "2.0",
      id,
      method: "tools/call",
      params: { name: "tracey_rule", arguments: { rule_id: uid } },
    };

    return new Promise<string>((resolve, reject) => {
      const child = spawn(this.command, this.args, { stdio: ["pipe", "pipe", "inherit"] });
      const rl = createInterface({ input: child.stdout });
      rl.once("line", (line) => {
        const parsed = JSON.parse(line) as JsonRpcResponse;
        child.kill();
        if (parsed.error) {
          reject(new Error(parsed.error.message));
          return;
        }
        resolve(parsed.result?.content?.[0]?.text ?? "");
      });
      child.stdin.write(`${JSON.stringify(request)}\n`);
    });
  }

  // r[impl REQ-INGEST-001]
  // r[impl REQ-INGEST-002]
  // r[impl REQ-INGEST-003]
  async fetchExcerpts(uids: readonly string[]): Promise<readonly RequirementExcerpt[]> {
    const results = await Promise.all(uids.map((uid) => this.callRule(uid)));
    return results.map((text, idx) => ({
      uid: uids[idx]!,
      title: text.split("\n")[0] ?? uids[idx]!,
      statement: text,
      coverage: text.includes("[stale]") ? "stale" : "covered",
    }));
  }

  /** Invalidate any in-process cache keyed on the daemon data version. */
  invalidate(newVersion: number): void {
    this.version = newVersion;
  }
}
