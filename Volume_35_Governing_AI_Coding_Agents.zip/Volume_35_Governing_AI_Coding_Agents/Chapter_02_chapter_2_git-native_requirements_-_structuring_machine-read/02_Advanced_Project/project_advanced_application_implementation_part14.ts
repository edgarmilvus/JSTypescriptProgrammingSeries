/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part14.ts
Description: Advanced Application Implementation
==========================================
*/

// tests/reconcile.spec.ts

import { describe, expect, it, vi } from "vitest";
import { admitOrThrottle } from "../lib/backpressure/controller";
import { InMemoryIdempotencyStore } from "../lib/idempotency/store";
import { StaticMerchantRegistry } from "../lib/registry/merchants";
import { renderContextBlock } from "../lib/context/augment";
import { buildStreamingResponse, POST, type ReconcileDeps } from "../app/api/reconcile/route";

/**
 * Collect a `ReadableStream` body into an array of parsed JSON chunks.
 * Used by the streaming tests below to assert on the exact chunk sequence.
 */
async function drain(stream: ReadableStream<Uint8Array>): Promise<unknown[]> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  const chunks: unknown[] = [];
  let buffer = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 1);
      if (line.length > 0) chunks.push(JSON.parse(line));
    }
  }
  return chunks;
}

describe("ingestion requirements", () => {
  // r[verify REQ-INGEST-001]
  it("replays the original result for a repeated idempotency key", async () => {
    const deps: ReconcileDeps = {
      idempotency: new InMemoryIdempotencyStore(),
      registry: new StaticMerchantRegistry(new Set(["mch_acme"])),
      backpressure: { highWaterMark: 100 },
      queueSnapshot: async () => ({ depth: 0, drainPerSecond: 1000 }),
      intentGraph: { async fetchExcerpts() { return []; } },
      async *reconcile() {
        yield { transactionId: "tx_1", status: "reconciled" as const, replayed: false };
      },
    };

    await deps.idempotency.record("mch_acme", "idem-1", {
      transactionId: "tx_1",
      status: "reconciled",
      replayed: false,
    });
    const replay = await deps.idempotency.resolve("mch_acme", "idem-1");
    expect(replay).not.toBeNull();
    expect(replay!.transactionId).toBe("tx_1");
  });

  // r[verify REQ-INGEST-002]
  it("throttles with a bounded Retry-After once the queue is saturated", () => {
    const admission = admitOrThrottle(
      { depth: 10_000, drainPerSecond: 100 },
      { highWaterMark: 5_000 },
    );
    expect(admission.kind).toBe("throttle");
    if (admission.kind === "throttle") {
      expect(admission.retryAfterSeconds).toBeGreaterThanOrEqual(1);
      expect(admission.retryAfterSeconds).toBeLessThanOrEqual(60);
    }
  });

  // r[verify REQ-INGEST-002]
  it("throttles a fully stalled consumer without dividing by zero", () => {
    const admission = admitOrThrottle(
      { depth: 100, drainPerSecond: 0 },
      { highWaterMark: 10 },
    );
    expect(admission.kind).toBe("throttle");
  });

  // r[verify REQ-INGEST-003]
  it("rejects requests whose merchant is unknown with HTTP 422", async () => {
    const request = new Request("https://ledger.test/api/reconcile", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "idempotency-key": "idem-42",
      },
      body: JSON.stringify({
        merchantId: "mch_nope",
        transactionId: "tx_9",
        amountMinor: 1200,
        currency: "USD",
        occurredAt: "2026-01-01T00:00:00Z",
      }),
    });
    const response = await POST(request);
    expect(response.status).toBe(422);
    const body = (await response.json()) as { error: string };
    expect(body.error).toBe("unknown_merchant");
  });

  // r[verify REQ-INGEST-001]
  it("rejects requests missing the Idempotency-Key header", async () => {
    const request = new Request("https://ledger.test/api/reconcile", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        merchantId: "mch_acme",
        transactionId: "tx_1",
        amountMinor: 100,
        currency: "USD",
        occurredAt: "2026-01-01T00:00:00Z",
      }),
    });
    const response = await POST(request);
    expect(response.status).toBe(400);
  });

  // r[verify REQ-INGEST-002]
  it("streams results as newline-delimited JSON and terminates with done", async () => {
    const response = buildStreamingResponse(
      {
        kind: "fresh",
        tx: {
          merchantId: "mch_acme",
          transactionId: "tx_1",
          idempotencyKey: "idem-1",
          amountMinor: 100,
          currency: "USD",
          occurredAt: "2026-01-01T00:00:00Z",
        },
      },
      {
        idempotency: new InMemoryIdempotencyStore(),
        registry: new StaticMerchantRegistry(new Set(["mch_acme"])),
        backpressure: { highWaterMark: 100 },
        queueSnapshot: async () => ({ depth: 0, drainPerSecond: 1000 }),
        intentGraph: {
          async fetchExcerpts(uids) {
            return uids.map((uid) => ({
              uid,
              title: uid,
              statement: "stub",
              coverage: "covered" as const,
            }));
          },
        },
        async *reconcile() {
          yield { transactionId: "tx_1", status: "reconciled" as const, replayed: false };
        },
      },
    );

    const chunks = await drain(response.body!);
    const types = chunks.map((c) => (c as { type: string }).type);
    expect(types).toContain("result");
    expect(types).toContain("context");
    expect(types.at(-1)).toBe("done");
  });

  // r[verify DES-PIPE-001]
  it("records and resolves idempotency entries under distinct merchant scopes", async () => {
    const store = new InMemoryIdempotencyStore();
    await store.record("mch_a", "k", { transactionId: "t", status: "reconciled", replayed: false });
    expect(await store.resolve("mch_b", "k")).toBeNull();
    expect(await store.resolve("mch_a", "k")).not.toBeNull();
  });
});

// r[verify SEC-PCI-002]
describe("audit event shaping", () => {
  it("emits merchant.unknown with the originating transaction ids", async () => {
    const { merchantUnknownAuditEvent } = await import("../lib/registry/merchants");
    const event = merchantUnknownAuditEvent({
      merchantId: "mch_x",
      transactionId: "tx_x",
      idempotencyKey: "k",
      amountMinor: 0,
      currency: "USD",
      occurredAt: "2026-01-01T00:00:00Z",
    });
    expect(event.kind).toBe("merchant.unknown");
    expect(event.merchantId).toBe("mch_x");
    expect(event.transactionId).toBe("tx_x");
  });
});
