/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part7.ts
Description: Advanced Application Implementation
==========================================
*/

// app/api/reconcile/types.ts

/**
 * A single inbound transaction emitted by a merchant integration.
 *
 * The `Idempotency-Key` is required by `REQ-INGEST-001`: the gateway must be
 * able to resolve replays deterministically. Callers that omit it are
 * rejected at the edge before this type is ever constructed.
 */
export interface InboundTransaction {
  readonly merchantId: string;
  readonly transactionId: string;
  readonly idempotencyKey: string;
  readonly amountMinor: number;
  readonly currency: string;
  readonly occurredAt: string; // ISO-8601
}

/**
 * The result of a reconcile pass. `replayed` is true when the response was
 * served from the idempotency cache rather than by re-executing the pipeline.
 */
export interface ReconcileResult {
  readonly transactionId: string;
  readonly status: "reconciled" | "rejected" | "deferred";
  readonly replayed: boolean;
  readonly reason?: string;
}

/**
 * A single chunk emitted on the streaming response. The trailing `[DONE]`
 * sentinel mirrors the OpenAI streaming envelope so the same client parser
 * can consume both.
 */
export type StreamChunk =
  | { readonly type: "result"; readonly value: ReconcileResult }
  | { readonly type: "context"; readonly requirementIds: readonly string[] }
  | { readonly type: "done" };
