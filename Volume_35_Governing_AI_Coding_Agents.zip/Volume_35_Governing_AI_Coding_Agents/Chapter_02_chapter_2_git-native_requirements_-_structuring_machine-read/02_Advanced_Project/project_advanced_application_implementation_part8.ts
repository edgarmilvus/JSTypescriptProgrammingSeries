/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part8.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/idempotency/store.ts

import type { ReconcileResult } from "../../app/api/reconcile/types";

/**
 * A read-through idempotency cache keyed by `(merchantId, idempotencyKey)`.
 *
 * Implementations may be backed by Redis, DynamoDB, or an in-process map;
 * the route handler only requires the interface contract below, and the
 * contract is what `DES-PIPE-001` pins down.
 */
export interface IdempotencyStore {
  /**
   * Resolve a stored result if one exists for this key. Returns `null` when
   * the key has never been seen, or when its stored entry has aged past the
   * retention window declared by `REQ-INGEST-001` (`IDEMPOTENCY_WINDOW: 24h`).
   *
   * @param merchantId     Merchant scope; keys are never shared across tenants.
   * @param idempotencyKey The client-supplied key from the `Idempotency-Key` header.
   * @returns The previously recorded result, or `null` if the key is fresh.
   */
  // r[depends DES-PIPE-001]
  resolve(
    merchantId: string,
    idempotencyKey: string,
  ): Promise<ReconcileResult | null>;

  /**
   * Persist the outcome of a reconcile pass so a subsequent replay resolves
   * without re-executing. Implementations MUST be atomic with respect to
   * `resolve`: a concurrent writer either wins outright or observes the
   * winner's result — never a torn value — to satisfy `REQ-INGEST-001`.
   */
  // r[depends DES-PIPE-001]
  record(
    merchantId: string,
    idempotencyKey: string,
    result: ReconcileResult,
  ): Promise<void>;
}

/**
 * In-memory reference implementation used by the Vitest suite and by local
 * development. It is intentionally not used in production — the retention
 * window is unbounded and no cross-process coordination is performed.
 */
export class InMemoryIdempotencyStore implements IdempotencyStore {
  private readonly map = new Map<string, ReconcileResult>();

  private static key(merchantId: string, idempotencyKey: string): string {
    return `${merchantId}\u0000${idempotencyKey}`;
  }

  // r[impl DES-PIPE-001]
  async resolve(
    merchantId: string,
    idempotencyKey: string,
  ): Promise<ReconcileResult | null> {
    return this.map.get(InMemoryIdempotencyStore.key(merchantId, idempotencyKey)) ?? null;
  }

  // r[impl DES-PIPE-001]
  async record(
    merchantId: string,
    idempotencyKey: string,
    result: ReconcileResult,
  ): Promise<void> {
    this.map.set(InMemoryIdempotencyStore.key(merchantId, idempotencyKey), result);
  }
}
