/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: project_advanced_application_implementation_part9.ts
Description: Advanced Application Implementation
==========================================
*/

// lib/registry/merchants.ts

import type { InboundTransaction } from "../../app/api/reconcile/types";

/**
 * Result of a merchant existence probe. Deliberately a discriminated union
 * rather than `boolean | null`, because `REQ-INGEST-003` requires distinct
 * handling for "known", "unknown", and "registry unavailable" — the latter
 * is a 503, not a 422.
 */
export type MerchantProbe =
  | { readonly kind: "known" }
  | { readonly kind: "unknown" }
  | { readonly kind: "unavailable"; readonly cause: string };

export interface MerchantRegistry {
  // r[depends REQ-INGEST-003]
  probe(merchantId: string): Promise<MerchantProbe>;
}

/**
 * A static registry backed by a plain `Set`. Suitable for tests and for the
 * smoke environment; the production registry delegates to the control-plane
 * merchant service over gRPC.
 */
export class StaticMerchantRegistry implements MerchantRegistry {
  constructor(private readonly known: ReadonlySet<string>) {}

  // r[impl REQ-INGEST-003]
  async probe(merchantId: string): Promise<MerchantProbe> {
    return this.known.has(merchantId) ? { kind: "known" } : { kind: "unknown" };
  }
}

/**
 * The audit event emitted when `REQ-INGEST-003` triggers a rejection. Kept
 * as a narrow factory so the shape stays stable across emitters.
 */
// r[impl SEC-PCI-002]
export function merchantUnknownAuditEvent(
  tx: InboundTransaction,
): {
  readonly kind: "merchant.unknown";
  readonly merchantId: string;
  readonly transactionId: string;
  readonly at: string;
} {
  return {
    kind: "merchant.unknown",
    merchantId: tx.merchantId,
    transactionId: tx.transactionId,
    at: new Date().toISOString(),
  };
}
