/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_1_bootstrapping_a_git-native_intent_graph_for_notif.ts
Description: Solutions and Explanations
==========================================
*/

// This TypeScript module exports every artifact as a string so the solution is
// self-contained. In a real repository, write each string to its target path.

export const notificationPreferencesSdoc = `[DOCUMENT]
TITLE: Notification Preferences
UID: NOTIF-SPEC
VERSION: 1.0.0
DATE: 2026-01-15
CLASSIFICATION: Internal
PREFIX: NOTIF-
OPTIONS:
  MARKUP: Markdown

[GRAMMAR]
ELEMENTS:
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: STATUS
    TYPE: String
    REQUIRED: False
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  - TITLE: PRIORITY
    TYPE: SingleChoice
    REQUIRED: False
    OPTIONS:
    - Must
    - Should
    - May
  - TITLE: VERIFICATION_METHOD
    TYPE: MultipleChoice
    REQUIRED: False
    OPTIONS:
    - Test
    - Analysis
    - Inspection
  - TITLE: TAGS
    TYPE: Tag
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
  - TYPE: Child
  - TYPE: File

[[SECTION]]
TITLE: Preference Model

[REQUIREMENT]
UID: NOTIF-PREF-001
STATUS: Approved
TITLE: Channel Preferences
STATEMENT: >>>
The system shall allow a user to enable or disable each notification channel: email, SMS, push, and in-app.
<<<
RATIONALE: Users must control how they are contacted.
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: channels, preferences
RELATIONS:
- TYPE: Child
  VALUE: NOTIF-PREF-002
- TYPE: File
  VALUE: src/notifications/preferences.ts
- TYPE: File
  VALUE: tests/notifications/preferences.test.ts

[REQUIREMENT]
UID: NOTIF-PREF-002
STATUS: Approved
TITLE: Scoped Preferences
STATEMENT: >>>
The system shall scope notification preferences per user and per notification category.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: scope, categories
RELATIONS:
- TYPE: File
  VALUE: src/notifications/preferences.ts

[[SECTION]]
TITLE: Quiet Hours

[REQUIREMENT]
UID: NOTIF-PREF-003
STATUS: Approved
TITLE: Per-Channel Quiet Hours
STATEMENT: >>>
Where a channel is enabled, the system shall allow the user to configure quiet hours for that channel.
<<<
PRIORITY: Should
VERIFICATION_METHOD: Test
TAGS: quiet-hours
RELATIONS:
- TYPE: Parent
  VALUE: NOTIF-PREF-001
- TYPE: File
  VALUE: src/notifications/quietHours.ts
- TYPE: File
  VALUE: tests/notifications/quietHours.test.ts

[[/SECTION]]
[[/SECTION]]

[[SECTION]]
TITLE: Validation Rules

[[SECTION]]
TITLE: Time Zone Validation

[REQUIREMENT]
UID: NOTIF-VALID-001
STATUS: Approved
TITLE: Reject Malformed Time Zones
STATEMENT: >>>
When a user submits a time zone, the system shall reject the request if the time zone is not a valid IANA time zone identifier.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: validation, timezone
RELATIONS:
- TYPE: Parent
  VALUE: NOTIF-PREF-003
- TYPE: File
  VALUE: src/notifications/validation.ts
- TYPE: File
  VALUE: tests/notifications/validation.test.ts

[REQUIREMENT]
UID: NOTIF-VALID-002
STATUS: Approved
TITLE: Reject Malformed Quiet-Hour Ranges
STATEMENT: >>>
When a user submits quiet hours, the system shall reject the request if the start or end time is malformed, or if the range exceeds 24 hours.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: validation, quiet-hours
RELATIONS:
- TYPE: Parent
  VALUE: NOTIF-PREF-003
- TYPE: File
  VALUE: src/notifications/validation.ts
- TYPE: File
  VALUE: tests/notifications/validation.test.ts

[[/SECTION]]
[[/SECTION]]

[[SECTION]]
TITLE: Delivery Behavior

[REQUIREMENT]
UID: NOTIF-DELIV-001
STATUS: Approved
TITLE: Respect User Preferences
STATEMENT: >>>
The system shall not deliver a notification on a channel that the user has disabled.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: delivery
RELATIONS:
- TYPE: Parent
  VALUE: NOTIF-PREF-001
- TYPE: File
  VALUE: src/notifications/delivery.ts
- TYPE: File
  VALUE: tests/notifications/delivery.test.ts

[REQUIREMENT]
UID: NOTIF-DELIV-002
STATUS: Approved
TITLE: System-Critical Override
STATEMENT: >>>
If a notification is marked system-critical, then the system shall deliver it even if the channel is disabled or quiet hours are active.
<<<
RATIONALE: Safety and security alerts must not be silenced.
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: delivery, critical
RELATIONS:
- TYPE: Parent
  VALUE: NOTIF-DELIV-001
- TYPE: File
  VALUE: src/notifications/delivery.ts
- TYPE: File
  VALUE: tests/notifications/delivery.test.ts

[[/SECTION]]

[[SECTION]]
TITLE: Audit and Compliance

[REQUIREMENT]
UID: NOTIF-AUDIT-001
STATUS: Approved
TITLE: Audit Preference Changes
STATEMENT: >>>
The system shall record an audit event for every change to a user's notification preferences.
<<<
RATIONALE: Compliance requires a tamper-evident history of preference changes.
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: audit
RELATIONS:
- TYPE: File
  VALUE: src/notifications/audit.ts
- TYPE: File
  VALUE: tests/notifications/audit.test.ts

[[/SECTION]]

[[SECTION]]
TITLE: Public TypeScript API

[REQUIREMENT]
UID: NOTIF-API-001
STATUS: Approved
TITLE: Stable TypeScript API
STATEMENT: >>>
The system shall expose a stable TypeScript API with functions to read and update notification preferences.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
TAGS: api
RELATIONS:
- TYPE: File
  VALUE: src/notifications/api.ts
- TYPE: File
  VALUE: tests/notifications/api.test.ts

[[/SECTION]]
`;

export const traceyConfig = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name notification-preferences
        include (docs/spec/**/*.sdoc)
        impls (
            {
                name typescript
                include (src/**/*.ts)
                test_include (tests/**/*.test.ts)
                exclude (dist/** coverage/**)
            }
        )
    }
)
`;

export const preferencesTs = `export interface Preferences {
  channels: { email: boolean; sms: boolean; push: boolean; inApp: boolean };
  quietHours?: Record<string, { start: string; end: string; timeZone: string }>;
}

// r[impl NOTIF-PREF-001]
export function setChannelEnabled(
  prefs: Preferences,
  channel: keyof Preferences['channels'],
  enabled: boolean
): Preferences {
  return { ...prefs, channels: { ...prefs.channels, [channel]: enabled } };
}

// r[impl NOTIF-PREF-002]
export function getPreferencesForCategory(
  prefs: Preferences,
  _userId: string,
  _category: string
): Preferences {
  return prefs;
}
`;

export const validationTs = `export function isValidIanaTimeZone(tz: string): boolean {
  try {
    Intl.DateTimeFormat(undefined, { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

// r[impl NOTIF-VALID-001]
export function validateTimeZone(tz: string): void {
  if (!isValidIanaTimeZone(tz)) throw new Error('Invalid IANA time zone');
}

// r[impl NOTIF-VALID-002]
export function validateQuietHours(start: string, end: string): void {
  if (!/^\\d{2}:\\d{2}$/.test(start) || !/^\\d{2}:\\d{2}$/.test(end)) {
    throw new Error('Invalid quiet hours');
  }
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  if (sh > 23 || eh > 23 || sm > 59 || em > 59) {
    throw new Error('Invalid quiet hours');
  }
  const startMin = sh * 60 + sm;
  const endMin = eh * 60 + em;
  const duration = endMin >= startMin ? endMin - startMin : 24 * 60 - startMin + endMin;
  if (duration > 24 * 60) throw new Error('Invalid quiet hours');
}
`;

export const validationTestTs = `import { describe, expect, it } from 'vitest';
import { validateQuietHours, validateTimeZone } from '../../src/notifications/validation';

// r[verify NOTIF-VALID-001]
describe('validateTimeZone', () => {
  it('accepts a valid IANA time zone', () => {
    expect(() => validateTimeZone('Europe/Paris')).not.toThrow();
  });

  it('rejects a malformed time zone', () => {
    expect(() => validateTimeZone('Mars/OlympusMons')).toThrow(/Invalid IANA time zone/);
  });
});

// r[verify NOTIF-VALID-002]
describe('validateQuietHours', () => {
  it('accepts overnight quiet hours', () => {
    expect(() => validateQuietHours('22:00', '06:00')).not.toThrow();
  });

  it('rejects malformed quiet hours', () => {
    expect(() => validateQuietHours('25:00', '06:00')).toThrow(/Invalid quiet hours/);
  });
});
`;

export const validationCommands = `
strictdoc export --formats=html .
tracey query status
tracey query uncovered
tracey query untested
tracey query validate --deny warnings
`;
