/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_2_custom_grammar_and_role-based_traceability_for_a.tsx
Description: Solutions and Explanations
==========================================
*/

export const safetySpecSdoc = `[DOCUMENT]
TITLE: Safety Status Panel
UID: SAFETY-STATUS-PANEL
VERSION: 1.0.0
DATE: 2026-01-15
CLASSIFICATION: Internal
PREFIX: SAFETY-
OPTIONS:
  MARKUP: Markdown

[GRAMMAR]
ELEMENTS:
- TAG: SYSTEM_REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: ASIL
    TYPE: SingleChoice
    REQUIRED: True
    OPTIONS:
    - A
    - B
    - C
    - D
  - TITLE: SAFETY_GOAL
    TYPE: String
    REQUIRED: False
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  - TITLE: PRIORITY
    TYPE: SingleChoice
    REQUIRED: True
    OPTIONS:
    - Must
    - Should
    - May
  - TITLE: VERIFICATION_METHOD
    TYPE: MultipleChoice
    REQUIRED: True
    OPTIONS:
    - Test
    - Analysis
    - Inspection
    - Demonstration
  - TITLE: COMMENT
    TYPE: String
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
    ROLE: Refines
    REVERSE_ROLE: RefinedBy
  - TYPE: Parent
    ROLE: Implements
    REVERSE_ROLE: ImplementedBy
  - TYPE: Parent
    ROLE: Verifies
    REVERSE_ROLE: VerifiedBy
  - TYPE: Child
  - TYPE: File

- TAG: SOFTWARE_REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: ASIL
    TYPE: SingleChoice
    REQUIRED: True
    OPTIONS:
    - A
    - B
    - C
    - D
  - TITLE: IMPLEMENTATION_CONSTRAINT
    TYPE: String
    REQUIRED: False
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  - TITLE: PRIORITY
    TYPE: SingleChoice
    REQUIRED: True
    OPTIONS:
    - Must
    - Should
    - May
  - TITLE: VERIFICATION_METHOD
    TYPE: MultipleChoice
    REQUIRED: True
    OPTIONS:
    - Test
    - Analysis
    - Inspection
    - Demonstration
  - TITLE: COMMENT
    TYPE: String
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
    ROLE: Refines
    REVERSE_ROLE: RefinedBy
  - TYPE: Parent
    ROLE: Implements
    REVERSE_ROLE: ImplementedBy
  - TYPE: Parent
    ROLE: Verifies
    REVERSE_ROLE: VerifiedBy
  - TYPE: Child
  - TYPE: File

- TAG: TEST_CASE
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: VERIFICATION_METHOD
    TYPE: MultipleChoice
    REQUIRED: False
    OPTIONS:
    - Test
    - Analysis
    - Inspection
    - Demonstration
  RELATIONS:
  - TYPE: Parent
    ROLE: Verifies
    REVERSE_ROLE: VerifiedBy

[[SECTION]]
TITLE: System Intent

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-001
ASIL: D
SAFETY_GOAL: Ensure operator is aware of safety state.
TITLE: Display Safety Status
STATEMENT: >>>
The SafetyStatusPanel shall display the current safety state as one of: normal, degraded, or failSafe.
<<<
RATIONALE: Operators must know the device safety state at all times.
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: File
  VALUE: src/SafetyStatusPanel.tsx
- TYPE: File
  VALUE: tests/SafetyStatusPanel.test.tsx

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-002
ASIL: D
SAFETY_GOAL: Ensure fail-safe is never hidden.
TITLE: Fail-Safe Visibility
STATEMENT: >>>
The SafetyStatusPanel shall never hide a failSafe status behind a collapsed panel.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-003
ASIL: D
SAFETY_GOAL: Ensure status is not color-only.
TITLE: Non-Color Status Indicator
STATEMENT: >>>
The SafetyStatusPanel shall not rely on color alone to communicate status.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-004
ASIL: D
SAFETY_GOAL: Ensure accessible status changes.
TITLE: Accessible Live Region
STATEMENT: >>>
The SafetyStatusPanel shall expose an accessible live region so screen readers announce status changes.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-005
ASIL: D
SAFETY_GOAL: Provide details for degraded and fail-safe.
TITLE: Details on Degraded and Fail-Safe
STATEMENT: >>>
When the status is degraded or failSafe, the SafetyStatusPanel shall render a details section.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test

[SYSTEM_REQUIREMENT]
UID: SAFETY-SYS-006
ASIL: D
SAFETY_GOAL: Allow acknowledgement.
TITLE: Acknowledge Callback
STATEMENT: >>>
When the user acknowledges a warning, the SafetyStatusPanel shall call the optional onAcknowledge callback.
<<<
PRIORITY: Should
VERIFICATION_METHOD: Test

[[/SECTION]]

[[SECTION]]
TITLE: Software Behavior

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-001
ASIL: D
IMPLEMENTATION_CONSTRAINT: Pure presentational component.
TITLE: Status Prop
STATEMENT: >>>
The SafetyStatusPanel shall accept a status prop with values normal, degraded, or failSafe.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-001
  ROLE: Refines
- TYPE: File
  VALUE: src/SafetyStatusPanel.tsx
- TYPE: File
  VALUE: tests/SafetyStatusPanel.test.tsx

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-002
ASIL: D
TITLE: Human-Readable Label
STATEMENT: >>>
The SafetyStatusPanel shall display a human-readable label for each status.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-001
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-003
ASIL: D
TITLE: Status Icon
STATEMENT: >>>
The SafetyStatusPanel shall display an icon for each status.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-001
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-004
ASIL: D
TITLE: Live Region
STATEMENT: >>>
The SafetyStatusPanel shall render an element with role="status" and aria-live="polite" that contains the current status label.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-004
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-005
ASIL: D
TITLE: Non-Color Text
STATEMENT: >>>
The SafetyStatusPanel shall include visible text that indicates the status, independent of color.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-003
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-006
ASIL: D
TITLE: Details Section
STATEMENT: >>>
When status is degraded or failSafe, the SafetyStatusPanel shall render a details section with a data-testid="details".
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-005
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-007
ASIL: D
TITLE: Acknowledge Button
STATEMENT: >>>
When onAcknowledge is provided and status is degraded or failSafe, the SafetyStatusPanel shall render an Acknowledge button that calls onAcknowledge.
<<<
PRIORITY: Should
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-006
  ROLE: Implements

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-008
ASIL: D
TITLE: Test Id
STATEMENT: >>>
The SafetyStatusPanel shall accept an optional testId prop and apply it as data-testid on the root element.
<<<
PRIORITY: Should
VERIFICATION_METHOD: Test

[[/SECTION]]

[[SECTION]]
TITLE: Accessibility

[SOFTWARE_REQUIREMENT]
UID: SAFETY-SW-009
ASIL: D
TITLE: Keyboard Access
STATEMENT: >>>
The SafetyStatusPanel shall make the Acknowledge button keyboard focusable.
<<<
PRIORITY: Must
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SYS-006
  ROLE: Implements

[[/SECTION]]

[[SECTION]]
TITLE: Verification

[TEST_CASE]
UID: SAFETY-TEST-001
TITLE: Verify normal status
STATEMENT: The test shall render normal status and assert the label and live region.
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SW-001
  ROLE: Verifies

[TEST_CASE]
UID: SAFETY-TEST-002
TITLE: Verify fail-safe visibility
STATEMENT: The test shall render failSafe and assert the details section is visible.
VERIFICATION_METHOD: Test
RELATIONS:
- TYPE: Parent
  VALUE: SAFETY-SW-006
  ROLE: Verifies

[[/SECTION]]
`;

export const safetyPanelTsx = `import React from 'react';

export type SafetyStatus = 'normal' | 'degraded' | 'failSafe';

export interface SafetyStatusPanelProps {
  status: SafetyStatus;
  onAcknowledge?: () => void;
  testId?: string;
}

const LABELS: Record<SafetyStatus, string> = {
  normal: 'Normal',
  degraded: 'Degraded',
  failSafe: 'Fail Safe',
};

const ICONS: Record<SafetyStatus, string> = {
  normal: '✓',
  degraded: '⚠',
  failSafe: '⛔',
};

// r[impl SAFETY-SW-001]
export function SafetyStatusPanel({ status, onAcknowledge, testId }: SafetyStatusPanelProps) {
  const label = LABELS[status];
  const icon = ICONS[status];
  const showDetails = status === 'degraded' || status === 'failSafe';

  return (
    <section data-testid={testId} aria-label="Safety status">
      <div role="status" aria-live="polite">
        <span aria-hidden="true">{icon}</span>
        <span>{label}</span>
      </div>
      {showDetails && (
        <div data-testid="details">
          <p>Safety state requires attention.</p>
          {onAcknowledge && (
            <button type="button" onClick={onAcknowledge}>
              Acknowledge
            </button>
          )}
        </div>
      )}
    </section>
  );
}
`;

export const safetyPanelTestTsx = `import { render, screen, fireEvent } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { SafetyStatusPanel } from '../src/SafetyStatusPanel';

// r[verify SAFETY-SW-001]
it('renders normal status', () => {
  render(<SafetyStatusPanel status="normal" />);
  expect(screen.getByRole('status')).toHaveTextContent('Normal');
});

// r[verify SAFETY-SW-006]
it('shows details for failSafe', () => {
  render(<SafetyStatusPanel status="failSafe" />);
  expect(screen.getByTestId('details')).toBeVisible();
});

// r[verify SAFETY-SW-007]
it('calls onAcknowledge', () => {
  const onAcknowledge = vi.fn();
  render(<SafetyStatusPanel status="degraded" onAcknowledge={onAcknowledge} />);
  fireEvent.click(screen.getByRole('button', { name: /acknowledge/i }));
  expect(onAcknowledge).toHaveBeenCalledTimes(1);
});
`;

export const traceyConfig = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name safety-status-panel
        include (docs/spec/**/*.sdoc)
        impls (
            {
                name react
                include (src/**/*.tsx src/**/*.ts)
                test_include (tests/**/*.test.tsx tests/**/*.test.ts)
                exclude (node_modules/** dist/** coverage/**)
            }
        )
    }
)
`;
