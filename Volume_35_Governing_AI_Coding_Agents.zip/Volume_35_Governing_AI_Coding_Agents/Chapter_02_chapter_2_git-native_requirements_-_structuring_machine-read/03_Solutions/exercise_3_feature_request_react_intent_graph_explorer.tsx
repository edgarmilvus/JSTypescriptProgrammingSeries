/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_3_feature_request_react_intent_graph_explorer.tsx
Description: Solutions and Explanations
==========================================
*/

export const intentGraphSpecSdoc = `[DOCUMENT]
TITLE: Intent Graph Explorer
UID: UI-INTENT-SPEC
VERSION: 1.0.0
DATE: 2026-01-15
CLASSIFICATION: Internal
PREFIX: UI-INTENT-
OPTIONS:
  MARKUP: Markdown

[GRAMMAR]
ELEMENTS:
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  - TITLE: PRIORITY
    TYPE: SingleChoice
    REQUIRED: False
    OPTIONS:
    - Must
    - Should
    - May
  RELATIONS:
  - TYPE: Parent
  - TYPE: Child
  - TYPE: File

[[SECTION]]
TITLE: Data Loading

[REQUIREMENT]
UID: UI-INTENT-LOAD-001
TITLE: Load Snapshot
STATEMENT: >>>
The IntentGraphExplorer shall fetch a JSON snapshot from the configured dataUrl.
<<<
RATIONALE: The component must not call Tracey MCP directly from the browser.
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx
- TYPE: File
  VALUE: scripts/build-intent-graph.ts
- TYPE: File
  VALUE: tests/IntentGraphExplorer.test.tsx

[REQUIREMENT]
UID: UI-INTENT-LOAD-002
TITLE: Bridge Calls Tracey MCP
STATEMENT: >>>
The bridge script shall spawn tracey mcp and call tracey_status, tracey_uncovered, tracey_untested, tracey_stale, tracey_rule, and tracey_validate.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: scripts/build-intent-graph.ts

[REQUIREMENT]
UID: UI-INTENT-LOAD-003
TITLE: Bridge Output Shape
STATEMENT: >>>
The bridge script shall write a JSON object with keys status, uncovered, untested, stale, rules, and validation to public/intent-graph.json.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: scripts/build-intent-graph.ts

[[/SECTION]]

[[SECTION]]
TITLE: Search and Filter

[REQUIREMENT]
UID: UI-INTENT-SEARCH-001
TITLE: Search by UID or Text
STATEMENT: >>>
The IntentGraphExplorer shall filter requirements by UID or statement text.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[REQUIREMENT]
UID: UI-INTENT-FILTER-001
TITLE: Coverage Filter
STATEMENT: >>>
The IntentGraphExplorer shall filter requirements by coverage state: all, covered, uncovered, untested, or stale.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[REQUIREMENT]
UID: UI-INTENT-FILTER-002
TITLE: Spec and Prefix Filter
STATEMENT: >>>
The IntentGraphExplorer shall allow filtering by spec/implementation pair and by requirement ID prefix.
<<<
PRIORITY: Should
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[[/SECTION]]

[[SECTION]]
TITLE: Coverage Display

[REQUIREMENT]
UID: UI-INTENT-DISPLAY-001
TITLE: Requirement List
STATEMENT: >>>
The IntentGraphExplorer shall render a keyboard-accessible list of requirements with UID, title or excerpt, implementation badge, verification badge, and stale badge when applicable.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[REQUIREMENT]
UID: UI-INTENT-DISPLAY-002
TITLE: Details Panel
STATEMENT: >>>
When a requirement is selected, the IntentGraphExplorer shall show its full statement, rationale, implementation references, verification references, and validation messages.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[[/SECTION]]

[[SECTION]]
TITLE: Stale Reference Handling

[REQUIREMENT]
UID: UI-INTENT-STALE-001
TITLE: Stale Badge
STATEMENT: >>>
The IntentGraphExplorer shall display a stale badge for requirements listed by tracey_stale.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx
- TYPE: File
  VALUE: tests/IntentGraphExplorer.test.tsx

[REQUIREMENT]
UID: UI-INTENT-STALE-002
TITLE: Stale Detail Guidance
STATEMENT: >>>
The details panel shall explain that stale references require code review before the annotation version is bumped.
<<<
PRIORITY: Should
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[[/SECTION]]

[[SECTION]]
TITLE: Accessibility

[REQUIREMENT]
UID: UI-INTENT-A11Y-001
TITLE: Keyboard Navigation
STATEMENT: >>>
The IntentGraphExplorer search input, filters, requirement list, and details panel shall be navigable without a mouse.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx

[[/SECTION]]

[[SECTION]]
TITLE: Error States

[REQUIREMENT]
UID: UI-INTENT-ERROR-001
TITLE: Fetch Error
STATEMENT: >>>
When the snapshot fetch fails, the IntentGraphExplorer shall render an accessible error state.
<<<
PRIORITY: Must
RELATIONS:
- TYPE: File
  VALUE: src/IntentGraphExplorer.tsx
- TYPE: File
  VALUE: tests/IntentGraphExplorer.test.tsx

[[/SECTION]]
`;

export const buildIntentGraphTs = `import { spawn } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';

type JsonRpcRequest = { jsonrpc: '2.0'; id: number; method: string; params?: unknown };
type JsonRpcResponse = { jsonrpc: '2.0'; id: number; result?: unknown; error?: { code: number; message: string } };

export class McpClient {
  private child = spawn('tracey', ['mcp'], { stdio: ['pipe', 'pipe', 'inherit'] });
  private nextId = 1;
  private pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void }>();

  constructor() {
    const rl = createInterface({ input: this.child.stdout });
    rl.on('line', (line) => {
      if (!line.trim()) return;
      const msg = JSON.parse(line) as JsonRpcResponse;
      const p = this.pending.get(msg.id);
      if (!p) return;
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message));
      else p.resolve(msg.result);
    });
  }

  callTool(name: string, params: Record<string, unknown> = {}): Promise<unknown> {
    const id = this.nextId++;
    const req: JsonRpcRequest = { jsonrpc: '2.0', id, method: name, params };
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.child.stdin.write(JSON.stringify(req) + '\\n');
    });
  }

  async close() {
    this.child.stdin.end();
  }
}

async function main() {
  const client = new McpClient();
  try {
    const status = await client.callTool('tracey_status');
    const uncovered = await client.callTool('tracey_uncovered');
    const untested = await client.callTool('tracey_untested');
    const stale = await client.callTool('tracey_stale');
    const validation = await client.callTool('tracey_validate');

    const uids = new Set<string>();
    for (const list of [uncovered, untested, stale]) {
      const text = JSON.stringify(list);
      for (const m of text.matchAll(/[A-Z][A-Z0-9_-]+-\\d+/g)) uids.add(m[0]);
    }

    const rules: Record<string, unknown> = {};
    for (const uid of uids) {
      rules[uid] = await client.callTool('tracey_rule', { uid });
    }

    const snapshot = { status, uncovered, untested, stale, rules, validation };
    await writeFile('public/intent-graph.json', JSON.stringify(snapshot, null, 2));
  } finally {
    await client.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
`;

export const intentGraphExplorerTsx = `import React, { useEffect, useMemo, useState } from 'react';

export interface IntentGraphSnapshot {
  status: unknown;
  uncovered: unknown;
  untested: unknown;
  stale: unknown;
  rules: Record<string, any>;
  validation: unknown;
}

export interface IntentGraphExplorerProps {
  dataUrl: string;
  initialSpecImpl?: string;
  initialPrefix?: string;
}

type CoverageFilter = 'all' | 'covered' | 'uncovered' | 'untested' | 'stale';

// r[impl UI-INTENT-LOAD-001]
export function IntentGraphExplorer({ dataUrl, initialPrefix = '' }: IntentGraphExplorerProps) {
  const [snapshot, setSnapshot] = useState<IntentGraphSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [prefix, setPrefix] = useState(initialPrefix);
  const [coverage, setCoverage] = useState<CoverageFilter>('all');
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    fetch(dataUrl)
      .then((r) => { if (!r.ok) throw new Error(\`HTTP \${r.status}\`); return r.json(); })
      .then(setSnapshot)
      .catch((e) => setError(e.message));
  }, [dataUrl]);

  const rules = useMemo(() => Object.entries(snapshot?.rules ?? {}), [snapshot]);
  const filtered = rules.filter(([uid, rule]) => {
    if (prefix && !uid.startsWith(prefix)) return false;
    const text = \`\${uid} \${rule?.statement ?? ''} \${rule?.title ?? ''}\`.toLowerCase();
    if (query && !text.includes(query.toLowerCase())) return false;
    if (coverage === 'uncovered' && !JSON.stringify(snapshot?.uncovered).includes(uid)) return false;
    if (coverage === 'untested' && !JSON.stringify(snapshot?.untested).includes(uid)) return false;
    if (coverage === 'stale' && !JSON.stringify(snapshot?.stale).includes(uid)) return false;
    return true;
  });

  if (error) return <div role="alert">Failed to load intent graph: {error}</div>;
  if (!snapshot) return <div>Loading intent graph…</div>;

  return (
    <section aria-label="Intent graph explorer">
      <input aria-label="Search requirements" value={query} onChange={(e) => setQuery(e.target.value)} />
      <input aria-label="Requirement prefix" value={prefix} onChange={(e) => setPrefix(e.target.value)} />
      <select aria-label="Coverage filter" value={coverage} onChange={(e) => setCoverage(e.target.value as CoverageFilter)}>
        <option value="all">All</option>
        <option value="covered">Covered</option>
        <option value="uncovered">Uncovered</option>
        <option value="untested">Untested</option>
        <option value="stale">Stale</option>
      </select>
      <ul>
        {filtered.map(([uid, rule]) => (
          <li key={uid}>
            <button onClick={() => setSelected(uid)}>{uid}</button>
            <span>{rule?.title ?? rule?.statement?.slice(0, 80)}</span>
          </li>
        ))}
      </ul>
      {selected && (
        <aside aria-label="Requirement details">
          <h2>{selected}</h2>
          <pre>{JSON.stringify(snapshot.rules[selected], null, 2)}</pre>
        </aside>
      )}
    </section>
  );
}
`;

export const intentGraphExplorerTestTsx = `import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { IntentGraphExplorer } from '../src/IntentGraphExplorer';

const fixture = {
  rules: {
    'UI-INTENT-LOAD-001': { title: 'Load Snapshot', statement: 'The component shall fetch JSON.' },
    'UI-INTENT-STALE-001': { title: 'Stale Badge', statement: 'Show stale badge.' },
  },
  uncovered: [],
  untested: [],
  stale: ['UI-INTENT-STALE-001'],
  status: {},
  validation: {},
};

// r[verify UI-INTENT-LOAD-001]
it('renders requirements from a fixture', async () => {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => fixture }));
  render(<IntentGraphExplorer dataUrl="/intent-graph.json" />);
  expect(await screen.findByText('Load Snapshot')).toBeInTheDocument();
});

// r[verify UI-INTENT-SEARCH-001]
it('filters by UID', async () => {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => fixture }));
  render(<IntentGraphExplorer dataUrl="/intent-graph.json" />);
  await screen.findByText('Load Snapshot');
  fireEvent.change(screen.getByLabelText(/search requirements/i), { target: { value: 'STALE' } });
  expect(screen.queryByText('Load Snapshot')).not.toBeInTheDocument();
});

// r[verify UI-INTENT-ERROR-001]
it('shows an error state when fetch fails', async () => {
  vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('network')));
  render(<IntentGraphExplorer dataUrl="/intent-graph.json" />);
  expect(await screen.findByRole('alert')).toHaveTextContent(/failed to load/i);
});
`;

export const traceyConfig = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name intent-graph-explorer
        include (docs/spec/intent-graph-explorer.sdoc)
        impls (
            {
                name frontend
                include (src/**/*.ts src/**/*.tsx scripts/**/*.ts)
                test_include (tests/**/*.test.ts tests/**/*.test.tsx)
                exclude (public/intent-graph.json node_modules/** dist/**)
            }
        )
    }
)
`;

export const agentWorkflowMd = `# AGENT_WORKFLOW.md

Before modifying \`IntentGraphExplorer\`, an AI coding agent MUST:

1. Call \`tracey_status\` to inspect current coverage.
2. Call \`tracey_uncovered\` to find requirements without implementations.
3. Call \`tracey_untested\` to find requirements without verification.
4. Call \`tracey_rule\` with a specific UID to read the exact normative statement.
5. Add \`// r[impl UI-INTENT-...]\` annotations to implementation code.
6. Add \`// r[verify UI-INTENT-...]\` annotations to tests.
7. Run \`tracey_validate\` before finishing.

The agent must never invent UIDs. It must never put \`impl\` annotations in test files.
`;
