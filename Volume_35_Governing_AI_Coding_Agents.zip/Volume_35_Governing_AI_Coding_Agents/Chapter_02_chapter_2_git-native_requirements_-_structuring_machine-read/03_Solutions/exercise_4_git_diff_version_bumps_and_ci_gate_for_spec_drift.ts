/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_4_git_diff_version_bumps_and_ci_gate_for_spec_drift.ts
Description: Solutions and Explanations
==========================================
*/

export const initialSpec = `[DOCUMENT]
TITLE: Auth Notifications
UID: AUTH-NOTIF-SPEC
VERSION: 1.0.0
DATE: 2026-01-15
CLASSIFICATION: Internal
PREFIX: AUTH-
OPTIONS:
  MARKUP: Markdown

[GRAMMAR]
ELEMENTS:
- TAG: REQUIREMENT
  FIELDS:
  - TITLE: UID
    TYPE: String
    REQUIRED: True
  - TITLE: TITLE
    TYPE: String
    REQUIRED: True
  - TITLE: STATEMENT
    TYPE: String
    REQUIRED: True
  - TITLE: RATIONALE
    TYPE: String
    REQUIRED: False
  RELATIONS:
  - TYPE: Parent
  - TYPE: Child
  - TYPE: File

[REQUIREMENT]
UID: AUTH-001
TITLE: Email Notifications
STATEMENT: >>>
The system shall allow email notifications.
<<<
RELATIONS:
- TYPE: File
  VALUE: src/auth.ts
- TYPE: File
  VALUE: tests/auth.test.ts

[REQUIREMENT]
UID: AUTH-002
TITLE: SMS Notifications
STATEMENT: >>>
The system shall allow SMS notifications.
<<<
RELATIONS:
- TYPE: File
  VALUE: src/auth.ts
- TYPE: File
  VALUE: tests/auth.test.ts

[REQUIREMENT]
UID: AUTH-003
TITLE: Push Notifications
STATEMENT: >>>
The system shall allow push notifications.
<<<
RELATIONS:
- TYPE: File
  VALUE: src/auth.ts
- TYPE: File
  VALUE: tests/auth.test.ts
`;

export const changedSpecWithoutBump = `[REQUIREMENT]
UID: AUTH-001
TITLE: Email Notifications
STATEMENT: >>>
The system shall allow email notifications only after email verification.
<<<
RELATIONS:
- TYPE: File
  VALUE: src/auth.ts
- TYPE: File
  VALUE: tests/auth.test.ts
`;

export const bumpedSpec = `[REQUIREMENT]
UID: AUTH-001+2
TITLE: Email Notifications
STATEMENT: >>>
The system shall allow email notifications only after email verification.
<<<
RELATIONS:
- TYPE: File
  VALUE: src/auth.ts
- TYPE: File
  VALUE: tests/auth.test.ts
`;

export const authTs = `export interface User {
  emailVerified: boolean;
}

// r[impl AUTH-001]
export function canSendEmailNotification(user: User): boolean {
  return user.emailVerified;
}

// r[impl AUTH-002]
export function canSendSmsNotification(): boolean {
  return true;
}

// r[impl AUTH-003]
export function canSendPushNotification(): boolean {
  return true;
}
`;

export const authTestTs = `import { describe, expect, it } from 'vitest';
import { canSendEmailNotification } from '../src/auth';

// r[verify AUTH-001]
describe('canSendEmailNotification', () => {
  it('rejects unverified email', () => {
    expect(canSendEmailNotification({ emailVerified: false })).toBe(false);
  });

  it('accepts verified email', () => {
    expect(canSendEmailNotification({ emailVerified: true })).toBe(true);
  });
});
`;

export const traceyConfig = `@schema {id crate:tracey-config@1, cli tracey}

specs (
    {
        name auth-notifications
        include (docs/spec/**/*.sdoc)
        impls (
            {
                name typescript
                include (src/**/*.ts)
                test_include (tests/**/*.test.ts)
                exclude (dist/** coverage/**)
            }
        )
    }
)
`;

export const preCommitHook = `#!/bin/sh
set -e
tracey pre-commit
`;

export const preCommitConfig = `repos:
  - repo: local
    hooks:
      - id: tracey-pre-commit
        name: Tracey Spec Drift Check
        entry: tracey pre-commit
        language: system
        files: ^(docs/.*\\.sdoc|docs/.*\\.md)$
`;

export const githubWorkflow = `name: Specification Assurance Gate
on: [push, pull_request]

jobs:
  verify-intent:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Tracey
        run: |
          curl --proto '=https' --tlsv1.2 -LsSf https://github.com/bearcove/tracey/releases/latest/download/tracey-installer.sh | sh
          echo "$HOME/.cargo/bin" >> $GITHUB_PATH

      - name: Install StrictDoc
        run: pip install strictdoc

      - name: Validate StrictDoc Document Tree
        run: strictdoc export --formats=html .

      - name: Enforce Zero-Warning Spec Coverage & Traceability
        run: tracey query validate --deny warnings
`;

export const driftReviewMd = `# DRIFT_REVIEW.md

## What changed
The requirement \`AUTH-001\` changed from "email notifications" to "email notifications only after email verification".

## How the implementation changed
\`canSendEmailNotification\` now returns \`user.emailVerified\` instead of \`true\`.

## Which tests verify the new behavior
\`tests/auth.test.ts\` rejects unverified email and accepts verified email.

## Why the annotation was bumped only after the code was updated
The annotation bump is a claim that the implementation was reviewed against the new text. Bumping it before updating the code would create false compliance.

## What would have happened if the annotation bump had been skipped
Tracey would continue to report \`AUTH-001\` as stale. The safe failure mode is noisy stale warnings, not silent drift.
`;

export const commandSequence = `
# Initial state
git add docs/spec/auth-notifications.sdoc .config/tracey/config.styx src/auth.ts tests/auth.test.ts
git commit -m "feat(auth): add initial intent graph"

# Change spec without bump
# edit docs/spec/auth-notifications.sdoc
git add docs/spec/auth-notifications.sdoc
tracey pre-commit   # fails: AUTH-001 changed without version bump

# Auto-bump
tracey bump
git diff --cached -- docs/spec

# Update implementation before annotation bump
# edit src/auth.ts and tests/auth.test.ts
tracey query stale   # reports AUTH-001

# Bump annotation
# edit src/auth.ts: r[impl AUTH-001+2]
tracey query stale   # no stale
tracey query validate --deny warnings

# Commit
git add src/auth.ts tests/auth.test.ts
git commit -m "fix(auth): require email verification before notifications"

# Install hook and CI
# copy preCommitHook to .git/hooks/pre-commit or use preCommitConfig
# add .github/workflows/spec-assurance.yml
`;
