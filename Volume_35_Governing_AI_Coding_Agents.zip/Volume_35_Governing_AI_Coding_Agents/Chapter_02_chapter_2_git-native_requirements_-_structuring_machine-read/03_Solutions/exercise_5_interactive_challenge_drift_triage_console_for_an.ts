/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
Source File: exercise_5_interactive_challenge_drift_triage_console_for_an.ts
Description: Solutions and Explanations
==========================================
*/

export const triageMarkdown = `# TRIAGE.md

## Round 1: Establish the Global Picture

Tool: \`tracey_status\`

Simulated output:
- Spec/implementation: payment-processing / typescript
- Prefix: PAY-
- Implementation coverage: 66%
- Verification coverage: 50%
- Stale references: 1

Analysis:
The global picture confirms we are reviewing one spec/implementation pair. Coverage is incomplete and one stale reference exists. We must not edit code from these numbers alone; we need the targeted work queues and exact requirement text.

## Round 2: Find Missing Work

Tools: \`tracey_uncovered\`, \`tracey_untested\`

Simulated output:
- Uncovered: PAY-REFUND-001
- Untested: PAY-REFUND-002, PAY-AUTH-002, PAY-CAPTURE-002

Analysis:
PAY-REFUND-001 needs an implementation reference. PAY-REFUND-002, PAY-AUTH-002, and PAY-CAPTURE-002 need verification references. A requirement can be implemented but untested. Uncovered requirements are often investigated first because missing implementation may indicate the feature does not exist at all. Untested requirements may already work but lack governance evidence.

## Round 3: Inspect Stale References

Tool: \`tracey_stale\`

Simulated output:
- PAY-AUTH-002 in \`src/payment/authorize.ts\`, annotation \`r[impl PAY-AUTH-002]\`, current spec version \`PAY-AUTH-002+2\`

Analysis:
The stale reference means the code was written against version 1, but the spec is now version 2. The code may still be correct, but it has not been reviewed against the new text. We must not simply change the annotation to \`+2\` without reading the new requirement. Next tool: \`tracey_rule PAY-AUTH-002\`.

## Round 4: Read the Exact Requirement

Tool: \`tracey_rule PAY-AUTH-002\`

Simulated output:
- Current statement: "The system shall reject authorization when the token is expired or revoked."
- References: stale implementation in \`authorize.ts\`, one verification reference.

Analysis:
The implementation must handle both expired and revoked tokens. The existing test may only assert expired-token behavior. Before resolving the stale reference, update \`authorize.ts\` to reject revoked tokens, add a Vitest test for revoked tokens, then bump the annotation to \`r[impl PAY-AUTH-002+2]\`.

## Round 5: Run Validation and Interpret Errors

Tool: \`tracey_validate\`

Simulated output:
- Error: Unknown requirement \`PAY-AUTH-003\` referenced in \`src/payment/authorize.ts\`.
- Error: \`impl\` annotation found in test file \`tests/payment/capture.test.ts\`.
- Warning: Cycle detected between \`PAY-AUTH-001\` and \`PAY-AUTH-002\`.
- Warning: \`PAY-REFUND-002\` has implementation reference but no verification reference.

Analysis:
Errors are hard failures. Warnings become failures under \`--deny warnings\`. Fix the unknown UID first: either remove the annotation or add the requirement to the spec if genuinely needed. Fix the \`impl\` in the test file by changing it to \`verify\` or moving it to an implementation file. The cycle warning is a specification/relation problem: the agent manually added both Parent and Child. Remove one side and let StrictDoc calculate the reverse relation.

## Round 6: Produce the Corrective Plan

1. Fix \`PAY-AUTH-003\`: remove the unknown annotation from \`src/payment/authorize.ts\` unless a real requirement is added to the spec.
2. Fix \`tests/payment/capture.test.ts\`: change \`r[impl PAY-CAPTURE-002]\` to \`r[verify PAY-CAPTURE-002]\`.
3. Fix the cycle: remove the redundant Child relation from \`PAY-AUTH-001\` or the Parent relation from \`PAY-AUTH-002\`.
4. Add implementation reference for \`PAY-REFUND-001\` in \`src/payment/refund.ts\`.
5. Add a real verification test for \`PAY-REFUND-002\` asserting that uncaptured refunds are rejected.
6. Correct the test annotation for \`PAY-CAPTURE-002\` so it references \`PAY-CAPTURE-002\`, not \`PAY-CAPTURE-001\`.
7. Update \`PAY-AUTH-002\`: implement revoked-token rejection, add a test, then bump annotation to \`+2\`.
8. Run:
   \`\`\`
   tracey query validate --deny warnings
   tracey query stale
   tracey query uncovered
   tracey query untested
   \`\`\`
9. Commit in separate steps:
   - \`fix(spec): remove auth relation cycle\`
   - \`fix(payment): correct capture test annotation\`
   - \`feat(refund): implement PAY-REFUND-001 and verify PAY-REFUND-002\`
   - \`fix(auth): handle revoked tokens and bump PAY-AUTH-002 annotation\`
10. Attach CI output showing zero errors and zero warnings.

## Prevention
Add \`tracey pre-commit\` and the CI gate \`tracey query validate --deny warnings\`. Instruct the AI agent to call \`tracey_status\`, \`tracey_uncovered\`, \`tracey_untested\`, \`tracey_stale\`, \`tracey_rule\`, and \`tracey_validate\` before and after making changes.
`;

export const triageConsoleTs = `import { McpClient } from './build-intent-graph';

async function triage() {
  const client = new McpClient();
  try {
    const status = await client.callTool('tracey_status');
    const uncovered = await client.callTool('tracey_uncovered');
    const untested = await client.callTool('tracey_untested');
    const stale = await client.callTool('tracey_stale');
    const rule = await client.callTool('tracey_rule', { uid: 'PAY-AUTH-002' });
    const validation = await client.callTool('tracey_validate');

    console.log(JSON.stringify({ status, uncovered, untested, stale, rule, validation }, null, 2));
  } finally {
    await client.close();
  }
}

triage().catch((err) => {
  console.error(err);
  process.exit(1);
});
`;
